; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64 }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:Nodes" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/typed:printer" = type { ptr, %"std/prelude/text:StringBuilder" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:landState" = type { { i64, ptr }, i1 }
%"compiler/typed:Landings" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:LastUses" = type { i64, { i64, ptr }, { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i32, i1, i1 }
%"compiler/typed:argRoot" = type { i64, i1 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:DerivedArg" = type { i64, i64, { i64, [2 x i64] } }
%"compiler/typed:Versions" = type { ptr, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/typed:ViewWalk" = type { ptr, ptr, i64, { ptr, ptr }, { ptr, ptr } }
%"compiler/typed:dropWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:holdWalk" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:SiteInfo" = type { i32, %"compiler/source:Span" }
%"compiler/typed:landLoop" = type { i32, i64, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/typed:wordReader" = type { { i64, ptr }, { ptr, ptr }, i64 }
define dso_local i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t13 = call i1 @compiler_2ftyped_2estmtsBreak(ptr %v0, { i64, ptr } %t9, i32 %a1)
  store i1 %t13, ptr %l8
  br label %bb4
bb4:
  %t14 = load i1, ptr %l8, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l2, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_4e05db95f2fd54c5_981a3a3cc6318dd9)
  unreachable
bb11:
  %t25 = load i64, ptr %l5, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2eEveryTurn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a0, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t30 = call i1 @compiler_2ftyped_2eturnStmt(ptr %v0, ptr %t24, %"compiler/source:Span" %a1)
  store i1 %t30, ptr %l19
  br label %bb5
bb5:
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eFreshViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, ptr %a3c, ptr %a3e, ptr %a4c, ptr %a4e) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca { ptr, ptr }
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l17 = alloca i1
  %l22 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { ptr, ptr }
  %l32 = alloca i64
  %l35 = alloca { i64, ptr }
  %l37 = alloca { i64, [2 x i64] }
  %l45 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l71 = alloca i64
  %l76 = alloca { i64, ptr }
  %l79 = alloca i1
  %l81 = alloca { i64, ptr }
  %l84 = alloca i64
  %l92 = alloca i1
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, [2 x i64] }
  %l98 = alloca { i64, [2 x i64] }
  %l100 = alloca i1
  %l104 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l110 = alloca i1
  %l116 = alloca i64
  %l119 = alloca i1
  %l124 = alloca i64
  %l127 = alloca ptr
  %l129 = alloca i32
  %l134 = alloca { i64, ptr }
  %l136 = alloca { i64, [2 x i64] }
  %l138 = alloca { i64, [2 x i64] }
  %l140 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  %pf3 = insertvalue { ptr, ptr } undef, ptr %a3c, 0
  %pg3 = insertvalue { ptr, ptr } %pf3, ptr %a3e, 1
  %pf4 = insertvalue { ptr, ptr } undef, ptr %a4c, 0
  %pg4 = insertvalue { ptr, ptr } %pf4, ptr %a4e, 1
  store { ptr, ptr } %pg4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t9 = and i64 %t5, %t6
  %t11 = icmp ne i64 %t9, 0
  store i1 %t11, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l17, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb6
bb5:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Call", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t19 = icmp slt i32 %t17, 0
  store i1 %t19, ptr %l22, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l22, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l27, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  store i32 %t27, ptr %l29, !tbaa !23
  %t28 = load { ptr, ptr }, ptr %l4
  store { ptr, ptr } %t28, ptr %l30
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t29)
  store i64 %t31, ptr %l32
  br label %bb10
bb10:
  %t32 = load i64, ptr %l32, !tbaa !24
  %t33 = trunc i64 %t32 to i32
  %t35 = load { ptr, ptr }, ptr %l30
  %t36 = extractvalue { ptr, ptr } %t35, 0
  %t37 = extractvalue { ptr, ptr } %t35, 1
  %t39 = call { i64, ptr } %t36(ptr %t37, ptr %s0, i32 %t33)
  store { i64, ptr } %t39, ptr %l35
  br label %bb11
bb11:
  %t40 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 8
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = load i32, ptr %l29, !tbaa !23
  %t50 = call { i64, [2 x i64] } @compiler_2ftyped_2eScope_2eresult(ptr %v0, ptr %s0, ptr %t47, i32 %t48, { i64, ptr } %t46)
  store { i64, [2 x i64] } %t50, ptr %l37
  br label %bb12
bb12:
  %t51 = load { i64, [2 x i64] }, ptr %l37
  store { i64, [2 x i64] } %t51, ptr %l5
  %t52 = load { i64, [2 x i64] }, ptr %l5
  %t54 = extractvalue { i64, [2 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  store i64 0, ptr %l6, !tbaa !24
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Call", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t63, i64 %t64)
  store i64 %t67, ptr %l45
  br label %bb16
bb16:
  %t68 = load i64, ptr %l45, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb22
bb19:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l52, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb21
bb21:
  %t95 = load i64, ptr %l52, !tbaa !24
  store i64 %t95, ptr %l49, !tbaa !24
  br label %bb22
bb22:
  %t96 = load i64, ptr %l49, !tbaa !24
  store i64 %t96, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t97 = load i64, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb67
bb25:
  br label %bb26
bb26:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load i64, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l2, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  store i64 %t116, ptr %l71, !tbaa !24
  %t117 = load i64, ptr %l71, !tbaa !24
  %t118 = load i64, ptr %l71, !tbaa !24
  %t119 = shl i64 1, %t118
  %t122 = and i64 %t115, %t119
  %t124 = icmp eq i64 %t122, 0
  br i1 %t124, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb28:
  br label %bb29
bb29:
  %t126 = load ptr, ptr %l1, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Call", ptr %t126, i32 0, i32 1
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l76, !tbaa !27
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr ptr, ptr %t133, i64 %t130
  %t135 = load ptr, ptr %t134, !tbaa !39
  %t137 = call i1 @compiler_2ftyped_2eMovedArg(ptr %v1, ptr %t135)
  store i1 %t137, ptr %l79
  br label %bb30
bb30:
  %t138 = load i1, ptr %l79, !tbaa !21
  br i1 %t138, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb32:
  br label %bb33
bb33:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Call", ptr %t139, i32 0, i32 1
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l81, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr ptr, ptr %t146, i64 %t143
  %t148 = load ptr, ptr %t147, !tbaa !39
  %t150 = call i64 @compiler_2ftyped_2efreshText(ptr %v1, ptr %t148, i64 0)
  store i64 %t150, ptr %l84
  br label %bb34
bb34:
  %t151 = load i64, ptr %l84, !tbaa !24
  store i64 %t151, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l12, !tbaa !24
  %t154 = icmp sge i64 %t152, 0
  br i1 %t154, label %bb35, label %bb36
bb35:
  %t156 = load i64, ptr %l12, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Plan", ptr %t157, i32 0, i32 0
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t165 = icmp sge i64 %t156, %t162
  br i1 %t165, label %bb37, label %bb38
bb36:
  br label %bb44
bb37:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb40
bb38:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/typed:Plan", ptr %t167, i32 0, i32 0
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l94, !tbaa !27
  %t171 = load i64, ptr %l12, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr { i64, [2 x i64] }, ptr %t174, i64 %t171
  %t176 = load { i64, [2 x i64] }, ptr %t175
  store { i64, [2 x i64] } %t176, ptr %l96
  %t177 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t177, ptr %l98
  %t180 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l96, ptr %l98)
  store i1 %t180, ptr %l100
  br label %bb39
bb39:
  %t181 = load i1, ptr %l100, !tbaa !21
  %t182 = xor i1 %t181, true
  store i1 %t182, ptr %l92, !tbaa !21
  br label %bb40
bb40:
  %t184 = load i1, ptr %l92, !tbaa !21
  br i1 %t184, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb44:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Call", ptr %t186, i32 0, i32 1
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  store { i64, ptr } %t189, ptr %l104, !tbaa !27
  %t190 = load i64, ptr %l11, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr ptr, ptr %t193, i64 %t190
  %t195 = load ptr, ptr %t194, !tbaa !39
  %t197 = call ptr @compiler_2ftyped_2eCall_2efresh(ptr %v1, ptr %v1, ptr %t195, i64 0)
  store ptr %t197, ptr %l107
  br label %bb45
bb45:
  %t198 = load ptr, ptr %l107, !tbaa !29
  store ptr %t198, ptr %l13, !tbaa !29
  %t199 = load ptr, ptr %l13, !tbaa !29
  %t201 = icmp eq ptr %t199, null
  br i1 %t201, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb48
bb47:
  %t203 = load ptr, ptr %l13, !tbaa !29
  %t205 = getelementptr %"compiler/typed:Call", ptr %t203, i32 0, i32 2
  %t206 = load i32, ptr %t205, !tbaa !23
  %t208 = icmp slt i32 %t206, 0
  store i1 %t208, ptr %l110, !tbaa !21
  br label %bb48
bb48:
  %t210 = load i1, ptr %l110, !tbaa !21
  br i1 %t210, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t212 = load ptr, ptr %l13, !tbaa !29
  %t214 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t212)
  store i64 %t214, ptr %l116
  br label %bb52
bb52:
  %t215 = load i64, ptr %l116, !tbaa !24
  store i64 %t215, ptr %l14, !tbaa !24
  %t216 = load i64, ptr %l14, !tbaa !24
  %t218 = icmp slt i64 %t216, 0
  br i1 %t218, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb56
bb54:
  %t221 = load i64, ptr %l14, !tbaa !24
  %t223 = trunc i64 %t221 to i32
  %t226 = extractvalue { ptr, ptr } %pg3, 0
  %t227 = extractvalue { ptr, ptr } %pg3, 1
  %t229 = call i64 %t226(ptr %t227, i32 %t223)
  store i64 %t229, ptr %l124
  br label %bb55
bb55:
  %t230 = load i64, ptr %l124, !tbaa !24
  %t231 = icmp ne i64 %t230, 0
  store i1 %t231, ptr %l119, !tbaa !21
  br label %bb56
bb56:
  %t233 = load i1, ptr %l119, !tbaa !21
  br i1 %t233, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l127, !tbaa !29
  %t236 = load ptr, ptr %l13, !tbaa !29
  %t238 = getelementptr %"compiler/typed:Call", ptr %t236, i32 0, i32 2
  %t239 = load i32, ptr %t238, !tbaa !23
  store i32 %t239, ptr %l129, !tbaa !23
  %t240 = load { ptr, ptr }, ptr %l4
  %t241 = load i64, ptr %l14, !tbaa !24
  %t243 = trunc i64 %t241 to i32
  %t246 = extractvalue { ptr, ptr } %t240, 0
  %t247 = extractvalue { ptr, ptr } %t240, 1
  %t249 = call { i64, ptr } %t246(ptr %t247, ptr %s4, i32 %t243)
  store { i64, ptr } %t249, ptr %l134
  br label %bb60
bb60:
  %t250 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 8
  %t254 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t257 = load ptr, ptr %l127, !tbaa !29
  %t258 = load i32, ptr %l129, !tbaa !23
  %t260 = call { i64, [2 x i64] } @compiler_2ftyped_2eScope_2eresult(ptr %v0, ptr %s4, ptr %t257, i32 %t258, { i64, ptr } %t256)
  store { i64, [2 x i64] } %t260, ptr %l136
  br label %bb61
bb61:
  %t261 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t261, ptr %l138
  %t264 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l136, ptr %l138)
  store i1 %t264, ptr %l140
  br label %bb62
bb62:
  %t265 = load i1, ptr %l140, !tbaa !21
  %t266 = xor i1 %t265, true
  br i1 %t266, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb66:
  %t269 = load i64, ptr %l10, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l10, !tbaa !24
  br label %bb23
bb67:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eNoCallbackExtern(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue { i64, ptr } undef, i64 95, 0
  %t5 = insertvalue { i64, ptr } %t4, ptr @G_2ecompiler_2ftyped_2enoCallbackNames, 1
  %t7 = load ptr, ptr @__olang_prog_scope
  %t10 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t7, ptr %v0, { i64, ptr } %t5, { i64, ptr } %a0)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/typed:Nodes" @compiler_2ftyped_2eNodes_2eOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca %"compiler/typed:Nodes"
  %rv = alloca %"compiler/typed:Nodes"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"compiler/typed:Nodes" @compiler_2ftyped_3aNodes_2ector(ptr %v1)
  store %"compiler/typed:Nodes" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"compiler/typed:Nodes", ptr %l2
  %t4 = load ptr, ptr %lp1
  store %"compiler/typed:Nodes" %t3, ptr %t4
  %t5 = load ptr, ptr %lp1
  %t8 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 11
  %t9 = load ptr, ptr %t8, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v1, ptr %v0, ptr %t5, ptr %t9)
  br label %bb2
bb2:
  %t12 = load ptr, ptr %lp1
  %t13 = load %"compiler/typed:Nodes", ptr %t12
  store %"compiler/typed:Nodes" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Nodes", ptr %rv
  ret %"compiler/typed:Nodes" %rr
}

define dso_local i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l63 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l73 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb63
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb15
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l17, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 18}
  %t32 = icmp eq i64 %t30, 3
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l1, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = call i1 @compiler_2ftyped_2ePurePlace(ptr %v0, ptr %t40)
  store i1 %t42, ptr %l24
  br label %bb16
bb16:
  %t43 = load i1, ptr %l24, !tbaa !21
  store i1 %t43, ptr %l6, !tbaa !21
  br label %bb63
bb17:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t45 = load ptr, ptr %l25, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb18, label %bb19
bb18:
  %t48 = load ptr, ptr %l25, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 17
  store i1 %t51, ptr %l26, !tbaa !21
  br label %bb19
bb19:
  %t52 = load i1, ptr %l26, !tbaa !21
  br i1 %t52, label %bb20, label %bb21
bb20:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l2, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = call i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %t59)
  store i1 %t61, ptr %l32
  br label %bb23
bb23:
  %t62 = load i1, ptr %l32, !tbaa !21
  store i1 %t62, ptr %l6, !tbaa !21
  br label %bb63
bb24:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t64 = load ptr, ptr %l33, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb25, label %bb26
bb25:
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 9
  store i1 %t70, ptr %l34, !tbaa !21
  br label %bb26
bb26:
  %t71 = load i1, ptr %l34, !tbaa !21
  br i1 %t71, label %bb27, label %bb28
bb27:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t74, i32 0, i32 3
  %t76 = load i32, ptr %t75, !range !{i32 0, i32 4}
  store i32 %t76, ptr %l3
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr { i64, [5 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t80, i32 0, i32 4
  %t82 = load { i64, ptr }, ptr %t81
  store { i64, ptr } %t82, ptr %l4, !tbaa !27
  br label %bb29
bb28:
  br label %bb37
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t84 = load i32, ptr %l3, !range !{i32 0, i32 4}
  %t86 = trunc i64 0 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb32
bb31:
  %t89 = load i32, ptr %l3, !range !{i32 0, i32 4}
  %t91 = trunc i64 3 to i32
  %t92 = icmp eq i32 %t89, %t91
  store i1 %t92, ptr %l43, !tbaa !21
  br label %bb32
bb32:
  %t94 = load i1, ptr %l43, !tbaa !21
  br i1 %t94, label %bb33, label %bb34
bb33:
  %t95 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t96 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t97 = insertvalue { ptr, ptr } %t96, ptr null, 1
  %t100 = extractvalue { ptr, ptr } %t97, 0
  %t101 = extractvalue { ptr, ptr } %t97, 1
  %t102 = call i1 @std_2fprelude_2farray_2eArray_3ccompiler_2ftyped_3aExpr_26_3e_2eEvery_3ccompiler_2ftyped_3aExpr_26_2c_20_3f_3e(ptr %v0, ptr %s4, { i64, ptr } %t95, ptr %t100, ptr %t101)
  store i1 %t102, ptr %l49
  br label %bb35
bb34:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb36
bb35:
  %t103 = load i1, ptr %l49, !tbaa !21
  store i1 %t103, ptr %l46, !tbaa !21
  br label %bb36
bb36:
  %t104 = load i1, ptr %l46, !tbaa !21
  store i1 %t104, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb63
bb37:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t106 = load ptr, ptr %l50, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb38, label %bb39
bb38:
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 18}
  %t112 = icmp eq i64 %t110, 11
  store i1 %t112, ptr %l51, !tbaa !21
  br label %bb39
bb39:
  %t113 = load i1, ptr %l51, !tbaa !21
  br i1 %t113, label %bb40, label %bb41
bb40:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr { i64, [5 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t116, i32 0, i32 2
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l5, !tbaa !29
  br label %bb42
bb41:
  br label %bb58
bb42:
  %t120 = load ptr, ptr %l5, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Cond", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = call i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %t123)
  store i1 %t125, ptr %l58
  br label %bb43
bb43:
  %t126 = load i1, ptr %l58, !tbaa !21
  br i1 %t126, label %bb44, label %bb45
bb44:
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Cond", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = icmp eq ptr %t130, null
  br i1 %t132, label %bb46, label %bb47
bb45:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb53
bb46:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb52
bb47:
  %t134 = load ptr, ptr %l5, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Cond", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = icmp eq ptr %t137, null
  br i1 %t139, label %bb48, label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_d912efc235b928ee_346c19f829a98a12)
  unreachable
bb49:
  br label %bb50
bb50:
  %t141 = load ptr, ptr %l5, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Cond", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = call i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %t144)
  store i1 %t146, ptr %l69
  br label %bb51
bb51:
  %t147 = load i1, ptr %l69, !tbaa !21
  store i1 %t147, ptr %l63, !tbaa !21
  br label %bb52
bb52:
  %t148 = load i1, ptr %l63, !tbaa !21
  store i1 %t148, ptr %l59, !tbaa !21
  br label %bb53
bb53:
  %t149 = load i1, ptr %l59, !tbaa !21
  br i1 %t149, label %bb54, label %bb55
bb54:
  %t150 = load ptr, ptr %l5, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Cond", ptr %t150, i32 0, i32 2
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = call i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %t153)
  store i1 %t155, ptr %l73
  br label %bb56
bb55:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb57
bb56:
  %t156 = load i1, ptr %l73, !tbaa !21
  store i1 %t156, ptr %l70, !tbaa !21
  br label %bb57
bb57:
  %t157 = load i1, ptr %l70, !tbaa !21
  store i1 %t157, ptr %l6, !tbaa !21
  br label %bb63
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_65920c013e21fbcc_fef959193df4a870)
  unreachable
bb63:
  call void @__olang_scope_close(ptr %s0)
  %t158 = load i1, ptr %l6, !tbaa !21
  store i1 %t158, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, [2 x i64] } } @compiler_2ftyped_2eScope_2eOfText(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l8 = alloca i1
  %l11 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l32 = alloca { i64, ptr }
  %l35 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i32
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i32
  %l50 = alloca i64
  %l51 = alloca i32
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i32
  %l67 = alloca i64
  %l68 = alloca i32
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i32
  %l77 = alloca i64
  %l78 = alloca i32
  %l80 = alloca { i64, ptr }
  %l82 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, [2 x i64] } }
  %t5 = alloca { i64, [2 x i64] }, align 8
  %t14 = alloca { i64, [2 x i64] }, align 8
  %t23 = alloca { i64, [2 x i64] }, align 8
  %t32 = alloca { i64, [2 x i64] }, align 8
  %t171 = alloca { i64, [2 x i64] }, align 8
  %t212 = alloca { i64, [2 x i64] }, align 8
  %t224 = alloca { i64, [2 x i64] }, align 8
  %t236 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load i1, ptr %l8, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t7 = load { i64, [2 x i64] }, ptr %t5
  call void @__olang_scope_close(ptr %s0)
  %t9 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, { i64, [2 x i64] } %t7, 1
  store { i32, { i64, [2 x i64] } } %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t12, ptr %l11
  br label %bb5
bb5:
  %t13 = load i1, ptr %l11, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  store { i64, [2 x i64] } zeroinitializer, ptr %t14
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 0
  store i64 3, ptr %t15
  %t16 = load { i64, [2 x i64] }, ptr %t14
  call void @__olang_scope_close(ptr %s0)
  %t18 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, { i64, [2 x i64] } %t16, 1
  store { i32, { i64, [2 x i64] } } %t18, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t21, ptr %l14
  br label %bb9
bb9:
  %t22 = load i1, ptr %l14, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  store { i64, [2 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 0
  store i64 5, ptr %t24
  %t25 = load { i64, [2 x i64] }, ptr %t23
  call void @__olang_scope_close(ptr %s0)
  %t27 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, { i64, [2 x i64] } %t25, 1
  store { i32, { i64, [2 x i64] } } %t27, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t28, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t30, ptr %l17
  br label %bb13
bb13:
  %t31 = load i1, ptr %l17, !tbaa !21
  br i1 %t31, label %bb14, label %bb15
bb14:
  store { i64, [2 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [2 x i64] }, ptr %t32, i32 0, i32 0
  store i64 6, ptr %t33
  %t34 = load { i64, [2 x i64] }, ptr %t32
  call void @__olang_scope_close(ptr %s0)
  %t36 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, { i64, [2 x i64] } %t34, 1
  store { i32, { i64, [2 x i64] } } %t36, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t41 = icmp slt i64 %t39, 2
  br i1 %t41, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t44 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [2 x i64] } } %t44, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t45, ptr %l23, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t46, 0
  store i64 %t49, ptr %l26, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l27, !tbaa !24
  %t52 = icmp sge i64 1, 0
  br i1 %t52, label %bb20, label %bb21
bb20:
  %t54 = load i64, ptr %l26, !tbaa !24
  %t55 = icmp sle i64 1, %t54
  br i1 %t55, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_e2b5788ffb480e02_d22fdd1ca3ce21ae)
  unreachable
bb22:
  %t57 = load i64, ptr %l26, !tbaa !24
  %t58 = load i64, ptr %l27, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e2b5788ffb480e02_d22fdd1ca3ce21ae)
  unreachable
bb24:
  %t61 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l26, !tbaa !24
  %t64 = getelementptr i8, ptr %t62, i64 1
  %t65 = sub i64 %t63, 1
  %t66 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t64, 1
  store { i64, ptr } %t67, ptr %l1, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t69, ptr %l32, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr i8, ptr %t71, i64 0
  %t73 = load i8, ptr %t72, !tbaa !32
  %t75 = icmp eq i8 %t73, 68
  br i1 %t75, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_e2b5788ffb480e02_d22fdd1ca3ce21ae)
  unreachable
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t77 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t79 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s6, { i64, ptr } %t77, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) })
  %t80 = extractvalue { i32, i64 } %t79, 1
  %t81 = extractvalue { i32, i64 } %t79, 0
  store i32 %t81, ptr %l38
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb29, label %ok.83, !prof !99
ok.83:
  store i64 %t80, ptr %l37
  br label %bb28
bb27:
  br label %bb56
bb28:
  %t84 = load i64, ptr %l37, !tbaa !24
  store i64 %t84, ptr %l35, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t86 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [2 x i64] } } %t86, ptr %rv
  br label %ret
bb31:
  %t87 = load i64, ptr %l35, !tbaa !24
  store i64 %t87, ptr %l2, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t88, ptr %l41, !tbaa !27
  %t89 = load i64, ptr %l2, !tbaa !24
  store i64 %t89, ptr %l42, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l43, !tbaa !24
  %t92 = icmp sge i64 0, 0
  br i1 %t92, label %bb32, label %bb33
bb32:
  %t94 = load i64, ptr %l42, !tbaa !24
  %t95 = icmp sle i64 0, %t94
  br i1 %t95, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_2f2480bdb29d1aff_ebfa87e8ba0b0aab)
  unreachable
bb34:
  %t97 = load i64, ptr %l42, !tbaa !24
  %t98 = load i64, ptr %l43, !tbaa !24
  %t99 = icmp sle i64 %t97, %t98
  br i1 %t99, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_2f2480bdb29d1aff_ebfa87e8ba0b0aab)
  unreachable
bb36:
  %t101 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l42, !tbaa !24
  %t104 = getelementptr i8, ptr %t102, i64 0
  %t105 = sub i64 %t103, 0
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %l47, !tbaa !27
  %t108 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 10)
  %t109 = extractvalue { i32, i64 } %t108, 1
  %t110 = extractvalue { i32, i64 } %t108, 0
  store i32 %t110, ptr %l49
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb39, label %ok.112, !prof !99
ok.112:
  store i64 %t109, ptr %l48
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_2f2480bdb29d1aff_ebfa87e8ba0b0aab)
  unreachable
bb38:
  %t113 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t114 = load i64, ptr %l48, !tbaa !24
  %t115 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t113, i64 %t114)
  %t116 = extractvalue { i32, i64 } %t115, 1
  %t117 = extractvalue { i32, i64 } %t115, 0
  store i32 %t117, ptr %l51
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb42, label %ok.119, !prof !99
ok.119:
  store i64 %t116, ptr %l50
  br label %bb41
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t121 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [2 x i64] } } %t121, ptr %rv
  br label %ret
bb41:
  %t122 = load i64, ptr %l50, !tbaa !24
  store i64 %t122, ptr %l40, !tbaa !24
  br label %bb43
bb42:
  br label %bb40
bb43:
  %t123 = load i64, ptr %l40, !tbaa !24
  store i64 %t123, ptr %l3, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t124, ptr %l54, !tbaa !27
  %t125 = load i64, ptr %l2, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l56, !tbaa !24
  %t128 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t128, 0
  store i64 %t131, ptr %l59, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 0
  store i64 %t133, ptr %l60, !tbaa !24
  %t134 = load i64, ptr %l56, !tbaa !24
  %t135 = icmp sge i64 %t134, 0
  br i1 %t135, label %bb44, label %bb45
bb44:
  %t137 = load i64, ptr %l56, !tbaa !24
  %t138 = load i64, ptr %l59, !tbaa !24
  %t139 = icmp sle i64 %t137, %t138
  br i1 %t139, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_689ec1bc34b2e694_7c9684f7b2e5e930)
  unreachable
bb46:
  %t141 = load i64, ptr %l59, !tbaa !24
  %t142 = load i64, ptr %l60, !tbaa !24
  %t143 = icmp sle i64 %t141, %t142
  br i1 %t143, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_689ec1bc34b2e694_7c9684f7b2e5e930)
  unreachable
bb48:
  %t145 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l56, !tbaa !24
  %t148 = load i64, ptr %l59, !tbaa !24
  %t149 = getelementptr i8, ptr %t146, i64 %t147
  %t150 = sub i64 %t148, %t147
  %t151 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t149, 1
  store { i64, ptr } %t152, ptr %l64, !tbaa !27
  %t153 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 10)
  %t154 = extractvalue { i32, i64 } %t153, 1
  %t155 = extractvalue { i32, i64 } %t153, 0
  store i32 %t155, ptr %l66
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb51, label %ok.157, !prof !99
ok.157:
  store i64 %t154, ptr %l65
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_689ec1bc34b2e694_7c9684f7b2e5e930)
  unreachable
bb50:
  %t158 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t159 = load i64, ptr %l65, !tbaa !24
  %t160 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t158, i64 %t159)
  %t161 = extractvalue { i32, i64 } %t160, 1
  %t162 = extractvalue { i32, i64 } %t160, 0
  store i32 %t162, ptr %l68
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb54, label %ok.164, !prof !99
ok.164:
  store i64 %t161, ptr %l67
  br label %bb53
bb51:
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t166 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [2 x i64] } } %t166, ptr %rv
  br label %ret
bb53:
  %t167 = load i64, ptr %l67, !tbaa !24
  store i64 %t167, ptr %l53, !tbaa !24
  br label %bb55
bb54:
  br label %bb52
bb55:
  %t168 = load i64, ptr %l53, !tbaa !24
  %t169 = load i64, ptr %l3, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [2 x i64] }, ptr %t171, i32 0, i32 0
  store i64 8, ptr %t172
  %t174 = insertvalue { i64, i64 } undef, i64 %t169, 0
  %t176 = insertvalue { i64, i64 } %t174, i64 %t168, 1
  %t177 = getelementptr { i64, [2 x i64] }, ptr %t171, i32 0, i32 1
  store { i64, i64 } %t176, ptr %t177
  %t178 = load { i64, [2 x i64] }, ptr %t171
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t180 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, { i64, [2 x i64] } %t178, 1
  store { i32, { i64, [2 x i64] } } %t180, ptr %rv
  br label %ret
bb56:
  %t181 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t181, ptr %l74, !tbaa !27
  %t182 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t183 = extractvalue { i32, i64 } %t182, 1
  %t184 = extractvalue { i32, i64 } %t182, 0
  store i32 %t184, ptr %l76
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb58, label %ok.186, !prof !99
ok.186:
  store i64 %t183, ptr %l75
  br label %bb57
bb57:
  %t187 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t188 = load i64, ptr %l75, !tbaa !24
  %t189 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t187, i64 %t188)
  %t190 = extractvalue { i32, i64 } %t189, 1
  %t191 = extractvalue { i32, i64 } %t189, 0
  store i32 %t191, ptr %l78
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb61, label %ok.193, !prof !99
ok.193:
  store i64 %t190, ptr %l77
  br label %bb60
bb58:
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  %t195 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [2 x i64] } } %t195, ptr %rv
  br label %ret
bb60:
  %t196 = load i64, ptr %l77, !tbaa !24
  store i64 %t196, ptr %l73, !tbaa !24
  br label %bb62
bb61:
  br label %bb59
bb62:
  %t197 = load i64, ptr %l73, !tbaa !24
  store i64 %t197, ptr %l5, !tbaa !24
  %t198 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t198, ptr %l80, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i8, ptr %t200, i64 0
  %t202 = load i8, ptr %t201, !tbaa !32
  store i8 %t202, ptr %l6, !tbaa !22
  %t204 = load i8, ptr %l6, !tbaa !22
  %t206 = icmp eq i8 %t204, 66
  br i1 %t206, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  %t208 = load i64, ptr %l5, !tbaa !24
  %t210 = trunc i64 %t208 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t212
  %t213 = getelementptr { i64, [2 x i64] }, ptr %t212, i32 0, i32 0
  store i64 1, ptr %t213
  %t215 = insertvalue { i32 } undef, i32 %t210, 0
  %t216 = getelementptr { i64, [2 x i64] }, ptr %t212, i32 0, i32 1
  store { i32 } %t215, ptr %t216
  %t217 = load { i64, [2 x i64] }, ptr %t212
  store { i64, [2 x i64] } %t217, ptr %l82
  br label %bb79
bb66:
  %t219 = load i8, ptr %l6, !tbaa !22
  %t221 = icmp eq i8 %t219, 86
  br i1 %t221, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  %t223 = load i64, ptr %l5, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t224
  %t225 = getelementptr { i64, [2 x i64] }, ptr %t224, i32 0, i32 0
  store i64 2, ptr %t225
  %t227 = insertvalue { i64 } undef, i64 %t223, 0
  %t228 = getelementptr { i64, [2 x i64] }, ptr %t224, i32 0, i32 1
  store { i64 } %t227, ptr %t228
  %t229 = load { i64, [2 x i64] }, ptr %t224
  store { i64, [2 x i64] } %t229, ptr %l82
  br label %bb79
bb70:
  %t231 = load i8, ptr %l6, !tbaa !22
  %t233 = icmp eq i8 %t231, 79
  br i1 %t233, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  %t235 = load i64, ptr %l5, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t236
  %t237 = getelementptr { i64, [2 x i64] }, ptr %t236, i32 0, i32 0
  store i64 7, ptr %t237
  %t239 = insertvalue { i64 } undef, i64 %t235, 0
  %t240 = getelementptr { i64, [2 x i64] }, ptr %t236, i32 0, i32 1
  store { i64 } %t239, ptr %t240
  %t241 = load { i64, [2 x i64] }, ptr %t236
  store { i64, [2 x i64] } %t241, ptr %l82
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  %t244 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, i32 65536, 0
  store { i32, { i64, [2 x i64] } } %t244, ptr %rv
  br label %ret
bb78:
  call void @__olang_check_failed(ptr @olang_loc_6a803bf61431eeb2_dc93aee23e6eb17e)
  unreachable
bb79:
  call void @__olang_scope_close(ptr %s0)
  %t245 = load { i64, [2 x i64] }, ptr %l82
  %t246 = insertvalue { i32, { i64, [2 x i64] } } zeroinitializer, { i64, [2 x i64] } %t245, 1
  store { i32, { i64, [2 x i64] } } %t246, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

define dso_local i1 @compiler_2ftyped_2eassertTrue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l2, !tbaa !24
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t26 = icmp eq i32 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp eq i64 %t28, 1
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l15, !tbaa !21
  store i1 %t32, ptr %l3, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_720fd1e6659a9cc9_2e78a3e82d892a55)
  unreachable
bb14:
  %t33 = load i1, ptr %l3, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecalleeBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t16, i32 %a1)
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l3, !tbaa !21
  br label %bb26
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 5}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  br label %bb24
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 5}
  %t39 = icmp eq i64 %t37, 1
  store i1 %t39, ptr %l19, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 5}
  %t48 = icmp eq i64 %t46, 3
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l26, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 5}
  %t57 = icmp eq i64 %t55, 4
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb21
bb21:
  %t58 = load i1, ptr %l27, !tbaa !21
  br i1 %t58, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_352016b8dfbaae41_4f83dc304b77dded)
  unreachable
bb26:
  %t59 = load i1, ptr %l3, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca %"compiler/typed:Local"
  %rv = alloca %"compiler/typed:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 7
  %t6 = sext i32 %a1 to i64
  %t9 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t3, i64 %t6)
  store %"compiler/typed:Local" %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load %"compiler/typed:Local", ptr %l6
  store %"compiler/typed:Local" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Local", ptr %rv
  ret %"compiler/typed:Local" %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2ePrint(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"compiler/typed:printer"
  %l6 = alloca ptr
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l22 = alloca ptr
  %l30 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/typed:printer" @compiler_2ftyped_3aprinter_2ector(ptr %v1, ptr %s0, ptr %a1)
  store %"compiler/typed:printer" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/typed:printer", ptr %l4
  %t5 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/typed:printer" %t4, ptr %t5
  store ptr %t5, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  store ptr %t7, ptr %l6, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 8
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 9
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eLen_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l15
  br label %bb4
bb4:
  %t23 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t27 = add i64 %t24, %t26
  %t28 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = load i64, ptr %l12, !tbaa !24
  %t32 = call i64 @__olang_fmt_i64(ptr null, i64 %t31)
  %t33 = add i64 %t30, %t32
  %t34 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t37 = load i64, ptr %l15, !tbaa !24
  %t38 = call i64 @__olang_fmt_i64(ptr null, i64 %t37)
  %t39 = add i64 %t36, %t38
  %t40 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t23, i64 %t24)
  %t44 = getelementptr i8, ptr %t43, i64 %t24
  %t45 = call i64 @__olang_fmt_i64(ptr %t44, i64 %t25)
  %t46 = getelementptr i8, ptr %t44, i64 %t26
  call void @olang_textcopy(ptr %t46, ptr %t28, i64 %t29)
  %t47 = getelementptr i8, ptr %t46, i64 %t29
  %t48 = call i64 @__olang_fmt_i64(ptr %t47, i64 %t31)
  %t49 = getelementptr i8, ptr %t47, i64 %t32
  call void @olang_textcopy(ptr %t49, ptr %t34, i64 %t35)
  %t50 = getelementptr i8, ptr %t49, i64 %t35
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t37)
  %t52 = getelementptr i8, ptr %t50, i64 %t38
  call void @olang_textcopy(ptr %t52, ptr %t40, i64 %t41)
  %t53 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t43, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = extractvalue { i64, ptr } %t54, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t62 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %s0, ptr %s0, ptr %t62, i64 0, { i64, ptr } %t61)
  br label %bb5
bb5:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Body", ptr %t64, i32 0, i32 11
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb6, label %bb7
bb6:
  %t73 = load ptr, ptr %l2, !tbaa !29
  store ptr %t73, ptr %l22, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 11
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb8, label %bb9
bb7:
  br label %bb12
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b47e7a13871964ca_e65b2c3f8690a096)
  unreachable
bb9:
  br label %bb10
bb10:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Body", ptr %t81, i32 0, i32 11
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %s0, ptr %v0, ptr %v1, ptr %t85, ptr %t84, i64 1)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr %"compiler/typed:printer", ptr %t87, i32 0, i32 1
  %t91 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %t89)
  store { i64, ptr } %t91, ptr %l30
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t92 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t92, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eRoom(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l7 = alloca i1
  %rv = alloca i1
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t6 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 20
  %t10 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eHas_3cI32_3e(ptr %v0, ptr %t6, i32 %t2)
  store i1 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i1, ptr %l7, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca %"compiler/typed:landState"
  %l21 = alloca %"compiler/typed:landState"
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca %"compiler/typed:landState"
  %l30 = alloca %"compiler/typed:landState"
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca %"compiler/typed:landState"
  %l36 = alloca ptr
  %l37 = alloca i32
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l44 = alloca i32
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca ptr
  %l53 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l105 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l126 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i1
  %l153 = alloca i64
  %l162 = alloca ptr
  %l163 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca i1
  %l197 = alloca ptr
  %l203 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca i1
  %l225 = alloca %"compiler/typed:landState"
  %l230 = alloca %"compiler/typed:landState"
  %l239 = alloca ptr
  %l240 = alloca i1
  %l253 = alloca { i64, ptr }
  %l263 = alloca ptr
  %l264 = alloca i1
  %l271 = alloca ptr
  %l272 = alloca i1
  %l278 = alloca %"compiler/typed:landState"
  %l283 = alloca %"compiler/typed:landState"
  %l292 = alloca { i64, ptr }
  %l306 = alloca %"compiler/typed:landState"
  %l312 = alloca %"compiler/typed:landState"
  %l313 = alloca %"compiler/typed:landState"
  %l319 = alloca ptr
  %l320 = alloca i1
  %l325 = alloca ptr
  %l326 = alloca i1
  %l342 = alloca { i64, ptr }
  %l351 = alloca ptr
  %l352 = alloca i1
  %l364 = alloca ptr
  %l365 = alloca i1
  %l378 = alloca { i64, ptr }
  %l381 = alloca ptr
  %l382 = alloca i1
  %l392 = alloca ptr
  %l393 = alloca i1
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t6 = load ptr, ptr %l56, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l56, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l57, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l57, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t15 = load ptr, ptr %l60, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l60, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l61, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l61, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb207
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t24 = load ptr, ptr %l64, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l64, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l65, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l65, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 0
  %t36 = load %"compiler/source:Span", ptr %t35
  store %"compiler/source:Span" %t36, ptr %l2
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t44 = load ptr, ptr %l3, !tbaa !29
  store ptr %t44, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t45 = load ptr, ptr %l72, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb19, label %bb20
bb19:
  %t48 = load ptr, ptr %l72, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 8}
  %t51 = icmp eq i64 %t49, 0
  store i1 %t51, ptr %l73, !tbaa !21
  br label %bb20
bb20:
  %t52 = load i1, ptr %l73, !tbaa !21
  br i1 %t52, label %bb21, label %bb22
bb21:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l4
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l5, !tbaa !23
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = getelementptr { i64, [4 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t67, i32 0, i32 2
  %t69 = load i32, ptr %t68
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t74 = load i32, ptr %t73, !tbaa !23
  %t76 = sext i32 %t74 to i64
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emention(ptr %v0, ptr %t71, i32 %t69, i64 %t76, i1 true)
  br label %bb23
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb207
bb26:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t85 = load ptr, ptr %l88, !tbaa !29
  %t86 = icmp ne ptr %t85, null
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t88 = load ptr, ptr %l88, !tbaa !29
  %t89 = load i64, ptr %t88, !range !{i64 0, i64 18}
  %t91 = icmp eq i64 %t89, 3
  store i1 %t91, ptr %l89, !tbaa !21
  br label %bb28
bb28:
  %t92 = load i1, ptr %l89, !tbaa !21
  br i1 %t92, label %bb29, label %bb30
bb29:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l7, !tbaa !29
  br label %bb35
bb30:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t100 = load ptr, ptr %l94, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb31, label %bb32
bb31:
  %t103 = load ptr, ptr %l94, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 18}
  %t106 = icmp eq i64 %t104, 4
  store i1 %t106, ptr %l95, !tbaa !21
  br label %bb32
bb32:
  %t107 = load i1, ptr %l95, !tbaa !21
  br i1 %t107, label %bb33, label %bb34
bb33:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l7, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l100, !tbaa !29
  %t115 = load ptr, ptr %l100, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Landings", ptr %t115, i32 0, i32 20
  %t117 = load i64, ptr %t116, !tbaa !24
  %t119 = add i64 %t117, 1
  %t121 = load ptr, ptr %l100, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Landings", ptr %t121, i32 0, i32 20
  store i64 %t119, ptr %t122, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t123, ptr %t124)
  br label %bb36
bb36:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l105, !tbaa !29
  %t128 = load ptr, ptr %l105, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Landings", ptr %t128, i32 0, i32 20
  %t130 = load i64, ptr %t129, !tbaa !24
  %t132 = sub i64 %t130, 1
  %t134 = load ptr, ptr %l105, !tbaa !29
  %t135 = getelementptr %"compiler/typed:Landings", ptr %t134, i32 0, i32 20
  store i64 %t132, ptr %t135, !tbaa !24
  br label %bb207
bb37:
  %t136 = load ptr, ptr %l1, !tbaa !29
  store ptr %t136, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t137 = load ptr, ptr %l108, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb38, label %bb39
bb38:
  %t140 = load ptr, ptr %l108, !tbaa !29
  %t141 = load i64, ptr %t140, !range !{i64 0, i64 18}
  %t143 = icmp eq i64 %t141, 5
  store i1 %t143, ptr %l109, !tbaa !21
  br label %bb39
bb39:
  %t144 = load i1, ptr %l109, !tbaa !21
  br i1 %t144, label %bb40, label %bb41
bb40:
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t147, i32 0, i32 2
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l8, !tbaa !29
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l8, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Promote", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t151, ptr %t155)
  br label %bb43
bb43:
  br label %bb207
bb44:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t160 = load ptr, ptr %l118, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb45, label %bb46
bb45:
  %t163 = load ptr, ptr %l118, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 18}
  %t166 = icmp eq i64 %t164, 6
  store i1 %t166, ptr %l119, !tbaa !21
  br label %bb46
bb46:
  %t167 = load i1, ptr %l119, !tbaa !21
  br i1 %t167, label %bb47, label %bb48
bb47:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [5 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l9, !tbaa !29
  br label %bb49
bb48:
  br label %bb60
bb49:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Landings", ptr %t174, i32 0, i32 15
  %t178 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t176)
  store i64 %t178, ptr %l126
  br label %bb50
bb50:
  %t179 = load i64, ptr %l126, !tbaa !24
  store i64 %t179, ptr %l10, !tbaa !24
  %t180 = load ptr, ptr %l9, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Call", ptr %t180, i32 0, i32 0
  %t183 = load ptr, ptr %t182, !tbaa !29
  store ptr %t183, ptr %l11, !tbaa !29
  %t185 = load ptr, ptr %l11, !tbaa !29
  store ptr %t185, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t186 = load ptr, ptr %l129, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb51, label %bb52
bb51:
  %t189 = load ptr, ptr %l129, !tbaa !29
  %t190 = load i64, ptr %t189, !range !{i64 0, i64 5}
  %t192 = icmp eq i64 %t190, 2
  store i1 %t192, ptr %l130, !tbaa !21
  br label %bb52
bb52:
  %t193 = load i1, ptr %l130, !tbaa !21
  br i1 %t193, label %bb53, label %bb54
bb53:
  %t194 = load ptr, ptr %l11, !tbaa !29
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { ptr }, ptr %t196, i32 0, i32 0
  %t198 = load ptr, ptr %t197
  %t200 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t200, ptr %t198)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l9, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Call", ptr %t206, i32 0, i32 1
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %t205, { i64, ptr } %t209)
  br label %bb57
bb57:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eapart(ptr %v0, ptr %t212, i64 %t213)
  br label %bb58
bb58:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ekeptBy(ptr %v0, ptr %t216, i64 %t217)
  br label %bb59
bb59:
  br label %bb207
bb60:
  %t220 = load ptr, ptr %l1, !tbaa !29
  store ptr %t220, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t221 = load ptr, ptr %l145, !tbaa !29
  %t222 = icmp ne ptr %t221, null
  br i1 %t222, label %bb61, label %bb62
bb61:
  %t224 = load ptr, ptr %l145, !tbaa !29
  %t225 = load i64, ptr %t224, !range !{i64 0, i64 18}
  %t227 = icmp eq i64 %t225, 7
  store i1 %t227, ptr %l146, !tbaa !21
  br label %bb62
bb62:
  %t228 = load i1, ptr %l146, !tbaa !21
  br i1 %t228, label %bb63, label %bb64
bb63:
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = getelementptr { i64, [5 x i64] }, ptr %t229, i32 0, i32 1
  %t232 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t231, i32 0, i32 2
  %t233 = load ptr, ptr %t232
  store ptr %t233, ptr %l13, !tbaa !29
  br label %bb65
bb64:
  br label %bb70
bb65:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/typed:Landings", ptr %t235, i32 0, i32 15
  %t239 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t237)
  store i64 %t239, ptr %l153
  br label %bb66
bb66:
  %t240 = load i64, ptr %l153, !tbaa !24
  store i64 %t240, ptr %l14, !tbaa !24
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l13, !tbaa !29
  %t244 = getelementptr %"compiler/typed:Make", ptr %t242, i32 0, i32 2
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %t241, { i64, ptr } %t245)
  br label %bb67
bb67:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l13, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Make", ptr %t249, i32 0, i32 3
  %t252 = load ptr, ptr %t251, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t248, ptr %t252)
  br label %bb68
bb68:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i64, ptr %l14, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eapart(ptr %v0, ptr %t255, i64 %t256)
  br label %bb69
bb69:
  br label %bb207
bb70:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t260 = load ptr, ptr %l162, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb71, label %bb72
bb71:
  %t263 = load ptr, ptr %l162, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 18}
  %t266 = icmp eq i64 %t264, 8
  store i1 %t266, ptr %l163, !tbaa !21
  br label %bb72
bb72:
  %t267 = load i1, ptr %l163, !tbaa !21
  br i1 %t267, label %bb73, label %bb74
bb73:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t270, i32 0, i32 2
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l15, !tbaa !29
  br label %bb75
bb74:
  br label %bb78
bb75:
  store %olang.scope zeroinitializer, ptr %s11
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l15, !tbaa !29
  %t277 = getelementptr %"compiler/typed:Collect", ptr %t275, i32 0, i32 0
  %t278 = load ptr, ptr %t277, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t274, ptr %t278)
  br label %bb76
bb76:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l15, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Collect", ptr %t282, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Block", ptr %t285, i32 0, i32 0
  %t288 = load i32, ptr %t287, !tbaa !23
  %t289 = load ptr, ptr %l15, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Collect", ptr %t289, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eloop(ptr %v0, ptr %v1, ptr %s11, ptr %t281, i32 %t288, ptr %t292, ptr null)
  br label %bb77
bb77:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/typed:Landings", ptr %t296, i32 0, i32 7
  store i1 false, ptr %t298, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb207
bb78:
  %t299 = load ptr, ptr %l1, !tbaa !29
  store ptr %t299, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t300 = load ptr, ptr %l178, !tbaa !29
  %t301 = icmp ne ptr %t300, null
  br i1 %t301, label %bb79, label %bb80
bb79:
  %t303 = load ptr, ptr %l178, !tbaa !29
  %t304 = load i64, ptr %t303, !range !{i64 0, i64 18}
  %t306 = icmp eq i64 %t304, 9
  store i1 %t306, ptr %l179, !tbaa !21
  br label %bb80
bb80:
  %t307 = load i1, ptr %l179, !tbaa !21
  br i1 %t307, label %bb81, label %bb82
bb81:
  %t308 = load ptr, ptr %l1, !tbaa !29
  %t310 = getelementptr { i64, [5 x i64] }, ptr %t308, i32 0, i32 1
  %t311 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t310, i32 0, i32 2
  %t312 = load i32, ptr %t311, !range !{i32 0, i32 51}
  store i32 %t312, ptr %l16
  %t314 = load ptr, ptr %l1, !tbaa !29
  %t316 = getelementptr { i64, [5 x i64] }, ptr %t314, i32 0, i32 1
  %t317 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t316, i32 0, i32 4
  %t318 = load { i64, ptr }, ptr %t317
  store { i64, ptr } %t318, ptr %l17, !tbaa !27
  br label %bb83
bb82:
  br label %bb88
bb83:
  %t320 = load i32, ptr %l16, !range !{i32 0, i32 51}
  %t322 = trunc i64 30 to i32
  %t323 = icmp eq i32 %t320, %t322
  %t325 = xor i1 %t323, true
  br i1 %t325, label %bb84, label %bb85
bb84:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %t327, { i64, ptr } %t328)
  br label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb87
bb87:
  br label %bb207
bb88:
  %t331 = load ptr, ptr %l1, !tbaa !29
  store ptr %t331, ptr %l191, !tbaa !29
  store i1 false, ptr %l192, !tbaa !21
  %t332 = load ptr, ptr %l191, !tbaa !29
  %t333 = icmp ne ptr %t332, null
  br i1 %t333, label %bb89, label %bb90
bb89:
  %t335 = load ptr, ptr %l191, !tbaa !29
  %t336 = load i64, ptr %t335, !range !{i64 0, i64 18}
  %t338 = icmp eq i64 %t336, 10
  store i1 %t338, ptr %l192, !tbaa !21
  br label %bb90
bb90:
  %t339 = load i1, ptr %l192, !tbaa !21
  br i1 %t339, label %bb91, label %bb92
bb91:
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t342 = getelementptr { i64, [5 x i64] }, ptr %t340, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t342, i32 0, i32 2
  %t344 = load ptr, ptr %t343
  store ptr %t344, ptr %l18, !tbaa !29
  br label %bb93
bb92:
  br label %bb97
bb93:
  %t346 = load ptr, ptr %l0, !tbaa !29
  store ptr %t346, ptr %l197, !tbaa !29
  %t347 = load ptr, ptr %l197, !tbaa !29
  %t348 = getelementptr %"compiler/typed:Landings", ptr %t347, i32 0, i32 20
  %t349 = load i64, ptr %t348, !tbaa !24
  %t351 = add i64 %t349, 1
  %t353 = load ptr, ptr %l197, !tbaa !29
  %t354 = getelementptr %"compiler/typed:Landings", ptr %t353, i32 0, i32 20
  store i64 %t351, ptr %t354, !tbaa !24
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load ptr, ptr %l18, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Slice", ptr %t356, i32 0, i32 0
  %t359 = load ptr, ptr %t358, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t355, ptr %t359)
  br label %bb94
bb94:
  %t362 = load ptr, ptr %l0, !tbaa !29
  store ptr %t362, ptr %l203, !tbaa !29
  %t363 = load ptr, ptr %l203, !tbaa !29
  %t364 = getelementptr %"compiler/typed:Landings", ptr %t363, i32 0, i32 20
  %t365 = load i64, ptr %t364, !tbaa !24
  %t367 = sub i64 %t365, 1
  %t369 = load ptr, ptr %l203, !tbaa !29
  %t370 = getelementptr %"compiler/typed:Landings", ptr %t369, i32 0, i32 20
  store i64 %t367, ptr %t370, !tbaa !24
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load ptr, ptr %l18, !tbaa !29
  %t374 = getelementptr %"compiler/typed:Slice", ptr %t372, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t371, ptr %t375)
  br label %bb95
bb95:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load ptr, ptr %l18, !tbaa !29
  %t382 = getelementptr %"compiler/typed:Slice", ptr %t380, i32 0, i32 2
  %t383 = load ptr, ptr %t382, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t379, ptr %t383)
  br label %bb96
bb96:
  br label %bb207
bb97:
  %t387 = load ptr, ptr %l1, !tbaa !29
  store ptr %t387, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t388 = load ptr, ptr %l214, !tbaa !29
  %t389 = icmp ne ptr %t388, null
  br i1 %t389, label %bb98, label %bb99
bb98:
  %t391 = load ptr, ptr %l214, !tbaa !29
  %t392 = load i64, ptr %t391, !range !{i64 0, i64 18}
  %t394 = icmp eq i64 %t392, 11
  store i1 %t394, ptr %l215, !tbaa !21
  br label %bb99
bb99:
  %t395 = load i1, ptr %l215, !tbaa !21
  br i1 %t395, label %bb100, label %bb101
bb100:
  %t396 = load ptr, ptr %l1, !tbaa !29
  %t398 = getelementptr { i64, [5 x i64] }, ptr %t396, i32 0, i32 1
  %t399 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t398, i32 0, i32 2
  %t400 = load ptr, ptr %t399
  store ptr %t400, ptr %l19, !tbaa !29
  br label %bb102
bb101:
  br label %bb110
bb102:
  store %olang.scope zeroinitializer, ptr %s15
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load ptr, ptr %l19, !tbaa !29
  %t405 = getelementptr %"compiler/typed:Cond", ptr %t403, i32 0, i32 0
  %t406 = load ptr, ptr %t405, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t402, ptr %t406)
  br label %bb103
bb103:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s15, ptr %t410)
  store %"compiler/typed:landState" %t412, ptr %l225
  br label %bb104
bb104:
  %t413 = load %"compiler/typed:landState", ptr %l225
  store %"compiler/typed:landState" %t413, ptr %l20
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load ptr, ptr %l19, !tbaa !29
  %t417 = getelementptr %"compiler/typed:Cond", ptr %t415, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t414, ptr %t418)
  br label %bb105
bb105:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s15, ptr %t421)
  store %"compiler/typed:landState" %t423, ptr %l230
  br label %bb106
bb106:
  %t424 = load %"compiler/typed:landState", ptr %l230
  store %"compiler/typed:landState" %t424, ptr %l21
  %t425 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s15, ptr %t425, ptr %l20)
  br label %bb107
bb107:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load ptr, ptr %l19, !tbaa !29
  %t431 = getelementptr %"compiler/typed:Cond", ptr %t429, i32 0, i32 2
  %t432 = load ptr, ptr %t431, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t428, ptr %t432)
  br label %bb108
bb108:
  %t436 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %s15, ptr %t436, ptr %l21)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s15)
  br label %bb207
bb110:
  %t439 = load ptr, ptr %l1, !tbaa !29
  store ptr %t439, ptr %l239, !tbaa !29
  store i1 false, ptr %l240, !tbaa !21
  %t440 = load ptr, ptr %l239, !tbaa !29
  %t441 = icmp ne ptr %t440, null
  br i1 %t441, label %bb111, label %bb112
bb111:
  %t443 = load ptr, ptr %l239, !tbaa !29
  %t444 = load i64, ptr %t443, !range !{i64 0, i64 18}
  %t446 = icmp eq i64 %t444, 12
  store i1 %t446, ptr %l240, !tbaa !21
  br label %bb112
bb112:
  %t447 = load i1, ptr %l240, !tbaa !21
  br i1 %t447, label %bb113, label %bb114
bb113:
  %t448 = load ptr, ptr %l1, !tbaa !29
  %t450 = getelementptr { i64, [5 x i64] }, ptr %t448, i32 0, i32 1
  %t451 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t450, i32 0, i32 2
  %t452 = load ptr, ptr %t451
  store ptr %t452, ptr %l22, !tbaa !29
  br label %bb115
bb114:
  br label %bb124
bb115:
  %t454 = load ptr, ptr %l22, !tbaa !29
  %t456 = getelementptr %"compiler/typed:Seq", ptr %t454, i32 0, i32 0
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  store { i64, ptr } %t457, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t459 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t459, 0
  store i64 %t461, ptr %l25, !tbaa !24
  br label %bb116
bb116:
  %t463 = load i64, ptr %l24, !tbaa !24
  %t464 = load i64, ptr %l25, !tbaa !24
  %t467 = icmp slt i64 %t463, %t464
  %t469 = xor i1 %t467, true
  br i1 %t469, label %bb117, label %bb118
bb117:
  br label %bb122
bb118:
  br label %bb119
bb119:
  %t471 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t471, ptr %l253, !tbaa !27
  %t472 = load i64, ptr %l24, !tbaa !24
  %t474 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr ptr, ptr %t475, i64 %t472
  %t477 = load ptr, ptr %t476, !tbaa !39
  %t479 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %t479, ptr %t477)
  br label %bb120
bb120:
  br label %bb121
bb121:
  %t483 = load i64, ptr %l24, !tbaa !24
  %t485 = add i64 %t483, 1
  store i64 %t485, ptr %l24, !tbaa !24
  br label %bb116
bb122:
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t488 = load ptr, ptr %l22, !tbaa !29
  %t490 = getelementptr %"compiler/typed:Seq", ptr %t488, i32 0, i32 1
  %t491 = load ptr, ptr %t490, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t487, ptr %t491)
  br label %bb123
bb123:
  br label %bb207
bb124:
  %t494 = load ptr, ptr %l1, !tbaa !29
  store ptr %t494, ptr %l263, !tbaa !29
  store i1 false, ptr %l264, !tbaa !21
  %t495 = load ptr, ptr %l263, !tbaa !29
  %t496 = icmp ne ptr %t495, null
  br i1 %t496, label %bb125, label %bb126
bb125:
  %t498 = load ptr, ptr %l263, !tbaa !29
  %t499 = load i64, ptr %t498, !range !{i64 0, i64 18}
  %t501 = icmp eq i64 %t499, 13
  store i1 %t501, ptr %l264, !tbaa !21
  br label %bb126
bb126:
  %t502 = load i1, ptr %l264, !tbaa !21
  br i1 %t502, label %bb127, label %bb128
bb127:
  %t503 = load ptr, ptr %l1, !tbaa !29
  %t505 = getelementptr { i64, [5 x i64] }, ptr %t503, i32 0, i32 1
  %t506 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t505, i32 0, i32 2
  %t507 = load ptr, ptr %t506
  store ptr %t507, ptr %l27, !tbaa !29
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ematchExpr(ptr %v0, ptr %v1, ptr %t509, ptr %t510)
  br label %bb130
bb130:
  br label %bb207
bb131:
  %t513 = load ptr, ptr %l1, !tbaa !29
  store ptr %t513, ptr %l271, !tbaa !29
  store i1 false, ptr %l272, !tbaa !21
  %t514 = load ptr, ptr %l271, !tbaa !29
  %t515 = icmp ne ptr %t514, null
  br i1 %t515, label %bb132, label %bb133
bb132:
  %t517 = load ptr, ptr %l271, !tbaa !29
  %t518 = load i64, ptr %t517, !range !{i64 0, i64 18}
  %t520 = icmp eq i64 %t518, 14
  store i1 %t520, ptr %l272, !tbaa !21
  br label %bb133
bb133:
  %t521 = load i1, ptr %l272, !tbaa !21
  br i1 %t521, label %bb134, label %bb135
bb134:
  %t522 = load ptr, ptr %l1, !tbaa !29
  %t524 = getelementptr { i64, [5 x i64] }, ptr %t522, i32 0, i32 1
  %t525 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t524, i32 0, i32 2
  %t526 = load ptr, ptr %t525
  store ptr %t526, ptr %l28, !tbaa !29
  br label %bb136
bb135:
  br label %bb157
bb136:
  store %olang.scope zeroinitializer, ptr %s21
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s21, ptr %t528)
  store %"compiler/typed:landState" %t530, ptr %l278
  br label %bb137
bb137:
  %t531 = load %"compiler/typed:landState", ptr %l278
  store %"compiler/typed:landState" %t531, ptr %l29
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load ptr, ptr %l28, !tbaa !29
  %t535 = getelementptr %"compiler/typed:Try", ptr %t533, i32 0, i32 0
  %t536 = load ptr, ptr %t535, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t532, ptr %t536)
  br label %bb138
bb138:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t541 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s21, ptr %t539)
  store %"compiler/typed:landState" %t541, ptr %l283
  br label %bb139
bb139:
  %t542 = load %"compiler/typed:landState", ptr %l283
  store %"compiler/typed:landState" %t542, ptr %l30
  %t543 = load ptr, ptr %l28, !tbaa !29
  %t545 = getelementptr %"compiler/typed:Try", ptr %t543, i32 0, i32 1
  %t546 = load { i64, ptr }, ptr %t545, !tbaa !27
  store { i64, ptr } %t546, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t548 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t550 = extractvalue { i64, ptr } %t548, 0
  store i64 %t550, ptr %l33, !tbaa !24
  br label %bb140
bb140:
  store %olang.scope zeroinitializer, ptr %s23
  %t552 = load i64, ptr %l32, !tbaa !24
  %t553 = load i64, ptr %l33, !tbaa !24
  %t556 = icmp slt i64 %t552, %t553
  %t558 = xor i1 %t556, true
  br i1 %t558, label %bb141, label %bb142
bb141:
  call void @__olang_scope_close(ptr %s23)
  br label %bb155
bb142:
  br label %bb143
bb143:
  %t560 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t560, ptr %l292, !tbaa !27
  %t561 = load i64, ptr %l32, !tbaa !24
  %t563 = getelementptr { i64, ptr }, ptr %l292, i32 0, i32 1
  %t564 = load ptr, ptr %t563, !tbaa !27
  %t565 = getelementptr ptr, ptr %t564, i64 %t561
  %t566 = load ptr, ptr %t565, !tbaa !39
  store ptr %t566, ptr %l34, !tbaa !29
  %t568 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s21, ptr %t568, ptr %l29)
  br label %bb144
bb144:
  %t571 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %s21, ptr %t571, ptr %l30)
  br label %bb145
bb145:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t575 = load ptr, ptr %l34, !tbaa !29
  %t577 = getelementptr %"compiler/typed:Clause", ptr %t575, i32 0, i32 3
  %t578 = load ptr, ptr %t577, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t574, ptr %t578)
  br label %bb146
bb146:
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load ptr, ptr %l34, !tbaa !29
  %t584 = getelementptr %"compiler/typed:Clause", ptr %t582, i32 0, i32 4
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %t581, { i64, ptr } %t585)
  br label %bb147
bb147:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t590 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s23, ptr %t588)
  store %"compiler/typed:landState" %t590, ptr %l306
  br label %bb148
bb148:
  %t591 = load %"compiler/typed:landState", ptr %l306
  store %"compiler/typed:landState" %t591, ptr %l35
  %t592 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s21, ptr %t592, ptr %l30)
  br label %bb149
bb149:
  %t595 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %s23, ptr %t595, ptr %l35)
  br label %bb150
bb150:
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t600 = call %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %s21, ptr %t598)
  store %"compiler/typed:landState" %t600, ptr %l312
  br label %bb151
bb151:
  %t601 = load %"compiler/typed:landState", ptr %l30
  store %"compiler/typed:landState" %t601, ptr %l313
  %t602 = load %"compiler/typed:landState", ptr %l312
  store %"compiler/typed:landState" %t602, ptr %l30
  %t603 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3alandState_2e0
  br i1 %t603, label %bb152, label %bb153
bb152:
  %t605 = getelementptr %"compiler/typed:landState", ptr %l313, i32 0, i32 0
  %t606 = load { i64, ptr }, ptr %t605
  %t607 = extractvalue { i64, ptr } %t606, 1
  call void @__olang_region_release(ptr %t607)
  store { i64, ptr } zeroinitializer, ptr %t605
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s23)
  br label %bb154
bb154:
  %t608 = load i64, ptr %l32, !tbaa !24
  %t610 = add i64 %t608, 1
  store i64 %t610, ptr %l32, !tbaa !24
  br label %bb140
bb155:
  %t612 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %s21, ptr %t612, ptr %l30)
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s21)
  br label %bb207
bb157:
  %t615 = load ptr, ptr %l1, !tbaa !29
  store ptr %t615, ptr %l319, !tbaa !29
  store i1 false, ptr %l320, !tbaa !21
  %t616 = load ptr, ptr %l319, !tbaa !29
  %t617 = icmp ne ptr %t616, null
  br i1 %t617, label %bb158, label %bb159
bb158:
  %t619 = load ptr, ptr %l319, !tbaa !29
  %t620 = load i64, ptr %t619, !range !{i64 0, i64 18}
  %t622 = icmp eq i64 %t620, 15
  store i1 %t622, ptr %l320, !tbaa !21
  br label %bb159
bb159:
  %t623 = load i1, ptr %l320, !tbaa !21
  br i1 %t623, label %bb160, label %bb161
bb160:
  %t624 = load ptr, ptr %l1, !tbaa !29
  %t626 = getelementptr { i64, [5 x i64] }, ptr %t624, i32 0, i32 1
  %t627 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t626, i32 0, i32 2
  %t628 = load ptr, ptr %t627
  store ptr %t628, ptr %l36, !tbaa !29
  br label %bb162
bb161:
  br label %bb181
bb162:
  %t630 = load ptr, ptr %l36, !tbaa !29
  store ptr %t630, ptr %l325, !tbaa !29
  store i1 false, ptr %l326, !tbaa !21
  %t631 = load ptr, ptr %l325, !tbaa !29
  %t632 = icmp ne ptr %t631, null
  br i1 %t632, label %bb163, label %bb164
bb163:
  %t634 = load ptr, ptr %l325, !tbaa !29
  %t635 = load i64, ptr %t634, !range !{i64 0, i64 3}
  %t637 = icmp eq i64 %t635, 1
  store i1 %t637, ptr %l326, !tbaa !21
  br label %bb164
bb164:
  %t638 = load i1, ptr %l326, !tbaa !21
  br i1 %t638, label %bb165, label %bb166
bb165:
  %t639 = load ptr, ptr %l36, !tbaa !29
  %t641 = getelementptr { i64, [4 x i64] }, ptr %t639, i32 0, i32 1
  %t642 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t641, i32 0, i32 0
  %t643 = load i32, ptr %t642
  store i32 %t643, ptr %l37, !tbaa !23
  %t645 = load ptr, ptr %l36, !tbaa !29
  %t647 = getelementptr { i64, [4 x i64] }, ptr %t645, i32 0, i32 1
  %t648 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t647, i32 0, i32 1
  %t649 = load { i64, ptr }, ptr %t648
  %t651 = load ptr, ptr %l36, !tbaa !29
  %t653 = getelementptr { i64, [4 x i64] }, ptr %t651, i32 0, i32 1
  %t654 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t653, i32 0, i32 2
  %t655 = load i32, ptr %t654
  store i32 %t655, ptr %l39, !tbaa !23
  store { i64, ptr } %t649, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t659 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t661 = extractvalue { i64, ptr } %t659, 0
  store i64 %t661, ptr %l42, !tbaa !24
  br label %bb167
bb166:
  br label %bb174
bb167:
  %t663 = load i64, ptr %l41, !tbaa !24
  %t664 = load i64, ptr %l42, !tbaa !24
  %t667 = icmp slt i64 %t663, %t664
  %t669 = xor i1 %t667, true
  br i1 %t669, label %bb168, label %bb169
bb168:
  br label %bb173
bb169:
  br label %bb170
bb170:
  %t671 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t671, ptr %l342, !tbaa !27
  %t672 = load i64, ptr %l41, !tbaa !24
  %t674 = getelementptr { i64, ptr }, ptr %l342, i32 0, i32 1
  %t675 = load ptr, ptr %t674, !tbaa !27
  %t676 = getelementptr ptr, ptr %t675, i64 %t672
  %t677 = load ptr, ptr %t676, !tbaa !39
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t682 = getelementptr %"compiler/typed:Capture", ptr %t677, i32 0, i32 1
  %t683 = load ptr, ptr %t682, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t679, ptr %t683)
  br label %bb171
bb171:
  br label %bb172
bb172:
  %t687 = load i64, ptr %l41, !tbaa !24
  %t689 = add i64 %t687, 1
  store i64 %t689, ptr %l41, !tbaa !24
  br label %bb167
bb173:
  br label %bb174
bb174:
  %t691 = load ptr, ptr %l36, !tbaa !29
  store ptr %t691, ptr %l351, !tbaa !29
  store i1 false, ptr %l352, !tbaa !21
  %t692 = load ptr, ptr %l351, !tbaa !29
  %t693 = icmp ne ptr %t692, null
  br i1 %t693, label %bb175, label %bb176
bb175:
  %t695 = load ptr, ptr %l351, !tbaa !29
  %t696 = load i64, ptr %t695, !range !{i64 0, i64 3}
  %t698 = icmp eq i64 %t696, 2
  store i1 %t698, ptr %l352, !tbaa !21
  br label %bb176
bb176:
  %t699 = load i1, ptr %l352, !tbaa !21
  br i1 %t699, label %bb177, label %bb178
bb177:
  %t700 = load ptr, ptr %l36, !tbaa !29
  %t702 = getelementptr { i64, [4 x i64] }, ptr %t700, i32 0, i32 1
  %t703 = getelementptr { i32, ptr, i32 }, ptr %t702, i32 0, i32 0
  %t704 = load i32, ptr %t703
  store i32 %t704, ptr %l44, !tbaa !23
  %t706 = load ptr, ptr %l36, !tbaa !29
  %t708 = getelementptr { i64, [4 x i64] }, ptr %t706, i32 0, i32 1
  %t709 = getelementptr { i32, ptr, i32 }, ptr %t708, i32 0, i32 1
  %t710 = load ptr, ptr %t709
  %t712 = load ptr, ptr %l36, !tbaa !29
  %t714 = getelementptr { i64, [4 x i64] }, ptr %t712, i32 0, i32 1
  %t715 = getelementptr { i32, ptr, i32 }, ptr %t714, i32 0, i32 2
  %t716 = load i32, ptr %t715
  store i32 %t716, ptr %l46, !tbaa !23
  %t718 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t718, ptr %t710)
  br label %bb179
bb178:
  br label %bb180
bb179:
  br label %bb180
bb180:
  br label %bb207
bb181:
  %t723 = load ptr, ptr %l1, !tbaa !29
  store ptr %t723, ptr %l364, !tbaa !29
  store i1 false, ptr %l365, !tbaa !21
  %t724 = load ptr, ptr %l364, !tbaa !29
  %t725 = icmp ne ptr %t724, null
  br i1 %t725, label %bb182, label %bb183
bb182:
  %t727 = load ptr, ptr %l364, !tbaa !29
  %t728 = load i64, ptr %t727, !range !{i64 0, i64 18}
  %t730 = icmp eq i64 %t728, 16
  store i1 %t730, ptr %l365, !tbaa !21
  br label %bb183
bb183:
  %t731 = load i1, ptr %l365, !tbaa !21
  br i1 %t731, label %bb184, label %bb185
bb184:
  %t732 = load ptr, ptr %l1, !tbaa !29
  %t734 = getelementptr { i64, [5 x i64] }, ptr %t732, i32 0, i32 1
  %t735 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t734, i32 0, i32 2
  %t736 = load ptr, ptr %t735
  store ptr %t736, ptr %l47, !tbaa !29
  br label %bb186
bb185:
  br label %bb199
bb186:
  %t738 = load ptr, ptr %l47, !tbaa !29
  %t740 = getelementptr %"compiler/typed:Text", ptr %t738, i32 0, i32 0
  %t741 = load { i64, ptr }, ptr %t740, !tbaa !27
  store { i64, ptr } %t741, ptr %l48, !tbaa !27
  store i64 0, ptr %l49, !tbaa !24
  %t743 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t745 = extractvalue { i64, ptr } %t743, 0
  store i64 %t745, ptr %l50, !tbaa !24
  br label %bb187
bb187:
  %t747 = load i64, ptr %l49, !tbaa !24
  %t748 = load i64, ptr %l50, !tbaa !24
  %t751 = icmp slt i64 %t747, %t748
  %t753 = xor i1 %t751, true
  br i1 %t753, label %bb188, label %bb189
bb188:
  br label %bb198
bb189:
  br label %bb190
bb190:
  %t755 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t755, ptr %l378, !tbaa !27
  %t756 = load i64, ptr %l49, !tbaa !24
  %t758 = getelementptr { i64, ptr }, ptr %l378, i32 0, i32 1
  %t759 = load ptr, ptr %t758, !tbaa !27
  %t760 = getelementptr ptr, ptr %t759, i64 %t756
  %t761 = load ptr, ptr %t760, !tbaa !39
  store ptr %t761, ptr %l51, !tbaa !29
  %t763 = load ptr, ptr %l51, !tbaa !29
  store ptr %t763, ptr %l381, !tbaa !29
  store i1 false, ptr %l382, !tbaa !21
  %t764 = load ptr, ptr %l381, !tbaa !29
  %t765 = icmp ne ptr %t764, null
  br i1 %t765, label %bb191, label %bb192
bb191:
  %t767 = load ptr, ptr %l381, !tbaa !29
  %t768 = load i64, ptr %t767, !range !{i64 0, i64 2}
  %t770 = icmp eq i64 %t768, 1
  store i1 %t770, ptr %l382, !tbaa !21
  br label %bb192
bb192:
  %t771 = load i1, ptr %l382, !tbaa !21
  br i1 %t771, label %bb193, label %bb194
bb193:
  %t772 = load ptr, ptr %l51, !tbaa !29
  %t774 = getelementptr { i64, [2 x i64] }, ptr %t772, i32 0, i32 1
  %t775 = getelementptr { ptr }, ptr %t774, i32 0, i32 0
  %t776 = load ptr, ptr %t775
  %t778 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t778, ptr %t776)
  br label %bb195
bb194:
  br label %bb196
bb195:
  br label %bb196
bb196:
  br label %bb197
bb197:
  %t783 = load i64, ptr %l49, !tbaa !24
  %t785 = add i64 %t783, 1
  store i64 %t785, ptr %l49, !tbaa !24
  br label %bb187
bb198:
  br label %bb207
bb199:
  %t787 = load ptr, ptr %l1, !tbaa !29
  store ptr %t787, ptr %l392, !tbaa !29
  store i1 false, ptr %l393, !tbaa !21
  %t788 = load ptr, ptr %l392, !tbaa !29
  %t789 = icmp ne ptr %t788, null
  br i1 %t789, label %bb200, label %bb201
bb200:
  %t791 = load ptr, ptr %l392, !tbaa !29
  %t792 = load i64, ptr %t791, !range !{i64 0, i64 18}
  %t794 = icmp eq i64 %t792, 17
  store i1 %t794, ptr %l393, !tbaa !21
  br label %bb201
bb201:
  %t795 = load i1, ptr %l393, !tbaa !21
  br i1 %t795, label %bb202, label %bb203
bb202:
  %t796 = load ptr, ptr %l1, !tbaa !29
  %t798 = getelementptr { i64, [5 x i64] }, ptr %t796, i32 0, i32 1
  %t799 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t798, i32 0, i32 2
  %t800 = load ptr, ptr %t799
  store ptr %t800, ptr %l53, !tbaa !29
  br label %bb204
bb203:
  br label %bb206
bb204:
  %t802 = load ptr, ptr %l0, !tbaa !29
  %t803 = load ptr, ptr %l53, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t802, ptr %t803)
  br label %bb205
bb205:
  br label %bb207
bb206:
  call void @__olang_check_failed(ptr @olang_loc_9444a0fe500d35e5_4f818c2c3ae57dd9)
  unreachable
bb207:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2elaterBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t2, i32 0, i32 9
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Landings", ptr %t8, i32 0, i32 9
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t10, ptr %a1)
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l7, !tbaa !29
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Landings", ptr %t15, i32 0, i32 9
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = sub i64 %t17, 1
  %t21 = load ptr, ptr %l7, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Landings", ptr %t21, i32 0, i32 9
  store i64 %t19, ptr %t22, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %ret
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:landState", ptr %t10, i32 0, i32 1
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Landings", ptr %t15, i32 0, i32 6
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb13
bb10:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l23, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l23, !tbaa !24
  store i64 %t48, ptr %l20, !tbaa !24
  br label %bb13
bb13:
  %t49 = load i64, ptr %l20, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb15, label %bb16
bb15:
  br label %bb22
bb16:
  br label %bb17
bb17:
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l4, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l7, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Landings", ptr %t68, i32 0, i32 6
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l42, !tbaa !27
  %t72 = load i64, ptr %l7, !tbaa !24
  store i64 %t72, ptr %l43, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Landings", ptr %t73, i32 0, i32 6
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l45, !tbaa !27
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i1, ptr %t80, i64 %t77
  %t82 = load i1, ptr %t81, !tbaa !31
  br i1 %t82, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/typed:landState", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l50, !tbaa !27
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i1, ptr %t91, i64 %t88
  %t93 = load i1, ptr %t92, !tbaa !31
  store i1 %t93, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t95 = load i1, ptr %l48, !tbaa !21
  %t96 = load i64, ptr %l43, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i1, ptr %t98, i64 %t96
  store i1 %t95, ptr %t99, !tbaa !31
  br label %bb21
bb21:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l6, !tbaa !24
  br label %bb14
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t24 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = sext i32 %t25 to i64
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emention(ptr %v0, ptr %t22, i32 %t23, i64 %t27, i1 false)
  br label %bb6
bb6:
  br label %bb54
bb7:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  br label %bb13
bb13:
  br label %bb54
bb14:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t52 = load ptr, ptr %l31, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 8}
  %t58 = icmp eq i64 %t56, 3
  store i1 %t58, ptr %l32, !tbaa !21
  br label %bb16
bb16:
  %t59 = load i1, ptr %l32, !tbaa !21
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l5, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t66, ptr %t67)
  br label %bb20
bb20:
  br label %bb54
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l39, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 4
  store i1 %t77, ptr %l40, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l40, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l6, !tbaa !29
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l6, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Elem", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t85, ptr %t89)
  br label %bb27
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Landings", ptr %t92, i32 0, i32 20
  %t95 = load i64, ptr %t94, !tbaa !24
  store i64 %t95, ptr %l7, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Landings", ptr %t97, i32 0, i32 20
  store i64 0, ptr %t99, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l6, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Elem", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t100, ptr %t104)
  br label %bb28
bb28:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l7, !tbaa !24
  %t112 = getelementptr %"compiler/typed:Landings", ptr %t108, i32 0, i32 20
  store i64 %t109, ptr %t112, !tbaa !24
  br label %bb54
bb29:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t114 = load ptr, ptr %l57, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb30, label %bb31
bb30:
  %t117 = load ptr, ptr %l57, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 8}
  %t120 = icmp eq i64 %t118, 5
  store i1 %t120, ptr %l58, !tbaa !21
  br label %bb31
bb31:
  %t121 = load i1, ptr %l58, !tbaa !21
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [4 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l8, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l8, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Payload", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eplace(ptr %v0, ptr %v1, ptr %t128, ptr %t132)
  br label %bb35
bb35:
  br label %bb54
bb36:
  %t135 = load ptr, ptr %l1, !tbaa !29
  store ptr %t135, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t136 = load ptr, ptr %l66, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %bb37, label %bb38
bb37:
  %t139 = load ptr, ptr %l66, !tbaa !29
  %t140 = load i64, ptr %t139, !range !{i64 0, i64 8}
  %t142 = icmp eq i64 %t140, 6
  store i1 %t142, ptr %l67, !tbaa !21
  br label %bb38
bb38:
  %t143 = load i1, ptr %l67, !tbaa !21
  br i1 %t143, label %bb39, label %bb40
bb39:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t146, i32 0, i32 2
  %t148 = load ptr, ptr %t147
  store ptr %t148, ptr %l9, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexpr(ptr %v0, ptr %v1, ptr %t150, ptr %t151)
  br label %bb42
bb42:
  br label %bb54
bb43:
  %t155 = load ptr, ptr %l1, !tbaa !29
  store ptr %t155, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t156 = load ptr, ptr %l75, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb44, label %bb45
bb44:
  %t159 = load ptr, ptr %l75, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 8}
  %t162 = icmp eq i64 %t160, 1
  store i1 %t162, ptr %l76, !tbaa !21
  br label %bb45
bb45:
  %t163 = load i1, ptr %l76, !tbaa !21
  br i1 %t163, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t165 = load ptr, ptr %l79, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb48, label %bb49
bb48:
  %t168 = load ptr, ptr %l79, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 8}
  %t171 = icmp eq i64 %t169, 7
  store i1 %t171, ptr %l80, !tbaa !21
  br label %bb49
bb49:
  %t172 = load i1, ptr %l80, !tbaa !21
  br i1 %t172, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_af04a8710b199599_1473152472f015d)
  unreachable
bb54:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ereadIn(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i1
  %l45 = alloca i64
  %l47 = alloca { i64, ptr }
  %l51 = alloca i1
  %l55 = alloca i64
  %l57 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Landings", ptr %t3, i32 0, i32 15
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i64, ptr %l12, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l19, !tbaa !24
  store i64 %t35, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l16, !tbaa !24
  store i64 %t36, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l3, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l8, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Landings", ptr %t55, i32 0, i32 17
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58)
  store i1 %t61, ptr %l40
  br label %bb12
bb12:
  %t62 = load i1, ptr %l40, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Landings", ptr %t63, i32 0, i32 15
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t65, i64 %t66)
  store i64 %t69, ptr %l45
  br label %bb15
bb14:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb16
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Landings", ptr %t70, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l47, !tbaa !27
  %t74 = load i64, ptr %l1, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i64, ptr %t77, i64 %t74
  %t79 = load i64, ptr %t78, !tbaa !34
  %t80 = load i64, ptr %l45, !tbaa !24
  %t82 = icmp eq i64 %t80, %t79
  store i1 %t82, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t84 = load i1, ptr %l41, !tbaa !21
  br i1 %t84, label %bb17, label %bb18
bb17:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Landings", ptr %t85, i32 0, i32 16
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l55
  br label %bb19
bb18:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb20
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Landings", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l57, !tbaa !27
  %t96 = load i64, ptr %l1, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i64, ptr %t99, i64 %t96
  %t101 = load i64, ptr %t100, !tbaa !34
  %t102 = load i64, ptr %l55, !tbaa !24
  %t104 = icmp eq i64 %t102, %t101
  store i1 %t104, ptr %l51, !tbaa !21
  br label %bb20
bb20:
  %t106 = load i1, ptr %l51, !tbaa !21
  br i1 %t106, label %bb21, label %bb22
bb21:
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l7, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb8
bb25:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l109 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca i1
  %l130 = alloca ptr
  %l137 = alloca ptr
  %l140 = alloca ptr
  %l141 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca i1
  %l211 = alloca { i64, ptr }
  %l222 = alloca ptr
  %l228 = alloca ptr
  %l229 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca i1
  %l262 = alloca { i64, ptr }
  %l265 = alloca ptr
  %l266 = alloca i1
  %l276 = alloca ptr
  %l277 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t6 = load ptr, ptr %l33, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l33, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l34, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l34, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t15 = load ptr, ptr %l37, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l37, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l38, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l38, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb170
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t24 = load ptr, ptr %l41, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l41, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l42, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l42, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l2, !tbaa !29
  br label %bb26
bb17:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t39 = load ptr, ptr %l47, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l47, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l48, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb26
bb21:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t54 = load ptr, ptr %l53, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l53, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l54, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l54, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb27
bb27:
  br label %bb170
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t73 = load ptr, ptr %l61, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb29, label %bb30
bb29:
  %t76 = load ptr, ptr %l61, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 5
  store i1 %t79, ptr %l62, !tbaa !21
  br label %bb30
bb30:
  %t80 = load i1, ptr %l62, !tbaa !21
  br i1 %t80, label %bb31, label %bb32
bb31:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Promote", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t87, ptr %t91)
  br label %bb34
bb34:
  br label %bb170
bb35:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t96 = load ptr, ptr %l71, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load ptr, ptr %l71, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 18}
  %t102 = icmp eq i64 %t100, 6
  store i1 %t102, ptr %l72, !tbaa !21
  br label %bb37
bb37:
  %t103 = load i1, ptr %l72, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb56
bb40:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/typed:LastUses", ptr %t110, i32 0, i32 3
  %t113 = load i64, ptr %t112, !tbaa !24
  store i64 %t113, ptr %l5, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:LastUses", ptr %t115, i32 0, i32 6
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t117)
  store i64 %t119, ptr %l81
  br label %bb41
bb41:
  %t120 = load i64, ptr %l81, !tbaa !24
  store i64 %t120, ptr %l6, !tbaa !24
  %t121 = load ptr, ptr %l4, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Call", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l7, !tbaa !29
  %t126 = load ptr, ptr %l7, !tbaa !29
  store ptr %t126, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t127 = load ptr, ptr %l84, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb42, label %bb43
bb42:
  %t130 = load ptr, ptr %l84, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 5}
  %t133 = icmp eq i64 %t131, 2
  store i1 %t133, ptr %l85, !tbaa !21
  br label %bb43
bb43:
  %t134 = load i1, ptr %l85, !tbaa !21
  br i1 %t134, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l7, !tbaa !29
  %t137 = getelementptr { i64, [3 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { ptr }, ptr %t137, i32 0, i32 0
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l8, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t141, ptr %t142)
  br label %bb47
bb47:
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_198aad80d0550ab5_c06608159f163401)
  unreachable
bb53:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Call", ptr %t147, i32 0, i32 1
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t146, { i64, ptr } %t150)
  br label %bb54
bb54:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i64, ptr %l5, !tbaa !24
  %t155 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %t153, i64 %t154, i64 %t155)
  br label %bb55
bb55:
  br label %bb170
bb56:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t160 = load ptr, ptr %l99, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb57, label %bb58
bb57:
  %t163 = load ptr, ptr %l99, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 18}
  %t166 = icmp eq i64 %t164, 7
  store i1 %t166, ptr %l100, !tbaa !21
  br label %bb58
bb58:
  %t167 = load i1, ptr %l100, !tbaa !21
  br i1 %t167, label %bb59, label %bb60
bb59:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [5 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l9, !tbaa !29
  br label %bb61
bb60:
  br label %bb67
bb61:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/typed:LastUses", ptr %t174, i32 0, i32 3
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l10, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/typed:LastUses", ptr %t179, i32 0, i32 6
  %t183 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t181)
  store i64 %t183, ptr %l109
  br label %bb62
bb62:
  %t184 = load i64, ptr %l109, !tbaa !24
  store i64 %t184, ptr %l11, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2ecopyOf(ptr %v0, ptr %v1, ptr %t185, ptr %t186)
  br label %bb63
bb63:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l9, !tbaa !29
  %t192 = getelementptr %"compiler/typed:Make", ptr %t190, i32 0, i32 2
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t189, { i64, ptr } %t193)
  br label %bb64
bb64:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l9, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Make", ptr %t197, i32 0, i32 3
  %t200 = load ptr, ptr %t199, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t196, ptr %t200)
  br label %bb65
bb65:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i64, ptr %l10, !tbaa !24
  %t205 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %t203, i64 %t204, i64 %t205)
  br label %bb66
bb66:
  br label %bb170
bb67:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t210 = load ptr, ptr %l121, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb68, label %bb69
bb68:
  %t213 = load ptr, ptr %l121, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 18}
  %t216 = icmp eq i64 %t214, 8
  store i1 %t216, ptr %l122, !tbaa !21
  br label %bb69
bb69:
  %t217 = load i1, ptr %l122, !tbaa !21
  br i1 %t217, label %bb70, label %bb71
bb70:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t220, i32 0, i32 2
  %t222 = load ptr, ptr %t221
  store ptr %t222, ptr %l12, !tbaa !29
  br label %bb72
bb71:
  br label %bb75
bb72:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l12, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Collect", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t224, ptr %t228)
  br label %bb73
bb73:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l130, !tbaa !29
  %t232 = load ptr, ptr %l130, !tbaa !29
  %t233 = getelementptr %"compiler/typed:LastUses", ptr %t232, i32 0, i32 4
  %t234 = load i64, ptr %t233, !tbaa !24
  %t236 = add i64 %t234, 1
  %t238 = load ptr, ptr %l130, !tbaa !29
  %t239 = getelementptr %"compiler/typed:LastUses", ptr %t238, i32 0, i32 4
  store i64 %t236, ptr %t239, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l12, !tbaa !29
  %t243 = getelementptr %"compiler/typed:Collect", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t240, ptr %t244)
  br label %bb74
bb74:
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l137, !tbaa !29
  %t249 = load ptr, ptr %l137, !tbaa !29
  %t250 = getelementptr %"compiler/typed:LastUses", ptr %t249, i32 0, i32 4
  %t251 = load i64, ptr %t250, !tbaa !24
  %t253 = sub i64 %t251, 1
  %t255 = load ptr, ptr %l137, !tbaa !29
  %t256 = getelementptr %"compiler/typed:LastUses", ptr %t255, i32 0, i32 4
  store i64 %t253, ptr %t256, !tbaa !24
  br label %bb170
bb75:
  %t257 = load ptr, ptr %l1, !tbaa !29
  store ptr %t257, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t258 = load ptr, ptr %l140, !tbaa !29
  %t259 = icmp ne ptr %t258, null
  br i1 %t259, label %bb76, label %bb77
bb76:
  %t261 = load ptr, ptr %l140, !tbaa !29
  %t262 = load i64, ptr %t261, !range !{i64 0, i64 18}
  %t264 = icmp eq i64 %t262, 9
  store i1 %t264, ptr %l141, !tbaa !21
  br label %bb77
bb77:
  %t265 = load i1, ptr %l141, !tbaa !21
  br i1 %t265, label %bb78, label %bb79
bb78:
  %t266 = load ptr, ptr %l1, !tbaa !29
  %t268 = getelementptr { i64, [5 x i64] }, ptr %t266, i32 0, i32 1
  %t269 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t268, i32 0, i32 4
  %t270 = load { i64, ptr }, ptr %t269
  store { i64, ptr } %t270, ptr %l13, !tbaa !27
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %t272, { i64, ptr } %t273)
  br label %bb81
bb81:
  br label %bb170
bb82:
  %t276 = load ptr, ptr %l1, !tbaa !29
  store ptr %t276, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t277 = load ptr, ptr %l148, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb83, label %bb84
bb83:
  %t280 = load ptr, ptr %l148, !tbaa !29
  %t281 = load i64, ptr %t280, !range !{i64 0, i64 18}
  %t283 = icmp eq i64 %t281, 10
  store i1 %t283, ptr %l149, !tbaa !21
  br label %bb84
bb84:
  %t284 = load i1, ptr %l149, !tbaa !21
  br i1 %t284, label %bb85, label %bb86
bb85:
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t287 = getelementptr { i64, [5 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t287, i32 0, i32 2
  %t289 = load ptr, ptr %t288
  store ptr %t289, ptr %l14, !tbaa !29
  br label %bb87
bb86:
  br label %bb91
bb87:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load ptr, ptr %l14, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Slice", ptr %t292, i32 0, i32 0
  %t295 = load ptr, ptr %t294, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t291, ptr %t295)
  br label %bb88
bb88:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l14, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Slice", ptr %t299, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t298, ptr %t302)
  br label %bb89
bb89:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l14, !tbaa !29
  %t309 = getelementptr %"compiler/typed:Slice", ptr %t307, i32 0, i32 2
  %t310 = load ptr, ptr %t309, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t306, ptr %t310)
  br label %bb90
bb90:
  br label %bb170
bb91:
  %t314 = load ptr, ptr %l1, !tbaa !29
  store ptr %t314, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t315 = load ptr, ptr %l165, !tbaa !29
  %t316 = icmp ne ptr %t315, null
  br i1 %t316, label %bb92, label %bb93
bb92:
  %t318 = load ptr, ptr %l165, !tbaa !29
  %t319 = load i64, ptr %t318, !range !{i64 0, i64 18}
  %t321 = icmp eq i64 %t319, 11
  store i1 %t321, ptr %l166, !tbaa !21
  br label %bb93
bb93:
  %t322 = load i1, ptr %l166, !tbaa !21
  br i1 %t322, label %bb94, label %bb95
bb94:
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr { i64, [5 x i64] }, ptr %t323, i32 0, i32 1
  %t326 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t325, i32 0, i32 2
  %t327 = load ptr, ptr %t326
  store ptr %t327, ptr %l15, !tbaa !29
  br label %bb96
bb95:
  br label %bb100
bb96:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load ptr, ptr %l15, !tbaa !29
  %t332 = getelementptr %"compiler/typed:Cond", ptr %t330, i32 0, i32 0
  %t333 = load ptr, ptr %t332, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t329, ptr %t333)
  br label %bb97
bb97:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load ptr, ptr %l15, !tbaa !29
  %t340 = getelementptr %"compiler/typed:Cond", ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t337, ptr %t341)
  br label %bb98
bb98:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l15, !tbaa !29
  %t347 = getelementptr %"compiler/typed:Cond", ptr %t345, i32 0, i32 2
  %t348 = load ptr, ptr %t347, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t344, ptr %t348)
  br label %bb99
bb99:
  br label %bb170
bb100:
  %t352 = load ptr, ptr %l1, !tbaa !29
  store ptr %t352, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t353 = load ptr, ptr %l182, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb101, label %bb102
bb101:
  %t356 = load ptr, ptr %l182, !tbaa !29
  %t357 = load i64, ptr %t356, !range !{i64 0, i64 18}
  %t359 = icmp eq i64 %t357, 12
  store i1 %t359, ptr %l183, !tbaa !21
  br label %bb102
bb102:
  %t360 = load i1, ptr %l183, !tbaa !21
  br i1 %t360, label %bb103, label %bb104
bb103:
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t363 = getelementptr { i64, [5 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t363, i32 0, i32 2
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l16, !tbaa !29
  br label %bb105
bb104:
  br label %bb108
bb105:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l16, !tbaa !29
  %t370 = getelementptr %"compiler/typed:Seq", ptr %t368, i32 0, i32 0
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %t367, { i64, ptr } %t371)
  br label %bb106
bb106:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load ptr, ptr %l16, !tbaa !29
  %t377 = getelementptr %"compiler/typed:Seq", ptr %t375, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t374, ptr %t378)
  br label %bb107
bb107:
  br label %bb170
bb108:
  %t381 = load ptr, ptr %l1, !tbaa !29
  store ptr %t381, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t382 = load ptr, ptr %l194, !tbaa !29
  %t383 = icmp ne ptr %t382, null
  br i1 %t383, label %bb109, label %bb110
bb109:
  %t385 = load ptr, ptr %l194, !tbaa !29
  %t386 = load i64, ptr %t385, !range !{i64 0, i64 18}
  %t388 = icmp eq i64 %t386, 13
  store i1 %t388, ptr %l195, !tbaa !21
  br label %bb110
bb110:
  %t389 = load i1, ptr %l195, !tbaa !21
  br i1 %t389, label %bb111, label %bb112
bb111:
  %t390 = load ptr, ptr %l1, !tbaa !29
  %t392 = getelementptr { i64, [5 x i64] }, ptr %t390, i32 0, i32 1
  %t393 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t392, i32 0, i32 2
  %t394 = load ptr, ptr %t393
  store ptr %t394, ptr %l17, !tbaa !29
  br label %bb113
bb112:
  br label %bb129
bb113:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l17, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Match", ptr %t397, i32 0, i32 0
  %t400 = load { i64, ptr }, ptr %t399, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %t396, { i64, ptr } %t400)
  br label %bb114
bb114:
  %t403 = load ptr, ptr %l17, !tbaa !29
  %t405 = getelementptr %"compiler/typed:Match", ptr %t403, i32 0, i32 1
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  store { i64, ptr } %t406, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t408 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t408, 0
  store i64 %t410, ptr %l20, !tbaa !24
  br label %bb115
bb115:
  %t412 = load i64, ptr %l19, !tbaa !24
  %t413 = load i64, ptr %l20, !tbaa !24
  %t416 = icmp slt i64 %t412, %t413
  %t418 = xor i1 %t416, true
  br i1 %t418, label %bb116, label %bb117
bb116:
  br label %bb121
bb117:
  br label %bb118
bb118:
  %t420 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t420, ptr %l211, !tbaa !27
  %t421 = load i64, ptr %l19, !tbaa !24
  %t423 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !27
  %t425 = getelementptr ptr, ptr %t424, i64 %t421
  %t426 = load ptr, ptr %t425, !tbaa !39
  %t428 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %t428, ptr %t426)
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t432 = load i64, ptr %l19, !tbaa !24
  %t434 = add i64 %t432, 1
  store i64 %t434, ptr %l19, !tbaa !24
  br label %bb115
bb121:
  %t436 = load ptr, ptr %l17, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Match", ptr %t436, i32 0, i32 2
  %t439 = load ptr, ptr %t438, !tbaa !29
  %t441 = icmp eq ptr %t439, null
  %t443 = xor i1 %t441, true
  br i1 %t443, label %bb122, label %bb123
bb122:
  %t445 = load ptr, ptr %l0, !tbaa !29
  store ptr %t445, ptr %l222, !tbaa !29
  %t446 = load ptr, ptr %l17, !tbaa !29
  %t448 = getelementptr %"compiler/typed:Match", ptr %t446, i32 0, i32 2
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t451 = icmp eq ptr %t449, null
  br i1 %t451, label %bb124, label %bb125
bb123:
  br label %bb128
bb124:
  call void @__olang_check_failed(ptr @olang_loc_28655f8a56cf669d_dc60f62ebe04c639)
  unreachable
bb125:
  br label %bb126
bb126:
  %t453 = load ptr, ptr %l17, !tbaa !29
  %t455 = getelementptr %"compiler/typed:Match", ptr %t453, i32 0, i32 2
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t457 = load ptr, ptr %l222, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %t457, ptr %t456)
  br label %bb127
bb127:
  br label %bb128
bb128:
  br label %bb170
bb129:
  %t459 = load ptr, ptr %l1, !tbaa !29
  store ptr %t459, ptr %l228, !tbaa !29
  store i1 false, ptr %l229, !tbaa !21
  %t460 = load ptr, ptr %l228, !tbaa !29
  %t461 = icmp ne ptr %t460, null
  br i1 %t461, label %bb130, label %bb131
bb130:
  %t463 = load ptr, ptr %l228, !tbaa !29
  %t464 = load i64, ptr %t463, !range !{i64 0, i64 18}
  %t466 = icmp eq i64 %t464, 14
  store i1 %t466, ptr %l229, !tbaa !21
  br label %bb131
bb131:
  %t467 = load i1, ptr %l229, !tbaa !21
  br i1 %t467, label %bb132, label %bb133
bb132:
  %t468 = load ptr, ptr %l1, !tbaa !29
  %t470 = getelementptr { i64, [5 x i64] }, ptr %t468, i32 0, i32 1
  %t471 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t470, i32 0, i32 2
  %t472 = load ptr, ptr %t471
  store ptr %t472, ptr %l22, !tbaa !29
  br label %bb134
bb133:
  br label %bb137
bb134:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load ptr, ptr %l22, !tbaa !29
  %t477 = getelementptr %"compiler/typed:Try", ptr %t475, i32 0, i32 0
  %t478 = load ptr, ptr %t477, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t474, ptr %t478)
  br label %bb135
bb135:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load ptr, ptr %l22, !tbaa !29
  %t484 = getelementptr %"compiler/typed:Try", ptr %t482, i32 0, i32 1
  %t485 = load { i64, ptr }, ptr %t484, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %t481, { i64, ptr } %t485)
  br label %bb136
bb136:
  br label %bb170
bb137:
  %t488 = load ptr, ptr %l1, !tbaa !29
  store ptr %t488, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t489 = load ptr, ptr %l240, !tbaa !29
  %t490 = icmp ne ptr %t489, null
  br i1 %t490, label %bb138, label %bb139
bb138:
  %t492 = load ptr, ptr %l240, !tbaa !29
  %t493 = load i64, ptr %t492, !range !{i64 0, i64 18}
  %t495 = icmp eq i64 %t493, 15
  store i1 %t495, ptr %l241, !tbaa !21
  br label %bb139
bb139:
  %t496 = load i1, ptr %l241, !tbaa !21
  br i1 %t496, label %bb140, label %bb141
bb140:
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t499 = getelementptr { i64, [5 x i64] }, ptr %t497, i32 0, i32 1
  %t500 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t499, i32 0, i32 2
  %t501 = load ptr, ptr %t500
  store ptr %t501, ptr %l23, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2efnVal(ptr %v0, ptr %v1, ptr %t503, ptr %t504)
  br label %bb143
bb143:
  br label %bb170
bb144:
  %t507 = load ptr, ptr %l1, !tbaa !29
  store ptr %t507, ptr %l248, !tbaa !29
  store i1 false, ptr %l249, !tbaa !21
  %t508 = load ptr, ptr %l248, !tbaa !29
  %t509 = icmp ne ptr %t508, null
  br i1 %t509, label %bb145, label %bb146
bb145:
  %t511 = load ptr, ptr %l248, !tbaa !29
  %t512 = load i64, ptr %t511, !range !{i64 0, i64 18}
  %t514 = icmp eq i64 %t512, 16
  store i1 %t514, ptr %l249, !tbaa !21
  br label %bb146
bb146:
  %t515 = load i1, ptr %l249, !tbaa !21
  br i1 %t515, label %bb147, label %bb148
bb147:
  %t516 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr { i64, [5 x i64] }, ptr %t516, i32 0, i32 1
  %t519 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t518, i32 0, i32 2
  %t520 = load ptr, ptr %t519
  store ptr %t520, ptr %l24, !tbaa !29
  br label %bb149
bb148:
  br label %bb162
bb149:
  %t522 = load ptr, ptr %l24, !tbaa !29
  %t524 = getelementptr %"compiler/typed:Text", ptr %t522, i32 0, i32 0
  %t525 = load { i64, ptr }, ptr %t524, !tbaa !27
  store { i64, ptr } %t525, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t527 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t527, 0
  store i64 %t529, ptr %l27, !tbaa !24
  br label %bb150
bb150:
  %t531 = load i64, ptr %l26, !tbaa !24
  %t532 = load i64, ptr %l27, !tbaa !24
  %t535 = icmp slt i64 %t531, %t532
  %t537 = xor i1 %t535, true
  br i1 %t537, label %bb151, label %bb152
bb151:
  br label %bb161
bb152:
  br label %bb153
bb153:
  %t539 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t539, ptr %l262, !tbaa !27
  %t540 = load i64, ptr %l26, !tbaa !24
  %t542 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t543 = load ptr, ptr %t542, !tbaa !27
  %t544 = getelementptr ptr, ptr %t543, i64 %t540
  %t545 = load ptr, ptr %t544, !tbaa !39
  store ptr %t545, ptr %l28, !tbaa !29
  %t547 = load ptr, ptr %l28, !tbaa !29
  store ptr %t547, ptr %l265, !tbaa !29
  store i1 false, ptr %l266, !tbaa !21
  %t548 = load ptr, ptr %l265, !tbaa !29
  %t549 = icmp ne ptr %t548, null
  br i1 %t549, label %bb154, label %bb155
bb154:
  %t551 = load ptr, ptr %l265, !tbaa !29
  %t552 = load i64, ptr %t551, !range !{i64 0, i64 2}
  %t554 = icmp eq i64 %t552, 1
  store i1 %t554, ptr %l266, !tbaa !21
  br label %bb155
bb155:
  %t555 = load i1, ptr %l266, !tbaa !21
  br i1 %t555, label %bb156, label %bb157
bb156:
  %t556 = load ptr, ptr %l28, !tbaa !29
  %t558 = getelementptr { i64, [2 x i64] }, ptr %t556, i32 0, i32 1
  %t559 = getelementptr { ptr }, ptr %t558, i32 0, i32 0
  %t560 = load ptr, ptr %t559
  %t562 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t562, ptr %t560)
  br label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t567 = load i64, ptr %l26, !tbaa !24
  %t569 = add i64 %t567, 1
  store i64 %t569, ptr %l26, !tbaa !24
  br label %bb150
bb161:
  br label %bb170
bb162:
  %t571 = load ptr, ptr %l1, !tbaa !29
  store ptr %t571, ptr %l276, !tbaa !29
  store i1 false, ptr %l277, !tbaa !21
  %t572 = load ptr, ptr %l276, !tbaa !29
  %t573 = icmp ne ptr %t572, null
  br i1 %t573, label %bb163, label %bb164
bb163:
  %t575 = load ptr, ptr %l276, !tbaa !29
  %t576 = load i64, ptr %t575, !range !{i64 0, i64 18}
  %t578 = icmp eq i64 %t576, 17
  store i1 %t578, ptr %l277, !tbaa !21
  br label %bb164
bb164:
  %t579 = load i1, ptr %l277, !tbaa !21
  br i1 %t579, label %bb165, label %bb166
bb165:
  %t580 = load ptr, ptr %l1, !tbaa !29
  %t582 = getelementptr { i64, [5 x i64] }, ptr %t580, i32 0, i32 1
  %t583 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t582, i32 0, i32 2
  %t584 = load ptr, ptr %t583
  store ptr %t584, ptr %l30, !tbaa !29
  br label %bb167
bb166:
  br label %bb169
bb167:
  %t586 = load ptr, ptr %l0, !tbaa !29
  %t587 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t586, ptr %t587)
  br label %bb168
bb168:
  br label %bb170
bb169:
  call void @__olang_check_failed(ptr @olang_loc_d36f57f073c6a2ff_232866ca740484ab)
  unreachable
bb170:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l21 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t30, ptr %l21, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Capture", ptr %t36, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t38, ptr %t42)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l4, !tbaa !24
  br label %bb6
bb12:
  br label %bb27
bb13:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 3}
  %t57 = icmp eq i64 %t55, 2
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb15
bb15:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { i32, ptr, i32 }, ptr %t61, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l7, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  br label %bb19
bb19:
  br label %bb27
bb20:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb21, label %bb22
bb21:
  %t74 = load ptr, ptr %l39, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 3}
  %t77 = icmp eq i64 %t75, 0
  store i1 %t77, ptr %l40, !tbaa !21
  br label %bb22
bb22:
  %t78 = load i1, ptr %l40, !tbaa !21
  br i1 %t78, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_faea1712f2053751_ed9fc9ee56afb56d)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2elaterBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LastUses", ptr %t2, i32 0, i32 5
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/typed:LastUses", ptr %t8, i32 0, i32 5
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t10, ptr %a1)
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l7, !tbaa !29
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = getelementptr %"compiler/typed:LastUses", ptr %t15, i32 0, i32 5
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = sub i64 %t17, 1
  %t21 = load ptr, ptr %l7, !tbaa !29
  %t22 = getelementptr %"compiler/typed:LastUses", ptr %t21, i32 0, i32 5
  store i64 %t19, ptr %t22, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %t16, i32 %t17)
  br label %bb6
bb6:
  br label %bb54
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  br label %bb13
bb13:
  br label %bb54
bb14:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t41 = load ptr, ptr %l25, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 8}
  %t47 = icmp eq i64 %t45, 3
  store i1 %t47, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t48 = load i1, ptr %l26, !tbaa !21
  br i1 %t48, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t55, ptr %t56)
  br label %bb20
bb20:
  br label %bb54
bb21:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 4
  store i1 %t66, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t67 = load i1, ptr %l34, !tbaa !21
  br i1 %t67, label %bb24, label %bb25
bb24:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Elem", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t74, ptr %t78)
  br label %bb27
bb27:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Elem", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t81, ptr %t85)
  br label %bb28
bb28:
  br label %bb54
bb29:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb30, label %bb31
bb30:
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 5
  store i1 %t96, ptr %l47, !tbaa !21
  br label %bb31
bb31:
  %t97 = load i1, ptr %l47, !tbaa !21
  br i1 %t97, label %bb32, label %bb33
bb32:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Payload", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t104, ptr %t108)
  br label %bb35
bb35:
  br label %bb54
bb36:
  %t111 = load ptr, ptr %l1, !tbaa !29
  store ptr %t111, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t112 = load ptr, ptr %l55, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb37, label %bb38
bb37:
  %t115 = load ptr, ptr %l55, !tbaa !29
  %t116 = load i64, ptr %t115, !range !{i64 0, i64 8}
  %t118 = icmp eq i64 %t116, 6
  store i1 %t118, ptr %l56, !tbaa !21
  br label %bb38
bb38:
  %t119 = load i1, ptr %l56, !tbaa !21
  br i1 %t119, label %bb39, label %bb40
bb39:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t122, i32 0, i32 2
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t126, ptr %t127)
  br label %bb42
bb42:
  br label %bb54
bb43:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t132 = load ptr, ptr %l64, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l64, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 8}
  %t138 = icmp eq i64 %t136, 1
  store i1 %t138, ptr %l65, !tbaa !21
  br label %bb45
bb45:
  %t139 = load i1, ptr %l65, !tbaa !21
  br i1 %t139, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  %t140 = load ptr, ptr %l1, !tbaa !29
  store ptr %t140, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t141 = load ptr, ptr %l68, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb48, label %bb49
bb48:
  %t144 = load ptr, ptr %l68, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 8}
  %t147 = icmp eq i64 %t145, 7
  store i1 %t147, ptr %l69, !tbaa !21
  br label %bb49
bb49:
  %t148 = load i1, ptr %l69, !tbaa !21
  br i1 %t148, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_4860703a134569c9_d00fc34d053d5355)
  unreachable
bb54:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2earg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca i64
  %l13 = alloca i1
  %l16 = alloca i1
  %l36 = alloca ptr
  %l40 = alloca i1
  %l43 = alloca i1
  %l61 = alloca ptr
  %l63 = alloca i32
  %l65 = alloca i1
  %l66 = alloca i1
  %l70 = alloca i1
  %l73 = alloca i1
  %l77 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l85 = alloca ptr
  %l87 = alloca { i64, [1 x i64] }
  %t156 = alloca { i64, [1 x i64] }, align 8
  %t160 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elendOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sge i64 %t11, 0
  store i1 %t13, ptr %l13, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l13, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/typed:LocalUses", ptr %t16, i32 0, i32 25
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = icmp eq i64 %t19, 0
  store i1 %t21, ptr %l16, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l16, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/typed:LocalUses", ptr %t24, i32 0, i32 13
  %t27 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t26, i64 %t27)
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:LocalUses", ptr %t30, i32 0, i32 14
  %t33 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t32, i64 %t33)
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/typed:LocalUses", ptr %t36, i32 0, i32 15
  %t39 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t38, i64 %t39)
  br label %bb12
bb12:
  br label %ret
bb13:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp sge i64 %t42, 0
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/typed:LocalUses", ptr %t46, i32 0, i32 2
  %t49 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t48, i64 %t49, i1 true)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t56 = call ptr @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempLent(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t52, ptr %t53)
  store ptr %t56, ptr %l36
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l36, !tbaa !29
  store ptr %t57, ptr %l6, !tbaa !29
  %t58 = load ptr, ptr %l6, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load i64, ptr %l2, !tbaa !24
  %t66 = icmp sge i64 %t64, 0
  store i1 %t66, ptr %l40, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb21
bb21:
  %t68 = load i1, ptr %l40, !tbaa !21
  br i1 %t68, label %bb22, label %bb23
bb22:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:LocalUses", ptr %t69, i32 0, i32 25
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = icmp eq i64 %t72, 0
  store i1 %t74, ptr %l43, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb24
bb24:
  %t76 = load i1, ptr %l43, !tbaa !21
  br i1 %t76, label %bb25, label %bb26
bb25:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/typed:LocalUses", ptr %t77, i32 0, i32 21
  %t80 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t79, ptr %t80)
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/typed:LocalUses", ptr %t83, i32 0, i32 22
  %t86 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t85, i64 %t86)
  br label %bb28
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/typed:LocalUses", ptr %t89, i32 0, i32 23
  %t92 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t91, i64 %t92)
  br label %bb29
bb29:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:LocalUses", ptr %t95, i32 0, i32 24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/typed:LocalUses", ptr %t98, i32 0, i32 26
  %t101 = load i32, ptr %t100, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t97, i32 %t101)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/typed:LocalUses", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  store ptr %t107, ptr %l61, !tbaa !29
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t108)
  store i32 %t110, ptr %l63
  br label %bb32
bb32:
  %t111 = load ptr, ptr %l61, !tbaa !29
  %t112 = call ptr @__olang_scope_or(ptr %v2, ptr %t111)
  %t113 = ptrtoint ptr %t112 to i64
  %t115 = inttoptr i64 %t113 to ptr
  %t116 = load ptr, ptr %l61, !tbaa !29
  %t117 = load i32, ptr %l63, !tbaa !23
  %t118 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t115, ptr %t116, i32 %t117)
  store i1 %t118, ptr %l65
  br label %bb33
bb33:
  %t119 = load i1, ptr %l65, !tbaa !21
  br i1 %t119, label %bb34, label %bb35
bb34:
  %t122 = xor i1 %a4, true
  store i1 %t122, ptr %l66, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb36
bb36:
  %t124 = load i1, ptr %l66, !tbaa !21
  store i1 %t124, ptr %l7, !tbaa !21
  %t125 = load i1, ptr %l7, !tbaa !21
  br i1 %t125, label %bb37, label %bb38
bb37:
  %t127 = load i64, ptr %l2, !tbaa !24
  %t129 = icmp sge i64 %t127, 0
  store i1 %t129, ptr %l70, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb39
bb39:
  %t131 = load i1, ptr %l70, !tbaa !21
  br i1 %t131, label %bb40, label %bb41
bb40:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/typed:LocalUses", ptr %t132, i32 0, i32 25
  %t135 = load i64, ptr %t134, !tbaa !24
  %t137 = icmp eq i64 %t135, 0
  store i1 %t137, ptr %l73, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb42
bb42:
  %t139 = load i1, ptr %l73, !tbaa !21
  br i1 %t139, label %bb43, label %bb44
bb43:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t142 = load i64, ptr %l2, !tbaa !24
  %t143 = load i64, ptr %l3, !tbaa !24
  %t148 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t140, ptr %t141, i64 %t142, i64 %t143)
  store i1 %t148, ptr %l82
  br label %bb45
bb44:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb46
bb45:
  %t149 = load i1, ptr %l82, !tbaa !21
  store i1 %t149, ptr %l77, !tbaa !21
  br label %bb46
bb46:
  %t150 = load i1, ptr %l77, !tbaa !21
  br i1 %t150, label %bb47, label %bb48
bb47:
  br label %ret
bb48:
  br label %bb49
bb49:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l83, !tbaa !29
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l85, !tbaa !29
  %t154 = load i1, ptr %l7, !tbaa !21
  br i1 %t154, label %bb50, label %bb51
bb50:
  store { i64, [1 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [1 x i64] }, ptr %t156, i32 0, i32 0
  store i64 5, ptr %t157
  %t158 = load { i64, [1 x i64] }, ptr %t156
  store { i64, [1 x i64] } %t158, ptr %l87
  br label %bb52
bb51:
  store { i64, [1 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [1 x i64] }, ptr %t160, i32 0, i32 0
  store i64 1, ptr %t161
  %t162 = load { i64, [1 x i64] }, ptr %t160
  store { i64, [1 x i64] } %t162, ptr %l87
  br label %bb52
bb52:
  %t164 = load ptr, ptr %l83, !tbaa !29
  %t165 = load ptr, ptr %l85, !tbaa !29
  %t166 = load { i64, [1 x i64] }, ptr %l87
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t164, ptr %t165, { i64, [1 x i64] } %t166)
  br label %bb53
bb53:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:argRoot" @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eargRoot(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l28 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca i1
  %l44 = alloca %"compiler/typed:argRoot"
  %l55 = alloca i64
  %l56 = alloca %"compiler/typed:argRoot"
  %l57 = alloca %"compiler/typed:argRoot"
  %l58 = alloca ptr
  %l59 = alloca i1
  %l66 = alloca i64
  %l67 = alloca %"compiler/typed:argRoot"
  %l68 = alloca ptr
  %l69 = alloca i1
  %l77 = alloca i64
  %l79 = alloca ptr
  %l82 = alloca i32
  %l84 = alloca i1
  %l85 = alloca %"compiler/typed:argRoot"
  %l86 = alloca ptr
  %l87 = alloca i1
  %l94 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca i1
  %l100 = alloca %"compiler/typed:argRoot"
  %l101 = alloca %"compiler/typed:argRoot"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/typed:argRoot"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call ptr @compiler_2ftyped_2econverted(ptr %v1, ptr %v1, ptr %t1)
  store ptr %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l15, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:LocalUses", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  store ptr %t8, ptr %l17, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t9)
  store i32 %t11, ptr %l19
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l17, !tbaa !29
  %t13 = call ptr @__olang_scope_or(ptr %v2, ptr %t12)
  %t14 = ptrtoint ptr %t13 to i64
  %t16 = inttoptr i64 %t14 to ptr
  %t17 = load ptr, ptr %l17, !tbaa !29
  %t18 = load i32, ptr %l19, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t16, ptr %t17, i32 %t18)
  store i1 %t19, ptr %l21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l21, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l2, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb6, label %bb7
bb5:
  br label %bb19
bb6:
  %t27 = load ptr, ptr %l23, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l24, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l24, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb12
bb9:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t36, i32 0, i32 0
  %t38 = load %"compiler/source:Span", ptr %t37
  store %"compiler/source:Span" %t38, ptr %l3
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l4, !tbaa !23
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l5, !tbaa !29
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t54, i32 0, i32 3
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l6, !tbaa !23
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:LocalUses", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l38, !tbaa !29
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t62)
  store i32 %t64, ptr %l40
  br label %bb10
bb10:
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = call ptr @__olang_scope_or(ptr %v2, ptr %t65)
  %t67 = ptrtoint ptr %t66 to i64
  %t69 = inttoptr i64 %t67 to ptr
  %t70 = load ptr, ptr %l38, !tbaa !29
  %t71 = load i32, ptr %l40, !tbaa !23
  %t72 = call i1 @compiler_2ftyped_2emayHold(ptr %t69, ptr %t70, i32 %t71, i64 0)
  store i1 %t72, ptr %l42
  br label %bb11
bb11:
  %t73 = load i1, ptr %l42, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t76 = load i1, ptr %l28, !tbaa !21
  br i1 %t76, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t77 = call %"compiler/typed:argRoot" @compiler_2ftyped_3aargRoot_2ector(ptr %s2, i64 -1, i1 false)
  store %"compiler/typed:argRoot" %t77, ptr %l44
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t78 = load %"compiler/typed:argRoot", ptr %l44
  store %"compiler/typed:argRoot" %t78, ptr %rv
  br label %ret
bb16:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr { i64, [5 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t81, i32 0, i32 0
  %t83 = load %"compiler/source:Span", ptr %t82
  store %"compiler/source:Span" %t83, ptr %l7
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t87, i32 0, i32 1
  %t89 = load i32, ptr %t88
  store i32 %t89, ptr %l8, !tbaa !23
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t99, i32 0, i32 3
  %t101 = load i32, ptr %t100
  store i32 %t101, ptr %l10, !tbaa !23
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t107 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t103, ptr %t95)
  store i64 %t107, ptr %l55
  br label %bb17
bb17:
  %t108 = load i64, ptr %l55, !tbaa !24
  %t109 = call %"compiler/typed:argRoot" @compiler_2ftyped_3aargRoot_2ector(ptr %s1, i64 %t108, i1 true)
  store %"compiler/typed:argRoot" %t109, ptr %l56
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t110 = load %"compiler/typed:argRoot", ptr %l56
  store %"compiler/typed:argRoot" %t110, ptr %rv
  br label %ret
bb19:
  %t111 = load ptr, ptr %l2, !tbaa !29
  store ptr %t111, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t112 = load ptr, ptr %l58, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb20, label %bb21
bb20:
  %t115 = load ptr, ptr %l58, !tbaa !29
  %t116 = load i64, ptr %t115, !range !{i64 0, i64 18}
  %t118 = icmp eq i64 %t116, 3
  store i1 %t118, ptr %l59, !tbaa !21
  br label %bb21
bb21:
  %t119 = load i1, ptr %l59, !tbaa !21
  br i1 %t119, label %bb22, label %bb23
bb22:
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t122 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t122, i32 0, i32 2
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l11, !tbaa !29
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l11, !tbaa !29
  %t130 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t126, ptr %t127)
  store i64 %t130, ptr %l66
  br label %bb25
bb25:
  %t131 = load i64, ptr %l66, !tbaa !24
  %t132 = call %"compiler/typed:argRoot" @compiler_2ftyped_3aargRoot_2ector(ptr %s0, i64 %t131, i1 false)
  store %"compiler/typed:argRoot" %t132, ptr %l67
  br label %bb26
bb26:
  %t133 = load %"compiler/typed:argRoot", ptr %l67
  store %"compiler/typed:argRoot" %t133, ptr %l57
  br label %bb53
bb27:
  %t134 = load ptr, ptr %l2, !tbaa !29
  store ptr %t134, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t135 = load ptr, ptr %l68, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb28, label %bb29
bb28:
  %t138 = load ptr, ptr %l68, !tbaa !29
  %t139 = load i64, ptr %t138, !range !{i64 0, i64 18}
  %t141 = icmp eq i64 %t139, 10
  store i1 %t141, ptr %l69, !tbaa !21
  br label %bb29
bb29:
  %t142 = load i1, ptr %l69, !tbaa !21
  br i1 %t142, label %bb30, label %bb31
bb30:
  %t143 = load ptr, ptr %l2, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t145, i32 0, i32 2
  %t147 = load ptr, ptr %t146
  store ptr %t147, ptr %l12, !tbaa !29
  br label %bb32
bb31:
  br label %bb37
bb32:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l12, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Slice", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t156 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t149, ptr %t153)
  store i64 %t156, ptr %l77
  br label %bb33
bb33:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/typed:LocalUses", ptr %t157, i32 0, i32 0
  %t160 = load ptr, ptr %t159, !tbaa !29
  store ptr %t160, ptr %l79, !tbaa !29
  %t161 = load ptr, ptr %l12, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Slice", ptr %t161, i32 0, i32 0
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t166 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t164)
  store i32 %t166, ptr %l82
  br label %bb34
bb34:
  %t167 = load ptr, ptr %l79, !tbaa !29
  %t168 = call ptr @__olang_scope_or(ptr %v2, ptr %t167)
  %t169 = ptrtoint ptr %t168 to i64
  %t171 = inttoptr i64 %t169 to ptr
  %t172 = load ptr, ptr %l79, !tbaa !29
  %t173 = load i32, ptr %l82, !tbaa !23
  %t174 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t171, ptr %t172, i32 %t173)
  store i1 %t174, ptr %l84
  br label %bb35
bb35:
  %t175 = load i64, ptr %l77, !tbaa !24
  %t176 = load i1, ptr %l84, !tbaa !21
  %t177 = call %"compiler/typed:argRoot" @compiler_2ftyped_3aargRoot_2ector(ptr %s0, i64 %t175, i1 %t176)
  store %"compiler/typed:argRoot" %t177, ptr %l85
  br label %bb36
bb36:
  %t178 = load %"compiler/typed:argRoot", ptr %l85
  store %"compiler/typed:argRoot" %t178, ptr %l57
  br label %bb53
bb37:
  %t179 = load ptr, ptr %l2, !tbaa !29
  store ptr %t179, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t180 = load ptr, ptr %l86, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb38, label %bb39
bb38:
  %t183 = load ptr, ptr %l86, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 18}
  %t186 = icmp eq i64 %t184, 2
  store i1 %t186, ptr %l87, !tbaa !21
  br label %bb39
bb39:
  %t187 = load i1, ptr %l87, !tbaa !21
  br i1 %t187, label %bb40, label %bb41
bb40:
  %t188 = load ptr, ptr %l2, !tbaa !29
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t190, i32 0, i32 2
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l13, !tbaa !29
  br label %bb42
bb41:
  br label %bb47
bb42:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l13, !tbaa !29
  %t198 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t194, ptr %t195)
  store i64 %t198, ptr %l94
  br label %bb43
bb43:
  %t199 = load ptr, ptr %l13, !tbaa !29
  store ptr %t199, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t200 = load ptr, ptr %l95, !tbaa !29
  %t201 = icmp ne ptr %t200, null
  br i1 %t201, label %bb44, label %bb45
bb44:
  %t203 = load ptr, ptr %l95, !tbaa !29
  %t204 = load i64, ptr %t203, !range !{i64 0, i64 8}
  %t206 = icmp eq i64 %t204, 0
  store i1 %t206, ptr %l96, !tbaa !21
  br label %bb45
bb45:
  %t207 = load i1, ptr %l96, !tbaa !21
  %t208 = xor i1 %t207, true
  %t209 = load i64, ptr %l94, !tbaa !24
  %t211 = call %"compiler/typed:argRoot" @compiler_2ftyped_3aargRoot_2ector(ptr %s0, i64 %t209, i1 %t208)
  store %"compiler/typed:argRoot" %t211, ptr %l100
  br label %bb46
bb46:
  %t212 = load %"compiler/typed:argRoot", ptr %l100
  store %"compiler/typed:argRoot" %t212, ptr %l57
  br label %bb53
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t213 = call %"compiler/typed:argRoot" @compiler_2ftyped_3aargRoot_2ector(ptr %s0, i64 -1, i1 false)
  store %"compiler/typed:argRoot" %t213, ptr %l101
  br label %bb51
bb51:
  %t214 = load %"compiler/typed:argRoot", ptr %l101
  store %"compiler/typed:argRoot" %t214, ptr %l57
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_2d500740710f6411_bcf53f428dcf676d)
  unreachable
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t215 = load %"compiler/typed:argRoot", ptr %l57
  store %"compiler/typed:argRoot" %t215, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:argRoot", ptr %rv
  ret %"compiler/typed:argRoot" %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca i1
  %l41 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca i64
  %l50 = alloca ptr
  %l56 = alloca i1
  %l59 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:LocalUses", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l17, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t27 = load ptr, ptr %l17, !tbaa !29
  %t28 = call ptr @__olang_scope_or(ptr %v2, ptr %t27)
  %t29 = ptrtoint ptr %t28 to i64
  %t31 = inttoptr i64 %t29 to ptr
  %t32 = load ptr, ptr %l17, !tbaa !29
  %t34 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t31, ptr %t32, i32 %t26)
  store i64 %t34, ptr %l20
  br label %bb6
bb6:
  %t35 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t36 = load i64, ptr %l20, !tbaa !24
  %t38 = and i64 %t36, %t35
  %t40 = icmp eq i64 %t38, 0
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load ptr, ptr %l3, !tbaa !29
  store ptr %t42, ptr %l24, !tbaa !29
  br label %bb9
bb8:
  store ptr null, ptr %l24, !tbaa !29
  br label %bb9
bb9:
  %t45 = load ptr, ptr %l24, !tbaa !29
  store ptr %t45, ptr %l7, !tbaa !29
  br label %bb29
bb10:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = load ptr, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 2
  store i1 %t53, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t54 = load i1, ptr %l28, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l4, !tbaa !23
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t63, i32 0, i32 2
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb24
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/typed:LocalUses", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  store ptr %t70, ptr %l36, !tbaa !29
  %t71 = load i32, ptr %l4, !tbaa !23
  %t72 = load ptr, ptr %l36, !tbaa !29
  %t73 = call ptr @__olang_scope_or(ptr %v2, ptr %t72)
  %t74 = ptrtoint ptr %t73 to i64
  %t76 = inttoptr i64 %t74 to ptr
  %t77 = load ptr, ptr %l36, !tbaa !29
  %t79 = call i1 @compiler_2ftyped_2escalarType(ptr %t76, ptr %t77, i32 %t71)
  store i1 %t79, ptr %l39
  br label %bb16
bb16:
  %t80 = load i1, ptr %l39, !tbaa !21
  %t81 = xor i1 %t80, true
  br i1 %t81, label %bb17, label %bb18
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/typed:LocalUses", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  store ptr %t86, ptr %l43, !tbaa !29
  %t87 = load i32, ptr %l4, !tbaa !23
  %t88 = load ptr, ptr %l43, !tbaa !29
  %t89 = call ptr @__olang_scope_or(ptr %v2, ptr %t88)
  %t90 = ptrtoint ptr %t89 to i64
  %t92 = inttoptr i64 %t90 to ptr
  %t93 = load ptr, ptr %l43, !tbaa !29
  %t95 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t92, ptr %t93, i32 %t87)
  store i64 %t95, ptr %l46
  br label %bb19
bb18:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb20
bb19:
  %t96 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t97 = load i64, ptr %l46, !tbaa !24
  %t99 = and i64 %t97, %t96
  %t101 = icmp eq i64 %t99, 0
  store i1 %t101, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t103 = load i1, ptr %l41, !tbaa !21
  br i1 %t103, label %bb21, label %bb22
bb21:
  %t104 = load ptr, ptr %l5, !tbaa !29
  store ptr %t104, ptr %l50, !tbaa !29
  br label %bb23
bb22:
  store ptr null, ptr %l50, !tbaa !29
  br label %bb23
bb23:
  %t107 = load ptr, ptr %l50, !tbaa !29
  store ptr %t107, ptr %l7, !tbaa !29
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store ptr null, ptr %l7, !tbaa !29
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_e6cc28bf48cbd31_b57ed710b41deab5)
  unreachable
bb29:
  %t108 = load ptr, ptr %l7, !tbaa !29
  store ptr %t108, ptr %l6, !tbaa !29
  %t109 = load ptr, ptr %l6, !tbaa !29
  %t111 = icmp eq ptr %t109, null
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb30, label %bb31
bb30:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l6, !tbaa !29
  %t119 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t115, ptr %t116)
  store i64 %t119, ptr %l59
  br label %bb32
bb31:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb33
bb32:
  %t120 = load i64, ptr %l59, !tbaa !24
  %t121 = icmp sge i64 %t120, 0
  store i1 %t121, ptr %l56, !tbaa !21
  br label %bb33
bb33:
  %t123 = load i1, ptr %l56, !tbaa !21
  store i1 %t123, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t5)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = call ptr @__olang_scope_or(ptr %v2, ptr %t8)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load i32, ptr %l6, !tbaa !23
  %t15 = call i1 @compiler_2ftyped_2escalarType(ptr %t12, ptr %t13, i32 %t14)
  store i1 %t15, ptr %l8
  br label %bb2
bb2:
  %t16 = load i1, ptr %l8, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t39 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2efieldsOnly(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store i1 %t39, ptr %l20
  br label %bb11
bb11:
  %t40 = load i1, ptr %l20, !tbaa !21
  store i1 %t40, ptr %l11, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_c33a5c6933895_a18ea8bdcccb3229)
  unreachable
bb17:
  %t41 = load i1, ptr %l11, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l52 = alloca i32
  %l54 = alloca i1
  %l55 = alloca { i64, [1 x i64] }
  %l58 = alloca ptr
  %l59 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca i1
  %l208 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l233 = alloca ptr
  %l236 = alloca ptr
  %l237 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca i1
  %t74 = alloca { i64, [1 x i64] }, align 8
  %t78 = alloca { i64, [1 x i64] }, align 8
  %t118 = alloca { i64, [1 x i64] }, align 8
  %t153 = alloca { i64, [1 x i64] }, align 8
  %t177 = alloca { i64, [1 x i64] }, align 8
  %t200 = alloca { i64, [1 x i64] }, align 8
  %t227 = alloca { i64, [1 x i64] }, align 8
  %t295 = alloca { i64, [1 x i64] }, align 8
  %t325 = alloca { i64, [1 x i64] }, align 8
  %t333 = alloca { i64, [1 x i64] }, align 8
  %t420 = alloca { i64, [1 x i64] }, align 8
  %t463 = alloca { i64, [1 x i64] }, align 8
  %t499 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t2 = load ptr, ptr %l24, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l24, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l25, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l25, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t22, i32 %t23, ptr %t24)
  br label %bb6
bb6:
  br label %bb133
bb7:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t29 = load ptr, ptr %l35, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l35, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 17}
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l36, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l36, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t39, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb20
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t51 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %v3, ptr %v2, ptr %t49, ptr %t50, ptr %t51)
  br label %bb13
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l46, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  store ptr %t56, ptr %l48, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:LocalUses", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l50, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t62)
  store i32 %t64, ptr %l52
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l50, !tbaa !29
  %t66 = call ptr @__olang_scope_or(ptr %v3, ptr %t65)
  %t67 = ptrtoint ptr %t66 to i64
  %t69 = inttoptr i64 %t67 to ptr
  %t70 = load ptr, ptr %l50, !tbaa !29
  %t71 = load i32, ptr %l52, !tbaa !23
  %t72 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t69, ptr %t70, i32 %t71)
  store i1 %t72, ptr %l54
  br label %bb15
bb15:
  %t73 = load i1, ptr %l54, !tbaa !21
  br i1 %t73, label %bb16, label %bb17
bb16:
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 5, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t74
  store { i64, [1 x i64] } %t76, ptr %l55
  br label %bb18
bb17:
  store { i64, [1 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [1 x i64] }, ptr %t78, i32 0, i32 0
  store i64 2, ptr %t79
  %t80 = load { i64, [1 x i64] }, ptr %t78
  store { i64, [1 x i64] } %t80, ptr %l55
  br label %bb18
bb18:
  %t82 = load ptr, ptr %l46, !tbaa !29
  %t83 = load ptr, ptr %l48, !tbaa !29
  %t84 = load { i64, [1 x i64] }, ptr %l55
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t82, ptr %t83, { i64, [1 x i64] } %t84)
  br label %bb19
bb19:
  br label %bb133
bb20:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t86 = load ptr, ptr %l58, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t89 = load ptr, ptr %l58, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 17}
  %t92 = icmp eq i64 %t90, 2
  store i1 %t92, ptr %l59, !tbaa !21
  br label %bb22
bb22:
  %t93 = load i1, ptr %l59, !tbaa !21
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", ptr }, ptr %t96, i32 0, i32 1
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l6, !tbaa !29
  br label %bb29
bb24:
  %t100 = load ptr, ptr %l1, !tbaa !29
  store ptr %t100, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t101 = load ptr, ptr %l64, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb25, label %bb26
bb25:
  %t104 = load ptr, ptr %l64, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 17}
  %t107 = icmp eq i64 %t105, 8
  store i1 %t107, ptr %l65, !tbaa !21
  br label %bb26
bb26:
  %t108 = load i1, ptr %l65, !tbaa !21
  br i1 %t108, label %bb27, label %bb28
bb27:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [3 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t111, i32 0, i32 1
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l6, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [1 x i64] }, ptr %t118, i32 0, i32 0
  store i64 0, ptr %t119
  %t120 = load { i64, [1 x i64] }, ptr %t118
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t115, ptr %t116, { i64, [1 x i64] } %t120)
  br label %bb30
bb30:
  br label %bb133
bb31:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t125 = load ptr, ptr %l74, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb32, label %bb33
bb32:
  %t128 = load ptr, ptr %l74, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 17}
  %t131 = icmp eq i64 %t129, 6
  store i1 %t131, ptr %l75, !tbaa !21
  br label %bb33
bb33:
  %t132 = load i1, ptr %l75, !tbaa !21
  br i1 %t132, label %bb34, label %bb35
bb34:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", ptr }, ptr %t135, i32 0, i32 1
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l7, !tbaa !29
  br label %bb36
bb35:
  br label %bb42
bb36:
  %t139 = load ptr, ptr %l7, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb37, label %bb38
bb37:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/typed:LocalUses", ptr %t145, i32 0, i32 20
  %t148 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t147, ptr %t148)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [1 x i64] }, ptr %t153, i32 0, i32 0
  store i64 3, ptr %t154
  %t155 = load { i64, [1 x i64] }, ptr %t153
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t151, ptr %t152, { i64, [1 x i64] } %t155)
  br label %bb41
bb41:
  br label %bb133
bb42:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t160 = load ptr, ptr %l89, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb43, label %bb44
bb43:
  %t163 = load ptr, ptr %l89, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 17}
  %t166 = icmp eq i64 %t164, 15
  store i1 %t166, ptr %l90, !tbaa !21
  br label %bb44
bb44:
  %t167 = load i1, ptr %l90, !tbaa !21
  br i1 %t167, label %bb45, label %bb46
bb45:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr }, ptr %t170, i32 0, i32 1
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l8, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l8, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t177
  %t178 = getelementptr { i64, [1 x i64] }, ptr %t177, i32 0, i32 0
  store i64 5, ptr %t178
  %t179 = load { i64, [1 x i64] }, ptr %t177
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t174, ptr %t175, { i64, [1 x i64] } %t179)
  br label %bb48
bb48:
  br label %bb133
bb49:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t184 = load ptr, ptr %l99, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb50, label %bb51
bb50:
  %t187 = load ptr, ptr %l99, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 17}
  %t190 = icmp eq i64 %t188, 16
  store i1 %t190, ptr %l100, !tbaa !21
  br label %bb51
bb51:
  %t191 = load i1, ptr %l100, !tbaa !21
  br i1 %t191, label %bb52, label %bb53
bb52:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l9, !tbaa !29
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l9, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t200
  %t201 = getelementptr { i64, [1 x i64] }, ptr %t200, i32 0, i32 0
  store i64 5, ptr %t201
  %t202 = load { i64, [1 x i64] }, ptr %t200
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t198, ptr %t199, { i64, [1 x i64] } %t202)
  br label %bb55
bb55:
  br label %bb133
bb56:
  %t206 = load ptr, ptr %l1, !tbaa !29
  store ptr %t206, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t207 = load ptr, ptr %l108, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb57, label %bb58
bb57:
  %t210 = load ptr, ptr %l108, !tbaa !29
  %t211 = load i64, ptr %t210, !range !{i64 0, i64 17}
  %t213 = icmp eq i64 %t211, 3
  store i1 %t213, ptr %l109, !tbaa !21
  br label %bb58
bb58:
  %t214 = load i1, ptr %l109, !tbaa !21
  br i1 %t214, label %bb59, label %bb60
bb59:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr { i64, [3 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", ptr }, ptr %t217, i32 0, i32 1
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l10, !tbaa !29
  br label %bb61
bb60:
  br label %bb65
bb61:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l10, !tbaa !29
  %t224 = getelementptr %"compiler/typed:If", ptr %t222, i32 0, i32 0
  %t225 = load ptr, ptr %t224, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t227
  %t228 = getelementptr { i64, [1 x i64] }, ptr %t227, i32 0, i32 0
  store i64 0, ptr %t228
  %t229 = load { i64, [1 x i64] }, ptr %t227
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t221, ptr %t225, { i64, [1 x i64] } %t229)
  br label %bb62
bb62:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load ptr, ptr %l10, !tbaa !29
  %t236 = getelementptr %"compiler/typed:If", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t233, ptr %t237)
  br label %bb63
bb63:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l10, !tbaa !29
  %t244 = getelementptr %"compiler/typed:If", ptr %t242, i32 0, i32 2
  %t245 = load ptr, ptr %t244, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t241, ptr %t245)
  br label %bb64
bb64:
  br label %bb133
bb65:
  %t248 = load ptr, ptr %l1, !tbaa !29
  store ptr %t248, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t249 = load ptr, ptr %l126, !tbaa !29
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %bb66, label %bb67
bb66:
  %t252 = load ptr, ptr %l126, !tbaa !29
  %t253 = load i64, ptr %t252, !range !{i64 0, i64 17}
  %t255 = icmp eq i64 %t253, 4
  store i1 %t255, ptr %l127, !tbaa !21
  br label %bb67
bb67:
  %t256 = load i1, ptr %l127, !tbaa !21
  br i1 %t256, label %bb68, label %bb69
bb68:
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr { i64, [3 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t259, i32 0, i32 1
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l11, !tbaa !29
  %t263 = load ptr, ptr %l1, !tbaa !29
  %t265 = getelementptr { i64, [3 x i64] }, ptr %t263, i32 0, i32 1
  %t266 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t265, i32 0, i32 2
  %t267 = load ptr, ptr %t266
  store ptr %t267, ptr %l12, !tbaa !29
  br label %bb70
bb69:
  br label %bb73
bb70:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t269, ptr %t270)
  br label %bb71
bb71:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t274, ptr %t275)
  br label %bb72
bb72:
  br label %bb133
bb73:
  %t278 = load ptr, ptr %l1, !tbaa !29
  store ptr %t278, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t279 = load ptr, ptr %l139, !tbaa !29
  %t280 = icmp ne ptr %t279, null
  br i1 %t280, label %bb74, label %bb75
bb74:
  %t282 = load ptr, ptr %l139, !tbaa !29
  %t283 = load i64, ptr %t282, !range !{i64 0, i64 17}
  %t285 = icmp eq i64 %t283, 9
  store i1 %t285, ptr %l140, !tbaa !21
  br label %bb75
bb75:
  %t286 = load i1, ptr %l140, !tbaa !21
  br i1 %t286, label %bb76, label %bb77
bb76:
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = getelementptr { i64, [3 x i64] }, ptr %t287, i32 0, i32 1
  %t290 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t289, i32 0, i32 2
  %t291 = load ptr, ptr %t290
  store ptr %t291, ptr %l13, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l13, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t295
  %t296 = getelementptr { i64, [1 x i64] }, ptr %t295, i32 0, i32 0
  store i64 0, ptr %t296
  %t297 = load { i64, [1 x i64] }, ptr %t295
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t293, ptr %t294, { i64, [1 x i64] } %t297)
  br label %bb79
bb79:
  br label %bb133
bb80:
  %t301 = load ptr, ptr %l1, !tbaa !29
  store ptr %t301, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t302 = load ptr, ptr %l148, !tbaa !29
  %t303 = icmp ne ptr %t302, null
  br i1 %t303, label %bb81, label %bb82
bb81:
  %t305 = load ptr, ptr %l148, !tbaa !29
  %t306 = load i64, ptr %t305, !range !{i64 0, i64 17}
  %t308 = icmp eq i64 %t306, 10
  store i1 %t308, ptr %l149, !tbaa !21
  br label %bb82
bb82:
  %t309 = load i1, ptr %l149, !tbaa !21
  br i1 %t309, label %bb83, label %bb84
bb83:
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr { i64, [3 x i64] }, ptr %t310, i32 0, i32 1
  %t313 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t312, i32 0, i32 1
  %t314 = load ptr, ptr %t313
  store ptr %t314, ptr %l14, !tbaa !29
  %t316 = load ptr, ptr %l1, !tbaa !29
  %t318 = getelementptr { i64, [3 x i64] }, ptr %t316, i32 0, i32 1
  %t319 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t318, i32 0, i32 2
  %t320 = load ptr, ptr %t319
  store ptr %t320, ptr %l15, !tbaa !29
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load ptr, ptr %l14, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t325
  %t326 = getelementptr { i64, [1 x i64] }, ptr %t325, i32 0, i32 0
  store i64 0, ptr %t326
  %t327 = load { i64, [1 x i64] }, ptr %t325
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t322, ptr %t323, { i64, [1 x i64] } %t327)
  br label %bb86
bb86:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l15, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t333
  %t334 = getelementptr { i64, [1 x i64] }, ptr %t333, i32 0, i32 0
  store i64 0, ptr %t334
  %t335 = load { i64, [1 x i64] }, ptr %t333
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t331, ptr %t332, { i64, [1 x i64] } %t335)
  br label %bb87
bb87:
  br label %bb133
bb88:
  %t339 = load ptr, ptr %l1, !tbaa !29
  store ptr %t339, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t340 = load ptr, ptr %l163, !tbaa !29
  %t341 = icmp ne ptr %t340, null
  br i1 %t341, label %bb89, label %bb90
bb89:
  %t343 = load ptr, ptr %l163, !tbaa !29
  %t344 = load i64, ptr %t343, !range !{i64 0, i64 17}
  %t346 = icmp eq i64 %t344, 11
  store i1 %t346, ptr %l164, !tbaa !21
  br label %bb90
bb90:
  %t347 = load i1, ptr %l164, !tbaa !21
  br i1 %t347, label %bb91, label %bb92
bb91:
  %t348 = load ptr, ptr %l1, !tbaa !29
  %t350 = getelementptr { i64, [3 x i64] }, ptr %t348, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", ptr }, ptr %t350, i32 0, i32 1
  %t352 = load ptr, ptr %t351
  store ptr %t352, ptr %l16, !tbaa !29
  br label %bb97
bb92:
  %t354 = load ptr, ptr %l1, !tbaa !29
  store ptr %t354, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t355 = load ptr, ptr %l169, !tbaa !29
  %t356 = icmp ne ptr %t355, null
  br i1 %t356, label %bb93, label %bb94
bb93:
  %t358 = load ptr, ptr %l169, !tbaa !29
  %t359 = load i64, ptr %t358, !range !{i64 0, i64 17}
  %t361 = icmp eq i64 %t359, 12
  store i1 %t361, ptr %l170, !tbaa !21
  br label %bb94
bb94:
  %t362 = load i1, ptr %l170, !tbaa !21
  br i1 %t362, label %bb95, label %bb96
bb95:
  %t363 = load ptr, ptr %l1, !tbaa !29
  %t365 = getelementptr { i64, [3 x i64] }, ptr %t363, i32 0, i32 1
  %t366 = getelementptr { %"compiler/source:Span", ptr }, ptr %t365, i32 0, i32 1
  %t367 = load ptr, ptr %t366
  store ptr %t367, ptr %l16, !tbaa !29
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t369, ptr %t370)
  br label %bb98
bb98:
  br label %bb133
bb99:
  %t374 = load ptr, ptr %l1, !tbaa !29
  store ptr %t374, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t375 = load ptr, ptr %l178, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb100, label %bb101
bb100:
  %t378 = load ptr, ptr %l178, !tbaa !29
  %t379 = load i64, ptr %t378, !range !{i64 0, i64 17}
  %t381 = icmp eq i64 %t379, 13
  store i1 %t381, ptr %l179, !tbaa !21
  br label %bb101
bb101:
  %t382 = load i1, ptr %l179, !tbaa !21
  br i1 %t382, label %bb102, label %bb103
bb102:
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = getelementptr { i64, [3 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", ptr }, ptr %t385, i32 0, i32 1
  %t387 = load ptr, ptr %t386
  store ptr %t387, ptr %l17, !tbaa !29
  br label %bb104
bb103:
  br label %bb107
bb104:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/typed:LocalUses", ptr %t389, i32 0, i32 45
  %t392 = load i64, ptr %t391, !tbaa !24
  store i64 %t392, ptr %l18, !tbaa !24
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/typed:LocalUses", ptr %t395, i32 0, i32 43
  %t398 = load i64, ptr %t397, !tbaa !24
  %t401 = getelementptr %"compiler/typed:LocalUses", ptr %t394, i32 0, i32 45
  store i64 %t398, ptr %t401, !tbaa !24
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load ptr, ptr %l17, !tbaa !29
  %t405 = getelementptr %"compiler/typed:Join", ptr %t403, i32 0, i32 0
  %t406 = load ptr, ptr %t405, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t402, ptr %t406)
  br label %bb105
bb105:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load i64, ptr %l18, !tbaa !24
  %t414 = getelementptr %"compiler/typed:LocalUses", ptr %t410, i32 0, i32 45
  store i64 %t411, ptr %t414, !tbaa !24
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load ptr, ptr %l17, !tbaa !29
  %t418 = getelementptr %"compiler/typed:Join", ptr %t416, i32 0, i32 2
  %t419 = load { i64, ptr }, ptr %t418, !tbaa !27
  store { i64, [1 x i64] } zeroinitializer, ptr %t420
  %t421 = getelementptr { i64, [1 x i64] }, ptr %t420, i32 0, i32 0
  store i64 5, ptr %t421
  %t422 = load { i64, [1 x i64] }, ptr %t420
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t415, { i64, ptr } %t419, { i64, [1 x i64] } %t422)
  br label %bb106
bb106:
  br label %bb133
bb107:
  %t426 = load ptr, ptr %l1, !tbaa !29
  store ptr %t426, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t427 = load ptr, ptr %l199, !tbaa !29
  %t428 = icmp ne ptr %t427, null
  br i1 %t428, label %bb108, label %bb109
bb108:
  %t430 = load ptr, ptr %l199, !tbaa !29
  %t431 = load i64, ptr %t430, !range !{i64 0, i64 17}
  %t433 = icmp eq i64 %t431, 14
  store i1 %t433, ptr %l200, !tbaa !21
  br label %bb109
bb109:
  %t434 = load i1, ptr %l200, !tbaa !21
  br i1 %t434, label %bb110, label %bb111
bb110:
  %t435 = load ptr, ptr %l1, !tbaa !29
  %t437 = getelementptr { i64, [3 x i64] }, ptr %t435, i32 0, i32 1
  %t438 = getelementptr { %"compiler/source:Span", ptr }, ptr %t437, i32 0, i32 1
  %t439 = load ptr, ptr %t438
  store ptr %t439, ptr %l19, !tbaa !29
  br label %bb112
bb111:
  br label %bb122
bb112:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load ptr, ptr %l19, !tbaa !29
  %t444 = getelementptr %"compiler/typed:Spawn", ptr %t442, i32 0, i32 0
  %t445 = load { i64, ptr }, ptr %t444, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etargets(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t441, { i64, ptr } %t445)
  br label %bb113
bb113:
  %t448 = load ptr, ptr %l0, !tbaa !29
  store ptr %t448, ptr %l208, !tbaa !29
  %t449 = load ptr, ptr %l208, !tbaa !29
  %t450 = getelementptr %"compiler/typed:LocalUses", ptr %t449, i32 0, i32 25
  %t451 = load i64, ptr %t450, !tbaa !24
  %t453 = add i64 %t451, 1
  %t455 = load ptr, ptr %l208, !tbaa !29
  %t456 = getelementptr %"compiler/typed:LocalUses", ptr %t455, i32 0, i32 25
  store i64 %t453, ptr %t456, !tbaa !24
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load ptr, ptr %l19, !tbaa !29
  %t460 = getelementptr %"compiler/typed:Spawn", ptr %t458, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t463
  %t464 = getelementptr { i64, [1 x i64] }, ptr %t463, i32 0, i32 0
  store i64 5, ptr %t464
  %t465 = load { i64, [1 x i64] }, ptr %t463
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t457, ptr %t461, { i64, [1 x i64] } %t465)
  br label %bb114
bb114:
  %t469 = load ptr, ptr %l19, !tbaa !29
  %t471 = getelementptr %"compiler/typed:Spawn", ptr %t469, i32 0, i32 2
  %t472 = load { i64, ptr }, ptr %t471, !tbaa !27
  store { i64, ptr } %t472, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t474 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t476 = extractvalue { i64, ptr } %t474, 0
  store i64 %t476, ptr %l22, !tbaa !24
  br label %bb115
bb115:
  %t478 = load i64, ptr %l21, !tbaa !24
  %t479 = load i64, ptr %l22, !tbaa !24
  %t482 = icmp slt i64 %t478, %t479
  %t484 = xor i1 %t482, true
  br i1 %t484, label %bb116, label %bb117
bb116:
  br label %bb121
bb117:
  br label %bb118
bb118:
  %t486 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t486, ptr %l224, !tbaa !27
  %t487 = load i64, ptr %l21, !tbaa !24
  %t489 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = getelementptr ptr, ptr %t490, i64 %t487
  %t492 = load ptr, ptr %t491, !tbaa !39
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/typed:TaskClause", ptr %t492, i32 0, i32 3
  %t498 = load ptr, ptr %t497, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t499
  %t500 = getelementptr { i64, [1 x i64] }, ptr %t499, i32 0, i32 0
  store i64 5, ptr %t500
  %t501 = load { i64, [1 x i64] }, ptr %t499
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t494, ptr %t498, { i64, [1 x i64] } %t501)
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t505 = load i64, ptr %l21, !tbaa !24
  %t507 = add i64 %t505, 1
  store i64 %t507, ptr %l21, !tbaa !24
  br label %bb115
bb121:
  %t509 = load ptr, ptr %l0, !tbaa !29
  store ptr %t509, ptr %l233, !tbaa !29
  %t510 = load ptr, ptr %l233, !tbaa !29
  %t511 = getelementptr %"compiler/typed:LocalUses", ptr %t510, i32 0, i32 25
  %t512 = load i64, ptr %t511, !tbaa !24
  %t514 = sub i64 %t512, 1
  %t516 = load ptr, ptr %l233, !tbaa !29
  %t517 = getelementptr %"compiler/typed:LocalUses", ptr %t516, i32 0, i32 25
  store i64 %t514, ptr %t517, !tbaa !24
  br label %bb133
bb122:
  %t518 = load ptr, ptr %l1, !tbaa !29
  store ptr %t518, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t519 = load ptr, ptr %l236, !tbaa !29
  %t520 = icmp ne ptr %t519, null
  br i1 %t520, label %bb123, label %bb124
bb123:
  %t522 = load ptr, ptr %l236, !tbaa !29
  %t523 = load i64, ptr %t522, !range !{i64 0, i64 17}
  %t525 = icmp eq i64 %t523, 5
  store i1 %t525, ptr %l237, !tbaa !21
  br label %bb124
bb124:
  %t526 = load i1, ptr %l237, !tbaa !21
  br i1 %t526, label %bb125, label %bb126
bb125:
  br label %bb131
bb126:
  %t527 = load ptr, ptr %l1, !tbaa !29
  store ptr %t527, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t528 = load ptr, ptr %l240, !tbaa !29
  %t529 = icmp ne ptr %t528, null
  br i1 %t529, label %bb127, label %bb128
bb127:
  %t531 = load ptr, ptr %l240, !tbaa !29
  %t532 = load i64, ptr %t531, !range !{i64 0, i64 17}
  %t534 = icmp eq i64 %t532, 7
  store i1 %t534, ptr %l241, !tbaa !21
  br label %bb128
bb128:
  %t535 = load i1, ptr %l241, !tbaa !21
  br i1 %t535, label %bb129, label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_9a2d2471d97215b1_125b5d47933e1fad)
  unreachable
bb133:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb37
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 4
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Elem", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %t35, ptr %t39)
  br label %bb13
bb13:
  br label %bb37
bb14:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 8}
  %t49 = icmp eq i64 %t47, 5
  store i1 %t49, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l25, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Payload", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %t57, ptr %t61)
  br label %bb20
bb20:
  br label %bb37
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t65 = load ptr, ptr %l33, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l33, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 8}
  %t71 = icmp eq i64 %t69, 6
  store i1 %t71, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t72 = load i1, ptr %l34, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t83 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %t79, ptr %t80)
  store i64 %t83, ptr %l41
  br label %bb27
bb27:
  %t84 = load i64, ptr %l41, !tbaa !24
  store i64 %t84, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l6, !tbaa !24
  %t87 = icmp sge i64 %t85, 0
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/typed:LocalUses", ptr %t89, i32 0, i32 2
  %t92 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t91, i64 %t92, i1 true)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_2dc1351d0e6e1c9_f66be85c5a6693dd)
  unreachable
bb37:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l3
  br label %bb37
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 8}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t79 = load ptr, ptr %l35, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t94 = load ptr, ptr %l41, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 8}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l42, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t109 = load ptr, ptr %l47, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l47, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 8}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l48, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l48, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l3
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_35eb3a0a3b047e6d_bf317ca81d1426a1)
  unreachable
bb37:
  %t125 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t125, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l1, !tbaa !23
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l1, !tbaa !23
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l1, !tbaa !23
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load i32, ptr %l1, !tbaa !23
  store i32 %t61, ptr %l3, !tbaa !23
  br label %bb37
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 8}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l2, !tbaa !23
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t79 = load ptr, ptr %l35, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l2, !tbaa !23
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t94 = load ptr, ptr %l41, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 8}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l42, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l2, !tbaa !23
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t109 = load ptr, ptr %l47, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l47, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 8}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l48, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l48, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32 }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l2, !tbaa !23
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load i32, ptr %l2, !tbaa !23
  store i32 %t123, ptr %l3, !tbaa !23
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_e2587c8ec5c6f861_9513078f5b00021d)
  unreachable
bb37:
  %t125 = load i32, ptr %l3, !tbaa !23
  store i32 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l18, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Alt", ptr %t33, i32 0, i32 1
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t50 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t50, ptr %l32, !tbaa !27
  %t51 = load i64, ptr %l7, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Bind", ptr %t56, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t58, ptr %t62)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l7, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Arm", ptr %t74, i32 0, i32 2
  %t77 = load ptr, ptr %t76, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t73, ptr %t77)
  br label %bb15
bb15:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Arm", ptr %t81, i32 0, i32 3
  %t84 = load ptr, ptr %t83, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  br label %bb16
bb16:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Arm", ptr %t88, i32 0, i32 4
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %t87, ptr %t91)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l26 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l11, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { ptr }, ptr %t17, i32 0, i32 0
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  br label %bb6
bb6:
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_f34835f3d61f57d9_feeccb0fe1526945)
  unreachable
bb12:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Call", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb14, label %bb15
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t42, ptr %l26, !tbaa !27
  %t43 = load i64, ptr %l5, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t50, ptr %t48)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l5, !tbaa !24
  br label %bb13
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l17 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l17, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Clause", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Clause", ptr %t30, i32 0, i32 4
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t47, ptr %l31, !tbaa !27
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %t55, ptr %t53)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t59 = load i64, ptr %l7, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l7, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eplaceAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Nodes", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Nodes", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %s2, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l38
  br label %bb12
bb12:
  %t61 = load ptr, ptr %l38, !tbaa !29
  %t63 = icmp eq ptr %t61, %a1
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t65, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t67 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eDerivedArgAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/typed:DerivedArg"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i32
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca %"compiler/typed:DerivedArg"
  %l30 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t16 = alloca { i64, [2 x i64] }, align 8
  %t61 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/typed:Plan", ptr %a0, i32 0, i32 19
  %t6 = sext i32 %a1 to i64
  %t9 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H05bdc185ea10b7cb65a89c49d4b056c8(ptr %v0, ptr %v0, ptr %t3, i64 %t6)
  %t10 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t9, 1
  %t11 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t9, 0
  store i32 %t11, ptr %l14
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13, !prof !99
ok.13:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l13
  br label %bb1
bb1:
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %s0, ptr %l13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l16
  br label %bb4
bb2:
  br label %bb3
bb3:
  store { i64, [2 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [2 x i64] }, ptr %t16, i32 0, i32 0
  store i64 0, ptr %t17
  %t18 = load { i64, [2 x i64] }, ptr %t16
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t18, ptr %rv
  br label %ret
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l8
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l4
  store ptr %l4, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t23 = load i64, ptr %l6, !tbaa !24
  store i64 %t23, ptr %l19, !tbaa !24
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eLen_H205a9438cb31641857cd9c1e93810664(ptr %s0, ptr %t24)
  store i64 %t26, ptr %l21
  br label %bb7
bb7:
  %t27 = load i64, ptr %l19, !tbaa !24
  %t28 = load i64, ptr %l21, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb8, label %bb9
bb8:
  br label %bb19
bb9:
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = call %"compiler/typed:DerivedArg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eAt__H3d322c834b4b1582ab12028f5b0f20b9(ptr %s0, ptr %t33, i64 %t34)
  store %"compiler/typed:DerivedArg" %t37, ptr %l26
  br label %bb11
bb11:
  %t38 = load %"compiler/typed:DerivedArg", ptr %l26
  store %"compiler/typed:DerivedArg" %t38, ptr %l7
  %t39 = getelementptr %"compiler/typed:DerivedArg", ptr %l7, i32 0, i32 0
  %t40 = load i64, ptr %t39, !tbaa !24
  %t44 = icmp eq i64 %t40, %a2
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = getelementptr %"compiler/typed:DerivedArg", ptr %l7, i32 0, i32 1
  %t47 = load i64, ptr %t46, !tbaa !24
  %t51 = icmp eq i64 %t47, %a3
  store i1 %t51, ptr %l30, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t54 = getelementptr %"compiler/typed:DerivedArg", ptr %l7, i32 0, i32 2
  %t55 = load { i64, [2 x i64] }, ptr %t54
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t55, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l6, !tbaa !24
  br label %bb6
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [2 x i64] }, ptr %t61, i32 0, i32 0
  store i64 0, ptr %t62
  %t63 = load { i64, [2 x i64] }, ptr %t61
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t63, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eDropHome(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca ptr
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 22
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Plan", ptr %t53, i32 0, i32 22
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s2, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l39
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t61 = load ptr, ptr %l39, !tbaa !29
  %t63 = icmp eq ptr %t61, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Plan", ptr %t65, i32 0, i32 23
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load { i64, [2 x i64] }, ptr %l2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eSetAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t67, i64 %t68, { i64, [2 x i64] } %t69)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l7, !tbaa !24
  br label %bb8
bb18:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Plan", ptr %t77, i32 0, i32 22
  %t80 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t79, ptr %t80)
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Plan", ptr %t83, i32 0, i32 23
  %t86 = load { i64, [2 x i64] }, ptr %l2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t85, { i64, [2 x i64] } %t86)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l12 = alloca i1
  %l15 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 14
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l6, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i64, ptr %t10, i64 %t7
  %t12 = load i64, ptr %t11, !tbaa !34
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t19, i32 0, i32 15
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  %t33 = icmp sge i64 %t18, %t30
  store i1 %t33, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t35 = load i1, ptr %l12, !tbaa !21
  br i1 %t35, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Plan", ptr %t36, i32 0, i32 16
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t41, %t42
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eSetAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t38, i64 %t45, { i64, [2 x i64] } %a3)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eTwin(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i1
  %l14 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  %t5 = icmp slt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Plan", ptr %t10, i32 0, i32 13
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp sge i64 %t9, %t15
  store i1 %t18, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l5, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Plan", ptr %t22, i32 0, i32 13
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l14, !tbaa !27
  %t26 = load i32, ptr %l1, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t30 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i64, ptr %t31, i64 %t28
  %t33 = load i64, ptr %t32, !tbaa !34
  store i64 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2enoneIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/typed:LocalUses"
  %l6 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"compiler/typed:LocalUses"
  %l23 = alloca i32
  %l27 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i1
  %l53 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t22 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb4
bb2:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l11, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 5
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v3, ptr %t11)
  store i64 %t13, ptr %l14
  br label %bb3
bb3:
  %t14 = load i64, ptr %l11, !tbaa !24
  %t15 = load i64, ptr %l14, !tbaa !24
  %t16 = icmp sge i64 %t14, %t15
  store i1 %t16, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t22, ptr %v1, ptr %v3, ptr %s0, ptr %t20, ptr %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t22, i64 1320, i1 false)
  br label %bb8
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l19, i64 1320, i1 false)
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 5
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v3, ptr %t27, i64 %t28)
  store i32 %t31, ptr %l23
  br label %bb9
bb9:
  %t32 = load i32, ptr %l23, !tbaa !23
  %t33 = sext i32 %t32 to i64
  store i64 %t33, ptr %l6, !tbaa !24
  %t35 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 7
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t35, i64 %t36)
  store i1 %t39, ptr %l27
  br label %bb10
bb10:
  %t40 = load i1, ptr %l27, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb14
bb12:
  %t41 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 2
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t41, i64 %t42)
  store i1 %t45, ptr %l31
  br label %bb13
bb13:
  %t46 = load i1, ptr %l31, !tbaa !21
  store i1 %t46, ptr %l28, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l28, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb18
bb16:
  %t48 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 4
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t48, i64 %t49)
  store i1 %t52, ptr %l35
  br label %bb17
bb17:
  %t53 = load i1, ptr %l35, !tbaa !21
  store i1 %t53, ptr %l32, !tbaa !21
  br label %bb18
bb18:
  %t54 = load i1, ptr %l32, !tbaa !21
  br i1 %t54, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t56 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 8
  %t57 = load i64, ptr %l6, !tbaa !24
  %t60 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t56, i64 %t57)
  store i1 %t60, ptr %l39
  br label %bb22
bb22:
  %t61 = load i1, ptr %l39, !tbaa !21
  br i1 %t61, label %bb23, label %bb24
bb23:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l41, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Body", ptr %t64, i32 0, i32 2
  %t67 = load i32, ptr %t66, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v1, ptr %t63, i32 %t67)
  store i32 %t70, ptr %l45
  br label %bb25
bb24:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb27
bb25:
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t72 = load i32, ptr %l45, !tbaa !23
  %t73 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v1, ptr %t71, i32 %t72)
  store i1 %t73, ptr %l46
  br label %bb26
bb26:
  %t74 = load i1, ptr %l46, !tbaa !21
  store i1 %t74, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t75 = load i1, ptr %l40, !tbaa !21
  br i1 %t75, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = load i64, ptr %l6, !tbaa !24
  %t86 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2enamedOnly(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %a0, ptr %t78, ptr %a2, ptr %l5, i64 %t80)
  store i1 %t86, ptr %l53
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i1, ptr %l53, !tbaa !21
  store i1 %t87, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2enoneKeptIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/typed:LocalUses"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i64
  %l38 = alloca i64
  %l43 = alloca %"compiler/typed:LocalUses"
  %l47 = alloca i32
  %l51 = alloca i1
  %l52 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l89 = alloca i64
  %l92 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l98 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i1
  %l108 = alloca i64
  %l112 = alloca i64
  %l115 = alloca i64
  %l135 = alloca i64
  %l138 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca ptr
  %l141 = alloca ptr
  %l144 = alloca i64
  %l147 = alloca i64
  %l148 = alloca i1
  %l154 = alloca i64
  %l158 = alloca i64
  %l161 = alloca i64
  %l181 = alloca i64
  %l184 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca ptr
  %l187 = alloca ptr
  %l190 = alloca i64
  %l193 = alloca i64
  %l194 = alloca i1
  %l200 = alloca i64
  %l204 = alloca i64
  %l207 = alloca i64
  %l227 = alloca i64
  %l230 = alloca i1
  %l236 = alloca i64
  %l238 = alloca ptr
  %l239 = alloca ptr
  %l240 = alloca ptr
  %l241 = alloca ptr
  %l244 = alloca i64
  %l245 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t22 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 11
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb4
bb2:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l35, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 5
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v3, ptr %t11)
  store i64 %t13, ptr %l38
  br label %bb3
bb3:
  %t14 = load i64, ptr %l35, !tbaa !24
  %t15 = load i64, ptr %l38, !tbaa !24
  %t16 = icmp sge i64 %t14, %t15
  store i1 %t16, ptr %l34, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l34, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t22, ptr %v1, ptr %v3, ptr %s0, ptr %t20, ptr %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l43, ptr %t22, i64 1320, i1 false)
  br label %bb8
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l43, i64 1320, i1 false)
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 5
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v3, ptr %t27, i64 %t28)
  store i32 %t31, ptr %l47
  br label %bb9
bb9:
  %t32 = load i32, ptr %l47, !tbaa !23
  %t33 = sext i32 %t32 to i64
  store i64 %t33, ptr %l6, !tbaa !24
  %t35 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 28
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t35, i64 %t36)
  store i1 %t39, ptr %l51
  br label %bb10
bb10:
  %t40 = load i1, ptr %l51, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb14
bb12:
  %t41 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 29
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t41, i64 %t42)
  store i1 %t45, ptr %l55
  br label %bb13
bb13:
  %t46 = load i1, ptr %l55, !tbaa !21
  store i1 %t46, ptr %l52, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l52, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb18
bb16:
  %t48 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 30
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t48, i64 %t49)
  store i1 %t52, ptr %l59
  br label %bb17
bb17:
  %t53 = load i1, ptr %l59, !tbaa !21
  store i1 %t53, ptr %l56, !tbaa !21
  br label %bb18
bb18:
  %t54 = load i1, ptr %l56, !tbaa !21
  br i1 %t54, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  store i64 0, ptr %l7, !tbaa !24
  %t56 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 16
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t56)
  store i64 %t58, ptr %l62
  br label %bb22
bb22:
  %t59 = load i64, ptr %l62, !tbaa !24
  store i64 %t59, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb23, label %bb24
bb23:
  %t66 = load i64, ptr %l9, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb28
bb25:
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l9, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l69, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb27
bb27:
  %t86 = load i64, ptr %l69, !tbaa !24
  store i64 %t86, ptr %l66, !tbaa !24
  br label %bb28
bb28:
  %t87 = load i64, ptr %l66, !tbaa !24
  store i64 %t87, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb29
bb29:
  %t88 = load i64, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb30, label %bb31
bb30:
  br label %bb44
bb31:
  br label %bb32
bb32:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l12, !tbaa !24
  %t106 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 16
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t106, i64 %t107)
  store i64 %t110, ptr %l89
  br label %bb33
bb33:
  %t111 = load i64, ptr %l6, !tbaa !24
  %t112 = load i64, ptr %l89, !tbaa !24
  %t114 = icmp eq i64 %t112, %t111
  br i1 %t114, label %bb34, label %bb35
bb34:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l93, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  store ptr %t117, ptr %l94, !tbaa !29
  %t118 = load ptr, ptr %l2, !tbaa !29
  store ptr %t118, ptr %l95, !tbaa !29
  %t119 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 17
  %t120 = load i64, ptr %l12, !tbaa !24
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t119, i64 %t120)
  store i64 %t123, ptr %l98
  br label %bb36
bb35:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb39
bb36:
  %t124 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 18
  %t125 = load i64, ptr %l12, !tbaa !24
  %t128 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t124, i64 %t125)
  store i64 %t128, ptr %l101
  br label %bb37
bb37:
  %t129 = load ptr, ptr %l93, !tbaa !29
  %t130 = load ptr, ptr %l94, !tbaa !29
  %t131 = load ptr, ptr %l95, !tbaa !29
  %t132 = load i64, ptr %l98, !tbaa !24
  %t133 = load i64, ptr %l101, !tbaa !24
  %t134 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t129, ptr %t130, ptr %t131, i64 %t132, i64 %t133)
  store i1 %t134, ptr %l102
  br label %bb38
bb38:
  %t135 = load i1, ptr %l102, !tbaa !21
  %t136 = xor i1 %t135, true
  store i1 %t136, ptr %l92, !tbaa !21
  br label %bb39
bb39:
  %t138 = load i1, ptr %l92, !tbaa !21
  br i1 %t138, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t140 = load i64, ptr %l11, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l11, !tbaa !24
  br label %bb29
bb44:
  store i64 0, ptr %l13, !tbaa !24
  %t144 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 13
  %t146 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t144)
  store i64 %t146, ptr %l108
  br label %bb45
bb45:
  %t147 = load i64, ptr %l108, !tbaa !24
  store i64 %t147, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t148 = load i64, ptr %l14, !tbaa !24
  %t149 = load i64, ptr %l13, !tbaa !24
  %t152 = icmp sgt i64 %t148, %t149
  br i1 %t152, label %bb46, label %bb47
bb46:
  %t154 = load i64, ptr %l15, !tbaa !24
  %t156 = icmp sgt i64 %t154, 0
  br i1 %t156, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb51
bb48:
  %t158 = load i64, ptr %l14, !tbaa !24
  %t159 = load i64, ptr %l13, !tbaa !24
  %t162 = sub i64 %t158, %t159
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = add i64 %t162, %t163
  %t168 = sub i64 %t166, 1
  %t169 = load i64, ptr %l15, !tbaa !24
  %t172 = sdiv i64 %t168, %t169
  store i64 %t172, ptr %l115, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb50
bb50:
  %t174 = load i64, ptr %l115, !tbaa !24
  store i64 %t174, ptr %l112, !tbaa !24
  br label %bb51
bb51:
  %t175 = load i64, ptr %l112, !tbaa !24
  store i64 %t175, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb52
bb52:
  %t176 = load i64, ptr %l17, !tbaa !24
  %t177 = load i64, ptr %l16, !tbaa !24
  %t180 = icmp slt i64 %t176, %t177
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb53, label %bb54
bb53:
  br label %bb67
bb54:
  br label %bb55
bb55:
  %t184 = load i64, ptr %l13, !tbaa !24
  %t185 = load i64, ptr %l17, !tbaa !24
  %t186 = load i64, ptr %l15, !tbaa !24
  %t189 = mul i64 %t185, %t186
  %t192 = add i64 %t184, %t189
  store i64 %t192, ptr %l18, !tbaa !24
  %t194 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 13
  %t195 = load i64, ptr %l18, !tbaa !24
  %t198 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t194, i64 %t195)
  store i64 %t198, ptr %l135
  br label %bb56
bb56:
  %t199 = load i64, ptr %l6, !tbaa !24
  %t200 = load i64, ptr %l135, !tbaa !24
  %t202 = icmp eq i64 %t200, %t199
  br i1 %t202, label %bb57, label %bb58
bb57:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l139, !tbaa !29
  %t205 = load ptr, ptr %l1, !tbaa !29
  store ptr %t205, ptr %l140, !tbaa !29
  %t206 = load ptr, ptr %l2, !tbaa !29
  store ptr %t206, ptr %l141, !tbaa !29
  %t207 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 14
  %t208 = load i64, ptr %l18, !tbaa !24
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t207, i64 %t208)
  store i64 %t211, ptr %l144
  br label %bb59
bb58:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb62
bb59:
  %t212 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 15
  %t213 = load i64, ptr %l18, !tbaa !24
  %t216 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t212, i64 %t213)
  store i64 %t216, ptr %l147
  br label %bb60
bb60:
  %t217 = load ptr, ptr %l139, !tbaa !29
  %t218 = load ptr, ptr %l140, !tbaa !29
  %t219 = load ptr, ptr %l141, !tbaa !29
  %t220 = load i64, ptr %l144, !tbaa !24
  %t221 = load i64, ptr %l147, !tbaa !24
  %t222 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t217, ptr %t218, ptr %t219, i64 %t220, i64 %t221)
  store i1 %t222, ptr %l148
  br label %bb61
bb61:
  %t223 = load i1, ptr %l148, !tbaa !21
  %t224 = xor i1 %t223, true
  store i1 %t224, ptr %l138, !tbaa !21
  br label %bb62
bb62:
  %t226 = load i1, ptr %l138, !tbaa !21
  br i1 %t226, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t228 = load i64, ptr %l17, !tbaa !24
  %t230 = add i64 %t228, 1
  store i64 %t230, ptr %l17, !tbaa !24
  br label %bb52
bb67:
  store i64 0, ptr %l19, !tbaa !24
  %t232 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 34
  %t234 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t232)
  store i64 %t234, ptr %l154
  br label %bb68
bb68:
  %t235 = load i64, ptr %l154, !tbaa !24
  store i64 %t235, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t236 = load i64, ptr %l20, !tbaa !24
  %t237 = load i64, ptr %l19, !tbaa !24
  %t240 = icmp sgt i64 %t236, %t237
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t242 = load i64, ptr %l21, !tbaa !24
  %t244 = icmp sgt i64 %t242, 0
  br i1 %t244, label %bb71, label %bb72
bb70:
  store i64 0, ptr %l158, !tbaa !24
  br label %bb74
bb71:
  %t246 = load i64, ptr %l20, !tbaa !24
  %t247 = load i64, ptr %l19, !tbaa !24
  %t250 = sub i64 %t246, %t247
  %t251 = load i64, ptr %l21, !tbaa !24
  %t254 = add i64 %t250, %t251
  %t256 = sub i64 %t254, 1
  %t257 = load i64, ptr %l21, !tbaa !24
  %t260 = sdiv i64 %t256, %t257
  store i64 %t260, ptr %l161, !tbaa !24
  br label %bb73
bb72:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb73
bb73:
  %t262 = load i64, ptr %l161, !tbaa !24
  store i64 %t262, ptr %l158, !tbaa !24
  br label %bb74
bb74:
  %t263 = load i64, ptr %l158, !tbaa !24
  store i64 %t263, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb75
bb75:
  %t264 = load i64, ptr %l23, !tbaa !24
  %t265 = load i64, ptr %l22, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb76, label %bb77
bb76:
  br label %bb90
bb77:
  br label %bb78
bb78:
  %t272 = load i64, ptr %l19, !tbaa !24
  %t273 = load i64, ptr %l23, !tbaa !24
  %t274 = load i64, ptr %l21, !tbaa !24
  %t277 = mul i64 %t273, %t274
  %t280 = add i64 %t272, %t277
  store i64 %t280, ptr %l24, !tbaa !24
  %t282 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 34
  %t283 = load i64, ptr %l24, !tbaa !24
  %t286 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t282, i64 %t283)
  store i64 %t286, ptr %l181
  br label %bb79
bb79:
  %t287 = load i64, ptr %l6, !tbaa !24
  %t288 = load i64, ptr %l181, !tbaa !24
  %t290 = icmp eq i64 %t288, %t287
  br i1 %t290, label %bb80, label %bb81
bb80:
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l185, !tbaa !29
  %t293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t293, ptr %l186, !tbaa !29
  %t294 = load ptr, ptr %l2, !tbaa !29
  store ptr %t294, ptr %l187, !tbaa !29
  %t295 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 35
  %t296 = load i64, ptr %l24, !tbaa !24
  %t299 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t295, i64 %t296)
  store i64 %t299, ptr %l190
  br label %bb82
bb81:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb85
bb82:
  %t300 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 36
  %t301 = load i64, ptr %l24, !tbaa !24
  %t304 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t300, i64 %t301)
  store i64 %t304, ptr %l193
  br label %bb83
bb83:
  %t305 = load ptr, ptr %l185, !tbaa !29
  %t306 = load ptr, ptr %l186, !tbaa !29
  %t307 = load ptr, ptr %l187, !tbaa !29
  %t308 = load i64, ptr %l190, !tbaa !24
  %t309 = load i64, ptr %l193, !tbaa !24
  %t310 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %t305, ptr %t306, ptr %t307, i64 %t308, i64 %t309)
  store i1 %t310, ptr %l194
  br label %bb84
bb84:
  %t311 = load i1, ptr %l194, !tbaa !21
  %t312 = xor i1 %t311, true
  store i1 %t312, ptr %l184, !tbaa !21
  br label %bb85
bb85:
  %t314 = load i1, ptr %l184, !tbaa !21
  br i1 %t314, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t316 = load i64, ptr %l23, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l23, !tbaa !24
  br label %bb75
bb90:
  store i64 0, ptr %l25, !tbaa !24
  %t320 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 39
  %t322 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t320)
  store i64 %t322, ptr %l200
  br label %bb91
bb91:
  %t323 = load i64, ptr %l200, !tbaa !24
  store i64 %t323, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t324 = load i64, ptr %l26, !tbaa !24
  %t325 = load i64, ptr %l25, !tbaa !24
  %t328 = icmp sgt i64 %t324, %t325
  br i1 %t328, label %bb92, label %bb93
bb92:
  %t330 = load i64, ptr %l27, !tbaa !24
  %t332 = icmp sgt i64 %t330, 0
  br i1 %t332, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb97
bb94:
  %t334 = load i64, ptr %l26, !tbaa !24
  %t335 = load i64, ptr %l25, !tbaa !24
  %t338 = sub i64 %t334, %t335
  %t339 = load i64, ptr %l27, !tbaa !24
  %t342 = add i64 %t338, %t339
  %t344 = sub i64 %t342, 1
  %t345 = load i64, ptr %l27, !tbaa !24
  %t348 = sdiv i64 %t344, %t345
  store i64 %t348, ptr %l207, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb96
bb96:
  %t350 = load i64, ptr %l207, !tbaa !24
  store i64 %t350, ptr %l204, !tbaa !24
  br label %bb97
bb97:
  %t351 = load i64, ptr %l204, !tbaa !24
  store i64 %t351, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb98
bb98:
  %t352 = load i64, ptr %l29, !tbaa !24
  %t353 = load i64, ptr %l28, !tbaa !24
  %t356 = icmp slt i64 %t352, %t353
  %t358 = xor i1 %t356, true
  br i1 %t358, label %bb99, label %bb100
bb99:
  br label %bb116
bb100:
  br label %bb101
bb101:
  %t360 = load i64, ptr %l25, !tbaa !24
  %t361 = load i64, ptr %l29, !tbaa !24
  %t362 = load i64, ptr %l27, !tbaa !24
  %t365 = mul i64 %t361, %t362
  %t368 = add i64 %t360, %t365
  store i64 %t368, ptr %l30, !tbaa !24
  %t370 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 39
  %t371 = load i64, ptr %l30, !tbaa !24
  %t374 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t370, i64 %t371)
  store i64 %t374, ptr %l227
  br label %bb102
bb102:
  %t375 = load i64, ptr %l6, !tbaa !24
  %t376 = load i64, ptr %l227, !tbaa !24
  %t378 = icmp ne i64 %t376, %t375
  br i1 %t378, label %bb103, label %bb104
bb103:
  store i1 true, ptr %l230, !tbaa !21
  br label %bb106
bb104:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load ptr, ptr %l1, !tbaa !29
  %t382 = load ptr, ptr %l2, !tbaa !29
  %t383 = load i64, ptr %l30, !tbaa !24
  %t389 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2elinkLevel(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t380, ptr %t381, ptr %t382, ptr %l5, i64 %t383)
  store i64 %t389, ptr %l236
  br label %bb105
bb105:
  %t390 = load i64, ptr %l236, !tbaa !24
  %t391 = icmp eq i64 %t390, 0
  store i1 %t391, ptr %l230, !tbaa !21
  br label %bb106
bb106:
  %t393 = load i1, ptr %l230, !tbaa !21
  br i1 %t393, label %bb107, label %bb108
bb107:
  br label %bb115
bb108:
  br label %bb109
bb109:
  %t394 = load ptr, ptr %l0, !tbaa !29
  store ptr %t394, ptr %l238, !tbaa !29
  %t395 = load ptr, ptr %l1, !tbaa !29
  store ptr %t395, ptr %l239, !tbaa !29
  %t396 = load ptr, ptr %l2, !tbaa !29
  store ptr %t396, ptr %l240, !tbaa !29
  store ptr %l5, ptr %l241, !tbaa !29
  %t397 = getelementptr %"compiler/typed:LocalUses", ptr %l5, i32 0, i32 38
  %t398 = load i64, ptr %l30, !tbaa !24
  %t401 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t397, i64 %t398)
  store i64 %t401, ptr %l244
  br label %bb110
bb110:
  %t402 = load ptr, ptr %l238, !tbaa !29
  %t403 = load ptr, ptr %l239, !tbaa !29
  %t404 = load ptr, ptr %l240, !tbaa !29
  %t405 = load ptr, ptr %l241, !tbaa !29
  %t406 = load i64, ptr %l244, !tbaa !24
  %t407 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eescapes(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %t402, ptr %t403, ptr %t404, ptr %t405, i64 %t406, i1 true, i64 0)
  store i1 %t407, ptr %l245
  br label %bb111
bb111:
  %t408 = load i1, ptr %l245, !tbaa !21
  br i1 %t408, label %bb112, label %bb113
bb112:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb113:
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t410 = load i64, ptr %l29, !tbaa !24
  %t412 = add i64 %t410, 1
  store i64 %t412, ptr %l29, !tbaa !24
  br label %bb98
bb116:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eDefOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca i64
  %l5 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Versions", ptr %a0, i32 0, i32 8
  store ptr %t3, ptr %l5, !tbaa !29
  %t8 = call i64 @compiler_2ftyped_2edefName(i64 %a1, i64 %a2)
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t9, i64 %t10)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t16 = load i64, ptr %l9, !tbaa !24
  store i64 %t16, ptr %l3, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l22 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l89 = alloca i32
  %l92 = alloca i32
  %l93 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l22, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Alt", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t51, ptr %l37, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Bind", ptr %t57, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t59, ptr %t63)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l7, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Arm", ptr %t76, i32 0, i32 2
  %t79 = load ptr, ptr %t78, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t75, ptr %t79)
  br label %bb15
bb15:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Arm", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  br i1 %t87, label %bb16, label %bb17
bb16:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Arm", ptr %t90, i32 0, i32 4
  %t93 = load ptr, ptr %t92, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t89, ptr %t93)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %ret
bb19:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Versions", ptr %t96, i32 0, i32 16
  store ptr %t98, ptr %l58, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Arm", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_43c6edd5f3ea6aa2_25eece1f43523776)
  unreachable
bb21:
  br label %bb22
bb22:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Arm", ptr %t106, i32 0, i32 3
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Block", ptr %t109, i32 0, i32 0
  %t113 = load i32, ptr %t112, !tbaa !23
  %t114 = load ptr, ptr %l58, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t114, i32 %t113)
  br label %bb23
bb23:
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Arm", ptr %t116, i32 0, i32 3
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  br i1 %t121, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_8a2b699ea2f67509_3bce0390ecfabbdd)
  unreachable
bb25:
  br label %bb26
bb26:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Arm", ptr %t123, i32 0, i32 3
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Block", ptr %t126, i32 0, i32 1
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  store i64 %t134, ptr %l12, !tbaa !24
  br label %bb27
bb27:
  %t136 = load i64, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb28, label %bb29
bb28:
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t144 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t144, ptr %l79, !tbaa !27
  %t145 = load i64, ptr %l11, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr ptr, ptr %t148, i64 %t145
  %t150 = load ptr, ptr %t149, !tbaa !39
  %t152 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %t152, ptr %t150)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t156 = load i64, ptr %l11, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l11, !tbaa !24
  br label %bb27
bb33:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Arm", ptr %t161, i32 0, i32 4
  %t164 = load ptr, ptr %t163, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t160, ptr %t164)
  br label %bb34
bb34:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/typed:Versions", ptr %t167, i32 0, i32 16
  %t171 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t169)
  %t172 = extractvalue { i32, i32 } %t171, 1
  %t173 = extractvalue { i32, i32 } %t171, 0
  store i32 %t173, ptr %l93
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb36, label %ok.175, !prof !99
ok.175:
  store i32 %t172, ptr %l92
  br label %bb35
bb35:
  %t176 = load i32, ptr %l92, !tbaa !23
  store i32 %t176, ptr %l89, !tbaa !23
  br label %bb43
bb36:
  %t177 = load i32, ptr %l93, !tbaa !23
  %t178 = icmp eq i32 %t177, 65536
  br i1 %t178, label %bb37, label %bb38
bb37:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a872ad126d8d9744_e4960385d07a8740)
  unreachable
bb38:
  %t180 = load i32, ptr %l93, !tbaa !23
  %t181 = icmp eq i32 %t180, 65537
  br i1 %t181, label %bb39, label %bb40
bb39:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f34031efedf98c99_ae8fa248572091b5)
  unreachable
bb40:
  %t183 = load i32, ptr %l93, !tbaa !23
  %t184 = icmp eq i32 %t183, 65538
  br i1 %t184, label %bb41, label %bb42
bb41:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1baf36c5dd0b9bdd_a2c9e1d98e30c571)
  unreachable
bb42:
  call void @__olang_bang_failed_plain(ptr @olang_loc_49ff4d0dc0b12b63_5e68d9fa98bc7cb7)
  unreachable
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l12 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca { i64, ptr }
  %l39 = alloca i64
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = ptrtoint ptr %s0 to i64
  store i64 %t7, ptr %l12, !tbaa !24
  %t8 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2eclauses_2elocal_2e4
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = call ptr @__olang_region_make(ptr %s0)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l12, !tbaa !24
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l12
  %t14 = inttoptr i64 %t13 to ptr
  %t16 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %t14, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l15
  br label %bb6
bb6:
  %t17 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2eclauses_2elocal_2e4
  br i1 %t17, label %bb7, label %bb8
bb7:
  %t19 = load i64, ptr %l12
  %t20 = inttoptr i64 %t19 to ptr
  %t21 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = call ptr @__olang_region_or(ptr %t23, ptr null)
  %t25 = call ptr @__olang_region_home(ptr %t24)
  %t26 = icmp ne ptr %t25, null
  %t27 = select i1 %t26, ptr %t25, ptr null
  %t28 = icmp eq ptr %t27, %t20
  call void @__olang_region_settle(ptr %t20, i1 %t28)
  br label %bb8
bb8:
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l4
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t30, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb10, label %bb11
bb10:
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = load i64, ptr %l6, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l8, !tbaa !29
  br i1 %a3, label %bb13, label %bb14
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eall(ptr %v0, ptr %t54)
  br label %bb15
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %v2, ptr %t56, ptr %a2)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l8, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Clause", ptr %t61, i32 0, i32 3
  %t64 = load ptr, ptr %t63, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %t60, ptr %t64)
  br label %bb18
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l8, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Clause", ptr %t68, i32 0, i32 4
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %t67, { i64, ptr } %t71)
  br label %bb19
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s0, ptr %t74, ptr %l4)
  br label %bb20
bb20:
  %t77 = ptrtoint ptr %s0 to i64
  store i64 %t77, ptr %l39, !tbaa !24
  %t78 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2eclauses_2elocal_2e4
  br i1 %t78, label %bb21, label %bb22
bb21:
  %t80 = call ptr @__olang_region_make(ptr %s0)
  %t81 = ptrtoint ptr %t80 to i64
  store i64 %t81, ptr %l39, !tbaa !24
  br label %bb22
bb22:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l39
  %t84 = inttoptr i64 %t83 to ptr
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %t84, ptr %t82)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l42
  br label %bb23
bb23:
  %t87 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2eclauses_2elocal_2e4
  br i1 %t87, label %bb24, label %bb25
bb24:
  %t89 = load i64, ptr %l39
  %t90 = inttoptr i64 %t89 to ptr
  %t91 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = call ptr @__olang_region_or(ptr %t93, ptr null)
  %t95 = call ptr @__olang_region_home(ptr %t94)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, ptr %t95, ptr null
  %t98 = icmp eq ptr %t97, %t90
  call void @__olang_region_settle(ptr %t90, i1 %t98)
  br label %bb25
bb25:
  %t99 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l44
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %l4
  %t101 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2eclauses_2elocal_2e4
  br i1 %t101, label %bb26, label %bb27
bb26:
  %t103 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = call ptr @__olang_region_or(ptr %t105, ptr null)
  %t107 = call ptr @__olang_region_home(ptr %t106)
  %t108 = icmp ne ptr %t107, null
  %t109 = select i1 %t108, ptr %t107, ptr null
  call void @__olang_region_drop(ptr %t109)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l44
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t110 = load i64, ptr %l6, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l6, !tbaa !24
  br label %bb9
bb29:
  %t114 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t114, ptr %l4)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ejump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i64
  %l23 = alloca i64
  %l31 = alloca i32
  %l42 = alloca i64
  %l45 = alloca i64
  %l66 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca ptr
  %l76 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l83 = alloca ptr
  %l86 = alloca i64
  %l87 = alloca ptr
  %l93 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb4
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %t6)
  store i1 %t8, ptr %l16
  br label %bb3
bb3:
  %t9 = load i1, ptr %l16, !tbaa !21
  store i1 %t9, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t10 = load i1, ptr %l14, !tbaa !21
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %t11)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %ret
bb8:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Versions", ptr %t13, i32 0, i32 3
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l20
  br label %bb9
bb9:
  %t18 = load i64, ptr %l20, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Versions", ptr %t19, i32 0, i32 17
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l23
  br label %bb10
bb10:
  %t24 = load i64, ptr %l23, !tbaa !24
  %t25 = sub i64 %t24, 1
  store i64 %t25, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sge i64 %t27, 0
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb12, label %bb13
bb12:
  br label %bb48
bb13:
  br label %bb14
bb14:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Versions", ptr %t33, i32 0, i32 17
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t35, i64 %t36)
  store i32 %t39, ptr %l31
  br label %bb15
bb15:
  %t41 = load i32, ptr %l31, !tbaa !23
  %t43 = icmp ne i32 %t41, %a2
  br i1 %t43, label %bb16, label %bb17
bb16:
  br label %bb47
bb17:
  br label %bb18
bb18:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = add i64 %t46, 1
  %t51 = mul i64 %t45, %t48
  store i64 %t51, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l3, !tbaa !24
  store i64 %t53, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp sgt i64 %t61, 0
  br i1 %t63, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb24
bb21:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = sub i64 %t65, %t66
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = sub i64 %t73, 1
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = sdiv i64 %t75, %t76
  store i64 %t79, ptr %l45, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t81 = load i64, ptr %l45, !tbaa !24
  store i64 %t81, ptr %l42, !tbaa !24
  br label %bb24
bb24:
  %t82 = load i64, ptr %l42, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb25
bb25:
  %t83 = load i64, ptr %l10, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb26, label %bb27
bb26:
  br label %bb41
bb27:
  br label %bb28
bb28:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = mul i64 %t92, %t93
  %t99 = add i64 %t91, %t96
  store i64 %t99, ptr %l11, !tbaa !24
  %t101 = load i32, ptr %l1, !range !{i32 0, i32 2}
  %t103 = trunc i64 0 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb29, label %bb30
bb29:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Versions", ptr %t106, i32 0, i32 18
  store ptr %t108, ptr %l66, !tbaa !29
  %t109 = load i64, ptr %l5, !tbaa !24
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = add i64 %t109, %t110
  store i64 %t113, ptr %l69, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l70, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Versions", ptr %t115, i32 0, i32 18
  %t118 = load i64, ptr %l5, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t117, i64 %t122)
  store i64 %t125, ptr %l76
  br label %bb31
bb30:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Versions", ptr %t126, i32 0, i32 19
  store ptr %t128, ptr %l83, !tbaa !29
  %t129 = load i64, ptr %l5, !tbaa !24
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = add i64 %t129, %t130
  store i64 %t133, ptr %l86, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l87, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Versions", ptr %t135, i32 0, i32 19
  %t138 = load i64, ptr %l5, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = add i64 %t138, %t139
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t137, i64 %t142)
  store i64 %t145, ptr %l93
  br label %bb35
bb31:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Versions", ptr %t146, i32 0, i32 14
  %t149 = load i64, ptr %l11, !tbaa !24
  %t152 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t148, i64 %t149)
  store i64 %t152, ptr %l80
  br label %bb32
bb32:
  %t153 = load ptr, ptr %l70, !tbaa !29
  %t154 = load i64, ptr %l76, !tbaa !24
  %t155 = load i64, ptr %l80, !tbaa !24
  %t156 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t153, i64 %t154, i64 %t155)
  store i64 %t156, ptr %l81
  br label %bb33
bb33:
  %t157 = load ptr, ptr %l66, !tbaa !29
  %t158 = load i64, ptr %l69, !tbaa !24
  %t159 = load i64, ptr %l81, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t157, i64 %t158, i64 %t159)
  br label %bb34
bb34:
  br label %bb39
bb35:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Versions", ptr %t160, i32 0, i32 14
  %t163 = load i64, ptr %l11, !tbaa !24
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t162, i64 %t163)
  store i64 %t166, ptr %l97
  br label %bb36
bb36:
  %t167 = load ptr, ptr %l87, !tbaa !29
  %t168 = load i64, ptr %l93, !tbaa !24
  %t169 = load i64, ptr %l97, !tbaa !24
  %t170 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t167, i64 %t168, i64 %t169)
  store i64 %t170, ptr %l98
  br label %bb37
bb37:
  %t171 = load ptr, ptr %l83, !tbaa !29
  %t172 = load i64, ptr %l86, !tbaa !24
  %t173 = load i64, ptr %l98, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172, i64 %t173)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t174 = load i64, ptr %l10, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l10, !tbaa !24
  br label %bb25
bb41:
  %t178 = load i32, ptr %l1, !range !{i32 0, i32 2}
  %t180 = trunc i64 0 to i32
  %t181 = icmp eq i32 %t178, %t180
  br i1 %t181, label %bb42, label %bb43
bb42:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Versions", ptr %t183, i32 0, i32 18
  %t186 = load i64, ptr %l5, !tbaa !24
  %t187 = load i64, ptr %l3, !tbaa !24
  %t190 = add i64 %t186, %t187
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t185, i64 %t190, i64 0)
  br label %bb44
bb43:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Versions", ptr %t193, i32 0, i32 19
  %t196 = load i64, ptr %l5, !tbaa !24
  %t197 = load i64, ptr %l3, !tbaa !24
  %t200 = add i64 %t196, %t197
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t195, i64 %t200, i64 0)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb48
bb47:
  %t203 = load i64, ptr %l4, !tbaa !24
  %t205 = sub i64 %t203, 1
  store i64 %t205, ptr %l4, !tbaa !24
  br label %bb11
bb48:
  %t207 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %t207)
  br label %bb49
bb49:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2elater(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s0, ptr %t1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l2
  %t5 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eall(ptr %v0, ptr %t5)
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %t7, ptr %a1)
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s0, ptr %t11, ptr %l2)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l42 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Versions", ptr %t6, i32 0, i32 14
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb4
bb4:
  %t11 = load i64, ptr %l12, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb10
bb7:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l19, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb9
bb9:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l16, !tbaa !24
  br label %bb10
bb10:
  %t39 = load i64, ptr %l16, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Versions", ptr %t58, i32 0, i32 14
  store ptr %t60, ptr %l38, !tbaa !29
  %t61 = load i64, ptr %l7, !tbaa !24
  store i64 %t61, ptr %l39, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %a1, i64 %t63)
  store i64 %t66, ptr %l42
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l38, !tbaa !29
  %t68 = load i64, ptr %l39, !tbaa !24
  %t69 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t68, i64 %t69)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l6, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l6, !tbaa !24
  br label %bb11
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eSettle(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l54 = alloca i1
  %l56 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i64
  %l64 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i64
  %l96 = alloca ptr
  %l100 = alloca ptr
  %l102 = alloca i64
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 1
  %t7 = load { i64, [2 x i64] }, ptr %t6
  %t9 = extractvalue { i64, [2 x i64] } %t7, 0
  %t10 = icmp eq i64 %t9, 1
  store i1 %t10, ptr %l3, !tbaa !21
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/typed:ViewWalk", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 7
  store ptr %t17, ptr %l23, !tbaa !29
  %t18 = load ptr, ptr %l23, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v3, ptr %t18)
  %t20 = ptrtoint ptr %t19 to i64
  %t22 = inttoptr i64 %t20 to ptr
  %t23 = load ptr, ptr %l23, !tbaa !29
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %t22, ptr %t23)
  store i64 %t24, ptr %l25
  br label %bb1
bb1:
  %t25 = load i64, ptr %l25, !tbaa !24
  store i64 %t25, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb2, label %bb3
bb2:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb7
bb4:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l32, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb6
bb6:
  %t52 = load i64, ptr %l32, !tbaa !24
  store i64 %t52, ptr %l29, !tbaa !24
  br label %bb7
bb7:
  %t53 = load i64, ptr %l29, !tbaa !24
  store i64 %t53, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb9, label %bb10
bb9:
  br label %bb42
bb10:
  br label %bb11
bb11:
  %t62 = load i64, ptr %l4, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l9, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i1, ptr %l3, !tbaa !21
  %t80 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eresultLocal(ptr %v0, ptr %v1, ptr %v3, ptr %v4, ptr %t72, ptr %t73, i64 %t74, i1 %t75)
  store i1 %t80, ptr %l54
  br label %bb12
bb12:
  %t81 = load i1, ptr %l54, !tbaa !21
  %t82 = xor i1 %t81, true
  br i1 %t82, label %bb13, label %bb14
bb13:
  br label %bb41
bb14:
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l56, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/typed:LocalUses", ptr %t85, i32 0, i32 10
  %t88 = load i64, ptr %l9, !tbaa !24
  %t91 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v1, ptr %v1, ptr %t87, i64 %t88)
  store ptr %t91, ptr %l60
  br label %bb16
bb16:
  %t92 = load ptr, ptr %l56, !tbaa !29
  %t93 = load ptr, ptr %l60, !tbaa !29
  %t94 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %v4, ptr %v3, ptr %t92, ptr %t93)
  store i64 %t94, ptr %l61
  br label %bb17
bb17:
  %t95 = load i64, ptr %l61, !tbaa !24
  store i64 %t95, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/typed:LocalUses", ptr %t96, i32 0, i32 11
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t98)
  store i64 %t100, ptr %l64
  br label %bb18
bb18:
  %t101 = load i64, ptr %l64, !tbaa !24
  store i64 %t101, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t102 = load i64, ptr %l12, !tbaa !24
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = icmp sgt i64 %t102, %t103
  br i1 %t106, label %bb19, label %bb20
bb19:
  %t108 = load i64, ptr %l13, !tbaa !24
  %t110 = icmp sgt i64 %t108, 0
  br i1 %t110, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb24
bb21:
  %t112 = load i64, ptr %l12, !tbaa !24
  %t113 = load i64, ptr %l11, !tbaa !24
  %t116 = sub i64 %t112, %t113
  %t117 = load i64, ptr %l13, !tbaa !24
  %t120 = add i64 %t116, %t117
  %t122 = sub i64 %t120, 1
  %t123 = load i64, ptr %l13, !tbaa !24
  %t126 = sdiv i64 %t122, %t123
  store i64 %t126, ptr %l71, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb23
bb23:
  %t128 = load i64, ptr %l71, !tbaa !24
  store i64 %t128, ptr %l68, !tbaa !24
  br label %bb24
bb24:
  %t129 = load i64, ptr %l68, !tbaa !24
  store i64 %t129, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb25
bb25:
  %t130 = load i64, ptr %l15, !tbaa !24
  %t131 = load i64, ptr %l14, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb26, label %bb27
bb26:
  br label %bb36
bb27:
  br label %bb28
bb28:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load i64, ptr %l15, !tbaa !24
  %t140 = load i64, ptr %l13, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l16, !tbaa !24
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr %"compiler/typed:LocalUses", ptr %t148, i32 0, i32 11
  %t151 = load i64, ptr %l16, !tbaa !24
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t150, i64 %t151)
  store i64 %t154, ptr %l92
  br label %bb29
bb29:
  %t155 = load i64, ptr %l9, !tbaa !24
  %t156 = load i64, ptr %l92, !tbaa !24
  %t158 = icmp eq i64 %t156, %t155
  br i1 %t158, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t160 = load i64, ptr %l10, !tbaa !24
  store i64 %t160, ptr %l95, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l96, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr %"compiler/typed:LocalUses", ptr %t162, i32 0, i32 12
  %t165 = load i64, ptr %l16, !tbaa !24
  %t168 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %s6, ptr %t164, i64 %t165)
  store ptr %t168, ptr %l100
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t169 = load ptr, ptr %l100, !tbaa !29
  %t170 = load ptr, ptr %l96, !tbaa !29
  %t172 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %s6, ptr %v4, ptr %v3, ptr %t170, ptr %t169)
  store i64 %t172, ptr %l102
  br label %bb33
bb33:
  %t173 = load i64, ptr %l95, !tbaa !24
  %t174 = load i64, ptr %l102, !tbaa !24
  %t175 = or i64 %t173, %t174
  store i64 %t175, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t177 = load i64, ptr %l15, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l15, !tbaa !24
  br label %bb25
bb36:
  %t181 = load i64, ptr %l10, !tbaa !24
  %t183 = icmp sgt i64 %t181, 0
  br i1 %t183, label %bb37, label %bb38
bb37:
  %t186 = load i64, ptr %l9, !tbaa !24
  %t187 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v2, ptr %a2, i64 %t186, i64 %t187)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t191 = load i64, ptr %l8, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l8, !tbaa !24
  br label %bb8
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i1
  %l48 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eparamBit(ptr %v0, ptr %v2, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  br label %bb40
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = inttoptr i64 0 to ptr
  %t43 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %v2, ptr %t40, ptr %t37, ptr %t38)
  store i64 %t43, ptr %l26
  br label %bb13
bb13:
  %t44 = load i64, ptr %l26, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  br label %bb40
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Elem", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = inttoptr i64 0 to ptr
  %t69 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %v2, ptr %t66, ptr %t60, ptr %t64)
  store i64 %t69, ptr %l37
  br label %bb20
bb20:
  %t70 = load i64, ptr %l37, !tbaa !24
  store i64 %t70, ptr %l7, !tbaa !24
  br label %bb40
bb21:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t75 = load ptr, ptr %l38, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 8}
  %t78 = icmp eq i64 %t76, 5
  store i1 %t78, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t79 = load i1, ptr %l39, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l5, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Payload", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = inttoptr i64 0 to ptr
  %t95 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %v2, ptr %t92, ptr %t86, ptr %t90)
  store i64 %t95, ptr %l48
  br label %bb27
bb27:
  %t96 = load i64, ptr %l48, !tbaa !24
  store i64 %t96, ptr %l7, !tbaa !24
  br label %bb40
bb28:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t98 = load ptr, ptr %l49, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb29, label %bb30
bb29:
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 8}
  %t104 = icmp eq i64 %t102, 2
  store i1 %t104, ptr %l50, !tbaa !21
  br label %bb30
bb30:
  %t105 = load i1, ptr %l50, !tbaa !21
  br i1 %t105, label %bb31, label %bb32
bb31:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 2
  %t110 = load ptr, ptr %t109
  store ptr %t110, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t116 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t112, ptr %t113)
  store i64 %t116, ptr %l57
  br label %bb34
bb34:
  %t117 = load i64, ptr %l57, !tbaa !24
  store i64 %t117, ptr %l7, !tbaa !24
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_34c65fd26df9bfcd_2dc4d2164b9a2f69)
  unreachable
bb40:
  %t118 = load i64, ptr %l7, !tbaa !24
  store i64 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i32
  %l36 = alloca i32
  %l39 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l159 = alloca i64
  %l160 = alloca { i64, ptr }
  %l169 = alloca ptr
  %l170 = alloca i1
  %l183 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca i1
  %l201 = alloca ptr
  %l202 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i1
  %l223 = alloca { i64, ptr }
  %l226 = alloca ptr
  %l227 = alloca i1
  %l237 = alloca ptr
  %l238 = alloca i1
  %l246 = alloca ptr
  %l247 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca i1
  %l269 = alloca { i64, ptr }
  %l278 = alloca ptr
  %l279 = alloca i1
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:dropWalk", ptr %t5, i32 0, i32 3
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l39, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l39, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t12 = load ptr, ptr %l42, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l42, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 18}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l43, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l43, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t21 = load ptr, ptr %l46, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l46, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l47, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l47, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb169
bb16:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t30 = load ptr, ptr %l50, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb17, label %bb18
bb17:
  %t33 = load ptr, ptr %l50, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l51, !tbaa !21
  br label %bb18
bb18:
  %t37 = load i1, ptr %l51, !tbaa !21
  br i1 %t37, label %bb19, label %bb20
bb19:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb29
bb20:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t45 = load ptr, ptr %l56, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb21, label %bb22
bb21:
  %t48 = load ptr, ptr %l56, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 3
  store i1 %t51, ptr %l57, !tbaa !21
  br label %bb22
bb22:
  %t52 = load i1, ptr %l57, !tbaa !21
  br i1 %t52, label %bb23, label %bb24
bb23:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l2, !tbaa !29
  br label %bb29
bb24:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t60 = load ptr, ptr %l62, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb25, label %bb26
bb25:
  %t63 = load ptr, ptr %l62, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 18}
  %t66 = icmp eq i64 %t64, 4
  store i1 %t66, ptr %l63, !tbaa !21
  br label %bb26
bb26:
  %t67 = load i1, ptr %l63, !tbaa !21
  br i1 %t67, label %bb27, label %bb28
bb27:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l2, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  br label %bb30
bb30:
  br label %bb169
bb31:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t80 = load ptr, ptr %l71, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb32, label %bb33
bb32:
  %t83 = load ptr, ptr %l71, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 18}
  %t86 = icmp eq i64 %t84, 5
  store i1 %t86, ptr %l72, !tbaa !21
  br label %bb33
bb33:
  %t87 = load i1, ptr %l72, !tbaa !21
  br i1 %t87, label %bb34, label %bb35
bb34:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t90, i32 0, i32 2
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l3, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l3, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Promote", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t94, ptr %t98)
  br label %bb37
bb37:
  br label %bb169
bb38:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t103 = load ptr, ptr %l81, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb39, label %bb40
bb39:
  %t106 = load ptr, ptr %l81, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 18}
  %t109 = icmp eq i64 %t107, 6
  store i1 %t109, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t110 = load i1, ptr %l82, !tbaa !21
  br i1 %t110, label %bb41, label %bb42
bb41:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l4, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ecall(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  br label %bb44
bb44:
  br label %bb169
bb45:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t122 = load ptr, ptr %l89, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb46, label %bb47
bb46:
  %t125 = load ptr, ptr %l89, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 18}
  %t128 = icmp eq i64 %t126, 7
  store i1 %t128, ptr %l90, !tbaa !21
  br label %bb47
bb47:
  %t129 = load i1, ptr %l90, !tbaa !21
  br i1 %t129, label %bb48, label %bb49
bb48:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l5, !tbaa !29
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l5, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Make", ptr %t137, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %t136, { i64, ptr } %t140)
  br label %bb51
bb51:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l5, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Make", ptr %t144, i32 0, i32 3
  %t147 = load ptr, ptr %t146, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t143, ptr %t147)
  br label %bb52
bb52:
  br label %bb169
bb53:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t151 = load ptr, ptr %l101, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb54, label %bb55
bb54:
  %t154 = load ptr, ptr %l101, !tbaa !29
  %t155 = load i64, ptr %t154, !range !{i64 0, i64 18}
  %t157 = icmp eq i64 %t155, 8
  store i1 %t157, ptr %l102, !tbaa !21
  br label %bb55
bb55:
  %t158 = load i1, ptr %l102, !tbaa !21
  br i1 %t158, label %bb56, label %bb57
bb56:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t161, i32 0, i32 2
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l6, !tbaa !29
  br label %bb58
bb57:
  br label %bb61
bb58:
  store %olang.scope zeroinitializer, ptr %s7
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l6, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Collect", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t165, ptr %t169)
  br label %bb59
bb59:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l6, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Collect", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %s7, ptr %t172, ptr %t176, ptr null)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s7)
  br label %bb169
bb61:
  %t179 = load ptr, ptr %l1, !tbaa !29
  store ptr %t179, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t180 = load ptr, ptr %l113, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb62, label %bb63
bb62:
  %t183 = load ptr, ptr %l113, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 18}
  %t186 = icmp eq i64 %t184, 9
  store i1 %t186, ptr %l114, !tbaa !21
  br label %bb63
bb63:
  %t187 = load i1, ptr %l114, !tbaa !21
  br i1 %t187, label %bb64, label %bb65
bb64:
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t190, i32 0, i32 4
  %t192 = load { i64, ptr }, ptr %t191
  store { i64, ptr } %t192, ptr %l7, !tbaa !27
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %t194, { i64, ptr } %t195)
  br label %bb67
bb67:
  %t198 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t198, i1 false)
  br label %bb68
bb68:
  br label %bb169
bb69:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t201 = load ptr, ptr %l122, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb70, label %bb71
bb70:
  %t204 = load ptr, ptr %l122, !tbaa !29
  %t205 = load i64, ptr %t204, !range !{i64 0, i64 18}
  %t207 = icmp eq i64 %t205, 10
  store i1 %t207, ptr %l123, !tbaa !21
  br label %bb71
bb71:
  %t208 = load i1, ptr %l123, !tbaa !21
  br i1 %t208, label %bb72, label %bb73
bb72:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 2
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l8, !tbaa !29
  br label %bb74
bb73:
  br label %bb78
bb74:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l8, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Slice", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t215, ptr %t219)
  br label %bb75
bb75:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l8, !tbaa !29
  %t226 = getelementptr %"compiler/typed:Slice", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t223, ptr %t227)
  br label %bb76
bb76:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l8, !tbaa !29
  %t234 = getelementptr %"compiler/typed:Slice", ptr %t232, i32 0, i32 2
  %t235 = load ptr, ptr %t234, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t231, ptr %t235)
  br label %bb77
bb77:
  br label %bb169
bb78:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t240 = load ptr, ptr %l140, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb79, label %bb80
bb79:
  %t243 = load ptr, ptr %l140, !tbaa !29
  %t244 = load i64, ptr %t243, !range !{i64 0, i64 18}
  %t246 = icmp eq i64 %t244, 11
  store i1 %t246, ptr %l141, !tbaa !21
  br label %bb80
bb80:
  %t247 = load i1, ptr %l141, !tbaa !21
  br i1 %t247, label %bb81, label %bb82
bb81:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t250, i32 0, i32 2
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l9, !tbaa !29
  br label %bb83
bb82:
  br label %bb91
bb83:
  store %olang.scope zeroinitializer, ptr %s10
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l9, !tbaa !29
  %t257 = getelementptr %"compiler/typed:Cond", ptr %t255, i32 0, i32 0
  %t258 = load ptr, ptr %t257, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t254, ptr %t258)
  br label %bb84
bb84:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s10, ptr %t262)
  store { i64, ptr } %t264, ptr %l151
  br label %bb85
bb85:
  %t265 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  store i64 %t266, ptr %l152, !tbaa !24
  %t267 = load i64, ptr %l152, !tbaa !24
  %t268 = mul i64 %t267, 1
  %t269 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t268)
  %t270 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  store { i64, ptr } %t271, ptr %l153, !tbaa !27
  %t272 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = load i64, ptr %l152, !tbaa !24
  %t277 = mul i64 %t276, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t273, ptr %t275, i64 %t277, i1 false)
  %t278 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t278, ptr %l10, !tbaa !27
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load ptr, ptr %l9, !tbaa !29
  %t282 = getelementptr %"compiler/typed:Cond", ptr %t280, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t279, ptr %t283)
  br label %bb86
bb86:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s10, ptr %t286)
  store { i64, ptr } %t288, ptr %l158
  br label %bb87
bb87:
  %t289 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 0
  store i64 %t290, ptr %l159, !tbaa !24
  %t291 = load i64, ptr %l159, !tbaa !24
  %t292 = mul i64 %t291, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t292)
  %t294 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  store { i64, ptr } %t295, ptr %l160, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = load i64, ptr %l159, !tbaa !24
  %t301 = mul i64 %t300, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t297, ptr %t299, i64 %t301, i1 false)
  %t302 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t302, ptr %l11, !tbaa !27
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s10, ptr %t303, { i64, ptr } %t304)
  br label %bb88
bb88:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load ptr, ptr %l9, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Cond", ptr %t308, i32 0, i32 2
  %t311 = load ptr, ptr %t310, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t307, ptr %t311)
  br label %bb89
bb89:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s10, ptr %t315, { i64, ptr } %t316)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s10)
  br label %bb169
bb91:
  %t319 = load ptr, ptr %l1, !tbaa !29
  store ptr %t319, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t320 = load ptr, ptr %l169, !tbaa !29
  %t321 = icmp ne ptr %t320, null
  br i1 %t321, label %bb92, label %bb93
bb92:
  %t323 = load ptr, ptr %l169, !tbaa !29
  %t324 = load i64, ptr %t323, !range !{i64 0, i64 18}
  %t326 = icmp eq i64 %t324, 12
  store i1 %t326, ptr %l170, !tbaa !21
  br label %bb93
bb93:
  %t327 = load i1, ptr %l170, !tbaa !21
  br i1 %t327, label %bb94, label %bb95
bb94:
  %t328 = load ptr, ptr %l1, !tbaa !29
  %t330 = getelementptr { i64, [5 x i64] }, ptr %t328, i32 0, i32 1
  %t331 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t330, i32 0, i32 2
  %t332 = load ptr, ptr %t331
  store ptr %t332, ptr %l12, !tbaa !29
  br label %bb96
bb95:
  br label %bb105
bb96:
  %t334 = load ptr, ptr %l12, !tbaa !29
  %t336 = getelementptr %"compiler/typed:Seq", ptr %t334, i32 0, i32 0
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t339 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t339, 0
  store i64 %t341, ptr %l15, !tbaa !24
  br label %bb97
bb97:
  %t343 = load i64, ptr %l14, !tbaa !24
  %t344 = load i64, ptr %l15, !tbaa !24
  %t347 = icmp slt i64 %t343, %t344
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb98, label %bb99
bb98:
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t351 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t351, ptr %l183, !tbaa !27
  %t352 = load i64, ptr %l14, !tbaa !24
  %t354 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !27
  %t356 = getelementptr ptr, ptr %t355, i64 %t352
  %t357 = load ptr, ptr %t356, !tbaa !39
  %t359 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %t359, ptr %t357)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t363 = load i64, ptr %l14, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l14, !tbaa !24
  br label %bb97
bb103:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l12, !tbaa !29
  %t370 = getelementptr %"compiler/typed:Seq", ptr %t368, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t367, ptr %t371)
  br label %bb104
bb104:
  br label %bb169
bb105:
  %t374 = load ptr, ptr %l1, !tbaa !29
  store ptr %t374, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t375 = load ptr, ptr %l193, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb106, label %bb107
bb106:
  %t378 = load ptr, ptr %l193, !tbaa !29
  %t379 = load i64, ptr %t378, !range !{i64 0, i64 18}
  %t381 = icmp eq i64 %t379, 13
  store i1 %t381, ptr %l194, !tbaa !21
  br label %bb107
bb107:
  %t382 = load i1, ptr %l194, !tbaa !21
  br i1 %t382, label %bb108, label %bb109
bb108:
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = getelementptr { i64, [5 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t385, i32 0, i32 2
  %t387 = load ptr, ptr %t386
  store ptr %t387, ptr %l17, !tbaa !29
  br label %bb110
bb109:
  br label %bb112
bb110:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ematch(ptr %v0, ptr %v1, ptr %t389, ptr %t390)
  br label %bb111
bb111:
  br label %bb169
bb112:
  %t393 = load ptr, ptr %l1, !tbaa !29
  store ptr %t393, ptr %l201, !tbaa !29
  store i1 false, ptr %l202, !tbaa !21
  %t394 = load ptr, ptr %l201, !tbaa !29
  %t395 = icmp ne ptr %t394, null
  br i1 %t395, label %bb113, label %bb114
bb113:
  %t397 = load ptr, ptr %l201, !tbaa !29
  %t398 = load i64, ptr %t397, !range !{i64 0, i64 18}
  %t400 = icmp eq i64 %t398, 14
  store i1 %t400, ptr %l202, !tbaa !21
  br label %bb114
bb114:
  %t401 = load i1, ptr %l202, !tbaa !21
  br i1 %t401, label %bb115, label %bb116
bb115:
  %t402 = load ptr, ptr %l1, !tbaa !29
  %t404 = getelementptr { i64, [5 x i64] }, ptr %t402, i32 0, i32 1
  %t405 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t404, i32 0, i32 2
  %t406 = load ptr, ptr %t405
  store ptr %t406, ptr %l18, !tbaa !29
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2etry(ptr %v0, ptr %v1, ptr %t408, ptr %t409)
  br label %bb118
bb118:
  br label %bb169
bb119:
  %t412 = load ptr, ptr %l1, !tbaa !29
  store ptr %t412, ptr %l209, !tbaa !29
  store i1 false, ptr %l210, !tbaa !21
  %t413 = load ptr, ptr %l209, !tbaa !29
  %t414 = icmp ne ptr %t413, null
  br i1 %t414, label %bb120, label %bb121
bb120:
  %t416 = load ptr, ptr %l209, !tbaa !29
  %t417 = load i64, ptr %t416, !range !{i64 0, i64 18}
  %t419 = icmp eq i64 %t417, 16
  store i1 %t419, ptr %l210, !tbaa !21
  br label %bb121
bb121:
  %t420 = load i1, ptr %l210, !tbaa !21
  br i1 %t420, label %bb122, label %bb123
bb122:
  %t421 = load ptr, ptr %l1, !tbaa !29
  %t423 = getelementptr { i64, [5 x i64] }, ptr %t421, i32 0, i32 1
  %t424 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t423, i32 0, i32 2
  %t425 = load ptr, ptr %t424
  store ptr %t425, ptr %l19, !tbaa !29
  br label %bb124
bb123:
  br label %bb137
bb124:
  %t427 = load ptr, ptr %l19, !tbaa !29
  %t429 = getelementptr %"compiler/typed:Text", ptr %t427, i32 0, i32 0
  %t430 = load { i64, ptr }, ptr %t429, !tbaa !27
  store { i64, ptr } %t430, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t432 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t432, 0
  store i64 %t434, ptr %l22, !tbaa !24
  br label %bb125
bb125:
  %t436 = load i64, ptr %l21, !tbaa !24
  %t437 = load i64, ptr %l22, !tbaa !24
  %t440 = icmp slt i64 %t436, %t437
  %t442 = xor i1 %t440, true
  br i1 %t442, label %bb126, label %bb127
bb126:
  br label %bb136
bb127:
  br label %bb128
bb128:
  %t444 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t444, ptr %l223, !tbaa !27
  %t445 = load i64, ptr %l21, !tbaa !24
  %t447 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr ptr, ptr %t448, i64 %t445
  %t450 = load ptr, ptr %t449, !tbaa !39
  store ptr %t450, ptr %l23, !tbaa !29
  %t452 = load ptr, ptr %l23, !tbaa !29
  store ptr %t452, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t453 = load ptr, ptr %l226, !tbaa !29
  %t454 = icmp ne ptr %t453, null
  br i1 %t454, label %bb129, label %bb130
bb129:
  %t456 = load ptr, ptr %l226, !tbaa !29
  %t457 = load i64, ptr %t456, !range !{i64 0, i64 2}
  %t459 = icmp eq i64 %t457, 1
  store i1 %t459, ptr %l227, !tbaa !21
  br label %bb130
bb130:
  %t460 = load i1, ptr %l227, !tbaa !21
  br i1 %t460, label %bb131, label %bb132
bb131:
  %t461 = load ptr, ptr %l23, !tbaa !29
  %t463 = getelementptr { i64, [2 x i64] }, ptr %t461, i32 0, i32 1
  %t464 = getelementptr { ptr }, ptr %t463, i32 0, i32 0
  %t465 = load ptr, ptr %t464
  %t467 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t467, ptr %t465)
  br label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t472 = load i64, ptr %l21, !tbaa !24
  %t474 = add i64 %t472, 1
  store i64 %t474, ptr %l21, !tbaa !24
  br label %bb125
bb136:
  br label %bb169
bb137:
  %t476 = load ptr, ptr %l1, !tbaa !29
  store ptr %t476, ptr %l237, !tbaa !29
  store i1 false, ptr %l238, !tbaa !21
  %t477 = load ptr, ptr %l237, !tbaa !29
  %t478 = icmp ne ptr %t477, null
  br i1 %t478, label %bb138, label %bb139
bb138:
  %t480 = load ptr, ptr %l237, !tbaa !29
  %t481 = load i64, ptr %t480, !range !{i64 0, i64 18}
  %t483 = icmp eq i64 %t481, 17
  store i1 %t483, ptr %l238, !tbaa !21
  br label %bb139
bb139:
  %t484 = load i1, ptr %l238, !tbaa !21
  br i1 %t484, label %bb140, label %bb141
bb140:
  %t485 = load ptr, ptr %l1, !tbaa !29
  %t487 = getelementptr { i64, [5 x i64] }, ptr %t485, i32 0, i32 1
  %t488 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t487, i32 0, i32 2
  %t489 = load ptr, ptr %t488
  store ptr %t489, ptr %l25, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t491, ptr %t492)
  br label %bb143
bb143:
  br label %bb169
bb144:
  %t496 = load ptr, ptr %l1, !tbaa !29
  store ptr %t496, ptr %l246, !tbaa !29
  store i1 false, ptr %l247, !tbaa !21
  %t497 = load ptr, ptr %l246, !tbaa !29
  %t498 = icmp ne ptr %t497, null
  br i1 %t498, label %bb145, label %bb146
bb145:
  %t500 = load ptr, ptr %l246, !tbaa !29
  %t501 = load i64, ptr %t500, !range !{i64 0, i64 18}
  %t503 = icmp eq i64 %t501, 15
  store i1 %t503, ptr %l247, !tbaa !21
  br label %bb146
bb146:
  %t504 = load i1, ptr %l247, !tbaa !21
  br i1 %t504, label %bb147, label %bb148
bb147:
  %t505 = load ptr, ptr %l1, !tbaa !29
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t507, i32 0, i32 2
  %t509 = load ptr, ptr %t508
  store ptr %t509, ptr %l26, !tbaa !29
  br label %bb149
bb148:
  br label %bb168
bb149:
  %t511 = load ptr, ptr %l26, !tbaa !29
  store ptr %t511, ptr %l252, !tbaa !29
  store i1 false, ptr %l253, !tbaa !21
  %t512 = load ptr, ptr %l252, !tbaa !29
  %t513 = icmp ne ptr %t512, null
  br i1 %t513, label %bb150, label %bb151
bb150:
  %t515 = load ptr, ptr %l252, !tbaa !29
  %t516 = load i64, ptr %t515, !range !{i64 0, i64 3}
  %t518 = icmp eq i64 %t516, 1
  store i1 %t518, ptr %l253, !tbaa !21
  br label %bb151
bb151:
  %t519 = load i1, ptr %l253, !tbaa !21
  br i1 %t519, label %bb152, label %bb153
bb152:
  %t520 = load ptr, ptr %l26, !tbaa !29
  %t522 = getelementptr { i64, [4 x i64] }, ptr %t520, i32 0, i32 1
  %t523 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t522, i32 0, i32 0
  %t524 = load i32, ptr %t523
  store i32 %t524, ptr %l27, !tbaa !23
  %t526 = load ptr, ptr %l26, !tbaa !29
  %t528 = getelementptr { i64, [4 x i64] }, ptr %t526, i32 0, i32 1
  %t529 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t528, i32 0, i32 1
  %t530 = load { i64, ptr }, ptr %t529
  %t532 = load ptr, ptr %l26, !tbaa !29
  %t534 = getelementptr { i64, [4 x i64] }, ptr %t532, i32 0, i32 1
  %t535 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t534, i32 0, i32 2
  %t536 = load i32, ptr %t535
  store i32 %t536, ptr %l29, !tbaa !23
  store { i64, ptr } %t530, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t540 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t540, 0
  store i64 %t542, ptr %l32, !tbaa !24
  br label %bb154
bb153:
  br label %bb161
bb154:
  %t544 = load i64, ptr %l31, !tbaa !24
  %t545 = load i64, ptr %l32, !tbaa !24
  %t548 = icmp slt i64 %t544, %t545
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb155, label %bb156
bb155:
  br label %bb160
bb156:
  br label %bb157
bb157:
  %t552 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t552, ptr %l269, !tbaa !27
  %t553 = load i64, ptr %l31, !tbaa !24
  %t555 = getelementptr { i64, ptr }, ptr %l269, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr ptr, ptr %t556, i64 %t553
  %t558 = load ptr, ptr %t557, !tbaa !39
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t563 = getelementptr %"compiler/typed:Capture", ptr %t558, i32 0, i32 1
  %t564 = load ptr, ptr %t563, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t560, ptr %t564)
  br label %bb158
bb158:
  br label %bb159
bb159:
  %t568 = load i64, ptr %l31, !tbaa !24
  %t570 = add i64 %t568, 1
  store i64 %t570, ptr %l31, !tbaa !24
  br label %bb154
bb160:
  br label %bb161
bb161:
  %t572 = load ptr, ptr %l26, !tbaa !29
  store ptr %t572, ptr %l278, !tbaa !29
  store i1 false, ptr %l279, !tbaa !21
  %t573 = load ptr, ptr %l278, !tbaa !29
  %t574 = icmp ne ptr %t573, null
  br i1 %t574, label %bb162, label %bb163
bb162:
  %t576 = load ptr, ptr %l278, !tbaa !29
  %t577 = load i64, ptr %t576, !range !{i64 0, i64 3}
  %t579 = icmp eq i64 %t577, 2
  store i1 %t579, ptr %l279, !tbaa !21
  br label %bb163
bb163:
  %t580 = load i1, ptr %l279, !tbaa !21
  br i1 %t580, label %bb164, label %bb165
bb164:
  %t581 = load ptr, ptr %l26, !tbaa !29
  %t583 = getelementptr { i64, [4 x i64] }, ptr %t581, i32 0, i32 1
  %t584 = getelementptr { i32, ptr, i32 }, ptr %t583, i32 0, i32 0
  %t585 = load i32, ptr %t584
  store i32 %t585, ptr %l34, !tbaa !23
  %t587 = load ptr, ptr %l26, !tbaa !29
  %t589 = getelementptr { i64, [4 x i64] }, ptr %t587, i32 0, i32 1
  %t590 = getelementptr { i32, ptr, i32 }, ptr %t589, i32 0, i32 1
  %t591 = load ptr, ptr %t590
  %t593 = load ptr, ptr %l26, !tbaa !29
  %t595 = getelementptr { i64, [4 x i64] }, ptr %t593, i32 0, i32 1
  %t596 = getelementptr { i32, ptr, i32 }, ptr %t595, i32 0, i32 2
  %t597 = load i32, ptr %t596
  store i32 %t597, ptr %l36, !tbaa !23
  %t599 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t599, ptr %t591)
  br label %bb166
bb165:
  br label %bb167
bb166:
  br label %bb167
bb167:
  br label %bb169
bb168:
  call void @__olang_check_failed(ptr @olang_loc_e0d071190e38de5d_291e4ea72946f179)
  unreachable
bb169:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb52
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l22, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t31 = load ptr, ptr %l25, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l25, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 17}
  %t37 = icmp eq i64 %t35, 12
  store i1 %t37, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l26, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l31, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t50 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eflagOf(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  store i64 %t50, ptr %l34
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l31, !tbaa !29
  %t52 = load i64, ptr %l34, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2enumber(ptr %v0, ptr %t51, i64 %t52)
  br label %bb14
bb14:
  br label %bb50
bb15:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 17}
  %t60 = icmp eq i64 %t58, 11
  store i1 %t60, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l7, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb21
bb21:
  br label %bb50
bb22:
  %t73 = load ptr, ptr %l5, !tbaa !29
  store ptr %t73, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t74 = load ptr, ptr %l44, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb23, label %bb24
bb23:
  %t77 = load ptr, ptr %l44, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 17}
  %t80 = icmp eq i64 %t78, 3
  store i1 %t80, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr { i64, [3 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", ptr }, ptr %t84, i32 0, i32 1
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = getelementptr %"compiler/typed:If", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t88, ptr %t92)
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l8, !tbaa !29
  %t99 = getelementptr %"compiler/typed:If", ptr %t97, i32 0, i32 2
  %t100 = load ptr, ptr %t99, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t96, ptr %t100)
  br label %bb29
bb29:
  br label %bb50
bb30:
  %t103 = load ptr, ptr %l5, !tbaa !29
  store ptr %t103, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t104 = load ptr, ptr %l57, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb31, label %bb32
bb31:
  %t107 = load ptr, ptr %l57, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 17}
  %t110 = icmp eq i64 %t108, 4
  store i1 %t110, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  %t111 = load i1, ptr %l58, !tbaa !21
  br i1 %t111, label %bb33, label %bb34
bb33:
  %t112 = load ptr, ptr %l5, !tbaa !29
  %t114 = getelementptr { i64, [3 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l9, !tbaa !29
  %t118 = load ptr, ptr %l5, !tbaa !29
  %t120 = getelementptr { i64, [3 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l10, !tbaa !29
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb36
bb36:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t129, ptr %t130)
  br label %bb37
bb37:
  br label %bb50
bb38:
  %t133 = load ptr, ptr %l5, !tbaa !29
  store ptr %t133, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t134 = load ptr, ptr %l70, !tbaa !29
  %t135 = icmp ne ptr %t134, null
  br i1 %t135, label %bb39, label %bb40
bb39:
  %t137 = load ptr, ptr %l70, !tbaa !29
  %t138 = load i64, ptr %t137, !range !{i64 0, i64 17}
  %t140 = icmp eq i64 %t138, 13
  store i1 %t140, ptr %l71, !tbaa !21
  br label %bb40
bb40:
  %t141 = load i1, ptr %l71, !tbaa !21
  br i1 %t141, label %bb41, label %bb42
bb41:
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t144 = getelementptr { i64, [3 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", ptr }, ptr %t144, i32 0, i32 1
  %t146 = load ptr, ptr %t145
  store ptr %t146, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l11, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Join", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efind(ptr %v0, ptr %v1, ptr %t148, ptr %t152)
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_9f9fe097503cda9_c6b719cc2534ac35)
  unreachable
bb50:
  br label %bb51
bb51:
  %t156 = load i64, ptr %l3, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l3, !tbaa !24
  br label %bb4
bb52:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eflagOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i64 @compiler_2ftyped_2eDropFlag(ptr %v0, ptr %v1, ptr %t4, ptr %a1)
  store i64 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i64
  %l48 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i32
  %l55 = alloca i1
  %l57 = alloca ptr
  %l61 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:dropWalk", ptr %t6, i32 0, i32 5
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb4
bb4:
  %t11 = load i64, ptr %l12, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb10
bb7:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l19, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb9
bb9:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l16, !tbaa !24
  br label %bb10
bb10:
  %t39 = load i64, ptr %l16, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  br label %bb31
bb13:
  br label %bb14
bb14:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:dropWalk", ptr %t58, i32 0, i32 6
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l40
  br label %bb15
bb15:
  %t66 = load i64, ptr %l40, !tbaa !24
  %t68 = icmp sgt i64 %t66, %a1
  br i1 %t68, label %bb16, label %bb17
bb16:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:dropWalk", ptr %t70, i32 0, i32 2
  store ptr %t72, ptr %l45, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/typed:dropWalk", ptr %t73, i32 0, i32 1
  store ptr %t75, ptr %l48, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/typed:dropWalk", ptr %t76, i32 0, i32 5
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t78, i64 %t79)
  store i64 %t82, ptr %l52
  br label %bb18
bb17:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb24
bb18:
  %t83 = load ptr, ptr %l48, !tbaa !29
  %t84 = load i64, ptr %l52, !tbaa !24
  %t85 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t83, i64 %t84)
  %t86 = extractvalue { i32, i64 } %t85, 1
  %t87 = extractvalue { i32, i64 } %t85, 0
  store i32 %t87, ptr %l54
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb20, label %ok.89, !prof !99
ok.89:
  store i64 %t86, ptr %l53
  br label %bb19
bb19:
  %t90 = load i64, ptr %l53, !tbaa !24
  store i64 %t90, ptr %l46, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb22
bb22:
  %t91 = load ptr, ptr %l45, !tbaa !29
  %t92 = load i64, ptr %l46, !tbaa !24
  %t93 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t91, i64 %t92)
  store i1 %t93, ptr %l55
  br label %bb23
bb23:
  %t94 = load i1, ptr %l55, !tbaa !21
  store i1 %t94, ptr %l43, !tbaa !21
  br label %bb24
bb24:
  %t95 = load i1, ptr %l43, !tbaa !21
  br i1 %t95, label %bb25, label %bb26
bb25:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/typed:dropWalk", ptr %t96, i32 0, i32 14
  store ptr %t98, ptr %l57, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/typed:dropWalk", ptr %t99, i32 0, i32 5
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t101, i64 %t102)
  store i64 %t105, ptr %l61
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t106 = load ptr, ptr %l57, !tbaa !29
  %t107 = load i64, ptr %l61, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t106, i64 %t107, i1 true)
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l6, !tbaa !24
  br label %bb11
bb31:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloopState(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l48 = alloca i1
  %l54 = alloca i1
  %l60 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l10, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:dropWalk", ptr %t2, i32 0, i32 2
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load i64, ptr %l13, !tbaa !24
  %t8 = add i64 %t7, 1
  %t9 = load i64, ptr %l10, !tbaa !24
  %t11 = mul i64 %t9, %t8
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:dropWalk", ptr %t13, i32 0, i32 2
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l18
  br label %bb2
bb2:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = add i64 %t18, 1
  store i64 %t19, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l23, !tbaa !24
  store i64 %t48, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  br label %bb9
bb9:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l9, !tbaa !24
  br i1 %a1, label %bb13, label %bb14
bb13:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/typed:dropWalk", ptr %t75, i32 0, i32 9
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t85 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t77, i64 %t82)
  store i1 %t85, ptr %l54
  br label %bb15
bb14:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/typed:dropWalk", ptr %t86, i32 0, i32 10
  %t89 = load i64, ptr %l3, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t89, %t90
  %t96 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t88, i64 %t93)
  store i1 %t96, ptr %l60
  br label %bb16
bb15:
  %t97 = load i1, ptr %l54, !tbaa !21
  store i1 %t97, ptr %l48, !tbaa !21
  br label %bb17
bb16:
  %t98 = load i1, ptr %l60, !tbaa !21
  store i1 %t98, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t99 = load i1, ptr %l48, !tbaa !21
  %t100 = load i64, ptr %l37, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i1, ptr %t102, i64 %t100
  store i1 %t99, ptr %t103, !tbaa !31
  %t104 = load i64, ptr %l37, !tbaa !24
  %t105 = add i64 %t104, 1
  store i64 %t105, ptr %l37, !tbaa !24
  br label %bb18
bb18:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  %t110 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t110, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb9
bb9:
  br label %bb44
bb10:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 8}
  %t32 = icmp eq i64 %t30, 3
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t40, ptr %t41)
  br label %bb16
bb16:
  br label %bb44
bb17:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb18, label %bb19
bb18:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb20, label %bb21
bb20:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Elem", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t60, ptr %t64)
  br label %bb23
bb23:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Elem", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t68, ptr %t72)
  br label %bb24
bb24:
  br label %bb44
bb25:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t80 = load ptr, ptr %l41, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 5
  store i1 %t83, ptr %l42, !tbaa !21
  br label %bb27
bb27:
  %t84 = load i1, ptr %l42, !tbaa !21
  br i1 %t84, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l5, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Payload", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t91, ptr %t95)
  br label %bb31
bb31:
  br label %bb44
bb32:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 8}
  %t106 = icmp eq i64 %t104, 6
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb34
bb34:
  %t107 = load i1, ptr %l52, !tbaa !21
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [4 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t114, ptr %t115)
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_c533040496e87321_52fb908a3762307d)
  unreachable
bb44:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esetLocal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 1
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l12
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l11
  br label %bb1
bb1:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  br label %ret
bb4:
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:dropWalk", ptr %t14, i32 0, i32 2
  store ptr %t16, ptr %l14, !tbaa !29
  store i64 %t13, ptr %l15, !tbaa !24
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l20, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t36, i32 0, i32 0
  %t38 = load %"compiler/source:Span", ptr %t37
  store %"compiler/source:Span" %t38, ptr %l4
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l5, !tbaa !23
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t48, i32 0, i32 2
  %t50 = load i64, ptr %t49
  %t54 = icmp eq i64 %t50, 0
  store i1 %t54, ptr %l24, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l24, !tbaa !21
  %t57 = xor i1 %t56, true
  %t58 = load ptr, ptr %l14, !tbaa !29
  %t59 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t58, i64 %t59, i1 %t57)
  br label %bb13
bb13:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ewiden(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l21 = alloca i64
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca i1
  %l69 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l12, !tbaa !27
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:dropWalk", ptr %t8, i32 0, i32 2
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l15
  br label %bb4
bb4:
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i1, ptr %t15, i64 %t13
  %t17 = load i1, ptr %t16, !tbaa !31
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i64 1, ptr %l17, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t19 = load i64, ptr %l17, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l18, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/typed:dropWalk", ptr %t21, i32 0, i32 2
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l21
  br label %bb8
bb8:
  %t26 = load i64, ptr %l21, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i1, ptr %t28, i64 %t26
  store i1 false, ptr %t29, !tbaa !31
  store i64 0, ptr %l3, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:dropWalk", ptr %t30, i32 0, i32 2
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l24
  br label %bb9
bb9:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = icmp sgt i64 %t36, %t37
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb15
bb12:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = sub i64 %t46, %t47
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t50, %t51
  %t56 = sub i64 %t54, 1
  %t57 = load i64, ptr %l5, !tbaa !24
  %t60 = sdiv i64 %t56, %t57
  store i64 %t60, ptr %l31, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb14
bb14:
  %t62 = load i64, ptr %l31, !tbaa !24
  store i64 %t62, ptr %l28, !tbaa !24
  br label %bb15
bb15:
  %t63 = load i64, ptr %l28, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb16
bb16:
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb32
bb18:
  br label %bb19
bb19:
  %t72 = load i64, ptr %l3, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = mul i64 %t73, %t74
  %t80 = add i64 %t72, %t77
  store i64 %t80, ptr %l8, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/typed:dropWalk", ptr %t82, i32 0, i32 2
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t84, i64 %t85)
  store i1 %t88, ptr %l52
  br label %bb20
bb20:
  %t89 = load i1, ptr %l52, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t90 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t90, ptr %l54, !tbaa !27
  %t91 = load i64, ptr %l8, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i1, ptr %t94, i64 %t91
  %t96 = load i1, ptr %t95, !tbaa !31
  %t98 = xor i1 %t96, true
  store i1 %t98, ptr %l53, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t100 = load i1, ptr %l53, !tbaa !21
  br i1 %t100, label %bb24, label %bb25
bb24:
  %t101 = load i64, ptr %l2, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l2, !tbaa !24
  br label %bb26
bb25:
  br label %bb26
bb26:
  %t105 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t105, ptr %l60, !tbaa !27
  %t106 = load i64, ptr %l8, !tbaa !24
  store i64 %t106, ptr %l61, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t107, ptr %l62, !tbaa !27
  %t108 = load i64, ptr %l8, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i1, ptr %t111, i64 %t108
  %t113 = load i1, ptr %t112, !tbaa !31
  br i1 %t113, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb30
bb28:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/typed:dropWalk", ptr %t115, i32 0, i32 2
  %t118 = load i64, ptr %l8, !tbaa !24
  %t121 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t117, i64 %t118)
  store i1 %t121, ptr %l69
  br label %bb29
bb29:
  %t122 = load i1, ptr %l69, !tbaa !21
  store i1 %t122, ptr %l65, !tbaa !21
  br label %bb30
bb30:
  %t123 = load i1, ptr %l65, !tbaa !21
  %t124 = load i64, ptr %l61, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i1, ptr %t126, i64 %t124
  store i1 %t123, ptr %t127, !tbaa !31
  br label %bb31
bb31:
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l7, !tbaa !24
  br label %bb16
bb32:
  %t132 = load i64, ptr %l2, !tbaa !24
  store i64 %t132, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eadd(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l6 = alloca i1
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i1
  %l19 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:holdWalk", ptr %t7, i32 0, i32 2
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t9, i64 %t10)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l10
  br label %bb3
bb3:
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l10)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l12
  br label %bb4
bb4:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %l12, i64 %t16)
  store i1 %t19, ptr %l15
  br label %bb5
bb5:
  %t20 = load i1, ptr %l15, !tbaa !21
  store i1 %t20, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l6, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:holdWalk", ptr %t22, i32 0, i32 2
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store ptr %t28, ptr %l19
  br label %bb10
bb10:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t30 = load ptr, ptr %l19, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t30, i64 %t29)
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/typed:holdWalk", ptr %t32, i32 0, i32 3
  store i1 true, ptr %t34, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2efnVal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca ptr
  %l18 = alloca i1
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca { i64, ptr }
  %l40 = alloca i64
  %l42 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca i1
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = ptrtoint ptr %v2 to i64
  store i64 %t1, ptr %l13, !tbaa !24
  %t2 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aholdWalk__2efnVal_2elocal_2e2
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = call ptr @__olang_region_make(ptr %v2)
  %t5 = ptrtoint ptr %t4 to i64
  store i64 %t5, ptr %l13, !tbaa !24
  br label %bb2
bb2:
  %t6 = load i64, ptr %l13
  %t7 = inttoptr i64 %t6 to ptr
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t7, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l15
  br label %bb3
bb3:
  %t9 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aholdWalk__2efnVal_2elocal_2e2
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l13
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = call ptr @__olang_region_or(ptr %t15, ptr null)
  %t17 = call ptr @__olang_region_home(ptr %t16)
  %t18 = icmp ne ptr %t17, null
  %t19 = select i1 %t18, ptr %t17, ptr null
  %t20 = icmp eq ptr %t19, %t12
  call void @__olang_region_settle(ptr %t12, i1 %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l2
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 3}
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34
  store { i64, ptr } %t35, ptr %l3, !tbaa !27
  br label %bb10
bb9:
  br label %bb31
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l23
  br label %bb11
bb11:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l4
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t39, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb13, label %bb14
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t53 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t53, ptr %l31, !tbaa !27
  %t54 = load i64, ptr %l6, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr ptr, ptr %t57, i64 %t54
  %t59 = load ptr, ptr %t58, !tbaa !39
  %t63 = getelementptr %"compiler/typed:Capture", ptr %t59, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s1, ptr %v1, ptr %l4, ptr %t64)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t67 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l6, !tbaa !24
  br label %bb12
bb18:
  store ptr %l4, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t72 = load i64, ptr %l10, !tbaa !24
  store i64 %t72, ptr %l40, !tbaa !24
  %t73 = load ptr, ptr %l9, !tbaa !29
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s1, ptr %t73)
  store i64 %t75, ptr %l42
  br label %bb20
bb20:
  %t76 = load i64, ptr %l40, !tbaa !24
  %t77 = load i64, ptr %l42, !tbaa !24
  %t78 = icmp slt i64 %t76, %t77
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb22:
  br label %bb23
bb23:
  %t82 = load ptr, ptr %l9, !tbaa !29
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s1, ptr %s1, ptr %t82, i64 %t83)
  store ptr %t86, ptr %l47
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l47, !tbaa !29
  store ptr %l2, ptr %l48, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t93 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %s1, ptr %v0, ptr %v3, ptr %v4, ptr %t88, ptr %t87)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l52
  br label %bb25
bb25:
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  %t95 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %t95
  %t96 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t96, ptr %t95)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb27:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l10, !tbaa !24
  br label %bb19
bb28:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l56, !tbaa !29
  %t104 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %s1, ptr %s1, ptr %l4)
  store { i64, ptr } %t104, ptr %l58
  br label %bb29
bb29:
  %t105 = load ptr, ptr %l56, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l58, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2emix(ptr %v0, ptr %s1, ptr %v3, ptr %v4, ptr %t105, { i64, ptr } %t106)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s1)
  br label %bb45
bb31:
  %t107 = load ptr, ptr %l1, !tbaa !29
  store ptr %t107, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t108 = load ptr, ptr %l59, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb32, label %bb33
bb32:
  %t111 = load ptr, ptr %l59, !tbaa !29
  %t112 = load i64, ptr %t111, !range !{i64 0, i64 3}
  %t114 = icmp eq i64 %t112, 2
  store i1 %t114, ptr %l60, !tbaa !21
  br label %bb33
bb33:
  %t115 = load i1, ptr %l60, !tbaa !21
  br i1 %t115, label %bb34, label %bb35
bb34:
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { i32, ptr, i32 }, ptr %t118, i32 0, i32 1
  %t120 = load ptr, ptr %t119
  store ptr %t120, ptr %l12, !tbaa !29
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l12, !tbaa !29
  %t127 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t122, ptr %t123)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %l68
  br label %bb37
bb37:
  %t128 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %l69
  %t129 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t129, ptr %l2
  %t130 = load i1, ptr @olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aholdWalk__2efnVal_2elocal_2e2
  br i1 %t130, label %bb38, label %bb39
bb38:
  %t132 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = call ptr @__olang_region_or(ptr %t134, ptr null)
  %t136 = call ptr @__olang_region_home(ptr %t135)
  %t137 = icmp ne ptr %t136, null
  %t138 = select i1 %t137, ptr %t136, ptr null
  call void @__olang_region_drop(ptr %t138)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l69
  br label %bb39
bb39:
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_3d59d966d65a5e81_dc9cdefe852f3965)
  unreachable
bb45:
  %t139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheld(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t30, i32 0, i32 3
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l5, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t38 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %t34, ptr %t35)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %rv
  br label %ret
bb6:
  %t40 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l25
  br label %bb7
bb7:
  %t41 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l6
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %s2, ptr %v3, ptr %v4, ptr %t42, ptr %t43)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l28
  br label %bb8
bb8:
  %t47 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  %t48 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %t48
  store ptr %t48, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load i64, ptr %l8, !tbaa !24
  store i64 %t50, ptr %l30, !tbaa !24
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t51)
  store i64 %t53, ptr %l32
  br label %bb10
bb10:
  %t54 = load i64, ptr %l30, !tbaa !24
  %t55 = load i64, ptr %l32, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l7, !tbaa !29
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l37
  br label %bb14
bb14:
  %t65 = load i64, ptr %l37, !tbaa !24
  store ptr %l6, ptr %l38, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/typed:holdWalk", ptr %t66, i32 0, i32 2
  %t72 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t68, i64 %t65)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l42
  br label %bb15
bb15:
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s3, ptr %l42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l44
  br label %bb16
bb16:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  %t76 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %t76
  %t77 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t77, ptr %t76)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l8, !tbaa !24
  br label %bb9
bb19:
  call void @__olang_scope_close(ptr %s2)
  %t83 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregisteredBefore(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i64
  %l56 = alloca i64
  %l60 = alloca i32
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i1
  %l103 = alloca i64
  %l106 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i32
  %l112 = alloca i32
  %l113 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  store i32 -1, ptr %l4, !tbaa !23
  store i64 0, ptr %l5, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:holdWalk", ptr %t1, i32 0, i32 11
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l7, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l7, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l7, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l26, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l23, !tbaa !24
  store i64 %t34, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l8, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l10, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:holdWalk", ptr %t53, i32 0, i32 11
  %t56 = load i64, ptr %l10, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l47
  br label %bb12
bb12:
  %t61 = load i64, ptr %l47, !tbaa !24
  %t63 = icmp ne i64 %t61, %a1
  br i1 %t63, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t67 = icmp sge i64 %t65, 0
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/typed:holdWalk", ptr %t70, i32 0, i32 10
  %t73 = load i64, ptr %l10, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t72, i64 %t73)
  store i64 %t76, ptr %l56
  br label %bb19
bb19:
  %t77 = load i64, ptr %l56, !tbaa !24
  store i64 %t77, ptr %l3, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/typed:holdWalk", ptr %t78, i32 0, i32 12
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t80, i64 %t81)
  store i32 %t84, ptr %l60
  br label %bb20
bb20:
  %t85 = load i32, ptr %l60, !tbaa !23
  store i32 %t85, ptr %l4, !tbaa !23
  br label %bb21
bb21:
  %t86 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l9, !tbaa !24
  br label %bb8
bb22:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t92 = icmp slt i64 %t90, 0
  br i1 %t92, label %bb23, label %bb24
bb23:
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l11, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/typed:holdWalk", ptr %t95, i32 0, i32 11
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t97)
  store i64 %t99, ptr %l68
  br label %bb26
bb26:
  %t100 = load i64, ptr %l68, !tbaa !24
  store i64 %t100, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t101 = load i64, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load i64, ptr %l13, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb32
bb29:
  %t111 = load i64, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l13, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l13, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l75, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb31
bb31:
  %t127 = load i64, ptr %l75, !tbaa !24
  store i64 %t127, ptr %l72, !tbaa !24
  br label %bb32
bb32:
  %t128 = load i64, ptr %l72, !tbaa !24
  store i64 %t128, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb33
bb33:
  %t129 = load i64, ptr %l15, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb34, label %bb35
bb34:
  br label %bb51
bb35:
  br label %bb36
bb36:
  %t137 = load i64, ptr %l11, !tbaa !24
  %t138 = load i64, ptr %l15, !tbaa !24
  %t139 = load i64, ptr %l13, !tbaa !24
  %t142 = mul i64 %t138, %t139
  %t145 = add i64 %t137, %t142
  store i64 %t145, ptr %l16, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/typed:holdWalk", ptr %t147, i32 0, i32 11
  %t150 = load i64, ptr %l16, !tbaa !24
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t149, i64 %t150)
  store i64 %t153, ptr %l96
  br label %bb37
bb37:
  %t155 = load i64, ptr %l96, !tbaa !24
  %t157 = icmp eq i64 %t155, %a2
  br i1 %t157, label %bb38, label %bb39
bb38:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/typed:holdWalk", ptr %t159, i32 0, i32 10
  %t162 = load i64, ptr %l16, !tbaa !24
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t161, i64 %t162)
  store i64 %t165, ptr %l103
  br label %bb40
bb39:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb46
bb40:
  %t166 = load i64, ptr %l3, !tbaa !24
  %t167 = load i64, ptr %l103, !tbaa !24
  %t169 = icmp sle i64 %t167, %t166
  br i1 %t169, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb45
bb42:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l107, !tbaa !29
  %t172 = load i32, ptr %l4, !tbaa !23
  store i32 %t172, ptr %l108, !tbaa !23
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/typed:holdWalk", ptr %t173, i32 0, i32 12
  %t176 = load i64, ptr %l16, !tbaa !24
  %t179 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t175, i64 %t176)
  store i32 %t179, ptr %l112
  br label %bb43
bb43:
  %t180 = load ptr, ptr %l107, !tbaa !29
  %t181 = load i32, ptr %l108, !tbaa !23
  %t182 = load i32, ptr %l112, !tbaa !23
  %t183 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eencloses(ptr %v0, ptr %v1, ptr %t180, i32 %t181, i32 %t182)
  store i1 %t183, ptr %l113
  br label %bb44
bb44:
  %t184 = load i1, ptr %l113, !tbaa !21
  %t185 = xor i1 %t184, true
  store i1 %t185, ptr %l106, !tbaa !21
  br label %bb45
bb45:
  %t187 = load i1, ptr %l106, !tbaa !21
  store i1 %t187, ptr %l99, !tbaa !21
  br label %bb46
bb46:
  %t188 = load i1, ptr %l99, !tbaa !21
  br i1 %t188, label %bb47, label %bb48
bb47:
  store i1 false, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t190 = load i64, ptr %l15, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l15, !tbaa !24
  br label %bb33
bb51:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempGiven(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l52 = alloca ptr
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca { i64, ptr }
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i64
  %l61 = alloca i64
  %l66 = alloca i64
  %l70 = alloca i1
  %l71 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i32
  %l77 = alloca i32
  %l79 = alloca i1
  %l80 = alloca i1
  %l83 = alloca i1
  %l92 = alloca i64
  %l95 = alloca ptr
  %l98 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l104 = alloca ptr
  %l106 = alloca i32
  %l108 = alloca ptr
  %l110 = alloca ptr
  %l113 = alloca i32
  %l116 = alloca i32
  %l118 = alloca ptr
  %l121 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %v1, ptr %t1, i64 %t2)
  store ptr %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l16, !tbaa !29
  %t7 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t6)
  store i32 %t7, ptr %l17
  br label %bb2
bb2:
  %t8 = load i32, ptr %l17, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l18
  br label %bb3
bb3:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l20
  br label %bb4
bb4:
  %t14 = load i64, ptr %l20, !tbaa !24
  store i64 %t14, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l7, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb10
bb7:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l27, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l27, !tbaa !24
  store i64 %t41, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t42 = load i64, ptr %l24, !tbaa !24
  store i64 %t42, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  %t43 = load i64, ptr %l9, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb12, label %bb13
bb12:
  br label %bb45
bb13:
  br label %bb14
bb14:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l9, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l10, !tbaa !24
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l1, !tbaa !24
  %t65 = icmp eq i64 %t61, %t62
  br i1 %t65, label %bb15, label %bb16
bb15:
  br label %bb44
bb16:
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l48, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l49, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %s4, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l52
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l52, !tbaa !29
  %t75 = load ptr, ptr %l49, !tbaa !29
  %t77 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %s4, ptr %s4, ptr %v2, ptr %v3, ptr %t75, ptr %t74)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %l54
  br label %bb19
bb19:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  %t79 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %t79
  %t81 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s4, ptr %s4, ptr %t79)
  store { i64, ptr } %t81, ptr %l56
  br label %bb20
bb20:
  %t82 = load ptr, ptr %l48, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t84 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclosure(ptr %v0, ptr %s4, ptr %s4, ptr %t82, { i64, ptr } %t83)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l57
  br label %bb21
bb21:
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  %t86 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %t86
  store ptr %t86, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb22
bb22:
  %t88 = load i64, ptr %l12, !tbaa !24
  store i64 %t88, ptr %l59, !tbaa !24
  %t89 = load ptr, ptr %l11, !tbaa !29
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s4, ptr %t89)
  store i64 %t91, ptr %l61
  br label %bb23
bb23:
  %t92 = load i64, ptr %l59, !tbaa !24
  %t93 = load i64, ptr %l61, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb24, label %bb25
bb24:
  br label %bb43
bb25:
  br label %bb26
bb26:
  %t98 = load ptr, ptr %l11, !tbaa !29
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s4, ptr %t98, i64 %t99)
  store i64 %t102, ptr %l66
  br label %bb27
bb27:
  %t103 = load i64, ptr %l66, !tbaa !24
  store i64 %t103, ptr %l13, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/typed:holdWalk", ptr %t104, i32 0, i32 6
  %t107 = load i64, ptr %l13, !tbaa !24
  %t110 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t106, i64 %t107)
  store i1 %t110, ptr %l70
  br label %bb28
bb28:
  %t111 = load i1, ptr %l70, !tbaa !21
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/typed:holdWalk", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  store ptr %t115, ptr %l73, !tbaa !29
  %t116 = load i32, ptr %l3, !tbaa !23
  store i32 %t116, ptr %l74, !tbaa !23
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l13, !tbaa !24
  %t121 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %v3, ptr %v2, ptr %t117, i64 %t118)
  store i32 %t121, ptr %l77
  br label %bb31
bb30:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb33
bb31:
  %t122 = load ptr, ptr %l73, !tbaa !29
  %t123 = call ptr @__olang_scope_or(ptr %v2, ptr %t122)
  %t124 = ptrtoint ptr %t123 to i64
  %t126 = inttoptr i64 %t124 to ptr
  %t127 = load ptr, ptr %l73, !tbaa !29
  %t128 = load i32, ptr %l74, !tbaa !23
  %t129 = load i32, ptr %l77, !tbaa !23
  %t130 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefInto(ptr %t126, ptr %t127, i32 %t128, i32 %t129)
  store i1 %t130, ptr %l79
  br label %bb32
bb32:
  %t131 = load i1, ptr %l79, !tbaa !21
  store i1 %t131, ptr %l71, !tbaa !21
  br label %bb33
bb33:
  %t132 = load i1, ptr %l71, !tbaa !21
  br i1 %t132, label %bb34, label %bb35
bb34:
  %t133 = load i64, ptr %l13, !tbaa !24
  %t136 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l4, i64 %t133)
  store i1 %t136, ptr %l83
  br label %bb36
bb35:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb37
bb36:
  %t137 = load i1, ptr %l83, !tbaa !21
  %t138 = xor i1 %t137, true
  store i1 %t138, ptr %l80, !tbaa !21
  br label %bb37
bb37:
  %t140 = load i1, ptr %l80, !tbaa !21
  br i1 %t140, label %bb38, label %bb39
bb38:
  %t141 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t141)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t144 = load i64, ptr %l12, !tbaa !24
  %t146 = add i64 %t144, 1
  store i64 %t146, ptr %l12, !tbaa !24
  br label %bb22
bb43:
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb44:
  %t148 = load i64, ptr %l9, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l9, !tbaa !24
  br label %bb11
bb45:
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t153, ptr %l92
  br label %bb46
bb46:
  %t154 = load i64, ptr %l92, !tbaa !24
  %t155 = icmp eq i64 %t154, 0
  br i1 %t155, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb48:
  br label %bb49
bb49:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/typed:holdWalk", ptr %t157, i32 0, i32 13
  store ptr %t159, ptr %l95, !tbaa !29
  %t160 = load ptr, ptr %l2, !tbaa !29
  %t161 = load i64, ptr %l1, !tbaa !24
  %t164 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %v1, ptr %t160, i64 %t161)
  store ptr %t164, ptr %l98
  br label %bb50
bb50:
  %t165 = load ptr, ptr %l98, !tbaa !29
  %t166 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t165)
  store %"compiler/source:Span" %t166, ptr %l99
  br label %bb51
bb51:
  %t167 = load ptr, ptr %l95, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l99
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t167, %"compiler/source:Span" %t168)
  br label %bb52
bb52:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/typed:holdWalk", ptr %t169, i32 0, i32 14
  %t172 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %s0, ptr %t171, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t172)
  br label %bb53
bb53:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/typed:holdWalk", ptr %t175, i32 0, i32 15
  store ptr %t177, ptr %l104, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2einBlock(ptr %v0, ptr %t178)
  store i32 %t180, ptr %l106
  br label %bb54
bb54:
  %t181 = load ptr, ptr %l104, !tbaa !29
  %t182 = load i32, ptr %l106, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t181, i32 %t182)
  br label %bb55
bb55:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/typed:holdWalk", ptr %t183, i32 0, i32 16
  store ptr %t185, ptr %l108, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/typed:holdWalk", ptr %t186, i32 0, i32 0
  %t189 = load ptr, ptr %t188, !tbaa !29
  store ptr %t189, ptr %l110, !tbaa !29
  %t190 = load i32, ptr %l3, !tbaa !23
  %t191 = load ptr, ptr %l110, !tbaa !29
  %t192 = call ptr @__olang_scope_or(ptr %v2, ptr %t191)
  %t193 = ptrtoint ptr %t192 to i64
  %t195 = inttoptr i64 %t193 to ptr
  %t196 = load ptr, ptr %l110, !tbaa !29
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t195, ptr %t196, i32 %t190)
  store i32 %t198, ptr %l113
  br label %bb56
bb56:
  %t199 = load i32, ptr %l113, !range !{i32 0, i32 33}
  %t201 = trunc i64 20 to i32
  %t202 = icmp eq i32 %t199, %t201
  br i1 %t202, label %bb57, label %bb58
bb57:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/typed:holdWalk", ptr %t204, i32 0, i32 0
  %t207 = load ptr, ptr %t206, !tbaa !29
  store ptr %t207, ptr %l118, !tbaa !29
  %t208 = load i32, ptr %l3, !tbaa !23
  %t209 = load ptr, ptr %l118, !tbaa !29
  %t210 = call ptr @__olang_scope_or(ptr %v2, ptr %t209)
  %t211 = ptrtoint ptr %t210 to i64
  %t213 = inttoptr i64 %t211 to ptr
  %t214 = load ptr, ptr %l118, !tbaa !29
  %t216 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t213, ptr %t214, i32 %t208)
  store i32 %t216, ptr %l121
  br label %bb59
bb58:
  %t217 = load i32, ptr %l3, !tbaa !23
  store i32 %t217, ptr %l116, !tbaa !23
  br label %bb60
bb59:
  %t219 = load i32, ptr %l121, !tbaa !23
  store i32 %t219, ptr %l116, !tbaa !23
  br label %bb60
bb60:
  %t220 = load ptr, ptr %l108, !tbaa !29
  %t221 = load i32, ptr %l116, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t220, i32 %t221)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1) #0 {
entry:
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t13 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %t10)
  store i1 %t13, ptr %l8
  br label %bb4
bb4:
  %t14 = load i1, ptr %l8, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eclausesLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca i1
  %l28 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Clause", ptr %t31, i32 0, i32 3
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t37 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eblockLeaves(ptr %v0, ptr %v1, ptr %t30, ptr %t34)
  store i1 %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb12
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Clause", ptr %t40, i32 0, i32 4
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t46 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %t39, { i64, ptr } %t43)
  store i1 %t46, ptr %l28
  br label %bb11
bb11:
  %t47 = load i1, ptr %l28, !tbaa !21
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t48 = load i1, ptr %l24, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l3, !tbaa !24
  br label %bb4
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l35 = alloca i32
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l72 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca i1
  %l86 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l102 = alloca i1
  %l107 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l117 = alloca i1
  %l125 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l134 = alloca i1
  %l140 = alloca i32
  %l142 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i1
  %l171 = alloca i32
  %l173 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l179 = alloca i1
  %l183 = alloca { i64, ptr }
  %l184 = alloca i32
  %l186 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l196 = alloca ptr
  %l197 = alloca i1
  %l205 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l215 = alloca { i64, ptr }
  %l217 = alloca ptr
  %l218 = alloca i1
  %l227 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l238 = alloca ptr
  %l239 = alloca i1
  %l246 = alloca i64
  %l250 = alloca { i64, ptr }
  %l252 = alloca ptr
  %l253 = alloca i1
  %l260 = alloca i64
  %l275 = alloca ptr
  %l276 = alloca i1
  %l284 = alloca { i64, ptr }
  %l289 = alloca ptr
  %l290 = alloca i1
  %l295 = alloca ptr
  %l296 = alloca i1
  %l307 = alloca ptr
  %l308 = alloca i1
  %l315 = alloca i64
  %l319 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.builder
  %s23room = alloca [64 x i8], align 8
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t5, ptr %l29, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l30, !tbaa !24
  %t8 = load i64, ptr %l30, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l31, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l30, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t19, ptr %l29, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/typed:printer", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l33, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t25)
  store i32 %t27, ptr %l35
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l33, !tbaa !29
  %t29 = call ptr @__olang_scope_or(ptr %v3, ptr %t28)
  %t30 = ptrtoint ptr %t29 to i64
  %t32 = inttoptr i64 %t30 to ptr
  %t34 = inttoptr i64 0 to ptr
  %t35 = load ptr, ptr %l33, !tbaa !29
  %t36 = load i32, ptr %l35, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t32, ptr %s0, ptr %t34, ptr %t35, i32 %t36)
  store { i64, ptr } %t37, ptr %l38
  br label %bb5
bb5:
  %t38 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t38, ptr %l2, !tbaa !27
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t40 = load ptr, ptr %l40, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb6, label %bb7
bb6:
  %t43 = load ptr, ptr %l40, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 18}
  %t46 = icmp eq i64 %t44, 0
  store i1 %t46, ptr %l41, !tbaa !21
  br label %bb7
bb7:
  %t47 = load i1, ptr %l41, !tbaa !21
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t50, i32 0, i32 2
  %t52 = load i64, ptr %t51
  store i64 %t52, ptr %l3, !tbaa !24
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = load i64, ptr %l3, !tbaa !24
  %t56 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t59 = extractvalue { i64, ptr } %t54, 1
  %t60 = extractvalue { i64, ptr } %t54, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t66 = call i64 @__olang_fmt_i64(ptr null, i64 %t55)
  %t67 = add i64 %t64, %t66
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t71 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t56, i64 %t57)
  %t72 = getelementptr i8, ptr %t71, i64 %t57
  call void @olang_textcopy(ptr %t72, ptr %t59, i64 %t60)
  %t73 = getelementptr i8, ptr %t72, i64 %t60
  call void @olang_textcopy(ptr %t73, ptr %t62, i64 %t63)
  %t74 = getelementptr i8, ptr %t73, i64 %t63
  %t75 = call i64 @__olang_fmt_i64(ptr %t74, i64 %t55)
  %t76 = getelementptr i8, ptr %t74, i64 %t66
  call void @olang_textcopy(ptr %t76, ptr %t68, i64 %t69)
  %t77 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t71, 1
  store { i64, ptr } %t78, ptr %l39, !tbaa !27
  br label %bb153
bb11:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t81 = load ptr, ptr %l49, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb12, label %bb13
bb12:
  %t84 = load ptr, ptr %l49, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 18}
  %t87 = icmp eq i64 %t85, 1
  store i1 %t87, ptr %l50, !tbaa !21
  br label %bb13
bb13:
  %t88 = load i1, ptr %l50, !tbaa !21
  br i1 %t88, label %bb14, label %bb15
bb14:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t91, i32 0, i32 2
  %t93 = load i64, ptr %t92
  store i64 %t93, ptr %l4, !tbaa !24
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t97, i32 0, i32 3
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t101, ptr %l57, !tbaa !27
  %t102 = load i64, ptr %l4, !tbaa !24
  store i64 %t102, ptr %l58, !tbaa !24
  %t103 = load ptr, ptr %l5, !tbaa !29
  %t105 = call { i64, ptr } @compiler_2ftyped_2econstText(ptr %v1, ptr %s4, ptr %t103)
  store { i64, ptr } %t105, ptr %l60
  br label %bb17
bb17:
  %t106 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t107 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t108 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = add i64 %t107, %t110
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t114 = add i64 %t111, %t113
  %t115 = load i64, ptr %l58, !tbaa !24
  %t116 = call i64 @__olang_fmt_i64(ptr null, i64 %t115)
  %t117 = add i64 %t114, %t116
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = add i64 %t120, %t123
  %t125 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t127 = add i64 %t124, %t126
  %t128 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t127)
  call void @olang_textcopy(ptr %t128, ptr %t106, i64 %t107)
  %t129 = getelementptr i8, ptr %t128, i64 %t107
  call void @olang_textcopy(ptr %t129, ptr %t109, i64 %t110)
  %t130 = getelementptr i8, ptr %t129, i64 %t110
  call void @olang_textcopy(ptr %t130, ptr %t112, i64 %t113)
  %t131 = getelementptr i8, ptr %t130, i64 %t113
  %t132 = call i64 @__olang_fmt_i64(ptr %t131, i64 %t115)
  %t133 = getelementptr i8, ptr %t131, i64 %t116
  call void @olang_textcopy(ptr %t133, ptr %t118, i64 %t119)
  %t134 = getelementptr i8, ptr %t133, i64 %t119
  call void @olang_textcopy(ptr %t134, ptr %t122, i64 %t123)
  %t135 = getelementptr i8, ptr %t134, i64 %t123
  call void @olang_textcopy(ptr %t135, ptr %t125, i64 %t126)
  %t136 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t128, 1
  store { i64, ptr } %t137, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb153
bb18:
  %t139 = load ptr, ptr %l1, !tbaa !29
  store ptr %t139, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t140 = load ptr, ptr %l62, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb19, label %bb20
bb19:
  %t143 = load ptr, ptr %l62, !tbaa !29
  %t144 = load i64, ptr %t143, !range !{i64 0, i64 18}
  %t146 = icmp eq i64 %t144, 2
  store i1 %t146, ptr %l63, !tbaa !21
  br label %bb20
bb20:
  %t147 = load i1, ptr %l63, !tbaa !21
  br i1 %t147, label %bb21, label %bb22
bb21:
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr { i64, [5 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t150, i32 0, i32 2
  %t152 = load ptr, ptr %t151
  store ptr %t152, ptr %l6, !tbaa !29
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t156, i32 0, i32 3
  %t158 = load i32, ptr %t157
  store i32 %t158, ptr %l7, !tbaa !23
  br label %bb23
bb22:
  br label %bb28
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l6, !tbaa !29
  %t164 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s6, ptr %v3, ptr %t160, ptr %t161)
  store { i64, ptr } %t164, ptr %l72
  br label %bb24
bb24:
  %t165 = load i32, ptr %l7, !tbaa !23
  %t167 = icmp sge i32 %t165, 0
  br i1 %t167, label %bb25, label %bb26
bb25:
  %t169 = load i32, ptr %l7, !tbaa !23
  %t170 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t173 = sext i32 %t169 to i64
  %t174 = call i64 @__olang_fmt_i64(ptr null, i64 %t173)
  %t175 = add i64 %t171, %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t170, i64 %t171)
  %t177 = getelementptr i8, ptr %t176, i64 %t171
  %t178 = call i64 @__olang_fmt_i64(ptr %t177, i64 %t173)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t176, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = extractvalue { i64, ptr } %t180, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l75, !tbaa !27
  br label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l75, !tbaa !27
  br label %bb27
bb27:
  %t189 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t191 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = add i64 %t190, %t193
  %t195 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = add i64 %t194, %t197
  %t199 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t202 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t201)
  call void @olang_textcopy(ptr %t202, ptr %t189, i64 %t190)
  %t203 = getelementptr i8, ptr %t202, i64 %t190
  call void @olang_textcopy(ptr %t203, ptr %t192, i64 %t193)
  %t204 = getelementptr i8, ptr %t203, i64 %t193
  call void @olang_textcopy(ptr %t204, ptr %t196, i64 %t197)
  %t205 = getelementptr i8, ptr %t204, i64 %t197
  call void @olang_textcopy(ptr %t205, ptr %t199, i64 %t200)
  %t206 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t202, 1
  store { i64, ptr } %t207, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb153
bb28:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t210 = load ptr, ptr %l80, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb29, label %bb30
bb29:
  %t213 = load ptr, ptr %l80, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 18}
  %t216 = icmp eq i64 %t214, 3
  store i1 %t216, ptr %l81, !tbaa !21
  br label %bb30
bb30:
  %t217 = load i1, ptr %l81, !tbaa !21
  br i1 %t217, label %bb31, label %bb32
bb31:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t220, i32 0, i32 2
  %t222 = load ptr, ptr %t221
  store ptr %t222, ptr %l8, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  store %olang.scope zeroinitializer, ptr %s9
  %t224 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t224, ptr %l86, !tbaa !27
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l8, !tbaa !29
  %t229 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s9, ptr %v3, ptr %t225, ptr %t226)
  store { i64, ptr } %t229, ptr %l89
  br label %bb34
bb34:
  %t230 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t232 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t239 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = add i64 %t238, %t241
  %t243 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t245 = add i64 %t242, %t244
  %t246 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t245)
  call void @olang_textcopy(ptr %t246, ptr %t230, i64 %t231)
  %t247 = getelementptr i8, ptr %t246, i64 %t231
  call void @olang_textcopy(ptr %t247, ptr %t233, i64 %t234)
  %t248 = getelementptr i8, ptr %t247, i64 %t234
  call void @olang_textcopy(ptr %t248, ptr %t236, i64 %t237)
  %t249 = getelementptr i8, ptr %t248, i64 %t237
  call void @olang_textcopy(ptr %t249, ptr %t240, i64 %t241)
  %t250 = getelementptr i8, ptr %t249, i64 %t241
  call void @olang_textcopy(ptr %t250, ptr %t243, i64 %t244)
  %t251 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t246, 1
  store { i64, ptr } %t252, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb153
bb35:
  %t254 = load ptr, ptr %l1, !tbaa !29
  store ptr %t254, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t255 = load ptr, ptr %l91, !tbaa !29
  %t256 = icmp ne ptr %t255, null
  br i1 %t256, label %bb36, label %bb37
bb36:
  %t258 = load ptr, ptr %l91, !tbaa !29
  %t259 = load i64, ptr %t258, !range !{i64 0, i64 18}
  %t261 = icmp eq i64 %t259, 4
  store i1 %t261, ptr %l92, !tbaa !21
  br label %bb37
bb37:
  %t262 = load i1, ptr %l92, !tbaa !21
  br i1 %t262, label %bb38, label %bb39
bb38:
  %t263 = load ptr, ptr %l1, !tbaa !29
  %t265 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 1
  %t266 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t265, i32 0, i32 2
  %t267 = load ptr, ptr %t266
  store ptr %t267, ptr %l9, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  store %olang.scope zeroinitializer, ptr %s11
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load ptr, ptr %l9, !tbaa !29
  %t273 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s11, ptr %v3, ptr %t269, ptr %t270)
  store { i64, ptr } %t273, ptr %l99
  br label %bb41
bb41:
  %t274 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t276 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t276, 1
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t279 = add i64 %t275, %t278
  %t280 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t281 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t282 = add i64 %t279, %t281
  %t283 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t282)
  call void @olang_textcopy(ptr %t283, ptr %t274, i64 %t275)
  %t284 = getelementptr i8, ptr %t283, i64 %t275
  call void @olang_textcopy(ptr %t284, ptr %t277, i64 %t278)
  %t285 = getelementptr i8, ptr %t284, i64 %t278
  call void @olang_textcopy(ptr %t285, ptr %t280, i64 %t281)
  %t286 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t283, 1
  store { i64, ptr } %t287, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb153
bb42:
  %t289 = load ptr, ptr %l1, !tbaa !29
  store ptr %t289, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t290 = load ptr, ptr %l101, !tbaa !29
  %t291 = icmp ne ptr %t290, null
  br i1 %t291, label %bb43, label %bb44
bb43:
  %t293 = load ptr, ptr %l101, !tbaa !29
  %t294 = load i64, ptr %t293, !range !{i64 0, i64 18}
  %t296 = icmp eq i64 %t294, 5
  store i1 %t296, ptr %l102, !tbaa !21
  br label %bb44
bb44:
  %t297 = load i1, ptr %l102, !tbaa !21
  br i1 %t297, label %bb45, label %bb46
bb45:
  %t298 = load ptr, ptr %l1, !tbaa !29
  %t300 = getelementptr { i64, [5 x i64] }, ptr %t298, i32 0, i32 1
  %t301 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t300, i32 0, i32 2
  %t302 = load ptr, ptr %t301
  store ptr %t302, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  store %olang.scope zeroinitializer, ptr %s13
  %t304 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t304, ptr %l107, !tbaa !27
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load ptr, ptr %l10, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Promote", ptr %t306, i32 0, i32 0
  %t309 = load ptr, ptr %t308, !tbaa !29
  %t313 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s13, ptr %v3, ptr %t305, ptr %t309)
  store { i64, ptr } %t313, ptr %l112
  br label %bb48
bb48:
  %t314 = load ptr, ptr %l10, !tbaa !29
  %t316 = getelementptr %"compiler/typed:Promote", ptr %t314, i32 0, i32 1
  %t317 = load i32, ptr %t316, !tbaa !23
  %t318 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t319 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t320 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t320, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = add i64 %t319, %t322
  %t324 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t326 = add i64 %t323, %t325
  %t327 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t328 = extractvalue { i64, ptr } %t327, 1
  %t329 = extractvalue { i64, ptr } %t327, 0
  %t330 = add i64 %t326, %t329
  %t331 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t332 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t333 = add i64 %t330, %t332
  %t335 = sext i32 %t317 to i64
  %t336 = call i64 @__olang_fmt_i64(ptr null, i64 %t335)
  %t337 = add i64 %t333, %t336
  %t338 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t339 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t340 = add i64 %t337, %t339
  %t341 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t340)
  call void @olang_textcopy(ptr %t341, ptr %t318, i64 %t319)
  %t342 = getelementptr i8, ptr %t341, i64 %t319
  call void @olang_textcopy(ptr %t342, ptr %t321, i64 %t322)
  %t343 = getelementptr i8, ptr %t342, i64 %t322
  call void @olang_textcopy(ptr %t343, ptr %t324, i64 %t325)
  %t344 = getelementptr i8, ptr %t343, i64 %t325
  call void @olang_textcopy(ptr %t344, ptr %t328, i64 %t329)
  %t345 = getelementptr i8, ptr %t344, i64 %t329
  call void @olang_textcopy(ptr %t345, ptr %t331, i64 %t332)
  %t346 = getelementptr i8, ptr %t345, i64 %t332
  %t347 = call i64 @__olang_fmt_i64(ptr %t346, i64 %t335)
  %t348 = getelementptr i8, ptr %t346, i64 %t336
  call void @olang_textcopy(ptr %t348, ptr %t338, i64 %t339)
  %t349 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t341, 1
  store { i64, ptr } %t350, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb153
bb49:
  %t352 = load ptr, ptr %l1, !tbaa !29
  store ptr %t352, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t353 = load ptr, ptr %l116, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb50, label %bb51
bb50:
  %t356 = load ptr, ptr %l116, !tbaa !29
  %t357 = load i64, ptr %t356, !range !{i64 0, i64 18}
  %t359 = icmp eq i64 %t357, 6
  store i1 %t359, ptr %l117, !tbaa !21
  br label %bb51
bb51:
  %t360 = load i1, ptr %l117, !tbaa !21
  br i1 %t360, label %bb52, label %bb53
bb52:
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t363 = getelementptr { i64, [5 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t363, i32 0, i32 2
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l11, !tbaa !29
  br label %bb54
bb53:
  br label %bb57
bb54:
  store %olang.scope zeroinitializer, ptr %s15
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l11, !tbaa !29
  %t370 = getelementptr %"compiler/typed:Call", ptr %t368, i32 0, i32 0
  %t371 = load ptr, ptr %t370, !tbaa !29
  %t374 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2ecallee(ptr %v0, ptr %v1, ptr %s15, ptr %v3, ptr %t367, ptr %t371)
  store { i64, ptr } %t374, ptr %l125
  br label %bb55
bb55:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load ptr, ptr %l11, !tbaa !29
  %t378 = getelementptr %"compiler/typed:Call", ptr %t376, i32 0, i32 1
  %t379 = load { i64, ptr }, ptr %t378, !tbaa !27
  %t382 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %s15, ptr %v3, ptr %t375, { i64, ptr } %t379)
  store { i64, ptr } %t382, ptr %l129
  br label %bb56
bb56:
  %t383 = load ptr, ptr %l11, !tbaa !29
  %t385 = getelementptr %"compiler/typed:Call", ptr %t383, i32 0, i32 2
  %t386 = load i32, ptr %t385, !tbaa !23
  %t387 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t388 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t389 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 1
  %t391 = extractvalue { i64, ptr } %t389, 0
  %t392 = add i64 %t388, %t391
  %t393 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t394 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t395 = add i64 %t392, %t394
  %t396 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t397 = extractvalue { i64, ptr } %t396, 1
  %t398 = extractvalue { i64, ptr } %t396, 0
  %t399 = add i64 %t395, %t398
  %t400 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t401 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t402 = add i64 %t399, %t401
  %t404 = sext i32 %t386 to i64
  %t405 = call i64 @__olang_fmt_i64(ptr null, i64 %t404)
  %t406 = add i64 %t402, %t405
  %t407 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t408 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t409 = add i64 %t406, %t408
  %t410 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t409)
  call void @olang_textcopy(ptr %t410, ptr %t387, i64 %t388)
  %t411 = getelementptr i8, ptr %t410, i64 %t388
  call void @olang_textcopy(ptr %t411, ptr %t390, i64 %t391)
  %t412 = getelementptr i8, ptr %t411, i64 %t391
  call void @olang_textcopy(ptr %t412, ptr %t393, i64 %t394)
  %t413 = getelementptr i8, ptr %t412, i64 %t394
  call void @olang_textcopy(ptr %t413, ptr %t397, i64 %t398)
  %t414 = getelementptr i8, ptr %t413, i64 %t398
  call void @olang_textcopy(ptr %t414, ptr %t400, i64 %t401)
  %t415 = getelementptr i8, ptr %t414, i64 %t401
  %t416 = call i64 @__olang_fmt_i64(ptr %t415, i64 %t404)
  %t417 = getelementptr i8, ptr %t415, i64 %t405
  call void @olang_textcopy(ptr %t417, ptr %t407, i64 %t408)
  %t418 = insertvalue { i64, ptr } undef, i64 %t409, 0
  %t419 = insertvalue { i64, ptr } %t418, ptr %t410, 1
  store { i64, ptr } %t419, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s15)
  br label %bb153
bb57:
  %t421 = load ptr, ptr %l1, !tbaa !29
  store ptr %t421, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t422 = load ptr, ptr %l133, !tbaa !29
  %t423 = icmp ne ptr %t422, null
  br i1 %t423, label %bb58, label %bb59
bb58:
  %t425 = load ptr, ptr %l133, !tbaa !29
  %t426 = load i64, ptr %t425, !range !{i64 0, i64 18}
  %t428 = icmp eq i64 %t426, 7
  store i1 %t428, ptr %l134, !tbaa !21
  br label %bb59
bb59:
  %t429 = load i1, ptr %l134, !tbaa !21
  br i1 %t429, label %bb60, label %bb61
bb60:
  %t430 = load ptr, ptr %l1, !tbaa !29
  %t432 = getelementptr { i64, [5 x i64] }, ptr %t430, i32 0, i32 1
  %t433 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t432, i32 0, i32 2
  %t434 = load ptr, ptr %t433
  store ptr %t434, ptr %l12, !tbaa !29
  br label %bb62
bb61:
  br label %bb66
bb62:
  store %olang.scope zeroinitializer, ptr %s17
  %t436 = load ptr, ptr %l12, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Make", ptr %t436, i32 0, i32 0
  %t439 = load i32, ptr %t438, !range !{i32 0, i32 5}
  store i32 %t439, ptr %l140
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aMakeKind(ptr %s18, ptr %l140, i64 0)
  br label %bb63
bb63:
  %t441 = load ptr, ptr %s18
  %t442 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t443 = load i64, ptr %t442
  %t444 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t443)
  call void @olang_textcopy(ptr %t444, ptr %t441, i64 %t443)
  %t445 = insertvalue { i64, ptr } undef, i64 %t443, 0
  %t446 = insertvalue { i64, ptr } %t445, ptr %t444, 1
  store { i64, ptr } %t446, ptr %l142, !tbaa !27
  %t447 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t448 = load ptr, ptr %t447
  %t449 = icmp ne ptr %t448, null
  br i1 %t449, label %sbgrew.450, label %sbdone.451
sbgrew.450:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.451
sbdone.451:
  %t452 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 0
  %t454 = extractvalue { i64, ptr } %t452, 1
  %t455 = mul i64 %t453, 1
  %t456 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t455)
  call void @llvm.memcpy.p0.p0.i64(ptr %t456, ptr %t454, i64 %t455, i1 false)
  %t457 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t458 = insertvalue { i64, ptr } %t457, ptr %t456, 1
  %t460 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s17, ptr %s17, { i64, ptr } %t458)
  store { i64, ptr } %t460, ptr %l144
  br label %bb64
bb64:
  %t461 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t461, ptr %l145, !tbaa !27
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load ptr, ptr %l12, !tbaa !29
  %t465 = getelementptr %"compiler/typed:Make", ptr %t463, i32 0, i32 2
  %t466 = load { i64, ptr }, ptr %t465, !tbaa !27
  %t469 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %s17, ptr %v3, ptr %t462, { i64, ptr } %t466)
  store { i64, ptr } %t469, ptr %l149
  br label %bb65
bb65:
  %t470 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t471 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t472 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t472, 1
  %t474 = extractvalue { i64, ptr } %t472, 0
  %t475 = add i64 %t471, %t474
  %t476 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t477 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t478 = add i64 %t475, %t477
  %t479 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t480 = extractvalue { i64, ptr } %t479, 1
  %t481 = extractvalue { i64, ptr } %t479, 0
  %t482 = add i64 %t478, %t481
  %t483 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t484 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t485 = add i64 %t482, %t484
  %t486 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t487 = extractvalue { i64, ptr } %t486, 1
  %t488 = extractvalue { i64, ptr } %t486, 0
  %t489 = add i64 %t485, %t488
  %t490 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t491 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t492 = add i64 %t489, %t491
  %t493 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t492)
  call void @olang_textcopy(ptr %t493, ptr %t470, i64 %t471)
  %t494 = getelementptr i8, ptr %t493, i64 %t471
  call void @olang_textcopy(ptr %t494, ptr %t473, i64 %t474)
  %t495 = getelementptr i8, ptr %t494, i64 %t474
  call void @olang_textcopy(ptr %t495, ptr %t476, i64 %t477)
  %t496 = getelementptr i8, ptr %t495, i64 %t477
  call void @olang_textcopy(ptr %t496, ptr %t480, i64 %t481)
  %t497 = getelementptr i8, ptr %t496, i64 %t481
  call void @olang_textcopy(ptr %t497, ptr %t483, i64 %t484)
  %t498 = getelementptr i8, ptr %t497, i64 %t484
  call void @olang_textcopy(ptr %t498, ptr %t487, i64 %t488)
  %t499 = getelementptr i8, ptr %t498, i64 %t488
  call void @olang_textcopy(ptr %t499, ptr %t490, i64 %t491)
  %t500 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t493, 1
  store { i64, ptr } %t501, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb153
bb66:
  %t503 = load ptr, ptr %l1, !tbaa !29
  store ptr %t503, ptr %l151, !tbaa !29
  store i1 false, ptr %l152, !tbaa !21
  %t504 = load ptr, ptr %l151, !tbaa !29
  %t505 = icmp ne ptr %t504, null
  br i1 %t505, label %bb67, label %bb68
bb67:
  %t507 = load ptr, ptr %l151, !tbaa !29
  %t508 = load i64, ptr %t507, !range !{i64 0, i64 18}
  %t510 = icmp eq i64 %t508, 8
  store i1 %t510, ptr %l152, !tbaa !21
  br label %bb68
bb68:
  %t511 = load i1, ptr %l152, !tbaa !21
  br i1 %t511, label %bb69, label %bb70
bb69:
  %t512 = load ptr, ptr %l1, !tbaa !29
  %t514 = getelementptr { i64, [5 x i64] }, ptr %t512, i32 0, i32 1
  %t515 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t514, i32 0, i32 2
  %t516 = load ptr, ptr %t515
  store ptr %t516, ptr %l13, !tbaa !29
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t518 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t519 = load ptr, ptr %l13, !tbaa !29
  %t521 = getelementptr %"compiler/typed:Collect", ptr %t519, i32 0, i32 2
  %t522 = load i32, ptr %t521, !tbaa !23
  %t523 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t524 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t526 = extractvalue { i64, ptr } %t518, 1
  %t527 = extractvalue { i64, ptr } %t518, 0
  %t528 = add i64 %t524, %t527
  %t529 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t530 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t531 = add i64 %t528, %t530
  %t533 = sext i32 %t522 to i64
  %t534 = call i64 @__olang_fmt_i64(ptr null, i64 %t533)
  %t535 = add i64 %t531, %t534
  %t536 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t537 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t538 = add i64 %t535, %t537
  %t539 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t538)
  call void @olang_textcopy(ptr %t539, ptr %t523, i64 %t524)
  %t540 = getelementptr i8, ptr %t539, i64 %t524
  call void @olang_textcopy(ptr %t540, ptr %t526, i64 %t527)
  %t541 = getelementptr i8, ptr %t540, i64 %t527
  call void @olang_textcopy(ptr %t541, ptr %t529, i64 %t530)
  %t542 = getelementptr i8, ptr %t541, i64 %t530
  %t543 = call i64 @__olang_fmt_i64(ptr %t542, i64 %t533)
  %t544 = getelementptr i8, ptr %t542, i64 %t534
  call void @olang_textcopy(ptr %t544, ptr %t536, i64 %t537)
  %t545 = insertvalue { i64, ptr } undef, i64 %t538, 0
  %t546 = insertvalue { i64, ptr } %t545, ptr %t539, 1
  store { i64, ptr } %t546, ptr %l39, !tbaa !27
  br label %bb153
bb72:
  %t548 = load ptr, ptr %l1, !tbaa !29
  store ptr %t548, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t549 = load ptr, ptr %l161, !tbaa !29
  %t550 = icmp ne ptr %t549, null
  br i1 %t550, label %bb73, label %bb74
bb73:
  %t552 = load ptr, ptr %l161, !tbaa !29
  %t553 = load i64, ptr %t552, !range !{i64 0, i64 18}
  %t555 = icmp eq i64 %t553, 9
  store i1 %t555, ptr %l162, !tbaa !21
  br label %bb74
bb74:
  %t556 = load i1, ptr %l162, !tbaa !21
  br i1 %t556, label %bb75, label %bb76
bb75:
  %t557 = load ptr, ptr %l1, !tbaa !29
  %t559 = getelementptr { i64, [5 x i64] }, ptr %t557, i32 0, i32 1
  %t560 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t559, i32 0, i32 2
  %t561 = load i32, ptr %t560, !range !{i32 0, i32 51}
  store i32 %t561, ptr %l14
  %t563 = load ptr, ptr %l1, !tbaa !29
  %t565 = getelementptr { i64, [5 x i64] }, ptr %t563, i32 0, i32 1
  %t566 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t565, i32 0, i32 3
  %t567 = load i32, ptr %t566, !range !{i32 0, i32 4}
  store i32 %t567, ptr %l15
  %t569 = load ptr, ptr %l1, !tbaa !29
  %t571 = getelementptr { i64, [5 x i64] }, ptr %t569, i32 0, i32 1
  %t572 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t571, i32 0, i32 4
  %t573 = load { i64, ptr }, ptr %t572
  store { i64, ptr } %t573, ptr %l16, !tbaa !27
  br label %bb77
bb76:
  br label %bb89
bb77:
  store %olang.scope zeroinitializer, ptr %s22
  %t575 = load i32, ptr %l14, !range !{i32 0, i32 51}
  store i32 %t575, ptr %l171
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s23
  store ptr %s23room, ptr %s23
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %s23, ptr %l171, i64 0)
  br label %bb78
bb78:
  %t577 = load ptr, ptr %s23
  %t578 = getelementptr %olang.builder, ptr %s23, i32 0, i32 1
  %t579 = load i64, ptr %t578
  %t580 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t579)
  call void @olang_textcopy(ptr %t580, ptr %t577, i64 %t579)
  %t581 = insertvalue { i64, ptr } undef, i64 %t579, 0
  %t582 = insertvalue { i64, ptr } %t581, ptr %t580, 1
  store { i64, ptr } %t582, ptr %l173, !tbaa !27
  %t583 = getelementptr %olang.builder, ptr %s23, i32 0, i32 3
  %t584 = load ptr, ptr %t583
  %t585 = icmp ne ptr %t584, null
  br i1 %t585, label %sbgrew.586, label %sbdone.587
sbgrew.586:
  call void @__olang_sb_done(ptr %s23)
  br label %sbdone.587
sbdone.587:
  %t588 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t589 = extractvalue { i64, ptr } %t588, 0
  %t590 = extractvalue { i64, ptr } %t588, 1
  %t591 = mul i64 %t589, 1
  %t592 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t591)
  call void @llvm.memcpy.p0.p0.i64(ptr %t592, ptr %t590, i64 %t591, i1 false)
  %t593 = insertvalue { i64, ptr } undef, i64 %t589, 0
  %t594 = insertvalue { i64, ptr } %t593, ptr %t592, 1
  %t596 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s22, ptr %s22, { i64, ptr } %t594)
  store { i64, ptr } %t596, ptr %l175
  br label %bb79
bb79:
  %t597 = load i32, ptr %l15, !range !{i32 0, i32 4}
  %t599 = trunc i64 0 to i32
  %t600 = icmp eq i32 %t597, %t599
  %t602 = xor i1 %t600, true
  br i1 %t602, label %bb80, label %bb81
bb80:
  %t604 = load i32, ptr %l15, !range !{i32 0, i32 4}
  %t606 = trunc i64 3 to i32
  %t607 = icmp eq i32 %t604, %t606
  %t609 = xor i1 %t607, true
  store i1 %t609, ptr %l179, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb82
bb82:
  %t611 = load i1, ptr %l179, !tbaa !21
  br i1 %t611, label %bb83, label %bb84
bb83:
  %t612 = load i32, ptr %l15, !range !{i32 0, i32 4}
  store i32 %t612, ptr %l184
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aCheck(ptr %s24, ptr %l184, i64 0)
  br label %bb85
bb84:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l183, !tbaa !27
  br label %bb87
bb85:
  %t614 = load ptr, ptr %s24
  %t615 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t616 = load i64, ptr %t615
  %t617 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t616)
  call void @olang_textcopy(ptr %t617, ptr %t614, i64 %t616)
  %t618 = insertvalue { i64, ptr } undef, i64 %t616, 0
  %t619 = insertvalue { i64, ptr } %t618, ptr %t617, 1
  store { i64, ptr } %t619, ptr %l186, !tbaa !27
  %t620 = getelementptr %olang.builder, ptr %s24, i32 0, i32 3
  %t621 = load ptr, ptr %t620
  %t622 = icmp ne ptr %t621, null
  br i1 %t622, label %sbgrew.623, label %sbdone.624
sbgrew.623:
  call void @__olang_sb_done(ptr %s24)
  br label %sbdone.624
sbdone.624:
  %t625 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t626 = extractvalue { i64, ptr } %t625, 0
  %t627 = extractvalue { i64, ptr } %t625, 1
  %t628 = mul i64 %t626, 1
  %t629 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t628)
  call void @llvm.memcpy.p0.p0.i64(ptr %t629, ptr %t627, i64 %t628, i1 false)
  %t630 = insertvalue { i64, ptr } undef, i64 %t626, 0
  %t631 = insertvalue { i64, ptr } %t630, ptr %t629, 1
  %t633 = call { i64, ptr } @compiler_2ftyped_2eshort(ptr %s22, ptr %s22, { i64, ptr } %t631)
  store { i64, ptr } %t633, ptr %l188
  br label %bb86
bb86:
  %t634 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t635 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t636 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t637 = extractvalue { i64, ptr } %t636, 1
  %t638 = extractvalue { i64, ptr } %t636, 0
  %t639 = add i64 %t635, %t638
  %t640 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t639)
  call void @olang_textcopy(ptr %t640, ptr %t634, i64 %t635)
  %t641 = getelementptr i8, ptr %t640, i64 %t635
  call void @olang_textcopy(ptr %t641, ptr %t637, i64 %t638)
  %t642 = insertvalue { i64, ptr } undef, i64 %t639, 0
  %t643 = insertvalue { i64, ptr } %t642, ptr %t640, 1
  %t645 = extractvalue { i64, ptr } %t643, 0
  %t646 = extractvalue { i64, ptr } %t643, 1
  %t647 = mul i64 %t645, 1
  %t648 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t647)
  call void @llvm.memcpy.p0.p0.i64(ptr %t648, ptr %t646, i64 %t647, i1 false)
  %t649 = insertvalue { i64, ptr } undef, i64 %t645, 0
  %t650 = insertvalue { i64, ptr } %t649, ptr %t648, 1
  store { i64, ptr } %t650, ptr %l183, !tbaa !27
  br label %bb87
bb87:
  %t652 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t652, ptr %l191, !tbaa !27
  %t653 = load ptr, ptr %l0, !tbaa !29
  %t654 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t657 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %s22, ptr %v3, ptr %t653, { i64, ptr } %t654)
  store { i64, ptr } %t657, ptr %l194
  br label %bb88
bb88:
  %t658 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t659 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t660 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t661 = extractvalue { i64, ptr } %t660, 1
  %t662 = extractvalue { i64, ptr } %t660, 0
  %t663 = add i64 %t659, %t662
  %t664 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t665 = extractvalue { i64, ptr } %t664, 1
  %t666 = extractvalue { i64, ptr } %t664, 0
  %t667 = add i64 %t663, %t666
  %t668 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t669 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t670 = add i64 %t667, %t669
  %t671 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t672 = extractvalue { i64, ptr } %t671, 1
  %t673 = extractvalue { i64, ptr } %t671, 0
  %t674 = add i64 %t670, %t673
  %t675 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t676 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t677 = add i64 %t674, %t676
  %t678 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t679 = extractvalue { i64, ptr } %t678, 1
  %t680 = extractvalue { i64, ptr } %t678, 0
  %t681 = add i64 %t677, %t680
  %t682 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t683 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t684 = add i64 %t681, %t683
  %t685 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t684)
  call void @olang_textcopy(ptr %t685, ptr %t658, i64 %t659)
  %t686 = getelementptr i8, ptr %t685, i64 %t659
  call void @olang_textcopy(ptr %t686, ptr %t661, i64 %t662)
  %t687 = getelementptr i8, ptr %t686, i64 %t662
  call void @olang_textcopy(ptr %t687, ptr %t665, i64 %t666)
  %t688 = getelementptr i8, ptr %t687, i64 %t666
  call void @olang_textcopy(ptr %t688, ptr %t668, i64 %t669)
  %t689 = getelementptr i8, ptr %t688, i64 %t669
  call void @olang_textcopy(ptr %t689, ptr %t672, i64 %t673)
  %t690 = getelementptr i8, ptr %t689, i64 %t673
  call void @olang_textcopy(ptr %t690, ptr %t675, i64 %t676)
  %t691 = getelementptr i8, ptr %t690, i64 %t676
  call void @olang_textcopy(ptr %t691, ptr %t679, i64 %t680)
  %t692 = getelementptr i8, ptr %t691, i64 %t680
  call void @olang_textcopy(ptr %t692, ptr %t682, i64 %t683)
  %t693 = insertvalue { i64, ptr } undef, i64 %t684, 0
  %t694 = insertvalue { i64, ptr } %t693, ptr %t685, 1
  store { i64, ptr } %t694, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  br label %bb153
bb89:
  %t696 = load ptr, ptr %l1, !tbaa !29
  store ptr %t696, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t697 = load ptr, ptr %l196, !tbaa !29
  %t698 = icmp ne ptr %t697, null
  br i1 %t698, label %bb90, label %bb91
bb90:
  %t700 = load ptr, ptr %l196, !tbaa !29
  %t701 = load i64, ptr %t700, !range !{i64 0, i64 18}
  %t703 = icmp eq i64 %t701, 10
  store i1 %t703, ptr %l197, !tbaa !21
  br label %bb91
bb91:
  %t704 = load i1, ptr %l197, !tbaa !21
  br i1 %t704, label %bb92, label %bb93
bb92:
  %t705 = load ptr, ptr %l1, !tbaa !29
  %t707 = getelementptr { i64, [5 x i64] }, ptr %t705, i32 0, i32 1
  %t708 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t707, i32 0, i32 2
  %t709 = load ptr, ptr %t708
  store ptr %t709, ptr %l17, !tbaa !29
  br label %bb94
bb93:
  br label %bb98
bb94:
  store %olang.scope zeroinitializer, ptr %s27
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t712 = load ptr, ptr %l17, !tbaa !29
  %t714 = getelementptr %"compiler/typed:Slice", ptr %t712, i32 0, i32 0
  %t715 = load ptr, ptr %t714, !tbaa !29
  %t718 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s27, ptr %v3, ptr %t711, ptr %t715)
  store { i64, ptr } %t718, ptr %l205
  br label %bb95
bb95:
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load ptr, ptr %l17, !tbaa !29
  %t722 = getelementptr %"compiler/typed:Slice", ptr %t720, i32 0, i32 1
  %t723 = load ptr, ptr %t722, !tbaa !29
  %t727 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %v3, ptr %t719, ptr %t723)
  store { i64, ptr } %t727, ptr %l210
  br label %bb96
bb96:
  %t728 = load ptr, ptr %l0, !tbaa !29
  %t729 = load ptr, ptr %l17, !tbaa !29
  %t731 = getelementptr %"compiler/typed:Slice", ptr %t729, i32 0, i32 2
  %t732 = load ptr, ptr %t731, !tbaa !29
  %t736 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %v3, ptr %t728, ptr %t732)
  store { i64, ptr } %t736, ptr %l215
  br label %bb97
bb97:
  %t737 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t738 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t739 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t740 = extractvalue { i64, ptr } %t739, 1
  %t741 = extractvalue { i64, ptr } %t739, 0
  %t742 = add i64 %t738, %t741
  %t743 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t744 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t745 = add i64 %t742, %t744
  %t746 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t747 = extractvalue { i64, ptr } %t746, 1
  %t748 = extractvalue { i64, ptr } %t746, 0
  %t749 = add i64 %t745, %t748
  %t750 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t751 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t752 = add i64 %t749, %t751
  %t753 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t754 = extractvalue { i64, ptr } %t753, 1
  %t755 = extractvalue { i64, ptr } %t753, 0
  %t756 = add i64 %t752, %t755
  %t757 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t758 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t759 = add i64 %t756, %t758
  %t760 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t759)
  call void @olang_textcopy(ptr %t760, ptr %t737, i64 %t738)
  %t761 = getelementptr i8, ptr %t760, i64 %t738
  call void @olang_textcopy(ptr %t761, ptr %t740, i64 %t741)
  %t762 = getelementptr i8, ptr %t761, i64 %t741
  call void @olang_textcopy(ptr %t762, ptr %t743, i64 %t744)
  %t763 = getelementptr i8, ptr %t762, i64 %t744
  call void @olang_textcopy(ptr %t763, ptr %t747, i64 %t748)
  %t764 = getelementptr i8, ptr %t763, i64 %t748
  call void @olang_textcopy(ptr %t764, ptr %t750, i64 %t751)
  %t765 = getelementptr i8, ptr %t764, i64 %t751
  call void @olang_textcopy(ptr %t765, ptr %t754, i64 %t755)
  %t766 = getelementptr i8, ptr %t765, i64 %t755
  call void @olang_textcopy(ptr %t766, ptr %t757, i64 %t758)
  %t767 = insertvalue { i64, ptr } undef, i64 %t759, 0
  %t768 = insertvalue { i64, ptr } %t767, ptr %t760, 1
  store { i64, ptr } %t768, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s27)
  br label %bb153
bb98:
  %t770 = load ptr, ptr %l1, !tbaa !29
  store ptr %t770, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t771 = load ptr, ptr %l217, !tbaa !29
  %t772 = icmp ne ptr %t771, null
  br i1 %t772, label %bb99, label %bb100
bb99:
  %t774 = load ptr, ptr %l217, !tbaa !29
  %t775 = load i64, ptr %t774, !range !{i64 0, i64 18}
  %t777 = icmp eq i64 %t775, 11
  store i1 %t777, ptr %l218, !tbaa !21
  br label %bb100
bb100:
  %t778 = load i1, ptr %l218, !tbaa !21
  br i1 %t778, label %bb101, label %bb102
bb101:
  %t779 = load ptr, ptr %l1, !tbaa !29
  %t781 = getelementptr { i64, [5 x i64] }, ptr %t779, i32 0, i32 1
  %t782 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t781, i32 0, i32 2
  %t783 = load ptr, ptr %t782
  store ptr %t783, ptr %l18, !tbaa !29
  br label %bb103
bb102:
  br label %bb107
bb103:
  store %olang.scope zeroinitializer, ptr %s29
  %t785 = load ptr, ptr %l0, !tbaa !29
  %t786 = load ptr, ptr %l18, !tbaa !29
  %t788 = getelementptr %"compiler/typed:Cond", ptr %t786, i32 0, i32 0
  %t789 = load ptr, ptr %t788, !tbaa !29
  %t793 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %v3, ptr %t785, ptr %t789)
  store { i64, ptr } %t793, ptr %l227
  br label %bb104
bb104:
  %t794 = load ptr, ptr %l0, !tbaa !29
  %t795 = load ptr, ptr %l18, !tbaa !29
  %t797 = getelementptr %"compiler/typed:Cond", ptr %t795, i32 0, i32 1
  %t798 = load ptr, ptr %t797, !tbaa !29
  %t801 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %v3, ptr %t794, ptr %t798)
  store { i64, ptr } %t801, ptr %l231
  br label %bb105
bb105:
  %t802 = load ptr, ptr %l0, !tbaa !29
  %t803 = load ptr, ptr %l18, !tbaa !29
  %t805 = getelementptr %"compiler/typed:Cond", ptr %t803, i32 0, i32 2
  %t806 = load ptr, ptr %t805, !tbaa !29
  %t810 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s29, ptr %v3, ptr %t802, ptr %t806)
  store { i64, ptr } %t810, ptr %l236
  br label %bb106
bb106:
  %t811 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t812 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t813 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t814 = extractvalue { i64, ptr } %t813, 1
  %t815 = extractvalue { i64, ptr } %t813, 0
  %t816 = add i64 %t812, %t815
  %t817 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t818 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t819 = add i64 %t816, %t818
  %t820 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t821 = extractvalue { i64, ptr } %t820, 1
  %t822 = extractvalue { i64, ptr } %t820, 0
  %t823 = add i64 %t819, %t822
  %t824 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t825 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t826 = add i64 %t823, %t825
  %t827 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t828 = extractvalue { i64, ptr } %t827, 1
  %t829 = extractvalue { i64, ptr } %t827, 0
  %t830 = add i64 %t826, %t829
  %t831 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t832 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t833 = add i64 %t830, %t832
  %t834 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t833)
  call void @olang_textcopy(ptr %t834, ptr %t811, i64 %t812)
  %t835 = getelementptr i8, ptr %t834, i64 %t812
  call void @olang_textcopy(ptr %t835, ptr %t814, i64 %t815)
  %t836 = getelementptr i8, ptr %t835, i64 %t815
  call void @olang_textcopy(ptr %t836, ptr %t817, i64 %t818)
  %t837 = getelementptr i8, ptr %t836, i64 %t818
  call void @olang_textcopy(ptr %t837, ptr %t821, i64 %t822)
  %t838 = getelementptr i8, ptr %t837, i64 %t822
  call void @olang_textcopy(ptr %t838, ptr %t824, i64 %t825)
  %t839 = getelementptr i8, ptr %t838, i64 %t825
  call void @olang_textcopy(ptr %t839, ptr %t828, i64 %t829)
  %t840 = getelementptr i8, ptr %t839, i64 %t829
  call void @olang_textcopy(ptr %t840, ptr %t831, i64 %t832)
  %t841 = insertvalue { i64, ptr } undef, i64 %t833, 0
  %t842 = insertvalue { i64, ptr } %t841, ptr %t834, 1
  store { i64, ptr } %t842, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s29)
  br label %bb153
bb107:
  %t844 = load ptr, ptr %l1, !tbaa !29
  store ptr %t844, ptr %l238, !tbaa !29
  store i1 false, ptr %l239, !tbaa !21
  %t845 = load ptr, ptr %l238, !tbaa !29
  %t846 = icmp ne ptr %t845, null
  br i1 %t846, label %bb108, label %bb109
bb108:
  %t848 = load ptr, ptr %l238, !tbaa !29
  %t849 = load i64, ptr %t848, !range !{i64 0, i64 18}
  %t851 = icmp eq i64 %t849, 12
  store i1 %t851, ptr %l239, !tbaa !21
  br label %bb109
bb109:
  %t852 = load i1, ptr %l239, !tbaa !21
  br i1 %t852, label %bb110, label %bb111
bb110:
  %t853 = load ptr, ptr %l1, !tbaa !29
  %t855 = getelementptr { i64, [5 x i64] }, ptr %t853, i32 0, i32 1
  %t856 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t855, i32 0, i32 2
  %t857 = load ptr, ptr %t856
  store ptr %t857, ptr %l19, !tbaa !29
  br label %bb112
bb111:
  br label %bb114
bb112:
  store %olang.scope zeroinitializer, ptr %s31
  %t859 = load ptr, ptr %l19, !tbaa !29
  %t861 = getelementptr %"compiler/typed:Seq", ptr %t859, i32 0, i32 0
  %t862 = load { i64, ptr }, ptr %t861, !tbaa !27
  %t864 = extractvalue { i64, ptr } %t862, 0
  store i64 %t864, ptr %l246, !tbaa !24
  %t865 = load ptr, ptr %l0, !tbaa !29
  %t866 = load ptr, ptr %l19, !tbaa !29
  %t868 = getelementptr %"compiler/typed:Seq", ptr %t866, i32 0, i32 1
  %t869 = load ptr, ptr %t868, !tbaa !29
  %t872 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s31, ptr %v3, ptr %t865, ptr %t869)
  store { i64, ptr } %t872, ptr %l250
  br label %bb113
bb113:
  %t873 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t874 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t875 = load i64, ptr %l246, !tbaa !24
  %t876 = call i64 @__olang_fmt_i64(ptr null, i64 %t875)
  %t877 = add i64 %t874, %t876
  %t878 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t879 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t880 = add i64 %t877, %t879
  %t881 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t882 = extractvalue { i64, ptr } %t881, 1
  %t883 = extractvalue { i64, ptr } %t881, 0
  %t884 = add i64 %t880, %t883
  %t885 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t886 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t887 = add i64 %t884, %t886
  %t888 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t887)
  call void @olang_textcopy(ptr %t888, ptr %t873, i64 %t874)
  %t889 = getelementptr i8, ptr %t888, i64 %t874
  %t890 = call i64 @__olang_fmt_i64(ptr %t889, i64 %t875)
  %t891 = getelementptr i8, ptr %t889, i64 %t876
  call void @olang_textcopy(ptr %t891, ptr %t878, i64 %t879)
  %t892 = getelementptr i8, ptr %t891, i64 %t879
  call void @olang_textcopy(ptr %t892, ptr %t882, i64 %t883)
  %t893 = getelementptr i8, ptr %t892, i64 %t883
  call void @olang_textcopy(ptr %t893, ptr %t885, i64 %t886)
  %t894 = insertvalue { i64, ptr } undef, i64 %t887, 0
  %t895 = insertvalue { i64, ptr } %t894, ptr %t888, 1
  store { i64, ptr } %t895, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s31)
  br label %bb153
bb114:
  %t897 = load ptr, ptr %l1, !tbaa !29
  store ptr %t897, ptr %l252, !tbaa !29
  store i1 false, ptr %l253, !tbaa !21
  %t898 = load ptr, ptr %l252, !tbaa !29
  %t899 = icmp ne ptr %t898, null
  br i1 %t899, label %bb115, label %bb116
bb115:
  %t901 = load ptr, ptr %l252, !tbaa !29
  %t902 = load i64, ptr %t901, !range !{i64 0, i64 18}
  %t904 = icmp eq i64 %t902, 13
  store i1 %t904, ptr %l253, !tbaa !21
  br label %bb116
bb116:
  %t905 = load i1, ptr %l253, !tbaa !21
  br i1 %t905, label %bb117, label %bb118
bb117:
  %t906 = load ptr, ptr %l1, !tbaa !29
  %t908 = getelementptr { i64, [5 x i64] }, ptr %t906, i32 0, i32 1
  %t909 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t908, i32 0, i32 2
  %t910 = load ptr, ptr %t909
  store ptr %t910, ptr %l20, !tbaa !29
  br label %bb119
bb118:
  br label %bb126
bb119:
  %t912 = load ptr, ptr %l20, !tbaa !29
  %t914 = getelementptr %"compiler/typed:Match", ptr %t912, i32 0, i32 1
  %t915 = load { i64, ptr }, ptr %t914, !tbaa !27
  %t917 = extractvalue { i64, ptr } %t915, 0
  store i64 %t917, ptr %l260, !tbaa !24
  %t918 = load ptr, ptr %l20, !tbaa !29
  %t920 = getelementptr %"compiler/typed:Match", ptr %t918, i32 0, i32 2
  %t921 = load ptr, ptr %t920, !tbaa !29
  %t923 = icmp eq ptr %t921, null
  br i1 %t923, label %bb120, label %bb121
bb120:
  call void @__olang_check_failed(ptr @olang_loc_a4fa64762613be8a_d12da9b666f393e6)
  unreachable
bb121:
  br label %bb122
bb122:
  %t925 = load ptr, ptr %l20, !tbaa !29
  %t927 = getelementptr %"compiler/typed:Match", ptr %t925, i32 0, i32 2
  %t928 = load ptr, ptr %t927, !tbaa !29
  %t931 = getelementptr %"compiler/typed:Arm", ptr %t928, i32 0, i32 3
  %t932 = load ptr, ptr %t931, !tbaa !29
  store ptr %t932, ptr %l21, !tbaa !29
  %t934 = load ptr, ptr %l21, !tbaa !29
  %t936 = icmp eq ptr %t934, null
  br i1 %t936, label %bb123, label %bb124
bb123:
  call void @__olang_check_failed(ptr @olang_loc_a4fa64762613be8a_d12da9b666f393e6)
  unreachable
bb124:
  br label %bb125
bb125:
  %t938 = load ptr, ptr %l21, !tbaa !29
  %t941 = getelementptr %"compiler/typed:Block", ptr %t938, i32 0, i32 1
  %t942 = load { i64, ptr }, ptr %t941, !tbaa !27
  %t944 = extractvalue { i64, ptr } %t942, 0
  %t945 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t946 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t947 = load i64, ptr %l260, !tbaa !24
  %t948 = call i64 @__olang_fmt_i64(ptr null, i64 %t947)
  %t949 = add i64 %t946, %t948
  %t950 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t951 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t952 = add i64 %t949, %t951
  %t954 = call i64 @__olang_fmt_i64(ptr null, i64 %t944)
  %t955 = add i64 %t952, %t954
  %t956 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t957 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t958 = add i64 %t955, %t957
  %t959 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t958)
  call void @olang_textcopy(ptr %t959, ptr %t945, i64 %t946)
  %t960 = getelementptr i8, ptr %t959, i64 %t946
  %t961 = call i64 @__olang_fmt_i64(ptr %t960, i64 %t947)
  %t962 = getelementptr i8, ptr %t960, i64 %t948
  call void @olang_textcopy(ptr %t962, ptr %t950, i64 %t951)
  %t963 = getelementptr i8, ptr %t962, i64 %t951
  %t964 = call i64 @__olang_fmt_i64(ptr %t963, i64 %t944)
  %t965 = getelementptr i8, ptr %t963, i64 %t954
  call void @olang_textcopy(ptr %t965, ptr %t956, i64 %t957)
  %t966 = insertvalue { i64, ptr } undef, i64 %t958, 0
  %t967 = insertvalue { i64, ptr } %t966, ptr %t959, 1
  store { i64, ptr } %t967, ptr %l39, !tbaa !27
  br label %bb153
bb126:
  %t969 = load ptr, ptr %l1, !tbaa !29
  store ptr %t969, ptr %l275, !tbaa !29
  store i1 false, ptr %l276, !tbaa !21
  %t970 = load ptr, ptr %l275, !tbaa !29
  %t971 = icmp ne ptr %t970, null
  br i1 %t971, label %bb127, label %bb128
bb127:
  %t973 = load ptr, ptr %l275, !tbaa !29
  %t974 = load i64, ptr %t973, !range !{i64 0, i64 18}
  %t976 = icmp eq i64 %t974, 14
  store i1 %t976, ptr %l276, !tbaa !21
  br label %bb128
bb128:
  %t977 = load i1, ptr %l276, !tbaa !21
  br i1 %t977, label %bb129, label %bb130
bb129:
  %t978 = load ptr, ptr %l1, !tbaa !29
  %t980 = getelementptr { i64, [5 x i64] }, ptr %t978, i32 0, i32 1
  %t981 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t980, i32 0, i32 2
  %t982 = load ptr, ptr %t981
  store ptr %t982, ptr %l22, !tbaa !29
  br label %bb131
bb130:
  br label %bb133
bb131:
  store %olang.scope zeroinitializer, ptr %s35
  %t984 = load ptr, ptr %l0, !tbaa !29
  %t985 = load ptr, ptr %l22, !tbaa !29
  %t987 = getelementptr %"compiler/typed:Try", ptr %t985, i32 0, i32 0
  %t988 = load ptr, ptr %t987, !tbaa !29
  %t991 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s35, ptr %v3, ptr %t984, ptr %t988)
  store { i64, ptr } %t991, ptr %l284
  br label %bb132
bb132:
  %t992 = load ptr, ptr %l22, !tbaa !29
  %t994 = getelementptr %"compiler/typed:Try", ptr %t992, i32 0, i32 1
  %t995 = load { i64, ptr }, ptr %t994, !tbaa !27
  %t997 = extractvalue { i64, ptr } %t995, 0
  %t998 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t999 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t1000 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t1001 = extractvalue { i64, ptr } %t1000, 1
  %t1002 = extractvalue { i64, ptr } %t1000, 0
  %t1003 = add i64 %t999, %t1002
  %t1004 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t1005 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t1006 = add i64 %t1003, %t1005
  %t1008 = call i64 @__olang_fmt_i64(ptr null, i64 %t997)
  %t1009 = add i64 %t1006, %t1008
  %t1010 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t1011 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t1012 = add i64 %t1009, %t1011
  %t1013 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1012)
  call void @olang_textcopy(ptr %t1013, ptr %t998, i64 %t999)
  %t1014 = getelementptr i8, ptr %t1013, i64 %t999
  call void @olang_textcopy(ptr %t1014, ptr %t1001, i64 %t1002)
  %t1015 = getelementptr i8, ptr %t1014, i64 %t1002
  call void @olang_textcopy(ptr %t1015, ptr %t1004, i64 %t1005)
  %t1016 = getelementptr i8, ptr %t1015, i64 %t1005
  %t1017 = call i64 @__olang_fmt_i64(ptr %t1016, i64 %t997)
  %t1018 = getelementptr i8, ptr %t1016, i64 %t1008
  call void @olang_textcopy(ptr %t1018, ptr %t1010, i64 %t1011)
  %t1019 = insertvalue { i64, ptr } undef, i64 %t1012, 0
  %t1020 = insertvalue { i64, ptr } %t1019, ptr %t1013, 1
  store { i64, ptr } %t1020, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s35)
  br label %bb153
bb133:
  %t1022 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1022, ptr %l289, !tbaa !29
  store i1 false, ptr %l290, !tbaa !21
  %t1023 = load ptr, ptr %l289, !tbaa !29
  %t1024 = icmp ne ptr %t1023, null
  br i1 %t1024, label %bb134, label %bb135
bb134:
  %t1026 = load ptr, ptr %l289, !tbaa !29
  %t1027 = load i64, ptr %t1026, !range !{i64 0, i64 18}
  %t1029 = icmp eq i64 %t1027, 15
  store i1 %t1029, ptr %l290, !tbaa !21
  br label %bb135
bb135:
  %t1030 = load i1, ptr %l290, !tbaa !21
  br i1 %t1030, label %bb136, label %bb137
bb136:
  br label %bb138
bb137:
  br label %bb139
bb138:
  %t1031 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1032 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t1033 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t1035 = extractvalue { i64, ptr } %t1031, 1
  %t1036 = extractvalue { i64, ptr } %t1031, 0
  %t1037 = add i64 %t1033, %t1036
  %t1038 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t1039 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t1040 = add i64 %t1037, %t1039
  %t1041 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1040)
  call void @olang_textcopy(ptr %t1041, ptr %t1032, i64 %t1033)
  %t1042 = getelementptr i8, ptr %t1041, i64 %t1033
  call void @olang_textcopy(ptr %t1042, ptr %t1035, i64 %t1036)
  %t1043 = getelementptr i8, ptr %t1042, i64 %t1036
  call void @olang_textcopy(ptr %t1043, ptr %t1038, i64 %t1039)
  %t1044 = insertvalue { i64, ptr } undef, i64 %t1040, 0
  %t1045 = insertvalue { i64, ptr } %t1044, ptr %t1041, 1
  store { i64, ptr } %t1045, ptr %l39, !tbaa !27
  br label %bb153
bb139:
  %t1047 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1047, ptr %l295, !tbaa !29
  store i1 false, ptr %l296, !tbaa !21
  %t1048 = load ptr, ptr %l295, !tbaa !29
  %t1049 = icmp ne ptr %t1048, null
  br i1 %t1049, label %bb140, label %bb141
bb140:
  %t1051 = load ptr, ptr %l295, !tbaa !29
  %t1052 = load i64, ptr %t1051, !range !{i64 0, i64 18}
  %t1054 = icmp eq i64 %t1052, 16
  store i1 %t1054, ptr %l296, !tbaa !21
  br label %bb141
bb141:
  %t1055 = load i1, ptr %l296, !tbaa !21
  br i1 %t1055, label %bb142, label %bb143
bb142:
  %t1056 = load ptr, ptr %l1, !tbaa !29
  %t1058 = getelementptr { i64, [5 x i64] }, ptr %t1056, i32 0, i32 1
  %t1059 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1058, i32 0, i32 2
  %t1060 = load ptr, ptr %t1059
  store ptr %t1060, ptr %l23, !tbaa !29
  br label %bb144
bb143:
  br label %bb145
bb144:
  %t1062 = load ptr, ptr %l23, !tbaa !29
  %t1064 = getelementptr %"compiler/typed:Text", ptr %t1062, i32 0, i32 0
  %t1065 = load { i64, ptr }, ptr %t1064, !tbaa !27
  %t1067 = extractvalue { i64, ptr } %t1065, 0
  %t1068 = load ptr, ptr %l23, !tbaa !29
  %t1070 = getelementptr %"compiler/typed:Text", ptr %t1068, i32 0, i32 1
  %t1071 = load i32, ptr %t1070, !tbaa !23
  %t1072 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t1073 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t1075 = call i64 @__olang_fmt_i64(ptr null, i64 %t1067)
  %t1076 = add i64 %t1073, %t1075
  %t1077 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t1078 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t1079 = add i64 %t1076, %t1078
  %t1081 = sext i32 %t1071 to i64
  %t1082 = call i64 @__olang_fmt_i64(ptr null, i64 %t1081)
  %t1083 = add i64 %t1079, %t1082
  %t1084 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t1085 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t1086 = add i64 %t1083, %t1085
  %t1087 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1086)
  call void @olang_textcopy(ptr %t1087, ptr %t1072, i64 %t1073)
  %t1088 = getelementptr i8, ptr %t1087, i64 %t1073
  %t1089 = call i64 @__olang_fmt_i64(ptr %t1088, i64 %t1067)
  %t1090 = getelementptr i8, ptr %t1088, i64 %t1075
  call void @olang_textcopy(ptr %t1090, ptr %t1077, i64 %t1078)
  %t1091 = getelementptr i8, ptr %t1090, i64 %t1078
  %t1092 = call i64 @__olang_fmt_i64(ptr %t1091, i64 %t1081)
  %t1093 = getelementptr i8, ptr %t1091, i64 %t1082
  call void @olang_textcopy(ptr %t1093, ptr %t1084, i64 %t1085)
  %t1094 = insertvalue { i64, ptr } undef, i64 %t1086, 0
  %t1095 = insertvalue { i64, ptr } %t1094, ptr %t1087, 1
  store { i64, ptr } %t1095, ptr %l39, !tbaa !27
  br label %bb153
bb145:
  %t1097 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1097, ptr %l307, !tbaa !29
  store i1 false, ptr %l308, !tbaa !21
  %t1098 = load ptr, ptr %l307, !tbaa !29
  %t1099 = icmp ne ptr %t1098, null
  br i1 %t1099, label %bb146, label %bb147
bb146:
  %t1101 = load ptr, ptr %l307, !tbaa !29
  %t1102 = load i64, ptr %t1101, !range !{i64 0, i64 18}
  %t1104 = icmp eq i64 %t1102, 17
  store i1 %t1104, ptr %l308, !tbaa !21
  br label %bb147
bb147:
  %t1105 = load i1, ptr %l308, !tbaa !21
  br i1 %t1105, label %bb148, label %bb149
bb148:
  %t1106 = load ptr, ptr %l1, !tbaa !29
  %t1108 = getelementptr { i64, [5 x i64] }, ptr %t1106, i32 0, i32 1
  %t1109 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1108, i32 0, i32 1
  %t1110 = load i64, ptr %t1109
  store i64 %t1110, ptr %l24, !tbaa !24
  %t1112 = load ptr, ptr %l1, !tbaa !29
  %t1114 = getelementptr { i64, [5 x i64] }, ptr %t1112, i32 0, i32 1
  %t1115 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1114, i32 0, i32 2
  %t1116 = load ptr, ptr %t1115
  store ptr %t1116, ptr %l25, !tbaa !29
  br label %bb150
bb149:
  br label %bb152
bb150:
  store %olang.scope zeroinitializer, ptr %s41
  %t1118 = load i64, ptr %l24, !tbaa !24
  store i64 %t1118, ptr %l315, !tbaa !24
  %t1119 = load ptr, ptr %l0, !tbaa !29
  %t1120 = load ptr, ptr %l25, !tbaa !29
  %t1124 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s41, ptr %v3, ptr %t1119, ptr %t1120)
  store { i64, ptr } %t1124, ptr %l319
  br label %bb151
bb151:
  %t1125 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t1126 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t1127 = load i64, ptr %l315, !tbaa !24
  %t1128 = call i64 @__olang_fmt_i64(ptr null, i64 %t1127)
  %t1129 = add i64 %t1126, %t1128
  %t1130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t1131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t1132 = add i64 %t1129, %t1131
  %t1133 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t1134 = extractvalue { i64, ptr } %t1133, 1
  %t1135 = extractvalue { i64, ptr } %t1133, 0
  %t1136 = add i64 %t1132, %t1135
  %t1137 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t1138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t1139 = add i64 %t1136, %t1138
  %t1140 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1139)
  call void @olang_textcopy(ptr %t1140, ptr %t1125, i64 %t1126)
  %t1141 = getelementptr i8, ptr %t1140, i64 %t1126
  %t1142 = call i64 @__olang_fmt_i64(ptr %t1141, i64 %t1127)
  %t1143 = getelementptr i8, ptr %t1141, i64 %t1128
  call void @olang_textcopy(ptr %t1143, ptr %t1130, i64 %t1131)
  %t1144 = getelementptr i8, ptr %t1143, i64 %t1131
  call void @olang_textcopy(ptr %t1144, ptr %t1134, i64 %t1135)
  %t1145 = getelementptr i8, ptr %t1144, i64 %t1135
  call void @olang_textcopy(ptr %t1145, ptr %t1137, i64 %t1138)
  %t1146 = insertvalue { i64, ptr } undef, i64 %t1139, 0
  %t1147 = insertvalue { i64, ptr } %t1146, ptr %t1140, 1
  store { i64, ptr } %t1147, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s41)
  br label %bb153
bb152:
  call void @__olang_check_failed(ptr @olang_loc_a387a9465b9f2118_49b9af8105801174)
  unreachable
bb153:
  call void @__olang_scope_close(ptr %s0)
  %t1149 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t1149, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i1
  %l65 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca i1
  %l81 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca i1
  %l96 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l103 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t20 = sext i32 %t16 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t20)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  br label %bb55
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 1
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t46, i32 0, i32 3
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l4, !tbaa !23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i32, ptr %l4, !tbaa !23
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t55 = call i64 @__olang_fmt_i64(ptr null, i64 %t50)
  %t56 = add i64 %t53, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t61 = sext i32 %t51 to i64
  %t62 = call i64 @__olang_fmt_i64(ptr null, i64 %t61)
  %t63 = add i64 %t59, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t52, i64 %t53)
  %t65 = getelementptr i8, ptr %t64, i64 %t53
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t50)
  %t67 = getelementptr i8, ptr %t65, i64 %t55
  call void @olang_textcopy(ptr %t67, ptr %t57, i64 %t58)
  %t68 = getelementptr i8, ptr %t67, i64 %t58
  %t69 = call i64 @__olang_fmt_i64(ptr %t68, i64 %t61)
  %t70 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t64, 1
  store { i64, ptr } %t71, ptr %l12, !tbaa !27
  br label %bb55
bb12:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t74 = load ptr, ptr %l32, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb13, label %bb14
bb13:
  %t77 = load ptr, ptr %l32, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 8}
  %t80 = icmp eq i64 %t78, 2
  store i1 %t80, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t81 = load i1, ptr %l33, !tbaa !21
  br i1 %t81, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t93 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %v3, ptr %t88, ptr %t89)
  store { i64, ptr } %t93, ptr %l41
  br label %bb18
bb18:
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t96 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = add i64 %t95, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t94, i64 %t95)
  %t101 = getelementptr i8, ptr %t100, i64 %t95
  call void @olang_textcopy(ptr %t101, ptr %t97, i64 %t98)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  store { i64, ptr } %t103, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb19:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t106 = load ptr, ptr %l43, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb20, label %bb21
bb20:
  %t109 = load ptr, ptr %l43, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 8}
  %t112 = icmp eq i64 %t110, 3
  store i1 %t112, ptr %l44, !tbaa !21
  br label %bb21
bb21:
  %t113 = load i1, ptr %l44, !tbaa !21
  br i1 %t113, label %bb22, label %bb23
bb22:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t116, i32 0, i32 2
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l6, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t122, i32 0, i32 3
  %t124 = load i64, ptr %t123
  store i64 %t124, ptr %l7, !tbaa !24
  br label %bb24
bb23:
  br label %bb26
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t130 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s7, ptr %v3, ptr %t126, ptr %t127)
  store { i64, ptr } %t130, ptr %l53
  br label %bb25
bb25:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t139 = call i64 @__olang_fmt_i64(ptr null, i64 %t131)
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t133, i64 %t134)
  %t142 = getelementptr i8, ptr %t141, i64 %t134
  call void @olang_textcopy(ptr %t142, ptr %t135, i64 %t136)
  %t143 = getelementptr i8, ptr %t142, i64 %t136
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t131)
  %t145 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t141, 1
  store { i64, ptr } %t146, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb26:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t149 = load ptr, ptr %l56, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb27, label %bb28
bb27:
  %t152 = load ptr, ptr %l56, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 8}
  %t155 = icmp eq i64 %t153, 4
  store i1 %t155, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t156 = load i1, ptr %l57, !tbaa !21
  br i1 %t156, label %bb29, label %bb30
bb29:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t159, i32 0, i32 2
  %t161 = load ptr, ptr %t160
  store ptr %t161, ptr %l8, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l8, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Elem", ptr %t164, i32 0, i32 0
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t170 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s9, ptr %v3, ptr %t163, ptr %t167)
  store { i64, ptr } %t170, ptr %l65
  br label %bb32
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l8, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Elem", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t179 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %v3, ptr %t171, ptr %t175)
  store { i64, ptr } %t179, ptr %l70
  br label %bb33
bb33:
  %t180 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t185 = add i64 %t182, %t184
  %t186 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t181, i64 %t182)
  %t194 = getelementptr i8, ptr %t193, i64 %t182
  call void @olang_textcopy(ptr %t194, ptr %t183, i64 %t184)
  %t195 = getelementptr i8, ptr %t194, i64 %t184
  call void @olang_textcopy(ptr %t195, ptr %t187, i64 %t188)
  %t196 = getelementptr i8, ptr %t195, i64 %t188
  call void @olang_textcopy(ptr %t196, ptr %t190, i64 %t191)
  %t197 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t193, 1
  store { i64, ptr } %t198, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb34:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t201 = load ptr, ptr %l72, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb35, label %bb36
bb35:
  %t204 = load ptr, ptr %l72, !tbaa !29
  %t205 = load i64, ptr %t204, !range !{i64 0, i64 8}
  %t207 = icmp eq i64 %t205, 5
  store i1 %t207, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t208 = load i1, ptr %l73, !tbaa !21
  br i1 %t208, label %bb37, label %bb38
bb37:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [4 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 2
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l9, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l9, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Payload", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t222 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s11, ptr %v3, ptr %t215, ptr %t219)
  store { i64, ptr } %t222, ptr %l81
  br label %bb40
bb40:
  %t223 = load ptr, ptr %l9, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Payload", ptr %t223, i32 0, i32 1
  %t226 = load i64, ptr %t225, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t234 = call i64 @__olang_fmt_i64(ptr null, i64 %t226)
  %t235 = add i64 %t232, %t234
  %t236 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t228, i64 %t229)
  %t237 = getelementptr i8, ptr %t236, i64 %t229
  call void @olang_textcopy(ptr %t237, ptr %t230, i64 %t231)
  %t238 = getelementptr i8, ptr %t237, i64 %t231
  %t239 = call i64 @__olang_fmt_i64(ptr %t238, i64 %t226)
  %t240 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t236, 1
  store { i64, ptr } %t241, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb41:
  %t243 = load ptr, ptr %l1, !tbaa !29
  store ptr %t243, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t244 = load ptr, ptr %l85, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb42, label %bb43
bb42:
  %t247 = load ptr, ptr %l85, !tbaa !29
  %t248 = load i64, ptr %t247, !range !{i64 0, i64 8}
  %t250 = icmp eq i64 %t248, 6
  store i1 %t250, ptr %l86, !tbaa !21
  br label %bb43
bb43:
  %t251 = load i1, ptr %l86, !tbaa !21
  br i1 %t251, label %bb44, label %bb45
bb44:
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t254, i32 0, i32 2
  %t256 = load ptr, ptr %t255
  store ptr %t256, ptr %l10, !tbaa !29
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t260, i32 0, i32 3
  %t262 = load i32, ptr %t261
  store i32 %t262, ptr %l11, !tbaa !23
  br label %bb46
bb45:
  br label %bb48
bb46:
  store %olang.scope zeroinitializer, ptr %s13
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l10, !tbaa !29
  %t269 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s13, ptr %v3, ptr %t264, ptr %t265)
  store { i64, ptr } %t269, ptr %l96
  br label %bb47
bb47:
  %t270 = load i32, ptr %l11, !tbaa !23
  %t271 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t272 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t273 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = add i64 %t272, %t275
  %t277 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t279 = add i64 %t276, %t278
  %t281 = sext i32 %t270 to i64
  %t282 = call i64 @__olang_fmt_i64(ptr null, i64 %t281)
  %t283 = add i64 %t279, %t282
  %t284 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t283)
  call void @olang_textcopy(ptr %t284, ptr %t271, i64 %t272)
  %t285 = getelementptr i8, ptr %t284, i64 %t272
  call void @olang_textcopy(ptr %t285, ptr %t274, i64 %t275)
  %t286 = getelementptr i8, ptr %t285, i64 %t275
  call void @olang_textcopy(ptr %t286, ptr %t277, i64 %t278)
  %t287 = getelementptr i8, ptr %t286, i64 %t278
  %t288 = call i64 @__olang_fmt_i64(ptr %t287, i64 %t281)
  %t289 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t284, 1
  store { i64, ptr } %t290, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb55
bb48:
  %t292 = load ptr, ptr %l1, !tbaa !29
  store ptr %t292, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t293 = load ptr, ptr %l99, !tbaa !29
  %t294 = icmp ne ptr %t293, null
  br i1 %t294, label %bb49, label %bb50
bb49:
  %t296 = load ptr, ptr %l99, !tbaa !29
  %t297 = load i64, ptr %t296, !range !{i64 0, i64 8}
  %t299 = icmp eq i64 %t297, 7
  store i1 %t299, ptr %l100, !tbaa !21
  br label %bb50
bb50:
  %t300 = load i1, ptr %l100, !tbaa !21
  br i1 %t300, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t301, ptr %l12, !tbaa !27
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_16612f18a9afa54d_299c1e15a68a5059)
  unreachable
bb55:
  %t303 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  store i64 %t304, ptr %l105, !tbaa !24
  %t305 = load i64, ptr %l105, !tbaa !24
  %t306 = mul i64 %t305, 1
  %t307 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t306)
  %t308 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  store { i64, ptr } %t309, ptr %l106, !tbaa !27
  %t310 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = load i64, ptr %l105, !tbaa !24
  %t315 = mul i64 %t314, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t311, ptr %t313, i64 %t315, i1 false)
  %t316 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t316, ptr %l12, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t317, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2econstText(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13
  store i64 %t14, ptr %l1, !tbaa !24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = call i64 @__olang_fmt_i64(ptr null, i64 %t16)
  %t19 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t18)
  %t20 = call i64 @__olang_fmt_i64(ptr %t19, i64 %t16)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t19, 1
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  br label %bb20
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l13, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 3}
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l14, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr } }, ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l2, !tbaa !27
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t45 = call i64 @__olang_fmt_i64(ptr null, i64 %t41)
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = getelementptr i8, ptr %t47, i64 %t43
  %t49 = call i64 @__olang_fmt_i64(ptr %t48, i64 %t41)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t47, 1
  store { i64, ptr } %t51, ptr %l4, !tbaa !27
  br label %bb20
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t54 = load ptr, ptr %l22, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l22, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 3}
  %t60 = icmp eq i64 %t58, 2
  store i1 %t60, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t61 = load i1, ptr %l23, !tbaa !21
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { { i64, ptr } }, ptr %t64, i32 0, i32 0
  %t66 = load { i64, ptr }, ptr %t65
  store { i64, ptr } %t66, ptr %l3, !tbaa !27
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = call { i64, ptr } @compiler_2ftyped_2econstItems(ptr %v0, ptr %v1, { i64, ptr } %t68)
  store { i64, ptr } %t70, ptr %l29
  br label %bb18
bb18:
  %t71 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t71, ptr %l4, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_411550143d3b0e9d_42067e02948bd729)
  unreachable
bb20:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ftyped_2ecopySite(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %l20 = alloca { i64, ptr }
  %l22 = alloca i64
  %l24 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l35 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 4 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Make", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l13, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Make", ptr %t34, i32 0, i32 2
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l20, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 0
  %t41 = load ptr, ptr %t40, !tbaa !39
  %t43 = call i64 @compiler_2ftyped_2ewholeLocal(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l22
  br label %bb11
bb10:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb12
bb11:
  %t44 = load i64, ptr %l22, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  store i1 %t45, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l18, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Make", ptr %t48, i32 0, i32 4
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = sext i32 %t51 to i64
  store i64 %t53, ptr %l24, !tbaa !24
  br label %bb15
bb14:
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb15
bb15:
  %t55 = load i64, ptr %l24, !tbaa !24
  store i64 %t55, ptr %l3, !tbaa !24
  br label %bb28
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 18}
  %t63 = icmp eq i64 %t61, 17
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t64 = load i1, ptr %l29, !tbaa !21
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l2, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = call i64 @compiler_2ftyped_2ecopySite(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l35
  br label %bb22
bb22:
  %t74 = load i64, ptr %l35, !tbaa !24
  store i64 %t74, ptr %l3, !tbaa !24
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_c89b2ac703a55b51_f16b1206186d62d)
  unreachable
bb28:
  %t75 = load i64, ptr %l3, !tbaa !24
  store i64 %t75, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2edefName(i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = mul i64 %a0, 1048576
  %t7 = add i64 %t3, %a1
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2einert(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb30
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb12, label %bb13
bb12:
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 8}
  %t32 = icmp eq i64 %t30, 0
  store i1 %t32, ptr %l16, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l16, !tbaa !21
  store i1 %t33, ptr %l4, !tbaa !21
  br label %bb30
bb14:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb15, label %bb16
bb15:
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 18}
  %t41 = icmp eq i64 %t39, 9
  store i1 %t41, ptr %l20, !tbaa !21
  br label %bb16
bb16:
  %t42 = load i1, ptr %l20, !tbaa !21
  br i1 %t42, label %bb17, label %bb18
bb17:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t45, i32 0, i32 2
  %t47 = load i32, ptr %t46, !range !{i32 0, i32 51}
  store i32 %t47, ptr %l2
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t51, i32 0, i32 4
  %t53 = load { i64, ptr }, ptr %t52
  store { i64, ptr } %t53, ptr %l3, !tbaa !27
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t55 = load i32, ptr %l2, !range !{i32 0, i32 51}
  %t57 = call i1 @compiler_2ftyped_2estoresNothing(i32 %t55)
  store i1 %t57, ptr %l28
  br label %bb20
bb20:
  %t58 = load i1, ptr %l28, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = call i1 @compiler_2ftyped_2eallInert(ptr %v0, { i64, ptr } %t59)
  store i1 %t61, ptr %l31
  br label %bb23
bb22:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb24
bb23:
  %t62 = load i1, ptr %l31, !tbaa !21
  store i1 %t62, ptr %l29, !tbaa !21
  br label %bb24
bb24:
  %t63 = load i1, ptr %l29, !tbaa !21
  store i1 %t63, ptr %l4, !tbaa !21
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_3f2c6ecf541578c9_647b3946439e894d)
  unreachable
bb30:
  %t64 = load i1, ptr %l4, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2emayHold(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l16 = alloca i1
  %l20 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l45 = alloca ptr
  %l48 = alloca i32
  %l51 = alloca i1
  %l54 = alloca i1
  %l57 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l75 = alloca i1
  %l83 = alloca i1
  %l86 = alloca i1
  %l89 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca i32
  %l97 = alloca i1
  %l102 = alloca ptr
  %l105 = alloca i32
  %l108 = alloca i32
  %l111 = alloca i32
  %l112 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l124 = alloca i1
  %l130 = alloca i1
  %l135 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2ftyped_2escalarType(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i1, ptr %l16, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l20
  br label %bb5
bb5:
  %t13 = load i32, ptr %l20, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l3, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l23
  br label %bb6
bb6:
  %t19 = load i32, ptr %l23, !range !{i32 0, i32 33}
  store i32 %t19, ptr %l4
  %t20 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t22 = trunc i64 1 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb9
bb8:
  %t25 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t27 = trunc i64 17 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l26, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sgt i64 %t32, 8
  br i1 %t34, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb15
bb14:
  %t36 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t38 = trunc i64 20 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t41 = load i1, ptr %l32, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb22
bb17:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l38
  br label %bb18
bb18:
  %t47 = load i1, ptr %l38, !tbaa !21
  br i1 %t47, label %bb19, label %bb20
bb19:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  store i1 %t50, ptr %l39, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t52 = load i1, ptr %l39, !tbaa !21
  store i1 %t52, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t53 = load i1, ptr %l35, !tbaa !21
  br i1 %t53, label %bb23, label %bb24
bb23:
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t55 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t57 = trunc i64 19 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb26, label %bb27
bb26:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l45, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l3, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l48
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t68 = add i64 %t66, 1
  %t69 = load ptr, ptr %l45, !tbaa !29
  %t70 = load i32, ptr %l48, !tbaa !23
  %t72 = call i1 @compiler_2ftyped_2emayHold(ptr %v0, ptr %t69, i32 %t70, i64 %t68)
  store i1 %t72, ptr %l51
  br label %bb29
bb29:
  %t73 = load i1, ptr %l51, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
bb30:
  %t74 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t76 = trunc i64 22 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb33
bb32:
  %t79 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t81 = trunc i64 23 to i32
  %t82 = icmp eq i32 %t79, %t81
  store i1 %t82, ptr %l54, !tbaa !21
  br label %bb33
bb33:
  %t84 = load i1, ptr %l54, !tbaa !21
  br i1 %t84, label %bb34, label %bb35
bb34:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l57, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t86, i32 %t87)
  store i32 %t90, ptr %l60
  br label %bb36
bb35:
  br label %bb48
bb36:
  %t91 = load ptr, ptr %l57, !tbaa !29
  %t92 = load i32, ptr %l60, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t91, i32 %t92)
  store { i64, ptr } %t93, ptr %l61
  br label %bb37
bb37:
  %t94 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t94, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  store i64 %t97, ptr %l7, !tbaa !24
  br label %bb38
bb38:
  %t99 = load i64, ptr %l6, !tbaa !24
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb39, label %bb40
bb39:
  br label %bb47
bb40:
  br label %bb41
bb41:
  %t107 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t107, ptr %l68, !tbaa !27
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 %t108
  %t113 = load i32, ptr %t112, !tbaa !33
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i64, ptr %l2, !tbaa !24
  %t119 = add i64 %t117, 1
  %t123 = call i1 @compiler_2ftyped_2emayHold(ptr %v0, ptr %t115, i32 %t113, i64 %t119)
  store i1 %t123, ptr %l75
  br label %bb42
bb42:
  %t124 = load i1, ptr %l75, !tbaa !21
  br i1 %t124, label %bb43, label %bb44
bb43:
  store i1 true, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t126 = load i64, ptr %l6, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l6, !tbaa !24
  br label %bb38
bb47:
  store i1 false, ptr %rv
  br label %ret
bb48:
  %t131 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t133 = trunc i64 18 to i32
  %t134 = icmp eq i32 %t131, %t133
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb52
bb50:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l3, !tbaa !23
  %t142 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t138, i32 %t139)
  store i1 %t142, ptr %l86
  br label %bb51
bb51:
  %t143 = load i1, ptr %l86, !tbaa !21
  %t144 = xor i1 %t143, true
  store i1 %t144, ptr %l83, !tbaa !21
  br label %bb52
bb52:
  %t146 = load i1, ptr %l83, !tbaa !21
  br i1 %t146, label %bb53, label %bb54
bb53:
  store i1 true, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l89, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l3, !tbaa !23
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t153, ptr %l92
  br label %bb56
bb56:
  %t154 = load ptr, ptr %l89, !tbaa !29
  %t155 = load i32, ptr %l92, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t156, ptr %l93
  br label %bb57
bb57:
  %t157 = load i32, ptr %l93, !range !{i32 0, i32 6}
  store i32 %t157, ptr %l9
  %t158 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t160 = trunc i64 0 to i32
  %t161 = icmp eq i32 %t158, %t160
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb58, label %bb59
bb58:
  %t165 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t167 = trunc i64 1 to i32
  %t168 = icmp eq i32 %t165, %t167
  %t170 = xor i1 %t168, true
  store i1 %t170, ptr %l97, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb60
bb60:
  %t172 = load i1, ptr %l97, !tbaa !21
  br i1 %t172, label %bb61, label %bb62
bb61:
  store i1 true, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l102, !tbaa !29
  %t175 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t177 = trunc i64 1 to i32
  %t178 = icmp eq i32 %t175, %t177
  br i1 %t178, label %bb64, label %bb65
bb64:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i32, ptr %l3, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t180, i32 %t181)
  store i32 %t184, ptr %l108
  br label %bb66
bb65:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l3, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l111
  br label %bb67
bb66:
  %t190 = load i32, ptr %l108, !tbaa !23
  store i32 %t190, ptr %l105, !tbaa !23
  br label %bb68
bb67:
  %t191 = load i32, ptr %l111, !tbaa !23
  store i32 %t191, ptr %l105, !tbaa !23
  br label %bb68
bb68:
  %t192 = load ptr, ptr %l102, !tbaa !29
  %t193 = load i32, ptr %l105, !tbaa !23
  %t194 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t192, i32 %t193)
  store { i64, ptr } %t194, ptr %l112
  br label %bb69
bb69:
  %t195 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t195, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  store i64 %t198, ptr %l12, !tbaa !24
  br label %bb70
bb70:
  %t200 = load i64, ptr %l11, !tbaa !24
  %t201 = load i64, ptr %l12, !tbaa !24
  %t204 = icmp slt i64 %t200, %t201
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb71, label %bb72
bb71:
  br label %bb88
bb72:
  br label %bb73
bb73:
  %t208 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t208, ptr %l119, !tbaa !27
  %t209 = load i64, ptr %l11, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr i32, ptr %t212, i64 %t209
  %t214 = load i32, ptr %t213, !tbaa !33
  store i32 %t214, ptr %l13, !tbaa !23
  %t216 = load i32, ptr %l13, !tbaa !23
  %t218 = icmp eq i32 %t216, 0
  br i1 %t218, label %bb74, label %bb75
bb74:
  %t220 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t222 = trunc i64 0 to i32
  %t223 = icmp eq i32 %t220, %t222
  store i1 %t223, ptr %l124, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb76
bb76:
  %t225 = load i1, ptr %l124, !tbaa !21
  br i1 %t225, label %bb77, label %bb78
bb77:
  store i1 true, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t227 = load i32, ptr %l13, !tbaa !23
  %t229 = icmp ne i32 %t227, 0
  br i1 %t229, label %bb80, label %bb81
bb80:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load i32, ptr %l13, !tbaa !23
  %t233 = load i64, ptr %l2, !tbaa !24
  %t235 = add i64 %t233, 1
  %t239 = call i1 @compiler_2ftyped_2emayHold(ptr %v0, ptr %t231, i32 %t232, i64 %t235)
  store i1 %t239, ptr %l135
  br label %bb82
bb81:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb83
bb82:
  %t240 = load i1, ptr %l135, !tbaa !21
  store i1 %t240, ptr %l130, !tbaa !21
  br label %bb83
bb83:
  %t241 = load i1, ptr %l130, !tbaa !21
  br i1 %t241, label %bb84, label %bb85
bb84:
  store i1 true, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t243 = load i64, ptr %l11, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l11, !tbaa !24
  br label %bb70
bb88:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2emeetRoots(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  store i1 %t7, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb6
bb5:
  %t10 = load i64, ptr %l0, !tbaa !24
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = or i64 %t10, %t11
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb6
bb6:
  %t16 = load i64, ptr %l7, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %l1, i64 %a0)
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ftyped_2estmtBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i1
  %l92 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l104 = alloca i1
  %l105 = alloca i1
  %l108 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l123 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l137 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l146 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i1
  %l158 = alloca i1
  %l159 = alloca i1
  %l162 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l178 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i1
  %l189 = alloca i1
  %l190 = alloca i1
  %l194 = alloca i1
  %l195 = alloca ptr
  %l196 = alloca i1
  %l204 = alloca i1
  %l205 = alloca i1
  %l210 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t2 = load ptr, ptr %l19, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l19, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l20, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 2}
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i32, ptr %l2, !range !{i32 0, i32 2}
  %t24 = trunc i64 0 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i32, ptr %l3, !tbaa !23
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  store i1 %t31, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l29, !tbaa !21
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb137
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t35 = load ptr, ptr %l33, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l33, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 17}
  %t41 = icmp eq i64 %t39, 0
  store i1 %t41, ptr %l34, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l34, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l4, !tbaa !29
  br label %bb22
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t50 = load ptr, ptr %l39, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l39, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 17}
  %t56 = icmp eq i64 %t54, 2
  store i1 %t56, ptr %l40, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l40, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l4, !tbaa !29
  br label %bb22
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t65 = load ptr, ptr %l45, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load ptr, ptr %l45, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 17}
  %t71 = icmp eq i64 %t69, 15
  store i1 %t71, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l46, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", ptr }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t79, i32 %t81)
  store i1 %t84, ptr %l54
  br label %bb23
bb23:
  %t85 = load i1, ptr %l54, !tbaa !21
  store i1 %t85, ptr %l18, !tbaa !21
  br label %bb137
bb24:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t87 = load ptr, ptr %l55, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l55, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 17}
  %t93 = icmp eq i64 %t91, 1
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l56, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t97, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l5, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb35
bb29:
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l65
  br label %bb30
bb30:
  %t112 = load i1, ptr %l65, !tbaa !21
  br i1 %t112, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb34
bb32:
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t115 = load i32, ptr %l1, !tbaa !23
  %t118 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t113, i32 %t115)
  store i1 %t118, ptr %l70
  br label %bb33
bb33:
  %t119 = load i1, ptr %l70, !tbaa !21
  store i1 %t119, ptr %l66, !tbaa !21
  br label %bb34
bb34:
  %t120 = load i1, ptr %l66, !tbaa !21
  store i1 %t120, ptr %l18, !tbaa !21
  br label %bb137
bb35:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t122 = load ptr, ptr %l71, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb36, label %bb37
bb36:
  %t125 = load ptr, ptr %l71, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 17}
  %t128 = icmp eq i64 %t126, 3
  store i1 %t128, ptr %l72, !tbaa !21
  br label %bb37
bb37:
  %t129 = load i1, ptr %l72, !tbaa !21
  br i1 %t129, label %bb38, label %bb39
bb38:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr { i64, [3 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr }, ptr %t132, i32 0, i32 1
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l7, !tbaa !29
  br label %bb40
bb39:
  br label %bb50
bb40:
  %t136 = load ptr, ptr %l7, !tbaa !29
  %t138 = getelementptr %"compiler/typed:If", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = load i32, ptr %l1, !tbaa !23
  %t144 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t139, i32 %t141)
  store i1 %t144, ptr %l81
  br label %bb41
bb41:
  %t145 = load i1, ptr %l81, !tbaa !21
  br i1 %t145, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb45
bb43:
  %t146 = load ptr, ptr %l7, !tbaa !29
  %t148 = getelementptr %"compiler/typed:If", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = load i32, ptr %l1, !tbaa !23
  %t154 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t149, i32 %t151)
  store i1 %t154, ptr %l87
  br label %bb44
bb44:
  %t155 = load i1, ptr %l87, !tbaa !21
  store i1 %t155, ptr %l82, !tbaa !21
  br label %bb45
bb45:
  %t156 = load i1, ptr %l82, !tbaa !21
  br i1 %t156, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb49
bb47:
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t159 = getelementptr %"compiler/typed:If", ptr %t157, i32 0, i32 2
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t161 = load i32, ptr %l1, !tbaa !23
  %t164 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t160, i32 %t161)
  store i1 %t164, ptr %l92
  br label %bb48
bb48:
  %t165 = load i1, ptr %l92, !tbaa !21
  store i1 %t165, ptr %l88, !tbaa !21
  br label %bb49
bb49:
  %t166 = load i1, ptr %l88, !tbaa !21
  store i1 %t166, ptr %l18, !tbaa !21
  br label %bb137
bb50:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t168 = load ptr, ptr %l93, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb51, label %bb52
bb51:
  %t171 = load ptr, ptr %l93, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 17}
  %t174 = icmp eq i64 %t172, 4
  store i1 %t174, ptr %l94, !tbaa !21
  br label %bb52
bb52:
  %t175 = load i1, ptr %l94, !tbaa !21
  br i1 %t175, label %bb53, label %bb54
bb53:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l8, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l9, !tbaa !29
  br label %bb55
bb54:
  br label %bb61
bb55:
  %t188 = load ptr, ptr %l8, !tbaa !29
  %t190 = load i32, ptr %l1, !tbaa !23
  %t193 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t188, i32 %t190)
  store i1 %t193, ptr %l104
  br label %bb56
bb56:
  %t194 = load i1, ptr %l104, !tbaa !21
  br i1 %t194, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb60
bb58:
  %t195 = load ptr, ptr %l9, !tbaa !29
  %t196 = load i32, ptr %l1, !tbaa !23
  %t199 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t195, i32 %t196)
  store i1 %t199, ptr %l108
  br label %bb59
bb59:
  %t200 = load i1, ptr %l108, !tbaa !21
  store i1 %t200, ptr %l105, !tbaa !21
  br label %bb60
bb60:
  %t201 = load i1, ptr %l105, !tbaa !21
  store i1 %t201, ptr %l18, !tbaa !21
  br label %bb137
bb61:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t203 = load ptr, ptr %l109, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb62, label %bb63
bb62:
  %t206 = load ptr, ptr %l109, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 6
  store i1 %t209, ptr %l110, !tbaa !21
  br label %bb63
bb63:
  %t210 = load i1, ptr %l110, !tbaa !21
  br i1 %t210, label %bb64, label %bb65
bb64:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l10, !tbaa !29
  br label %bb70
bb65:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t218 = load ptr, ptr %l115, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb66, label %bb67
bb66:
  %t221 = load ptr, ptr %l115, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 17}
  %t224 = icmp eq i64 %t222, 16
  store i1 %t224, ptr %l116, !tbaa !21
  br label %bb67
bb67:
  %t225 = load i1, ptr %l116, !tbaa !21
  br i1 %t225, label %bb68, label %bb69
bb68:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr }, ptr %t228, i32 0, i32 1
  %t230 = load ptr, ptr %t229
  store ptr %t230, ptr %l10, !tbaa !29
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t232 = load ptr, ptr %l10, !tbaa !29
  %t233 = load i32, ptr %l1, !tbaa !23
  %t236 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t232, i32 %t233)
  store i1 %t236, ptr %l123
  br label %bb71
bb71:
  %t237 = load i1, ptr %l123, !tbaa !21
  store i1 %t237, ptr %l18, !tbaa !21
  br label %bb137
bb72:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t239 = load ptr, ptr %l124, !tbaa !29
  %t240 = icmp ne ptr %t239, null
  br i1 %t240, label %bb73, label %bb74
bb73:
  %t242 = load ptr, ptr %l124, !tbaa !29
  %t243 = load i64, ptr %t242, !range !{i64 0, i64 17}
  %t245 = icmp eq i64 %t243, 7
  store i1 %t245, ptr %l125, !tbaa !21
  br label %bb74
bb74:
  %t246 = load i1, ptr %l125, !tbaa !21
  br i1 %t246, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb137
bb78:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t248 = load ptr, ptr %l128, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb79, label %bb80
bb79:
  %t251 = load ptr, ptr %l128, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 17}
  %t254 = icmp eq i64 %t252, 8
  store i1 %t254, ptr %l129, !tbaa !21
  br label %bb80
bb80:
  %t255 = load i1, ptr %l129, !tbaa !21
  br i1 %t255, label %bb81, label %bb82
bb81:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l11, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t262 = load ptr, ptr %l11, !tbaa !29
  %t264 = load i32, ptr %l1, !tbaa !23
  %t267 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t262, i32 %t264)
  store i1 %t267, ptr %l137
  br label %bb84
bb84:
  %t268 = load i1, ptr %l137, !tbaa !21
  store i1 %t268, ptr %l18, !tbaa !21
  br label %bb137
bb85:
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t270 = load ptr, ptr %l138, !tbaa !29
  %t271 = icmp ne ptr %t270, null
  br i1 %t271, label %bb86, label %bb87
bb86:
  %t273 = load ptr, ptr %l138, !tbaa !29
  %t274 = load i64, ptr %t273, !range !{i64 0, i64 17}
  %t276 = icmp eq i64 %t274, 9
  store i1 %t276, ptr %l139, !tbaa !21
  br label %bb87
bb87:
  %t277 = load i1, ptr %l139, !tbaa !21
  br i1 %t277, label %bb88, label %bb89
bb88:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t278, i32 0, i32 1
  %t281 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t280, i32 0, i32 2
  %t282 = load ptr, ptr %t281
  store ptr %t282, ptr %l12, !tbaa !29
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t284 = load ptr, ptr %l12, !tbaa !29
  %t285 = load i32, ptr %l1, !tbaa !23
  %t288 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t284, i32 %t285)
  store i1 %t288, ptr %l146
  br label %bb91
bb91:
  %t289 = load i1, ptr %l146, !tbaa !21
  store i1 %t289, ptr %l18, !tbaa !21
  br label %bb137
bb92:
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t291 = load ptr, ptr %l147, !tbaa !29
  %t292 = icmp ne ptr %t291, null
  br i1 %t292, label %bb93, label %bb94
bb93:
  %t294 = load ptr, ptr %l147, !tbaa !29
  %t295 = load i64, ptr %t294, !range !{i64 0, i64 17}
  %t297 = icmp eq i64 %t295, 10
  store i1 %t297, ptr %l148, !tbaa !21
  br label %bb94
bb94:
  %t298 = load i1, ptr %l148, !tbaa !21
  br i1 %t298, label %bb95, label %bb96
bb95:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr { i64, [3 x i64] }, ptr %t299, i32 0, i32 1
  %t302 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t301, i32 0, i32 1
  %t303 = load ptr, ptr %t302
  store ptr %t303, ptr %l13, !tbaa !29
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr { i64, [3 x i64] }, ptr %t305, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t307, i32 0, i32 2
  %t309 = load ptr, ptr %t308
  store ptr %t309, ptr %l14, !tbaa !29
  br label %bb97
bb96:
  br label %bb103
bb97:
  %t311 = load ptr, ptr %l13, !tbaa !29
  %t313 = load i32, ptr %l1, !tbaa !23
  %t316 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t311, i32 %t313)
  store i1 %t316, ptr %l158
  br label %bb98
bb98:
  %t317 = load i1, ptr %l158, !tbaa !21
  br i1 %t317, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l159, !tbaa !21
  br label %bb102
bb100:
  %t318 = load ptr, ptr %l14, !tbaa !29
  %t319 = load i32, ptr %l1, !tbaa !23
  %t322 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t318, i32 %t319)
  store i1 %t322, ptr %l162
  br label %bb101
bb101:
  %t323 = load i1, ptr %l162, !tbaa !21
  store i1 %t323, ptr %l159, !tbaa !21
  br label %bb102
bb102:
  %t324 = load i1, ptr %l159, !tbaa !21
  store i1 %t324, ptr %l18, !tbaa !21
  br label %bb137
bb103:
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t326 = load ptr, ptr %l163, !tbaa !29
  %t327 = icmp ne ptr %t326, null
  br i1 %t327, label %bb104, label %bb105
bb104:
  %t329 = load ptr, ptr %l163, !tbaa !29
  %t330 = load i64, ptr %t329, !range !{i64 0, i64 17}
  %t332 = icmp eq i64 %t330, 11
  store i1 %t332, ptr %l164, !tbaa !21
  br label %bb105
bb105:
  %t333 = load i1, ptr %l164, !tbaa !21
  br i1 %t333, label %bb106, label %bb107
bb106:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr { i64, [3 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", ptr }, ptr %t336, i32 0, i32 1
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l15, !tbaa !29
  br label %bb112
bb107:
  %t340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t340, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t341 = load ptr, ptr %l169, !tbaa !29
  %t342 = icmp ne ptr %t341, null
  br i1 %t342, label %bb108, label %bb109
bb108:
  %t344 = load ptr, ptr %l169, !tbaa !29
  %t345 = load i64, ptr %t344, !range !{i64 0, i64 17}
  %t347 = icmp eq i64 %t345, 12
  store i1 %t347, ptr %l170, !tbaa !21
  br label %bb109
bb109:
  %t348 = load i1, ptr %l170, !tbaa !21
  br i1 %t348, label %bb110, label %bb111
bb110:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr { i64, [3 x i64] }, ptr %t349, i32 0, i32 1
  %t352 = getelementptr { %"compiler/source:Span", ptr }, ptr %t351, i32 0, i32 1
  %t353 = load ptr, ptr %t352
  store ptr %t353, ptr %l15, !tbaa !29
  br label %bb112
bb111:
  br label %bb114
bb112:
  %t355 = load ptr, ptr %l15, !tbaa !29
  %t357 = load i32, ptr %l1, !tbaa !23
  %t360 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t355, i32 %t357)
  store i1 %t360, ptr %l178
  br label %bb113
bb113:
  %t361 = load i1, ptr %l178, !tbaa !21
  store i1 %t361, ptr %l18, !tbaa !21
  br label %bb137
bb114:
  %t362 = load ptr, ptr %l0, !tbaa !29
  store ptr %t362, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t363 = load ptr, ptr %l179, !tbaa !29
  %t364 = icmp ne ptr %t363, null
  br i1 %t364, label %bb115, label %bb116
bb115:
  %t366 = load ptr, ptr %l179, !tbaa !29
  %t367 = load i64, ptr %t366, !range !{i64 0, i64 17}
  %t369 = icmp eq i64 %t367, 13
  store i1 %t369, ptr %l180, !tbaa !21
  br label %bb116
bb116:
  %t370 = load i1, ptr %l180, !tbaa !21
  br i1 %t370, label %bb117, label %bb118
bb117:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr { i64, [3 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", ptr }, ptr %t373, i32 0, i32 1
  %t375 = load ptr, ptr %t374
  store ptr %t375, ptr %l16, !tbaa !29
  br label %bb119
bb118:
  br label %bb125
bb119:
  %t377 = load ptr, ptr %l16, !tbaa !29
  %t379 = getelementptr %"compiler/typed:Join", ptr %t377, i32 0, i32 0
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = load i32, ptr %l1, !tbaa !23
  %t385 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t380, i32 %t382)
  store i1 %t385, ptr %l189
  br label %bb120
bb120:
  %t386 = load i1, ptr %l189, !tbaa !21
  br i1 %t386, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb124
bb122:
  %t387 = load ptr, ptr %l16, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Join", ptr %t387, i32 0, i32 2
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !27
  %t391 = load i32, ptr %l1, !tbaa !23
  %t394 = call i1 @compiler_2ftyped_2eclausesBreak(ptr %v0, { i64, ptr } %t390, i32 %t391)
  store i1 %t394, ptr %l194
  br label %bb123
bb123:
  %t395 = load i1, ptr %l194, !tbaa !21
  store i1 %t395, ptr %l190, !tbaa !21
  br label %bb124
bb124:
  %t396 = load i1, ptr %l190, !tbaa !21
  store i1 %t396, ptr %l18, !tbaa !21
  br label %bb137
bb125:
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l195, !tbaa !29
  store i1 false, ptr %l196, !tbaa !21
  %t398 = load ptr, ptr %l195, !tbaa !29
  %t399 = icmp ne ptr %t398, null
  br i1 %t399, label %bb126, label %bb127
bb126:
  %t401 = load ptr, ptr %l195, !tbaa !29
  %t402 = load i64, ptr %t401, !range !{i64 0, i64 17}
  %t404 = icmp eq i64 %t402, 14
  store i1 %t404, ptr %l196, !tbaa !21
  br label %bb127
bb127:
  %t405 = load i1, ptr %l196, !tbaa !21
  br i1 %t405, label %bb128, label %bb129
bb128:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr { i64, [3 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", ptr }, ptr %t408, i32 0, i32 1
  %t410 = load ptr, ptr %t409
  store ptr %t410, ptr %l17, !tbaa !29
  br label %bb130
bb129:
  br label %bb136
bb130:
  %t412 = load ptr, ptr %l17, !tbaa !29
  %t414 = getelementptr %"compiler/typed:Spawn", ptr %t412, i32 0, i32 0
  %t415 = load { i64, ptr }, ptr %t414, !tbaa !27
  %t416 = load i32, ptr %l1, !tbaa !23
  %t419 = call i1 @compiler_2ftyped_2etargetsBreak(ptr %v0, { i64, ptr } %t415, i32 %t416)
  store i1 %t419, ptr %l204
  br label %bb131
bb131:
  %t420 = load i1, ptr %l204, !tbaa !21
  br i1 %t420, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb135
bb133:
  %t421 = load ptr, ptr %l17, !tbaa !29
  %t423 = getelementptr %"compiler/typed:Spawn", ptr %t421, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !29
  %t426 = load i32, ptr %l1, !tbaa !23
  %t429 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t424, i32 %t426)
  store i1 %t429, ptr %l210
  br label %bb134
bb134:
  %t430 = load i1, ptr %l210, !tbaa !21
  store i1 %t430, ptr %l205, !tbaa !21
  br label %bb135
bb135:
  %t431 = load i1, ptr %l205, !tbaa !21
  store i1 %t431, ptr %l18, !tbaa !21
  br label %bb137
bb136:
  call void @__olang_check_failed(ptr @olang_loc_ab0bd1a1cb525619_8191fed8583864ed)
  unreachable
bb137:
  %t432 = load i1, ptr %l18, !tbaa !21
  store i1 %t432, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2estmtsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t34 = call i1 @compiler_2ftyped_2estmtBreaks(ptr %v0, ptr %t28, i32 %a1)
  store i1 %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ewholeLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l17 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l33 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l2
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3, !tbaa !23
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t39, i32 0, i32 2
  %t41 = load i32, ptr %t40
  %t45 = sext i32 %t41 to i64
  store i64 %t45, ptr %l17, !tbaa !24
  br label %bb10
bb9:
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l17, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  br label %bb23
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 17
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t56 = load i1, ptr %l27, !tbaa !21
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t65 = call i64 @compiler_2ftyped_2ewholeLocal(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l33
  br label %bb17
bb17:
  %t66 = load i64, ptr %l33, !tbaa !24
  store i64 %t66, ptr %l6, !tbaa !24
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_9bf6326dc96b231_1fb9b096f472b9bd)
  unreachable
bb23:
  %t67 = load i64, ptr %l6, !tbaa !24
  store i64 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ewordsOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l19 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s1, ptr %v0, { i64, ptr } %a0, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store { i64, ptr } %t5, ptr %l8
  br label %bb2
bb2:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb5:
  br label %bb6
bb6:
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %t23, i64 %t20
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !37
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t27, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t29, ptr %l19
  br label %bb7
bb7:
  %t30 = load i1, ptr %l19, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %l1, { i64, ptr } %t33)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb3
bb13:
  call void @__olang_scope_close(ptr %s1)
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"compiler/typed:Alt" @compiler_2ftyped_3aAlt_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Alt"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Alt" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/typed:Alt" %t6, { i64, ptr } %a1, 1
  store %"compiler/typed:Alt" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Alt", ptr %rv
  ret %"compiler/typed:Alt" %rr
}

define dso_local %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Bind"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Bind" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Bind" %t6, ptr %a1, 1
  store %"compiler/typed:Bind" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Bind", ptr %rv
  ret %"compiler/typed:Bind" %rr
}

define dso_local %"compiler/typed:DerivedArg" @compiler_2ftyped_3aDerivedArg_2ector(ptr %v0, i64 %a0, i64 %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:DerivedArg"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:DerivedArg" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/typed:DerivedArg" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/typed:DerivedArg" %t10, { i64, [2 x i64] } %a2, 2
  store %"compiler/typed:DerivedArg" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:DerivedArg", ptr %rv
  ret %"compiler/typed:DerivedArg" %rr
}

define dso_local %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Elem"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Elem" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Elem" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:Elem" %t10, i32 %a2, 2
  store %"compiler/typed:Elem" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Elem", ptr %rv
  ret %"compiler/typed:Elem" %rr
}

define dso_local %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:If"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:If" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:If" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:If" %t10, ptr %a2, 2
  store %"compiler/typed:If" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:If", ptr %rv
  ret %"compiler/typed:If" %rr
}

define dso_local %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Item"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Item" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Item" %t6, i64 %a1, 1
  store %"compiler/typed:Item" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Item", ptr %rv
  ret %"compiler/typed:Item" %rr
}

define dso_local void @compiler_2ftyped_3aLocalUses_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i1
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca i64
  %l55 = alloca i64
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i64
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca i64
  %l65 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l67 = alloca i64
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca i64
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca i64
  %l77 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l79 = alloca i64
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca i64
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca i64
  %l95 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l97 = alloca i64
  %l99 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca i64
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca i64
  %l107 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l109 = alloca i64
  %l111 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca i64
  %l115 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l117 = alloca i64
  %l119 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l121 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l122 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l123 = alloca i64
  %l125 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l127 = alloca i64
  %l129 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l131 = alloca i64
  %l133 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l135 = alloca i64
  %l137 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l139 = alloca i64
  %l141 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca i64
  %l145 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l147 = alloca i64
  %l149 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l151 = alloca i64
  %l153 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l155 = alloca i64
  %l157 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l159 = alloca i64
  %l161 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l163 = alloca i64
  %l165 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l167 = alloca i64
  %l169 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l171 = alloca i64
  %l173 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l175 = alloca i64
  %l177 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l179 = alloca i64
  %l181 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l183 = alloca i64
  %l185 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l187 = alloca i64
  %l189 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l191 = alloca i64
  %l193 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l195 = alloca i64
  %l197 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l200 = alloca %"compiler/typed:LocalUses"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  %t5 = ptrtoint ptr %v2 to i64
  store i64 %t5, ptr %l55, !tbaa !24
  %t6 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e2
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call ptr @__olang_region_make(ptr %v2)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l55, !tbaa !24
  br label %bb2
bb2:
  %t10 = load i64, ptr %l55
  %t11 = inttoptr i64 %t10 to ptr
  %t12 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t11, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l57
  br label %bb3
bb3:
  %t13 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e2
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load i64, ptr %l55
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57, i32 0, i32 0
  %t18 = load { i64, ptr }, ptr %t17
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = call ptr @__olang_region_or(ptr %t19, ptr null)
  %t21 = call ptr @__olang_region_home(ptr %t20)
  %t22 = icmp ne ptr %t21, null
  %t23 = select i1 %t22, ptr %t21, ptr null
  %t24 = icmp eq ptr %t23, %t16
  call void @__olang_region_settle(ptr %t16, i1 %t24)
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l4
  %t26 = ptrtoint ptr %v2 to i64
  store i64 %t26, ptr %l59, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e3
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = call ptr @__olang_region_make(ptr %v2)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l59, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l59
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t32, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l61
  br label %bb8
bb8:
  %t34 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e3
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load i64, ptr %l59
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61, i32 0, i32 0
  %t39 = load { i64, ptr }, ptr %t38
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = call ptr @__olang_region_or(ptr %t40, ptr null)
  %t42 = call ptr @__olang_region_home(ptr %t41)
  %t43 = icmp ne ptr %t42, null
  %t44 = select i1 %t43, ptr %t42, ptr null
  %t45 = icmp eq ptr %t44, %t37
  call void @__olang_region_settle(ptr %t37, i1 %t45)
  br label %bb10
bb10:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l5
  %t47 = ptrtoint ptr %v2 to i64
  store i64 %t47, ptr %l63, !tbaa !24
  %t48 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e4
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = call ptr @__olang_region_make(ptr %v2)
  %t51 = ptrtoint ptr %t50 to i64
  store i64 %t51, ptr %l63, !tbaa !24
  br label %bb12
bb12:
  %t52 = load i64, ptr %l63
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t53, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l65
  br label %bb13
bb13:
  %t55 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e4
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load i64, ptr %l63
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = call ptr @__olang_region_or(ptr %t61, ptr null)
  %t63 = call ptr @__olang_region_home(ptr %t62)
  %t64 = icmp ne ptr %t63, null
  %t65 = select i1 %t64, ptr %t63, ptr null
  %t66 = icmp eq ptr %t65, %t58
  call void @__olang_region_settle(ptr %t58, i1 %t66)
  br label %bb15
bb15:
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l6
  %t68 = ptrtoint ptr %v2 to i64
  store i64 %t68, ptr %l67, !tbaa !24
  %t69 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e5
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t71 = call ptr @__olang_region_make(ptr %v2)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l67, !tbaa !24
  br label %bb17
bb17:
  %t73 = load i64, ptr %l67
  %t74 = inttoptr i64 %t73 to ptr
  %t75 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t74, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l69
  br label %bb18
bb18:
  %t76 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e5
  br i1 %t76, label %bb19, label %bb20
bb19:
  %t78 = load i64, ptr %l67
  %t79 = inttoptr i64 %t78 to ptr
  %t80 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = call ptr @__olang_region_or(ptr %t82, ptr null)
  %t84 = call ptr @__olang_region_home(ptr %t83)
  %t85 = icmp ne ptr %t84, null
  %t86 = select i1 %t85, ptr %t84, ptr null
  %t87 = icmp eq ptr %t86, %t79
  call void @__olang_region_settle(ptr %t79, i1 %t87)
  br label %bb20
bb20:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l7
  %t89 = ptrtoint ptr %v2 to i64
  store i64 %t89, ptr %l71, !tbaa !24
  %t90 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e6
  br i1 %t90, label %bb21, label %bb22
bb21:
  %t92 = call ptr @__olang_region_make(ptr %v2)
  %t93 = ptrtoint ptr %t92 to i64
  store i64 %t93, ptr %l71, !tbaa !24
  br label %bb22
bb22:
  %t94 = load i64, ptr %l71
  %t95 = inttoptr i64 %t94 to ptr
  %t96 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t95, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %l73
  br label %bb23
bb23:
  %t97 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e6
  br i1 %t97, label %bb24, label %bb25
bb24:
  %t99 = load i64, ptr %l71
  %t100 = inttoptr i64 %t99 to ptr
  %t101 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73, i32 0, i32 0
  %t102 = load { i64, ptr }, ptr %t101
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = call ptr @__olang_region_or(ptr %t103, ptr null)
  %t105 = call ptr @__olang_region_home(ptr %t104)
  %t106 = icmp ne ptr %t105, null
  %t107 = select i1 %t106, ptr %t105, ptr null
  %t108 = icmp eq ptr %t107, %t100
  call void @__olang_region_settle(ptr %t100, i1 %t108)
  br label %bb25
bb25:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l8
  %t110 = ptrtoint ptr %v2 to i64
  store i64 %t110, ptr %l75, !tbaa !24
  %t111 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e7
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t113 = call ptr @__olang_region_make(ptr %v2)
  %t114 = ptrtoint ptr %t113 to i64
  store i64 %t114, ptr %l75, !tbaa !24
  br label %bb27
bb27:
  %t115 = load i64, ptr %l75
  %t116 = inttoptr i64 %t115 to ptr
  %t117 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t116, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %l77
  br label %bb28
bb28:
  %t118 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e7
  br i1 %t118, label %bb29, label %bb30
bb29:
  %t120 = load i64, ptr %l75
  %t121 = inttoptr i64 %t120 to ptr
  %t122 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = call ptr @__olang_region_or(ptr %t124, ptr null)
  %t126 = call ptr @__olang_region_home(ptr %t125)
  %t127 = icmp ne ptr %t126, null
  %t128 = select i1 %t127, ptr %t126, ptr null
  %t129 = icmp eq ptr %t128, %t121
  call void @__olang_region_settle(ptr %t121, i1 %t129)
  br label %bb30
bb30:
  %t130 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l9
  %t131 = ptrtoint ptr %v2 to i64
  store i64 %t131, ptr %l79, !tbaa !24
  %t132 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e8
  br i1 %t132, label %bb31, label %bb32
bb31:
  %t134 = call ptr @__olang_region_make(ptr %v2)
  %t135 = ptrtoint ptr %t134 to i64
  store i64 %t135, ptr %l79, !tbaa !24
  br label %bb32
bb32:
  %t136 = load i64, ptr %l79
  %t137 = inttoptr i64 %t136 to ptr
  %t138 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t137, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %l81
  br label %bb33
bb33:
  %t139 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e8
  br i1 %t139, label %bb34, label %bb35
bb34:
  %t141 = load i64, ptr %l79
  %t142 = inttoptr i64 %t141 to ptr
  %t143 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81, i32 0, i32 0
  %t144 = load { i64, ptr }, ptr %t143
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = call ptr @__olang_region_or(ptr %t145, ptr null)
  %t147 = call ptr @__olang_region_home(ptr %t146)
  %t148 = icmp ne ptr %t147, null
  %t149 = select i1 %t148, ptr %t147, ptr null
  %t150 = icmp eq ptr %t149, %t142
  call void @__olang_region_settle(ptr %t142, i1 %t150)
  br label %bb35
bb35:
  %t151 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l10
  %t152 = ptrtoint ptr %v2 to i64
  store i64 %t152, ptr %l83, !tbaa !24
  %t153 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e9
  br i1 %t153, label %bb36, label %bb37
bb36:
  %t155 = call ptr @__olang_region_make(ptr %v2)
  %t156 = ptrtoint ptr %t155 to i64
  store i64 %t156, ptr %l83, !tbaa !24
  br label %bb37
bb37:
  %t157 = load i64, ptr %l83
  %t158 = inttoptr i64 %t157 to ptr
  %t159 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t158, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %l85
  br label %bb38
bb38:
  %t160 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e9
  br i1 %t160, label %bb39, label %bb40
bb39:
  %t162 = load i64, ptr %l83
  %t163 = inttoptr i64 %t162 to ptr
  %t164 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85, i32 0, i32 0
  %t165 = load { i64, ptr }, ptr %t164
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = call ptr @__olang_region_or(ptr %t166, ptr null)
  %t168 = call ptr @__olang_region_home(ptr %t167)
  %t169 = icmp ne ptr %t168, null
  %t170 = select i1 %t169, ptr %t168, ptr null
  %t171 = icmp eq ptr %t170, %t163
  call void @__olang_region_settle(ptr %t163, i1 %t171)
  br label %bb40
bb40:
  %t172 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t172, ptr %l11
  %t173 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t173, ptr %l87
  br label %bb41
bb41:
  %t174 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t174, ptr %l12
  %t175 = ptrtoint ptr %v2 to i64
  store i64 %t175, ptr %l88, !tbaa !24
  %t176 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e11
  br i1 %t176, label %bb42, label %bb43
bb42:
  %t178 = call ptr @__olang_region_make(ptr %v2)
  %t179 = ptrtoint ptr %t178 to i64
  store i64 %t179, ptr %l88, !tbaa !24
  br label %bb43
bb43:
  %t180 = load i64, ptr %l88
  %t181 = inttoptr i64 %t180 to ptr
  %t182 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t181, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t182, ptr %l90
  br label %bb44
bb44:
  %t183 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e11
  br i1 %t183, label %bb45, label %bb46
bb45:
  %t185 = load i64, ptr %l88
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90, i32 0, i32 0
  %t188 = load { i64, ptr }, ptr %t187
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = call ptr @__olang_region_or(ptr %t189, ptr null)
  %t191 = call ptr @__olang_region_home(ptr %t190)
  %t192 = icmp ne ptr %t191, null
  %t193 = select i1 %t192, ptr %t191, ptr null
  %t194 = icmp eq ptr %t193, %t186
  call void @__olang_region_settle(ptr %t186, i1 %t194)
  br label %bb46
bb46:
  %t195 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t195, ptr %l13
  %t196 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t196, ptr %l92
  br label %bb47
bb47:
  %t197 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t197, ptr %l14
  %t198 = ptrtoint ptr %v2 to i64
  store i64 %t198, ptr %l93, !tbaa !24
  %t199 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e13
  br i1 %t199, label %bb48, label %bb49
bb48:
  %t201 = call ptr @__olang_region_make(ptr %v2)
  %t202 = ptrtoint ptr %t201 to i64
  store i64 %t202, ptr %l93, !tbaa !24
  br label %bb49
bb49:
  %t203 = load i64, ptr %l93
  %t204 = inttoptr i64 %t203 to ptr
  %t205 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t204, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l95
  br label %bb50
bb50:
  %t206 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e13
  br i1 %t206, label %bb51, label %bb52
bb51:
  %t208 = load i64, ptr %l93
  %t209 = inttoptr i64 %t208 to ptr
  %t210 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95, i32 0, i32 0
  %t211 = load { i64, ptr }, ptr %t210
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = call ptr @__olang_region_or(ptr %t212, ptr null)
  %t214 = call ptr @__olang_region_home(ptr %t213)
  %t215 = icmp ne ptr %t214, null
  %t216 = select i1 %t215, ptr %t214, ptr null
  %t217 = icmp eq ptr %t216, %t209
  call void @__olang_region_settle(ptr %t209, i1 %t217)
  br label %bb52
bb52:
  %t218 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t218, ptr %l15
  %t219 = ptrtoint ptr %v2 to i64
  store i64 %t219, ptr %l97, !tbaa !24
  %t220 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e14
  br i1 %t220, label %bb53, label %bb54
bb53:
  %t222 = call ptr @__olang_region_make(ptr %v2)
  %t223 = ptrtoint ptr %t222 to i64
  store i64 %t223, ptr %l97, !tbaa !24
  br label %bb54
bb54:
  %t224 = load i64, ptr %l97
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t225, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t226, ptr %l99
  br label %bb55
bb55:
  %t227 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e14
  br i1 %t227, label %bb56, label %bb57
bb56:
  %t229 = load i64, ptr %l97
  %t230 = inttoptr i64 %t229 to ptr
  %t231 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l99, i32 0, i32 0
  %t232 = load { i64, ptr }, ptr %t231
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = call ptr @__olang_region_or(ptr %t233, ptr null)
  %t235 = call ptr @__olang_region_home(ptr %t234)
  %t236 = icmp ne ptr %t235, null
  %t237 = select i1 %t236, ptr %t235, ptr null
  %t238 = icmp eq ptr %t237, %t230
  call void @__olang_region_settle(ptr %t230, i1 %t238)
  br label %bb57
bb57:
  %t239 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l99
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %l16
  %t240 = ptrtoint ptr %v2 to i64
  store i64 %t240, ptr %l101, !tbaa !24
  %t241 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e15
  br i1 %t241, label %bb58, label %bb59
bb58:
  %t243 = call ptr @__olang_region_make(ptr %v2)
  %t244 = ptrtoint ptr %t243 to i64
  store i64 %t244, ptr %l101, !tbaa !24
  br label %bb59
bb59:
  %t245 = load i64, ptr %l101
  %t246 = inttoptr i64 %t245 to ptr
  %t247 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t246, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t247, ptr %l103
  br label %bb60
bb60:
  %t248 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e15
  br i1 %t248, label %bb61, label %bb62
bb61:
  %t250 = load i64, ptr %l101
  %t251 = inttoptr i64 %t250 to ptr
  %t252 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252
  %t254 = extractvalue { i64, ptr } %t253, 1
  %t255 = call ptr @__olang_region_or(ptr %t254, ptr null)
  %t256 = call ptr @__olang_region_home(ptr %t255)
  %t257 = icmp ne ptr %t256, null
  %t258 = select i1 %t257, ptr %t256, ptr null
  %t259 = icmp eq ptr %t258, %t251
  call void @__olang_region_settle(ptr %t251, i1 %t259)
  br label %bb62
bb62:
  %t260 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t260, ptr %l17
  %t261 = ptrtoint ptr %v2 to i64
  store i64 %t261, ptr %l105, !tbaa !24
  %t262 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e16
  br i1 %t262, label %bb63, label %bb64
bb63:
  %t264 = call ptr @__olang_region_make(ptr %v2)
  %t265 = ptrtoint ptr %t264 to i64
  store i64 %t265, ptr %l105, !tbaa !24
  br label %bb64
bb64:
  %t266 = load i64, ptr %l105
  %t267 = inttoptr i64 %t266 to ptr
  %t268 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t267, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t268, ptr %l107
  br label %bb65
bb65:
  %t269 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e16
  br i1 %t269, label %bb66, label %bb67
bb66:
  %t271 = load i64, ptr %l105
  %t272 = inttoptr i64 %t271 to ptr
  %t273 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l107, i32 0, i32 0
  %t274 = load { i64, ptr }, ptr %t273
  %t275 = extractvalue { i64, ptr } %t274, 1
  %t276 = call ptr @__olang_region_or(ptr %t275, ptr null)
  %t277 = call ptr @__olang_region_home(ptr %t276)
  %t278 = icmp ne ptr %t277, null
  %t279 = select i1 %t278, ptr %t277, ptr null
  %t280 = icmp eq ptr %t279, %t272
  call void @__olang_region_settle(ptr %t272, i1 %t280)
  br label %bb67
bb67:
  %t281 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l107
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t281, ptr %l18
  %t282 = ptrtoint ptr %v2 to i64
  store i64 %t282, ptr %l109, !tbaa !24
  %t283 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e17
  br i1 %t283, label %bb68, label %bb69
bb68:
  %t285 = call ptr @__olang_region_make(ptr %v2)
  %t286 = ptrtoint ptr %t285 to i64
  store i64 %t286, ptr %l109, !tbaa !24
  br label %bb69
bb69:
  %t287 = load i64, ptr %l109
  %t288 = inttoptr i64 %t287 to ptr
  %t289 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t288, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t289, ptr %l111
  br label %bb70
bb70:
  %t290 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e17
  br i1 %t290, label %bb71, label %bb72
bb71:
  %t292 = load i64, ptr %l109
  %t293 = inttoptr i64 %t292 to ptr
  %t294 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l111, i32 0, i32 0
  %t295 = load { i64, ptr }, ptr %t294
  %t296 = extractvalue { i64, ptr } %t295, 1
  %t297 = call ptr @__olang_region_or(ptr %t296, ptr null)
  %t298 = call ptr @__olang_region_home(ptr %t297)
  %t299 = icmp ne ptr %t298, null
  %t300 = select i1 %t299, ptr %t298, ptr null
  %t301 = icmp eq ptr %t300, %t293
  call void @__olang_region_settle(ptr %t293, i1 %t301)
  br label %bb72
bb72:
  %t302 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l111
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t302, ptr %l19
  %t303 = ptrtoint ptr %v2 to i64
  store i64 %t303, ptr %l113, !tbaa !24
  %t304 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e18
  br i1 %t304, label %bb73, label %bb74
bb73:
  %t306 = call ptr @__olang_region_make(ptr %v2)
  %t307 = ptrtoint ptr %t306 to i64
  store i64 %t307, ptr %l113, !tbaa !24
  br label %bb74
bb74:
  %t308 = load i64, ptr %l113
  %t309 = inttoptr i64 %t308 to ptr
  %t310 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t309, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t310, ptr %l115
  br label %bb75
bb75:
  %t311 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e18
  br i1 %t311, label %bb76, label %bb77
bb76:
  %t313 = load i64, ptr %l113
  %t314 = inttoptr i64 %t313 to ptr
  %t315 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l115, i32 0, i32 0
  %t316 = load { i64, ptr }, ptr %t315
  %t317 = extractvalue { i64, ptr } %t316, 1
  %t318 = call ptr @__olang_region_or(ptr %t317, ptr null)
  %t319 = call ptr @__olang_region_home(ptr %t318)
  %t320 = icmp ne ptr %t319, null
  %t321 = select i1 %t320, ptr %t319, ptr null
  %t322 = icmp eq ptr %t321, %t314
  call void @__olang_region_settle(ptr %t314, i1 %t322)
  br label %bb77
bb77:
  %t323 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l115
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t323, ptr %l20
  %t324 = ptrtoint ptr %v2 to i64
  store i64 %t324, ptr %l117, !tbaa !24
  %t325 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e19
  br i1 %t325, label %bb78, label %bb79
bb78:
  %t327 = call ptr @__olang_region_make(ptr %v2)
  %t328 = ptrtoint ptr %t327 to i64
  store i64 %t328, ptr %l117, !tbaa !24
  br label %bb79
bb79:
  %t329 = load i64, ptr %l117
  %t330 = inttoptr i64 %t329 to ptr
  %t331 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t330, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t331, ptr %l119
  br label %bb80
bb80:
  %t332 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e19
  br i1 %t332, label %bb81, label %bb82
bb81:
  %t334 = load i64, ptr %l117
  %t335 = inttoptr i64 %t334 to ptr
  %t336 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l119, i32 0, i32 0
  %t337 = load { i64, ptr }, ptr %t336
  %t338 = extractvalue { i64, ptr } %t337, 1
  %t339 = call ptr @__olang_region_or(ptr %t338, ptr null)
  %t340 = call ptr @__olang_region_home(ptr %t339)
  %t341 = icmp ne ptr %t340, null
  %t342 = select i1 %t341, ptr %t340, ptr null
  %t343 = icmp eq ptr %t342, %t335
  call void @__olang_region_settle(ptr %t335, i1 %t343)
  br label %bb82
bb82:
  %t344 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l119
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t344, ptr %l21
  %t345 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t345, ptr %l121
  br label %bb83
bb83:
  %t346 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l121
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t346, ptr %l22
  %t347 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t347, ptr %l122
  br label %bb84
bb84:
  %t348 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t348, ptr %l23
  %t349 = ptrtoint ptr %v2 to i64
  store i64 %t349, ptr %l123, !tbaa !24
  %t350 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e22
  br i1 %t350, label %bb85, label %bb86
bb85:
  %t352 = call ptr @__olang_region_make(ptr %v2)
  %t353 = ptrtoint ptr %t352 to i64
  store i64 %t353, ptr %l123, !tbaa !24
  br label %bb86
bb86:
  %t354 = load i64, ptr %l123
  %t355 = inttoptr i64 %t354 to ptr
  %t356 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t355, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t356, ptr %l125
  br label %bb87
bb87:
  %t357 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e22
  br i1 %t357, label %bb88, label %bb89
bb88:
  %t359 = load i64, ptr %l123
  %t360 = inttoptr i64 %t359 to ptr
  %t361 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125, i32 0, i32 0
  %t362 = load { i64, ptr }, ptr %t361
  %t363 = extractvalue { i64, ptr } %t362, 1
  %t364 = call ptr @__olang_region_or(ptr %t363, ptr null)
  %t365 = call ptr @__olang_region_home(ptr %t364)
  %t366 = icmp ne ptr %t365, null
  %t367 = select i1 %t366, ptr %t365, ptr null
  %t368 = icmp eq ptr %t367, %t360
  call void @__olang_region_settle(ptr %t360, i1 %t368)
  br label %bb89
bb89:
  %t369 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t369, ptr %l24
  %t370 = ptrtoint ptr %v2 to i64
  store i64 %t370, ptr %l127, !tbaa !24
  %t371 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e23
  br i1 %t371, label %bb90, label %bb91
bb90:
  %t373 = call ptr @__olang_region_make(ptr %v2)
  %t374 = ptrtoint ptr %t373 to i64
  store i64 %t374, ptr %l127, !tbaa !24
  br label %bb91
bb91:
  %t375 = load i64, ptr %l127
  %t376 = inttoptr i64 %t375 to ptr
  %t377 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t376, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t377, ptr %l129
  br label %bb92
bb92:
  %t378 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e23
  br i1 %t378, label %bb93, label %bb94
bb93:
  %t380 = load i64, ptr %l127
  %t381 = inttoptr i64 %t380 to ptr
  %t382 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l129, i32 0, i32 0
  %t383 = load { i64, ptr }, ptr %t382
  %t384 = extractvalue { i64, ptr } %t383, 1
  %t385 = call ptr @__olang_region_or(ptr %t384, ptr null)
  %t386 = call ptr @__olang_region_home(ptr %t385)
  %t387 = icmp ne ptr %t386, null
  %t388 = select i1 %t387, ptr %t386, ptr null
  %t389 = icmp eq ptr %t388, %t381
  call void @__olang_region_settle(ptr %t381, i1 %t389)
  br label %bb94
bb94:
  %t390 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l129
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t390, ptr %l25
  %t391 = ptrtoint ptr %v2 to i64
  store i64 %t391, ptr %l131, !tbaa !24
  %t392 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e24
  br i1 %t392, label %bb95, label %bb96
bb95:
  %t394 = call ptr @__olang_region_make(ptr %v2)
  %t395 = ptrtoint ptr %t394 to i64
  store i64 %t395, ptr %l131, !tbaa !24
  br label %bb96
bb96:
  %t396 = load i64, ptr %l131
  %t397 = inttoptr i64 %t396 to ptr
  %t398 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %t397, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t398, ptr %l133
  br label %bb97
bb97:
  %t399 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e24
  br i1 %t399, label %bb98, label %bb99
bb98:
  %t401 = load i64, ptr %l131
  %t402 = inttoptr i64 %t401 to ptr
  %t403 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l133, i32 0, i32 0
  %t404 = load { i64, ptr }, ptr %t403
  %t405 = extractvalue { i64, ptr } %t404, 1
  %t406 = call ptr @__olang_region_or(ptr %t405, ptr null)
  %t407 = call ptr @__olang_region_home(ptr %t406)
  %t408 = icmp ne ptr %t407, null
  %t409 = select i1 %t408, ptr %t407, ptr null
  %t410 = icmp eq ptr %t409, %t402
  call void @__olang_region_settle(ptr %t402, i1 %t410)
  br label %bb99
bb99:
  %t411 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l133
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t411, ptr %l26
  store i64 0, ptr %l27, !tbaa !24
  store i32 0, ptr %l28, !tbaa !23
  store i1 false, ptr %l29, !tbaa !21
  %t412 = ptrtoint ptr %v2 to i64
  store i64 %t412, ptr %l135, !tbaa !24
  %t413 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e28
  br i1 %t413, label %bb100, label %bb101
bb100:
  %t415 = call ptr @__olang_region_make(ptr %v2)
  %t416 = ptrtoint ptr %t415 to i64
  store i64 %t416, ptr %l135, !tbaa !24
  br label %bb101
bb101:
  %t417 = load i64, ptr %l135
  %t418 = inttoptr i64 %t417 to ptr
  %t419 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t418, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t419, ptr %l137
  br label %bb102
bb102:
  %t420 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e28
  br i1 %t420, label %bb103, label %bb104
bb103:
  %t422 = load i64, ptr %l135
  %t423 = inttoptr i64 %t422 to ptr
  %t424 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l137, i32 0, i32 0
  %t425 = load { i64, ptr }, ptr %t424
  %t426 = extractvalue { i64, ptr } %t425, 1
  %t427 = call ptr @__olang_region_or(ptr %t426, ptr null)
  %t428 = call ptr @__olang_region_home(ptr %t427)
  %t429 = icmp ne ptr %t428, null
  %t430 = select i1 %t429, ptr %t428, ptr null
  %t431 = icmp eq ptr %t430, %t423
  call void @__olang_region_settle(ptr %t423, i1 %t431)
  br label %bb104
bb104:
  %t432 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l137
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t432, ptr %l30
  %t433 = ptrtoint ptr %v2 to i64
  store i64 %t433, ptr %l139, !tbaa !24
  %t434 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e29
  br i1 %t434, label %bb105, label %bb106
bb105:
  %t436 = call ptr @__olang_region_make(ptr %v2)
  %t437 = ptrtoint ptr %t436 to i64
  store i64 %t437, ptr %l139, !tbaa !24
  br label %bb106
bb106:
  %t438 = load i64, ptr %l139
  %t439 = inttoptr i64 %t438 to ptr
  %t440 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t439, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t440, ptr %l141
  br label %bb107
bb107:
  %t441 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e29
  br i1 %t441, label %bb108, label %bb109
bb108:
  %t443 = load i64, ptr %l139
  %t444 = inttoptr i64 %t443 to ptr
  %t445 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l141, i32 0, i32 0
  %t446 = load { i64, ptr }, ptr %t445
  %t447 = extractvalue { i64, ptr } %t446, 1
  %t448 = call ptr @__olang_region_or(ptr %t447, ptr null)
  %t449 = call ptr @__olang_region_home(ptr %t448)
  %t450 = icmp ne ptr %t449, null
  %t451 = select i1 %t450, ptr %t449, ptr null
  %t452 = icmp eq ptr %t451, %t444
  call void @__olang_region_settle(ptr %t444, i1 %t452)
  br label %bb109
bb109:
  %t453 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l141
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t453, ptr %l31
  %t454 = ptrtoint ptr %v2 to i64
  store i64 %t454, ptr %l143, !tbaa !24
  %t455 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e30
  br i1 %t455, label %bb110, label %bb111
bb110:
  %t457 = call ptr @__olang_region_make(ptr %v2)
  %t458 = ptrtoint ptr %t457 to i64
  store i64 %t458, ptr %l143, !tbaa !24
  br label %bb111
bb111:
  %t459 = load i64, ptr %l143
  %t460 = inttoptr i64 %t459 to ptr
  %t461 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t460, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t461, ptr %l145
  br label %bb112
bb112:
  %t462 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e30
  br i1 %t462, label %bb113, label %bb114
bb113:
  %t464 = load i64, ptr %l143
  %t465 = inttoptr i64 %t464 to ptr
  %t466 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l145, i32 0, i32 0
  %t467 = load { i64, ptr }, ptr %t466
  %t468 = extractvalue { i64, ptr } %t467, 1
  %t469 = call ptr @__olang_region_or(ptr %t468, ptr null)
  %t470 = call ptr @__olang_region_home(ptr %t469)
  %t471 = icmp ne ptr %t470, null
  %t472 = select i1 %t471, ptr %t470, ptr null
  %t473 = icmp eq ptr %t472, %t465
  call void @__olang_region_settle(ptr %t465, i1 %t473)
  br label %bb114
bb114:
  %t474 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l145
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t474, ptr %l32
  %t475 = ptrtoint ptr %v2 to i64
  store i64 %t475, ptr %l147, !tbaa !24
  %t476 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e31
  br i1 %t476, label %bb115, label %bb116
bb115:
  %t478 = call ptr @__olang_region_make(ptr %v2)
  %t479 = ptrtoint ptr %t478 to i64
  store i64 %t479, ptr %l147, !tbaa !24
  br label %bb116
bb116:
  %t480 = load i64, ptr %l147
  %t481 = inttoptr i64 %t480 to ptr
  %t482 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t481, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t482, ptr %l149
  br label %bb117
bb117:
  %t483 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e31
  br i1 %t483, label %bb118, label %bb119
bb118:
  %t485 = load i64, ptr %l147
  %t486 = inttoptr i64 %t485 to ptr
  %t487 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149, i32 0, i32 0
  %t488 = load { i64, ptr }, ptr %t487
  %t489 = extractvalue { i64, ptr } %t488, 1
  %t490 = call ptr @__olang_region_or(ptr %t489, ptr null)
  %t491 = call ptr @__olang_region_home(ptr %t490)
  %t492 = icmp ne ptr %t491, null
  %t493 = select i1 %t492, ptr %t491, ptr null
  %t494 = icmp eq ptr %t493, %t486
  call void @__olang_region_settle(ptr %t486, i1 %t494)
  br label %bb119
bb119:
  %t495 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t495, ptr %l33
  %t496 = ptrtoint ptr %v2 to i64
  store i64 %t496, ptr %l151, !tbaa !24
  %t497 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e32
  br i1 %t497, label %bb120, label %bb121
bb120:
  %t499 = call ptr @__olang_region_make(ptr %v2)
  %t500 = ptrtoint ptr %t499 to i64
  store i64 %t500, ptr %l151, !tbaa !24
  br label %bb121
bb121:
  %t501 = load i64, ptr %l151
  %t502 = inttoptr i64 %t501 to ptr
  %t503 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t502, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t503, ptr %l153
  br label %bb122
bb122:
  %t504 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e32
  br i1 %t504, label %bb123, label %bb124
bb123:
  %t506 = load i64, ptr %l151
  %t507 = inttoptr i64 %t506 to ptr
  %t508 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l153, i32 0, i32 0
  %t509 = load { i64, ptr }, ptr %t508
  %t510 = extractvalue { i64, ptr } %t509, 1
  %t511 = call ptr @__olang_region_or(ptr %t510, ptr null)
  %t512 = call ptr @__olang_region_home(ptr %t511)
  %t513 = icmp ne ptr %t512, null
  %t514 = select i1 %t513, ptr %t512, ptr null
  %t515 = icmp eq ptr %t514, %t507
  call void @__olang_region_settle(ptr %t507, i1 %t515)
  br label %bb124
bb124:
  %t516 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l153
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t516, ptr %l34
  %t517 = ptrtoint ptr %v2 to i64
  store i64 %t517, ptr %l155, !tbaa !24
  %t518 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e33
  br i1 %t518, label %bb125, label %bb126
bb125:
  %t520 = call ptr @__olang_region_make(ptr %v2)
  %t521 = ptrtoint ptr %t520 to i64
  store i64 %t521, ptr %l155, !tbaa !24
  br label %bb126
bb126:
  %t522 = load i64, ptr %l155
  %t523 = inttoptr i64 %t522 to ptr
  %t524 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t523, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t524, ptr %l157
  br label %bb127
bb127:
  %t525 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e33
  br i1 %t525, label %bb128, label %bb129
bb128:
  %t527 = load i64, ptr %l155
  %t528 = inttoptr i64 %t527 to ptr
  %t529 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l157, i32 0, i32 0
  %t530 = load { i64, ptr }, ptr %t529
  %t531 = extractvalue { i64, ptr } %t530, 1
  %t532 = call ptr @__olang_region_or(ptr %t531, ptr null)
  %t533 = call ptr @__olang_region_home(ptr %t532)
  %t534 = icmp ne ptr %t533, null
  %t535 = select i1 %t534, ptr %t533, ptr null
  %t536 = icmp eq ptr %t535, %t528
  call void @__olang_region_settle(ptr %t528, i1 %t536)
  br label %bb129
bb129:
  %t537 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l157
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t537, ptr %l35
  %t538 = ptrtoint ptr %v2 to i64
  store i64 %t538, ptr %l159, !tbaa !24
  %t539 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e34
  br i1 %t539, label %bb130, label %bb131
bb130:
  %t541 = call ptr @__olang_region_make(ptr %v2)
  %t542 = ptrtoint ptr %t541 to i64
  store i64 %t542, ptr %l159, !tbaa !24
  br label %bb131
bb131:
  %t543 = load i64, ptr %l159
  %t544 = inttoptr i64 %t543 to ptr
  %t545 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t544, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t545, ptr %l161
  br label %bb132
bb132:
  %t546 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e34
  br i1 %t546, label %bb133, label %bb134
bb133:
  %t548 = load i64, ptr %l159
  %t549 = inttoptr i64 %t548 to ptr
  %t550 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l161, i32 0, i32 0
  %t551 = load { i64, ptr }, ptr %t550
  %t552 = extractvalue { i64, ptr } %t551, 1
  %t553 = call ptr @__olang_region_or(ptr %t552, ptr null)
  %t554 = call ptr @__olang_region_home(ptr %t553)
  %t555 = icmp ne ptr %t554, null
  %t556 = select i1 %t555, ptr %t554, ptr null
  %t557 = icmp eq ptr %t556, %t549
  call void @__olang_region_settle(ptr %t549, i1 %t557)
  br label %bb134
bb134:
  %t558 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l161
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t558, ptr %l36
  %t559 = ptrtoint ptr %v2 to i64
  store i64 %t559, ptr %l163, !tbaa !24
  %t560 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e35
  br i1 %t560, label %bb135, label %bb136
bb135:
  %t562 = call ptr @__olang_region_make(ptr %v2)
  %t563 = ptrtoint ptr %t562 to i64
  store i64 %t563, ptr %l163, !tbaa !24
  br label %bb136
bb136:
  %t564 = load i64, ptr %l163
  %t565 = inttoptr i64 %t564 to ptr
  %t566 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t565, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t566, ptr %l165
  br label %bb137
bb137:
  %t567 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e35
  br i1 %t567, label %bb138, label %bb139
bb138:
  %t569 = load i64, ptr %l163
  %t570 = inttoptr i64 %t569 to ptr
  %t571 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l165, i32 0, i32 0
  %t572 = load { i64, ptr }, ptr %t571
  %t573 = extractvalue { i64, ptr } %t572, 1
  %t574 = call ptr @__olang_region_or(ptr %t573, ptr null)
  %t575 = call ptr @__olang_region_home(ptr %t574)
  %t576 = icmp ne ptr %t575, null
  %t577 = select i1 %t576, ptr %t575, ptr null
  %t578 = icmp eq ptr %t577, %t570
  call void @__olang_region_settle(ptr %t570, i1 %t578)
  br label %bb139
bb139:
  %t579 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l165
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t579, ptr %l37
  %t580 = ptrtoint ptr %v2 to i64
  store i64 %t580, ptr %l167, !tbaa !24
  %t581 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e36
  br i1 %t581, label %bb140, label %bb141
bb140:
  %t583 = call ptr @__olang_region_make(ptr %v2)
  %t584 = ptrtoint ptr %t583 to i64
  store i64 %t584, ptr %l167, !tbaa !24
  br label %bb141
bb141:
  %t585 = load i64, ptr %l167
  %t586 = inttoptr i64 %t585 to ptr
  %t587 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t586, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t587, ptr %l169
  br label %bb142
bb142:
  %t588 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e36
  br i1 %t588, label %bb143, label %bb144
bb143:
  %t590 = load i64, ptr %l167
  %t591 = inttoptr i64 %t590 to ptr
  %t592 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l169, i32 0, i32 0
  %t593 = load { i64, ptr }, ptr %t592
  %t594 = extractvalue { i64, ptr } %t593, 1
  %t595 = call ptr @__olang_region_or(ptr %t594, ptr null)
  %t596 = call ptr @__olang_region_home(ptr %t595)
  %t597 = icmp ne ptr %t596, null
  %t598 = select i1 %t597, ptr %t596, ptr null
  %t599 = icmp eq ptr %t598, %t591
  call void @__olang_region_settle(ptr %t591, i1 %t599)
  br label %bb144
bb144:
  %t600 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l169
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t600, ptr %l38
  %t601 = ptrtoint ptr %v2 to i64
  store i64 %t601, ptr %l171, !tbaa !24
  %t602 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e37
  br i1 %t602, label %bb145, label %bb146
bb145:
  %t604 = call ptr @__olang_region_make(ptr %v2)
  %t605 = ptrtoint ptr %t604 to i64
  store i64 %t605, ptr %l171, !tbaa !24
  br label %bb146
bb146:
  %t606 = load i64, ptr %l171
  %t607 = inttoptr i64 %t606 to ptr
  %t608 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t607, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t608, ptr %l173
  br label %bb147
bb147:
  %t609 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e37
  br i1 %t609, label %bb148, label %bb149
bb148:
  %t611 = load i64, ptr %l171
  %t612 = inttoptr i64 %t611 to ptr
  %t613 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l173, i32 0, i32 0
  %t614 = load { i64, ptr }, ptr %t613
  %t615 = extractvalue { i64, ptr } %t614, 1
  %t616 = call ptr @__olang_region_or(ptr %t615, ptr null)
  %t617 = call ptr @__olang_region_home(ptr %t616)
  %t618 = icmp ne ptr %t617, null
  %t619 = select i1 %t618, ptr %t617, ptr null
  %t620 = icmp eq ptr %t619, %t612
  call void @__olang_region_settle(ptr %t612, i1 %t620)
  br label %bb149
bb149:
  %t621 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l173
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t621, ptr %l39
  %t622 = ptrtoint ptr %v2 to i64
  store i64 %t622, ptr %l175, !tbaa !24
  %t623 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e38
  br i1 %t623, label %bb150, label %bb151
bb150:
  %t625 = call ptr @__olang_region_make(ptr %v2)
  %t626 = ptrtoint ptr %t625 to i64
  store i64 %t626, ptr %l175, !tbaa !24
  br label %bb151
bb151:
  %t627 = load i64, ptr %l175
  %t628 = inttoptr i64 %t627 to ptr
  %t629 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t628, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t629, ptr %l177
  br label %bb152
bb152:
  %t630 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e38
  br i1 %t630, label %bb153, label %bb154
bb153:
  %t632 = load i64, ptr %l175
  %t633 = inttoptr i64 %t632 to ptr
  %t634 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l177, i32 0, i32 0
  %t635 = load { i64, ptr }, ptr %t634
  %t636 = extractvalue { i64, ptr } %t635, 1
  %t637 = call ptr @__olang_region_or(ptr %t636, ptr null)
  %t638 = call ptr @__olang_region_home(ptr %t637)
  %t639 = icmp ne ptr %t638, null
  %t640 = select i1 %t639, ptr %t638, ptr null
  %t641 = icmp eq ptr %t640, %t633
  call void @__olang_region_settle(ptr %t633, i1 %t641)
  br label %bb154
bb154:
  %t642 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l177
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t642, ptr %l40
  %t643 = ptrtoint ptr %v2 to i64
  store i64 %t643, ptr %l179, !tbaa !24
  %t644 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e39
  br i1 %t644, label %bb155, label %bb156
bb155:
  %t646 = call ptr @__olang_region_make(ptr %v2)
  %t647 = ptrtoint ptr %t646 to i64
  store i64 %t647, ptr %l179, !tbaa !24
  br label %bb156
bb156:
  %t648 = load i64, ptr %l179
  %t649 = inttoptr i64 %t648 to ptr
  %t650 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t649, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t650, ptr %l181
  br label %bb157
bb157:
  %t651 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e39
  br i1 %t651, label %bb158, label %bb159
bb158:
  %t653 = load i64, ptr %l179
  %t654 = inttoptr i64 %t653 to ptr
  %t655 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l181, i32 0, i32 0
  %t656 = load { i64, ptr }, ptr %t655
  %t657 = extractvalue { i64, ptr } %t656, 1
  %t658 = call ptr @__olang_region_or(ptr %t657, ptr null)
  %t659 = call ptr @__olang_region_home(ptr %t658)
  %t660 = icmp ne ptr %t659, null
  %t661 = select i1 %t660, ptr %t659, ptr null
  %t662 = icmp eq ptr %t661, %t654
  call void @__olang_region_settle(ptr %t654, i1 %t662)
  br label %bb159
bb159:
  %t663 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l181
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t663, ptr %l41
  %t664 = ptrtoint ptr %v2 to i64
  store i64 %t664, ptr %l183, !tbaa !24
  %t665 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e40
  br i1 %t665, label %bb160, label %bb161
bb160:
  %t667 = call ptr @__olang_region_make(ptr %v2)
  %t668 = ptrtoint ptr %t667 to i64
  store i64 %t668, ptr %l183, !tbaa !24
  br label %bb161
bb161:
  %t669 = load i64, ptr %l183
  %t670 = inttoptr i64 %t669 to ptr
  %t671 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t670, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t671, ptr %l185
  br label %bb162
bb162:
  %t672 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e40
  br i1 %t672, label %bb163, label %bb164
bb163:
  %t674 = load i64, ptr %l183
  %t675 = inttoptr i64 %t674 to ptr
  %t676 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l185, i32 0, i32 0
  %t677 = load { i64, ptr }, ptr %t676
  %t678 = extractvalue { i64, ptr } %t677, 1
  %t679 = call ptr @__olang_region_or(ptr %t678, ptr null)
  %t680 = call ptr @__olang_region_home(ptr %t679)
  %t681 = icmp ne ptr %t680, null
  %t682 = select i1 %t681, ptr %t680, ptr null
  %t683 = icmp eq ptr %t682, %t675
  call void @__olang_region_settle(ptr %t675, i1 %t683)
  br label %bb164
bb164:
  %t684 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l185
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t684, ptr %l42
  %t685 = ptrtoint ptr %v2 to i64
  store i64 %t685, ptr %l187, !tbaa !24
  %t686 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e41
  br i1 %t686, label %bb165, label %bb166
bb165:
  %t688 = call ptr @__olang_region_make(ptr %v2)
  %t689 = ptrtoint ptr %t688 to i64
  store i64 %t689, ptr %l187, !tbaa !24
  br label %bb166
bb166:
  %t690 = load i64, ptr %l187
  %t691 = inttoptr i64 %t690 to ptr
  %t692 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t691, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t692, ptr %l189
  br label %bb167
bb167:
  %t693 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e41
  br i1 %t693, label %bb168, label %bb169
bb168:
  %t695 = load i64, ptr %l187
  %t696 = inttoptr i64 %t695 to ptr
  %t697 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l189, i32 0, i32 0
  %t698 = load { i64, ptr }, ptr %t697
  %t699 = extractvalue { i64, ptr } %t698, 1
  %t700 = call ptr @__olang_region_or(ptr %t699, ptr null)
  %t701 = call ptr @__olang_region_home(ptr %t700)
  %t702 = icmp ne ptr %t701, null
  %t703 = select i1 %t702, ptr %t701, ptr null
  %t704 = icmp eq ptr %t703, %t696
  call void @__olang_region_settle(ptr %t696, i1 %t704)
  br label %bb169
bb169:
  %t705 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l189
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t705, ptr %l43
  %t706 = ptrtoint ptr %v2 to i64
  store i64 %t706, ptr %l191, !tbaa !24
  %t707 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e42
  br i1 %t707, label %bb170, label %bb171
bb170:
  %t709 = call ptr @__olang_region_make(ptr %v2)
  %t710 = ptrtoint ptr %t709 to i64
  store i64 %t710, ptr %l191, !tbaa !24
  br label %bb171
bb171:
  %t711 = load i64, ptr %l191
  %t712 = inttoptr i64 %t711 to ptr
  %t713 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t712, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t713, ptr %l193
  br label %bb172
bb172:
  %t714 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e42
  br i1 %t714, label %bb173, label %bb174
bb173:
  %t716 = load i64, ptr %l191
  %t717 = inttoptr i64 %t716 to ptr
  %t718 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l193, i32 0, i32 0
  %t719 = load { i64, ptr }, ptr %t718
  %t720 = extractvalue { i64, ptr } %t719, 1
  %t721 = call ptr @__olang_region_or(ptr %t720, ptr null)
  %t722 = call ptr @__olang_region_home(ptr %t721)
  %t723 = icmp ne ptr %t722, null
  %t724 = select i1 %t723, ptr %t722, ptr null
  %t725 = icmp eq ptr %t724, %t717
  call void @__olang_region_settle(ptr %t717, i1 %t725)
  br label %bb174
bb174:
  %t726 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l193
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t726, ptr %l44
  store i64 0, ptr %l45, !tbaa !24
  %t727 = ptrtoint ptr %v2 to i64
  store i64 %t727, ptr %l195, !tbaa !24
  %t728 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e44
  br i1 %t728, label %bb175, label %bb176
bb175:
  %t730 = call ptr @__olang_region_make(ptr %v2)
  %t731 = ptrtoint ptr %t730 to i64
  store i64 %t731, ptr %l195, !tbaa !24
  br label %bb176
bb176:
  %t732 = load i64, ptr %l195
  %t733 = inttoptr i64 %t732 to ptr
  %t734 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t733, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t734, ptr %l197
  br label %bb177
bb177:
  %t735 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e44
  br i1 %t735, label %bb178, label %bb179
bb178:
  %t737 = load i64, ptr %l195
  %t738 = inttoptr i64 %t737 to ptr
  %t739 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l197, i32 0, i32 0
  %t740 = load { i64, ptr }, ptr %t739
  %t741 = extractvalue { i64, ptr } %t740, 1
  %t742 = call ptr @__olang_region_or(ptr %t741, ptr null)
  %t743 = call ptr @__olang_region_home(ptr %t742)
  %t744 = icmp ne ptr %t743, null
  %t745 = select i1 %t744, ptr %t743, ptr null
  %t746 = icmp eq ptr %t745, %t738
  call void @__olang_region_settle(ptr %t738, i1 %t746)
  br label %bb179
bb179:
  %t747 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l197
  %t748 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t750 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 0
  %t751 = load ptr, ptr %l2, !tbaa !29
  store ptr %t751, ptr %t750, !tbaa !29
  %t752 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 1
  %t753 = load ptr, ptr %l3, !tbaa !29
  store ptr %t753, ptr %t752, !tbaa !29
  %t754 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 2
  %t755 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t755, ptr %t754
  %t756 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 3
  %t757 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t757, ptr %t756
  %t758 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 4
  %t759 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t759, ptr %t758
  %t760 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 5
  %t761 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t761, ptr %t760
  %t762 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 6
  %t763 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t763, ptr %t762
  %t764 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 7
  %t765 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t765, ptr %t764
  %t766 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 8
  %t767 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t767, ptr %t766
  %t768 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 9
  %t769 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t769, ptr %t768
  %t770 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 10
  %t771 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t771, ptr %t770
  %t772 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 11
  %t773 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t773, ptr %t772
  %t774 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 12
  %t775 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t775, ptr %t774
  %t776 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 13
  %t777 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t777, ptr %t776
  %t778 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 14
  %t779 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t779, ptr %t778
  %t780 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 15
  %t781 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t781, ptr %t780
  %t782 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 16
  %t783 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t783, ptr %t782
  %t784 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 17
  %t785 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t785, ptr %t784
  %t786 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 18
  %t787 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t787, ptr %t786
  %t788 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 19
  %t789 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t789, ptr %t788
  %t790 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 20
  %t791 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t791, ptr %t790
  %t792 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 21
  %t793 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t793, ptr %t792
  %t794 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 22
  %t795 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t795, ptr %t794
  %t796 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 23
  %t797 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t797, ptr %t796
  %t798 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 24
  %t799 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t799, ptr %t798
  %t800 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 25
  %t801 = load i64, ptr %l27, !tbaa !24
  store i64 %t801, ptr %t800, !tbaa !24
  %t802 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 26
  %t803 = load i32, ptr %l28, !tbaa !23
  store i32 %t803, ptr %t802, !tbaa !23
  %t804 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 27
  %t805 = load i1, ptr %l29, !tbaa !21
  store i1 %t805, ptr %t804, !tbaa !21
  %t806 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 28
  %t807 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t807, ptr %t806
  %t808 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 29
  %t809 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t809, ptr %t808
  %t810 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 30
  %t811 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t811, ptr %t810
  %t812 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 31
  %t813 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t813, ptr %t812
  %t814 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 32
  %t815 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t815, ptr %t814
  %t816 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 33
  %t817 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t817, ptr %t816
  %t818 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 34
  %t819 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t819, ptr %t818
  %t820 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 35
  %t821 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t821, ptr %t820
  %t822 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 36
  %t823 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t823, ptr %t822
  %t824 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 37
  %t825 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t825, ptr %t824
  %t826 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 38
  %t827 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t827, ptr %t826
  %t828 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 39
  %t829 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t829, ptr %t828
  %t830 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 40
  %t831 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t831, ptr %t830
  %t832 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 41
  %t833 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t833, ptr %t832
  %t834 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 42
  %t835 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t835, ptr %t834
  %t836 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 43
  %t837 = load i64, ptr %l45, !tbaa !24
  store i64 %t837, ptr %t836, !tbaa !24
  %t838 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t747, ptr %t838
  %t840 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 45
  store i64 -1, ptr %t840, !tbaa !24
  %t842 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 46
  store i64 -1, ptr %t842, !tbaa !24
  %t844 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 47
  store i64 -1, ptr %t844, !tbaa !24
  %t846 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 48
  store i32 %t748, ptr %t846, !tbaa !23
  %t848 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 49
  store i1 false, ptr %t848, !tbaa !21
  %t850 = getelementptr %"compiler/typed:LocalUses", ptr %l200, i32 0, i32 50
  store i1 true, ptr %t850, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l200, i64 1320, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5) #0 {
entry:
  %rv = alloca %"compiler/typed:Local"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/typed:Local" undef, i32 %a0, 0
  %t16 = insertvalue %"compiler/typed:Local" %t14, %"compiler/source:Span" %a1, 1
  %t18 = insertvalue %"compiler/typed:Local" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/typed:Local" %t18, i32 %a3, 3
  %t22 = insertvalue %"compiler/typed:Local" %t20, i32 %a4, 4
  %t24 = insertvalue %"compiler/typed:Local" %t22, { i64, [1 x i64] } %a5, 5
  %t26 = insertvalue %"compiler/typed:Local" %t24, i1 false, 6
  %t28 = insertvalue %"compiler/typed:Local" %t26, i1 false, 7
  store %"compiler/typed:Local" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Local", ptr %rv
  ret %"compiler/typed:Local" %rr
}

define dso_local void @compiler_2ftyped_3aPlan_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, [2 x i64] }
  %l36 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i64
  %l48 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i64
  %l58 = alloca i64
  %l62 = alloca i64
  %l66 = alloca i64
  %l70 = alloca i64
  %l72 = alloca i64
  %l76 = alloca i64
  %l78 = alloca i64
  %l82 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l87 = alloca i64
  %l89 = alloca i64
  %l93 = alloca i64
  %l95 = alloca i64
  %l99 = alloca i64
  %l101 = alloca i64
  %l105 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l106 = alloca i64
  %l108 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca i64
  %l112 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l115 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l116 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l117 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l118 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l119 = alloca %"compiler/typed:Plan"
  %t15 = alloca { i64, [2 x i64] }, align 8
  %t28 = alloca i64
  %t170 = alloca i64
  %t198 = alloca i64
  %t249 = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l27, !tbaa !24
  %t2 = load i64, ptr %l27, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l27, !tbaa !24
  %t6 = icmp sle i64 %t5, 384307168202282325
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_480f1658b5360f56_487a5534952ab742)
  unreachable
bb3:
  %t8 = load i64, ptr %l27, !tbaa !24
  %t9 = mul i64 %t8, 24
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l31, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [2 x i64] }, ptr %t15, i32 0, i32 0
  store i64 5, ptr %t16
  %t17 = load { i64, [2 x i64] }, ptr %t15
  store { i64, [2 x i64] } %t17, ptr %l32
  %t18 = load i64, ptr %l31, !tbaa !24
  %t19 = icmp sge i64 %t18, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_480f1658b5360f56_487a5534952ab742)
  unreachable
bb5:
  %t21 = load i64, ptr %l31, !tbaa !24
  %t22 = icmp sle i64 %t21, 384307168202282325
  br i1 %t22, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_8f643c1a2619646b_285ffd8328f7aef7)
  unreachable
bb7:
  %t24 = load i64, ptr %l31, !tbaa !24
  %t25 = mul i64 %t24, 24
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = load { i64, [2 x i64] }, ptr %l32
  store i64 0, ptr %t28
  br label %fill.29
fill.29:
  %t32 = load i64, ptr %t28
  %t33 = icmp slt i64 %t32, %t24
  br i1 %t33, label %fillb.30, label %filld.31
fillb.30:
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t26, i64 %t32
  store { i64, [2 x i64] } %t27, ptr %t34
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %t28
  br label %fill.29
filld.31:
  %t36 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t26, 1
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  %t39 = ptrtoint ptr %v0 to i64
  store i64 %t39, ptr %l36, !tbaa !24
  %t40 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e2
  br i1 %t40, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_8f643c1a2619646b_285ffd8328f7aef7)
  unreachable
bb9:
  %t42 = call ptr @__olang_region_make(ptr %v0)
  %t43 = ptrtoint ptr %t42 to i64
  store i64 %t43, ptr %l36, !tbaa !24
  br label %bb10
bb10:
  store i64 %a2, ptr %l38, !tbaa !24
  %t45 = load i64, ptr %l38, !tbaa !24
  %t46 = icmp sge i64 %t45, 0
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load i64, ptr %l38, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = load i64, ptr %l36
  %t51 = inttoptr i64 %t50 to ptr
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %t51, i64 %t49)
  %t53 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l5, !tbaa !27
  %t56 = ptrtoint ptr %v0 to i64
  store i64 %t56, ptr %l41, !tbaa !24
  %t57 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e3
  br i1 %t57, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_879aacf2d1a22b08_c7cef0899cf1454)
  unreachable
bb13:
  %t59 = call ptr @__olang_region_make(ptr %v0)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l41, !tbaa !24
  br label %bb14
bb14:
  %t61 = load i64, ptr %l1, !tbaa !24
  store i64 %t61, ptr %l43, !tbaa !24
  %t62 = load i64, ptr %l43, !tbaa !24
  %t63 = icmp sge i64 %t62, 0
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = load i64, ptr %l43, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = load i64, ptr %l41
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = call ptr @__olang_scope_alloc_zeroed(ptr %t68, i64 %t66)
  %t70 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l6, !tbaa !27
  %t73 = ptrtoint ptr %v0 to i64
  store i64 %t73, ptr %l46, !tbaa !24
  %t74 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e4
  br i1 %t74, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_642fe669e8876d75_a0626c7162644c61)
  unreachable
bb17:
  %t76 = call ptr @__olang_region_make(ptr %v0)
  %t77 = ptrtoint ptr %t76 to i64
  store i64 %t77, ptr %l46, !tbaa !24
  br label %bb18
bb18:
  %t78 = load i64, ptr %l1, !tbaa !24
  store i64 %t78, ptr %l48, !tbaa !24
  %t79 = load i64, ptr %l48, !tbaa !24
  %t80 = icmp sge i64 %t79, 0
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t82 = load i64, ptr %l48, !tbaa !24
  %t83 = mul i64 %t82, 1
  %t84 = load i64, ptr %l46
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = call ptr @__olang_scope_alloc_zeroed(ptr %t85, i64 %t83)
  %t87 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l7, !tbaa !27
  %t90 = ptrtoint ptr %v0 to i64
  store i64 %t90, ptr %l51, !tbaa !24
  %t91 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e5
  br i1 %t91, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d6ddef0f5c032242_b9ab7c7dee5da456)
  unreachable
bb21:
  %t93 = call ptr @__olang_region_make(ptr %v0)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t95 = load i64, ptr %l0, !tbaa !24
  store i64 %t95, ptr %l53, !tbaa !24
  %t96 = load i64, ptr %l53, !tbaa !24
  %t97 = icmp sge i64 %t96, 0
  br i1 %t97, label %bb23, label %bb24
bb23:
  %t99 = load i64, ptr %l53, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = load i64, ptr %l51
  %t102 = inttoptr i64 %t101 to ptr
  %t103 = call ptr @__olang_scope_alloc_zeroed(ptr %t102, i64 %t100)
  %t104 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l8, !tbaa !27
  %t107 = ptrtoint ptr %v0 to i64
  store i64 %t107, ptr %l56, !tbaa !24
  %t108 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e6
  br i1 %t108, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b6c3975defd019f7_100a23f5f40f96b)
  unreachable
bb25:
  %t110 = call ptr @__olang_region_make(ptr %v0)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l56, !tbaa !24
  br label %bb26
bb26:
  %t112 = load i64, ptr %l0, !tbaa !24
  store i64 %t112, ptr %l58, !tbaa !24
  %t113 = load i64, ptr %l58, !tbaa !24
  %t114 = icmp sge i64 %t113, 0
  br i1 %t114, label %bb27, label %bb28
bb27:
  %t116 = load i64, ptr %l58, !tbaa !24
  %t117 = icmp sle i64 %t116, 1152921504606846975
  br i1 %t117, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_9ae088e360a77f54_f93713180ac9c008)
  unreachable
bb29:
  %t119 = load i64, ptr %l58, !tbaa !24
  %t120 = mul i64 %t119, 8
  %t121 = load i64, ptr %l56
  %t122 = inttoptr i64 %t121 to ptr
  %t123 = call ptr @__olang_scope_alloc_zeroed(ptr %t122, i64 %t120)
  %t124 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l9, !tbaa !27
  %t127 = load i64, ptr %l0, !tbaa !24
  store i64 %t127, ptr %l62, !tbaa !24
  %t128 = load i64, ptr %l62, !tbaa !24
  %t129 = icmp sge i64 %t128, 0
  br i1 %t129, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_9ae088e360a77f54_f93713180ac9c008)
  unreachable
bb31:
  %t131 = load i64, ptr %l62, !tbaa !24
  %t132 = icmp sle i64 %t131, 384307168202282325
  br i1 %t132, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_2ec6064c293cb761_d5cc4c8f21af0275)
  unreachable
bb33:
  %t134 = load i64, ptr %l62, !tbaa !24
  %t135 = mul i64 %t134, 24
  %t136 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t135)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  store { i64, ptr } %t138, ptr %l10, !tbaa !27
  %t140 = load i64, ptr %l0, !tbaa !24
  store i64 %t140, ptr %l66, !tbaa !24
  %t141 = load i64, ptr %l66, !tbaa !24
  %t142 = icmp sge i64 %t141, 0
  br i1 %t142, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_2ec6064c293cb761_d5cc4c8f21af0275)
  unreachable
bb35:
  %t144 = load i64, ptr %l66, !tbaa !24
  %t145 = icmp sle i64 %t144, 1152921504606846975
  br i1 %t145, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_c8e1f518d05ff72e_7dbe2fc13ad1d5a)
  unreachable
bb37:
  %t147 = load i64, ptr %l66, !tbaa !24
  %t148 = mul i64 %t147, 8
  %t149 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l11, !tbaa !27
  %t153 = ptrtoint ptr %v0 to i64
  store i64 %t153, ptr %l70, !tbaa !24
  %t154 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e9
  br i1 %t154, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_c8e1f518d05ff72e_7dbe2fc13ad1d5a)
  unreachable
bb39:
  %t156 = call ptr @__olang_region_make(ptr %v0)
  %t157 = ptrtoint ptr %t156 to i64
  store i64 %t157, ptr %l70, !tbaa !24
  br label %bb40
bb40:
  %t158 = load i64, ptr %l0, !tbaa !24
  store i64 %t158, ptr %l72, !tbaa !24
  %t159 = load i64, ptr %l72, !tbaa !24
  %t160 = icmp sge i64 %t159, 0
  br i1 %t160, label %bb41, label %bb42
bb41:
  %t162 = load i64, ptr %l72, !tbaa !24
  %t163 = icmp sle i64 %t162, 1152921504606846975
  br i1 %t163, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_74963255e70253a3_2345454c3593352f)
  unreachable
bb43:
  %t165 = load i64, ptr %l72, !tbaa !24
  %t166 = mul i64 %t165, 8
  %t167 = load i64, ptr %l70
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_held_alloc(ptr %t168, i64 %t166)
  store i64 0, ptr %t170
  br label %fill.171
fill.171:
  %t174 = load i64, ptr %t170
  %t175 = icmp slt i64 %t174, %t165
  br i1 %t175, label %fillb.172, label %filld.173
fillb.172:
  %t176 = getelementptr i64, ptr %t169, i64 %t174
  store i64 -1, ptr %t176
  %t177 = add i64 %t174, 1
  store i64 %t177, ptr %t170
  br label %fill.171
filld.173:
  %t178 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t169, 1
  store { i64, ptr } %t179, ptr %l12, !tbaa !27
  %t181 = ptrtoint ptr %v0 to i64
  store i64 %t181, ptr %l76, !tbaa !24
  %t182 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e10
  br i1 %t182, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_74963255e70253a3_2345454c3593352f)
  unreachable
bb45:
  %t184 = call ptr @__olang_region_make(ptr %v0)
  %t185 = ptrtoint ptr %t184 to i64
  store i64 %t185, ptr %l76, !tbaa !24
  br label %bb46
bb46:
  %t186 = load i64, ptr %l0, !tbaa !24
  store i64 %t186, ptr %l78, !tbaa !24
  %t187 = load i64, ptr %l78, !tbaa !24
  %t188 = icmp sge i64 %t187, 0
  br i1 %t188, label %bb47, label %bb48
bb47:
  %t190 = load i64, ptr %l78, !tbaa !24
  %t191 = icmp sle i64 %t190, 1152921504606846975
  br i1 %t191, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_246582a5b3ca2693_193f7b7ac5c42ad7)
  unreachable
bb49:
  %t193 = load i64, ptr %l78, !tbaa !24
  %t194 = mul i64 %t193, 8
  %t195 = load i64, ptr %l76
  %t196 = inttoptr i64 %t195 to ptr
  %t197 = call ptr @__olang_held_alloc(ptr %t196, i64 %t194)
  store i64 0, ptr %t198
  br label %fill.199
fill.199:
  %t202 = load i64, ptr %t198
  %t203 = icmp slt i64 %t202, %t193
  br i1 %t203, label %fillb.200, label %filld.201
fillb.200:
  %t204 = getelementptr i64, ptr %t197, i64 %t202
  store i64 -1, ptr %t204
  %t205 = add i64 %t202, 1
  store i64 %t205, ptr %t198
  br label %fill.199
filld.201:
  %t206 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t197, 1
  store { i64, ptr } %t207, ptr %l13, !tbaa !27
  %t209 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t209, ptr %l82
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_246582a5b3ca2693_193f7b7ac5c42ad7)
  unreachable
bb51:
  %t210 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t210, ptr %l14
  %t211 = ptrtoint ptr %v0 to i64
  store i64 %t211, ptr %l83, !tbaa !24
  %t212 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e12
  br i1 %t212, label %bb52, label %bb53
bb52:
  %t214 = call ptr @__olang_region_make(ptr %v0)
  %t215 = ptrtoint ptr %t214 to i64
  store i64 %t215, ptr %l83, !tbaa !24
  br label %bb53
bb53:
  %t216 = load i64, ptr %l83
  %t217 = inttoptr i64 %t216 to ptr
  %t218 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t217, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t218, ptr %l85
  br label %bb54
bb54:
  %t219 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e12
  br i1 %t219, label %bb55, label %bb56
bb55:
  %t221 = load i64, ptr %l83
  %t222 = inttoptr i64 %t221 to ptr
  %t223 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85, i32 0, i32 0
  %t224 = load { i64, ptr }, ptr %t223
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = call ptr @__olang_region_or(ptr %t225, ptr null)
  %t227 = call ptr @__olang_region_home(ptr %t226)
  %t228 = icmp ne ptr %t227, null
  %t229 = select i1 %t228, ptr %t227, ptr null
  %t230 = icmp eq ptr %t229, %t222
  call void @__olang_region_settle(ptr %t222, i1 %t230)
  br label %bb56
bb56:
  %t231 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t231, ptr %l15
  %t232 = ptrtoint ptr %v0 to i64
  store i64 %t232, ptr %l87, !tbaa !24
  %t233 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e13
  br i1 %t233, label %bb57, label %bb58
bb57:
  %t235 = call ptr @__olang_region_make(ptr %v0)
  %t236 = ptrtoint ptr %t235 to i64
  store i64 %t236, ptr %l87, !tbaa !24
  br label %bb58
bb58:
  %t237 = load i64, ptr %l0, !tbaa !24
  store i64 %t237, ptr %l89, !tbaa !24
  %t238 = load i64, ptr %l89, !tbaa !24
  %t239 = icmp sge i64 %t238, 0
  br i1 %t239, label %bb59, label %bb60
bb59:
  %t241 = load i64, ptr %l89, !tbaa !24
  %t242 = icmp sle i64 %t241, 1152921504606846975
  br i1 %t242, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_9dd38347e47b515e_f9e635a831e39e22)
  unreachable
bb61:
  %t244 = load i64, ptr %l89, !tbaa !24
  %t245 = mul i64 %t244, 8
  %t246 = load i64, ptr %l87
  %t247 = inttoptr i64 %t246 to ptr
  %t248 = call ptr @__olang_held_alloc(ptr %t247, i64 %t245)
  store i64 0, ptr %t249
  br label %fill.250
fill.250:
  %t253 = load i64, ptr %t249
  %t254 = icmp slt i64 %t253, %t244
  br i1 %t254, label %fillb.251, label %filld.252
fillb.251:
  %t255 = getelementptr i64, ptr %t248, i64 %t253
  store i64 -1, ptr %t255
  %t256 = add i64 %t253, 1
  store i64 %t256, ptr %t249
  br label %fill.250
filld.252:
  %t257 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t248, 1
  store { i64, ptr } %t258, ptr %l16, !tbaa !27
  %t260 = ptrtoint ptr %v0 to i64
  store i64 %t260, ptr %l93, !tbaa !24
  %t261 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e14
  br i1 %t261, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_9dd38347e47b515e_f9e635a831e39e22)
  unreachable
bb63:
  %t263 = call ptr @__olang_region_make(ptr %v0)
  %t264 = ptrtoint ptr %t263 to i64
  store i64 %t264, ptr %l93, !tbaa !24
  br label %bb64
bb64:
  %t265 = load i64, ptr %l0, !tbaa !24
  store i64 %t265, ptr %l95, !tbaa !24
  %t266 = load i64, ptr %l95, !tbaa !24
  %t267 = icmp sge i64 %t266, 0
  br i1 %t267, label %bb65, label %bb66
bb65:
  %t269 = load i64, ptr %l95, !tbaa !24
  %t270 = icmp sle i64 %t269, 1152921504606846975
  br i1 %t270, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_34c0f2b90676669d_3857a098f6688741)
  unreachable
bb67:
  %t272 = load i64, ptr %l95, !tbaa !24
  %t273 = mul i64 %t272, 8
  %t274 = load i64, ptr %l93
  %t275 = inttoptr i64 %t274 to ptr
  %t276 = call ptr @__olang_scope_alloc_zeroed(ptr %t275, i64 %t273)
  %t277 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  store { i64, ptr } %t278, ptr %l17, !tbaa !27
  %t280 = ptrtoint ptr %v0 to i64
  store i64 %t280, ptr %l99, !tbaa !24
  %t281 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e15
  br i1 %t281, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_34c0f2b90676669d_3857a098f6688741)
  unreachable
bb69:
  %t283 = call ptr @__olang_region_make(ptr %v0)
  %t284 = ptrtoint ptr %t283 to i64
  store i64 %t284, ptr %l99, !tbaa !24
  br label %bb70
bb70:
  %t285 = load i64, ptr %l0, !tbaa !24
  store i64 %t285, ptr %l101, !tbaa !24
  %t286 = load i64, ptr %l101, !tbaa !24
  %t287 = icmp sge i64 %t286, 0
  br i1 %t287, label %bb71, label %bb72
bb71:
  %t289 = load i64, ptr %l101, !tbaa !24
  %t290 = icmp sle i64 %t289, 1152921504606846975
  br i1 %t290, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_f7f5500b221013f0_a265fad2981ec934)
  unreachable
bb73:
  %t292 = load i64, ptr %l101, !tbaa !24
  %t293 = mul i64 %t292, 8
  %t294 = load i64, ptr %l99
  %t295 = inttoptr i64 %t294 to ptr
  %t296 = call ptr @__olang_scope_alloc_zeroed(ptr %t295, i64 %t293)
  %t297 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t296, 1
  store { i64, ptr } %t298, ptr %l18, !tbaa !27
  %t300 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t300, ptr %l105
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_f7f5500b221013f0_a265fad2981ec934)
  unreachable
bb75:
  %t301 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l105
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t301, ptr %l19
  %t302 = ptrtoint ptr %v0 to i64
  store i64 %t302, ptr %l106, !tbaa !24
  %t303 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e17
  br i1 %t303, label %bb76, label %bb77
bb76:
  %t305 = call ptr @__olang_region_make(ptr %v0)
  %t306 = ptrtoint ptr %t305 to i64
  store i64 %t306, ptr %l106, !tbaa !24
  br label %bb77
bb77:
  %t307 = load i64, ptr %l106
  %t308 = inttoptr i64 %t307 to ptr
  %t309 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t308, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t309, ptr %l108
  br label %bb78
bb78:
  %t310 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e17
  br i1 %t310, label %bb79, label %bb80
bb79:
  %t312 = load i64, ptr %l106
  %t313 = inttoptr i64 %t312 to ptr
  %t314 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l108, i32 0, i32 0
  %t315 = load { i64, ptr }, ptr %t314
  %t316 = extractvalue { i64, ptr } %t315, 1
  %t317 = call ptr @__olang_region_or(ptr %t316, ptr null)
  %t318 = call ptr @__olang_region_home(ptr %t317)
  %t319 = icmp ne ptr %t318, null
  %t320 = select i1 %t319, ptr %t318, ptr null
  %t321 = icmp eq ptr %t320, %t313
  call void @__olang_region_settle(ptr %t313, i1 %t321)
  br label %bb80
bb80:
  %t322 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l108
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t322, ptr %l20
  %t323 = ptrtoint ptr %v0 to i64
  store i64 %t323, ptr %l110, !tbaa !24
  %t324 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e18
  br i1 %t324, label %bb81, label %bb82
bb81:
  %t326 = call ptr @__olang_region_make(ptr %v0)
  %t327 = ptrtoint ptr %t326 to i64
  store i64 %t327, ptr %l110, !tbaa !24
  br label %bb82
bb82:
  %t328 = load i64, ptr %l110
  %t329 = inttoptr i64 %t328 to ptr
  %t330 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t329, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t330, ptr %l112
  br label %bb83
bb83:
  %t331 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3aPlan_2e18
  br i1 %t331, label %bb84, label %bb85
bb84:
  %t333 = load i64, ptr %l110
  %t334 = inttoptr i64 %t333 to ptr
  %t335 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112, i32 0, i32 0
  %t336 = load { i64, ptr }, ptr %t335
  %t337 = extractvalue { i64, ptr } %t336, 1
  %t338 = call ptr @__olang_region_or(ptr %t337, ptr null)
  %t339 = call ptr @__olang_region_home(ptr %t338)
  %t340 = icmp ne ptr %t339, null
  %t341 = select i1 %t340, ptr %t339, ptr null
  %t342 = icmp eq ptr %t341, %t334
  call void @__olang_region_settle(ptr %t334, i1 %t342)
  br label %bb85
bb85:
  %t343 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t343, ptr %l21
  %t344 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H1ef0ed4704dec6d220ade362c849361f(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t344, ptr %l114
  br label %bb86
bb86:
  %t345 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l114
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t345, ptr %l22
  %t346 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t346, ptr %l115
  br label %bb87
bb87:
  %t347 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l115
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t347, ptr %l23
  %t348 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t348, ptr %l116
  br label %bb88
bb88:
  %t349 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l116
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t349, ptr %l24
  %t350 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t350, ptr %l117
  br label %bb89
bb89:
  %t351 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l117
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t351, ptr %l25
  %t352 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t352, ptr %l118
  br label %bb90
bb90:
  %t353 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l118
  %t354 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 0
  %t355 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t355, ptr %t354, !tbaa !27
  %t356 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 1
  %t357 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t357, ptr %t356, !tbaa !27
  %t358 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 2
  %t359 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t359, ptr %t358, !tbaa !27
  %t360 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 3
  %t361 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t361, ptr %t360, !tbaa !27
  %t362 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 4
  %t363 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t363, ptr %t362, !tbaa !27
  %t364 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 5
  %t365 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t365, ptr %t364, !tbaa !27
  %t366 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 6
  %t367 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t367, ptr %t366, !tbaa !27
  %t368 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 7
  %t369 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t369, ptr %t368, !tbaa !27
  %t370 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 8
  %t371 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t371, ptr %t370, !tbaa !27
  %t372 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 9
  %t373 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t373, ptr %t372, !tbaa !27
  %t374 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 10
  %t375 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t375, ptr %t374, !tbaa !27
  %t376 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 11
  %t377 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t377, ptr %t376
  %t378 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 12
  %t379 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t379, ptr %t378
  %t380 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 13
  %t381 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t381, ptr %t380, !tbaa !27
  %t382 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 14
  %t383 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t383, ptr %t382, !tbaa !27
  %t384 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 15
  %t385 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t385, ptr %t384, !tbaa !27
  %t386 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 16
  %t387 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t387, ptr %t386
  %t388 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 17
  %t389 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t389, ptr %t388
  %t390 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 18
  %t391 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t391, ptr %t390
  %t392 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 19
  %t393 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l22
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t393, ptr %t392
  %t394 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 20
  %t395 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t395, ptr %t394
  %t396 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 21
  %t397 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t397, ptr %t396
  %t398 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 22
  %t399 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t399, ptr %t398
  %t400 = getelementptr %"compiler/typed:Plan", ptr %l119, i32 0, i32 23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t353, ptr %t400
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l119, i64 584, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Seq"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Seq" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/typed:Seq" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:Seq" %t10, i1 %a2, 2
  store %"compiler/typed:Seq" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Seq", ptr %rv
  ret %"compiler/typed:Seq" %rr
}

define dso_local %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:SiteInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:SiteInfo" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:SiteInfo" %t6, %"compiler/source:Span" %a1, 1
  store %"compiler/typed:SiteInfo" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:SiteInfo", ptr %rv
  ret %"compiler/typed:SiteInfo" %rr
}

define dso_local %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/typed:Spawn"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/typed:Spawn" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/typed:Spawn" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/typed:Spawn" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/typed:Spawn" %t14, i32 %a3, 3
  store %"compiler/typed:Spawn" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Spawn", ptr %rv
  ret %"compiler/typed:Spawn" %rr
}

define dso_local %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Text"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Text" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/typed:Text" %t6, i32 %a1, 1
  store %"compiler/typed:Text" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Text", ptr %rv
  ret %"compiler/typed:Text" %rr
}

define dso_local %"compiler/typed:landLoop" @compiler_2ftyped_3alandLoop_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %rv = alloca %"compiler/typed:landLoop"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l2, !tbaa !23
  %t3 = load i64, ptr %l1, !tbaa !24
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = ptrtoint ptr %v0 to i64
  store i64 %t5, ptr %l10, !tbaa !24
  %t6 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3alandLoop_2e2
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = call ptr @__olang_region_make(ptr %v0)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l10, !tbaa !24
  br label %bb2
bb2:
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l12, !tbaa !24
  %t11 = load i64, ptr %l12, !tbaa !24
  %t12 = icmp sge i64 %t11, 0
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = load i64, ptr %l10
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %t17, i64 %t15)
  %t19 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t22 = ptrtoint ptr %v0 to i64
  store i64 %t22, ptr %l15, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2ftyped_3alandLoop_2e3
  br i1 %t23, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_652e3003820639e_452d7c4eea959e6a)
  unreachable
bb5:
  %t25 = call ptr @__olang_region_make(ptr %v0)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t27 = load i64, ptr %l1, !tbaa !24
  store i64 %t27, ptr %l17, !tbaa !24
  %t28 = load i64, ptr %l17, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = load i64, ptr %l17, !tbaa !24
  %t32 = mul i64 %t31, 1
  %t33 = load i64, ptr %l15
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_scope_alloc_zeroed(ptr %t34, i64 %t32)
  %t36 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  %t39 = load i32, ptr %l2, !tbaa !23
  %t40 = insertvalue %"compiler/typed:landLoop" undef, i32 %t39, 0
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = insertvalue %"compiler/typed:landLoop" %t40, i64 %t41, 1
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t44 = insertvalue %"compiler/typed:landLoop" %t42, { i64, ptr } %t43, 2
  %t46 = insertvalue %"compiler/typed:landLoop" %t44, { i64, ptr } %t37, 3
  %t48 = insertvalue %"compiler/typed:landLoop" %t46, i1 false, 4
  %t50 = insertvalue %"compiler/typed:landLoop" %t48, i1 false, 5
  store %"compiler/typed:landLoop" %t50, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_6ab171d7108733d3_fb4921eacef8293f)
  unreachable
ret:
  %rr = load %"compiler/typed:landLoop", ptr %rv
  ret %"compiler/typed:landLoop" %rr
}

define dso_local %"compiler/typed:wordReader" @compiler_2ftyped_3awordReader_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %rv = alloca %"compiler/typed:wordReader"
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:wordReader" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/typed:wordReader" %t6, { ptr, ptr } %pg1, 1
  %t10 = insertvalue %"compiler/typed:wordReader" %t8, i64 0, 2
  store %"compiler/typed:wordReader" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:wordReader", ptr %rv
  ret %"compiler/typed:wordReader" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 9}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 9}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb15
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 7, label %bb7 i64 8, label %bb8 ]
bb3:
  br label %bb15
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb9, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb10, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb11, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 0
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 0
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb13, label %bb1
bb9:
  br label %bb3
bb10:
  br label %bb3
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64 }, ptr %t71, i32 0, i32 1
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64 }, ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb14, label %bb1
bb14:
  br label %bb3
bb15:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define internal i1 @olang_lambda_0(ptr %env, ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %a0)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  store i1 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"U" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"P" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"F" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"I" }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d6 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"body " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d7 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" locals " }>, align 8
@.d8 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" blocks " }>, align 8
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" sites" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@olang_2esole_2ecompiler_2ftyped_3alandState_2e0 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
declare ptr @__olang_scope_or(ptr, ptr)
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aVersions__2eclauses_2elocal_2e4 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle(ptr, i1)
declare void @__olang_region_drop(ptr) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_2esole_2ecompiler__2ftyped__2ecompiler__2ftyped__3aholdWalk__2efnVal_2elocal_2e2 = weak hidden constant i1 false
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d11 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(lit " }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d14 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(data " }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d17 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(read " }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d21 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"(borrow " }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d24 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(take " }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d26 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"(promote " }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d28 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(call " }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aMakeKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 5}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
ret:
  ret void
}

declare void @__olang_sb_done(ptr)
@.d34 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(make " }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d37 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"(collect " }>, align 8
@.d38 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aPrimOp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 51}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 i64 9, label %bb11 i64 10, label %bb12 i64 11, label %bb13 i64 12, label %bb14 i64 13, label %bb15 i64 14, label %bb16 i64 15, label %bb17 i64 16, label %bb18 i64 17, label %bb19 i64 18, label %bb20 i64 19, label %bb21 i64 20, label %bb22 i64 21, label %bb23 i64 22, label %bb24 i64 23, label %bb25 i64 24, label %bb26 i64 25, label %bb27 i64 26, label %bb28 i64 27, label %bb29 i64 28, label %bb30 i64 29, label %bb31 i64 30, label %bb32 i64 31, label %bb33 i64 32, label %bb34 i64 33, label %bb35 i64 34, label %bb36 i64 35, label %bb37 i64 36, label %bb38 i64 37, label %bb39 i64 38, label %bb40 i64 39, label %bb41 i64 40, label %bb42 i64 41, label %bb43 i64 42, label %bb44 i64 43, label %bb45 i64 44, label %bb46 i64 45, label %bb47 i64 46, label %bb48 i64 47, label %bb49 i64 48, label %bb50 i64 49, label %bb51 i64 50, label %bb52 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
bb6:
  %t13 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t13, i64 %t14)
  br label %bb1
bb7:
  %t15 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t15, i64 %t16)
  br label %bb1
bb8:
  %t17 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb9:
  %t19 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t19, i64 %t20)
  br label %bb1
bb10:
  %t21 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t21, i64 %t22)
  br label %bb1
bb11:
  %t23 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t23, i64 %t24)
  br label %bb1
bb12:
  %t25 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t25, i64 %t26)
  br label %bb1
bb13:
  %t27 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t27, i64 %t28)
  br label %bb1
bb14:
  %t29 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t29, i64 %t30)
  br label %bb1
bb15:
  %t31 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb16:
  %t33 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb17:
  %t35 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  br label %bb1
bb18:
  %t37 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  br label %bb1
bb19:
  %t39 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t39, i64 %t40)
  br label %bb1
bb20:
  %t41 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t41, i64 %t42)
  br label %bb1
bb21:
  %t43 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t43, i64 %t44)
  br label %bb1
bb22:
  %t45 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t45, i64 %t46)
  br label %bb1
bb23:
  %t47 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb24:
  %t49 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb25:
  %t51 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb26:
  %t53 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  br label %bb1
bb27:
  %t55 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb28:
  %t57 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  br label %bb1
bb29:
  %t59 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  br label %bb1
bb30:
  %t61 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t61, i64 %t62)
  br label %bb1
bb31:
  %t63 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t63, i64 %t64)
  br label %bb1
bb32:
  %t65 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t65, i64 %t66)
  br label %bb1
bb33:
  %t67 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t67, i64 %t68)
  br label %bb1
bb34:
  %t69 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t69, i64 %t70)
  br label %bb1
bb35:
  %t71 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t71, i64 %t72)
  br label %bb1
bb36:
  %t73 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t73, i64 %t74)
  br label %bb1
bb37:
  %t75 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t75, i64 %t76)
  br label %bb1
bb38:
  %t77 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  br label %bb1
bb39:
  %t79 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t79, i64 %t80)
  br label %bb1
bb40:
  %t81 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t81, i64 %t82)
  br label %bb1
bb41:
  %t83 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t83, i64 %t84)
  br label %bb1
bb42:
  %t85 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t85, i64 %t86)
  br label %bb1
bb43:
  %t87 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t87, i64 %t88)
  br label %bb1
bb44:
  %t89 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t89, i64 %t90)
  br label %bb1
bb45:
  %t91 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t91, i64 %t92)
  br label %bb1
bb46:
  %t93 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t93, i64 %t94)
  br label %bb1
bb47:
  %t95 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t95, i64 %t96)
  br label %bb1
bb48:
  %t97 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t97, i64 %t98)
  br label %bb1
bb49:
  %t99 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t99, i64 %t100)
  br label %bb1
bb50:
  %t101 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t101, i64 %t102)
  br label %bb1
bb51:
  %t103 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t103, i64 %t104)
  br label %bb1
bb52:
  %t105 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t105, i64 %t106)
  br label %bb1
ret:
  ret void
}

define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aCheck(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 4}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb3:
  %t7 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t8 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  br label %bb1
bb4:
  %t9 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb1
bb5:
  %t11 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb1
ret:
  ret void
}

@.d40 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d45 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"(slice " }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d48 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(cond " }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(seq " }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d54 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"(match " }>, align 8
@.d55 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" arms, nomatch " }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d57 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(try " }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d59 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" clauses)" }>, align 8
@.d60 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"(fn " }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d62 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(text " }>, align 8
@.d63 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d65 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(away " }>, align 8
@.d66 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"G" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"*" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d75 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" as " }>, align 8
@.d76 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"tmp " }>, align 8
@.d77 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d78 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"target" }>, align 8
@.d79 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"text " }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e7 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e8 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e9 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e11 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e13 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e14 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e15 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e16 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e17 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e18 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e19 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e22 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e23 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e24 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e28 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e29 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e30 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e31 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e32 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e33 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e34 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e35 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e36 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e37 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e38 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e39 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e40 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e41 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e42 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aLocalUses_2e44 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e9 = weak hidden constant i1 false
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e10 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e12 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e13 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e14 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e15 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e17 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3aPlan_2e18 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H1ef0ed4704dec6d220ade362c849361f(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2ftyped_3alandLoop_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ftyped_3alandLoop_2e3 = weak hidden constant i1 false
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@.d82 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.MakeKind.Tuple" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d83 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.MakeKind.Case" }>, align 8
@.d84 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.MakeKind.Array" }>, align 8
@.d85 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.MakeKind.Fill" }>, align 8
@.d86 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.MakeKind.Copy" }>, align 8
@.d87 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Neg" }>, align 8
@.d88 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.BitNot" }>, align 8
@.d89 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Not" }>, align 8
@.d90 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Add" }>, align 8
@.d91 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Sub" }>, align 8
@.d92 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Mul" }>, align 8
@.d93 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Div" }>, align 8
@.d94 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Rem" }>, align 8
@.d95 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Shl" }>, align 8
@.d96 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Shr" }>, align 8
@.d97 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.BitAnd" }>, align 8
@.d98 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.PrimOp.BitOr" }>, align 8
@.d99 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.BitXor" }>, align 8
@.d100 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Eq" }>, align 8
@.d101 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Ne" }>, align 8
@.d102 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Lt" }>, align 8
@.d103 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Le" }>, align 8
@.d104 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Gt" }>, align 8
@.d105 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.PrimOp.Ge" }>, align 8
@.d106 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.PrimOp.Same" }>, align 8
@.d107 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.Convert" }>, align 8
@.d108 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.Bitcast" }>, align 8
@.d109 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.PrimOp.Len" }>, align 8
@.d110 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.IsCase" }>, align 8
@.d111 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"typed.PrimOp.AtomicLoad" }>, align 8
@.d112 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.AtomicStore" }>, align 8
@.d113 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"typed.PrimOp.AtomicAdd" }>, align 8
@.d114 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"typed.PrimOp.AtomicSwap" }>, align 8
@.d115 = private unnamed_addr constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"typed.PrimOp.AtomicCompareSwap" }>, align 8
@.d116 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.Retire" }>, align 8
@.d117 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.PrimOp.Drop" }>, align 8
@.d118 = private unnamed_addr constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"typed.PrimOp.LeadingZeros" }>, align 8
@.d119 = private unnamed_addr constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"typed.PrimOp.TrailingZeros" }>, align 8
@.d120 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.PopCount" }>, align 8
@.d121 = private unnamed_addr constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"typed.PrimOp.RotateLeft" }>, align 8
@.d122 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.RotateRight" }>, align 8
@.d123 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.ByteSwap" }>, align 8
@.d124 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.LaneLen" }>, align 8
@.d125 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.NonEmpty" }>, align 8
@.d126 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.Unpack" }>, align 8
@.d127 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.Repack" }>, align 8
@.d128 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.AnyMake" }>, align 8
@.d129 = private unnamed_addr constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"typed.PrimOp.AnyInstance" }>, align 8
@.d130 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.PrimOp.AnyIs" }>, align 8
@.d131 = private unnamed_addr constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"typed.PrimOp.ErrPush" }>, align 8
@.d132 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"typed.PrimOp.ErrCaught" }>, align 8
@.d133 = private unnamed_addr constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"typed.PrimOp.ErrTaken" }>, align 8
@.d134 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.SatAdd" }>, align 8
@.d135 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.SatSub" }>, align 8
@.d136 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.SatMul" }>, align 8
@.d137 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.PrimOp.SatShl" }>, align 8
@.d138 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"typed.Check.None" }>, align 8
@.d139 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.Check.Abort" }>, align 8
@.d140 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.Check.Try" }>, align 8
@.d141 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.Check.Debug" }>, align 8
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
@olang_loc_4e05db95f2fd54c5_981a3a3cc6318dd9 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eturnStmt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
declare { i64, [2 x i64] } @compiler_2ftyped_2eScope_2eresult(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i1 @compiler_2ftyped_2eMovedArg(ptr %v0, ptr %a0)
declare i64 @compiler_2ftyped_2efreshText(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2ftyped_2eCall_2efresh(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ftyped_2enoCallbackNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/typed:Nodes" @compiler_2ftyped_3aNodes_2ector(ptr %v0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ePurePlace(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2farray_2eArray_3ccompiler_2ftyped_3aExpr_26_3e_2eEvery_3ccompiler_2ftyped_3aExpr_26_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
@olang_loc_d912efc235b928ee_346c19f829a98a12 = external constant [0 x i8]
@olang_loc_65920c013e21fbcc_fef959193df4a870 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_e2b5788ffb480e02_d22fdd1ca3ce21ae = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2f2480bdb29d1aff_ebfa87e8ba0b0aab = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_689ec1bc34b2e694_7c9684f7b2e5e930 = external constant [0 x i8]
@olang_loc_6a803bf61431eeb2_dc93aee23e6eb17e = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@olang_loc_720fd1e6659a9cc9_2e78a3e82d892a55 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_352016b8dfbaae41_4f83dc304b77dded = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:printer" @compiler_2ftyped_3aprinter_2ector(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eLen_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_b47e7a13871964ca_e65b2c3f8690a096 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eHas_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emention(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eapart(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ekeptBy(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
declare %"compiler/typed:landState" @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2esave(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2ematchExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_9444a0fe500d35e5_4f818c2c3ae57dd9 = external constant [0 x i8]
@olang_loc_af04a8710b199599_1473152472f015d = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_198aad80d0550ab5_c06608159f163401 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eapart(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2ecopyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_28655f8a56cf669d_dc60f62ebe04c639 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_d36f57f073c6a2ff_232866ca740484ab = external constant [0 x i8]
@olang_loc_faea1712f2053751_ed9fc9ee56afb56d = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4860703a134569c9_d00fc34d053d5355 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elendOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempLent(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2)
declare ptr @compiler_2ftyped_2econverted(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:argRoot" @compiler_2ftyped_3aargRoot_2ector(ptr %v0, i64 %a0, i1 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2d500740710f6411_bcf53f428dcf676d = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftyped_2escalarType(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e6cc28bf48cbd31_b57ed710b41deab5 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2efieldsOnly(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c33a5c6933895_a18ea8bdcccb3229 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, ptr %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, [1 x i64] } %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etargets(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1)
@olang_loc_9a2d2471d97215b1_125b5d47933e1fad = external constant [0 x i8]
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2dc1351d0e6e1c9_f66be85c5a6693dd = external constant [0 x i8]
@olang_loc_35eb3a0a3b047e6d_bf317ca81d1426a1 = external constant [0 x i8]
@olang_loc_e2587c8ec5c6f861_9513078f5b00021d = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aNodes_2eopt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f34835f3d61f57d9_feeccb0fe1526945 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H05bdc185ea10b7cb65a89c49d4b056c8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eLen_H205a9438cb31641857cd9c1e93810664(ptr %v0, ptr %a0)
declare %"compiler/typed:DerivedArg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_2eAt__H3d322c834b4b1582ab12028f5b0f20b9(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eSetAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2enamedOnly(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2elinkLevel(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eescapes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, i64 %a4, i1 %a5, i64 %a6)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_43c6edd5f3ea6aa2_25eece1f43523776 = external constant [0 x i8]
@olang_loc_8a2b699ea2f67509_3bce0390ecfabbdd = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_a872ad126d8d9744_e4960385d07a8740 = external constant [0 x i8]
@olang_loc_f34031efedf98c99_ae8fa248572091b5 = external constant [0 x i8]
@olang_loc_1baf36c5dd0b9bdd_a2c9e1d98e30c571 = external constant [0 x i8]
@olang_loc_49ff4d0dc0b12b63_5e68d9fa98bc7cb7 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eall(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eend(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eresultLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, i1 %a3)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eparamBit(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_34c65fd26df9bfcd_2dc4d2164b9a2f69 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %a0, i1 %a1)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2etry(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e0d071190e38de5d_291e4ea72946f179 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2enumber(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9f9fe097503cda9_c6b719cc2534ac35 = external constant [0 x i8]
declare i64 @compiler_2ftyped_2eDropFlag(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_c533040496e87321_52fb908a3762307d = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2eunion(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eToArra_H50cbff9caa8a2389caf3e92da7e24507(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2emix(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1)
@olang_loc_3d59d966d65a5e81_dc9cdefe852f3965 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eencloses(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclosure(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2einBlock(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2ecallee(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexprs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftyped_2eshort(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_a4fa64762613be8a_d12da9b666f393e6 = external constant [0 x i8]
@olang_loc_a387a9465b9f2118_49b9af8105801174 = external constant [0 x i8]
@olang_loc_16612f18a9afa54d_299c1e15a68a5059 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftyped_2econstItems(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_411550143d3b0e9d_42067e02948bd729 = external constant [0 x i8]
@olang_loc_c89b2ac703a55b51_f16b1206186d62d = external constant [0 x i8]
declare i1 @compiler_2ftyped_2estoresNothing(i32 %a0)
declare i1 @compiler_2ftyped_2eallInert(ptr %v0, { i64, ptr } %a0)
@olang_loc_3f2c6ecf541578c9_647b3946439e894d = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eclausesBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2ftyped_2etargetsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
@olang_loc_ab0bd1a1cb525619_8191fed8583864ed = external constant [0 x i8]
@olang_loc_9bf6326dc96b231_1fb9b096f472b9bd = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@olang_loc_480f1658b5360f56_487a5534952ab742 = external constant [0 x i8]
@olang_loc_8f643c1a2619646b_285ffd8328f7aef7 = external constant [0 x i8]
@olang_loc_879aacf2d1a22b08_c7cef0899cf1454 = external constant [0 x i8]
@olang_loc_642fe669e8876d75_a0626c7162644c61 = external constant [0 x i8]
@olang_loc_d6ddef0f5c032242_b9ab7c7dee5da456 = external constant [0 x i8]
@olang_loc_b6c3975defd019f7_100a23f5f40f96b = external constant [0 x i8]
@olang_loc_9ae088e360a77f54_f93713180ac9c008 = external constant [0 x i8]
@olang_loc_2ec6064c293cb761_d5cc4c8f21af0275 = external constant [0 x i8]
@olang_loc_c8e1f518d05ff72e_7dbe2fc13ad1d5a = external constant [0 x i8]
@olang_loc_74963255e70253a3_2345454c3593352f = external constant [0 x i8]
@olang_loc_246582a5b3ca2693_193f7b7ac5c42ad7 = external constant [0 x i8]
@olang_loc_9dd38347e47b515e_f9e635a831e39e22 = external constant [0 x i8]
@olang_loc_34c0f2b90676669d_3857a098f6688741 = external constant [0 x i8]
@olang_loc_f7f5500b221013f0_a265fad2981ec934 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_652e3003820639e_452d7c4eea959e6a = external constant [0 x i8]
@olang_loc_6ab171d7108733d3_fb4921eacef8293f = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
