; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/prompt:Reply" = type { i1, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, { i64, ptr }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, i1, i1, i64, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/net:Addr" = type { %"std/net:IP", i16 }
%"std/net:IP" = type { i1, [16 x i8] }
%"compiler/prompt:Session" = type { ptr, i64, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/eval:Snapshot", { ptr, ptr }, i1, i1, %"compiler/cells:Worker", %"compiler/build:Config", { i64, ptr } }
%"compiler/eval:Snapshot" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/cells:Worker" = type { i1, i32, i32, i32, i32, i32, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/jupyter:pending" = type { i64, { i64, ptr } }
%"compiler/jupyter:kernel" = type { { i64, ptr }, { i64, ptr }, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/net:Listener" = type { i32 }
%"std/zmtp:Socket" = type { %"std/net:Conn", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1 }
%"std/net:Conn" = type { i32 }
%"compiler/jupyter:Capture" = type { i32, i32, i32 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/jupyter:request" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/prompt:Decl" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64 }
%"compiler/prompt:Value" = type { { i64, ptr }, { i64, ptr }, i1, i64, { i64, ptr }, { i64, ptr } }
define dso_local { i64, ptr } @compiler_2fjupyter_2eData(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l12 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store ptr %l1, ptr %l4, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/prompt:Reply", ptr %t3, i32 0, i32 3
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store { i64, ptr } %t8, ptr %l7
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t11 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = add i64 %t10, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t9, i64 %t10)
  %t16 = getelementptr i8, ptr %t15, i64 %t10
  call void @olang_textcopy(ptr %t16, ptr %t12, i64 %t13)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t15, 1
  %t20 = load ptr, ptr %l4, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t20, { i64, ptr } %t18)
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/prompt:Reply", ptr %t22, i32 0, i32 6
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t25, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t27, ptr %l12
  br label %bb4
bb4:
  %t28 = load i1, ptr %l12, !tbaa !21
  %t29 = xor i1 %t28, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/prompt:Reply", ptr %t31, i32 0, i32 6
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t34, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t36, ptr %l16
  br label %bb7
bb6:
  br label %bb15
bb7:
  %t37 = load i1, ptr %l16, !tbaa !21
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/prompt:Reply", ptr %t38, i32 0, i32 7
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t44 = call { i64, ptr } @std_2fbase64_2eEncode(ptr %v0, ptr %v0, { i64, ptr } %t41)
  store { i64, ptr } %t44, ptr %l21
  br label %bb10
bb9:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/prompt:Reply", ptr %t45, i32 0, i32 7
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l17, !tbaa !27
  br label %bb11
bb10:
  %t50 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t50, ptr %l17, !tbaa !27
  br label %bb11
bb11:
  %t52 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t52, ptr %l2, !tbaa !27
  store ptr %l1, ptr %l25, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/prompt:Reply", ptr %t53, i32 0, i32 6
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %v0, ptr %s2, { i64, ptr } %t56)
  store { i64, ptr } %t58, ptr %l28
  br label %bb12
bb12:
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %v0, ptr %s2, { i64, ptr } %t59)
  store { i64, ptr } %t61, ptr %l30
  br label %bb13
bb13:
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t64 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = add i64 %t63, %t66
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t71 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = add i64 %t70, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t62, i64 %t63)
  %t76 = getelementptr i8, ptr %t75, i64 %t63
  call void @olang_textcopy(ptr %t76, ptr %t65, i64 %t66)
  %t77 = getelementptr i8, ptr %t76, i64 %t66
  call void @olang_textcopy(ptr %t77, ptr %t68, i64 %t69)
  %t78 = getelementptr i8, ptr %t77, i64 %t69
  call void @olang_textcopy(ptr %t78, ptr %t72, i64 %t73)
  %t79 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t75, 1
  %t82 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t82, { i64, ptr } %t80)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 125)
  br label %bb16
bb16:
  %t86 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t86, ptr %l35
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fjupyter_2eInstall(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i32, { i64, [2 x i64] } }
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i32, { i64, [2 x i64] } }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l25 = alloca i32
  %l27 = alloca i1
  %l28 = alloca { i32, { i64, [2 x i64] } }
  %l29 = alloca { i32, { i64, [2 x i64] } }
  %l30 = alloca i32
  %l35 = alloca { i32, { i64, [2 x i64] } }
  %l36 = alloca { i32, { i64, [2 x i64] } }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i32, { i64, [2 x i64] } }
  %l42 = alloca { i32, { i64, [2 x i64] } }
  %l43 = alloca i32
  %l58 = alloca { i64, ptr }
  %l60 = alloca i32
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l76 = alloca i32
  %l78 = alloca i1
  %l79 = alloca { i32, { i64, [2 x i64] } }
  %l80 = alloca { i32, { i64, [2 x i64] } }
  %l81 = alloca i32
  %l86 = alloca { i32, { i64, [2 x i64] } }
  %l87 = alloca { i32, { i64, [2 x i64] } }
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i32, { i64, [2 x i64] } }
  %l93 = alloca { i32, { i64, [2 x i64] } }
  %l94 = alloca i32
  %l109 = alloca { i64, ptr }
  %l111 = alloca i32
  %l114 = alloca i32
  %l116 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d5, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l10
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t6, ptr %l8, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l10, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l8, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t15, ptr %l14
  br label %bb7
bb7:
  %t16 = load i1, ptr %l14, !tbaa !21
  br i1 %t16, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s1, ptr %s1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) })
  %t18 = extractvalue { i32, { i64, ptr } } %t17, 1
  %t19 = extractvalue { i32, { i64, ptr } } %t17, 0
  store i32 %t19, ptr %l17
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb11, label %ok.21, !prof !99
ok.21:
  store { i64, ptr } %t18, ptr %l16
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  br label %bb15
bb11:
  %t23 = load i32, ptr %l17, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  br i1 %t26, label %bb12, label %bb13
bb12:
  call void @__olang_errpay_pop()
  br label %bb13
bb13:
  br label %bb14
bb14:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l15, !tbaa !27
  br label %bb15
bb15:
  %t28 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 1
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t29, i64 %t30)
  %t35 = getelementptr i8, ptr %t34, i64 %t30
  call void @olang_textcopy(ptr %t35, ptr %t31, i64 %t32)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t34, 1
  store { i64, ptr } %t37, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = extractvalue { i64, ptr } %t40, 0
  %t44 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = getelementptr i8, ptr %t47, i64 %t43
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l3, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t54 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t52)
  store i32 %t54, ptr %l25
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb18, label %ok.56, !prof !99
ok.56:
  br label %bb17
bb17:
  br label %bb42
bb18:
  %t57 = load i32, ptr %l25, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l27, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l4
  %t61 = load i32, ptr %l25, !tbaa !23
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t61, 65535
  %t64 = icmp eq i32 %t62, 1
  %t65 = select i1 %t64, i32 1, i32 0
  %t66 = icmp eq i32 %t61, 0
  %t67 = shl i32 %t65, 16
  %t68 = or i32 %t67, %t63
  %t69 = select i1 %t66, i32 0, i32 %t68
  %t70 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l4, i32 0, i32 0
  store i32 %t69, ptr %t70, !tbaa !23
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = load { i32, { i64, [2 x i64] } }, ptr %l4
  store { i32, { i64, [2 x i64] } } %t71, ptr %l28
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l29
  %t72 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l28, i32 0, i32 0
  %t73 = load i32, ptr %t72, !tbaa !23
  store i32 %t73, ptr %l30, !tbaa !23
  %t74 = load i32, ptr %l30, !tbaa !23
  %t75 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l29, i32 0, i32 0
  store i32 %t74, ptr %t75, !tbaa !23
  %t76 = load i32, ptr %l30, !tbaa !23
  %t77 = ashr i32 %t76, 16
  %t79 = icmp eq i32 %t77, 1
  br i1 %t79, label %bb20, label %bb21
bb20:
  %t81 = call ptr @__olang_errpay_top_get()
  %t83 = load { i64, [2 x i64] }, ptr %t81
  %t84 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l29, i32 0, i32 1
  store { i64, [2 x i64] } %t83, ptr %t84
  br label %bb21
bb21:
  %t86 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l29)
  store { i32, { i64, [2 x i64] } } %t86, ptr %l35
  br label %bb22
bb22:
  %t87 = load { i32, { i64, [2 x i64] } }, ptr %l35
  store { i32, { i64, [2 x i64] } } %t87, ptr %l4
  %t88 = load { i32, { i64, [2 x i64] } }, ptr %l4
  store { i32, { i64, [2 x i64] } } %t88, ptr %l36
  %t89 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l36, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t91 = ashr i32 %t90, 16
  %t93 = icmp eq i32 %t91, 1
  br i1 %t93, label %bb23, label %bb24
bb23:
  call void @__olang_errpay_pop()
  br label %bb24
bb24:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l39, !tbaa !27
  %t96 = load { i32, { i64, [2 x i64] } }, ptr %l4
  store { i32, { i64, [2 x i64] } } %t96, ptr %l40
  %t98 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s4, ptr %l40)
  store { i32, { i64, [2 x i64] } } %t98, ptr %l42
  br label %bb25
bb25:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t99 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t99, i64 %t100)
  %t101 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  call void @__olang_sb_put(ptr %s5, ptr %t102, i64 %t103)
  %t104 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t104, i64 %t105)
  %t106 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l42, i32 0, i32 0
  %t107 = load i32, ptr %t106, !tbaa !23
  store i32 %t107, ptr %l43, !tbaa !23
  %t108 = load i32, ptr %l43, !tbaa !23
  %t109 = icmp eq i32 %t108, 0
  br i1 %t109, label %bb27, label %bb28
bb26:
  %t111 = load ptr, ptr %s5
  %t112 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t113 = load i64, ptr %t112
  %t114 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t111, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l58, !tbaa !27
  %t117 = getelementptr %olang.builder, ptr %s5, i32 0, i32 3
  %t118 = load ptr, ptr %t117
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %sbgrew.120, label %sbdone.121
sbgrew.120:
  call void @__olang_sb_done(ptr %s5)
  br label %sbdone.121
sbdone.121:
  %t122 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t124 = call i32 @compiler_2fjupyter_2efail(ptr %s4, { i64, ptr } %t122)
  store i32 %t124, ptr %l60
  br label %bb41
bb27:
  %t125 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t125, i64 %t126)
  br label %bb26
bb28:
  %t127 = load i32, ptr %l43, !tbaa !23
  %t128 = icmp eq i32 %t127, 65536
  br i1 %t128, label %bb29, label %bb30
bb29:
  %t130 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t130, i64 %t131)
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t132, i64 %t133)
  %t134 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l42, i32 0, i32 1
  %t135 = getelementptr { i64, [2 x i64] }, ptr %t134, i32 0, i32 1
  %t136 = getelementptr { { i64, ptr } }, ptr %t135, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t139, i64 %t140, i8 34)
  %t142 = call ptr @__olang_sb_room(ptr %s5, i64 %t141)
  %t143 = call i64 @__olang_rd_quote(ptr %t142, i64 0, ptr %t139, i64 %t140, i8 34)
  call void @__olang_sb_add(ptr %s5, i64 %t141)
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t144, i64 %t145)
  br label %bb26
bb30:
  %t146 = load i32, ptr %l43, !tbaa !23
  %t147 = icmp eq i32 %t146, 65537
  br i1 %t147, label %bb31, label %bb32
bb31:
  %t149 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t149, i64 %t150)
  %t151 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t151, i64 %t152)
  %t153 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l42, i32 0, i32 1
  %t154 = getelementptr { i64, [2 x i64] }, ptr %t153, i32 0, i32 1
  %t155 = getelementptr { { i64, ptr } }, ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = extractvalue { i64, ptr } %t156, 0
  %t160 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t158, i64 %t159, i8 34)
  %t161 = call ptr @__olang_sb_room(ptr %s5, i64 %t160)
  %t162 = call i64 @__olang_rd_quote(ptr %t161, i64 0, ptr %t158, i64 %t159, i8 34)
  call void @__olang_sb_add(ptr %s5, i64 %t160)
  %t163 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t163, i64 %t164)
  br label %bb26
bb32:
  %t165 = load i32, ptr %l43, !tbaa !23
  %t166 = icmp eq i32 %t165, 65538
  br i1 %t166, label %bb33, label %bb34
bb33:
  %t168 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t168, i64 %t169)
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t170, i64 %t171)
  %t172 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l42, i32 0, i32 1
  %t173 = getelementptr { i64, [2 x i64] }, ptr %t172, i32 0, i32 1
  %t174 = getelementptr { { i64, ptr } }, ptr %t173, i32 0, i32 0
  %t175 = load { i64, ptr }, ptr %t174
  %t177 = extractvalue { i64, ptr } %t175, 1
  %t178 = extractvalue { i64, ptr } %t175, 0
  %t179 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t177, i64 %t178, i8 34)
  %t180 = call ptr @__olang_sb_room(ptr %s5, i64 %t179)
  %t181 = call i64 @__olang_rd_quote(ptr %t180, i64 0, ptr %t177, i64 %t178, i8 34)
  call void @__olang_sb_add(ptr %s5, i64 %t179)
  %t182 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t182, i64 %t183)
  br label %bb26
bb34:
  %t184 = load i32, ptr %l43, !tbaa !23
  %t185 = icmp eq i32 %t184, 65539
  br i1 %t185, label %bb35, label %bb36
bb35:
  %t187 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t187, i64 %t188)
  %t189 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t189, i64 %t190)
  %t191 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l42, i32 0, i32 1
  %t192 = getelementptr { i64, [2 x i64] }, ptr %t191, i32 0, i32 1
  %t193 = getelementptr { { i64, ptr } }, ptr %t192, i32 0, i32 0
  %t194 = load { i64, ptr }, ptr %t193
  %t196 = extractvalue { i64, ptr } %t194, 1
  %t197 = extractvalue { i64, ptr } %t194, 0
  %t198 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t196, i64 %t197, i8 34)
  %t199 = call ptr @__olang_sb_room(ptr %s5, i64 %t198)
  %t200 = call i64 @__olang_rd_quote(ptr %t199, i64 0, ptr %t196, i64 %t197, i8 34)
  call void @__olang_sb_add(ptr %s5, i64 %t198)
  %t201 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t201, i64 %t202)
  br label %bb26
bb36:
  %t203 = load i32, ptr %l43, !tbaa !23
  %t204 = icmp eq i32 %t203, 65540
  br i1 %t204, label %bb37, label %bb38
bb37:
  %t206 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t206, i64 %t207)
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t208, i64 %t209)
  %t210 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l42, i32 0, i32 1
  %t211 = getelementptr { i64, [2 x i64] }, ptr %t210, i32 0, i32 1
  %t212 = getelementptr { { i64, ptr } }, ptr %t211, i32 0, i32 0
  %t213 = load { i64, ptr }, ptr %t212
  %t215 = extractvalue { i64, ptr } %t213, 1
  %t216 = extractvalue { i64, ptr } %t213, 0
  %t217 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t215, i64 %t216, i8 34)
  %t218 = call ptr @__olang_sb_room(ptr %s5, i64 %t217)
  %t219 = call i64 @__olang_rd_quote(ptr %t218, i64 0, ptr %t215, i64 %t216, i8 34)
  call void @__olang_sb_add(ptr %s5, i64 %t217)
  %t220 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t220, i64 %t221)
  br label %bb26
bb38:
  %t222 = load i32, ptr %l43, !tbaa !23
  %t223 = icmp eq i32 %t222, 65541
  br i1 %t223, label %bb39, label %bb40
bb39:
  %t225 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t225, i64 %t226)
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t227, i64 %t228)
  %t229 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l42, i32 0, i32 1
  %t230 = getelementptr { i64, [2 x i64] }, ptr %t229, i32 0, i32 1
  %t231 = getelementptr { { i64, ptr } }, ptr %t230, i32 0, i32 0
  %t232 = load { i64, ptr }, ptr %t231
  %t234 = extractvalue { i64, ptr } %t232, 1
  %t235 = extractvalue { i64, ptr } %t232, 0
  %t236 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t234, i64 %t235, i8 34)
  %t237 = call ptr @__olang_sb_room(ptr %s5, i64 %t236)
  %t238 = call i64 @__olang_rd_quote(ptr %t237, i64 0, ptr %t234, i64 %t235, i8 34)
  call void @__olang_sb_add(ptr %s5, i64 %t236)
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t239, i64 %t240)
  br label %bb26
bb40:
  %t241 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t241, i64 %t242)
  %t243 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t243, i64 %t244)
  %t245 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l42, i32 0, i32 1
  %t246 = getelementptr { i64, [2 x i64] }, ptr %t245, i32 0, i32 1
  %t247 = getelementptr { { i64, ptr } }, ptr %t246, i32 0, i32 0
  %t248 = load { i64, ptr }, ptr %t247
  %t250 = extractvalue { i64, ptr } %t248, 1
  %t251 = extractvalue { i64, ptr } %t248, 0
  %t252 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t250, i64 %t251, i8 34)
  %t253 = call ptr @__olang_sb_room(ptr %s5, i64 %t252)
  %t254 = call i64 @__olang_rd_quote(ptr %t253, i64 0, ptr %t250, i64 %t251, i8 34)
  call void @__olang_sb_add(ptr %s5, i64 %t252)
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t255, i64 %t256)
  br label %bb26
bb41:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t257 = load i32, ptr %l60, !tbaa !23
  store i32 %t257, ptr %rv
  br label %ret
bb42:
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t260 = getelementptr %"compiler/build:Config", ptr %t258, i32 0, i32 5
  %t261 = load i1, ptr %t260, !tbaa !21
  br i1 %t261, label %bb43, label %bb44
bb43:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l63, !tbaa !27
  br label %bb45
bb44:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l63, !tbaa !27
  br label %bb45
bb45:
  %t263 = load ptr, ptr %l1, !tbaa !29
  %t265 = getelementptr %"compiler/build:Config", ptr %t263, i32 0, i32 26
  %t266 = load i1, ptr %t265, !tbaa !21
  br i1 %t266, label %bb46, label %bb47
bb46:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb48
bb47:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb48
bb48:
  %t268 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t274 = add i64 %t270, %t273
  %t275 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t274)
  call void @olang_textcopy(ptr %t275, ptr %t269, i64 %t270)
  %t276 = getelementptr i8, ptr %t275, i64 %t270
  call void @olang_textcopy(ptr %t276, ptr %t272, i64 %t273)
  %t277 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t275, 1
  store { i64, ptr } %t278, ptr %l5, !tbaa !27
  %t282 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t282, ptr %l69
  br label %bb49
bb49:
  %t283 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t284 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t285 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t286 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = add i64 %t285, %t288
  %t290 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t291 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t292 = add i64 %t289, %t291
  %t294 = extractvalue { i64, ptr } %t283, 1
  %t295 = extractvalue { i64, ptr } %t283, 0
  %t296 = add i64 %t292, %t295
  %t297 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t298 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t299 = add i64 %t296, %t298
  %t300 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t302 = add i64 %t299, %t301
  %t303 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t302)
  call void @olang_textcopy(ptr %t303, ptr %t284, i64 %t285)
  %t304 = getelementptr i8, ptr %t303, i64 %t285
  call void @olang_textcopy(ptr %t304, ptr %t287, i64 %t288)
  %t305 = getelementptr i8, ptr %t304, i64 %t288
  call void @olang_textcopy(ptr %t305, ptr %t290, i64 %t291)
  %t306 = getelementptr i8, ptr %t305, i64 %t291
  call void @olang_textcopy(ptr %t306, ptr %t294, i64 %t295)
  %t307 = getelementptr i8, ptr %t306, i64 %t295
  call void @olang_textcopy(ptr %t307, ptr %t297, i64 %t298)
  %t308 = getelementptr i8, ptr %t307, i64 %t298
  call void @olang_textcopy(ptr %t308, ptr %t300, i64 %t301)
  %t309 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t303, 1
  %t312 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t312, 1
  %t315 = extractvalue { i64, ptr } %t312, 0
  %t316 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t317 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t318 = add i64 %t315, %t317
  %t319 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t318)
  call void @olang_textcopy(ptr %t319, ptr %t314, i64 %t315)
  %t320 = getelementptr i8, ptr %t319, i64 %t315
  call void @olang_textcopy(ptr %t320, ptr %t316, i64 %t317)
  %t321 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t322 = insertvalue { i64, ptr } %t321, ptr %t319, 1
  %t327 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t322, { i64, ptr } %t310)
  store i32 %t327, ptr %l76
  %t328 = icmp ne i32 %t327, 0
  br i1 %t328, label %bb51, label %ok.329, !prof !99
ok.329:
  br label %bb50
bb50:
  br label %bb75
bb51:
  %t330 = load i32, ptr %l76, !tbaa !23
  %t331 = ashr i32 %t330, 16
  %t333 = icmp eq i32 %t331, 1
  store i1 %t333, ptr %l78, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l7
  %t334 = load i32, ptr %l76, !tbaa !23
  %t335 = lshr i32 %t334, 16
  %t336 = and i32 %t334, 65535
  %t337 = icmp eq i32 %t335, 1
  %t338 = select i1 %t337, i32 1, i32 0
  %t339 = icmp eq i32 %t334, 0
  %t340 = shl i32 %t338, 16
  %t341 = or i32 %t340, %t336
  %t342 = select i1 %t339, i32 0, i32 %t341
  %t343 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l7, i32 0, i32 0
  store i32 %t342, ptr %t343, !tbaa !23
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  %t344 = load { i32, { i64, [2 x i64] } }, ptr %l7
  store { i32, { i64, [2 x i64] } } %t344, ptr %l79
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l80
  %t345 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l79, i32 0, i32 0
  %t346 = load i32, ptr %t345, !tbaa !23
  store i32 %t346, ptr %l81, !tbaa !23
  %t347 = load i32, ptr %l81, !tbaa !23
  %t348 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l80, i32 0, i32 0
  store i32 %t347, ptr %t348, !tbaa !23
  %t349 = load i32, ptr %l81, !tbaa !23
  %t350 = ashr i32 %t349, 16
  %t352 = icmp eq i32 %t350, 1
  br i1 %t352, label %bb53, label %bb54
bb53:
  %t354 = call ptr @__olang_errpay_top_get()
  %t356 = load { i64, [2 x i64] }, ptr %t354
  %t357 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l80, i32 0, i32 1
  store { i64, [2 x i64] } %t356, ptr %t357
  br label %bb54
bb54:
  %t359 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l80)
  store { i32, { i64, [2 x i64] } } %t359, ptr %l86
  br label %bb55
bb55:
  %t360 = load { i32, { i64, [2 x i64] } }, ptr %l86
  store { i32, { i64, [2 x i64] } } %t360, ptr %l7
  %t361 = load { i32, { i64, [2 x i64] } }, ptr %l7
  store { i32, { i64, [2 x i64] } } %t361, ptr %l87
  %t362 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l87, i32 0, i32 0
  %t363 = load i32, ptr %t362, !tbaa !23
  %t364 = ashr i32 %t363, 16
  %t366 = icmp eq i32 %t364, 1
  br i1 %t366, label %bb56, label %bb57
bb56:
  call void @__olang_errpay_pop()
  br label %bb57
bb57:
  %t368 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t368, ptr %l90, !tbaa !27
  %t369 = load { i32, { i64, [2 x i64] } }, ptr %l7
  store { i32, { i64, [2 x i64] } } %t369, ptr %l91
  %t371 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s9, ptr %l91)
  store { i32, { i64, [2 x i64] } } %t371, ptr %l93
  br label %bb58
bb58:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t372 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t372, i64 %t373)
  %t374 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  call void @__olang_sb_put(ptr %s10, ptr %t375, i64 %t376)
  %t377 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t378 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t377, i64 %t378)
  %t379 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l93, i32 0, i32 0
  %t380 = load i32, ptr %t379, !tbaa !23
  store i32 %t380, ptr %l94, !tbaa !23
  %t381 = load i32, ptr %l94, !tbaa !23
  %t382 = icmp eq i32 %t381, 0
  br i1 %t382, label %bb60, label %bb61
bb59:
  %t384 = load ptr, ptr %s10
  %t385 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t386 = load i64, ptr %t385
  %t387 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t386)
  call void @olang_textcopy(ptr %t387, ptr %t384, i64 %t386)
  %t388 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t387, 1
  store { i64, ptr } %t389, ptr %l109, !tbaa !27
  %t390 = getelementptr %olang.builder, ptr %s10, i32 0, i32 3
  %t391 = load ptr, ptr %t390
  %t392 = icmp ne ptr %t391, null
  br i1 %t392, label %sbgrew.393, label %sbdone.394
sbgrew.393:
  call void @__olang_sb_done(ptr %s10)
  br label %sbdone.394
sbdone.394:
  %t395 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t397 = call i32 @compiler_2fjupyter_2efail(ptr %s9, { i64, ptr } %t395)
  store i32 %t397, ptr %l111
  br label %bb74
bb60:
  %t398 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t399 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t398, i64 %t399)
  br label %bb59
bb61:
  %t400 = load i32, ptr %l94, !tbaa !23
  %t401 = icmp eq i32 %t400, 65536
  br i1 %t401, label %bb62, label %bb63
bb62:
  %t403 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t403, i64 %t404)
  %t405 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t406 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t405, i64 %t406)
  %t407 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l93, i32 0, i32 1
  %t408 = getelementptr { i64, [2 x i64] }, ptr %t407, i32 0, i32 1
  %t409 = getelementptr { { i64, ptr } }, ptr %t408, i32 0, i32 0
  %t410 = load { i64, ptr }, ptr %t409
  %t412 = extractvalue { i64, ptr } %t410, 1
  %t413 = extractvalue { i64, ptr } %t410, 0
  %t414 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t412, i64 %t413, i8 34)
  %t415 = call ptr @__olang_sb_room(ptr %s10, i64 %t414)
  %t416 = call i64 @__olang_rd_quote(ptr %t415, i64 0, ptr %t412, i64 %t413, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t414)
  %t417 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t418 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t417, i64 %t418)
  br label %bb59
bb63:
  %t419 = load i32, ptr %l94, !tbaa !23
  %t420 = icmp eq i32 %t419, 65537
  br i1 %t420, label %bb64, label %bb65
bb64:
  %t422 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t423 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t422, i64 %t423)
  %t424 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t425 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t424, i64 %t425)
  %t426 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l93, i32 0, i32 1
  %t427 = getelementptr { i64, [2 x i64] }, ptr %t426, i32 0, i32 1
  %t428 = getelementptr { { i64, ptr } }, ptr %t427, i32 0, i32 0
  %t429 = load { i64, ptr }, ptr %t428
  %t431 = extractvalue { i64, ptr } %t429, 1
  %t432 = extractvalue { i64, ptr } %t429, 0
  %t433 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t431, i64 %t432, i8 34)
  %t434 = call ptr @__olang_sb_room(ptr %s10, i64 %t433)
  %t435 = call i64 @__olang_rd_quote(ptr %t434, i64 0, ptr %t431, i64 %t432, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t433)
  %t436 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t437 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t436, i64 %t437)
  br label %bb59
bb65:
  %t438 = load i32, ptr %l94, !tbaa !23
  %t439 = icmp eq i32 %t438, 65538
  br i1 %t439, label %bb66, label %bb67
bb66:
  %t441 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t442 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t441, i64 %t442)
  %t443 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t444 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t443, i64 %t444)
  %t445 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l93, i32 0, i32 1
  %t446 = getelementptr { i64, [2 x i64] }, ptr %t445, i32 0, i32 1
  %t447 = getelementptr { { i64, ptr } }, ptr %t446, i32 0, i32 0
  %t448 = load { i64, ptr }, ptr %t447
  %t450 = extractvalue { i64, ptr } %t448, 1
  %t451 = extractvalue { i64, ptr } %t448, 0
  %t452 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t450, i64 %t451, i8 34)
  %t453 = call ptr @__olang_sb_room(ptr %s10, i64 %t452)
  %t454 = call i64 @__olang_rd_quote(ptr %t453, i64 0, ptr %t450, i64 %t451, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t452)
  %t455 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t456 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t455, i64 %t456)
  br label %bb59
bb67:
  %t457 = load i32, ptr %l94, !tbaa !23
  %t458 = icmp eq i32 %t457, 65539
  br i1 %t458, label %bb68, label %bb69
bb68:
  %t460 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t461 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t460, i64 %t461)
  %t462 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t463 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t462, i64 %t463)
  %t464 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l93, i32 0, i32 1
  %t465 = getelementptr { i64, [2 x i64] }, ptr %t464, i32 0, i32 1
  %t466 = getelementptr { { i64, ptr } }, ptr %t465, i32 0, i32 0
  %t467 = load { i64, ptr }, ptr %t466
  %t469 = extractvalue { i64, ptr } %t467, 1
  %t470 = extractvalue { i64, ptr } %t467, 0
  %t471 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t469, i64 %t470, i8 34)
  %t472 = call ptr @__olang_sb_room(ptr %s10, i64 %t471)
  %t473 = call i64 @__olang_rd_quote(ptr %t472, i64 0, ptr %t469, i64 %t470, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t471)
  %t474 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t475 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t474, i64 %t475)
  br label %bb59
bb69:
  %t476 = load i32, ptr %l94, !tbaa !23
  %t477 = icmp eq i32 %t476, 65540
  br i1 %t477, label %bb70, label %bb71
bb70:
  %t479 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t480 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t479, i64 %t480)
  %t481 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t482 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t481, i64 %t482)
  %t483 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l93, i32 0, i32 1
  %t484 = getelementptr { i64, [2 x i64] }, ptr %t483, i32 0, i32 1
  %t485 = getelementptr { { i64, ptr } }, ptr %t484, i32 0, i32 0
  %t486 = load { i64, ptr }, ptr %t485
  %t488 = extractvalue { i64, ptr } %t486, 1
  %t489 = extractvalue { i64, ptr } %t486, 0
  %t490 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t488, i64 %t489, i8 34)
  %t491 = call ptr @__olang_sb_room(ptr %s10, i64 %t490)
  %t492 = call i64 @__olang_rd_quote(ptr %t491, i64 0, ptr %t488, i64 %t489, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t490)
  %t493 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t494 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t493, i64 %t494)
  br label %bb59
bb71:
  %t495 = load i32, ptr %l94, !tbaa !23
  %t496 = icmp eq i32 %t495, 65541
  br i1 %t496, label %bb72, label %bb73
bb72:
  %t498 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t499 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t498, i64 %t499)
  %t500 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t501 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t500, i64 %t501)
  %t502 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l93, i32 0, i32 1
  %t503 = getelementptr { i64, [2 x i64] }, ptr %t502, i32 0, i32 1
  %t504 = getelementptr { { i64, ptr } }, ptr %t503, i32 0, i32 0
  %t505 = load { i64, ptr }, ptr %t504
  %t507 = extractvalue { i64, ptr } %t505, 1
  %t508 = extractvalue { i64, ptr } %t505, 0
  %t509 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t507, i64 %t508, i8 34)
  %t510 = call ptr @__olang_sb_room(ptr %s10, i64 %t509)
  %t511 = call i64 @__olang_rd_quote(ptr %t510, i64 0, ptr %t507, i64 %t508, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t509)
  %t512 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t513 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t512, i64 %t513)
  br label %bb59
bb73:
  %t514 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t515 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t514, i64 %t515)
  %t516 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t517 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t516, i64 %t517)
  %t518 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l93, i32 0, i32 1
  %t519 = getelementptr { i64, [2 x i64] }, ptr %t518, i32 0, i32 1
  %t520 = getelementptr { { i64, ptr } }, ptr %t519, i32 0, i32 0
  %t521 = load { i64, ptr }, ptr %t520
  %t523 = extractvalue { i64, ptr } %t521, 1
  %t524 = extractvalue { i64, ptr } %t521, 0
  %t525 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t523, i64 %t524, i8 34)
  %t526 = call ptr @__olang_sb_room(ptr %s10, i64 %t525)
  %t527 = call i64 @__olang_rd_quote(ptr %t526, i64 0, ptr %t523, i64 %t524, i8 34)
  call void @__olang_sb_add(ptr %s10, i64 %t525)
  %t528 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t529 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t528, i64 %t529)
  br label %bb59
bb74:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t530 = load i32, ptr %l111, !tbaa !23
  store i32 %t530, ptr %rv
  br label %ret
bb75:
  %t531 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t532 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t533 = extractvalue { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t535 = extractvalue { i64, ptr } %t531, 1
  %t536 = extractvalue { i64, ptr } %t531, 0
  %t537 = add i64 %t533, %t536
  %t538 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t539 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t540 = add i64 %t537, %t539
  %t541 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t540)
  call void @olang_textcopy(ptr %t541, ptr %t532, i64 %t533)
  %t542 = getelementptr i8, ptr %t541, i64 %t533
  call void @olang_textcopy(ptr %t542, ptr %t535, i64 %t536)
  %t543 = getelementptr i8, ptr %t542, i64 %t536
  call void @olang_textcopy(ptr %t543, ptr %t538, i64 %t539)
  %t544 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t541, 1
  %t547 = call i32 @std_2fio_2ePut_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %t545)
  store i32 %t547, ptr %l114
  %t548 = icmp ne i32 %t547, 0
  br i1 %t548, label %bb77, label %ok.549, !prof !99
ok.549:
  br label %bb76
bb76:
  br label %bb81
bb77:
  %t550 = load i32, ptr %l114, !tbaa !23
  %t551 = ashr i32 %t550, 16
  %t553 = icmp eq i32 %t551, 1
  store i1 %t553, ptr %l116, !tbaa !21
  %t554 = load i32, ptr %l114, !tbaa !23
  %t555 = ashr i32 %t554, 16
  %t557 = icmp eq i32 %t555, 1
  br i1 %t557, label %bb78, label %bb79
bb78:
  call void @__olang_errpay_pop()
  br label %bb79
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fjupyter_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i32, { i64, [2 x i64] } }
  %l4 = alloca { i32, { i64, [2 x i64] } }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i32, { i64, [2 x i64] } }
  %l16 = alloca { i32, { i64, [2 x i64] } }
  %l17 = alloca %"std/net:Addr"
  %l18 = alloca { i32, { i64, [2 x i64] } }
  %l19 = alloca %"compiler/prompt:Session"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca %"compiler/jupyter:pending"
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l48 = alloca i1
  %l49 = alloca { i32, { i64, [2 x i64] } }
  %l50 = alloca { i32, { i64, [2 x i64] } }
  %l51 = alloca i32
  %l56 = alloca { i32, { i64, [2 x i64] } }
  %l57 = alloca { i32, { i64, [2 x i64] } }
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i32, { i64, [2 x i64] } }
  %l63 = alloca { i32, { i64, [2 x i64] } }
  %l64 = alloca i32
  %l79 = alloca { i64, ptr }
  %l81 = alloca i32
  %l82 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca i32
  %l87 = alloca i1
  %l88 = alloca { i32, { i64, [2 x i64] } }
  %l89 = alloca { i32, { i64, [2 x i64] } }
  %l90 = alloca i32
  %l95 = alloca { i32, { i64, [2 x i64] } }
  %l96 = alloca { i32, { i64, [2 x i64] } }
  %l99 = alloca { i32, { i64, [2 x i64] } }
  %l101 = alloca { i32, { i64, [2 x i64] } }
  %l102 = alloca i32
  %l128 = alloca { i64, ptr }
  %l130 = alloca i32
  %l131 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l135 = alloca ptr
  %l136 = alloca i32
  %l138 = alloca i1
  %l141 = alloca { i64, ptr }
  %l142 = alloca i32
  %l144 = alloca i1
  %l147 = alloca i64
  %l149 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l154 = alloca i32
  %l156 = alloca i1
  %l159 = alloca { i64, ptr }
  %l160 = alloca i32
  %l162 = alloca i1
  %l165 = alloca { i64, ptr }
  %l169 = alloca %"compiler/jupyter:kernel"
  %l170 = alloca ptr
  %l171 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l182 = alloca i64
  %l185 = alloca ptr
  %l186 = alloca i32
  %l188 = alloca i1
  %l189 = alloca i64
  %l190 = alloca i32
  %l192 = alloca i1
  %l193 = alloca { i32, { i64, [2 x i64] } }
  %l194 = alloca { i32, { i64, [2 x i64] } }
  %l195 = alloca i32
  %l200 = alloca { i32, { i64, [2 x i64] } }
  %l201 = alloca { i32, { i64, [2 x i64] } }
  %l204 = alloca { i64, ptr }
  %l205 = alloca { i32, { i64, [2 x i64] } }
  %l207 = alloca { i32, { i64, [2 x i64] } }
  %l208 = alloca i32
  %l234 = alloca { i64, ptr }
  %l236 = alloca i32
  %l239 = alloca %"std/net:Addr"
  %l244 = alloca %"std/net:Addr"
  %l245 = alloca i32
  %l247 = alloca i1
  %l248 = alloca { i32, { i64, [2 x i64] } }
  %l249 = alloca { i32, { i64, [2 x i64] } }
  %l250 = alloca i32
  %l255 = alloca { i32, { i64, [2 x i64] } }
  %l256 = alloca { i32, { i64, [2 x i64] } }
  %l259 = alloca { i32, { i64, [2 x i64] } }
  %l261 = alloca { i32, { i64, [2 x i64] } }
  %l265 = alloca { i64, ptr }
  %l267 = alloca i32
  %l270 = alloca ptr
  %l271 = alloca %"std/net:Listener"
  %l273 = alloca %"std/net:Listener"
  %l274 = alloca i32
  %l276 = alloca i1
  %l277 = alloca { i32, { i64, [2 x i64] } }
  %l278 = alloca { i32, { i64, [2 x i64] } }
  %l279 = alloca i32
  %l284 = alloca { i32, { i64, [2 x i64] } }
  %l285 = alloca { i32, { i64, [2 x i64] } }
  %l288 = alloca %"std/net:Addr"
  %l289 = alloca { i32, { i64, [2 x i64] } }
  %l291 = alloca { i32, { i64, [2 x i64] } }
  %l293 = alloca i32
  %l306 = alloca { i64, ptr }
  %l308 = alloca i32
  %l315 = alloca %"compiler/prompt:Session"
  %l323 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l325 = alloca { i64, ptr }
  %l332 = alloca { i64, ptr }
  %l335 = alloca ptr
  %l337 = alloca i32
  %l343 = alloca { i64, ptr }
  %l350 = alloca { i64, ptr }
  %l353 = alloca ptr
  %l355 = alloca i32
  %l360 = alloca { i64, ptr }
  %l361 = alloca { i64, ptr }
  %l363 = alloca i64
  %l367 = alloca i64
  %l370 = alloca i64
  %l390 = alloca ptr
  %l393 = alloca ptr
  %l399 = alloca i64
  %l401 = alloca i64
  %l406 = alloca i64
  %l409 = alloca i64
  %l428 = alloca i64
  %l441 = alloca i1
  %l444 = alloca i64
  %l447 = alloca %"compiler/jupyter:pending"
  %l450 = alloca %"compiler/jupyter:pending"
  %l451 = alloca i32
  %l453 = alloca i1
  %l460 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.builder
  %s9room = alloca [64 x i8], align 8
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.builder
  %s14room = alloca [64 x i8], align 8
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %rv = alloca i32
  %t576 = alloca %"compiler/jupyter:kernel", align 8
  %t1186 = alloca %"compiler/prompt:Session", align 8
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fsession_2eIgnoreBrokenPipes()
  br label %bb1
bb1:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l46
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb3, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l45
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t8, ptr %l43, !tbaa !27
  br label %bb27
bb3:
  %t9 = load i32, ptr %l46, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l48, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l2
  %t13 = load i32, ptr %l46, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t22 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l2, i32 0, i32 0
  store i32 %t21, ptr %t22, !tbaa !23
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load { i32, { i64, [2 x i64] } }, ptr %l2
  store { i32, { i64, [2 x i64] } } %t23, ptr %l49
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l50
  %t24 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l49, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  store i32 %t25, ptr %l51, !tbaa !23
  %t26 = load i32, ptr %l51, !tbaa !23
  %t27 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l50, i32 0, i32 0
  store i32 %t26, ptr %t27, !tbaa !23
  %t28 = load i32, ptr %l51, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = call ptr @__olang_errpay_top_get()
  %t35 = load { i64, [2 x i64] }, ptr %t33
  %t36 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l50, i32 0, i32 1
  store { i64, [2 x i64] } %t35, ptr %t36
  br label %bb6
bb6:
  %t38 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s0, ptr %l50)
  store { i32, { i64, [2 x i64] } } %t38, ptr %l56
  br label %bb7
bb7:
  %t39 = load { i32, { i64, [2 x i64] } }, ptr %l56
  store { i32, { i64, [2 x i64] } } %t39, ptr %l2
  %t40 = load { i32, { i64, [2 x i64] } }, ptr %l2
  store { i32, { i64, [2 x i64] } } %t40, ptr %l57
  %t41 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l57, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  br i1 %t45, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %l60, !tbaa !27
  %t48 = load { i32, { i64, [2 x i64] } }, ptr %l2
  store { i32, { i64, [2 x i64] } } %t48, ptr %l61
  %t50 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %s1, ptr %l61)
  store { i32, { i64, [2 x i64] } } %t50, ptr %l63
  br label %bb10
bb10:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t51 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t51, i64 %t52)
  %t53 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  call void @__olang_sb_put(ptr %s2, ptr %t54, i64 %t55)
  %t56 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t56, i64 %t57)
  %t58 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l63, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  store i32 %t59, ptr %l64, !tbaa !23
  %t60 = load i32, ptr %l64, !tbaa !23
  %t61 = icmp eq i32 %t60, 0
  br i1 %t61, label %bb12, label %bb13
bb11:
  %t63 = load ptr, ptr %s2
  %t64 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t63, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l79, !tbaa !27
  %t69 = getelementptr %olang.builder, ptr %s2, i32 0, i32 3
  %t70 = load ptr, ptr %t69
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %sbgrew.72, label %sbdone.73
sbgrew.72:
  call void @__olang_sb_done(ptr %s2)
  br label %sbdone.73
sbdone.73:
  %t74 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t76 = call i32 @compiler_2fjupyter_2efail(ptr %s1, { i64, ptr } %t74)
  store i32 %t76, ptr %l81
  br label %bb26
bb12:
  %t77 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t77, i64 %t78)
  br label %bb11
bb13:
  %t79 = load i32, ptr %l64, !tbaa !23
  %t80 = icmp eq i32 %t79, 65536
  br i1 %t80, label %bb14, label %bb15
bb14:
  %t82 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t82, i64 %t83)
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t84, i64 %t85)
  %t86 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l63, i32 0, i32 1
  %t87 = getelementptr { i64, [2 x i64] }, ptr %t86, i32 0, i32 1
  %t88 = getelementptr { { i64, ptr } }, ptr %t87, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t91, i64 %t92, i8 34)
  %t94 = call ptr @__olang_sb_room(ptr %s2, i64 %t93)
  %t95 = call i64 @__olang_rd_quote(ptr %t94, i64 0, ptr %t91, i64 %t92, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t93)
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t96, i64 %t97)
  br label %bb11
bb15:
  %t98 = load i32, ptr %l64, !tbaa !23
  %t99 = icmp eq i32 %t98, 65537
  br i1 %t99, label %bb16, label %bb17
bb16:
  %t101 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t101, i64 %t102)
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t103, i64 %t104)
  %t105 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l63, i32 0, i32 1
  %t106 = getelementptr { i64, [2 x i64] }, ptr %t105, i32 0, i32 1
  %t107 = getelementptr { { i64, ptr } }, ptr %t106, i32 0, i32 0
  %t108 = load { i64, ptr }, ptr %t107
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = extractvalue { i64, ptr } %t108, 0
  %t112 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t110, i64 %t111, i8 34)
  %t113 = call ptr @__olang_sb_room(ptr %s2, i64 %t112)
  %t114 = call i64 @__olang_rd_quote(ptr %t113, i64 0, ptr %t110, i64 %t111, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t112)
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t115, i64 %t116)
  br label %bb11
bb17:
  %t117 = load i32, ptr %l64, !tbaa !23
  %t118 = icmp eq i32 %t117, 65538
  br i1 %t118, label %bb18, label %bb19
bb18:
  %t120 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t120, i64 %t121)
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t122, i64 %t123)
  %t124 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l63, i32 0, i32 1
  %t125 = getelementptr { i64, [2 x i64] }, ptr %t124, i32 0, i32 1
  %t126 = getelementptr { { i64, ptr } }, ptr %t125, i32 0, i32 0
  %t127 = load { i64, ptr }, ptr %t126
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = extractvalue { i64, ptr } %t127, 0
  %t131 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t129, i64 %t130, i8 34)
  %t132 = call ptr @__olang_sb_room(ptr %s2, i64 %t131)
  %t133 = call i64 @__olang_rd_quote(ptr %t132, i64 0, ptr %t129, i64 %t130, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t131)
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t134, i64 %t135)
  br label %bb11
bb19:
  %t136 = load i32, ptr %l64, !tbaa !23
  %t137 = icmp eq i32 %t136, 65539
  br i1 %t137, label %bb20, label %bb21
bb20:
  %t139 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t139, i64 %t140)
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t141, i64 %t142)
  %t143 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l63, i32 0, i32 1
  %t144 = getelementptr { i64, [2 x i64] }, ptr %t143, i32 0, i32 1
  %t145 = getelementptr { { i64, ptr } }, ptr %t144, i32 0, i32 0
  %t146 = load { i64, ptr }, ptr %t145
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = extractvalue { i64, ptr } %t146, 0
  %t150 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t148, i64 %t149, i8 34)
  %t151 = call ptr @__olang_sb_room(ptr %s2, i64 %t150)
  %t152 = call i64 @__olang_rd_quote(ptr %t151, i64 0, ptr %t148, i64 %t149, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t150)
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t153, i64 %t154)
  br label %bb11
bb21:
  %t155 = load i32, ptr %l64, !tbaa !23
  %t156 = icmp eq i32 %t155, 65540
  br i1 %t156, label %bb22, label %bb23
bb22:
  %t158 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t158, i64 %t159)
  %t160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t160, i64 %t161)
  %t162 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l63, i32 0, i32 1
  %t163 = getelementptr { i64, [2 x i64] }, ptr %t162, i32 0, i32 1
  %t164 = getelementptr { { i64, ptr } }, ptr %t163, i32 0, i32 0
  %t165 = load { i64, ptr }, ptr %t164
  %t167 = extractvalue { i64, ptr } %t165, 1
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t167, i64 %t168, i8 34)
  %t170 = call ptr @__olang_sb_room(ptr %s2, i64 %t169)
  %t171 = call i64 @__olang_rd_quote(ptr %t170, i64 0, ptr %t167, i64 %t168, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t169)
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t172, i64 %t173)
  br label %bb11
bb23:
  %t174 = load i32, ptr %l64, !tbaa !23
  %t175 = icmp eq i32 %t174, 65541
  br i1 %t175, label %bb24, label %bb25
bb24:
  %t177 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t177, i64 %t178)
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t179, i64 %t180)
  %t181 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l63, i32 0, i32 1
  %t182 = getelementptr { i64, [2 x i64] }, ptr %t181, i32 0, i32 1
  %t183 = getelementptr { { i64, ptr } }, ptr %t182, i32 0, i32 0
  %t184 = load { i64, ptr }, ptr %t183
  %t186 = extractvalue { i64, ptr } %t184, 1
  %t187 = extractvalue { i64, ptr } %t184, 0
  %t188 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t186, i64 %t187, i8 34)
  %t189 = call ptr @__olang_sb_room(ptr %s2, i64 %t188)
  %t190 = call i64 @__olang_rd_quote(ptr %t189, i64 0, ptr %t186, i64 %t187, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t188)
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t192 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t191, i64 %t192)
  br label %bb11
bb25:
  %t193 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t193, i64 %t194)
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t195, i64 %t196)
  %t197 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l63, i32 0, i32 1
  %t198 = getelementptr { i64, [2 x i64] }, ptr %t197, i32 0, i32 1
  %t199 = getelementptr { { i64, ptr } }, ptr %t198, i32 0, i32 0
  %t200 = load { i64, ptr }, ptr %t199
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = extractvalue { i64, ptr } %t200, 0
  %t204 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t202, i64 %t203, i8 34)
  %t205 = call ptr @__olang_sb_room(ptr %s2, i64 %t204)
  %t206 = call i64 @__olang_rd_quote(ptr %t205, i64 0, ptr %t202, i64 %t203, i8 34)
  call void @__olang_sb_add(ptr %s2, i64 %t204)
  %t207 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t207, i64 %t208)
  br label %bb11
bb26:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t209 = load i32, ptr %l81, !tbaa !23
  store i32 %t209, ptr %rv
  br label %ret
bb27:
  %t210 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t213 = call { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %s0, ptr %s0, { i64, ptr } %t210)
  %t214 = extractvalue { i32, ptr } %t213, 1
  %t215 = extractvalue { i32, ptr } %t213, 0
  store i32 %t215, ptr %l85
  %t216 = icmp ne i32 %t215, 0
  br i1 %t216, label %bb29, label %ok.217, !prof !99
ok.217:
  store ptr %t214, ptr %l84
  br label %bb28
bb28:
  %t218 = load ptr, ptr %l84, !tbaa !29
  store ptr %t218, ptr %l82, !tbaa !29
  br label %bb59
bb29:
  %t219 = load i32, ptr %l85, !tbaa !23
  %t220 = ashr i32 %t219, 16
  %t222 = icmp eq i32 %t220, 1
  store i1 %t222, ptr %l87, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l4
  %t223 = load i32, ptr %l85, !tbaa !23
  %t224 = lshr i32 %t223, 16
  %t225 = and i32 %t223, 65535
  %t226 = icmp eq i32 %t224, 1
  %t227 = select i1 %t226, i32 1, i32 0
  %t228 = icmp eq i32 %t223, 0
  %t229 = shl i32 %t227, 16
  %t230 = or i32 %t229, %t225
  %t231 = select i1 %t228, i32 0, i32 %t230
  %t232 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l4, i32 0, i32 0
  store i32 %t231, ptr %t232, !tbaa !23
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t233 = load { i32, { i64, [2 x i64] } }, ptr %l4
  store { i32, { i64, [2 x i64] } } %t233, ptr %l88
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l89
  %t234 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l88, i32 0, i32 0
  %t235 = load i32, ptr %t234, !tbaa !23
  store i32 %t235, ptr %l90, !tbaa !23
  %t236 = load i32, ptr %l90, !tbaa !23
  %t237 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l89, i32 0, i32 0
  store i32 %t236, ptr %t237, !tbaa !23
  %t238 = load i32, ptr %l90, !tbaa !23
  %t239 = ashr i32 %t238, 16
  %t241 = icmp eq i32 %t239, 1
  br i1 %t241, label %bb31, label %bb32
bb31:
  %t243 = call ptr @__olang_errpay_top_get()
  %t245 = load { i64, [2 x i64] }, ptr %t243
  %t246 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l89, i32 0, i32 1
  store { i64, [2 x i64] } %t245, ptr %t246
  br label %bb32
bb32:
  %t248 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fjson_3aError_7d(ptr %s0, ptr %l89)
  store { i32, { i64, [2 x i64] } } %t248, ptr %l95
  br label %bb33
bb33:
  %t249 = load { i32, { i64, [2 x i64] } }, ptr %l95
  store { i32, { i64, [2 x i64] } } %t249, ptr %l4
  %t250 = load { i32, { i64, [2 x i64] } }, ptr %l4
  store { i32, { i64, [2 x i64] } } %t250, ptr %l96
  %t251 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l96, i32 0, i32 0
  %t252 = load i32, ptr %t251, !tbaa !23
  %t253 = ashr i32 %t252, 16
  %t255 = icmp eq i32 %t253, 1
  br i1 %t255, label %bb34, label %bb35
bb34:
  call void @__olang_errpay_pop()
  br label %bb35
bb35:
  %t257 = load { i32, { i64, [2 x i64] } }, ptr %l4
  store { i32, { i64, [2 x i64] } } %t257, ptr %l99
  %t259 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fjson_3aError_7d(ptr %s3, ptr %l99)
  store { i32, { i64, [2 x i64] } } %t259, ptr %l101
  br label %bb36
bb36:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t260 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t261 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t260, i64 %t261)
  %t262 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 0
  %t263 = load i32, ptr %t262, !tbaa !23
  store i32 %t263, ptr %l102, !tbaa !23
  %t264 = load i32, ptr %l102, !tbaa !23
  %t265 = icmp eq i32 %t264, 0
  br i1 %t265, label %bb38, label %bb39
bb37:
  %t267 = load ptr, ptr %s4
  %t268 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t269 = load i64, ptr %t268
  %t270 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t269)
  call void @olang_textcopy(ptr %t270, ptr %t267, i64 %t269)
  %t271 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t270, 1
  store { i64, ptr } %t272, ptr %l128, !tbaa !27
  %t273 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t274 = load ptr, ptr %t273
  %t275 = icmp ne ptr %t274, null
  br i1 %t275, label %sbgrew.276, label %sbdone.277
sbgrew.276:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.277
sbdone.277:
  %t278 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t280 = call i32 @compiler_2fjupyter_2efail(ptr %s3, { i64, ptr } %t278)
  store i32 %t280, ptr %l130
  br label %bb58
bb38:
  %t281 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t281, i64 %t282)
  br label %bb37
bb39:
  %t283 = load i32, ptr %l102, !tbaa !23
  %t284 = icmp eq i32 %t283, 65536
  br i1 %t284, label %bb40, label %bb41
bb40:
  %t286 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t287 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t286, i64 %t287)
  %t288 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t289 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t288, i64 %t289)
  %t290 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t291 = getelementptr { i64, [2 x i64] }, ptr %t290, i32 0, i32 1
  %t292 = getelementptr { i64, i64 }, ptr %t291, i32 0, i32 0
  %t293 = load i64, ptr %t292
  %t295 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t296 = call i64 @__olang_fmt_i64(ptr %t295, i64 %t293)
  call void @__olang_sb_add(ptr %s4, i64 %t296)
  %t297 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t298 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t297, i64 %t298)
  %t299 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t300 = getelementptr { i64, [2 x i64] }, ptr %t299, i32 0, i32 1
  %t301 = getelementptr { i64, i64 }, ptr %t300, i32 0, i32 1
  %t302 = load i64, ptr %t301
  %t304 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t305 = call i64 @__olang_fmt_i64(ptr %t304, i64 %t302)
  call void @__olang_sb_add(ptr %s4, i64 %t305)
  %t306 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t306, i64 %t307)
  br label %bb37
bb41:
  %t308 = load i32, ptr %l102, !tbaa !23
  %t309 = icmp eq i32 %t308, 65537
  br i1 %t309, label %bb42, label %bb43
bb42:
  %t311 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t312 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t311, i64 %t312)
  %t313 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t314 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t313, i64 %t314)
  %t315 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t316 = getelementptr { i64, [2 x i64] }, ptr %t315, i32 0, i32 1
  %t317 = getelementptr { i64, i64 }, ptr %t316, i32 0, i32 0
  %t318 = load i64, ptr %t317
  %t320 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t321 = call i64 @__olang_fmt_i64(ptr %t320, i64 %t318)
  call void @__olang_sb_add(ptr %s4, i64 %t321)
  %t322 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t322, i64 %t323)
  %t324 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t325 = getelementptr { i64, [2 x i64] }, ptr %t324, i32 0, i32 1
  %t326 = getelementptr { i64, i64 }, ptr %t325, i32 0, i32 1
  %t327 = load i64, ptr %t326
  %t329 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t330 = call i64 @__olang_fmt_i64(ptr %t329, i64 %t327)
  call void @__olang_sb_add(ptr %s4, i64 %t330)
  %t331 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t331, i64 %t332)
  br label %bb37
bb43:
  %t333 = load i32, ptr %l102, !tbaa !23
  %t334 = icmp eq i32 %t333, 65538
  br i1 %t334, label %bb44, label %bb45
bb44:
  %t336 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t337 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t336, i64 %t337)
  %t338 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t339 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t338, i64 %t339)
  %t340 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t341 = getelementptr { i64, [2 x i64] }, ptr %t340, i32 0, i32 1
  %t342 = getelementptr { i64, i64 }, ptr %t341, i32 0, i32 0
  %t343 = load i64, ptr %t342
  %t345 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t346 = call i64 @__olang_fmt_i64(ptr %t345, i64 %t343)
  call void @__olang_sb_add(ptr %s4, i64 %t346)
  %t347 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t347, i64 %t348)
  %t349 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t350 = getelementptr { i64, [2 x i64] }, ptr %t349, i32 0, i32 1
  %t351 = getelementptr { i64, i64 }, ptr %t350, i32 0, i32 1
  %t352 = load i64, ptr %t351
  %t354 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t355 = call i64 @__olang_fmt_i64(ptr %t354, i64 %t352)
  call void @__olang_sb_add(ptr %s4, i64 %t355)
  %t356 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t357 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t356, i64 %t357)
  br label %bb37
bb45:
  %t358 = load i32, ptr %l102, !tbaa !23
  %t359 = icmp eq i32 %t358, 65539
  br i1 %t359, label %bb46, label %bb47
bb46:
  %t361 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t362 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t361, i64 %t362)
  %t363 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t363, i64 %t364)
  %t365 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t366 = getelementptr { i64, [2 x i64] }, ptr %t365, i32 0, i32 1
  %t367 = getelementptr { i64, i64 }, ptr %t366, i32 0, i32 0
  %t368 = load i64, ptr %t367
  %t370 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t371 = call i64 @__olang_fmt_i64(ptr %t370, i64 %t368)
  call void @__olang_sb_add(ptr %s4, i64 %t371)
  %t372 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t372, i64 %t373)
  %t374 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t375 = getelementptr { i64, [2 x i64] }, ptr %t374, i32 0, i32 1
  %t376 = getelementptr { i64, i64 }, ptr %t375, i32 0, i32 1
  %t377 = load i64, ptr %t376
  %t379 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t380 = call i64 @__olang_fmt_i64(ptr %t379, i64 %t377)
  call void @__olang_sb_add(ptr %s4, i64 %t380)
  %t381 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t381, i64 %t382)
  br label %bb37
bb47:
  %t383 = load i32, ptr %l102, !tbaa !23
  %t384 = icmp eq i32 %t383, 65540
  br i1 %t384, label %bb48, label %bb49
bb48:
  %t386 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t387 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t386, i64 %t387)
  %t388 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t389 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t388, i64 %t389)
  %t390 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t391 = getelementptr { i64, [2 x i64] }, ptr %t390, i32 0, i32 1
  %t392 = getelementptr { i64, i64 }, ptr %t391, i32 0, i32 0
  %t393 = load i64, ptr %t392
  %t395 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t396 = call i64 @__olang_fmt_i64(ptr %t395, i64 %t393)
  call void @__olang_sb_add(ptr %s4, i64 %t396)
  %t397 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t397, i64 %t398)
  %t399 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t400 = getelementptr { i64, [2 x i64] }, ptr %t399, i32 0, i32 1
  %t401 = getelementptr { i64, i64 }, ptr %t400, i32 0, i32 1
  %t402 = load i64, ptr %t401
  %t404 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t405 = call i64 @__olang_fmt_i64(ptr %t404, i64 %t402)
  call void @__olang_sb_add(ptr %s4, i64 %t405)
  %t406 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t407 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t406, i64 %t407)
  br label %bb37
bb49:
  %t408 = load i32, ptr %l102, !tbaa !23
  %t409 = icmp eq i32 %t408, 65541
  br i1 %t409, label %bb50, label %bb51
bb50:
  %t411 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t412 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t411, i64 %t412)
  %t413 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t414 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t413, i64 %t414)
  %t415 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t416 = getelementptr { i64, [2 x i64] }, ptr %t415, i32 0, i32 1
  %t417 = getelementptr { i64, i64 }, ptr %t416, i32 0, i32 0
  %t418 = load i64, ptr %t417
  %t420 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t421 = call i64 @__olang_fmt_i64(ptr %t420, i64 %t418)
  call void @__olang_sb_add(ptr %s4, i64 %t421)
  %t422 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t423 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t422, i64 %t423)
  %t424 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t425 = getelementptr { i64, [2 x i64] }, ptr %t424, i32 0, i32 1
  %t426 = getelementptr { i64, i64 }, ptr %t425, i32 0, i32 1
  %t427 = load i64, ptr %t426
  %t429 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t430 = call i64 @__olang_fmt_i64(ptr %t429, i64 %t427)
  call void @__olang_sb_add(ptr %s4, i64 %t430)
  %t431 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t432 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t431, i64 %t432)
  br label %bb37
bb51:
  %t433 = load i32, ptr %l102, !tbaa !23
  %t434 = icmp eq i32 %t433, 65542
  br i1 %t434, label %bb52, label %bb53
bb52:
  %t436 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t437 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t436, i64 %t437)
  %t438 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t439 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t438, i64 %t439)
  %t440 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t441 = getelementptr { i64, [2 x i64] }, ptr %t440, i32 0, i32 1
  %t442 = getelementptr { i64, i64 }, ptr %t441, i32 0, i32 0
  %t443 = load i64, ptr %t442
  %t445 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t446 = call i64 @__olang_fmt_i64(ptr %t445, i64 %t443)
  call void @__olang_sb_add(ptr %s4, i64 %t446)
  %t447 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t448 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t447, i64 %t448)
  %t449 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t450 = getelementptr { i64, [2 x i64] }, ptr %t449, i32 0, i32 1
  %t451 = getelementptr { i64, i64 }, ptr %t450, i32 0, i32 1
  %t452 = load i64, ptr %t451
  %t454 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t455 = call i64 @__olang_fmt_i64(ptr %t454, i64 %t452)
  call void @__olang_sb_add(ptr %s4, i64 %t455)
  %t456 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t457 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t456, i64 %t457)
  br label %bb37
bb53:
  %t458 = load i32, ptr %l102, !tbaa !23
  %t459 = icmp eq i32 %t458, 65543
  br i1 %t459, label %bb54, label %bb55
bb54:
  %t461 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t462 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t461, i64 %t462)
  %t463 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t463, i64 %t464)
  %t465 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l101, i32 0, i32 1
  %t466 = getelementptr { i64, [2 x i64] }, ptr %t465, i32 0, i32 1
  %t467 = getelementptr { { i64, ptr } }, ptr %t466, i32 0, i32 0
  %t468 = load { i64, ptr }, ptr %t467
  %t470 = extractvalue { i64, ptr } %t468, 1
  %t471 = extractvalue { i64, ptr } %t468, 0
  %t472 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t470, i64 %t471, i8 34)
  %t473 = call ptr @__olang_sb_room(ptr %s4, i64 %t472)
  %t474 = call i64 @__olang_rd_quote(ptr %t473, i64 0, ptr %t470, i64 %t471, i8 34)
  call void @__olang_sb_add(ptr %s4, i64 %t472)
  %t475 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t476 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t475, i64 %t476)
  br label %bb37
bb55:
  %t477 = load i32, ptr %l102, !tbaa !23
  %t478 = icmp eq i32 %t477, 65544
  br i1 %t478, label %bb56, label %bb57
bb56:
  %t480 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t481 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t480, i64 %t481)
  br label %bb37
bb57:
  %t482 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t483 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t482, i64 %t483)
  br label %bb37
bb58:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t484 = load i32, ptr %l130, !tbaa !23
  store i32 %t484, ptr %rv
  br label %ret
bb59:
  %t485 = load ptr, ptr %l82, !tbaa !29
  store ptr %t485, ptr %l5, !tbaa !29
  %t486 = load ptr, ptr %l5, !tbaa !29
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %l133, !tbaa !27
  %t487 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t490 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t486, { i64, ptr } %t487)
  %t491 = extractvalue { i32, ptr } %t490, 1
  %t492 = extractvalue { i32, ptr } %t490, 0
  store i32 %t492, ptr %l136
  %t493 = icmp ne i32 %t492, 0
  br i1 %t493, label %bb61, label %ok.494, !prof !99
ok.494:
  store ptr %t491, ptr %l135
  br label %bb60
bb60:
  %t495 = load ptr, ptr %l135, !tbaa !29
  %t496 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %s0, ptr %s0, ptr %t495)
  %t497 = extractvalue { i32, { i64, ptr } } %t496, 1
  %t498 = extractvalue { i32, { i64, ptr } } %t496, 0
  store i32 %t498, ptr %l142
  %t499 = icmp ne i32 %t498, 0
  br i1 %t499, label %bb66, label %ok.500, !prof !99
ok.500:
  store { i64, ptr } %t497, ptr %l141
  br label %bb65
bb61:
  %t501 = load i32, ptr %l136, !tbaa !23
  %t502 = ashr i32 %t501, 16
  %t504 = icmp eq i32 %t502, 1
  store i1 %t504, ptr %l138, !tbaa !21
  %t505 = load i32, ptr %l136, !tbaa !23
  %t506 = ashr i32 %t505, 16
  %t508 = icmp eq i32 %t506, 1
  br i1 %t508, label %bb62, label %bb63
bb62:
  call void @__olang_errpay_pop()
  br label %bb63
bb63:
  br label %bb64
bb64:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l131, !tbaa !27
  br label %bb69
bb65:
  %t510 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t510, ptr %l131, !tbaa !27
  br label %bb69
bb66:
  %t511 = load i32, ptr %l142, !tbaa !23
  %t512 = ashr i32 %t511, 16
  %t514 = icmp eq i32 %t512, 1
  store i1 %t514, ptr %l144, !tbaa !21
  %t515 = load i32, ptr %l142, !tbaa !23
  %t516 = ashr i32 %t515, 16
  %t518 = icmp eq i32 %t516, 1
  br i1 %t518, label %bb67, label %bb68
bb67:
  call void @__olang_errpay_pop()
  br label %bb68
bb68:
  br label %bb64
bb69:
  %t520 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t520, ptr %l6, !tbaa !27
  %t521 = call ptr @__olang_scope_hold(ptr %s0)
  %t522 = ptrtoint ptr %t521 to i64
  store i64 %t522, ptr %l147, !tbaa !24
  %t523 = load i1, ptr @olang_2esole_2ecompiler_2fjupyter_3akernel_2e0
  br i1 %t523, label %bb70, label %bb71
bb70:
  %t525 = call ptr @__olang_region_make_part(ptr %s0)
  %t526 = ptrtoint ptr %t525 to i64
  store i64 %t526, ptr %l147, !tbaa !24
  br label %bb71
bb71:
  %t527 = load ptr, ptr %l5, !tbaa !29
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l151, !tbaa !27
  %t528 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t531 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %s0, ptr %t527, { i64, ptr } %t528)
  %t532 = extractvalue { i32, ptr } %t531, 1
  %t533 = extractvalue { i32, ptr } %t531, 0
  store i32 %t533, ptr %l154
  %t534 = icmp ne i32 %t533, 0
  br i1 %t534, label %bb73, label %ok.535, !prof !99
ok.535:
  store ptr %t532, ptr %l153
  br label %bb72
bb72:
  %t536 = load ptr, ptr %l153, !tbaa !29
  %t537 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %s0, ptr %s0, ptr %t536)
  %t538 = extractvalue { i32, { i64, ptr } } %t537, 1
  %t539 = extractvalue { i32, { i64, ptr } } %t537, 0
  store i32 %t539, ptr %l160
  %t540 = icmp ne i32 %t539, 0
  br i1 %t540, label %bb78, label %ok.541, !prof !99
ok.541:
  store { i64, ptr } %t538, ptr %l159
  br label %bb77
bb73:
  %t542 = load i32, ptr %l154, !tbaa !23
  %t543 = ashr i32 %t542, 16
  %t545 = icmp eq i32 %t543, 1
  store i1 %t545, ptr %l156, !tbaa !21
  %t546 = load i32, ptr %l154, !tbaa !23
  %t547 = ashr i32 %t546, 16
  %t549 = icmp eq i32 %t547, 1
  br i1 %t549, label %bb74, label %bb75
bb74:
  call void @__olang_errpay_pop()
  br label %bb75
bb75:
  br label %bb76
bb76:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l149, !tbaa !27
  br label %bb81
bb77:
  %t551 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t551, ptr %l149, !tbaa !27
  br label %bb81
bb78:
  %t552 = load i32, ptr %l160, !tbaa !23
  %t553 = ashr i32 %t552, 16
  %t555 = icmp eq i32 %t553, 1
  store i1 %t555, ptr %l162, !tbaa !21
  %t556 = load i32, ptr %l160, !tbaa !23
  %t557 = ashr i32 %t556, 16
  %t559 = icmp eq i32 %t557, 1
  br i1 %t559, label %bb79, label %bb80
bb79:
  call void @__olang_errpay_pop()
  br label %bb80
bb80:
  br label %bb76
bb81:
  %t561 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t562 = extractvalue { i64, ptr } %t561, 1
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t564 = load i64, ptr %l147
  %t565 = inttoptr i64 %t564 to ptr
  %t566 = call ptr @__olang_held_alloc(ptr %t565, i64 %t563)
  call void @olang_textcopy(ptr %t566, ptr %t562, i64 %t563)
  %t567 = insertvalue { i64, ptr } undef, i64 %t563, 0
  %t568 = insertvalue { i64, ptr } %t567, ptr %t566, 1
  store { i64, ptr } %t568, ptr %l165, !tbaa !27
  %t569 = load i1, ptr @olang_2esole_2ecompiler_2fjupyter_3akernel_2e0
  br i1 %t569, label %bb82, label %bb83
bb82:
  %t571 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t572 = extractvalue { i64, ptr } %t571, 0
  %t574 = icmp eq i64 %t572, 0
  br i1 %t574, label %bb84, label %bb85
bb83:
  %t577 = load { i64, ptr }, ptr %l165, !tbaa !27
  call void @compiler_2fjupyter_3akernel_2ector(ptr %t576, ptr %s0, { i64, ptr } %t577)
  call void @llvm.memmove.p0.p0.i64(ptr %l169, ptr %t576, i64 152, i1 false)
  br label %bb86
bb84:
  store { i64, ptr } zeroinitializer, ptr %l165, !tbaa !27
  br label %bb85
bb85:
  %t578 = load i64, ptr %l147
  %t579 = inttoptr i64 %t578 to ptr
  %t580 = load { i64, ptr }, ptr %l165
  %t581 = extractvalue { i64, ptr } %t580, 1
  %t582 = call ptr @__olang_region_or(ptr %t581, ptr null)
  %t583 = icmp ne ptr %t582, null
  %t584 = select i1 %t583, ptr %t582, ptr null
  call void @__olang_region_settle_in(ptr %t579, ptr %t584)
  br label %bb83
bb86:
  %t585 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 152, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t585, ptr %l169, i64 152, i1 false)
  store ptr %t585, ptr %l170, !tbaa !29
  %t586 = load ptr, ptr %l170, !tbaa !29
  call void @__olang_scope_register_dtor(ptr %s0, ptr %t586, ptr @olang_2emir_2eHelperKind_2eDrop_2ecompiler_2fjupyter_3akernel_rt)
  %t587 = load ptr, ptr %l170, !tbaa !29
  store ptr %t587, ptr %l7, !tbaa !29
  %t588 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t588, ptr %l171
  br label %bb87
bb87:
  %t589 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l171
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t589, ptr %l8
  store i1 true, ptr %l9, !tbaa !21
  store ptr @G_2ecompiler_2fjupyter_2ePortKeys, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t591 = load ptr, ptr %l10
  store i64 5, ptr %l12, !tbaa !24
  br label %bb88
bb88:
  store %olang.scope zeroinitializer, ptr %s7
  %t594 = load i64, ptr %l11, !tbaa !24
  %t595 = load i64, ptr %l12, !tbaa !24
  %t598 = icmp slt i64 %t594, %t595
  %t600 = xor i1 %t598, true
  br i1 %t600, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s7)
  br label %bb187
bb90:
  br label %bb91
bb91:
  %t602 = load ptr, ptr %l10
  %t603 = load i64, ptr %l11, !tbaa !24
  %t606 = getelementptr [5 x { i64, ptr }], ptr %t602, i64 0, i64 %t603
  %t607 = load { i64, ptr }, ptr %t606, !tbaa !37
  store { i64, ptr } %t607, ptr %l13, !tbaa !27
  %t609 = load ptr, ptr %l5, !tbaa !29
  %t610 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t611 = load ptr, ptr @__olang_prog_scope
  %t614 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0, ptr %t611, ptr %s0, ptr %t609, { i64, ptr } %t610)
  %t615 = extractvalue { i32, ptr } %t614, 1
  %t616 = extractvalue { i32, ptr } %t614, 0
  store i32 %t616, ptr %l186
  %t617 = icmp ne i32 %t616, 0
  br i1 %t617, label %bb93, label %ok.618, !prof !99
ok.618:
  store ptr %t615, ptr %l185
  br label %bb92
bb92:
  %t619 = load ptr, ptr %l185, !tbaa !29
  %t620 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %s0, ptr %t619)
  %t621 = extractvalue { i32, i64 } %t620, 1
  %t622 = extractvalue { i32, i64 } %t620, 0
  store i32 %t622, ptr %l190
  %t623 = icmp ne i32 %t622, 0
  br i1 %t623, label %bb96, label %ok.624, !prof !99
ok.624:
  store i64 %t621, ptr %l189
  br label %bb95
bb93:
  %t625 = load i32, ptr %l186, !tbaa !23
  %t626 = ashr i32 %t625, 16
  %t628 = icmp eq i32 %t626, 1
  store i1 %t628, ptr %l188, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l14
  %t629 = load i32, ptr %l186, !tbaa !23
  %t630 = lshr i32 %t629, 16
  %t631 = and i32 %t629, 65535
  %t632 = icmp eq i32 %t630, 1
  %t633 = select i1 %t632, i32 1, i32 0
  %t634 = icmp eq i32 %t629, 0
  %t635 = shl i32 %t633, 16
  %t636 = or i32 %t635, %t631
  %t637 = select i1 %t634, i32 0, i32 %t636
  %t638 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l14, i32 0, i32 0
  store i32 %t637, ptr %t638, !tbaa !23
  br label %bb94
bb94:
  store %olang.scope zeroinitializer, ptr %s8
  %t639 = load { i32, { i64, [2 x i64] } }, ptr %l14
  store { i32, { i64, [2 x i64] } } %t639, ptr %l193
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l194
  %t640 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l193, i32 0, i32 0
  %t641 = load i32, ptr %t640, !tbaa !23
  store i32 %t641, ptr %l195, !tbaa !23
  %t642 = load i32, ptr %l195, !tbaa !23
  %t643 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l194, i32 0, i32 0
  store i32 %t642, ptr %t643, !tbaa !23
  %t644 = load i32, ptr %l195, !tbaa !23
  %t645 = ashr i32 %t644, 16
  %t647 = icmp eq i32 %t645, 1
  br i1 %t647, label %bb97, label %bb98
bb95:
  %t649 = load i64, ptr %l189, !tbaa !24
  store i64 %t649, ptr %l182, !tbaa !24
  br label %bb129
bb96:
  %t650 = load i32, ptr %l190, !tbaa !23
  %t651 = ashr i32 %t650, 16
  %t653 = icmp eq i32 %t651, 1
  store i1 %t653, ptr %l192, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l14
  %t654 = load i32, ptr %l190, !tbaa !23
  %t655 = lshr i32 %t654, 16
  %t656 = and i32 %t654, 65535
  %t657 = icmp eq i32 %t655, 1
  %t658 = select i1 %t657, i32 1, i32 0
  %t659 = icmp eq i32 %t654, 0
  %t660 = shl i32 %t658, 16
  %t661 = or i32 %t660, %t656
  %t662 = select i1 %t659, i32 0, i32 %t661
  %t663 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l14, i32 0, i32 0
  store i32 %t662, ptr %t663, !tbaa !23
  br label %bb94
bb97:
  %t664 = call ptr @__olang_errpay_top_get()
  %t666 = load { i64, [2 x i64] }, ptr %t664
  %t667 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l194, i32 0, i32 1
  store { i64, [2 x i64] } %t666, ptr %t667
  br label %bb98
bb98:
  %t669 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fjson_3aError_7d(ptr %s7, ptr %l194)
  store { i32, { i64, [2 x i64] } } %t669, ptr %l200
  br label %bb99
bb99:
  %t670 = load { i32, { i64, [2 x i64] } }, ptr %l200
  store { i32, { i64, [2 x i64] } } %t670, ptr %l14
  %t671 = load { i32, { i64, [2 x i64] } }, ptr %l14
  store { i32, { i64, [2 x i64] } } %t671, ptr %l201
  %t672 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l201, i32 0, i32 0
  %t673 = load i32, ptr %t672, !tbaa !23
  %t674 = ashr i32 %t673, 16
  %t676 = icmp eq i32 %t674, 1
  br i1 %t676, label %bb100, label %bb101
bb100:
  call void @__olang_errpay_pop()
  br label %bb101
bb101:
  %t678 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t678, ptr %l204, !tbaa !27
  %t679 = load { i32, { i64, [2 x i64] } }, ptr %l14
  store { i32, { i64, [2 x i64] } } %t679, ptr %l205
  %t681 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fjson_3aError_7d(ptr %s8, ptr %l205)
  store { i32, { i64, [2 x i64] } } %t681, ptr %l207
  br label %bb102
bb102:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s9
  store ptr %s9room, ptr %s9
  %t682 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t683 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t682, i64 %t683)
  %t684 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t685 = extractvalue { i64, ptr } %t684, 1
  %t686 = extractvalue { i64, ptr } %t684, 0
  call void @__olang_sb_put(ptr %s9, ptr %t685, i64 %t686)
  %t687 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t688 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t687, i64 %t688)
  %t689 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 0
  %t690 = load i32, ptr %t689, !tbaa !23
  store i32 %t690, ptr %l208, !tbaa !23
  %t691 = load i32, ptr %l208, !tbaa !23
  %t692 = icmp eq i32 %t691, 0
  br i1 %t692, label %bb104, label %bb105
bb103:
  %t694 = load ptr, ptr %s9
  %t695 = getelementptr %olang.builder, ptr %s9, i32 0, i32 1
  %t696 = load i64, ptr %t695
  %t697 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t696)
  call void @olang_textcopy(ptr %t697, ptr %t694, i64 %t696)
  %t698 = insertvalue { i64, ptr } undef, i64 %t696, 0
  %t699 = insertvalue { i64, ptr } %t698, ptr %t697, 1
  store { i64, ptr } %t699, ptr %l234, !tbaa !27
  %t700 = getelementptr %olang.builder, ptr %s9, i32 0, i32 3
  %t701 = load ptr, ptr %t700
  %t702 = icmp ne ptr %t701, null
  br i1 %t702, label %sbgrew.703, label %sbdone.704
sbgrew.703:
  call void @__olang_sb_done(ptr %s9)
  br label %sbdone.704
sbdone.704:
  %t705 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t707 = call i32 @compiler_2fjupyter_2efail(ptr %s8, { i64, ptr } %t705)
  store i32 %t707, ptr %l236
  br label %bb124
bb104:
  %t708 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t709 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t708, i64 %t709)
  br label %bb103
bb105:
  %t710 = load i32, ptr %l208, !tbaa !23
  %t711 = icmp eq i32 %t710, 65536
  br i1 %t711, label %bb106, label %bb107
bb106:
  %t713 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t714 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t713, i64 %t714)
  %t715 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t716 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t715, i64 %t716)
  %t717 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t718 = getelementptr { i64, [2 x i64] }, ptr %t717, i32 0, i32 1
  %t719 = getelementptr { i64, i64 }, ptr %t718, i32 0, i32 0
  %t720 = load i64, ptr %t719
  %t722 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t723 = call i64 @__olang_fmt_i64(ptr %t722, i64 %t720)
  call void @__olang_sb_add(ptr %s9, i64 %t723)
  %t724 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t725 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t724, i64 %t725)
  %t726 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t727 = getelementptr { i64, [2 x i64] }, ptr %t726, i32 0, i32 1
  %t728 = getelementptr { i64, i64 }, ptr %t727, i32 0, i32 1
  %t729 = load i64, ptr %t728
  %t731 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t732 = call i64 @__olang_fmt_i64(ptr %t731, i64 %t729)
  call void @__olang_sb_add(ptr %s9, i64 %t732)
  %t733 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t734 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t733, i64 %t734)
  br label %bb103
bb107:
  %t735 = load i32, ptr %l208, !tbaa !23
  %t736 = icmp eq i32 %t735, 65537
  br i1 %t736, label %bb108, label %bb109
bb108:
  %t738 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t739 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t738, i64 %t739)
  %t740 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t741 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t740, i64 %t741)
  %t742 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t743 = getelementptr { i64, [2 x i64] }, ptr %t742, i32 0, i32 1
  %t744 = getelementptr { i64, i64 }, ptr %t743, i32 0, i32 0
  %t745 = load i64, ptr %t744
  %t747 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t748 = call i64 @__olang_fmt_i64(ptr %t747, i64 %t745)
  call void @__olang_sb_add(ptr %s9, i64 %t748)
  %t749 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t750 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t749, i64 %t750)
  %t751 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t752 = getelementptr { i64, [2 x i64] }, ptr %t751, i32 0, i32 1
  %t753 = getelementptr { i64, i64 }, ptr %t752, i32 0, i32 1
  %t754 = load i64, ptr %t753
  %t756 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t757 = call i64 @__olang_fmt_i64(ptr %t756, i64 %t754)
  call void @__olang_sb_add(ptr %s9, i64 %t757)
  %t758 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t759 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t758, i64 %t759)
  br label %bb103
bb109:
  %t760 = load i32, ptr %l208, !tbaa !23
  %t761 = icmp eq i32 %t760, 65538
  br i1 %t761, label %bb110, label %bb111
bb110:
  %t763 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t764 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t763, i64 %t764)
  %t765 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t766 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t765, i64 %t766)
  %t767 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t768 = getelementptr { i64, [2 x i64] }, ptr %t767, i32 0, i32 1
  %t769 = getelementptr { i64, i64 }, ptr %t768, i32 0, i32 0
  %t770 = load i64, ptr %t769
  %t772 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t773 = call i64 @__olang_fmt_i64(ptr %t772, i64 %t770)
  call void @__olang_sb_add(ptr %s9, i64 %t773)
  %t774 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t775 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t774, i64 %t775)
  %t776 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t777 = getelementptr { i64, [2 x i64] }, ptr %t776, i32 0, i32 1
  %t778 = getelementptr { i64, i64 }, ptr %t777, i32 0, i32 1
  %t779 = load i64, ptr %t778
  %t781 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t782 = call i64 @__olang_fmt_i64(ptr %t781, i64 %t779)
  call void @__olang_sb_add(ptr %s9, i64 %t782)
  %t783 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t784 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t783, i64 %t784)
  br label %bb103
bb111:
  %t785 = load i32, ptr %l208, !tbaa !23
  %t786 = icmp eq i32 %t785, 65539
  br i1 %t786, label %bb112, label %bb113
bb112:
  %t788 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t789 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t788, i64 %t789)
  %t790 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t791 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t790, i64 %t791)
  %t792 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t793 = getelementptr { i64, [2 x i64] }, ptr %t792, i32 0, i32 1
  %t794 = getelementptr { i64, i64 }, ptr %t793, i32 0, i32 0
  %t795 = load i64, ptr %t794
  %t797 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t798 = call i64 @__olang_fmt_i64(ptr %t797, i64 %t795)
  call void @__olang_sb_add(ptr %s9, i64 %t798)
  %t799 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t800 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t799, i64 %t800)
  %t801 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t802 = getelementptr { i64, [2 x i64] }, ptr %t801, i32 0, i32 1
  %t803 = getelementptr { i64, i64 }, ptr %t802, i32 0, i32 1
  %t804 = load i64, ptr %t803
  %t806 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t807 = call i64 @__olang_fmt_i64(ptr %t806, i64 %t804)
  call void @__olang_sb_add(ptr %s9, i64 %t807)
  %t808 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t809 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t808, i64 %t809)
  br label %bb103
bb113:
  %t810 = load i32, ptr %l208, !tbaa !23
  %t811 = icmp eq i32 %t810, 65540
  br i1 %t811, label %bb114, label %bb115
bb114:
  %t813 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t814 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t813, i64 %t814)
  %t815 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t816 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t815, i64 %t816)
  %t817 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t818 = getelementptr { i64, [2 x i64] }, ptr %t817, i32 0, i32 1
  %t819 = getelementptr { i64, i64 }, ptr %t818, i32 0, i32 0
  %t820 = load i64, ptr %t819
  %t822 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t823 = call i64 @__olang_fmt_i64(ptr %t822, i64 %t820)
  call void @__olang_sb_add(ptr %s9, i64 %t823)
  %t824 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t825 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t824, i64 %t825)
  %t826 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t827 = getelementptr { i64, [2 x i64] }, ptr %t826, i32 0, i32 1
  %t828 = getelementptr { i64, i64 }, ptr %t827, i32 0, i32 1
  %t829 = load i64, ptr %t828
  %t831 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t832 = call i64 @__olang_fmt_i64(ptr %t831, i64 %t829)
  call void @__olang_sb_add(ptr %s9, i64 %t832)
  %t833 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t834 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t833, i64 %t834)
  br label %bb103
bb115:
  %t835 = load i32, ptr %l208, !tbaa !23
  %t836 = icmp eq i32 %t835, 65541
  br i1 %t836, label %bb116, label %bb117
bb116:
  %t838 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t839 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t838, i64 %t839)
  %t840 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t841 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t840, i64 %t841)
  %t842 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t843 = getelementptr { i64, [2 x i64] }, ptr %t842, i32 0, i32 1
  %t844 = getelementptr { i64, i64 }, ptr %t843, i32 0, i32 0
  %t845 = load i64, ptr %t844
  %t847 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t848 = call i64 @__olang_fmt_i64(ptr %t847, i64 %t845)
  call void @__olang_sb_add(ptr %s9, i64 %t848)
  %t849 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t850 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t849, i64 %t850)
  %t851 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t852 = getelementptr { i64, [2 x i64] }, ptr %t851, i32 0, i32 1
  %t853 = getelementptr { i64, i64 }, ptr %t852, i32 0, i32 1
  %t854 = load i64, ptr %t853
  %t856 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t857 = call i64 @__olang_fmt_i64(ptr %t856, i64 %t854)
  call void @__olang_sb_add(ptr %s9, i64 %t857)
  %t858 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t859 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t858, i64 %t859)
  br label %bb103
bb117:
  %t860 = load i32, ptr %l208, !tbaa !23
  %t861 = icmp eq i32 %t860, 65542
  br i1 %t861, label %bb118, label %bb119
bb118:
  %t863 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t864 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t863, i64 %t864)
  %t865 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t866 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t865, i64 %t866)
  %t867 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t868 = getelementptr { i64, [2 x i64] }, ptr %t867, i32 0, i32 1
  %t869 = getelementptr { i64, i64 }, ptr %t868, i32 0, i32 0
  %t870 = load i64, ptr %t869
  %t872 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t873 = call i64 @__olang_fmt_i64(ptr %t872, i64 %t870)
  call void @__olang_sb_add(ptr %s9, i64 %t873)
  %t874 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t875 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t874, i64 %t875)
  %t876 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t877 = getelementptr { i64, [2 x i64] }, ptr %t876, i32 0, i32 1
  %t878 = getelementptr { i64, i64 }, ptr %t877, i32 0, i32 1
  %t879 = load i64, ptr %t878
  %t881 = call ptr @__olang_sb_room(ptr %s9, i64 24)
  %t882 = call i64 @__olang_fmt_i64(ptr %t881, i64 %t879)
  call void @__olang_sb_add(ptr %s9, i64 %t882)
  %t883 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t884 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t883, i64 %t884)
  br label %bb103
bb119:
  %t885 = load i32, ptr %l208, !tbaa !23
  %t886 = icmp eq i32 %t885, 65543
  br i1 %t886, label %bb120, label %bb121
bb120:
  %t888 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t889 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t888, i64 %t889)
  %t890 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t891 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t890, i64 %t891)
  %t892 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l207, i32 0, i32 1
  %t893 = getelementptr { i64, [2 x i64] }, ptr %t892, i32 0, i32 1
  %t894 = getelementptr { { i64, ptr } }, ptr %t893, i32 0, i32 0
  %t895 = load { i64, ptr }, ptr %t894
  %t897 = extractvalue { i64, ptr } %t895, 1
  %t898 = extractvalue { i64, ptr } %t895, 0
  %t899 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t897, i64 %t898, i8 34)
  %t900 = call ptr @__olang_sb_room(ptr %s9, i64 %t899)
  %t901 = call i64 @__olang_rd_quote(ptr %t900, i64 0, ptr %t897, i64 %t898, i8 34)
  call void @__olang_sb_add(ptr %s9, i64 %t899)
  %t902 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t903 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t902, i64 %t903)
  br label %bb103
bb121:
  %t904 = load i32, ptr %l208, !tbaa !23
  %t905 = icmp eq i32 %t904, 65544
  br i1 %t905, label %bb122, label %bb123
bb122:
  %t907 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t908 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t907, i64 %t908)
  br label %bb103
bb123:
  %t909 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t910 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t909, i64 %t910)
  br label %bb103
bb124:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  %t911 = load i1, ptr %l9, !tbaa !21
  br i1 %t911, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s11
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e(ptr %s11, ptr %l8)
  br label %bb127
bb126:
  br label %bb128
bb127:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s0)
  %t914 = load i32, ptr %l236, !tbaa !23
  store i32 %t914, ptr %rv
  br label %ret
bb129:
  %t915 = load i64, ptr %l182, !tbaa !24
  %t916 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t919 = extractvalue { i64, ptr } %t916, 1
  %t920 = extractvalue { i64, ptr } %t916, 0
  %t921 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t922 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t923 = add i64 %t920, %t922
  %t925 = call i64 @__olang_fmt_i64(ptr null, i64 %t915)
  %t926 = add i64 %t923, %t925
  %t927 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t926)
  call void @olang_textcopy(ptr %t927, ptr %t919, i64 %t920)
  %t928 = getelementptr i8, ptr %t927, i64 %t920
  call void @olang_textcopy(ptr %t928, ptr %t921, i64 %t922)
  %t929 = getelementptr i8, ptr %t928, i64 %t922
  %t930 = call i64 @__olang_fmt_i64(ptr %t929, i64 %t915)
  %t931 = insertvalue { i64, ptr } undef, i64 %t926, 0
  %t932 = insertvalue { i64, ptr } %t931, ptr %t927, 1
  %t935 = call { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2eParse(ptr %s7, { i64, ptr } %t932)
  %t936 = extractvalue { i32, %"std/net:Addr" } %t935, 1
  %t937 = extractvalue { i32, %"std/net:Addr" } %t935, 0
  store i32 %t937, ptr %l245
  %t938 = icmp ne i32 %t937, 0
  br i1 %t938, label %bb131, label %ok.939, !prof !99
ok.939:
  store %"std/net:Addr" %t936, ptr %l244
  br label %bb130
bb130:
  %t940 = load %"std/net:Addr", ptr %l244
  store %"std/net:Addr" %t940, ptr %l239
  br label %bb147
bb131:
  %t941 = load i32, ptr %l245, !tbaa !23
  %t942 = ashr i32 %t941, 16
  %t944 = icmp eq i32 %t942, 1
  store i1 %t944, ptr %l247, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l16
  %t945 = load i32, ptr %l245, !tbaa !23
  %t946 = lshr i32 %t945, 16
  %t947 = and i32 %t945, 65535
  %t948 = icmp eq i32 %t946, 1
  %t949 = select i1 %t948, i32 1, i32 0
  %t950 = icmp eq i32 %t945, 0
  %t951 = shl i32 %t949, 16
  %t952 = or i32 %t951, %t947
  %t953 = select i1 %t950, i32 0, i32 %t952
  %t954 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l16, i32 0, i32 0
  store i32 %t953, ptr %t954, !tbaa !23
  br label %bb132
bb132:
  store %olang.scope zeroinitializer, ptr %s13
  %t955 = load { i32, { i64, [2 x i64] } }, ptr %l16
  store { i32, { i64, [2 x i64] } } %t955, ptr %l248
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l249
  %t956 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l248, i32 0, i32 0
  %t957 = load i32, ptr %t956, !tbaa !23
  store i32 %t957, ptr %l250, !tbaa !23
  %t958 = load i32, ptr %l250, !tbaa !23
  %t959 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l249, i32 0, i32 0
  store i32 %t958, ptr %t959, !tbaa !23
  %t960 = load i32, ptr %l250, !tbaa !23
  %t961 = ashr i32 %t960, 16
  %t963 = icmp eq i32 %t961, 1
  br i1 %t963, label %bb133, label %bb134
bb133:
  %t965 = call ptr @__olang_errpay_top_get()
  %t967 = load { i64, [2 x i64] }, ptr %t965
  %t968 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l249, i32 0, i32 1
  store { i64, [2 x i64] } %t967, ptr %t968
  br label %bb134
bb134:
  %t970 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fnet_3aError_2e_2332_7d(ptr %s7, ptr %l249)
  store { i32, { i64, [2 x i64] } } %t970, ptr %l255
  br label %bb135
bb135:
  %t971 = load { i32, { i64, [2 x i64] } }, ptr %l255
  store { i32, { i64, [2 x i64] } } %t971, ptr %l16
  %t972 = load { i32, { i64, [2 x i64] } }, ptr %l16
  store { i32, { i64, [2 x i64] } } %t972, ptr %l256
  %t973 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l256, i32 0, i32 0
  %t974 = load i32, ptr %t973, !tbaa !23
  %t975 = ashr i32 %t974, 16
  %t977 = icmp eq i32 %t975, 1
  br i1 %t977, label %bb136, label %bb137
bb136:
  call void @__olang_errpay_pop()
  br label %bb137
bb137:
  %t979 = load { i32, { i64, [2 x i64] } }, ptr %l16
  store { i32, { i64, [2 x i64] } } %t979, ptr %l259
  %t981 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fnet_3aError_2e_2332_7d(ptr %s13, ptr %l259)
  store { i32, { i64, [2 x i64] } } %t981, ptr %l261
  br label %bb138
bb138:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s14
  store ptr %s14room, ptr %s14
  %t982 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l261, i32 0, i32 0
  %t983 = load i32, ptr %t982, !tbaa !23
  %t985 = icmp eq i32 %t983, 0
  br i1 %t985, label %bb140, label %bb141
bb139:
  %t987 = load ptr, ptr %s14
  %t988 = getelementptr %olang.builder, ptr %s14, i32 0, i32 1
  %t989 = load i64, ptr %t988
  %t990 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t989)
  call void @olang_textcopy(ptr %t990, ptr %t987, i64 %t989)
  %t991 = insertvalue { i64, ptr } undef, i64 %t989, 0
  %t992 = insertvalue { i64, ptr } %t991, ptr %t990, 1
  store { i64, ptr } %t992, ptr %l265, !tbaa !27
  %t993 = getelementptr %olang.builder, ptr %s14, i32 0, i32 3
  %t994 = load ptr, ptr %t993
  %t995 = icmp ne ptr %t994, null
  br i1 %t995, label %sbgrew.996, label %sbdone.997
sbgrew.996:
  call void @__olang_sb_done(ptr %s14)
  br label %sbdone.997
sbdone.997:
  %t998 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t1000 = call i32 @compiler_2fjupyter_2efail(ptr %s13, { i64, ptr } %t998)
  store i32 %t1000, ptr %l267
  br label %bb142
bb140:
  %t1001 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t1002 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t1001, i64 %t1002)
  br label %bb139
bb141:
  %t1003 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t1004 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t1003, i64 %t1004)
  %t1005 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t1006 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t1005, i64 %t1006)
  %t1007 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l261, i32 0, i32 1
  %t1008 = getelementptr { i64, [2 x i64] }, ptr %t1007, i32 0, i32 1
  %t1009 = getelementptr { { i64, ptr } }, ptr %t1008, i32 0, i32 0
  %t1010 = load { i64, ptr }, ptr %t1009
  %t1012 = extractvalue { i64, ptr } %t1010, 1
  %t1013 = extractvalue { i64, ptr } %t1010, 0
  %t1014 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t1012, i64 %t1013, i8 34)
  %t1015 = call ptr @__olang_sb_room(ptr %s14, i64 %t1014)
  %t1016 = call i64 @__olang_rd_quote(ptr %t1015, i64 0, ptr %t1012, i64 %t1013, i8 34)
  call void @__olang_sb_add(ptr %s14, i64 %t1014)
  %t1017 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t1018 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s14, ptr %t1017, i64 %t1018)
  br label %bb139
bb142:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s7)
  %t1019 = load i1, ptr %l9, !tbaa !21
  br i1 %t1019, label %bb143, label %bb144
bb143:
  store %olang.scope zeroinitializer, ptr %s16
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e(ptr %s16, ptr %l8)
  br label %bb145
bb144:
  br label %bb146
bb145:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s16)
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s0)
  %t1022 = load i32, ptr %l267, !tbaa !23
  store i32 %t1022, ptr %rv
  br label %ret
bb147:
  %t1023 = load %"std/net:Addr", ptr %l239
  store %"std/net:Addr" %t1023, ptr %l17
  store ptr %l8, ptr %l270, !tbaa !29
  %t1025 = call { i32, %"std/net:Listener" } @std_2fnet_2eListener_2eListen(ptr %s7, ptr %l17, i32 128)
  %t1026 = extractvalue { i32, %"std/net:Listener" } %t1025, 1
  %t1027 = extractvalue { i32, %"std/net:Listener" } %t1025, 0
  store i32 %t1027, ptr %l274
  %t1028 = icmp ne i32 %t1027, 0
  br i1 %t1028, label %bb149, label %ok.1029, !prof !99
ok.1029:
  store %"std/net:Listener" %t1026, ptr %l273
  br label %bb148
bb148:
  %t1030 = load %"std/net:Listener", ptr %l273
  store %"std/net:Listener" %t1030, ptr %l271
  br label %bb184
bb149:
  %t1031 = load i32, ptr %l274, !tbaa !23
  %t1032 = ashr i32 %t1031, 16
  %t1034 = icmp eq i32 %t1032, 1
  store i1 %t1034, ptr %l276, !tbaa !21
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l18
  %t1035 = load i32, ptr %l274, !tbaa !23
  %t1036 = lshr i32 %t1035, 16
  %t1037 = and i32 %t1035, 65535
  %t1038 = icmp eq i32 %t1036, 1
  %t1039 = select i1 %t1038, i32 1, i32 0
  %t1040 = icmp eq i32 %t1035, 0
  %t1041 = shl i32 %t1039, 16
  %t1042 = or i32 %t1041, %t1037
  %t1043 = select i1 %t1040, i32 0, i32 %t1042
  %t1044 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l18, i32 0, i32 0
  store i32 %t1043, ptr %t1044, !tbaa !23
  br label %bb150
bb150:
  store %olang.scope zeroinitializer, ptr %s17
  %t1045 = load { i32, { i64, [2 x i64] } }, ptr %l18
  store { i32, { i64, [2 x i64] } } %t1045, ptr %l277
  store { i32, { i64, [2 x i64] } } zeroinitializer, ptr %l278
  %t1046 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l277, i32 0, i32 0
  %t1047 = load i32, ptr %t1046, !tbaa !23
  store i32 %t1047, ptr %l279, !tbaa !23
  %t1048 = load i32, ptr %l279, !tbaa !23
  %t1049 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l278, i32 0, i32 0
  store i32 %t1048, ptr %t1049, !tbaa !23
  %t1050 = load i32, ptr %l279, !tbaa !23
  %t1051 = ashr i32 %t1050, 16
  %t1053 = icmp eq i32 %t1051, 1
  br i1 %t1053, label %bb151, label %bb152
bb151:
  %t1055 = call ptr @__olang_errpay_top_get()
  %t1057 = load { i64, [2 x i64] }, ptr %t1055
  %t1058 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l278, i32 0, i32 1
  store { i64, [2 x i64] } %t1057, ptr %t1058
  br label %bb152
bb152:
  %t1060 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fnet_3aError_7d(ptr %s7, ptr %l278)
  store { i32, { i64, [2 x i64] } } %t1060, ptr %l284
  br label %bb153
bb153:
  %t1061 = load { i32, { i64, [2 x i64] } }, ptr %l284
  store { i32, { i64, [2 x i64] } } %t1061, ptr %l18
  %t1062 = load { i32, { i64, [2 x i64] } }, ptr %l18
  store { i32, { i64, [2 x i64] } } %t1062, ptr %l285
  %t1063 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l285, i32 0, i32 0
  %t1064 = load i32, ptr %t1063, !tbaa !23
  %t1065 = ashr i32 %t1064, 16
  %t1067 = icmp eq i32 %t1065, 1
  br i1 %t1067, label %bb154, label %bb155
bb154:
  call void @__olang_errpay_pop()
  br label %bb155
bb155:
  %t1069 = load %"std/net:Addr", ptr %l17
  store %"std/net:Addr" %t1069, ptr %l288
  %t1070 = load { i32, { i64, [2 x i64] } }, ptr %l18
  store { i32, { i64, [2 x i64] } } %t1070, ptr %l289
  %t1072 = call { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fnet_3aError_7d(ptr %s17, ptr %l289)
  store { i32, { i64, [2 x i64] } } %t1072, ptr %l291
  br label %bb156
bb156:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  %t1073 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t1074 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1073, i64 %t1074)
  call void @olang_2emir_2eHelperKind_2eRender_2estd_2fnet_3aAddr(ptr %s18, ptr %l288, i64 0)
  br label %bb157
bb157:
  %t1076 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t1077 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1076, i64 %t1077)
  %t1078 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l291, i32 0, i32 0
  %t1079 = load i32, ptr %t1078, !tbaa !23
  store i32 %t1079, ptr %l293, !tbaa !23
  %t1080 = load i32, ptr %l293, !tbaa !23
  %t1081 = icmp eq i32 %t1080, 0
  br i1 %t1081, label %bb159, label %bb160
bb158:
  %t1083 = load ptr, ptr %s18
  %t1084 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t1085 = load i64, ptr %t1084
  %t1086 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t1085)
  call void @olang_textcopy(ptr %t1086, ptr %t1083, i64 %t1085)
  %t1087 = insertvalue { i64, ptr } undef, i64 %t1085, 0
  %t1088 = insertvalue { i64, ptr } %t1087, ptr %t1086, 1
  store { i64, ptr } %t1088, ptr %l306, !tbaa !27
  %t1089 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t1090 = load ptr, ptr %t1089
  %t1091 = icmp ne ptr %t1090, null
  br i1 %t1091, label %sbgrew.1092, label %sbdone.1093
sbgrew.1092:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.1093
sbdone.1093:
  %t1094 = load { i64, ptr }, ptr %l306, !tbaa !27
  %t1096 = call i32 @compiler_2fjupyter_2efail(ptr %s17, { i64, ptr } %t1094)
  store i32 %t1096, ptr %l308
  br label %bb179
bb159:
  %t1097 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t1098 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1097, i64 %t1098)
  br label %bb158
bb160:
  %t1099 = load i32, ptr %l293, !tbaa !23
  %t1100 = icmp eq i32 %t1099, 65536
  br i1 %t1100, label %bb161, label %bb162
bb161:
  %t1102 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t1103 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1102, i64 %t1103)
  br label %bb158
bb162:
  %t1104 = load i32, ptr %l293, !tbaa !23
  %t1105 = icmp eq i32 %t1104, 65537
  br i1 %t1105, label %bb163, label %bb164
bb163:
  %t1107 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t1108 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1107, i64 %t1108)
  br label %bb158
bb164:
  %t1109 = load i32, ptr %l293, !tbaa !23
  %t1110 = icmp eq i32 %t1109, 65538
  br i1 %t1110, label %bb165, label %bb166
bb165:
  %t1112 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t1113 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1112, i64 %t1113)
  br label %bb158
bb166:
  %t1114 = load i32, ptr %l293, !tbaa !23
  %t1115 = icmp eq i32 %t1114, 65539
  br i1 %t1115, label %bb167, label %bb168
bb167:
  %t1117 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t1118 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1117, i64 %t1118)
  br label %bb158
bb168:
  %t1119 = load i32, ptr %l293, !tbaa !23
  %t1120 = icmp eq i32 %t1119, 65540
  br i1 %t1120, label %bb169, label %bb170
bb169:
  %t1122 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t1123 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1122, i64 %t1123)
  br label %bb158
bb170:
  %t1124 = load i32, ptr %l293, !tbaa !23
  %t1125 = icmp eq i32 %t1124, 65541
  br i1 %t1125, label %bb171, label %bb172
bb171:
  %t1127 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t1128 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1127, i64 %t1128)
  %t1129 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t1130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1129, i64 %t1130)
  %t1131 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l291, i32 0, i32 1
  %t1132 = getelementptr { i64, [2 x i64] }, ptr %t1131, i32 0, i32 1
  %t1133 = getelementptr { { i64, ptr } }, ptr %t1132, i32 0, i32 0
  %t1134 = load { i64, ptr }, ptr %t1133
  %t1136 = extractvalue { i64, ptr } %t1134, 1
  %t1137 = extractvalue { i64, ptr } %t1134, 0
  %t1138 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t1136, i64 %t1137, i8 34)
  %t1139 = call ptr @__olang_sb_room(ptr %s18, i64 %t1138)
  %t1140 = call i64 @__olang_rd_quote(ptr %t1139, i64 0, ptr %t1136, i64 %t1137, i8 34)
  call void @__olang_sb_add(ptr %s18, i64 %t1138)
  %t1141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t1142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1141, i64 %t1142)
  br label %bb158
bb172:
  %t1143 = load i32, ptr %l293, !tbaa !23
  %t1144 = icmp eq i32 %t1143, 65542
  br i1 %t1144, label %bb173, label %bb174
bb173:
  %t1146 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t1147 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1146, i64 %t1147)
  %t1148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t1149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1148, i64 %t1149)
  %t1150 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l291, i32 0, i32 1
  %t1151 = getelementptr { i64, [2 x i64] }, ptr %t1150, i32 0, i32 1
  %t1152 = getelementptr { { i64, ptr } }, ptr %t1151, i32 0, i32 0
  %t1153 = load { i64, ptr }, ptr %t1152
  %t1155 = extractvalue { i64, ptr } %t1153, 1
  %t1156 = extractvalue { i64, ptr } %t1153, 0
  %t1157 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t1155, i64 %t1156, i8 34)
  %t1158 = call ptr @__olang_sb_room(ptr %s18, i64 %t1157)
  %t1159 = call i64 @__olang_rd_quote(ptr %t1158, i64 0, ptr %t1155, i64 %t1156, i8 34)
  call void @__olang_sb_add(ptr %s18, i64 %t1157)
  %t1160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t1161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1160, i64 %t1161)
  br label %bb158
bb174:
  %t1162 = load i32, ptr %l293, !tbaa !23
  %t1163 = icmp eq i32 %t1162, 65543
  br i1 %t1163, label %bb175, label %bb176
bb175:
  %t1165 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t1166 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1165, i64 %t1166)
  br label %bb158
bb176:
  %t1167 = load i32, ptr %l293, !tbaa !23
  %t1168 = icmp eq i32 %t1167, 65544
  br i1 %t1168, label %bb177, label %bb178
bb177:
  %t1170 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t1171 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1170, i64 %t1171)
  br label %bb158
bb178:
  %t1172 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t1173 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t1172, i64 %t1173)
  br label %bb158
bb179:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s7)
  %t1174 = load i1, ptr %l9, !tbaa !21
  br i1 %t1174, label %bb180, label %bb181
bb180:
  store %olang.scope zeroinitializer, ptr %s20
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e(ptr %s20, ptr %l8)
  br label %bb182
bb181:
  br label %bb183
bb182:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s20)
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s0)
  %t1177 = load i32, ptr %l308, !tbaa !23
  store i32 %t1177, ptr %rv
  br label %ret
bb184:
  %t1178 = load ptr, ptr %l270, !tbaa !29
  %t1179 = load %"std/net:Listener", ptr %l271
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2ePush_3cstd_2fnet_3aListener_3e(ptr %s0, ptr %t1178, %"std/net:Listener" %t1179)
  br label %bb185
bb185:
  call void @__olang_scope_close(ptr %s7)
  br label %bb186
bb186:
  %t1180 = load i64, ptr %l11, !tbaa !24
  %t1183 = add i64 %t1180, 1
  store i64 %t1183, ptr %l11, !tbaa !24
  br label %bb88
bb187:
  call void @compiler_2fprompt_3aSession_2ector(ptr %t1186, ptr %v0, ptr %s0, ptr %a0)
  call void @llvm.memmove.p0.p0.i64(ptr %l315, ptr %t1186, i64 1152, i1 false)
  br label %bb188
bb188:
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %l315, i64 1152, i1 false)
  %t1188 = getelementptr %"compiler/prompt:Session", ptr %l19, i32 0, i32 8
  store i1 true, ptr %t1188, !tbaa !21
  %t1189 = load ptr, ptr %l7, !tbaa !29
  %t1190 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t1191 = ptrtoint ptr %t1190 to i64
  %t1192 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 %t1191, i64 8)
  %t1193 = getelementptr { ptr, ptr }, ptr %t1192, i32 0, i32 0
  store ptr %t1189, ptr %t1193, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t1195 = call ptr @__olang_scope_hold(ptr %s0)
  %t1196 = getelementptr { ptr, ptr }, ptr %t1192, i32 0, i32 1
  store ptr %t1195, ptr %t1196, !tbaa !28
  %t1197 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_114, 0
  %t1198 = insertvalue { ptr, ptr } %t1197, ptr %t1192, 1
  %t1201 = getelementptr %"compiler/prompt:Session", ptr %l19, i32 0, i32 6
  store { ptr, ptr } %t1198, ptr %t1201
  br label %bb189
bb189:
  store %olang.scope zeroinitializer, ptr %s22
  %t1202 = load ptr, ptr %l7, !tbaa !29
  %t1204 = getelementptr %"compiler/jupyter:kernel", ptr %t1202, i32 0, i32 6
  %t1205 = load i1, ptr %t1204, !tbaa !21
  %t1207 = xor i1 %t1205, true
  %t1209 = xor i1 %t1207, true
  br i1 %t1209, label %bb190, label %bb191
bb190:
  call void @__olang_scope_close(ptr %s22)
  br label %bb267
bb191:
  br label %bb192
bb192:
  %t1211 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %s22, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1211, ptr %l323
  br label %bb193
bb193:
  %t1212 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l323
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1212, ptr %l20
  %t1214 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2eView_3cstd_2fnet_3aListener_3e(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t1214, ptr %l325
  br label %bb194
bb194:
  %t1215 = load { i64, ptr }, ptr %l325, !tbaa !27
  store { i64, ptr } %t1215, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t1216 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t1218 = extractvalue { i64, ptr } %t1216, 0
  store i64 %t1218, ptr %l23, !tbaa !24
  br label %bb195
bb195:
  %t1220 = load i64, ptr %l22, !tbaa !24
  %t1221 = load i64, ptr %l23, !tbaa !24
  %t1224 = icmp slt i64 %t1220, %t1221
  %t1226 = xor i1 %t1224, true
  br i1 %t1226, label %bb196, label %bb197
bb196:
  br label %bb202
bb197:
  br label %bb198
bb198:
  %t1228 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t1228, ptr %l332, !tbaa !27
  %t1229 = load i64, ptr %l22, !tbaa !24
  %t1231 = getelementptr { i64, ptr }, ptr %l332, i32 0, i32 1
  %t1232 = load ptr, ptr %t1231, !tbaa !27
  %t1233 = getelementptr %"std/net:Listener", ptr %t1232, i64 %t1229
  store ptr %l20, ptr %l335, !tbaa !29
  %t1237 = call i32 @std_2fnet_2estd_2fnet_3aListener_2eFd(ptr %s0, ptr %t1233)
  store i32 %t1237, ptr %l337
  br label %bb199
bb199:
  %t1238 = load ptr, ptr %l335, !tbaa !29
  %t1239 = load i32, ptr %l337, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %s22, ptr %t1238, i32 %t1239)
  br label %bb200
bb200:
  br label %bb201
bb201:
  %t1240 = load i64, ptr %l22, !tbaa !24
  %t1243 = add i64 %t1240, 1
  store i64 %t1243, ptr %l22, !tbaa !24
  br label %bb195
bb202:
  %t1245 = load ptr, ptr %l7, !tbaa !29
  %t1247 = getelementptr %"compiler/jupyter:kernel", ptr %t1245, i32 0, i32 4
  %t1249 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eView_3cstd_2fzmtp_3aSocket_3e(ptr %s0, ptr %s0, ptr %t1247)
  store { i64, ptr } %t1249, ptr %l343
  br label %bb203
bb203:
  %t1250 = load { i64, ptr }, ptr %l343, !tbaa !27
  store { i64, ptr } %t1250, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t1251 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t1253 = extractvalue { i64, ptr } %t1251, 0
  store i64 %t1253, ptr %l27, !tbaa !24
  br label %bb204
bb204:
  %t1255 = load i64, ptr %l26, !tbaa !24
  %t1256 = load i64, ptr %l27, !tbaa !24
  %t1259 = icmp slt i64 %t1255, %t1256
  %t1261 = xor i1 %t1259, true
  br i1 %t1261, label %bb205, label %bb206
bb205:
  br label %bb211
bb206:
  br label %bb207
bb207:
  %t1263 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t1263, ptr %l350, !tbaa !27
  %t1264 = load i64, ptr %l26, !tbaa !24
  %t1266 = getelementptr { i64, ptr }, ptr %l350, i32 0, i32 1
  %t1267 = load ptr, ptr %t1266, !tbaa !27
  %t1268 = getelementptr %"std/zmtp:Socket", ptr %t1267, i64 %t1264
  store ptr %l20, ptr %l353, !tbaa !29
  %t1272 = call i32 @std_2fzmtp_2estd_2fzmtp_3aSocket_2eFd(ptr %s0, ptr %t1268)
  store i32 %t1272, ptr %l355
  br label %bb208
bb208:
  %t1273 = load ptr, ptr %l353, !tbaa !29
  %t1274 = load i32, ptr %l355, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %s22, ptr %t1273, i32 %t1274)
  br label %bb209
bb209:
  br label %bb210
bb210:
  %t1275 = load i64, ptr %l26, !tbaa !24
  %t1278 = add i64 %t1275, 1
  store i64 %t1278, ptr %l26, !tbaa !24
  br label %bb204
bb211:
  %t1281 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eView_3cI32_3e(ptr %s22, ptr %s22, ptr %l20)
  store { i64, ptr } %t1281, ptr %l360
  br label %bb212
bb212:
  %t1282 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t1283 = call { i64, ptr } @std_2fnet_2eReadable(ptr %s22, ptr %s22, { i64, ptr } %t1282, i64 -1)
  store { i64, ptr } %t1283, ptr %l361
  br label %bb213
bb213:
  %t1284 = load { i64, ptr }, ptr %l361, !tbaa !27
  store { i64, ptr } %t1284, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t1286 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2eLen_3cstd_2fnet_3aListener_3e(ptr %s0, ptr %l8)
  store i64 %t1286, ptr %l363
  br label %bb214
bb214:
  %t1287 = load i64, ptr %l363, !tbaa !24
  store i64 %t1287, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t1288 = load i64, ptr %l31, !tbaa !24
  %t1289 = load i64, ptr %l30, !tbaa !24
  %t1292 = icmp sgt i64 %t1288, %t1289
  br i1 %t1292, label %bb215, label %bb216
bb215:
  %t1294 = load i64, ptr %l32, !tbaa !24
  %t1296 = icmp sgt i64 %t1294, 0
  br i1 %t1296, label %bb217, label %bb218
bb216:
  store i64 0, ptr %l367, !tbaa !24
  br label %bb220
bb217:
  %t1298 = load i64, ptr %l31, !tbaa !24
  %t1299 = load i64, ptr %l30, !tbaa !24
  %t1302 = sub i64 %t1298, %t1299
  %t1303 = load i64, ptr %l32, !tbaa !24
  %t1306 = add i64 %t1302, %t1303
  %t1308 = sub i64 %t1306, 1
  %t1309 = load i64, ptr %l32, !tbaa !24
  %t1312 = sdiv i64 %t1308, %t1309
  store i64 %t1312, ptr %l370, !tbaa !24
  br label %bb219
bb218:
  store i64 0, ptr %l370, !tbaa !24
  br label %bb219
bb219:
  %t1314 = load i64, ptr %l370, !tbaa !24
  store i64 %t1314, ptr %l367, !tbaa !24
  br label %bb220
bb220:
  %t1315 = load i64, ptr %l367, !tbaa !24
  store i64 %t1315, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb221
bb221:
  %t1316 = load i64, ptr %l34, !tbaa !24
  %t1317 = load i64, ptr %l33, !tbaa !24
  %t1320 = icmp slt i64 %t1316, %t1317
  %t1322 = xor i1 %t1320, true
  br i1 %t1322, label %bb222, label %bb223
bb222:
  br label %bb231
bb223:
  br label %bb224
bb224:
  %t1324 = load i64, ptr %l30, !tbaa !24
  %t1325 = load i64, ptr %l34, !tbaa !24
  %t1326 = load i64, ptr %l32, !tbaa !24
  %t1329 = mul i64 %t1325, %t1326
  %t1332 = add i64 %t1324, %t1329
  store i64 %t1332, ptr %l35, !tbaa !24
  %t1334 = load i64, ptr %l35, !tbaa !24
  %t1336 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t1337 = load ptr, ptr %t1336, !tbaa !27
  %t1338 = getelementptr i1, ptr %t1337, i64 %t1334
  %t1339 = load i1, ptr %t1338, !tbaa !31
  br i1 %t1339, label %bb225, label %bb226
bb225:
  %t1341 = load ptr, ptr %l7, !tbaa !29
  store ptr %t1341, ptr %l390, !tbaa !29
  %t1342 = load i64, ptr %l35, !tbaa !24
  %t1345 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2eRefMut_3cstd_2fnet_3aListener_3e(ptr %s0, ptr %s0, ptr %l8, i64 %t1342)
  store ptr %t1345, ptr %l393
  br label %bb227
bb226:
  br label %bb229
bb227:
  %t1346 = load i64, ptr %l35, !tbaa !24
  %t1347 = load ptr, ptr %l390, !tbaa !29
  %t1348 = load ptr, ptr %l393, !tbaa !29
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2eaccept(ptr %s0, ptr %s0, ptr %t1347, ptr %t1348, i64 %t1346)
  br label %bb228
bb228:
  br label %bb229
bb229:
  br label %bb230
bb230:
  %t1350 = load i64, ptr %l34, !tbaa !24
  %t1353 = add i64 %t1350, 1
  store i64 %t1353, ptr %l34, !tbaa !24
  br label %bb221
bb231:
  store i64 0, ptr %l36, !tbaa !24
  %t1355 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t1357 = extractvalue { i64, ptr } %t1355, 0
  store i64 %t1357, ptr %l399, !tbaa !24
  %t1359 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2eLen_3cstd_2fnet_3aListener_3e(ptr %s0, ptr %l8)
  store i64 %t1359, ptr %l401
  br label %bb232
bb232:
  %t1360 = load i64, ptr %l399, !tbaa !24
  %t1361 = load i64, ptr %l401, !tbaa !24
  %t1362 = sub i64 %t1360, %t1361
  store i64 %t1362, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t1364 = load i64, ptr %l37, !tbaa !24
  %t1365 = load i64, ptr %l36, !tbaa !24
  %t1368 = icmp sgt i64 %t1364, %t1365
  br i1 %t1368, label %bb233, label %bb234
bb233:
  %t1370 = load i64, ptr %l38, !tbaa !24
  %t1372 = icmp sgt i64 %t1370, 0
  br i1 %t1372, label %bb235, label %bb236
bb234:
  store i64 0, ptr %l406, !tbaa !24
  br label %bb238
bb235:
  %t1374 = load i64, ptr %l37, !tbaa !24
  %t1375 = load i64, ptr %l36, !tbaa !24
  %t1378 = sub i64 %t1374, %t1375
  %t1379 = load i64, ptr %l38, !tbaa !24
  %t1382 = add i64 %t1378, %t1379
  %t1384 = sub i64 %t1382, 1
  %t1385 = load i64, ptr %l38, !tbaa !24
  %t1388 = sdiv i64 %t1384, %t1385
  store i64 %t1388, ptr %l409, !tbaa !24
  br label %bb237
bb236:
  store i64 0, ptr %l409, !tbaa !24
  br label %bb237
bb237:
  %t1390 = load i64, ptr %l409, !tbaa !24
  store i64 %t1390, ptr %l406, !tbaa !24
  br label %bb238
bb238:
  %t1391 = load i64, ptr %l406, !tbaa !24
  store i64 %t1391, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb239
bb239:
  %t1392 = load i64, ptr %l40, !tbaa !24
  %t1393 = load i64, ptr %l39, !tbaa !24
  %t1396 = icmp slt i64 %t1392, %t1393
  %t1398 = xor i1 %t1396, true
  br i1 %t1398, label %bb240, label %bb241
bb240:
  br label %bb249
bb241:
  br label %bb242
bb242:
  %t1400 = load i64, ptr %l36, !tbaa !24
  %t1401 = load i64, ptr %l40, !tbaa !24
  %t1402 = load i64, ptr %l38, !tbaa !24
  %t1405 = mul i64 %t1401, %t1402
  %t1408 = add i64 %t1400, %t1405
  store i64 %t1408, ptr %l41, !tbaa !24
  %t1411 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2eLen_3cstd_2fnet_3aListener_3e(ptr %s0, ptr %l8)
  store i64 %t1411, ptr %l428
  br label %bb243
bb243:
  %t1412 = load i64, ptr %l41, !tbaa !24
  %t1413 = load i64, ptr %l428, !tbaa !24
  %t1415 = add i64 %t1413, %t1412
  %t1417 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t1418 = load ptr, ptr %t1417, !tbaa !27
  %t1419 = getelementptr i1, ptr %t1418, i64 %t1415
  %t1420 = load i1, ptr %t1419, !tbaa !31
  br i1 %t1420, label %bb244, label %bb245
bb244:
  %t1422 = load ptr, ptr %l7, !tbaa !29
  %t1423 = load i64, ptr %l41, !tbaa !24
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2eserve(ptr %s0, ptr %s0, ptr %v0, ptr %t1422, ptr %l19, i64 %t1423)
  br label %bb246
bb245:
  br label %bb247
bb246:
  br label %bb247
bb247:
  br label %bb248
bb248:
  %t1427 = load i64, ptr %l40, !tbaa !24
  %t1430 = add i64 %t1427, 1
  store i64 %t1430, ptr %l40, !tbaa !24
  br label %bb239
bb249:
  br label %bb250
bb250:
  store %olang.scope zeroinitializer, ptr %s37
  %t1432 = load ptr, ptr %l7, !tbaa !29
  %t1434 = getelementptr %"compiler/jupyter:kernel", ptr %t1432, i32 0, i32 6
  %t1435 = load i1, ptr %t1434, !tbaa !21
  %t1437 = xor i1 %t1435, true
  br i1 %t1437, label %bb251, label %bb252
bb251:
  %t1439 = load ptr, ptr %l7, !tbaa !29
  %t1441 = getelementptr %"compiler/jupyter:kernel", ptr %t1439, i32 0, i32 7
  %t1443 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fjupyter_3apending_3e_2eLen__H3ed9013f6604c7fc0e46a0318571cb25(ptr %s0, ptr %t1441)
  store i64 %t1443, ptr %l444
  br label %bb253
bb252:
  store i1 false, ptr %l441, !tbaa !21
  br label %bb254
bb253:
  %t1444 = load i64, ptr %l444, !tbaa !24
  %t1445 = icmp sgt i64 %t1444, 0
  store i1 %t1445, ptr %l441, !tbaa !21
  br label %bb254
bb254:
  %t1447 = load i1, ptr %l441, !tbaa !21
  %t1448 = xor i1 %t1447, true
  br i1 %t1448, label %bb255, label %bb256
bb255:
  call void @__olang_scope_close(ptr %s37)
  br label %bb264
bb256:
  br label %bb257
bb257:
  %t1450 = load ptr, ptr %l7, !tbaa !29
  %t1452 = getelementptr %"compiler/jupyter:kernel", ptr %t1450, i32 0, i32 7
  %t1454 = call { i32, %"compiler/jupyter:pending" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fjupyter_3apending_3e_2eTake_H6fdf3e54d655bfcfaddc15fb1412c3ad(ptr %s0, ptr %s0, ptr %t1452, i64 0)
  %t1455 = extractvalue { i32, %"compiler/jupyter:pending" } %t1454, 1
  %t1456 = extractvalue { i32, %"compiler/jupyter:pending" } %t1454, 0
  store i32 %t1456, ptr %l451
  %t1457 = icmp ne i32 %t1456, 0
  br i1 %t1457, label %bb259, label %ok.1458, !prof !99
ok.1458:
  store %"compiler/jupyter:pending" %t1455, ptr %l450
  br label %bb258
bb258:
  %t1459 = load %"compiler/jupyter:pending", ptr %l450
  store %"compiler/jupyter:pending" %t1459, ptr %l447
  br label %bb261
bb259:
  %t1460 = load i32, ptr %l451, !tbaa !23
  %t1461 = ashr i32 %t1460, 16
  %t1463 = icmp eq i32 %t1461, 1
  store i1 %t1463, ptr %l453, !tbaa !21
  br label %bb260
bb260:
  call void @__olang_scope_close(ptr %s37)
  br label %bb264
bb261:
  %t1464 = load %"compiler/jupyter:pending", ptr %l447
  store %"compiler/jupyter:pending" %t1464, ptr %l42
  %t1465 = load ptr, ptr %l7, !tbaa !29
  %t1466 = getelementptr %"compiler/jupyter:pending", ptr %l42, i32 0, i32 0
  %t1467 = load i64, ptr %t1466, !tbaa !24
  %t1468 = getelementptr %"compiler/jupyter:pending", ptr %l42, i32 0, i32 1
  %t1469 = load { i64, ptr }, ptr %t1468, !tbaa !27
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ehandle(ptr %s0, ptr %s0, ptr %s37, ptr %v0, ptr %t1465, ptr %l19, i64 %t1467, { i64, ptr } %t1469)
  br label %bb262
bb262:
  call void @__olang_scope_close(ptr %s37)
  br label %bb263
bb263:
  br label %bb250
bb264:
  %t1474 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2esweep(ptr %s0, ptr %t1474)
  br label %bb265
bb265:
  call void @__olang_scope_close(ptr %s22)
  br label %bb266
bb266:
  br label %bb189
bb267:
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eEnd(ptr %s0, ptr %v0, ptr %l19)
  br label %bb268
bb268:
  store i32 0, ptr %l460, !tbaa !23
  %t1477 = load i1, ptr %l9, !tbaa !21
  br i1 %t1477, label %bb269, label %bb270
bb269:
  store %olang.scope zeroinitializer, ptr %s40
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e(ptr %s40, ptr %l8)
  br label %bb271
bb270:
  br label %bb272
bb271:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s40)
  br label %bb272
bb272:
  call void @__olang_scope_close(ptr %s0)
  %t1480 = load i32, ptr %l460, !tbaa !23
  store i32 %t1480, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, i64, i64 } @compiler_2fjupyter_2ecivil(i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l51 = alloca i64
  %l59 = alloca i64
  %l62 = alloca i64
  %rv = alloca { i64, i64, i64 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = add i64 %a0, 719468
  store i64 %t3, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = sdiv i64 %t5, 146097
  store i64 %t7, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = mul i64 %t10, 146097
  %t15 = sub i64 %t9, %t12
  store i64 %t15, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = sdiv i64 %t18, 1460
  %t23 = sub i64 %t17, %t20
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = sdiv i64 %t24, 36524
  %t29 = add i64 %t23, %t26
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = sdiv i64 %t30, 146096
  %t35 = sub i64 %t29, %t32
  %t37 = sdiv i64 %t35, 365
  store i64 %t37, ptr %l4, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = mul i64 365, %t40
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = sdiv i64 %t43, 4
  %t48 = add i64 %t42, %t45
  %t49 = load i64, ptr %l4, !tbaa !24
  %t51 = sdiv i64 %t49, 100
  %t54 = sub i64 %t48, %t51
  %t57 = sub i64 %t39, %t54
  store i64 %t57, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = mul i64 5, %t59
  %t63 = add i64 %t61, 2
  %t65 = sdiv i64 %t63, 153
  store i64 %t65, ptr %l6, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = mul i64 153, %t68
  %t72 = add i64 %t70, 2
  %t74 = sdiv i64 %t72, 5
  %t77 = sub i64 %t67, %t74
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l7, !tbaa !24
  %t81 = load i64, ptr %l6, !tbaa !24
  %t83 = icmp slt i64 %t81, 10
  br i1 %t83, label %bb1, label %bb2
bb1:
  %t85 = load i64, ptr %l6, !tbaa !24
  %t87 = add i64 %t85, 3
  store i64 %t87, ptr %l51, !tbaa !24
  br label %bb3
bb2:
  %t89 = load i64, ptr %l6, !tbaa !24
  %t91 = sub i64 %t89, 9
  store i64 %t91, ptr %l51, !tbaa !24
  br label %bb3
bb3:
  %t93 = load i64, ptr %l51, !tbaa !24
  store i64 %t93, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l4, !tbaa !24
  %t95 = load i64, ptr %l2, !tbaa !24
  %t97 = mul i64 %t95, 400
  %t100 = add i64 %t94, %t97
  store i64 %t100, ptr %l59, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t103 = icmp sle i64 %t101, 2
  br i1 %t103, label %bb4, label %bb5
bb4:
  store i64 1, ptr %l62, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb6
bb6:
  %t105 = load i64, ptr %l59, !tbaa !24
  %t106 = load i64, ptr %l62, !tbaa !24
  %t107 = add i64 %t105, %t106
  %t108 = load i64, ptr %l8, !tbaa !24
  %t109 = load i64, ptr %l7, !tbaa !24
  %t111 = insertvalue { i64, i64, i64 } undef, i64 %t107, 0
  %t113 = insertvalue { i64, i64, i64 } %t111, i64 %t108, 1
  %t115 = insertvalue { i64, i64, i64 } %t113, i64 %t109, 2
  store { i64, i64, i64 } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64, i64 }, ptr %rv
  ret { i64, i64, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2fjupyter_2ecompiler_2fjupyter_3aCapture_2eEnd(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l31 = alloca i32
  %l32 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l45 = alloca i64
  %l54 = alloca i32
  %l55 = alloca i64
  %l56 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/jupyter:Capture", ptr %t1, i32 0, i32 1
  %t4 = load i32, ptr %t3, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/jupyter:Capture", ptr %t5, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t11 = call i32 @dup2(i32 %t4, i32 %t8)
  store i32 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/jupyter:Capture", ptr %t12, i32 0, i32 1
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = call i32 @close(i32 %t15)
  store i32 %t17, ptr %l12
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/jupyter:Capture", ptr %t18, i32 0, i32 2
  %t21 = load i32, ptr %t20, !tbaa !23
  %t23 = call i64 @lseek(i32 %t21, i64 0, i32 2)
  store i64 %t23, ptr %l15
  br label %bb3
bb3:
  %t24 = load i64, ptr %l15, !tbaa !24
  store i64 %t24, ptr %l1, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/jupyter:Capture", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  %t30 = call i64 @lseek(i32 %t28, i64 0, i32 0)
  store i64 %t30, ptr %l18
  br label %bb4
bb4:
  %t31 = load i64, ptr %l1, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load i64, ptr %l1, !tbaa !24
  store i64 %t35, ptr %l21, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l21, !tbaa !24
  %t38 = icmp sge i64 %t37, 0
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load i64, ptr %l21, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_c63743b1fec4c0d4_43198d06044e4ff0)
  unreachable
bb10:
  %t46 = load i64, ptr %l3, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t52 = icmp slt i64 %t46, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb11, label %bb12
bb11:
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/jupyter:Capture", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %t58, !tbaa !23
  store i32 %t59, ptr %l31, !tbaa !23
  %t60 = load i64, ptr %l3, !tbaa !24
  store i64 %t60, ptr %l32, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l34, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l35, !tbaa !24
  %t66 = load i64, ptr %l32, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  br i1 %t67, label %bb14, label %bb15
bb14:
  %t69 = load i64, ptr %l32, !tbaa !24
  %t70 = load i64, ptr %l34, !tbaa !24
  %t71 = icmp sle i64 %t69, %t70
  br i1 %t71, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_69a6c85b3d3b36f9_8c1f3e3900689b5d)
  unreachable
bb16:
  %t73 = load i64, ptr %l34, !tbaa !24
  %t74 = load i64, ptr %l35, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  br i1 %t75, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_69a6c85b3d3b36f9_8c1f3e3900689b5d)
  unreachable
bb18:
  %t77 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = load i64, ptr %l32, !tbaa !24
  %t80 = load i64, ptr %l34, !tbaa !24
  %t81 = getelementptr i8, ptr %t78, i64 %t79
  %t82 = sub i64 %t80, %t79
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = load i64, ptr %l3, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t93 = load i32, ptr %l31, !tbaa !23
  %t95 = extractvalue { i64, ptr } %t84, 1
  %t96 = extractvalue { i64, ptr } %t84, 0
  %t98 = call i64 @read(i32 %t93, ptr %t95, i64 %t91)
  store i64 %t98, ptr %l45
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_69a6c85b3d3b36f9_8c1f3e3900689b5d)
  unreachable
bb20:
  %t99 = load i64, ptr %l45, !tbaa !24
  store i64 %t99, ptr %l4, !tbaa !24
  %t100 = load i64, ptr %l4, !tbaa !24
  %t102 = icmp sle i64 %t100, 0
  br i1 %t102, label %bb21, label %bb22
bb21:
  br label %bb25
bb22:
  br label %bb23
bb23:
  %t104 = load i64, ptr %l3, !tbaa !24
  %t106 = load i64, ptr %l4, !tbaa !24
  %t109 = add i64 %t104, %t106
  store i64 %t109, ptr %l3, !tbaa !24
  br label %bb24
bb24:
  br label %bb10
bb25:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/jupyter:Capture", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %t113, !tbaa !23
  %t116 = call i32 @close(i32 %t114)
  store i32 %t116, ptr %l54
  br label %bb26
bb26:
  %t117 = load i64, ptr %l3, !tbaa !24
  store i64 %t117, ptr %l55, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l56, !tbaa !24
  %t120 = icmp sge i64 0, 0
  br i1 %t120, label %bb27, label %bb28
bb27:
  %t122 = load i64, ptr %l55, !tbaa !24
  %t123 = icmp sle i64 0, %t122
  br i1 %t123, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_df7b1c0fb7414e5a_53e9012a4cdfda7e)
  unreachable
bb29:
  %t125 = load i64, ptr %l55, !tbaa !24
  %t126 = load i64, ptr %l56, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_df7b1c0fb7414e5a_53e9012a4cdfda7e)
  unreachable
bb31:
  %t129 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l55, !tbaa !24
  %t132 = getelementptr i8, ptr %t130, i64 0
  %t133 = sub i64 %t131, 0
  %t134 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t132, 1
  store { i64, ptr } %t135, ptr %l61, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  store i64 %t138, ptr %l62, !tbaa !24
  %t139 = load i64, ptr %l62, !tbaa !24
  %t140 = mul i64 %t139, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l63, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l62, !tbaa !24
  %t149 = mul i64 %t148, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %t147, i64 %t149, i1 false)
  %t150 = load { i64, ptr }, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t150, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_df7b1c0fb7414e5a_53e9012a4cdfda7e)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2eaccept(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"std/zmtp:Socket"
  %l9 = alloca %"std/zmtp:Socket"
  %l10 = alloca i32
  %l12 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/jupyter:kernel", ptr %t1, i32 0, i32 4
  store ptr %t3, ptr %l4, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = getelementptr [5 x { i64, ptr }], ptr @G_2ecompiler_2fjupyter_2eKinds, i64 0, i64 %t5
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !37
  %t9 = load ptr, ptr @__olang_prog_scope
  %t12 = call { i32, %"std/zmtp:Socket" } @std_2fzmtp_2eSocket_2eAccept(ptr %v1, ptr %t9, ptr %v0, ptr %a1, { i64, ptr } %t8)
  %t13 = extractvalue { i32, %"std/zmtp:Socket" } %t12, 1
  %t14 = extractvalue { i32, %"std/zmtp:Socket" } %t12, 0
  store i32 %t14, ptr %l10
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb2, label %ok.16, !prof !99
ok.16:
  store %"std/zmtp:Socket" %t13, ptr %l9
  br label %bb1
bb1:
  %t17 = load %"std/zmtp:Socket", ptr %l9
  store %"std/zmtp:Socket" %t17, ptr %l5
  br label %bb6
bb2:
  %t18 = load i32, ptr %l10, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  store i1 %t21, ptr %l12, !tbaa !21
  %t22 = load i32, ptr %l10, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  br i1 %t25, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %ret
bb6:
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t28 = load %"std/zmtp:Socket", ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2ePush_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %v0, ptr %t27, %"std/zmtp:Socket" %t28)
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/jupyter:kernel", ptr %t29, i32 0, i32 5
  %t32 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t31, i64 %t32)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2eexecute(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i64 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca %"compiler/jupyter:Capture"
  %l9 = alloca %"compiler/jupyter:Capture"
  %l10 = alloca %"compiler/prompt:Reply"
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/text:LineIter"
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i32
  %l35 = alloca i1
  %l40 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l56 = alloca %"compiler/jupyter:Capture"
  %l57 = alloca %"compiler/jupyter:Capture"
  %l58 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l66 = alloca %"compiler/prompt:Reply"
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l87 = alloca i1
  %l90 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l95 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l103 = alloca i1
  %l111 = alloca { i64, ptr }
  %l112 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca { i64, ptr }
  %l115 = alloca %"std/prelude/text:LineIter"
  %l116 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l119 = alloca i32
  %l121 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i64
  %l126 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %t126 = alloca %"compiler/prompt:Reply", align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fjupyter_2estr(ptr %v3, ptr %s0, ptr %v3, ptr %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d115, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l21
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load ptr, ptr %l4, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d116, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t9 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v3, ptr %v3, ptr %t5, { i64, ptr } %t6)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l27
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13, !prof !99
ok.13:
  store ptr %t10, ptr %l26
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l26, !tbaa !29
  %t15 = call { i32, i1 } @std_2fjson_2estd_2fjson_3aJson_2eAsBool(ptr %v3, ptr %t14)
  %t16 = extractvalue { i32, i1 } %t15, 1
  %t17 = extractvalue { i32, i1 } %t15, 0
  store i32 %t17, ptr %l33
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb8, label %ok.19, !prof !99
ok.19:
  store i1 %t16, ptr %l32
  br label %bb7
bb3:
  %t20 = load i32, ptr %l27, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l29, !tbaa !21
  %t24 = load i32, ptr %l27, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb7:
  %t29 = load i1, ptr %l32, !tbaa !21
  store i1 %t29, ptr %l22, !tbaa !21
  br label %bb11
bb8:
  %t30 = load i32, ptr %l33, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  store i1 %t33, ptr %l35, !tbaa !21
  %t34 = load i32, ptr %l33, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  br i1 %t37, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb6
bb11:
  %t39 = load i1, ptr %l22, !tbaa !21
  store i1 %t39, ptr %l6, !tbaa !21
  %t40 = load i1, ptr %l6, !tbaa !21
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l40, !tbaa !29
  %t45 = load ptr, ptr %l40, !tbaa !29
  %t46 = getelementptr %"compiler/jupyter:kernel", ptr %t45, i32 0, i32 2
  %t47 = load i64, ptr %t46, !tbaa !24
  %t50 = add i64 %t47, 1
  %t52 = load ptr, ptr %l40, !tbaa !29
  %t53 = getelementptr %"compiler/jupyter:kernel", ptr %t52, i32 0, i32 2
  store i64 %t50, ptr %t53, !tbaa !24
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/jupyter:kernel", ptr %t54, i32 0, i32 2
  %t57 = load i64, ptr %t56, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  %t59 = load i1, ptr %l6, !tbaa !21
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l48, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = getelementptr %"compiler/jupyter:request", ptr %t64, i32 0, i32 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l50, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t70 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %v3, ptr %s2, { i64, ptr } %t68)
  store { i64, ptr } %t70, ptr %l52
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t72 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t74 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t82 = call i64 @__olang_fmt_i64(ptr null, i64 %t71)
  %t83 = add i64 %t80, %t82
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t72, i64 %t73)
  %t88 = getelementptr i8, ptr %t87, i64 %t73
  call void @olang_textcopy(ptr %t88, ptr %t75, i64 %t76)
  %t89 = getelementptr i8, ptr %t88, i64 %t76
  call void @olang_textcopy(ptr %t89, ptr %t78, i64 %t79)
  %t90 = getelementptr i8, ptr %t89, i64 %t79
  %t91 = call i64 @__olang_fmt_i64(ptr %t90, i64 %t71)
  %t92 = getelementptr i8, ptr %t90, i64 %t82
  call void @olang_textcopy(ptr %t92, ptr %t84, i64 %t85)
  %t93 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t87, 1
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l50, !tbaa !27
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2epublish(ptr %v0, ptr %s2, ptr %v2, ptr %s2, ptr %t96, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d120, i32 0, i32 1) }, { i64, ptr } %t97, { i64, ptr } %t94)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t99 = call %"compiler/jupyter:Capture" @compiler_2fjupyter_3aCapture_2ector(ptr %s0, i32 1)
  store %"compiler/jupyter:Capture" %t99, ptr %l56
  br label %bb20
bb20:
  %t100 = load %"compiler/jupyter:Capture", ptr %l56
  store %"compiler/jupyter:Capture" %t100, ptr %l8
  %t101 = call %"compiler/jupyter:Capture" @compiler_2fjupyter_3aCapture_2ector(ptr %s0, i32 2)
  store %"compiler/jupyter:Capture" %t101, ptr %l57
  br label %bb21
bb21:
  %t102 = load %"compiler/jupyter:Capture", ptr %l57
  store %"compiler/jupyter:Capture" %t102, ptr %l9
  store ptr %a1, ptr %l58, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t104, ptr %l59, !tbaa !27
  %t105 = load i1, ptr %l6, !tbaa !21
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb22, label %bb23
bb22:
  %t109 = load i64, ptr %l7, !tbaa !24
  %t110 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t111 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t113 = call i64 @__olang_fmt_i64(ptr null, i64 %t109)
  %t114 = add i64 %t111, %t113
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t110, i64 %t111)
  %t119 = getelementptr i8, ptr %t118, i64 %t111
  %t120 = call i64 @__olang_fmt_i64(ptr %t119, i64 %t109)
  %t121 = getelementptr i8, ptr %t119, i64 %t113
  call void @olang_textcopy(ptr %t121, ptr %t115, i64 %t116)
  %t122 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t118, 1
  store { i64, ptr } %t123, ptr %l62, !tbaa !27
  br label %bb24
bb23:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d123, i32 0, i32 1) }, ptr %l62, !tbaa !27
  br label %bb24
bb24:
  %t127 = load ptr, ptr %l58, !tbaa !29
  %t128 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l62, !tbaa !27
  call void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eCell(ptr %t126, ptr %v1, ptr %v3, ptr %s0, ptr %v1, ptr %v4, ptr %t127, { i64, ptr } %t128, { i64, ptr } %t129)
  call void @llvm.memmove.p0.p0.i64(ptr %l66, ptr %t126, i64 144, i1 false)
  br label %bb25
bb25:
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %l66, i64 144, i1 false)
  %t131 = call { i64, ptr } @compiler_2fjupyter_2ecompiler_2fjupyter_3aCapture_2eEnd(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t131, ptr %l68
  br label %bb26
bb26:
  %t132 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t132, ptr %l11, !tbaa !27
  %t134 = call { i64, ptr } @compiler_2fjupyter_2ecompiler_2fjupyter_3aCapture_2eEnd(ptr %s0, ptr %s0, ptr %l9)
  store { i64, ptr } %t134, ptr %l70
  br label %bb27
bb27:
  %t135 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t135, ptr %l12, !tbaa !27
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l3, !tbaa !29
  %t139 = getelementptr %"compiler/jupyter:request", ptr %t137, i32 0, i32 1
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2estream(ptr %v0, ptr %v2, ptr %s0, ptr %s0, ptr %t136, { i64, ptr } %t140, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d124, i32 0, i32 1) }, { i64, ptr } %t141)
  br label %bb28
bb28:
  %t145 = getelementptr %"compiler/prompt:Reply", ptr %l10, i32 0, i32 0
  %t146 = load i1, ptr %t145, !tbaa !21
  br i1 %t146, label %bb29, label %bb30
bb29:
  %t148 = getelementptr %"compiler/prompt:Reply", ptr %l10, i32 0, i32 1
  %t149 = load { i64, ptr }, ptr %t148, !tbaa !27
  store { i64, ptr } %t149, ptr %l76, !tbaa !27
  br label %bb31
bb30:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d125, i32 0, i32 1) }, ptr %l76, !tbaa !27
  br label %bb31
bb31:
  %t151 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l3, !tbaa !29
  %t155 = getelementptr %"compiler/jupyter:request", ptr %t153, i32 0, i32 1
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t159 = getelementptr %"compiler/prompt:Reply", ptr %l10, i32 0, i32 5
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t157, 1
  %t163 = extractvalue { i64, ptr } %t157, 0
  %t165 = extractvalue { i64, ptr } %t151, 1
  %t166 = extractvalue { i64, ptr } %t151, 0
  %t167 = add i64 %t163, %t166
  %t169 = extractvalue { i64, ptr } %t160, 1
  %t170 = extractvalue { i64, ptr } %t160, 0
  %t171 = add i64 %t167, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t162, i64 %t163)
  %t173 = getelementptr i8, ptr %t172, i64 %t163
  call void @olang_textcopy(ptr %t173, ptr %t165, i64 %t166)
  %t174 = getelementptr i8, ptr %t173, i64 %t166
  call void @olang_textcopy(ptr %t174, ptr %t169, i64 %t170)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2estream(ptr %v0, ptr %v2, ptr %s0, ptr %s0, ptr %t152, { i64, ptr } %t156, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d126, i32 0, i32 1) }, { i64, ptr } %t176)
  br label %bb32
bb32:
  %t181 = getelementptr %"compiler/prompt:Reply", ptr %l10, i32 0, i32 2
  %t182 = load i1, ptr %t181, !tbaa !21
  br i1 %t182, label %bb33, label %bb34
bb33:
  %t184 = load i1, ptr %l6, !tbaa !21
  %t186 = xor i1 %t184, true
  store i1 %t186, ptr %l87, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb35
bb35:
  %t188 = load i1, ptr %l87, !tbaa !21
  br i1 %t188, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l90, !tbaa !29
  %t190 = load ptr, ptr %l3, !tbaa !29
  %t192 = getelementptr %"compiler/jupyter:request", ptr %t190, i32 0, i32 1
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  store { i64, ptr } %t193, ptr %l92, !tbaa !27
  %t194 = load i64, ptr %l7, !tbaa !24
  store i64 %t194, ptr %l93, !tbaa !24
  %t196 = call { i64, ptr } @compiler_2fjupyter_2eData(ptr %v1, ptr %s6, ptr %l10)
  store { i64, ptr } %t196, ptr %l95
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t197 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t198 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t199 = load i64, ptr %l93, !tbaa !24
  %t200 = call i64 @__olang_fmt_i64(ptr null, i64 %t199)
  %t201 = add i64 %t198, %t200
  %t202 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t203 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t204 = add i64 %t201, %t203
  %t205 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 1
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = add i64 %t204, %t207
  %t209 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t210 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t211 = add i64 %t208, %t210
  %t212 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t211)
  call void @olang_textcopy(ptr %t212, ptr %t197, i64 %t198)
  %t213 = getelementptr i8, ptr %t212, i64 %t198
  %t214 = call i64 @__olang_fmt_i64(ptr %t213, i64 %t199)
  %t215 = getelementptr i8, ptr %t213, i64 %t200
  call void @olang_textcopy(ptr %t215, ptr %t202, i64 %t203)
  %t216 = getelementptr i8, ptr %t215, i64 %t203
  call void @olang_textcopy(ptr %t216, ptr %t206, i64 %t207)
  %t217 = getelementptr i8, ptr %t216, i64 %t207
  call void @olang_textcopy(ptr %t217, ptr %t209, i64 %t210)
  %t218 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t212, 1
  %t221 = load ptr, ptr %l90, !tbaa !29
  %t222 = load { i64, ptr }, ptr %l92, !tbaa !27
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2epublish(ptr %v0, ptr %s6, ptr %v2, ptr %s6, ptr %t221, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d130, i32 0, i32 1) }, { i64, ptr } %t222, { i64, ptr } %t219)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb40:
  %t224 = getelementptr %"compiler/prompt:Reply", ptr %l10, i32 0, i32 0
  %t225 = load i1, ptr %t224, !tbaa !21
  br i1 %t225, label %bb41, label %bb42
bb41:
  %t227 = getelementptr %"compiler/prompt:Reply", ptr %l10, i32 0, i32 4
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l99, !tbaa !27
  br label %bb43
bb42:
  %t230 = getelementptr %"compiler/prompt:Reply", ptr %l10, i32 0, i32 1
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  store { i64, ptr } %t231, ptr %l99, !tbaa !27
  br label %bb43
bb43:
  %t233 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t233, ptr %l14, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t236 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t234, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d131, i32 0, i32 1) })
  store i1 %t236, ptr %l103
  br label %bb44
bb44:
  %t237 = load i1, ptr %l103, !tbaa !21
  br i1 %t237, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i64, ptr %l2, !tbaa !24
  %t240 = load ptr, ptr %l3, !tbaa !29
  %t241 = load i64, ptr %l7, !tbaa !24
  %t242 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t243 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t245 = call i64 @__olang_fmt_i64(ptr null, i64 %t241)
  %t246 = add i64 %t243, %t245
  %t247 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t249 = add i64 %t246, %t248
  %t250 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t249)
  call void @olang_textcopy(ptr %t250, ptr %t242, i64 %t243)
  %t251 = getelementptr i8, ptr %t250, i64 %t243
  %t252 = call i64 @__olang_fmt_i64(ptr %t251, i64 %t241)
  %t253 = getelementptr i8, ptr %t251, i64 %t245
  call void @olang_textcopy(ptr %t253, ptr %t247, i64 %t248)
  %t254 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t250, 1
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ereply(ptr %v0, ptr %v2, ptr %s8, ptr %s8, ptr %t238, i64 %t239, ptr %t240, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d134, i32 0, i32 1) }, { i64, ptr } %t255)
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb48:
  %t261 = getelementptr %"compiler/prompt:Reply", ptr %l10, i32 0, i32 0
  %t262 = load i1, ptr %t261, !tbaa !21
  br i1 %t262, label %bb49, label %bb50
bb49:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d135, i32 0, i32 1) }, ptr %l111, !tbaa !27
  br label %bb51
bb50:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d136, i32 0, i32 1) }, ptr %l111, !tbaa !27
  br label %bb51
bb51:
  %t264 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t264, ptr %l15, !tbaa !27
  %t265 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265, ptr %l112
  br label %bb52
bb52:
  %t266 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %l16
  %t267 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t269 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v1, ptr %v1, { i64, ptr } %t267)
  store { i64, ptr } %t269, ptr %l114
  br label %bb53
bb53:
  %t270 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t271 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t270)
  store %"std/prelude/text:LineIter" %t271, ptr %l115
  br label %bb54
bb54:
  %t272 = load %"std/prelude/text:LineIter", ptr %l115
  store %"std/prelude/text:LineIter" %t272, ptr %l17
  br label %bb55
bb55:
  %t274 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l17)
  %t275 = extractvalue { i32, { i64, ptr } } %t274, 1
  %t276 = extractvalue { i32, { i64, ptr } } %t274, 0
  store i32 %t276, ptr %l119
  %t277 = icmp ne i32 %t276, 0
  br i1 %t277, label %bb57, label %ok.278, !prof !99
ok.278:
  store { i64, ptr } %t275, ptr %l118
  br label %bb56
bb56:
  %t279 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t279, ptr %l116, !tbaa !27
  br label %bb59
bb57:
  %t280 = load i32, ptr %l119, !tbaa !23
  %t281 = ashr i32 %t280, 16
  %t283 = icmp eq i32 %t281, 1
  store i1 %t283, ptr %l121, !tbaa !21
  br label %bb58
bb58:
  br label %bb65
bb59:
  %t284 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t284, ptr %l18, !tbaa !27
  store ptr %l16, ptr %l122, !tbaa !29
  %t285 = call ptr @__olang_scope_hold(ptr %s0)
  %t286 = ptrtoint ptr %t285 to i64
  store i64 %t286, ptr %l123, !tbaa !24
  %t287 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t287, label %bb60, label %bb61
bb60:
  %t289 = call ptr @__olang_region_make(ptr %s0)
  %t290 = ptrtoint ptr %t289 to i64
  store i64 %t290, ptr %l123, !tbaa !24
  br label %bb61
bb61:
  %t291 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t292 = load i64, ptr %l123
  %t293 = inttoptr i64 %t292 to ptr
  %t295 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %v1, ptr %t293, { i64, ptr } %t291)
  store { i64, ptr } %t295, ptr %l126
  br label %bb62
bb62:
  %t296 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t297 = load ptr, ptr %l122, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t297, { i64, ptr } %t296)
  br label %bb63
bb63:
  br label %bb64
bb64:
  br label %bb55
bb65:
  %t299 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t299, ptr %l128, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t302 = call { i64, ptr } @compiler_2fjupyter_2eFirstLine(ptr %v1, ptr %s0, { i64, ptr } %t300)
  store { i64, ptr } %t302, ptr %l130
  br label %bb66
bb66:
  %t303 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t305 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %s0, ptr %s0, { i64, ptr } %t303)
  store { i64, ptr } %t305, ptr %l132
  br label %bb67
bb67:
  %t307 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l16, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) })
  store { i64, ptr } %t307, ptr %l134
  br label %bb68
bb68:
  %t308 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t309 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t310 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 1
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t313 = add i64 %t309, %t312
  %t314 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t315 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t316 = add i64 %t313, %t315
  %t317 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 1
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t320 = add i64 %t316, %t319
  %t321 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t322 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t323 = add i64 %t320, %t322
  %t324 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t324, 1
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t327 = add i64 %t323, %t326
  %t328 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t329 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t330 = add i64 %t327, %t329
  %t331 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t330)
  call void @olang_textcopy(ptr %t331, ptr %t308, i64 %t309)
  %t332 = getelementptr i8, ptr %t331, i64 %t309
  call void @olang_textcopy(ptr %t332, ptr %t311, i64 %t312)
  %t333 = getelementptr i8, ptr %t332, i64 %t312
  call void @olang_textcopy(ptr %t333, ptr %t314, i64 %t315)
  %t334 = getelementptr i8, ptr %t333, i64 %t315
  call void @olang_textcopy(ptr %t334, ptr %t318, i64 %t319)
  %t335 = getelementptr i8, ptr %t334, i64 %t319
  call void @olang_textcopy(ptr %t335, ptr %t321, i64 %t322)
  %t336 = getelementptr i8, ptr %t335, i64 %t322
  call void @olang_textcopy(ptr %t336, ptr %t325, i64 %t326)
  %t337 = getelementptr i8, ptr %t336, i64 %t326
  call void @olang_textcopy(ptr %t337, ptr %t328, i64 %t329)
  %t338 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t331, 1
  store { i64, ptr } %t339, ptr %l19, !tbaa !27
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load ptr, ptr %l3, !tbaa !29
  %t344 = getelementptr %"compiler/jupyter:request", ptr %t342, i32 0, i32 1
  %t345 = load { i64, ptr }, ptr %t344, !tbaa !27
  %t346 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t347 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t350 = extractvalue { i64, ptr } %t346, 1
  %t351 = extractvalue { i64, ptr } %t346, 0
  %t352 = add i64 %t348, %t351
  %t353 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t354 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t355 = add i64 %t352, %t354
  %t356 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t355)
  call void @olang_textcopy(ptr %t356, ptr %t347, i64 %t348)
  %t357 = getelementptr i8, ptr %t356, i64 %t348
  call void @olang_textcopy(ptr %t357, ptr %t350, i64 %t351)
  %t358 = getelementptr i8, ptr %t357, i64 %t351
  call void @olang_textcopy(ptr %t358, ptr %t353, i64 %t354)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t356, 1
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2epublish(ptr %v0, ptr %s0, ptr %v2, ptr %s0, ptr %t341, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d144, i32 0, i32 1) }, { i64, ptr } %t345, { i64, ptr } %t360)
  br label %bb69
bb69:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load i64, ptr %l2, !tbaa !24
  %t367 = load ptr, ptr %l3, !tbaa !29
  %t368 = load i64, ptr %l7, !tbaa !24
  %t369 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t370 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t371 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t373 = call i64 @__olang_fmt_i64(ptr null, i64 %t368)
  %t374 = add i64 %t371, %t373
  %t375 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t376 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t377 = add i64 %t374, %t376
  %t379 = extractvalue { i64, ptr } %t369, 1
  %t380 = extractvalue { i64, ptr } %t369, 0
  %t381 = add i64 %t377, %t380
  %t382 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t384 = add i64 %t381, %t383
  %t385 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t384)
  call void @olang_textcopy(ptr %t385, ptr %t370, i64 %t371)
  %t386 = getelementptr i8, ptr %t385, i64 %t371
  %t387 = call i64 @__olang_fmt_i64(ptr %t386, i64 %t368)
  %t388 = getelementptr i8, ptr %t386, i64 %t373
  call void @olang_textcopy(ptr %t388, ptr %t375, i64 %t376)
  %t389 = getelementptr i8, ptr %t388, i64 %t376
  call void @olang_textcopy(ptr %t389, ptr %t379, i64 %t380)
  %t390 = getelementptr i8, ptr %t389, i64 %t380
  call void @olang_textcopy(ptr %t390, ptr %t382, i64 %t383)
  %t391 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t392 = insertvalue { i64, ptr } %t391, ptr %t385, 1
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ereply(ptr %v0, ptr %v2, ptr %s0, ptr %s0, ptr %t365, i64 %t366, ptr %t367, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d148, i32 0, i32 1) }, { i64, ptr } %t392)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ehandle(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i32
  %l47 = alloca i1
  %l56 = alloca i1
  %l60 = alloca %"compiler/jupyter:request"
  %l63 = alloca %"compiler/jupyter:request"
  %l64 = alloca i32
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i32
  %l74 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l89 = alloca i1
  %l96 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i64
  %l99 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i64
  %l108 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l114 = alloca i1
  %l119 = alloca i1
  %l124 = alloca i1
  %l129 = alloca i1
  %l134 = alloca i1
  %l135 = alloca i1
  %l137 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l140 = alloca i32
  %l142 = alloca i1
  %l145 = alloca i1
  %l146 = alloca i32
  %l148 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %t142 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/jupyter:kernel", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l17
  br label %bb1
bb1:
  %t8 = load i64, ptr %l17, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2fjupyter_2eHeartbeat, !tbaa !24
  %t13 = icmp eq i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l21
  br label %bb4
bb3:
  br label %bb21
bb4:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l5
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l8, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t31 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t31, ptr %l29, !tbaa !27
  %t32 = load i64, ptr %l7, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %t35, i64 %t32
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !37
  store { i64, ptr } %t37, ptr %l31, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l32, !tbaa !24
  %t40 = load i64, ptr %l32, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l33, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l32, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s1, ptr %s1, ptr %l5, { i64, ptr } %t51)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = add i64 %t55, 1
  store i64 %t58, ptr %l7, !tbaa !24
  br label %bb5
bb11:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/jupyter:kernel", ptr %t60, i32 0, i32 4
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eRefMut_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %v0, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l42
  br label %bb12
bb12:
  %t68 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s1, ptr %s1, ptr %l5)
  store { i64, ptr } %t68, ptr %l44
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l42, !tbaa !29
  %t70 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t71 = call i32 @std_2fzmtp_2estd_2fzmtp_3aSocket_2eSend(ptr %v0, ptr %s1, ptr %t69, { i64, ptr } %t70)
  store i32 %t71, ptr %l45
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb15, label %ok.73, !prof !99
ok.73:
  br label %bb14
bb14:
  br label %bb20
bb15:
  %t74 = load i32, ptr %l45, !tbaa !23
  %t75 = ashr i32 %t74, 16
  %t77 = icmp eq i32 %t75, 1
  store i1 %t77, ptr %l47, !tbaa !21
  %t78 = load i32, ptr %l45, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  br i1 %t81, label %bb16, label %bb17
bb16:
  call void @__olang_errpay_pop()
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/jupyter:kernel", ptr %t83, i32 0, i32 5
  %t86 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t85, i64 %t86, i64 -1)
  br label %bb19
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb21:
  %t89 = load i64, ptr %l4, !tbaa !24
  %t90 = load i64, ptr @G_2ecompiler_2fjupyter_2eShell, !tbaa !24
  %t93 = icmp ne i64 %t89, %t90
  br i1 %t93, label %bb22, label %bb23
bb22:
  %t95 = load i64, ptr %l4, !tbaa !24
  %t96 = load i64, ptr @G_2ecompiler_2fjupyter_2eControl, !tbaa !24
  %t99 = icmp ne i64 %t95, %t96
  store i1 %t99, ptr %l56, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb24
bb24:
  %t101 = load i1, ptr %l56, !tbaa !21
  br i1 %t101, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t106 = call { i32, %"compiler/jupyter:request" } @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2eread(ptr %v0, ptr %v2, ptr %v1, ptr %t102, { i64, ptr } %t103)
  %t107 = extractvalue { i32, %"compiler/jupyter:request" } %t106, 1
  %t108 = extractvalue { i32, %"compiler/jupyter:request" } %t106, 0
  store i32 %t108, ptr %l64
  %t109 = icmp ne i32 %t108, 0
  br i1 %t109, label %bb29, label %ok.110, !prof !99
ok.110:
  store %"compiler/jupyter:request" %t107, ptr %l63
  br label %bb28
bb28:
  %t111 = load %"compiler/jupyter:request", ptr %l63
  store %"compiler/jupyter:request" %t111, ptr %l60
  br label %bb31
bb29:
  %t112 = load i32, ptr %l64, !tbaa !23
  %t113 = ashr i32 %t112, 16
  %t115 = icmp eq i32 %t113, 1
  store i1 %t115, ptr %l66, !tbaa !21
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  %t116 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store ptr %t116, ptr %lp10
  %t117 = load %"compiler/jupyter:request", ptr %l60
  %t118 = load ptr, ptr %lp10
  store %"compiler/jupyter:request" %t117, ptr %t118
  %t119 = load ptr, ptr %lp10
  %t121 = call { i64, ptr } @compiler_2fjupyter_2ekindOf(ptr %v1, ptr %s0, ptr %t119)
  store { i64, ptr } %t121, ptr %l68
  br label %bb32
bb32:
  %t122 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t122, ptr %l11, !tbaa !27
  %t123 = load ptr, ptr %lp10
  %t124 = getelementptr %"compiler/jupyter:request", ptr %t123, i32 0, i32 2
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t127 = call { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v1, ptr %v1, { i64, ptr } %t125)
  %t128 = extractvalue { i32, ptr } %t127, 1
  %t129 = extractvalue { i32, ptr } %t127, 0
  store i32 %t129, ptr %l72
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb34, label %ok.131, !prof !99
ok.131:
  store ptr %t128, ptr %l71
  br label %bb33
bb33:
  %t132 = load ptr, ptr %l71, !tbaa !29
  store ptr %t132, ptr %l69, !tbaa !29
  br label %bb38
bb34:
  %t133 = load i32, ptr %l72, !tbaa !23
  %t134 = ashr i32 %t133, 16
  %t136 = icmp eq i32 %t134, 1
  store i1 %t136, ptr %l74, !tbaa !21
  %t137 = load i32, ptr %l72, !tbaa !23
  %t138 = ashr i32 %t137, 16
  %t140 = icmp eq i32 %t138, 1
  br i1 %t140, label %bb35, label %bb36
bb35:
  call void @__olang_errpay_pop()
  br label %bb36
bb36:
  br label %bb37
bb37:
  store { i64, [2 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [2 x i64] }, ptr %t142, i32 0, i32 0
  store i64 0, ptr %t143
  %t144 = load { i64, [2 x i64] }, ptr %t142
  %t146 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t144, ptr %t146
  store ptr %t146, ptr %l69, !tbaa !29
  br label %bb38
bb38:
  %t148 = load ptr, ptr %l69, !tbaa !29
  store ptr %t148, ptr %l12, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %lp10
  %t151 = getelementptr %"compiler/jupyter:request", ptr %t150, i32 0, i32 1
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2epublish(ptr %v0, ptr %s0, ptr %v1, ptr %s0, ptr %t149, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d149, i32 0, i32 1) }, { i64, ptr } %t152, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d150, i32 0, i32 1) })
  br label %bb39
bb39:
  %t155 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t157 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t155, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d151, i32 0, i32 1) })
  store i1 %t157, ptr %l82
  br label %bb40
bb40:
  %t158 = load i1, ptr %l82, !tbaa !21
  br i1 %t158, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb46
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l83, !tbaa !29
  %t160 = load i64, ptr %l2, !tbaa !24
  store i64 %t160, ptr %l84, !tbaa !24
  %t161 = load ptr, ptr %lp10
  store ptr %t161, ptr %l85, !tbaa !29
  %t162 = call { i64, ptr } @compiler_2fjupyter_2ekernelInfo(ptr %s8)
  store { i64, ptr } %t162, ptr %l86
  br label %bb44
bb44:
  %t163 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t164 = load ptr, ptr %l83, !tbaa !29
  %t165 = load i64, ptr %l84, !tbaa !24
  %t166 = load ptr, ptr %l85, !tbaa !29
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ereply(ptr %v0, ptr %v1, ptr %s8, ptr %s8, ptr %t164, i64 %t165, ptr %t166, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d152, i32 0, i32 1) }, { i64, ptr } %t163)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb112
bb46:
  %t168 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t170 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t168, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d153, i32 0, i32 1) })
  store i1 %t170, ptr %l89
  br label %bb47
bb47:
  %t171 = load i1, ptr %l89, !tbaa !21
  br i1 %t171, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t174 = load i64, ptr %l2, !tbaa !24
  %t175 = load ptr, ptr %lp10
  %t176 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2eexecute(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v3, ptr %t172, ptr %t173, i64 %t174, ptr %t175, ptr %t176)
  br label %bb51
bb51:
  br label %bb112
bb52:
  %t182 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t184 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t182, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d154, i32 0, i32 1) })
  store i1 %t184, ptr %l96
  br label %bb53
bb53:
  %t185 = load i1, ptr %l96, !tbaa !21
  br i1 %t185, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb60
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l97, !tbaa !29
  %t187 = load i64, ptr %l2, !tbaa !24
  store i64 %t187, ptr %l98, !tbaa !24
  %t188 = load ptr, ptr %lp10
  store ptr %t188, ptr %l99, !tbaa !29
  %t189 = load ptr, ptr %l12, !tbaa !29
  %t191 = call { i64, ptr } @compiler_2fjupyter_2estr(ptr %v1, ptr %s10, ptr %v1, ptr %t189, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d155, i32 0, i32 1) })
  store { i64, ptr } %t191, ptr %l101
  br label %bb57
bb57:
  %t192 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t193 = call { i64, ptr } @compiler_2fjupyter_2eisComplete(ptr %v1, ptr %s10, { i64, ptr } %t192)
  store { i64, ptr } %t193, ptr %l102
  br label %bb58
bb58:
  %t194 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t195 = load ptr, ptr %l97, !tbaa !29
  %t196 = load i64, ptr %l98, !tbaa !24
  %t197 = load ptr, ptr %l99, !tbaa !29
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ereply(ptr %v0, ptr %v1, ptr %s10, ptr %s10, ptr %t195, i64 %t196, ptr %t197, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d156, i32 0, i32 1) }, { i64, ptr } %t194)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb112
bb60:
  %t199 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t201 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t199, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d157, i32 0, i32 1) })
  store i1 %t201, ptr %l105
  br label %bb61
bb61:
  %t202 = load i1, ptr %l105, !tbaa !21
  br i1 %t202, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb67
bb64:
  store %olang.scope zeroinitializer, ptr %s11
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l106, !tbaa !29
  %t204 = load i64, ptr %l2, !tbaa !24
  store i64 %t204, ptr %l107, !tbaa !24
  %t205 = load ptr, ptr %lp10
  store ptr %t205, ptr %l108, !tbaa !29
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t207 = load ptr, ptr %l12, !tbaa !29
  %t210 = call { i64, ptr } @compiler_2fjupyter_2ecomplete(ptr %v1, ptr %v1, ptr %s11, ptr %t206, ptr %t207)
  store { i64, ptr } %t210, ptr %l111
  br label %bb65
bb65:
  %t211 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t212 = load ptr, ptr %l106, !tbaa !29
  %t213 = load i64, ptr %l107, !tbaa !24
  %t214 = load ptr, ptr %l108, !tbaa !29
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ereply(ptr %v0, ptr %v1, ptr %s11, ptr %s11, ptr %t212, i64 %t213, ptr %t214, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d158, i32 0, i32 1) }, { i64, ptr } %t211)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s11)
  br label %bb112
bb67:
  %t216 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t218 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t216, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d159, i32 0, i32 1) })
  store i1 %t218, ptr %l114
  br label %bb68
bb68:
  %t219 = load i1, ptr %l114, !tbaa !21
  br i1 %t219, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb73
bb71:
  store %olang.scope zeroinitializer, ptr %s12
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i64, ptr %l2, !tbaa !24
  %t222 = load ptr, ptr %lp10
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ereply(ptr %v0, ptr %v1, ptr %s12, ptr %s12, ptr %t220, i64 %t221, ptr %t222, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d160, i32 0, i32 1) }, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d161, i32 0, i32 1) })
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s12)
  br label %bb112
bb73:
  %t226 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t228 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t226, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d162, i32 0, i32 1) })
  store i1 %t228, ptr %l119
  br label %bb74
bb74:
  %t229 = load i1, ptr %l119, !tbaa !21
  br i1 %t229, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb79
bb77:
  store %olang.scope zeroinitializer, ptr %s13
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l2, !tbaa !24
  %t232 = load ptr, ptr %lp10
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ereply(ptr %v0, ptr %v1, ptr %s13, ptr %s13, ptr %t230, i64 %t231, ptr %t232, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d163, i32 0, i32 1) }, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d164, i32 0, i32 1) })
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  br label %bb112
bb79:
  %t236 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t238 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t236, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d165, i32 0, i32 1) })
  store i1 %t238, ptr %l124
  br label %bb80
bb80:
  %t239 = load i1, ptr %l124, !tbaa !21
  br i1 %t239, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb85
bb83:
  store %olang.scope zeroinitializer, ptr %s14
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i64, ptr %l2, !tbaa !24
  %t242 = load ptr, ptr %lp10
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ereply(ptr %v0, ptr %v1, ptr %s14, ptr %s14, ptr %t240, i64 %t241, ptr %t242, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d166, i32 0, i32 1) }, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d167, i32 0, i32 1) })
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s14)
  br label %bb112
bb85:
  %t246 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t248 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t246, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d168, i32 0, i32 1) })
  store i1 %t248, ptr %l129
  br label %bb86
bb86:
  %t249 = load i1, ptr %l129, !tbaa !21
  br i1 %t249, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb91
bb89:
  store %olang.scope zeroinitializer, ptr %s15
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i64, ptr %l2, !tbaa !24
  %t252 = load ptr, ptr %lp10
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ereply(ptr %v0, ptr %v1, ptr %s15, ptr %s15, ptr %t250, i64 %t251, ptr %t252, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d169, i32 0, i32 1) }, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d170, i32 0, i32 1) })
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s15)
  br label %bb112
bb91:
  %t256 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t258 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t256, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d171, i32 0, i32 1) })
  store i1 %t258, ptr %l134
  br label %bb92
bb92:
  %t259 = load i1, ptr %l134, !tbaa !21
  br i1 %t259, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb107
bb95:
  store %olang.scope zeroinitializer, ptr %s16
  %t260 = load ptr, ptr %l12, !tbaa !29
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d172, i32 0, i32 1) }, ptr %l137, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t264 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t260, { i64, ptr } %t261)
  %t265 = extractvalue { i32, ptr } %t264, 1
  %t266 = extractvalue { i32, ptr } %t264, 0
  store i32 %t266, ptr %l140
  %t267 = icmp ne i32 %t266, 0
  br i1 %t267, label %bb97, label %ok.268, !prof !99
ok.268:
  store ptr %t265, ptr %l139
  br label %bb96
bb96:
  %t269 = load ptr, ptr %l139, !tbaa !29
  %t270 = call { i32, i1 } @std_2fjson_2estd_2fjson_3aJson_2eAsBool(ptr %v1, ptr %t269)
  %t271 = extractvalue { i32, i1 } %t270, 1
  %t272 = extractvalue { i32, i1 } %t270, 0
  store i32 %t272, ptr %l146
  %t273 = icmp ne i32 %t272, 0
  br i1 %t273, label %bb102, label %ok.274, !prof !99
ok.274:
  store i1 %t271, ptr %l145
  br label %bb101
bb97:
  %t275 = load i32, ptr %l140, !tbaa !23
  %t276 = ashr i32 %t275, 16
  %t278 = icmp eq i32 %t276, 1
  store i1 %t278, ptr %l142, !tbaa !21
  %t279 = load i32, ptr %l140, !tbaa !23
  %t280 = ashr i32 %t279, 16
  %t282 = icmp eq i32 %t280, 1
  br i1 %t282, label %bb98, label %bb99
bb98:
  call void @__olang_errpay_pop()
  br label %bb99
bb99:
  br label %bb100
bb100:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb105
bb101:
  %t284 = load i1, ptr %l145, !tbaa !21
  store i1 %t284, ptr %l135, !tbaa !21
  br label %bb105
bb102:
  %t285 = load i32, ptr %l146, !tbaa !23
  %t286 = ashr i32 %t285, 16
  %t288 = icmp eq i32 %t286, 1
  store i1 %t288, ptr %l148, !tbaa !21
  %t289 = load i32, ptr %l146, !tbaa !23
  %t290 = ashr i32 %t289, 16
  %t292 = icmp eq i32 %t290, 1
  br i1 %t292, label %bb103, label %bb104
bb103:
  call void @__olang_errpay_pop()
  br label %bb104
bb104:
  br label %bb100
bb105:
  %t294 = load i1, ptr %l135, !tbaa !21
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load i64, ptr %l2, !tbaa !24
  %t297 = load ptr, ptr %lp10
  %t299 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t300 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t302 = select i1 %t294, ptr @.c174, ptr @.c175
  %t303 = select i1 %t294, i64 4, i64 5
  %t304 = add i64 %t300, %t303
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t307 = add i64 %t304, %t306
  %t308 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t307)
  call void @olang_textcopy(ptr %t308, ptr %t299, i64 %t300)
  %t309 = getelementptr i8, ptr %t308, i64 %t300
  call void @olang_textcopy(ptr %t309, ptr %t302, i64 %t303)
  %t310 = getelementptr i8, ptr %t309, i64 %t303
  call void @olang_textcopy(ptr %t310, ptr %t305, i64 %t306)
  %t311 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t308, 1
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ereply(ptr %v0, ptr %v1, ptr %s16, ptr %s16, ptr %t295, i64 %t296, ptr %t297, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d177, i32 0, i32 1) }, { i64, ptr } %t312)
  br label %bb106
bb106:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/jupyter:kernel", ptr %t318, i32 0, i32 6
  store i1 true, ptr %t320, !tbaa !21
  call void @__olang_scope_close(ptr %s16)
  br label %bb112
bb107:
  br i1 true, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_62bbb1ef982cce0d_1ddca4bbad92f791)
  unreachable
bb112:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %lp10
  %t323 = getelementptr %"compiler/jupyter:request", ptr %t322, i32 0, i32 1
  %t324 = load { i64, ptr }, ptr %t323, !tbaa !27
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2epublish(ptr %v0, ptr %s0, ptr %v1, ptr %s0, ptr %t321, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d178, i32 0, i32 1) }, { i64, ptr } %t324, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d179, i32 0, i32 1) })
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2eheader(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca ptr
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/jupyter:kernel", ptr %t2, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = add i64 %t4, 1
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = getelementptr %"compiler/jupyter:kernel", ptr %t9, i32 0, i32 3
  store i64 %t7, ptr %t10, !tbaa !24
  %t11 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t12, ptr %l2
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/jupyter:kernel", ptr %t13, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/jupyter:kernel", ptr %t17, i32 0, i32 3
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/jupyter:kernel", ptr %t21, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t25 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t28 = extractvalue { i64, ptr } %t16, 1
  %t29 = extractvalue { i64, ptr } %t16, 0
  %t30 = add i64 %t26, %t29
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t35 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t36 = add i64 %t33, %t35
  %t37 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t41 = extractvalue { i64, ptr } %t24, 1
  %t42 = extractvalue { i64, ptr } %t24, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t25, i64 %t26)
  %t48 = getelementptr i8, ptr %t47, i64 %t26
  call void @olang_textcopy(ptr %t48, ptr %t28, i64 %t29)
  %t49 = getelementptr i8, ptr %t48, i64 %t29
  call void @olang_textcopy(ptr %t49, ptr %t31, i64 %t32)
  %t50 = getelementptr i8, ptr %t49, i64 %t32
  %t51 = call i64 @__olang_fmt_i64(ptr %t50, i64 %t20)
  %t52 = getelementptr i8, ptr %t50, i64 %t35
  call void @olang_textcopy(ptr %t52, ptr %t37, i64 %t38)
  %t53 = getelementptr i8, ptr %t52, i64 %t38
  call void @olang_textcopy(ptr %t53, ptr %t41, i64 %t42)
  %t54 = getelementptr i8, ptr %t53, i64 %t42
  call void @olang_textcopy(ptr %t54, ptr %t44, i64 %t45)
  %t55 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t47, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t56)
  br label %bb2
bb2:
  store ptr %l2, ptr %l17, !tbaa !29
  %t60 = call { i64, ptr } @compiler_2fjupyter_2eisoNow(ptr %s0)
  store { i64, ptr } %t60, ptr %l18
  br label %bb3
bb3:
  %t62 = load { i64, ptr }, ptr @G_2ecompiler_2fjupyter_2eProtocol, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t70 = extractvalue { i64, ptr } %a1, 1
  %t71 = extractvalue { i64, ptr } %a1, 0
  %t72 = add i64 %t68, %t71
  %t73 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t75 = add i64 %t72, %t74
  %t77 = extractvalue { i64, ptr } %t62, 1
  %t78 = extractvalue { i64, ptr } %t62, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t64, i64 %t65)
  %t84 = getelementptr i8, ptr %t83, i64 %t65
  call void @olang_textcopy(ptr %t84, ptr %t66, i64 %t67)
  %t85 = getelementptr i8, ptr %t84, i64 %t67
  call void @olang_textcopy(ptr %t85, ptr %t70, i64 %t71)
  %t86 = getelementptr i8, ptr %t85, i64 %t71
  call void @olang_textcopy(ptr %t86, ptr %t73, i64 %t74)
  %t87 = getelementptr i8, ptr %t86, i64 %t74
  call void @olang_textcopy(ptr %t87, ptr %t77, i64 %t78)
  %t88 = getelementptr i8, ptr %t87, i64 %t78
  call void @olang_textcopy(ptr %t88, ptr %t80, i64 %t81)
  %t89 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t83, 1
  %t92 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t92, { i64, ptr } %t90)
  br label %bb4
bb4:
  %t95 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t95, ptr %l24
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t96 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2einterrupted(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"compiler/jupyter:request"
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca i64
  %l53 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca i32
  %l69 = alloca i1
  %l75 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l81 = alloca i32
  %l85 = alloca i1
  %l87 = alloca ptr
  %l90 = alloca %"compiler/jupyter:pending"
  %l92 = alloca %"compiler/jupyter:pending"
  %l99 = alloca i64
  %l103 = alloca i64
  %l106 = alloca i64
  %l124 = alloca %"compiler/jupyter:request"
  %l125 = alloca ptr
  %l129 = alloca ptr
  %l132 = alloca %"compiler/jupyter:request"
  %l133 = alloca i32
  %l135 = alloca i1
  %l137 = alloca { i64, ptr }
  %l139 = alloca i1
  %l140 = alloca i1
  %l142 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/jupyter:kernel", ptr %t1, i32 0, i32 7
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fjupyter_3apending_3e_2eLen__H3ed9013f6604c7fc0e46a0318571cb25(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/jupyter:kernel", ptr %t7, i32 0, i32 4
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eLen_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l22
  br label %bb2
bb2:
  %t12 = load i64, ptr %l22, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l29, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l29, !tbaa !24
  store i64 %t39, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l26, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/jupyter:kernel", ptr %t59, i32 0, i32 5
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l50
  br label %bb13
bb13:
  %t66 = load i64, ptr @G_2ecompiler_2fjupyter_2eControl, !tbaa !24
  %t67 = load i64, ptr %l50, !tbaa !24
  %t69 = icmp ne i64 %t67, %t66
  br i1 %t69, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb19
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/jupyter:kernel", ptr %t71, i32 0, i32 4
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eRef_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  store ptr %t77, ptr %l57
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l57, !tbaa !29
  %t79 = call i32 @std_2fzmtp_2estd_2fzmtp_3aSocket_2eFd(ptr %v0, ptr %t78)
  store i32 %t79, ptr %l58
  br label %bb17
bb17:
  %t80 = mul i64 1, 4
  %t81 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 1, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  store { i64, ptr } %t83, ptr %l59, !tbaa !27
  %t84 = load i32, ptr %l58, !tbaa !23
  %t85 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i32, ptr %t86, i64 0
  store i32 %t84, ptr %t87, !tbaa !33
  %t88 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t89 = call { i64, ptr } @std_2fnet_2eReadable(ptr %s2, ptr %s2, { i64, ptr } %t88, i64 0)
  store { i64, ptr } %t89, ptr %l60
  br label %bb18
bb18:
  %t90 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i1, ptr %t91, i64 0
  %t93 = load i1, ptr %t92, !tbaa !31
  %t95 = xor i1 %t93, true
  store i1 %t95, ptr %l53, !tbaa !21
  br label %bb19
bb19:
  %t97 = load i1, ptr %l53, !tbaa !21
  br i1 %t97, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb21:
  br label %bb22
bb22:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/jupyter:kernel", ptr %t98, i32 0, i32 4
  %t101 = load i64, ptr %l7, !tbaa !24
  %t104 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eRefMut_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %v0, ptr %t100, i64 %t101)
  store ptr %t104, ptr %l66
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l66, !tbaa !29
  %t106 = call i32 @std_2fzmtp_2estd_2fzmtp_3aSocket_2eFill(ptr %v0, ptr %t105)
  store i32 %t106, ptr %l67
  %t107 = icmp ne i32 %t106, 0
  br i1 %t107, label %bb25, label %ok.108, !prof !99
ok.108:
  br label %bb24
bb24:
  br label %bb30
bb25:
  %t109 = load i32, ptr %l67, !tbaa !23
  %t110 = ashr i32 %t109, 16
  %t112 = icmp eq i32 %t110, 1
  store i1 %t112, ptr %l69, !tbaa !21
  %t113 = load i32, ptr %l67, !tbaa !23
  %t114 = ashr i32 %t113, 16
  %t116 = icmp eq i32 %t114, 1
  br i1 %t116, label %bb26, label %bb27
bb26:
  call void @__olang_errpay_pop()
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/jupyter:kernel", ptr %t118, i32 0, i32 5
  %t121 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t120, i64 %t121, i64 -1)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb30:
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/jupyter:kernel", ptr %t124, i32 0, i32 4
  %t127 = load i64, ptr %l7, !tbaa !24
  %t130 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eRefMut_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %v0, ptr %t126, i64 %t127)
  store ptr %t130, ptr %l79
  br label %bb32
bb32:
  %t131 = load ptr, ptr %l79, !tbaa !29
  %t132 = call { i32, { i64, ptr } } @std_2fzmtp_2estd_2fzmtp_3aSocket_2eNext(ptr %v0, ptr %s5, ptr %t131)
  %t133 = extractvalue { i32, { i64, ptr } } %t132, 1
  %t134 = extractvalue { i32, { i64, ptr } } %t132, 0
  store i32 %t134, ptr %l81
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb34, label %ok.136, !prof !99
ok.136:
  store { i64, ptr } %t133, ptr %l80
  br label %bb33
bb33:
  %t137 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t137, ptr %l75, !tbaa !27
  br label %bb39
bb34:
  %t138 = load i32, ptr %l81, !tbaa !23
  %t139 = ashr i32 %t138, 16
  %t141 = icmp eq i32 %t139, 1
  br i1 %t141, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  %t143 = load i32, ptr %l81, !tbaa !23
  %t144 = ashr i32 %t143, 16
  %t146 = icmp eq i32 %t144, 2
  store i1 %t146, ptr %l85, !tbaa !21
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb39:
  %t147 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/jupyter:kernel", ptr %t148, i32 0, i32 7
  store ptr %t150, ptr %l87, !tbaa !29
  %t151 = load i64, ptr %l7, !tbaa !24
  %t155 = call %"compiler/jupyter:pending" @compiler_2fjupyter_3apending_2ector(ptr %s5, ptr %s5, i64 %t151, { i64, ptr } %t147)
  store %"compiler/jupyter:pending" %t155, ptr %l90
  br label %bb40
bb40:
  %t157 = call %"compiler/jupyter:pending" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fjupyter_3apending(ptr %s5, ptr %l90)
  store %"compiler/jupyter:pending" %t157, ptr %l92
  br label %bb41
bb41:
  %t158 = load ptr, ptr %l87, !tbaa !29
  %t159 = load %"compiler/jupyter:pending", ptr %l92
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fjupyter_3apending_3e_2ePush_H6843df326b132ec5af167b6d6aa0ee91(ptr %v0, ptr %s5, ptr %t158, %"compiler/jupyter:pending" %t159)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb43:
  br label %bb31
bb44:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb45:
  %t160 = load i64, ptr %l6, !tbaa !24
  %t163 = add i64 %t160, 1
  store i64 %t163, ptr %l6, !tbaa !24
  br label %bb9
bb46:
  %t165 = load i64, ptr %l1, !tbaa !24
  store i64 %t165, ptr %l9, !tbaa !24
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/jupyter:kernel", ptr %t167, i32 0, i32 7
  %t171 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fjupyter_3apending_3e_2eLen__H3ed9013f6604c7fc0e46a0318571cb25(ptr %v0, ptr %t169)
  store i64 %t171, ptr %l99
  br label %bb47
bb47:
  %t172 = load i64, ptr %l99, !tbaa !24
  store i64 %t172, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t173 = load i64, ptr %l10, !tbaa !24
  %t174 = load i64, ptr %l9, !tbaa !24
  %t177 = icmp sgt i64 %t173, %t174
  br i1 %t177, label %bb48, label %bb49
bb48:
  %t179 = load i64, ptr %l11, !tbaa !24
  %t181 = icmp sgt i64 %t179, 0
  br i1 %t181, label %bb50, label %bb51
bb49:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb53
bb50:
  %t183 = load i64, ptr %l10, !tbaa !24
  %t184 = load i64, ptr %l9, !tbaa !24
  %t187 = sub i64 %t183, %t184
  %t188 = load i64, ptr %l11, !tbaa !24
  %t191 = add i64 %t187, %t188
  %t193 = sub i64 %t191, 1
  %t194 = load i64, ptr %l11, !tbaa !24
  %t197 = sdiv i64 %t193, %t194
  store i64 %t197, ptr %l106, !tbaa !24
  br label %bb52
bb51:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb52
bb52:
  %t199 = load i64, ptr %l106, !tbaa !24
  store i64 %t199, ptr %l103, !tbaa !24
  br label %bb53
bb53:
  %t200 = load i64, ptr %l103, !tbaa !24
  store i64 %t200, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s10
  %t201 = load i64, ptr %l13, !tbaa !24
  %t202 = load i64, ptr %l12, !tbaa !24
  %t205 = icmp slt i64 %t201, %t202
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s10)
  br label %bb73
bb56:
  br label %bb57
bb57:
  %t209 = load i64, ptr %l9, !tbaa !24
  %t210 = load i64, ptr %l13, !tbaa !24
  %t211 = load i64, ptr %l11, !tbaa !24
  %t214 = mul i64 %t210, %t211
  %t217 = add i64 %t209, %t214
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l125, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/jupyter:kernel", ptr %t220, i32 0, i32 7
  %t226 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fjupyter_3apending_3e_2eRef__H00d3a79bbb7d8106151b81913e117b7b(ptr %v0, ptr %v0, ptr %t222, i64 %t217)
  store ptr %t226, ptr %l129
  br label %bb58
bb58:
  %t227 = load ptr, ptr %l129, !tbaa !29
  %t229 = getelementptr %"compiler/jupyter:pending", ptr %t227, i32 0, i32 1
  %t230 = load { i64, ptr }, ptr %t229, !tbaa !27
  %t231 = load ptr, ptr %l125, !tbaa !29
  %t233 = call { i32, %"compiler/jupyter:request" } @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2eread(ptr %v0, ptr %v0, ptr %s10, ptr %t231, { i64, ptr } %t230)
  %t234 = extractvalue { i32, %"compiler/jupyter:request" } %t233, 1
  %t235 = extractvalue { i32, %"compiler/jupyter:request" } %t233, 0
  store i32 %t235, ptr %l133
  %t236 = icmp ne i32 %t235, 0
  br i1 %t236, label %bb60, label %ok.237, !prof !99
ok.237:
  store %"compiler/jupyter:request" %t234, ptr %l132
  br label %bb59
bb59:
  %t238 = load %"compiler/jupyter:request", ptr %l132
  store %"compiler/jupyter:request" %t238, ptr %l124
  br label %bb62
bb60:
  %t239 = load i32, ptr %l133, !tbaa !23
  %t240 = ashr i32 %t239, 16
  %t242 = icmp eq i32 %t240, 1
  store i1 %t242, ptr %l135, !tbaa !21
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s10)
  br label %bb72
bb62:
  %t243 = load %"compiler/jupyter:request", ptr %l124
  store %"compiler/jupyter:request" %t243, ptr %l15
  %t245 = call { i64, ptr } @compiler_2fjupyter_2ekindOf(ptr %s10, ptr %s10, ptr %l15)
  store { i64, ptr } %t245, ptr %l137
  br label %bb63
bb63:
  %t246 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t246, ptr %l16, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t249 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t247, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d187, i32 0, i32 1) })
  store i1 %t249, ptr %l139
  br label %bb64
bb64:
  %t250 = load i1, ptr %l139, !tbaa !21
  br i1 %t250, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb68
bb66:
  %t251 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t253 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s10, ptr %s10, { i64, ptr } %t251, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d188, i32 0, i32 1) })
  store i1 %t253, ptr %l142
  br label %bb67
bb67:
  %t254 = load i1, ptr %l142, !tbaa !21
  store i1 %t254, ptr %l140, !tbaa !21
  br label %bb68
bb68:
  %t255 = load i1, ptr %l140, !tbaa !21
  br i1 %t255, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s10)
  store i1 true, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s10)
  br label %bb72
bb72:
  %t257 = load i64, ptr %l13, !tbaa !24
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %l13, !tbaa !24
  br label %bb54
bb73:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2epublish(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l53 = alloca i64
  %l59 = alloca ptr
  %l61 = alloca i32
  %l63 = alloca i1
  %s0 = alloca %olang.scope
  %t6 = alloca %olang.slotscope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = call ptr @__olang_scope_hold(ptr %s0)
  %t3 = ptrtoint ptr %t2 to i64
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_201_3e_2e_2d1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %s0
  %t8 = icmp eq ptr %t7, @__olang_slot_chunk
  %t9 = getelementptr %olang.scope, ptr %s0, i32 0, i32 2
  %t10 = load ptr, ptr %t9
  %t11 = select i1 %t8, ptr %t10, ptr %s0
  store %olang.scope zeroinitializer, ptr %t6
  store ptr @__olang_slot_chunk, ptr %t6
  %t12 = getelementptr %olang.scope, ptr %t6, i32 0, i32 2
  store ptr %t11, ptr %t12
  %t13 = getelementptr %olang.slotscope, ptr %t6, i32 0, i32 1
  store i64 0, ptr %t13
  %t14 = ptrtoint ptr %t6 to i64
  store i64 %t14, ptr %l12, !tbaa !24
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/jupyter:kernel", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t23 = extractvalue { i64, ptr } %t18, 1
  %t24 = extractvalue { i64, ptr } %t18, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t30 = extractvalue { i64, ptr } %t19, 1
  %t31 = extractvalue { i64, ptr } %t19, 0
  %t32 = add i64 %t28, %t31
  %t33 = load i64, ptr %l12
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_held_alloc(ptr %t34, i64 %t32)
  call void @olang_textcopy(ptr %t35, ptr %t20, i64 %t21)
  %t36 = getelementptr i8, ptr %t35, i64 %t21
  call void @olang_textcopy(ptr %t36, ptr %t23, i64 %t24)
  %t37 = getelementptr i8, ptr %t36, i64 %t24
  call void @olang_textcopy(ptr %t37, ptr %t26, i64 %t27)
  %t38 = getelementptr i8, ptr %t37, i64 %t27
  call void @olang_textcopy(ptr %t38, ptr %t30, i64 %t31)
  %t39 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t35, 1
  %t41 = mul i64 1, 16
  %t42 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 1, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l18, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %t47, i64 0
  store { i64, ptr } %t40, ptr %t48, !tbaa !37
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t52 = load ptr, ptr %l11, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t57 = call { i64, ptr } @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2eframes(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %v3, ptr %s0, ptr %t52, { i64, ptr } %t53, { i64, ptr } %t49, { i64, ptr } %a2, { i64, ptr } %a3)
  store { i64, ptr } %t57, ptr %l22
  br label %bb3
bb3:
  %t58 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t58, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/jupyter:kernel", ptr %t59, i32 0, i32 4
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eLen_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l25
  br label %bb4
bb4:
  %t64 = load i64, ptr %l25, !tbaa !24
  store i64 %t64, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb5, label %bb6
bb5:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb10
bb7:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l5, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l7, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l32, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb9
bb9:
  %t91 = load i64, ptr %l32, !tbaa !24
  store i64 %t91, ptr %l29, !tbaa !24
  br label %bb10
bb10:
  %t92 = load i64, ptr %l29, !tbaa !24
  store i64 %t92, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb12, label %bb13
bb12:
  br label %bb28
bb13:
  br label %bb14
bb14:
  %t101 = load i64, ptr %l5, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l10, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/jupyter:kernel", ptr %t111, i32 0, i32 5
  %t114 = load i64, ptr %l10, !tbaa !24
  %t117 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t113, i64 %t114)
  store i64 %t117, ptr %l53
  br label %bb15
bb15:
  %t118 = load i64, ptr @G_2ecompiler_2fjupyter_2eIOPub, !tbaa !24
  %t119 = load i64, ptr %l53, !tbaa !24
  %t121 = icmp ne i64 %t119, %t118
  br i1 %t121, label %bb16, label %bb17
bb16:
  br label %bb27
bb17:
  br label %bb18
bb18:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/jupyter:kernel", ptr %t123, i32 0, i32 4
  %t126 = load i64, ptr %l10, !tbaa !24
  %t129 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eRefMut_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %v0, ptr %t125, i64 %t126)
  store ptr %t129, ptr %l59
  br label %bb19
bb19:
  %t130 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t131 = load ptr, ptr %l59, !tbaa !29
  %t133 = call i32 @std_2fzmtp_2estd_2fzmtp_3aSocket_2eSend(ptr %v0, ptr %s0, ptr %t131, { i64, ptr } %t130)
  store i32 %t133, ptr %l61
  %t134 = icmp ne i32 %t133, 0
  br i1 %t134, label %bb21, label %ok.135, !prof !99
ok.135:
  br label %bb20
bb20:
  br label %bb26
bb21:
  %t136 = load i32, ptr %l61, !tbaa !23
  %t137 = ashr i32 %t136, 16
  %t139 = icmp eq i32 %t137, 1
  store i1 %t139, ptr %l63, !tbaa !21
  %t140 = load i32, ptr %l61, !tbaa !23
  %t141 = ashr i32 %t140, 16
  %t143 = icmp eq i32 %t141, 1
  br i1 %t143, label %bb22, label %bb23
bb22:
  call void @__olang_errpay_pop()
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/jupyter:kernel", ptr %t145, i32 0, i32 5
  %t148 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t147, i64 %t148, i64 -1)
  br label %bb25
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t151 = load i64, ptr %l9, !tbaa !24
  %t154 = add i64 %t151, 1
  store i64 %t154, ptr %l9, !tbaa !24
  br label %bb11
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/jupyter:request" } @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l23 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l38 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l68 = alloca i1
  %l75 = alloca i64
  %l78 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l99 = alloca i64
  %l101 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l121 = alloca %"compiler/jupyter:request"
  %l123 = alloca %"compiler/jupyter:request"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/jupyter:request" }
  %t180 = alloca %olang.slotscope
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -1, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l4, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l23, !tbaa !27
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  %t26 = load { i64, ptr }, ptr @G_2ecompiler_2fjupyter_2eDelimiter, !tbaa !27
  %t27 = load ptr, ptr @__olang_prog_scope
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %t27, { i64, ptr } %t23, { i64, ptr } %t26)
  store i1 %t30, ptr %l28
  br label %bb5
bb5:
  %t31 = load i1, ptr %l28, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  store i1 %t34, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t36 = load i1, ptr %l29, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l6, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb11
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t39, 1
  store i64 %t42, ptr %l4, !tbaa !24
  br label %bb1
bb13:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = icmp slt i64 %t44, 0
  br i1 %t46, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb16
bb15:
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = add i64 %t51, 6
  %t56 = icmp slt i64 %t50, %t53
  store i1 %t56, ptr %l38, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l38, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, %"compiler/jupyter:request" } zeroinitializer, i32 65537, 0
  store { i32, %"compiler/jupyter:request" } %t60, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t62, ptr %l46, !tbaa !27
  %t63 = load i64, ptr %l2, !tbaa !24
  %t65 = add i64 %t63, 2
  %t67 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %t68, i64 %t65
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !37
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t71, ptr %l50, !tbaa !27
  %t72 = load i64, ptr %l2, !tbaa !24
  %t74 = add i64 %t72, 3
  %t76 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %t77, i64 %t74
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !37
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t80, ptr %l54, !tbaa !27
  %t81 = load i64, ptr %l2, !tbaa !24
  %t83 = add i64 %t81, 4
  %t85 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %t86, i64 %t83
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !37
  %t89 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t89, ptr %l58, !tbaa !27
  %t90 = load i64, ptr %l2, !tbaa !24
  %t92 = add i64 %t90, 5
  %t94 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %t95, i64 %t92
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !37
  %t103 = call { i64, ptr } @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2esign(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %t70, { i64, ptr } %t79, { i64, ptr } %t88, { i64, ptr } %t97)
  store { i64, ptr } %t103, ptr %l62
  br label %bb20
bb20:
  %t104 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t105, ptr %l64, !tbaa !27
  %t106 = load i64, ptr %l2, !tbaa !24
  %t108 = add i64 %t106, 1
  %t110 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %t111, i64 %t108
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !37
  %t116 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t104, { i64, ptr } %t113)
  store i1 %t116, ptr %l68
  br label %bb21
bb21:
  %t117 = load i1, ptr %l68, !tbaa !21
  %t118 = xor i1 %t117, true
  br i1 %t118, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t121 = insertvalue { i32, %"compiler/jupyter:request" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/jupyter:request" } %t121, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store i64 0, ptr %l8, !tbaa !24
  %t122 = load i64, ptr %l2, !tbaa !24
  store i64 %t122, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l8, !tbaa !24
  %t128 = icmp sgt i64 %t124, %t125
  br i1 %t128, label %bb25, label %bb26
bb25:
  %t130 = load i64, ptr %l10, !tbaa !24
  %t132 = icmp sgt i64 %t130, 0
  br i1 %t132, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb30
bb27:
  %t134 = load i64, ptr %l9, !tbaa !24
  %t135 = load i64, ptr %l8, !tbaa !24
  %t138 = sub i64 %t134, %t135
  %t139 = load i64, ptr %l10, !tbaa !24
  %t142 = add i64 %t138, %t139
  %t144 = sub i64 %t142, 1
  %t145 = load i64, ptr %l10, !tbaa !24
  %t148 = sdiv i64 %t144, %t145
  store i64 %t148, ptr %l78, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb29
bb29:
  %t150 = load i64, ptr %l78, !tbaa !24
  store i64 %t150, ptr %l75, !tbaa !24
  br label %bb30
bb30:
  %t151 = load i64, ptr %l75, !tbaa !24
  store i64 %t151, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l11, !tbaa !24
  %t154 = mul i64 %t152, 16
  %t155 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t154)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  store { i64, ptr } %t157, ptr %l88, !tbaa !27
  store i64 0, ptr %l89, !tbaa !24
  br label %bb31
bb31:
  %t158 = load i64, ptr %l12, !tbaa !24
  %t159 = load i64, ptr %l11, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb32, label %bb33
bb32:
  br label %bb38
bb33:
  br label %bb34
bb34:
  %t166 = load i64, ptr %l8, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t168 = load i64, ptr %l10, !tbaa !24
  %t171 = mul i64 %t167, %t168
  %t174 = add i64 %t166, %t171
  store i64 %t174, ptr %l13, !tbaa !24
  %t176 = call ptr @__olang_scope_hold(ptr %s0)
  %t177 = ptrtoint ptr %t176 to i64
  store i64 %t177, ptr %l99, !tbaa !24
  %t178 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_3e_2e_2d1
  br i1 %t178, label %bb35, label %bb36
bb35:
  %t181 = load ptr, ptr %s0
  %t182 = icmp eq ptr %t181, @__olang_slot_chunk
  %t183 = getelementptr %olang.scope, ptr %s0, i32 0, i32 2
  %t184 = load ptr, ptr %t183
  %t185 = select i1 %t182, ptr %t184, ptr %s0
  store %olang.scope zeroinitializer, ptr %t180
  store ptr @__olang_slot_chunk, ptr %t180
  %t186 = getelementptr %olang.scope, ptr %t180, i32 0, i32 2
  store ptr %t185, ptr %t186
  %t187 = getelementptr %olang.slotscope, ptr %t180, i32 0, i32 1
  store i64 0, ptr %t187
  %t188 = ptrtoint ptr %t180 to i64
  store i64 %t188, ptr %l99, !tbaa !24
  br label %bb36
bb36:
  %t189 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t189, ptr %l101, !tbaa !27
  %t190 = load i64, ptr %l13, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %t193, i64 %t190
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !37
  %t197 = extractvalue { i64, ptr } %t195, 1
  %t198 = extractvalue { i64, ptr } %t195, 0
  %t199 = load i64, ptr %l99
  %t200 = inttoptr i64 %t199 to ptr
  %t201 = call ptr @__olang_held_alloc(ptr %t200, i64 %t198)
  call void @olang_textcopy(ptr %t201, ptr %t197, i64 %t198)
  %t202 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  %t205 = load i64, ptr %l89, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %t207, i64 %t205
  store { i64, ptr } %t203, ptr %t208, !tbaa !37
  %t209 = load i64, ptr %l89, !tbaa !24
  %t210 = add i64 %t209, 1
  store i64 %t210, ptr %l89, !tbaa !24
  br label %bb37
bb37:
  %t211 = load i64, ptr %l12, !tbaa !24
  %t214 = add i64 %t211, 1
  store i64 %t214, ptr %l12, !tbaa !24
  br label %bb31
bb38:
  %t216 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t220 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, { i64, ptr } %t216)
  store { i64, ptr } %t220, ptr %l110
  br label %bb39
bb39:
  %t221 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t221, ptr %l111, !tbaa !27
  %t222 = load i64, ptr %l2, !tbaa !24
  %t224 = add i64 %t222, 2
  %t226 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr { i64, ptr }, ptr %t227, i64 %t224
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !37
  %t231 = extractvalue { i64, ptr } %t229, 1
  %t232 = extractvalue { i64, ptr } %t229, 0
  %t233 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t231, i64 %t232)
  %t234 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  %t236 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t236, ptr %l116, !tbaa !27
  %t237 = load i64, ptr %l2, !tbaa !24
  %t239 = add i64 %t237, 5
  %t241 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %t242, i64 %t239
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !37
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = extractvalue { i64, ptr } %t244, 0
  %t248 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t247)
  call void @olang_textcopy(ptr %t248, ptr %t246, i64 %t247)
  %t249 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t251 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t254 = call %"compiler/jupyter:request" @compiler_2fjupyter_3arequest_2ector(ptr %v2, ptr %v2, { i64, ptr } %t251, { i64, ptr } %t235, { i64, ptr } %t250)
  store %"compiler/jupyter:request" %t254, ptr %l121
  br label %bb40
bb40:
  %t256 = call %"compiler/jupyter:request" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fjupyter_3arequest(ptr %v2, ptr %l121)
  store %"compiler/jupyter:request" %t256, ptr %l123
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t257 = load %"compiler/jupyter:request", ptr %l123
  %t258 = insertvalue { i32, %"compiler/jupyter:request" } zeroinitializer, %"compiler/jupyter:request" %t257, 1
  store { i32, %"compiler/jupyter:request" } %t258, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/jupyter:request" }, ptr %rv
  ret { i32, %"compiler/jupyter:request" } %rr
}

define dso_local void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2eserve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca i1
  %l20 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l30 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/jupyter:kernel", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eRefMut_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t9 = call i32 @std_2fzmtp_2estd_2fzmtp_3aSocket_2eFill(ptr %v0, ptr %t8)
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  br label %bb2
bb2:
  br label %bb8
bb3:
  %t12 = load i32, ptr %l8, !tbaa !23
  %t13 = ashr i32 %t12, 16
  %t15 = icmp eq i32 %t13, 1
  store i1 %t15, ptr %l10, !tbaa !21
  %t16 = load i32, ptr %l8, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  br i1 %t19, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/jupyter:kernel", ptr %t21, i32 0, i32 5
  %t24 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t23, i64 %t24, i64 -1)
  br label %bb7
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/jupyter:kernel", ptr %t27, i32 0, i32 6
  %t30 = load i1, ptr %t29, !tbaa !21
  %t32 = xor i1 %t30, true
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb11:
  br label %bb12
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/jupyter:kernel", ptr %t36, i32 0, i32 4
  %t39 = load i64, ptr %l2, !tbaa !24
  %t42 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eRefMut_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %v0, ptr %t38, i64 %t39)
  store ptr %t42, ptr %l24
  br label %bb13
bb13:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = call { i32, { i64, ptr } } @std_2fzmtp_2estd_2fzmtp_3aSocket_2eNext(ptr %v0, ptr %s2, ptr %t43)
  %t45 = extractvalue { i32, { i64, ptr } } %t44, 1
  %t46 = extractvalue { i32, { i64, ptr } } %t44, 0
  store i32 %t46, ptr %l26
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb15, label %ok.48, !prof !99
ok.48:
  store { i64, ptr } %t45, ptr %l25
  br label %bb14
bb14:
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t49, ptr %l20, !tbaa !27
  br label %bb21
bb15:
  %t50 = load i32, ptr %l26, !tbaa !23
  %t51 = ashr i32 %t50, 16
  %t53 = icmp eq i32 %t51, 1
  br i1 %t53, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  %t55 = load i32, ptr %l26, !tbaa !23
  %t56 = ashr i32 %t55, 16
  %t58 = icmp eq i32 %t56, 2
  store i1 %t58, ptr %l30, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/jupyter:kernel", ptr %t59, i32 0, i32 5
  %t62 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t61, i64 %t62, i64 -1)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb21:
  %t65 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ehandle(ptr %v0, ptr %v1, ptr %s2, ptr %v2, ptr %t66, ptr %a1, i64 %t68, { i64, ptr } %t65)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  br label %bb9
bb24:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2estream(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d191, i32 0, i32 1) })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a0, ptr %l6, !tbaa !29
  store { i64, ptr } %a1, ptr %l7, !tbaa !27
  store { i64, ptr } %a2, ptr %l8, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %v3, ptr %s0, { i64, ptr } %t8)
  store { i64, ptr } %t10, ptr %l10
  br label %bb5
bb5:
  %t11 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 1
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t11, i64 %t12)
  %t28 = getelementptr i8, ptr %t27, i64 %t12
  call void @olang_textcopy(ptr %t28, ptr %t14, i64 %t15)
  %t29 = getelementptr i8, ptr %t28, i64 %t15
  call void @olang_textcopy(ptr %t29, ptr %t17, i64 %t18)
  %t30 = getelementptr i8, ptr %t29, i64 %t18
  call void @olang_textcopy(ptr %t30, ptr %t21, i64 %t22)
  %t31 = getelementptr i8, ptr %t30, i64 %t22
  call void @olang_textcopy(ptr %t31, ptr %t24, i64 %t25)
  %t32 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  %t35 = load ptr, ptr %l6, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2epublish(ptr %v0, ptr %s0, ptr %v1, ptr %s0, ptr %t35, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d195, i32 0, i32 1) }, { i64, ptr } %t36, { i64, ptr } %t33)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2esweep(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l37 = alloca i64
  %l44 = alloca i64
  %l49 = alloca i32
  %l51 = alloca i1
  %l55 = alloca i32
  %l57 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/jupyter:kernel", ptr %t1, i32 0, i32 5
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb26
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/jupyter:kernel", ptr %t53, i32 0, i32 5
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t55)
  store i64 %t57, ptr %l37
  br label %bb12
bb12:
  %t58 = load i64, ptr %l37, !tbaa !24
  %t59 = sub i64 %t58, 1
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = sub i64 %t59, %t60
  store i64 %t63, ptr %l7, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/jupyter:kernel", ptr %t65, i32 0, i32 5
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t68)
  store i64 %t71, ptr %l44
  br label %bb13
bb13:
  %t72 = load i64, ptr %l44, !tbaa !24
  %t73 = icmp sge i64 %t72, 0
  br i1 %t73, label %bb14, label %bb15
bb14:
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/jupyter:kernel", ptr %t75, i32 0, i32 4
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eRemoveAt_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %t77, i64 %t78)
  store i32 %t81, ptr %l49
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb18, label %ok.83, !prof !99
ok.83:
  br label %bb17
bb17:
  br label %bb20
bb18:
  %t84 = load i32, ptr %l49, !tbaa !23
  %t85 = ashr i32 %t84, 16
  %t87 = icmp eq i32 %t85, 1
  store i1 %t87, ptr %l51, !tbaa !21
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/jupyter:kernel", ptr %t88, i32 0, i32 5
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %t90, i64 %t91)
  store i32 %t94, ptr %l55
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb22, label %ok.96, !prof !99
ok.96:
  br label %bb21
bb21:
  br label %bb24
bb22:
  %t97 = load i32, ptr %l55, !tbaa !23
  %t98 = ashr i32 %t97, 16
  %t100 = icmp eq i32 %t98, 1
  store i1 %t100, ptr %l57, !tbaa !21
  br label %bb23
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t101 = load i64, ptr %l5, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l5, !tbaa !24
  br label %bb8
bb26:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fjupyter_2ecomplete(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/prompt:Decl"
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/prompt:Value"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i32
  %l36 = alloca i1
  %l39 = alloca i64
  %l40 = alloca i32
  %l42 = alloca i1
  %l51 = alloca i1
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l103 = alloca i1
  %l104 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca i64
  %l116 = alloca i1
  %l118 = alloca i1
  %l121 = alloca { i64, ptr }
  %l122 = alloca i1
  %l131 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l161 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l162 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l164 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l176 = alloca i1
  %l178 = alloca i1
  %l182 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i64
  %l189 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fjupyter_2estr(ptr %v1, ptr %s0, ptr %v1, ptr %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d196, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l28
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load ptr, ptr %l1, !tbaa !29
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d197, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t9 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %v1, ptr %t5, { i64, ptr } %t6)
  %t10 = extractvalue { i32, ptr } %t9, 1
  %t11 = extractvalue { i32, ptr } %t9, 0
  store i32 %t11, ptr %l34
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13, !prof !99
ok.13:
  store ptr %t10, ptr %l33
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l33, !tbaa !29
  %t15 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %v1, ptr %t14)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l40
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb8, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l39
  br label %bb7
bb3:
  %t20 = load i32, ptr %l34, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l36, !tbaa !21
  %t24 = load i32, ptr %l34, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l29, !tbaa !24
  br label %bb11
bb7:
  %t33 = load i64, ptr %l39, !tbaa !24
  store i64 %t33, ptr %l29, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i32, ptr %l40, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  store i1 %t37, ptr %l42, !tbaa !21
  %t38 = load i32, ptr %l40, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb6
bb11:
  %t43 = load i64, ptr %l29, !tbaa !24
  store i64 %t43, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t50 = icmp sgt i64 %t44, %t47
  br i1 %t50, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb14
bb13:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = icmp slt i64 %t52, 0
  store i1 %t54, ptr %l51, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l51, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l3, !tbaa !24
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t61 = load i64, ptr %l3, !tbaa !24
  store i64 %t61, ptr %l4, !tbaa !24
  br label %bb18
bb18:
  %t63 = load i64, ptr %l4, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t67, ptr %l60, !tbaa !27
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = sub i64 %t68, 1
  %t72 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 %t70
  %t75 = load i8, ptr %t74, !tbaa !32
  %t77 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t75)
  store i1 %t77, ptr %l64
  br label %bb21
bb20:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb29
bb21:
  %t78 = load i1, ptr %l64, !tbaa !21
  br i1 %t78, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb25
bb23:
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t79, ptr %l66, !tbaa !27
  %t80 = load i64, ptr %l4, !tbaa !24
  %t82 = sub i64 %t80, 1
  %t84 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i8, ptr %t85, i64 %t82
  %t87 = load i8, ptr %t86, !tbaa !32
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t87)
  store i1 %t89, ptr %l70
  br label %bb24
bb24:
  %t90 = load i1, ptr %l70, !tbaa !21
  store i1 %t90, ptr %l65, !tbaa !21
  br label %bb25
bb25:
  %t91 = load i1, ptr %l65, !tbaa !21
  br i1 %t91, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb28
bb27:
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l72, !tbaa !27
  %t93 = load i64, ptr %l4, !tbaa !24
  %t95 = sub i64 %t93, 1
  %t97 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i8, ptr %t98, i64 %t95
  %t100 = load i8, ptr %t99, !tbaa !32
  %t102 = icmp eq i8 %t100, 95
  store i1 %t102, ptr %l71, !tbaa !21
  br label %bb28
bb28:
  %t104 = load i1, ptr %l71, !tbaa !21
  store i1 %t104, ptr %l59, !tbaa !21
  br label %bb29
bb29:
  %t105 = load i1, ptr %l59, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  br label %bb32
bb32:
  %t108 = load i64, ptr %l4, !tbaa !24
  %t111 = sub i64 %t108, 1
  store i64 %t111, ptr %l4, !tbaa !24
  br label %bb33
bb33:
  br label %bb18
bb34:
  %t113 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t113, ptr %l81, !tbaa !27
  %t114 = load i64, ptr %l4, !tbaa !24
  store i64 %t114, ptr %l82, !tbaa !24
  %t115 = load i64, ptr %l3, !tbaa !24
  store i64 %t115, ptr %l83, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  store i64 %t117, ptr %l84, !tbaa !24
  %t118 = load i64, ptr %l82, !tbaa !24
  %t119 = icmp sge i64 %t118, 0
  br i1 %t119, label %bb35, label %bb36
bb35:
  %t121 = load i64, ptr %l82, !tbaa !24
  %t122 = load i64, ptr %l83, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_a3bb6ba411f5318_f8f719f7dabe5f3c)
  unreachable
bb37:
  %t125 = load i64, ptr %l83, !tbaa !24
  %t126 = load i64, ptr %l84, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_a3bb6ba411f5318_f8f719f7dabe5f3c)
  unreachable
bb39:
  %t129 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l82, !tbaa !24
  %t132 = load i64, ptr %l83, !tbaa !24
  %t133 = getelementptr i8, ptr %t130, i64 %t131
  %t134 = sub i64 %t132, %t131
  %t135 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t133, 1
  store { i64, ptr } %t136, ptr %l5, !tbaa !27
  %t138 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %l89
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_a3bb6ba411f5318_f8f719f7dabe5f3c)
  unreachable
bb41:
  %t139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %l6
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/prompt:Session", ptr %t140, i32 0, i32 3
  %t144 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eView_3ccompiler_2fprompt_3aDecl_3e(ptr %v0, ptr %v0, ptr %t142)
  store { i64, ptr } %t144, ptr %l92
  br label %bb42
bb42:
  %t145 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t145, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  store i64 %t148, ptr %l9, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s4
  %t150 = load i64, ptr %l8, !tbaa !24
  %t151 = load i64, ptr %l9, !tbaa !24
  %t154 = icmp slt i64 %t150, %t151
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s4)
  br label %bb67
bb45:
  br label %bb46
bb46:
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t158, ptr %l99, !tbaa !27
  %t159 = load i64, ptr %l8, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr %"compiler/prompt:Decl", ptr %t162, i64 %t159
  %t164 = load %"compiler/prompt:Decl", ptr %t163
  store %"compiler/prompt:Decl" %t164, ptr %l10
  %t166 = getelementptr %"compiler/prompt:Decl", ptr %l10, i32 0, i32 0
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  %t169 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s4, { i64, ptr } %t167, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d198, i32 0, i32 1) })
  store i1 %t169, ptr %l103
  br label %bb47
bb47:
  %t170 = load i1, ptr %l103, !tbaa !21
  br i1 %t170, label %bb48, label %bb49
bb48:
  %t171 = getelementptr %"compiler/prompt:Decl", ptr %l10, i32 0, i32 0
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l105, !tbaa !27
  %t173 = getelementptr %"compiler/prompt:Decl", ptr %l10, i32 0, i32 0
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t174, 0
  store i64 %t177, ptr %l108, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  store i64 %t179, ptr %l109, !tbaa !24
  %t180 = icmp sge i64 7, 0
  br i1 %t180, label %bb50, label %bb51
bb49:
  %t182 = getelementptr %"compiler/prompt:Decl", ptr %l10, i32 0, i32 0
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %l104, !tbaa !27
  br label %bb56
bb50:
  %t185 = load i64, ptr %l108, !tbaa !24
  %t186 = icmp sle i64 7, %t185
  br i1 %t186, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_a638196a2ff6a75_60555f0a368b3729)
  unreachable
bb52:
  %t188 = load i64, ptr %l108, !tbaa !24
  %t189 = load i64, ptr %l109, !tbaa !24
  %t190 = icmp sle i64 %t188, %t189
  br i1 %t190, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_a638196a2ff6a75_60555f0a368b3729)
  unreachable
bb54:
  %t192 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = load i64, ptr %l108, !tbaa !24
  %t195 = getelementptr i8, ptr %t193, i64 7
  %t196 = sub i64 %t194, 7
  %t197 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t195, 1
  store { i64, ptr } %t198, ptr %l104, !tbaa !27
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_a638196a2ff6a75_60555f0a368b3729)
  unreachable
bb56:
  %t200 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t200, ptr %l11, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t203 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s4, { i64, ptr } %t201, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d199, i32 0, i32 1) })
  store i1 %t203, ptr %l116
  br label %bb57
bb57:
  %t204 = load i1, ptr %l116, !tbaa !21
  %t205 = xor i1 %t204, true
  br i1 %t205, label %bb58, label %bb59
bb58:
  %t207 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d200, i32 0, i32 1) }, ptr %l121, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t211 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s4, { i64, ptr } %t207, { i64, ptr } %t210)
  store i1 %t211, ptr %l122
  br label %bb60
bb59:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb61
bb60:
  %t212 = load i1, ptr %l122, !tbaa !21
  %t213 = xor i1 %t212, true
  store i1 %t213, ptr %l118, !tbaa !21
  br label %bb61
bb61:
  %t215 = load i1, ptr %l118, !tbaa !21
  br i1 %t215, label %bb62, label %bb63
bb62:
  %t216 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %l6, { i64, ptr } %t216)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb66:
  %t219 = load i64, ptr %l8, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l8, !tbaa !24
  br label %bb43
bb67:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/prompt:Session", ptr %t224, i32 0, i32 4
  %t228 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eView_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %v0, ptr %t226)
  store { i64, ptr } %t228, ptr %l131
  br label %bb68
bb68:
  %t229 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t229, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t230 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  store i64 %t232, ptr %l14, !tbaa !24
  br label %bb69
bb69:
  %t234 = load i64, ptr %l13, !tbaa !24
  %t235 = load i64, ptr %l14, !tbaa !24
  %t238 = icmp slt i64 %t234, %t235
  %t240 = xor i1 %t238, true
  br i1 %t240, label %bb70, label %bb71
bb70:
  br label %bb75
bb71:
  br label %bb72
bb72:
  %t242 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t242, ptr %l138, !tbaa !27
  %t243 = load i64, ptr %l13, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr %"compiler/prompt:Value", ptr %t246, i64 %t243
  %t248 = load %"compiler/prompt:Value", ptr %t247
  store %"compiler/prompt:Value" %t248, ptr %l15
  %t250 = getelementptr %"compiler/prompt:Value", ptr %l15, i32 0, i32 0
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %l6, { i64, ptr } %t251)
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t254 = load i64, ptr %l13, !tbaa !24
  %t257 = add i64 %t254, 1
  store i64 %t257, ptr %l13, !tbaa !24
  br label %bb69
bb75:
  store ptr @G_2ecompiler_2fjupyter_2eKeywords, ptr %l16
  store i64 0, ptr %l17, !tbaa !24
  %t260 = load ptr, ptr %l16
  store i64 25, ptr %l18, !tbaa !24
  br label %bb76
bb76:
  %t263 = load i64, ptr %l17, !tbaa !24
  %t264 = load i64, ptr %l18, !tbaa !24
  %t267 = icmp slt i64 %t263, %t264
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb77, label %bb78
bb77:
  br label %bb82
bb78:
  br label %bb79
bb79:
  %t271 = load ptr, ptr %l16
  %t272 = load i64, ptr %l17, !tbaa !24
  %t275 = getelementptr [25 x { i64, ptr }], ptr %t271, i64 0, i64 %t272
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !37
  %t279 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %t279, ptr %l6, { i64, ptr } %t276)
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t282 = load i64, ptr %l17, !tbaa !24
  %t285 = add i64 %t282, 1
  store i64 %t285, ptr %l17, !tbaa !24
  br label %bb76
bb82:
  %t287 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t287, ptr %l161
  br label %bb83
bb83:
  %t288 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l161
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t288, ptr %l20
  %t289 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t289, ptr %l162
  br label %bb84
bb84:
  %t290 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l162
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t290, ptr %l21
  %t292 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H563b551a62b57e684177c5454e33a204(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t292, ptr %l164
  br label %bb85
bb85:
  %t293 = load { i64, ptr }, ptr %l164, !tbaa !27
  store { i64, ptr } %t293, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t294 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t294, 0
  store i64 %t296, ptr %l24, !tbaa !24
  br label %bb86
bb86:
  %t298 = load i64, ptr %l23, !tbaa !24
  %t299 = load i64, ptr %l24, !tbaa !24
  %t302 = icmp slt i64 %t298, %t299
  %t304 = xor i1 %t302, true
  br i1 %t304, label %bb87, label %bb88
bb87:
  br label %bb104
bb88:
  br label %bb89
bb89:
  %t306 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t306, ptr %l171, !tbaa !27
  %t307 = load i64, ptr %l23, !tbaa !24
  %t309 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %t310, i64 %t307
  %t312 = load { i64, ptr }, ptr %t311, !tbaa !37
  store { i64, ptr } %t312, ptr %l25, !tbaa !27
  %t314 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t318 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %v1, { i64, ptr } %t314, { i64, ptr } %t315)
  store i1 %t318, ptr %l176
  br label %bb90
bb90:
  %t319 = load i1, ptr %l176, !tbaa !21
  %t320 = xor i1 %t319, true
  br i1 %t320, label %bb91, label %bb92
bb91:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb94
bb92:
  %t322 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t327 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %s0, ptr %s0, ptr %l20, { i64, ptr } %t322)
  store i1 %t327, ptr %l182
  br label %bb93
bb93:
  %t328 = load i1, ptr %l182, !tbaa !21
  store i1 %t328, ptr %l178, !tbaa !21
  br label %bb94
bb94:
  %t329 = load i1, ptr %l178, !tbaa !21
  br i1 %t329, label %bb95, label %bb96
bb95:
  br label %bb103
bb96:
  br label %bb97
bb97:
  %t330 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %s0, ptr %s0, ptr %l20, { i64, ptr } %t330, i1 true)
  br label %bb98
bb98:
  store ptr %l21, ptr %l185, !tbaa !29
  %t333 = call ptr @__olang_scope_hold(ptr %s0)
  %t334 = ptrtoint ptr %t333 to i64
  store i64 %t334, ptr %l186, !tbaa !24
  %t335 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t335, label %bb99, label %bb100
bb99:
  %t337 = call ptr @__olang_region_make(ptr %s0)
  %t338 = ptrtoint ptr %t337 to i64
  store i64 %t338, ptr %l186, !tbaa !24
  br label %bb100
bb100:
  %t339 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t340 = load i64, ptr %l186
  %t341 = inttoptr i64 %t340 to ptr
  %t343 = call { i64, ptr } @compiler_2fjupyter_2eQ(ptr %s0, ptr %t341, { i64, ptr } %t339)
  store { i64, ptr } %t343, ptr %l189
  br label %bb101
bb101:
  %t344 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t345 = load ptr, ptr %l185, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t345, { i64, ptr } %t344)
  br label %bb102
bb102:
  br label %bb103
bb103:
  %t347 = load i64, ptr %l23, !tbaa !24
  %t350 = add i64 %t347, 1
  store i64 %t350, ptr %l23, !tbaa !24
  br label %bb86
bb104:
  %t353 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d201, i32 0, i32 1) })
  store { i64, ptr } %t353, ptr %l195
  br label %bb105
bb105:
  %t354 = load i64, ptr %l4, !tbaa !24
  %t355 = load i64, ptr %l3, !tbaa !24
  %t356 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d202, i32 0, i32 1) }, 1
  %t357 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d202, i32 0, i32 1) }, 0
  %t358 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 1
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = add i64 %t357, %t360
  %t362 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t363 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t364 = add i64 %t361, %t363
  %t366 = call i64 @__olang_fmt_i64(ptr null, i64 %t354)
  %t367 = add i64 %t364, %t366
  %t368 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t369 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t370 = add i64 %t367, %t369
  %t372 = call i64 @__olang_fmt_i64(ptr null, i64 %t355)
  %t373 = add i64 %t370, %t372
  %t374 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t375 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t376 = add i64 %t373, %t375
  %t377 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t376)
  call void @olang_textcopy(ptr %t377, ptr %t356, i64 %t357)
  %t378 = getelementptr i8, ptr %t377, i64 %t357
  call void @olang_textcopy(ptr %t378, ptr %t359, i64 %t360)
  %t379 = getelementptr i8, ptr %t378, i64 %t360
  call void @olang_textcopy(ptr %t379, ptr %t362, i64 %t363)
  %t380 = getelementptr i8, ptr %t379, i64 %t363
  %t381 = call i64 @__olang_fmt_i64(ptr %t380, i64 %t354)
  %t382 = getelementptr i8, ptr %t380, i64 %t366
  call void @olang_textcopy(ptr %t382, ptr %t368, i64 %t369)
  %t383 = getelementptr i8, ptr %t382, i64 %t369
  %t384 = call i64 @__olang_fmt_i64(ptr %t383, i64 %t355)
  %t385 = getelementptr i8, ptr %t383, i64 %t372
  call void @olang_textcopy(ptr %t385, ptr %t374, i64 %t375)
  %t386 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t387 = insertvalue { i64, ptr } %t386, ptr %t377, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t387, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fjupyter_2eisComplete(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2fprompt_2eOpen(ptr %v0, { i64, ptr } %a0)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d206, i32 0, i32 1) }, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t5, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d207, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l9, !tbaa !24
  %t24 = load i64, ptr %l9, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l10, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l9, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t35, ptr %l8, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fjupyter_2eisoNow(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca { i64, i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l13 = alloca { i64, i64, i64 }
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i64 @std_2ftime_2eWall()
  store i64 %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load i64, ptr %l8, !tbaa !24
  store i64 %t2, ptr %l0, !tbaa !24
  %t3 = load i64, ptr %l0, !tbaa !24
  %t5 = sdiv i64 %t3, 1000000000
  store i64 %t5, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = sdiv i64 %t7, 86400
  %t11 = call { i64, i64, i64 } @compiler_2fjupyter_2ecivil(i64 %t9)
  store { i64, i64, i64 } %t11, ptr %l13
  br label %bb2
bb2:
  %t12 = load { i64, i64, i64 }, ptr %l13
  store { i64, i64, i64 } %t12, ptr %l2
  %t13 = getelementptr { i64, i64, i64 }, ptr %l2, i32 0, i32 0
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = getelementptr { i64, i64, i64 }, ptr %l2, i32 0, i32 1
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = getelementptr { i64, i64, i64 }, ptr %l2, i32 0, i32 2
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  %t24 = srem i64 %t22, 86400
  store i64 %t24, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l0, !tbaa !24
  %t28 = srem i64 %t26, 1000000000
  %t30 = sdiv i64 %t28, 1000
  %t32 = call i64 @__olang_fmt_i64(ptr null, i64 %t30)
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  %t34 = call i64 @__olang_fmt_i64(ptr %t33, i64 %t30)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %l7, !tbaa !27
  store i64 %t14, ptr %l23, !tbaa !24
  %t41 = call { i64, ptr } @compiler_2fjupyter_2etwo(ptr %s0, i64 %t17)
  store { i64, ptr } %t41, ptr %l25
  br label %bb3
bb3:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t44 = call { i64, ptr } @compiler_2fjupyter_2etwo(ptr %s0, i64 %t42)
  store { i64, ptr } %t44, ptr %l27
  br label %bb4
bb4:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t47 = sdiv i64 %t45, 3600
  %t49 = call { i64, ptr } @compiler_2fjupyter_2etwo(ptr %s0, i64 %t47)
  store { i64, ptr } %t49, ptr %l30
  br label %bb5
bb5:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = sdiv i64 %t50, 60
  %t54 = srem i64 %t52, 60
  %t56 = call { i64, ptr } @compiler_2fjupyter_2etwo(ptr %s0, i64 %t54)
  store { i64, ptr } %t56, ptr %l34
  br label %bb6
bb6:
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = srem i64 %t57, 60
  %t61 = call { i64, ptr } @compiler_2fjupyter_2etwo(ptr %s0, i64 %t59)
  store { i64, ptr } %t61, ptr %l37
  br label %bb7
bb7:
  %t62 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t64 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s0, ptr %s0, { i64, ptr } %t62, i64 6, i8 48)
  store { i64, ptr } %t64, ptr %l39
  br label %bb8
bb8:
  %t65 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  store i64 %t66, ptr %l40, !tbaa !24
  %t67 = load i64, ptr %l40, !tbaa !24
  %t68 = mul i64 %t67, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l41, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = load i64, ptr %l40, !tbaa !24
  %t77 = mul i64 %t76, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t73, ptr %t75, i64 %t77, i1 false)
  %t78 = load i64, ptr %l23, !tbaa !24
  %t79 = call i64 @__olang_fmt_i64(ptr null, i64 %t78)
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = add i64 %t82, %t85
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t90 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = add i64 %t89, %t92
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t97 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = add i64 %t96, %t99
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t103 = add i64 %t100, %t102
  %t104 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = add i64 %t103, %t106
  %t108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t110 = add i64 %t107, %t109
  %t111 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = add i64 %t110, %t113
  %t115 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t118 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = add i64 %t117, %t120
  %t122 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t124)
  %t126 = call i64 @__olang_fmt_i64(ptr %t125, i64 %t78)
  %t127 = getelementptr i8, ptr %t125, i64 %t79
  call void @olang_textcopy(ptr %t127, ptr %t80, i64 %t81)
  %t128 = getelementptr i8, ptr %t127, i64 %t81
  call void @olang_textcopy(ptr %t128, ptr %t84, i64 %t85)
  %t129 = getelementptr i8, ptr %t128, i64 %t85
  call void @olang_textcopy(ptr %t129, ptr %t87, i64 %t88)
  %t130 = getelementptr i8, ptr %t129, i64 %t88
  call void @olang_textcopy(ptr %t130, ptr %t91, i64 %t92)
  %t131 = getelementptr i8, ptr %t130, i64 %t92
  call void @olang_textcopy(ptr %t131, ptr %t94, i64 %t95)
  %t132 = getelementptr i8, ptr %t131, i64 %t95
  call void @olang_textcopy(ptr %t132, ptr %t98, i64 %t99)
  %t133 = getelementptr i8, ptr %t132, i64 %t99
  call void @olang_textcopy(ptr %t133, ptr %t101, i64 %t102)
  %t134 = getelementptr i8, ptr %t133, i64 %t102
  call void @olang_textcopy(ptr %t134, ptr %t105, i64 %t106)
  %t135 = getelementptr i8, ptr %t134, i64 %t106
  call void @olang_textcopy(ptr %t135, ptr %t108, i64 %t109)
  %t136 = getelementptr i8, ptr %t135, i64 %t109
  call void @olang_textcopy(ptr %t136, ptr %t112, i64 %t113)
  %t137 = getelementptr i8, ptr %t136, i64 %t113
  call void @olang_textcopy(ptr %t137, ptr %t115, i64 %t116)
  %t138 = getelementptr i8, ptr %t137, i64 %t116
  call void @olang_textcopy(ptr %t138, ptr %t119, i64 %t120)
  %t139 = getelementptr i8, ptr %t138, i64 %t120
  call void @olang_textcopy(ptr %t139, ptr %t122, i64 %t123)
  %t140 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t125, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t141, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fjupyter_2ekernelInfo(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l1
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  %t3 = load { i64, ptr }, ptr @G_2ecompiler_2fjupyter_2eProtocol, !tbaa !27
  %t4 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %t3, 1
  %t8 = extractvalue { i64, ptr } %t3, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t7, i64 %t8)
  %t15 = getelementptr i8, ptr %t14, i64 %t8
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l0, { i64, ptr } %t17)
  br label %bb2
bb2:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l0, { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d215, i32 0, i32 1) })
  br label %bb3
bb3:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l0, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d216, i32 0, i32 1) })
  br label %bb4
bb4:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l0, { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d217, i32 0, i32 1) })
  br label %bb5
bb5:
  %t25 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l0)
  store { i64, ptr } %t25, ptr %l10
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fjupyter_2enewId(ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i32
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i64 @std_2ftime_2eWall()
  store i64 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = call i64 @std_2ftime_2eNow()
  store i64 %t2, ptr %l1
  br label %bb2
bb2:
  %t3 = call i32 @getpid()
  store i32 %t3, ptr %l2
  br label %bb3
bb3:
  %t4 = load i64, ptr %l0, !tbaa !24
  %t5 = call i64 @__olang_fmt_i64(ptr null, i64 %t4)
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = call i64 @__olang_fmt_i64(ptr null, i64 %t9)
  %t11 = add i64 %t8, %t10
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = load i32, ptr %l2, !tbaa !23
  %t16 = sext i32 %t15 to i64
  %t17 = call i64 @__olang_fmt_i64(ptr null, i64 %t16)
  %t18 = add i64 %t14, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  %t20 = call i64 @__olang_fmt_i64(ptr %t19, i64 %t4)
  %t21 = getelementptr i8, ptr %t19, i64 %t5
  call void @olang_textcopy(ptr %t21, ptr %t6, i64 %t7)
  %t22 = getelementptr i8, ptr %t21, i64 %t7
  %t23 = call i64 @__olang_fmt_i64(ptr %t22, i64 %t9)
  %t24 = getelementptr i8, ptr %t22, i64 %t10
  call void @olang_textcopy(ptr %t24, ptr %t12, i64 %t13)
  %t25 = getelementptr i8, ptr %t24, i64 %t13
  %t26 = call i64 @__olang_fmt_i64(ptr %t25, i64 %t16)
  %t27 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t19, 1
  %t31 = extractvalue { i64, ptr } %t28, 0
  %t32 = extractvalue { i64, ptr } %t28, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t38 = call { i64, ptr } @std_2fsha256_2eSum(ptr %s0, ptr %s0, { i64, ptr } %t36)
  store { i64, ptr } %t38, ptr %l6
  br label %bb4
bb4:
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = call { i64, ptr } @std_2fhex_2eEncode(ptr %s0, ptr %s0, { i64, ptr } %t39)
  store { i64, ptr } %t41, ptr %l8
  br label %bb5
bb5:
  %t42 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l9, !tbaa !24
  %t44 = icmp sge i64 0, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = icmp sle i64 0, 32
  br i1 %t46, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_66bf4c979bf9bab0_63292861daf5748c)
  unreachable
bb8:
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp sle i64 32, %t48
  br i1 %t49, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_66bf4c979bf9bab0_63292861daf5748c)
  unreachable
bb10:
  %t51 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i8, ptr %t52, i64 0
  %t54 = sub i64 32, 0
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %l14, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  store i64 %t59, ptr %l15, !tbaa !24
  %t60 = load i64, ptr %l15, !tbaa !24
  %t61 = mul i64 %t60, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l16, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l15, !tbaa !24
  %t70 = mul i64 %t69, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t66, ptr %t68, i64 %t70, i1 false)
  %t71 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t71, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t72 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_66bf4c979bf9bab0_63292861daf5748c)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fjupyter_2etwo(ptr %v0, i64 %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %s0, i64 %a0, i64 2, i8 48)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t7 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t6)
  call void @olang_textcopy(ptr %t7, ptr %t5, i64 %t6)
  %t8 = insertvalue { i64, ptr } undef, i64 %t6, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr %t7, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fjupyter_3akernel_2ector(ptr %out, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"compiler/jupyter:kernel"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l9, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load i64, ptr %l10, !tbaa !24
  %t5 = mul i64 %t4, 1
  %t6 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l11, !tbaa !27
  %t9 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = mul i64 %t13, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t10, ptr %t12, i64 %t14, i1 false)
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t15, ptr %l1, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2fjupyter_2enewId(ptr %v0)
  store { i64, ptr } %t16, ptr %l12
  br label %bb1
bb1:
  %t17 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l13
  br label %bb2
bb2:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l5
  %t20 = call ptr @__olang_scope_hold(ptr %v0)
  %t21 = ptrtoint ptr %t20 to i64
  store i64 %t21, ptr %l14, !tbaa !24
  %t22 = load i1, ptr @olang_2esole_2ecompiler_2fjupyter_3akernel_2e5
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = call ptr @__olang_region_make(ptr %v0)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l14, !tbaa !24
  br label %bb4
bb4:
  %t26 = load i64, ptr %l14
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t27, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l16
  br label %bb5
bb5:
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2fjupyter_3akernel_2e5
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load i64, ptr %l14
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = call ptr @__olang_region_or(ptr %t35, ptr null)
  %t37 = call ptr @__olang_region_home(ptr %t36)
  %t38 = icmp ne ptr %t37, null
  %t39 = select i1 %t38, ptr %t37, ptr null
  call void @__olang_region_settle_in(ptr %t32, ptr %t39)
  br label %bb7
bb7:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l6
  store i1 false, ptr %l7, !tbaa !21
  %t41 = call ptr @__olang_scope_hold(ptr %v0)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l18, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fjupyter_3akernel_2e7
  br i1 %t43, label %bb8, label %bb9
bb8:
  %t45 = call ptr @__olang_region_make(ptr %v0)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l18, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l18
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fjupyter_3apending_3e_2ector(ptr %t48, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l20
  br label %bb10
bb10:
  %t50 = load i1, ptr @olang_2esole_2ecompiler_2fjupyter_3akernel_2e7
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t52 = load i64, ptr %l18
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20, i32 0, i32 0
  %t55 = load { i64, ptr }, ptr %t54
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = call ptr @__olang_region_or(ptr %t56, ptr null)
  %t58 = call ptr @__olang_region_home(ptr %t57)
  %t59 = icmp ne ptr %t58, null
  %t60 = select i1 %t59, ptr %t58, ptr null
  call void @__olang_region_settle_in(ptr %t53, ptr %t60)
  br label %bb12
bb12:
  %t61 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  %t62 = getelementptr %"compiler/jupyter:kernel", ptr %l22, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t63, ptr %t62, !tbaa !27
  %t64 = getelementptr %"compiler/jupyter:kernel", ptr %l22, i32 0, i32 1
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t65, ptr %t64, !tbaa !27
  %t66 = getelementptr %"compiler/jupyter:kernel", ptr %l22, i32 0, i32 2
  %t67 = load i64, ptr %l3, !tbaa !24
  store i64 %t67, ptr %t66, !tbaa !24
  %t68 = getelementptr %"compiler/jupyter:kernel", ptr %l22, i32 0, i32 3
  %t69 = load i64, ptr %l4, !tbaa !24
  store i64 %t69, ptr %t68, !tbaa !24
  %t70 = getelementptr %"compiler/jupyter:kernel", ptr %l22, i32 0, i32 4
  %t71 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %t70
  %t72 = getelementptr %"compiler/jupyter:kernel", ptr %l22, i32 0, i32 5
  %t73 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %t72
  %t74 = getelementptr %"compiler/jupyter:kernel", ptr %l22, i32 0, i32 6
  %t75 = load i1, ptr %l7, !tbaa !21
  store i1 %t75, ptr %t74, !tbaa !21
  %t76 = getelementptr %"compiler/jupyter:kernel", ptr %l22, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %t76
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l22, i64 152, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/jupyter:pending" @compiler_2fjupyter_3apending_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca %"compiler/jupyter:pending"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/jupyter:pending" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/jupyter:pending" %t6, { i64, ptr } %a1, 1
  store %"compiler/jupyter:pending" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/jupyter:pending", ptr %rv
  ret %"compiler/jupyter:pending" %rr
}

define dso_local %"compiler/jupyter:request" @compiler_2fjupyter_3arequest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/jupyter:request"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/jupyter:request" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/jupyter:request" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/jupyter:request" %t10, { i64, ptr } %a2, 2
  store %"compiler/jupyter:request" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/jupyter:request", ptr %rv
  ret %"compiler/jupyter:request" %rr
}

@.d0 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"{\22text/plain\22:" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"image/png" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d5 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"JUPYTER_DATA_DIR" }>, align 8
declare void @__olang_errpay_pop()
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"HOME" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d10 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"/.local/share/jupyter" }>, align 8
@.d11 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/kernels/olang" }>, align 8
declare ptr @__olang_errpay_top_get()
define linkonce_odr { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fos_3aError_7d(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [2 x i64] } }
  %l3 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, [2 x i64] } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i32, { i64, [2 x i64] } }, ptr %a0
  store { i32, { i64, [2 x i64] } } %t2, ptr %l1
  %t3 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  %t5 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %t3)
  store { i64, [2 x i64] } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  store { i64, [2 x i64] } %t6, ptr %t7
  %t8 = load { i32, { i64, [2 x i64] } }, ptr %l1
  store { i32, { i64, [2 x i64] } } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

@.d12 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"cannot make " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
declare void @__olang_sb_done(ptr)
@.d14 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d15 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
declare i64 @__olang_rd_quote(ptr, i64, ptr, i64, i8)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d18 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d19 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d20 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d21 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d22 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d23 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@.d24 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", \22-quick\22" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", \22-checked\22" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"{\0A  \22argv\22: [" }>, align 8
@.d29 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", \22serve\22, \22jupyter\22" }>, align 8
@.d30 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c", \22{connection_file}\22],\0A  \22display_name\22: \22olang\22,\0A" }>, align 8
@.d31 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"  \22language\22: \22olang\22,\0A  \22interrupt_mode\22: \22message\22\0A}\0A" }>, align 8
@.d32 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"/kernel.json" }>, align 8
@.d33 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"cannot write " }>, align 8
@.d34 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/kernel.json: " }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d36 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d39 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d40 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d41 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d42 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d43 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d44 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
@.d45 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"olang serve jupyter: the kernel is installed at " }>, align 8
@.d46 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"/kernel.json - pick \22olang\22 in a notebook\0A" }>, align 8
@.d47 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"cannot read the connection file " }>, align 8
@.d48 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d49 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d50 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotFound" }>, align 8
@.d51 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d53 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Exists" }>, align 8
@.d54 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Denied" }>, align 8
@.d55 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.NotDir" }>, align 8
@.d56 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"os.Error.IsDir" }>, align 8
@.d57 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"os.Error.NotEmpty" }>, align 8
@.d58 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"os.Error.Failed" }>, align 8
define linkonce_odr { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fjson_3aError_7d(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [2 x i64] } }
  %l3 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, [2 x i64] } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i32, { i64, [2 x i64] } }, ptr %a0
  store { i32, { i64, [2 x i64] } } %t2, ptr %l1
  %t3 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  %t5 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %v0, ptr %t3)
  store { i64, [2 x i64] } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  store { i64, [2 x i64] } %t6, ptr %t7
  %t8 = load { i32, { i64, [2 x i64] } }, ptr %l1
  store { i32, { i64, [2 x i64] } } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

@.d59 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"the connection file is no JSON: " }>, align 8
@.d60 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d61 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"json.Error.Unexpected" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d63 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d65 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"json.Error.Unterminated" }>, align 8
@.d66 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"json.Error.BadEscape" }>, align 8
@.d67 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"json.Error.BadNumber" }>, align 8
@.d68 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"json.Error.BadUtf8" }>, align 8
@.d69 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"json.Error.Trailing" }>, align 8
@.d70 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"json.Error.Depth" }>, align 8
@.d71 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"json.Error.Missing" }>, align 8
@.d72 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"json.Error.WrongKind" }>, align 8
@.d73 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"json.Error.Uneven" }>, align 8
@.d74 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ip" }>, align 8
@.d75 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"127.0.0.1" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fjupyter_3akernel_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
@.d76 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"key" }>, align 8
@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_scope_register_dtor(ptr, ptr, ptr)
define linkonce_odr void @olang_2emir_2eHelperKind_2eDrop_2ecompiler_2fjupyter_3akernel_rt(ptr %inst, ptr %scope) #0 {
entry:
  call void @olang_2emir_2eHelperKind_2eDrop_2ecompiler_2fjupyter_3akernel(ptr %scope, ptr %inst)
  ret void
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d78 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"the connection file has no " }>, align 8
@.d79 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d80 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d81 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"json.Error.Unexpected" }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d83 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d84 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d85 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"json.Error.Unterminated" }>, align 8
@.d86 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"json.Error.BadEscape" }>, align 8
@.d87 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"json.Error.BadNumber" }>, align 8
@.d88 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"json.Error.BadUtf8" }>, align 8
@.d89 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"json.Error.Trailing" }>, align 8
@.d90 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"json.Error.Depth" }>, align 8
@.d91 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"json.Error.Missing" }>, align 8
@.d92 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"json.Error.WrongKind" }>, align 8
@.d93 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"json.Error.Uneven" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eDrop_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @std_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2edtor(ptr %v0, ptr %a0)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

@.d94 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define linkonce_odr { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fnet_3aError_2e_2332_7d(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [2 x i64] } }
  %l3 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, [2 x i64] } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i32, { i64, [2 x i64] } }, ptr %a0
  store { i32, { i64, [2 x i64] } } %t2, ptr %l1
  %t3 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  %t5 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %v0, ptr %t3)
  store { i64, [2 x i64] } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  store { i64, [2 x i64] } %t6, ptr %t7
  %t8 = load { i32, { i64, [2 x i64] } }, ptr %l1
  store { i32, { i64, [2 x i64] } } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

@.d95 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d96 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"net.Error.Address" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d98 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
define linkonce_odr { i32, { i64, [2 x i64] } } @olang_2emir_2eHelperKind_2eCopy_2eerror_7bstd_2fnet_3aError_7d(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i32, { i64, [2 x i64] } }
  %l3 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, [2 x i64] } }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i32, { i64, [2 x i64] } }, ptr %a0
  store { i32, { i64, [2 x i64] } } %t2, ptr %l1
  %t3 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  %t5 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %v0, ptr %t3)
  store { i64, [2 x i64] } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, [2 x i64] }, ptr %l3
  %t7 = getelementptr { i32, { i64, [2 x i64] } }, ptr %l1, i32 0, i32 1
  store { i64, [2 x i64] } %t6, ptr %t7
  %t8 = load { i32, { i64, [2 x i64] } }, ptr %l1
  store { i32, { i64, [2 x i64] } } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, [2 x i64] } }, ptr %rv
  ret { i32, { i64, [2 x i64] } } %rr
}

@.d99 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"cannot listen at " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2estd_2fnet_3aAddr(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = call ptr @__olang_scope_of(ptr %t2, ptr null)
  %t4 = call ptr @__olang_scope_hold(ptr %t3)
  %t5 = ptrtoint ptr %t4 to i64
  %t7 = inttoptr i64 %t5 to ptr
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = call { i64, ptr } @std_2fnet_2estd_2fnet_3aAddr_2eStr(ptr %t7, ptr %s1, ptr %t8)
  store { i64, ptr } %t9, ptr %l3
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 1
  %t12 = extractvalue { i64, ptr } %t10, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

@.d100 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d101 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d102 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"net.Error.Refused" }>, align 8
@.d103 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"net.Error.InUse" }>, align 8
@.d104 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"net.Error.Timeout" }>, align 8
@.d105 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"net.Error.Reset" }>, align 8
@.d106 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"net.Error.Unreachable" }>, align 8
@.d107 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"net.Error.Address" }>, align 8
@.d108 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d109 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d110 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"net.Error.UnknownHost" }>, align 8
@.d111 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"net.Error.Closed" }>, align 8
@.d112 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"net.Error.Denied" }>, align 8
@.d113 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"net.Error.Failed" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_114(ptr %env) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2einterrupted(ptr %vc0, ptr %cv0)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  store i1 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare i32 @dup2(i32, i32)
declare i32 @close(i32)
declare i64 @lseek(i32, i64, i32)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_check_failed(ptr) cold noreturn
declare i64 @read(i32, ptr, i64)
@.d115 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"code" }>, align 8
@.d116 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"silent" }>, align 8
@.d117 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"{\22code\22:" }>, align 8
@.d118 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c",\22execution_count\22:" }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d120 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"execute_input" }>, align 8
@.d121 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"In[" }>, align 8
@.d122 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d123 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"silent" }>, align 8
@.d124 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"stdout" }>, align 8
@.d125 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d126 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"stderr" }>, align 8
@.d127 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"{\22execution_count\22:" }>, align 8
@.d128 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c",\22data\22:" }>, align 8
@.d129 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c",\22metadata\22:{}}" }>, align 8
@.d130 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"execute_result" }>, align 8
@.d131 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d132 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"{\22status\22:\22ok\22,\22execution_count\22:" }>, align 8
@.d133 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c",\22user_expressions\22:{},\22payload\22:[]}" }>, align 8
@.d134 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"execute_reply" }>, align 8
@.d135 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"RuntimeError" }>, align 8
@.d136 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"CompileError" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d138 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22ename\22:\22" }>, align 8
@.d139 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"\22,\22evalue\22:" }>, align 8
@.d140 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c",\22traceback\22:[" }>, align 8
@.d141 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d142 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d143 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d144 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"error" }>, align 8
@.d145 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"{\22status\22:\22error\22,\22execution_count\22:" }>, align 8
@.d146 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d147 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d148 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"execute_reply" }>, align 8
@.d149 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"status" }>, align 8
@.d150 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"{\22execution_state\22:\22busy\22}" }>, align 8
@.d151 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"kernel_info_request" }>, align 8
@.d152 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"kernel_info_reply" }>, align 8
@.d153 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"execute_request" }>, align 8
@.d154 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"is_complete_request" }>, align 8
@.d155 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"code" }>, align 8
@.d156 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"is_complete_reply" }>, align 8
@.d157 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"complete_request" }>, align 8
@.d158 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"complete_reply" }>, align 8
@.d159 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"inspect_request" }>, align 8
@.d160 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"inspect_reply" }>, align 8
@.d161 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"{\22status\22:\22ok\22,\22found\22:false,\22data\22:{},\22metadata\22:{}}" }>, align 8
@.d162 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"history_request" }>, align 8
@.d163 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"history_reply" }>, align 8
@.d164 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"{\22status\22:\22ok\22,\22history\22:[]}" }>, align 8
@.d165 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"comm_info_request" }>, align 8
@.d166 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"comm_info_reply" }>, align 8
@.d167 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"{\22status\22:\22ok\22,\22comms\22:{}}" }>, align 8
@.d168 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"interrupt_request" }>, align 8
@.d169 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"interrupt_reply" }>, align 8
@.d170 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"{\22status\22:\22ok\22}" }>, align 8
@.d171 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"shutdown_request" }>, align 8
@.d172 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"restart" }>, align 8
@.d173 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"{\22status\22:\22ok\22,\22restart\22:" }>, align 8
@.c174 = private unnamed_addr constant [5 x i8] c"true\00"
@.c175 = private unnamed_addr constant [6 x i8] c"false\00"
@.d176 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d177 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"shutdown_reply" }>, align 8
@.d178 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"status" }>, align 8
@.d179 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"{\22execution_state\22:\22idle\22}" }>, align 8
@.d180 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"{\22msg_id\22:\22" }>, align 8
@.d181 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d182 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"\22,\22session\22:\22" }>, align 8
@.d183 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"\22,\22username\22:\22olang\22,\22date\22:\22" }>, align 8
@.d184 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22,\22msg_type\22:\22" }>, align 8
@.d185 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"\22,\22version\22:\22" }>, align 8
@.d186 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22}" }>, align 8
define linkonce_odr %"compiler/jupyter:pending" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fjupyter_3apending(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/jupyter:pending"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"compiler/jupyter:pending"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/jupyter:pending", ptr %a0
  store %"compiler/jupyter:pending" %t2, ptr %l1
  %t3 = getelementptr %"compiler/jupyter:pending", ptr %l1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"compiler/jupyter:pending", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"compiler/jupyter:pending", ptr %l1
  store %"compiler/jupyter:pending" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/jupyter:pending", ptr %rv
  ret %"compiler/jupyter:pending" %rr
}

@.d187 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"interrupt_request" }>, align 8
@.d188 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"shutdown_request" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_201_3e_2e_2d1 = weak hidden constant i1 false
@__olang_slot_chunk = external global %olang.chunk
@.d189 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"kernel." }>, align 8
@.d190 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_3e_2e_2d1 = weak hidden constant i1 false
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t12 = alloca %olang.slotscope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 16
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  %t8 = call ptr @__olang_scope_hold(ptr %v0)
  %t9 = ptrtoint ptr %t8 to i64
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_3e_2e_2d1
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %v0
  %t14 = icmp eq ptr %t13, @__olang_slot_chunk
  %t15 = getelementptr %olang.scope, ptr %v0, i32 0, i32 2
  %t16 = load ptr, ptr %t15
  %t17 = select i1 %t14, ptr %t16, ptr %v0
  store %olang.scope zeroinitializer, ptr %t12
  store ptr @__olang_slot_chunk, ptr %t12
  %t18 = getelementptr %olang.scope, ptr %t12, i32 0, i32 2
  store ptr %t17, ptr %t18
  %t19 = getelementptr %olang.slotscope, ptr %t12, i32 0, i32 1
  store i64 0, ptr %t19
  %t20 = ptrtoint ptr %t12 to i64
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store i64 0, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp slt i64 %t21, %t22
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %t27, i64 %t25
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !37
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %t32, i64 %t30
  store { i64, ptr } %t29, ptr %t33, !tbaa !37
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %t36, i64 %t34
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !37
  %t39 = extractvalue { i64, ptr } %t38, 0
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb6, label %bb7
bb5:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t43, ptr %rv
  br label %ret
bb6:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %t46, i64 %t44
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !37
  store { i64, ptr } %t48, ptr %l9, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l10, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = load i64, ptr %l3
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call ptr @__olang_held_alloc(ptr %t54, i64 %t52)
  %t56 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l11, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l10, !tbaa !24
  %t63 = mul i64 %t62, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %t61, i64 %t63, i1 false)
  %t64 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %t67, i64 %t65
  store { i64, ptr } %t64, ptr %t68, !tbaa !37
  br label %bb8
bb7:
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %t71, i64 %t69
  store { i64, ptr } zeroinitializer, ptr %t72, !tbaa !37
  br label %bb8
bb8:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t73, 1
  store i64 %t74, ptr %l5, !tbaa !24
  br label %bb3
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr %"compiler/jupyter:request" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fjupyter_3arequest(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/jupyter:request"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %rv = alloca %"compiler/jupyter:request"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/jupyter:request", ptr %a0
  store %"compiler/jupyter:request" %t2, ptr %l1
  %t3 = getelementptr %"compiler/jupyter:request", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"compiler/jupyter:request", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = getelementptr %"compiler/jupyter:request", ptr %l1, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = getelementptr %"compiler/jupyter:request", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  %t26 = getelementptr %"compiler/jupyter:request", ptr %l1, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l8, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l9, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t42 = getelementptr %"compiler/jupyter:request", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t41, ptr %t42, !tbaa !27
  %t43 = load %"compiler/jupyter:request", ptr %l1
  store %"compiler/jupyter:request" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/jupyter:request", ptr %rv
  ret %"compiler/jupyter:request" %rr
}

@.d191 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d192 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"{\22name\22:\22" }>, align 8
@.d193 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22,\22text\22:" }>, align 8
@.d194 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d195 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"stream" }>, align 8
@.d196 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"code" }>, align 8
@.d197 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"cursor_pos" }>, align 8
@.d198 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d199 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"text " }>, align 8
@.d200 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d201 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d202 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"{\22status\22:\22ok\22,\22matches\22:[" }>, align 8
@.d203 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"],\22cursor_start\22:" }>, align 8
@.d204 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c",\22cursor_end\22:" }>, align 8
@.d205 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c",\22metadata\22:{}}" }>, align 8
@.d206 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"{\22status\22:\22incomplete\22,\22indent\22:\22    \22}" }>, align 8
@.d207 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"{\22status\22:\22complete\22}" }>, align 8
@.d208 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d209 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"T" }>, align 8
@.d210 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d211 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d212 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"Z" }>, align 8
@.d213 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"{\22status\22:\22ok\22,\22protocol_version\22:\22" }>, align 8
@.d214 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"\22,\22implementation\22:\22olang\22," }>, align 8
@.d215 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"\22implementation_version\22:\221\22,\22language_info\22:{\22name\22:\22olang\22,\22version\22:\221\22," }>, align 8
@.d216 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"\22mimetype\22:\22text/x-olang\22,\22file_extension\22:\22.olang\22}," }>, align 8
@.d217 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c"\22banner\22:\22olang - each cell runs in one session, as at the prompt (B22)\22,\22help_links\22:[]}" }>, align 8
declare i32 @getpid()
@.d218 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2ecompiler_2fjupyter_3akernel_2e5 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
@olang_2esole_2ecompiler_2fjupyter_3akernel_2e7 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fos_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 7}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { { i64, ptr } }, ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, ptr } }, ptr %t42, i32 0, i32 0
  store { i64, ptr } %t41, ptr %t43
  br label %bb1
bb4:
  %t44 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t45 = getelementptr { { i64, ptr } }, ptr %t44, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45
  store { i64, ptr } %t46, ptr %l9, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  store i64 %t48, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = mul i64 %t49, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  %t52 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l11, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = load i64, ptr %l10, !tbaa !24
  %t59 = mul i64 %t58, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t55, ptr %t57, i64 %t59, i1 false)
  %t60 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t61 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t62 = getelementptr { { i64, ptr } }, ptr %t61, i32 0, i32 0
  store { i64, ptr } %t60, ptr %t62
  br label %bb1
bb5:
  %t63 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t64 = getelementptr { { i64, ptr } }, ptr %t63, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64
  store { i64, ptr } %t65, ptr %l12, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l13, !tbaa !24
  %t68 = load i64, ptr %l13, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l14, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l13, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t80 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t81 = getelementptr { { i64, ptr } }, ptr %t80, i32 0, i32 0
  store { i64, ptr } %t79, ptr %t81
  br label %bb1
bb6:
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t83 = getelementptr { { i64, ptr } }, ptr %t82, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83
  store { i64, ptr } %t84, ptr %l15, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l16, !tbaa !24
  %t88 = mul i64 %t87, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l17, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l16, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  %t98 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t99 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t100 = getelementptr { { i64, ptr } }, ptr %t99, i32 0, i32 0
  store { i64, ptr } %t98, ptr %t100
  br label %bb1
bb7:
  %t101 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t102 = getelementptr { { i64, ptr } }, ptr %t101, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102
  store { i64, ptr } %t103, ptr %l18, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l19, !tbaa !24
  %t106 = load i64, ptr %l19, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l20, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l19, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t118 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t119 = getelementptr { { i64, ptr } }, ptr %t118, i32 0, i32 0
  store { i64, ptr } %t117, ptr %t119
  br label %bb1
bb8:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t121 = getelementptr { { i64, ptr } }, ptr %t120, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l21, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l22, !tbaa !24
  %t125 = load i64, ptr %l22, !tbaa !24
  %t126 = mul i64 %t125, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t126)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  store { i64, ptr } %t129, ptr %l23, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = load i64, ptr %l22, !tbaa !24
  %t135 = mul i64 %t134, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t131, ptr %t133, i64 %t135, i1 false)
  %t136 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t137 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t138 = getelementptr { { i64, ptr } }, ptr %t137, i32 0, i32 0
  store { i64, ptr } %t136, ptr %t138
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

declare ptr @__olang_sb_grow(ptr, i64) noinline
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 10}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  br label %bb1
bb3:
  br label %bb1
bb4:
  br label %bb1
bb5:
  br label %bb1
bb6:
  br label %bb1
bb7:
  br label %bb1
bb8:
  br label %bb1
bb9:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr void @olang_2emir_2eHelperKind_2eDrop_2ecompiler_2fjupyter_3akernel(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t2 = getelementptr %"compiler/jupyter:kernel", ptr %a0, i32 0, i32 4
  call void @olang_2emir_2eHelperKind_2eDrop_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %t2)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fnet_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 10}
  switch i64 %t3, label %bb1 [ i64 5, label %bb2 i64 6, label %bb3 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
bb3:
  %t25 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t26 = getelementptr { { i64, ptr } }, ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  store { i64, ptr } %t27, ptr %l6, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t43 = getelementptr { { i64, ptr } }, ptr %t42, i32 0, i32 0
  store { i64, ptr } %t41, ptr %t43
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

declare ptr @__olang_scope_of(ptr, ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define linkonce_odr void @olang_2emir_2eHelperKind_2eDrop_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @std_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2edtor(ptr %v0, ptr %a0)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fjupyter_2eQ(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fbase64_2eEncode(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fjupyter_2efail(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fio_2ePut_3cstd_2fprelude_2ftext_3aString_3e({ i64, ptr } %a0)
declare void @compiler_2fsession_2eIgnoreBrokenPipes()
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2fjupyter_2ePortKeys = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %v0, ptr %a0)
declare { i32, %"std/net:Addr" } @std_2fnet_2eAddr_2eParse(ptr %v0, { i64, ptr } %a0)
declare { i32, %"std/net:Listener" } @std_2fnet_2eListener_2eListen(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2ePush_3cstd_2fnet_3aListener_3e(ptr %v0, ptr %a0, %"std/net:Listener" %a1)
declare void @compiler_2fprompt_3aSession_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2eView_3cstd_2fnet_3aListener_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fnet_2estd_2fnet_3aListener_2eFd(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eView_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fzmtp_2estd_2fzmtp_3aSocket_2eFd(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2eView_3cI32_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fnet_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2eLen_3cstd_2fnet_3aListener_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2eRefMut_3cstd_2fnet_3aListener_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fjupyter_3apending_3e_2eLen__H3ed9013f6604c7fc0e46a0318571cb25(ptr %v0, ptr %a0)
declare { i32, %"compiler/jupyter:pending" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fjupyter_3apending_3e_2eTake_H6fdf3e54d655bfcfaddc15fb1412c3ad(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eEnd(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_c63743b1fec4c0d4_43198d06044e4ff0 = external constant [0 x i8]
@olang_loc_69a6c85b3d3b36f9_8c1f3e3900689b5d = external constant [0 x i8]
@olang_loc_df7b1c0fb7414e5a_53e9012a4cdfda7e = external constant [0 x i8]
@G_2ecompiler_2fjupyter_2eKinds = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare { i32, %"std/zmtp:Socket" } @std_2fzmtp_2eSocket_2eAccept(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2ePush_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %v1, ptr %a0, %"std/zmtp:Socket" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fjupyter_2estr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i32, i1 } @std_2fjson_2estd_2fjson_3aJson_2eAsBool(ptr %v0, ptr %a0)
declare %"compiler/jupyter:Capture" @compiler_2fjupyter_3aCapture_2ector(ptr %v0, i32 %a0)
declare void @compiler_2fprompt_2ecompiler_2fprompt_3aSession_2eCell(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2ereply(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fjupyter_2eFirstLine(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fjupyter_2eHeartbeat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eRefMut_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fzmtp_2estd_2fzmtp_3aSocket_2eSend(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2fjupyter_2eShell = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fjupyter_2eControl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fjupyter_2ekindOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_62bbb1ef982cce0d_1ddca4bbad92f791 = external constant [0 x i8]
@G_2ecompiler_2fjupyter_2eProtocol = external constant <{ [8 x i8], ptr }>
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eLen_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eRef_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @std_2fzmtp_2estd_2fzmtp_3aSocket_2eFill(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fzmtp_2estd_2fzmtp_3aSocket_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fjupyter_3apending_3e_2ePush_H6843df326b132ec5af167b6d6aa0ee91(ptr %v0, ptr %v1, ptr %a0, %"compiler/jupyter:pending" %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fjupyter_3apending_3e_2eRef__H00d3a79bbb7d8106151b81913e117b7b(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2eframes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
@G_2ecompiler_2fjupyter_2eIOPub = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fjupyter_2eDelimiter = external constant <{ [8 x i8], ptr }>
declare { i64, ptr } @compiler_2fjupyter_2ecompiler_2fjupyter_3akernel_2esign(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2eRemoveAt_3cstd_2fzmtp_3aSocket_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_a3bb6ba411f5318_f8f719f7dabe5f3c = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aDecl_3e_2eView_3ccompiler_2fprompt_3aDecl_3e(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a638196a2ff6a75_60555f0a368b3729 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprompt_3aValue_3e_2eView_3ccompiler_2fprompt_3aValue_3e(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2fjupyter_2eKeywords = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H563b551a62b57e684177c5454e33a204(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H2b85ceff512af6e6ca26c554a1c16247(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i1 @compiler_2fprompt_2eOpen(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2ftime_2eWall()
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i64 @std_2ftime_2eNow()
declare { i64, ptr } @std_2fsha256_2eSum(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fhex_2eEncode(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_66bf4c979bf9bab0_63292861daf5748c = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %v0, i64 %a0, i64 %a1, i8 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fjupyter_3apending_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_3aVec_3cstd_2fnet_3aListener_3e_2edtor(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fnet_2estd_2fnet_3aAddr_2eStr(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare void @std_2fprelude_2fvec_3aVec_3cstd_2fzmtp_3aSocket_3e_2edtor(ptr %v0, ptr %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
