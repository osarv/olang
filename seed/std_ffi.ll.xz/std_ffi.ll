; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
define dso_local i8 @std_2fffi_2eArrayOf(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca i8
  %l3 = alloca i8
  %s0 = alloca %olang.scope
  %rv = alloca i8
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l1
  %t2 = load i32, ptr %l1
  %t3 = call i8 @std_2fffi_2eCode(i32 %t2)
  store i8 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i8, ptr %l2
  %t5 = or i8 %t4, -128
  store i8 %t5, ptr %l3
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i8, ptr %l3
  store i8 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local { i32, i64 } @std_2fffi_2eCall(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i8 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i8
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i8
  %l28 = alloca i8
  %l29 = alloca i1
  %l30 = alloca i32
  %l31 = alloca i8
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i32
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i8
  %l59 = alloca i8
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca i1
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca i8
  %l89 = alloca i64
  %l90 = alloca i8
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca i8
  %l99 = alloca i32
  %l100 = alloca i32
  %l101 = alloca i1
  %l102 = alloca i32
  %l103 = alloca i32
  %l104 = alloca i1
  %l105 = alloca i32
  %l106 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i8
  %l112 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.builder
  %s12room = alloca [64 x i8], align 8
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i8 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l4
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t1, ptr %l18
  %t2 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t2, ptr %l5
  store i64 0, ptr %l6
  %t3 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t3, ptr %l19
  %t4 = load { i64, ptr }, ptr %l19
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l20
  %t6 = load i64, ptr %l20
  store i64 %t6, ptr %l7
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l6
  store i64 %t7, ptr %l21
  %t8 = load i64, ptr %l7
  store i64 %t8, ptr %l22
  %t9 = load i64, ptr %l21
  %t10 = load i64, ptr %l22
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l23
  %t12 = load i1, ptr %l23
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l24
  %t14 = load i1, ptr %l24
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t15, ptr %l25
  %t16 = load i64, ptr %l6
  store i64 %t16, ptr %l26
  %t17 = load i64, ptr %l26
  %t18 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  %t20 = getelementptr i8, ptr %t19, i64 %t17
  %t21 = load i8, ptr %t20
  store i8 %t21, ptr %l27
  %t22 = load i8, ptr %l27
  store i8 %t22, ptr %l8
  %t23 = load i8, ptr %l8
  store i8 %t23, ptr %l28
  %t24 = load i8, ptr %l28
  %t25 = icmp eq i8 %t24, 0
  store i1 %t25, ptr %l29
  %t26 = load i1, ptr %l29
  br i1 %t26, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 65538, ptr %l30
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l30
  %t28 = insertvalue { i32, i64 } zeroinitializer, i32 %t27, 0
  store { i32, i64 } %t28, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t29 = load i8, ptr %l8
  store i8 %t29, ptr %l31
  %t30 = load i8, ptr %l31
  %t31 = icmp ult i8 %t30, -128
  store i1 %t31, ptr %l32
  %t32 = load i1, ptr %l32
  br i1 %t32, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t33 = load i64, ptr %l4
  store i64 %t33, ptr %l33
  %t34 = load i64, ptr %l33
  %t35 = add i64 %t34, 1
  store i64 %t35, ptr %l34
  %t36 = load i64, ptr %l34
  store i64 %t36, ptr %l4
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l4
  store i64 %t37, ptr %l35
  %t38 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t38, ptr %l36
  %t39 = load { i64, ptr }, ptr %l36
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l37
  %t41 = load i64, ptr %l35
  %t42 = load i64, ptr %l37
  %t43 = icmp sge i64 %t41, %t42
  store i1 %t43, ptr %l38
  %t44 = load i1, ptr %l38
  br i1 %t44, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  store i32 65538, ptr %l39
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load i32, ptr %l39
  %t46 = insertvalue { i32, i64 } zeroinitializer, i32 %t45, 0
  store { i32, i64 } %t46, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t47 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t47, ptr %l40
  %t48 = load i64, ptr %l4
  store i64 %t48, ptr %l41
  %t49 = load i64, ptr %l41
  %t50 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  %t52 = getelementptr i64, ptr %t51, i64 %t49
  %t53 = load i64, ptr %t52
  store i64 %t53, ptr %l42
  %t54 = load i64, ptr %l42
  store i64 %t54, ptr %l43
  %t55 = load i64, ptr %l43
  store i64 %t55, ptr %l9
  %t56 = load i64, ptr %l9
  store i64 %t56, ptr %l44
  %t57 = load i64, ptr %l44
  %t58 = icmp slt i64 %t57, 0
  store i1 %t58, ptr %l45
  %t59 = load i1, ptr %l45
  br i1 %t59, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l46
  br label %bb16
bb15:
  %t60 = load i64, ptr %l9
  store i64 %t60, ptr %l47
  %t61 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t61, ptr %l48
  %t62 = load { i64, ptr }, ptr %l48
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l49
  %t64 = load i64, ptr %l4
  store i64 %t64, ptr %l50
  %t65 = load i64, ptr %l49
  %t66 = load i64, ptr %l50
  %t67 = sub i64 %t65, %t66
  store i64 %t67, ptr %l51
  %t68 = load i64, ptr %l51
  %t69 = sub i64 %t68, 1
  store i64 %t69, ptr %l52
  %t70 = load i64, ptr %l52
  %t71 = mul i64 %t70, 8
  store i64 %t71, ptr %l53
  %t72 = load i64, ptr %l47
  %t73 = load i64, ptr %l53
  %t74 = icmp sgt i64 %t72, %t73
  store i1 %t74, ptr %l54
  %t75 = load i1, ptr %l54
  store i1 %t75, ptr %l46
  br label %bb16
bb16:
  %t76 = load i1, ptr %l46
  br i1 %t76, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  store i32 65538, ptr %l55
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i32, ptr %l55
  %t78 = insertvalue { i32, i64 } zeroinitializer, i32 %t77, 0
  store { i32, i64 } %t78, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t79 = load i64, ptr %l4
  store i64 %t79, ptr %l56
  %t80 = load i64, ptr %l9
  store i64 %t80, ptr %l57
  %t81 = load i8, ptr %l8
  store i8 %t81, ptr %l58
  %t82 = load i8, ptr %l58
  %t83 = and i8 %t82, 127
  store i8 %t83, ptr %l59
  %t84 = load i8, ptr %l59
  %t85 = call i64 @std_2fffi_2ewidth(i8 %t84)
  store i64 %t85, ptr %l60
  br label %bb20
bb20:
  %t86 = load i64, ptr %l57
  %t87 = load i64, ptr %l60
  %t88 = mul i64 %t86, %t87
  store i64 %t88, ptr %l61
  %t89 = load i64, ptr %l61
  %t90 = add i64 %t89, 7
  store i64 %t90, ptr %l62
  %t91 = load i64, ptr %l62
  %t92 = sdiv i64 %t91, 8
  store i64 %t92, ptr %l63
  %t93 = load i64, ptr %l63
  %t94 = add i64 1, %t93
  store i64 %t94, ptr %l64
  %t95 = load i64, ptr %l56
  %t96 = load i64, ptr %l64
  %t97 = add i64 %t95, %t96
  store i64 %t97, ptr %l65
  %t98 = load i64, ptr %l65
  store i64 %t98, ptr %l4
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s7
  %t99 = load i64, ptr %l6
  store i64 %t99, ptr %l66
  %t100 = load i64, ptr %l66
  %t101 = add i64 %t100, 1
  store i64 %t101, ptr %l67
  %t102 = load i64, ptr %l67
  store i64 %t102, ptr %l6
  call void @__olang_scope_close(ptr %s7)
  br label %bb1
bb22:
  call void @__olang_scope_close(ptr %s1)
  %t103 = load i64, ptr %l4
  store i64 %t103, ptr %l68
  %t104 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t104, ptr %l69
  %t105 = load { i64, ptr }, ptr %l69
  %t106 = extractvalue { i64, ptr } %t105, 0
  store i64 %t106, ptr %l70
  %t107 = load i64, ptr %l68
  %t108 = load i64, ptr %l70
  %t109 = icmp sgt i64 %t107, %t108
  store i1 %t109, ptr %l71
  %t110 = load i1, ptr %l71
  br i1 %t110, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 65538, ptr %l72
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i32, ptr %l72
  %t112 = insertvalue { i32, i64 } zeroinitializer, i32 %t111, 0
  store { i32, i64 } %t112, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t113 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t113, ptr %l73
  %t114 = load { i64, ptr }, ptr %l73
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l74
  %t116 = load i64, ptr %l74
  %t117 = add i64 %t116, 1
  store i64 %t117, ptr %l75
  %t118 = load i64, ptr %l75
  %t119 = icmp sge i64 %t118, 0
  store i1 %t119, ptr %l76
  %t120 = load i1, ptr %l76
  br i1 %t120, label %bb26, label %bb27
bb26:
  %t121 = load i64, ptr %l75
  %t122 = mul i64 %t121, 1
  %t123 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l77
  %t126 = load { i64, ptr }, ptr %l77
  store { i64, ptr } %t126, ptr %l10
  store %olang.scope zeroinitializer, ptr %s9
  %t127 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t127, ptr %l78
  %t128 = load { i64, ptr }, ptr %l78
  store { i64, ptr } %t128, ptr %l11
  store i64 0, ptr %l12
  %t129 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t129, ptr %l79
  %t130 = load { i64, ptr }, ptr %l79
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l80
  %t132 = load i64, ptr %l80
  store i64 %t132, ptr %l13
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb28:
  store %olang.scope zeroinitializer, ptr %s10
  %t133 = load i64, ptr %l12
  store i64 %t133, ptr %l81
  %t134 = load i64, ptr %l13
  store i64 %t134, ptr %l82
  %t135 = load i64, ptr %l81
  %t136 = load i64, ptr %l82
  %t137 = icmp slt i64 %t135, %t136
  store i1 %t137, ptr %l83
  %t138 = load i1, ptr %l83
  %t139 = xor i1 %t138, true
  store i1 %t139, ptr %l84
  %t140 = load i1, ptr %l84
  br i1 %t140, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s10)
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t141 = load i64, ptr %l12
  store i64 %t141, ptr %l85
  %t142 = load i64, ptr %l85
  store i64 %t142, ptr %l14
  %t143 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t143, ptr %l86
  %t144 = load i64, ptr %l12
  store i64 %t144, ptr %l87
  %t145 = load i64, ptr %l87
  %t146 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t147 = load ptr, ptr %t146
  %t148 = getelementptr i8, ptr %t147, i64 %t145
  %t149 = load i8, ptr %t148
  store i8 %t149, ptr %l88
  %t150 = load i8, ptr %l88
  store i8 %t150, ptr %l15
  %t151 = load i64, ptr %l14
  store i64 %t151, ptr %l89
  %t152 = load i8, ptr %l15
  store i8 %t152, ptr %l90
  %t153 = load i8, ptr %l90
  %t154 = load i64, ptr %l89
  %t155 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t156 = load ptr, ptr %t155
  %t157 = getelementptr i8, ptr %t156, i64 %t154
  store i8 %t153, ptr %t157
  call void @__olang_scope_close(ptr %s10)
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s11
  %t158 = load i64, ptr %l12
  store i64 %t158, ptr %l91
  %t159 = load i64, ptr %l91
  %t160 = add i64 %t159, 1
  store i64 %t160, ptr %l92
  %t161 = load i64, ptr %l92
  store i64 %t161, ptr %l12
  call void @__olang_scope_close(ptr %s11)
  br label %bb28
bb33:
  call void @__olang_scope_close(ptr %s9)
  %t162 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t162, ptr %l93
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s12
  store ptr %s12room, ptr %s12
  %t163 = load { i64, ptr }, ptr %l93
  %t164 = extractvalue { i64, ptr } %t163, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  call void @__olang_sb_put(ptr %s12, ptr %t164, i64 %t165)
  %t166 = extractvalue { i64, ptr } { i64 1, ptr @.d1 }, 1
  %t167 = extractvalue { i64, ptr } { i64 1, ptr @.d1 }, 0
  call void @__olang_sb_put(ptr %s12, ptr %t166, i64 %t167)
  %t168 = load ptr, ptr %s12
  %t169 = getelementptr %olang.builder, ptr %s12, i32 0, i32 1
  %t170 = load i64, ptr %t169
  %t171 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t170)
  call void @llvm.memcpy.p0.p0.i64(ptr %t171, ptr %t168, i64 %t170, i1 false)
  %t172 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  store { i64, ptr } %t173, ptr %l94
  call void @__olang_sb_done(ptr %s12)
  %t174 = load { i64, ptr }, ptr %l94
  store { i64, ptr } %t174, ptr %l16
  %t175 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t175, ptr %l95
  %t176 = load { i64, ptr }, ptr %l95
  store { i64, ptr } %t176, ptr %l96
  %t177 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t177, ptr %l97
  %t178 = load i8, ptr %l3
  store i8 %t178, ptr %l98
  %t179 = load { i64, ptr }, ptr %l96
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = load { i64, ptr }, ptr %l97
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = load i8, ptr %l98
  %t186 = call i32 @__olang_dyncall_check(ptr %t180, ptr %t183, i8 %t185)
  store i32 %t186, ptr %l99
  br label %bb34
bb34:
  %t187 = load i32, ptr %l99
  store i32 %t187, ptr %l17
  %t188 = load i32, ptr %l17
  store i32 %t188, ptr %l100
  %t189 = load i32, ptr %l100
  %t190 = icmp eq i32 %t189, 1
  store i1 %t190, ptr %l101
  %t191 = load i1, ptr %l101
  br i1 %t191, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s13
  store i32 65536, ptr %l102
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t192 = load i32, ptr %l102
  %t193 = insertvalue { i32, i64 } zeroinitializer, i32 %t192, 0
  store { i32, i64 } %t193, ptr %rv
  br label %ret
bb38:
  %t194 = load i32, ptr %l17
  store i32 %t194, ptr %l103
  %t195 = load i32, ptr %l103
  %t196 = icmp eq i32 %t195, 2
  store i1 %t196, ptr %l104
  %t197 = load i1, ptr %l104
  br i1 %t197, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s14
  store i32 65537, ptr %l105
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t198 = load i32, ptr %l105
  %t199 = insertvalue { i32, i64 } zeroinitializer, i32 %t198, 0
  store { i32, i64 } %t199, ptr %rv
  br label %ret
bb42:
  store %olang.scope zeroinitializer, ptr %s15
  call void @__olang_scope_close(ptr %s15)
  br label %bb43
bb43:
  %t200 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t200, ptr %l106
  %t201 = load { i64, ptr }, ptr %l106
  store { i64, ptr } %t201, ptr %l107
  %t202 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t202, ptr %l108
  %t203 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t203, ptr %l109
  %t204 = load { i64, ptr }, ptr %l109
  store { i64, ptr } %t204, ptr %l110
  %t205 = load i8, ptr %l3
  store i8 %t205, ptr %l111
  %t206 = load { i64, ptr }, ptr %l107
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = load { i64, ptr }, ptr %l108
  %t210 = extractvalue { i64, ptr } %t209, 1
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t212 = load { i64, ptr }, ptr %l110
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = load i8, ptr %l111
  %t216 = call i64 @__olang_dyncall(ptr %t207, ptr %t210, ptr %t213, i8 %t215)
  store i64 %t216, ptr %l112
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t217 = load i64, ptr %l112
  %t218 = insertvalue { i32, i64 } zeroinitializer, i64 %t217, 1
  store { i32, i64 } %t218, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i8 @std_2fffi_2eCode(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i8
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i32
  %l25 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i8
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l2
  %t2 = load i32, ptr %l2
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t2, %t3
  store i1 %t4, ptr %l3
  %t5 = load i1, ptr %l3
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store i8 1, ptr %l1
  call void @__olang_scope_close(ptr %s1)
  br label %bb49
bb4:
  %t6 = load i32, ptr %l0
  store i32 %t6, ptr %l4
  %t7 = load i32, ptr %l4
  %t8 = trunc i64 1 to i32
  %t9 = icmp eq i32 %t7, %t8
  store i1 %t9, ptr %l5
  %t10 = load i1, ptr %l5
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store i8 2, ptr %l1
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb8:
  %t11 = load i32, ptr %l0
  store i32 %t11, ptr %l6
  %t12 = load i32, ptr %l6
  %t13 = trunc i64 2 to i32
  %t14 = icmp eq i32 %t12, %t13
  store i1 %t14, ptr %l7
  %t15 = load i1, ptr %l7
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store i8 3, ptr %l1
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb12:
  %t16 = load i32, ptr %l0
  store i32 %t16, ptr %l8
  %t17 = load i32, ptr %l8
  %t18 = trunc i64 3 to i32
  %t19 = icmp eq i32 %t17, %t18
  store i1 %t19, ptr %l9
  %t20 = load i1, ptr %l9
  br i1 %t20, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store i8 4, ptr %l1
  call void @__olang_scope_close(ptr %s4)
  br label %bb49
bb16:
  %t21 = load i32, ptr %l0
  store i32 %t21, ptr %l10
  %t22 = load i32, ptr %l10
  %t23 = trunc i64 4 to i32
  %t24 = icmp eq i32 %t22, %t23
  store i1 %t24, ptr %l11
  %t25 = load i1, ptr %l11
  br i1 %t25, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  store i8 5, ptr %l1
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb20:
  %t26 = load i32, ptr %l0
  store i32 %t26, ptr %l12
  %t27 = load i32, ptr %l12
  %t28 = trunc i64 5 to i32
  %t29 = icmp eq i32 %t27, %t28
  store i1 %t29, ptr %l13
  %t30 = load i1, ptr %l13
  br i1 %t30, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  store i8 6, ptr %l1
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb24:
  %t31 = load i32, ptr %l0
  store i32 %t31, ptr %l14
  %t32 = load i32, ptr %l14
  %t33 = trunc i64 6 to i32
  %t34 = icmp eq i32 %t32, %t33
  store i1 %t34, ptr %l15
  %t35 = load i1, ptr %l15
  br i1 %t35, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store i8 7, ptr %l1
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb28:
  %t36 = load i32, ptr %l0
  store i32 %t36, ptr %l16
  %t37 = load i32, ptr %l16
  %t38 = trunc i64 7 to i32
  %t39 = icmp eq i32 %t37, %t38
  store i1 %t39, ptr %l17
  %t40 = load i1, ptr %l17
  br i1 %t40, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  store i8 8, ptr %l1
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb32:
  %t41 = load i32, ptr %l0
  store i32 %t41, ptr %l18
  %t42 = load i32, ptr %l18
  %t43 = trunc i64 8 to i32
  %t44 = icmp eq i32 %t42, %t43
  store i1 %t44, ptr %l19
  %t45 = load i1, ptr %l19
  br i1 %t45, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s9
  store i8 9, ptr %l1
  call void @__olang_scope_close(ptr %s9)
  br label %bb49
bb36:
  %t46 = load i32, ptr %l0
  store i32 %t46, ptr %l20
  %t47 = load i32, ptr %l20
  %t48 = trunc i64 9 to i32
  %t49 = icmp eq i32 %t47, %t48
  store i1 %t49, ptr %l21
  %t50 = load i1, ptr %l21
  br i1 %t50, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  store i8 10, ptr %l1
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb40:
  %t51 = load i32, ptr %l0
  store i32 %t51, ptr %l22
  %t52 = load i32, ptr %l22
  %t53 = trunc i64 10 to i32
  %t54 = icmp eq i32 %t52, %t53
  store i1 %t54, ptr %l23
  %t55 = load i1, ptr %l23
  br i1 %t55, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s11
  store i8 11, ptr %l1
  call void @__olang_scope_close(ptr %s11)
  br label %bb49
bb44:
  %t56 = load i32, ptr %l0
  store i32 %t56, ptr %l24
  %t57 = load i32, ptr %l24
  %t58 = trunc i64 11 to i32
  %t59 = icmp eq i32 %t57, %t58
  store i1 %t59, ptr %l25
  %t60 = load i1, ptr %l25
  br i1 %t60, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s12
  store i8 12, ptr %l1
  call void @__olang_scope_close(ptr %s12)
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i8, ptr %l1
  store i8 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local i64 @std_2fffi_2eWordsFor(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l1
  %t2 = load i64, ptr %l1
  %t3 = add i64 %t2, 7
  store i64 %t3, ptr %l2
  %t4 = load i64, ptr %l2
  %t5 = sdiv i64 %t4, 8
  store i64 %t5, ptr %l3
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i64, ptr %l3
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fffi_2ewidth(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i1
  %l6 = alloca i8
  %l7 = alloca i1
  %l8 = alloca i8
  %l9 = alloca i1
  %l10 = alloca i8
  %l11 = alloca i1
  %l12 = alloca i8
  %l13 = alloca i1
  %l14 = alloca i8
  %l15 = alloca i1
  %l16 = alloca i8
  %l17 = alloca i1
  %l18 = alloca i8
  %l19 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0
  store i8 %t1, ptr %l2
  %t2 = load i8, ptr %l2
  %t3 = icmp eq i8 %t2, 1
  store i1 %t3, ptr %l3
  %t4 = load i1, ptr %l3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb5
bb2:
  %t5 = load i8, ptr %l0
  store i8 %t5, ptr %l4
  %t6 = load i8, ptr %l4
  %t7 = icmp eq i8 %t6, 5
  store i1 %t7, ptr %l5
  %t8 = load i1, ptr %l5
  br i1 %t8, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 1, ptr %l1
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb6:
  %t9 = load i8, ptr %l0
  store i8 %t9, ptr %l6
  %t10 = load i8, ptr %l6
  %t11 = icmp eq i8 %t10, 2
  store i1 %t11, ptr %l7
  %t12 = load i1, ptr %l7
  br i1 %t12, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  %t13 = load i8, ptr %l0
  store i8 %t13, ptr %l8
  %t14 = load i8, ptr %l8
  %t15 = icmp eq i8 %t14, 6
  store i1 %t15, ptr %l9
  %t16 = load i1, ptr %l9
  br i1 %t16, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t17 = load i8, ptr %l0
  store i8 %t17, ptr %l10
  %t18 = load i8, ptr %l10
  %t19 = icmp eq i8 %t18, 9
  store i1 %t19, ptr %l11
  %t20 = load i1, ptr %l11
  br i1 %t20, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t21 = load i8, ptr %l0
  store i8 %t21, ptr %l12
  %t22 = load i8, ptr %l12
  %t23 = icmp eq i8 %t22, 10
  store i1 %t23, ptr %l13
  %t24 = load i1, ptr %l13
  br i1 %t24, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 2, ptr %l1
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb16:
  %t25 = load i8, ptr %l0
  store i8 %t25, ptr %l14
  %t26 = load i8, ptr %l14
  %t27 = icmp eq i8 %t26, 3
  store i1 %t27, ptr %l15
  %t28 = load i1, ptr %l15
  br i1 %t28, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  %t29 = load i8, ptr %l0
  store i8 %t29, ptr %l16
  %t30 = load i8, ptr %l16
  %t31 = icmp eq i8 %t30, 7
  store i1 %t31, ptr %l17
  %t32 = load i1, ptr %l17
  br i1 %t32, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  %t33 = load i8, ptr %l0
  store i8 %t33, ptr %l18
  %t34 = load i8, ptr %l18
  %t35 = icmp eq i8 %t34, 11
  store i1 %t35, ptr %l19
  %t36 = load i1, ptr %l19
  br i1 %t36, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  store i64 4, ptr %l1
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  store i64 8, ptr %l1
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i64, ptr %l1
  store i64 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare void @__olang_scope_close(ptr)
declare ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [45 x i8] c"std/ffi.olang:97: array length out of range\0A\00"
declare void @__olang_sb_put(ptr, ptr, i64)
@.d1 = private constant [1 x i8] c"\00"
declare ptr @__olang_scope_alloc(ptr, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_sb_done(ptr)
declare i32 @__olang_dyncall_check(ptr, ptr, i8)
declare i64 @__olang_dyncall(ptr, ptr, ptr, i8)
@.c2 = private unnamed_addr constant [44 x i8] c"std/ffi.olang:43: reached unreachable code\0A\00"
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
