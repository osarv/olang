; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/lsp:Server" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"compiler/lsp:Worker", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1 }
%"compiler/lsp:Worker" = type { i32, i32, ptr, i64 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/session:Reader" = type { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/lsp:Doc" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/lsp:worker" = type { ptr, ptr, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/session:Positions" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/session:Found" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/session:Analysis" = type { ptr, ptr, ptr, ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/session:Items" = type { %"std/prelude/text:StringBuilder", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" = type { ptr, i64, ptr, ptr }
%"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" = type { { i64, ptr }, { i64, ptr } }
%"compiler/diag:Item" = type { i1, { i64, ptr }, i64, i64, i64, i64, { i64, ptr } }
@G_2ecompiler_2flsp_2eRequests = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flsp_2eRequests.k1, [8 x i8] c"\17\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flsp_2eRequests.k2, [8 x i8] c"\1B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flsp_2eRequests.k3, [8 x i8] c"\17\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flsp_2eRequests.k4, [8 x i8] c"\17\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flsp_2eRequests.k5 }>, align 64
@G_2ecompiler_2flsp_2eRequests.k1 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\74\65\78\74\44\6F\63\75\6D\65\6E\74\2F\68\6F\76\65\72" }>, align 8
@G_2ecompiler_2flsp_2eRequests.k2 = internal constant <{ [23 x i8] }> <{ [23 x i8] c"\74\65\78\74\44\6F\63\75\6D\65\6E\74\2F\64\65\66\69\6E\69\74\69\6F\6E" }>, align 8
@G_2ecompiler_2flsp_2eRequests.k3 = internal constant <{ [27 x i8] }> <{ [27 x i8] c"\74\65\78\74\44\6F\63\75\6D\65\6E\74\2F\64\6F\63\75\6D\65\6E\74\53\79\6D\62\6F\6C" }>, align 8
@G_2ecompiler_2flsp_2eRequests.k4 = internal constant <{ [23 x i8] }> <{ [23 x i8] c"\74\65\78\74\44\6F\63\75\6D\65\6E\74\2F\63\6F\6D\70\6C\65\74\69\6F\6E" }>, align 8
@G_2ecompiler_2flsp_2eRequests.k5 = internal constant <{ [23 x i8] }> <{ [23 x i8] c"\74\65\78\74\44\6F\63\75\6D\65\6E\74\2F\66\6F\72\6D\61\74\74\69\6E\67" }>, align 8
@G_2ecompiler_2flsp_2eSessionSrc = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\F4\00\00\00\00\00\00\00", ptr @G_2ecompiler_2flsp_2eSessionSrc.k1 }>, align 8
@G_2ecompiler_2flsp_2eSessionSrc.k1 = internal constant <{ [244 x i8] }> <{ [244 x i8] c"\69\6D\70\6F\72\74\20\22\73\74\64\2F\69\6F\22\0A\0A\23\20\61\20\70\6F\69\6E\74\20\6F\6E\20\61\20\70\6C\61\6E\65\0A\74\79\70\65\20\50\6F\69\6E\74\20\73\74\72\75\63\74\28\58\20\49\36\34\2C\20\59\20\49\36\34\29\20\7B\0A\20\20\20\20\58\0A\20\20\20\20\59\0A\7D\0A\0A\23\20\74\68\65\20\73\75\6D\20\6F\66\20\61\20\70\6F\69\6E\74\27\73\20\63\6F\6F\72\64\69\6E\61\74\65\73\0A\66\6E\20\73\75\6D\28\70\20\50\6F\69\6E\74\29\20\49\36\34\20\7B\0A\20\20\20\20\72\65\74\75\72\6E\20\70\2E\58\2B\70\2E\59\0A\7D\0A\0A\66\6E\20\6D\61\69\6E\28\29\20\7B\0A\20\20\20\20\71\20\3A\3D\20\50\6F\69\6E\74\28\31\2C\20\32\29\0A\20\20\20\20\69\6F\2E\50\72\69\6E\74\6C\6E\28\24\73\75\6D\28\71\29\29\21\0A\20\20\20\20\62\61\64\20\49\33\32\20\3D\20\22\78\22\0A\7D\0A" }>, align 64
@G_2ecompiler_2flsp_2eSettleNs = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\5A\62\02\00\00\00\00" }>, align 8
@G_2ecompiler_2flsp_2eStuckNs = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\58\47\F8\0D\00\00\00" }>, align 8
define dso_local { i64, ptr } @compiler_2flsp_2ePathOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i1
  %l10 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l38 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca i64
  %l49 = alloca i32
  %l58 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t9, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 0
  store i64 %t19, ptr %l13, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l14, !tbaa !24
  %t22 = icmp sge i64 7, 0
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = icmp sle i64 7, %t24
  br i1 %t25, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6756d46c47226ab9_ec8477bb3ab165)
  unreachable
bb7:
  %t27 = load i64, ptr %l13, !tbaa !24
  %t28 = load i64, ptr %l14, !tbaa !24
  %t29 = icmp sle i64 %t27, %t28
  br i1 %t29, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_6756d46c47226ab9_ec8477bb3ab165)
  unreachable
bb9:
  %t31 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = getelementptr i8, ptr %t32, i64 7
  %t35 = sub i64 %t33, 7
  %t36 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t34, 1
  store { i64, ptr } %t37, ptr %l1, !tbaa !27
  %t39 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t39, ptr %l19
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_6756d46c47226ab9_ec8477bb3ab165)
  unreachable
bb11:
  %t40 = load %"std/prelude/text:StringBuilder", ptr %l19
  store %"std/prelude/text:StringBuilder" %t40, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t47 = icmp slt i64 %t41, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb14:
  br label %bb15
bb15:
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t51, ptr %l25, !tbaa !27
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t52
  %t57 = load i8, ptr %t56, !tbaa !32
  %t59 = icmp eq i8 %t57, 37
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = add i64 %t61, 2
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t69 = icmp slt i64 %t63, %t66
  store i1 %t69, ptr %l29, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t71 = load i1, ptr %l29, !tbaa !21
  br i1 %t71, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t72, ptr %l36, !tbaa !27
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l38, !tbaa !24
  %t76 = load i64, ptr %l3, !tbaa !24
  %t78 = add i64 %t76, 3
  store i64 %t78, ptr %l40, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l41, !tbaa !24
  %t81 = load i64, ptr %l38, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  br i1 %t82, label %bb21, label %bb22
bb20:
  br label %bb37
bb21:
  %t84 = load i64, ptr %l38, !tbaa !24
  %t85 = load i64, ptr %l40, !tbaa !24
  %t86 = icmp sle i64 %t84, %t85
  br i1 %t86, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_78ef8a2f2ef3c68c_b23277b974982b08)
  unreachable
bb23:
  %t88 = load i64, ptr %l40, !tbaa !24
  %t89 = load i64, ptr %l41, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_78ef8a2f2ef3c68c_b23277b974982b08)
  unreachable
bb25:
  %t92 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l38, !tbaa !24
  %t95 = load i64, ptr %l40, !tbaa !24
  %t96 = getelementptr i8, ptr %t93, i64 %t94
  %t97 = sub i64 %t95, %t94
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  store { i64, ptr } %t99, ptr %l45, !tbaa !27
  %t100 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 16)
  %t101 = extractvalue { i32, i64 } %t100, 1
  %t102 = extractvalue { i32, i64 } %t100, 0
  store i32 %t102, ptr %l47
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb28, label %ok.104
ok.104:
  store i64 %t101, ptr %l46
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_78ef8a2f2ef3c68c_b23277b974982b08)
  unreachable
bb27:
  %t105 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t106 = load i64, ptr %l46, !tbaa !24
  %t107 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t105, i64 %t106)
  %t108 = extractvalue { i32, i64 } %t107, 1
  %t109 = extractvalue { i32, i64 } %t107, 0
  store i32 %t109, ptr %l49
  %t110 = icmp ne i32 %t109, 0
  br i1 %t110, label %bb31, label %ok.111
ok.111:
  store i64 %t108, ptr %l48
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb32
bb30:
  %t112 = load i64, ptr %l48, !tbaa !24
  store i64 %t112, ptr %l35, !tbaa !24
  br label %bb32
bb31:
  br label %bb29
bb32:
  %t113 = load i64, ptr %l35, !tbaa !24
  store i64 %t113, ptr %l4, !tbaa !24
  %t114 = load i64, ptr %l4, !tbaa !24
  %t116 = icmp sge i64 %t114, 0
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t118 = load i64, ptr %l4, !tbaa !24
  %t120 = trunc i64 %t118 to i8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 %t120)
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load i64, ptr %l3, !tbaa !24
  %t125 = add i64 %t123, 3
  store i64 %t125, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb37:
  %t127 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t127, ptr %l58, !tbaa !27
  %t128 = load i64, ptr %l3, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i8, ptr %t131, i64 %t128
  %t133 = load i8, ptr %t132, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 %t133)
  br label %bb38
bb38:
  %t136 = load i64, ptr %l3, !tbaa !24
  %t138 = add i64 %t136, 1
  store i64 %t138, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb39:
  br label %bb12
bb40:
  %t141 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t141, ptr %l64
  br label %bb41
bb41:
  %t142 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t142, ptr %l65, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l66, !tbaa !24
  %t145 = load i64, ptr %l66, !tbaa !24
  %t146 = mul i64 %t145, 1
  %t147 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t146)
  %t148 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  store { i64, ptr } %t149, ptr %l67, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l66, !tbaa !24
  %t155 = mul i64 %t154, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t151, ptr %t153, i64 %t155, i1 false)
  %t156 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t156, ptr %l65, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t157 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t157, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flsp_2eRequests_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t2 = insertvalue [5 x { i64, ptr }] %t1, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t3 = insertvalue [5 x { i64, ptr }] %t2, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d3, i32 0, i32 1) }, 2
  %t4 = insertvalue [5 x { i64, ptr }] %t3, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d4, i32 0, i32 1) }, 3
  %t5 = insertvalue [5 x { i64, ptr }] %t4, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d5, i32 0, i32 1) }, 4
  store [5 x { i64, ptr }] %t5, ptr @G_2ecompiler_2flsp_2eRequests
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2flsp_2eServe(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca [2 x i32]
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l10 = alloca %"compiler/lsp:Server"
  %l12 = alloca %"compiler/session:Reader"
  %l29 = alloca i64
  %l38 = alloca i64
  %l44 = alloca i1
  %l47 = alloca i64
  %l49 = alloca i1
  %l52 = alloca i64
  %l54 = alloca i1
  %l57 = alloca i64
  %l58 = alloca i64
  %l64 = alloca { i64, ptr }
  %l67 = alloca i1
  %l72 = alloca i1
  %l77 = alloca i32
  %l82 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i32
  %l93 = alloca i1
  %l94 = alloca i64
  %l102 = alloca i1
  %l106 = alloca i1
  %l107 = alloca i64
  %l113 = alloca i1
  %l116 = alloca i64
  %l118 = alloca i1
  %l121 = alloca i64
  %l127 = alloca i32
  %s1 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fsession_2eIgnoreBrokenPipes()
  br label %bb1
bb1:
  %t3 = call %"compiler/lsp:Server" @compiler_2flsp_3aServer_2ector(ptr %v0, ptr %v0, ptr %a0)
  store %"compiler/lsp:Server" %t3, ptr %l10
  br label %bb2
bb2:
  %t4 = load %"compiler/lsp:Server", ptr %l10
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 80, i64 8)
  store %"compiler/lsp:Server" %t4, ptr %t5
  store ptr %t5, ptr %l1, !tbaa !29
  %t7 = call %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %v0, i32 0)
  store %"compiler/session:Reader" %t7, ptr %l12
  br label %bb3
bb3:
  %t8 = load %"compiler/session:Reader", ptr %l12
  %t9 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/session:Reader" %t8, ptr %t9
  store ptr %t9, ptr %l2, !tbaa !29
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/lsp:Server", ptr %t11, i32 0, i32 8
  %t14 = load i1, ptr %t13, !tbaa !21
  %t16 = xor i1 %t14, true
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb99
bb6:
  br label %bb7
bb7:
  %t20 = insertvalue [2 x i32] undef, i32 -1, 0
  %t21 = insertvalue [2 x i32] %t20, i32 -1, 1
  store [2 x i32] %t21, ptr %l3
  %t23 = getelementptr [2 x i32], ptr %l3, i64 0, i64 0
  store i32 0, ptr %t23, !tbaa !33
  store i64 1, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/lsp:Server", ptr %t24, i32 0, i32 3
  %t27 = getelementptr %"compiler/lsp:Worker", ptr %t26, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  %t30 = icmp sgt i32 %t28, 0
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/lsp:Server", ptr %t32, i32 0, i32 3
  %t35 = getelementptr %"compiler/lsp:Worker", ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb10, label %bb11
bb9:
  br label %bb13
bb10:
  call void @__olang_check_failed(ptr @olang_loc_28490b3d64df97fe_1fa673a94cf24522)
  unreachable
bb11:
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/lsp:Server", ptr %t40, i32 0, i32 3
  %t43 = getelementptr %"compiler/lsp:Worker", ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t47 = getelementptr %"compiler/session:Reader", ptr %t44, i32 0, i32 0
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = getelementptr [2 x i32], ptr %l3, i64 0, i64 1
  store i32 %t48, ptr %t50, !tbaa !33
  store i64 2, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  store i32 -1, ptr %l5, !tbaa !23
  %t51 = call i64 @std_2ftime_2eNow()
  store i64 %t51, ptr %l29
  br label %bb14
bb14:
  %t52 = load i64, ptr %l29, !tbaa !24
  store i64 %t52, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/lsp:Server", ptr %t53, i32 0, i32 6
  %t56 = load i64, ptr %t55, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb15, label %bb16
bb15:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/lsp:Server", ptr %t60, i32 0, i32 6
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = sub i64 %t63, %t64
  %t69 = sdiv i64 %t67, 1000000
  %t71 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 0, i64 %t69)
  store i64 %t71, ptr %l38
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t72 = load i64, ptr %l38, !tbaa !24
  %t73 = add i64 %t72, 1
  %t75 = trunc i64 %t73 to i32
  store i32 %t75, ptr %l5, !tbaa !23
  br label %bb18
bb18:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/lsp:Server", ptr %t77, i32 0, i32 3
  %t80 = getelementptr %"compiler/lsp:Worker", ptr %t79, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t83 = icmp sgt i32 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb19:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/lsp:Server", ptr %t85, i32 0, i32 5
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t87)
  store i64 %t89, ptr %l47
  br label %bb21
bb20:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb26
bb21:
  %t90 = load i64, ptr %l47, !tbaa !24
  %t91 = icmp sgt i64 %t90, 0
  br i1 %t91, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb25
bb23:
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr %"compiler/lsp:Server", ptr %t93, i32 0, i32 4
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l52
  br label %bb24
bb24:
  %t98 = load i64, ptr %l52, !tbaa !24
  %t99 = icmp sgt i64 %t98, 0
  store i1 %t99, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t101 = load i1, ptr %l49, !tbaa !21
  store i1 %t101, ptr %l44, !tbaa !21
  br label %bb26
bb26:
  %t102 = load i1, ptr %l44, !tbaa !21
  br i1 %t102, label %bb27, label %bb28
bb27:
  %t103 = load i32, ptr %l5, !tbaa !23
  %t105 = icmp slt i32 %t103, 0
  store i1 %t105, ptr %l54, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb29
bb29:
  %t107 = load i1, ptr %l54, !tbaa !21
  br i1 %t107, label %bb30, label %bb31
bb30:
  store i32 1000, ptr %l5, !tbaa !23
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t108 = load i64, ptr %l4, !tbaa !24
  store i64 %t108, ptr %l57, !tbaa !24
  %t109 = load [2 x i32], ptr %l3
  store i64 2, ptr %l58, !tbaa !24
  %t110 = icmp sge i64 0, 0
  br i1 %t110, label %bb33, label %bb34
bb33:
  %t112 = load i64, ptr %l57, !tbaa !24
  %t113 = icmp sle i64 0, %t112
  br i1 %t113, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d1a2ced90ae1fed3_af42112fabe41f37)
  unreachable
bb35:
  %t115 = load i64, ptr %l57, !tbaa !24
  %t116 = load i64, ptr %l58, !tbaa !24
  %t117 = icmp sle i64 %t115, %t116
  br i1 %t117, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d1a2ced90ae1fed3_af42112fabe41f37)
  unreachable
bb37:
  %t119 = load i64, ptr %l57, !tbaa !24
  %t120 = getelementptr i32, ptr %l3, i64 0
  %t121 = sub i64 %t119, 0
  %t122 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t120, 1
  %t124 = load i32, ptr %l5, !tbaa !23
  %t127 = call { i64, ptr } @compiler_2fsession_2eReadable(ptr %s1, ptr %s1, { i64, ptr } %t123, i32 %t124)
  store { i64, ptr } %t127, ptr %l64
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_d1a2ced90ae1fed3_af42112fabe41f37)
  unreachable
bb39:
  %t128 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t128, ptr %l7, !tbaa !27
  %t129 = load i64, ptr %l4, !tbaa !24
  %t131 = icmp eq i64 %t129, 2
  br i1 %t131, label %bb40, label %bb41
bb40:
  %t133 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr i1, ptr %t134, i64 1
  %t136 = load i1, ptr %t135, !tbaa !31
  store i1 %t136, ptr %l67, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb42
bb42:
  %t138 = load i1, ptr %l67, !tbaa !21
  br i1 %t138, label %bb43, label %bb44
bb43:
  %t139 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2efromWorker(ptr %v0, ptr %t139)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t141 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i1, ptr %t142, i64 0
  %t144 = load i1, ptr %t143, !tbaa !31
  br i1 %t144, label %bb47, label %bb48
bb47:
  %t146 = load ptr, ptr %l2, !tbaa !29
  %t148 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %v0, ptr %t146)
  store i1 %t148, ptr %l72
  br label %bb49
bb48:
  br label %bb70
bb49:
  %t149 = load i1, ptr %l72, !tbaa !21
  %t150 = xor i1 %t149, true
  br i1 %t150, label %bb50, label %bb51
bb50:
  %t152 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2edrain(ptr %v0, ptr %t152)
  br label %bb52
bb51:
  br label %bb56
bb52:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr %"compiler/lsp:Server", ptr %t154, i32 0, i32 7
  %t157 = load i1, ptr %t156, !tbaa !21
  br i1 %t157, label %bb53, label %bb54
bb53:
  store i32 0, ptr %l77, !tbaa !23
  br label %bb55
bb54:
  store i32 1, ptr %l77, !tbaa !23
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s1)
  %t159 = load i32, ptr %l77, !tbaa !23
  store i32 %t159, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s8
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/lsp:Server", ptr %t160, i32 0, i32 8
  %t163 = load i1, ptr %t162, !tbaa !21
  %t165 = xor i1 %t163, true
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s8)
  br label %bb69
bb59:
  br label %bb60
bb60:
  %t169 = load ptr, ptr %l2, !tbaa !29
  %t171 = call { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNext(ptr %v0, ptr %s8, ptr %t169)
  %t172 = extractvalue { i32, { i64, ptr } } %t171, 1
  %t173 = extractvalue { i32, { i64, ptr } } %t171, 0
  store i32 %t173, ptr %l85
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb62, label %ok.175
ok.175:
  store { i64, ptr } %t172, ptr %l84
  br label %bb61
bb61:
  %t176 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t176, ptr %l82, !tbaa !27
  br label %bb66
bb62:
  %t177 = load i32, ptr %l85, !tbaa !23
  %t178 = ashr i32 %t177, 16
  %t180 = icmp eq i32 %t178, 1
  br i1 %t180, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_3b6b320f0468fe97_a6b70e33112bfcbb)
  unreachable
bb65:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s8)
  br label %bb69
bb66:
  %t182 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t183 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2ehandle(ptr %v0, ptr %s8, ptr %t183, { i64, ptr } %t182)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s8)
  br label %bb68
bb68:
  br label %bb57
bb69:
  br label %bb70
bb70:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr %"compiler/lsp:Server", ptr %t187, i32 0, i32 6
  %t190 = load i64, ptr %t189, !tbaa !24
  %t192 = icmp sgt i64 %t190, 0
  br i1 %t192, label %bb71, label %bb72
bb71:
  %t194 = call i64 @std_2ftime_2eNow()
  store i64 %t194, ptr %l94
  br label %bb73
bb72:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb74
bb73:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr %"compiler/lsp:Server", ptr %t195, i32 0, i32 6
  %t198 = load i64, ptr %t197, !tbaa !24
  %t199 = load i64, ptr %l94, !tbaa !24
  %t201 = icmp sge i64 %t199, %t198
  store i1 %t201, ptr %l93, !tbaa !21
  br label %bb74
bb74:
  %t203 = load i1, ptr %l93, !tbaa !21
  br i1 %t203, label %bb75, label %bb76
bb75:
  %t204 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estartWorker(ptr %v0, ptr %t204)
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb78
bb78:
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr %"compiler/lsp:Server", ptr %t206, i32 0, i32 3
  %t209 = getelementptr %"compiler/lsp:Worker", ptr %t208, i32 0, i32 0
  %t210 = load i32, ptr %t209, !tbaa !23
  %t212 = icmp sgt i32 %t210, 0
  br i1 %t212, label %bb79, label %bb80
bb79:
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t216 = getelementptr %"compiler/lsp:Server", ptr %t214, i32 0, i32 3
  %t217 = getelementptr %"compiler/lsp:Worker", ptr %t216, i32 0, i32 3
  %t218 = load i64, ptr %t217, !tbaa !24
  %t220 = icmp sgt i64 %t218, 0
  store i1 %t220, ptr %l102, !tbaa !21
  br label %bb81
bb80:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb81
bb81:
  %t222 = load i1, ptr %l102, !tbaa !21
  br i1 %t222, label %bb82, label %bb83
bb82:
  %t223 = call i64 @std_2ftime_2eNow()
  store i64 %t223, ptr %l107
  br label %bb84
bb83:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb85
bb84:
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr %"compiler/lsp:Server", ptr %t224, i32 0, i32 3
  %t227 = getelementptr %"compiler/lsp:Worker", ptr %t226, i32 0, i32 3
  %t228 = load i64, ptr %t227, !tbaa !24
  %t229 = load i64, ptr %l107, !tbaa !24
  %t231 = sub i64 %t229, %t228
  %t232 = load i64, ptr @G_2ecompiler_2flsp_2eStuckNs, !tbaa !24
  %t235 = icmp sgt i64 %t231, %t232
  store i1 %t235, ptr %l106, !tbaa !21
  br label %bb85
bb85:
  %t237 = load i1, ptr %l106, !tbaa !21
  br i1 %t237, label %bb86, label %bb87
bb86:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr %"compiler/lsp:Server", ptr %t238, i32 0, i32 5
  %t242 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t240)
  store i64 %t242, ptr %l116
  br label %bb88
bb87:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb93
bb88:
  %t243 = load i64, ptr %l116, !tbaa !24
  %t244 = icmp sgt i64 %t243, 0
  br i1 %t244, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb92
bb90:
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr %"compiler/lsp:Server", ptr %t246, i32 0, i32 4
  %t250 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t248)
  store i64 %t250, ptr %l121
  br label %bb91
bb91:
  %t251 = load i64, ptr %l121, !tbaa !24
  %t252 = icmp sgt i64 %t251, 0
  store i1 %t252, ptr %l118, !tbaa !21
  br label %bb92
bb92:
  %t254 = load i1, ptr %l118, !tbaa !21
  store i1 %t254, ptr %l113, !tbaa !21
  br label %bb93
bb93:
  %t255 = load i1, ptr %l113, !tbaa !21
  br i1 %t255, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s11
  %t256 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eworkerLost(ptr %v0, ptr %s11, ptr %t256, { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb96
bb95:
  br label %bb97
bb96:
  call void @__olang_scope_close(ptr %s11)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s1)
  br label %bb98
bb98:
  br label %bb4
bb99:
  %t258 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estopWorker(ptr %v0, ptr %t258)
  br label %bb100
bb100:
  %t260 = load ptr, ptr %l1, !tbaa !29
  %t262 = getelementptr %"compiler/lsp:Server", ptr %t260, i32 0, i32 7
  %t263 = load i1, ptr %t262, !tbaa !21
  br i1 %t263, label %bb101, label %bb102
bb101:
  store i32 0, ptr %l127, !tbaa !23
  br label %bb103
bb102:
  store i32 1, ptr %l127, !tbaa !23
  br label %bb103
bb103:
  %t265 = load i32, ptr %l127, !tbaa !23
  store i32 %t265, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2flsp_2eSessionSrc_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t2 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t3 = extractvalue { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t5 = add i64 %t2, %t4
  %t6 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t9 = load ptr, ptr @__olang_prog_scope
  %t10 = call ptr @__olang_scope_alloc(ptr %t9, i64 %t8)
  call void @olang_textcopy(ptr %t10, ptr %t1, i64 %t2)
  %t11 = getelementptr i8, ptr %t10, i64 %t2
  call void @olang_textcopy(ptr %t11, ptr %t3, i64 %t4)
  %t12 = getelementptr i8, ptr %t11, i64 %t4
  call void @olang_textcopy(ptr %t12, ptr %t6, i64 %t7)
  %t13 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t10, 1
  %t16 = load ptr, ptr @__olang_prog_scope
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = extractvalue { i64, ptr } %t14, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %t16, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr @G_2ecompiler_2flsp_2eSessionSrc, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2eSettleNs_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 40000000, ptr @G_2ecompiler_2flsp_2eSettleNs, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2eStuckNs_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 60000000000, ptr @G_2ecompiler_2flsp_2eStuckNs, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2flsp_2eUriOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l40 = alloca ptr
  %l42 = alloca i8
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d10, i32 0, i32 1) })
  br label %bb2
bb2:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb5:
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t19
  %t24 = load i8, ptr %t23, !tbaa !32
  store i8 %t24, ptr %l5, !tbaa !22
  %t26 = load i8, ptr %l5, !tbaa !22
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t26)
  store i1 %t28, ptr %l19
  br label %bb7
bb7:
  %t29 = load i1, ptr %l19, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb11
bb9:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t30)
  store i1 %t32, ptr %l22
  br label %bb10
bb10:
  %t33 = load i1, ptr %l22, !tbaa !21
  store i1 %t33, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb14
bb13:
  %t35 = load i8, ptr %l5, !tbaa !22
  %t37 = icmp eq i8 %t35, 47
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb17
bb16:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t42 = icmp eq i8 %t40, 45
  store i1 %t42, ptr %l26, !tbaa !21
  br label %bb17
bb17:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  %t45 = load i8, ptr %l5, !tbaa !22
  %t47 = icmp eq i8 %t45, 46
  store i1 %t47, ptr %l29, !tbaa !21
  br label %bb20
bb20:
  %t49 = load i1, ptr %l29, !tbaa !21
  br i1 %t49, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb23
bb22:
  %t50 = load i8, ptr %l5, !tbaa !22
  %t52 = icmp eq i8 %t50, 95
  store i1 %t52, ptr %l32, !tbaa !21
  br label %bb23
bb23:
  %t54 = load i1, ptr %l32, !tbaa !21
  br i1 %t54, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb26
bb25:
  %t55 = load i8, ptr %l5, !tbaa !22
  %t57 = icmp eq i8 %t55, 126
  store i1 %t57, ptr %l35, !tbaa !21
  br label %bb26
bb26:
  %t59 = load i1, ptr %l35, !tbaa !21
  br i1 %t59, label %bb27, label %bb28
bb27:
  %t60 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t60)
  br label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l1, ptr %l40, !tbaa !29
  %t63 = load i8, ptr %l5, !tbaa !22
  store i8 %t63, ptr %l42, !tbaa !22
  %t65 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 16)
  %t66 = extractvalue { i32, i64 } %t65, 1
  %t67 = extractvalue { i32, i64 } %t65, 0
  store i32 %t67, ptr %l44
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb31, label %ok.69
ok.69:
  store i64 %t66, ptr %l43
  br label %bb30
bb29:
  br label %bb36
bb30:
  %t70 = load i8, ptr %l42, !tbaa !22
  %t71 = load i64, ptr %l43, !tbaa !24
  %t72 = call { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %s4, i8 %t70, i64 %t71)
  store { i64, ptr } %t72, ptr %l45
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_b56467a85251252d_5a05a1cd484a3361)
  unreachable
bb32:
  %t73 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = extractvalue { i64, ptr } %t73, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t81 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %s4, ptr %s4, { i64, ptr } %t79)
  store { i64, ptr } %t81, ptr %l47
  br label %bb33
bb33:
  %t82 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  %t84 = extractvalue { i64, ptr } %t82, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  %t90 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s4, ptr %s4, { i64, ptr } %t88, i64 2, i8 48)
  store { i64, ptr } %t90, ptr %l49
  br label %bb34
bb34:
  %t91 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t93 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = add i64 %t92, %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t91, i64 %t92)
  %t98 = getelementptr i8, ptr %t97, i64 %t92
  call void @olang_textcopy(ptr %t98, ptr %t94, i64 %t95)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l40, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t108, { i64, ptr } %t107)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb37:
  %t110 = load i64, ptr %l3, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l3, !tbaa !24
  br label %bb3
bb38:
  %t115 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t115, ptr %l55
  br label %bb39
bb39:
  %t116 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t116, ptr %l56, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l57, !tbaa !24
  %t119 = load i64, ptr %l57, !tbaa !24
  %t120 = mul i64 %t119, 1
  %t121 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l58, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l57, !tbaa !24
  %t129 = mul i64 %t128, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t130, ptr %l56, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t131 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t131, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2ecompilerUnderTest(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d12, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l0, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t19, ptr %l8
  br label %bb5
bb5:
  %t20 = load i1, ptr %l8, !tbaa !21
  %t21 = xor i1 %t20, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t31, ptr %l10, !tbaa !27
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l15, !tbaa !24
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l16, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l15, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t46, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eaddPending(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i1
  %l9 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:Server", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemove_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/lsp:Server", ptr %t8, i32 0, i32 4
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eInsert_3cI64_3e(ptr %v0, ptr %t10, i64 0, i64 %t11)
  store i32 %t14, ptr %l9
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16
ok.16:
  br label %bb2
bb2:
  br label %bb6
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lsp:Server", ptr %t17, i32 0, i32 4
  %t20 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t19, i64 %t20)
  br label %bb5
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eask(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:Server", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/lsp:Worker", ptr %t3, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = icmp sle i32 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estartWorker(ptr %v0, ptr %t9)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lsp:Server", ptr %t11, i32 0, i32 3
  %t14 = getelementptr %"compiler/lsp:Worker", ptr %t13, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = icmp sle i32 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  %t20 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %v2, ptr %s2, ptr %s2, { i64, ptr } %t20, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store { i64, ptr } %t22, ptr %l12
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t30 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s2, ptr %t30, { i64, ptr } %t29)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lsp:Server", ptr %t32, i32 0, i32 5
  store ptr %t34, ptr %l15, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l17, !tbaa !27
  %t36 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t37 = extractvalue { i32, i64 } %t36, 1
  %t38 = extractvalue { i32, i64 } %t36, 0
  store i32 %t38, ptr %l19
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb11, label %ok.40
ok.40:
  store i64 %t37, ptr %l18
  br label %bb10
bb10:
  %t41 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t42 = load i64, ptr %l18, !tbaa !24
  %t43 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v2, { i64, ptr } %t41, i64 %t42)
  %t44 = extractvalue { i32, i64 } %t43, 1
  %t45 = extractvalue { i32, i64 } %t43, 0
  store i32 %t45, ptr %l21
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb14, label %ok.47
ok.47:
  store i64 %t44, ptr %l20
  br label %bb13
bb11:
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l16, !tbaa !24
  br label %bb15
bb13:
  %t48 = load i64, ptr %l20, !tbaa !24
  store i64 %t48, ptr %l16, !tbaa !24
  br label %bb15
bb14:
  br label %bb12
bb15:
  %t49 = load ptr, ptr %l15, !tbaa !29
  %t50 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t49, i64 %t50)
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lsp:Server", ptr %t51, i32 0, i32 3
  %t54 = getelementptr %"compiler/lsp:Worker", ptr %t53, i32 0, i32 1
  %t55 = load i32, ptr %t54, !tbaa !23
  call void @compiler_2fsession_2eWriteFramed(ptr %v1, i32 %t55, { i64, ptr } %a1)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2echanged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call i64 @compiler_2flsp_2ecompiler_2flsp_3aServer_2eslotOf(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eopened(ptr %v0, ptr %v1, ptr %v2, ptr %t11, { i64, ptr } %t12, { i64, ptr } %t13)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %ret
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esetText(ptr %v0, ptr %v2, ptr %t17, i64 %t18, { i64, ptr } %t19)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2ecloseWorker(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:Server", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/lsp:Worker", ptr %t3, i32 0, i32 1
  %t5 = load i32, ptr %t4, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t5)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lsp:Server", ptr %t7, i32 0, i32 3
  %t10 = getelementptr %"compiler/lsp:Worker", ptr %t9, i32 0, i32 2
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a8eebe32341e04e6_239ed324021d536a)
  unreachable
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lsp:Server", ptr %t15, i32 0, i32 3
  %t18 = getelementptr %"compiler/lsp:Worker", ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t22 = getelementptr %"compiler/session:Reader", ptr %t19, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t23)
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/lsp:Server", ptr %t25, i32 0, i32 3
  %t28 = getelementptr %"compiler/lsp:Worker", ptr %t27, i32 0, i32 0
  store i32 -1, ptr %t28, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lsp:Server", ptr %t29, i32 0, i32 3
  %t32 = getelementptr %"compiler/lsp:Worker", ptr %t31, i32 0, i32 1
  store i32 -1, ptr %t32, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eclosed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i64
  %l18 = alloca ptr
  %l22 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l42 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l58 = alloca i1
  %l59 = alloca ptr
  %l62 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2flsp_2ecompiler_2flsp_3aServer_2eslotOf(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %a1)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/lsp:Server", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l18
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l18, !tbaa !29
  store ptr %t18, ptr %l3, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/lsp:Doc", ptr %t19, i32 0, i32 4
  store i1 false, ptr %t21, !tbaa !21
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/lsp:Doc", ptr %t22, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %t24)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l22, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr %"compiler/lsp:Doc", ptr %t27, i32 0, i32 0
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t32 = call { i64, ptr } @compiler_2flsp_2epublish(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store { i64, ptr } %t32, ptr %l25
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t40 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s0, ptr %t40, { i64, ptr } %t39)
  br label %bb8
bb8:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = getelementptr %"compiler/lsp:Doc", ptr %t42, i32 0, i32 6
  store ptr %t44, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t46, i64 %t47)
  %t51 = extractvalue { i32, { i64, ptr } } %t50, 1
  %t52 = extractvalue { i32, { i64, ptr } } %t50, 0
  store i32 %t52, ptr %l33
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb11, label %ok.54
ok.54:
  store { i64, ptr } %t51, ptr %l32
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  br label %bb15
bb11:
  %t56 = load i32, ptr %l33, !tbaa !23
  %t57 = ashr i32 %t56, 16
  %t59 = icmp eq i32 %t57, 1
  br i1 %t59, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_1f1ebcf53f42361_3e0cb829339a6f9d)
  unreachable
bb14:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb15:
  %t61 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t61, ptr %l6, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb18:
  br label %bb19
bb19:
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t74, ptr %l42, !tbaa !27
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %t78, i64 %t75
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !37
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l45, !tbaa !29
  %t85 = call { i64, ptr } @compiler_2flsp_2epublish(ptr %v0, ptr %s4, ptr %s4, { i64, ptr } %t80, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store { i64, ptr } %t85, ptr %l47
  br label %bb20
bb20:
  %t86 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t88 = extractvalue { i64, ptr } %t86, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t93 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s4, ptr %t93, { i64, ptr } %t92)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t95 = load i64, ptr %l8, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l8, !tbaa !24
  br label %bb16
bb23:
  %t99 = load i64, ptr %l5, !tbaa !24
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = add i64 %t99, %t100
  store i64 %t103, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  br label %bb9
bb25:
  %t105 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estopWorker(ptr %v0, ptr %t105)
  br label %bb26
bb26:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/lsp:Server", ptr %t107, i32 0, i32 4
  %t110 = load i64, ptr %l2, !tbaa !24
  %t113 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemove_3cI64_3e(ptr %v0, ptr %t109, i64 %t110)
  store i1 %t113, ptr %l58
  br label %bb27
bb27:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l59, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/lsp:Server", ptr %t115, i32 0, i32 4
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t117)
  store i64 %t119, ptr %l62
  br label %bb28
bb28:
  %t120 = load i64, ptr %l62, !tbaa !24
  %t121 = icmp sgt i64 %t120, 0
  br i1 %t121, label %bb29, label %bb30
bb29:
  %t123 = call i64 @std_2ftime_2eNow()
  store i64 %t123, ptr %l65
  br label %bb31
bb30:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb32
bb31:
  %t124 = load i64, ptr @G_2ecompiler_2flsp_2eSettleNs, !tbaa !24
  %t125 = load i64, ptr %l65, !tbaa !24
  %t127 = add i64 %t125, %t124
  store i64 %t127, ptr %l64, !tbaa !24
  br label %bb32
bb32:
  %t129 = load i64, ptr %l64, !tbaa !24
  %t130 = load ptr, ptr %l59, !tbaa !29
  %t131 = getelementptr %"compiler/lsp:Server", ptr %t130, i32 0, i32 6
  store i64 %t129, ptr %t131, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2edrain(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca [1 x i32]
  %l3 = alloca { i64, ptr }
  %l6 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i64
  %l17 = alloca i1
  %l20 = alloca i64
  %l22 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i64
  %l44 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:Server", ptr %t1, i32 0, i32 4
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lsp:Server", ptr %t9, i32 0, i32 3
  %t12 = getelementptr %"compiler/lsp:Worker", ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = icmp sle i32 %t13, 0
  store i1 %t15, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estartWorker(ptr %v0, ptr %t18)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t20 = call i64 @std_2ftime_2eNow()
  store i64 %t20, ptr %l13
  br label %bb9
bb9:
  %t21 = load i64, ptr %l13, !tbaa !24
  store i64 %t21, ptr %l1, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/lsp:Server", ptr %t22, i32 0, i32 3
  %t25 = getelementptr %"compiler/lsp:Worker", ptr %t24, i32 0, i32 0
  %t26 = load i32, ptr %t25, !tbaa !23
  %t28 = icmp sgt i32 %t26, 0
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/lsp:Server", ptr %t30, i32 0, i32 4
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l20
  br label %bb13
bb12:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb18
bb13:
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = icmp sgt i64 %t35, 0
  br i1 %t36, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb17
bb15:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lsp:Server", ptr %t38, i32 0, i32 5
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t40)
  store i64 %t42, ptr %l25
  br label %bb16
bb16:
  %t43 = load i64, ptr %l25, !tbaa !24
  %t44 = icmp sgt i64 %t43, 0
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb17
bb17:
  %t46 = load i1, ptr %l22, !tbaa !21
  store i1 %t46, ptr %l17, !tbaa !21
  br label %bb18
bb18:
  %t47 = load i1, ptr %l17, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb20:
  br label %bb21
bb21:
  %t50 = call i64 @std_2ftime_2eNow()
  store i64 %t50, ptr %l28
  br label %bb22
bb22:
  %t51 = load i64, ptr %l1, !tbaa !24
  %t52 = load i64, ptr %l28, !tbaa !24
  %t54 = sub i64 %t52, %t51
  %t55 = load i64, ptr @G_2ecompiler_2flsp_2eStuckNs, !tbaa !24
  %t58 = icmp sgt i64 %t54, %t55
  br i1 %t58, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eworkerLost(ptr %v0, ptr %s3, ptr %t60, { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d19, i32 0, i32 1) })
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb26:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/lsp:Server", ptr %t62, i32 0, i32 3
  %t65 = getelementptr %"compiler/lsp:Worker", ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_43d07951ce1dba96_20fc5bf2a8432eaa)
  unreachable
bb28:
  br label %bb29
bb29:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lsp:Server", ptr %t70, i32 0, i32 3
  %t73 = getelementptr %"compiler/lsp:Worker", ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t77 = getelementptr %"compiler/session:Reader", ptr %t74, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = insertvalue [1 x i32] undef, i32 %t78, 0
  store [1 x i32] %t80, ptr %l2
  %t83 = insertvalue { i64, ptr } undef, i64 1, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %l2, 1
  %t86 = call { i64, ptr } @compiler_2fsession_2eReadable(ptr %s2, ptr %s2, { i64, ptr } %t84, i32 1000)
  store { i64, ptr } %t86, ptr %l44
  br label %bb30
bb30:
  %t87 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t87, ptr %l3, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i1, ptr %t89, i64 0
  %t91 = load i1, ptr %t90, !tbaa !31
  br i1 %t91, label %bb31, label %bb32
bb31:
  %t93 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2efromWorker(ptr %v0, ptr %t93)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb35:
  br label %bb10
bb36:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2edue(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l42 = alloca i1
  %l46 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estopWorker(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eaddPending(ptr %v0, ptr %t3, i64 %t4)
  br label %bb2
bb2:
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/lsp:Server", ptr %t7, i32 0, i32 1
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H1531dad62b744074bb3be3226dd54f14(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l14
  br label %bb3
bb3:
  %t12 = load i64, ptr %l14, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb9
bb6:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l21, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l21, !tbaa !24
  store i64 %t39, ptr %l18, !tbaa !24
  br label %bb9
bb9:
  %t40 = load i64, ptr %l18, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb12:
  br label %bb13
bb13:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l1, !tbaa !24
  %t63 = icmp ne i64 %t59, %t60
  br i1 %t63, label %bb14, label %bb15
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lsp:Server", ptr %t65, i32 0, i32 1
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l46
  br label %bb16
bb15:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb17
bb16:
  %t72 = load ptr, ptr %l46, !tbaa !29
  %t74 = getelementptr %"compiler/lsp:Doc", ptr %t72, i32 0, i32 4
  %t75 = load i1, ptr %t74, !tbaa !21
  store i1 %t75, ptr %l42, !tbaa !21
  br label %bb17
bb17:
  %t77 = load i1, ptr %l42, !tbaa !21
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t78 = load i64, ptr %l1, !tbaa !24
  store i64 %t78, ptr %l8, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/lsp:Server", ptr %t80, i32 0, i32 1
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t82, i64 %t83)
  store ptr %t86, ptr %l54
  br label %bb20
bb19:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb22
bb20:
  %t87 = load ptr, ptr %l54, !tbaa !29
  %t89 = getelementptr %"compiler/lsp:Doc", ptr %t87, i32 0, i32 5
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t93, ptr %l58
  br label %bb21
bb21:
  %t94 = load i1, ptr %l58, !tbaa !21
  store i1 %t94, ptr %l49, !tbaa !21
  br label %bb22
bb22:
  %t95 = load i1, ptr %l49, !tbaa !21
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eaddPending(ptr %v0, ptr %t96, i64 %t97)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l6, !tbaa !24
  br label %bb10
bb28:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l63, !tbaa !29
  %t105 = call i64 @std_2ftime_2eNow()
  store i64 %t105, ptr %l64
  br label %bb29
bb29:
  %t106 = load i64, ptr @G_2ecompiler_2flsp_2eSettleNs, !tbaa !24
  %t107 = load i64, ptr %l64, !tbaa !24
  %t109 = add i64 %t107, %t106
  %t111 = load ptr, ptr %l63, !tbaa !29
  %t112 = getelementptr %"compiler/lsp:Server", ptr %t111, i32 0, i32 6
  store i64 %t109, ptr %t112, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2efromWorker(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l11 = alloca i1
  %l15 = alloca i32
  %l19 = alloca i64
  %l21 = alloca i1
  %l24 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca i64
  %l42 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l53 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i32
  %l64 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i32
  %l70 = alloca i64
  %l71 = alloca i32
  %l75 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:Server", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/lsp:Worker", ptr %t3, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_824396f7e8872934_1f4412bc0bc5f5e0)
  unreachable
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lsp:Server", ptr %t9, i32 0, i32 3
  %t12 = getelementptr %"compiler/lsp:Worker", ptr %t11, i32 0, i32 2
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %v0, ptr %t13)
  store i1 %t15, ptr %l11
  br label %bb4
bb4:
  %t16 = load i1, ptr %l11, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/lsp:Server", ptr %t19, i32 0, i32 3
  %t22 = getelementptr %"compiler/lsp:Worker", ptr %t21, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t25 = call i32 @compiler_2fsession_2eReap(i32 %t23)
  store i32 %t25, ptr %l15
  br label %bb7
bb6:
  br label %bb25
bb7:
  %t26 = load i32, ptr %l15, !tbaa !23
  store i32 %t26, ptr %l1, !tbaa !23
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2ecloseWorker(ptr %v0, ptr %t27)
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/lsp:Server", ptr %t29, i32 0, i32 4
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l19
  br label %bb9
bb9:
  %t34 = load i64, ptr %l19, !tbaa !24
  %t35 = icmp sgt i64 %t34, 0
  br i1 %t35, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb13
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/lsp:Server", ptr %t37, i32 0, i32 5
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l24
  br label %bb12
bb12:
  %t42 = load i64, ptr %l24, !tbaa !24
  %t43 = icmp sgt i64 %t42, 0
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lsp:Server", ptr %t46, i32 0, i32 3
  %t49 = getelementptr %"compiler/lsp:Worker", ptr %t48, i32 0, i32 0
  store i32 -1, ptr %t49, !tbaa !23
  store { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t50, ptr %l28, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l29, !tbaa !24
  %t53 = load i64, ptr %l29, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l30, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l29, !tbaa !24
  %t63 = mul i64 %t62, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %t61, i64 %t63, i1 false)
  %t64 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t64, ptr %l2, !tbaa !27
  %t65 = load i32, ptr %l1, !tbaa !23
  %t67 = icmp sgt i32 %t65, 128
  br i1 %t67, label %bb16, label %bb17
bb15:
  br label %bb24
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t69 = load i32, ptr %l1, !tbaa !23
  %t71 = sub i32 %t69, 128
  %t73 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s3, i32 %t71)
  store { i64, ptr } %t73, ptr %l35
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t74 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t76 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t74, i64 %t75)
  %t84 = getelementptr i8, ptr %t83, i64 %t75
  call void @olang_textcopy(ptr %t84, ptr %t77, i64 %t78)
  %t85 = getelementptr i8, ptr %t84, i64 %t78
  call void @olang_textcopy(ptr %t85, ptr %t80, i64 %t81)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t83, 1
  store { i64, ptr } %t87, ptr %l36, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  %t90 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l38, !tbaa !24
  %t93 = load i64, ptr %l38, !tbaa !24
  %t94 = icmp eq i64 %t89, %t93
  br i1 %t94, label %bb19, label %bb20
bb19:
  %t96 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l38, !tbaa !24
  %t101 = mul i64 %t100, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t97, ptr %t99, i64 %t101, i1 false)
  br label %bb21
bb20:
  %t102 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t102, ptr %l2, !tbaa !27
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eworkerLost(ptr %v0, ptr %s2, ptr %t103, { i64, ptr } %t104)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  br label %ret
bb25:
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/lsp:Server", ptr %t107, i32 0, i32 3
  %t110 = getelementptr %"compiler/lsp:Worker", ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  br i1 %t113, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_b5606d6e3fe22ec3_be86f13ccb1ff2ff)
  unreachable
bb28:
  br label %bb29
bb29:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/lsp:Server", ptr %t115, i32 0, i32 3
  %t118 = getelementptr %"compiler/lsp:Worker", ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = call { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNext(ptr %v0, ptr %s5, ptr %t119)
  %t122 = extractvalue { i32, { i64, ptr } } %t121, 1
  %t123 = extractvalue { i32, { i64, ptr } } %t121, 0
  store i32 %t123, ptr %l49
  %t124 = icmp ne i32 %t123, 0
  br i1 %t124, label %bb31, label %ok.125
ok.125:
  store { i64, ptr } %t122, ptr %l48
  br label %bb30
bb30:
  %t126 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t126, ptr %l42, !tbaa !27
  br label %bb35
bb31:
  %t127 = load i32, ptr %l49, !tbaa !23
  %t128 = ashr i32 %t127, 16
  %t130 = icmp eq i32 %t128, 1
  br i1 %t130, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_ad997ef4ac6fd571_d04020f26953855d)
  unreachable
bb34:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb35:
  %t132 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t132, ptr %l3, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t135 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s5, ptr %s5, { i64, ptr } %t133, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t135, ptr %l53
  br label %bb36
bb36:
  %t136 = load i1, ptr %l53, !tbaa !21
  br i1 %t136, label %bb37, label %bb38
bb37:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2enote(ptr %v0, ptr %s5, ptr %t137, { i64, ptr } %t138)
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s5)
  br label %bb60
bb40:
  %t141 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t143 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s5, ptr %s5, { i64, ptr } %t141, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t143, ptr %l57
  br label %bb41
bb41:
  %t144 = load i1, ptr %l57, !tbaa !21
  br i1 %t144, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t145 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t147 = call { i32, ptr } @std_2fjson_2eParse(ptr %s5, ptr %s8, ptr %s8, { i64, ptr } %t145, ptr null)
  %t148 = extractvalue { i32, ptr } %t147, 1
  %t149 = extractvalue { i32, ptr } %t147, 0
  store i32 %t149, ptr %l61
  %t150 = icmp ne i32 %t149, 0
  br i1 %t150, label %bb45, label %ok.151
ok.151:
  store ptr %t148, ptr %l60
  br label %bb44
bb43:
  br label %bb58
bb44:
  %t152 = load ptr, ptr %l60, !tbaa !29
  store ptr %t152, ptr %l58, !tbaa !29
  br label %bb49
bb45:
  %t153 = load i32, ptr %l61, !tbaa !23
  %t154 = ashr i32 %t153, 16
  %t156 = icmp eq i32 %t154, 1
  br i1 %t156, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_aa7531c8ff935160_c377f1bac17802ac)
  unreachable
bb48:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  br label %bb60
bb49:
  %t158 = load ptr, ptr %l58, !tbaa !29
  %t161 = call { i64, ptr } @compiler_2flsp_2eidOf(ptr %s8, ptr %s8, ptr %t158)
  store { i64, ptr } %t161, ptr %l66
  br label %bb50
bb50:
  %t162 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  %t164 = extractvalue { i64, ptr } %t162, 1
  %t165 = mul i64 %t163, 1
  %t166 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t165)
  call void @llvm.memcpy.p0.p0.i64(ptr %t166, ptr %t164, i64 %t165, i1 false)
  %t167 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l67, !tbaa !27
  %t169 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s8, i64 10)
  %t170 = extractvalue { i32, i64 } %t169, 1
  %t171 = extractvalue { i32, i64 } %t169, 0
  store i32 %t171, ptr %l69
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb52, label %ok.173
ok.173:
  store i64 %t170, ptr %l68
  br label %bb51
bb51:
  %t174 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t175 = load i64, ptr %l68, !tbaa !24
  %t176 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s8, { i64, ptr } %t174, i64 %t175)
  %t177 = extractvalue { i32, i64 } %t176, 1
  %t178 = extractvalue { i32, i64 } %t176, 0
  store i32 %t178, ptr %l71
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb55, label %ok.180
ok.180:
  store i64 %t177, ptr %l70
  br label %bb54
bb52:
  br label %bb53
bb53:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l64, !tbaa !24
  br label %bb56
bb54:
  %t181 = load i64, ptr %l70, !tbaa !24
  store i64 %t181, ptr %l64, !tbaa !24
  br label %bb56
bb55:
  br label %bb53
bb56:
  %t182 = load i64, ptr %l64, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/lsp:Server", ptr %t183, i32 0, i32 5
  %t189 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemove_3cI64_3e(ptr %v0, ptr %t185, i64 %t182)
  store i1 %t189, ptr %l75
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb58:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s5, ptr %t190, { i64, ptr } %t191)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s5)
  br label %bb60
bb60:
  br label %bb26
bb61:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2ehandle(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l41 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l59 = alloca i32
  %l63 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l66 = alloca i32
  %l69 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca i32
  %l84 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l89 = alloca i32
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l98 = alloca i32
  %l101 = alloca { i64, ptr }
  %l102 = alloca i32
  %l108 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l123 = alloca ptr
  %l124 = alloca i32
  %l128 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l131 = alloca i32
  %l134 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l138 = alloca i1
  %l143 = alloca i1
  %l147 = alloca ptr
  %l152 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call { i32, ptr } @std_2fjson_2eParse(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t1, ptr null)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l14
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store ptr %t4, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l13, !tbaa !29
  store ptr %t8, ptr %l11, !tbaa !29
  br label %bb8
bb2:
  %t9 = load i32, ptr %l14, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_56fa7fac25efd7e3_fd7025eb3c8ceb4f)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l17, !tbaa !29
  %t15 = call { i64, ptr } @compiler_2flsp_2eerrorReply(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d25, i32 0, i32 1) }, i64 -32700, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store { i64, ptr } %t15, ptr %l18
  br label %bb6
bb6:
  %t16 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  %t18 = extractvalue { i64, ptr } %t16, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t23 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s1, ptr %t23, { i64, ptr } %t22)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t25 = load ptr, ptr %l11, !tbaa !29
  store ptr %t25, ptr %l2, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s0, ptr %s0, ptr %t26, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store { i64, ptr } %t28, ptr %l21
  br label %bb9
bb9:
  %t29 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = call { i64, ptr } @compiler_2flsp_2eidOf(ptr %s0, ptr %s0, ptr %t30)
  store { i64, ptr } %t32, ptr %l23
  br label %bb10
bb10:
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t36, ptr %l25
  br label %bb11
bb11:
  %t37 = load i1, ptr %l25, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2einitialize(ptr %v0, ptr %s0, ptr %s0, ptr %t38, ptr %t39, { i64, ptr } %t40)
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t44, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t46, ptr %l30
  br label %bb16
bb16:
  %t47 = load i1, ptr %l30, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb20
bb18:
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t48, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t50, ptr %l33
  br label %bb19
bb19:
  %t51 = load i1, ptr %l33, !tbaa !21
  store i1 %t51, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t52 = load i1, ptr %l31, !tbaa !21
  br i1 %t52, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb24
bb22:
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t53, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t55, ptr %l36
  br label %bb23
bb23:
  %t56 = load i1, ptr %l36, !tbaa !21
  store i1 %t56, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  %t57 = load i1, ptr %l34, !tbaa !21
  br i1 %t57, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb28
bb26:
  %t58 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t58, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t60, ptr %l39
  br label %bb27
bb27:
  %t61 = load i1, ptr %l39, !tbaa !21
  store i1 %t61, ptr %l37, !tbaa !21
  br label %bb28
bb28:
  %t62 = load i1, ptr %l37, !tbaa !21
  br i1 %t62, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  br label %bb31
bb31:
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t63, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t65, ptr %l41
  br label %bb32
bb32:
  %t66 = load i1, ptr %l41, !tbaa !21
  br i1 %t66, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2edrain(ptr %v0, ptr %t67)
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/lsp:Server", ptr %t69, i32 0, i32 7
  store i1 true, ptr %t71, !tbaa !21
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l44, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t75 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s4, ptr %s4, { i64, ptr } %t73, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store { i64, ptr } %t75, ptr %l46
  br label %bb36
bb36:
  %t76 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  %t78 = extractvalue { i64, ptr } %t76, 1
  %t79 = mul i64 %t77, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t79)
  call void @llvm.memcpy.p0.p0.i64(ptr %t80, ptr %t78, i64 %t79, i1 false)
  %t81 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  %t83 = load ptr, ptr %l44, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s4, ptr %t83, { i64, ptr } %t82)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb38:
  %t85 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t85, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t87, ptr %l49
  br label %bb39
bb39:
  %t88 = load i1, ptr %l49, !tbaa !21
  br i1 %t88, label %bb40, label %bb41
bb40:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/lsp:Server", ptr %t89, i32 0, i32 8
  store i1 true, ptr %t91, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb41:
  br label %bb42
bb42:
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t94 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t92, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t94, ptr %l52
  br label %bb43
bb43:
  %t95 = load i1, ptr %l52, !tbaa !21
  br i1 %t95, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s6
  %t96 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l56, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t101 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t96, { i64, ptr } %t98)
  %t102 = extractvalue { i32, ptr } %t101, 1
  %t103 = extractvalue { i32, ptr } %t101, 0
  store i32 %t103, ptr %l59
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb47, label %ok.105
ok.105:
  store ptr %t102, ptr %l58
  br label %bb46
bb45:
  br label %bb59
bb46:
  %t106 = load ptr, ptr %l58, !tbaa !29
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l63, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t110 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t106, { i64, ptr } %t107)
  %t111 = extractvalue { i32, ptr } %t110, 1
  %t112 = extractvalue { i32, ptr } %t110, 0
  store i32 %t112, ptr %l66
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb52, label %ok.114
ok.114:
  store ptr %t111, ptr %l65
  br label %bb51
bb47:
  %t115 = load i32, ptr %l59, !tbaa !23
  %t116 = ashr i32 %t115, 16
  %t118 = icmp eq i32 %t116, 1
  br i1 %t118, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_bad65bd0ec5ef9e2_cc5215fe2456bb0e)
  unreachable
bb50:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb51:
  %t120 = load ptr, ptr %l65, !tbaa !29
  store ptr %t120, ptr %l53, !tbaa !29
  br label %bb55
bb52:
  %t121 = load i32, ptr %l66, !tbaa !23
  %t122 = ashr i32 %t121, 16
  %t124 = icmp eq i32 %t122, 1
  br i1 %t124, label %bb53, label %bb54
bb53:
  br label %bb50
bb54:
  call void @__olang_check_failed(ptr @olang_loc_bad65bd0ec5ef9e2_cc5215fe2456bb0e)
  unreachable
bb55:
  %t126 = load ptr, ptr %l53, !tbaa !29
  store ptr %t126, ptr %l5, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l69, !tbaa !29
  %t128 = load ptr, ptr %l5, !tbaa !29
  %t130 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s0, ptr %s6, ptr %t128, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store { i64, ptr } %t130, ptr %l71
  br label %bb56
bb56:
  %t131 = load ptr, ptr %l5, !tbaa !29
  %t133 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s0, ptr %s6, ptr %t131, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store { i64, ptr } %t133, ptr %l73
  br label %bb57
bb57:
  %t134 = load ptr, ptr %l69, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l73, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eopened(ptr %v0, ptr %s0, ptr %s0, ptr %t134, { i64, ptr } %t135, { i64, ptr } %t136)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb59:
  %t137 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t137, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t139, ptr %l75
  br label %bb60
bb60:
  %t140 = load i1, ptr %l75, !tbaa !21
  br i1 %t140, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s8
  %t141 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l78, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t145 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t141, { i64, ptr } %t142)
  %t146 = extractvalue { i32, ptr } %t145, 1
  %t147 = extractvalue { i32, ptr } %t145, 0
  store i32 %t147, ptr %l81
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb64, label %ok.149
ok.149:
  store ptr %t146, ptr %l80
  br label %bb63
bb62:
  br label %bb91
bb63:
  %t150 = load ptr, ptr %l80, !tbaa !29
  store ptr %t150, ptr %l76, !tbaa !29
  br label %bb68
bb64:
  %t151 = load i32, ptr %l81, !tbaa !23
  %t152 = ashr i32 %t151, 16
  %t154 = icmp eq i32 %t152, 1
  br i1 %t154, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_779866c44d300dd9_2ce9f6dddf4879c5)
  unreachable
bb67:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb68:
  %t156 = load ptr, ptr %l76, !tbaa !29
  store ptr %t156, ptr %l6, !tbaa !29
  %t157 = load ptr, ptr %l6, !tbaa !29
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l86, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t161 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t157, { i64, ptr } %t158)
  %t162 = extractvalue { i32, ptr } %t161, 1
  %t163 = extractvalue { i32, ptr } %t161, 0
  store i32 %t163, ptr %l89
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb70, label %ok.165
ok.165:
  store ptr %t162, ptr %l88
  br label %bb69
bb69:
  %t166 = load ptr, ptr %l88, !tbaa !29
  store ptr %t166, ptr %l84, !tbaa !29
  br label %bb74
bb70:
  %t167 = load i32, ptr %l89, !tbaa !23
  %t168 = ashr i32 %t167, 16
  %t170 = icmp eq i32 %t168, 1
  br i1 %t170, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_88935568e23e9408_fef9f2c10b524914)
  unreachable
bb73:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb74:
  %t172 = load ptr, ptr %l84, !tbaa !29
  %t173 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s0, ptr %s8, ptr %t172, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store { i64, ptr } %t173, ptr %l92
  br label %bb75
bb75:
  %t174 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t174, ptr %l7, !tbaa !27
  %t175 = load ptr, ptr %l6, !tbaa !29
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l95, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t179 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t175, { i64, ptr } %t176)
  %t180 = extractvalue { i32, ptr } %t179, 1
  %t181 = extractvalue { i32, ptr } %t179, 0
  store i32 %t181, ptr %l98
  %t182 = icmp ne i32 %t181, 0
  br i1 %t182, label %bb77, label %ok.183
ok.183:
  store ptr %t180, ptr %l97
  br label %bb76
bb76:
  %t184 = load ptr, ptr %l97, !tbaa !29
  %t185 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %s0, ptr %t184)
  %t186 = extractvalue { i32, { i64, ptr } } %t185, 1
  %t187 = extractvalue { i32, { i64, ptr } } %t185, 0
  store i32 %t187, ptr %l102
  %t188 = icmp ne i32 %t187, 0
  br i1 %t188, label %bb82, label %ok.189
ok.189:
  store { i64, ptr } %t186, ptr %l101
  br label %bb81
bb77:
  %t190 = load i32, ptr %l98, !tbaa !23
  %t191 = ashr i32 %t190, 16
  %t193 = icmp eq i32 %t191, 1
  br i1 %t193, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_8a94f6ccb57e7bff_9da85173f0218233)
  unreachable
bb80:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb81:
  %t195 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t195, ptr %l93, !tbaa !27
  br label %bb85
bb82:
  %t196 = load i32, ptr %l102, !tbaa !23
  %t197 = ashr i32 %t196, 16
  %t199 = icmp eq i32 %t197, 1
  br i1 %t199, label %bb83, label %bb84
bb83:
  br label %bb80
bb84:
  call void @__olang_check_failed(ptr @olang_loc_8a94f6ccb57e7bff_9da85173f0218233)
  unreachable
bb85:
  %t201 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t201, ptr %l8, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t206 = icmp eq i64 %t204, 0
  br i1 %t206, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb87:
  br label %bb88
bb88:
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l108, !tbaa !29
  %t209 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t209, ptr %l109, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t210, ptr %l110, !tbaa !27
  %t211 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t215 = sub i64 %t213, 1
  %t217 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr ptr, ptr %t218, i64 %t215
  %t220 = load ptr, ptr %t219, !tbaa !39
  %t222 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s0, ptr %s8, ptr %t220, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store { i64, ptr } %t222, ptr %l115
  br label %bb89
bb89:
  %t223 = load ptr, ptr %l108, !tbaa !29
  %t224 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l115, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2echanged(ptr %v0, ptr %s0, ptr %s0, ptr %t223, { i64, ptr } %t224, { i64, ptr } %t225)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb91:
  %t226 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t228 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t226, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t228, ptr %l117
  br label %bb92
bb92:
  %t229 = load i1, ptr %l117, !tbaa !21
  br i1 %t229, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s13
  %t230 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l121, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t235 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t230, { i64, ptr } %t232)
  %t236 = extractvalue { i32, ptr } %t235, 1
  %t237 = extractvalue { i32, ptr } %t235, 0
  store i32 %t237, ptr %l124
  %t238 = icmp ne i32 %t237, 0
  br i1 %t238, label %bb96, label %ok.239
ok.239:
  store ptr %t236, ptr %l123
  br label %bb95
bb94:
  br label %bb107
bb95:
  %t240 = load ptr, ptr %l123, !tbaa !29
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l128, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t244 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t240, { i64, ptr } %t241)
  %t245 = extractvalue { i32, ptr } %t244, 1
  %t246 = extractvalue { i32, ptr } %t244, 0
  store i32 %t246, ptr %l131
  %t247 = icmp ne i32 %t246, 0
  br i1 %t247, label %bb101, label %ok.248
ok.248:
  store ptr %t245, ptr %l130
  br label %bb100
bb96:
  %t249 = load i32, ptr %l124, !tbaa !23
  %t250 = ashr i32 %t249, 16
  %t252 = icmp eq i32 %t250, 1
  br i1 %t252, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_927186eff22c45fe_ce09c1db1b05d8b2)
  unreachable
bb99:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb100:
  %t254 = load ptr, ptr %l130, !tbaa !29
  store ptr %t254, ptr %l118, !tbaa !29
  br label %bb104
bb101:
  %t255 = load i32, ptr %l131, !tbaa !23
  %t256 = ashr i32 %t255, 16
  %t258 = icmp eq i32 %t256, 1
  br i1 %t258, label %bb102, label %bb103
bb102:
  br label %bb99
bb103:
  call void @__olang_check_failed(ptr @olang_loc_927186eff22c45fe_ce09c1db1b05d8b2)
  unreachable
bb104:
  %t260 = load ptr, ptr %l118, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l134, !tbaa !29
  %t264 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s0, ptr %s13, ptr %t260, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store { i64, ptr } %t264, ptr %l136
  br label %bb105
bb105:
  %t265 = load ptr, ptr %l134, !tbaa !29
  %t266 = load { i64, ptr }, ptr %l136, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eclosed(ptr %v0, ptr %s0, ptr %t265, { i64, ptr } %t266)
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb107:
  %t267 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t269 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t267, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t269, ptr %l138
  br label %bb108
bb108:
  %t270 = load i1, ptr %l138, !tbaa !21
  br i1 %t270, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb110:
  br label %bb111
bb111:
  %t271 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t274 = insertvalue { i64, ptr } undef, i64 5, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr @G_2ecompiler_2flsp_2eRequests, 1
  %t277 = load ptr, ptr @__olang_prog_scope
  %t280 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t277, ptr %s0, { i64, ptr } %t275, { i64, ptr } %t271)
  store i1 %t280, ptr %l143
  br label %bb112
bb112:
  %t281 = load i1, ptr %l143, !tbaa !21
  br i1 %t281, label %bb113, label %bb114
bb113:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t284 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eask(ptr %v0, ptr %v1, ptr %s0, ptr %t282, { i64, ptr } %t283, { i64, ptr } %t284)
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb116:
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l147, !tbaa !29
  %t289 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t290 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t291 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t294 = extractvalue { i64, ptr } %t290, 1
  %t295 = extractvalue { i64, ptr } %t290, 0
  %t296 = add i64 %t292, %t295
  %t297 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t296)
  call void @olang_textcopy(ptr %t297, ptr %t291, i64 %t292)
  %t298 = getelementptr i8, ptr %t297, i64 %t292
  call void @olang_textcopy(ptr %t298, ptr %t294, i64 %t295)
  %t299 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t297, 1
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = extractvalue { i64, ptr } %t300, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  %t310 = call { i64, ptr } @compiler_2flsp_2eerrorReply(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t289, i64 -32601, { i64, ptr } %t307)
  store { i64, ptr } %t310, ptr %l152
  br label %bb117
bb117:
  %t311 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 0
  %t313 = extractvalue { i64, ptr } %t311, 1
  %t314 = mul i64 %t312, 1
  %t315 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t314)
  call void @llvm.memcpy.p0.p0.i64(ptr %t315, ptr %t313, i64 %t314, i1 false)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t315, 1
  %t318 = load ptr, ptr %l147, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s0, ptr %t318, { i64, ptr } %t317)
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2einitialize(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i32
  %l20 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i32
  %l28 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i32
  %l35 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i32
  %l67 = alloca i1
  %l73 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l80 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t6 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %a1, { i64, ptr } %t3)
  %t7 = extractvalue { i32, ptr } %t6, 1
  %t8 = extractvalue { i32, ptr } %t6, 0
  store i32 %t8, ptr %l15
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb2, label %ok.10
ok.10:
  store ptr %t7, ptr %l14
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l14, !tbaa !29
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t16 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %t11, { i64, ptr } %t13)
  %t17 = extractvalue { i32, ptr } %t16, 1
  %t18 = extractvalue { i32, ptr } %t16, 0
  store i32 %t18, ptr %l23
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb7, label %ok.20
ok.20:
  store ptr %t17, ptr %l22
  br label %bb6
bb2:
  %t21 = load i32, ptr %l15, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b07487623eac622f_c8aa01acfc198fbb)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  %t26 = icmp sge i64 0, 0
  br i1 %t26, label %bb22, label %bb23
bb6:
  %t28 = load ptr, ptr %l22, !tbaa !29
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t33 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %t28, { i64, ptr } %t30)
  %t34 = extractvalue { i32, ptr } %t33, 1
  %t35 = extractvalue { i32, ptr } %t33, 0
  store i32 %t35, ptr %l31
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb11, label %ok.37
ok.37:
  store ptr %t34, ptr %l30
  br label %bb10
bb7:
  %t38 = load i32, ptr %l23, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb8, label %bb9
bb8:
  br label %bb5
bb9:
  call void @__olang_check_failed(ptr @olang_loc_b07487623eac622f_c8aa01acfc198fbb)
  unreachable
bb10:
  %t43 = load ptr, ptr %l30, !tbaa !29
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t47 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v1, ptr %t43, { i64, ptr } %t44)
  %t48 = extractvalue { i32, ptr } %t47, 1
  %t49 = extractvalue { i32, ptr } %t47, 0
  store i32 %t49, ptr %l38
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb15, label %ok.51
ok.51:
  store ptr %t48, ptr %l37
  br label %bb14
bb11:
  %t52 = load i32, ptr %l31, !tbaa !23
  %t53 = ashr i32 %t52, 16
  %t55 = icmp eq i32 %t53, 1
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb5
bb13:
  call void @__olang_check_failed(ptr @olang_loc_b07487623eac622f_c8aa01acfc198fbb)
  unreachable
bb14:
  %t57 = load ptr, ptr %l37, !tbaa !29
  %t58 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %v1, ptr %t57)
  %t59 = extractvalue { i32, { i64, ptr } } %t58, 1
  %t60 = extractvalue { i32, { i64, ptr } } %t58, 0
  store i32 %t60, ptr %l42
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb19, label %ok.62
ok.62:
  store { i64, ptr } %t59, ptr %l41
  br label %bb18
bb15:
  %t63 = load i32, ptr %l38, !tbaa !23
  %t64 = ashr i32 %t63, 16
  %t66 = icmp eq i32 %t64, 1
  br i1 %t66, label %bb16, label %bb17
bb16:
  br label %bb5
bb17:
  call void @__olang_check_failed(ptr @olang_loc_b07487623eac622f_c8aa01acfc198fbb)
  unreachable
bb18:
  %t68 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t68, ptr %l9, !tbaa !27
  br label %bb26
bb19:
  %t69 = load i32, ptr %l42, !tbaa !23
  %t70 = ashr i32 %t69, 16
  %t72 = icmp eq i32 %t70, 1
  br i1 %t72, label %bb20, label %bb21
bb20:
  br label %bb5
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b07487623eac622f_c8aa01acfc198fbb)
  unreachable
bb22:
  %t74 = icmp sle i64 0, 1152921504606846975
  br i1 %t74, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_d23162b8215dec1d_483a007ef8846361)
  unreachable
bb24:
  %t76 = mul i64 0, 8
  %t77 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t76)
  %t78 = insertvalue { i64, ptr } undef, i64 0, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l9, !tbaa !27
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_d23162b8215dec1d_483a007ef8846361)
  unreachable
bb26:
  %t81 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t81, ptr %l3, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t86 = icmp sgt i64 %t84, 0
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t88 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t88, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  store i64 %t92, ptr %l6, !tbaa !24
  br label %bb29
bb28:
  br label %bb45
bb29:
  store %olang.scope zeroinitializer, ptr %s3
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb31:
  br label %bb32
bb32:
  %t102 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t102, ptr %l58, !tbaa !27
  %t103 = load i64, ptr %l5, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 %t103
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t112 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v1, ptr %t108)
  %t113 = extractvalue { i32, { i64, ptr } } %t112, 1
  %t114 = extractvalue { i32, { i64, ptr } } %t112, 0
  store i32 %t114, ptr %l64
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb34, label %ok.116
ok.116:
  store { i64, ptr } %t113, ptr %l63
  br label %bb33
bb33:
  %t117 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t117, ptr %l61, !tbaa !27
  br label %bb38
bb34:
  %t118 = load i32, ptr %l64, !tbaa !23
  %t119 = ashr i32 %t118, 16
  %t121 = icmp eq i32 %t119, 1
  br i1 %t121, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_712aaea22fe89d25_c40047bf6049dd1)
  unreachable
bb37:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l61, !tbaa !27
  br label %bb38
bb38:
  %t123 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t124 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t123, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t124, ptr %l67
  br label %bb39
bb39:
  %t125 = load i1, ptr %l67, !tbaa !21
  br i1 %t125, label %bb40, label %bb41
bb40:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/lsp:Server", ptr %t126, i32 0, i32 2
  store i1 true, ptr %t128, !tbaa !21
  br label %bb42
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  %t129 = load i64, ptr %l5, !tbaa !24
  %t131 = add i64 %t129, 1
  store i64 %t131, ptr %l5, !tbaa !24
  br label %bb29
bb44:
  br label %bb45
bb45:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/lsp:Server", ptr %t133, i32 0, i32 2
  %t136 = load i1, ptr %t135, !tbaa !21
  br i1 %t136, label %bb46, label %bb47
bb46:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l73, !tbaa !27
  br label %bb48
bb47:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l73, !tbaa !27
  br label %bb48
bb48:
  %t138 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t140 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = add i64 %t139, %t142
  %t144 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t146 = add i64 %t143, %t145
  %t147 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = extractvalue { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t151 = extractvalue { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t152 = add i64 %t149, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t138, i64 %t139)
  %t154 = getelementptr i8, ptr %t153, i64 %t139
  call void @olang_textcopy(ptr %t154, ptr %t141, i64 %t142)
  %t155 = getelementptr i8, ptr %t154, i64 %t142
  call void @olang_textcopy(ptr %t155, ptr %t144, i64 %t145)
  %t156 = getelementptr i8, ptr %t155, i64 %t145
  call void @olang_textcopy(ptr %t156, ptr %t147, i64 %t148)
  %t157 = getelementptr i8, ptr %t156, i64 %t148
  call void @olang_textcopy(ptr %t157, ptr %t150, i64 %t151)
  %t158 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t153, 1
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l75, !tbaa !29
  %t164 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t167 = extractvalue { i64, ptr } %t159, 1
  %t168 = extractvalue { i64, ptr } %t159, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t164, i64 %t165)
  %t174 = getelementptr i8, ptr %t173, i64 %t165
  call void @olang_textcopy(ptr %t174, ptr %t167, i64 %t168)
  %t175 = getelementptr i8, ptr %t174, i64 %t168
  call void @olang_textcopy(ptr %t175, ptr %t170, i64 %t171)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t173, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = extractvalue { i64, ptr } %t177, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t187 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %a2, { i64, ptr } %t184)
  store { i64, ptr } %t187, ptr %l80
  br label %bb49
bb49:
  %t188 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = extractvalue { i64, ptr } %t188, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  %t195 = load ptr, ptr %l75, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s0, ptr %t195, { i64, ptr } %t194)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2enote(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i32
  %l21 = alloca i64
  %l23 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i32
  %l29 = alloca i64
  %l30 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i64
  %l39 = alloca i64
  %l44 = alloca i1
  %l48 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca i32
  %l59 = alloca { i64, ptr }
  %l60 = alloca i32
  %l70 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l75 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i32
  %l85 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca i32
  %l93 = alloca { i64, ptr }
  %l94 = alloca i32
  %l104 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, ptr } @std_2fjson_2eParse(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %a1, ptr null)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l18
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store ptr %t4, ptr %l17
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l17, !tbaa !29
  store ptr %t8, ptr %l15, !tbaa !29
  br label %bb6
bb2:
  %t9 = load i32, ptr %l18, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5c32fdd2254e4c55_6ae9d0a3a84d2bb1)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t14 = load ptr, ptr %l15, !tbaa !29
  store ptr %t14, ptr %l2, !tbaa !29
  %t15 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t19 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t15, { i64, ptr } %t16)
  %t20 = extractvalue { i32, ptr } %t19, 1
  %t21 = extractvalue { i32, ptr } %t19, 0
  store i32 %t21, ptr %l26
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb8, label %ok.23
ok.23:
  store ptr %t20, ptr %l25
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l25, !tbaa !29
  %t25 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %s0, ptr %t24)
  %t26 = extractvalue { i32, i64 } %t25, 1
  %t27 = extractvalue { i32, i64 } %t25, 0
  store i32 %t27, ptr %l30
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb13, label %ok.29
ok.29:
  store i64 %t26, ptr %l29
  br label %bb12
bb8:
  %t30 = load i32, ptr %l26, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  br i1 %t33, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_17725019f9643264_c99bbb5f098da7a0)
  unreachable
bb11:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb16
bb12:
  %t35 = load i64, ptr %l29, !tbaa !24
  store i64 %t35, ptr %l21, !tbaa !24
  br label %bb16
bb13:
  %t36 = load i32, ptr %l30, !tbaa !23
  %t37 = ashr i32 %t36, 16
  %t39 = icmp eq i32 %t37, 1
  br i1 %t39, label %bb14, label %bb15
bb14:
  br label %bb11
bb15:
  call void @__olang_check_failed(ptr @olang_loc_17725019f9643264_c99bbb5f098da7a0)
  unreachable
bb16:
  %t41 = load i64, ptr %l21, !tbaa !24
  store i64 %t41, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp slt i64 %t42, 0
  br i1 %t44, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb20
bb18:
  %t46 = load i64, ptr %l3, !tbaa !24
  store i64 %t46, ptr %l36, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/lsp:Server", ptr %t47, i32 0, i32 1
  %t51 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H1531dad62b744074bb3be3226dd54f14(ptr %v0, ptr %t49)
  store i64 %t51, ptr %l39
  br label %bb19
bb19:
  %t52 = load i64, ptr %l36, !tbaa !24
  %t53 = load i64, ptr %l39, !tbaa !24
  %t54 = icmp sge i64 %t52, %t53
  store i1 %t54, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t56 = load i1, ptr %l35, !tbaa !21
  br i1 %t56, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  br label %bb23
bb23:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lsp:Server", ptr %t57, i32 0, i32 4
  %t60 = load i64, ptr %l3, !tbaa !24
  %t63 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemove_3cI64_3e(ptr %v0, ptr %t59, i64 %t60)
  store i1 %t63, ptr %l44
  br label %bb24
bb24:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/lsp:Server", ptr %t64, i32 0, i32 1
  %t67 = load i64, ptr %l3, !tbaa !24
  %t70 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l48
  br label %bb25
bb25:
  %t71 = load ptr, ptr %l48, !tbaa !29
  store ptr %t71, ptr %l4, !tbaa !29
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t74 = getelementptr %"compiler/lsp:Doc", ptr %t72, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t74)
  br label %bb26
bb26:
  %t76 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l53, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t80 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t76, { i64, ptr } %t77)
  %t81 = extractvalue { i32, ptr } %t80, 1
  %t82 = extractvalue { i32, ptr } %t80, 0
  store i32 %t82, ptr %l56
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb28, label %ok.84
ok.84:
  store ptr %t81, ptr %l55
  br label %bb27
bb27:
  %t85 = load ptr, ptr %l55, !tbaa !29
  %t86 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %s0, ptr %t85)
  %t87 = extractvalue { i32, { i64, ptr } } %t86, 1
  %t88 = extractvalue { i32, { i64, ptr } } %t86, 0
  store i32 %t88, ptr %l60
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb33, label %ok.90
ok.90:
  store { i64, ptr } %t87, ptr %l59
  br label %bb32
bb28:
  %t91 = load i32, ptr %l56, !tbaa !23
  %t92 = ashr i32 %t91, 16
  %t94 = icmp eq i32 %t92, 1
  br i1 %t94, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_f638230cb743249f_247d31742d58659b)
  unreachable
bb31:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t96 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t96, ptr %l51, !tbaa !27
  br label %bb36
bb33:
  %t97 = load i32, ptr %l60, !tbaa !23
  %t98 = ashr i32 %t97, 16
  %t100 = icmp eq i32 %t98, 1
  br i1 %t100, label %bb34, label %bb35
bb34:
  br label %bb31
bb35:
  call void @__olang_check_failed(ptr @olang_loc_f638230cb743249f_247d31742d58659b)
  unreachable
bb36:
  %t102 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t102, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %l8, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s5
  %t109 = load i64, ptr %l7, !tbaa !24
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb39:
  br label %bb40
bb40:
  %t117 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t117, ptr %l70, !tbaa !27
  %t118 = load i64, ptr %l7, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr ptr, ptr %t121, i64 %t118
  %t123 = load ptr, ptr %t122, !tbaa !39
  %t125 = load ptr, ptr %l4, !tbaa !29
  %t127 = getelementptr %"compiler/lsp:Doc", ptr %t125, i32 0, i32 5
  store ptr %t127, ptr %l74, !tbaa !29
  %t130 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %s0, ptr %t123)
  %t131 = extractvalue { i32, i64 } %t130, 1
  %t132 = extractvalue { i32, i64 } %t130, 0
  store i32 %t132, ptr %l78
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb42, label %ok.134
ok.134:
  store i64 %t131, ptr %l77
  br label %bb41
bb41:
  %t135 = load i64, ptr %l77, !tbaa !24
  store i64 %t135, ptr %l75, !tbaa !24
  br label %bb46
bb42:
  %t136 = load i32, ptr %l78, !tbaa !23
  %t137 = ashr i32 %t136, 16
  %t139 = icmp eq i32 %t137, 1
  br i1 %t139, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_8dd922756996ba1e_e7fa0e8ed65b4b9a)
  unreachable
bb45:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l75, !tbaa !24
  br label %bb46
bb46:
  %t141 = load ptr, ptr %l74, !tbaa !29
  %t142 = load i64, ptr %l75, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t141, i64 %t142)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb48:
  %t143 = load i64, ptr %l7, !tbaa !24
  %t145 = add i64 %t143, 1
  store i64 %t145, ptr %l7, !tbaa !24
  br label %bb37
bb49:
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t149 = getelementptr %"compiler/lsp:Doc", ptr %t147, i32 0, i32 6
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H962a30edd485f38e7d3abb41262b569a(ptr %v0, ptr %t149)
  br label %bb50
bb50:
  %t151 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l87, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t155 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t151, { i64, ptr } %t152)
  %t156 = extractvalue { i32, ptr } %t155, 1
  %t157 = extractvalue { i32, ptr } %t155, 0
  store i32 %t157, ptr %l90
  %t158 = icmp ne i32 %t157, 0
  br i1 %t158, label %bb52, label %ok.159
ok.159:
  store ptr %t156, ptr %l89
  br label %bb51
bb51:
  %t160 = load ptr, ptr %l89, !tbaa !29
  %t161 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %s0, ptr %t160)
  %t162 = extractvalue { i32, { i64, ptr } } %t161, 1
  %t163 = extractvalue { i32, { i64, ptr } } %t161, 0
  store i32 %t163, ptr %l94
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb57, label %ok.165
ok.165:
  store { i64, ptr } %t162, ptr %l93
  br label %bb56
bb52:
  %t166 = load i32, ptr %l90, !tbaa !23
  %t167 = ashr i32 %t166, 16
  %t169 = icmp eq i32 %t167, 1
  br i1 %t169, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_ea7eed99d59acef9_46ecfb6f0a8a862d)
  unreachable
bb55:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  %t171 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t171, ptr %l85, !tbaa !27
  br label %bb60
bb57:
  %t172 = load i32, ptr %l94, !tbaa !23
  %t173 = ashr i32 %t172, 16
  %t175 = icmp eq i32 %t173, 1
  br i1 %t175, label %bb58, label %bb59
bb58:
  br label %bb55
bb59:
  call void @__olang_check_failed(ptr @olang_loc_ea7eed99d59acef9_46ecfb6f0a8a862d)
  unreachable
bb60:
  %t177 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t177, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  store i64 %t182, ptr %l13, !tbaa !24
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s9
  %t184 = load i64, ptr %l12, !tbaa !24
  %t185 = load i64, ptr %l13, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s9)
  br label %bb73
bb63:
  br label %bb64
bb64:
  %t192 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t192, ptr %l104, !tbaa !27
  %t193 = load i64, ptr %l12, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr ptr, ptr %t196, i64 %t193
  %t198 = load ptr, ptr %t197, !tbaa !39
  %t200 = load ptr, ptr %l4, !tbaa !29
  %t202 = getelementptr %"compiler/lsp:Doc", ptr %t200, i32 0, i32 6
  store ptr %t202, ptr %l108, !tbaa !29
  %t205 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %s0, ptr %t198)
  %t206 = extractvalue { i32, { i64, ptr } } %t205, 1
  %t207 = extractvalue { i32, { i64, ptr } } %t205, 0
  store i32 %t207, ptr %l112
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb66, label %ok.209
ok.209:
  store { i64, ptr } %t206, ptr %l111
  br label %bb65
bb65:
  %t210 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t210, ptr %l109, !tbaa !27
  br label %bb70
bb66:
  %t211 = load i32, ptr %l112, !tbaa !23
  %t212 = ashr i32 %t211, 16
  %t214 = icmp eq i32 %t212, 1
  br i1 %t214, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_f1b3f1e4d6991028_b1cc0ac5434ca67c)
  unreachable
bb69:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l109, !tbaa !27
  br label %bb70
bb70:
  %t216 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = extractvalue { i64, ptr } %t216, 0
  %t219 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t217, i64 %t218)
  %t220 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = extractvalue { i64, ptr } %t221, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  %t229 = load ptr, ptr %l108, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t229, { i64, ptr } %t228)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s9)
  br label %bb72
bb72:
  %t231 = load i64, ptr %l12, !tbaa !24
  %t233 = add i64 %t231, 1
  store i64 %t233, ptr %l12, !tbaa !24
  br label %bb61
bb73:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eopened(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l68 = alloca %"compiler/lsp:Doc"
  %l75 = alloca i64
  %l80 = alloca ptr
  %l89 = alloca ptr
  %l91 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call i64 @compiler_2flsp_2ecompiler_2flsp_3aServer_2eslotOf(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t2)
  store i64 %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load i64, ptr %l15, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t13 = call { i64, ptr } @compiler_2flsp_2ePathOf(ptr %v1, ptr %s1, { i64, ptr } %t11)
  store { i64, ptr } %t13, ptr %l19
  br label %bb4
bb3:
  br label %bb33
bb4:
  %t14 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t14, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/lsp:Server", ptr %t15, i32 0, i32 1
  %t19 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H1531dad62b744074bb3be3226dd54f14(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l22
  br label %bb5
bb5:
  %t20 = load i64, ptr %l22, !tbaa !24
  store i64 %t20, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb11
bb8:
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l29, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l29, !tbaa !24
  store i64 %t47, ptr %l26, !tbaa !24
  br label %bb11
bb11:
  %t48 = load i64, ptr %l26, !tbaa !24
  store i64 %t48, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t58 = load i64, ptr %l9, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l10, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lsp:Server", ptr %t67, i32 0, i32 1
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l50
  br label %bb16
bb16:
  %t74 = load ptr, ptr %l50, !tbaa !29
  %t76 = getelementptr %"compiler/lsp:Doc", ptr %t74, i32 0, i32 4
  %t77 = load i1, ptr %t76, !tbaa !21
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb17, label %bb18
bb17:
  %t81 = load i64, ptr %l10, !tbaa !24
  store i64 %t81, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l9, !tbaa !24
  br label %bb12
bb21:
  %t87 = load i64, ptr %l3, !tbaa !24
  %t89 = icmp slt i64 %t87, 0
  br i1 %t89, label %bb22, label %bb23
bb22:
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 1
  %t94 = extractvalue { i64, ptr } %t91, 0
  %t95 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t93, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = extractvalue { i64, ptr } %t97, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l61, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = extractvalue { i64, ptr } %t105, 0
  %t109 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t107, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = extractvalue { i64, ptr } %t111, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l64, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %s1, ptr %v0, { i64, ptr } %t119)
  store { i64, ptr } %t121, ptr %l66
  br label %bb24
bb23:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/lsp:Server", ptr %t122, i32 0, i32 1
  %t125 = load i64, ptr %l3, !tbaa !24
  %t128 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t124, i64 %t125)
  store ptr %t128, ptr %l80
  br label %bb28
bb24:
  %t129 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  %t131 = extractvalue { i64, ptr } %t129, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  %t136 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t139 = call %"compiler/lsp:Doc" @compiler_2flsp_3aDoc_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t136, { i64, ptr } %t137, { i64, ptr } %t135)
  store %"compiler/lsp:Doc" %t139, ptr %l68
  br label %bb25
bb25:
  %t140 = load %"compiler/lsp:Doc", ptr %l68
  %t141 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 80, i64 8)
  store %"compiler/lsp:Doc" %t140, ptr %t141
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/lsp:Server", ptr %t143, i32 0, i32 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_Hc8e24fa4dba7e8fd650818e9a0171b72(ptr %v0, ptr %v0, ptr %t145, ptr %t141)
  br label %bb26
bb26:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/lsp:Server", ptr %t149, i32 0, i32 1
  %t153 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H1531dad62b744074bb3be3226dd54f14(ptr %v0, ptr %t151)
  store i64 %t153, ptr %l75
  br label %bb27
bb27:
  %t154 = load i64, ptr %l75, !tbaa !24
  %t155 = sub i64 %t154, 1
  store i64 %t155, ptr %l3, !tbaa !24
  br label %bb32
bb28:
  %t157 = load ptr, ptr %l80, !tbaa !29
  store ptr %t157, ptr %l12, !tbaa !29
  %t158 = load ptr, ptr %l12, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 1
  %t162 = extractvalue { i64, ptr } %t159, 0
  %t163 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t162)
  call void @olang_textcopy(ptr %t163, ptr %t161, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = extractvalue { i64, ptr } %t165, 1
  %t169 = mul i64 %t167, 1
  %t170 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t169)
  call void @llvm.memcpy.p0.p0.i64(ptr %t170, ptr %t168, i64 %t169, i1 false)
  %t171 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  %t175 = getelementptr %"compiler/lsp:Doc", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t172, ptr %t175, !tbaa !27
  %t176 = load ptr, ptr %l12, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 1
  %t180 = extractvalue { i64, ptr } %t177, 0
  %t181 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t179, i64 %t180)
  %t182 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t193 = getelementptr %"compiler/lsp:Doc", ptr %t176, i32 0, i32 1
  store { i64, ptr } %t190, ptr %t193, !tbaa !27
  %t194 = load ptr, ptr %l12, !tbaa !29
  store ptr %t194, ptr %l89, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t197 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %s1, ptr %v0, { i64, ptr } %t195)
  store { i64, ptr } %t197, ptr %l91
  br label %bb29
bb29:
  %t198 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  %t200 = extractvalue { i64, ptr } %t198, 1
  %t201 = mul i64 %t199, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  %t206 = load ptr, ptr %l89, !tbaa !29
  %t207 = getelementptr %"compiler/lsp:Doc", ptr %t206, i32 0, i32 2
  store { i64, ptr } %t204, ptr %t207, !tbaa !27
  %t208 = load ptr, ptr %l12, !tbaa !29
  %t210 = getelementptr %"compiler/lsp:Doc", ptr %t208, i32 0, i32 4
  store i1 true, ptr %t210, !tbaa !21
  %t211 = load ptr, ptr %l12, !tbaa !29
  %t213 = getelementptr %"compiler/lsp:Doc", ptr %t211, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t213)
  br label %bb30
bb30:
  %t215 = load ptr, ptr %l12, !tbaa !29
  %t217 = getelementptr %"compiler/lsp:Doc", ptr %t215, i32 0, i32 6
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H962a30edd485f38e7d3abb41262b569a(ptr %v0, ptr %t217)
  br label %bb31
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s1)
  br label %bb33
bb33:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esetText(ptr %v0, ptr %v2, ptr %t219, i64 %t220, { i64, ptr } %a2)
  br label %bb34
bb34:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fsession_2eWriteFramed(ptr %v1, i32 1, { i64, ptr } %a1)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esetText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l7 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:Server", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/lsp:Doc", ptr %t9, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %t11)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t15 = getelementptr %"compiler/lsp:Doc", ptr %t13, i32 0, i32 3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %a2)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2edue(ptr %v0, ptr %t19, i64 %t20)
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2flsp_2ecompiler_2flsp_3aServer_2eslotOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca ptr
  %l41 = alloca i1
  %l45 = alloca ptr
  %l49 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:Server", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H1531dad62b744074bb3be3226dd54f14(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/lsp:Server", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l38, !tbaa !29
  %t62 = getelementptr %"compiler/lsp:Doc", ptr %t60, i32 0, i32 4
  %t63 = load i1, ptr %t62, !tbaa !21
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/lsp:Server", ptr %t65, i32 0, i32 1
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l45
  br label %bb15
bb14:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb17
bb15:
  %t72 = load ptr, ptr %l45, !tbaa !29
  %t74 = getelementptr %"compiler/lsp:Doc", ptr %t72, i32 0, i32 0
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t75, { i64, ptr } %a1)
  store i1 %t79, ptr %l49
  br label %bb16
bb16:
  %t80 = load i1, ptr %l49, !tbaa !21
  store i1 %t80, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t81 = load i1, ptr %l41, !tbaa !21
  br i1 %t81, label %bb18, label %bb19
bb18:
  %t82 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t82, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t84 = load i64, ptr %l6, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l6, !tbaa !24
  br label %bb8
bb22:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estartWorker(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i32, i32 }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i32, i32 }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l13 = alloca { i32, i32 }
  %l16 = alloca { i32, i32 }
  %l21 = alloca i1
  %l28 = alloca i32
  %l40 = alloca %"compiler/lsp:worker"
  %l49 = alloca ptr
  %l51 = alloca %"compiler/session:Reader"
  %l53 = alloca ptr
  %l54 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:Server", ptr %t1, i32 0, i32 6
  store i64 0, ptr %t3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/lsp:Server", ptr %t4, i32 0, i32 3
  %t7 = getelementptr %"compiler/lsp:Worker", ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = icmp sgt i32 %t8, 0
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = call { i32, i32 } @compiler_2fsession_2ePipe()
  store { i32, i32 } %t12, ptr %l13
  br label %bb4
bb4:
  %t13 = load { i32, i32 }, ptr %l13
  store { i32, i32 } %t13, ptr %l1
  %t14 = getelementptr { i32, i32 }, ptr %l1, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  store i32 %t15, ptr %l2, !tbaa !23
  %t17 = getelementptr { i32, i32 }, ptr %l1, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = call { i32, i32 } @compiler_2fsession_2ePipe()
  store { i32, i32 } %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load { i32, i32 }, ptr %l16
  store { i32, i32 } %t21, ptr %l4
  %t22 = getelementptr { i32, i32 }, ptr %l4, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  store i32 %t23, ptr %l5, !tbaa !23
  %t25 = getelementptr { i32, i32 }, ptr %l4, i32 0, i32 1
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l6, !tbaa !23
  %t28 = load i32, ptr %l2, !tbaa !23
  %t30 = icmp slt i32 %t28, 0
  br i1 %t30, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t32 = load i32, ptr %l5, !tbaa !23
  %t34 = icmp slt i32 %t32, 0
  store i1 %t34, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t37 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t37)
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t39 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t39)
  br label %bb12
bb12:
  %t41 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t41)
  br label %bb13
bb13:
  %t43 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t43)
  br label %bb14
bb14:
  br label %ret
bb15:
  %t45 = call i32 @compiler_2fsession_2eFork()
  store i32 %t45, ptr %l28
  br label %bb16
bb16:
  %t46 = load i32, ptr %l28, !tbaa !23
  store i32 %t46, ptr %l7, !tbaa !23
  %t47 = load i32, ptr %l7, !tbaa !23
  %t49 = icmp slt i32 %t47, 0
  br i1 %t49, label %bb17, label %bb18
bb17:
  br label %ret
bb18:
  br label %bb19
bb19:
  %t51 = load i32, ptr %l7, !tbaa !23
  %t53 = icmp eq i32 %t51, 0
  br i1 %t53, label %bb20, label %bb21
bb20:
  %t55 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t55)
  br label %bb22
bb21:
  br label %bb28
bb22:
  %t57 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t57)
  br label %bb23
bb23:
  call void @compiler_2fsession_2eDup2(i32 2, i32 1)
  br label %bb24
bb24:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/lsp:Server", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i32, ptr %l2, !tbaa !23
  %t65 = load i32, ptr %l6, !tbaa !23
  %t70 = call %"compiler/lsp:worker" @compiler_2flsp_3aworker_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t59, ptr %t63, i32 %t64, i32 %t65)
  store %"compiler/lsp:worker" %t70, ptr %l40
  br label %bb25
bb25:
  %t71 = load %"compiler/lsp:worker", ptr %l40
  %t72 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/lsp:worker" %t71, ptr %t72
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2eRun(ptr %v0, ptr %t72)
  br label %bb26
bb26:
  call void @compiler_2fsession_2eExit(i32 0)
  unreachable
bb27:
  call void @__olang_check_failed(ptr @olang_loc_1521364e571a2f2d_bf1cb7a51b345899)
  unreachable
bb28:
  %t76 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t76)
  br label %bb29
bb29:
  %t78 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t78)
  br label %bb30
bb30:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l7, !tbaa !23
  %t84 = getelementptr %"compiler/lsp:Server", ptr %t80, i32 0, i32 3
  %t85 = getelementptr %"compiler/lsp:Worker", ptr %t84, i32 0, i32 0
  store i32 %t81, ptr %t85, !tbaa !23
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = getelementptr %"compiler/lsp:Server", ptr %t86, i32 0, i32 3
  %t91 = getelementptr %"compiler/lsp:Worker", ptr %t90, i32 0, i32 1
  store i32 %t87, ptr %t91, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l49, !tbaa !29
  %t93 = load i32, ptr %l5, !tbaa !23
  %t95 = call %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %v0, i32 %t93)
  store %"compiler/session:Reader" %t95, ptr %l51
  br label %bb31
bb31:
  %t96 = load %"compiler/session:Reader", ptr %l51
  %t97 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/session:Reader" %t96, ptr %t97
  %t99 = load ptr, ptr %l49, !tbaa !29
  %t100 = getelementptr %"compiler/lsp:Server", ptr %t99, i32 0, i32 3
  %t101 = getelementptr %"compiler/lsp:Worker", ptr %t100, i32 0, i32 2
  store ptr %t97, ptr %t101, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l53, !tbaa !29
  %t103 = call i64 @std_2ftime_2eNow()
  store i64 %t103, ptr %l54
  br label %bb32
bb32:
  %t104 = load i64, ptr %l54, !tbaa !24
  %t105 = load ptr, ptr %l53, !tbaa !29
  %t106 = getelementptr %"compiler/lsp:Server", ptr %t105, i32 0, i32 3
  %t107 = getelementptr %"compiler/lsp:Worker", ptr %t106, i32 0, i32 3
  store i64 %t104, ptr %t107, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2estopWorker(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l24 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:Server", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/lsp:Worker", ptr %t3, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = icmp sle i32 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lsp:Server", ptr %t9, i32 0, i32 3
  %t12 = getelementptr %"compiler/lsp:Worker", ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  call void @compiler_2fsession_2eKillAndReap(i32 %t13)
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2ecloseWorker(ptr %v0, ptr %t15)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lsp:Server", ptr %t17, i32 0, i32 5
  store ptr %t19, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load i64, ptr %l2, !tbaa !24
  store i64 %t21, ptr %l12, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l14
  br label %bb7
bb7:
  %t25 = load i64, ptr %l12, !tbaa !24
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = icmp slt i64 %t25, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l19
  br label %bb11
bb11:
  %t36 = load i64, ptr %l19, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l20, !tbaa !29
  %t40 = call i64 @__olang_fmt_i64(ptr null, i64 %t36)
  %t41 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t40)
  %t42 = call i64 @__olang_fmt_i64(ptr %t41, i64 %t36)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t53 = call { i64, ptr } @compiler_2flsp_2eerrorReply(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t51, i64 -32801, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store { i64, ptr } %t53, ptr %l24
  br label %bb12
bb12:
  %t54 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t61 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s3, ptr %t61, { i64, ptr } %t60)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t63 = load i64, ptr %l2, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l2, !tbaa !24
  br label %bb6
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/lsp:Server", ptr %t67, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t69)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aServer_2eworkerLost(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l40 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l54 = alloca i64
  %l56 = alloca i64
  %l61 = alloca i64
  %l62 = alloca ptr
  %l66 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:Server", ptr %t1, i32 0, i32 3
  %t4 = getelementptr %"compiler/lsp:Worker", ptr %t3, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  %t7 = icmp sgt i32 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/lsp:Server", ptr %t9, i32 0, i32 3
  %t12 = getelementptr %"compiler/lsp:Worker", ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  call void @compiler_2fsession_2eKillAndReap(i32 %t13)
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2ecloseWorker(ptr %v0, ptr %t15)
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/lsp:Server", ptr %t17, i32 0, i32 4
  store ptr %t19, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load i64, ptr %l3, !tbaa !24
  store i64 %t21, ptr %l16, !tbaa !24
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t22)
  store i64 %t24, ptr %l18
  br label %bb7
bb7:
  %t25 = load i64, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = icmp slt i64 %t25, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb9:
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l23
  br label %bb11
bb11:
  %t36 = load i64, ptr %l23, !tbaa !24
  store i64 %t36, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  store i64 %t37, ptr %l24, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/lsp:Server", ptr %t38, i32 0, i32 1
  %t42 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H1531dad62b744074bb3be3226dd54f14(ptr %v0, ptr %t40)
  store i64 %t42, ptr %l27
  br label %bb12
bb12:
  %t43 = load i64, ptr %l24, !tbaa !24
  %t44 = load i64, ptr %l27, !tbaa !24
  %t45 = icmp slt i64 %t43, %t44
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/lsp:Server", ptr %t47, i32 0, i32 1
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t49, i64 %t50)
  store ptr %t53, ptr %l33
  br label %bb15
bb14:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb16
bb15:
  %t54 = load ptr, ptr %l33, !tbaa !29
  %t56 = getelementptr %"compiler/lsp:Doc", ptr %t54, i32 0, i32 4
  %t57 = load i1, ptr %t56, !tbaa !21
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t59 = load i1, ptr %l29, !tbaa !21
  br i1 %t59, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l36, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/lsp:Server", ptr %t61, i32 0, i32 1
  %t64 = load i64, ptr %l4, !tbaa !24
  %t67 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t63, i64 %t64)
  store ptr %t67, ptr %l40
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t68 = load ptr, ptr %l40, !tbaa !29
  %t70 = getelementptr %"compiler/lsp:Doc", ptr %t68, i32 0, i32 0
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l42, !tbaa !27
  %t74 = call { i64, ptr } @compiler_2flsp_2elostDiagnostic(ptr %v1, ptr %s4, { i64, ptr } %a1)
  store { i64, ptr } %t74, ptr %l44
  br label %bb20
bb20:
  %t75 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  %t82 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t84 = call { i64, ptr } @compiler_2flsp_2epublish(ptr %v0, ptr %s4, ptr %s4, { i64, ptr } %t82, { i64, ptr } %t81)
  store { i64, ptr } %t84, ptr %l46
  br label %bb21
bb21:
  %t85 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t92 = load ptr, ptr %l36, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s4, ptr %t92, { i64, ptr } %t91)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t94 = load i64, ptr %l3, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l3, !tbaa !24
  br label %bb6
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/lsp:Server", ptr %t98, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t100)
  br label %bb26
bb26:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/lsp:Server", ptr %t102, i32 0, i32 5
  store ptr %t104, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t106 = load i64, ptr %l6, !tbaa !24
  store i64 %t106, ptr %l54, !tbaa !24
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t107)
  store i64 %t109, ptr %l56
  br label %bb28
bb28:
  %t110 = load i64, ptr %l54, !tbaa !24
  %t111 = load i64, ptr %l56, !tbaa !24
  %t112 = icmp slt i64 %t110, %t111
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb30:
  br label %bb31
bb31:
  %t116 = load ptr, ptr %l5, !tbaa !29
  %t117 = load i64, ptr %l6, !tbaa !24
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t116, i64 %t117)
  store i64 %t120, ptr %l61
  br label %bb32
bb32:
  %t121 = load i64, ptr %l61, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l62, !tbaa !29
  %t125 = call i64 @__olang_fmt_i64(ptr null, i64 %t121)
  %t126 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t125)
  %t127 = call i64 @__olang_fmt_i64(ptr %t126, i64 %t121)
  %t128 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t126, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = extractvalue { i64, ptr } %t129, 1
  %t133 = mul i64 %t131, 1
  %t134 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  %t138 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s7, ptr %s7, ptr %s7, { i64, ptr } %t136, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store { i64, ptr } %t138, ptr %l66
  br label %bb33
bb33:
  %t139 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  %t141 = extractvalue { i64, ptr } %t139, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  %t146 = load ptr, ptr %l62, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aServer_2esend(ptr %v0, ptr %s7, ptr %t146, { i64, ptr } %t145)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t148 = load i64, ptr %l6, !tbaa !24
  %t150 = add i64 %t148, 1
  store i64 %t150, ptr %l6, !tbaa !24
  br label %bb27
bb36:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/lsp:Server", ptr %t152, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t154)
  br label %bb37
bb37:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2eRun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca %"compiler/session:Reader"
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l28 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l50 = alloca i64
  %l52 = alloca i64
  %l57 = alloca i64
  %l64 = alloca %"compiler/session:Reader"
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:worker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lsp:Server", ptr %t4, i32 0, i32 1
  store ptr %t6, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_Hc8f637dbd3c39b4e5f02c4f7fcfa329b(ptr %v0, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l19
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l18
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  br label %bb7
bb3:
  %t18 = load i32, ptr %l19, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_808e0602b7ec4f9f_4ebb0156f1026a43)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb7:
  %t23 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t36, ptr %l28, !tbaa !27
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 %t37
  %t42 = load ptr, ptr %t41, !tbaa !39
  store ptr %t42, ptr %l6, !tbaa !29
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = getelementptr %"compiler/lsp:Doc", ptr %t44, i32 0, i32 4
  %t47 = load i1, ptr %t46, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/lsp:worker", ptr %t49, i32 0, i32 4
  store ptr %t51, ptr %l34, !tbaa !29
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = getelementptr %"compiler/lsp:Doc", ptr %t52, i32 0, i32 2
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t57, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = extractvalue { i64, ptr } %t61, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l38, !tbaa !27
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr %"compiler/lsp:Doc", ptr %t69, i32 0, i32 3
  %t73 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v0, ptr %t71)
  store { i64, ptr } %t73, ptr %l41
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t74 = load ptr, ptr %l34, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t74, { i64, ptr } %t75, { i64, ptr } %t76)
  br label %bb15
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t77 = load i64, ptr %l5, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l5, !tbaa !24
  br label %bb8
bb18:
  %t81 = load i64, ptr %l2, !tbaa !24
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t81, %t82
  store i64 %t85, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  br label %bb1
bb20:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/lsp:worker", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/lsp:Server", ptr %t90, i32 0, i32 4
  store ptr %t92, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  %t94 = load i64, ptr %l8, !tbaa !24
  store i64 %t94, ptr %l50, !tbaa !24
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l52
  br label %bb22
bb22:
  %t98 = load i64, ptr %l50, !tbaa !24
  %t99 = load i64, ptr %l52, !tbaa !24
  %t100 = icmp slt i64 %t98, %t99
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s8)
  br label %bb29
bb24:
  br label %bb25
bb25:
  %t104 = load ptr, ptr %l7, !tbaa !29
  %t105 = load i64, ptr %l8, !tbaa !24
  %t108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t104, i64 %t105)
  store i64 %t108, ptr %l57
  br label %bb26
bb26:
  %t109 = load i64, ptr %l57, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2echeck(ptr %v0, ptr %t110, i64 %t109)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s8)
  br label %bb28
bb28:
  %t114 = load i64, ptr %l8, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l8, !tbaa !24
  br label %bb21
bb29:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/lsp:worker", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t123 = call %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %s0, i32 %t121)
  store %"compiler/session:Reader" %t123, ptr %l64
  br label %bb30
bb30:
  %t124 = load %"compiler/session:Reader", ptr %l64
  store %"compiler/session:Reader" %t124, ptr %l10
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s10
  %t126 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %s0, ptr %l10)
  store i1 %t126, ptr %l66
  br label %bb32
bb32:
  %t127 = load i1, ptr %l66, !tbaa !21
  %t128 = xor i1 %t127, true
  br i1 %t128, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s11
  %t131 = call { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNext(ptr %s0, ptr %s11, ptr %l10)
  %t132 = extractvalue { i32, { i64, ptr } } %t131, 1
  %t133 = extractvalue { i32, { i64, ptr } } %t131, 0
  store i32 %t133, ptr %l71
  %t134 = icmp ne i32 %t133, 0
  br i1 %t134, label %bb38, label %ok.135
ok.135:
  store { i64, ptr } %t132, ptr %l70
  br label %bb37
bb37:
  %t136 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t136, ptr %l68, !tbaa !27
  br label %bb42
bb38:
  %t137 = load i32, ptr %l71, !tbaa !23
  %t138 = ashr i32 %t137, 16
  %t140 = icmp eq i32 %t138, 1
  br i1 %t140, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_182f056b6a3fe51e_12be5b3b255222c2)
  unreachable
bb41:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s11)
  br label %bb45
bb42:
  %t142 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t143 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2eanswer(ptr %v0, ptr %s11, ptr %t143, { i64, ptr } %t142)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s11)
  br label %bb44
bb44:
  br label %bb36
bb45:
  call void @__olang_scope_close(ptr %s10)
  br label %bb46
bb46:
  br label %bb31
bb47:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2flsp_2ecompiler_2flsp_3aworker_2eanalysis(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l8 = alloca i1
  %l22 = alloca ptr
  %l30 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/lsp:worker", ptr %t2, i32 0, i32 6
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = icmp eq i64 %t1, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/lsp:worker", ptr %t10, i32 0, i32 5
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  %t17 = xor i1 %t15, true
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l8, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/lsp:worker", ptr %t20, i32 0, i32 5
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb6, label %bb7
bb5:
  br label %bb9
bb6:
  call void @__olang_check_failed(ptr @olang_loc_cb6dbf061e2dce2f_dc463ae13d2c2fbb)
  unreachable
bb7:
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/lsp:worker", ptr %t27, i32 0, i32 5
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %rv
  br label %ret
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/lsp:worker", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/lsp:Server", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t37, i64 %t38)
  store ptr %t41, ptr %l22
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t44 = getelementptr %"compiler/lsp:Doc", ptr %t42, i32 0, i32 1
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/lsp:worker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/lsp:worker", ptr %t51, i32 0, i32 4
  %t58 = call ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t45, ptr %t49, ptr %a2, ptr %t53, i1 true)
  store ptr %t58, ptr %l30
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l30, !tbaa !29
  store ptr %t59, ptr %l3, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t65 = getelementptr %"compiler/lsp:worker", ptr %t60, i32 0, i32 5
  store ptr %t61, ptr %t65, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  %t70 = getelementptr %"compiler/lsp:worker", ptr %t66, i32 0, i32 6
  store i64 %t67, ptr %t70, !tbaa !24
  %t71 = load ptr, ptr %l3, !tbaa !29
  store ptr %t71, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2eanswer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/session:Positions"
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca %"compiler/session:Found"
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"compiler/session:Positions"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca %"std/prelude/text:StringBuilder"
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i32
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca i32
  %l45 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca i32
  %l57 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca i32
  %l84 = alloca %"compiler/session:Positions"
  %l85 = alloca i64
  %l88 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca i32
  %l95 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l98 = alloca i32
  %l101 = alloca i64
  %l102 = alloca i32
  %l105 = alloca i64
  %l108 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l111 = alloca i32
  %l115 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l118 = alloca i32
  %l121 = alloca i64
  %l122 = alloca i32
  %l128 = alloca i64
  %l131 = alloca %"compiler/diag:Diagnostics"
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca i32
  %l141 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l147 = alloca i1
  %l148 = alloca ptr
  %l150 = alloca { i64, ptr }
  %l152 = alloca %"std/prelude/text:StringBuilder"
  %l162 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l169 = alloca i1
  %l180 = alloca ptr
  %l182 = alloca i1
  %l186 = alloca i64
  %l189 = alloca i1
  %l194 = alloca ptr
  %l199 = alloca ptr
  %l201 = alloca { i64, ptr }
  %l203 = alloca %"std/prelude/text:StringBuilder"
  %l204 = alloca ptr
  %l205 = alloca ptr
  %l210 = alloca ptr
  %l216 = alloca ptr
  %l217 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l222 = alloca %"compiler/session:Found"
  %l227 = alloca %"compiler/session:Found"
  %l228 = alloca i32
  %l231 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l236 = alloca i1
  %l237 = alloca %"std/prelude/text:StringBuilder"
  %l242 = alloca ptr
  %l243 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l249 = alloca i1
  %l250 = alloca i1
  %l253 = alloca ptr
  %l255 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %l265 = alloca %"compiler/session:Positions"
  %l268 = alloca %"compiler/source:Span"
  %l269 = alloca %"std/prelude/text:StringBuilder"
  %l271 = alloca ptr
  %l274 = alloca { i64, ptr }
  %l284 = alloca ptr
  %l285 = alloca { i64, ptr }
  %l287 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %t231 = alloca %"compiler/diag:Diagnostics", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, ptr } @std_2fjson_2eParse(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %a1, ptr null)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l30
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store ptr %t4, ptr %l29
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l29, !tbaa !29
  store ptr %t8, ptr %l27, !tbaa !29
  br label %bb6
bb2:
  %t9 = load i32, ptr %l30, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_87f37ba47774b846_89d4dc908ddb257a)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t14 = load ptr, ptr %l27, !tbaa !29
  store ptr %t14, ptr %l2, !tbaa !29
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = call { i64, ptr } @compiler_2flsp_2eidOf(ptr %s0, ptr %s0, ptr %t15)
  store { i64, ptr } %t17, ptr %l34
  br label %bb7
bb7:
  %t18 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s0, ptr %s0, ptr %t19, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store { i64, ptr } %t21, ptr %l36
  br label %bb8
bb8:
  %t22 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  %t23 = load ptr, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t27 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t23, { i64, ptr } %t24)
  %t28 = extractvalue { i32, ptr } %t27, 1
  %t29 = extractvalue { i32, ptr } %t27, 0
  store i32 %t29, ptr %l42
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb10, label %ok.31
ok.31:
  store ptr %t28, ptr %l41
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l41, !tbaa !29
  store ptr %t32, ptr %l37, !tbaa !29
  br label %bb16
bb10:
  %t33 = load i32, ptr %l42, !tbaa !23
  %t34 = ashr i32 %t33, 16
  %t36 = icmp eq i32 %t34, 1
  br i1 %t36, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_4ebfa45d02ec2e27_3873456da27149fb)
  unreachable
bb13:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l45, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t41 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s2, ptr %s2, { i64, ptr } %t39, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store { i64, ptr } %t41, ptr %l47
  br label %bb14
bb14:
  %t42 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  %t44 = extractvalue { i64, ptr } %t42, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t49 = load ptr, ptr %l45, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s2, ptr %t49, { i64, ptr } %t48)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t51 = load ptr, ptr %l37, !tbaa !29
  store ptr %t51, ptr %l5, !tbaa !29
  %t52 = load ptr, ptr %l5, !tbaa !29
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l51, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t56 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t52, { i64, ptr } %t53)
  %t57 = extractvalue { i32, ptr } %t56, 1
  %t58 = extractvalue { i32, ptr } %t56, 0
  store i32 %t58, ptr %l54
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb18, label %ok.60
ok.60:
  store ptr %t57, ptr %l53
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l53, !tbaa !29
  store ptr %t61, ptr %l49, !tbaa !29
  br label %bb22
bb18:
  %t62 = load i32, ptr %l54, !tbaa !23
  %t63 = ashr i32 %t62, 16
  %t65 = icmp eq i32 %t63, 1
  br i1 %t65, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_38a34762ac5520ac_3968f3c3cddc2680)
  unreachable
bb21:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t67 = load ptr, ptr %l49, !tbaa !29
  %t68 = call { i64, ptr } @compiler_2flsp_2estr(ptr %s0, ptr %s0, ptr %t67, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store { i64, ptr } %t68, ptr %l57
  br label %bb23
bb23:
  %t69 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/lsp:worker", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t77 = call i64 @compiler_2flsp_2ecompiler_2flsp_3aServer_2eslotOf(ptr %v0, ptr %s0, ptr %t73, { i64, ptr } %t69)
  store i64 %t77, ptr %l61
  br label %bb24
bb24:
  %t78 = load i64, ptr %l61, !tbaa !24
  store i64 %t78, ptr %l7, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp slt i64 %t79, 0
  br i1 %t81, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l64, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t86 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s4, ptr %s4, { i64, ptr } %t84, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d78, i32 0, i32 1) })
  store { i64, ptr } %t86, ptr %l66
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t87 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t94 = load ptr, ptr %l64, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s4, ptr %t94, { i64, ptr } %t93)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/lsp:worker", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/lsp:Server", ptr %t99, i32 0, i32 1
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t101, i64 %t102)
  store ptr %t105, ptr %l72
  br label %bb30
bb30:
  %t106 = load ptr, ptr %l72, !tbaa !29
  store ptr %t106, ptr %l8, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/lsp:worker", ptr %t107, i32 0, i32 4
  %t110 = load ptr, ptr %l8, !tbaa !29
  %t112 = getelementptr %"compiler/lsp:Doc", ptr %t110, i32 0, i32 2
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t116 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v0, ptr %v0, ptr %t109, { i64, ptr } %t113)
  %t117 = extractvalue { i32, { i64, ptr } } %t116, 1
  %t118 = extractvalue { i32, { i64, ptr } } %t116, 0
  store i32 %t118, ptr %l79
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb32, label %ok.120
ok.120:
  store { i64, ptr } %t117, ptr %l78
  br label %bb31
bb31:
  %t121 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t121, ptr %l73, !tbaa !27
  br label %bb34
bb32:
  br label %bb33
bb33:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l73, !tbaa !27
  br label %bb34
bb34:
  %t122 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t122, ptr %l9, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/lsp:worker", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/lsp:Server", ptr %t127, i32 0, i32 2
  %t130 = load i1, ptr %t129, !tbaa !21
  %t133 = call %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %v0, ptr %s0, { i64, ptr } %t123, i1 %t130)
  store %"compiler/session:Positions" %t133, ptr %l84
  br label %bb35
bb35:
  %t134 = load %"compiler/session:Positions", ptr %l84
  store %"compiler/session:Positions" %t134, ptr %l10
  %t135 = load ptr, ptr %l5, !tbaa !29
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %l88, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t140 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t135, { i64, ptr } %t137)
  %t141 = extractvalue { i32, ptr } %t140, 1
  %t142 = extractvalue { i32, ptr } %t140, 0
  store i32 %t142, ptr %l91
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb37, label %ok.144
ok.144:
  store ptr %t141, ptr %l90
  br label %bb36
bb36:
  %t145 = load ptr, ptr %l90, !tbaa !29
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l95, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t149 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t145, { i64, ptr } %t146)
  %t150 = extractvalue { i32, ptr } %t149, 1
  %t151 = extractvalue { i32, ptr } %t149, 0
  store i32 %t151, ptr %l98
  %t152 = icmp ne i32 %t151, 0
  br i1 %t152, label %bb42, label %ok.153
ok.153:
  store ptr %t150, ptr %l97
  br label %bb41
bb37:
  %t154 = load i32, ptr %l91, !tbaa !23
  %t155 = ashr i32 %t154, 16
  %t157 = icmp eq i32 %t155, 1
  br i1 %t157, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_456b769a5430a35d_bb604ee566770711)
  unreachable
bb40:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l85, !tbaa !24
  br label %bb49
bb41:
  %t159 = load ptr, ptr %l97, !tbaa !29
  %t160 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %s0, ptr %t159)
  %t161 = extractvalue { i32, i64 } %t160, 1
  %t162 = extractvalue { i32, i64 } %t160, 0
  store i32 %t162, ptr %l102
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb46, label %ok.164
ok.164:
  store i64 %t161, ptr %l101
  br label %bb45
bb42:
  %t165 = load i32, ptr %l98, !tbaa !23
  %t166 = ashr i32 %t165, 16
  %t168 = icmp eq i32 %t166, 1
  br i1 %t168, label %bb43, label %bb44
bb43:
  br label %bb40
bb44:
  call void @__olang_check_failed(ptr @olang_loc_456b769a5430a35d_bb604ee566770711)
  unreachable
bb45:
  %t170 = load i64, ptr %l101, !tbaa !24
  store i64 %t170, ptr %l85, !tbaa !24
  br label %bb49
bb46:
  %t171 = load i32, ptr %l102, !tbaa !23
  %t172 = ashr i32 %t171, 16
  %t174 = icmp eq i32 %t172, 1
  br i1 %t174, label %bb47, label %bb48
bb47:
  br label %bb40
bb48:
  call void @__olang_check_failed(ptr @olang_loc_456b769a5430a35d_bb604ee566770711)
  unreachable
bb49:
  %t176 = load i64, ptr %l85, !tbaa !24
  store i64 %t176, ptr %l11, !tbaa !24
  %t177 = load ptr, ptr %l5, !tbaa !29
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l108, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t182 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t177, { i64, ptr } %t179)
  %t183 = extractvalue { i32, ptr } %t182, 1
  %t184 = extractvalue { i32, ptr } %t182, 0
  store i32 %t184, ptr %l111
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb51, label %ok.186
ok.186:
  store ptr %t183, ptr %l110
  br label %bb50
bb50:
  %t187 = load ptr, ptr %l110, !tbaa !29
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l115, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t191 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %s0, ptr %t187, { i64, ptr } %t188)
  %t192 = extractvalue { i32, ptr } %t191, 1
  %t193 = extractvalue { i32, ptr } %t191, 0
  store i32 %t193, ptr %l118
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb56, label %ok.195
ok.195:
  store ptr %t192, ptr %l117
  br label %bb55
bb51:
  %t196 = load i32, ptr %l111, !tbaa !23
  %t197 = ashr i32 %t196, 16
  %t199 = icmp eq i32 %t197, 1
  br i1 %t199, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_7f592474689ac30a_b2c7e24f5de8ebf6)
  unreachable
bb54:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l105, !tbaa !24
  br label %bb63
bb55:
  %t201 = load ptr, ptr %l117, !tbaa !29
  %t202 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %s0, ptr %t201)
  %t203 = extractvalue { i32, i64 } %t202, 1
  %t204 = extractvalue { i32, i64 } %t202, 0
  store i32 %t204, ptr %l122
  %t205 = icmp ne i32 %t204, 0
  br i1 %t205, label %bb60, label %ok.206
ok.206:
  store i64 %t203, ptr %l121
  br label %bb59
bb56:
  %t207 = load i32, ptr %l118, !tbaa !23
  %t208 = ashr i32 %t207, 16
  %t210 = icmp eq i32 %t208, 1
  br i1 %t210, label %bb57, label %bb58
bb57:
  br label %bb54
bb58:
  call void @__olang_check_failed(ptr @olang_loc_7f592474689ac30a_b2c7e24f5de8ebf6)
  unreachable
bb59:
  %t212 = load i64, ptr %l121, !tbaa !24
  store i64 %t212, ptr %l105, !tbaa !24
  br label %bb63
bb60:
  %t213 = load i32, ptr %l122, !tbaa !23
  %t214 = ashr i32 %t213, 16
  %t216 = icmp eq i32 %t214, 1
  br i1 %t216, label %bb61, label %bb62
bb61:
  br label %bb54
bb62:
  call void @__olang_check_failed(ptr @olang_loc_7f592474689ac30a_b2c7e24f5de8ebf6)
  unreachable
bb63:
  %t218 = load i64, ptr %l105, !tbaa !24
  %t219 = load i64, ptr %l11, !tbaa !24
  %t224 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eOffset(ptr %s0, ptr %l10, i64 %t219, i64 %t218)
  store i64 %t224, ptr %l128
  br label %bb64
bb64:
  %t225 = load i64, ptr %l128, !tbaa !24
  store i64 %t225, ptr %l13, !tbaa !24
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/lsp:worker", ptr %t226, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !29
  store ptr %t229, ptr %l14, !tbaa !29
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t231, ptr %v0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l131, ptr %t231, i64 200, i1 false)
  br label %bb65
bb65:
  %t232 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 200, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t232, ptr %l131, i64 200, i1 false)
  store ptr %t232, ptr %l15, !tbaa !29
  %t234 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t236 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t234, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t236, ptr %l134
  br label %bb66
bb66:
  %t237 = load i1, ptr %l134, !tbaa !21
  br i1 %t237, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s5
  %t238 = load ptr, ptr %l8, !tbaa !29
  %t240 = getelementptr %"compiler/lsp:Doc", ptr %t238, i32 0, i32 1
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t245 = call { i32, { i64, ptr } } @compiler_2fsession_2eFormat(ptr %v0, ptr %v0, ptr %s5, { i64, ptr } %t241, { i64, ptr } %t242)
  %t246 = extractvalue { i32, { i64, ptr } } %t245, 1
  %t247 = extractvalue { i32, { i64, ptr } } %t245, 0
  store i32 %t247, ptr %l140
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb70, label %ok.249
ok.249:
  store { i64, ptr } %t246, ptr %l139
  br label %bb69
bb68:
  br label %bb90
bb69:
  %t250 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t250, ptr %l135, !tbaa !27
  br label %bb74
bb70:
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s6
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l141, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t254 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s6, ptr %s6, { i64, ptr } %t252, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d85, i32 0, i32 1) })
  store { i64, ptr } %t254, ptr %l143
  br label %bb72
bb72:
  %t255 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 0
  %t257 = extractvalue { i64, ptr } %t255, 1
  %t258 = mul i64 %t256, 1
  %t259 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t257, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  %t262 = load ptr, ptr %l141, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s6, ptr %t262, { i64, ptr } %t261)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb74:
  %t264 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t264, ptr %l16, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t269 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %v0, { i64, ptr } %t265, { i64, ptr } %t266)
  store i1 %t269, ptr %l147
  br label %bb75
bb75:
  %t270 = load i1, ptr %l147, !tbaa !21
  br i1 %t270, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s7
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l148, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t274 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s7, ptr %s7, { i64, ptr } %t272, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) })
  store { i64, ptr } %t274, ptr %l150
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t275 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 0
  %t277 = extractvalue { i64, ptr } %t275, 1
  %t278 = mul i64 %t276, 1
  %t279 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t278)
  call void @llvm.memcpy.p0.p0.i64(ptr %t279, ptr %t277, i64 %t278, i1 false)
  %t280 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t279, 1
  %t282 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s7, ptr %t282, { i64, ptr } %t281)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb80:
  %t284 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s5)
  store %"std/prelude/text:StringBuilder" %t284, ptr %l152
  br label %bb81
bb81:
  %t285 = load %"std/prelude/text:StringBuilder", ptr %l152
  store %"std/prelude/text:StringBuilder" %t285, ptr %l17
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s5, ptr %s5, ptr %l17, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d87, i32 0, i32 1) })
  br label %bb82
bb82:
  %t287 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t289 = extractvalue { i64, ptr } %t287, 0
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %s0, ptr %s5, ptr %l10, ptr %l17, i64 0, i64 %t289)
  br label %bb83
bb83:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s5, ptr %s5, ptr %l17, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d88, i32 0, i32 1) })
  br label %bb84
bb84:
  %t294 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s5, ptr %s5, ptr %l17, { i64, ptr } %t294)
  br label %bb85
bb85:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s5, ptr %s5, ptr %l17, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb86
bb86:
  %t298 = load ptr, ptr %l0, !tbaa !29
  store ptr %t298, ptr %l162, !tbaa !29
  %t299 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t299, ptr %l163, !tbaa !27
  %t301 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s5, ptr %s5, ptr %l17)
  store { i64, ptr } %t301, ptr %l165
  br label %bb87
bb87:
  %t302 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t303 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t304 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s5, ptr %s5, { i64, ptr } %t302, { i64, ptr } %t303)
  store { i64, ptr } %t304, ptr %l166
  br label %bb88
bb88:
  %t305 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t305, 0
  %t307 = extractvalue { i64, ptr } %t305, 1
  %t308 = mul i64 %t306, 1
  %t309 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t308)
  call void @llvm.memcpy.p0.p0.i64(ptr %t309, ptr %t307, i64 %t308, i1 false)
  %t310 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t309, 1
  %t312 = load ptr, ptr %l162, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s5, ptr %t312, { i64, ptr } %t311)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb90:
  %t314 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t316 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t314, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d90, i32 0, i32 1) })
  store i1 %t316, ptr %l169
  br label %bb91
bb91:
  %t317 = load i1, ptr %l169, !tbaa !21
  br i1 %t317, label %bb92, label %bb93
bb92:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t320 = load ptr, ptr %l8, !tbaa !29
  %t321 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t322 = load i64, ptr %l13, !tbaa !24
  %t323 = load ptr, ptr %l14, !tbaa !29
  %t324 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2ecomplete(ptr %v0, ptr %s0, ptr %v0, ptr %v0, ptr %v0, ptr %t318, { i64, ptr } %t319, ptr %t320, { i64, ptr } %t321, i64 %t322, ptr %t323, ptr %t324)
  br label %bb94
bb93:
  br label %bb95
bb94:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb95:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i64, ptr %l7, !tbaa !24
  %t334 = load ptr, ptr %l15, !tbaa !29
  %t338 = call ptr @compiler_2flsp_2ecompiler_2flsp_3aworker_2eanalysis(ptr %v0, ptr %v0, ptr %t332, i64 %t333, ptr %t334)
  store ptr %t338, ptr %l180
  br label %bb96
bb96:
  %t339 = load ptr, ptr %l180, !tbaa !29
  store ptr %t339, ptr %l18, !tbaa !29
  %t340 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t342 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t340, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d91, i32 0, i32 1) })
  store i1 %t342, ptr %l182
  br label %bb97
bb97:
  %t343 = load i1, ptr %l182, !tbaa !21
  br i1 %t343, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s9
  %t344 = load ptr, ptr %l18, !tbaa !29
  %t345 = load ptr, ptr %l8, !tbaa !29
  %t347 = getelementptr %"compiler/lsp:Doc", ptr %t345, i32 0, i32 2
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !27
  %t351 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v0, ptr %t344, { i64, ptr } %t348)
  store i64 %t351, ptr %l186
  br label %bb100
bb99:
  br label %bb116
bb100:
  %t352 = load i64, ptr %l186, !tbaa !24
  store i64 %t352, ptr %l19, !tbaa !24
  %t353 = load i64, ptr %l19, !tbaa !24
  %t355 = icmp slt i64 %t353, 0
  br i1 %t355, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l189, !tbaa !21
  br label %bb104
bb102:
  %t357 = load ptr, ptr %l18, !tbaa !29
  %t359 = getelementptr %"compiler/session:Analysis", ptr %t357, i32 0, i32 0
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t362 = getelementptr %"compiler/load:Loader", ptr %t360, i32 0, i32 5
  %t363 = load i64, ptr %l19, !tbaa !24
  %t366 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t362, i64 %t363)
  store ptr %t366, ptr %l194
  br label %bb103
bb103:
  %t367 = load ptr, ptr %l194, !tbaa !29
  %t369 = getelementptr %"compiler/load:Module", ptr %t367, i32 0, i32 8
  %t370 = load { i64, ptr }, ptr %t369, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t370, 0
  %t374 = icmp eq i64 %t372, 0
  store i1 %t374, ptr %l189, !tbaa !21
  br label %bb104
bb104:
  %t376 = load i1, ptr %l189, !tbaa !21
  br i1 %t376, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s10
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l199, !tbaa !29
  %t378 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t380 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s10, ptr %s10, { i64, ptr } %t378, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store { i64, ptr } %t380, ptr %l201
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t381 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 0
  %t383 = extractvalue { i64, ptr } %t381, 1
  %t384 = mul i64 %t382, 1
  %t385 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t384)
  call void @llvm.memcpy.p0.p0.i64(ptr %t385, ptr %t383, i64 %t384, i1 false)
  %t386 = insertvalue { i64, ptr } undef, i64 %t382, 0
  %t387 = insertvalue { i64, ptr } %t386, ptr %t385, 1
  %t388 = load ptr, ptr %l199, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s10, ptr %t388, { i64, ptr } %t387)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb109:
  %t390 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s9)
  store %"std/prelude/text:StringBuilder" %t390, ptr %l203
  br label %bb110
bb110:
  %t391 = load %"std/prelude/text:StringBuilder", ptr %l203
  store %"std/prelude/text:StringBuilder" %t391, ptr %l20
  store ptr %l20, ptr %l204, !tbaa !29
  store ptr %l10, ptr %l205, !tbaa !29
  %t392 = load ptr, ptr %l18, !tbaa !29
  %t394 = getelementptr %"compiler/session:Analysis", ptr %t392, i32 0, i32 0
  %t395 = load ptr, ptr %t394, !tbaa !29
  %t397 = getelementptr %"compiler/load:Loader", ptr %t395, i32 0, i32 5
  %t398 = load i64, ptr %l19, !tbaa !24
  %t401 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t397, i64 %t398)
  store ptr %t401, ptr %l210
  br label %bb111
bb111:
  %t402 = load ptr, ptr %l210, !tbaa !29
  %t404 = getelementptr %"compiler/load:Module", ptr %t402, i32 0, i32 8
  %t405 = load { i64, ptr }, ptr %t404, !tbaa !27
  %t406 = load ptr, ptr %l18, !tbaa !29
  %t408 = getelementptr %"compiler/session:Analysis", ptr %t406, i32 0, i32 0
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = getelementptr %"compiler/load:Loader", ptr %t409, i32 0, i32 3
  %t412 = load ptr, ptr %t411, !tbaa !29
  %t413 = load ptr, ptr %l204, !tbaa !29
  %t414 = load ptr, ptr %l205, !tbaa !29
  call void @compiler_2fsession_2eSymbols(ptr %s9, ptr %s0, ptr %v0, ptr %v0, ptr %t413, ptr %t414, { i64, ptr } %t405, ptr %t412)
  br label %bb112
bb112:
  %t417 = load ptr, ptr %l0, !tbaa !29
  store ptr %t417, ptr %l216, !tbaa !29
  %t418 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t418, ptr %l217, !tbaa !27
  %t420 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s9, ptr %s9, ptr %l20)
  store { i64, ptr } %t420, ptr %l219
  br label %bb113
bb113:
  %t421 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t422 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t423 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s9, ptr %s9, { i64, ptr } %t421, { i64, ptr } %t422)
  store { i64, ptr } %t423, ptr %l220
  br label %bb114
bb114:
  %t424 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 0
  %t426 = extractvalue { i64, ptr } %t424, 1
  %t427 = mul i64 %t425, 1
  %t428 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t427)
  call void @llvm.memcpy.p0.p0.i64(ptr %t428, ptr %t426, i64 %t427, i1 false)
  %t429 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t428, 1
  %t431 = load ptr, ptr %l216, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s9, ptr %t431, { i64, ptr } %t430)
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb116:
  %t433 = load ptr, ptr %l18, !tbaa !29
  %t434 = load ptr, ptr %l8, !tbaa !29
  %t436 = getelementptr %"compiler/lsp:Doc", ptr %t434, i32 0, i32 2
  %t437 = load { i64, ptr }, ptr %t436, !tbaa !27
  %t438 = load i64, ptr %l13, !tbaa !24
  %t442 = call { i32, %"compiler/session:Found" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eLookup(ptr %v0, ptr %v0, ptr %s0, ptr %t433, { i64, ptr } %t437, i64 %t438)
  %t443 = extractvalue { i32, %"compiler/session:Found" } %t442, 1
  %t444 = extractvalue { i32, %"compiler/session:Found" } %t442, 0
  store i32 %t444, ptr %l228
  %t445 = icmp ne i32 %t444, 0
  br i1 %t445, label %bb118, label %ok.446
ok.446:
  store %"compiler/session:Found" %t443, ptr %l227
  br label %bb117
bb117:
  %t447 = load %"compiler/session:Found", ptr %l227
  store %"compiler/session:Found" %t447, ptr %l222
  br label %bb124
bb118:
  %t448 = load i32, ptr %l228, !tbaa !23
  %t449 = ashr i32 %t448, 16
  %t451 = icmp eq i32 %t449, 1
  br i1 %t451, label %bb119, label %bb120
bb119:
  br label %bb121
bb120:
  call void @__olang_check_failed(ptr @olang_loc_bd1a900ffc81074b_9b3f40c88c4de497)
  unreachable
bb121:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s11
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l231, !tbaa !29
  %t454 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t456 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s11, ptr %s11, { i64, ptr } %t454, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store { i64, ptr } %t456, ptr %l233
  br label %bb122
bb122:
  %t457 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t457, 0
  %t459 = extractvalue { i64, ptr } %t457, 1
  %t460 = mul i64 %t458, 1
  %t461 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t460)
  call void @llvm.memcpy.p0.p0.i64(ptr %t461, ptr %t459, i64 %t460, i1 false)
  %t462 = insertvalue { i64, ptr } undef, i64 %t458, 0
  %t463 = insertvalue { i64, ptr } %t462, ptr %t461, 1
  %t464 = load ptr, ptr %l231, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s11, ptr %t464, { i64, ptr } %t463)
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb124:
  %t466 = load %"compiler/session:Found", ptr %l222
  store %"compiler/session:Found" %t466, ptr %l21
  %t467 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t469 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t467, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d94, i32 0, i32 1) })
  store i1 %t469, ptr %l236
  br label %bb125
bb125:
  %t470 = load i1, ptr %l236, !tbaa !21
  br i1 %t470, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s12
  %t471 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s12)
  store %"std/prelude/text:StringBuilder" %t471, ptr %l237
  br label %bb128
bb127:
  br label %bb135
bb128:
  %t472 = load %"std/prelude/text:StringBuilder", ptr %l237
  store %"std/prelude/text:StringBuilder" %t472, ptr %l22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s12, ptr %s12, ptr %l22, { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d95, i32 0, i32 1) })
  br label %bb129
bb129:
  %t474 = getelementptr %"compiler/session:Found", ptr %l21, i32 0, i32 0
  %t475 = load { i64, ptr }, ptr %t474, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s12, ptr %s0, ptr %l22, { i64, ptr } %t475)
  br label %bb130
bb130:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s12, ptr %s12, ptr %l22, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d96, i32 0, i32 1) })
  br label %bb131
bb131:
  %t479 = load ptr, ptr %l0, !tbaa !29
  store ptr %t479, ptr %l242, !tbaa !29
  %t480 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t480, ptr %l243, !tbaa !27
  %t482 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s12, ptr %s12, ptr %l22)
  store { i64, ptr } %t482, ptr %l245
  br label %bb132
bb132:
  %t483 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t484 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t485 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s12, ptr %s12, { i64, ptr } %t483, { i64, ptr } %t484)
  store { i64, ptr } %t485, ptr %l246
  br label %bb133
bb133:
  %t486 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t487 = extractvalue { i64, ptr } %t486, 0
  %t488 = extractvalue { i64, ptr } %t486, 1
  %t489 = mul i64 %t487, 1
  %t490 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t489)
  call void @llvm.memcpy.p0.p0.i64(ptr %t490, ptr %t488, i64 %t489, i1 false)
  %t491 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t492 = insertvalue { i64, ptr } %t491, ptr %t490, 1
  %t493 = load ptr, ptr %l242, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s12, ptr %t493, { i64, ptr } %t492)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb135:
  %t495 = getelementptr %"compiler/session:Found", ptr %l21, i32 0, i32 1
  %t496 = load { i64, ptr }, ptr %t495, !tbaa !27
  %t498 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t496, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d97, i32 0, i32 1) })
  store i1 %t498, ptr %l249
  br label %bb136
bb136:
  %t499 = load i1, ptr %l249, !tbaa !21
  br i1 %t499, label %bb137, label %bb138
bb137:
  store i1 true, ptr %l250, !tbaa !21
  br label %bb139
bb138:
  %t500 = getelementptr %"compiler/session:Found", ptr %l21, i32 0, i32 2
  %t501 = load i64, ptr %t500, !tbaa !24
  %t503 = icmp slt i64 %t501, 0
  store i1 %t503, ptr %l250, !tbaa !21
  br label %bb139
bb139:
  %t505 = load i1, ptr %l250, !tbaa !21
  br i1 %t505, label %bb140, label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s13
  %t506 = load ptr, ptr %l0, !tbaa !29
  store ptr %t506, ptr %l253, !tbaa !29
  %t507 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t509 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s13, ptr %s13, { i64, ptr } %t507, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store { i64, ptr } %t509, ptr %l255
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t510 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t511 = extractvalue { i64, ptr } %t510, 0
  %t512 = extractvalue { i64, ptr } %t510, 1
  %t513 = mul i64 %t511, 1
  %t514 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t513)
  call void @llvm.memcpy.p0.p0.i64(ptr %t514, ptr %t512, i64 %t513, i1 false)
  %t515 = insertvalue { i64, ptr } undef, i64 %t511, 0
  %t516 = insertvalue { i64, ptr } %t515, ptr %t514, 1
  %t517 = load ptr, ptr %l253, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s13, ptr %t517, { i64, ptr } %t516)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb144:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load ptr, ptr %l18, !tbaa !29
  %t521 = getelementptr %"compiler/session:Found", ptr %l21, i32 0, i32 1
  %t522 = load { i64, ptr }, ptr %t521, !tbaa !27
  %t526 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2etextOf(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t519, ptr %t520, { i64, ptr } %t522)
  store { i64, ptr } %t526, ptr %l260
  br label %bb145
bb145:
  %t527 = load { i64, ptr }, ptr %l260, !tbaa !27
  store { i64, ptr } %t527, ptr %l23, !tbaa !27
  %t528 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t531 = getelementptr %"compiler/lsp:worker", ptr %t529, i32 0, i32 0
  %t532 = load ptr, ptr %t531, !tbaa !29
  %t534 = getelementptr %"compiler/lsp:Server", ptr %t532, i32 0, i32 2
  %t535 = load i1, ptr %t534, !tbaa !21
  %t538 = call %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %s0, ptr %s0, { i64, ptr } %t528, i1 %t535)
  store %"compiler/session:Positions" %t538, ptr %l265
  br label %bb146
bb146:
  %t539 = load %"compiler/session:Positions", ptr %l265
  store %"compiler/session:Positions" %t539, ptr %l24
  %t540 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t541 = getelementptr %"compiler/session:Found", ptr %l21, i32 0, i32 2
  %t542 = load i64, ptr %t541, !tbaa !24
  %t545 = call %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %s0, { i64, ptr } %t540, i64 %t542)
  store %"compiler/source:Span" %t545, ptr %l268
  br label %bb147
bb147:
  %t546 = load %"compiler/source:Span", ptr %l268
  store %"compiler/source:Span" %t546, ptr %l25
  %t547 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t547, ptr %l269
  br label %bb148
bb148:
  %t548 = load %"std/prelude/text:StringBuilder", ptr %l269
  store %"std/prelude/text:StringBuilder" %t548, ptr %l26
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l26, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb149
bb149:
  store ptr %l26, ptr %l271, !tbaa !29
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/session:Found", ptr %l21, i32 0, i32 1
  %t552 = load { i64, ptr }, ptr %t551, !tbaa !27
  %t555 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2euriOf(ptr %v0, ptr %s0, ptr %s0, ptr %t550, { i64, ptr } %t552)
  store { i64, ptr } %t555, ptr %l274
  br label %bb150
bb150:
  %t556 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t557 = extractvalue { i64, ptr } %t556, 0
  %t558 = extractvalue { i64, ptr } %t556, 1
  %t559 = mul i64 %t557, 1
  %t560 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t559)
  call void @llvm.memcpy.p0.p0.i64(ptr %t560, ptr %t558, i64 %t559, i1 false)
  %t561 = insertvalue { i64, ptr } undef, i64 %t557, 0
  %t562 = insertvalue { i64, ptr } %t561, ptr %t560, 1
  %t563 = load ptr, ptr %l271, !tbaa !29
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %s0, ptr %t563, { i64, ptr } %t562)
  br label %bb151
bb151:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l26, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d100, i32 0, i32 1) })
  br label %bb152
bb152:
  %t566 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 0
  %t567 = load i32, ptr %t566, !tbaa !23
  %t569 = sext i32 %t567 to i64
  %t570 = getelementptr %"compiler/source:Span", ptr %l25, i32 0, i32 1
  %t571 = load i32, ptr %t570, !tbaa !23
  %t573 = sext i32 %t571 to i64
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %s0, ptr %s0, ptr %l24, ptr %l26, i64 %t569, i64 %t573)
  br label %bb153
bb153:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l26, i8 125)
  br label %bb154
bb154:
  %t579 = load ptr, ptr %l0, !tbaa !29
  store ptr %t579, ptr %l284, !tbaa !29
  %t580 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t580, ptr %l285, !tbaa !27
  %t582 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l26)
  store { i64, ptr } %t582, ptr %l287
  br label %bb155
bb155:
  %t583 = load { i64, ptr }, ptr %l285, !tbaa !27
  %t584 = load { i64, ptr }, ptr %l287, !tbaa !27
  %t585 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t583, { i64, ptr } %t584)
  store { i64, ptr } %t585, ptr %l288
  br label %bb156
bb156:
  %t586 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t587 = extractvalue { i64, ptr } %t586, 0
  %t588 = extractvalue { i64, ptr } %t586, 1
  %t589 = mul i64 %t587, 1
  %t590 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t589)
  call void @llvm.memcpy.p0.p0.i64(ptr %t590, ptr %t588, i64 %t589, i1 false)
  %t591 = insertvalue { i64, ptr } undef, i64 %t587, 0
  %t592 = insertvalue { i64, ptr } %t591, ptr %t590, 1
  %t593 = load ptr, ptr %l284, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s0, ptr %t593, { i64, ptr } %t592)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2echeck(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca %"compiler/diag:Diagnostics"
  %l43 = alloca ptr
  %l45 = alloca i64
  %l52 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca i64
  %l65 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca %"std/prelude/text:StringBuilder"
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i32
  %l92 = alloca { i64, ptr }
  %l98 = alloca i64
  %l102 = alloca i64
  %l105 = alloca i64
  %l126 = alloca i1
  %l131 = alloca ptr
  %l134 = alloca i1
  %l139 = alloca ptr
  %l144 = alloca i1
  %l161 = alloca i64
  %l165 = alloca i64
  %l168 = alloca i64
  %l189 = alloca ptr
  %l192 = alloca { i64, ptr }
  %l196 = alloca ptr
  %l198 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t17 = alloca %"compiler/diag:Diagnostics", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:worker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lsp:Server", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %l1, !tbaa !24
  %t10 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t6, i64 %t7)
  store ptr %t10, ptr %l32
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l32, !tbaa !29
  store ptr %t11, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/lsp:worker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  store ptr %t15, ptr %l3, !tbaa !29
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t17, ptr %v0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l35, ptr %t17, i64 200, i1 false)
  br label %bb2
bb2:
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 200, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t18, ptr %l35, i64 200, i1 false)
  store ptr %t18, ptr %l4, !tbaa !29
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/lsp:Doc", ptr %t20, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/lsp:worker", ptr %t26, i32 0, i32 4
  %t33 = call ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t23, ptr %t24, ptr %t25, ptr %t28, i1 false)
  store ptr %t33, ptr %l43
  br label %bb3
bb3:
  %t34 = load ptr, ptr %l43, !tbaa !29
  store ptr %t34, ptr %l5, !tbaa !29
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l45
  br label %bb4
bb4:
  %t38 = load i64, ptr %l45, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/lsp:Doc", ptr %t43, i32 0, i32 6
  %t51 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flsp_2ecompiler_2flsp_3aworker_2epublishAll(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %s0, ptr %t39, i64 %t40, ptr %t41, ptr %t42, ptr %t45)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %l52
  br label %bb5
bb5:
  %t52 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l7
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t54 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2eHold(ptr %v0, ptr %v0, ptr %t53, ptr %t54)
  br label %bb6
bb6:
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l56
  br label %bb7
bb7:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l56, !tbaa !24
  %t63 = icmp ne i64 %t61, %t60
  br i1 %t63, label %bb8, label %bb9
bb8:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t69 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t71 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, ptr %t71
  %t77 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flsp_2ecompiler_2flsp_3aworker_2epublishAll(ptr %v0, ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t65, i64 %t66, ptr %t67, ptr %t68, ptr %t71)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l65
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t78 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %l7
  br label %bb11
bb11:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/lsp:worker", ptr %t79, i32 0, i32 5
  store ptr %t80, ptr %t84, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l1, !tbaa !24
  %t89 = getelementptr %"compiler/lsp:worker", ptr %t85, i32 0, i32 6
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t90, ptr %l71
  br label %bb12
bb12:
  %t91 = load %"std/prelude/text:StringBuilder", ptr %l71
  store %"std/prelude/text:StringBuilder" %t91, ptr %l8
  %t92 = load i64, ptr %l1, !tbaa !24
  %t93 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t96 = call i64 @__olang_fmt_i64(ptr null, i64 %t92)
  %t97 = add i64 %t94, %t96
  %t98 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t101 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t93, i64 %t94)
  %t102 = getelementptr i8, ptr %t101, i64 %t94
  %t103 = call i64 @__olang_fmt_i64(ptr %t102, i64 %t92)
  %t104 = getelementptr i8, ptr %t102, i64 %t96
  call void @olang_textcopy(ptr %t104, ptr %t98, i64 %t99)
  %t105 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t101, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = extractvalue { i64, ptr } %t106, 1
  %t110 = mul i64 %t108, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t110)
  call void @llvm.memcpy.p0.p0.i64(ptr %t111, ptr %t109, i64 %t110, i1 false)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l8, { i64, ptr } %t113)
  br label %bb13
bb13:
  store i1 true, ptr %l9, !tbaa !21
  %t116 = load ptr, ptr %l5, !tbaa !29
  %t118 = getelementptr %"compiler/session:Analysis", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/load:Loader", ptr %t119, i32 0, i32 5
  store ptr %t121, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t123 = load ptr, ptr %l10, !tbaa !29
  %t124 = load i64, ptr %l11, !tbaa !24
  %t127 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H8fdab0f9e4aba8682af3c4e1d27c3999(ptr %v0, ptr %t123, i64 %t124)
  %t128 = extractvalue { i32, { i64, ptr } } %t127, 1
  %t129 = extractvalue { i32, { i64, ptr } } %t127, 0
  store i32 %t129, ptr %l83
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb16, label %ok.131
ok.131:
  store { i64, ptr } %t128, ptr %l82
  br label %bb15
bb15:
  %t132 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t132, ptr %l79, !tbaa !27
  br label %bb20
bb16:
  %t133 = load i32, ptr %l83, !tbaa !23
  %t134 = ashr i32 %t133, 16
  %t136 = icmp eq i32 %t134, 1
  br i1 %t136, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_7dbcadc8ee279278_9f927e608471f374)
  unreachable
bb19:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb58
bb20:
  %t138 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t138, ptr %l12, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  store i64 %t141, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t143 = load i64, ptr %l14, !tbaa !24
  %t144 = load i64, ptr %l13, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb56
bb23:
  br label %bb24
bb24:
  %t151 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t151, ptr %l92, !tbaa !27
  %t152 = load i64, ptr %l14, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr ptr, ptr %t155, i64 %t152
  %t157 = load ptr, ptr %t156, !tbaa !39
  store ptr %t157, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/lsp:worker", ptr %t159, i32 0, i32 0
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/lsp:Server", ptr %t162, i32 0, i32 1
  %t166 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H1531dad62b744074bb3be3226dd54f14(ptr %v0, ptr %t164)
  store i64 %t166, ptr %l98
  br label %bb25
bb25:
  %t167 = load i64, ptr %l98, !tbaa !24
  store i64 %t167, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t168 = load i64, ptr %l17, !tbaa !24
  %t169 = load i64, ptr %l16, !tbaa !24
  %t172 = icmp sgt i64 %t168, %t169
  br i1 %t172, label %bb26, label %bb27
bb26:
  %t174 = load i64, ptr %l18, !tbaa !24
  %t176 = icmp sgt i64 %t174, 0
  br i1 %t176, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb31
bb28:
  %t178 = load i64, ptr %l17, !tbaa !24
  %t179 = load i64, ptr %l16, !tbaa !24
  %t182 = sub i64 %t178, %t179
  %t183 = load i64, ptr %l18, !tbaa !24
  %t186 = add i64 %t182, %t183
  %t188 = sub i64 %t186, 1
  %t189 = load i64, ptr %l18, !tbaa !24
  %t192 = sdiv i64 %t188, %t189
  store i64 %t192, ptr %l105, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb30
bb30:
  %t194 = load i64, ptr %l105, !tbaa !24
  store i64 %t194, ptr %l102, !tbaa !24
  br label %bb31
bb31:
  %t195 = load i64, ptr %l102, !tbaa !24
  store i64 %t195, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t196 = load i64, ptr %l20, !tbaa !24
  %t197 = load i64, ptr %l19, !tbaa !24
  %t200 = icmp slt i64 %t196, %t197
  %t202 = xor i1 %t200, true
  br i1 %t202, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb54
bb34:
  br label %bb35
bb35:
  %t204 = load i64, ptr %l16, !tbaa !24
  %t205 = load i64, ptr %l20, !tbaa !24
  %t206 = load i64, ptr %l18, !tbaa !24
  %t209 = mul i64 %t205, %t206
  %t212 = add i64 %t204, %t209
  store i64 %t212, ptr %l21, !tbaa !24
  %t214 = load i64, ptr %l21, !tbaa !24
  %t215 = load i64, ptr %l1, !tbaa !24
  %t218 = icmp ne i64 %t214, %t215
  br i1 %t218, label %bb36, label %bb37
bb36:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/lsp:worker", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = getelementptr %"compiler/lsp:Server", ptr %t223, i32 0, i32 1
  %t226 = load i64, ptr %l21, !tbaa !24
  %t229 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t225, i64 %t226)
  store ptr %t229, ptr %l131
  br label %bb38
bb37:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb39
bb38:
  %t230 = load ptr, ptr %l131, !tbaa !29
  %t232 = getelementptr %"compiler/lsp:Doc", ptr %t230, i32 0, i32 4
  %t233 = load i1, ptr %t232, !tbaa !21
  store i1 %t233, ptr %l126, !tbaa !21
  br label %bb39
bb39:
  %t235 = load i1, ptr %l126, !tbaa !21
  br i1 %t235, label %bb40, label %bb41
bb40:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/lsp:worker", ptr %t236, i32 0, i32 0
  %t239 = load ptr, ptr %t238, !tbaa !29
  %t241 = getelementptr %"compiler/lsp:Server", ptr %t239, i32 0, i32 1
  %t242 = load i64, ptr %l21, !tbaa !24
  %t245 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t241, i64 %t242)
  store ptr %t245, ptr %l139
  br label %bb42
bb41:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb44
bb42:
  %t246 = load ptr, ptr %l139, !tbaa !29
  %t248 = getelementptr %"compiler/lsp:Doc", ptr %t246, i32 0, i32 2
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  %t250 = load ptr, ptr %l15, !tbaa !29
  %t252 = getelementptr %"compiler/load:Module", ptr %t250, i32 0, i32 1
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t256 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t249, { i64, ptr } %t253)
  store i1 %t256, ptr %l144
  br label %bb43
bb43:
  %t257 = load i1, ptr %l144, !tbaa !21
  store i1 %t257, ptr %l134, !tbaa !21
  br label %bb44
bb44:
  %t258 = load i1, ptr %l134, !tbaa !21
  br i1 %t258, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t259 = load i1, ptr %l9, !tbaa !21
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb47, label %bb48
bb46:
  br label %bb52
bb47:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l8, i8 44)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  store i1 false, ptr %l9, !tbaa !21
  %t264 = load i64, ptr %l21, !tbaa !24
  %t266 = call i64 @__olang_fmt_i64(ptr null, i64 %t264)
  %t267 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t266)
  %t268 = call i64 @__olang_fmt_i64(ptr %t267, i64 %t264)
  %t269 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t267, 1
  %t272 = extractvalue { i64, ptr } %t270, 0
  %t273 = extractvalue { i64, ptr } %t270, 1
  %t274 = mul i64 %t272, 1
  %t275 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t274)
  call void @llvm.memcpy.p0.p0.i64(ptr %t275, ptr %t273, i64 %t274, i1 false)
  %t276 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l8, { i64, ptr } %t277)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s8)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb53
bb53:
  %t280 = load i64, ptr %l20, !tbaa !24
  %t282 = add i64 %t280, 1
  store i64 %t282, ptr %l20, !tbaa !24
  br label %bb32
bb54:
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb55:
  %t284 = load i64, ptr %l14, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l14, !tbaa !24
  br label %bb21
bb56:
  %t288 = load i64, ptr %l11, !tbaa !24
  %t289 = load i64, ptr %l13, !tbaa !24
  %t292 = add i64 %t288, %t289
  store i64 %t292, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb57:
  br label %bb14
bb58:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l8, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d103, i32 0, i32 1) })
  br label %bb59
bb59:
  store i64 0, ptr %l22, !tbaa !24
  %t296 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l7)
  store i64 %t296, ptr %l161
  br label %bb60
bb60:
  %t297 = load i64, ptr %l161, !tbaa !24
  store i64 %t297, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t298 = load i64, ptr %l23, !tbaa !24
  %t299 = load i64, ptr %l22, !tbaa !24
  %t302 = icmp sgt i64 %t298, %t299
  br i1 %t302, label %bb61, label %bb62
bb61:
  %t304 = load i64, ptr %l24, !tbaa !24
  %t306 = icmp sgt i64 %t304, 0
  br i1 %t306, label %bb63, label %bb64
bb62:
  store i64 0, ptr %l165, !tbaa !24
  br label %bb66
bb63:
  %t308 = load i64, ptr %l23, !tbaa !24
  %t309 = load i64, ptr %l22, !tbaa !24
  %t312 = sub i64 %t308, %t309
  %t313 = load i64, ptr %l24, !tbaa !24
  %t316 = add i64 %t312, %t313
  %t318 = sub i64 %t316, 1
  %t319 = load i64, ptr %l24, !tbaa !24
  %t322 = sdiv i64 %t318, %t319
  store i64 %t322, ptr %l168, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l168, !tbaa !24
  br label %bb65
bb65:
  %t324 = load i64, ptr %l168, !tbaa !24
  store i64 %t324, ptr %l165, !tbaa !24
  br label %bb66
bb66:
  %t325 = load i64, ptr %l165, !tbaa !24
  store i64 %t325, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s14
  %t326 = load i64, ptr %l26, !tbaa !24
  %t327 = load i64, ptr %l25, !tbaa !24
  %t330 = icmp slt i64 %t326, %t327
  %t332 = xor i1 %t330, true
  br i1 %t332, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s14)
  br label %bb78
bb69:
  br label %bb70
bb70:
  %t334 = load i64, ptr %l22, !tbaa !24
  %t335 = load i64, ptr %l26, !tbaa !24
  %t336 = load i64, ptr %l24, !tbaa !24
  %t339 = mul i64 %t335, %t336
  %t342 = add i64 %t334, %t339
  store i64 %t342, ptr %l27, !tbaa !24
  %t344 = load i64, ptr %l27, !tbaa !24
  %t346 = icmp sgt i64 %t344, 0
  br i1 %t346, label %bb71, label %bb72
bb71:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l8, i8 44)
  br label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb74
bb74:
  store ptr %l8, ptr %l189, !tbaa !29
  %t349 = load i64, ptr %l27, !tbaa !24
  %t352 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l7, i64 %t349)
  store { i64, ptr } %t352, ptr %l192
  br label %bb75
bb75:
  %t353 = load ptr, ptr %l189, !tbaa !29
  %t354 = load { i64, ptr }, ptr %l192, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %s0, ptr %t353, { i64, ptr } %t354)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s14)
  br label %bb77
bb77:
  %t355 = load i64, ptr %l26, !tbaa !24
  %t357 = add i64 %t355, 1
  store i64 %t357, ptr %l26, !tbaa !24
  br label %bb67
bb78:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb79
bb79:
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l196, !tbaa !29
  %t362 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t362, ptr %l198
  br label %bb80
bb80:
  %t363 = load ptr, ptr %l196, !tbaa !29
  %t364 = load { i64, ptr }, ptr %l198, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s0, ptr %t363, { i64, ptr } %t364)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2ecomplete(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, ptr %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/session:Items"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l14 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l29 = alloca %"compiler/session:Items"
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l49 = alloca i1
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l71 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l74 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l75 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l77 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l78 = alloca i32
  %l99 = alloca ptr
  %l111 = alloca ptr
  %l117 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  store ptr %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l4, !tbaa !24
  store i64 %t1, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load i64, ptr %l7, !tbaa !24
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t7, ptr %l21, !tbaa !27
  %t8 = load i64, ptr %l7, !tbaa !24
  %t10 = sub i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = call i1 @compiler_2fsession_2eWordChar(i8 %t15)
  store i1 %t17, ptr %l25
  br label %bb4
bb3:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i1, ptr %l25, !tbaa !21
  store i1 %t18, ptr %l20, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l20, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t22 = load i64, ptr %l7, !tbaa !24
  %t24 = sub i64 %t22, 1
  store i64 %t24, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %bb1
bb10:
  %t26 = call %"compiler/session:Items" @compiler_2fsession_3aItems_2ector(ptr %s0)
  store %"compiler/session:Items" %t26, ptr %l29
  br label %bb11
bb11:
  %t27 = load %"compiler/session:Items", ptr %l29
  store %"compiler/session:Items" %t27, ptr %l8
  %t28 = load i64, ptr %l7, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb12, label %bb13
bb12:
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t32, ptr %l33, !tbaa !27
  %t33 = load i64, ptr %l7, !tbaa !24
  %t35 = sub i64 %t33, 1
  %t37 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i8, ptr %t38, i64 %t35
  %t40 = load i8, ptr %t39, !tbaa !32
  %t42 = icmp eq i8 %t40, 46
  store i1 %t42, ptr %l32, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb14
bb14:
  %t44 = load i1, ptr %l32, !tbaa !21
  br i1 %t44, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = sub i64 %t45, 1
  store i64 %t47, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  store i64 %t49, ptr %l10, !tbaa !24
  br label %bb17
bb16:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/lsp:Doc", ptr %t51, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t56 = load ptr, ptr %l6, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/lsp:worker", ptr %t57, i32 0, i32 4
  %t64 = call ptr @compiler_2fsession_2eAnalyze(ptr %v2, ptr %v4, ptr %v0, { i64, ptr } %t54, ptr %t55, ptr %t56, ptr %t59, i1 true)
  store ptr %t64, ptr %l111
  br label %bb54
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t71 = icmp slt i64 %t65, %t68
  br i1 %t71, label %bb18, label %bb19
bb18:
  %t73 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t73, ptr %l46, !tbaa !27
  %t74 = load i64, ptr %l10, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 %t74
  %t79 = load i8, ptr %t78, !tbaa !32
  %t81 = call i1 @compiler_2fsession_2eWordChar(i8 %t79)
  store i1 %t81, ptr %l49
  br label %bb20
bb19:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb21
bb20:
  %t82 = load i1, ptr %l49, !tbaa !21
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb21
bb21:
  %t83 = load i1, ptr %l45, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t86 = load i64, ptr %l10, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  br label %bb17
bb26:
  %t90 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t90, ptr %l53, !tbaa !27
  %t91 = load i64, ptr %l9, !tbaa !24
  store i64 %t91, ptr %l54, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l55, !tbaa !24
  %t94 = icmp sge i64 0, 0
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t96 = load i64, ptr %l54, !tbaa !24
  %t97 = icmp sle i64 0, %t96
  br i1 %t97, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a)
  unreachable
bb29:
  %t99 = load i64, ptr %l54, !tbaa !24
  %t100 = load i64, ptr %l55, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  br i1 %t101, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a)
  unreachable
bb31:
  %t103 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l54, !tbaa !24
  %t106 = getelementptr i8, ptr %t104, i64 0
  %t107 = sub i64 %t105, 0
  %t108 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  store { i64, ptr } %t109, ptr %l59, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t110, ptr %l60, !tbaa !27
  %t111 = load i64, ptr %l10, !tbaa !24
  store i64 %t111, ptr %l61, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t112, 0
  store i64 %t115, ptr %l64, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  store i64 %t117, ptr %l65, !tbaa !24
  %t118 = load i64, ptr %l61, !tbaa !24
  %t119 = icmp sge i64 %t118, 0
  br i1 %t119, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a)
  unreachable
bb33:
  %t121 = load i64, ptr %l61, !tbaa !24
  %t122 = load i64, ptr %l64, !tbaa !24
  %t123 = icmp sle i64 %t121, %t122
  br i1 %t123, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a)
  unreachable
bb35:
  %t125 = load i64, ptr %l64, !tbaa !24
  %t126 = load i64, ptr %l65, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a)
  unreachable
bb37:
  %t129 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l61, !tbaa !24
  %t132 = load i64, ptr %l64, !tbaa !24
  %t133 = getelementptr i8, ptr %t130, i64 %t131
  %t134 = sub i64 %t132, %t131
  %t135 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t133, 1
  %t137 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t141 = extractvalue { i64, ptr } %t136, 1
  %t142 = extractvalue { i64, ptr } %t136, 0
  %t143 = add i64 %t139, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t138, i64 %t139)
  %t145 = getelementptr i8, ptr %t144, i64 %t139
  call void @olang_textcopy(ptr %t145, ptr %t141, i64 %t142)
  %t146 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t144, 1
  store { i64, ptr } %t147, ptr %l11, !tbaa !27
  %t149 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t149, ptr %l71
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a)
  unreachable
bb39:
  %t150 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l71
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t150, ptr %l12
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/lsp:worker", ptr %t151, i32 0, i32 4
  %t155 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H233962476a3191cb30d917b30cae0288(ptr %v0, ptr %v0, ptr %t153)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t155, ptr %l74
  br label %bb40
bb40:
  %t156 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l74
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t156, ptr %l13
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t158 = call { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2_H2ebf6f1d68886862a568a520c713bfce(ptr %v0, ptr %v0, ptr %l13)
  %t159 = extractvalue { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } %t158, 1
  %t160 = extractvalue { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } %t158, 0
  store i32 %t160, ptr %l78
  %t161 = icmp ne i32 %t160, 0
  br i1 %t161, label %bb43, label %ok.162
ok.162:
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t159, ptr %l77
  br label %bb42
bb42:
  %t163 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l77
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t163, ptr %l75
  br label %bb47
bb43:
  %t164 = load i32, ptr %l78, !tbaa !23
  %t165 = ashr i32 %t164, 16
  %t167 = icmp eq i32 %t165, 1
  br i1 %t167, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_a7da96addb4507f4_b5358bb03c267030)
  unreachable
bb46:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb47:
  %t169 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l75
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t169, ptr %l14
  %t170 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l14, i32 0, i32 0
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t171, 1
  %t174 = extractvalue { i64, ptr } %t171, 0
  %t175 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t173, i64 %t174)
  %t176 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = extractvalue { i64, ptr } %t177, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l14, i32 0, i32 1
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 1
  %t189 = extractvalue { i64, ptr } %t186, 0
  %t190 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t189)
  call void @olang_textcopy(ptr %t190, ptr %t188, i64 %t189)
  %t191 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  %t194 = extractvalue { i64, ptr } %t192, 0
  %t195 = extractvalue { i64, ptr } %t192, 1
  %t196 = mul i64 %t194, 1
  %t197 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t195, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %s2, ptr %s2, ptr %s2, ptr %l12, { i64, ptr } %t184, { i64, ptr } %t199)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  br label %bb41
bb50:
  %t203 = load ptr, ptr %l2, !tbaa !29
  %t205 = getelementptr %"compiler/lsp:Doc", ptr %t203, i32 0, i32 2
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 1
  %t209 = extractvalue { i64, ptr } %t206, 0
  %t210 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t209)
  call void @olang_textcopy(ptr %t210, ptr %t208, i64 %t209)
  %t211 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = extractvalue { i64, ptr } %t212, 1
  %t216 = mul i64 %t214, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t217, ptr %t215, i64 %t216, i1 false)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  %t220 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %s2, ptr %s2, ptr %s2, ptr %l12, { i64, ptr } %t219, { i64, ptr } %t220)
  br label %bb51
bb51:
  %t224 = load ptr, ptr %l2, !tbaa !29
  %t226 = getelementptr %"compiler/lsp:Doc", ptr %t224, i32 0, i32 1
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t228 = load ptr, ptr %l5, !tbaa !29
  %t229 = load ptr, ptr %l6, !tbaa !29
  %t234 = call ptr @compiler_2fsession_2eAnalyze(ptr %v2, ptr %v4, ptr %s2, { i64, ptr } %t227, ptr %t228, ptr %t229, ptr %l12, i1 true)
  store ptr %t234, ptr %l99
  br label %bb52
bb52:
  %t235 = load ptr, ptr %l99, !tbaa !29
  %t237 = load ptr, ptr %l2, !tbaa !29
  %t239 = getelementptr %"compiler/lsp:Doc", ptr %t237, i32 0, i32 2
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  %t241 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eMembers(ptr %v4, ptr %s0, ptr %v2, ptr %t235, ptr %l8, { i64, ptr } %t240, i64 %t241)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s2)
  br label %bb56
bb54:
  %t246 = load ptr, ptr %l111, !tbaa !29
  %t248 = load ptr, ptr %l2, !tbaa !29
  %t250 = getelementptr %"compiler/lsp:Doc", ptr %t248, i32 0, i32 2
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  %t252 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eNames(ptr %v4, ptr %s0, ptr %v2, ptr %t246, ptr %l8, { i64, ptr } %t251, i64 %t252)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l117, !tbaa !29
  store { i64, ptr } %a1, ptr %l118, !tbaa !27
  %t259 = getelementptr %"compiler/session:Items", ptr %l8, i32 0, i32 0
  %t261 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t259)
  store { i64, ptr } %t261, ptr %l120
  br label %bb57
bb57:
  %t262 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t264 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 1
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t267 = add i64 %t263, %t266
  %t268 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t270 = add i64 %t267, %t269
  %t271 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t270)
  call void @olang_textcopy(ptr %t271, ptr %t262, i64 %t263)
  %t272 = getelementptr i8, ptr %t271, i64 %t263
  call void @olang_textcopy(ptr %t272, ptr %t265, i64 %t266)
  %t273 = getelementptr i8, ptr %t272, i64 %t266
  call void @olang_textcopy(ptr %t273, ptr %t268, i64 %t269)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t271, 1
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t278 = extractvalue { i64, ptr } %t275, 1
  %t279 = mul i64 %t277, 1
  %t280 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t279)
  call void @llvm.memcpy.p0.p0.i64(ptr %t280, ptr %t278, i64 %t279, i1 false)
  %t281 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  %t283 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t285 = call { i64, ptr } @compiler_2flsp_2ereply(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t283, { i64, ptr } %t282)
  store { i64, ptr } %t285, ptr %l123
  br label %bb58
bb58:
  %t286 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 0
  %t288 = extractvalue { i64, ptr } %t286, 1
  %t289 = mul i64 %t287, 1
  %t290 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t289)
  call void @llvm.memcpy.p0.p0.i64(ptr %t290, ptr %t288, i64 %t289, i1 false)
  %t291 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  %t293 = load ptr, ptr %l117, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s0, ptr %t293, { i64, ptr } %t292)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2ediagnostic(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/diag:Item"
  %l8 = alloca %"compiler/session:Positions"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca %"compiler/diag:Item"
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"compiler/session:Positions"
  %l21 = alloca %"compiler/diag:Item"
  %l25 = alloca { i64, ptr }
  %l30 = alloca %"compiler/session:Positions"
  %l38 = alloca i1
  %l46 = alloca %"std/prelude/text:StringBuilder"
  %l50 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l77 = alloca %"compiler/diag:Item"
  %l80 = alloca i64
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l99 = alloca %"compiler/session:Positions"
  %l101 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l118 = alloca i64
  %l120 = alloca ptr
  %l122 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t2 = load i64, ptr %l5, !tbaa !24
  %t5 = call %"compiler/diag:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %v4, ptr %v4, ptr %t1, i64 %t2)
  store %"compiler/diag:Item" %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load %"compiler/diag:Item", ptr %l21
  store %"compiler/diag:Item" %t6, ptr %l7
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t13 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2etextOf(ptr %v0, ptr %v2, ptr %v5, ptr %s0, ptr %t7, ptr %t8, { i64, ptr } %t9)
  store { i64, ptr } %t13, ptr %l25
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/lsp:worker", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/lsp:Server", ptr %t24, i32 0, i32 2
  %t27 = load i1, ptr %t26, !tbaa !21
  %t30 = call %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %s0, ptr %s0, { i64, ptr } %t20, i1 %t27)
  store %"compiler/session:Positions" %t30, ptr %l30
  br label %bb3
bb3:
  %t31 = load %"compiler/session:Positions", ptr %l30
  store %"compiler/session:Positions" %t31, ptr %l8
  %t32 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t32, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d107, i32 0, i32 1) })
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2erangeOf(ptr %v0, ptr %v1, ptr %s0, ptr %v4, ptr %t34, ptr %t35, ptr %l8, ptr %l7)
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t40, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb6
bb6:
  %t42 = getelementptr %"compiler/diag:Item", ptr %l7, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t43, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d109, i32 0, i32 1) })
  store i1 %t45, ptr %l38
  br label %bb7
bb7:
  %t46 = load i1, ptr %l38, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t49 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t49, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/diag:Item", ptr %l7, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v1, ptr %v4, ptr %t51, { i64, ptr } %t53)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb12:
  %t56 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t56, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/diag:Item", ptr %l7, i32 0, i32 6
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v1, ptr %v4, ptr %t58, { i64, ptr } %t60)
  br label %bb14
bb14:
  %t63 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t63, ptr %l46
  br label %bb15
bb15:
  %t64 = load %"std/prelude/text:StringBuilder", ptr %l46
  store %"std/prelude/text:StringBuilder" %t64, ptr %l9
  %t65 = load i64, ptr %l5, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l10, !tbaa !24
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %v4, ptr %t69)
  store i64 %t71, ptr %l50
  br label %bb16
bb16:
  %t72 = load i64, ptr %l50, !tbaa !24
  store i64 %t72, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t73 = load i64, ptr %l11, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t77 = icmp sgt i64 %t73, %t74
  br i1 %t77, label %bb17, label %bb18
bb17:
  %t79 = load i64, ptr %l12, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb22
bb19:
  %t83 = load i64, ptr %l11, !tbaa !24
  %t84 = load i64, ptr %l10, !tbaa !24
  %t87 = sub i64 %t83, %t84
  %t88 = load i64, ptr %l12, !tbaa !24
  %t91 = add i64 %t87, %t88
  %t93 = sub i64 %t91, 1
  %t94 = load i64, ptr %l12, !tbaa !24
  %t97 = sdiv i64 %t93, %t94
  store i64 %t97, ptr %l57, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb21
bb21:
  %t99 = load i64, ptr %l57, !tbaa !24
  store i64 %t99, ptr %l54, !tbaa !24
  br label %bb22
bb22:
  %t100 = load i64, ptr %l54, !tbaa !24
  store i64 %t100, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t101 = load i64, ptr %l14, !tbaa !24
  %t102 = load i64, ptr %l13, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb51
bb25:
  br label %bb26
bb26:
  %t109 = load i64, ptr %l10, !tbaa !24
  %t110 = load i64, ptr %l14, !tbaa !24
  %t111 = load i64, ptr %l12, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  %t119 = load ptr, ptr %l4, !tbaa !29
  %t123 = call %"compiler/diag:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %v4, ptr %v4, ptr %t119, i64 %t117)
  store %"compiler/diag:Item" %t123, ptr %l77
  br label %bb27
bb27:
  %t124 = load %"compiler/diag:Item", ptr %l77
  store %"compiler/diag:Item" %t124, ptr %l16
  %t125 = getelementptr %"compiler/diag:Item", ptr %l16, i32 0, i32 0
  %t126 = load i1, ptr %t125, !tbaa !21
  br i1 %t126, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb51
bb29:
  br label %bb30
bb30:
  %t129 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l9)
  store i64 %t129, ptr %l80
  br label %bb31
bb31:
  %t130 = load i64, ptr %l80, !tbaa !24
  %t131 = icmp sgt i64 %t130, 0
  br i1 %t131, label %bb32, label %bb33
bb32:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 44)
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  %t134 = getelementptr %"compiler/diag:Item", ptr %l16, i32 0, i32 2
  %t135 = load i64, ptr %t134, !tbaa !24
  %t137 = icmp sge i64 %t135, 0
  br i1 %t137, label %bb36, label %bb37
bb36:
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t140 = getelementptr %"compiler/diag:Item", ptr %l16, i32 0, i32 2
  %t141 = load i64, ptr %t140, !tbaa !24
  %t144 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eRealOfFile(ptr %v2, ptr %s3, ptr %t139, i64 %t141)
  store { i64, ptr } %t144, ptr %l88
  br label %bb38
bb37:
  %t145 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = extractvalue { i64, ptr } %t145, 0
  %t149 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t147, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l85, !tbaa !27
  br label %bb39
bb38:
  %t153 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t153, ptr %l85, !tbaa !27
  br label %bb39
bb39:
  %t154 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t154, ptr %l17, !tbaa !27
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l2, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t161 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2etextOf(ptr %v0, ptr %v2, ptr %s3, ptr %s3, ptr %t155, ptr %t156, { i64, ptr } %t157)
  store { i64, ptr } %t161, ptr %l94
  br label %bb40
bb40:
  %t162 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  %t164 = extractvalue { i64, ptr } %t162, 1
  %t165 = mul i64 %t163, 1
  %t166 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t165)
  call void @llvm.memcpy.p0.p0.i64(ptr %t166, ptr %t164, i64 %t165, i1 false)
  %t167 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/lsp:worker", ptr %t169, i32 0, i32 0
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/lsp:Server", ptr %t172, i32 0, i32 2
  %t175 = load i1, ptr %t174, !tbaa !21
  %t178 = call %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %s3, ptr %s3, { i64, ptr } %t168, i1 %t175)
  store %"compiler/session:Positions" %t178, ptr %l99
  br label %bb41
bb41:
  %t179 = load %"compiler/session:Positions", ptr %l99
  store %"compiler/session:Positions" %t179, ptr %l18
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l9, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb42
bb42:
  store ptr %l9, ptr %l101, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t185 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2euriOf(ptr %v0, ptr %s3, ptr %s3, ptr %t181, { i64, ptr } %t182)
  store { i64, ptr } %t185, ptr %l104
  br label %bb43
bb43:
  %t186 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t188 = extractvalue { i64, ptr } %t186, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  %t193 = load ptr, ptr %l101, !tbaa !29
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %s3, ptr %t193, { i64, ptr } %t192)
  br label %bb44
bb44:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l9, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d113, i32 0, i32 1) })
  br label %bb45
bb45:
  %t196 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2erangeOf(ptr %v0, ptr %s0, ptr %s3, ptr %v4, ptr %t196, ptr %l9, ptr %l18, ptr %l16)
  br label %bb46
bb46:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l9, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d114, i32 0, i32 1) })
  br label %bb47
bb47:
  %t202 = getelementptr %"compiler/diag:Item", ptr %l16, i32 0, i32 6
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v4, ptr %l9, { i64, ptr } %t203)
  br label %bb48
bb48:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l9, i8 125)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s3)
  br label %bb50
bb50:
  %t207 = load i64, ptr %l14, !tbaa !24
  %t209 = add i64 %t207, 1
  store i64 %t209, ptr %l14, !tbaa !24
  br label %bb23
bb51:
  %t212 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l9)
  store i64 %t212, ptr %l118
  br label %bb52
bb52:
  %t213 = load i64, ptr %l118, !tbaa !24
  %t214 = icmp sgt i64 %t213, 0
  br i1 %t214, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s8
  %t216 = load ptr, ptr %l1, !tbaa !29
  store ptr %t216, ptr %l120, !tbaa !29
  %t218 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s8, ptr %l9)
  store { i64, ptr } %t218, ptr %l122
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t219 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t221 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = add i64 %t220, %t223
  %t225 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t219, i64 %t220)
  %t229 = getelementptr i8, ptr %t228, i64 %t220
  call void @olang_textcopy(ptr %t229, ptr %t222, i64 %t223)
  %t230 = getelementptr i8, ptr %t229, i64 %t223
  call void @olang_textcopy(ptr %t230, ptr %t225, i64 %t226)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t228, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = extractvalue { i64, ptr } %t232, 1
  %t236 = mul i64 %t234, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t237, ptr %t235, i64 %t236, i1 false)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  %t240 = load ptr, ptr %l120, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s8, ptr %t240, { i64, ptr } %t239)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s8)
  br label %bb57
bb57:
  %t242 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t242, i8 125)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2flsp_2ecompiler_2flsp_3aworker_2epublishAll(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/diag:Item"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"std/prelude/text:StringBuilder"
  %l25 = alloca %"std/prelude/text:StringBuilder"
  %lp26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i64
  %l84 = alloca %"compiler/diag:Item"
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l97 = alloca i1
  %l100 = alloca { i64, ptr }
  %l102 = alloca i64
  %l105 = alloca i64
  %l109 = alloca i64
  %l112 = alloca i64
  %l132 = alloca { i64, ptr }
  %l134 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca %"std/prelude/text:StringBuilder"
  %l147 = alloca i64
  %l151 = alloca %"std/prelude/text:StringBuilder"
  %l153 = alloca i64
  %l165 = alloca %"std/prelude/text:StringBuilder"
  %l166 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l168 = alloca i64
  %l172 = alloca i64
  %l175 = alloca i64
  %l195 = alloca { i64, ptr }
  %l198 = alloca i1
  %l201 = alloca %"std/prelude/text:StringBuilder"
  %l204 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l214 = alloca i64
  %l218 = alloca i64
  %l221 = alloca i64
  %l241 = alloca { i64, ptr }
  %l244 = alloca i1
  %l245 = alloca i1
  %l246 = alloca ptr
  %l249 = alloca { i64, ptr }
  %l250 = alloca i1
  %l251 = alloca ptr
  %l254 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l257 = alloca { i64, ptr }
  %l260 = alloca %"std/prelude/text:StringBuilder"
  %l262 = alloca { i64, ptr }
  %l265 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l277 = alloca { i64, ptr }
  %l278 = alloca i32
  %l287 = alloca { i64, ptr }
  %l293 = alloca i1
  %l295 = alloca ptr
  %l297 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:worker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lsp:Server", ptr %t4, i32 0, i32 1
  %t10 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l51
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l51, !tbaa !29
  store ptr %t11, ptr %l5, !tbaa !29
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l52
  br label %bb2
bb2:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l6
  %t14 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilder_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l53
  br label %bb3
bb3:
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l7
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eItems(ptr %v2, ptr %s0, ptr %t16)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l55
  br label %bb4
bb4:
  %t19 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %l8)
  store i64 %t21, ptr %l57
  br label %bb5
bb5:
  %t22 = load i64, ptr %l57, !tbaa !24
  store i64 %t22, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t23 = load i64, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l9, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load i64, ptr %l11, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb11
bb8:
  %t33 = load i64, ptr %l10, !tbaa !24
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l11, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l11, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l64, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l64, !tbaa !24
  store i64 %t49, ptr %l61, !tbaa !24
  br label %bb11
bb11:
  %t50 = load i64, ptr %l61, !tbaa !24
  store i64 %t50, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load i64, ptr %l13, !tbaa !24
  %t52 = load i64, ptr %l12, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb14:
  br label %bb15
bb15:
  %t59 = load i64, ptr %l9, !tbaa !24
  %t60 = load i64, ptr %l13, !tbaa !24
  %t61 = load i64, ptr %l11, !tbaa !24
  %t64 = mul i64 %t60, %t61
  %t67 = add i64 %t59, %t64
  store i64 %t67, ptr %l14, !tbaa !24
  %t69 = load i64, ptr %l14, !tbaa !24
  %t72 = call %"compiler/diag:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %s0, ptr %s0, ptr %l8, i64 %t69)
  store %"compiler/diag:Item" %t72, ptr %l84
  br label %bb16
bb16:
  %t73 = load %"compiler/diag:Item", ptr %l84
  store %"compiler/diag:Item" %t73, ptr %l15
  %t74 = getelementptr %"compiler/diag:Item", ptr %l15, i32 0, i32 0
  %t75 = load i1, ptr %t74, !tbaa !21
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb63
bb18:
  br label %bb19
bb19:
  %t79 = getelementptr %"compiler/diag:Item", ptr %l15, i32 0, i32 2
  %t80 = load i64, ptr %t79, !tbaa !24
  %t82 = icmp sge i64 %t80, 0
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr %"compiler/diag:Item", ptr %l15, i32 0, i32 2
  %t86 = load i64, ptr %t85, !tbaa !24
  %t89 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eRealOfFile(ptr %v1, ptr %s2, ptr %t84, i64 %t86)
  store { i64, ptr } %t89, ptr %l92
  br label %bb22
bb21:
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/lsp:Doc", ptr %t90, i32 0, i32 2
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = extractvalue { i64, ptr } %t93, 0
  %t97 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t95, i64 %t96)
  %t98 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l89, !tbaa !27
  br label %bb23
bb22:
  %t101 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t101, ptr %l89, !tbaa !27
  br label %bb23
bb23:
  %t102 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t102, ptr %l16, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t105 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t103, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d117, i32 0, i32 1) })
  store i1 %t105, ptr %l97
  br label %bb24
bb24:
  %t106 = load i1, ptr %l97, !tbaa !21
  br i1 %t106, label %bb25, label %bb26
bb25:
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t109 = getelementptr %"compiler/lsp:Doc", ptr %t107, i32 0, i32 2
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 1
  %t113 = extractvalue { i64, ptr } %t110, 0
  %t114 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t112, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l100, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  %t119 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l102, !tbaa !24
  %t122 = load i64, ptr %l102, !tbaa !24
  %t123 = icmp eq i64 %t118, %t122
  br i1 %t123, label %bb27, label %bb28
bb26:
  br label %bb30
bb27:
  %t125 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l102, !tbaa !24
  %t130 = mul i64 %t129, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %t128, i64 %t130, i1 false)
  br label %bb29
bb28:
  %t131 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t131, ptr %l16, !tbaa !27
  br label %bb29
bb29:
  br label %bb30
bb30:
  store i64 -1, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t133 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l6)
  store i64 %t133, ptr %l105
  br label %bb31
bb31:
  %t134 = load i64, ptr %l105, !tbaa !24
  store i64 %t134, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t135 = load i64, ptr %l19, !tbaa !24
  %t136 = load i64, ptr %l18, !tbaa !24
  %t139 = icmp sgt i64 %t135, %t136
  br i1 %t139, label %bb32, label %bb33
bb32:
  %t141 = load i64, ptr %l20, !tbaa !24
  %t143 = icmp sgt i64 %t141, 0
  br i1 %t143, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb37
bb34:
  %t145 = load i64, ptr %l19, !tbaa !24
  %t146 = load i64, ptr %l18, !tbaa !24
  %t149 = sub i64 %t145, %t146
  %t150 = load i64, ptr %l20, !tbaa !24
  %t153 = add i64 %t149, %t150
  %t155 = sub i64 %t153, 1
  %t156 = load i64, ptr %l20, !tbaa !24
  %t159 = sdiv i64 %t155, %t156
  store i64 %t159, ptr %l112, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb36
bb36:
  %t161 = load i64, ptr %l112, !tbaa !24
  store i64 %t161, ptr %l109, !tbaa !24
  br label %bb37
bb37:
  %t162 = load i64, ptr %l109, !tbaa !24
  store i64 %t162, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t163 = load i64, ptr %l22, !tbaa !24
  %t164 = load i64, ptr %l21, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb40:
  br label %bb41
bb41:
  %t171 = load i64, ptr %l18, !tbaa !24
  %t172 = load i64, ptr %l22, !tbaa !24
  %t173 = load i64, ptr %l20, !tbaa !24
  %t176 = mul i64 %t172, %t173
  %t179 = add i64 %t171, %t176
  store i64 %t179, ptr %l23, !tbaa !24
  %t181 = load i64, ptr %l23, !tbaa !24
  %t184 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l6, i64 %t181)
  store { i64, ptr } %t184, ptr %l132
  br label %bb42
bb42:
  %t185 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t188 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t186, { i64, ptr } %t185)
  store i1 %t188, ptr %l134
  br label %bb43
bb43:
  %t189 = load i1, ptr %l134, !tbaa !21
  br i1 %t189, label %bb44, label %bb45
bb44:
  %t190 = load i64, ptr %l23, !tbaa !24
  store i64 %t190, ptr %l17, !tbaa !24
  br label %bb46
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s8)
  br label %bb47
bb47:
  %t192 = load i64, ptr %l22, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l22, !tbaa !24
  br label %bb38
bb48:
  %t196 = load i64, ptr %l17, !tbaa !24
  %t198 = icmp slt i64 %t196, 0
  br i1 %t198, label %bb49, label %bb50
bb49:
  %t200 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = extractvalue { i64, ptr } %t200, 0
  %t204 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t203)
  call void @olang_textcopy(ptr %t204, ptr %t202, i64 %t203)
  %t205 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = extractvalue { i64, ptr } %t206, 1
  %t210 = mul i64 %t208, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t210)
  call void @llvm.memcpy.p0.p0.i64(ptr %t211, ptr %t209, i64 %t210, i1 false)
  %t212 = insertvalue { i64, ptr } undef, i64 %t208, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t213)
  br label %bb51
bb50:
  br label %bb55
bb51:
  store ptr %l7, ptr %l144, !tbaa !29
  %t216 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t216, ptr %l145
  br label %bb52
bb52:
  %t217 = load ptr, ptr %l144, !tbaa !29
  %t218 = load %"std/prelude/text:StringBuilder", ptr %l145
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilde_H96a31ecee6fa958f3b956bd4cf13d4ad(ptr %s0, ptr %s0, ptr %t217, %"std/prelude/text:StringBuilder" %t218)
  br label %bb53
bb53:
  %t220 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l6)
  store i64 %t220, ptr %l147
  br label %bb54
bb54:
  %t221 = load i64, ptr %l147, !tbaa !24
  %t222 = sub i64 %t221, 1
  store i64 %t222, ptr %l17, !tbaa !24
  br label %bb55
bb55:
  %t224 = load i64, ptr %l17, !tbaa !24
  %t227 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilde_H0e2e3c0fe5ff21020d49b50eb045255d(ptr %s0, ptr %s0, ptr %l7, i64 %t224)
  store %"std/prelude/text:StringBuilder" %t227, ptr %l151
  br label %bb56
bb56:
  %t228 = load %"std/prelude/text:StringBuilder", ptr %l151
  store %"std/prelude/text:StringBuilder" %t228, ptr %l24
  %t230 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l24)
  store i64 %t230, ptr %l153
  br label %bb57
bb57:
  %t231 = load i64, ptr %l153, !tbaa !24
  %t232 = icmp sgt i64 %t231, 0
  br i1 %t232, label %bb58, label %bb59
bb58:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l24, i8 44)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load ptr, ptr %l2, !tbaa !29
  %t237 = load ptr, ptr %l3, !tbaa !29
  %t238 = load i64, ptr %l14, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2ediagnostic(ptr %v0, ptr %s0, ptr %v1, ptr %v2, ptr %s0, ptr %s2, ptr %t235, ptr %l24, ptr %t236, ptr %t237, ptr %l8, i64 %t238, { i64, ptr } %t239)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s2)
  br label %bb63
bb63:
  %t247 = load i64, ptr %l13, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l13, !tbaa !24
  br label %bb12
bb64:
  %t251 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t251, ptr %l165
  br label %bb65
bb65:
  %t252 = load %"std/prelude/text:StringBuilder", ptr %l165
  store %"std/prelude/text:StringBuilder" %t252, ptr %l25
  %t253 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t253, ptr %l166
  br label %bb66
bb66:
  %t254 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 8, i64 8)
  store ptr %t254, ptr %lp26
  %t255 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l166
  %t256 = load ptr, ptr %lp26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t255, ptr %t256
  store i64 0, ptr %l27, !tbaa !24
  %t258 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l6)
  store i64 %t258, ptr %l168
  br label %bb67
bb67:
  %t259 = load i64, ptr %l168, !tbaa !24
  store i64 %t259, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t260 = load i64, ptr %l28, !tbaa !24
  %t261 = load i64, ptr %l27, !tbaa !24
  %t264 = icmp sgt i64 %t260, %t261
  br i1 %t264, label %bb68, label %bb69
bb68:
  %t266 = load i64, ptr %l29, !tbaa !24
  %t268 = icmp sgt i64 %t266, 0
  br i1 %t268, label %bb70, label %bb71
bb69:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb73
bb70:
  %t270 = load i64, ptr %l28, !tbaa !24
  %t271 = load i64, ptr %l27, !tbaa !24
  %t274 = sub i64 %t270, %t271
  %t275 = load i64, ptr %l29, !tbaa !24
  %t278 = add i64 %t274, %t275
  %t280 = sub i64 %t278, 1
  %t281 = load i64, ptr %l29, !tbaa !24
  %t284 = sdiv i64 %t280, %t281
  store i64 %t284, ptr %l175, !tbaa !24
  br label %bb72
bb71:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb72
bb72:
  %t286 = load i64, ptr %l175, !tbaa !24
  store i64 %t286, ptr %l172, !tbaa !24
  br label %bb73
bb73:
  %t287 = load i64, ptr %l172, !tbaa !24
  store i64 %t287, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s16
  %t288 = load i64, ptr %l31, !tbaa !24
  %t289 = load i64, ptr %l30, !tbaa !24
  %t292 = icmp slt i64 %t288, %t289
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s16)
  br label %bb85
bb76:
  br label %bb77
bb77:
  %t296 = load i64, ptr %l27, !tbaa !24
  %t297 = load i64, ptr %l31, !tbaa !24
  %t298 = load i64, ptr %l29, !tbaa !24
  %t301 = mul i64 %t297, %t298
  %t304 = add i64 %t296, %t301
  store i64 %t304, ptr %l32, !tbaa !24
  %t306 = load i64, ptr %l32, !tbaa !24
  %t309 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l6, i64 %t306)
  store { i64, ptr } %t309, ptr %l195
  br label %bb78
bb78:
  %t310 = load ptr, ptr %l5, !tbaa !29
  %t312 = getelementptr %"compiler/lsp:Doc", ptr %t310, i32 0, i32 2
  %t313 = load { i64, ptr }, ptr %t312, !tbaa !27
  %t314 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t316 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v0, { i64, ptr } %t314, { i64, ptr } %t313)
  store i1 %t316, ptr %l198
  br label %bb79
bb79:
  %t317 = load i1, ptr %l198, !tbaa !21
  br i1 %t317, label %bb80, label %bb81
bb80:
  %t318 = load i64, ptr %l32, !tbaa !24
  %t321 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilde_H0e2e3c0fe5ff21020d49b50eb045255d(ptr %s0, ptr %s0, ptr %l7, i64 %t318)
  store %"std/prelude/text:StringBuilder" %t321, ptr %l201
  br label %bb82
bb81:
  br label %bb83
bb82:
  %t322 = load %"std/prelude/text:StringBuilder", ptr %l201
  store %"std/prelude/text:StringBuilder" %t322, ptr %l25
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s16)
  br label %bb84
bb84:
  %t323 = load i64, ptr %l31, !tbaa !24
  %t325 = add i64 %t323, 1
  store i64 %t325, ptr %l31, !tbaa !24
  br label %bb74
bb85:
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l204, !tbaa !29
  %t328 = load ptr, ptr %l5, !tbaa !29
  %t330 = getelementptr %"compiler/lsp:Doc", ptr %t328, i32 0, i32 0
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  store { i64, ptr } %t331, ptr %l206, !tbaa !27
  %t333 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l25)
  store { i64, ptr } %t333, ptr %l208
  br label %bb86
bb86:
  %t334 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t335 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t336 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = add i64 %t335, %t338
  %t340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t341 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t342 = add i64 %t339, %t341
  %t343 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t342)
  call void @olang_textcopy(ptr %t343, ptr %t334, i64 %t335)
  %t344 = getelementptr i8, ptr %t343, i64 %t335
  call void @olang_textcopy(ptr %t344, ptr %t337, i64 %t338)
  %t345 = getelementptr i8, ptr %t344, i64 %t338
  call void @olang_textcopy(ptr %t345, ptr %t340, i64 %t341)
  %t346 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t343, 1
  %t349 = extractvalue { i64, ptr } %t347, 0
  %t350 = extractvalue { i64, ptr } %t347, 1
  %t351 = mul i64 %t349, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t351)
  call void @llvm.memcpy.p0.p0.i64(ptr %t352, ptr %t350, i64 %t351, i1 false)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  %t355 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t357 = call { i64, ptr } @compiler_2flsp_2epublish(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t355, { i64, ptr } %t354)
  store { i64, ptr } %t357, ptr %l211
  br label %bb87
bb87:
  %t358 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  %t360 = extractvalue { i64, ptr } %t358, 1
  %t361 = mul i64 %t359, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t361)
  call void @llvm.memcpy.p0.p0.i64(ptr %t362, ptr %t360, i64 %t361, i1 false)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  %t365 = load ptr, ptr %l204, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s0, ptr %t365, { i64, ptr } %t364)
  br label %bb88
bb88:
  store i64 0, ptr %l33, !tbaa !24
  %t368 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l6)
  store i64 %t368, ptr %l214
  br label %bb89
bb89:
  %t369 = load i64, ptr %l214, !tbaa !24
  store i64 %t369, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t370 = load i64, ptr %l34, !tbaa !24
  %t371 = load i64, ptr %l33, !tbaa !24
  %t374 = icmp sgt i64 %t370, %t371
  br i1 %t374, label %bb90, label %bb91
bb90:
  %t376 = load i64, ptr %l35, !tbaa !24
  %t378 = icmp sgt i64 %t376, 0
  br i1 %t378, label %bb92, label %bb93
bb91:
  store i64 0, ptr %l218, !tbaa !24
  br label %bb95
bb92:
  %t380 = load i64, ptr %l34, !tbaa !24
  %t381 = load i64, ptr %l33, !tbaa !24
  %t384 = sub i64 %t380, %t381
  %t385 = load i64, ptr %l35, !tbaa !24
  %t388 = add i64 %t384, %t385
  %t390 = sub i64 %t388, 1
  %t391 = load i64, ptr %l35, !tbaa !24
  %t394 = sdiv i64 %t390, %t391
  store i64 %t394, ptr %l221, !tbaa !24
  br label %bb94
bb93:
  store i64 0, ptr %l221, !tbaa !24
  br label %bb94
bb94:
  %t396 = load i64, ptr %l221, !tbaa !24
  store i64 %t396, ptr %l218, !tbaa !24
  br label %bb95
bb95:
  %t397 = load i64, ptr %l218, !tbaa !24
  store i64 %t397, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s21
  %t398 = load i64, ptr %l37, !tbaa !24
  %t399 = load i64, ptr %l36, !tbaa !24
  %t402 = icmp slt i64 %t398, %t399
  %t404 = xor i1 %t402, true
  br i1 %t404, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s21)
  br label %bb118
bb98:
  br label %bb99
bb99:
  %t406 = load i64, ptr %l33, !tbaa !24
  %t407 = load i64, ptr %l37, !tbaa !24
  %t408 = load i64, ptr %l35, !tbaa !24
  %t411 = mul i64 %t407, %t408
  %t414 = add i64 %t406, %t411
  store i64 %t414, ptr %l38, !tbaa !24
  %t416 = load i64, ptr %l38, !tbaa !24
  %t419 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l6, i64 %t416)
  store { i64, ptr } %t419, ptr %l241
  br label %bb100
bb100:
  %t420 = load ptr, ptr %l5, !tbaa !29
  %t422 = getelementptr %"compiler/lsp:Doc", ptr %t420, i32 0, i32 2
  %t423 = load { i64, ptr }, ptr %t422, !tbaa !27
  %t424 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t426 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v0, { i64, ptr } %t424, { i64, ptr } %t423)
  store i1 %t426, ptr %l244
  br label %bb101
bb101:
  %t427 = load i1, ptr %l244, !tbaa !21
  br i1 %t427, label %bb102, label %bb103
bb102:
  store i1 true, ptr %l245, !tbaa !21
  br label %bb106
bb103:
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l246, !tbaa !29
  %t429 = load i64, ptr %l38, !tbaa !24
  %t432 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l6, i64 %t429)
  store { i64, ptr } %t432, ptr %l249
  br label %bb104
bb104:
  %t433 = load ptr, ptr %l246, !tbaa !29
  %t434 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t435 = call i1 @compiler_2flsp_2ecompiler_2flsp_3aworker_2eslotPending(ptr %v0, ptr %s0, ptr %t433, { i64, ptr } %t434)
  store i1 %t435, ptr %l250
  br label %bb105
bb105:
  %t436 = load i1, ptr %l250, !tbaa !21
  store i1 %t436, ptr %l245, !tbaa !21
  br label %bb106
bb106:
  %t437 = load i1, ptr %l245, !tbaa !21
  br i1 %t437, label %bb107, label %bb108
bb107:
  call void @__olang_scope_close(ptr %s21)
  br label %bb117
bb108:
  br label %bb109
bb109:
  %t438 = load ptr, ptr %l0, !tbaa !29
  store ptr %t438, ptr %l251, !tbaa !29
  %t439 = load i64, ptr %l38, !tbaa !24
  %t442 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l6, i64 %t439)
  store { i64, ptr } %t442, ptr %l254
  br label %bb110
bb110:
  %t443 = load ptr, ptr %l251, !tbaa !29
  %t444 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t445 = call { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2euriOf(ptr %v0, ptr %s0, ptr %s21, ptr %t443, { i64, ptr } %t444)
  store { i64, ptr } %t445, ptr %l255
  br label %bb111
bb111:
  %t446 = load { i64, ptr }, ptr %l255, !tbaa !27
  store { i64, ptr } %t446, ptr %l39, !tbaa !27
  %t447 = load ptr, ptr %l0, !tbaa !29
  store ptr %t447, ptr %l256, !tbaa !29
  %t448 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t448, ptr %l257, !tbaa !27
  %t449 = load i64, ptr %l38, !tbaa !24
  %t452 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilde_H0e2e3c0fe5ff21020d49b50eb045255d(ptr %s0, ptr %s0, ptr %l7, i64 %t449)
  store %"std/prelude/text:StringBuilder" %t452, ptr %l260
  br label %bb112
bb112:
  %t453 = load %"std/prelude/text:StringBuilder", ptr %l260
  %t454 = call ptr @__olang_scope_alloc_a(ptr %s21, i64 8, i64 8)
  store %"std/prelude/text:StringBuilder" %t453, ptr %t454
  %t456 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s21, ptr %t454)
  store { i64, ptr } %t456, ptr %l262
  br label %bb113
bb113:
  %t457 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t458 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t459 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t459, 1
  %t461 = extractvalue { i64, ptr } %t459, 0
  %t462 = add i64 %t458, %t461
  %t463 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t465 = add i64 %t462, %t464
  %t466 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t465)
  call void @olang_textcopy(ptr %t466, ptr %t457, i64 %t458)
  %t467 = getelementptr i8, ptr %t466, i64 %t458
  call void @olang_textcopy(ptr %t467, ptr %t460, i64 %t461)
  %t468 = getelementptr i8, ptr %t467, i64 %t461
  call void @olang_textcopy(ptr %t468, ptr %t463, i64 %t464)
  %t469 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t466, 1
  %t472 = extractvalue { i64, ptr } %t470, 0
  %t473 = extractvalue { i64, ptr } %t470, 1
  %t474 = mul i64 %t472, 1
  %t475 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t474)
  call void @llvm.memcpy.p0.p0.i64(ptr %t475, ptr %t473, i64 %t474, i1 false)
  %t476 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  %t478 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t480 = call { i64, ptr } @compiler_2flsp_2epublish(ptr %s21, ptr %s21, ptr %s21, { i64, ptr } %t478, { i64, ptr } %t477)
  store { i64, ptr } %t480, ptr %l265
  br label %bb114
bb114:
  %t481 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t481, 0
  %t483 = extractvalue { i64, ptr } %t481, 1
  %t484 = mul i64 %t482, 1
  %t485 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t484)
  call void @llvm.memcpy.p0.p0.i64(ptr %t485, ptr %t483, i64 %t484, i1 false)
  %t486 = insertvalue { i64, ptr } undef, i64 %t482, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t485, 1
  %t488 = load ptr, ptr %l256, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s21, ptr %t488, { i64, ptr } %t487)
  br label %bb115
bb115:
  %t490 = load ptr, ptr %lp26
  %t491 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 1
  %t494 = extractvalue { i64, ptr } %t491, 0
  %t495 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t494)
  call void @olang_textcopy(ptr %t495, ptr %t493, i64 %t494)
  %t496 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t497 = insertvalue { i64, ptr } %t496, ptr %t495, 1
  %t499 = extractvalue { i64, ptr } %t497, 0
  %t500 = extractvalue { i64, ptr } %t497, 1
  %t501 = mul i64 %t499, 1
  %t502 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t501)
  call void @llvm.memcpy.p0.p0.i64(ptr %t502, ptr %t500, i64 %t501, i1 false)
  %t503 = insertvalue { i64, ptr } undef, i64 %t499, 0
  %t504 = insertvalue { i64, ptr } %t503, ptr %t502, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v4, ptr %v4, ptr %t490, { i64, ptr } %t504)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s21)
  br label %bb117
bb117:
  %t507 = load i64, ptr %l37, !tbaa !24
  %t509 = add i64 %t507, 1
  store i64 %t509, ptr %l37, !tbaa !24
  br label %bb96
bb118:
  store ptr %a4, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s27
  %t513 = load ptr, ptr %l40, !tbaa !29
  %t514 = load i64, ptr %l41, !tbaa !24
  %t517 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v3, ptr %t513, i64 %t514)
  %t518 = extractvalue { i32, { i64, ptr } } %t517, 1
  %t519 = extractvalue { i32, { i64, ptr } } %t517, 0
  store i32 %t519, ptr %l278
  %t520 = icmp ne i32 %t519, 0
  br i1 %t520, label %bb121, label %ok.521
ok.521:
  store { i64, ptr } %t518, ptr %l277
  br label %bb120
bb120:
  %t522 = load { i64, ptr }, ptr %l277, !tbaa !27
  store { i64, ptr } %t522, ptr %l274, !tbaa !27
  br label %bb125
bb121:
  %t523 = load i32, ptr %l278, !tbaa !23
  %t524 = ashr i32 %t523, 16
  %t526 = icmp eq i32 %t524, 1
  br i1 %t526, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_check_failed(ptr @olang_loc_e34d33a8199c916a_aaf0de3edf4986c6)
  unreachable
bb124:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s27)
  br label %bb139
bb125:
  %t528 = load { i64, ptr }, ptr %l274, !tbaa !27
  store { i64, ptr } %t528, ptr %l42, !tbaa !27
  %t529 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t531 = extractvalue { i64, ptr } %t529, 0
  store i64 %t531, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb126
bb126:
  store %olang.scope zeroinitializer, ptr %s28
  %t533 = load i64, ptr %l44, !tbaa !24
  %t534 = load i64, ptr %l43, !tbaa !24
  %t537 = icmp slt i64 %t533, %t534
  %t539 = xor i1 %t537, true
  br i1 %t539, label %bb127, label %bb128
bb127:
  call void @__olang_scope_close(ptr %s28)
  br label %bb137
bb128:
  br label %bb129
bb129:
  %t541 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t541, ptr %l287, !tbaa !27
  %t542 = load i64, ptr %l44, !tbaa !24
  %t544 = getelementptr { i64, ptr }, ptr %l287, i32 0, i32 1
  %t545 = load ptr, ptr %t544, !tbaa !27
  %t546 = getelementptr { i64, ptr }, ptr %t545, i64 %t542
  %t547 = load { i64, ptr }, ptr %t546, !tbaa !37
  store { i64, ptr } %t547, ptr %l45, !tbaa !27
  %t549 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t551 = load ptr, ptr %lp26
  %t555 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v4, ptr %v3, ptr %t551, { i64, ptr } %t549)
  store i1 %t555, ptr %l293
  br label %bb130
bb130:
  %t556 = load i1, ptr %l293, !tbaa !21
  %t557 = xor i1 %t556, true
  br i1 %t557, label %bb131, label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s29
  %t559 = load ptr, ptr %l0, !tbaa !29
  store ptr %t559, ptr %l295, !tbaa !29
  %t560 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t562 = call { i64, ptr } @compiler_2flsp_2epublish(ptr %v3, ptr %s29, ptr %s29, { i64, ptr } %t560, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d122, i32 0, i32 1) })
  store { i64, ptr } %t562, ptr %l297
  br label %bb133
bb132:
  br label %bb135
bb133:
  %t563 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t564 = extractvalue { i64, ptr } %t563, 0
  %t565 = extractvalue { i64, ptr } %t563, 1
  %t566 = mul i64 %t564, 1
  %t567 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t566)
  call void @llvm.memcpy.p0.p0.i64(ptr %t567, ptr %t565, i64 %t566, i1 false)
  %t568 = insertvalue { i64, ptr } undef, i64 %t564, 0
  %t569 = insertvalue { i64, ptr } %t568, ptr %t567, 1
  %t570 = load ptr, ptr %l295, !tbaa !29
  call void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %s29, ptr %t570, { i64, ptr } %t569)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s29)
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s28)
  br label %bb136
bb136:
  %t572 = load i64, ptr %l44, !tbaa !24
  %t574 = add i64 %t572, 1
  store i64 %t574, ptr %l44, !tbaa !24
  br label %bb126
bb137:
  %t576 = load i64, ptr %l41, !tbaa !24
  %t577 = load i64, ptr %l43, !tbaa !24
  %t580 = add i64 %t576, %t577
  store i64 %t580, ptr %l41, !tbaa !24
  call void @__olang_scope_close(ptr %s27)
  br label %bb138
bb138:
  br label %bb119
bb139:
  %t582 = load ptr, ptr %lp26
  %t583 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t582
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t583, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2erangeOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca i64
  %l17 = alloca i64
  %l25 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Item", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store ptr %a2, ptr %l8, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/diag:Item", ptr %t10, i32 0, i32 3
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = getelementptr %"compiler/diag:Item", ptr %t14, i32 0, i32 4
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/diag:Item", ptr %t18, i32 0, i32 3
  %t21 = load i64, ptr %t20, !tbaa !24
  %t24 = icmp sgt i64 %t17, %t21
  br i1 %t24, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/diag:Item", ptr %t26, i32 0, i32 4
  %t29 = load i64, ptr %t28, !tbaa !24
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/diag:Item", ptr %t31, i32 0, i32 3
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l8, !tbaa !29
  %t37 = load ptr, ptr %l9, !tbaa !29
  %t38 = load i64, ptr %l11, !tbaa !24
  %t39 = load i64, ptr %l17, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %v2, ptr %v1, ptr %t36, ptr %t37, i64 %t38, i64 %t39)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"compiler/diag:Item", ptr %t40, i32 0, i32 5
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = getelementptr %"compiler/diag:Item", ptr %t47, i32 0, i32 5
  %t50 = load i64, ptr %t49, !tbaa !24
  %t52 = sub i64 %t50, 1
  store i64 %t52, ptr %l25, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l25, !tbaa !24
  store i64 %t54, ptr %l4, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t56 = load i64, ptr %l4, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t58 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t61 = call i64 @__olang_fmt_i64(ptr null, i64 %t56)
  %t62 = add i64 %t59, %t61
  %t63 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t67 = call i64 @__olang_fmt_i64(ptr null, i64 %t57)
  %t68 = add i64 %t65, %t67
  %t69 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t71 = add i64 %t68, %t70
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t58, i64 %t59)
  %t73 = getelementptr i8, ptr %t72, i64 %t59
  %t74 = call i64 @__olang_fmt_i64(ptr %t73, i64 %t56)
  %t75 = getelementptr i8, ptr %t73, i64 %t61
  call void @olang_textcopy(ptr %t75, ptr %t63, i64 %t64)
  %t76 = getelementptr i8, ptr %t75, i64 %t64
  %t77 = call i64 @__olang_fmt_i64(ptr %t76, i64 %t57)
  %t78 = getelementptr i8, ptr %t76, i64 %t67
  call void @olang_textcopy(ptr %t78, ptr %t69, i64 %t70)
  %t79 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t72, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = extractvalue { i64, ptr } %t80, 1
  %t84 = mul i64 %t82, 1
  %t85 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t84)
  call void @llvm.memcpy.p0.p0.i64(ptr %t85, ptr %t83, i64 %t84, i1 false)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t55, { i64, ptr } %t87)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2flsp_2ecompiler_2flsp_3aworker_2esend(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lsp:worker", ptr %a0, i32 0, i32 3
  %t4 = load i32, ptr %t3, !tbaa !23
  call void @compiler_2fsession_2eWriteFramed(ptr %v1, i32 %t4, { i64, ptr } %a1)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2flsp_2ecompiler_2flsp_3aworker_2eslotPending(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i64
  %l20 = alloca ptr
  %l24 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/lsp:worker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lsp:Server", ptr %t4, i32 0, i32 4
  store ptr %t6, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l15
  br label %bb6
bb6:
  %t23 = load i64, ptr %l15, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/lsp:worker", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/lsp:Server", ptr %t27, i32 0, i32 1
  %t33 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v0, ptr %t29, i64 %t23)
  store ptr %t33, ptr %l20
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t36 = getelementptr %"compiler/lsp:Doc", ptr %t34, i32 0, i32 2
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t37, { i64, ptr } %a1)
  store i1 %t41, ptr %l24
  br label %bb8
bb8:
  %t42 = load i1, ptr %l24, !tbaa !21
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l3, !tbaa !24
  br label %bb1
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2etextOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca i1
  %l18 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/lsp:worker", ptr %a0, i32 0, i32 4
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v2, ptr %v0, ptr %t3, { i64, ptr } %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l9
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t12, ptr %l5, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d126, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t13, ptr %l3, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t14, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d127, i32 0, i32 1) })
  store i1 %t16, ptr %l12
  br label %bb5
bb5:
  %t17 = load i1, ptr %l12, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = extractvalue { i64, ptr } %t20, 0
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t22, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t32 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v1, ptr %v2, ptr %t28, { i64, ptr } %t29)
  store i64 %t32, ptr %l18
  br label %bb9
bb9:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp sge i64 %t34, 0
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v1, ptr %t38, i64 %t39)
  store { i64, ptr } %t42, ptr %l24
  br label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t43, ptr %l21, !tbaa !27
  br label %bb13
bb12:
  %t45 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l21, !tbaa !27
  br label %bb13
bb13:
  %t52 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l28, !tbaa !24
  %t54 = load i64, ptr %l28, !tbaa !24
  %t55 = mul i64 %t54, 1
  %t56 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l29, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l28, !tbaa !24
  %t64 = mul i64 %t63, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t60, ptr %t62, i64 %t64, i1 false)
  %t65 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t65, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t66 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t66, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2ecompiler_2flsp_3aworker_2euriOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l24 = alloca { i64, ptr }
  %l29 = alloca i1
  %l33 = alloca i1
  %l43 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/lsp:worker", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/lsp:Server", ptr %t4, i32 0, i32 1
  store ptr %t6, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = load i64, ptr %l3, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_Hc8f637dbd3c39b4e5f02c4f7fcfa329b(ptr %v0, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l15
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l14
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  br label %bb7
bb3:
  %t18 = load i32, ptr %l15, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_7cd8b38167923161_43fbbad0bd403bed)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb7:
  %t23 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t36, ptr %l24, !tbaa !27
  %t37 = load i64, ptr %l6, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 %t37
  %t42 = load ptr, ptr %t41, !tbaa !39
  store ptr %t42, ptr %l7, !tbaa !29
  %t44 = load ptr, ptr %l7, !tbaa !29
  %t46 = getelementptr %"compiler/lsp:Doc", ptr %t44, i32 0, i32 4
  %t47 = load i1, ptr %t46, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l7, !tbaa !29
  %t51 = getelementptr %"compiler/lsp:Doc", ptr %t49, i32 0, i32 2
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t56 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t52, { i64, ptr } %t53)
  store i1 %t56, ptr %l33
  br label %bb14
bb13:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb15
bb14:
  %t57 = load i1, ptr %l33, !tbaa !21
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  %t58 = load i1, ptr %l29, !tbaa !21
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l7, !tbaa !29
  %t61 = getelementptr %"compiler/lsp:Doc", ptr %t59, i32 0, i32 0
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = extractvalue { i64, ptr } %t62, 0
  %t66 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t65)
  call void @olang_textcopy(ptr %t66, ptr %t64, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t68, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t70 = load i64, ptr %l6, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l6, !tbaa !24
  br label %bb8
bb20:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t75 = load i64, ptr %l5, !tbaa !24
  %t78 = add i64 %t74, %t75
  store i64 %t78, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb1
bb22:
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t82 = call { i64, ptr } @compiler_2flsp_2eUriOf(ptr %v1, ptr %v2, { i64, ptr } %t80)
  store { i64, ptr } %t82, ptr %l43
  br label %bb23
bb23:
  %t83 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t83, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2eerrorReply(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t8 = extractvalue { i64, ptr } %a0, 1
  %t9 = extractvalue { i64, ptr } %a0, 0
  %t10 = add i64 %t6, %t9
  %t11 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t16 = add i64 %t13, %t15
  %t17 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t5, i64 %t6)
  %t21 = getelementptr i8, ptr %t20, i64 %t6
  call void @olang_textcopy(ptr %t21, ptr %t8, i64 %t9)
  %t22 = getelementptr i8, ptr %t21, i64 %t9
  call void @olang_textcopy(ptr %t22, ptr %t11, i64 %t12)
  %t23 = getelementptr i8, ptr %t22, i64 %t12
  %t24 = call i64 @__olang_fmt_i64(ptr %t23, i64 %a1)
  %t25 = getelementptr i8, ptr %t23, i64 %t15
  call void @olang_textcopy(ptr %t25, ptr %t17, i64 %t18)
  %t26 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t20, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t34)
  br label %bb2
bb2:
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v1, ptr %l3, { i64, ptr } %a2)
  br label %bb3
bb3:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d132, i32 0, i32 1) })
  br label %bb4
bb4:
  %t42 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t42, ptr %l14
  br label %bb5
bb5:
  %t43 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t43, ptr %l15, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l16, !tbaa !24
  %t46 = load i64, ptr %l16, !tbaa !24
  %t47 = mul i64 %t46, 1
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l17, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l16, !tbaa !24
  %t56 = mul i64 %t55, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t52, ptr %t54, i64 %t56, i1 false)
  %t57 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t57, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2eframed(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t8 = call i64 @__olang_fmt_i64(ptr null, i64 %t3)
  %t9 = add i64 %t6, %t8
  %t10 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = extractvalue { i64, ptr } %t4, 1
  %t15 = extractvalue { i64, ptr } %t4, 0
  %t16 = add i64 %t12, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t5, i64 %t6)
  %t18 = getelementptr i8, ptr %t17, i64 %t6
  %t19 = call i64 @__olang_fmt_i64(ptr %t18, i64 %t3)
  %t20 = getelementptr i8, ptr %t18, i64 %t8
  call void @olang_textcopy(ptr %t20, ptr %t10, i64 %t11)
  %t21 = getelementptr i8, ptr %t20, i64 %t11
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t17, 1
  store { i64, ptr } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2flsp_2eframes(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i32
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca i64
  %l49 = alloca i32
  %l57 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l60 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l70 = alloca { i64, ptr }
  %l74 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %t3
  store ptr %t3, ptr %l1, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l9, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t6, 0
  store i64 %t9, ptr %l12, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l13, !tbaa !24
  %t12 = icmp sge i64 0, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = icmp sle i64 0, %t14
  br i1 %t15, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_f3afb7cdea72bea9_2e903794abb886a5)
  unreachable
bb4:
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = load i64, ptr %l13, !tbaa !24
  %t19 = icmp sle i64 %t17, %t18
  br i1 %t19, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f3afb7cdea72bea9_2e903794abb886a5)
  unreachable
bb6:
  %t21 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l12, !tbaa !24
  %t24 = getelementptr i8, ptr %t22, i64 0
  %t25 = sub i64 %t23, 0
  %t26 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t24, 1
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f3afb7cdea72bea9_2e903794abb886a5)
  unreachable
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t31 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s1, { i64, ptr } %t29, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d135, i32 0, i32 1) })
  %t32 = extractvalue { i32, i64 } %t31, 1
  %t33 = extractvalue { i32, i64 } %t31, 0
  store i32 %t33, ptr %l21
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb10, label %ok.35
ok.35:
  store i64 %t32, ptr %l20
  br label %bb9
bb9:
  %t36 = load i64, ptr %l20, !tbaa !24
  store i64 %t36, ptr %l18, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s1)
  br label %bb53
bb12:
  %t37 = load i64, ptr %l18, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  %t41 = add i64 %t37, 16
  store i64 %t41, ptr %l24, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t42, 0
  store i64 %t45, ptr %l27, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l28, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = icmp sge i64 %t48, 0
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load i64, ptr %l24, !tbaa !24
  %t52 = load i64, ptr %l27, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8c5172bb8ea5e6bc_75de6e53c7815648)
  unreachable
bb15:
  %t55 = load i64, ptr %l27, !tbaa !24
  %t56 = load i64, ptr %l28, !tbaa !24
  %t57 = icmp sle i64 %t55, %t56
  br i1 %t57, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8c5172bb8ea5e6bc_75de6e53c7815648)
  unreachable
bb17:
  %t59 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l24, !tbaa !24
  %t62 = load i64, ptr %l27, !tbaa !24
  %t63 = getelementptr i8, ptr %t60, i64 %t61
  %t64 = sub i64 %t62, %t61
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l4, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t70 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s1, { i64, ptr } %t68, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d136, i32 0, i32 1) })
  %t71 = extractvalue { i32, i64 } %t70, 1
  %t72 = extractvalue { i32, i64 } %t70, 0
  store i32 %t72, ptr %l36
  %t73 = icmp ne i32 %t72, 0
  br i1 %t73, label %bb20, label %ok.74
ok.74:
  store i64 %t71, ptr %l35
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8c5172bb8ea5e6bc_75de6e53c7815648)
  unreachable
bb19:
  %t75 = load i64, ptr %l35, !tbaa !24
  store i64 %t75, ptr %l33, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s1)
  br label %bb53
bb22:
  %t76 = load i64, ptr %l33, !tbaa !24
  store i64 %t76, ptr %l5, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t77, ptr %l38, !tbaa !27
  %t78 = load i64, ptr %l5, !tbaa !24
  store i64 %t78, ptr %l39, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l40, !tbaa !24
  %t81 = icmp sge i64 0, 0
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t83 = load i64, ptr %l39, !tbaa !24
  %t84 = icmp sle i64 0, %t83
  br i1 %t84, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_6f843a9f898efe67_8723688731f48c63)
  unreachable
bb25:
  %t86 = load i64, ptr %l39, !tbaa !24
  %t87 = load i64, ptr %l40, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_6f843a9f898efe67_8723688731f48c63)
  unreachable
bb27:
  %t90 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = load i64, ptr %l39, !tbaa !24
  %t93 = getelementptr i8, ptr %t91, i64 0
  %t94 = sub i64 %t92, 0
  %t95 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t93, 1
  %t98 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t96)
  store { i64, ptr } %t98, ptr %l45
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_6f843a9f898efe67_8723688731f48c63)
  unreachable
bb29:
  %t99 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s1, i64 10)
  %t100 = extractvalue { i32, i64 } %t99, 1
  %t101 = extractvalue { i32, i64 } %t99, 0
  store i32 %t101, ptr %l47
  %t102 = icmp ne i32 %t101, 0
  br i1 %t102, label %bb31, label %ok.103
ok.103:
  store i64 %t100, ptr %l46
  br label %bb30
bb30:
  %t104 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t105 = load i64, ptr %l46, !tbaa !24
  %t106 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t104, i64 %t105)
  %t107 = extractvalue { i32, i64 } %t106, 1
  %t108 = extractvalue { i32, i64 } %t106, 0
  store i32 %t108, ptr %l49
  %t109 = icmp ne i32 %t108, 0
  br i1 %t109, label %bb34, label %ok.110
ok.110:
  store i64 %t107, ptr %l48
  br label %bb33
bb31:
  br label %bb32
bb32:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s1)
  br label %bb53
bb33:
  %t111 = load i64, ptr %l48, !tbaa !24
  store i64 %t111, ptr %l37, !tbaa !24
  br label %bb35
bb34:
  br label %bb32
bb35:
  %t112 = load i64, ptr %l37, !tbaa !24
  store i64 %t112, ptr %l6, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = load i64, ptr %l5, !tbaa !24
  %t118 = add i64 %t116, 4
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t125 = icmp slt i64 %t115, %t122
  br i1 %t125, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s1)
  br label %bb53
bb37:
  br label %bb38
bb38:
  %t127 = load ptr, ptr %l1, !tbaa !29
  store ptr %t127, ptr %l57, !tbaa !29
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l58, !tbaa !27
  %t129 = load i64, ptr %l5, !tbaa !24
  %t131 = add i64 %t129, 4
  store i64 %t131, ptr %l60, !tbaa !24
  %t132 = load i64, ptr %l5, !tbaa !24
  %t134 = add i64 %t132, 4
  %t135 = load i64, ptr %l6, !tbaa !24
  %t138 = add i64 %t134, %t135
  store i64 %t138, ptr %l64, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l65, !tbaa !24
  %t141 = load i64, ptr %l60, !tbaa !24
  %t142 = icmp sge i64 %t141, 0
  br i1 %t142, label %bb39, label %bb40
bb39:
  %t144 = load i64, ptr %l60, !tbaa !24
  %t145 = load i64, ptr %l64, !tbaa !24
  %t146 = icmp sle i64 %t144, %t145
  br i1 %t146, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_8f54b2067e6b6b8a_86cbf1b666cce186)
  unreachable
bb41:
  %t148 = load i64, ptr %l64, !tbaa !24
  %t149 = load i64, ptr %l65, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_8f54b2067e6b6b8a_86cbf1b666cce186)
  unreachable
bb43:
  %t152 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l60, !tbaa !24
  %t155 = load i64, ptr %l64, !tbaa !24
  %t156 = getelementptr i8, ptr %t153, i64 %t154
  %t157 = sub i64 %t155, %t154
  %t158 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  %t160 = load ptr, ptr %l57, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t160, { i64, ptr } %t159)
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_8f54b2067e6b6b8a_86cbf1b666cce186)
  unreachable
bb45:
  %t162 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t162, ptr %l70, !tbaa !27
  %t163 = load i64, ptr %l5, !tbaa !24
  %t165 = add i64 %t163, 4
  %t166 = load i64, ptr %l6, !tbaa !24
  %t169 = add i64 %t165, %t166
  store i64 %t169, ptr %l74, !tbaa !24
  %t170 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t170, 0
  store i64 %t173, ptr %l77, !tbaa !24
  %t174 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t174, 0
  store i64 %t175, ptr %l78, !tbaa !24
  %t176 = load i64, ptr %l74, !tbaa !24
  %t177 = icmp sge i64 %t176, 0
  br i1 %t177, label %bb46, label %bb47
bb46:
  %t179 = load i64, ptr %l74, !tbaa !24
  %t180 = load i64, ptr %l77, !tbaa !24
  %t181 = icmp sle i64 %t179, %t180
  br i1 %t181, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_c8d49224b0a3e505_8d1f0d35a00e1b49)
  unreachable
bb48:
  %t183 = load i64, ptr %l77, !tbaa !24
  %t184 = load i64, ptr %l78, !tbaa !24
  %t185 = icmp sle i64 %t183, %t184
  br i1 %t185, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_c8d49224b0a3e505_8d1f0d35a00e1b49)
  unreachable
bb50:
  %t187 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = load i64, ptr %l74, !tbaa !24
  %t190 = load i64, ptr %l77, !tbaa !24
  %t191 = getelementptr i8, ptr %t188, i64 %t189
  %t192 = sub i64 %t190, %t189
  %t193 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t191, 1
  store { i64, ptr } %t194, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_c8d49224b0a3e505_8d1f0d35a00e1b49)
  unreachable
bb52:
  br label %bb8
bb53:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2eidOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d137, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %a0, { i64, ptr } %t2)
  %t6 = extractvalue { i32, ptr } %t5, 1
  %t7 = extractvalue { i32, ptr } %t5, 0
  store i32 %t7, ptr %l7
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store ptr %t6, ptr %l6
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  br label %bb6
bb2:
  %t11 = load i32, ptr %l7, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_3745daa1275561cc_12cd1f9b9ff8c2e8)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d138, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l12, !tbaa !24
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l13, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l12, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t30, ptr %l11, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb6:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %v1, ptr %v1, ptr %t32, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d139, i32 0, i32 1) })
  store { i64, ptr } %t35, ptr %l15
  br label %bb7
bb7:
  %t36 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t36, ptr %l16, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l17, !tbaa !24
  %t39 = load i64, ptr %l17, !tbaa !24
  %t40 = mul i64 %t39, 1
  %t41 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l18, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l17, !tbaa !24
  %t49 = mul i64 %t48, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t50, ptr %l16, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2elostDiagnostic(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l2
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 89, ptr getelementptr inbounds (<{ i64, [89 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t18)
  br label %bb2
bb2:
  %t22 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t25 = extractvalue { i64, ptr } %a0, 1
  %t26 = extractvalue { i64, ptr } %a0, 0
  %t27 = add i64 %t23, %t26
  %t28 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = getelementptr i8, ptr %t31, i64 %t23
  call void @olang_textcopy(ptr %t32, ptr %t25, i64 %t26)
  %t33 = getelementptr i8, ptr %t32, i64 %t26
  call void @olang_textcopy(ptr %t33, ptr %t28, i64 %t29)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t31, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } %t35, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t42)
  br label %bb3
bb3:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d144, i32 0, i32 1) })
  br label %bb4
bb4:
  %t47 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t47, ptr %l12
  br label %bb5
bb5:
  %t48 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t48, ptr %l13, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l14, !tbaa !24
  %t51 = load i64, ptr %l14, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l15, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l14, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t62, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t63 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t63, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2epublish(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d145, i32 0, i32 1) })
  br label %bb2
bb2:
  call void @compiler_2fsession_2eJsonStr(ptr %s0, ptr %v0, ptr %l2, { i64, ptr } %a0)
  br label %bb3
bb3:
  %t8 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t8, i64 %t9)
  %t18 = getelementptr i8, ptr %t17, i64 %t9
  call void @olang_textcopy(ptr %t18, ptr %t11, i64 %t12)
  %t19 = getelementptr i8, ptr %t18, i64 %t12
  call void @olang_textcopy(ptr %t19, ptr %t14, i64 %t15)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t17, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } %t28)
  br label %bb4
bb4:
  %t32 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t32, ptr %l12
  br label %bb5
bb5:
  %t33 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t33, ptr %l13, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l14, !tbaa !24
  %t36 = load i64, ptr %l14, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l15, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t47, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t48 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2ereply(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t6 = extractvalue { i64, ptr } %a0, 1
  %t7 = extractvalue { i64, ptr } %a0, 0
  %t8 = add i64 %t4, %t7
  %t9 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t11 = add i64 %t8, %t10
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t3, i64 %t4)
  %t20 = getelementptr i8, ptr %t19, i64 %t4
  call void @olang_textcopy(ptr %t20, ptr %t6, i64 %t7)
  %t21 = getelementptr i8, ptr %t20, i64 %t7
  call void @olang_textcopy(ptr %t21, ptr %t9, i64 %t10)
  %t22 = getelementptr i8, ptr %t21, i64 %t10
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t19, 1
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2flsp_2estr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  %t6 = extractvalue { i32, ptr } %t5, 1
  %t7 = extractvalue { i32, ptr } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store ptr %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %t10)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l10
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb7, label %ok.15
ok.15:
  store { i64, ptr } %t12, ptr %l9
  br label %bb6
bb2:
  %t16 = load i32, ptr %l6, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_898f47ed6de9d529_f325535f3a937a9d)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d151, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb10
bb6:
  %t21 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t21, ptr %l2, !tbaa !27
  br label %bb10
bb7:
  %t22 = load i32, ptr %l10, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  br i1 %t25, label %bb8, label %bb9
bb8:
  br label %bb5
bb9:
  call void @__olang_check_failed(ptr @olang_loc_898f47ed6de9d529_f325535f3a937a9d)
  unreachable
bb10:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/lsp:Doc" @compiler_2flsp_3aDoc_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i1
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lsp:Doc"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l3, !tbaa !27
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  %t7 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v3)
  store %"std/prelude/text:StringBuilder" %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load %"std/prelude/text:StringBuilder", ptr %l13
  store %"std/prelude/text:StringBuilder" %t8, ptr %l6
  store i1 true, ptr %l7, !tbaa !21
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l8
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l15
  br label %bb3
bb3:
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = insertvalue %"compiler/lsp:Doc" undef, { i64, ptr } %t13, 0
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = insertvalue %"compiler/lsp:Doc" %t14, { i64, ptr } %t15, 1
  %t17 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t18 = insertvalue %"compiler/lsp:Doc" %t16, { i64, ptr } %t17, 2
  %t19 = load %"std/prelude/text:StringBuilder", ptr %l6
  %t20 = insertvalue %"compiler/lsp:Doc" %t18, %"std/prelude/text:StringBuilder" %t19, 3
  %t21 = load i1, ptr %l7, !tbaa !21
  %t22 = insertvalue %"compiler/lsp:Doc" %t20, i1 %t21, 4
  %t23 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t24 = insertvalue %"compiler/lsp:Doc" %t22, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, 5
  %t26 = insertvalue %"compiler/lsp:Doc" %t24, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, 6
  store %"compiler/lsp:Doc" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lsp:Doc", ptr %rv
  ret %"compiler/lsp:Doc" %rr
}

define dso_local %"compiler/lsp:Server" @compiler_2flsp_3aServer_2ector(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i1
  %l4 = alloca %"compiler/lsp:Worker"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"compiler/lsp:Worker"
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lsp:Server"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  store i1 false, ptr %l3, !tbaa !21
  %t5 = call %"compiler/lsp:Worker" @compiler_2flsp_3aWorker_2ector(ptr %v1)
  store %"compiler/lsp:Worker" %t5, ptr %l12
  br label %bb2
bb2:
  %t6 = load %"compiler/lsp:Worker", ptr %l12
  store %"compiler/lsp:Worker" %t6, ptr %l4
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l13
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l5
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l14
  br label %bb4
bb4:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t12 = insertvalue %"compiler/lsp:Server" undef, ptr %t11, 0
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t14 = insertvalue %"compiler/lsp:Server" %t12, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, 1
  %t15 = load i1, ptr %l3, !tbaa !21
  %t16 = insertvalue %"compiler/lsp:Server" %t14, i1 %t15, 2
  %t17 = load %"compiler/lsp:Worker", ptr %l4
  %t18 = insertvalue %"compiler/lsp:Server" %t16, %"compiler/lsp:Worker" %t17, 3
  %t19 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t20 = insertvalue %"compiler/lsp:Server" %t18, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, 4
  %t22 = insertvalue %"compiler/lsp:Server" %t20, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, 5
  %t24 = insertvalue %"compiler/lsp:Server" %t22, i64 0, 6
  %t26 = insertvalue %"compiler/lsp:Server" %t24, i1 false, 7
  %t28 = insertvalue %"compiler/lsp:Server" %t26, i1 false, 8
  store %"compiler/lsp:Server" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lsp:Server", ptr %rv
  ret %"compiler/lsp:Server" %rr
}

define dso_local %"compiler/lsp:Worker" @compiler_2flsp_3aWorker_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/lsp:Worker"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/lsp:Worker" undef, i32 -1, 0
  %t4 = insertvalue %"compiler/lsp:Worker" %t2, i32 -1, 1
  %t6 = insertvalue %"compiler/lsp:Worker" %t4, ptr null, 2
  %t8 = insertvalue %"compiler/lsp:Worker" %t6, i64 0, 3
  store %"compiler/lsp:Worker" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lsp:Worker", ptr %rv
  ret %"compiler/lsp:Worker" %rr
}

define dso_local %"compiler/lsp:worker" @compiler_2flsp_3aworker_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l15 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/lsp:worker"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l4, !tbaa !29
  store ptr %a1, ptr %l5, !tbaa !29
  store i32 %a2, ptr %l6, !tbaa !23
  store i32 %a3, ptr %l7, !tbaa !23
  %t9 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v2)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l15
  br label %bb1
bb1:
  %t10 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t12 = insertvalue %"compiler/lsp:worker" undef, ptr %t11, 0
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t14 = insertvalue %"compiler/lsp:worker" %t12, ptr %t13, 1
  %t15 = load i32, ptr %l6, !tbaa !23
  %t16 = insertvalue %"compiler/lsp:worker" %t14, i32 %t15, 2
  %t17 = load i32, ptr %l7, !tbaa !23
  %t18 = insertvalue %"compiler/lsp:worker" %t16, i32 %t17, 3
  %t20 = insertvalue %"compiler/lsp:worker" %t18, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, 4
  %t22 = insertvalue %"compiler/lsp:worker" %t20, ptr null, 5
  %t24 = insertvalue %"compiler/lsp:worker" %t22, i64 -1, 6
  store %"compiler/lsp:worker" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/lsp:worker", ptr %rv
  ret %"compiler/lsp:worker" %rr
}

define dso_local void @olang_2einit_2ecompiler_2flsp() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2flsp_2eSettleNs_2einit()
  br label %bb1
bb1:
  call void @compiler_2flsp_2eStuckNs_2einit()
  br label %bb2
bb2:
  call void @compiler_2flsp_2eRequests_2einit()
  br label %bb3
bb3:
  call void @compiler_2flsp_2eSessionSrc_2einit()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"file://" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"textDocument/hover" }>, align 8
@.d2 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"textDocument/definition" }>, align 8
@.d3 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"textDocument/documentSymbol" }>, align 8
@.d4 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"textDocument/completion" }>, align 8
@.d5 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"textDocument/formatting" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d6 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"checking took more than a minute - it was stopped" }>, align 8
@.d7 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"import \22std/io\22\0A\0A# a point on a plane\0Atype Point struct(X I64, Y I64) {\0A    X\0A    Y\0A}\0A\0A" }>, align 8
@.d8 = private constant <{ i64, [79 x i8] }> <{ i64 0, [79 x i8] c"# the sum of a point's coordinates\0Afn sum(p Point) I64 {\0A    return p.X+p.Y\0A}\0A\0A" }>, align 8
@.d9 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c"fn main() {\0A    q := Point(1, 2)\0A    io.Println($sum(q))!\0A    bad I32 = \22x\22\0A}\0A" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d10 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"file://" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d12 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"OLANG" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"build/olang" }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d18 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d19 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"checking took more than a minute - it was stopped" }>, align 8
@.d20 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"the compiler ended while checking this file" }>, align 8
@.d21 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"the compiler ended (" }>, align 8
@.d22 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c") while checking this file" }>, align 8
@.d23 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"{\22olang\22:" }>, align 8
@.d24 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"{\22jsonrpc\22:\222.0\22,\22id\22:" }>, align 8
@.d25 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d26 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"the message is not JSON" }>, align 8
@.d27 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"method" }>, align 8
@.d28 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"initialize" }>, align 8
@.d29 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"initialized" }>, align 8
@.d30 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"$/cancelRequest" }>, align 8
@.d31 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"$/setTrace" }>, align 8
@.d32 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"textDocument/didSave" }>, align 8
@.d33 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"shutdown" }>, align 8
@.d34 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"exit" }>, align 8
@.d36 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"textDocument/didOpen" }>, align 8
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d38 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"textDocument" }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"uri" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d41 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"textDocument/didChange" }>, align 8
@.d42 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d43 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"textDocument" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"uri" }>, align 8
@.d45 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"contentChanges" }>, align 8
@.d46 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d47 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"textDocument/didClose" }>, align 8
@.d48 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d49 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"textDocument" }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"uri" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"olang lsp has no " }>, align 8
@.d53 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d54 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"capabilities" }>, align 8
@.d55 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"general" }>, align 8
@.d56 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"positionEncodings" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"utf-8" }>, align 8
@.d59 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"utf-8" }>, align 8
@.d60 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"utf-16" }>, align 8
@.d61 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"{\22positionEncoding\22:\22" }>, align 8
@.d62 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"\22,\22textDocumentSync\22:{\22openClose\22:true," }>, align 8
@.d63 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c"\22change\22:1},\22hoverProvider\22:true,\22definitionProvider\22:true,\22documentSymbolProvider\22:true," }>, align 8
@.d64 = private constant <{ i64, [83 x i8] }> <{ i64 0, [83 x i8] c"\22completionProvider\22:{\22triggerCharacters\22:[\22.\22]},\22documentFormattingProvider\22:true}" }>, align 8
@.d65 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"{\22capabilities\22:" }>, align 8
@.d66 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c",\22serverInfo\22:{\22name\22:\22olang\22}}" }>, align 8
@.d67 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"slot" }>, align 8
@.d68 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"deps" }>, align 8
@.d69 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"foreign" }>, align 8
@.d70 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d71 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"the files changed" }>, align 8
@.d72 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d73 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"method" }>, align 8
@.d74 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"params" }>, align 8
@.d75 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d76 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"textDocument" }>, align 8
@.d77 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"uri" }>, align 8
@.d78 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d80 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"position" }>, align 8
@.d81 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"line" }>, align 8
@.d82 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"position" }>, align 8
@.d83 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"character" }>, align 8
@.d84 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"textDocument/formatting" }>, align 8
@.d85 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d86 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d87 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"[{\22range\22:" }>, align 8
@.d88 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22newText\22:" }>, align 8
@.d89 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}]" }>, align 8
@.d90 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"textDocument/completion" }>, align 8
@.d91 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"textDocument/documentSymbol" }>, align 8
@.d92 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d93 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d94 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"textDocument/hover" }>, align 8
@.d95 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"{\22contents\22:{\22kind\22:\22markdown\22,\22value\22:" }>, align 8
@.d96 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}}" }>, align 8
@.d97 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d98 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d99 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"{\22uri\22:" }>, align 8
@.d100 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c",\22range\22:" }>, align 8
@.d101 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"{\22olang\22:\22checked\22,\22slot\22:" }>, align 8
@.d102 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c",\22deps\22:[" }>, align 8
@.d103 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"],\22foreign\22:[" }>, align 8
@.d104 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@.d105 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"{\22isIncomplete\22:false,\22items\22:[" }>, align 8
@.d106 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@.d107 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"{\22range\22:" }>, align 8
@.d108 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c",\22severity\22:1,\22source\22:\22olang\22" }>, align 8
@.d109 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d110 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c",\22code\22:" }>, align 8
@.d111 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22message\22:" }>, align 8
@.d112 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"{\22location\22:{\22uri\22:" }>, align 8
@.d113 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c",\22range\22:" }>, align 8
@.d114 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"},\22message\22:" }>, align 8
@.d115 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c",\22relatedInformation\22:[" }>, align 8
@.d116 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilder_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilder_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d117 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d118 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d120 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d121 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d122 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d123 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"{\22start\22:{\22line\22:" }>, align 8
@.d124 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c",\22character\22:0},\22end\22:{\22line\22:" }>, align 8
@.d125 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c",\22character\22:0}}" }>, align 8
@.d126 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d127 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d128 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d129 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"{\22jsonrpc\22:\222.0\22,\22id\22:" }>, align 8
@.d130 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c",\22error\22:{\22code\22:" }>, align 8
@.d131 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c",\22message\22:" }>, align 8
@.d132 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}}" }>, align 8
@.d133 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"Content-Length: " }>, align 8
@.d134 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\0D\0A\0D\0A" }>, align 8
@.d135 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"Content-Length: " }>, align 8
@.d136 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\0D\0A\0D\0A" }>, align 8
@.d137 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"id" }>, align 8
@.d138 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d139 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d140 = private constant <{ i64, [89 x i8] }> <{ i64 0, [89 x i8] c"[{\22range\22:{\22start\22:{\22line\22:0,\22character\22:0},\22end\22:{\22line\22:0,\22character\22:0}},\22severity\22:1," }>, align 8
@.d141 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"\22source\22:\22olang\22,\22message\22:" }>, align 8
@.d142 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d143 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c" - a bug in the compiler, not in the program" }>, align 8
@.d144 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}]" }>, align 8
@.d145 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c"{\22jsonrpc\22:\222.0\22,\22method\22:\22textDocument/publishDiagnostics\22,\22params\22:{\22uri\22:" }>, align 8
@.d146 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c",\22diagnostics\22:" }>, align 8
@.d147 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}}" }>, align 8
@.d148 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"{\22jsonrpc\22:\222.0\22,\22id\22:" }>, align 8
@.d149 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22result\22:" }>, align 8
@.d150 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d151 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_Hf48d6d4096e547b8075d5a903caa3d54(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_6756d46c47226ab9_ec8477bb3ab165 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
@olang_loc_78ef8a2f2ef3c68c_b23277b974982b08 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fsession_2eIgnoreBrokenPipes()
declare %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %v0, i32 %a0)
@olang_loc_28490b3d64df97fe_1fa673a94cf24522 = external constant [0 x i8]
declare i64 @std_2ftime_2eNow()
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_d1a2ced90ae1fed3_af42112fabe41f37 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsession_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNext(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_3b6b320f0468fe97_a6b70e33112bfcbb = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %v0, i8 %a0, i64 %a1)
@olang_loc_b56467a85251252d_5a05a1cd484a3361 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemove_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eInsert_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fsession_2eWriteFramed(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare void @compiler_2fsession_2eCloseFd(i32 %a0)
@olang_loc_a8eebe32341e04e6_239ed324021d536a = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H8382af141d9e85fe3a70b55889952bcd(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eClear(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1f1ebcf53f42361_3e0cb829339a6f9d = external constant [0 x i8]
@olang_loc_43d07951ce1dba96_20fc5bf2a8432eaa = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_H1531dad62b744074bb3be3226dd54f14(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_824396f7e8872934_1f4412bc0bc5f5e0 = external constant [0 x i8]
declare i32 @compiler_2fsession_2eReap(i32 %a0)
declare { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0)
@olang_loc_b5606d6e3fe22ec3_be86f13ccb1ff2ff = external constant [0 x i8]
@olang_loc_ad997ef4ac6fd571_d04020f26953855d = external constant [0 x i8]
declare { i32, ptr } @std_2fjson_2eParse(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@olang_loc_aa7531c8ff935160_c377f1bac17802ac = external constant [0 x i8]
@olang_loc_56fa7fac25efd7e3_fd7025eb3c8ceb4f = external constant [0 x i8]
declare { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_3e(ptr %v0, ptr %a0, { i64, ptr } %a1)
@olang_loc_bad65bd0ec5ef9e2_cc5215fe2456bb0e = external constant [0 x i8]
@olang_loc_779866c44d300dd9_2ce9f6dddf4879c5 = external constant [0 x i8]
@olang_loc_88935568e23e9408_fef9f2c10b524914 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %v0, ptr %a0)
@olang_loc_8a94f6ccb57e7bff_9da85173f0218233 = external constant [0 x i8]
@olang_loc_927186eff22c45fe_ce09c1db1b05d8b2 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_b07487623eac622f_c8aa01acfc198fbb = external constant [0 x i8]
@olang_loc_d23162b8215dec1d_483a007ef8846361 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %a0)
@olang_loc_712aaea22fe89d25_c40047bf6049dd1 = external constant [0 x i8]
@olang_loc_5c32fdd2254e4c55_6ae9d0a3a84d2bb1 = external constant [0 x i8]
declare { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %v0, ptr %a0)
@olang_loc_17725019f9643264_c99bbb5f098da7a0 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_f638230cb743249f_247d31742d58659b = external constant [0 x i8]
@olang_loc_8dd922756996ba1e_e7fa0e8ed65b4b9a = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H962a30edd485f38e7d3abb41262b569a(ptr %v0, ptr %a0)
@olang_loc_ea7eed99d59acef9_46ecfb6f0a8a862d = external constant [0 x i8]
@olang_loc_f1b3f1e4d6991028_b1cc0ac5434ca67c = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_Hc8e24fa4dba7e8fd650818e9a0171b72(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i32 } @compiler_2fsession_2ePipe()
declare i32 @compiler_2fsession_2eFork()
declare void @compiler_2fsession_2eDup2(i32 %a0, i32 %a1)
declare void @compiler_2fsession_2eExit(i32 %a0)
@olang_loc_1521364e571a2f2d_bf1cb7a51b345899 = external constant [0 x i8]
declare void @compiler_2fsession_2eKillAndReap(i32 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2e_Hc8f637dbd3c39b4e5f02c4f7fcfa329b(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_808e0602b7ec4f9f_4ebb0156f1026a43 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_182f056b6a3fe51e_12be5b3b255222c2 = external constant [0 x i8]
@olang_loc_cb6dbf061e2dce2f_dc463ae13d2c2fbb = external constant [0 x i8]
declare ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, i1 %a4)
@olang_loc_87f37ba47774b846_89d4dc908ddb257a = external constant [0 x i8]
@olang_loc_4ebfa45d02ec2e27_3873456da27149fb = external constant [0 x i8]
@olang_loc_38a34762ac5520ac_3968f3c3cddc2680 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
@olang_loc_456b769a5430a35d_bb604ee566770711 = external constant [0 x i8]
@olang_loc_7f592474689ac30a_b2c7e24f5de8ebf6 = external constant [0 x i8]
declare i64 @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eOffset(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare { i32, { i64, ptr } } @compiler_2fsession_2eFormat(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fsession_2eSymbols(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3)
declare { i32, %"compiler/session:Found" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eLookup(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
@olang_loc_bd1a900ffc81074b_9b3f40c88c4de497 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare void @compiler_2fsession_2eHold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H8fdab0f9e4aba8682af3c4e1d27c3999(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7dbcadc8ee279278_9f927e608471f374 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fsession_2eWordChar(i8 %a0)
declare %"compiler/session:Items" @compiler_2fsession_3aItems_2ector(ptr %v0)
@olang_loc_af7c431932a7c0fe_be95e1b6bda5ce6a = external constant [0 x i8]
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H233962476a3191cb30d917b30cae0288(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2_H2ebf6f1d68886862a568a520c713bfce(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_a7da96addb4507f4_b5358bb03c267030 = external constant [0 x i8]
declare void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eMembers(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3)
declare void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3)
declare %"compiler/diag:Item" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eAt_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aItem_3e_2eLen_3ccompiler_2fdiag_3aItem_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eRealOfFile(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eItems(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilde_H96a31ecee6fa958f3b956bd4cf13d4ad(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/text:StringBuilder" %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilde_H0e2e3c0fe5ff21020d49b50eb045255d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_e34d33a8199c916a_aaf0de3edf4986c6 = external constant [0 x i8]
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7cd8b38167923161_43fbbad0bd403bed = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
@olang_loc_f3afb7cdea72bea9_2e903794abb886a5 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8c5172bb8ea5e6bc_75de6e53c7815648 = external constant [0 x i8]
@olang_loc_6f843a9f898efe67_8723688731f48c63 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
@olang_loc_8f54b2067e6b6b8a_86cbf1b666cce186 = external constant [0 x i8]
@olang_loc_c8d49224b0a3e505_8d1f0d35a00e1b49 = external constant [0 x i8]
@olang_loc_3745daa1275561cc_12cd1f9b9ff8c2e8 = external constant [0 x i8]
declare { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAt_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_898f47ed6de9d529_f325535f3a937a9d = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aStringBuilder_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20compiler_2flsp_3aDoc_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
