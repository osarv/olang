; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/io:Reader" = type { i32, %"std/io:source" }
%"std/io:source" = type { i32, { i64, ptr }, i64, i64 }
define dso_local { i32, i1 } @std_2fio_2estd_2fio_3aReader_2eNext_3cBool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l8 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i1 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"std/io:Reader", ptr %a0, i32 0, i32 1
  %t5 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3asource_2eword(ptr %v0, ptr %s0, ptr %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t12, 2
  %t17 = select i1 %t16, i32 2, i32 %t15
  %t18 = icmp eq i32 %t11, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t13
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, i1 } zeroinitializer, i32 %t21, 0
  store { i32, i1 } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = call { i32, i1 } @std_2fprelude_2ftext_2eBool_2eParse(ptr %s0, { i64, ptr } %t24)
  %t28 = extractvalue { i32, i1 } %t27, 1
  %t29 = extractvalue { i32, i1 } %t27, 0
  store i32 %t29, ptr %l11
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31, !prof !99
ok.31:
  store i1 %t28, ptr %l10
  br label %bb4
bb4:
  %t32 = load i1, ptr %l10, !tbaa !21
  store i1 %t32, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t33 = load i32, ptr %l11, !tbaa !23
  %t34 = lshr i32 %t33, 16
  %t35 = and i32 %t33, 65535
  %t36 = icmp eq i32 %t34, 1
  %t37 = select i1 %t36, i32 3, i32 0
  %t38 = icmp eq i32 %t33, 0
  %t39 = shl i32 %t37, 16
  %t40 = or i32 %t39, %t35
  %t41 = select i1 %t38, i32 0, i32 %t40
  call void @__olang_scope_close(ptr %s0)
  %t43 = insertvalue { i32, i1 } zeroinitializer, i32 %t41, 0
  store { i32, i1 } %t43, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load i1, ptr %l8, !tbaa !21
  %t45 = insertvalue { i32, i1 } zeroinitializer, i1 %t44, 1
  store { i32, i1 } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local { i32, float } @std_2fio_2estd_2fio_3aReader_2eNext_3cF32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l8 = alloca float
  %l10 = alloca float
  %l11 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, float }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"std/io:Reader", ptr %a0, i32 0, i32 1
  %t5 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3asource_2eword(ptr %v0, ptr %s0, ptr %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t12, 2
  %t17 = select i1 %t16, i32 2, i32 %t15
  %t18 = icmp eq i32 %t11, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t13
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, float } zeroinitializer, i32 %t21, 0
  store { i32, float } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = call { i32, float } @std_2fprelude_2ftext_2eT_2eParse_3cF32_3e(ptr %s0, { i64, ptr } %t24)
  %t28 = extractvalue { i32, float } %t27, 1
  %t29 = extractvalue { i32, float } %t27, 0
  store i32 %t29, ptr %l11
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31, !prof !99
ok.31:
  store float %t28, ptr %l10
  br label %bb4
bb4:
  %t32 = load float, ptr %l10, !tbaa !25
  store float %t32, ptr %l8, !tbaa !25
  br label %bb6
bb5:
  %t33 = load i32, ptr %l11, !tbaa !23
  %t34 = lshr i32 %t33, 16
  %t35 = and i32 %t33, 65535
  %t36 = icmp eq i32 %t34, 1
  %t37 = select i1 %t36, i32 3, i32 0
  %t38 = icmp eq i32 %t33, 0
  %t39 = shl i32 %t37, 16
  %t40 = or i32 %t39, %t35
  %t41 = select i1 %t38, i32 0, i32 %t40
  call void @__olang_scope_close(ptr %s0)
  %t43 = insertvalue { i32, float } zeroinitializer, i32 %t41, 0
  store { i32, float } %t43, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load float, ptr %l8, !tbaa !25
  %t45 = insertvalue { i32, float } zeroinitializer, float %t44, 1
  store { i32, float } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i32, float }, ptr %rv
  ret { i32, float } %rr
}

define dso_local { i32, double } @std_2fio_2estd_2fio_3aReader_2eNext_3cF64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l8 = alloca double
  %l10 = alloca double
  %l11 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, double }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"std/io:Reader", ptr %a0, i32 0, i32 1
  %t5 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3asource_2eword(ptr %v0, ptr %s0, ptr %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t12, 2
  %t17 = select i1 %t16, i32 2, i32 %t15
  %t18 = icmp eq i32 %t11, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t13
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, double } zeroinitializer, i32 %t21, 0
  store { i32, double } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t27 = call { i32, double } @std_2fprelude_2ftext_2eT_2eParse_3cF64_3e(ptr %s0, { i64, ptr } %t24)
  %t28 = extractvalue { i32, double } %t27, 1
  %t29 = extractvalue { i32, double } %t27, 0
  store i32 %t29, ptr %l11
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31, !prof !99
ok.31:
  store double %t28, ptr %l10
  br label %bb4
bb4:
  %t32 = load double, ptr %l10, !tbaa !26
  store double %t32, ptr %l8, !tbaa !26
  br label %bb6
bb5:
  %t33 = load i32, ptr %l11, !tbaa !23
  %t34 = lshr i32 %t33, 16
  %t35 = and i32 %t33, 65535
  %t36 = icmp eq i32 %t34, 1
  %t37 = select i1 %t36, i32 3, i32 0
  %t38 = icmp eq i32 %t33, 0
  %t39 = shl i32 %t37, 16
  %t40 = or i32 %t39, %t35
  %t41 = select i1 %t38, i32 0, i32 %t40
  call void @__olang_scope_close(ptr %s0)
  %t43 = insertvalue { i32, double } zeroinitializer, i32 %t41, 0
  store { i32, double } %t43, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load double, ptr %l8, !tbaa !26
  %t45 = insertvalue { i32, double } zeroinitializer, double %t44, 1
  store { i32, double } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local { i32, i128 } @std_2fio_2estd_2fio_3aReader_2eNext_3cI128_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l8 = alloca i128
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i128
  %l14 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i128 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"std/io:Reader", ptr %a0, i32 0, i32 1
  %t5 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3asource_2eword(ptr %v0, ptr %s0, ptr %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t12, 2
  %t17 = select i1 %t16, i32 2, i32 %t15
  %t18 = icmp eq i32 %t11, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t13
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, i128 } zeroinitializer, i32 %t21, 0
  store { i32, i128 } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  %t26 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t27 = extractvalue { i32, i64 } %t26, 1
  %t28 = extractvalue { i32, i64 } %t26, 0
  store i32 %t28, ptr %l11
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb5, label %ok.30, !prof !99
ok.30:
  store i64 %t27, ptr %l10
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t32 = load i64, ptr %l10, !tbaa !24
  %t33 = call { i32, i128 } @std_2fprelude_2ftext_2eT_2eParse_3cI128_3e(ptr %s0, { i64, ptr } %t31, i64 %t32)
  %t34 = extractvalue { i32, i128 } %t33, 1
  %t35 = extractvalue { i32, i128 } %t33, 0
  store i32 %t35, ptr %l14
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb7, label %ok.37, !prof !99
ok.37:
  store i128 %t34, ptr %l13
  br label %bb6
bb5:
  %t38 = load i32, ptr %l11, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 0, i32 0
  %t43 = icmp eq i32 %t38, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t40
  %t46 = select i1 %t43, i32 0, i32 %t45
  call void @__olang_scope_close(ptr %s0)
  %t48 = insertvalue { i32, i128 } zeroinitializer, i32 %t46, 0
  store { i32, i128 } %t48, ptr %rv
  br label %ret
bb6:
  %t49 = load i128, ptr %l13
  store i128 %t49, ptr %l8
  br label %bb8
bb7:
  %t50 = load i32, ptr %l14, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 3, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, i128 } zeroinitializer, i32 %t58, 0
  store { i32, i128 } %t60, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i128, ptr %l8
  %t62 = insertvalue { i32, i128 } zeroinitializer, i128 %t61, 1
  store { i32, i128 } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i128 }, ptr %rv
  ret { i32, i128 } %rr
}

define dso_local { i32, i32 } @std_2fio_2estd_2fio_3aReader_2eNext_3cI32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"std/io:Reader", ptr %a0, i32 0, i32 1
  %t5 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3asource_2eword(ptr %v0, ptr %s0, ptr %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t12, 2
  %t17 = select i1 %t16, i32 2, i32 %t15
  %t18 = icmp eq i32 %t11, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t13
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, i32 } zeroinitializer, i32 %t21, 0
  store { i32, i32 } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  %t26 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t27 = extractvalue { i32, i64 } %t26, 1
  %t28 = extractvalue { i32, i64 } %t26, 0
  store i32 %t28, ptr %l11
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb5, label %ok.30, !prof !99
ok.30:
  store i64 %t27, ptr %l10
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t32 = load i64, ptr %l10, !tbaa !24
  %t33 = call { i32, i32 } @std_2fprelude_2ftext_2eT_2eParse_3cI32_3e(ptr %s0, { i64, ptr } %t31, i64 %t32)
  %t34 = extractvalue { i32, i32 } %t33, 1
  %t35 = extractvalue { i32, i32 } %t33, 0
  store i32 %t35, ptr %l14
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb7, label %ok.37, !prof !99
ok.37:
  store i32 %t34, ptr %l13
  br label %bb6
bb5:
  %t38 = load i32, ptr %l11, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 0, i32 0
  %t43 = icmp eq i32 %t38, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t40
  %t46 = select i1 %t43, i32 0, i32 %t45
  call void @__olang_scope_close(ptr %s0)
  %t48 = insertvalue { i32, i32 } zeroinitializer, i32 %t46, 0
  store { i32, i32 } %t48, ptr %rv
  br label %ret
bb6:
  %t49 = load i32, ptr %l13, !tbaa !23
  store i32 %t49, ptr %l8, !tbaa !23
  br label %bb8
bb7:
  %t50 = load i32, ptr %l14, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 3, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, i32 } zeroinitializer, i32 %t58, 0
  store { i32, i32 } %t60, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i32, ptr %l8, !tbaa !23
  %t62 = insertvalue { i32, i32 } zeroinitializer, i32 %t61, 1
  store { i32, i32 } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, i64 } @std_2fio_2estd_2fio_3aReader_2eNext_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"std/io:Reader", ptr %a0, i32 0, i32 1
  %t5 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3asource_2eword(ptr %v0, ptr %s0, ptr %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t12, 2
  %t17 = select i1 %t16, i32 2, i32 %t15
  %t18 = icmp eq i32 %t11, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t13
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, i64 } zeroinitializer, i32 %t21, 0
  store { i32, i64 } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  %t26 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t27 = extractvalue { i32, i64 } %t26, 1
  %t28 = extractvalue { i32, i64 } %t26, 0
  store i32 %t28, ptr %l11
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb5, label %ok.30, !prof !99
ok.30:
  store i64 %t27, ptr %l10
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t32 = load i64, ptr %l10, !tbaa !24
  %t33 = call { i32, i64 } @std_2fprelude_2ftext_2eT_2eParse_3cI64_3e(ptr %s0, { i64, ptr } %t31, i64 %t32)
  %t34 = extractvalue { i32, i64 } %t33, 1
  %t35 = extractvalue { i32, i64 } %t33, 0
  store i32 %t35, ptr %l14
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb7, label %ok.37, !prof !99
ok.37:
  store i64 %t34, ptr %l13
  br label %bb6
bb5:
  %t38 = load i32, ptr %l11, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 0, i32 0
  %t43 = icmp eq i32 %t38, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t40
  %t46 = select i1 %t43, i32 0, i32 %t45
  call void @__olang_scope_close(ptr %s0)
  %t48 = insertvalue { i32, i64 } zeroinitializer, i32 %t46, 0
  store { i32, i64 } %t48, ptr %rv
  br label %ret
bb6:
  %t49 = load i64, ptr %l13, !tbaa !24
  store i64 %t49, ptr %l8, !tbaa !24
  br label %bb8
bb7:
  %t50 = load i32, ptr %l14, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 3, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, i64 } zeroinitializer, i32 %t58, 0
  store { i32, i64 } %t60, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = insertvalue { i32, i64 } zeroinitializer, i64 %t61, 1
  store { i32, i64 } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, i8 } @std_2fio_2estd_2fio_3aReader_2eNext_3cU8_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l8 = alloca i8
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i8
  %l14 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i8 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"std/io:Reader", ptr %a0, i32 0, i32 1
  %t5 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3asource_2eword(ptr %v0, ptr %s0, ptr %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t12, 2
  %t17 = select i1 %t16, i32 2, i32 %t15
  %t18 = icmp eq i32 %t11, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t13
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, i8 } zeroinitializer, i32 %t21, 0
  store { i32, i8 } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  %t26 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t27 = extractvalue { i32, i64 } %t26, 1
  %t28 = extractvalue { i32, i64 } %t26, 0
  store i32 %t28, ptr %l11
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb5, label %ok.30, !prof !99
ok.30:
  store i64 %t27, ptr %l10
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t32 = load i64, ptr %l10, !tbaa !24
  %t33 = call { i32, i8 } @std_2fprelude_2ftext_2eT_2eParse_3cU8_3e(ptr %s0, { i64, ptr } %t31, i64 %t32)
  %t34 = extractvalue { i32, i8 } %t33, 1
  %t35 = extractvalue { i32, i8 } %t33, 0
  store i32 %t35, ptr %l14
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb7, label %ok.37, !prof !99
ok.37:
  store i8 %t34, ptr %l13
  br label %bb6
bb5:
  %t38 = load i32, ptr %l11, !tbaa !23
  %t39 = lshr i32 %t38, 16
  %t40 = and i32 %t38, 65535
  %t41 = icmp eq i32 %t39, 1
  %t42 = select i1 %t41, i32 0, i32 0
  %t43 = icmp eq i32 %t38, 0
  %t44 = shl i32 %t42, 16
  %t45 = or i32 %t44, %t40
  %t46 = select i1 %t43, i32 0, i32 %t45
  call void @__olang_scope_close(ptr %s0)
  %t48 = insertvalue { i32, i8 } zeroinitializer, i32 %t46, 0
  store { i32, i8 } %t48, ptr %rv
  br label %ret
bb6:
  %t49 = load i8, ptr %l13, !tbaa !22
  store i8 %t49, ptr %l8, !tbaa !22
  br label %bb8
bb7:
  %t50 = load i32, ptr %l14, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 3, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, i8 } zeroinitializer, i32 %t58, 0
  store { i32, i8 } %t60, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i8, ptr %l8, !tbaa !22
  %t62 = insertvalue { i32, i8 } zeroinitializer, i8 %t61, 1
  store { i32, i8 } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i8 }, ptr %rv
  ret { i32, i8 } %rr
}

define dso_local i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l5 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l0, !tbaa !24
  %t5 = icmp slt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb3
bb2:
  %t9 = load i64, ptr %l0, !tbaa !24
  store i64 %t9, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, float } @std_2fprelude_2ftext_2eT_2eParse_3cF32_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca double
  %l2 = alloca float
  %l3 = alloca double
  %l5 = alloca double
  %l6 = alloca i32
  %l13 = alloca i1
  %l18 = alloca i1
  %rv = alloca { i32, float }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, double } %t3, 1
  %t5 = extractvalue { i32, double } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store double %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load double, ptr %l5, !tbaa !26
  store double %t8, ptr %l3, !tbaa !26
  br label %bb3
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, float } zeroinitializer, i32 %t17, 0
  store { i32, float } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load double, ptr %l3, !tbaa !26
  store double %t20, ptr %l1, !tbaa !26
  %t21 = load double, ptr %l1, !tbaa !26
  %t23 = fptrunc double %t21 to float
  store float %t23, ptr %l2, !tbaa !25
  %t25 = load double, ptr %l1, !tbaa !26
  %t26 = load double, ptr %l1, !tbaa !26
  %t29 = fcmp oeq double %t25, %t26
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t31 = load double, ptr %l1, !tbaa !26
  %t32 = load double, ptr %l1, !tbaa !26
  %t35 = fsub double %t31, %t32
  %t37 = fcmp oeq double %t35, 0x0000000000000000
  store i1 %t37, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t39 = load i1, ptr %l13, !tbaa !21
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t40 = load float, ptr %l2, !tbaa !25
  %t41 = load float, ptr %l2, !tbaa !25
  %t44 = fsub float %t40, %t41
  %t46 = fcmp une float %t44, 0x0000000000000000
  store i1 %t46, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l18, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = insertvalue { i32, float } zeroinitializer, i32 65538, 0
  store { i32, float } %t50, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t51 = load float, ptr %l2, !tbaa !25
  %t53 = insertvalue { i32, float } zeroinitializer, float %t51, 1
  store { i32, float } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i32, float }, ptr %rv
  ret { i32, float } %rr
}

define dso_local { i32, double } @std_2fprelude_2ftext_2eT_2eParse_3cF64_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca double
  %l2 = alloca double
  %l3 = alloca double
  %l5 = alloca double
  %l6 = alloca i32
  %l12 = alloca i1
  %l17 = alloca i1
  %rv = alloca { i32, double }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, double } %t3, 1
  %t5 = extractvalue { i32, double } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store double %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load double, ptr %l5, !tbaa !26
  store double %t8, ptr %l3, !tbaa !26
  br label %bb3
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, double } zeroinitializer, i32 %t17, 0
  store { i32, double } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load double, ptr %l3, !tbaa !26
  store double %t20, ptr %l1, !tbaa !26
  %t21 = load double, ptr %l1, !tbaa !26
  store double %t21, ptr %l2, !tbaa !26
  %t23 = load double, ptr %l1, !tbaa !26
  %t24 = load double, ptr %l1, !tbaa !26
  %t27 = fcmp oeq double %t23, %t24
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load double, ptr %l1, !tbaa !26
  %t30 = load double, ptr %l1, !tbaa !26
  %t33 = fsub double %t29, %t30
  %t35 = fcmp oeq double %t33, 0x0000000000000000
  store i1 %t35, ptr %l12, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t37 = load i1, ptr %l12, !tbaa !21
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t38 = load double, ptr %l2, !tbaa !26
  %t39 = load double, ptr %l2, !tbaa !26
  %t42 = fsub double %t38, %t39
  %t44 = fcmp une double %t42, 0x0000000000000000
  store i1 %t44, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l17, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = insertvalue { i32, double } zeroinitializer, i32 65538, 0
  store { i32, double } %t48, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t49 = load double, ptr %l2, !tbaa !26
  %t51 = insertvalue { i32, double } zeroinitializer, double %t49, 1
  store { i32, double } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local { i32, i128 } @std_2fprelude_2ftext_2eT_2eParse_3cI128_3e(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i128
  %l7 = alloca i64
  %l8 = alloca i128
  %l9 = alloca i128
  %l10 = alloca i128
  %l11 = alloca i128
  %l12 = alloca i128
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i8
  %l18 = alloca i64
  %l19 = alloca i128
  %l24 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l42 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l52 = alloca i1
  %l56 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i128
  %l61 = alloca i128
  %l62 = alloca i32
  %l90 = alloca i1
  %l94 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i32
  %l109 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i32
  %l118 = alloca i1
  %l129 = alloca i64
  %l135 = alloca i128
  %l153 = alloca { i64, ptr }
  %l158 = alloca i1
  %l164 = alloca i1
  %l165 = alloca { i64, ptr }
  %l170 = alloca i1
  %l178 = alloca i64
  %l189 = alloca i1
  %l193 = alloca i1
  %l207 = alloca i1
  %l211 = alloca i1
  %rv = alloca { i32, i128 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = insertvalue { i32, i128 } zeroinitializer, i32 65536, 0
  store { i32, i128 } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l24, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  %t15 = icmp eq i8 %t13, 45
  store i1 %t15, ptr %l2, !tbaa !21
  %t17 = load i1, ptr %l2, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb6
bb5:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l29, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 0
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp eq i8 %t23, 43
  store i1 %t25, ptr %l28, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l28, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t28, ptr %l33, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t29, 0
  store i64 %t32, ptr %l36, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l37, !tbaa !24
  %t35 = icmp sge i64 1, 0
  br i1 %t35, label %bb9, label %bb10
bb8:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l42, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t38, 0
  store i64 %t41, ptr %l45, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l46, !tbaa !24
  %t44 = icmp sge i64 0, 0
  br i1 %t44, label %bb15, label %bb16
bb9:
  %t46 = load i64, ptr %l36, !tbaa !24
  %t47 = icmp sle i64 1, %t46
  br i1 %t47, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8de27d6f5cb8b5a8_575e8481497d3ea4)
  unreachable
bb11:
  %t49 = load i64, ptr %l36, !tbaa !24
  %t50 = load i64, ptr %l37, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_8de27d6f5cb8b5a8_575e8481497d3ea4)
  unreachable
bb13:
  %t53 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l36, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 1
  %t57 = sub i64 %t55, 1
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l32, !tbaa !27
  br label %bb21
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8de27d6f5cb8b5a8_575e8481497d3ea4)
  unreachable
bb15:
  %t61 = load i64, ptr %l45, !tbaa !24
  %t62 = icmp sle i64 0, %t61
  br i1 %t62, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8de27d6f5cb8b5a8_575e8481497d3ea4)
  unreachable
bb17:
  %t64 = load i64, ptr %l45, !tbaa !24
  %t65 = load i64, ptr %l46, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  br i1 %t66, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8de27d6f5cb8b5a8_575e8481497d3ea4)
  unreachable
bb19:
  %t68 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l45, !tbaa !24
  %t71 = getelementptr i8, ptr %t69, i64 0
  %t72 = sub i64 %t70, 0
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  store { i64, ptr } %t74, ptr %l32, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_8de27d6f5cb8b5a8_575e8481497d3ea4)
  unreachable
bb21:
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t76, ptr %l3, !tbaa !27
  %t77 = icmp sgt i64 16, 8
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = icmp eq i64 %t79, 0
  store i1 %t82, ptr %l52, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb24
bb24:
  %t84 = load i1, ptr %l52, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  %t85 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %t85)
  store i1 %t87, ptr %l58
  br label %bb27
bb26:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  %t88 = load i1, ptr %l58, !tbaa !21
  store i1 %t88, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t89 = load i1, ptr %l56, !tbaa !21
  br i1 %t89, label %bb29, label %bb30
bb29:
  %t90 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t92 = call { i32, i128 } @std_2fprelude_2ftext_2ereadWide(ptr %v0, { i64, ptr } %t90)
  %t93 = extractvalue { i32, i128 } %t92, 1
  %t94 = extractvalue { i32, i128 } %t92, 0
  store i32 %t94, ptr %l62
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb32, label %ok.96, !prof !99
ok.96:
  store i128 %t93, ptr %l61
  br label %bb31
bb30:
  br label %bb49
bb31:
  %t97 = load i128, ptr %l61
  store i128 %t97, ptr %l59
  br label %bb33
bb32:
  %t98 = load i32, ptr %l62, !tbaa !23
  %t99 = lshr i32 %t98, 16
  %t100 = and i32 %t98, 65535
  %t101 = icmp eq i32 %t99, 1
  %t102 = select i1 %t101, i32 1, i32 0
  %t103 = icmp eq i32 %t98, 0
  %t104 = shl i32 %t102, 16
  %t105 = or i32 %t104, %t100
  %t106 = select i1 %t103, i32 0, i32 %t105
  %t108 = insertvalue { i32, i128 } zeroinitializer, i32 %t106, 0
  store { i32, i128 } %t108, ptr %rv
  br label %ret
bb33:
  %t109 = load i128, ptr %l59
  store i128 %t109, ptr %l4
  %t110 = load i128, ptr %l4
  %t111 = zext i64 -1 to i128
  %t114 = icmp ugt i128 %t110, %t111
  br i1 %t114, label %bb34, label %bb35
bb34:
  %t116 = load i1, ptr %l2, !tbaa !21
  br i1 %t116, label %bb36, label %bb37
bb35:
  br label %bb48
bb36:
  %t118 = zext i64 127 to i128
  %t119 = shl i128 1, %t118
  %t121 = icmp eq i128 %t119, 0
  br i1 %t121, label %bb38, label %bb39
bb37:
  br label %bb44
bb38:
  %t124 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t124, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t125 = load i128, ptr %l4
  %t126 = zext i64 127 to i128
  %t127 = shl i128 1, %t126
  %t129 = xor i128 %t127, -1
  %t132 = add i128 %t129, 1
  %t135 = icmp ugt i128 %t125, %t132
  br i1 %t135, label %bb41, label %bb42
bb41:
  %t138 = insertvalue { i32, i128 } zeroinitializer, i32 65538, 0
  store { i32, i128 } %t138, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t139 = load i128, ptr %l4
  %t142 = sub i128 0, %t139
  %t144 = insertvalue { i32, i128 } zeroinitializer, i128 %t142, 1
  store { i32, i128 } %t144, ptr %rv
  br label %ret
bb44:
  %t145 = load i128, ptr %l4
  %t146 = zext i64 127 to i128
  %t147 = shl i128 1, %t146
  %t149 = xor i128 %t147, -1
  %t153 = icmp ugt i128 %t145, %t149
  br i1 %t153, label %bb45, label %bb46
bb45:
  %t156 = insertvalue { i32, i128 } zeroinitializer, i32 65538, 0
  store { i32, i128 } %t156, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t157 = load i128, ptr %l4
  %t160 = insertvalue { i32, i128 } zeroinitializer, i128 %t157, 1
  store { i32, i128 } %t160, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t161 = icmp sle i64 16, 8
  br i1 %t161, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb56
bb51:
  %t163 = load i64, ptr %l1, !tbaa !24
  %t166 = icmp eq i64 %t163, 0
  br i1 %t166, label %bb52, label %bb53
bb52:
  %t168 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t170 = call i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %t168)
  store i1 %t170, ptr %l96
  br label %bb54
bb53:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb55
bb54:
  %t171 = load i1, ptr %l96, !tbaa !21
  store i1 %t171, ptr %l94, !tbaa !21
  br label %bb55
bb55:
  %t172 = load i1, ptr %l94, !tbaa !21
  store i1 %t172, ptr %l90, !tbaa !21
  br label %bb56
bb56:
  %t173 = load i1, ptr %l90, !tbaa !21
  br i1 %t173, label %bb57, label %bb58
bb57:
  %t174 = zext i64 127 to i128
  %t175 = shl i128 1, %t174
  %t177 = icmp slt i128 %t175, 0
  br i1 %t177, label %bb59, label %bb60
bb58:
  br label %bb71
bb59:
  %t179 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t180 = load i64, ptr %l1, !tbaa !24
  %t183 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t179, i64 %t180)
  %t184 = extractvalue { i32, i64 } %t183, 1
  %t185 = extractvalue { i32, i64 } %t183, 0
  store i32 %t185, ptr %l103
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb62, label %ok.187, !prof !99
ok.187:
  store i64 %t184, ptr %l102
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t188 = load i64, ptr %l102, !tbaa !24
  store i64 %t188, ptr %l99, !tbaa !24
  br label %bb63
bb62:
  %t189 = load i32, ptr %l103, !tbaa !23
  %t190 = lshr i32 %t189, 16
  %t191 = and i32 %t189, 65535
  %t192 = icmp eq i32 %t190, 1
  %t193 = select i1 %t192, i32 1, i32 0
  %t194 = icmp eq i32 %t189, 0
  %t195 = shl i32 %t193, 16
  %t196 = or i32 %t195, %t191
  %t197 = select i1 %t194, i32 0, i32 %t196
  %t199 = insertvalue { i32, i128 } zeroinitializer, i32 %t197, 0
  store { i32, i128 } %t199, ptr %rv
  br label %ret
bb63:
  %t200 = load i64, ptr %l99, !tbaa !24
  %t203 = sext i64 %t200 to i128
  %t205 = insertvalue { i32, i128 } zeroinitializer, i128 %t203, 1
  store { i32, i128 } %t205, ptr %rv
  br label %ret
bb64:
  %t206 = load i1, ptr %l2, !tbaa !21
  br i1 %t206, label %bb65, label %bb66
bb65:
  %t209 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t209, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  %t210 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t211 = load i64, ptr %l1, !tbaa !24
  %t214 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t210, i64 %t211)
  %t215 = extractvalue { i32, i64 } %t214, 1
  %t216 = extractvalue { i32, i64 } %t214, 0
  store i32 %t216, ptr %l113
  %t217 = icmp ne i32 %t216, 0
  br i1 %t217, label %bb69, label %ok.218, !prof !99
ok.218:
  store i64 %t215, ptr %l112
  br label %bb68
bb68:
  %t219 = load i64, ptr %l112, !tbaa !65
  store i64 %t219, ptr %l109, !tbaa !65
  br label %bb70
bb69:
  %t220 = load i32, ptr %l113, !tbaa !23
  %t221 = lshr i32 %t220, 16
  %t222 = and i32 %t220, 65535
  %t223 = icmp eq i32 %t221, 1
  %t224 = select i1 %t223, i32 1, i32 0
  %t225 = icmp eq i32 %t220, 0
  %t226 = shl i32 %t224, 16
  %t227 = or i32 %t226, %t222
  %t228 = select i1 %t225, i32 0, i32 %t227
  %t230 = insertvalue { i32, i128 } zeroinitializer, i32 %t228, 0
  store { i32, i128 } %t230, ptr %rv
  br label %ret
bb70:
  %t231 = load i64, ptr %l109, !tbaa !65
  %t234 = zext i64 %t231 to i128
  %t236 = insertvalue { i32, i128 } zeroinitializer, i128 %t234, 1
  store { i32, i128 } %t236, ptr %rv
  br label %ret
bb71:
  %t237 = load i1, ptr %l2, !tbaa !21
  br i1 %t237, label %bb72, label %bb73
bb72:
  %t239 = zext i64 127 to i128
  %t240 = shl i128 1, %t239
  %t242 = icmp eq i128 %t240, 0
  store i1 %t242, ptr %l118, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb74
bb74:
  %t244 = load i1, ptr %l118, !tbaa !21
  br i1 %t244, label %bb75, label %bb76
bb75:
  %t246 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t246, ptr %rv
  br label %ret
bb76:
  br label %bb77
bb77:
  %t247 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t247, 0
  %t251 = icmp eq i64 %t249, 0
  br i1 %t251, label %bb78, label %bb79
bb78:
  %t254 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t254, ptr %rv
  br label %ret
bb79:
  br label %bb80
bb80:
  %t255 = load i64, ptr %l1, !tbaa !24
  %t258 = icmp eq i64 %t255, 0
  br i1 %t258, label %bb81, label %bb82
bb81:
  store i64 10, ptr %l129, !tbaa !24
  br label %bb83
bb82:
  %t260 = load i64, ptr %l1, !tbaa !24
  store i64 %t260, ptr %l129, !tbaa !24
  br label %bb83
bb83:
  %t263 = load i64, ptr %l129, !tbaa !24
  store i64 %t263, ptr %l7, !tbaa !24
  %t264 = load i64, ptr %l7, !tbaa !24
  %t266 = sext i64 %t264 to i128
  store i128 %t266, ptr %l8
  %t268 = load i1, ptr %l2, !tbaa !21
  br i1 %t268, label %bb84, label %bb85
bb84:
  %t270 = zext i64 127 to i128
  %t271 = shl i128 1, %t270
  store i128 %t271, ptr %l135
  br label %bb86
bb85:
  %t273 = zext i64 127 to i128
  %t274 = shl i128 1, %t273
  %t276 = xor i128 %t274, -1
  store i128 %t276, ptr %l135
  br label %bb86
bb86:
  %t278 = load i128, ptr %l135
  store i128 %t278, ptr %l9
  %t279 = load i128, ptr %l9
  %t280 = load i128, ptr %l8
  %t283 = sdiv i128 %t279, %t280
  store i128 %t283, ptr %l10
  %t285 = load i128, ptr %l9
  %t286 = load i128, ptr %l8
  %t289 = srem i128 %t285, %t286
  store i128 %t289, ptr %l11
  store i128 0, ptr %l12
  %t291 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t291, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t293 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t293, 0
  store i64 %t295, ptr %l15, !tbaa !24
  br label %bb87
bb87:
  %t297 = load i64, ptr %l14, !tbaa !24
  %t298 = load i64, ptr %l15, !tbaa !24
  %t301 = icmp slt i64 %t297, %t298
  %t303 = xor i1 %t301, true
  br i1 %t303, label %bb88, label %bb89
bb88:
  br label %bb132
bb89:
  br label %bb90
bb90:
  %t305 = load i64, ptr %l14, !tbaa !24
  store i64 %t305, ptr %l16, !tbaa !24
  %t307 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t307, ptr %l153, !tbaa !27
  %t308 = load i64, ptr %l14, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr i8, ptr %t311, i64 %t308
  %t313 = load i8, ptr %t312, !tbaa !32
  store i8 %t313, ptr %l17, !tbaa !22
  %t315 = load i8, ptr %l17, !tbaa !22
  %t317 = icmp eq i8 %t315, 95
  br i1 %t317, label %bb91, label %bb92
bb91:
  %t319 = load i64, ptr %l1, !tbaa !24
  %t322 = icmp eq i64 %t319, 0
  store i1 %t322, ptr %l158, !tbaa !21
  br label %bb93
bb92:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb93
bb93:
  %t324 = load i1, ptr %l158, !tbaa !21
  br i1 %t324, label %bb94, label %bb95
bb94:
  %t325 = load i64, ptr %l16, !tbaa !24
  %t327 = icmp eq i64 %t325, 0
  br i1 %t327, label %bb96, label %bb97
bb95:
  br label %bb105
bb96:
  store i1 true, ptr %l164, !tbaa !21
  br label %bb98
bb97:
  %t329 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t329, ptr %l165, !tbaa !27
  %t330 = load i64, ptr %l16, !tbaa !24
  %t332 = sub i64 %t330, 1
  %t334 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr i8, ptr %t335, i64 %t332
  %t337 = load i8, ptr %t336, !tbaa !32
  %t339 = icmp eq i8 %t337, 95
  store i1 %t339, ptr %l164, !tbaa !21
  br label %bb98
bb98:
  %t341 = load i1, ptr %l164, !tbaa !21
  br i1 %t341, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l170, !tbaa !21
  br label %bb101
bb100:
  %t342 = load i64, ptr %l16, !tbaa !24
  %t344 = add i64 %t342, 1
  %t345 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t345, 0
  %t350 = icmp eq i64 %t344, %t347
  store i1 %t350, ptr %l170, !tbaa !21
  br label %bb101
bb101:
  %t352 = load i1, ptr %l170, !tbaa !21
  br i1 %t352, label %bb102, label %bb103
bb102:
  %t354 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t354, ptr %rv
  br label %ret
bb103:
  br label %bb104
bb104:
  br label %bb131
bb105:
  %t355 = load i8, ptr %l17, !tbaa !22
  %t357 = call i64 @std_2fprelude_2ftext_2edigitWorth(i8 %t355)
  store i64 %t357, ptr %l178
  br label %bb106
bb106:
  %t358 = load i64, ptr %l178, !tbaa !24
  store i64 %t358, ptr %l18, !tbaa !24
  %t359 = load i64, ptr %l18, !tbaa !24
  %t360 = load i64, ptr %l7, !tbaa !24
  %t363 = icmp sge i64 %t359, %t360
  br i1 %t363, label %bb107, label %bb108
bb107:
  %t366 = insertvalue { i32, i128 } zeroinitializer, i32 65537, 0
  store { i32, i128 } %t366, ptr %rv
  br label %ret
bb108:
  br label %bb109
bb109:
  %t367 = load i64, ptr %l18, !tbaa !24
  %t369 = sext i64 %t367 to i128
  store i128 %t369, ptr %l19
  %t371 = load i1, ptr %l2, !tbaa !21
  br i1 %t371, label %bb110, label %bb111
bb110:
  %t373 = load i128, ptr %l12
  %t374 = load i128, ptr %l10
  %t377 = icmp slt i128 %t373, %t374
  br i1 %t377, label %bb112, label %bb113
bb111:
  %t379 = load i128, ptr %l12
  %t380 = load i128, ptr %l10
  %t383 = icmp sgt i128 %t379, %t380
  br i1 %t383, label %bb121, label %bb122
bb112:
  store i1 true, ptr %l189, !tbaa !21
  br label %bb117
bb113:
  %t385 = load i128, ptr %l12
  %t386 = load i128, ptr %l10
  %t389 = icmp eq i128 %t385, %t386
  br i1 %t389, label %bb114, label %bb115
bb114:
  %t391 = load i128, ptr %l19
  %t393 = sub i128 0, %t391
  %t394 = load i128, ptr %l11
  %t397 = icmp slt i128 %t393, %t394
  store i1 %t397, ptr %l193, !tbaa !21
  br label %bb116
bb115:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb116
bb116:
  %t399 = load i1, ptr %l193, !tbaa !21
  store i1 %t399, ptr %l189, !tbaa !21
  br label %bb117
bb117:
  %t400 = load i1, ptr %l189, !tbaa !21
  br i1 %t400, label %bb118, label %bb119
bb118:
  %t402 = insertvalue { i32, i128 } zeroinitializer, i32 65538, 0
  store { i32, i128 } %t402, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  %t403 = load i128, ptr %l12
  %t404 = load i128, ptr %l8
  %t407 = mul i128 %t403, %t404
  %t408 = load i128, ptr %l19
  %t411 = sub i128 %t407, %t408
  store i128 %t411, ptr %l12
  br label %bb130
bb121:
  store i1 true, ptr %l207, !tbaa !21
  br label %bb126
bb122:
  %t413 = load i128, ptr %l12
  %t414 = load i128, ptr %l10
  %t417 = icmp eq i128 %t413, %t414
  br i1 %t417, label %bb123, label %bb124
bb123:
  %t419 = load i128, ptr %l19
  %t420 = load i128, ptr %l11
  %t423 = icmp sgt i128 %t419, %t420
  store i1 %t423, ptr %l211, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l211, !tbaa !21
  br label %bb125
bb125:
  %t425 = load i1, ptr %l211, !tbaa !21
  store i1 %t425, ptr %l207, !tbaa !21
  br label %bb126
bb126:
  %t426 = load i1, ptr %l207, !tbaa !21
  br i1 %t426, label %bb127, label %bb128
bb127:
  %t428 = insertvalue { i32, i128 } zeroinitializer, i32 65538, 0
  store { i32, i128 } %t428, ptr %rv
  br label %ret
bb128:
  br label %bb129
bb129:
  %t429 = load i128, ptr %l12
  %t430 = load i128, ptr %l8
  %t433 = mul i128 %t429, %t430
  %t434 = load i128, ptr %l19
  %t437 = add i128 %t433, %t434
  store i128 %t437, ptr %l12
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t439 = load i64, ptr %l14, !tbaa !24
  %t441 = add i64 %t439, 1
  store i64 %t441, ptr %l14, !tbaa !24
  br label %bb87
bb132:
  %t443 = load i128, ptr %l12
  %t445 = insertvalue { i32, i128 } zeroinitializer, i128 %t443, 1
  store { i32, i128 } %t445, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i128 }, ptr %rv
  ret { i32, i128 } %rr
}

define dso_local { i32, i32 } @std_2fprelude_2ftext_2eT_2eParse_3cI32_3e(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i32
  %l43 = alloca i1
  %l47 = alloca i1
  %rv = alloca { i32, i32 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  %t15 = icmp eq i8 %t13, 45
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 0
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp eq i8 %t23, 43
  store i1 %t25, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t28, ptr %l18, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t29, 0
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = icmp sge i64 1, 0
  br i1 %t35, label %bb9, label %bb10
bb8:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t38, 0
  store i64 %t41, ptr %l30, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l31, !tbaa !24
  %t44 = icmp sge i64 0, 0
  br i1 %t44, label %bb15, label %bb16
bb9:
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 1, %t46
  br i1 %t47, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_aed6a0dcc67a72aa_b0d7416b4f3011be)
  unreachable
bb11:
  %t49 = load i64, ptr %l21, !tbaa !24
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_aed6a0dcc67a72aa_b0d7416b4f3011be)
  unreachable
bb13:
  %t53 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l21, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 1
  %t57 = sub i64 %t55, 1
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l17, !tbaa !27
  br label %bb21
bb14:
  call void @__olang_check_failed(ptr @olang_loc_aed6a0dcc67a72aa_b0d7416b4f3011be)
  unreachable
bb15:
  %t61 = load i64, ptr %l30, !tbaa !24
  %t62 = icmp sle i64 0, %t61
  br i1 %t62, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_aed6a0dcc67a72aa_b0d7416b4f3011be)
  unreachable
bb17:
  %t64 = load i64, ptr %l30, !tbaa !24
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  br i1 %t66, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_aed6a0dcc67a72aa_b0d7416b4f3011be)
  unreachable
bb19:
  %t68 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l30, !tbaa !24
  %t71 = getelementptr i8, ptr %t69, i64 0
  %t72 = sub i64 %t70, 0
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  store { i64, ptr } %t74, ptr %l17, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_aed6a0dcc67a72aa_b0d7416b4f3011be)
  unreachable
bb21:
  %t76 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t76, ptr %l3, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t81 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t77, i64 %a1)
  %t82 = extractvalue { i32, i64 } %t81, 1
  %t83 = extractvalue { i32, i64 } %t81, 0
  store i32 %t83, ptr %l40
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb23, label %ok.85, !prof !99
ok.85:
  store i64 %t82, ptr %l39
  br label %bb22
bb22:
  %t86 = load i64, ptr %l39, !tbaa !24
  store i64 %t86, ptr %l36, !tbaa !24
  br label %bb24
bb23:
  %t87 = load i32, ptr %l40, !tbaa !23
  %t88 = lshr i32 %t87, 16
  %t89 = and i32 %t87, 65535
  %t90 = icmp eq i32 %t88, 1
  %t91 = select i1 %t90, i32 1, i32 0
  %t92 = icmp eq i32 %t87, 0
  %t93 = shl i32 %t91, 16
  %t94 = or i32 %t93, %t89
  %t95 = select i1 %t92, i32 0, i32 %t94
  %t97 = insertvalue { i32, i32 } zeroinitializer, i32 %t95, 0
  store { i32, i32 } %t97, ptr %rv
  br label %ret
bb24:
  %t98 = load i64, ptr %l36, !tbaa !24
  store i64 %t98, ptr %l4, !tbaa !24
  %t99 = icmp sle i64 4, 8
  br i1 %t99, label %bb25, label %bb26
bb25:
  %t101 = load i64, ptr %l4, !tbaa !24
  %t102 = sext i32 -2147483648 to i64
  %t105 = icmp slt i64 %t101, %t102
  br i1 %t105, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb30
bb27:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb29
bb28:
  %t107 = load i64, ptr %l4, !tbaa !24
  %t108 = sext i32 2147483647 to i64
  %t111 = icmp sgt i64 %t107, %t108
  store i1 %t111, ptr %l47, !tbaa !21
  br label %bb29
bb29:
  %t113 = load i1, ptr %l47, !tbaa !21
  store i1 %t113, ptr %l43, !tbaa !21
  br label %bb30
bb30:
  %t114 = load i1, ptr %l43, !tbaa !21
  br i1 %t114, label %bb31, label %bb32
bb31:
  %t116 = insertvalue { i32, i32 } zeroinitializer, i32 65538, 0
  store { i32, i32 } %t116, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t117 = load i64, ptr %l4, !tbaa !24
  %t119 = trunc i64 %t117 to i32
  %t121 = insertvalue { i32, i32 } zeroinitializer, i32 %t119, 1
  store { i32, i32 } %t121, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2eT_2eParse_3cI64_3e(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i32
  %l43 = alloca i1
  %l46 = alloca i1
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  %t15 = icmp eq i8 %t13, 45
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 0
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp eq i8 %t23, 43
  store i1 %t25, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t28, ptr %l18, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t29, 0
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = icmp sge i64 1, 0
  br i1 %t35, label %bb9, label %bb10
bb8:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t38, 0
  store i64 %t41, ptr %l30, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l31, !tbaa !24
  %t44 = icmp sge i64 0, 0
  br i1 %t44, label %bb15, label %bb16
bb9:
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 1, %t46
  br i1 %t47, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3e9148f9e0e46869_5b7400af9745fccd)
  unreachable
bb11:
  %t49 = load i64, ptr %l21, !tbaa !24
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3e9148f9e0e46869_5b7400af9745fccd)
  unreachable
bb13:
  %t53 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l21, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 1
  %t57 = sub i64 %t55, 1
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l17, !tbaa !27
  br label %bb21
bb14:
  call void @__olang_check_failed(ptr @olang_loc_3e9148f9e0e46869_5b7400af9745fccd)
  unreachable
bb15:
  %t61 = load i64, ptr %l30, !tbaa !24
  %t62 = icmp sle i64 0, %t61
  br i1 %t62, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_3e9148f9e0e46869_5b7400af9745fccd)
  unreachable
bb17:
  %t64 = load i64, ptr %l30, !tbaa !24
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  br i1 %t66, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_3e9148f9e0e46869_5b7400af9745fccd)
  unreachable
bb19:
  %t68 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l30, !tbaa !24
  %t71 = getelementptr i8, ptr %t69, i64 0
  %t72 = sub i64 %t70, 0
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  store { i64, ptr } %t74, ptr %l17, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_3e9148f9e0e46869_5b7400af9745fccd)
  unreachable
bb21:
  %t76 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t76, ptr %l3, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t81 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t77, i64 %a1)
  %t82 = extractvalue { i32, i64 } %t81, 1
  %t83 = extractvalue { i32, i64 } %t81, 0
  store i32 %t83, ptr %l40
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb23, label %ok.85, !prof !99
ok.85:
  store i64 %t82, ptr %l39
  br label %bb22
bb22:
  %t86 = load i64, ptr %l39, !tbaa !24
  store i64 %t86, ptr %l36, !tbaa !24
  br label %bb24
bb23:
  %t87 = load i32, ptr %l40, !tbaa !23
  %t88 = lshr i32 %t87, 16
  %t89 = and i32 %t87, 65535
  %t90 = icmp eq i32 %t88, 1
  %t91 = select i1 %t90, i32 1, i32 0
  %t92 = icmp eq i32 %t87, 0
  %t93 = shl i32 %t91, 16
  %t94 = or i32 %t93, %t89
  %t95 = select i1 %t92, i32 0, i32 %t94
  %t97 = insertvalue { i32, i64 } zeroinitializer, i32 %t95, 0
  store { i32, i64 } %t97, ptr %rv
  br label %ret
bb24:
  %t98 = load i64, ptr %l36, !tbaa !24
  store i64 %t98, ptr %l4, !tbaa !24
  %t99 = icmp sle i64 8, 8
  br i1 %t99, label %bb25, label %bb26
bb25:
  %t101 = load i64, ptr %l4, !tbaa !24
  %t103 = icmp slt i64 %t101, -9223372036854775808
  br i1 %t103, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb30
bb27:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb29
bb28:
  %t105 = load i64, ptr %l4, !tbaa !24
  %t107 = icmp sgt i64 %t105, 9223372036854775807
  store i1 %t107, ptr %l46, !tbaa !21
  br label %bb29
bb29:
  %t109 = load i1, ptr %l46, !tbaa !21
  store i1 %t109, ptr %l43, !tbaa !21
  br label %bb30
bb30:
  %t110 = load i1, ptr %l43, !tbaa !21
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t112, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t113 = load i64, ptr %l4, !tbaa !24
  %t115 = insertvalue { i32, i64 } zeroinitializer, i64 %t113, 1
  store { i32, i64 } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, i8 } @std_2fprelude_2ftext_2eT_2eParse_3cU8_3e(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i32
  %l45 = alloca i1
  %rv = alloca { i32, i8 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t8 = insertvalue { i32, i8 } zeroinitializer, i32 65536, 0
  store { i32, i8 } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  %t15 = icmp eq i8 %t13, 45
  store i1 %t15, ptr %l2, !tbaa !21
  %t17 = load i1, ptr %l2, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 0
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp eq i8 %t23, 43
  store i1 %t25, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t28, ptr %l18, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t29, 0
  store i64 %t32, ptr %l21, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l22, !tbaa !24
  %t35 = icmp sge i64 1, 0
  br i1 %t35, label %bb9, label %bb10
bb8:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t38, 0
  store i64 %t41, ptr %l30, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l31, !tbaa !24
  %t44 = icmp sge i64 0, 0
  br i1 %t44, label %bb15, label %bb16
bb9:
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 1, %t46
  br i1 %t47, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_ca892011aac17b75_e14eaf889df4b399)
  unreachable
bb11:
  %t49 = load i64, ptr %l21, !tbaa !24
  %t50 = load i64, ptr %l22, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_ca892011aac17b75_e14eaf889df4b399)
  unreachable
bb13:
  %t53 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l21, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 1
  %t57 = sub i64 %t55, 1
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l17, !tbaa !27
  br label %bb21
bb14:
  call void @__olang_check_failed(ptr @olang_loc_ca892011aac17b75_e14eaf889df4b399)
  unreachable
bb15:
  %t61 = load i64, ptr %l30, !tbaa !24
  %t62 = icmp sle i64 0, %t61
  br i1 %t62, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_ca892011aac17b75_e14eaf889df4b399)
  unreachable
bb17:
  %t64 = load i64, ptr %l30, !tbaa !24
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  br i1 %t66, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_ca892011aac17b75_e14eaf889df4b399)
  unreachable
bb19:
  %t68 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l30, !tbaa !24
  %t71 = getelementptr i8, ptr %t69, i64 0
  %t72 = sub i64 %t70, 0
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  store { i64, ptr } %t74, ptr %l17, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ca892011aac17b75_e14eaf889df4b399)
  unreachable
bb21:
  %t76 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t76, ptr %l3, !tbaa !27
  %t77 = load i1, ptr %l2, !tbaa !21
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t80 = insertvalue { i32, i8 } zeroinitializer, i32 65537, 0
  store { i32, i8 } %t80, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t81 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t85 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t81, i64 %a1)
  %t86 = extractvalue { i32, i64 } %t85, 1
  %t87 = extractvalue { i32, i64 } %t85, 0
  store i32 %t87, ptr %l42
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb26, label %ok.89, !prof !99
ok.89:
  store i64 %t86, ptr %l41
  br label %bb25
bb25:
  %t90 = load i64, ptr %l41, !tbaa !65
  store i64 %t90, ptr %l38, !tbaa !65
  br label %bb27
bb26:
  %t91 = load i32, ptr %l42, !tbaa !23
  %t92 = lshr i32 %t91, 16
  %t93 = and i32 %t91, 65535
  %t94 = icmp eq i32 %t92, 1
  %t95 = select i1 %t94, i32 1, i32 0
  %t96 = icmp eq i32 %t91, 0
  %t97 = shl i32 %t95, 16
  %t98 = or i32 %t97, %t93
  %t99 = select i1 %t96, i32 0, i32 %t98
  %t101 = insertvalue { i32, i8 } zeroinitializer, i32 %t99, 0
  store { i32, i8 } %t101, ptr %rv
  br label %ret
bb27:
  %t102 = load i64, ptr %l38, !tbaa !65
  store i64 %t102, ptr %l4, !tbaa !65
  %t103 = icmp sle i64 1, 8
  br i1 %t103, label %bb28, label %bb29
bb28:
  %t105 = load i64, ptr %l4, !tbaa !65
  %t106 = zext i8 -1 to i64
  %t109 = icmp ugt i64 %t105, %t106
  store i1 %t109, ptr %l45, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb30
bb30:
  %t111 = load i1, ptr %l45, !tbaa !21
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t113 = insertvalue { i32, i8 } zeroinitializer, i32 65538, 0
  store { i32, i8 } %t113, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t114 = load i64, ptr %l4, !tbaa !65
  %t116 = trunc i64 %t114 to i8
  %t118 = insertvalue { i32, i8 } zeroinitializer, i8 %t116, 1
  store { i32, i8 } %t118, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i8 }, ptr %rv
  ret { i32, i8 } %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i32, { i64, ptr } } @std_2fio_2estd_2fio_3asource_2eword(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i1 } @std_2fprelude_2ftext_2eBool_2eParse(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
@olang_loc_8de27d6f5cb8b5a8_575e8481497d3ea4 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %a0)
declare { i32, i128 } @std_2fprelude_2ftext_2ereadWide(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i64 @std_2fprelude_2ftext_2edigitWorth(i8 %a0)
@olang_loc_aed6a0dcc67a72aa_b0d7416b4f3011be = external constant [0 x i8]
@olang_loc_3e9148f9e0e46869_5b7400af9745fccd = external constant [0 x i8]
@olang_loc_ca892011aac17b75_e14eaf889df4b399 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
