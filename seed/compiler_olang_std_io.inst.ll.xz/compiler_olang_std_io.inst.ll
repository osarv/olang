; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
define dso_local i32 @olang_2eslot_2eI32_7cstd_2fio_3aDescriptor_2e0(ptr %v0, ptr %a0) #0 {
entry:
  %l3 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = load i32, ptr %a0, !tbaa !23
  %t5 = call i32 @std_2fprelude_2finput_2eI32_2eFd(i32 %t3)
  store i32 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i32, ptr %l3, !tbaa !23
  store i32 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i1 } @std_2fio_2estd_2fio_3aReader_2eNext_3cBool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l7 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i1 }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aReader_2eWord(ptr %v0, ptr %s0, ptr %a0)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t10, 2
  %t15 = select i1 %t14, i32 2, i32 %t13
  %t16 = icmp eq i32 %t9, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t11
  %t19 = select i1 %t16, i32 0, i32 %t18
  call void @__olang_scope_close(ptr %s0)
  %t21 = insertvalue { i32, i1 } zeroinitializer, i32 %t19, 0
  store { i32, i1 } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = call { i32, i1 } @std_2fprelude_2ftext_2eBool_2eParse(ptr %s0, { i64, ptr } %t22)
  %t26 = extractvalue { i32, i1 } %t25, 1
  %t27 = extractvalue { i32, i1 } %t25, 0
  store i32 %t27, ptr %l10
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb5, label %ok.29, !prof !99
ok.29:
  store i1 %t26, ptr %l9
  br label %bb4
bb4:
  %t30 = load i1, ptr %l9, !tbaa !21
  store i1 %t30, ptr %l7, !tbaa !21
  br label %bb6
bb5:
  %t31 = load i32, ptr %l10, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 3, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  call void @__olang_scope_close(ptr %s0)
  %t41 = insertvalue { i32, i1 } zeroinitializer, i32 %t39, 0
  store { i32, i1 } %t41, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load i1, ptr %l7, !tbaa !21
  %t43 = insertvalue { i32, i1 } zeroinitializer, i1 %t42, 1
  store { i32, i1 } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local { i32, float } @std_2fio_2estd_2fio_3aReader_2eNext_3cF32_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l7 = alloca float
  %l9 = alloca float
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, float }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aReader_2eWord(ptr %v0, ptr %s0, ptr %a0)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t10, 2
  %t15 = select i1 %t14, i32 2, i32 %t13
  %t16 = icmp eq i32 %t9, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t11
  %t19 = select i1 %t16, i32 0, i32 %t18
  call void @__olang_scope_close(ptr %s0)
  %t21 = insertvalue { i32, float } zeroinitializer, i32 %t19, 0
  store { i32, float } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = call { i32, float } @std_2fprelude_2ftext_2eT_2eParse_3cF32_3e(ptr %s0, { i64, ptr } %t22)
  %t26 = extractvalue { i32, float } %t25, 1
  %t27 = extractvalue { i32, float } %t25, 0
  store i32 %t27, ptr %l10
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb5, label %ok.29, !prof !99
ok.29:
  store float %t26, ptr %l9
  br label %bb4
bb4:
  %t30 = load float, ptr %l9, !tbaa !25
  store float %t30, ptr %l7, !tbaa !25
  br label %bb6
bb5:
  %t31 = load i32, ptr %l10, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 3, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  call void @__olang_scope_close(ptr %s0)
  %t41 = insertvalue { i32, float } zeroinitializer, i32 %t39, 0
  store { i32, float } %t41, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load float, ptr %l7, !tbaa !25
  %t43 = insertvalue { i32, float } zeroinitializer, float %t42, 1
  store { i32, float } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i32, float }, ptr %rv
  ret { i32, float } %rr
}

define dso_local { i32, double } @std_2fio_2estd_2fio_3aReader_2eNext_3cF64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l7 = alloca double
  %l9 = alloca double
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, double }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aReader_2eWord(ptr %v0, ptr %s0, ptr %a0)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t10, 2
  %t15 = select i1 %t14, i32 2, i32 %t13
  %t16 = icmp eq i32 %t9, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t11
  %t19 = select i1 %t16, i32 0, i32 %t18
  call void @__olang_scope_close(ptr %s0)
  %t21 = insertvalue { i32, double } zeroinitializer, i32 %t19, 0
  store { i32, double } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = call { i32, double } @std_2fprelude_2ftext_2eT_2eParse_3cF64_3e(ptr %s0, { i64, ptr } %t22)
  %t26 = extractvalue { i32, double } %t25, 1
  %t27 = extractvalue { i32, double } %t25, 0
  store i32 %t27, ptr %l10
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb5, label %ok.29, !prof !99
ok.29:
  store double %t26, ptr %l9
  br label %bb4
bb4:
  %t30 = load double, ptr %l9, !tbaa !26
  store double %t30, ptr %l7, !tbaa !26
  br label %bb6
bb5:
  %t31 = load i32, ptr %l10, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 3, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  call void @__olang_scope_close(ptr %s0)
  %t41 = insertvalue { i32, double } zeroinitializer, i32 %t39, 0
  store { i32, double } %t41, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load double, ptr %l7, !tbaa !26
  %t43 = insertvalue { i32, double } zeroinitializer, double %t42, 1
  store { i32, double } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local { i32, float } @std_2fprelude_2ftext_2eT_2eParse_3cF32_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca double
  %l2 = alloca float
  %l3 = alloca double
  %l5 = alloca double
  %l6 = alloca i32
  %l13 = alloca i1
  %l18 = alloca i1
  %rv = alloca { i32, float }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, double } %t3, 1
  %t5 = extractvalue { i32, double } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store double %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load double, ptr %l5, !tbaa !26
  store double %t8, ptr %l3, !tbaa !26
  br label %bb3
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, float } zeroinitializer, i32 %t17, 0
  store { i32, float } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load double, ptr %l3, !tbaa !26
  store double %t20, ptr %l1, !tbaa !26
  %t21 = load double, ptr %l1, !tbaa !26
  %t23 = fptrunc double %t21 to float
  store float %t23, ptr %l2, !tbaa !25
  %t25 = load double, ptr %l1, !tbaa !26
  %t26 = load double, ptr %l1, !tbaa !26
  %t29 = fcmp oeq double %t25, %t26
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t31 = load double, ptr %l1, !tbaa !26
  %t32 = load double, ptr %l1, !tbaa !26
  %t35 = fsub double %t31, %t32
  %t37 = fcmp oeq double %t35, 0x0000000000000000
  store i1 %t37, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t39 = load i1, ptr %l13, !tbaa !21
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t40 = load float, ptr %l2, !tbaa !25
  %t41 = load float, ptr %l2, !tbaa !25
  %t44 = fsub float %t40, %t41
  %t46 = fcmp une float %t44, 0x0000000000000000
  store i1 %t46, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l18, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = insertvalue { i32, float } zeroinitializer, i32 65538, 0
  store { i32, float } %t50, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t51 = load float, ptr %l2, !tbaa !25
  %t53 = insertvalue { i32, float } zeroinitializer, float %t51, 1
  store { i32, float } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i32, float }, ptr %rv
  ret { i32, float } %rr
}

define dso_local { i32, double } @std_2fprelude_2ftext_2eT_2eParse_3cF64_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca double
  %l2 = alloca double
  %l3 = alloca double
  %l5 = alloca double
  %l6 = alloca i32
  %l12 = alloca i1
  %l17 = alloca i1
  %rv = alloca { i32, double }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
  %t4 = extractvalue { i32, double } %t3, 1
  %t5 = extractvalue { i32, double } %t3, 0
  store i32 %t5, ptr %l6
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store double %t4, ptr %l5
  br label %bb1
bb1:
  %t8 = load double, ptr %l5, !tbaa !26
  store double %t8, ptr %l3, !tbaa !26
  br label %bb3
bb2:
  %t9 = load i32, ptr %l6, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, double } zeroinitializer, i32 %t17, 0
  store { i32, double } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load double, ptr %l3, !tbaa !26
  store double %t20, ptr %l1, !tbaa !26
  %t21 = load double, ptr %l1, !tbaa !26
  store double %t21, ptr %l2, !tbaa !26
  %t23 = load double, ptr %l1, !tbaa !26
  %t24 = load double, ptr %l1, !tbaa !26
  %t27 = fcmp oeq double %t23, %t24
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load double, ptr %l1, !tbaa !26
  %t30 = load double, ptr %l1, !tbaa !26
  %t33 = fsub double %t29, %t30
  %t35 = fcmp oeq double %t33, 0x0000000000000000
  store i1 %t35, ptr %l12, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t37 = load i1, ptr %l12, !tbaa !21
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t38 = load double, ptr %l2, !tbaa !26
  %t39 = load double, ptr %l2, !tbaa !26
  %t42 = fsub double %t38, %t39
  %t44 = fcmp une double %t42, 0x0000000000000000
  store i1 %t44, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l17, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = insertvalue { i32, double } zeroinitializer, i32 65538, 0
  store { i32, double } %t48, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t49 = load double, ptr %l2, !tbaa !26
  %t51 = insertvalue { i32, double } zeroinitializer, double %t49, 1
  store { i32, double } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i32 @std_2fprelude_2finput_2eI32_2eFd(i32 %a0)
declare { i32, { i64, ptr } } @std_2fio_2estd_2fio_3aReader_2eWord(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i1 } @std_2fprelude_2ftext_2eBool_2eParse(ptr %v0, { i64, ptr } %a0)
declare { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
