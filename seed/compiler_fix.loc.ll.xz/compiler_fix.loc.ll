; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_299e69389bcee8f2_b185402659ea7d46 = weak_odr constant [51 x i8] c"compiler/fix.olang:165: slice bounds out of range\0A\00"
@olang_loc_8fcf87cfa7be21dd_bbd76dac3520f231 = weak_odr constant [51 x i8] c"compiler/fix.olang:103: array length out of range\0A\00"
@olang_loc_9433da86f750b978_3ff5b65d50af9d4 = weak_odr constant [50 x i8] c"compiler/fix.olang:66: array length out of range\0A\00"
