; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
@G_2estd_2fprelude_2fnumber_2eEuler = global double zeroinitializer
@G_2estd_2fprelude_2fnumber_2eInf = global double zeroinitializer
@G_2estd_2fprelude_2fnumber_2eNaN = global double zeroinitializer
@G_2estd_2fprelude_2fnumber_2ePi = global double zeroinitializer
define dso_local void @olang_2einit_2estd_2fprelude_2fnumber() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @std_2fprelude_2fnumber_2ePi_2einit()
  br label %bb1
bb1:
  call void @std_2fprelude_2fnumber_2eEuler_2einit()
  br label %bb2
bb2:
  call void @std_2fprelude_2fnumber_2eInf_2einit()
  br label %bb3
bb3:
  call void @std_2fprelude_2fnumber_2eNaN_2einit()
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fnumber_2eEuler_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store double 0x4005bf0a8b145769, ptr @G_2estd_2fprelude_2fnumber_2eEuler
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fnumber_2eInf_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store double 0x7ff0000000000000, ptr @G_2estd_2fprelude_2fnumber_2eInf
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fnumber_2eNaN_2einit() #0 {
entry:
  %l0 = alloca double
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = bitcast i64 9221120237041090560 to double
  store double %t1, ptr %l0
  %t2 = load double, ptr %l0
  store double %t2, ptr @G_2estd_2fprelude_2fnumber_2eNaN
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fnumber_2ePi_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store double 0x400921fb54442d18, ptr @G_2estd_2fprelude_2fnumber_2ePi
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare void @__olang_scope_close(ptr)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
