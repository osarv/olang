; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
@G_2estd_2fprelude_2fnumber_2eEuler = constant <{ [8 x i8] }> <{ [8 x i8] c"\69\57\14\8B\0A\BF\05\40" }>, align 8
@G_2estd_2fprelude_2fnumber_2eInf = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\F0\7F" }>, align 8
@G_2estd_2fprelude_2fnumber_2eNaN = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\F8\7F" }>, align 8
@G_2estd_2fprelude_2fnumber_2ePi = constant <{ [8 x i8] }> <{ [8 x i8] c"\18\2D\44\54\FB\21\09\40" }>, align 8
define dso_local void @olang_2einit_2estd_2fprelude_2fnumber() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @std_2fprelude_2fnumber_2ePi_2einit()
  br label %bb1
bb1:
  call void @std_2fprelude_2fnumber_2eEuler_2einit()
  br label %bb2
bb2:
  call void @std_2fprelude_2fnumber_2eInf_2einit()
  br label %bb3
bb3:
  call void @std_2fprelude_2fnumber_2eNaN_2einit()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fnumber_2eEuler_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x4005bf0a8b145769, ptr @G_2estd_2fprelude_2fnumber_2eEuler, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local { i32, i16 } @std_2fprelude_2fnumber_2eI16_2eSqrt(i16 %a0) #0 {
entry:
  %l0 = alloca i16
  %l6 = alloca i64
  %rv = alloca { i32, i16 }
  store i16 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i16, ptr %l0, !tbaa !62
  %t3 = icmp slt i16 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t6 = insertvalue { i32, i16 } zeroinitializer, i32 65536, 0
  store { i32, i16 } %t6, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load i16, ptr %l0, !tbaa !62
  %t9 = sext i16 %t7 to i64
  %t11 = call i64 @std_2fprelude_2fnumber_2esqrtU64(i64 %t9)
  store i64 %t11, ptr %l6
  br label %bb4
bb4:
  %t12 = load i64, ptr %l6, !tbaa !65
  %t13 = trunc i64 %t12 to i16
  %t15 = insertvalue { i32, i16 } zeroinitializer, i16 %t13, 1
  store { i32, i16 } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i16 }, ptr %rv
  ret { i32, i16 } %rr
}

define dso_local { i32, i32 } @std_2fprelude_2fnumber_2eI32_2eSqrt(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l6 = alloca i64
  %rv = alloca { i32, i32 }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t6 = insertvalue { i32, i32 } zeroinitializer, i32 65536, 0
  store { i32, i32 } %t6, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load i32, ptr %l0, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t11 = call i64 @std_2fprelude_2fnumber_2esqrtU64(i64 %t9)
  store i64 %t11, ptr %l6
  br label %bb4
bb4:
  %t12 = load i64, ptr %l6, !tbaa !65
  %t13 = trunc i64 %t12 to i32
  %t15 = insertvalue { i32, i32 } zeroinitializer, i32 %t13, 1
  store { i32, i32 } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2fnumber_2eI64_2eSqrt(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l6 = alloca i64
  %rv = alloca { i32, i64 }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t6 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t6, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load i64, ptr %l0, !tbaa !24
  %t10 = call i64 @std_2fprelude_2fnumber_2esqrtU64(i64 %t7)
  store i64 %t10, ptr %l6
  br label %bb4
bb4:
  %t11 = load i64, ptr %l6, !tbaa !65
  %t13 = insertvalue { i32, i64 } zeroinitializer, i64 %t11, 1
  store { i32, i64 } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, i8 } @std_2fprelude_2fnumber_2eI8_2eSqrt(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l6 = alloca i64
  %rv = alloca { i32, i8 }
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !61
  %t3 = icmp slt i8 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t6 = insertvalue { i32, i8 } zeroinitializer, i32 65536, 0
  store { i32, i8 } %t6, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load i8, ptr %l0, !tbaa !61
  %t9 = sext i8 %t7 to i64
  %t11 = call i64 @std_2fprelude_2fnumber_2esqrtU64(i64 %t9)
  store i64 %t11, ptr %l6
  br label %bb4
bb4:
  %t12 = load i64, ptr %l6, !tbaa !65
  %t13 = trunc i64 %t12 to i8
  %t15 = insertvalue { i32, i8 } zeroinitializer, i8 %t13, 1
  store { i32, i8 } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i8 }, ptr %rv
  ret { i32, i8 } %rr
}

define dso_local void @std_2fprelude_2fnumber_2eInf_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x7ff0000000000000, ptr @G_2estd_2fprelude_2fnumber_2eInf, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fnumber_2eNaN_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = bitcast i64 9221120237041090560 to double
  store double %t1, ptr @G_2estd_2fprelude_2fnumber_2eNaN, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fnumber_2ePi_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x400921fb54442d18, ptr @G_2estd_2fprelude_2fnumber_2ePi, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local i16 @std_2fprelude_2fnumber_2eU16_2eSqrt(i16 %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i16
  br label %start
start:
  br label %bb0
bb0:
  %t3 = zext i16 %a0 to i64
  %t5 = call i64 @std_2fprelude_2fnumber_2esqrtU64(i64 %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !65
  %t7 = trunc i64 %t6 to i16
  store i16 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i16, ptr %rv
  ret i16 %rr
}

define dso_local i32 @std_2fprelude_2fnumber_2eU32_2eSqrt(i32 %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = zext i32 %a0 to i64
  %t5 = call i64 @std_2fprelude_2fnumber_2esqrtU64(i64 %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !65
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @std_2fprelude_2fnumber_2eU64_2eSqrt(i64 %a0) #0 {
entry:
  %l2 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i64 @std_2fprelude_2fnumber_2esqrtU64(i64 %a0)
  store i64 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i64, ptr %l2, !tbaa !65
  store i64 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i8 @std_2fprelude_2fnumber_2eU8_2eSqrt(i8 %a0) #0 {
entry:
  %l3 = alloca i64
  %rv = alloca i8
  br label %start
start:
  br label %bb0
bb0:
  %t3 = zext i8 %a0 to i64
  %t5 = call i64 @std_2fprelude_2fnumber_2esqrtU64(i64 %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load i64, ptr %l3, !tbaa !65
  %t7 = trunc i64 %t6 to i8
  store i8 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local i64 @std_2fprelude_2fnumber_2esqrtU64(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l7 = alloca double
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !65
  %t3 = icmp ult i64 %t1, 2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !65
  store i64 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load i64, ptr %l0, !tbaa !65
  %t9 = uitofp i64 %t7 to double
  %t11 = call double @llvm.sqrt.f64(double %t9)
  store double %t11, ptr %l7
  br label %bb4
bb4:
  %t12 = load double, ptr %l7, !tbaa !26
  %t13 = fptoui double %t12 to i64
  store i64 %t13, ptr %l1, !tbaa !65
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l1, !tbaa !65
  %t16 = load i64, ptr %l0, !tbaa !65
  %t17 = load i64, ptr %l1, !tbaa !65
  %t20 = udiv i64 %t16, %t17
  %t23 = icmp ugt i64 %t15, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t27 = load i64, ptr %l1, !tbaa !65
  %t29 = sub i64 %t27, 1
  store i64 %t29, ptr %l1, !tbaa !65
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  br label %bb5
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l1, !tbaa !65
  %t33 = add i64 %t31, 1
  %t34 = load i64, ptr %l0, !tbaa !65
  %t35 = load i64, ptr %l1, !tbaa !65
  %t37 = add i64 %t35, 1
  %t40 = udiv i64 %t34, %t37
  %t43 = icmp ule i64 %t33, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l1, !tbaa !65
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l1, !tbaa !65
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  br label %bb11
bb16:
  %t51 = load i64, ptr %l1, !tbaa !65
  store i64 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare double @llvm.sqrt.f64(double)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
