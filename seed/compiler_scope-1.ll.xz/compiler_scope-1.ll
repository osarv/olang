; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/scope:walked" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/typed:Plan", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, [2 x i64] }, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:rel" = type { { i64, [2 x i64] }, { i64, [2 x i64] }, i1, %"compiler/source:Span", i64, i1 }
%"compiler/scope:summary" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/scope:Val" = type { i32, { i64, [2 x i64] } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/scope:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/scope:fnUse" = type { i64, %"compiler/source:Span", i64, i64, i32 }
%"compiler/scope:markRead" = type { i64, i64, { i64, [1 x i64] } }
define dso_local void @compiler_2fscope_2ecollectStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca i64
  %l53 = alloca ptr
  %l55 = alloca i64
  %l57 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i64
  %l64 = alloca ptr
  %l66 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i1
  %l185 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca i1
  %l207 = alloca { i64, ptr }
  %l213 = alloca i64
  %l216 = alloca ptr
  %l218 = alloca i64
  %l220 = alloca i1
  %l222 = alloca i1
  %l224 = alloca i64
  %l227 = alloca ptr
  %l229 = alloca i64
  %l249 = alloca { i64, ptr }
  %l257 = alloca ptr
  %l258 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t6 = load ptr, ptr %l32, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l32, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 17}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l33, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l33, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t22)
  br label %bb9
bb9:
  br label %bb166
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t26 = load ptr, ptr %l41, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l41, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 17}
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l42, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l42, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb35
bb15:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l50
  br label %bb16
bb16:
  %t49 = load i64, ptr %l50, !tbaa !24
  %t50 = icmp sge i64 %t49, 0
  br i1 %t50, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/scope:walked", ptr %t52, i32 0, i32 1
  store ptr %t54, ptr %l53, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %t55)
  store i64 %t57, ptr %l55
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l53, !tbaa !29
  %t59 = load i64, ptr %l55, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t58, i64 %t59)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %t60)
  store i1 %t62, ptr %l57
  br label %bb22
bb22:
  %t63 = load i1, ptr %l57, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb23, label %bb24
bb23:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l61
  br label %bb25
bb24:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb26
bb25:
  %t69 = load i64, ptr %l61, !tbaa !24
  %t70 = icmp sge i64 %t69, 0
  store i1 %t70, ptr %l59, !tbaa !21
  br label %bb26
bb26:
  %t72 = load i1, ptr %l59, !tbaa !21
  br i1 %t72, label %bb27, label %bb28
bb27:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/scope:walked", ptr %t73, i32 0, i32 4
  store ptr %t75, ptr %l64, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t76)
  store i64 %t78, ptr %l66
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t79 = load ptr, ptr %l64, !tbaa !29
  %t80 = load i64, ptr %l66, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t79, i64 %t80)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectField(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  br label %bb32
bb32:
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %t85, ptr %t87)
  br label %bb33
bb33:
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t90, ptr %t92)
  br label %bb34
bb34:
  br label %bb166
bb35:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t96 = load ptr, ptr %l75, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load ptr, ptr %l75, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 17}
  %t102 = icmp eq i64 %t100, 2
  store i1 %t102, ptr %l76, !tbaa !21
  br label %bb37
bb37:
  %t103 = load i1, ptr %l76, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr { i64, [3 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", ptr }, ptr %t106, i32 0, i32 1
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l5, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t110 = load ptr, ptr %l5, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t110, ptr %t112)
  br label %bb41
bb41:
  br label %bb166
bb42:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t116 = load ptr, ptr %l84, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb43, label %bb44
bb43:
  %t119 = load ptr, ptr %l84, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 17}
  %t122 = icmp eq i64 %t120, 3
  store i1 %t122, ptr %l85, !tbaa !21
  br label %bb44
bb44:
  %t123 = load i1, ptr %l85, !tbaa !21
  br i1 %t123, label %bb45, label %bb46
bb45:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", ptr }, ptr %t126, i32 0, i32 1
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l6, !tbaa !29
  br label %bb47
bb46:
  br label %bb51
bb47:
  %t130 = load ptr, ptr %l6, !tbaa !29
  %t132 = getelementptr %"compiler/typed:If", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t133, ptr %t135)
  br label %bb48
bb48:
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t140 = getelementptr %"compiler/typed:If", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t141, ptr %t143)
  br label %bb49
bb49:
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t148 = getelementptr %"compiler/typed:If", ptr %t146, i32 0, i32 2
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t149, ptr %t150)
  br label %bb50
bb50:
  br label %bb166
bb51:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t154 = load ptr, ptr %l101, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb52, label %bb53
bb52:
  %t157 = load ptr, ptr %l101, !tbaa !29
  %t158 = load i64, ptr %t157, !range !{i64 0, i64 17}
  %t160 = icmp eq i64 %t158, 4
  store i1 %t160, ptr %l102, !tbaa !21
  br label %bb53
bb53:
  %t161 = load i1, ptr %l102, !tbaa !21
  br i1 %t161, label %bb54, label %bb55
bb54:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr { i64, [3 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t164, i32 0, i32 1
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l7, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l8, !tbaa !29
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t174 = load ptr, ptr %l7, !tbaa !29
  %t176 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t174, ptr %t176)
  br label %bb57
bb57:
  %t179 = load ptr, ptr %l8, !tbaa !29
  %t180 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  br label %bb58
bb58:
  br label %bb166
bb59:
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t184 = load ptr, ptr %l114, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb60, label %bb61
bb60:
  %t187 = load ptr, ptr %l114, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 17}
  %t190 = icmp eq i64 %t188, 6
  store i1 %t190, ptr %l115, !tbaa !21
  br label %bb61
bb61:
  %t191 = load i1, ptr %l115, !tbaa !21
  br i1 %t191, label %bb62, label %bb63
bb62:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l9, !tbaa !29
  br label %bb68
bb63:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t199 = load ptr, ptr %l120, !tbaa !29
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %bb64, label %bb65
bb64:
  %t202 = load ptr, ptr %l120, !tbaa !29
  %t203 = load i64, ptr %t202, !range !{i64 0, i64 17}
  %t205 = icmp eq i64 %t203, 16
  store i1 %t205, ptr %l121, !tbaa !21
  br label %bb65
bb65:
  %t206 = load i1, ptr %l121, !tbaa !21
  br i1 %t206, label %bb66, label %bb67
bb66:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr { i64, [3 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", ptr }, ptr %t209, i32 0, i32 1
  %t211 = load ptr, ptr %t210
  store ptr %t211, ptr %l9, !tbaa !29
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t213 = load ptr, ptr %l9, !tbaa !29
  %t214 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t213, ptr %t214)
  br label %bb69
bb69:
  br label %bb166
bb70:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t218 = load ptr, ptr %l128, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb71, label %bb72
bb71:
  %t221 = load ptr, ptr %l128, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 17}
  %t224 = icmp eq i64 %t222, 10
  store i1 %t224, ptr %l129, !tbaa !21
  br label %bb72
bb72:
  %t225 = load i1, ptr %l129, !tbaa !21
  br i1 %t225, label %bb73, label %bb74
bb73:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t228, i32 0, i32 1
  %t230 = load ptr, ptr %t229
  store ptr %t230, ptr %l10, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr { i64, [3 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t234, i32 0, i32 2
  %t236 = load ptr, ptr %t235
  store ptr %t236, ptr %l11, !tbaa !29
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t238 = load ptr, ptr %l10, !tbaa !29
  %t240 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t238, ptr %t240)
  br label %bb76
bb76:
  %t243 = load ptr, ptr %l11, !tbaa !29
  %t244 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t243, ptr %t244)
  br label %bb77
bb77:
  br label %bb166
bb78:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t248 = load ptr, ptr %l141, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb79, label %bb80
bb79:
  %t251 = load ptr, ptr %l141, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 17}
  %t254 = icmp eq i64 %t252, 9
  store i1 %t254, ptr %l142, !tbaa !21
  br label %bb80
bb80:
  %t255 = load i1, ptr %l142, !tbaa !21
  br i1 %t255, label %bb81, label %bb82
bb81:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 2
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l12, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t262 = load ptr, ptr %l12, !tbaa !29
  %t263 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t262, ptr %t263)
  br label %bb84
bb84:
  br label %bb166
bb85:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t267 = load ptr, ptr %l149, !tbaa !29
  %t268 = icmp ne ptr %t267, null
  br i1 %t268, label %bb86, label %bb87
bb86:
  %t270 = load ptr, ptr %l149, !tbaa !29
  %t271 = load i64, ptr %t270, !range !{i64 0, i64 17}
  %t273 = icmp eq i64 %t271, 11
  store i1 %t273, ptr %l150, !tbaa !21
  br label %bb87
bb87:
  %t274 = load i1, ptr %l150, !tbaa !21
  br i1 %t274, label %bb88, label %bb89
bb88:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", ptr }, ptr %t277, i32 0, i32 1
  %t279 = load ptr, ptr %t278
  store ptr %t279, ptr %l13, !tbaa !29
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t281 = load ptr, ptr %l13, !tbaa !29
  %t283 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t281, ptr %t283)
  br label %bb91
bb91:
  br label %bb166
bb92:
  %t286 = load ptr, ptr %l0, !tbaa !29
  store ptr %t286, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t287 = load ptr, ptr %l158, !tbaa !29
  %t288 = icmp ne ptr %t287, null
  br i1 %t288, label %bb93, label %bb94
bb93:
  %t290 = load ptr, ptr %l158, !tbaa !29
  %t291 = load i64, ptr %t290, !range !{i64 0, i64 17}
  %t293 = icmp eq i64 %t291, 12
  store i1 %t293, ptr %l159, !tbaa !21
  br label %bb94
bb94:
  %t294 = load i1, ptr %l159, !tbaa !21
  br i1 %t294, label %bb95, label %bb96
bb95:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr { i64, [3 x i64] }, ptr %t295, i32 0, i32 1
  %t298 = getelementptr { %"compiler/source:Span", ptr }, ptr %t297, i32 0, i32 1
  %t299 = load ptr, ptr %t298
  store ptr %t299, ptr %l14, !tbaa !29
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t301 = load ptr, ptr %l14, !tbaa !29
  %t303 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t301, ptr %t303)
  br label %bb98
bb98:
  br label %bb166
bb99:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l167, !tbaa !29
  store i1 false, ptr %l168, !tbaa !21
  %t307 = load ptr, ptr %l167, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb100, label %bb101
bb100:
  %t310 = load ptr, ptr %l167, !tbaa !29
  %t311 = load i64, ptr %t310, !range !{i64 0, i64 17}
  %t313 = icmp eq i64 %t311, 13
  store i1 %t313, ptr %l168, !tbaa !21
  br label %bb101
bb101:
  %t314 = load i1, ptr %l168, !tbaa !21
  br i1 %t314, label %bb102, label %bb103
bb102:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr { i64, [3 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", ptr }, ptr %t317, i32 0, i32 1
  %t319 = load ptr, ptr %t318
  store ptr %t319, ptr %l15, !tbaa !29
  br label %bb104
bb103:
  br label %bb113
bb104:
  %t321 = load ptr, ptr %l15, !tbaa !29
  %t323 = getelementptr %"compiler/typed:Join", ptr %t321, i32 0, i32 0
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t326 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t324, ptr %t326)
  br label %bb105
bb105:
  %t329 = load ptr, ptr %l15, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Join", ptr %t329, i32 0, i32 2
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  store { i64, ptr } %t332, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t334 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t334, 0
  store i64 %t336, ptr %l18, !tbaa !24
  br label %bb106
bb106:
  %t338 = load i64, ptr %l17, !tbaa !24
  %t339 = load i64, ptr %l18, !tbaa !24
  %t342 = icmp slt i64 %t338, %t339
  %t344 = xor i1 %t342, true
  br i1 %t344, label %bb107, label %bb108
bb107:
  br label %bb112
bb108:
  br label %bb109
bb109:
  %t346 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t346, ptr %l185, !tbaa !27
  %t347 = load i64, ptr %l17, !tbaa !24
  %t349 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr ptr, ptr %t350, i64 %t347
  %t352 = load ptr, ptr %t351, !tbaa !39
  %t356 = getelementptr %"compiler/typed:Clause", ptr %t352, i32 0, i32 3
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t358 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t357, ptr %t358)
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t361 = load i64, ptr %l17, !tbaa !24
  %t363 = add i64 %t361, 1
  store i64 %t363, ptr %l17, !tbaa !24
  br label %bb106
bb112:
  br label %bb166
bb113:
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t366 = load ptr, ptr %l193, !tbaa !29
  %t367 = icmp ne ptr %t366, null
  br i1 %t367, label %bb114, label %bb115
bb114:
  %t369 = load ptr, ptr %l193, !tbaa !29
  %t370 = load i64, ptr %t369, !range !{i64 0, i64 17}
  %t372 = icmp eq i64 %t370, 14
  store i1 %t372, ptr %l194, !tbaa !21
  br label %bb115
bb115:
  %t373 = load i1, ptr %l194, !tbaa !21
  br i1 %t373, label %bb116, label %bb117
bb116:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr { i64, [3 x i64] }, ptr %t374, i32 0, i32 1
  %t377 = getelementptr { %"compiler/source:Span", ptr }, ptr %t376, i32 0, i32 1
  %t378 = load ptr, ptr %t377
  store ptr %t378, ptr %l20, !tbaa !29
  br label %bb118
bb117:
  br label %bb154
bb118:
  %t380 = load ptr, ptr %l20, !tbaa !29
  %t382 = getelementptr %"compiler/typed:Spawn", ptr %t380, i32 0, i32 0
  %t383 = load { i64, ptr }, ptr %t382, !tbaa !27
  store { i64, ptr } %t383, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t385 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t385, 0
  store i64 %t387, ptr %l23, !tbaa !24
  br label %bb119
bb119:
  %t389 = load i64, ptr %l22, !tbaa !24
  %t390 = load i64, ptr %l23, !tbaa !24
  %t393 = icmp slt i64 %t389, %t390
  %t395 = xor i1 %t393, true
  br i1 %t395, label %bb120, label %bb121
bb120:
  br label %bb145
bb121:
  br label %bb122
bb122:
  %t397 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t397, ptr %l207, !tbaa !27
  %t398 = load i64, ptr %l22, !tbaa !24
  %t400 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr ptr, ptr %t401, i64 %t398
  %t403 = load ptr, ptr %t402, !tbaa !39
  store ptr %t403, ptr %l24, !tbaa !29
  %t405 = load ptr, ptr %l24, !tbaa !29
  %t407 = icmp eq ptr %t405, null
  br i1 %t407, label %bb123, label %bb124
bb123:
  br label %bb144
bb124:
  br label %bb125
bb125:
  %t409 = load ptr, ptr %l24, !tbaa !29
  %t411 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %t409)
  store i64 %t411, ptr %l213
  br label %bb126
bb126:
  %t412 = load i64, ptr %l213, !tbaa !24
  %t413 = icmp sge i64 %t412, 0
  br i1 %t413, label %bb127, label %bb128
bb127:
  %t415 = load ptr, ptr %l1, !tbaa !29
  %t417 = getelementptr %"compiler/scope:walked", ptr %t415, i32 0, i32 1
  store ptr %t417, ptr %l216, !tbaa !29
  %t418 = load ptr, ptr %l24, !tbaa !29
  %t420 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %t418)
  store i64 %t420, ptr %l218
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t421 = load ptr, ptr %l216, !tbaa !29
  %t422 = load i64, ptr %l218, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t421, i64 %t422)
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t423 = load ptr, ptr %l24, !tbaa !29
  %t425 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %t423)
  store i1 %t425, ptr %l220
  br label %bb132
bb132:
  %t426 = load i1, ptr %l220, !tbaa !21
  %t427 = xor i1 %t426, true
  br i1 %t427, label %bb133, label %bb134
bb133:
  %t429 = load ptr, ptr %l24, !tbaa !29
  %t431 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t429)
  store i64 %t431, ptr %l224
  br label %bb135
bb134:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb136
bb135:
  %t432 = load i64, ptr %l224, !tbaa !24
  %t433 = icmp sge i64 %t432, 0
  store i1 %t433, ptr %l222, !tbaa !21
  br label %bb136
bb136:
  %t435 = load i1, ptr %l222, !tbaa !21
  br i1 %t435, label %bb137, label %bb138
bb137:
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t438 = getelementptr %"compiler/scope:walked", ptr %t436, i32 0, i32 4
  store ptr %t438, ptr %l227, !tbaa !29
  %t439 = load ptr, ptr %l24, !tbaa !29
  %t441 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t439)
  store i64 %t441, ptr %l229
  br label %bb139
bb138:
  br label %bb141
bb139:
  %t442 = load ptr, ptr %l227, !tbaa !29
  %t443 = load i64, ptr %l229, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t442, i64 %t443)
  br label %bb140
bb140:
  br label %bb141
bb141:
  %t444 = load ptr, ptr %l24, !tbaa !29
  %t445 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectField(ptr %v0, ptr %v1, ptr %t444, ptr %t445)
  br label %bb142
bb142:
  %t448 = load ptr, ptr %l24, !tbaa !29
  %t450 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %t448, ptr %t450)
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t453 = load i64, ptr %l22, !tbaa !24
  %t455 = add i64 %t453, 1
  store i64 %t455, ptr %l22, !tbaa !24
  br label %bb119
bb145:
  %t457 = load ptr, ptr %l20, !tbaa !29
  %t459 = getelementptr %"compiler/typed:Spawn", ptr %t457, i32 0, i32 1
  %t460 = load ptr, ptr %t459, !tbaa !29
  %t462 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t460, ptr %t462)
  br label %bb146
bb146:
  %t465 = load ptr, ptr %l20, !tbaa !29
  %t467 = getelementptr %"compiler/typed:Spawn", ptr %t465, i32 0, i32 2
  %t468 = load { i64, ptr }, ptr %t467, !tbaa !27
  store { i64, ptr } %t468, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t470 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t470, 0
  store i64 %t472, ptr %l27, !tbaa !24
  br label %bb147
bb147:
  %t474 = load i64, ptr %l26, !tbaa !24
  %t475 = load i64, ptr %l27, !tbaa !24
  %t478 = icmp slt i64 %t474, %t475
  %t480 = xor i1 %t478, true
  br i1 %t480, label %bb148, label %bb149
bb148:
  br label %bb153
bb149:
  br label %bb150
bb150:
  %t482 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t482, ptr %l249, !tbaa !27
  %t483 = load i64, ptr %l26, !tbaa !24
  %t485 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !27
  %t487 = getelementptr ptr, ptr %t486, i64 %t483
  %t488 = load ptr, ptr %t487, !tbaa !39
  %t492 = getelementptr %"compiler/typed:TaskClause", ptr %t488, i32 0, i32 3
  %t493 = load ptr, ptr %t492, !tbaa !29
  %t494 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t493, ptr %t494)
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t497 = load i64, ptr %l26, !tbaa !24
  %t499 = add i64 %t497, 1
  store i64 %t499, ptr %l26, !tbaa !24
  br label %bb147
bb153:
  br label %bb166
bb154:
  %t501 = load ptr, ptr %l0, !tbaa !29
  store ptr %t501, ptr %l257, !tbaa !29
  store i1 false, ptr %l258, !tbaa !21
  %t502 = load ptr, ptr %l257, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb155, label %bb156
bb155:
  %t505 = load ptr, ptr %l257, !tbaa !29
  %t506 = load i64, ptr %t505, !range !{i64 0, i64 17}
  %t508 = icmp eq i64 %t506, 15
  store i1 %t508, ptr %l258, !tbaa !21
  br label %bb156
bb156:
  %t509 = load i1, ptr %l258, !tbaa !21
  br i1 %t509, label %bb157, label %bb158
bb157:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t512 = getelementptr { i64, [3 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", ptr }, ptr %t512, i32 0, i32 1
  %t514 = load ptr, ptr %t513
  store ptr %t514, ptr %l29, !tbaa !29
  br label %bb159
bb158:
  br label %bb161
bb159:
  %t516 = load ptr, ptr %l29, !tbaa !29
  %t518 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t516, ptr %t518)
  br label %bb160
bb160:
  br label %bb166
bb161:
  br i1 true, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_1f46f0e2a5866641_40fe5c75700827d5)
  unreachable
bb166:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesFirst(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 24
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %s0, ptr %t3)
  store { i64, ptr } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = mul i64 %t9, 8
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = mul i64 %t18, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eFoldStats(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca i32
  %l21 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l54 = alloca %"compiler/typed:Plan"
  %l56 = alloca %"compiler/typed:Plan"
  %l62 = alloca i64
  %l65 = alloca i64
  %l86 = alloca %"compiler/typed:Plan"
  %l88 = alloca %"compiler/typed:Plan"
  %l89 = alloca { i64, ptr }
  %l98 = alloca i1
  %l105 = alloca i64
  %l108 = alloca i64
  %l110 = alloca i1
  %l115 = alloca %"compiler/typed:BlockInfo"
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t67 = alloca %"compiler/typed:Plan", align 8
  %t70 = alloca %"compiler/typed:Plan", align 8
  %t127 = alloca %"compiler/typed:Plan", align 8
  %t130 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load i64, ptr %l21, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l28, !tbaa !24
  store i64 %t33, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l25, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l49
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l49, !tbaa !29
  store ptr %t60, ptr %l9, !tbaa !29
  %t61 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t61, ptr %l50
  br label %bb13
bb13:
  %t62 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t62, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 2
  %t66 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t67, ptr %v0, ptr %v0, ptr %t65, i64 %t66)
  call void @llvm.memmove.p0.p0.i64(ptr %l54, ptr %t67, i64 176, i1 false)
  br label %bb14
bb14:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t70, ptr %v0, ptr %l54)
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %t70, i64 176, i1 false)
  br label %bb15
bb15:
  %t72 = getelementptr %"compiler/typed:Plan", ptr %l56, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  store i64 %t75, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t77 = load i64, ptr %l12, !tbaa !24
  %t78 = load i64, ptr %l11, !tbaa !24
  %t81 = icmp sgt i64 %t77, %t78
  br i1 %t81, label %bb16, label %bb17
bb16:
  %t83 = load i64, ptr %l13, !tbaa !24
  %t85 = icmp sgt i64 %t83, 0
  br i1 %t85, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb21
bb18:
  %t87 = load i64, ptr %l12, !tbaa !24
  %t88 = load i64, ptr %l11, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t92 = load i64, ptr %l13, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  store i64 %t101, ptr %l65, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb20
bb20:
  %t103 = load i64, ptr %l65, !tbaa !24
  store i64 %t103, ptr %l62, !tbaa !24
  br label %bb21
bb21:
  %t104 = load i64, ptr %l62, !tbaa !24
  store i64 %t104, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb22
bb22:
  %t105 = load i64, ptr %l15, !tbaa !24
  %t106 = load i64, ptr %l14, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb23, label %bb24
bb23:
  br label %bb51
bb24:
  br label %bb25
bb25:
  %t113 = load i64, ptr %l11, !tbaa !24
  %t114 = load i64, ptr %l15, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = mul i64 %t114, %t115
  %t121 = add i64 %t113, %t118
  store i64 %t121, ptr %l16, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 2
  %t126 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t127, ptr %v0, ptr %v0, ptr %t125, i64 %t126)
  call void @llvm.memmove.p0.p0.i64(ptr %l86, ptr %t127, i64 176, i1 false)
  br label %bb26
bb26:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t130, ptr %v0, ptr %l86)
  call void @llvm.memmove.p0.p0.i64(ptr %l88, ptr %t130, i64 176, i1 false)
  br label %bb27
bb27:
  %t132 = getelementptr %"compiler/typed:Plan", ptr %l88, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l89, !tbaa !27
  %t134 = load i64, ptr %l16, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr { i64, [1 x i64] }, ptr %t137, i64 %t134
  %t139 = load { i64, [1 x i64] }, ptr %t138
  store { i64, [1 x i64] } %t139, ptr %l17
  %t141 = load { i64, [1 x i64] }, ptr %l17
  %t143 = extractvalue { i64, [1 x i64] } %t141, 0
  %t144 = icmp eq i64 %t143, 1
  br i1 %t144, label %bb28, label %bb29
bb28:
  %t146 = getelementptr { i64, [1 x i64] }, ptr %l17, i32 0, i32 1
  %t147 = getelementptr { i32 }, ptr %t146, i32 0, i32 0
  %t148 = load i32, ptr %t147
  store i32 %t148, ptr %l18, !tbaa !23
  br label %bb30
bb29:
  br label %bb44
bb30:
  %t150 = load i32, ptr %l18, !tbaa !23
  %t152 = sext i32 %t150 to i64
  %t155 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s2, ptr %l10, i64 %t152)
  store i1 %t155, ptr %l98
  br label %bb31
bb31:
  %t156 = load i1, ptr %l98, !tbaa !21
  br i1 %t156, label %bb32, label %bb33
bb32:
  br label %bb50
bb33:
  br label %bb34
bb34:
  %t157 = load i32, ptr %l18, !tbaa !23
  %t159 = sext i32 %t157 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s2, ptr %l10, i64 %t159, i1 true)
  br label %bb35
bb35:
  %t162 = load i64, ptr %l2, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l2, !tbaa !24
  %t166 = load i32, ptr %l18, !tbaa !23
  %t168 = sext i32 %t166 to i64
  store i64 %t168, ptr %l105, !tbaa !24
  %t169 = load ptr, ptr %l9, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Body", ptr %t169, i32 0, i32 8
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t171)
  store i64 %t173, ptr %l108
  br label %bb36
bb36:
  %t174 = load i64, ptr %l105, !tbaa !24
  %t175 = load i64, ptr %l108, !tbaa !24
  %t176 = icmp slt i64 %t174, %t175
  br i1 %t176, label %bb37, label %bb38
bb37:
  %t178 = load ptr, ptr %l9, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Body", ptr %t178, i32 0, i32 8
  %t181 = load i32, ptr %l18, !tbaa !23
  %t183 = sext i32 %t181 to i64
  %t186 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t180, i64 %t183)
  store %"compiler/typed:BlockInfo" %t186, ptr %l115
  br label %bb39
bb38:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb40
bb39:
  %t187 = getelementptr %"compiler/typed:BlockInfo", ptr %l115, i32 0, i32 1
  %t188 = load i32, ptr %t187, !range !{i32 0, i32 9}
  %t190 = trunc i64 1 to i32
  %t191 = icmp eq i32 %t188, %t190
  store i1 %t191, ptr %l110, !tbaa !21
  br label %bb40
bb40:
  %t193 = load i1, ptr %l110, !tbaa !21
  br i1 %t193, label %bb41, label %bb42
bb41:
  %t194 = load i64, ptr %l1, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l1, !tbaa !24
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_c4dcb08f8057e6b4_879f1d415f5e90f0)
  unreachable
bb49:
  br label %bb50
bb50:
  %t198 = load i64, ptr %l15, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l15, !tbaa !24
  br label %bb22
bb51:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb52:
  %t202 = load i64, ptr %l7, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l7, !tbaa !24
  br label %bb8
bb53:
  %t206 = load i64, ptr %l2, !tbaa !24
  %t207 = load i64, ptr %l1, !tbaa !24
  %t208 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t211 = call i64 @__olang_fmt_i64(ptr null, i64 %t206)
  %t212 = add i64 %t209, %t211
  %t213 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t217 = call i64 @__olang_fmt_i64(ptr null, i64 %t207)
  %t218 = add i64 %t215, %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t208, i64 %t209)
  %t220 = getelementptr i8, ptr %t219, i64 %t209
  %t221 = call i64 @__olang_fmt_i64(ptr %t220, i64 %t206)
  %t222 = getelementptr i8, ptr %t220, i64 %t211
  call void @olang_textcopy(ptr %t222, ptr %t213, i64 %t214)
  %t223 = getelementptr i8, ptr %t222, i64 %t214
  %t224 = call i64 @__olang_fmt_i64(ptr %t223, i64 %t207)
  %t225 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t219, 1
  store { i64, ptr } %t226, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/scope:rel"
  %lp7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca %"compiler/scope:rel"
  %l37 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l46 = alloca i1
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 6
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_H9c3932eb53016bf6f47a08eef06aacbe(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %lp3
  %t17 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v2, ptr %v2, ptr %t15)
  store { i64, ptr } %t17, ptr %l15
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t18 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t18, ptr %l16, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l17, !tbaa !24
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = mul i64 %t21, 16
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l18, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l17, !tbaa !24
  %t31 = mul i64 %t30, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/scope:Scoper", ptr %t34, i32 0, i32 6
  %t37 = load i64, ptr %l1, !tbaa !24
  %t40 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t36, i64 %t37)
  store ptr %t40, ptr %l22
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t43 = getelementptr %"compiler/scope:summary", ptr %t41, i32 0, i32 0
  store ptr %t43, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i64, ptr %l5, !tbaa !24
  store i64 %t45, ptr %l25, !tbaa !24
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l27
  br label %bb9
bb9:
  %t49 = load i64, ptr %l25, !tbaa !24
  %t50 = load i64, ptr %l27, !tbaa !24
  %t51 = icmp slt i64 %t49, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb11:
  br label %bb12
bb12:
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t55, i64 %t56)
  store %"compiler/scope:rel" %t59, ptr %l32
  br label %bb13
bb13:
  %t60 = load %"compiler/scope:rel", ptr %l32
  store %"compiler/scope:rel" %t60, ptr %l6
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 0
  %t64 = load { i64, [2 x i64] }, ptr %t63
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t70 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etermName(ptr %v0, ptr %v1, ptr %s3, ptr %t61, i64 %t62, { i64, [2 x i64] } %t64, ptr %t65)
  store { i64, ptr } %t70, ptr %l37
  br label %bb14
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i64, ptr %l1, !tbaa !24
  %t73 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 1
  %t74 = load { i64, [2 x i64] }, ptr %t73
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t80 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etermName(ptr %v0, ptr %v1, ptr %s3, ptr %t71, i64 %t72, { i64, [2 x i64] } %t74, ptr %t75)
  store { i64, ptr } %t80, ptr %l42
  br label %bb15
bb15:
  %t81 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t87 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = add i64 %t86, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t82, i64 %t83)
  %t92 = getelementptr i8, ptr %t91, i64 %t83
  call void @olang_textcopy(ptr %t92, ptr %t84, i64 %t85)
  %t93 = getelementptr i8, ptr %t92, i64 %t85
  call void @olang_textcopy(ptr %t93, ptr %t88, i64 %t89)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t91, 1
  %t96 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t96, ptr %lp7
  %t98 = load ptr, ptr %lp7
  store { i64, ptr } %t95, ptr %t98, !tbaa !27
  %t99 = load ptr, ptr %lp3
  %t100 = load ptr, ptr %lp7
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t104 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v2, ptr %v2, ptr %t99, { i64, ptr } %t101)
  store i1 %t104, ptr %l46
  br label %bb16
bb16:
  %t105 = load i1, ptr %l46, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb17, label %bb18
bb17:
  %t108 = load ptr, ptr %lp3
  %t109 = load ptr, ptr %lp7
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t108, { i64, ptr } %t110)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t113 = load i64, ptr %l5, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l5, !tbaa !24
  br label %bb8
bb22:
  %t117 = load ptr, ptr %lp3
  %t119 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v2, ptr %v2, ptr %t117)
  store { i64, ptr } %t119, ptr %l53
  br label %bb23
bb23:
  %t120 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t120, ptr %l54, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l55, !tbaa !24
  %t123 = load i64, ptr %l55, !tbaa !24
  %t124 = mul i64 %t123, 16
  %t125 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l56, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = load i64, ptr %l55, !tbaa !24
  %t133 = mul i64 %t132, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t129, ptr %t131, i64 %t133, i1 false)
  %t134 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t134, ptr %l54, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t135, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eValueCovered(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 149
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3, i64 %a1)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsOwn(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 42
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, ptr } %t12, 1
  %t14 = extractvalue { i32, ptr } %t12, 0
  store i32 %t14, ptr %l11
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  store ptr %t13, ptr %l10
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l10, !tbaa !29
  store ptr %t17, ptr %l6, !tbaa !29
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %rv
  br label %ret
bb7:
  %t19 = load ptr, ptr %l6, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorBuilt(ptr %v0, ptr %v0, ptr %t20, ptr %t19)
  store i1 %t24, ptr %l15
  br label %bb8
bb8:
  %t25 = load i1, ptr %l15, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeBuilds(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t15 = load ptr, ptr %l4, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 5}
  %t22 = icmp eq i64 %t20, 4
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8066e5da37f3a23b_ece6b8d6fabe8bf7)
  unreachable
bb15:
  %t31 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsSum(ptr %v0, ptr %a0, i64 %a2, i64 %a3)
  store i1 %t31, ptr %l19
  br label %bb16
bb16:
  %t32 = load i1, ptr %l19, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 1
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 1
  %t33 = load { i64, [2 x i64] }, ptr %t32
  store { i64, [2 x i64] } %t33, ptr %l4
  %t35 = load { i64, [2 x i64] }, ptr %l4
  %t37 = extractvalue { i64, [2 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 0
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t41 = getelementptr { i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l5, !tbaa !24
  br label %bb9
bb8:
  br label %bb13
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l27, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l29, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l33
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l29, !tbaa !29
  %t67 = load i64, ptr %l33, !tbaa !24
  %t68 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t66, i64 %t67)
  store ptr %t68, ptr %l34
  br label %bb11
bb11:
  %t69 = load ptr, ptr %l34, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Func", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  %t73 = load ptr, ptr %l27, !tbaa !29
  %t75 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t73, i32 %t72)
  store { i64, ptr } %t75, ptr %l37
  br label %bb12
bb12:
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t77, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t81, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_a571972fdacfaed1_c7933b0216b7b5ad)
  unreachable
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_9f9bf081c1674640_32724a584f79d5fc)
  unreachable
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t83, ptr %l40, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l41, !tbaa !24
  %t86 = load i64, ptr %l41, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l42, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l41, !tbaa !24
  %t96 = mul i64 %t95, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t92, ptr %t94, i64 %t96, i1 false)
  %t97 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t97, ptr %l40, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i1
  %l9 = alloca i1
  %l13 = alloca %"compiler/scope:Val"
  %l18 = alloca ptr
  %l19 = alloca i1
  %l34 = alloca i1
  %l39 = alloca %"compiler/source:Span"
  %l53 = alloca %"compiler/scope:Val"
  %l69 = alloca i1
  %l73 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l91 = alloca i64
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca %"compiler/msgs:Msg"
  %l96 = alloca i64
  %l97 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca %"compiler/msgs:Msg"
  %l102 = alloca i64
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t2 = load ptr, ptr %l18, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l18, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l19, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l19, !tbaa !21
  store i1 %t9, ptr %l4, !tbaa !21
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i1, ptr %l2, !tbaa !21
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 73
  store i1 %t13, ptr %t16, !tbaa !21
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 76
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l5, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 77
  %t25 = load %"compiler/source:Span", ptr %t24
  store %"compiler/source:Span" %t25, ptr %l6
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 78
  %t30 = load { i64, [2 x i64] }, ptr %t29
  store { i64, [2 x i64] } %t30, ptr %l7
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/scope:Scoper", ptr %t32, i32 0, i32 79
  %t35 = load i1, ptr %t34, !tbaa !21
  store i1 %t35, ptr %l8, !tbaa !21
  %t37 = load i1, ptr %l2, !tbaa !21
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load i1, ptr %l4, !tbaa !21
  %t41 = xor i1 %t39, true
  store i1 %t41, ptr %l34, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb8
bb8:
  %t43 = load i1, ptr %l34, !tbaa !21
  br i1 %t43, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l9, !tbaa !21
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t48 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  store %"compiler/source:Span" %t48, ptr %l39
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t49 = load %"compiler/source:Span", ptr %l39
  %t50 = load { i64, [2 x i64] }, ptr %l3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i1, ptr %l9, !tbaa !21
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t52, i32 0, i32 76
  store i1 %t53, ptr %t56, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t57, i32 0, i32 77
  store %"compiler/source:Span" %t49, ptr %t61
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 78
  store { i64, [2 x i64] } %t50, ptr %t66
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/scope:Scoper", ptr %t67, i32 0, i32 79
  store i1 true, ptr %t71, !tbaa !21
  br label %bb12
bb12:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = load { i64, [2 x i64] }, ptr %l3
  %t79 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t72, ptr %t73, { i64, [2 x i64] } %t75)
  store %"compiler/scope:Val" %t79, ptr %l53
  br label %bb13
bb13:
  %t80 = load %"compiler/scope:Val", ptr %l53
  store %"compiler/scope:Val" %t80, ptr %l13
  %t81 = load i1, ptr %l5, !tbaa !21
  %t83 = load %"compiler/source:Span", ptr %l6
  %t85 = load { i64, [2 x i64] }, ptr %l7
  %t87 = load i1, ptr %l8, !tbaa !21
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/scope:Scoper", ptr %t89, i32 0, i32 76
  store i1 %t81, ptr %t93, !tbaa !21
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/scope:Scoper", ptr %t94, i32 0, i32 77
  store %"compiler/source:Span" %t83, ptr %t98
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/scope:Scoper", ptr %t99, i32 0, i32 78
  store { i64, [2 x i64] } %t85, ptr %t103
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/scope:Scoper", ptr %t104, i32 0, i32 79
  store i1 %t87, ptr %t108, !tbaa !21
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/scope:Scoper", ptr %t109, i32 0, i32 73
  store i1 false, ptr %t111, !tbaa !21
  %t112 = load i1, ptr %l2, !tbaa !21
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb16
bb15:
  %t116 = getelementptr %"compiler/scope:Val", ptr %l13, i32 0, i32 0
  %t117 = load i32, ptr %t116, !range !{i32 0, i32 5}
  %t119 = trunc i64 3 to i32
  %t120 = icmp eq i32 %t117, %t119
  %t122 = xor i1 %t120, true
  store i1 %t122, ptr %l69, !tbaa !21
  br label %bb16
bb16:
  %t124 = load i1, ptr %l69, !tbaa !21
  br i1 %t124, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb20
bb18:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/scope:Val", ptr %l13, i32 0, i32 1
  %t127 = load { i64, [2 x i64] }, ptr %t126
  %t128 = load { i64, [2 x i64] }, ptr %l3
  %t132 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastsUntil(ptr %v0, ptr %t125, { i64, [2 x i64] } %t127, { i64, [2 x i64] } %t128)
  store i1 %t132, ptr %l77
  br label %bb19
bb19:
  %t133 = load i1, ptr %l77, !tbaa !21
  store i1 %t133, ptr %l73, !tbaa !21
  br label %bb20
bb20:
  %t134 = load i1, ptr %l73, !tbaa !21
  br i1 %t134, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb23
bb22:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/scope:Scoper", ptr %t135, i32 0, i32 27
  %t138 = load i1, ptr %t137, !tbaa !21
  %t140 = xor i1 %t138, true
  store i1 %t140, ptr %l78, !tbaa !21
  br label %bb23
bb23:
  %t142 = load i1, ptr %l78, !tbaa !21
  br i1 %t142, label %bb24, label %bb25
bb24:
  br label %ret
bb25:
  br label %bb26
bb26:
  %t143 = load i1, ptr %l4, !tbaa !21
  br i1 %t143, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l83, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l84, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/scope:Scoper", ptr %t147, i32 0, i32 25
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb29, label %bb30
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l97, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t159 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t155, ptr %t156)
  store %"compiler/source:Span" %t159, ptr %l100
  br label %bb36
bb29:
  call void @__olang_check_failed(ptr @olang_loc_9e4942b53b152c4c_8e08edd23a0a3ef8)
  unreachable
bb30:
  br label %bb31
bb31:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/scope:Scoper", ptr %t160, i32 0, i32 25
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Body", ptr %t163, i32 0, i32 3
  %t167 = load i64, ptr %t166, !tbaa !24
  store i64 %t167, ptr %l91, !tbaa !24
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t168)
  store %"compiler/source:Span" %t170, ptr %l93
  br label %bb32
bb32:
  %t171 = load ptr, ptr %l84, !tbaa !29
  %t172 = load i64, ptr %l91, !tbaa !24
  %t173 = load %"compiler/source:Span", ptr %l93
  %t174 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t171, i64 %t172, %"compiler/source:Span" %t173)
  store %"compiler/source:Span" %t174, ptr %l94
  br label %bb33
bb33:
  %t175 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnCaptureTooShort(ptr %s4)
  store %"compiler/msgs:Msg" %t175, ptr %l95
  br label %bb34
bb34:
  %t176 = load ptr, ptr %l83, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l94
  %t178 = load %"compiler/msgs:Msg", ptr %l95
  %t179 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s4, ptr %t176, %"compiler/source:Span" %t177, %"compiler/msgs:Msg" %t178)
  store i64 %t179, ptr %l96
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb36:
  %t180 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %s5)
  store %"compiler/msgs:Msg" %t180, ptr %l101
  br label %bb37
bb37:
  %t181 = load ptr, ptr %l97, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l100
  %t183 = load %"compiler/msgs:Msg", ptr %l101
  %t184 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s5, ptr %t181, %"compiler/source:Span" %t182, %"compiler/msgs:Msg" %t183)
  store i64 %t184, ptr %l102
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallsAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i1
  %l22 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca i1
  %l52 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l10, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l11, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr { i64, [3 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { i32 }, ptr %t20, i32 0, i32 0
  %t22 = load i32, ptr %t21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 1
  %t29 = sext i32 %t22 to i64
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t26, i64 %t29)
  store ptr %t32, ptr %l22
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l22, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 1
  %t36 = load { i64, [2 x i64] }, ptr %t35
  store { i64, [2 x i64] } %t36, ptr %l4
  %t38 = load { i64, [2 x i64] }, ptr %l4
  %t40 = extractvalue { i64, [2 x i64] } %t38, 0
  %t41 = icmp eq i64 %t40, 0
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t46 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t47 = getelementptr { i64 }, ptr %t46, i32 0, i32 0
  %t48 = load i64, ptr %t47
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/scope:Scoper", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t61 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t57, i64 %t48)
  store i64 %t61, ptr %l35
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = load i64, ptr %l35, !tbaa !24
  %t64 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t62, i64 %t63)
  store ptr %t64, ptr %l36
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l36, !tbaa !29
  store ptr %t65, ptr %l6, !tbaa !29
  %t66 = load ptr, ptr %l6, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Func", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/scope:Scoper", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/load:Loader", ptr %t80, i32 0, i32 3
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Func", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %t86, !tbaa !23
  %t90 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t83, i32 %t87)
  store { i64, ptr } %t90, ptr %l47
  br label %bb15
bb15:
  %t91 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t91, ptr %l7, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t94 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t92, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t94, ptr %l49
  br label %bb16
bb16:
  %t95 = load i1, ptr %l49, !tbaa !21
  br i1 %t95, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb20
bb18:
  %t96 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t98 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t96, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t98, ptr %l52
  br label %bb19
bb19:
  %t99 = load i1, ptr %l52, !tbaa !21
  store i1 %t99, ptr %l50, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t100 = load i1, ptr %l50, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallsItself(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 12
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i64, ptr %l11, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/scope:Scoper", ptr %t9, i32 0, i32 12
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t12, 1
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t11, i64 %t14)
  store i64 %t17, ptr %l16
  br label %bb2
bb2:
  %t18 = load i64, ptr %l16, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l20, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/scope:Scoper", ptr %t65, i32 0, i32 13
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t63)
  store i64 %t71, ptr %l44
  br label %bb13
bb13:
  %t72 = load i64, ptr %l1, !tbaa !24
  %t73 = load i64, ptr %l44, !tbaa !24
  %t75 = icmp eq i64 %t73, %t72
  br i1 %t75, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb9
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %a1, ptr %l2)
  br label %bb2
bb2:
  store ptr %l2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l12, !tbaa !24
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t11)
  store i64 %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = load i64, ptr %l14, !tbaa !24
  %t16 = icmp slt i64 %t14, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t20, i64 %t21)
  store i64 %t24, ptr %l19
  br label %bb8
bb8:
  %t25 = load i64, ptr %l19, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 112
  %t32 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t28, i64 %t25)
  store i1 %t32, ptr %l23
  br label %bb9
bb9:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb3
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecomponents(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/scope:walked"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca %"compiler/scope:walked"
  %l67 = alloca i64
  %l69 = alloca i64
  %l74 = alloca i64
  %l81 = alloca ptr
  %l84 = alloca i64
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca i64
  %l100 = alloca ptr
  %l103 = alloca i64
  %l105 = alloca i64
  %l107 = alloca i64
  %l112 = alloca i64
  %l119 = alloca i64
  %l123 = alloca i64
  %l126 = alloca i64
  %l145 = alloca ptr
  %l148 = alloca ptr
  %l151 = alloca i32
  %l152 = alloca i32
  %l153 = alloca i64
  %l156 = alloca i64
  %l157 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l169 = alloca ptr
  %l172 = alloca i64
  %l174 = alloca ptr
  %l177 = alloca i64
  %l179 = alloca ptr
  %l182 = alloca i64
  %l187 = alloca i64
  %l190 = alloca i64
  %l211 = alloca i64
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %t67 = alloca %"compiler/scope:walked", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l32
  br label %bb1
bb1:
  %t6 = load i64, ptr %l32, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l40, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l40, !tbaa !24
  store i64 %t35, ptr %l37, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l37, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %t55, i32 0, i32 12
  store ptr %t57, ptr %l59, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 13
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t60)
  store i64 %t62, ptr %l62
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l59, !tbaa !29
  %t64 = load i64, ptr %l62, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fscope_2ewalkBody(ptr %t67, ptr %v0, ptr %s2, ptr %t65, i64 %t66)
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t67, i64 224, i1 false)
  br label %bb14
bb14:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l65, i64 224, i1 false)
  %t70 = getelementptr %"compiler/scope:walked", ptr %l8, i32 0, i32 0
  store ptr %t70, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  %t72 = load i64, ptr %l10, !tbaa !24
  store i64 %t72, ptr %l67, !tbaa !24
  %t73 = load ptr, ptr %l9, !tbaa !29
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t73)
  store i64 %t75, ptr %l69
  br label %bb16
bb16:
  %t76 = load i64, ptr %l67, !tbaa !24
  %t77 = load i64, ptr %l69, !tbaa !24
  %t78 = icmp slt i64 %t76, %t77
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l9, !tbaa !29
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l74
  br label %bb20
bb20:
  %t87 = load i64, ptr %l74, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/scope:Scoper", ptr %t88, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t90, i64 %t87)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t94 = load i64, ptr %l10, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l10, !tbaa !24
  br label %bb15
bb23:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/scope:Scoper", ptr %t98, i32 0, i32 14
  store ptr %t100, ptr %l81, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/scope:Scoper", ptr %t101, i32 0, i32 15
  %t105 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t103)
  store i64 %t105, ptr %l84
  br label %bb24
bb24:
  %t106 = load ptr, ptr %l81, !tbaa !29
  %t107 = load i64, ptr %l84, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t106, i64 %t107)
  br label %bb25
bb25:
  %t108 = getelementptr %"compiler/scope:walked", ptr %l8, i32 0, i32 1
  store ptr %t108, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t110 = load i64, ptr %l13, !tbaa !24
  store i64 %t110, ptr %l86, !tbaa !24
  %t111 = load ptr, ptr %l12, !tbaa !29
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t111)
  store i64 %t113, ptr %l88
  br label %bb27
bb27:
  %t114 = load i64, ptr %l86, !tbaa !24
  %t115 = load i64, ptr %l88, !tbaa !24
  %t116 = icmp slt i64 %t114, %t115
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb28, label %bb29
bb28:
  br label %bb34
bb29:
  br label %bb30
bb30:
  %t120 = load ptr, ptr %l12, !tbaa !29
  %t121 = load i64, ptr %l13, !tbaa !24
  %t124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t120, i64 %t121)
  store i64 %t124, ptr %l93
  br label %bb31
bb31:
  %t125 = load i64, ptr %l93, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/scope:Scoper", ptr %t126, i32 0, i32 15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t128, i64 %t125)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t132 = load i64, ptr %l13, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l13, !tbaa !24
  br label %bb26
bb34:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/scope:Scoper", ptr %t136, i32 0, i32 16
  store ptr %t138, ptr %l100, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %t139, i32 0, i32 17
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t141)
  store i64 %t143, ptr %l103
  br label %bb35
bb35:
  %t144 = load ptr, ptr %l100, !tbaa !29
  %t145 = load i64, ptr %l103, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t144, i64 %t145)
  br label %bb36
bb36:
  %t146 = getelementptr %"compiler/scope:walked", ptr %l8, i32 0, i32 2
  store ptr %t146, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb37
bb37:
  %t148 = load i64, ptr %l16, !tbaa !24
  store i64 %t148, ptr %l105, !tbaa !24
  %t149 = load ptr, ptr %l15, !tbaa !29
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t149)
  store i64 %t151, ptr %l107
  br label %bb38
bb38:
  %t152 = load i64, ptr %l105, !tbaa !24
  %t153 = load i64, ptr %l107, !tbaa !24
  %t154 = icmp slt i64 %t152, %t153
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb39, label %bb40
bb39:
  br label %bb45
bb40:
  br label %bb41
bb41:
  %t158 = load ptr, ptr %l15, !tbaa !29
  %t159 = load i64, ptr %l16, !tbaa !24
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t158, i64 %t159)
  store i64 %t162, ptr %l112
  br label %bb42
bb42:
  %t163 = load i64, ptr %l112, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/scope:Scoper", ptr %t164, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t166, i64 %t163)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t170 = load i64, ptr %l16, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l16, !tbaa !24
  br label %bb37
bb45:
  store i64 0, ptr %l18, !tbaa !24
  %t174 = getelementptr %"compiler/scope:walked", ptr %l8, i32 0, i32 5
  %t176 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s2, ptr %t174)
  store i64 %t176, ptr %l119
  br label %bb46
bb46:
  %t177 = load i64, ptr %l119, !tbaa !24
  store i64 %t177, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t178 = load i64, ptr %l19, !tbaa !24
  %t179 = load i64, ptr %l18, !tbaa !24
  %t182 = icmp sgt i64 %t178, %t179
  br i1 %t182, label %bb47, label %bb48
bb47:
  %t184 = load i64, ptr %l20, !tbaa !24
  %t186 = icmp sgt i64 %t184, 0
  br i1 %t186, label %bb49, label %bb50
bb48:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb52
bb49:
  %t188 = load i64, ptr %l19, !tbaa !24
  %t189 = load i64, ptr %l18, !tbaa !24
  %t192 = sub i64 %t188, %t189
  %t193 = load i64, ptr %l20, !tbaa !24
  %t196 = add i64 %t192, %t193
  %t198 = sub i64 %t196, 1
  %t199 = load i64, ptr %l20, !tbaa !24
  %t202 = sdiv i64 %t198, %t199
  store i64 %t202, ptr %l126, !tbaa !24
  br label %bb51
bb50:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb51
bb51:
  %t204 = load i64, ptr %l126, !tbaa !24
  store i64 %t204, ptr %l123, !tbaa !24
  br label %bb52
bb52:
  %t205 = load i64, ptr %l123, !tbaa !24
  store i64 %t205, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s13
  %t206 = load i64, ptr %l22, !tbaa !24
  %t207 = load i64, ptr %l21, !tbaa !24
  %t210 = icmp slt i64 %t206, %t207
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s13)
  br label %bb63
bb55:
  br label %bb56
bb56:
  %t214 = load i64, ptr %l18, !tbaa !24
  %t215 = load i64, ptr %l22, !tbaa !24
  %t216 = load i64, ptr %l20, !tbaa !24
  %t219 = mul i64 %t215, %t216
  %t222 = add i64 %t214, %t219
  store i64 %t222, ptr %l23, !tbaa !24
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/scope:Scoper", ptr %t224, i32 0, i32 47
  store ptr %t226, ptr %l145, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/scope:Scoper", ptr %t227, i32 0, i32 0
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = getelementptr %"compiler/generic:Program", ptr %t230, i32 0, i32 2
  store ptr %t232, ptr %l148, !tbaa !29
  %t233 = getelementptr %"compiler/scope:walked", ptr %l8, i32 0, i32 5
  %t234 = load i64, ptr %l23, !tbaa !24
  %t237 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s2, ptr %t233, i64 %t234)
  store i32 %t237, ptr %l151
  br label %bb57
bb57:
  %t238 = load ptr, ptr %l148, !tbaa !29
  %t239 = load i32, ptr %l151, !tbaa !23
  %t240 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t238, i32 %t239)
  store i32 %t240, ptr %l152
  br label %bb58
bb58:
  %t241 = load i32, ptr %l152, !tbaa !23
  %t242 = sext i32 %t241 to i64
  store i64 %t242, ptr %l153, !tbaa !24
  %t243 = getelementptr %"compiler/scope:walked", ptr %l8, i32 0, i32 6
  %t244 = load i64, ptr %l23, !tbaa !24
  %t247 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t243, i64 %t244)
  store i64 %t247, ptr %l156
  br label %bb59
bb59:
  %t248 = load i64, ptr %l153, !tbaa !24
  %t249 = load i64, ptr %l156, !tbaa !24
  %t250 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s13, i64 %t248, i64 %t249)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t250, ptr %l157
  br label %bb60
bb60:
  %t251 = load ptr, ptr %l145, !tbaa !29
  %t252 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l157
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t251, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t252, i1 true)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb62
bb62:
  %t253 = load i64, ptr %l22, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l22, !tbaa !24
  br label %bb53
bb63:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/scope:Scoper", ptr %t257, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t259, i64 -1)
  br label %bb64
bb64:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/scope:Scoper", ptr %t261, i32 0, i32 19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t263, i64 0)
  br label %bb65
bb65:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/scope:Scoper", ptr %t265, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t267, i1 false)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb67:
  %t269 = load i64, ptr %l6, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l6, !tbaa !24
  br label %bb8
bb68:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/scope:Scoper", ptr %t273, i32 0, i32 12
  store ptr %t275, ptr %l169, !tbaa !29
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/scope:Scoper", ptr %t276, i32 0, i32 13
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t278)
  store i64 %t280, ptr %l172
  br label %bb69
bb69:
  %t281 = load ptr, ptr %l169, !tbaa !29
  %t282 = load i64, ptr %l172, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t281, i64 %t282)
  br label %bb70
bb70:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/scope:Scoper", ptr %t283, i32 0, i32 14
  store ptr %t285, ptr %l174, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/scope:Scoper", ptr %t286, i32 0, i32 15
  %t290 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t288)
  store i64 %t290, ptr %l177
  br label %bb71
bb71:
  %t291 = load ptr, ptr %l174, !tbaa !29
  %t292 = load i64, ptr %l177, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t291, i64 %t292)
  br label %bb72
bb72:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/scope:Scoper", ptr %t293, i32 0, i32 16
  store ptr %t295, ptr %l179, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/scope:Scoper", ptr %t296, i32 0, i32 17
  %t300 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t298)
  store i64 %t300, ptr %l182
  br label %bb73
bb73:
  %t301 = load ptr, ptr %l179, !tbaa !29
  %t302 = load i64, ptr %l182, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t301, i64 %t302)
  br label %bb74
bb74:
  store i64 0, ptr %l24, !tbaa !24
  %t303 = load i64, ptr %l1, !tbaa !24
  store i64 %t303, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t305 = load i64, ptr %l25, !tbaa !24
  %t306 = load i64, ptr %l24, !tbaa !24
  %t309 = icmp sgt i64 %t305, %t306
  br i1 %t309, label %bb75, label %bb76
bb75:
  %t311 = load i64, ptr %l26, !tbaa !24
  %t313 = icmp sgt i64 %t311, 0
  br i1 %t313, label %bb77, label %bb78
bb76:
  store i64 0, ptr %l187, !tbaa !24
  br label %bb80
bb77:
  %t315 = load i64, ptr %l25, !tbaa !24
  %t316 = load i64, ptr %l24, !tbaa !24
  %t319 = sub i64 %t315, %t316
  %t320 = load i64, ptr %l26, !tbaa !24
  %t323 = add i64 %t319, %t320
  %t325 = sub i64 %t323, 1
  %t326 = load i64, ptr %l26, !tbaa !24
  %t329 = sdiv i64 %t325, %t326
  store i64 %t329, ptr %l190, !tbaa !24
  br label %bb79
bb78:
  store i64 0, ptr %l190, !tbaa !24
  br label %bb79
bb79:
  %t331 = load i64, ptr %l190, !tbaa !24
  store i64 %t331, ptr %l187, !tbaa !24
  br label %bb80
bb80:
  %t332 = load i64, ptr %l187, !tbaa !24
  store i64 %t332, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb81
bb81:
  %t333 = load i64, ptr %l28, !tbaa !24
  %t334 = load i64, ptr %l27, !tbaa !24
  %t337 = icmp slt i64 %t333, %t334
  %t339 = xor i1 %t337, true
  br i1 %t339, label %bb82, label %bb83
bb82:
  br label %bb91
bb83:
  br label %bb84
bb84:
  %t341 = load i64, ptr %l24, !tbaa !24
  %t342 = load i64, ptr %l28, !tbaa !24
  %t343 = load i64, ptr %l26, !tbaa !24
  %t346 = mul i64 %t342, %t343
  %t349 = add i64 %t341, %t346
  store i64 %t349, ptr %l29, !tbaa !24
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/scope:Scoper", ptr %t351, i32 0, i32 18
  %t354 = load i64, ptr %l29, !tbaa !24
  %t357 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t353, i64 %t354)
  store i64 %t357, ptr %l211
  br label %bb85
bb85:
  %t358 = load i64, ptr %l211, !tbaa !24
  %t359 = icmp slt i64 %t358, 0
  br i1 %t359, label %bb86, label %bb87
bb86:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i64, ptr %l29, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evisit(ptr %v0, ptr %t361, i64 %t362)
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t365 = load i64, ptr %l28, !tbaa !24
  %t367 = add i64 %t365, 1
  store i64 %t367, ptr %l28, !tbaa !24
  br label %bb81
bb91:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edecide(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca %"compiler/typed:Local"
  %l7 = alloca i1
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca { i64, [1 x i64] }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l27 = alloca %"compiler/typed:Local"
  %l37 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  %l51 = alloca i1
  %l54 = alloca { i64, [2 x i64] }
  %l56 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l63 = alloca i1
  %l65 = alloca { i64, [2 x i64] }
  %l67 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i1
  %l89 = alloca i1
  %l90 = alloca i1
  %l93 = alloca i1
  %l99 = alloca i1
  %l101 = alloca { i64, ptr }
  %l103 = alloca i64
  %l109 = alloca i1
  %l112 = alloca i1
  %l121 = alloca ptr
  %l127 = alloca ptr
  %l131 = alloca ptr
  %l137 = alloca i64
  %l142 = alloca ptr
  %l143 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca ptr
  %l151 = alloca i32
  %l152 = alloca i64
  %l153 = alloca ptr
  %l156 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca ptr
  %l162 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l165 = alloca i1
  %l168 = alloca i1
  %l171 = alloca i1
  %l176 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca ptr
  %l184 = alloca i32
  %l185 = alloca i64
  %l188 = alloca ptr
  %l189 = alloca ptr
  %l193 = alloca i32
  %l194 = alloca i64
  %l200 = alloca i1
  %l202 = alloca i1
  %l206 = alloca i1
  %s14 = alloca %olang.scope
  %t2 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [2 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [2 x i64] }, ptr %t2
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 104
  store { i64, [2 x i64] } %t4, ptr %t7
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 105
  store i1 false, ptr %t10, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 108
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 25
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  br i1 %t19, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_be4231f99dfc50a7_6a00356b78c435db)
  unreachable
bb2:
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 25
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 7
  %t28 = load i32, ptr %l1, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t33 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t27, i64 %t30)
  store %"compiler/typed:Local" %t33, ptr %l27
  br label %bb4
bb4:
  %t34 = load %"compiler/typed:Local", ptr %l27
  store %"compiler/typed:Local" %t34, ptr %l5
  %t35 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t36 = load i32, ptr %t35, !range !{i32 0, i32 7}
  %t38 = trunc i64 2 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 25
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  br i1 %t46, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_badc8ccdfeb92288_a041b08d3fc96aec)
  unreachable
bb9:
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/scope:Scoper", ptr %t48, i32 0, i32 25
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t51, i32 0, i32 1
  %t55 = load { i64, [2 x i64] }, ptr %t54
  %t59 = extractvalue { i64, [2 x i64] } %t55, 0
  %t60 = icmp eq i64 %t59, 1
  br i1 %t60, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_58d2ded8d237a84_721cf65762561fa8)
  unreachable
bb19:
  %t62 = load i1, ptr %l37, !tbaa !21
  store i1 %t62, ptr %l7, !tbaa !21
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/typed:Local", ptr %l5
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t69 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2equalifiesMove(ptr %v0, ptr %v1, ptr %t63, %"compiler/typed:Local" %t64, ptr %t65)
  store i1 %t69, ptr %l43
  br label %bb20
bb20:
  %t70 = load i1, ptr %l43, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  %t71 = load i1, ptr %l7, !tbaa !21
  %t73 = xor i1 %t71, true
  store i1 %t73, ptr %l44, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l44, !tbaa !21
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l1, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t82 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %t76, i64 %t79)
  store i1 %t82, ptr %l51
  br label %bb26
bb25:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb27
bb26:
  %t83 = load i1, ptr %l51, !tbaa !21
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l47, !tbaa !21
  br label %bb27
bb27:
  %t86 = load i1, ptr %l47, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultTerm(ptr %v0, ptr %t87, i64 0)
  store { i64, [2 x i64] } %t89, ptr %l54
  br label %bb30
bb29:
  br label %bb71
bb30:
  %t90 = load { i64, [2 x i64] }, ptr %l54
  store { i64, [2 x i64] } %t90, ptr %l8
  %t91 = load { i64, [2 x i64] }, ptr %l8
  %t93 = call i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %t91)
  store i1 %t93, ptr %l56
  br label %bb31
bb31:
  %t94 = load i1, ptr %l56, !tbaa !21
  br i1 %t94, label %bb32, label %bb33
bb32:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t100 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t95, i32 %t97)
  store i1 %t100, ptr %l60
  br label %bb34
bb33:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb35
bb34:
  %t101 = load i1, ptr %l60, !tbaa !21
  store i1 %t101, ptr %l57, !tbaa !21
  br label %bb35
bb35:
  %t102 = load i1, ptr %l57, !tbaa !21
  br i1 %t102, label %bb36, label %bb37
bb36:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereturnsArray(ptr %v0, ptr %t103)
  store i1 %t105, ptr %l63
  br label %bb38
bb37:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb39
bb38:
  %t106 = load i1, ptr %l63, !tbaa !21
  store i1 %t106, ptr %l61, !tbaa !21
  br label %bb39
bb39:
  %t107 = load i1, ptr %l61, !tbaa !21
  br i1 %t107, label %bb40, label %bb41
bb40:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorageTerm(ptr %v0, ptr %t108)
  store { i64, [2 x i64] } %t110, ptr %l65
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t111 = load { i64, [2 x i64] }, ptr %l65
  store { i64, [2 x i64] } %t111, ptr %l8
  br label %bb43
bb43:
  %t112 = load { i64, [2 x i64] }, ptr %l8
  %t114 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t112)
  store i1 %t114, ptr %l67
  br label %bb44
bb44:
  %t115 = load i1, ptr %l67, !tbaa !21
  br i1 %t115, label %bb45, label %bb46
bb45:
  %t116 = load { i64, [2 x i64] }, ptr %l8
  %t118 = call i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %t116)
  store i1 %t118, ptr %l70
  br label %bb47
bb46:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb48
bb47:
  %t119 = load i1, ptr %l70, !tbaa !21
  %t120 = xor i1 %t119, true
  store i1 %t120, ptr %l68, !tbaa !21
  br label %bb48
bb48:
  %t122 = load i1, ptr %l68, !tbaa !21
  br i1 %t122, label %bb49, label %bb50
bb49:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowStart(ptr %v0, ptr %t123, i32 %t124, i64 0)
  br label %bb51
bb50:
  br label %bb70
bb51:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/scope:Scoper", ptr %t127, i32 0, i32 120
  store i1 false, ptr %t129, !tbaa !21
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t132 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowRun(ptr %v0, ptr %v2, ptr %t130, { i64, ptr } %t131, i64 %t132)
  br label %bb52
bb52:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/scope:Scoper", ptr %t136, i32 0, i32 120
  store i1 true, ptr %t138, !tbaa !21
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %t139, i32 0, i32 113
  %t142 = load i32, ptr %l1, !tbaa !23
  %t144 = sext i32 %t142 to i64
  %t147 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t141, i64 %t144)
  store i1 %t147, ptr %l83
  br label %bb53
bb53:
  %t148 = load i1, ptr %l83, !tbaa !21
  br i1 %t148, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb61
bb55:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/scope:Scoper", ptr %t149, i32 0, i32 112
  %t152 = load i32, ptr %l1, !tbaa !23
  %t154 = sext i32 %t152 to i64
  %t157 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t151, i64 %t154)
  store i1 %t157, ptr %l89
  br label %bb56
bb56:
  %t158 = load i1, ptr %l89, !tbaa !21
  br i1 %t158, label %bb57, label %bb58
bb57:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l2, !tbaa !29
  %t163 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etiedToBlock(ptr %v0, ptr %v1, ptr %t159, ptr %t160)
  store i1 %t163, ptr %l93
  br label %bb59
bb58:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb60
bb59:
  %t164 = load i1, ptr %l93, !tbaa !21
  %t165 = xor i1 %t164, true
  store i1 %t165, ptr %l90, !tbaa !21
  br label %bb60
bb60:
  %t167 = load i1, ptr %l90, !tbaa !21
  store i1 %t167, ptr %l84, !tbaa !21
  br label %bb61
bb61:
  %t168 = load i1, ptr %l84, !tbaa !21
  br i1 %t168, label %bb62, label %bb63
bb62:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load { i64, [2 x i64] }, ptr %l8
  %t173 = getelementptr %"compiler/scope:Scoper", ptr %t169, i32 0, i32 104
  store { i64, [2 x i64] } %t170, ptr %t173
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t176 = load i32, ptr %t175, !tbaa !23
  %t179 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t174, i32 %t176)
  store i1 %t179, ptr %l99
  br label %bb64
bb63:
  br label %bb69
bb64:
  %t180 = load i1, ptr %l99, !tbaa !21
  br i1 %t180, label %bb65, label %bb66
bb65:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/scope:Scoper", ptr %t181, i32 0, i32 30
  %t184 = getelementptr %"compiler/typed:Plan", ptr %t183, i32 0, i32 3
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  store { i64, ptr } %t185, ptr %l101, !tbaa !27
  %t186 = load i32, ptr %l1, !tbaa !23
  %t188 = sext i32 %t186 to i64
  store i64 %t188, ptr %l103, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load i32, ptr %l1, !tbaa !23
  %t192 = sext i32 %t190 to i64
  %t193 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t194 = load i64, ptr %l4, !tbaa !24
  %t199 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArray(ptr %v0, ptr %v2, ptr %t189, i64 %t192, { i64, ptr } %t193, i64 %t194)
  store i1 %t199, ptr %l109
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t200 = load i1, ptr %l109, !tbaa !21
  %t201 = load i64, ptr %l103, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i1, ptr %t203, i64 %t201
  store i1 %t200, ptr %t204, !tbaa !31
  br label %bb68
bb68:
  br label %ret
bb69:
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t207 = load i32, ptr %t206, !tbaa !23
  %t210 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t205, i32 %t207)
  store i1 %t210, ptr %l112
  br label %bb72
bb72:
  %t211 = load i1, ptr %l112, !tbaa !21
  %t212 = xor i1 %t211, true
  br i1 %t212, label %bb73, label %bb74
bb73:
  br label %ret
bb74:
  br label %bb75
bb75:
  %t214 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 5
  %t215 = load { i64, [1 x i64] }, ptr %t214
  store { i64, [1 x i64] } %t215, ptr %l9
  %t217 = load { i64, [1 x i64] }, ptr %l9
  %t219 = extractvalue { i64, [1 x i64] } %t217, 0
  %t220 = icmp eq i64 %t219, 0
  br i1 %t220, label %bb76, label %bb77
bb76:
  br label %bb80
bb77:
  %t222 = load { i64, [1 x i64] }, ptr %l9
  %t224 = extractvalue { i64, [1 x i64] } %t222, 0
  %t225 = icmp eq i64 %t224, 4
  br i1 %t225, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb86
bb81:
  br i1 true, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %ret
bb85:
  call void @__olang_check_failed(ptr @olang_loc_36d9ea1b8e0be675_6ae7f20c6157de79)
  unreachable
bb86:
  %t227 = load ptr, ptr %l2, !tbaa !29
  %t230 = call ptr @compiler_2ftyped_2eCallOf(ptr %v1, ptr %v1, ptr %t227)
  store ptr %t230, ptr %l121
  br label %bb87
bb87:
  %t231 = load ptr, ptr %l121, !tbaa !29
  store ptr %t231, ptr %l10, !tbaa !29
  %t232 = load ptr, ptr %l10, !tbaa !29
  %t234 = icmp eq ptr %t232, null
  br i1 %t234, label %bb88, label %bb89
bb88:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load ptr, ptr %l2, !tbaa !29
  %t241 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCallOf(ptr %v0, ptr %v1, ptr %v1, ptr %t236, ptr %t237)
  store ptr %t241, ptr %l127
  br label %bb90
bb89:
  br label %bb94
bb90:
  %t242 = load ptr, ptr %l127, !tbaa !29
  store ptr %t242, ptr %l10, !tbaa !29
  %t243 = load ptr, ptr %l10, !tbaa !29
  %t245 = icmp eq ptr %t243, null
  br i1 %t245, label %bb91, label %bb92
bb91:
  br label %ret
bb92:
  br label %bb93
bb93:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/scope:Scoper", ptr %t247, i32 0, i32 108
  store i1 true, ptr %t249, !tbaa !21
  br label %bb94
bb94:
  %t250 = load ptr, ptr %l0, !tbaa !29
  store ptr %t250, ptr %l131, !tbaa !29
  %t251 = load ptr, ptr %l10, !tbaa !29
  %t253 = icmp eq ptr %t251, null
  br i1 %t253, label %bb95, label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_318ee1b3da3da37b_dfd49c38f0c44407)
  unreachable
bb96:
  br label %bb97
bb97:
  %t255 = load ptr, ptr %l10, !tbaa !29
  %t258 = getelementptr %"compiler/typed:Call", ptr %t255, i32 0, i32 0
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t260 = load ptr, ptr %l131, !tbaa !29
  %t262 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t260, ptr %t259)
  store i64 %t262, ptr %l137
  br label %bb98
bb98:
  %t263 = load i64, ptr %l137, !tbaa !24
  store i64 %t263, ptr %l11, !tbaa !24
  %t264 = load ptr, ptr %l10, !tbaa !29
  %t266 = icmp eq ptr %t264, null
  br i1 %t266, label %bb99, label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_b8fb270bdd73210c_150398a92061e6e8)
  unreachable
bb100:
  br label %bb101
bb101:
  %t268 = load ptr, ptr %l10, !tbaa !29
  %t271 = getelementptr %"compiler/typed:Call", ptr %t268, i32 0, i32 0
  %t272 = load ptr, ptr %t271, !tbaa !29
  store ptr %t272, ptr %l142, !tbaa !29
  store i1 false, ptr %l143, !tbaa !21
  %t273 = load ptr, ptr %l142, !tbaa !29
  %t274 = icmp ne ptr %t273, null
  br i1 %t274, label %bb102, label %bb103
bb102:
  %t276 = load ptr, ptr %l142, !tbaa !29
  %t277 = load i64, ptr %t276, !range !{i64 0, i64 5}
  %t279 = icmp eq i64 %t277, 2
  store i1 %t279, ptr %l143, !tbaa !21
  br label %bb103
bb103:
  %t280 = load i1, ptr %l143, !tbaa !21
  br i1 %t280, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s14
  %t281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t281, ptr %l146, !tbaa !29
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l147, !tbaa !29
  %t283 = load ptr, ptr %l10, !tbaa !29
  %t285 = icmp eq ptr %t283, null
  br i1 %t285, label %bb106, label %bb107
bb105:
  br label %bb119
bb106:
  call void @__olang_check_failed(ptr @olang_loc_6763258997513a41_ec0b86cc45ca0bbd)
  unreachable
bb107:
  br label %bb108
bb108:
  %t287 = load ptr, ptr %l10, !tbaa !29
  %t288 = load ptr, ptr %l147, !tbaa !29
  %t290 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t288, ptr %t287)
  store i32 %t290, ptr %l151
  br label %bb109
bb109:
  %t291 = load ptr, ptr %l146, !tbaa !29
  %t292 = load i32, ptr %l151, !tbaa !23
  %t293 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t291, i32 %t292)
  store i64 %t293, ptr %l152
  br label %bb110
bb110:
  %t294 = load i64, ptr %l152, !tbaa !24
  store i64 %t294, ptr %l12, !tbaa !24
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l153, !tbaa !29
  %t296 = load i64, ptr %l12, !tbaa !24
  %t298 = icmp sge i64 %t296, 0
  br i1 %t298, label %bb111, label %bb112
bb111:
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l157, !tbaa !29
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l158, !tbaa !29
  %t302 = load ptr, ptr %l10, !tbaa !29
  %t304 = icmp eq ptr %t302, null
  br i1 %t304, label %bb113, label %bb114
bb112:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb118
bb113:
  call void @__olang_check_failed(ptr @olang_loc_6767537ca10246ba_b3f77aefc3649fd6)
  unreachable
bb114:
  br label %bb115
bb115:
  %t306 = load ptr, ptr %l10, !tbaa !29
  %t307 = load ptr, ptr %l158, !tbaa !29
  %t309 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallRels(ptr %v0, ptr %v1, ptr %v0, ptr %t307, ptr %t306)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t309, ptr %l162
  br label %bb116
bb116:
  %t310 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l162
  %t311 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t310, ptr %t311
  %t312 = load i64, ptr %l12, !tbaa !24
  %t313 = load ptr, ptr %l157, !tbaa !29
  %t316 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforcedBy(ptr %v0, ptr %v0, ptr %t313, ptr %t311, i64 %t312)
  store i1 %t316, ptr %l165
  br label %bb117
bb117:
  %t317 = load i1, ptr %l165, !tbaa !21
  store i1 %t317, ptr %l156, !tbaa !21
  br label %bb118
bb118:
  %t318 = load i1, ptr %l156, !tbaa !21
  %t319 = load ptr, ptr %l153, !tbaa !29
  %t320 = getelementptr %"compiler/scope:Scoper", ptr %t319, i32 0, i32 105
  store i1 %t318, ptr %t320, !tbaa !21
  call void @__olang_scope_close(ptr %s14)
  br label %ret
bb119:
  %t321 = load i64, ptr %l11, !tbaa !24
  %t323 = icmp slt i64 %t321, 0
  br i1 %t323, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l168, !tbaa !21
  br label %bb123
bb121:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load i64, ptr %l11, !tbaa !24
  %t329 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t325, i64 %t326)
  store i1 %t329, ptr %l171
  br label %bb122
bb122:
  %t330 = load i1, ptr %l171, !tbaa !21
  %t331 = xor i1 %t330, true
  store i1 %t331, ptr %l168, !tbaa !21
  br label %bb123
bb123:
  %t333 = load i1, ptr %l168, !tbaa !21
  br i1 %t333, label %bb124, label %bb125
bb124:
  br label %ret
bb125:
  br label %bb126
bb126:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i32, ptr %l1, !tbaa !23
  %t337 = sext i32 %t335 to i64
  %t340 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewalkLocal(ptr %v0, ptr %t334, i64 %t337)
  store i1 %t340, ptr %l176
  br label %bb127
bb127:
  %t341 = load i1, ptr %l176, !tbaa !21
  br i1 %t341, label %bb128, label %bb129
bb128:
  br label %ret
bb129:
  br label %bb130
bb130:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/scope:Scoper", ptr %t342, i32 0, i32 0
  %t345 = load ptr, ptr %t344, !tbaa !29
  %t347 = getelementptr %"compiler/generic:Program", ptr %t345, i32 0, i32 2
  store ptr %t347, ptr %l179, !tbaa !29
  %t348 = load ptr, ptr %l0, !tbaa !29
  store ptr %t348, ptr %l180, !tbaa !29
  %t349 = load ptr, ptr %l10, !tbaa !29
  %t351 = icmp eq ptr %t349, null
  br i1 %t351, label %bb131, label %bb132
bb131:
  call void @__olang_check_failed(ptr @olang_loc_5eb3bfaaf86e9baf_8dddb03606b5f843)
  unreachable
bb132:
  br label %bb133
bb133:
  %t353 = load ptr, ptr %l10, !tbaa !29
  %t354 = load ptr, ptr %l180, !tbaa !29
  %t356 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t354, ptr %t353)
  store i32 %t356, ptr %l184
  br label %bb134
bb134:
  %t357 = load ptr, ptr %l179, !tbaa !29
  %t358 = load i32, ptr %l184, !tbaa !23
  %t359 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t357, i32 %t358)
  store i64 %t359, ptr %l185
  br label %bb135
bb135:
  %t360 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t361 = load i64, ptr %l185, !tbaa !24
  %t363 = icmp eq i64 %t361, %t360
  br i1 %t363, label %bb136, label %bb137
bb136:
  br label %ret
bb137:
  br label %bb138
bb138:
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l188, !tbaa !29
  %t366 = load ptr, ptr %l0, !tbaa !29
  store ptr %t366, ptr %l189, !tbaa !29
  %t367 = load ptr, ptr %l10, !tbaa !29
  %t369 = icmp eq ptr %t367, null
  br i1 %t369, label %bb139, label %bb140
bb139:
  call void @__olang_check_failed(ptr @olang_loc_8d9c16c9e7a15650_5ac0d9bfaf5af2b4)
  unreachable
bb140:
  br label %bb141
bb141:
  %t371 = load ptr, ptr %l10, !tbaa !29
  %t372 = load ptr, ptr %l189, !tbaa !29
  %t374 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t372, ptr %t371)
  store i32 %t374, ptr %l193
  br label %bb142
bb142:
  %t375 = load ptr, ptr %l188, !tbaa !29
  %t376 = load i32, ptr %l193, !tbaa !23
  %t377 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t375, i32 %t376)
  store i64 %t377, ptr %l194
  br label %bb143
bb143:
  %t378 = load i64, ptr %l194, !tbaa !24
  store i64 %t378, ptr %l13, !tbaa !24
  %t379 = load i64, ptr %l13, !tbaa !24
  %t381 = icmp slt i64 %t379, 0
  br i1 %t381, label %bb144, label %bb145
bb144:
  br label %ret
bb145:
  br label %bb146
bb146:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load i64, ptr %l11, !tbaa !24
  %t385 = load i64, ptr %l13, !tbaa !24
  %t389 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumBuilds(ptr %v0, ptr %t383, i64 %t384, i64 %t385)
  store i1 %t389, ptr %l200
  br label %bb147
bb147:
  %t390 = load i1, ptr %l200, !tbaa !21
  %t391 = xor i1 %t390, true
  br i1 %t391, label %bb148, label %bb149
bb148:
  store i1 true, ptr %l202, !tbaa !21
  br label %bb151
bb149:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load i64, ptr %l11, !tbaa !24
  %t395 = load i64, ptr %l13, !tbaa !24
  %t399 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforced(ptr %v0, ptr %t393, i64 %t394, i64 %t395)
  store i1 %t399, ptr %l206
  br label %bb150
bb150:
  %t400 = load i1, ptr %l206, !tbaa !21
  store i1 %t400, ptr %l202, !tbaa !21
  br label %bb151
bb151:
  %t401 = load i1, ptr %l202, !tbaa !21
  br i1 %t401, label %bb152, label %bb153
bb152:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/scope:Scoper", ptr %t402, i32 0, i32 105
  store i1 true, ptr %t404, !tbaa !21
  br label %ret
bb153:
  br label %bb154
bb154:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowStart(ptr %v0, ptr %t405, i32 %t406, i64 1)
  br label %bb155
bb155:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t411 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowRun(ptr %v0, ptr %v2, ptr %t409, { i64, ptr } %t410, i64 %t411)
  br label %bb156
bb156:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/scope:Scoper", ptr %t416, i32 0, i32 114
  %t419 = load i1, ptr %t418, !tbaa !21
  %t422 = getelementptr %"compiler/scope:Scoper", ptr %t415, i32 0, i32 105
  store i1 %t419, ptr %t422, !tbaa !21
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/scope:Scoper", ptr %t423, i32 0, i32 115
  store i64 0, ptr %t425, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edisagree(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, { i64, [2 x i64] } %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l7 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/msgs:Msg"
  %l28 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l2
  %t3 = load { i64, [2 x i64] }, ptr %l3
  %t7 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudgeOut(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2, { i64, [2 x i64] } %t3)
  store i64 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp eq i64 %t9, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load { i64, [2 x i64] }, ptr %l3
  %t15 = load { i64, [2 x i64] }, ptr %l2
  %t19 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudgeOut(ptr %v0, ptr %t13, { i64, [2 x i64] } %t14, { i64, [2 x i64] } %t15)
  store i64 %t19, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t20 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t23 = icmp eq i64 %t21, %t20
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l10, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load { i64, [2 x i64] }, ptr %l2
  %t28 = load { i64, [2 x i64] }, ptr %l3
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %t26, { i64, [2 x i64] } %t27, { i64, [2 x i64] } %t28, i1 true)
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 27
  %t36 = load i1, ptr %t35, !tbaa !21
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l25, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l26
  %t43 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgsDisagree(ptr %s0)
  store %"compiler/msgs:Msg" %t43, ptr %l27
  br label %bb13
bb13:
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l26
  %t46 = load %"compiler/msgs:Msg", ptr %l27
  %t47 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s0, ptr %t44, %"compiler/source:Span" %t45, %"compiler/msgs:Msg" %t46)
  store i64 %t47, ptr %l28
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load i64, ptr %l28, !tbaa !24
  store i64 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edischarge(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l7
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/scope:Scoper", ptr %t3, i32 0, i32 6
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t5, i64 %t6)
  store ptr %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l11, !tbaa !29
  %t12 = getelementptr %"compiler/scope:summary", ptr %t10, i32 0, i32 0
  %t13 = load i64, ptr %l2, !tbaa !24
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t18 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edischargeRels(ptr %v0, ptr %v0, ptr %v1, ptr %v2, ptr %t17, %"compiler/source:Span" %t18, ptr %t12, i64 %t13, { i64, ptr } %a3, ptr %a4, i1 %a5)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eeqAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l39 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l56 = alloca i1
  %l64 = alloca i1
  %l65 = alloca { i64, ptr }
  %l77 = alloca i1
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l100 = alloca i1
  %l110 = alloca %"compiler/source:Span"
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 25
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_7b1e363353e9e01f_5d568e34003a167b)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l18
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l17
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l7, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  store i64 %t31, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t39 = icmp slt i64 %t33, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t41, ptr %l26, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = icmp ne i8 %t47, 10
  store i1 %t49, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l25, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb12, label %bb13
bb12:
  br label %bb66
bb13:
  br label %bb14
bb14:
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i8, ptr %t58, i64 %t55
  %t60 = load i8, ptr %t59, !tbaa !32
  store i8 %t60, ptr %l5, !tbaa !22
  %t62 = load i8, ptr %l5, !tbaa !22
  %t64 = icmp eq i8 %t62, 40
  br i1 %t64, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb17
bb16:
  %t66 = load i8, ptr %l5, !tbaa !22
  %t68 = icmp eq i8 %t66, 91
  store i1 %t68, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t70 = load i1, ptr %l36, !tbaa !21
  br i1 %t70, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb20
bb19:
  %t71 = load i8, ptr %l5, !tbaa !22
  %t73 = icmp eq i8 %t71, 123
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l4, !tbaa !24
  br label %bb64
bb22:
  %t80 = load i8, ptr %l5, !tbaa !22
  %t82 = icmp eq i8 %t80, 41
  br i1 %t82, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb25
bb24:
  %t84 = load i8, ptr %l5, !tbaa !22
  %t86 = icmp eq i8 %t84, 93
  store i1 %t86, ptr %l46, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l46, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb28
bb27:
  %t89 = load i8, ptr %l5, !tbaa !22
  %t91 = icmp eq i8 %t89, 125
  store i1 %t91, ptr %l49, !tbaa !21
  br label %bb28
bb28:
  %t93 = load i1, ptr %l49, !tbaa !21
  br i1 %t93, label %bb29, label %bb30
bb29:
  %t94 = load i64, ptr %l4, !tbaa !24
  %t96 = sub i64 %t94, 1
  store i64 %t96, ptr %l4, !tbaa !24
  br label %bb63
bb30:
  %t98 = load i8, ptr %l5, !tbaa !22
  %t100 = icmp eq i8 %t98, 61
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t102 = load i64, ptr %l4, !tbaa !24
  %t104 = icmp eq i64 %t102, 0
  store i1 %t104, ptr %l56, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb33
bb33:
  %t106 = load i1, ptr %l56, !tbaa !21
  br i1 %t106, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load i64, ptr %l3, !tbaa !24
  %t109 = add i64 %t107, 1
  %t110 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t115 = icmp slt i64 %t109, %t112
  br i1 %t115, label %bb36, label %bb37
bb35:
  br label %bb62
bb36:
  %t117 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t117, ptr %l65, !tbaa !27
  %t118 = load i64, ptr %l3, !tbaa !24
  %t120 = add i64 %t118, 1
  %t122 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i8, ptr %t123, i64 %t120
  %t125 = load i8, ptr %t124, !tbaa !32
  %t127 = icmp eq i8 %t125, 61
  store i1 %t127, ptr %l64, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb38
bb38:
  %t129 = load i1, ptr %l64, !tbaa !21
  br i1 %t129, label %bb39, label %bb40
bb39:
  %t130 = load i64, ptr %l3, !tbaa !24
  %t132 = add i64 %t130, 2
  store i64 %t132, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb65
bb40:
  br label %bb41
bb41:
  %t134 = load i64, ptr %l3, !tbaa !24
  store i64 %t134, ptr %l6, !tbaa !24
  br label %bb42
bb42:
  %t136 = load i64, ptr %l6, !tbaa !24
  %t137 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t138 = load i32, ptr %t137, !tbaa !23
  %t140 = sext i32 %t138 to i64
  %t143 = icmp sgt i64 %t136, %t140
  br i1 %t143, label %bb43, label %bb44
bb43:
  %t145 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t145, ptr %l78, !tbaa !27
  %t146 = load i64, ptr %l6, !tbaa !24
  %t148 = sub i64 %t146, 1
  %t150 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i8, ptr %t151, i64 %t148
  %t153 = load i8, ptr %t152, !tbaa !32
  %t155 = icmp ne i8 %t153, 32
  store i1 %t155, ptr %l77, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb45
bb45:
  %t157 = load i1, ptr %l77, !tbaa !21
  br i1 %t157, label %bb46, label %bb47
bb46:
  %t158 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t158, ptr %l84, !tbaa !27
  %t159 = load i64, ptr %l6, !tbaa !24
  %t161 = sub i64 %t159, 1
  %t163 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i8, ptr %t164, i64 %t161
  %t166 = load i8, ptr %t165, !tbaa !32
  %t168 = icmp ne i8 %t166, 41
  store i1 %t168, ptr %l83, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb48
bb48:
  %t170 = load i1, ptr %l83, !tbaa !21
  br i1 %t170, label %bb49, label %bb50
bb49:
  %t171 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t171, ptr %l90, !tbaa !27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t174 = sub i64 %t172, 1
  %t176 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 %t174
  %t179 = load i8, ptr %t178, !tbaa !32
  %t181 = icmp ne i8 %t179, 93
  store i1 %t181, ptr %l89, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb51
bb51:
  %t183 = load i1, ptr %l89, !tbaa !21
  br i1 %t183, label %bb52, label %bb53
bb52:
  %t184 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t184, ptr %l96, !tbaa !27
  %t185 = load i64, ptr %l6, !tbaa !24
  %t187 = sub i64 %t185, 1
  %t189 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i8, ptr %t190, i64 %t187
  %t192 = load i8, ptr %t191, !tbaa !32
  %t194 = call i1 @compiler_2fscope_2eisNameChar(i8 %t192)
  store i1 %t194, ptr %l100
  br label %bb54
bb53:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb55
bb54:
  %t195 = load i1, ptr %l100, !tbaa !21
  %t196 = xor i1 %t195, true
  store i1 %t196, ptr %l95, !tbaa !21
  br label %bb55
bb55:
  %t198 = load i1, ptr %l95, !tbaa !21
  %t199 = xor i1 %t198, true
  br i1 %t199, label %bb56, label %bb57
bb56:
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t201 = load i64, ptr %l6, !tbaa !24
  %t203 = sub i64 %t201, 1
  store i64 %t203, ptr %l6, !tbaa !24
  br label %bb59
bb59:
  br label %bb42
bb60:
  %t205 = load i64, ptr %l6, !tbaa !24
  %t207 = trunc i64 %t205 to i32
  %t208 = load i64, ptr %l3, !tbaa !24
  %t210 = add i64 %t208, 1
  %t212 = trunc i64 %t210 to i32
  %t215 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t207, i32 %t212)
  store %"compiler/source:Span" %t215, ptr %l110
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s6)
  %t216 = load %"compiler/source:Span", ptr %l110
  store %"compiler/source:Span" %t216, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t217 = load i64, ptr %l3, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l3, !tbaa !24
  br label %bb65
bb65:
  br label %bb8
bb66:
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eexports(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca ptr
  %l52 = alloca i64
  %l56 = alloca ptr
  %l60 = alloca i1
  %l64 = alloca ptr
  %l67 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l103 = alloca { i64, [3 x i64] }
  %l107 = alloca { i64, ptr }
  %l109 = alloca %"compiler/msgs:Msg"
  %l110 = alloca i64
  %s3 = alloca %olang.scope
  %t192 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load i64, ptr %l15, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l22, !tbaa !24
  store i64 %t33, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb42
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l43
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l43, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 1
  %t63 = load { i64, [2 x i64] }, ptr %t62
  store { i64, [2 x i64] } %t63, ptr %l7
  %t65 = load { i64, [2 x i64] }, ptr %l7
  %t67 = extractvalue { i64, [2 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 0
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t71 = getelementptr { i64 }, ptr %t70, i32 0, i32 0
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l8, !tbaa !24
  br label %bb15
bb14:
  br label %bb35
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/scope:Scoper", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t77, i64 %t78)
  store i64 %t81, ptr %l52
  br label %bb16
bb16:
  %t82 = load i64, ptr %l52, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s3, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l56
  br label %bb17
bb17:
  %t91 = load ptr, ptr %l56, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Func", ptr %t91, i32 0, i32 7
  %t94 = load i1, ptr %t93, !tbaa !21
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb22
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/scope:Scoper", ptr %t98, i32 0, i32 6
  %t101 = load i64, ptr %l6, !tbaa !24
  %t104 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t100, i64 %t101)
  store ptr %t104, ptr %l64
  br label %bb20
bb20:
  %t105 = load ptr, ptr %l64, !tbaa !29
  %t107 = getelementptr %"compiler/scope:summary", ptr %t105, i32 0, i32 0
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t107)
  store i64 %t109, ptr %l67
  br label %bb21
bb21:
  %t110 = load i64, ptr %l67, !tbaa !24
  %t111 = icmp eq i64 %t110, 0
  store i1 %t111, ptr %l60, !tbaa !21
  br label %bb22
bb22:
  %t113 = load i1, ptr %l60, !tbaa !21
  br i1 %t113, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb24:
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t117, i64 %t118)
  store ptr %t121, ptr %l72
  br label %bb26
bb26:
  %t122 = load ptr, ptr %l72, !tbaa !29
  store ptr %t122, ptr %l10, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 10
  store ptr %t131, ptr %l76, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/scope:Scoper", ptr %t132, i32 0, i32 0
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t136 = load i64, ptr %l9, !tbaa !24
  %t139 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t135, i64 %t136)
  store i64 %t139, ptr %l80
  br label %bb27
bb27:
  %t140 = load ptr, ptr %l76, !tbaa !29
  %t141 = load i64, ptr %l80, !tbaa !24
  %t142 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  store ptr %t142, ptr %l81
  br label %bb28
bb28:
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t145 = getelementptr %"compiler/load:Module", ptr %t143, i32 0, i32 4
  %t146 = load i64, ptr %t145, !tbaa !24
  store i64 %t146, ptr %l11, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i64, ptr %l6, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/scope:Scoper", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/load:Loader", ptr %t156, i32 0, i32 3
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t163 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v0, ptr %s3, ptr %t148, i64 %t149, ptr %t159)
  store { i64, ptr } %t163, ptr %l90
  br label %bb29
bb29:
  %t164 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t164, ptr %l12, !tbaa !27
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 0
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/load:Loader", ptr %t171, i32 0, i32 4
  %t174 = load ptr, ptr %t173, !tbaa !29
  store ptr %t174, ptr %l94, !tbaa !29
  %t175 = load i64, ptr %l11, !tbaa !24
  %t176 = load ptr, ptr %l10, !tbaa !29
  %t178 = getelementptr %"compiler/ast:Func", ptr %t176, i32 0, i32 0
  %t179 = getelementptr %"compiler/source:Span", ptr %t178, i32 0, i32 0
  %t180 = load i32, ptr %t179, !tbaa !23
  %t182 = sext i32 %t180 to i64
  %t183 = load ptr, ptr %l10, !tbaa !29
  %t185 = getelementptr %"compiler/ast:Func", ptr %t183, i32 0, i32 0
  %t186 = getelementptr %"compiler/source:Span", ptr %t185, i32 0, i32 0
  %t187 = load i32, ptr %t186, !tbaa !23
  %t189 = sext i32 %t187 to i64
  %t191 = add i64 %t189, 6
  store { i64, [3 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 0
  store i64 3, ptr %t193
  %t195 = insertvalue { i64, i64, i64 } undef, i64 %t175, 0
  %t197 = insertvalue { i64, i64, i64 } %t195, i64 %t182, 1
  %t199 = insertvalue { i64, i64, i64 } %t197, i64 %t191, 2
  %t200 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  store { i64, i64, i64 } %t199, ptr %t200
  %t201 = load { i64, [3 x i64] }, ptr %t192
  store { i64, [3 x i64] } %t201, ptr %l103
  %t202 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t206 = icmp sgt i64 %t204, 0
  br i1 %t206, label %bb30, label %bb31
bb30:
  %t208 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, ptr }, ptr %t209, i64 0
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !37
  store { i64, ptr } %t211, ptr %l107, !tbaa !27
  br label %bb32
bb31:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l107, !tbaa !27
  br label %bb32
bb32:
  %t213 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t214 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportObligation(ptr %s3, ptr %s3, { i64, ptr } %t213)
  store %"compiler/msgs:Msg" %t214, ptr %l109
  br label %bb33
bb33:
  %t215 = load ptr, ptr %l94, !tbaa !29
  %t216 = load { i64, [3 x i64] }, ptr %l103
  %t217 = load %"compiler/msgs:Msg", ptr %l109
  %t218 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t215, { i64, [3 x i64] } %t216, %"compiler/msgs:Msg" %t217)
  store i64 %t218, ptr %l110
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_3d4ddf74a6173f57_410f107a77dd9b9b)
  unreachable
bb40:
  br label %bb41
bb41:
  %t219 = load i64, ptr %l5, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l5, !tbaa !24
  br label %bb8
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t7)
  store ptr %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l8, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l3, !tbaa !29
  br label %bb11
bb6:
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 18}
  %t32 = icmp eq i64 %t30, 3
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t44 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceDecl(ptr %v0, ptr %s0, ptr %t40, ptr %t41)
  store i64 %t44, ptr %l24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l24, !tbaa !24
  store i64 %t45, ptr %l9, !tbaa !24
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_e3d7361eb9c064f6_d6d91699ddbb69ea)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t46 = load i64, ptr %l9, !tbaa !24
  store i64 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efitErrorAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca %"compiler/msgs:Msg"
  %l5 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca { i64, [2 x i64] }
  %l13 = alloca { i64, [2 x i64] }
  %l15 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca %"compiler/msgs:Msg"
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i64
  %l25 = alloca %"compiler/msgs:Msg"
  %l30 = alloca i1
  %l33 = alloca i1
  %l37 = alloca %"compiler/msgs:Msg"
  %l41 = alloca %"compiler/msgs:Msg"
  %l45 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l54 = alloca { i64, [2 x i64] }
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca [24 x i8]
  %l74 = alloca ptr
  %l81 = alloca ptr
  %l90 = alloca %"compiler/typed:Local"
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca %"compiler/msgs:Msg"
  %l102 = alloca %"compiler/msgs:Msg"
  %l106 = alloca %"compiler/msgs:Msg"
  %l111 = alloca %"compiler/msgs:Msg"
  %l112 = alloca %"compiler/msgs:Msg"
  %l113 = alloca %"compiler/msgs:Msg"
  %l117 = alloca %"compiler/msgs:Msg"
  %l121 = alloca %"compiler/msgs:Msg"
  %l132 = alloca %"compiler/msgs:Msg"
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca %"compiler/msgs:Msg"
  %l138 = alloca %"compiler/msgs:Msg"
  %l142 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 76
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 80
  %t9 = load { i64, [2 x i64] }, ptr %t8
  store { i64, [2 x i64] } %t9, ptr %l10
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 78
  %t13 = load { i64, [2 x i64] }, ptr %t12
  store { i64, [2 x i64] } %t13, ptr %l13
  %t16 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l10, ptr %l13)
  store i1 %t16, ptr %l15
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t17 = load i1, ptr %l15, !tbaa !21
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 77
  %t23 = load %"compiler/source:Span", ptr %t22
  store %"compiler/source:Span" %t23, ptr %l18
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 79
  %t27 = load i1, ptr %t26, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %s1)
  store %"compiler/msgs:Msg" %t29, ptr %l22
  br label %bb9
bb8:
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgHoldsShort(ptr %s1)
  store %"compiler/msgs:Msg" %t30, ptr %l23
  br label %bb10
bb9:
  %t31 = load %"compiler/msgs:Msg", ptr %l22
  store %"compiler/msgs:Msg" %t31, ptr %l21
  br label %bb11
bb10:
  %t32 = load %"compiler/msgs:Msg", ptr %l23
  store %"compiler/msgs:Msg" %t32, ptr %l21
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l18
  %t35 = load %"compiler/msgs:Msg", ptr %l21
  %t36 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s1, ptr %t33, %"compiler/source:Span" %t34, %"compiler/msgs:Msg" %t35)
  store i64 %t36, ptr %l24
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i64, ptr %l24, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
bb13:
  %t38 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeMayNotOutlive(ptr %s0)
  store %"compiler/msgs:Msg" %t38, ptr %l25
  br label %bb14
bb14:
  %t39 = load %"compiler/msgs:Msg", ptr %l25
  store %"compiler/msgs:Msg" %t39, ptr %l4
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr @G_2ecompiler_2fscope_2eFitLocal, !tbaa !24
  %t44 = icmp eq i64 %t40, %t41
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t46 = load i1, ptr %l3, !tbaa !21
  br i1 %t46, label %bb17, label %bb18
bb16:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2ecompiler_2fscope_2eFitPayload, !tbaa !24
  %t52 = icmp eq i64 %t48, %t49
  br i1 %t52, label %bb27, label %bb28
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 81
  %t57 = load i1, ptr %t56, !tbaa !21
  br i1 %t57, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb22
bb19:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb21
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 82
  %t62 = load i1, ptr %t61, !tbaa !21
  %t64 = xor i1 %t62, true
  store i1 %t64, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l33, !tbaa !21
  store i1 %t66, ptr %l30, !tbaa !21
  br label %bb22
bb22:
  %t67 = load i1, ptr %l30, !tbaa !21
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t68 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %s0)
  store %"compiler/msgs:Msg" %t68, ptr %l37
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t69 = load %"compiler/msgs:Msg", ptr %l37
  store %"compiler/msgs:Msg" %t69, ptr %l4
  br label %bb26
bb26:
  br label %bb101
bb27:
  %t70 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t70, ptr %l41
  br label %bb29
bb28:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load i64, ptr @G_2ecompiler_2fscope_2eFitOwn, !tbaa !24
  %t75 = icmp eq i64 %t71, %t72
  br i1 %t75, label %bb30, label %bb31
bb29:
  %t77 = load %"compiler/msgs:Msg", ptr %l41
  store %"compiler/msgs:Msg" %t77, ptr %l4
  br label %bb100
bb30:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb32
bb31:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t79 = load i64, ptr @G_2ecompiler_2fscope_2eFitReturn, !tbaa !24
  %t82 = icmp eq i64 %t78, %t79
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t84 = load i1, ptr %l45, !tbaa !21
  br i1 %t84, label %bb33, label %bb34
bb33:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/scope:Scoper", ptr %t85, i32 0, i32 111
  %t88 = load i1, ptr %t87, !tbaa !21
  store i1 %t88, ptr %l49, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb35
bb35:
  %t90 = load i1, ptr %l49, !tbaa !21
  br i1 %t90, label %bb36, label %bb37
bb36:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %t91)
  store { i64, [2 x i64] } %t93, ptr %l54
  br label %bb38
bb37:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb39
bb38:
  %t94 = load { i64, [2 x i64] }, ptr %l54
  %t96 = extractvalue { i64, [2 x i64] } %t94, 0
  %t97 = icmp eq i64 %t96, 0
  %t99 = xor i1 %t97, true
  store i1 %t99, ptr %l52, !tbaa !21
  br label %bb39
bb39:
  %t101 = load i1, ptr %l52, !tbaa !21
  br i1 %t101, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  store { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l58, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t102, ptr %l59, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = mul i64 24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l60, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 24, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %l60, 1
  store { i64, ptr } %t108, ptr %l5, !tbaa !27
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 25
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = icmp eq ptr %t113, null
  br i1 %t115, label %bb42, label %bb43
bb41:
  %t117 = load i64, ptr %l2, !tbaa !24
  %t118 = load i64, ptr @G_2ecompiler_2fscope_2eFitOwn, !tbaa !24
  %t121 = icmp eq i64 %t117, %t118
  br i1 %t121, label %bb60, label %bb61
bb42:
  call void @__olang_check_failed(ptr @olang_loc_12677068e04dfe45_ab703d1ad408b711)
  unreachable
bb43:
  br label %bb44
bb44:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 25
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Body", ptr %t126, i32 0, i32 16
  %t130 = load i1, ptr %t129, !tbaa !21
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/scope:Scoper", ptr %t134, i32 0, i32 0
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/load:Loader", ptr %t140, i32 0, i32 3
  %t143 = load ptr, ptr %t142, !tbaa !29
  store ptr %t143, ptr %l74, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/scope:Scoper", ptr %t144, i32 0, i32 25
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  br i1 %t149, label %bb47, label %bb48
bb46:
  br label %bb58
bb47:
  call void @__olang_check_failed(ptr @olang_loc_bf00db29bdc1b99e_9dc03d0b43789e0a)
  unreachable
bb48:
  br label %bb49
bb49:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/scope:Scoper", ptr %t151, i32 0, i32 25
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Body", ptr %t154, i32 0, i32 7
  store ptr %t157, ptr %l81, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/scope:Scoper", ptr %t158, i32 0, i32 25
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_bf00db29bdc1b99e_9dc03d0b43789e0a)
  unreachable
bb51:
  br label %bb52
bb52:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 25
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Body", ptr %t168, i32 0, i32 15
  %t172 = load i32, ptr %t171, !tbaa !23
  %t174 = sext i32 %t172 to i64
  %t175 = load ptr, ptr %l81, !tbaa !29
  %t177 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t175, i64 %t174)
  store %"compiler/typed:Local" %t177, ptr %l90
  br label %bb53
bb53:
  %t178 = getelementptr %"compiler/typed:Local", ptr %l90, i32 0, i32 0
  %t179 = load i32, ptr %t178, !tbaa !23
  %t180 = load ptr, ptr %l74, !tbaa !29
  %t182 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s8, ptr %t180, i32 %t179)
  store { i64, ptr } %t182, ptr %l92
  br label %bb54
bb54:
  %t183 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t185 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = add i64 %t184, %t187
  %t189 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t191 = add i64 %t188, %t190
  %t192 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t191)
  call void @olang_textcopy(ptr %t192, ptr %t183, i64 %t184)
  %t193 = getelementptr i8, ptr %t192, i64 %t184
  call void @olang_textcopy(ptr %t193, ptr %t186, i64 %t187)
  %t194 = getelementptr i8, ptr %t193, i64 %t187
  call void @olang_textcopy(ptr %t194, ptr %t189, i64 %t190)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t192, 1
  store { i64, ptr } %t196, ptr %l93, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  %t199 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  store i64 %t200, ptr %l95, !tbaa !24
  %t202 = load i64, ptr %l95, !tbaa !24
  %t203 = icmp eq i64 %t198, %t202
  br i1 %t203, label %bb55, label %bb56
bb55:
  %t205 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = load i64, ptr %l95, !tbaa !24
  %t210 = mul i64 %t209, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t206, ptr %t208, i64 %t210, i1 false)
  br label %bb57
bb56:
  %t211 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t211, ptr %l5, !tbaa !27
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb58:
  %t212 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t214 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenYieldShorter(ptr %s7, ptr %s0, { i64, ptr } %t212)
  store %"compiler/msgs:Msg" %t214, ptr %l98
  br label %bb59
bb59:
  %t215 = load %"compiler/msgs:Msg", ptr %l98
  store %"compiler/msgs:Msg" %t215, ptr %l4
  call void @__olang_scope_close(ptr %s7)
  br label %bb99
bb60:
  %t216 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnCannotOutlive(ptr %s0)
  store %"compiler/msgs:Msg" %t216, ptr %l102
  br label %bb62
bb61:
  %t217 = load i64, ptr %l2, !tbaa !24
  %t218 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  %t221 = icmp eq i64 %t217, %t218
  br i1 %t221, label %bb63, label %bb64
bb62:
  %t223 = load %"compiler/msgs:Msg", ptr %l102
  store %"compiler/msgs:Msg" %t223, ptr %l4
  br label %bb98
bb63:
  %t224 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoredRefOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t224, ptr %l106
  br label %bb65
bb64:
  %t225 = load i64, ptr %l2, !tbaa !24
  %t226 = load i64, ptr @G_2ecompiler_2fscope_2eFitElem, !tbaa !24
  %t229 = icmp eq i64 %t225, %t226
  br i1 %t229, label %bb66, label %bb67
bb65:
  %t231 = load %"compiler/msgs:Msg", ptr %l106
  store %"compiler/msgs:Msg" %t231, ptr %l4
  br label %bb97
bb66:
  %t232 = load i1, ptr %l3, !tbaa !21
  br i1 %t232, label %bb68, label %bb69
bb67:
  %t234 = load i64, ptr %l2, !tbaa !24
  %t235 = load i64, ptr @G_2ecompiler_2fscope_2eFitAnyCopy, !tbaa !24
  %t238 = icmp eq i64 %t234, %t235
  br i1 %t238, label %bb73, label %bb74
bb68:
  %t240 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemNotInArrayScope(ptr %s0)
  store %"compiler/msgs:Msg" %t240, ptr %l112
  br label %bb70
bb69:
  %t241 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t241, ptr %l113
  br label %bb71
bb70:
  %t242 = load %"compiler/msgs:Msg", ptr %l112
  store %"compiler/msgs:Msg" %t242, ptr %l111
  br label %bb72
bb71:
  %t243 = load %"compiler/msgs:Msg", ptr %l113
  store %"compiler/msgs:Msg" %t243, ptr %l111
  br label %bb72
bb72:
  %t244 = load %"compiler/msgs:Msg", ptr %l111
  store %"compiler/msgs:Msg" %t244, ptr %l4
  br label %bb96
bb73:
  %t245 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCopyOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t245, ptr %l117
  br label %bb75
bb74:
  %t246 = load i64, ptr %l2, !tbaa !24
  %t247 = load i64, ptr @G_2ecompiler_2fscope_2eFitGlobal, !tbaa !24
  %t250 = icmp eq i64 %t246, %t247
  br i1 %t250, label %bb76, label %bb77
bb75:
  %t252 = load %"compiler/msgs:Msg", ptr %l117
  store %"compiler/msgs:Msg" %t252, ptr %l4
  br label %bb95
bb76:
  %t253 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalHoldsShorter(ptr %s0)
  store %"compiler/msgs:Msg" %t253, ptr %l121
  br label %bb78
bb77:
  %t254 = load i64, ptr %l2, !tbaa !24
  %t255 = load i64, ptr @G_2ecompiler_2fscope_2eFitReturn, !tbaa !24
  %t258 = icmp eq i64 %t254, %t255
  br i1 %t258, label %bb79, label %bb80
bb78:
  %t260 = load %"compiler/msgs:Msg", ptr %l121
  store %"compiler/msgs:Msg" %t260, ptr %l4
  br label %bb94
bb79:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/scope:Scoper", ptr %t261, i32 0, i32 25
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = icmp eq ptr %t264, null
  br i1 %t266, label %bb81, label %bb82
bb80:
  %t268 = load i64, ptr %l2, !tbaa !24
  %t269 = load i64, ptr @G_2ecompiler_2fscope_2eFitValue, !tbaa !24
  %t272 = icmp eq i64 %t268, %t269
  br i1 %t272, label %bb89, label %bb90
bb81:
  call void @__olang_check_failed(ptr @olang_loc_2de0ba6211cb93cf_481b942389356f0b)
  unreachable
bb82:
  br label %bb83
bb83:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/scope:Scoper", ptr %t274, i32 0, i32 25
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t280 = getelementptr %"compiler/typed:Body", ptr %t277, i32 0, i32 14
  %t281 = load i1, ptr %t280, !tbaa !21
  br i1 %t281, label %bb84, label %bb85
bb84:
  %t283 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOwnStorage(ptr %s0)
  store %"compiler/msgs:Msg" %t283, ptr %l133
  br label %bb86
bb85:
  %t284 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnOwnStorage(ptr %s0)
  store %"compiler/msgs:Msg" %t284, ptr %l134
  br label %bb87
bb86:
  %t285 = load %"compiler/msgs:Msg", ptr %l133
  store %"compiler/msgs:Msg" %t285, ptr %l132
  br label %bb88
bb87:
  %t286 = load %"compiler/msgs:Msg", ptr %l134
  store %"compiler/msgs:Msg" %t286, ptr %l132
  br label %bb88
bb88:
  %t287 = load %"compiler/msgs:Msg", ptr %l132
  store %"compiler/msgs:Msg" %t287, ptr %l4
  br label %bb93
bb89:
  %t288 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueRefsOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t288, ptr %l138
  br label %bb91
bb90:
  br label %bb92
bb91:
  %t289 = load %"compiler/msgs:Msg", ptr %l138
  store %"compiler/msgs:Msg" %t289, ptr %l4
  br label %bb92
bb92:
  br label %bb93
bb93:
  br label %bb94
bb94:
  br label %bb95
bb95:
  br label %bb96
bb96:
  br label %bb97
bb97:
  br label %bb98
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  br label %bb101
bb101:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = load %"compiler/msgs:Msg", ptr %l4
  %t296 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s0, ptr %t290, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %t292)
  store i64 %t296, ptr %l142
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s0)
  %t297 = load i64, ptr %l142, !tbaa !24
  store i64 %t297, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca i64
  %l58 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  br label %bb41
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store i64 %t44, ptr %l26
  br label %bb13
bb13:
  %t45 = load i64, ptr %l26, !tbaa !24
  store i64 %t45, ptr %l7, !tbaa !24
  br label %bb41
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l28, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store i64 %t68, ptr %l36
  br label %bb20
bb20:
  %t69 = load i64, ptr %l36, !tbaa !24
  store i64 %t69, ptr %l7, !tbaa !24
  br label %bb41
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l37, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 2
  store i1 %t77, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l38, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t90 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExprRoot(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  store i64 %t90, ptr %l46
  br label %bb27
bb27:
  %t91 = load i64, ptr %l46, !tbaa !24
  store i64 %t91, ptr %l7, !tbaa !24
  br label %bb41
bb28:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t93 = load ptr, ptr %l47, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l47, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 8}
  %t99 = icmp eq i64 %t97, 6
  store i1 %t99, ptr %l48, !tbaa !21
  br label %bb30
bb30:
  %t100 = load i1, ptr %l48, !tbaa !21
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t112 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExprRoot(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  store i64 %t112, ptr %l56
  br label %bb34
bb34:
  %t113 = load i64, ptr %l56, !tbaa !24
  store i64 %t113, ptr %l7, !tbaa !24
  br label %bb41
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = call i64 @compiler_2fscope_2eflRoot(ptr %v1, ptr %t114)
  store i64 %t116, ptr %l58
  br label %bb39
bb39:
  %t117 = load i64, ptr %l58, !tbaa !24
  store i64 %t117, ptr %l7, !tbaa !24
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_e9ea5d5d3867ce51_dfb99b888a23f285)
  unreachable
bb41:
  %t118 = load i64, ptr %l7, !tbaa !24
  store i64 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efnFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t20 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturesNothing(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %t17)
  store i1 %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load i1, ptr %l12, !tbaa !21
  store i1 %t21, ptr %l3, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7f2f0698823b265a_e0642f9ed23c39f6)
  unreachable
bb12:
  %t22 = load i1, ptr %l3, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforWrap(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l20 = alloca %"compiler/typed:BlockInfo"
  %l24 = alloca i1
  %l36 = alloca i64
  %l39 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca i1
  %l73 = alloca i1
  %l83 = alloca %"compiler/typed:Local"
  %l88 = alloca ptr
  %l89 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_6b4093eaa9dab6e0_ebbf8088c45502d4)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 8
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Block", ptr %t15, i32 0, i32 0
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t23 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t14, i64 %t20)
  store %"compiler/typed:BlockInfo" %t23, ptr %l20
  br label %bb4
bb4:
  %t24 = getelementptr %"compiler/typed:BlockInfo", ptr %l20, i32 0, i32 1
  %t25 = load i32, ptr %t24, !range !{i32 0, i32 9}
  %t27 = trunc i64 1 to i32
  %t28 = icmp eq i32 %t25, %t27
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb7
bb6:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Block", ptr %t32, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t39 = icmp slt i64 %t37, 2
  store i1 %t39, ptr %l24, !tbaa !21
  br label %bb7
bb7:
  %t41 = load i1, ptr %l24, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store i64 0, ptr %l2, !tbaa !24
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Block", ptr %t43, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  store i64 %t48, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb11, label %bb12
bb11:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb16
bb13:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t61 = load i64, ptr %l2, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l4, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l4, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l39, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb15
bb15:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l36, !tbaa !24
  br label %bb16
bb16:
  %t77 = load i64, ptr %l36, !tbaa !24
  store i64 %t77, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb18, label %bb19
bb18:
  br label %bb52
bb19:
  br label %bb20
bb20:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l7, !tbaa !24
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Block", ptr %t96, i32 0, i32 1
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l58, !tbaa !27
  %t100 = load i64, ptr %l7, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr ptr, ptr %t103, i64 %t100
  %t105 = load ptr, ptr %t104, !tbaa !39
  store ptr %t105, ptr %l8, !tbaa !29
  %t107 = load ptr, ptr %l8, !tbaa !29
  store ptr %t107, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t108 = load ptr, ptr %l61, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb21, label %bb22
bb21:
  %t111 = load ptr, ptr %l61, !tbaa !29
  %t112 = load i64, ptr %t111, !range !{i64 0, i64 17}
  %t114 = icmp eq i64 %t112, 0
  store i1 %t114, ptr %l62, !tbaa !21
  br label %bb22
bb22:
  %t115 = load i1, ptr %l62, !tbaa !21
  br i1 %t115, label %bb23, label %bb24
bb23:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t118 = getelementptr { i64, [3 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t118, i32 0, i32 1
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l9, !tbaa !23
  br label %bb25
bb24:
  br label %bb36
bb25:
  %t122 = load i64, ptr %l7, !tbaa !24
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Block", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t130 = sub i64 %t128, 1
  %t133 = icmp eq i64 %t122, %t130
  br i1 %t133, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb32
bb27:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/scope:Scoper", ptr %t135, i32 0, i32 25
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = icmp eq ptr %t138, null
  br i1 %t140, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_a83726b6934b3ff_5f714cf565db93e3)
  unreachable
bb29:
  br label %bb30
bb30:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/scope:Scoper", ptr %t142, i32 0, i32 25
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Body", ptr %t145, i32 0, i32 7
  %t149 = load i32, ptr %l9, !tbaa !23
  %t151 = sext i32 %t149 to i64
  %t154 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t148, i64 %t151)
  store %"compiler/typed:Local" %t154, ptr %l83
  br label %bb31
bb31:
  %t155 = getelementptr %"compiler/typed:Local", ptr %l83, i32 0, i32 4
  %t156 = load i32, ptr %t155, !range !{i32 0, i32 7}
  %t158 = trunc i64 1 to i32
  %t159 = icmp eq i32 %t156, %t158
  %t161 = xor i1 %t159, true
  store i1 %t161, ptr %l73, !tbaa !21
  br label %bb32
bb32:
  %t163 = load i1, ptr %l73, !tbaa !21
  br i1 %t163, label %bb33, label %bb34
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb50
bb36:
  %t165 = load ptr, ptr %l8, !tbaa !29
  store ptr %t165, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t166 = load ptr, ptr %l88, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb37, label %bb38
bb37:
  %t169 = load ptr, ptr %l88, !tbaa !29
  %t170 = load i64, ptr %t169, !range !{i64 0, i64 17}
  %t172 = icmp eq i64 %t170, 4
  store i1 %t172, ptr %l89, !tbaa !21
  br label %bb38
bb38:
  %t173 = load i1, ptr %l89, !tbaa !21
  br i1 %t173, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t174 = load i64, ptr %l7, !tbaa !24
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/typed:Block", ptr %t175, i32 0, i32 1
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t182 = sub i64 %t180, 1
  %t185 = icmp ne i64 %t174, %t182
  br i1 %t185, label %bb42, label %bb43
bb42:
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i1 false, ptr %rv
  br label %ret
bb49:
  call void @__olang_check_failed(ptr @olang_loc_2e96c7acbe66a05d_c52c59876e2a2911)
  unreachable
bb50:
  br label %bb51
bb51:
  %t189 = load i64, ptr %l6, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l6, !tbaa !24
  br label %bb17
bb52:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforcedBy(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/scope:rel"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca %"compiler/scope:rel"
  %l17 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l41 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb35
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v1, ptr %t13, i64 %t14)
  store %"compiler/scope:rel" %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load %"compiler/scope:rel", ptr %l14
  store %"compiler/scope:rel" %t18, ptr %l5
  %t19 = getelementptr %"compiler/scope:rel", ptr %l5, i32 0, i32 0
  %t20 = load { i64, [2 x i64] }, ptr %t19
  %t22 = extractvalue { i64, [2 x i64] } %t20, 0
  %t23 = icmp eq i64 %t22, 2
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = getelementptr %"compiler/scope:rel", ptr %l5, i32 0, i32 0
  %t26 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 1
  %t27 = getelementptr { i64 }, ptr %t26, i32 0, i32 0
  %t28 = load i64, ptr %t27
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = icmp eq i64 %t28, %t29
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = getelementptr %"compiler/scope:rel", ptr %l5, i32 0, i32 1
  %t36 = load { i64, [2 x i64] }, ptr %t35
  %t38 = extractvalue { i64, [2 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 2
  br i1 %t39, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb15
bb12:
  %t41 = getelementptr %"compiler/scope:rel", ptr %l5, i32 0, i32 1
  %t42 = getelementptr { i64, [2 x i64] }, ptr %t41, i32 0, i32 1
  %t43 = getelementptr { i64 }, ptr %t42, i32 0, i32 0
  %t44 = load i64, ptr %t43
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = icmp eq i64 %t44, %t45
  store i1 %t48, ptr %l24, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l24, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l21, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l21, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t55 = getelementptr %"compiler/scope:rel", ptr %l5, i32 0, i32 2
  %t56 = load i1, ptr %t55, !tbaa !21
  br i1 %t56, label %bb19, label %bb20
bb19:
  %t58 = getelementptr %"compiler/scope:rel", ptr %l5, i32 0, i32 1
  %t59 = load { i64, [2 x i64] }, ptr %t58
  %t61 = extractvalue { i64, [2 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 2
  br i1 %t62, label %bb21, label %bb22
bb20:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb24
bb21:
  %t64 = getelementptr %"compiler/scope:rel", ptr %l5, i32 0, i32 1
  %t65 = getelementptr { i64, [2 x i64] }, ptr %t64, i32 0, i32 1
  %t66 = getelementptr { i64 }, ptr %t65, i32 0, i32 0
  %t67 = load i64, ptr %t66
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp eq i64 %t67, %t68
  store i1 %t71, ptr %l34, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t73 = load i1, ptr %l34, !tbaa !21
  store i1 %t73, ptr %l31, !tbaa !21
  br label %bb24
bb24:
  %t74 = load i1, ptr %l31, !tbaa !21
  br i1 %t74, label %bb25, label %bb26
bb25:
  %t75 = getelementptr %"compiler/scope:rel", ptr %l5, i32 0, i32 0
  %t76 = load { i64, [2 x i64] }, ptr %t75
  %t78 = extractvalue { i64, [2 x i64] } %t76, 0
  %t79 = icmp eq i64 %t78, 2
  br i1 %t79, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb30
bb27:
  %t81 = getelementptr %"compiler/scope:rel", ptr %l5, i32 0, i32 0
  %t82 = getelementptr { i64, [2 x i64] }, ptr %t81, i32 0, i32 1
  %t83 = getelementptr { i64 }, ptr %t82, i32 0, i32 0
  %t84 = load i64, ptr %t83
  %t85 = load i64, ptr %l2, !tbaa !24
  %t88 = icmp eq i64 %t84, %t85
  store i1 %t88, ptr %l41, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb29
bb29:
  %t90 = load i1, ptr %l41, !tbaa !21
  %t91 = xor i1 %t90, true
  store i1 %t91, ptr %l38, !tbaa !21
  br label %bb30
bb30:
  %t93 = load i1, ptr %l38, !tbaa !21
  br i1 %t93, label %bb31, label %bb32
bb31:
  store i1 true, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t95 = load i64, ptr %l4, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l4, !tbaa !24
  br label %bb1
bb35:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egap(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3) #0 {
entry:
  %l5 = alloca ptr
  %l11 = alloca %"compiler/scope:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 3
  store ptr %t3, ptr %l5, !tbaa !29
  %t8 = extractvalue { i64, ptr } %a3, 1
  %t9 = extractvalue { i64, ptr } %a3, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t23 = call %"compiler/scope:Gap" @compiler_2fscope_3aGap_2ector(ptr %v0, ptr %v0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %t19)
  store %"compiler/scope:Gap" %t23, ptr %l11
  br label %bb1
bb1:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t25 = load %"compiler/scope:Gap", ptr %l11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ePush_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %v0, ptr %t24, %"compiler/scope:Gap" %t25)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBack(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i1
  %l11 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l26 = alloca ptr
  %l28 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l30 = alloca ptr
  %l32 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 139
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 142
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 60
  %t15 = load i1, ptr %t14, !tbaa !21
  %t17 = xor i1 %t15, true
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l7, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  store i1 %t22, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l11, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 144
  store ptr %t29, ptr %l16, !tbaa !29
  %t30 = load i64, ptr %l1, !tbaa !24
  %t32 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t30, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32, ptr %l18
  br label %bb13
bb13:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  %t35 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t33, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34)
  store i1 %t35, ptr %l19
  br label %bb14
bb14:
  %t36 = load i1, ptr %l19, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/scope:Scoper", ptr %t39, i32 0, i32 162
  store ptr %t41, ptr %l22, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t44 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t42, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t44, ptr %l24
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t45, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t46)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 144
  store ptr %t49, ptr %l26, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t50, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t52, ptr %l28
  br label %bb20
bb20:
  %t53 = load ptr, ptr %l26, !tbaa !29
  %t54 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l28
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t53, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t54, i1 true)
  br label %bb21
bb21:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %t55, i32 0, i32 160
  store ptr %t57, ptr %l30, !tbaa !29
  %t58 = load i64, ptr %l1, !tbaa !24
  %t60 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t58, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t60, ptr %l32
  br label %bb22
bb22:
  %t61 = load ptr, ptr %l30, !tbaa !29
  %t62 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t61, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t62)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l7 = alloca i64
  %l12 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v1, ptr %t1, ptr %t2, { i64, [2 x i64] } %a2)
  store i64 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i64, ptr %l7, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Call", ptr %t14, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l12, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackExpr(ptr %v0, ptr %v1, ptr %t13, ptr %t23)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackDerived(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l29 = alloca ptr
  %l38 = alloca i32
  %l40 = alloca %"compiler/typed:Local"
  %l42 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i64
  %l48 = alloca ptr
  %l55 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l56 = alloca i64
  %l57 = alloca i32
  %l60 = alloca i1
  %l63 = alloca i64
  %l66 = alloca i64
  %l68 = alloca ptr
  %l74 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  %t10 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t11 = getelementptr { i64, i64 }, ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb42
bb3:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l11, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 25
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb10
bb6:
  call void @__olang_check_failed(ptr @olang_loc_96b0618960354e24_3d02a19520d5ec20)
  unreachable
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 25
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 5
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l19
  br label %bb9
bb9:
  %t35 = load i64, ptr %l11, !tbaa !24
  %t36 = load i64, ptr %l19, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  store i1 %t37, ptr %l10, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l10, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l21, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l22, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/scope:Scoper", ptr %t42, i32 0, i32 25
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb13, label %bb14
bb12:
  br label %bb23
bb13:
  call void @__olang_check_failed(ptr @olang_loc_96b0618960354e24_3d02a19520d5ec20)
  unreachable
bb14:
  br label %bb15
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 25
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 7
  store ptr %t55, ptr %l29, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/scope:Scoper", ptr %t56, i32 0, i32 25
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  br i1 %t61, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_96b0618960354e24_3d02a19520d5ec20)
  unreachable
bb17:
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 25
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Body", ptr %t66, i32 0, i32 5
  %t70 = load i64, ptr %l2, !tbaa !24
  %t73 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t69, i64 %t70)
  store i32 %t73, ptr %l38
  br label %bb19
bb19:
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = sext i32 %t74 to i64
  %t76 = load ptr, ptr %l29, !tbaa !29
  %t78 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t76, i64 %t75)
  store %"compiler/typed:Local" %t78, ptr %l40
  br label %bb20
bb20:
  %t79 = getelementptr %"compiler/typed:Local", ptr %l40, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t81 = load ptr, ptr %l22, !tbaa !29
  %t83 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %t81, i32 %t80)
  store i64 %t83, ptr %l42
  br label %bb21
bb21:
  %t84 = load ptr, ptr %l21, !tbaa !29
  %t85 = load i64, ptr %l42, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBack(ptr %v0, ptr %t84, i64 %t85)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t88 = icmp sge i64 %t86, 0
  br i1 %t88, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l45, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/scope:Scoper", ptr %t91, i32 0, i32 133
  store ptr %t93, ptr %l48, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/scope:Scoper", ptr %t94, i32 0, i32 26
  %t97 = load i64, ptr %t96, !tbaa !24
  %t99 = mul i64 %t97, 65536
  %t100 = load i64, ptr %l2, !tbaa !24
  %t103 = add i64 %t99, %t100
  %t104 = load i64, ptr %l3, !tbaa !24
  %t107 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t103, i64 %t104)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t107, ptr %l55
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t109 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l55
  %t110 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t108, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t109)
  %t111 = extractvalue { i32, i64 } %t110, 1
  %t112 = extractvalue { i32, i64 } %t110, 0
  store i32 %t112, ptr %l57
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb28, label %ok.114, !prof !99
ok.114:
  store i64 %t111, ptr %l56
  br label %bb27
bb27:
  %t115 = load i64, ptr %l56, !tbaa !24
  store i64 %t115, ptr %l46, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l46, !tbaa !24
  br label %bb30
bb30:
  %t116 = load ptr, ptr %l45, !tbaa !29
  %t117 = load i64, ptr %l46, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBack(ptr %v0, ptr %t116, i64 %t117)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb32:
  %t118 = load i64, ptr %l2, !tbaa !24
  %t120 = icmp slt i64 %t118, 0
  br i1 %t120, label %bb33, label %bb34
bb33:
  %t122 = load i64, ptr %l2, !tbaa !24
  %t124 = sub i64 0, %t122
  %t126 = sub i64 %t124, 1
  store i64 %t126, ptr %l63, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/scope:Scoper", ptr %t127, i32 0, i32 91
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t129)
  store i64 %t131, ptr %l66
  br label %bb35
bb34:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb36
bb35:
  %t132 = load i64, ptr %l63, !tbaa !24
  %t133 = load i64, ptr %l66, !tbaa !24
  %t134 = icmp slt i64 %t132, %t133
  store i1 %t134, ptr %l60, !tbaa !21
  br label %bb36
bb36:
  %t136 = load i1, ptr %l60, !tbaa !21
  br i1 %t136, label %bb37, label %bb38
bb37:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l68, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/scope:Scoper", ptr %t138, i32 0, i32 91
  %t141 = load i64, ptr %l2, !tbaa !24
  %t143 = sub i64 0, %t141
  %t145 = sub i64 %t143, 1
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t140, i64 %t145)
  store i64 %t148, ptr %l74
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t149 = load ptr, ptr %l68, !tbaa !29
  %t150 = load i64, ptr %l74, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBack(ptr %v0, ptr %t149, i64 %t150)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_1224d6df3464748a_e87c09d967c04386)
  unreachable
bb47:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 139
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 142
  %t11 = load i1, ptr %t10, !tbaa !21
  %t13 = xor i1 %t11, true
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l7, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t16, ptr %a1)
  store ptr %t21, ptr %l14
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t22)
  store ptr %t23, ptr %l15
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 18}
  %t32 = icmp eq i64 %t30, 2
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb17
bb12:
  %t40 = load ptr, ptr %l2, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 18}
  %t47 = icmp eq i64 %t45, 3
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l23, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackPlace(ptr %v0, ptr %s0, ptr %t55, ptr %t56)
  br label %bb18
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_fe279d5820b85dad_458b53b3da9c6ff1)
  unreachable
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 139
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 142
  %t11 = load i1, ptr %t10, !tbaa !21
  %t13 = xor i1 %t11, true
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l9, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t33)
  store i32 %t35, ptr %l22
  br label %bb12
bb12:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = load i32, ptr %l22, !tbaa !23
  %t38 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %t36, i32 %t37)
  store i64 %t38, ptr %l23
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l19, !tbaa !29
  %t40 = load i64, ptr %l23, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBack(ptr %v0, ptr %t39, i64 %t40)
  br label %bb14
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackPlace(ptr %v0, ptr %v1, ptr %t41, ptr %t42)
  br label %bb15
bb15:
  br label %bb42
bb16:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t46 = load ptr, ptr %l26, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t53 = load i1, ptr %l27, !tbaa !21
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Elem", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackPlace(ptr %v0, ptr %v1, ptr %t60, ptr %t64)
  br label %bb22
bb22:
  br label %bb42
bb23:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t68 = load ptr, ptr %l35, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb24, label %bb25
bb24:
  %t71 = load ptr, ptr %l35, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 8}
  %t74 = icmp eq i64 %t72, 5
  store i1 %t74, ptr %l36, !tbaa !21
  br label %bb25
bb25:
  %t75 = load i1, ptr %l36, !tbaa !21
  br i1 %t75, label %bb26, label %bb27
bb26:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l4, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l4, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Payload", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackPlace(ptr %v0, ptr %v1, ptr %t82, ptr %t86)
  br label %bb29
bb29:
  br label %bb42
bb30:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t90 = load ptr, ptr %l44, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb31, label %bb32
bb31:
  %t93 = load ptr, ptr %l44, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 2
  store i1 %t96, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l45, !tbaa !21
  br i1 %t97, label %bb33, label %bb34
bb33:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l5, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackExpr(ptr %v0, ptr %v1, ptr %t104, ptr %t105)
  br label %bb36
bb36:
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_6ed8db51a3dfced1_45a76436772cba65)
  unreachable
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l9 = alloca i1
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisParam(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/scope:Scoper", ptr %t7, i32 0, i32 33
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t13, ptr %l9
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t14 = load i1, ptr %l9, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 32
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t21, i64 %t22)
  store { i64, [2 x i64] } %t25, ptr %l15
  br label %bb9
bb9:
  %t26 = load { i64, [2 x i64] }, ptr %l15
  %t27 = call i1 @compiler_2fscope_2etermGiven({ i64, [2 x i64] } %t26)
  store i1 %t27, ptr %l16
  br label %bb10
bb10:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l59 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenLocal(ptr %v0, ptr %t16, i64 %t19)
  store i1 %t22, ptr %l17
  br label %bb6
bb6:
  %t23 = load i1, ptr %l17, !tbaa !21
  store i1 %t23, ptr %l7, !tbaa !21
  br label %bb46
bb7:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t25 = load ptr, ptr %l18, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l18, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 8}
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb46
bb13:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb14, label %bb15
bb14:
  %t37 = load ptr, ptr %l22, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 8}
  %t40 = icmp eq i64 %t38, 3
  store i1 %t40, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t41 = load i1, ptr %l23, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t52 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenPlace(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store i1 %t52, ptr %l30
  br label %bb19
bb19:
  %t53 = load i1, ptr %l30, !tbaa !21
  store i1 %t53, ptr %l7, !tbaa !21
  br label %bb46
bb20:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb21, label %bb22
bb21:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 8}
  %t61 = icmp eq i64 %t59, 4
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb23, label %bb24
bb23:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Elem", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t76 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenPlace(ptr %v0, ptr %v1, ptr %t69, ptr %t73)
  store i1 %t76, ptr %l40
  br label %bb26
bb26:
  %t77 = load i1, ptr %l40, !tbaa !21
  store i1 %t77, ptr %l7, !tbaa !21
  br label %bb46
bb27:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t79 = load ptr, ptr %l41, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb28, label %bb29
bb28:
  %t82 = load ptr, ptr %l41, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l42, !tbaa !21
  br label %bb29
bb29:
  %t86 = load i1, ptr %l42, !tbaa !21
  br i1 %t86, label %bb30, label %bb31
bb30:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l5, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Payload", ptr %t94, i32 0, i32 0
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t100 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenPlace(ptr %v0, ptr %v1, ptr %t93, ptr %t97)
  store i1 %t100, ptr %l50
  br label %bb33
bb33:
  %t101 = load i1, ptr %l50, !tbaa !21
  store i1 %t101, ptr %l7, !tbaa !21
  br label %bb46
bb34:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb35, label %bb36
bb35:
  %t106 = load ptr, ptr %l51, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 8}
  %t109 = icmp eq i64 %t107, 2
  store i1 %t109, ptr %l52, !tbaa !21
  br label %bb36
bb36:
  %t110 = load i1, ptr %l52, !tbaa !21
  br i1 %t110, label %bb37, label %bb38
bb37:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l6, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t121 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenRef(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  store i1 %t121, ptr %l59
  br label %bb40
bb40:
  %t122 = load i1, ptr %l59, !tbaa !21
  store i1 %t122, ptr %l7, !tbaa !21
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_d375f47869e73b1e_ab7f910edbf0dc32)
  unreachable
bb46:
  %t123 = load i1, ptr %l7, !tbaa !21
  store i1 %t123, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandedOn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call i1 @compiler_2fscope_2eisParamRead(ptr %v1, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i1, ptr %l8, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i64 1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l1, !tbaa !29
  store ptr %t8, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 3
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = call i64 @compiler_2fscope_2eownField(ptr %v1, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l18
  br label %bb10
bb10:
  %t28 = load i64, ptr %l18, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  br i1 %t29, label %bb11, label %bb12
bb11:
  store i64 2, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb40
bb14:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb15, label %bb16
bb15:
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 18}
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb17, label %bb18
bb17:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb35
bb19:
  %t47 = load ptr, ptr %l4, !tbaa !29
  store ptr %t47, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t48 = load ptr, ptr %l27, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb20, label %bb21
bb20:
  %t51 = load ptr, ptr %l27, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 8}
  %t54 = icmp eq i64 %t52, 2
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb21
bb21:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l5, !tbaa !29
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = call i1 @compiler_2fscope_2eisParamRead(ptr %v1, ptr %t62, i64 %t63)
  store i1 %t66, ptr %l35
  br label %bb25
bb25:
  %t67 = load i1, ptr %l35, !tbaa !21
  br i1 %t67, label %bb26, label %bb27
bb26:
  store i64 3, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_9c7ebd2b12e06561_d1b788b185a2a0b5)
  unreachable
bb34:
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_e6e67a80e175cfd0_914d29e7454711c4)
  unreachable
bb40:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandedRegion(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca i64
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l3, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_9d00f6934855daa_c9673762d5df43fe)
  unreachable
bb16:
  br label %bb43
bb17:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb18, label %bb19
bb18:
  %t39 = load ptr, ptr %l21, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 3
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb19
bb19:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb20, label %bb21
bb20:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = call i64 @compiler_2fscope_2eregionRoot(ptr %v1, ptr %t50)
  store i64 %t52, ptr %l28
  br label %bb23
bb23:
  %t53 = load i64, ptr %l28, !tbaa !24
  store i64 %t53, ptr %rv
  br label %ret
bb24:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb25, label %bb26
bb25:
  %t58 = load ptr, ptr %l29, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 10
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb26
bb26:
  %t62 = load i1, ptr %l30, !tbaa !21
  br i1 %t62, label %bb27, label %bb28
bb27:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Slice", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = call i64 @compiler_2fscope_2eregionRoot(ptr %v1, ptr %t72)
  store i64 %t74, ptr %l37
  br label %bb30
bb30:
  %t75 = load i64, ptr %l37, !tbaa !24
  store i64 %t75, ptr %rv
  br label %ret
bb31:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t77 = load ptr, ptr %l38, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb32, label %bb33
bb32:
  %t80 = load ptr, ptr %l38, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 18}
  %t83 = icmp eq i64 %t81, 17
  store i1 %t83, ptr %l39, !tbaa !21
  br label %bb33
bb33:
  %t84 = load i1, ptr %l39, !tbaa !21
  br i1 %t84, label %bb34, label %bb35
bb34:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t95 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandedRegion(ptr %v0, ptr %v1, ptr %a0, ptr %t92)
  store i64 %t95, ptr %l46
  br label %bb37
bb37:
  %t96 = load i64, ptr %l46, !tbaa !24
  store i64 %t96, ptr %rv
  br label %ret
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_6f89170392198c6b_c18aa73f993179ff)
  unreachable
bb43:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t6, i32 %a1)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i1
  %l49 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb32
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 1
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l19
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 1
  %t33 = load { i64, [2 x i64] }, ptr %t32
  store { i64, [2 x i64] } %t33, ptr %l4
  %t35 = load { i64, [2 x i64] }, ptr %l4
  %t37 = extractvalue { i64, [2 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 0
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t41 = getelementptr { i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l5, !tbaa !24
  br label %bb9
bb8:
  br label %bb26
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l28, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l30, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l34
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l30, !tbaa !29
  %t67 = load i64, ptr %l34, !tbaa !24
  %t68 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t66, i64 %t67)
  store ptr %t68, ptr %l35
  br label %bb11
bb11:
  %t69 = load ptr, ptr %l35, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Func", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  %t73 = load ptr, ptr %l28, !tbaa !29
  %t75 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t73, i32 %t72)
  store { i64, ptr } %t75, ptr %l38
  br label %bb12
bb12:
  %t76 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t76, ptr %l6, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t77, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t79, ptr %l40
  br label %bb13
bb13:
  %t80 = load i1, ptr %l40, !tbaa !21
  br i1 %t80, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb17
bb15:
  %t81 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t81, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t83, ptr %l43
  br label %bb16
bb16:
  %t84 = load i1, ptr %l43, !tbaa !21
  store i1 %t84, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t85 = load i1, ptr %l41, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb21
bb19:
  %t86 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t86, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t88, ptr %l46
  br label %bb20
bb20:
  %t89 = load i1, ptr %l46, !tbaa !21
  store i1 %t89, ptr %l44, !tbaa !21
  br label %bb21
bb21:
  %t90 = load i1, ptr %l44, !tbaa !21
  br i1 %t90, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb25
bb23:
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t91, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t93, ptr %l49
  br label %bb24
bb24:
  %t94 = load i1, ptr %l49, !tbaa !21
  store i1 %t94, ptr %l47, !tbaa !21
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  %t95 = load i1, ptr %l47, !tbaa !21
  store i1 %t95, ptr %rv
  br label %ret
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_2d8599dd2a60d272_f2da26d46793a2d6)
  unreachable
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_8dedfa134432c6f3_d3b15d93042206f7)
  unreachable
bb37:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einferClaims(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 125
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 126
  store i1 false, ptr %t6, !tbaa !21
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudge(ptr %v0, ptr %t7, i64 %a1, i1 false)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 125
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 126
  %t17 = load i1, ptr %t16, !tbaa !21
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstContexts(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:Origin"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/generic:Origin"
  %l19 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l33 = alloca i64
  %l53 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l64 = alloca %"compiler/generic:Origin"
  %l77 = alloca i64
  %l81 = alloca i64
  %l84 = alloca i64
  %l102 = alloca ptr
  %l104 = alloca i64
  %l108 = alloca %"compiler/generic:Origin"
  %l109 = alloca ptr
  %l111 = alloca i64
  %l115 = alloca i64
  %l120 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l143 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i64
  %t254 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l24
  br label %bb4
bb4:
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l2
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l25
  br label %bb5
bb5:
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l3
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 32, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb11
bb8:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l33, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb10
bb10:
  %t38 = load i64, ptr %l33, !tbaa !24
  store i64 %t38, ptr %l30, !tbaa !24
  br label %bb11
bb11:
  %t39 = load i64, ptr %l30, !tbaa !24
  store i64 %t39, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb14:
  br label %bb15
bb15:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  store ptr %t63, ptr %l53, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/scope:Scoper", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t67, i64 %t68)
  store i32 %t71, ptr %l57
  br label %bb16
bb16:
  %t72 = load ptr, ptr %l53, !tbaa !29
  %t73 = load i32, ptr %l57, !tbaa !23
  %t74 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s3, ptr %t72, i32 %t73)
  store { i64, ptr } %t74, ptr %l58
  br label %bb17
bb17:
  %t75 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  %t78 = icmp eq i64 %t76, 0
  br i1 %t78, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb19:
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/scope:Scoper", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load i64, ptr %l4, !tbaa !24
  %t87 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t83, i64 %t84)
  store %"compiler/generic:Origin" %t87, ptr %l64
  br label %bb21
bb21:
  %t88 = load %"compiler/generic:Origin", ptr %l64
  store %"compiler/generic:Origin" %t88, ptr %l11
  %t89 = getelementptr %"compiler/generic:Origin", ptr %l11, i32 0, i32 0
  %t90 = load i64, ptr %t89, !tbaa !24
  %t92 = icmp slt i64 %t90, 0
  br i1 %t92, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t94 = load %"compiler/generic:Origin", ptr %l11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2ePush_3ccompiler_2fgeneric_3aOrigin_3e(ptr %s0, ptr %l2, %"compiler/generic:Origin" %t94)
  br label %bb25
bb25:
  %t97 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t97)
  br label %bb26
bb26:
  %t100 = getelementptr %"compiler/generic:Origin", ptr %l11, i32 0, i32 2
  %t101 = load i64, ptr %t100, !tbaa !24
  %t103 = icmp slt i64 %t101, 0
  br i1 %t103, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb28:
  br label %bb29
bb29:
  %t105 = getelementptr %"compiler/generic:Origin", ptr %l11, i32 0, i32 2
  %t106 = load i64, ptr %t105, !tbaa !24
  store i64 %t106, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t108 = load i64, ptr %l9, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l9, !tbaa !24
  br label %bb12
bb31:
  store i64 0, ptr %l12, !tbaa !24
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eLen_3ccompiler_2fgeneric_3aOrigin_3e(ptr %s0, ptr %l2)
  store i64 %t113, ptr %l77
  br label %bb32
bb32:
  %t114 = load i64, ptr %l77, !tbaa !24
  store i64 %t114, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb33, label %bb34
bb33:
  %t121 = load i64, ptr %l14, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb38
bb35:
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l14, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l84, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb37
bb37:
  %t141 = load i64, ptr %l84, !tbaa !24
  store i64 %t141, ptr %l81, !tbaa !24
  br label %bb38
bb38:
  %t142 = load i64, ptr %l81, !tbaa !24
  store i64 %t142, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s9
  %t143 = load i64, ptr %l16, !tbaa !24
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb41:
  br label %bb42
bb42:
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l16, !tbaa !24
  %t153 = load i64, ptr %l14, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l17, !tbaa !24
  store ptr %l2, ptr %l102, !tbaa !29
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eLen_3ccompiler_2fgeneric_3aOrigin_3e(ptr %s0, ptr %l2)
  store i64 %t162, ptr %l104
  br label %bb43
bb43:
  %t163 = load i64, ptr %l104, !tbaa !24
  %t164 = sub i64 %t163, 1
  %t165 = load i64, ptr %l17, !tbaa !24
  %t168 = sub i64 %t164, %t165
  %t169 = load ptr, ptr %l102, !tbaa !29
  %t171 = call %"compiler/generic:Origin" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eAt_3ccompiler_2fgeneric_3aOrigin_3e(ptr %s0, ptr %t169, i64 %t168)
  store %"compiler/generic:Origin" %t171, ptr %l108
  br label %bb44
bb44:
  %t172 = load %"compiler/generic:Origin", ptr %l108
  store %"compiler/generic:Origin" %t172, ptr %l18
  store ptr %l3, ptr %l109, !tbaa !29
  %t174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eLen_3ccompiler_2fgeneric_3aOrigin_3e(ptr %s0, ptr %l2)
  store i64 %t174, ptr %l111
  br label %bb45
bb45:
  %t175 = load i64, ptr %l111, !tbaa !24
  %t176 = sub i64 %t175, 1
  %t177 = load i64, ptr %l17, !tbaa !24
  %t180 = sub i64 %t176, %t177
  %t181 = load ptr, ptr %l109, !tbaa !29
  %t183 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t181, i64 %t180)
  store i64 %t183, ptr %l115
  br label %bb46
bb46:
  %t184 = load i64, ptr %l115, !tbaa !24
  store i64 %t184, ptr %l19, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/scope:Scoper", ptr %t185, i32 0, i32 4
  %t188 = load { ptr, ptr }, ptr %t187
  %t190 = extractvalue { ptr, ptr } %t188, 0
  %t191 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t192 = icmp eq ptr %t190, %t191
  %t193 = extractvalue { ptr, ptr } %t188, 1
  %t194 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t195 = icmp eq ptr %t193, %t194
  %t196 = and i1 %t192, %t195
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb47, label %bb48
bb47:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/scope:Scoper", ptr %t200, i32 0, i32 4
  %t203 = load { ptr, ptr }, ptr %t202
  %t205 = extractvalue { ptr, ptr } %t203, 0
  %t206 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t207 = icmp eq ptr %t205, %t206
  %t208 = extractvalue { ptr, ptr } %t203, 1
  %t209 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t210 = icmp eq ptr %t208, %t209
  %t211 = and i1 %t207, %t210
  br i1 %t211, label %bb49, label %bb50
bb48:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l120, !tbaa !27
  br label %bb53
bb49:
  call void @__olang_check_failed(ptr @olang_loc_74da5f49279f5443_41bd0bd1769c76af)
  unreachable
bb50:
  br label %bb51
bb51:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/scope:Scoper", ptr %t213, i32 0, i32 4
  %t216 = load { ptr, ptr }, ptr %t215
  %t217 = load i64, ptr %l19, !tbaa !24
  %t219 = extractvalue { ptr, ptr } %t216, 0
  %t220 = extractvalue { ptr, ptr } %t216, 1
  %t222 = call { i64, ptr } %t219(ptr %t220, ptr %s9, i64 %t217)
  store { i64, ptr } %t222, ptr %l127
  br label %bb52
bb52:
  %t223 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t225 = extractvalue { i64, ptr } %t223, 1
  %t226 = mul i64 %t224, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  store { i64, ptr } %t229, ptr %l120, !tbaa !27
  br label %bb53
bb53:
  %t231 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/scope:Scoper", ptr %t232, i32 0, i32 0
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 0
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = getelementptr %"compiler/load:Loader", ptr %t238, i32 0, i32 4
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t242 = getelementptr %"compiler/generic:Origin", ptr %l18, i32 0, i32 0
  %t243 = load i64, ptr %t242, !tbaa !24
  %t244 = getelementptr %"compiler/generic:Origin", ptr %l18, i32 0, i32 1
  %t245 = getelementptr %"compiler/source:Span", ptr %t244, i32 0, i32 0
  %t246 = load i32, ptr %t245, !tbaa !23
  %t248 = sext i32 %t246 to i64
  %t249 = getelementptr %"compiler/generic:Origin", ptr %l18, i32 0, i32 1
  %t250 = getelementptr %"compiler/source:Span", ptr %t249, i32 0, i32 1
  %t251 = load i32, ptr %t250, !tbaa !23
  %t253 = sext i32 %t251 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t254
  %t255 = getelementptr { i64, [3 x i64] }, ptr %t254, i32 0, i32 0
  store i64 3, ptr %t255
  %t257 = insertvalue { i64, i64, i64 } undef, i64 %t243, 0
  %t259 = insertvalue { i64, i64, i64 } %t257, i64 %t248, 1
  %t261 = insertvalue { i64, i64, i64 } %t259, i64 %t253, 2
  %t262 = getelementptr { i64, [3 x i64] }, ptr %t254, i32 0, i32 1
  store { i64, i64, i64 } %t261, ptr %t262
  %t263 = load { i64, [3 x i64] }, ptr %t254
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %s9, ptr %t241, { i64, [3 x i64] } %t263, { i64, ptr } %t231)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  %t268 = load i64, ptr %l16, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l16, !tbaa !24
  br label %bb39
bb56:
  %t273 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eLen_3ccompiler_2fgeneric_3aOrigin_3e(ptr %s0, ptr %l2)
  store i64 %t273, ptr %l143
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t274 = load i64, ptr %l143, !tbaa !24
  store i64 %t274, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceArgs(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l11 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t20, i64 %t21)
  store i32 %t24, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t25 = load ptr, ptr %l11, !tbaa !29
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t25, i32 %t26)
  store { i64, ptr } %t27, ptr %l16
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t31 = icmp sgt i64 %t29, 0
  store i1 %t31, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i1, ptr %l8, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisAdapter(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 3}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_a5122b0b395bd8b_9870aa37c8b5f2ef)
  unreachable
bb16:
  br label %bb29
bb17:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb18, label %bb19
bb18:
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 18}
  %t33 = icmp eq i64 %t31, 17
  store i1 %t33, ptr %l16, !tbaa !21
  br label %bb19
bb19:
  %t34 = load i1, ptr %l16, !tbaa !21
  br i1 %t34, label %bb20, label %bb21
bb20:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t45 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisAdapter(ptr %v0, ptr %v1, ptr %a0, ptr %t42)
  store i1 %t45, ptr %l23
  br label %bb23
bb23:
  %t46 = load i1, ptr %l23, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_51a7ef38ab67534a_42b12633f9b5762e)
  unreachable
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisCtor(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d38420f770b56a25_293628bae4d10df9)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 1
  %t15 = load { i64, [2 x i64] }, ptr %t14
  %t19 = extractvalue { i64, [2 x i64] } %t15, 0
  %t20 = icmp eq i64 %t19, 1
  br i1 %t20, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7d2ed71f654b640d_ba09ac545853f0c1)
  unreachable
bb12:
  %t22 = load i1, ptr %l9, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %a0, i32 %t17)
  store i1 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4d20f13e93e5e00_8edf44d94b0465ac)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eitemKind(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 5}
  %t3 = trunc i64 1 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load i64, ptr @G_2ecompiler_2fscope_2eFitPayload, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb15
bb4:
  %t8 = load i32, ptr %l1, !range !{i32 0, i32 5}
  %t10 = trunc i64 2 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t13 = load i32, ptr %l1, !range !{i32 0, i32 5}
  %t15 = trunc i64 3 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t18 = load i64, ptr @G_2ecompiler_2fscope_2eFitElem, !tbaa !24
  store i64 %t18, ptr %l2, !tbaa !24
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t20 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  store i64 %t20, ptr %l2, !tbaa !24
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_6eab74aa3e0b63d9_475cda0f5b688a85)
  unreachable
bb15:
  %t22 = load i64, ptr %l2, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudge(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:Local"
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca { i64, [1 x i64] }
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca %"compiler/scope:rel"
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l49 = alloca ptr
  %l55 = alloca i64
  %l57 = alloca i64
  %l62 = alloca %"compiler/typed:Local"
  %l69 = alloca i1
  %l74 = alloca i1
  %l77 = alloca i1
  %l147 = alloca i1
  %l150 = alloca i1
  %l154 = alloca ptr
  %l159 = alloca i64
  %l168 = alloca ptr
  %l170 = alloca %"compiler/typed:Plan"
  %l185 = alloca i1
  %l188 = alloca i64
  %l192 = alloca i64
  %l195 = alloca i64
  %l233 = alloca { i64, [1 x i64] }
  %l239 = alloca i64
  %l241 = alloca i1
  %l242 = alloca i32
  %l245 = alloca i32
  %l268 = alloca ptr
  %l273 = alloca i64
  %l274 = alloca i64
  %l275 = alloca ptr
  %l278 = alloca i64
  %l279 = alloca i64
  %l280 = alloca ptr
  %l281 = alloca %"compiler/source:Span"
  %l282 = alloca ptr
  %l283 = alloca %"compiler/source:Span"
  %l286 = alloca i1
  %l290 = alloca i1
  %l294 = alloca i1
  %l298 = alloca ptr
  %l300 = alloca %"compiler/source:Span"
  %l301 = alloca %"compiler/msgs:Msg"
  %l302 = alloca i64
  %l303 = alloca ptr
  %l304 = alloca i64
  %l306 = alloca i64
  %l308 = alloca %"compiler/source:Span"
  %l309 = alloca %"compiler/msgs:Msg"
  %l315 = alloca i64
  %l318 = alloca i64
  %l347 = alloca i64
  %l350 = alloca i64
  %l352 = alloca i64
  %l357 = alloca %"compiler/scope:rel"
  %l361 = alloca ptr
  %l370 = alloca ptr
  %l379 = alloca i64
  %l381 = alloca i64
  %l386 = alloca { i64, [2 x i64] }
  %l402 = alloca i64
  %l406 = alloca i64
  %l409 = alloca i64
  %l428 = alloca ptr
  %l432 = alloca i1
  %l434 = alloca ptr
  %l438 = alloca i1
  %l440 = alloca ptr
  %l444 = alloca i64
  %l446 = alloca ptr
  %l450 = alloca %"compiler/source:Span"
  %l457 = alloca i64
  %l461 = alloca i64
  %l464 = alloca i64
  %l488 = alloca { i64, ptr }
  %l489 = alloca i64
  %l493 = alloca i1
  %l498 = alloca ptr
  %l499 = alloca i64
  %l501 = alloca %"compiler/typed:Plan"
  %l503 = alloca %"compiler/typed:Plan"
  %s0 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %t253 = alloca { i64, [2 x i64] }, align 8
  %t266 = alloca %"compiler/typed:Plan", align 8
  %t949 = alloca %"compiler/typed:Plan", align 8
  %t953 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l49
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l49, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 7
  store ptr %t18, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  store i64 %t20, ptr %l55, !tbaa !24
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l57
  br label %bb6
bb6:
  %t24 = load i64, ptr %l55, !tbaa !24
  %t25 = load i64, ptr %l57, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t30, i64 %t31)
  store %"compiler/typed:Local" %t34, ptr %l62
  br label %bb10
bb10:
  %t35 = load %"compiler/typed:Local", ptr %l62
  store %"compiler/typed:Local" %t35, ptr %l6
  %t36 = getelementptr %"compiler/typed:Local", ptr %l6, i32 0, i32 2
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t41 = icmp eq i32 %t37, %t38
  br i1 %t41, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l5, !tbaa !24
  br label %bb5
bb15:
  %t47 = load i1, ptr %l2, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 48
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = icmp ne i64 %t52, %t53
  store i1 %t56, ptr %l69, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l69, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i64, ptr %l1, !tbaa !24
  %t63 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehasLateLocals(ptr %v0, ptr %t59, i64 %t60)
  store i1 %t63, ptr %l77
  br label %bb21
bb20:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb22
bb21:
  %t64 = load i1, ptr %l77, !tbaa !21
  store i1 %t64, ptr %l74, !tbaa !21
  br label %bb22
bb22:
  %t65 = load i1, ptr %l74, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 48
  store i64 %t67, ptr %t70, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/scope:Scoper", ptr %t71, i32 0, i32 50
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H075aca2c24d2905e4fa457b6b6d6570e(ptr %v0, ptr %t73)
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/scope:Scoper", ptr %t75, i32 0, i32 51
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t77)
  br label %bb26
bb26:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/scope:Scoper", ptr %t79, i32 0, i32 52
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t81)
  br label %bb27
bb27:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 49
  store i1 true, ptr %t85, !tbaa !21
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/scope:Scoper", ptr %t86, i32 0, i32 125
  %t89 = load i1, ptr %t88, !tbaa !21
  store i1 %t89, ptr %l7, !tbaa !21
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/scope:Scoper", ptr %t91, i32 0, i32 125
  store i1 false, ptr %t93, !tbaa !21
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudge(ptr %v0, ptr %t94, i64 %t95, i1 false)
  br label %bb28
bb28:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i1, ptr %l7, !tbaa !21
  %t102 = getelementptr %"compiler/scope:Scoper", ptr %t98, i32 0, i32 125
  store i1 %t99, ptr %t102, !tbaa !21
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/scope:Scoper", ptr %t103, i32 0, i32 49
  store i1 false, ptr %t105, !tbaa !21
  br label %bb29
bb29:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/scope:Scoper", ptr %t106, i32 0, i32 11
  %t109 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t108, i64 %t109, i1 true)
  br label %bb30
bb30:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t117 = getelementptr %"compiler/scope:Scoper", ptr %t112, i32 0, i32 25
  store ptr %t113, ptr %t117, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i64, ptr %l1, !tbaa !24
  %t122 = getelementptr %"compiler/scope:Scoper", ptr %t118, i32 0, i32 26
  store i64 %t119, ptr %t122, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t125)
  br label %bb31
bb31:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/scope:Scoper", ptr %t127, i32 0, i32 32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t129)
  br label %bb32
bb32:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/scope:Scoper", ptr %t131, i32 0, i32 134
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t133)
  br label %bb33
bb33:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/scope:Scoper", ptr %t135, i32 0, i32 135
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t137)
  br label %bb34
bb34:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %t139, i32 0, i32 33
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t141)
  br label %bb35
bb35:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/scope:Scoper", ptr %t143, i32 0, i32 34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t145)
  br label %bb36
bb36:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/scope:Scoper", ptr %t147, i32 0, i32 74
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t149)
  br label %bb37
bb37:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/scope:Scoper", ptr %t151, i32 0, i32 35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eClear_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t153)
  br label %bb38
bb38:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/scope:Scoper", ptr %t155, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t157)
  br label %bb39
bb39:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/scope:Scoper", ptr %t159, i32 0, i32 37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t161)
  br label %bb40
bb40:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/scope:Scoper", ptr %t163, i32 0, i32 40
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %t165)
  br label %bb41
bb41:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/scope:Scoper", ptr %t167, i32 0, i32 41
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %t169)
  br label %bb42
bb42:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/scope:Scoper", ptr %t171, i32 0, i32 42
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %t173)
  br label %bb43
bb43:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/scope:Scoper", ptr %t175, i32 0, i32 43
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t177)
  br label %bb44
bb44:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/scope:Scoper", ptr %t179, i32 0, i32 44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t181)
  br label %bb45
bb45:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/scope:Scoper", ptr %t183, i32 0, i32 45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t185)
  br label %bb46
bb46:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/scope:Scoper", ptr %t187, i32 0, i32 46
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t189)
  br label %bb47
bb47:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/scope:Scoper", ptr %t191, i32 0, i32 53
  store i64 -1, ptr %t193, !tbaa !24
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/scope:Scoper", ptr %t194, i32 0, i32 55
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t196)
  br label %bb48
bb48:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/scope:Scoper", ptr %t198, i32 0, i32 56
  store i1 false, ptr %t200, !tbaa !21
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/scope:Scoper", ptr %t201, i32 0, i32 57
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eClea_Hf36a88772899b36a46c039ef55a38999(ptr %v0, ptr %t203)
  br label %bb49
bb49:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/scope:Scoper", ptr %t205, i32 0, i32 39
  store i64 -1, ptr %t207, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/scope:Scoper", ptr %t208, i32 0, i32 65
  store i64 -1, ptr %t210, !tbaa !24
  %t211 = load ptr, ptr %l3, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Body", ptr %t211, i32 0, i32 14
  %t214 = load i1, ptr %t213, !tbaa !21
  br i1 %t214, label %bb50, label %bb51
bb50:
  %t216 = load ptr, ptr %l3, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Body", ptr %t216, i32 0, i32 16
  %t219 = load i1, ptr %t218, !tbaa !21
  store i1 %t219, ptr %l147, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb52
bb52:
  %t221 = load i1, ptr %l147, !tbaa !21
  br i1 %t221, label %bb53, label %bb54
bb53:
  %t222 = load ptr, ptr %l3, !tbaa !29
  %t224 = getelementptr %"compiler/typed:Body", ptr %t222, i32 0, i32 15
  %t225 = load i32, ptr %t224, !tbaa !23
  %t227 = icmp sge i32 %t225, 0
  store i1 %t227, ptr %l150, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb55
bb55:
  %t229 = load i1, ptr %l150, !tbaa !21
  br i1 %t229, label %bb56, label %bb57
bb56:
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l154, !tbaa !29
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load i64, ptr %l1, !tbaa !24
  %t233 = load ptr, ptr %l3, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Body", ptr %t233, i32 0, i32 15
  %t236 = load i32, ptr %t235, !tbaa !23
  %t240 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecaptureVar(ptr %v0, ptr %t231, i64 %t232, i32 %t236)
  store i64 %t240, ptr %l159
  br label %bb58
bb57:
  br label %bb59
bb58:
  %t241 = load i64, ptr %l159, !tbaa !24
  %t242 = load ptr, ptr %l154, !tbaa !29
  %t243 = getelementptr %"compiler/scope:Scoper", ptr %t242, i32 0, i32 65
  store i64 %t241, ptr %t243, !tbaa !24
  br label %bb59
bb59:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/scope:Scoper", ptr %t244, i32 0, i32 66
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %t246)
  br label %bb60
bb60:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/scope:Scoper", ptr %t248, i32 0, i32 68
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t250)
  br label %bb61
bb61:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [2 x i64] }, ptr %t253, i32 0, i32 0
  store i64 0, ptr %t254
  %t255 = load { i64, [2 x i64] }, ptr %t253
  %t258 = getelementptr %"compiler/scope:Scoper", ptr %t252, i32 0, i32 67
  store { i64, [2 x i64] } %t255, ptr %t258
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i1, ptr %l2, !tbaa !21
  %t263 = getelementptr %"compiler/scope:Scoper", ptr %t259, i32 0, i32 27
  store i1 %t260, ptr %t263, !tbaa !21
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l168, !tbaa !29
  %t265 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2eNewPlan(ptr %t266, ptr %v0, ptr %v0, ptr %t265)
  call void @llvm.memmove.p0.p0.i64(ptr %l170, ptr %t266, i64 176, i1 false)
  br label %bb62
bb62:
  %t268 = load ptr, ptr %l168, !tbaa !29
  %t269 = getelementptr %"compiler/scope:Scoper", ptr %t268, i32 0, i32 30
  call void @llvm.memmove.p0.p0.i64(ptr %t269, ptr %l170, i64 176, i1 false)
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/scope:Scoper", ptr %t270, i32 0, i32 58
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t272)
  br label %bb63
bb63:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/scope:Scoper", ptr %t274, i32 0, i32 59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t276)
  br label %bb64
bb64:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/scope:Scoper", ptr %t278, i32 0, i32 61
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t280)
  br label %bb65
bb65:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/scope:Scoper", ptr %t282, i32 0, i32 62
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t284)
  br label %bb66
bb66:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/scope:Scoper", ptr %t286, i32 0, i32 63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t288)
  br label %bb67
bb67:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/scope:Scoper", ptr %t290, i32 0, i32 64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t292)
  br label %bb68
bb68:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load ptr, ptr %l3, !tbaa !29
  %t298 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStr(ptr %v0, ptr %v0, ptr %t294, ptr %t295)
  store i1 %t298, ptr %l185
  br label %bb69
bb69:
  %t299 = load i1, ptr %l185, !tbaa !21
  store i1 %t299, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  %t300 = load ptr, ptr %l3, !tbaa !29
  %t302 = getelementptr %"compiler/typed:Body", ptr %t300, i32 0, i32 6
  %t304 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t302)
  store i64 %t304, ptr %l188
  br label %bb70
bb70:
  %t305 = load i64, ptr %l188, !tbaa !24
  store i64 %t305, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t306 = load i64, ptr %l10, !tbaa !24
  %t307 = load i64, ptr %l9, !tbaa !24
  %t310 = icmp sgt i64 %t306, %t307
  br i1 %t310, label %bb71, label %bb72
bb71:
  %t312 = load i64, ptr %l11, !tbaa !24
  %t314 = icmp sgt i64 %t312, 0
  br i1 %t314, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l192, !tbaa !24
  br label %bb76
bb73:
  %t316 = load i64, ptr %l10, !tbaa !24
  %t317 = load i64, ptr %l9, !tbaa !24
  %t320 = sub i64 %t316, %t317
  %t321 = load i64, ptr %l11, !tbaa !24
  %t324 = add i64 %t320, %t321
  %t326 = sub i64 %t324, 1
  %t327 = load i64, ptr %l11, !tbaa !24
  %t330 = sdiv i64 %t326, %t327
  store i64 %t330, ptr %l195, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l195, !tbaa !24
  br label %bb75
bb75:
  %t332 = load i64, ptr %l195, !tbaa !24
  store i64 %t332, ptr %l192, !tbaa !24
  br label %bb76
bb76:
  %t333 = load i64, ptr %l192, !tbaa !24
  store i64 %t333, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb77
bb77:
  %t334 = load i64, ptr %l13, !tbaa !24
  %t335 = load i64, ptr %l12, !tbaa !24
  %t338 = icmp slt i64 %t334, %t335
  %t340 = xor i1 %t338, true
  br i1 %t340, label %bb78, label %bb79
bb78:
  br label %bb106
bb79:
  br label %bb80
bb80:
  %t342 = load i64, ptr %l9, !tbaa !24
  %t343 = load i64, ptr %l13, !tbaa !24
  %t344 = load i64, ptr %l11, !tbaa !24
  %t347 = mul i64 %t343, %t344
  %t350 = add i64 %t342, %t347
  store i64 %t350, ptr %l14, !tbaa !24
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/scope:Scoper", ptr %t352, i32 0, i32 58
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t354, i1 false)
  br label %bb81
bb81:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/scope:Scoper", ptr %t356, i32 0, i32 59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t358, i1 false)
  br label %bb82
bb82:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/scope:Scoper", ptr %t360, i32 0, i32 61
  %t363 = load ptr, ptr %l3, !tbaa !29
  %t365 = getelementptr %"compiler/typed:Body", ptr %t363, i32 0, i32 4
  %t366 = load %"compiler/source:Span", ptr %t365
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t362, %"compiler/source:Span" %t366)
  br label %bb83
bb83:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/scope:Scoper", ptr %t369, i32 0, i32 62
  %t372 = load ptr, ptr %l3, !tbaa !29
  %t374 = getelementptr %"compiler/typed:Body", ptr %t372, i32 0, i32 3
  %t375 = load i64, ptr %t374, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t371, i64 %t375)
  br label %bb84
bb84:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/scope:Scoper", ptr %t378, i32 0, i32 63
  %t381 = load ptr, ptr %l3, !tbaa !29
  %t383 = getelementptr %"compiler/typed:Body", ptr %t381, i32 0, i32 4
  %t384 = load %"compiler/source:Span", ptr %t383
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t380, %"compiler/source:Span" %t384)
  br label %bb85
bb85:
  store i1 false, ptr %l15, !tbaa !21
  %t387 = load i1, ptr %l8, !tbaa !21
  br i1 %t387, label %bb86, label %bb87
bb86:
  %t389 = load ptr, ptr %l3, !tbaa !29
  %t391 = getelementptr %"compiler/typed:Body", ptr %t389, i32 0, i32 6
  %t392 = load i64, ptr %l14, !tbaa !24
  %t395 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t391, i64 %t392)
  store { i64, [1 x i64] } %t395, ptr %l233
  br label %bb88
bb87:
  br label %bb103
bb88:
  %t396 = load { i64, [1 x i64] }, ptr %l233
  store { i64, [1 x i64] } %t396, ptr %l16
  %t397 = load { i64, [1 x i64] }, ptr %l16
  %t399 = extractvalue { i64, [1 x i64] } %t397, 0
  %t400 = icmp eq i64 %t399, 0
  br i1 %t400, label %bb89, label %bb90
bb89:
  %t402 = getelementptr { i64, [1 x i64] }, ptr %l16, i32 0, i32 1
  %t403 = getelementptr { i32 }, ptr %t402, i32 0, i32 0
  %t404 = load i32, ptr %t403
  store i32 %t404, ptr %l17, !tbaa !23
  br label %bb91
bb90:
  br label %bb97
bb91:
  %t406 = load ptr, ptr %l3, !tbaa !29
  %t408 = getelementptr %"compiler/typed:Body", ptr %t406, i32 0, i32 5
  %t410 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t408)
  store i64 %t410, ptr %l239
  br label %bb92
bb92:
  %t411 = load i64, ptr %l239, !tbaa !24
  %t412 = icmp sgt i64 %t411, 0
  br i1 %t412, label %bb93, label %bb94
bb93:
  %t414 = load i32, ptr %l17, !tbaa !23
  store i32 %t414, ptr %l242, !tbaa !23
  %t415 = load ptr, ptr %l3, !tbaa !29
  %t417 = getelementptr %"compiler/typed:Body", ptr %t415, i32 0, i32 5
  %t419 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t417, i64 0)
  store i32 %t419, ptr %l245
  br label %bb95
bb94:
  store i1 false, ptr %l241, !tbaa !21
  br label %bb96
bb95:
  %t420 = load i32, ptr %l242, !tbaa !23
  %t421 = load i32, ptr %l245, !tbaa !23
  %t422 = icmp eq i32 %t420, %t421
  store i1 %t422, ptr %l241, !tbaa !21
  br label %bb96
bb96:
  %t424 = load i1, ptr %l241, !tbaa !21
  store i1 %t424, ptr %l15, !tbaa !21
  br label %bb102
bb97:
  br i1 true, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_75ea16a293881b53_a3e5ee6d3f4964f)
  unreachable
bb102:
  br label %bb103
bb103:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/scope:Scoper", ptr %t425, i32 0, i32 64
  %t428 = load i1, ptr %l15, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t427, i1 %t428)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t431 = load i64, ptr %l13, !tbaa !24
  %t433 = add i64 %t431, 1
  store i64 %t433, ptr %l13, !tbaa !24
  br label %bb77
bb106:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/scope:Scoper", ptr %t435, i32 0, i32 89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t437)
  br label %bb107
bb107:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/scope:Scoper", ptr %t439, i32 0, i32 90
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t441)
  br label %bb108
bb108:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/scope:Scoper", ptr %t443, i32 0, i32 91
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t445)
  br label %bb109
bb109:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/scope:Scoper", ptr %t447, i32 0, i32 92
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %t449)
  br label %bb110
bb110:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/scope:Scoper", ptr %t451, i32 0, i32 93
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %t453)
  br label %bb111
bb111:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/scope:Scoper", ptr %t455, i32 0, i32 95
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t457)
  br label %bb112
bb112:
  store i64 0, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t459 = load i1, ptr %l2, !tbaa !21
  br i1 %t459, label %bb113, label %bb114
bb113:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/scope:Scoper", ptr %t461, i32 0, i32 0
  %t464 = load ptr, ptr %t463, !tbaa !29
  %t466 = getelementptr %"compiler/generic:Program", ptr %t464, i32 0, i32 0
  %t467 = load ptr, ptr %t466, !tbaa !29
  %t469 = getelementptr %"compiler/load:Loader", ptr %t467, i32 0, i32 4
  %t470 = load ptr, ptr %t469, !tbaa !29
  store ptr %t470, ptr %l268, !tbaa !29
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr %"compiler/scope:Scoper", ptr %t471, i32 0, i32 0
  %t474 = load ptr, ptr %t473, !tbaa !29
  %t476 = getelementptr %"compiler/generic:Program", ptr %t474, i32 0, i32 0
  %t477 = load ptr, ptr %t476, !tbaa !29
  %t479 = getelementptr %"compiler/load:Loader", ptr %t477, i32 0, i32 4
  %t480 = load ptr, ptr %t479, !tbaa !29
  %t482 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextDepth(ptr %v0, ptr %t480)
  store i64 %t482, ptr %l273
  br label %bb115
bb114:
  br label %bb119
bb115:
  %t483 = load ptr, ptr %l268, !tbaa !29
  %t484 = load i64, ptr %l273, !tbaa !24
  %t485 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextBase(ptr %v0, ptr %t483, i64 %t484)
  store i64 %t485, ptr %l274
  br label %bb116
bb116:
  %t486 = load i64, ptr %l274, !tbaa !24
  store i64 %t486, ptr %l19, !tbaa !24
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l275, !tbaa !29
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load i64, ptr %l1, !tbaa !24
  %t492 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %t488, i64 %t489)
  store i64 %t492, ptr %l278
  br label %bb117
bb117:
  %t493 = load ptr, ptr %l275, !tbaa !29
  %t494 = load i64, ptr %l278, !tbaa !24
  %t495 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstContexts(ptr %v0, ptr %t493, i64 %t494)
  store i64 %t495, ptr %l279
  br label %bb118
bb118:
  %t496 = load i64, ptr %l279, !tbaa !24
  store i64 %t496, ptr %l18, !tbaa !24
  br label %bb119
bb119:
  %t497 = load ptr, ptr %l0, !tbaa !29
  store ptr %t497, ptr %l280, !tbaa !29
  %t498 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t498, ptr %l281
  br label %bb120
bb120:
  %t499 = load %"compiler/source:Span", ptr %l281
  %t500 = load ptr, ptr %l280, !tbaa !29
  %t501 = getelementptr %"compiler/scope:Scoper", ptr %t500, i32 0, i32 28
  store %"compiler/source:Span" %t499, ptr %t501
  %t502 = load ptr, ptr %l0, !tbaa !29
  store ptr %t502, ptr %l282, !tbaa !29
  %t503 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t503, ptr %l283
  br label %bb121
bb121:
  %t504 = load %"compiler/source:Span", ptr %l283
  %t505 = load ptr, ptr %l282, !tbaa !29
  %t506 = getelementptr %"compiler/scope:Scoper", ptr %t505, i32 0, i32 29
  store %"compiler/source:Span" %t504, ptr %t506
  %t507 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erun(ptr %v0, ptr %t507)
  br label %bb122
bb122:
  %t509 = load i1, ptr %l2, !tbaa !21
  br i1 %t509, label %bb123, label %bb124
bb123:
  %t511 = load i1, ptr %l8, !tbaa !21
  store i1 %t511, ptr %l286, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l286, !tbaa !21
  br label %bb125
bb125:
  %t513 = load i1, ptr %l286, !tbaa !21
  br i1 %t513, label %bb126, label %bb127
bb126:
  %t514 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estrReceiver(ptr %v0, ptr %t514)
  br label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb129
bb129:
  %t516 = load i1, ptr %l2, !tbaa !21
  br i1 %t516, label %bb130, label %bb131
bb130:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t520 = getelementptr %"compiler/scope:Scoper", ptr %t518, i32 0, i32 28
  %t521 = getelementptr %"compiler/source:Span", ptr %t520, i32 0, i32 0
  %t522 = load i32, ptr %t521, !tbaa !23
  %t524 = icmp sge i32 %t522, 0
  store i1 %t524, ptr %l290, !tbaa !21
  br label %bb132
bb131:
  store i1 false, ptr %l290, !tbaa !21
  br label %bb132
bb132:
  %t526 = load i1, ptr %l290, !tbaa !21
  br i1 %t526, label %bb133, label %bb134
bb133:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr %"compiler/scope:Scoper", ptr %t527, i32 0, i32 29
  %t530 = getelementptr %"compiler/source:Span", ptr %t529, i32 0, i32 0
  %t531 = load i32, ptr %t530, !tbaa !23
  %t533 = icmp sge i32 %t531, 0
  store i1 %t533, ptr %l294, !tbaa !21
  br label %bb135
bb134:
  store i1 false, ptr %l294, !tbaa !21
  br label %bb135
bb135:
  %t535 = load i1, ptr %l294, !tbaa !21
  br i1 %t535, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s16
  %t536 = load ptr, ptr %l0, !tbaa !29
  store ptr %t536, ptr %l298, !tbaa !29
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = getelementptr %"compiler/scope:Scoper", ptr %t537, i32 0, i32 28
  %t540 = load %"compiler/source:Span", ptr %t539
  store %"compiler/source:Span" %t540, ptr %l300
  %t541 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeDestructor(ptr %s16, ptr %s16, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t541, ptr %l301
  br label %bb138
bb137:
  br label %bb142
bb138:
  %t542 = load ptr, ptr %l298, !tbaa !29
  %t543 = load %"compiler/source:Span", ptr %l300
  %t544 = load %"compiler/msgs:Msg", ptr %l301
  %t545 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s16, ptr %t542, %"compiler/source:Span" %t543, %"compiler/msgs:Msg" %t544)
  store i64 %t545, ptr %l302
  br label %bb139
bb139:
  %t546 = load i64, ptr %l302, !tbaa !24
  %t547 = load ptr, ptr %l0, !tbaa !29
  store ptr %t547, ptr %l303, !tbaa !29
  store i64 %t546, ptr %l304, !tbaa !24
  %t549 = load ptr, ptr %l3, !tbaa !29
  %t551 = getelementptr %"compiler/typed:Body", ptr %t549, i32 0, i32 3
  %t552 = load i64, ptr %t551, !tbaa !24
  store i64 %t552, ptr %l306, !tbaa !24
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t555 = getelementptr %"compiler/scope:Scoper", ptr %t553, i32 0, i32 29
  %t556 = load %"compiler/source:Span", ptr %t555
  store %"compiler/source:Span" %t556, ptr %l308
  %t557 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s16)
  store %"compiler/msgs:Msg" %t557, ptr %l309
  br label %bb140
bb140:
  %t558 = load ptr, ptr %l303, !tbaa !29
  %t559 = load i64, ptr %l304, !tbaa !24
  %t560 = load i64, ptr %l306, !tbaa !24
  %t561 = load %"compiler/source:Span", ptr %l308
  %t562 = load %"compiler/msgs:Msg", ptr %l309
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s16, ptr %t558, i64 %t559, i64 %t560, %"compiler/source:Span" %t561, %"compiler/msgs:Msg" %t562)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s16)
  br label %bb142
bb142:
  %t563 = load i1, ptr %l2, !tbaa !21
  br i1 %t563, label %bb143, label %bb144
bb143:
  store i64 0, ptr %l21, !tbaa !24
  %t565 = load i64, ptr %l18, !tbaa !24
  store i64 %t565, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t567 = load i64, ptr %l22, !tbaa !24
  %t568 = load i64, ptr %l21, !tbaa !24
  %t571 = icmp sgt i64 %t567, %t568
  br i1 %t571, label %bb145, label %bb146
bb144:
  br label %bb159
bb145:
  %t573 = load i64, ptr %l23, !tbaa !24
  %t575 = icmp sgt i64 %t573, 0
  br i1 %t575, label %bb147, label %bb148
bb146:
  store i64 0, ptr %l315, !tbaa !24
  br label %bb150
bb147:
  %t577 = load i64, ptr %l22, !tbaa !24
  %t578 = load i64, ptr %l21, !tbaa !24
  %t581 = sub i64 %t577, %t578
  %t582 = load i64, ptr %l23, !tbaa !24
  %t585 = add i64 %t581, %t582
  %t587 = sub i64 %t585, 1
  %t588 = load i64, ptr %l23, !tbaa !24
  %t591 = sdiv i64 %t587, %t588
  store i64 %t591, ptr %l318, !tbaa !24
  br label %bb149
bb148:
  store i64 0, ptr %l318, !tbaa !24
  br label %bb149
bb149:
  %t593 = load i64, ptr %l318, !tbaa !24
  store i64 %t593, ptr %l315, !tbaa !24
  br label %bb150
bb150:
  %t594 = load i64, ptr %l315, !tbaa !24
  store i64 %t594, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb151
bb151:
  %t595 = load i64, ptr %l25, !tbaa !24
  %t596 = load i64, ptr %l24, !tbaa !24
  %t599 = icmp slt i64 %t595, %t596
  %t601 = xor i1 %t599, true
  br i1 %t601, label %bb152, label %bb153
bb152:
  br label %bb157
bb153:
  br label %bb154
bb154:
  %t603 = load i64, ptr %l21, !tbaa !24
  %t604 = load i64, ptr %l25, !tbaa !24
  %t605 = load i64, ptr %l23, !tbaa !24
  %t608 = mul i64 %t604, %t605
  %t611 = add i64 %t603, %t608
  store i64 %t611, ptr %l26, !tbaa !24
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t615 = getelementptr %"compiler/scope:Scoper", ptr %t613, i32 0, i32 0
  %t616 = load ptr, ptr %t615, !tbaa !29
  %t618 = getelementptr %"compiler/generic:Program", ptr %t616, i32 0, i32 0
  %t619 = load ptr, ptr %t618, !tbaa !29
  %t621 = getelementptr %"compiler/load:Loader", ptr %t619, i32 0, i32 4
  %t622 = load ptr, ptr %t621, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %t622)
  br label %bb155
bb155:
  br label %bb156
bb156:
  %t624 = load i64, ptr %l25, !tbaa !24
  %t626 = add i64 %t624, 1
  store i64 %t626, ptr %l25, !tbaa !24
  br label %bb151
bb157:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr %"compiler/scope:Scoper", ptr %t628, i32 0, i32 0
  %t631 = load ptr, ptr %t630, !tbaa !29
  %t633 = getelementptr %"compiler/generic:Program", ptr %t631, i32 0, i32 0
  %t634 = load ptr, ptr %t633, !tbaa !29
  %t636 = getelementptr %"compiler/load:Loader", ptr %t634, i32 0, i32 4
  %t637 = load ptr, ptr %t636, !tbaa !29
  %t638 = load i64, ptr %l19, !tbaa !24
  %t641 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextBase(ptr %v0, ptr %t637, i64 %t638)
  store i64 %t641, ptr %l347
  br label %bb158
bb158:
  br label %bb159
bb159:
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t644 = getelementptr %"compiler/scope:Scoper", ptr %t642, i32 0, i32 35
  store ptr %t644, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb160
bb160:
  %t646 = load i64, ptr %l28, !tbaa !24
  store i64 %t646, ptr %l350, !tbaa !24
  %t647 = load ptr, ptr %l27, !tbaa !29
  %t649 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t647)
  store i64 %t649, ptr %l352
  br label %bb161
bb161:
  %t650 = load i64, ptr %l350, !tbaa !24
  %t651 = load i64, ptr %l352, !tbaa !24
  %t652 = icmp slt i64 %t650, %t651
  %t654 = xor i1 %t652, true
  br i1 %t654, label %bb162, label %bb163
bb162:
  br label %bb169
bb163:
  br label %bb164
bb164:
  %t656 = load ptr, ptr %l27, !tbaa !29
  %t657 = load i64, ptr %l28, !tbaa !24
  %t660 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t656, i64 %t657)
  store %"compiler/scope:rel" %t660, ptr %l357
  br label %bb165
bb165:
  %t661 = load %"compiler/scope:rel", ptr %l357
  store %"compiler/scope:rel" %t661, ptr %l29
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t664 = getelementptr %"compiler/scope:Scoper", ptr %t662, i32 0, i32 6
  %t665 = load i64, ptr %l1, !tbaa !24
  %t668 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t664, i64 %t665)
  store ptr %t668, ptr %l361
  br label %bb166
bb166:
  %t669 = load ptr, ptr %l361, !tbaa !29
  %t671 = getelementptr %"compiler/scope:summary", ptr %t669, i32 0, i32 0
  %t672 = load %"compiler/scope:rel", ptr %l29
  call void @compiler_2fscope_2ekeepRel(ptr %v0, ptr %t671, %"compiler/scope:rel" %t672)
  br label %bb167
bb167:
  br label %bb168
bb168:
  %t675 = load i64, ptr %l28, !tbaa !24
  %t677 = add i64 %t675, 1
  store i64 %t677, ptr %l28, !tbaa !24
  br label %bb160
bb169:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t681 = getelementptr %"compiler/scope:Scoper", ptr %t679, i32 0, i32 6
  %t682 = load i64, ptr %l1, !tbaa !24
  %t685 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t681, i64 %t682)
  store ptr %t685, ptr %l370
  br label %bb170
bb170:
  %t686 = load ptr, ptr %l370, !tbaa !29
  store ptr %t686, ptr %l30, !tbaa !29
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t688 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteFieldRecs(ptr %v0, ptr %v0, ptr %t687, ptr %t688)
  br label %bb171
bb171:
  %t691 = load ptr, ptr %l30, !tbaa !29
  %t693 = getelementptr %"compiler/scope:summary", ptr %t691, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t693)
  br label %bb172
bb172:
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t697 = getelementptr %"compiler/scope:Scoper", ptr %t695, i32 0, i32 56
  %t698 = load i1, ptr %t697, !tbaa !21
  br i1 %t698, label %bb173, label %bb174
bb173:
  %t700 = load ptr, ptr %l0, !tbaa !29
  %t702 = getelementptr %"compiler/scope:Scoper", ptr %t700, i32 0, i32 55
  store ptr %t702, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb175
bb174:
  br label %bb184
bb175:
  %t704 = load i64, ptr %l32, !tbaa !24
  store i64 %t704, ptr %l379, !tbaa !24
  %t705 = load ptr, ptr %l31, !tbaa !29
  %t707 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t705)
  store i64 %t707, ptr %l381
  br label %bb176
bb176:
  %t708 = load i64, ptr %l379, !tbaa !24
  %t709 = load i64, ptr %l381, !tbaa !24
  %t710 = icmp slt i64 %t708, %t709
  %t712 = xor i1 %t710, true
  br i1 %t712, label %bb177, label %bb178
bb177:
  br label %bb183
bb178:
  br label %bb179
bb179:
  %t714 = load ptr, ptr %l31, !tbaa !29
  %t715 = load i64, ptr %l32, !tbaa !24
  %t718 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t714, i64 %t715)
  store { i64, [2 x i64] } %t718, ptr %l386
  br label %bb180
bb180:
  %t719 = load { i64, [2 x i64] }, ptr %l386
  %t720 = load ptr, ptr %l30, !tbaa !29
  %t722 = getelementptr %"compiler/scope:summary", ptr %t720, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t722, { i64, [2 x i64] } %t719)
  br label %bb181
bb181:
  br label %bb182
bb182:
  %t726 = load i64, ptr %l32, !tbaa !24
  %t728 = add i64 %t726, 1
  store i64 %t728, ptr %l32, !tbaa !24
  br label %bb175
bb183:
  br label %bb184
bb184:
  %t730 = load ptr, ptr %l30, !tbaa !29
  %t732 = getelementptr %"compiler/scope:summary", ptr %t730, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t732)
  br label %bb185
bb185:
  %t734 = load ptr, ptr %l30, !tbaa !29
  %t736 = getelementptr %"compiler/scope:summary", ptr %t734, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t736)
  br label %bb186
bb186:
  %t738 = load ptr, ptr %l30, !tbaa !29
  %t740 = getelementptr %"compiler/scope:summary", ptr %t738, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t740)
  br label %bb187
bb187:
  %t742 = load ptr, ptr %l30, !tbaa !29
  %t744 = getelementptr %"compiler/scope:summary", ptr %t742, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t744)
  br label %bb188
bb188:
  store i64 0, ptr %l34, !tbaa !24
  %t746 = load ptr, ptr %l0, !tbaa !29
  %t748 = getelementptr %"compiler/scope:Scoper", ptr %t746, i32 0, i32 58
  %t750 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t748)
  store i64 %t750, ptr %l402
  br label %bb189
bb189:
  %t751 = load i64, ptr %l402, !tbaa !24
  store i64 %t751, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t752 = load i64, ptr %l35, !tbaa !24
  %t753 = load i64, ptr %l34, !tbaa !24
  %t756 = icmp sgt i64 %t752, %t753
  br i1 %t756, label %bb190, label %bb191
bb190:
  %t758 = load i64, ptr %l36, !tbaa !24
  %t760 = icmp sgt i64 %t758, 0
  br i1 %t760, label %bb192, label %bb193
bb191:
  store i64 0, ptr %l406, !tbaa !24
  br label %bb195
bb192:
  %t762 = load i64, ptr %l35, !tbaa !24
  %t763 = load i64, ptr %l34, !tbaa !24
  %t766 = sub i64 %t762, %t763
  %t767 = load i64, ptr %l36, !tbaa !24
  %t770 = add i64 %t766, %t767
  %t772 = sub i64 %t770, 1
  %t773 = load i64, ptr %l36, !tbaa !24
  %t776 = sdiv i64 %t772, %t773
  store i64 %t776, ptr %l409, !tbaa !24
  br label %bb194
bb193:
  store i64 0, ptr %l409, !tbaa !24
  br label %bb194
bb194:
  %t778 = load i64, ptr %l409, !tbaa !24
  store i64 %t778, ptr %l406, !tbaa !24
  br label %bb195
bb195:
  %t779 = load i64, ptr %l406, !tbaa !24
  store i64 %t779, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb196
bb196:
  %t780 = load i64, ptr %l38, !tbaa !24
  %t781 = load i64, ptr %l37, !tbaa !24
  %t784 = icmp slt i64 %t780, %t781
  %t786 = xor i1 %t784, true
  br i1 %t786, label %bb197, label %bb198
bb197:
  br label %bb209
bb198:
  br label %bb199
bb199:
  %t788 = load i64, ptr %l34, !tbaa !24
  %t789 = load i64, ptr %l38, !tbaa !24
  %t790 = load i64, ptr %l36, !tbaa !24
  %t793 = mul i64 %t789, %t790
  %t796 = add i64 %t788, %t793
  store i64 %t796, ptr %l39, !tbaa !24
  %t798 = load ptr, ptr %l30, !tbaa !29
  %t800 = getelementptr %"compiler/scope:summary", ptr %t798, i32 0, i32 1
  store ptr %t800, ptr %l428, !tbaa !29
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t803 = getelementptr %"compiler/scope:Scoper", ptr %t801, i32 0, i32 58
  %t804 = load i64, ptr %l39, !tbaa !24
  %t807 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t803, i64 %t804)
  store i1 %t807, ptr %l432
  br label %bb200
bb200:
  %t808 = load ptr, ptr %l428, !tbaa !29
  %t809 = load i1, ptr %l432, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t808, i1 %t809)
  br label %bb201
bb201:
  %t810 = load ptr, ptr %l30, !tbaa !29
  %t812 = getelementptr %"compiler/scope:summary", ptr %t810, i32 0, i32 2
  store ptr %t812, ptr %l434, !tbaa !29
  %t813 = load ptr, ptr %l0, !tbaa !29
  %t815 = getelementptr %"compiler/scope:Scoper", ptr %t813, i32 0, i32 59
  %t816 = load i64, ptr %l39, !tbaa !24
  %t819 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t815, i64 %t816)
  store i1 %t819, ptr %l438
  br label %bb202
bb202:
  %t820 = load ptr, ptr %l434, !tbaa !29
  %t821 = load i1, ptr %l438, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t820, i1 %t821)
  br label %bb203
bb203:
  %t822 = load ptr, ptr %l30, !tbaa !29
  %t824 = getelementptr %"compiler/scope:summary", ptr %t822, i32 0, i32 3
  store ptr %t824, ptr %l440, !tbaa !29
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t827 = getelementptr %"compiler/scope:Scoper", ptr %t825, i32 0, i32 62
  %t828 = load i64, ptr %l39, !tbaa !24
  %t831 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t827, i64 %t828)
  store i64 %t831, ptr %l444
  br label %bb204
bb204:
  %t832 = load ptr, ptr %l440, !tbaa !29
  %t833 = load i64, ptr %l444, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t832, i64 %t833)
  br label %bb205
bb205:
  %t834 = load ptr, ptr %l30, !tbaa !29
  %t836 = getelementptr %"compiler/scope:summary", ptr %t834, i32 0, i32 4
  store ptr %t836, ptr %l446, !tbaa !29
  %t837 = load ptr, ptr %l0, !tbaa !29
  %t839 = getelementptr %"compiler/scope:Scoper", ptr %t837, i32 0, i32 63
  %t840 = load i64, ptr %l39, !tbaa !24
  %t843 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t839, i64 %t840)
  store %"compiler/source:Span" %t843, ptr %l450
  br label %bb206
bb206:
  %t844 = load ptr, ptr %l446, !tbaa !29
  %t845 = load %"compiler/source:Span", ptr %l450
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t844, %"compiler/source:Span" %t845)
  br label %bb207
bb207:
  br label %bb208
bb208:
  %t846 = load i64, ptr %l38, !tbaa !24
  %t848 = add i64 %t846, 1
  store i64 %t848, ptr %l38, !tbaa !24
  br label %bb196
bb209:
  %t850 = load ptr, ptr %l0, !tbaa !29
  %t851 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecomputeKeeps(ptr %v0, ptr %v0, ptr %t850, ptr %t851)
  br label %bb210
bb210:
  store i64 0, ptr %l40, !tbaa !24
  %t854 = load ptr, ptr %l0, !tbaa !29
  %t856 = getelementptr %"compiler/scope:Scoper", ptr %t854, i32 0, i32 58
  %t858 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t856)
  store i64 %t858, ptr %l457
  br label %bb211
bb211:
  %t859 = load i64, ptr %l457, !tbaa !24
  store i64 %t859, ptr %l41, !tbaa !24
  store i64 1, ptr %l42, !tbaa !24
  %t860 = load i64, ptr %l41, !tbaa !24
  %t861 = load i64, ptr %l40, !tbaa !24
  %t864 = icmp sgt i64 %t860, %t861
  br i1 %t864, label %bb212, label %bb213
bb212:
  %t866 = load i64, ptr %l42, !tbaa !24
  %t868 = icmp sgt i64 %t866, 0
  br i1 %t868, label %bb214, label %bb215
bb213:
  store i64 0, ptr %l461, !tbaa !24
  br label %bb217
bb214:
  %t870 = load i64, ptr %l41, !tbaa !24
  %t871 = load i64, ptr %l40, !tbaa !24
  %t874 = sub i64 %t870, %t871
  %t875 = load i64, ptr %l42, !tbaa !24
  %t878 = add i64 %t874, %t875
  %t880 = sub i64 %t878, 1
  %t881 = load i64, ptr %l42, !tbaa !24
  %t884 = sdiv i64 %t880, %t881
  store i64 %t884, ptr %l464, !tbaa !24
  br label %bb216
bb215:
  store i64 0, ptr %l464, !tbaa !24
  br label %bb216
bb216:
  %t886 = load i64, ptr %l464, !tbaa !24
  store i64 %t886, ptr %l461, !tbaa !24
  br label %bb217
bb217:
  %t887 = load i64, ptr %l461, !tbaa !24
  store i64 %t887, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb218
bb218:
  %t888 = load i64, ptr %l44, !tbaa !24
  %t889 = load i64, ptr %l43, !tbaa !24
  %t892 = icmp slt i64 %t888, %t889
  %t894 = xor i1 %t892, true
  br i1 %t894, label %bb219, label %bb220
bb219:
  br label %bb227
bb220:
  br label %bb221
bb221:
  %t896 = load i64, ptr %l40, !tbaa !24
  %t897 = load i64, ptr %l44, !tbaa !24
  %t898 = load i64, ptr %l42, !tbaa !24
  %t901 = mul i64 %t897, %t898
  %t904 = add i64 %t896, %t901
  store i64 %t904, ptr %l45, !tbaa !24
  %t906 = load i64, ptr %l45, !tbaa !24
  %t907 = load ptr, ptr %l0, !tbaa !29
  %t909 = getelementptr %"compiler/scope:Scoper", ptr %t907, i32 0, i32 30
  %t910 = getelementptr %"compiler/typed:Plan", ptr %t909, i32 0, i32 2
  %t911 = load { i64, ptr }, ptr %t910, !tbaa !27
  %t913 = extractvalue { i64, ptr } %t911, 0
  %t916 = icmp slt i64 %t906, %t913
  br i1 %t916, label %bb222, label %bb223
bb222:
  %t918 = load ptr, ptr %l0, !tbaa !29
  %t920 = getelementptr %"compiler/scope:Scoper", ptr %t918, i32 0, i32 30
  %t921 = getelementptr %"compiler/typed:Plan", ptr %t920, i32 0, i32 2
  %t922 = load { i64, ptr }, ptr %t921, !tbaa !27
  store { i64, ptr } %t922, ptr %l488, !tbaa !27
  %t923 = load i64, ptr %l45, !tbaa !24
  store i64 %t923, ptr %l489, !tbaa !24
  %t924 = load ptr, ptr %l0, !tbaa !29
  %t926 = getelementptr %"compiler/scope:Scoper", ptr %t924, i32 0, i32 58
  %t927 = load i64, ptr %l45, !tbaa !24
  %t930 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t926, i64 %t927)
  store i1 %t930, ptr %l493
  br label %bb224
bb223:
  br label %bb225
bb224:
  %t931 = load i1, ptr %l493, !tbaa !21
  %t932 = load i64, ptr %l489, !tbaa !24
  %t933 = getelementptr { i64, ptr }, ptr %l488, i32 0, i32 1
  %t934 = load ptr, ptr %t933, !tbaa !27
  %t935 = getelementptr i1, ptr %t934, i64 %t932
  store i1 %t931, ptr %t935, !tbaa !31
  br label %bb225
bb225:
  br label %bb226
bb226:
  %t936 = load i64, ptr %l44, !tbaa !24
  %t938 = add i64 %t936, 1
  store i64 %t938, ptr %l44, !tbaa !24
  br label %bb218
bb227:
  %t940 = load i1, ptr %l2, !tbaa !21
  br i1 %t940, label %bb228, label %bb229
bb228:
  %t942 = load ptr, ptr %l0, !tbaa !29
  %t944 = getelementptr %"compiler/scope:Scoper", ptr %t942, i32 0, i32 2
  store ptr %t944, ptr %l498, !tbaa !29
  %t945 = load i64, ptr %l1, !tbaa !24
  store i64 %t945, ptr %l499, !tbaa !24
  %t946 = load ptr, ptr %l0, !tbaa !29
  %t948 = getelementptr %"compiler/scope:Scoper", ptr %t946, i32 0, i32 30
  call void @llvm.memmove.p0.p0.i64(ptr %l501, ptr %t948, i64 176, i1 false)
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t949, ptr %v0, ptr %l501)
  call void @llvm.memmove.p0.p0.i64(ptr %l503, ptr %t949, i64 176, i1 false)
  br label %bb230
bb229:
  br label %bb232
bb230:
  %t951 = load ptr, ptr %l498, !tbaa !29
  %t952 = load i64, ptr %l499, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t953, ptr %l503, i64 176, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eSetAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t951, i64 %t952, ptr %t953)
  br label %bb231
bb231:
  br label %bb232
bb232:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandByObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/scope:rel"
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca i64
  %l40 = alloca i64
  %l45 = alloca %"compiler/scope:rel"
  %l48 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l69 = alloca { i64, ptr }
  %l77 = alloca i1
  %l91 = alloca { i64, [2 x i64] }
  %l93 = alloca i1
  %l95 = alloca i1
  %l102 = alloca { i64, [2 x i64] }
  %l112 = alloca i1
  %l116 = alloca i1
  %l125 = alloca i64
  %l132 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t38 = alloca { i64, [2 x i64] }, align 8
  %t42 = alloca { i64, [2 x i64] }, align 8
  %t105 = alloca { i64, [2 x i64] }, align 8
  %t152 = alloca { i64, [2 x i64] }, align 8
  %t207 = alloca { i64, [2 x i64] }, align 8
  %t239 = alloca { i64, [2 x i64] }, align 8
  %t243 = alloca { i64, [2 x i64] }, align 8
  %t280 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l17
  br label %bb1
bb1:
  %t9 = load i64, ptr %l17, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Call", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t14 = load ptr, ptr %l19, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l19, !tbaa !29
  %t18 = load i64, ptr %t17, !range !{i64 0, i64 5}
  %t20 = icmp eq i64 %t18, 2
  store i1 %t20, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l20, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb4, label %bb5
bb4:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp slt i64 %t24, 0
  br i1 %t26, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb10
bb6:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t28, i64 %t29)
  store i1 %t32, ptr %l30
  br label %bb8
bb8:
  %t33 = load i1, ptr %l30, !tbaa !21
  %t34 = xor i1 %t33, true
  store i1 %t34, ptr %l27, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l27, !tbaa !21
  store i1 %t36, ptr %l24, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l24, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store { i64, [2 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 0
  store i64 0, ptr %t39
  %t40 = load { i64, [2 x i64] }, ptr %t38
  store { i64, [2 x i64] } %t40, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  store { i64, [2 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [2 x i64] }, ptr %t42, i32 0, i32 0
  store i64 0, ptr %t43
  %t44 = load { i64, [2 x i64] }, ptr %t42
  store { i64, [2 x i64] } %t44, ptr %l5
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t50 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallRels(ptr %v0, ptr %v1, ptr %s2, ptr %t46, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l36
  br label %bb14
bb14:
  %t51 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  %t52 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %t52
  store ptr %t52, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t54 = load i64, ptr %l7, !tbaa !24
  store i64 %t54, ptr %l38, !tbaa !24
  %t55 = load ptr, ptr %l6, !tbaa !29
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %s2, ptr %t55)
  store i64 %t57, ptr %l40
  br label %bb16
bb16:
  %t58 = load i64, ptr %l38, !tbaa !24
  %t59 = load i64, ptr %l40, !tbaa !24
  %t60 = icmp slt i64 %t58, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb17, label %bb18
bb17:
  br label %bb102
bb18:
  br label %bb19
bb19:
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %s2, ptr %t64, i64 %t65)
  store %"compiler/scope:rel" %t68, ptr %l45
  br label %bb20
bb20:
  %t69 = load %"compiler/scope:rel", ptr %l45
  store %"compiler/scope:rel" %t69, ptr %l8
  %t70 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 1
  %t71 = load { i64, [2 x i64] }, ptr %t70
  %t73 = extractvalue { i64, [2 x i64] } %t71, 0
  %t74 = icmp eq i64 %t73, 2
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 1
  %t77 = getelementptr { i64, [2 x i64] }, ptr %t76, i32 0, i32 1
  %t78 = getelementptr { i64 }, ptr %t77, i32 0, i32 0
  %t79 = load i64, ptr %t78
  %t80 = load i64, ptr %l2, !tbaa !24
  %t83 = icmp eq i64 %t79, %t80
  store i1 %t83, ptr %l48, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb23
bb23:
  %t85 = load i1, ptr %l48, !tbaa !21
  %t86 = xor i1 %t85, true
  br i1 %t86, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb29
bb25:
  %t88 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t89 = load { i64, [2 x i64] }, ptr %t88
  %t91 = extractvalue { i64, [2 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 2
  br i1 %t92, label %bb26, label %bb27
bb26:
  %t94 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t95 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 1
  %t96 = getelementptr { i64 }, ptr %t95, i32 0, i32 0
  %t97 = load i64, ptr %t96
  %t98 = load i64, ptr %l2, !tbaa !24
  %t101 = icmp eq i64 %t97, %t98
  store i1 %t101, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t103 = load i1, ptr %l56, !tbaa !21
  store i1 %t103, ptr %l53, !tbaa !21
  br label %bb29
bb29:
  %t104 = load i1, ptr %l53, !tbaa !21
  br i1 %t104, label %bb30, label %bb31
bb30:
  br label %bb101
bb31:
  br label %bb32
bb32:
  store { i64, [2 x i64] } zeroinitializer, ptr %t105
  %t106 = getelementptr { i64, [2 x i64] }, ptr %t105, i32 0, i32 0
  store i64 0, ptr %t106
  %t107 = load { i64, [2 x i64] }, ptr %t105
  store { i64, [2 x i64] } %t107, ptr %l9
  %t109 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t110 = load { i64, [2 x i64] }, ptr %t109
  store { i64, [2 x i64] } %t110, ptr %l10
  %t112 = load { i64, [2 x i64] }, ptr %l10
  %t114 = extractvalue { i64, [2 x i64] } %t112, 0
  %t115 = icmp eq i64 %t114, 2
  br i1 %t115, label %bb33, label %bb34
bb33:
  %t117 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t118 = getelementptr { i64 }, ptr %t117, i32 0, i32 0
  %t119 = load i64, ptr %t118
  store i64 %t119, ptr %l11, !tbaa !24
  br label %bb35
bb34:
  br label %bb46
bb35:
  %t121 = load i64, ptr %l11, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t127 = icmp slt i64 %t121, %t124
  br i1 %t127, label %bb36, label %bb37
bb36:
  %t129 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t129, ptr %l69, !tbaa !27
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, [2 x i64] }, ptr %t133, i64 %t130
  %t135 = load { i64, [2 x i64] }, ptr %t134
  store { i64, [2 x i64] } %t135, ptr %l9
  br label %bb38
bb37:
  br label %bb38
bb38:
  %t137 = load { i64, [2 x i64] }, ptr %l9
  %t139 = extractvalue { i64, [2 x i64] } %t137, 0
  %t140 = icmp eq i64 %t139, 0
  br i1 %t140, label %bb39, label %bb40
bb39:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t144 = load i64, ptr %l11, !tbaa !24
  %t148 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticVar(ptr %v0, ptr %v1, ptr %t142, ptr %t143, i64 %t144)
  store i1 %t148, ptr %l77
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t149 = load i1, ptr %l77, !tbaa !21
  %t150 = xor i1 %t149, true
  br i1 %t150, label %bb42, label %bb43
bb42:
  br label %bb101
bb43:
  br label %bb44
bb44:
  store { i64, [2 x i64] } zeroinitializer, ptr %t152
  %t153 = getelementptr { i64, [2 x i64] }, ptr %t152, i32 0, i32 0
  store i64 3, ptr %t153
  %t154 = load { i64, [2 x i64] }, ptr %t152
  store { i64, [2 x i64] } %t154, ptr %l9
  br label %bb45
bb45:
  br label %bb67
bb46:
  %t156 = load { i64, [2 x i64] }, ptr %l10
  %t158 = extractvalue { i64, [2 x i64] } %t156, 0
  %t159 = icmp eq i64 %t158, 4
  br i1 %t159, label %bb47, label %bb48
bb47:
  %t161 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t162 = getelementptr { i64, i64 }, ptr %t161, i32 0, i32 0
  %t163 = load i64, ptr %t162
  store i64 %t163, ptr %l12, !tbaa !24
  %t165 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t166 = getelementptr { i64, i64 }, ptr %t165, i32 0, i32 1
  %t167 = load i64, ptr %t166
  store i64 %t167, ptr %l13, !tbaa !24
  br label %bb49
bb48:
  br label %bb62
bb49:
  %t169 = load i64, ptr %l12, !tbaa !24
  %t171 = icmp sge i64 %t169, 0
  br i1 %t171, label %bb50, label %bb51
bb50:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l12, !tbaa !24
  %t175 = load i64, ptr %l13, !tbaa !24
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t183 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedAt(ptr %v0, ptr %v1, ptr %v2, ptr %t173, i64 %t174, i64 %t175, ptr %t176, i1 true, { i64, ptr } %t177)
  store { i64, [2 x i64] } %t183, ptr %l91
  br label %bb52
bb51:
  br label %bb61
bb52:
  %t184 = load { i64, [2 x i64] }, ptr %l91
  store { i64, [2 x i64] } %t184, ptr %l9
  %t185 = load { i64, [2 x i64] }, ptr %l9
  %t187 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t185)
  store i1 %t187, ptr %l93
  br label %bb53
bb53:
  %t188 = load i1, ptr %l93, !tbaa !21
  %t189 = xor i1 %t188, true
  br i1 %t189, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l95, !tbaa !21
  br label %bb56
bb55:
  %t191 = load { i64, [2 x i64] }, ptr %l9
  %t193 = extractvalue { i64, [2 x i64] } %t191, 0
  %t194 = icmp eq i64 %t193, 3
  store i1 %t194, ptr %l95, !tbaa !21
  br label %bb56
bb56:
  %t196 = load i1, ptr %l95, !tbaa !21
  br i1 %t196, label %bb57, label %bb58
bb57:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t199 = load i64, ptr %l12, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t205 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamBinding(ptr %v0, ptr %v1, ptr %v2, ptr %t197, ptr %t198, i64 %t199, { i64, ptr } %t200)
  store { i64, [2 x i64] } %t205, ptr %l102
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t206 = load { i64, [2 x i64] }, ptr %l102
  store { i64, [2 x i64] } %t206, ptr %l9
  br label %bb60
bb60:
  br label %bb61
bb61:
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store { i64, [2 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [2 x i64] }, ptr %t207, i32 0, i32 0
  store i64 0, ptr %t208
  %t209 = load { i64, [2 x i64] }, ptr %t207
  call void @__olang_scope_close(ptr %s2)
  store { i64, [2 x i64] } %t209, ptr %rv
  br label %ret
bb66:
  call void @__olang_check_failed(ptr @olang_loc_8c8a5a319e38c1bd_d671b8fda2886981)
  unreachable
bb67:
  %t211 = load { i64, [2 x i64] }, ptr %l9
  %t213 = extractvalue { i64, [2 x i64] } %t211, 0
  %t214 = icmp eq i64 %t213, 1
  br i1 %t214, label %bb68, label %bb69
bb68:
  br label %bb72
bb69:
  %t216 = load { i64, [2 x i64] }, ptr %l9
  %t218 = extractvalue { i64, [2 x i64] } %t216, 0
  %t219 = icmp eq i64 %t218, 2
  br i1 %t219, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb89
bb73:
  %t221 = load { i64, [2 x i64] }, ptr %l9
  %t223 = extractvalue { i64, [2 x i64] } %t221, 0
  %t224 = icmp eq i64 %t223, 3
  br i1 %t224, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb84
bb76:
  %t226 = load i64, ptr %l4, !tbaa !24
  %t228 = icmp slt i64 %t226, 0
  br i1 %t228, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb80
bb78:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l4, !tbaa !24
  %t232 = load i64, ptr %l2, !tbaa !24
  %t236 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumBuilds(ptr %v0, ptr %t230, i64 %t231, i64 %t232)
  store i1 %t236, ptr %l116
  br label %bb79
bb79:
  %t237 = load i1, ptr %l116, !tbaa !21
  store i1 %t237, ptr %l112, !tbaa !21
  br label %bb80
bb80:
  %t238 = load i1, ptr %l112, !tbaa !21
  br i1 %t238, label %bb81, label %bb82
bb81:
  store { i64, [2 x i64] } zeroinitializer, ptr %t239
  %t240 = getelementptr { i64, [2 x i64] }, ptr %t239, i32 0, i32 0
  store i64 0, ptr %t240
  %t241 = load { i64, [2 x i64] }, ptr %t239
  call void @__olang_scope_close(ptr %s2)
  store { i64, [2 x i64] } %t241, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  br label %bb89
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  store { i64, [2 x i64] } zeroinitializer, ptr %t243
  %t244 = getelementptr { i64, [2 x i64] }, ptr %t243, i32 0, i32 0
  store i64 0, ptr %t244
  %t245 = load { i64, [2 x i64] }, ptr %t243
  call void @__olang_scope_close(ptr %s2)
  store { i64, [2 x i64] } %t245, ptr %rv
  br label %ret
bb88:
  call void @__olang_check_failed(ptr @olang_loc_d6d71e16ab160a8c_d85efb61f7dcc5f0)
  unreachable
bb89:
  %t247 = load { i64, [2 x i64] }, ptr %l5
  %t249 = extractvalue { i64, [2 x i64] } %t247, 0
  %t250 = icmp eq i64 %t249, 0
  br i1 %t250, label %bb90, label %bb91
bb90:
  %t252 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t252, ptr %l5
  br label %bb100
bb91:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load { i64, [2 x i64] }, ptr %l5
  %t256 = load { i64, [2 x i64] }, ptr %l9
  %t260 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t254, { i64, [2 x i64] } %t255, { i64, [2 x i64] } %t256)
  store i64 %t260, ptr %l125
  br label %bb92
bb92:
  %t261 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t262 = load i64, ptr %l125, !tbaa !24
  %t264 = icmp eq i64 %t262, %t261
  br i1 %t264, label %bb93, label %bb94
bb93:
  %t266 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t266, ptr %l5
  br label %bb99
bb94:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load { i64, [2 x i64] }, ptr %l9
  %t270 = load { i64, [2 x i64] }, ptr %l5
  %t274 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t268, { i64, [2 x i64] } %t269, { i64, [2 x i64] } %t270)
  store i64 %t274, ptr %l132
  br label %bb95
bb95:
  %t275 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t276 = load i64, ptr %l132, !tbaa !24
  %t278 = icmp ne i64 %t276, %t275
  br i1 %t278, label %bb96, label %bb97
bb96:
  store { i64, [2 x i64] } zeroinitializer, ptr %t280
  %t281 = getelementptr { i64, [2 x i64] }, ptr %t280, i32 0, i32 0
  store i64 0, ptr %t281
  %t282 = load { i64, [2 x i64] }, ptr %t280
  call void @__olang_scope_close(ptr %s2)
  store { i64, [2 x i64] } %t282, ptr %rv
  br label %ret
bb97:
  br label %bb98
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  br label %bb101
bb101:
  %t284 = load i64, ptr %l7, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l7, !tbaa !24
  br label %bb15
bb102:
  call void @__olang_scope_close(ptr %s2)
  %t288 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t288, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandHeld(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l2 = alloca %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78"
  %l5 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l6 = alloca %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78"
  %l8 = alloca %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78"
  %l9 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca { i64, [2 x i64] }
  %l17 = alloca %"compiler/scope:Val"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 40
  %t5 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H7e82b4dbdb79c77bc51fdaf9d4704834(ptr %v0, ptr %v0, ptr %t3)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l5
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t6, ptr %l1
  br label %bb2
bb2:
  %t8 = call { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20compiler_2ftyped_3aExpr_2_H4ea279ff901448a8d94a2f42aa119fd2(ptr %v0, ptr %v0, ptr %l1)
  %t9 = extractvalue { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } %t8, 1
  %t10 = extractvalue { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } %t8, 0
  store i32 %t10, ptr %l9
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t9, ptr %l8
  br label %bb3
bb3:
  %t13 = load %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %l8
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t13, ptr %l6
  br label %bb6
bb4:
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  br label %bb10
bb6:
  %t18 = load %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %l6
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t18, ptr %l2
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  %t20 = getelementptr %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %l2, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t23)
  store { i64, [2 x i64] } %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load { i64, [2 x i64] }, ptr %l16
  %t29 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v0, ptr %t26, ptr %t27, { i64, [2 x i64] } %t28)
  store %"compiler/scope:Val" %t29, ptr %l17
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %bb2
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l24 = alloca ptr
  %l30 = alloca i32
  %l34 = alloca i64
  %l37 = alloca i1
  %l40 = alloca i1
  %l47 = alloca i64
  %l53 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l99 = alloca i64
  %l102 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i64
  %l135 = alloca i1
  %l140 = alloca i64
  %l143 = alloca { i64, ptr }
  %l147 = alloca { i64, [2 x i64] }
  %l151 = alloca i64
  %l154 = alloca { i64, ptr }
  %l157 = alloca { i64, [2 x i64] }
  %l166 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t10 = alloca { i64, [2 x i64] }, align 8
  %t42 = alloca { i64, [2 x i64] }, align 8
  %t61 = alloca { i64, [2 x i64] }, align 8
  %t75 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = call ptr @compiler_2ftyped_2eCallOf(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t4, ptr %l24
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l24, !tbaa !29
  store ptr %t5, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t10
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 0
  store i64 0, ptr %t11
  %t12 = load { i64, [2 x i64] }, ptr %t10
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t12, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t18 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  store i32 %t18, ptr %l30
  br label %bb5
bb5:
  %t19 = load i32, ptr %l30, !tbaa !23
  store i32 %t19, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Call", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t27 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t20, ptr %t24)
  store i64 %t27, ptr %l34
  br label %bb6
bb6:
  %t28 = load i64, ptr %l34, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  br i1 %t31, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb10
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t33, i64 %t34)
  store i1 %t37, ptr %l40
  br label %bb9
bb9:
  %t38 = load i1, ptr %l40, !tbaa !21
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l37, !tbaa !21
  br label %bb10
bb10:
  %t41 = load i1, ptr %l37, !tbaa !21
  br i1 %t41, label %bb11, label %bb12
bb11:
  store { i64, [2 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [2 x i64] }, ptr %t42, i32 0, i32 0
  store i64 0, ptr %t43
  %t44 = load { i64, [2 x i64] }, ptr %t42
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t44, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t51, i32 %t52)
  store i64 %t55, ptr %l47
  br label %bb14
bb14:
  %t56 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t57 = load i64, ptr %l47, !tbaa !24
  %t59 = icmp eq i64 %t57, %t56
  br i1 %t59, label %bb15, label %bb16
bb15:
  store { i64, [2 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [2 x i64] }, ptr %t61, i32 0, i32 0
  store i64 0, ptr %t62
  %t63 = load { i64, [2 x i64] }, ptr %t61
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t63, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t69, ptr %l53
  br label %bb18
bb18:
  %t70 = load i64, ptr %l53, !tbaa !24
  store i64 %t70, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = icmp slt i64 %t71, 0
  br i1 %t73, label %bb19, label %bb20
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [2 x i64] }, ptr %t75, i32 0, i32 0
  store i64 0, ptr %t76
  %t77 = load { i64, [2 x i64] }, ptr %t75
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t77, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/scope:Scoper", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l3, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t84, i32 %t85)
  store { i64, ptr } %t88, ptr %l61
  br label %bb22
bb22:
  %t89 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t89, ptr %l6, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  store i64 %t92, ptr %l63, !tbaa !24
  %t93 = load i64, ptr %l63, !tbaa !24
  %t94 = icmp sge i64 %t93, 0
  br i1 %t94, label %bb23, label %bb24
bb23:
  %t96 = load i64, ptr %l63, !tbaa !24
  %t97 = icmp sle i64 %t96, 384307168202282325
  br i1 %t97, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ec2dd22d28cc6988_9d0975400b204864)
  unreachable
bb25:
  %t99 = load i64, ptr %l63, !tbaa !24
  %t100 = mul i64 %t99, 24
  %t101 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Call", ptr %t105, i32 0, i32 1
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t112 = load i64, ptr %l9, !tbaa !24
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = icmp sgt i64 %t112, %t113
  br i1 %t116, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ec2dd22d28cc6988_9d0975400b204864)
  unreachable
bb27:
  %t118 = load i64, ptr %l10, !tbaa !24
  %t120 = icmp sgt i64 %t118, 0
  br i1 %t120, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb32
bb29:
  %t122 = load i64, ptr %l9, !tbaa !24
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = sub i64 %t122, %t123
  %t127 = load i64, ptr %l10, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t132 = sub i64 %t130, 1
  %t133 = load i64, ptr %l10, !tbaa !24
  %t136 = sdiv i64 %t132, %t133
  store i64 %t136, ptr %l76, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb31
bb31:
  %t138 = load i64, ptr %l76, !tbaa !24
  store i64 %t138, ptr %l73, !tbaa !24
  br label %bb32
bb32:
  %t139 = load i64, ptr %l73, !tbaa !24
  store i64 %t139, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb33
bb33:
  %t140 = load i64, ptr %l12, !tbaa !24
  %t141 = load i64, ptr %l11, !tbaa !24
  %t144 = icmp slt i64 %t140, %t141
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb34, label %bb35
bb34:
  br label %bb65
bb35:
  br label %bb36
bb36:
  %t148 = load i64, ptr %l8, !tbaa !24
  %t149 = load i64, ptr %l12, !tbaa !24
  %t150 = load i64, ptr %l10, !tbaa !24
  %t153 = mul i64 %t149, %t150
  %t156 = add i64 %t148, %t153
  store i64 %t156, ptr %l13, !tbaa !24
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/scope:Scoper", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l3, !tbaa !23
  %t165 = load i64, ptr %l13, !tbaa !24
  %t169 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t163, i32 %t164, i64 %t165)
  store i64 %t169, ptr %l99
  br label %bb37
bb37:
  %t170 = load i64, ptr %l99, !tbaa !24
  store i64 %t170, ptr %l14, !tbaa !24
  %t171 = load i64, ptr %l14, !tbaa !24
  %t173 = icmp sge i64 %t171, 0
  br i1 %t173, label %bb38, label %bb39
bb38:
  %t175 = load i64, ptr %l14, !tbaa !24
  store i64 %t175, ptr %l102, !tbaa !24
  br label %bb40
bb39:
  %t177 = load i64, ptr %l13, !tbaa !24
  store i64 %t177, ptr %l102, !tbaa !24
  br label %bb40
bb40:
  %t179 = load i64, ptr %l102, !tbaa !24
  store i64 %t179, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  store i64 %t182, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t184 = load i64, ptr %l17, !tbaa !24
  %t185 = load i64, ptr %l16, !tbaa !24
  %t188 = icmp sgt i64 %t184, %t185
  br i1 %t188, label %bb41, label %bb42
bb41:
  %t190 = load i64, ptr %l18, !tbaa !24
  %t192 = icmp sgt i64 %t190, 0
  br i1 %t192, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb46
bb43:
  %t194 = load i64, ptr %l17, !tbaa !24
  %t195 = load i64, ptr %l16, !tbaa !24
  %t198 = sub i64 %t194, %t195
  %t199 = load i64, ptr %l18, !tbaa !24
  %t202 = add i64 %t198, %t199
  %t204 = sub i64 %t202, 1
  %t205 = load i64, ptr %l18, !tbaa !24
  %t208 = sdiv i64 %t204, %t205
  store i64 %t208, ptr %l113, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb45
bb45:
  %t210 = load i64, ptr %l113, !tbaa !24
  store i64 %t210, ptr %l110, !tbaa !24
  br label %bb46
bb46:
  %t211 = load i64, ptr %l110, !tbaa !24
  store i64 %t211, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb47
bb47:
  %t212 = load i64, ptr %l20, !tbaa !24
  %t213 = load i64, ptr %l19, !tbaa !24
  %t216 = icmp slt i64 %t212, %t213
  %t218 = xor i1 %t216, true
  br i1 %t218, label %bb48, label %bb49
bb48:
  br label %bb63
bb49:
  br label %bb50
bb50:
  %t220 = load i64, ptr %l16, !tbaa !24
  %t221 = load i64, ptr %l20, !tbaa !24
  %t222 = load i64, ptr %l18, !tbaa !24
  %t225 = mul i64 %t221, %t222
  %t228 = add i64 %t220, %t225
  store i64 %t228, ptr %l21, !tbaa !24
  %t230 = load i64, ptr %l21, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr i64, ptr %t233, i64 %t230
  %t235 = load i64, ptr %t234, !tbaa !34
  %t236 = load i64, ptr %l15, !tbaa !24
  %t239 = icmp ne i64 %t235, %t236
  br i1 %t239, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l135, !tbaa !21
  br label %bb53
bb52:
  %t241 = load i64, ptr %l21, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr { i64, [2 x i64] }, ptr %t244, i64 %t241
  %t246 = load { i64, [2 x i64] }, ptr %t245
  %t248 = extractvalue { i64, [2 x i64] } %t246, 0
  %t249 = icmp eq i64 %t248, 0
  %t251 = xor i1 %t249, true
  store i1 %t251, ptr %l135, !tbaa !21
  br label %bb53
bb53:
  %t253 = load i1, ptr %l135, !tbaa !21
  br i1 %t253, label %bb54, label %bb55
bb54:
  br label %bb62
bb55:
  br label %bb56
bb56:
  %t254 = load i64, ptr %l21, !tbaa !24
  store i64 %t254, ptr %l140, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load ptr, ptr %l2, !tbaa !29
  %t258 = getelementptr %"compiler/typed:Call", ptr %t256, i32 0, i32 1
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  store { i64, ptr } %t259, ptr %l143, !tbaa !27
  %t260 = load i64, ptr %l13, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr ptr, ptr %t263, i64 %t260
  %t265 = load ptr, ptr %t264, !tbaa !39
  %t269 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %t255, ptr %t265)
  store { i64, [2 x i64] } %t269, ptr %l147
  br label %bb57
bb57:
  %t270 = load { i64, [2 x i64] }, ptr %l147
  %t271 = load i64, ptr %l140, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr { i64, [2 x i64] }, ptr %t273, i64 %t271
  store { i64, [2 x i64] } %t270, ptr %t274
  %t275 = load i64, ptr %l21, !tbaa !24
  %t277 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = getelementptr { i64, [2 x i64] }, ptr %t278, i64 %t275
  %t280 = load { i64, [2 x i64] }, ptr %t279
  %t282 = extractvalue { i64, [2 x i64] } %t280, 0
  %t283 = icmp eq i64 %t282, 0
  br i1 %t283, label %bb58, label %bb59
bb58:
  %t285 = load i64, ptr %l21, !tbaa !24
  store i64 %t285, ptr %l151, !tbaa !24
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load ptr, ptr %l2, !tbaa !29
  %t289 = getelementptr %"compiler/typed:Call", ptr %t287, i32 0, i32 1
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  store { i64, ptr } %t290, ptr %l154, !tbaa !27
  %t291 = load i64, ptr %l13, !tbaa !24
  %t293 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr ptr, ptr %t294, i64 %t291
  %t296 = load ptr, ptr %t295, !tbaa !39
  %t299 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandTerm(ptr %v0, ptr %v1, ptr %t286, ptr %t296)
  store { i64, [2 x i64] } %t299, ptr %l157
  br label %bb60
bb59:
  br label %bb61
bb60:
  %t300 = load { i64, [2 x i64] }, ptr %l157
  %t301 = load i64, ptr %l151, !tbaa !24
  %t302 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr { i64, [2 x i64] }, ptr %t303, i64 %t301
  store { i64, [2 x i64] } %t300, ptr %t304
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t305 = load i64, ptr %l20, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l20, !tbaa !24
  br label %bb47
bb63:
  br label %bb64
bb64:
  %t309 = load i64, ptr %l12, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l12, !tbaa !24
  br label %bb33
bb65:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load ptr, ptr %l2, !tbaa !29
  %t315 = load i64, ptr %l5, !tbaa !24
  %t316 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t321 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandByObligations(ptr %v0, ptr %v1, ptr %s0, ptr %t313, ptr %t314, i64 %t315, { i64, ptr } %t316)
  store { i64, [2 x i64] } %t321, ptr %l166
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  %t322 = load { i64, [2 x i64] }, ptr %l166
  store { i64, [2 x i64] } %t322, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca i1
  %l53 = alloca %"compiler/source:Span"
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 25
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d50f79fefbee4394_12c4367532f3ae80)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l18
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l17
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l7, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  store i64 %t31, ptr %l3, !tbaa !24
  %t33 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t34 = load i32, ptr %t33, !tbaa !23
  %t36 = sext i32 %t34 to i64
  store i64 %t36, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = icmp sgt i64 %t38, %t41
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t46, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l5
  br label %bb11
bb11:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  br label %bb31
bb13:
  br label %bb14
bb14:
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t58, ptr %l33, !tbaa !27
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = call i1 @compiler_2fscope_2eisNameChar(i8 %t64)
  store i1 %t66, ptr %l36
  br label %bb15
bb15:
  %t67 = load i1, ptr %l36, !tbaa !21
  br i1 %t67, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l3, !tbaa !24
  store i64 %t68, ptr %l6, !tbaa !24
  br label %bb18
bb17:
  br label %bb29
bb18:
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t76, ptr %l42, !tbaa !27
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 %t77
  %t82 = load i8, ptr %t81, !tbaa !32
  %t84 = call i1 @compiler_2fscope_2eisNameChar(i8 %t82)
  store i1 %t84, ptr %l45
  br label %bb21
bb20:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb21:
  %t85 = load i1, ptr %l45, !tbaa !21
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l41, !tbaa !21
  %t87 = xor i1 %t86, true
  br i1 %t87, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t89 = load i64, ptr %l3, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l3, !tbaa !24
  br label %bb26
bb26:
  br label %bb18
bb27:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = trunc i64 %t93 to i32
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = trunc i64 %t96 to i32
  %t101 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t95, i32 %t98)
  store %"compiler/source:Span" %t101, ptr %l53
  br label %bb28
bb28:
  %t102 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t102, ptr %l5
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb29:
  %t103 = load i64, ptr %l3, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l3, !tbaa !24
  br label %bb30
bb30:
  br label %bb11
bb31:
  %t107 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t107, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elentLoopCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l36 = alloca %"compiler/typed:Local"
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l8, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 3
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb27
bb6:
  %t23 = load ptr, ptr %l3, !tbaa !29
  store ptr %t23, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 8}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l4, !tbaa !23
  br label %bb11
bb10:
  br label %bb21
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l4, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t44 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %t38, i64 %t41)
  store i1 %t44, ptr %l24
  br label %bb12
bb12:
  %t45 = load i1, ptr %l24, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 25
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  br i1 %t52, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb20
bb15:
  call void @__olang_check_failed(ptr @olang_loc_42ddfa07d54a3511_7eb6b931dfed5aa5)
  unreachable
bb16:
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 25
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t57, i32 0, i32 7
  %t61 = load i32, ptr %l4, !tbaa !23
  %t63 = sext i32 %t61 to i64
  %t66 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t60, i64 %t63)
  store %"compiler/typed:Local" %t66, ptr %l36
  br label %bb18
bb18:
  %t67 = getelementptr %"compiler/typed:Local", ptr %l36, i32 0, i32 2
  %t68 = load i32, ptr %t67, !tbaa !23
  %t69 = load ptr, ptr %l26, !tbaa !29
  %t71 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t69, i32 %t68)
  store i1 %t71, ptr %l38
  br label %bb19
bb19:
  %t72 = load i1, ptr %l38, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l25, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load i1, ptr %l25, !tbaa !21
  store i1 %t75, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_133169b3f1711469_c566838c26ef218d)
  unreachable
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_31030507f1509b32_81bbcae78c23c7f6)
  unreachable
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elet(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca i32
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca %"compiler/scope:Val"
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca { i64, [2 x i64] }
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca { i64, [1 x i64] }
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca { i64, [2 x i64] }
  %l24 = alloca %"compiler/scope:Val"
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca { i64, [2 x i64] }
  %l30 = alloca { i64, [2 x i64] }
  %l31 = alloca i64
  %l33 = alloca %"compiler/scope:Val"
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i64
  %l47 = alloca %"compiler/typed:Local"
  %l70 = alloca { i64, [2 x i64] }
  %l74 = alloca i1
  %l76 = alloca ptr
  %l81 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l82 = alloca i1
  %l86 = alloca { i64, [2 x i64] }
  %l90 = alloca { i64, [2 x i64] }
  %l93 = alloca ptr
  %l95 = alloca i64
  %l98 = alloca { i64, [2 x i64] }
  %l101 = alloca i1
  %l104 = alloca i1
  %l106 = alloca i1
  %l109 = alloca i1
  %l113 = alloca i1
  %l114 = alloca i1
  %l119 = alloca i1
  %l121 = alloca { i64, [2 x i64] }
  %l123 = alloca i1
  %l130 = alloca { i64, ptr }
  %l132 = alloca i64
  %l135 = alloca { i64, [1 x i64] }
  %l136 = alloca ptr
  %l137 = alloca { i64, [2 x i64] }
  %l138 = alloca %"compiler/source:Span"
  %l157 = alloca i1
  %l165 = alloca { i64, ptr }
  %l167 = alloca i64
  %l170 = alloca { i64, [1 x i64] }
  %l171 = alloca ptr
  %l172 = alloca { i64, [2 x i64] }
  %l176 = alloca %"compiler/source:Span"
  %l183 = alloca i64
  %l187 = alloca %"compiler/source:Span"
  %l191 = alloca %"compiler/scope:Val"
  %l192 = alloca ptr
  %l193 = alloca i32
  %l199 = alloca ptr
  %l200 = alloca { i64, [2 x i64] }
  %l201 = alloca { i64, [2 x i64] }
  %l204 = alloca i1
  %l205 = alloca i1
  %l208 = alloca i1
  %l215 = alloca i1
  %l220 = alloca %"compiler/scope:Val"
  %l223 = alloca i1
  %l228 = alloca i32
  %l231 = alloca i1
  %l233 = alloca ptr
  %l238 = alloca i1
  %l240 = alloca i1
  %l243 = alloca i1
  %l245 = alloca ptr
  %l247 = alloca i64
  %l258 = alloca i1
  %l261 = alloca i1
  %l264 = alloca ptr
  %l265 = alloca ptr
  %l266 = alloca i1
  %l271 = alloca ptr
  %l274 = alloca i32
  %l275 = alloca i1
  %l276 = alloca i1
  %l281 = alloca i1
  %l282 = alloca i1
  %l286 = alloca i1
  %l287 = alloca ptr
  %l289 = alloca i32
  %l292 = alloca { i64, [2 x i64] }
  %l295 = alloca %"compiler/source:Span"
  %l302 = alloca %"compiler/scope:Val"
  %l305 = alloca ptr
  %l307 = alloca i64
  %l308 = alloca ptr
  %l309 = alloca %"compiler/scope:Val"
  %l312 = alloca { i64, [2 x i64] }
  %l313 = alloca { i64, [2 x i64] }
  %l316 = alloca i1
  %l317 = alloca ptr
  %l321 = alloca i1
  %l322 = alloca ptr
  %l323 = alloca ptr
  %l326 = alloca { i64, [2 x i64] }
  %l327 = alloca %"compiler/scope:Val"
  %l336 = alloca { i64, [2 x i64] }
  %l340 = alloca i1
  %l347 = alloca i1
  %l364 = alloca { i64, [2 x i64] }
  %l373 = alloca ptr
  %l376 = alloca { i64, [2 x i64] }
  %l378 = alloca { i64, [2 x i64] }
  %l381 = alloca { i64, [2 x i64] }
  %l384 = alloca i1
  %l385 = alloca i1
  %l389 = alloca i1
  %l393 = alloca ptr
  %l399 = alloca i1
  %l400 = alloca i1
  %l403 = alloca ptr
  %l404 = alloca i1
  %l411 = alloca i1
  %l412 = alloca i1
  %l415 = alloca i1
  %l417 = alloca ptr
  %l419 = alloca i64
  %l422 = alloca { i64, [2 x i64] }
  %l428 = alloca { i64, [2 x i64] }
  %l432 = alloca { i64, [2 x i64] }
  %l436 = alloca ptr
  %l438 = alloca i1
  %l441 = alloca i1
  %l445 = alloca ptr
  %l447 = alloca i1
  %l450 = alloca i64
  %l456 = alloca %"compiler/scope:Val"
  %l460 = alloca ptr
  %l462 = alloca i64
  %l469 = alloca i1
  %l470 = alloca i1
  %l474 = alloca i1
  %l490 = alloca ptr
  %l494 = alloca i64
  %l497 = alloca i1
  %l501 = alloca i1
  %l503 = alloca ptr
  %l505 = alloca i64
  %l506 = alloca i64
  %l510 = alloca i64
  %l511 = alloca i32
  %l515 = alloca ptr
  %l520 = alloca ptr
  %l521 = alloca ptr
  %l523 = alloca ptr
  %l527 = alloca i1
  %l534 = alloca { i64, ptr }
  %l536 = alloca i64
  %l539 = alloca i1
  %l543 = alloca i1
  %l545 = alloca ptr
  %l547 = alloca i64
  %l548 = alloca i64
  %l552 = alloca i64
  %l553 = alloca i32
  %l554 = alloca ptr
  %l555 = alloca i32
  %l560 = alloca ptr
  %l562 = alloca i64
  %l566 = alloca { i64, [2 x i64] }
  %l567 = alloca ptr
  %l568 = alloca i32
  %l572 = alloca i1
  %l582 = alloca ptr
  %l590 = alloca { i64, [2 x i64] }
  %l595 = alloca { i64, [2 x i64] }
  %l596 = alloca i32
  %l612 = alloca i1
  %l615 = alloca i64
  %l618 = alloca i64
  %l620 = alloca i1
  %l626 = alloca i1
  %l627 = alloca ptr
  %l633 = alloca ptr
  %l634 = alloca ptr
  %l638 = alloca %"compiler/source:Span"
  %l639 = alloca %"compiler/source:Span"
  %l640 = alloca %"compiler/msgs:Msg"
  %l641 = alloca i64
  %l649 = alloca i1
  %l652 = alloca i1
  %l653 = alloca i1
  %l654 = alloca ptr
  %l658 = alloca i1
  %l664 = alloca %"compiler/scope:Val"
  %l666 = alloca ptr
  %l667 = alloca i32
  %l678 = alloca i1
  %l681 = alloca ptr
  %l682 = alloca { i64, [2 x i64] }
  %l683 = alloca { i64, [2 x i64] }
  %l684 = alloca i1
  %l687 = alloca ptr
  %l689 = alloca i64
  %l695 = alloca i1
  %l698 = alloca i1
  %l699 = alloca i1
  %l700 = alloca ptr
  %l704 = alloca i1
  %l712 = alloca i1
  %l715 = alloca i1
  %l718 = alloca i1
  %l719 = alloca ptr
  %l720 = alloca ptr
  %l724 = alloca %"compiler/source:Span"
  %l725 = alloca %"compiler/msgs:Msg"
  %l726 = alloca i64
  %l729 = alloca i1
  %l732 = alloca i1
  %l733 = alloca { i64, [2 x i64] }
  %l735 = alloca { i64, [2 x i64] }
  %l737 = alloca i1
  %l739 = alloca i1
  %l741 = alloca i1
  %l744 = alloca ptr
  %l745 = alloca { i64, [2 x i64] }
  %l746 = alloca { i64, [2 x i64] }
  %l756 = alloca i1
  %l762 = alloca i1
  %l764 = alloca i64
  %l772 = alloca ptr
  %l773 = alloca { i64, [2 x i64] }
  %l774 = alloca { i64, [2 x i64] }
  %l775 = alloca i1
  %s0 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %t57 = alloca { i64, [2 x i64] }, align 8
  %t388 = alloca { i64, [2 x i64] }, align 8
  %t462 = alloca { i64, [2 x i64] }, align 8
  %t564 = alloca { i64, [2 x i64] }, align 8
  %t631 = alloca { i64, [2 x i64] }, align 8
  %t677 = alloca { i64, [2 x i64] }, align 8
  %t907 = alloca { i64, [2 x i64] }, align 8
  %t1038 = alloca { i64, [2 x i64] }, align 8
  %t1212 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_16a749f285461106_b0e7908cc5ae695a)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t15 = load i32, ptr %l2, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t20 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %t17)
  store %"compiler/typed:Local" %t20, ptr %l47
  br label %bb4
bb4:
  %t21 = load %"compiler/typed:Local", ptr %l47
  store %"compiler/typed:Local" %t21, ptr %l4
  %t22 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  store i32 %t23, ptr %l5, !tbaa !23
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 42
  %t34 = load i32, ptr %l2, !tbaa !23
  %t36 = sext i32 %t34 to i64
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %t33, i64 %t36, ptr %t37)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 104
  %t44 = load { i64, [2 x i64] }, ptr %t43
  store { i64, [2 x i64] } %t44, ptr %l6
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 105
  %t49 = load i1, ptr %t48, !tbaa !21
  store i1 %t49, ptr %l7, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/scope:Scoper", ptr %t51, i32 0, i32 108
  %t54 = load i1, ptr %t53, !tbaa !21
  store i1 %t54, ptr %l8, !tbaa !21
  %t56 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [2 x i64] }, ptr %t57, i32 0, i32 0
  store i64 0, ptr %t58
  %t59 = load { i64, [2 x i64] }, ptr %t57
  %t62 = getelementptr %"compiler/scope:Scoper", ptr %t56, i32 0, i32 104
  store { i64, [2 x i64] } %t59, ptr %t62
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 105
  store i1 false, ptr %t65, !tbaa !21
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 108
  store i1 false, ptr %t68, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t72 = sext i32 %t70 to i64
  %t75 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftOf(ptr %v0, ptr %t69, i64 %t72)
  store { i64, [2 x i64] } %t75, ptr %l70
  br label %bb9
bb9:
  %t76 = load { i64, [2 x i64] }, ptr %l70
  store { i64, [2 x i64] } %t76, ptr %l9
  %t77 = load { i64, [2 x i64] }, ptr %l9
  %t79 = extractvalue { i64, [2 x i64] } %t77, 0
  %t80 = icmp eq i64 %t79, 0
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb10, label %bb11
bb10:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/scope:Scoper", ptr %t84, i32 0, i32 129
  store ptr %t86, ptr %l76, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/scope:Scoper", ptr %t87, i32 0, i32 26
  %t90 = load i64, ptr %t89, !tbaa !24
  %t91 = load i32, ptr %l2, !tbaa !23
  %t93 = sext i32 %t91 to i64
  %t96 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t90, i64 %t93)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t96, ptr %l81
  br label %bb12
bb11:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb14
bb12:
  %t97 = load ptr, ptr %l76, !tbaa !29
  %t98 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l81
  %t99 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t97, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t98)
  store i1 %t99, ptr %l82
  br label %bb13
bb13:
  %t100 = load i1, ptr %l82, !tbaa !21
  store i1 %t100, ptr %l74, !tbaa !21
  br label %bb14
bb14:
  %t101 = load i1, ptr %l74, !tbaa !21
  br i1 %t101, label %bb15, label %bb16
bb15:
  %t102 = load { i64, [2 x i64] }, ptr %l6
  %t104 = extractvalue { i64, [2 x i64] } %t102, 0
  %t105 = icmp eq i64 %t104, 0
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb17, label %bb18
bb16:
  br label %bb21
bb17:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load { i64, [2 x i64] }, ptr %l6
  %t111 = load { i64, [2 x i64] }, ptr %l9
  %t115 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoinTerm(ptr %v0, ptr %t109, { i64, [2 x i64] } %t110, { i64, [2 x i64] } %t111)
  store { i64, [2 x i64] } %t115, ptr %l90
  br label %bb19
bb18:
  %t116 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t116, ptr %l86
  br label %bb20
bb19:
  %t118 = load { i64, [2 x i64] }, ptr %l90
  store { i64, [2 x i64] } %t118, ptr %l86
  br label %bb20
bb20:
  %t119 = load { i64, [2 x i64] }, ptr %l86
  store { i64, [2 x i64] } %t119, ptr %l6
  br label %bb21
bb21:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/scope:Scoper", ptr %t120, i32 0, i32 32
  store ptr %t122, ptr %l93, !tbaa !29
  %t123 = load i32, ptr %l2, !tbaa !23
  %t125 = sext i32 %t123 to i64
  store i64 %t125, ptr %l95, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t128 = load i32, ptr %t127, !tbaa !23
  %t131 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t126, i32 %t128)
  store { i64, [2 x i64] } %t131, ptr %l98
  br label %bb22
bb22:
  %t132 = load ptr, ptr %l93, !tbaa !29
  %t133 = load i64, ptr %l95, !tbaa !24
  %t134 = load { i64, [2 x i64] }, ptr %l98
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t132, i64 %t133, { i64, [2 x i64] } %t134)
  br label %bb23
bb23:
  %t135 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t136 = load i32, ptr %t135, !range !{i32 0, i32 7}
  %t138 = trunc i64 6 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb24, label %bb25
bb24:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i32, ptr %l5, !tbaa !23
  %t145 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t141, i32 %t142)
  store i1 %t145, ptr %l104
  br label %bb26
bb25:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb27
bb26:
  %t146 = load i1, ptr %l104, !tbaa !21
  %t147 = xor i1 %t146, true
  store i1 %t147, ptr %l101, !tbaa !21
  br label %bb27
bb27:
  %t149 = load i1, ptr %l101, !tbaa !21
  br i1 %t149, label %bb28, label %bb29
bb28:
  %t150 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t151 = load i32, ptr %t150, !tbaa !23
  %t153 = icmp eq i32 %t151, 0
  store i1 %t153, ptr %l106, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb30
bb30:
  %t155 = load i1, ptr %l106, !tbaa !21
  br i1 %t155, label %bb31, label %bb32
bb31:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i32, ptr %l2, !tbaa !23
  %t159 = sext i32 %t157 to i64
  %t162 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowed(ptr %v0, ptr %t156, i64 %t159)
  store i1 %t162, ptr %l113
  br label %bb33
bb32:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb38
bb33:
  %t163 = load i1, ptr %l113, !tbaa !21
  br i1 %t163, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb37
bb35:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/scope:Scoper", ptr %t164, i32 0, i32 0
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  %t170 = load i32, ptr %l5, !tbaa !23
  %t173 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t169, i32 %t170)
  store i1 %t173, ptr %l119
  br label %bb36
bb36:
  %t174 = load i1, ptr %l119, !tbaa !21
  store i1 %t174, ptr %l114, !tbaa !21
  br label %bb37
bb37:
  %t175 = load i1, ptr %l114, !tbaa !21
  store i1 %t175, ptr %l109, !tbaa !21
  br label %bb38
bb38:
  %t176 = load i1, ptr %l109, !tbaa !21
  br i1 %t176, label %bb39, label %bb40
bb39:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t177, i32 0)
  store { i64, [2 x i64] } %t179, ptr %l121
  br label %bb41
bb40:
  br label %bb52
bb41:
  %t180 = load { i64, [2 x i64] }, ptr %l121
  store { i64, [2 x i64] } %t180, ptr %l10
  %t181 = load { i64, [2 x i64] }, ptr %l10
  %t183 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t181)
  store i1 %t183, ptr %l123
  br label %bb42
bb42:
  %t184 = load i1, ptr %l123, !tbaa !21
  br i1 %t184, label %bb43, label %bb44
bb43:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/scope:Scoper", ptr %t185, i32 0, i32 32
  %t188 = load i32, ptr %l2, !tbaa !23
  %t190 = sext i32 %t188 to i64
  %t191 = load { i64, [2 x i64] }, ptr %l10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t187, i64 %t190, { i64, [2 x i64] } %t191)
  br label %bb45
bb44:
  br label %bb51
bb45:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/scope:Scoper", ptr %t195, i32 0, i32 30
  %t198 = getelementptr %"compiler/typed:Plan", ptr %t197, i32 0, i32 1
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  store { i64, ptr } %t199, ptr %l130, !tbaa !27
  %t200 = load i32, ptr %l2, !tbaa !23
  %t202 = sext i32 %t200 to i64
  store i64 %t202, ptr %l132, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load { i64, [2 x i64] }, ptr %l10
  %t207 = call { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %t203, { i64, [2 x i64] } %t204)
  store { i64, [1 x i64] } %t207, ptr %l135
  br label %bb46
bb46:
  %t208 = load { i64, [1 x i64] }, ptr %l135
  %t209 = load i64, ptr %l132, !tbaa !24
  %t210 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr { i64, [1 x i64] }, ptr %t211, i64 %t209
  store { i64, [1 x i64] } %t208, ptr %t212
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l136, !tbaa !29
  %t214 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t214, ptr %l137
  %t215 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t215, ptr %l138
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/scope:Scoper", ptr %t216, i32 0, i32 25
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = icmp eq ptr %t219, null
  br i1 %t221, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_18c7df235ed333ed_6cb02ce97018ae1)
  unreachable
bb48:
  br label %bb49
bb49:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/scope:Scoper", ptr %t223, i32 0, i32 25
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t229 = getelementptr %"compiler/typed:Body", ptr %t226, i32 0, i32 3
  %t230 = load i64, ptr %t229, !tbaa !24
  %t231 = load %"compiler/source:Span", ptr %l1
  %t232 = load ptr, ptr %l136, !tbaa !29
  %t233 = load { i64, [2 x i64] }, ptr %l137
  %t234 = load %"compiler/source:Span", ptr %l138
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t232, { i64, [2 x i64] } %t233, %"compiler/source:Span" %t234, i64 %t230, %"compiler/source:Span" %t231)
  br label %bb50
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t237 = load { i64, [2 x i64] }, ptr %l6
  %t239 = extractvalue { i64, [2 x i64] } %t237, 0
  %t240 = icmp eq i64 %t239, 0
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb53, label %bb54
bb53:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/scope:Scoper", ptr %t244, i32 0, i32 31
  %t247 = load i32, ptr %l2, !tbaa !23
  %t249 = sext i32 %t247 to i64
  %t250 = load { i64, [2 x i64] }, ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t246, i64 %t249, { i64, [2 x i64] } %t250)
  br label %bb55
bb54:
  br label %bb91
bb55:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load i32, ptr %l5, !tbaa !23
  %t258 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t254, i32 %t255)
  store i1 %t258, ptr %l157
  br label %bb56
bb56:
  %t259 = load i1, ptr %l157, !tbaa !21
  %t260 = xor i1 %t259, true
  br i1 %t260, label %bb57, label %bb58
bb57:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/scope:Scoper", ptr %t262, i32 0, i32 32
  %t265 = load i32, ptr %l2, !tbaa !23
  %t267 = sext i32 %t265 to i64
  %t268 = load { i64, [2 x i64] }, ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t264, i64 %t267, { i64, [2 x i64] } %t268)
  br label %bb59
bb58:
  br label %bb73
bb59:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/scope:Scoper", ptr %t272, i32 0, i32 30
  %t275 = getelementptr %"compiler/typed:Plan", ptr %t274, i32 0, i32 1
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  store { i64, ptr } %t276, ptr %l165, !tbaa !27
  %t277 = load i32, ptr %l2, !tbaa !23
  %t279 = sext i32 %t277 to i64
  store i64 %t279, ptr %l167, !tbaa !24
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load { i64, [2 x i64] }, ptr %l6
  %t284 = call { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %t280, { i64, [2 x i64] } %t281)
  store { i64, [1 x i64] } %t284, ptr %l170
  br label %bb60
bb60:
  %t285 = load { i64, [1 x i64] }, ptr %l170
  %t286 = load i64, ptr %l167, !tbaa !24
  %t287 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr { i64, [1 x i64] }, ptr %t288, i64 %t286
  store { i64, [1 x i64] } %t285, ptr %t289
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l171, !tbaa !29
  %t291 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t291, ptr %l172
  %t292 = load ptr, ptr %l3, !tbaa !29
  %t294 = icmp eq ptr %t292, null
  br i1 %t294, label %bb61, label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_732b86ec1c46a4d8_efc842c6ef92792c)
  unreachable
bb62:
  br label %bb63
bb63:
  %t296 = load ptr, ptr %l3, !tbaa !29
  %t298 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t296)
  store %"compiler/source:Span" %t298, ptr %l176
  br label %bb64
bb64:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/scope:Scoper", ptr %t299, i32 0, i32 25
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = icmp eq ptr %t302, null
  br i1 %t304, label %bb65, label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_732b86ec1c46a4d8_efc842c6ef92792c)
  unreachable
bb66:
  br label %bb67
bb67:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/scope:Scoper", ptr %t306, i32 0, i32 25
  %t309 = load ptr, ptr %t308, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Body", ptr %t309, i32 0, i32 3
  %t313 = load i64, ptr %t312, !tbaa !24
  store i64 %t313, ptr %l183, !tbaa !24
  %t314 = load ptr, ptr %l3, !tbaa !29
  %t316 = icmp eq ptr %t314, null
  br i1 %t316, label %bb68, label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_732b86ec1c46a4d8_efc842c6ef92792c)
  unreachable
bb69:
  br label %bb70
bb70:
  %t318 = load ptr, ptr %l3, !tbaa !29
  %t320 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t318)
  store %"compiler/source:Span" %t320, ptr %l187
  br label %bb71
bb71:
  %t321 = load ptr, ptr %l171, !tbaa !29
  %t322 = load { i64, [2 x i64] }, ptr %l172
  %t323 = load %"compiler/source:Span", ptr %l176
  %t324 = load i64, ptr %l183, !tbaa !24
  %t325 = load %"compiler/source:Span", ptr %l187
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t321, { i64, [2 x i64] } %t322, %"compiler/source:Span" %t323, i64 %t324, %"compiler/source:Span" %t325)
  br label %bb72
bb72:
  br label %bb73
bb73:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load ptr, ptr %l3, !tbaa !29
  %t328 = load { i64, [2 x i64] }, ptr %l6
  %t332 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t326, ptr %t327, { i64, [2 x i64] } %t328)
  store %"compiler/scope:Val" %t332, ptr %l191
  br label %bb74
bb74:
  %t333 = load %"compiler/scope:Val", ptr %l191
  store %"compiler/scope:Val" %t333, ptr %l11
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l192, !tbaa !29
  %t335 = load i32, ptr %l2, !tbaa !23
  store i32 %t335, ptr %l193, !tbaa !23
  %t336 = load ptr, ptr %l3, !tbaa !29
  %t338 = icmp eq ptr %t336, null
  br i1 %t338, label %bb75, label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_32a69b93b2b7f4f7_279e7ae047adaf1b)
  unreachable
bb76:
  br label %bb77
bb77:
  %t340 = load ptr, ptr %l3, !tbaa !29
  %t341 = load ptr, ptr %l192, !tbaa !29
  %t342 = load i32, ptr %l193, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %t341, i32 %t342, ptr %t340)
  br label %bb78
bb78:
  %t344 = getelementptr %"compiler/scope:Val", ptr %l11, i32 0, i32 0
  %t345 = load i32, ptr %t344, !range !{i32 0, i32 5}
  %t347 = trunc i64 3 to i32
  %t348 = icmp eq i32 %t345, %t347
  br i1 %t348, label %bb79, label %bb80
bb79:
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l199, !tbaa !29
  %t351 = getelementptr %"compiler/scope:Val", ptr %l11, i32 0, i32 1
  %t352 = load { i64, [2 x i64] }, ptr %t351
  store { i64, [2 x i64] } %t352, ptr %l200
  %t353 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t353, ptr %l201
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i32, ptr %l5, !tbaa !23
  %t358 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t354, i32 %t355)
  store i1 %t358, ptr %l204
  br label %bb81
bb80:
  br label %bb90
bb81:
  %t359 = load i1, ptr %l204, !tbaa !21
  br i1 %t359, label %bb82, label %bb83
bb82:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb85
bb83:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load i32, ptr %l5, !tbaa !23
  %t364 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t360, i32 %t361)
  store i1 %t364, ptr %l208
  br label %bb84
bb84:
  %t365 = load i1, ptr %l208, !tbaa !21
  store i1 %t365, ptr %l205, !tbaa !21
  br label %bb85
bb85:
  %t366 = load ptr, ptr %l3, !tbaa !29
  %t368 = icmp eq ptr %t366, null
  br i1 %t368, label %bb86, label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_cbe9d007f71e6f0a_66029137d6521816)
  unreachable
bb87:
  br label %bb88
bb88:
  %t370 = load ptr, ptr %l3, !tbaa !29
  %t371 = load i64, ptr @G_2ecompiler_2fscope_2eFitLocal, !tbaa !24
  %t372 = load ptr, ptr %l199, !tbaa !29
  %t373 = load { i64, [2 x i64] }, ptr %l200
  %t374 = load { i64, [2 x i64] }, ptr %l201
  %t375 = load i1, ptr %l205, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t372, { i64, [2 x i64] } %t373, { i64, [2 x i64] } %t374, i1 %t375, ptr %t370, i64 %t371)
  br label %bb89
bb89:
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb91:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i32, ptr %l5, !tbaa !23
  %t382 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t378, i32 %t379)
  store i1 %t382, ptr %l215
  br label %bb92
bb92:
  %t383 = load i1, ptr %l215, !tbaa !21
  %t384 = xor i1 %t383, true
  br i1 %t384, label %bb93, label %bb94
bb93:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load ptr, ptr %l3, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t388
  %t389 = getelementptr { i64, [2 x i64] }, ptr %t388, i32 0, i32 0
  store i64 0, ptr %t389
  %t390 = load { i64, [2 x i64] }, ptr %t388
  %t394 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t386, ptr %t387, { i64, [2 x i64] } %t390)
  store %"compiler/scope:Val" %t394, ptr %l220
  br label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb96:
  %t395 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t396 = load i32, ptr %t395, !range !{i32 0, i32 7}
  %t398 = trunc i64 3 to i32
  %t399 = icmp eq i32 %t396, %t398
  br i1 %t399, label %bb97, label %bb98
bb97:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/scope:Scoper", ptr %t401, i32 0, i32 0
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = getelementptr %"compiler/generic:Program", ptr %t404, i32 0, i32 2
  %t407 = load i32, ptr %l5, !tbaa !23
  %t410 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t406, i32 %t407)
  store i32 %t410, ptr %l228
  br label %bb99
bb98:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb100
bb99:
  %t411 = load i32, ptr %l228, !range !{i32 0, i32 33}
  %t413 = trunc i64 22 to i32
  %t414 = icmp eq i32 %t411, %t413
  store i1 %t414, ptr %l223, !tbaa !21
  br label %bb100
bb100:
  %t416 = load i1, ptr %l223, !tbaa !21
  br i1 %t416, label %bb101, label %bb102
bb101:
  %t417 = load ptr, ptr %l3, !tbaa !29
  %t419 = call ptr @compiler_2ftyped_2eCallOf(ptr %v1, ptr %s0, ptr %t417)
  store ptr %t419, ptr %l233
  br label %bb103
bb102:
  store i1 false, ptr %l231, !tbaa !21
  br label %bb104
bb103:
  %t420 = load ptr, ptr %l233, !tbaa !29
  %t421 = icmp eq ptr %t420, null
  %t423 = xor i1 %t421, true
  store i1 %t423, ptr %l231, !tbaa !21
  br label %bb104
bb104:
  %t425 = load i1, ptr %l231, !tbaa !21
  store i1 %t425, ptr %l12, !tbaa !21
  %t426 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t427 = load i32, ptr %t426, !range !{i32 0, i32 7}
  %t429 = trunc i64 2 to i32
  %t430 = icmp eq i32 %t427, %t429
  br i1 %t430, label %bb105, label %bb106
bb105:
  store i1 true, ptr %l238, !tbaa !21
  br label %bb107
bb106:
  %t432 = load i1, ptr %l12, !tbaa !21
  store i1 %t432, ptr %l238, !tbaa !21
  br label %bb107
bb107:
  %t434 = load i1, ptr %l238, !tbaa !21
  br i1 %t434, label %bb108, label %bb109
bb108:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load ptr, ptr %l3, !tbaa !29
  %t439 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t435, ptr %t436)
  store i1 %t439, ptr %l243
  br label %bb110
bb109:
  store i1 false, ptr %l240, !tbaa !21
  br label %bb111
bb110:
  %t440 = load i1, ptr %l243, !tbaa !21
  store i1 %t440, ptr %l240, !tbaa !21
  br label %bb111
bb111:
  %t441 = load i1, ptr %l240, !tbaa !21
  br i1 %t441, label %bb112, label %bb113
bb112:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/scope:Scoper", ptr %t442, i32 0, i32 40
  store ptr %t444, ptr %l245, !tbaa !29
  %t445 = load i32, ptr %l2, !tbaa !23
  %t447 = sext i32 %t445 to i64
  store i64 %t447, ptr %l247, !tbaa !24
  %t448 = load ptr, ptr %l3, !tbaa !29
  %t450 = icmp eq ptr %t448, null
  br i1 %t450, label %bb114, label %bb115
bb113:
  br label %bb119
bb114:
  call void @__olang_check_failed(ptr @olang_loc_d999d01787ae8811_e9a058a4efe4c7fd)
  unreachable
bb115:
  br label %bb116
bb116:
  %t452 = load ptr, ptr %l3, !tbaa !29
  %t453 = load ptr, ptr %l245, !tbaa !29
  %t454 = load i64, ptr %l247, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %t453, i64 %t454, ptr %t452)
  br label %bb117
bb117:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/scope:Scoper", ptr %t456, i32 0, i32 31
  %t459 = load i32, ptr %l2, !tbaa !23
  %t461 = sext i32 %t459 to i64
  store { i64, [2 x i64] } zeroinitializer, ptr %t462
  %t463 = getelementptr { i64, [2 x i64] }, ptr %t462, i32 0, i32 0
  store i64 0, ptr %t463
  %t464 = load { i64, [2 x i64] }, ptr %t462
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t458, i64 %t461, { i64, [2 x i64] } %t464)
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb119:
  %t468 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t469 = load i32, ptr %t468, !range !{i32 0, i32 7}
  %t471 = trunc i64 3 to i32
  %t472 = icmp eq i32 %t469, %t471
  br i1 %t472, label %bb120, label %bb121
bb120:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load i32, ptr %l5, !tbaa !23
  %t478 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t474, i32 %t475)
  store i1 %t478, ptr %l261
  br label %bb122
bb121:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb123
bb122:
  %t479 = load i1, ptr %l261, !tbaa !21
  store i1 %t479, ptr %l258, !tbaa !21
  br label %bb123
bb123:
  %t480 = load i1, ptr %l258, !tbaa !21
  br i1 %t480, label %bb124, label %bb125
bb124:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load ptr, ptr %l3, !tbaa !29
  %t485 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v0, ptr %t481, ptr %t482)
  store ptr %t485, ptr %l264
  br label %bb126
bb125:
  br label %bb158
bb126:
  %t486 = load ptr, ptr %l264, !tbaa !29
  store ptr %t486, ptr %l13, !tbaa !29
  %t487 = load ptr, ptr %l13, !tbaa !29
  store ptr %t487, ptr %l265, !tbaa !29
  store i1 false, ptr %l266, !tbaa !21
  %t488 = load ptr, ptr %l265, !tbaa !29
  %t489 = icmp ne ptr %t488, null
  br i1 %t489, label %bb127, label %bb128
bb127:
  %t491 = load ptr, ptr %l265, !tbaa !29
  %t492 = load i64, ptr %t491, !range !{i64 0, i64 18}
  %t494 = icmp eq i64 %t492, 5
  store i1 %t494, ptr %l266, !tbaa !21
  br label %bb128
bb128:
  %t495 = load i1, ptr %l266, !tbaa !21
  br i1 %t495, label %bb129, label %bb130
bb129:
  %t496 = load ptr, ptr %l13, !tbaa !29
  %t498 = getelementptr { i64, [5 x i64] }, ptr %t496, i32 0, i32 1
  %t499 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t498, i32 0, i32 2
  %t500 = load ptr, ptr %t499
  store ptr %t500, ptr %l14, !tbaa !29
  br label %bb131
bb130:
  br label %bb152
bb131:
  %t502 = load ptr, ptr %l0, !tbaa !29
  store ptr %t502, ptr %l271, !tbaa !29
  %t503 = load ptr, ptr %l14, !tbaa !29
  %t505 = getelementptr %"compiler/typed:Promote", ptr %t503, i32 0, i32 0
  %t506 = load ptr, ptr %t505, !tbaa !29
  %t508 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t506)
  store i32 %t508, ptr %l274
  br label %bb132
bb132:
  %t509 = load ptr, ptr %l271, !tbaa !29
  %t510 = load i32, ptr %l274, !tbaa !23
  %t511 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t509, i32 %t510)
  store i1 %t511, ptr %l275
  br label %bb133
bb133:
  %t512 = load i1, ptr %l275, !tbaa !21
  br i1 %t512, label %bb134, label %bb135
bb134:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load ptr, ptr %l14, !tbaa !29
  %t516 = getelementptr %"compiler/typed:Promote", ptr %t514, i32 0, i32 0
  %t517 = load ptr, ptr %t516, !tbaa !29
  %t521 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v0, ptr %t513, ptr %t517)
  store i1 %t521, ptr %l281
  br label %bb136
bb135:
  store i1 false, ptr %l276, !tbaa !21
  br label %bb137
bb136:
  %t522 = load i1, ptr %l281, !tbaa !21
  store i1 %t522, ptr %l276, !tbaa !21
  br label %bb137
bb137:
  %t523 = load i1, ptr %l276, !tbaa !21
  br i1 %t523, label %bb138, label %bb139
bb138:
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load ptr, ptr %l14, !tbaa !29
  %t527 = getelementptr %"compiler/typed:Promote", ptr %t525, i32 0, i32 0
  %t528 = load ptr, ptr %t527, !tbaa !29
  %t531 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLands(ptr %v0, ptr %v0, ptr %t524, ptr %t528)
  store i1 %t531, ptr %l286
  br label %bb140
bb139:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb141
bb140:
  %t532 = load i1, ptr %l286, !tbaa !21
  store i1 %t532, ptr %l282, !tbaa !21
  br label %bb141
bb141:
  %t533 = load i1, ptr %l282, !tbaa !21
  br i1 %t533, label %bb142, label %bb143
bb142:
  %t534 = load ptr, ptr %l0, !tbaa !29
  store ptr %t534, ptr %l287, !tbaa !29
  %t535 = load ptr, ptr %l14, !tbaa !29
  %t537 = getelementptr %"compiler/typed:Promote", ptr %t535, i32 0, i32 1
  %t538 = load i32, ptr %t537, !tbaa !23
  store i32 %t538, ptr %l289, !tbaa !23
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t540 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t541 = load i32, ptr %t540, !tbaa !23
  %t544 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t539, i32 %t541)
  store { i64, [2 x i64] } %t544, ptr %l292
  br label %bb144
bb143:
  br label %bb151
bb144:
  %t545 = load ptr, ptr %l14, !tbaa !29
  %t547 = getelementptr %"compiler/typed:Promote", ptr %t545, i32 0, i32 0
  %t548 = load ptr, ptr %t547, !tbaa !29
  %t550 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t548)
  store %"compiler/source:Span" %t550, ptr %l295
  br label %bb145
bb145:
  %t551 = load ptr, ptr %l287, !tbaa !29
  %t552 = load i32, ptr %l289, !tbaa !23
  %t553 = load { i64, [2 x i64] }, ptr %l292
  %t554 = load %"compiler/source:Span", ptr %l295
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildSite(ptr %v0, ptr %t551, i32 %t552, { i64, [2 x i64] } %t553, %"compiler/source:Span" %t554)
  br label %bb146
bb146:
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t557 = getelementptr %"compiler/scope:Scoper", ptr %t555, i32 0, i32 106
  store i1 true, ptr %t557, !tbaa !21
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t559 = load ptr, ptr %l14, !tbaa !29
  %t561 = getelementptr %"compiler/typed:Promote", ptr %t559, i32 0, i32 0
  %t562 = load ptr, ptr %t561, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t564
  %t565 = getelementptr { i64, [2 x i64] }, ptr %t564, i32 0, i32 0
  store i64 0, ptr %t565
  %t566 = load { i64, [2 x i64] }, ptr %t564
  %t570 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v0, ptr %t558, ptr %t562, { i64, [2 x i64] } %t566)
  store %"compiler/scope:Val" %t570, ptr %l302
  br label %bb147
bb147:
  %t571 = load %"compiler/scope:Val", ptr %l302
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t574 = getelementptr %"compiler/scope:Scoper", ptr %t572, i32 0, i32 106
  store i1 false, ptr %t574, !tbaa !21
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t577 = getelementptr %"compiler/scope:Scoper", ptr %t575, i32 0, i32 31
  store ptr %t577, ptr %l305, !tbaa !29
  %t578 = load i32, ptr %l2, !tbaa !23
  %t580 = sext i32 %t578 to i64
  store i64 %t580, ptr %l307, !tbaa !24
  %t581 = load ptr, ptr %l0, !tbaa !29
  store ptr %t581, ptr %l308, !tbaa !29
  store %"compiler/scope:Val" %t571, ptr %l309
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t584 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t585 = load i32, ptr %t584, !tbaa !23
  %t588 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t583, i32 %t585)
  store { i64, [2 x i64] } %t588, ptr %l312
  br label %bb148
bb148:
  %t589 = load ptr, ptr %l308, !tbaa !29
  %t590 = load %"compiler/scope:Val", ptr %l309
  %t591 = load { i64, [2 x i64] }, ptr %l312
  %t592 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalTerm(ptr %v0, ptr %t589, %"compiler/scope:Val" %t590, { i64, [2 x i64] } %t591)
  store { i64, [2 x i64] } %t592, ptr %l313
  br label %bb149
bb149:
  %t593 = load ptr, ptr %l305, !tbaa !29
  %t594 = load i64, ptr %l307, !tbaa !24
  %t595 = load { i64, [2 x i64] }, ptr %l313
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t593, i64 %t594, { i64, [2 x i64] } %t595)
  br label %bb150
bb150:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb151:
  br label %bb157
bb152:
  br i1 true, label %bb153, label %bb154
bb153:
  br label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb157
bb156:
  call void @__olang_check_failed(ptr @olang_loc_63421958175545b3_aea9f7881c37205f)
  unreachable
bb157:
  br label %bb158
bb158:
  %t596 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t597 = load i32, ptr %t596, !range !{i32 0, i32 7}
  %t599 = trunc i64 3 to i32
  %t600 = icmp eq i32 %t597, %t599
  br i1 %t600, label %bb159, label %bb160
bb159:
  %t602 = load ptr, ptr %l0, !tbaa !29
  store ptr %t602, ptr %l317, !tbaa !29
  %t603 = load ptr, ptr %l3, !tbaa !29
  %t605 = icmp eq ptr %t603, null
  br i1 %t605, label %bb161, label %bb162
bb160:
  store i1 false, ptr %l316, !tbaa !21
  br label %bb165
bb161:
  call void @__olang_check_failed(ptr @olang_loc_764527203cdb400b_6de4094d30d6c847)
  unreachable
bb162:
  br label %bb163
bb163:
  %t607 = load ptr, ptr %l3, !tbaa !29
  %t608 = load ptr, ptr %l317, !tbaa !29
  %t610 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %t608, ptr %t607)
  store i1 %t610, ptr %l321
  br label %bb164
bb164:
  %t611 = load i1, ptr %l321, !tbaa !21
  store i1 %t611, ptr %l316, !tbaa !21
  br label %bb165
bb165:
  %t612 = load i1, ptr %l316, !tbaa !21
  br i1 %t612, label %bb166, label %bb167
bb166:
  %t613 = load ptr, ptr %l0, !tbaa !29
  store ptr %t613, ptr %l322, !tbaa !29
  %t614 = load ptr, ptr %l3, !tbaa !29
  store ptr %t614, ptr %l323, !tbaa !29
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t616 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t617 = load i32, ptr %t616, !tbaa !23
  %t620 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t615, i32 %t617)
  store { i64, [2 x i64] } %t620, ptr %l326
  br label %bb168
bb167:
  br label %bb171
bb168:
  %t621 = load ptr, ptr %l322, !tbaa !29
  %t622 = load ptr, ptr %l323, !tbaa !29
  %t623 = load { i64, [2 x i64] }, ptr %l326
  %t624 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t621, ptr %t622, { i64, [2 x i64] } %t623)
  store %"compiler/scope:Val" %t624, ptr %l327
  br label %bb169
bb169:
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/scope:Scoper", ptr %t625, i32 0, i32 31
  %t628 = load i32, ptr %l2, !tbaa !23
  %t630 = sext i32 %t628 to i64
  store { i64, [2 x i64] } zeroinitializer, ptr %t631
  %t632 = getelementptr { i64, [2 x i64] }, ptr %t631, i32 0, i32 0
  store i64 3, ptr %t632
  %t633 = load { i64, [2 x i64] }, ptr %t631
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t627, i64 %t630, { i64, [2 x i64] } %t633)
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb171:
  %t637 = load ptr, ptr %l0, !tbaa !29
  %t638 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t639 = load { i64, [1 x i64] }, ptr %t638
  %t640 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t641 = load i32, ptr %t640, !tbaa !23
  %t645 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarkTerm(ptr %v0, ptr %t637, { i64, [1 x i64] } %t639, i32 %t641)
  store { i64, [2 x i64] } %t645, ptr %l336
  br label %bb172
bb172:
  %t646 = load { i64, [2 x i64] }, ptr %l336
  store { i64, [2 x i64] } %t646, ptr %l16
  %t647 = load { i64, [2 x i64] }, ptr %l9
  %t649 = extractvalue { i64, [2 x i64] } %t647, 0
  %t650 = icmp eq i64 %t649, 0
  %t652 = xor i1 %t650, true
  br i1 %t652, label %bb173, label %bb174
bb173:
  %t654 = load { i64, [2 x i64] }, ptr %l16
  %t656 = extractvalue { i64, [2 x i64] } %t654, 0
  %t657 = icmp eq i64 %t656, 0
  %t659 = xor i1 %t657, true
  store i1 %t659, ptr %l340, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l340, !tbaa !21
  br label %bb175
bb175:
  %t661 = load i1, ptr %l340, !tbaa !21
  br i1 %t661, label %bb176, label %bb177
bb176:
  %t662 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t662, ptr %l16
  br label %bb178
bb177:
  br label %bb178
bb178:
  %t664 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t665 = load i32, ptr %t664, !range !{i32 0, i32 7}
  %t667 = trunc i64 1 to i32
  %t668 = icmp eq i32 %t665, %t667
  br i1 %t668, label %bb179, label %bb180
bb179:
  %t670 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t671 = load { i64, [1 x i64] }, ptr %t670
  %t673 = extractvalue { i64, [1 x i64] } %t671, 0
  %t674 = icmp eq i64 %t673, 1
  store i1 %t674, ptr %l347, !tbaa !21
  br label %bb181
bb180:
  store i1 false, ptr %l347, !tbaa !21
  br label %bb181
bb181:
  %t676 = load i1, ptr %l347, !tbaa !21
  br i1 %t676, label %bb182, label %bb183
bb182:
  store { i64, [2 x i64] } zeroinitializer, ptr %t677
  %t678 = getelementptr { i64, [2 x i64] }, ptr %t677, i32 0, i32 0
  store i64 0, ptr %t678
  %t679 = load { i64, [2 x i64] }, ptr %t677
  store { i64, [2 x i64] } %t679, ptr %l16
  br label %bb184
bb183:
  br label %bb184
bb184:
  %t681 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t682 = load { i64, [1 x i64] }, ptr %t681
  store { i64, [1 x i64] } %t682, ptr %l17
  %t684 = load { i64, [1 x i64] }, ptr %l17
  %t686 = extractvalue { i64, [1 x i64] } %t684, 0
  %t687 = icmp eq i64 %t686, 2
  br i1 %t687, label %bb185, label %bb186
bb185:
  %t689 = getelementptr { i64, [1 x i64] }, ptr %l17, i32 0, i32 1
  %t690 = getelementptr { i32 }, ptr %t689, i32 0, i32 0
  %t691 = load i32, ptr %t690
  store i32 %t691, ptr %l18, !tbaa !23
  br label %bb187
bb186:
  br label %bb196
bb187:
  %t693 = load { i64, [2 x i64] }, ptr %l16
  %t695 = extractvalue { i64, [2 x i64] } %t693, 0
  %t696 = icmp eq i64 %t695, 5
  br i1 %t696, label %bb188, label %bb189
bb188:
  %t698 = getelementptr { i64, [2 x i64] }, ptr %l16, i32 0, i32 1
  %t699 = getelementptr { i64 }, ptr %t698, i32 0, i32 0
  %t700 = load i64, ptr %t699
  store i64 %t700, ptr %l19, !tbaa !24
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t704 = getelementptr %"compiler/scope:Scoper", ptr %t702, i32 0, i32 27
  %t705 = load i1, ptr %t704, !tbaa !21
  br i1 %t705, label %bb190, label %bb191
bb189:
  br label %bb195
bb190:
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t708 = load i32, ptr %l18, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunknownMark(ptr %v0, ptr %t707, i32 %t708)
  br label %bb192
bb191:
  br label %bb193
bb192:
  br label %bb193
bb193:
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t712 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t713 = load i32, ptr %t712, !tbaa !23
  %t716 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t711, i32 %t713)
  store { i64, [2 x i64] } %t716, ptr %l364
  br label %bb194
bb194:
  %t717 = load { i64, [2 x i64] }, ptr %l364
  store { i64, [2 x i64] } %t717, ptr %l16
  br label %bb195
bb195:
  br label %bb201
bb196:
  br i1 true, label %bb197, label %bb198
bb197:
  br label %bb199
bb198:
  br label %bb200
bb199:
  br label %bb201
bb200:
  call void @__olang_check_failed(ptr @olang_loc_544377bbfc98dd_9d2d150d24c02431)
  unreachable
bb201:
  %t718 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t719 = load i32, ptr %t718, !range !{i32 0, i32 7}
  %t721 = trunc i64 6 to i32
  %t722 = icmp eq i32 %t719, %t721
  br i1 %t722, label %bb202, label %bb203
bb202:
  %t724 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t725 = load { i64, [1 x i64] }, ptr %t724
  store { i64, [1 x i64] } %t725, ptr %l20
  %t727 = load { i64, [1 x i64] }, ptr %l20
  %t729 = extractvalue { i64, [1 x i64] } %t727, 0
  %t730 = icmp eq i64 %t729, 2
  br i1 %t730, label %bb204, label %bb205
bb203:
  br label %bb217
bb204:
  %t732 = getelementptr { i64, [1 x i64] }, ptr %l20, i32 0, i32 1
  %t733 = getelementptr { i32 }, ptr %t732, i32 0, i32 0
  %t734 = load i32, ptr %t733
  store i32 %t734, ptr %l21, !tbaa !23
  br label %bb206
bb205:
  br label %bb210
bb206:
  %t736 = load ptr, ptr %l0, !tbaa !29
  %t737 = load i64, ptr @G_2ecompiler_2fscope_2eWhyField, !tbaa !24
  %t740 = getelementptr %"compiler/scope:Scoper", ptr %t736, i32 0, i32 103
  store i64 %t737, ptr %t740, !tbaa !24
  %t741 = load ptr, ptr %l0, !tbaa !29
  store ptr %t741, ptr %l373, !tbaa !29
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t743 = load i32, ptr %l21, !tbaa !23
  %t746 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %t742, i32 %t743)
  store { i64, [2 x i64] } %t746, ptr %l376
  br label %bb207
bb207:
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t749 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t747, i32 0)
  store { i64, [2 x i64] } %t749, ptr %l378
  br label %bb208
bb208:
  %t750 = load ptr, ptr %l373, !tbaa !29
  %t751 = load { i64, [2 x i64] }, ptr %l376
  %t752 = load { i64, [2 x i64] }, ptr %l378
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %t750, { i64, [2 x i64] } %t751, { i64, [2 x i64] } %t752, i1 false)
  br label %bb209
bb209:
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t755 = getelementptr %"compiler/scope:Scoper", ptr %t753, i32 0, i32 103
  store i64 0, ptr %t755, !tbaa !24
  br label %bb216
bb210:
  br i1 true, label %bb211, label %bb212
bb211:
  br label %bb213
bb212:
  br label %bb215
bb213:
  %t756 = load ptr, ptr %l0, !tbaa !29
  %t758 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t756, i32 0)
  store { i64, [2 x i64] } %t758, ptr %l381
  br label %bb214
bb214:
  %t759 = load { i64, [2 x i64] }, ptr %l381
  store { i64, [2 x i64] } %t759, ptr %l16
  br label %bb216
bb215:
  call void @__olang_check_failed(ptr @olang_loc_f38c14401421162c_fbdeffc88600a020)
  unreachable
bb216:
  br label %bb217
bb217:
  %t760 = load ptr, ptr %l0, !tbaa !29
  %t761 = load i32, ptr %l5, !tbaa !23
  %t764 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t760, i32 %t761)
  store i1 %t764, ptr %l384
  br label %bb218
bb218:
  %t765 = load i1, ptr %l384, !tbaa !21
  br i1 %t765, label %bb219, label %bb220
bb219:
  %t766 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t767 = load i32, ptr %t766, !range !{i32 0, i32 7}
  %t769 = trunc i64 3 to i32
  %t770 = icmp eq i32 %t767, %t769
  %t772 = xor i1 %t770, true
  store i1 %t772, ptr %l385, !tbaa !21
  br label %bb221
bb220:
  store i1 false, ptr %l385, !tbaa !21
  br label %bb221
bb221:
  %t774 = load i1, ptr %l385, !tbaa !21
  br i1 %t774, label %bb222, label %bb223
bb222:
  %t775 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t776 = load i32, ptr %t775, !range !{i32 0, i32 7}
  %t778 = trunc i64 2 to i32
  %t779 = icmp eq i32 %t776, %t778
  %t781 = xor i1 %t779, true
  store i1 %t781, ptr %l389, !tbaa !21
  br label %bb224
bb223:
  store i1 false, ptr %l389, !tbaa !21
  br label %bb224
bb224:
  %t783 = load i1, ptr %l389, !tbaa !21
  br i1 %t783, label %bb225, label %bb226
bb225:
  %t784 = load ptr, ptr %l0, !tbaa !29
  store ptr %t784, ptr %l393, !tbaa !29
  %t785 = load ptr, ptr %l3, !tbaa !29
  %t787 = icmp eq ptr %t785, null
  br i1 %t787, label %bb227, label %bb228
bb226:
  br label %bb231
bb227:
  call void @__olang_check_failed(ptr @olang_loc_9ce531bc53dbe305_ec5af8173ba88031)
  unreachable
bb228:
  br label %bb229
bb229:
  %t789 = load ptr, ptr %l3, !tbaa !29
  %t790 = load ptr, ptr %l393, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitBorrow(ptr %v0, ptr %v1, ptr %t790, ptr %t789)
  br label %bb230
bb230:
  br label %bb231
bb231:
  %t792 = load ptr, ptr %l0, !tbaa !29
  %t793 = load i32, ptr %l5, !tbaa !23
  %t796 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t792, i32 %t793)
  store i1 %t796, ptr %l399
  br label %bb232
bb232:
  %t797 = load i1, ptr %l399, !tbaa !21
  br i1 %t797, label %bb233, label %bb234
bb233:
  %t798 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t799 = load i32, ptr %t798, !range !{i32 0, i32 7}
  %t801 = trunc i64 3 to i32
  %t802 = icmp eq i32 %t799, %t801
  store i1 %t802, ptr %l400, !tbaa !21
  br label %bb235
bb234:
  store i1 false, ptr %l400, !tbaa !21
  br label %bb235
bb235:
  %t804 = load i1, ptr %l400, !tbaa !21
  br i1 %t804, label %bb236, label %bb237
bb236:
  %t805 = load ptr, ptr %l3, !tbaa !29
  store ptr %t805, ptr %l403, !tbaa !29
  store i1 false, ptr %l404, !tbaa !21
  %t806 = load ptr, ptr %l403, !tbaa !29
  %t807 = icmp ne ptr %t806, null
  br i1 %t807, label %bb238, label %bb239
bb237:
  br label %bb259
bb238:
  %t809 = load ptr, ptr %l403, !tbaa !29
  %t810 = load i64, ptr %t809, !range !{i64 0, i64 18}
  %t812 = icmp eq i64 %t810, 3
  store i1 %t812, ptr %l404, !tbaa !21
  br label %bb239
bb239:
  %t813 = load i1, ptr %l404, !tbaa !21
  br i1 %t813, label %bb240, label %bb241
bb240:
  %t814 = load ptr, ptr %l3, !tbaa !29
  %t816 = getelementptr { i64, [5 x i64] }, ptr %t814, i32 0, i32 1
  %t817 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t816, i32 0, i32 2
  %t818 = load ptr, ptr %t817
  store ptr %t818, ptr %l22, !tbaa !29
  br label %bb242
bb241:
  br label %bb253
bb242:
  %t820 = load ptr, ptr %l0, !tbaa !29
  %t821 = load ptr, ptr %l22, !tbaa !29
  %t824 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitPlace(ptr %v0, ptr %v1, ptr %t820, ptr %t821)
  store i1 %t824, ptr %l411
  br label %bb243
bb243:
  %t825 = load i1, ptr %l411, !tbaa !21
  br i1 %t825, label %bb244, label %bb245
bb244:
  store i1 true, ptr %l412, !tbaa !21
  br label %bb247
bb245:
  %t826 = load ptr, ptr %l0, !tbaa !29
  %t827 = load ptr, ptr %l22, !tbaa !29
  %t830 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitHeld(ptr %v0, ptr %v1, ptr %t826, ptr %t827)
  store i1 %t830, ptr %l415
  br label %bb246
bb246:
  %t831 = load i1, ptr %l415, !tbaa !21
  store i1 %t831, ptr %l412, !tbaa !21
  br label %bb247
bb247:
  %t832 = load i1, ptr %l412, !tbaa !21
  br i1 %t832, label %bb248, label %bb249
bb248:
  %t833 = load ptr, ptr %l0, !tbaa !29
  %t835 = getelementptr %"compiler/scope:Scoper", ptr %t833, i32 0, i32 41
  store ptr %t835, ptr %l417, !tbaa !29
  %t836 = load i32, ptr %l2, !tbaa !23
  %t838 = sext i32 %t836 to i64
  store i64 %t838, ptr %l419, !tbaa !24
  %t839 = load ptr, ptr %l0, !tbaa !29
  %t840 = load ptr, ptr %l22, !tbaa !29
  %t843 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %t839, ptr %t840)
  store { i64, [2 x i64] } %t843, ptr %l422
  br label %bb250
bb249:
  br label %bb252
bb250:
  %t844 = load ptr, ptr %l417, !tbaa !29
  %t845 = load i64, ptr %l419, !tbaa !24
  %t846 = load { i64, [2 x i64] }, ptr %l422
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H38f9aff1b0310316a48dc5a28922f96e(ptr %v0, ptr %t844, i64 %t845, { i64, [2 x i64] } %t846)
  br label %bb251
bb251:
  br label %bb252
bb252:
  br label %bb258
bb253:
  br i1 true, label %bb254, label %bb255
bb254:
  br label %bb256
bb255:
  br label %bb257
bb256:
  br label %bb258
bb257:
  call void @__olang_check_failed(ptr @olang_loc_f132d9555aa3b3ed_19b32ee1bad8ae89)
  unreachable
bb258:
  br label %bb259
bb259:
  %t847 = load { i64, [2 x i64] }, ptr %l16
  %t849 = extractvalue { i64, [2 x i64] } %t847, 0
  %t850 = icmp eq i64 %t849, 0
  br i1 %t850, label %bb260, label %bb261
bb260:
  store %olang.scope zeroinitializer, ptr %s29
  %t852 = load { i64, [2 x i64] }, ptr %l9
  %t854 = extractvalue { i64, [2 x i64] } %t852, 0
  %t855 = icmp eq i64 %t854, 0
  %t857 = xor i1 %t855, true
  br i1 %t857, label %bb262, label %bb263
bb261:
  br label %bb404
bb262:
  %t859 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t859, ptr %l428
  br label %bb265
bb263:
  %t861 = load ptr, ptr %l0, !tbaa !29
  %t862 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t863 = load i32, ptr %t862, !tbaa !23
  %t866 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t861, i32 %t863)
  store { i64, [2 x i64] } %t866, ptr %l432
  br label %bb264
bb264:
  %t867 = load { i64, [2 x i64] }, ptr %l432
  store { i64, [2 x i64] } %t867, ptr %l428
  br label %bb265
bb265:
  %t868 = load { i64, [2 x i64] }, ptr %l428
  store { i64, [2 x i64] } %t868, ptr %l23
  %t869 = load ptr, ptr %l0, !tbaa !29
  %t870 = load i32, ptr %l2, !tbaa !23
  %t872 = sext i32 %t870 to i64
  %t875 = getelementptr %"compiler/scope:Scoper", ptr %t869, i32 0, i32 137
  store i64 %t872, ptr %t875, !tbaa !24
  %t876 = load ptr, ptr %l0, !tbaa !29
  store ptr %t876, ptr %l436, !tbaa !29
  %t877 = load i1, ptr %l7, !tbaa !21
  br i1 %t877, label %bb266, label %bb267
bb266:
  %t879 = load i1, ptr %l8, !tbaa !21
  %t881 = xor i1 %t879, true
  store i1 %t881, ptr %l438, !tbaa !21
  br label %bb268
bb267:
  store i1 false, ptr %l438, !tbaa !21
  br label %bb268
bb268:
  %t883 = load i1, ptr %l438, !tbaa !21
  br i1 %t883, label %bb269, label %bb270
bb269:
  %t884 = load { i64, [2 x i64] }, ptr %l9
  %t886 = extractvalue { i64, [2 x i64] } %t884, 0
  %t887 = icmp eq i64 %t886, 0
  store i1 %t887, ptr %l441, !tbaa !21
  br label %bb271
bb270:
  store i1 false, ptr %l441, !tbaa !21
  br label %bb271
bb271:
  %t889 = load i1, ptr %l441, !tbaa !21
  %t890 = load ptr, ptr %l436, !tbaa !29
  %t891 = getelementptr %"compiler/scope:Scoper", ptr %t890, i32 0, i32 106
  store i1 %t889, ptr %t891, !tbaa !21
  %t892 = load i1, ptr %l8, !tbaa !21
  br i1 %t892, label %bb272, label %bb273
bb272:
  %t894 = load ptr, ptr %l0, !tbaa !29
  store ptr %t894, ptr %l445, !tbaa !29
  %t895 = load i1, ptr %l7, !tbaa !21
  br i1 %t895, label %bb274, label %bb275
bb273:
  br label %bb280
bb274:
  %t897 = load { i64, [2 x i64] }, ptr %l9
  %t899 = extractvalue { i64, [2 x i64] } %t897, 0
  %t900 = icmp eq i64 %t899, 0
  store i1 %t900, ptr %l447, !tbaa !21
  br label %bb276
bb275:
  store i1 false, ptr %l447, !tbaa !21
  br label %bb276
bb276:
  %t902 = load i1, ptr %l447, !tbaa !21
  br i1 %t902, label %bb277, label %bb278
bb277:
  store i64 1, ptr %l450, !tbaa !24
  br label %bb279
bb278:
  store i64 0, ptr %l450, !tbaa !24
  br label %bb279
bb279:
  %t903 = load i64, ptr %l450, !tbaa !24
  %t904 = load ptr, ptr %l445, !tbaa !29
  %t905 = getelementptr %"compiler/scope:Scoper", ptr %t904, i32 0, i32 109
  store i64 %t903, ptr %t905, !tbaa !24
  br label %bb280
bb280:
  %t906 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t907
  %t908 = getelementptr { i64, [2 x i64] }, ptr %t907, i32 0, i32 0
  store i64 0, ptr %t908
  %t909 = load { i64, [2 x i64] }, ptr %t907
  %t912 = getelementptr %"compiler/scope:Scoper", ptr %t906, i32 0, i32 67
  store { i64, [2 x i64] } %t909, ptr %t912
  %t913 = load ptr, ptr %l0, !tbaa !29
  %t914 = load ptr, ptr %l3, !tbaa !29
  %t915 = load { i64, [2 x i64] }, ptr %l23
  %t919 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t913, ptr %t914, { i64, [2 x i64] } %t915)
  store %"compiler/scope:Val" %t919, ptr %l456
  br label %bb281
bb281:
  %t920 = load %"compiler/scope:Val", ptr %l456
  store %"compiler/scope:Val" %t920, ptr %l24
  %t921 = load ptr, ptr %l0, !tbaa !29
  %t923 = getelementptr %"compiler/scope:Scoper", ptr %t921, i32 0, i32 137
  store i64 -1, ptr %t923, !tbaa !24
  %t924 = load ptr, ptr %l0, !tbaa !29
  %t926 = getelementptr %"compiler/scope:Scoper", ptr %t924, i32 0, i32 106
  store i1 false, ptr %t926, !tbaa !21
  %t927 = load ptr, ptr %l0, !tbaa !29
  %t929 = getelementptr %"compiler/scope:Scoper", ptr %t927, i32 0, i32 109
  store i64 -1, ptr %t929, !tbaa !24
  %t930 = load ptr, ptr %l0, !tbaa !29
  store ptr %t930, ptr %l460, !tbaa !29
  %t931 = load i32, ptr %l2, !tbaa !23
  %t933 = sext i32 %t931 to i64
  store i64 %t933, ptr %l462, !tbaa !24
  %t934 = load ptr, ptr %l3, !tbaa !29
  %t936 = icmp eq ptr %t934, null
  br i1 %t936, label %bb282, label %bb283
bb282:
  call void @__olang_check_failed(ptr @olang_loc_607bd9fd8b5af48f_3677f488c8afa2ab)
  unreachable
bb283:
  br label %bb284
bb284:
  %t938 = load ptr, ptr %l3, !tbaa !29
  %t939 = load %"compiler/scope:Val", ptr %l24
  %t940 = load ptr, ptr %l460, !tbaa !29
  %t941 = load i64, ptr %l462, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteOrigin(ptr %v0, ptr %v1, ptr %t940, i64 %t941, ptr %t938, %"compiler/scope:Val" %t939)
  br label %bb285
bb285:
  %t944 = load ptr, ptr %l0, !tbaa !29
  %t946 = getelementptr %"compiler/scope:Scoper", ptr %t944, i32 0, i32 67
  %t947 = load { i64, [2 x i64] }, ptr %t946
  %t949 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t947)
  store i1 %t949, ptr %l469
  br label %bb286
bb286:
  %t950 = load i1, ptr %l469, !tbaa !21
  br i1 %t950, label %bb287, label %bb288
bb287:
  %t951 = load ptr, ptr %l0, !tbaa !29
  %t952 = load i32, ptr %l2, !tbaa !23
  %t954 = sext i32 %t952 to i64
  %t957 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewalkLocal(ptr %v0, ptr %t951, i64 %t954)
  store i1 %t957, ptr %l474
  br label %bb289
bb288:
  store i1 false, ptr %l470, !tbaa !21
  br label %bb290
bb289:
  %t958 = load i1, ptr %l474, !tbaa !21
  store i1 %t958, ptr %l470, !tbaa !21
  br label %bb290
bb290:
  %t959 = load i1, ptr %l470, !tbaa !21
  br i1 %t959, label %bb291, label %bb292
bb291:
  %t960 = load ptr, ptr %l0, !tbaa !29
  %t962 = getelementptr %"compiler/scope:Scoper", ptr %t960, i32 0, i32 66
  %t963 = load i32, ptr %l2, !tbaa !23
  %t965 = sext i32 %t963 to i64
  %t966 = load ptr, ptr %l0, !tbaa !29
  %t968 = getelementptr %"compiler/scope:Scoper", ptr %t966, i32 0, i32 67
  %t969 = load { i64, [2 x i64] }, ptr %t968
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H38f9aff1b0310316a48dc5a28922f96e(ptr %v0, ptr %t962, i64 %t965, { i64, [2 x i64] } %t969)
  br label %bb293
bb292:
  br label %bb294
bb293:
  br label %bb294
bb294:
  %t973 = load ptr, ptr %l0, !tbaa !29
  %t975 = getelementptr %"compiler/scope:Scoper", ptr %t973, i32 0, i32 69
  %t976 = load i64, ptr %t975, !tbaa !24
  %t978 = icmp sge i64 %t976, 0
  br i1 %t978, label %bb295, label %bb296
bb295:
  %t980 = load ptr, ptr %l0, !tbaa !29
  %t982 = getelementptr %"compiler/scope:Scoper", ptr %t980, i32 0, i32 68
  %t983 = load i32, ptr %l2, !tbaa !23
  %t985 = sext i32 %t983 to i64
  %t986 = load ptr, ptr %l0, !tbaa !29
  %t988 = getelementptr %"compiler/scope:Scoper", ptr %t986, i32 0, i32 69
  %t989 = load i64, ptr %t988, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t982, i64 %t985, i64 %t989)
  br label %bb297
bb296:
  br label %bb298
bb297:
  br label %bb298
bb298:
  %t993 = load ptr, ptr %l0, !tbaa !29
  store ptr %t993, ptr %l490, !tbaa !29
  %t994 = load ptr, ptr %l3, !tbaa !29
  %t996 = icmp eq ptr %t994, null
  br i1 %t996, label %bb299, label %bb300
bb299:
  call void @__olang_check_failed(ptr @olang_loc_a12e96be7ca439b0_5f205879a795b73c)
  unreachable
bb300:
  br label %bb301
bb301:
  %t998 = load ptr, ptr %l3, !tbaa !29
  %t999 = load ptr, ptr %l490, !tbaa !29
  %t1001 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %v1, ptr %t999, ptr %t998)
  store i64 %t1001, ptr %l494
  br label %bb302
bb302:
  %t1002 = load i64, ptr %l494, !tbaa !24
  store i64 %t1002, ptr %l25, !tbaa !24
  %t1003 = load i64, ptr %l25, !tbaa !24
  %t1005 = icmp sge i64 %t1003, 0
  br i1 %t1005, label %bb303, label %bb304
bb303:
  %t1007 = load ptr, ptr %l0, !tbaa !29
  %t1009 = getelementptr %"compiler/scope:Scoper", ptr %t1007, i32 0, i32 68
  %t1010 = load i64, ptr %l25, !tbaa !24
  %t1013 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t1009, i64 %t1010)
  store i1 %t1013, ptr %l501
  br label %bb305
bb304:
  store i1 false, ptr %l497, !tbaa !21
  br label %bb306
bb305:
  %t1014 = load i1, ptr %l501, !tbaa !21
  store i1 %t1014, ptr %l497, !tbaa !21
  br label %bb306
bb306:
  %t1015 = load i1, ptr %l497, !tbaa !21
  br i1 %t1015, label %bb307, label %bb308
bb307:
  %t1016 = load ptr, ptr %l0, !tbaa !29
  %t1018 = getelementptr %"compiler/scope:Scoper", ptr %t1016, i32 0, i32 68
  store ptr %t1018, ptr %l503, !tbaa !29
  %t1019 = load i32, ptr %l2, !tbaa !23
  %t1021 = sext i32 %t1019 to i64
  store i64 %t1021, ptr %l505, !tbaa !24
  %t1022 = load ptr, ptr %l0, !tbaa !29
  %t1024 = getelementptr %"compiler/scope:Scoper", ptr %t1022, i32 0, i32 68
  %t1025 = load i64, ptr %l25, !tbaa !24
  %t1028 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t1024, i64 %t1025)
  %t1029 = extractvalue { i32, i64 } %t1028, 1
  %t1030 = extractvalue { i32, i64 } %t1028, 0
  store i32 %t1030, ptr %l511
  %t1031 = icmp ne i32 %t1030, 0
  br i1 %t1031, label %bb310, label %ok.1032, !prof !99
ok.1032:
  store i64 %t1029, ptr %l510
  br label %bb309
bb308:
  br label %bb314
bb309:
  %t1033 = load i64, ptr %l510, !tbaa !24
  store i64 %t1033, ptr %l506, !tbaa !24
  br label %bb312
bb310:
  br label %bb311
bb311:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l506, !tbaa !24
  br label %bb312
bb312:
  %t1034 = load ptr, ptr %l503, !tbaa !29
  %t1035 = load i64, ptr %l505, !tbaa !24
  %t1036 = load i64, ptr %l506, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t1034, i64 %t1035, i64 %t1036)
  br label %bb313
bb313:
  br label %bb314
bb314:
  %t1037 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t1038
  %t1039 = getelementptr { i64, [2 x i64] }, ptr %t1038, i32 0, i32 0
  store i64 0, ptr %t1039
  %t1040 = load { i64, [2 x i64] }, ptr %t1038
  %t1043 = getelementptr %"compiler/scope:Scoper", ptr %t1037, i32 0, i32 67
  store { i64, [2 x i64] } %t1040, ptr %t1043
  %t1044 = load ptr, ptr %l0, !tbaa !29
  %t1046 = getelementptr %"compiler/scope:Scoper", ptr %t1044, i32 0, i32 69
  store i64 -1, ptr %t1046, !tbaa !24
  %t1047 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1047, ptr %l515, !tbaa !29
  %t1048 = load ptr, ptr %l3, !tbaa !29
  %t1050 = icmp eq ptr %t1048, null
  br i1 %t1050, label %bb315, label %bb316
bb315:
  call void @__olang_check_failed(ptr @olang_loc_7ab8aec1f64ce329_6f79d936f6de900d)
  unreachable
bb316:
  br label %bb317
bb317:
  %t1052 = load ptr, ptr %l3, !tbaa !29
  %t1054 = load ptr, ptr %l515, !tbaa !29
  %t1056 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s29, ptr %t1054, ptr %t1052)
  store ptr %t1056, ptr %l520
  br label %bb318
bb318:
  %t1057 = load ptr, ptr %l520, !tbaa !29
  %t1058 = call ptr @compiler_2fscope_2eunPassed(ptr %s29, ptr %s29, ptr %t1057)
  store ptr %t1058, ptr %l521
  br label %bb319
bb319:
  %t1059 = load ptr, ptr %l521, !tbaa !29
  %t1061 = call ptr @compiler_2ftyped_2eCallOf(ptr %s29, ptr %s29, ptr %t1059)
  store ptr %t1061, ptr %l523
  br label %bb320
bb320:
  %t1062 = load ptr, ptr %l523, !tbaa !29
  store ptr %t1062, ptr %l26, !tbaa !29
  %t1063 = load ptr, ptr %l26, !tbaa !29
  %t1065 = icmp eq ptr %t1063, null
  %t1067 = xor i1 %t1065, true
  br i1 %t1067, label %bb321, label %bb322
bb321:
  %t1069 = load ptr, ptr %l26, !tbaa !29
  %t1071 = getelementptr %"compiler/typed:Call", ptr %t1069, i32 0, i32 1
  %t1072 = load { i64, ptr }, ptr %t1071, !tbaa !27
  %t1074 = extractvalue { i64, ptr } %t1072, 0
  %t1076 = icmp sgt i64 %t1074, 0
  store i1 %t1076, ptr %l527, !tbaa !21
  br label %bb323
bb322:
  store i1 false, ptr %l527, !tbaa !21
  br label %bb323
bb323:
  %t1078 = load i1, ptr %l527, !tbaa !21
  br i1 %t1078, label %bb324, label %bb325
bb324:
  %t1079 = load ptr, ptr %l0, !tbaa !29
  %t1080 = load ptr, ptr %l26, !tbaa !29
  %t1082 = getelementptr %"compiler/typed:Call", ptr %t1080, i32 0, i32 1
  %t1083 = load { i64, ptr }, ptr %t1082, !tbaa !27
  store { i64, ptr } %t1083, ptr %l534, !tbaa !27
  %t1084 = getelementptr { i64, ptr }, ptr %l534, i32 0, i32 1
  %t1085 = load ptr, ptr %t1084, !tbaa !27
  %t1086 = getelementptr ptr, ptr %t1085, i64 0
  %t1087 = load ptr, ptr %t1086, !tbaa !39
  %t1090 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLocal(ptr %v0, ptr %s29, ptr %t1079, ptr %t1087)
  store i64 %t1090, ptr %l536
  br label %bb326
bb325:
  br label %bb339
bb326:
  %t1091 = load i64, ptr %l536, !tbaa !24
  store i64 %t1091, ptr %l27, !tbaa !24
  %t1092 = load i64, ptr %l27, !tbaa !24
  %t1094 = icmp sge i64 %t1092, 0
  br i1 %t1094, label %bb327, label %bb328
bb327:
  %t1096 = load ptr, ptr %l0, !tbaa !29
  %t1098 = getelementptr %"compiler/scope:Scoper", ptr %t1096, i32 0, i32 68
  %t1099 = load i64, ptr %l27, !tbaa !24
  %t1102 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t1098, i64 %t1099)
  store i1 %t1102, ptr %l543
  br label %bb329
bb328:
  store i1 false, ptr %l539, !tbaa !21
  br label %bb330
bb329:
  %t1103 = load i1, ptr %l543, !tbaa !21
  store i1 %t1103, ptr %l539, !tbaa !21
  br label %bb330
bb330:
  %t1104 = load i1, ptr %l539, !tbaa !21
  br i1 %t1104, label %bb331, label %bb332
bb331:
  %t1105 = load ptr, ptr %l0, !tbaa !29
  %t1107 = getelementptr %"compiler/scope:Scoper", ptr %t1105, i32 0, i32 68
  store ptr %t1107, ptr %l545, !tbaa !29
  %t1108 = load i32, ptr %l2, !tbaa !23
  %t1110 = sext i32 %t1108 to i64
  store i64 %t1110, ptr %l547, !tbaa !24
  %t1111 = load ptr, ptr %l0, !tbaa !29
  %t1113 = getelementptr %"compiler/scope:Scoper", ptr %t1111, i32 0, i32 68
  %t1114 = load i64, ptr %l27, !tbaa !24
  %t1117 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t1113, i64 %t1114)
  %t1118 = extractvalue { i32, i64 } %t1117, 1
  %t1119 = extractvalue { i32, i64 } %t1117, 0
  store i32 %t1119, ptr %l553
  %t1120 = icmp ne i32 %t1119, 0
  br i1 %t1120, label %bb334, label %ok.1121, !prof !99
ok.1121:
  store i64 %t1118, ptr %l552
  br label %bb333
bb332:
  br label %bb338
bb333:
  %t1122 = load i64, ptr %l552, !tbaa !24
  store i64 %t1122, ptr %l548, !tbaa !24
  br label %bb336
bb334:
  br label %bb335
bb335:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l548, !tbaa !24
  br label %bb336
bb336:
  %t1123 = load ptr, ptr %l545, !tbaa !29
  %t1124 = load i64, ptr %l547, !tbaa !24
  %t1125 = load i64, ptr %l548, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t1123, i64 %t1124, i64 %t1125)
  br label %bb337
bb337:
  br label %bb338
bb338:
  br label %bb339
bb339:
  %t1126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1126, ptr %l554, !tbaa !29
  %t1127 = load i32, ptr %l2, !tbaa !23
  store i32 %t1127, ptr %l555, !tbaa !23
  %t1128 = load ptr, ptr %l3, !tbaa !29
  %t1130 = icmp eq ptr %t1128, null
  br i1 %t1130, label %bb340, label %bb341
bb340:
  call void @__olang_check_failed(ptr @olang_loc_4cb1e8bfb0eaf742_30c70eda17c6c626)
  unreachable
bb341:
  br label %bb342
bb342:
  %t1132 = load ptr, ptr %l3, !tbaa !29
  %t1133 = load ptr, ptr %l554, !tbaa !29
  %t1134 = load i32, ptr %l555, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %t1133, i32 %t1134, ptr %t1132)
  br label %bb343
bb343:
  %t1136 = load ptr, ptr %l0, !tbaa !29
  %t1138 = getelementptr %"compiler/scope:Scoper", ptr %t1136, i32 0, i32 31
  store ptr %t1138, ptr %l560, !tbaa !29
  %t1139 = load i32, ptr %l2, !tbaa !23
  %t1141 = sext i32 %t1139 to i64
  store i64 %t1141, ptr %l562, !tbaa !24
  %t1142 = load ptr, ptr %l0, !tbaa !29
  %t1143 = load %"compiler/scope:Val", ptr %l24
  %t1144 = load { i64, [2 x i64] }, ptr %l23
  %t1148 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalTerm(ptr %v0, ptr %t1142, %"compiler/scope:Val" %t1143, { i64, [2 x i64] } %t1144)
  store { i64, [2 x i64] } %t1148, ptr %l566
  br label %bb344
bb344:
  %t1149 = load ptr, ptr %l560, !tbaa !29
  %t1150 = load i64, ptr %l562, !tbaa !24
  %t1151 = load { i64, [2 x i64] }, ptr %l566
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1149, i64 %t1150, { i64, [2 x i64] } %t1151)
  br label %bb345
bb345:
  %t1152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1152, ptr %l567, !tbaa !29
  %t1153 = load i32, ptr %l5, !tbaa !23
  store i32 %t1153, ptr %l568, !tbaa !23
  %t1154 = load ptr, ptr %l3, !tbaa !29
  %t1156 = icmp eq ptr %t1154, null
  br i1 %t1156, label %bb346, label %bb347
bb346:
  call void @__olang_check_failed(ptr @olang_loc_ebf021f92f33e6c3_51775e5dd3616c17)
  unreachable
bb347:
  br label %bb348
bb348:
  %t1158 = load ptr, ptr %l3, !tbaa !29
  %t1159 = load ptr, ptr %l567, !tbaa !29
  %t1160 = load i32, ptr %l568, !tbaa !23
  %t1162 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownCall(ptr %v0, ptr %v1, ptr %t1159, i32 %t1160, ptr %t1158)
  store i1 %t1162, ptr %l572
  br label %bb349
bb349:
  %t1163 = load i1, ptr %l572, !tbaa !21
  br i1 %t1163, label %bb350, label %bb351
bb350:
  %t1164 = load ptr, ptr %l0, !tbaa !29
  %t1166 = getelementptr %"compiler/scope:Scoper", ptr %t1164, i32 0, i32 31
  %t1167 = load i32, ptr %l2, !tbaa !23
  %t1169 = sext i32 %t1167 to i64
  %t1170 = load { i64, [2 x i64] }, ptr %l23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1166, i64 %t1169, { i64, [2 x i64] } %t1170)
  br label %bb352
bb351:
  br label %bb361
bb352:
  %t1174 = load ptr, ptr %l3, !tbaa !29
  %t1176 = icmp eq ptr %t1174, null
  br i1 %t1176, label %bb353, label %bb354
bb353:
  call void @__olang_check_failed(ptr @olang_loc_b8d34b82d7d8e134_8820b4804d519ff8)
  unreachable
bb354:
  br label %bb355
bb355:
  %t1178 = load ptr, ptr %l3, !tbaa !29
  %t1181 = call ptr @compiler_2ftyped_2eCallOf(ptr %v1, ptr %v1, ptr %t1178)
  store ptr %t1181, ptr %l582
  br label %bb356
bb356:
  %t1182 = load ptr, ptr %l582, !tbaa !29
  store ptr %t1182, ptr %l28, !tbaa !29
  %t1183 = load ptr, ptr %l28, !tbaa !29
  %t1185 = icmp eq ptr %t1183, null
  %t1187 = xor i1 %t1185, true
  br i1 %t1187, label %bb357, label %bb358
bb357:
  %t1189 = load ptr, ptr %l0, !tbaa !29
  %t1190 = load ptr, ptr %l28, !tbaa !29
  %t1192 = getelementptr %"compiler/typed:Call", ptr %t1190, i32 0, i32 2
  %t1193 = load i32, ptr %t1192, !tbaa !23
  %t1194 = load { i64, [2 x i64] }, ptr %l23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuild(ptr %v0, ptr %t1189, i32 %t1193, { i64, [2 x i64] } %t1194)
  br label %bb359
bb358:
  br label %bb360
bb359:
  br label %bb360
bb360:
  br label %bb361
bb361:
  %t1198 = load ptr, ptr %l0, !tbaa !29
  %t1200 = getelementptr %"compiler/scope:Scoper", ptr %t1198, i32 0, i32 41
  %t1201 = load i32, ptr %l2, !tbaa !23
  %t1203 = sext i32 %t1201 to i64
  %t1206 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H65b4b9a6d1679f5b3ddedaa5b2e336bd(ptr %v0, ptr %t1200, i64 %t1203)
  %t1207 = extractvalue { i32, { i64, [2 x i64] } } %t1206, 1
  %t1208 = extractvalue { i32, { i64, [2 x i64] } } %t1206, 0
  store i32 %t1208, ptr %l596
  %t1209 = icmp ne i32 %t1208, 0
  br i1 %t1209, label %bb363, label %ok.1210, !prof !99
ok.1210:
  store { i64, [2 x i64] } %t1207, ptr %l595
  br label %bb362
bb362:
  %t1211 = load { i64, [2 x i64] }, ptr %l595
  store { i64, [2 x i64] } %t1211, ptr %l590
  br label %bb365
bb363:
  br label %bb364
bb364:
  call void @__olang_ert_req_clear()
  store { i64, [2 x i64] } zeroinitializer, ptr %t1212
  %t1213 = getelementptr { i64, [2 x i64] }, ptr %t1212, i32 0, i32 0
  store i64 0, ptr %t1213
  %t1214 = load { i64, [2 x i64] }, ptr %t1212
  store { i64, [2 x i64] } %t1214, ptr %l590
  br label %bb365
bb365:
  %t1216 = load { i64, [2 x i64] }, ptr %l590
  store { i64, [2 x i64] } %t1216, ptr %l29
  %t1217 = load { i64, [2 x i64] }, ptr %l29
  %t1219 = extractvalue { i64, [2 x i64] } %t1217, 0
  %t1220 = icmp eq i64 %t1219, 0
  %t1222 = xor i1 %t1220, true
  br i1 %t1222, label %bb366, label %bb367
bb366:
  %t1224 = load ptr, ptr %l0, !tbaa !29
  %t1226 = getelementptr %"compiler/scope:Scoper", ptr %t1224, i32 0, i32 31
  %t1227 = load i32, ptr %l2, !tbaa !23
  %t1229 = sext i32 %t1227 to i64
  %t1230 = load { i64, [2 x i64] }, ptr %l29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1226, i64 %t1229, { i64, [2 x i64] } %t1230)
  br label %bb368
bb367:
  br label %bb369
bb368:
  br label %bb369
bb369:
  %t1234 = getelementptr %"compiler/scope:Val", ptr %l24, i32 0, i32 1
  %t1235 = load { i64, [2 x i64] }, ptr %t1234
  store { i64, [2 x i64] } %t1235, ptr %l30
  %t1237 = load { i64, [2 x i64] }, ptr %l30
  %t1239 = extractvalue { i64, [2 x i64] } %t1237, 0
  %t1240 = icmp eq i64 %t1239, 4
  br i1 %t1240, label %bb370, label %bb371
bb370:
  %t1242 = getelementptr { i64, [2 x i64] }, ptr %l30, i32 0, i32 1
  %t1243 = getelementptr { i64, i64 }, ptr %t1242, i32 0, i32 0
  %t1244 = load i64, ptr %t1243
  store i64 %t1244, ptr %l31, !tbaa !24
  br label %bb372
bb371:
  br label %bb398
bb372:
  %t1246 = load i64, ptr %l31, !tbaa !24
  %t1248 = icmp slt i64 %t1246, 0
  br i1 %t1248, label %bb373, label %bb374
bb373:
  %t1250 = load i64, ptr %l31, !tbaa !24
  %t1252 = sub i64 0, %t1250
  %t1254 = sub i64 %t1252, 1
  store i64 %t1254, ptr %l615, !tbaa !24
  %t1255 = load ptr, ptr %l0, !tbaa !29
  %t1257 = getelementptr %"compiler/scope:Scoper", ptr %t1255, i32 0, i32 90
  %t1259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t1257)
  store i64 %t1259, ptr %l618
  br label %bb375
bb374:
  store i1 false, ptr %l612, !tbaa !21
  br label %bb376
bb375:
  %t1260 = load i64, ptr %l615, !tbaa !24
  %t1261 = load i64, ptr %l618, !tbaa !24
  %t1262 = icmp slt i64 %t1260, %t1261
  store i1 %t1262, ptr %l612, !tbaa !21
  br label %bb376
bb376:
  %t1264 = load i1, ptr %l612, !tbaa !21
  br i1 %t1264, label %bb377, label %bb378
bb377:
  %t1265 = load ptr, ptr %l0, !tbaa !29
  %t1267 = getelementptr %"compiler/scope:Scoper", ptr %t1265, i32 0, i32 90
  %t1268 = load i64, ptr %l31, !tbaa !24
  %t1270 = sub i64 0, %t1268
  %t1272 = sub i64 %t1270, 1
  %t1275 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1267, i64 %t1272)
  store i1 %t1275, ptr %l626
  br label %bb379
bb378:
  store i1 false, ptr %l620, !tbaa !21
  br label %bb380
bb379:
  %t1276 = load i1, ptr %l626, !tbaa !21
  store i1 %t1276, ptr %l620, !tbaa !21
  br label %bb380
bb380:
  %t1277 = load i1, ptr %l620, !tbaa !21
  br i1 %t1277, label %bb381, label %bb382
bb381:
  %t1278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1278, ptr %l627, !tbaa !29
  %t1279 = load ptr, ptr %l3, !tbaa !29
  %t1281 = icmp eq ptr %t1279, null
  br i1 %t1281, label %bb383, label %bb384
bb382:
  br label %bb397
bb383:
  call void @__olang_check_failed(ptr @olang_loc_4a1df88f6e47fa3d_f104cf9ebdc893f9)
  unreachable
bb384:
  br label %bb385
bb385:
  %t1283 = load ptr, ptr %l3, !tbaa !29
  %t1284 = load ptr, ptr %l627, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackExpr(ptr %v0, ptr %v1, ptr %t1284, ptr %t1283)
  br label %bb386
bb386:
  %t1286 = load ptr, ptr %l0, !tbaa !29
  %t1288 = getelementptr %"compiler/scope:Scoper", ptr %t1286, i32 0, i32 27
  %t1289 = load i1, ptr %t1288, !tbaa !21
  br i1 %t1289, label %bb387, label %bb388
bb387:
  store %olang.scope zeroinitializer, ptr %s41
  %t1291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1291, ptr %l633, !tbaa !29
  %t1292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1292, ptr %l634, !tbaa !29
  %t1293 = load ptr, ptr %l3, !tbaa !29
  %t1295 = icmp eq ptr %t1293, null
  br i1 %t1295, label %bb389, label %bb390
bb388:
  br label %bb396
bb389:
  call void @__olang_check_failed(ptr @olang_loc_1209ecb2ebe28e56_3903fb857fc509d2)
  unreachable
bb390:
  br label %bb391
bb391:
  %t1297 = load ptr, ptr %l3, !tbaa !29
  %t1299 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t1297)
  store %"compiler/source:Span" %t1299, ptr %l638
  br label %bb392
bb392:
  %t1300 = load ptr, ptr %l634, !tbaa !29
  %t1301 = load %"compiler/source:Span", ptr %l638
  %t1302 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t1300, %"compiler/source:Span" %t1301)
  store %"compiler/source:Span" %t1302, ptr %l639
  br label %bb393
bb393:
  %t1303 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %s41)
  store %"compiler/msgs:Msg" %t1303, ptr %l640
  br label %bb394
bb394:
  %t1304 = load ptr, ptr %l633, !tbaa !29
  %t1305 = load %"compiler/source:Span", ptr %l639
  %t1306 = load %"compiler/msgs:Msg", ptr %l640
  %t1307 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s41, ptr %t1304, %"compiler/source:Span" %t1305, %"compiler/msgs:Msg" %t1306)
  store i64 %t1307, ptr %l641
  br label %bb395
bb395:
  call void @__olang_scope_close(ptr %s41)
  br label %bb396
bb396:
  br label %bb397
bb397:
  br label %bb403
bb398:
  br i1 true, label %bb399, label %bb400
bb399:
  br label %bb401
bb400:
  br label %bb402
bb401:
  br label %bb403
bb402:
  call void @__olang_check_failed(ptr @olang_loc_f4fc0aa0b05f02b5_215f839e2022cb11)
  unreachable
bb403:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb404:
  %t1308 = load ptr, ptr %l0, !tbaa !29
  %t1310 = getelementptr %"compiler/scope:Scoper", ptr %t1308, i32 0, i32 31
  %t1311 = load i32, ptr %l2, !tbaa !23
  %t1313 = sext i32 %t1311 to i64
  %t1314 = load { i64, [2 x i64] }, ptr %l16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1310, i64 %t1313, { i64, [2 x i64] } %t1314)
  br label %bb405
bb405:
  %t1318 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t1319 = load { i64, [1 x i64] }, ptr %t1318
  %t1321 = extractvalue { i64, [1 x i64] } %t1319, 0
  %t1322 = icmp eq i64 %t1321, 1
  br i1 %t1322, label %bb406, label %bb407
bb406:
  %t1324 = load ptr, ptr %l0, !tbaa !29
  %t1325 = load i32, ptr %l5, !tbaa !23
  %t1328 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t1324, i32 %t1325)
  store i1 %t1328, ptr %l652
  br label %bb408
bb407:
  store i1 false, ptr %l649, !tbaa !21
  br label %bb409
bb408:
  %t1329 = load i1, ptr %l652, !tbaa !21
  store i1 %t1329, ptr %l649, !tbaa !21
  br label %bb409
bb409:
  %t1330 = load i1, ptr %l649, !tbaa !21
  br i1 %t1330, label %bb410, label %bb411
bb410:
  %t1331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1331, ptr %l654, !tbaa !29
  %t1332 = load ptr, ptr %l3, !tbaa !29
  %t1334 = icmp eq ptr %t1332, null
  br i1 %t1334, label %bb412, label %bb413
bb411:
  store i1 false, ptr %l653, !tbaa !21
  br label %bb416
bb412:
  call void @__olang_check_failed(ptr @olang_loc_404d48eac542ce9d_9912d4e42165f0c9)
  unreachable
bb413:
  br label %bb414
bb414:
  %t1336 = load ptr, ptr %l3, !tbaa !29
  %t1337 = load ptr, ptr %l654, !tbaa !29
  %t1339 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfRefs(ptr %v0, ptr %v1, ptr %t1337, ptr %t1336)
  store i1 %t1339, ptr %l658
  br label %bb415
bb415:
  %t1340 = load i1, ptr %l658, !tbaa !21
  store i1 %t1340, ptr %l653, !tbaa !21
  br label %bb416
bb416:
  %t1341 = load i1, ptr %l653, !tbaa !21
  %t1342 = load ptr, ptr %l0, !tbaa !29
  %t1346 = getelementptr %"compiler/scope:Scoper", ptr %t1342, i32 0, i32 122
  store i1 %t1341, ptr %t1346, !tbaa !21
  %t1347 = load ptr, ptr %l0, !tbaa !29
  %t1348 = load ptr, ptr %l3, !tbaa !29
  %t1349 = load { i64, [2 x i64] }, ptr %l16
  %t1353 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1347, ptr %t1348, { i64, [2 x i64] } %t1349)
  store %"compiler/scope:Val" %t1353, ptr %l664
  br label %bb417
bb417:
  %t1354 = load %"compiler/scope:Val", ptr %l664
  store %"compiler/scope:Val" %t1354, ptr %l33
  %t1355 = load ptr, ptr %l0, !tbaa !29
  %t1357 = getelementptr %"compiler/scope:Scoper", ptr %t1355, i32 0, i32 122
  store i1 false, ptr %t1357, !tbaa !21
  %t1358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1358, ptr %l666, !tbaa !29
  %t1359 = load i32, ptr %l2, !tbaa !23
  store i32 %t1359, ptr %l667, !tbaa !23
  %t1360 = load ptr, ptr %l3, !tbaa !29
  %t1362 = icmp eq ptr %t1360, null
  br i1 %t1362, label %bb418, label %bb419
bb418:
  call void @__olang_check_failed(ptr @olang_loc_bc57042d1b9aa9c8_42b203ed434388d4)
  unreachable
bb419:
  br label %bb420
bb420:
  %t1364 = load ptr, ptr %l3, !tbaa !29
  %t1365 = load ptr, ptr %l666, !tbaa !29
  %t1366 = load i32, ptr %l667, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %t1365, i32 %t1366, ptr %t1364)
  br label %bb421
bb421:
  %t1368 = getelementptr %"compiler/scope:Val", ptr %l33, i32 0, i32 1
  %t1369 = load { i64, [2 x i64] }, ptr %t1368
  %t1373 = extractvalue { i64, [2 x i64] } %t1369, 0
  %t1374 = icmp eq i64 %t1373, 5
  br i1 %t1374, label %bb422, label %bb423
bb422:
  br label %bb424
bb423:
  br label %bb451
bb424:
  %t1376 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t1377 = load i32, ptr %t1376, !range !{i32 0, i32 7}
  %t1379 = trunc i64 6 to i32
  %t1380 = icmp eq i32 %t1377, %t1379
  br i1 %t1380, label %bb425, label %bb426
bb425:
  %t1382 = load ptr, ptr %l0, !tbaa !29
  %t1383 = load i32, ptr %l5, !tbaa !23
  %t1386 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t1382, i32 %t1383)
  store i1 %t1386, ptr %l678
  br label %bb427
bb426:
  br label %bb435
bb427:
  %t1387 = load i1, ptr %l678, !tbaa !21
  store i1 %t1387, ptr %l35, !tbaa !21
  %t1388 = load ptr, ptr %l0, !tbaa !29
  %t1389 = load i64, ptr @G_2ecompiler_2fscope_2eWhyHolds, !tbaa !24
  %t1392 = getelementptr %"compiler/scope:Scoper", ptr %t1388, i32 0, i32 103
  store i64 %t1389, ptr %t1392, !tbaa !24
  %t1393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1393, ptr %l681, !tbaa !29
  %t1394 = getelementptr %"compiler/scope:Val", ptr %l33, i32 0, i32 1
  %t1395 = load { i64, [2 x i64] }, ptr %t1394
  store { i64, [2 x i64] } %t1395, ptr %l682
  %t1396 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t1396, ptr %l683
  %t1397 = load i1, ptr %l35, !tbaa !21
  store i1 %t1397, ptr %l684, !tbaa !21
  %t1398 = load ptr, ptr %l3, !tbaa !29
  %t1400 = icmp eq ptr %t1398, null
  br i1 %t1400, label %bb428, label %bb429
bb428:
  call void @__olang_check_failed(ptr @olang_loc_19aa55fe70facde7_b663d059e4ca19e3)
  unreachable
bb429:
  br label %bb430
bb430:
  %t1402 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1402, ptr %l687, !tbaa !29
  %t1403 = load i1, ptr %l35, !tbaa !21
  br i1 %t1403, label %bb431, label %bb432
bb431:
  %t1405 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  store i64 %t1405, ptr %l689, !tbaa !24
  br label %bb433
bb432:
  %t1407 = load i64, ptr @G_2ecompiler_2fscope_2eFitDecl, !tbaa !24
  store i64 %t1407, ptr %l689, !tbaa !24
  br label %bb433
bb433:
  %t1409 = load ptr, ptr %l681, !tbaa !29
  %t1410 = load { i64, [2 x i64] }, ptr %l682
  %t1411 = load { i64, [2 x i64] }, ptr %l683
  %t1412 = load i1, ptr %l684, !tbaa !21
  %t1413 = load ptr, ptr %l687, !tbaa !29
  %t1414 = load i64, ptr %l689, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t1409, { i64, [2 x i64] } %t1410, { i64, [2 x i64] } %t1411, i1 %t1412, ptr %t1413, i64 %t1414)
  br label %bb434
bb434:
  %t1415 = load ptr, ptr %l0, !tbaa !29
  %t1417 = getelementptr %"compiler/scope:Scoper", ptr %t1415, i32 0, i32 103
  store i64 0, ptr %t1417, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb435:
  %t1418 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t1419 = load { i64, [1 x i64] }, ptr %t1418
  %t1421 = extractvalue { i64, [1 x i64] } %t1419, 0
  %t1422 = icmp eq i64 %t1421, 1
  br i1 %t1422, label %bb436, label %bb437
bb436:
  %t1424 = load ptr, ptr %l0, !tbaa !29
  %t1425 = load i32, ptr %l5, !tbaa !23
  %t1428 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t1424, i32 %t1425)
  store i1 %t1428, ptr %l698
  br label %bb438
bb437:
  store i1 false, ptr %l695, !tbaa !21
  br label %bb439
bb438:
  %t1429 = load i1, ptr %l698, !tbaa !21
  store i1 %t1429, ptr %l695, !tbaa !21
  br label %bb439
bb439:
  %t1430 = load i1, ptr %l695, !tbaa !21
  br i1 %t1430, label %bb440, label %bb441
bb440:
  %t1431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1431, ptr %l700, !tbaa !29
  %t1432 = load ptr, ptr %l3, !tbaa !29
  %t1434 = icmp eq ptr %t1432, null
  br i1 %t1434, label %bb442, label %bb443
bb441:
  store i1 false, ptr %l699, !tbaa !21
  br label %bb446
bb442:
  call void @__olang_check_failed(ptr @olang_loc_eca6e0b2d52570fa_4fe6c0f0f8e0b5fe)
  unreachable
bb443:
  br label %bb444
bb444:
  %t1436 = load ptr, ptr %l3, !tbaa !29
  %t1437 = load ptr, ptr %l700, !tbaa !29
  %t1439 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfRefs(ptr %v0, ptr %v1, ptr %t1437, ptr %t1436)
  store i1 %t1439, ptr %l704
  br label %bb445
bb445:
  %t1440 = load i1, ptr %l704, !tbaa !21
  store i1 %t1440, ptr %l699, !tbaa !21
  br label %bb446
bb446:
  %t1441 = load i1, ptr %l699, !tbaa !21
  br i1 %t1441, label %bb447, label %bb448
bb447:
  %t1442 = load ptr, ptr %l0, !tbaa !29
  %t1444 = getelementptr %"compiler/scope:Scoper", ptr %t1442, i32 0, i32 31
  %t1445 = load i32, ptr %l2, !tbaa !23
  %t1447 = sext i32 %t1445 to i64
  %t1448 = getelementptr %"compiler/scope:Val", ptr %l33, i32 0, i32 1
  %t1449 = load { i64, [2 x i64] }, ptr %t1448
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1444, i64 %t1447, { i64, [2 x i64] } %t1449)
  br label %bb449
bb448:
  br label %bb450
bb449:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb450:
  br label %bb456
bb451:
  br i1 true, label %bb452, label %bb453
bb452:
  br label %bb454
bb453:
  br label %bb455
bb454:
  br label %bb456
bb455:
  call void @__olang_check_failed(ptr @olang_loc_acdf13ac8090b308_c550e3cb7d47705c)
  unreachable
bb456:
  %t1453 = getelementptr %"compiler/scope:Val", ptr %l33, i32 0, i32 0
  %t1454 = load i32, ptr %t1453, !range !{i32 0, i32 5}
  %t1456 = trunc i64 2 to i32
  %t1457 = icmp eq i32 %t1454, %t1456
  br i1 %t1457, label %bb457, label %bb458
bb457:
  %t1459 = load ptr, ptr %l0, !tbaa !29
  %t1461 = getelementptr %"compiler/scope:Scoper", ptr %t1459, i32 0, i32 27
  %t1462 = load i1, ptr %t1461, !tbaa !21
  store i1 %t1462, ptr %l712, !tbaa !21
  br label %bb459
bb458:
  store i1 false, ptr %l712, !tbaa !21
  br label %bb459
bb459:
  %t1464 = load i1, ptr %l712, !tbaa !21
  br i1 %t1464, label %bb460, label %bb461
bb460:
  %t1465 = load ptr, ptr %l0, !tbaa !29
  %t1466 = load { i64, [2 x i64] }, ptr %l16
  %t1469 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunknownBinding(ptr %v0, ptr %t1465, { i64, [2 x i64] } %t1466)
  store i1 %t1469, ptr %l718
  br label %bb462
bb461:
  store i1 false, ptr %l715, !tbaa !21
  br label %bb463
bb462:
  %t1470 = load i1, ptr %l718, !tbaa !21
  store i1 %t1470, ptr %l715, !tbaa !21
  br label %bb463
bb463:
  %t1471 = load i1, ptr %l715, !tbaa !21
  br i1 %t1471, label %bb464, label %bb465
bb464:
  store %olang.scope zeroinitializer, ptr %s47
  %t1472 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1472, ptr %l719, !tbaa !29
  %t1473 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1473, ptr %l720, !tbaa !29
  %t1474 = load ptr, ptr %l3, !tbaa !29
  %t1476 = icmp eq ptr %t1474, null
  br i1 %t1476, label %bb466, label %bb467
bb465:
  br label %bb472
bb466:
  call void @__olang_check_failed(ptr @olang_loc_3b111cc35ad2064c_5bc510d97bfe7450)
  unreachable
bb467:
  br label %bb468
bb468:
  %t1478 = load ptr, ptr %l3, !tbaa !29
  %t1479 = load ptr, ptr %l720, !tbaa !29
  %t1481 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t1479, ptr %t1478)
  store %"compiler/source:Span" %t1481, ptr %l724
  br label %bb469
bb469:
  %t1482 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %s47)
  store %"compiler/msgs:Msg" %t1482, ptr %l725
  br label %bb470
bb470:
  %t1483 = load ptr, ptr %l719, !tbaa !29
  %t1484 = load %"compiler/source:Span", ptr %l724
  %t1485 = load %"compiler/msgs:Msg", ptr %l725
  %t1486 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s47, ptr %t1483, %"compiler/source:Span" %t1484, %"compiler/msgs:Msg" %t1485)
  store i64 %t1486, ptr %l726
  br label %bb471
bb471:
  call void @__olang_scope_close(ptr %s47)
  br label %bb472
bb472:
  %t1487 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t1488 = load i32, ptr %t1487, !range !{i32 0, i32 7}
  %t1490 = trunc i64 6 to i32
  %t1491 = icmp eq i32 %t1488, %t1490
  br i1 %t1491, label %bb473, label %bb474
bb473:
  %t1493 = getelementptr %"compiler/scope:Val", ptr %l33, i32 0, i32 0
  %t1494 = load i32, ptr %t1493, !range !{i32 0, i32 5}
  %t1496 = trunc i64 2 to i32
  %t1497 = icmp eq i32 %t1494, %t1496
  store i1 %t1497, ptr %l729, !tbaa !21
  br label %bb475
bb474:
  store i1 false, ptr %l729, !tbaa !21
  br label %bb475
bb475:
  %t1499 = load i1, ptr %l729, !tbaa !21
  br i1 %t1499, label %bb476, label %bb477
bb476:
  %t1500 = getelementptr %"compiler/scope:Val", ptr %l33, i32 0, i32 1
  %t1501 = load { i64, [2 x i64] }, ptr %t1500
  store { i64, [2 x i64] } %t1501, ptr %l733
  %t1502 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t1502, ptr %l735
  %t1505 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l733, ptr %l735)
  store i1 %t1505, ptr %l737
  br label %bb478
bb477:
  store i1 false, ptr %l732, !tbaa !21
  br label %bb479
bb478:
  %t1506 = load i1, ptr %l737, !tbaa !21
  %t1507 = xor i1 %t1506, true
  store i1 %t1507, ptr %l732, !tbaa !21
  br label %bb479
bb479:
  %t1509 = load i1, ptr %l732, !tbaa !21
  br i1 %t1509, label %bb480, label %bb481
bb480:
  %t1510 = getelementptr %"compiler/scope:Val", ptr %l33, i32 0, i32 1
  %t1511 = load { i64, [2 x i64] }, ptr %t1510
  %t1513 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRelatable({ i64, [2 x i64] } %t1511)
  store i1 %t1513, ptr %l741
  br label %bb482
bb481:
  store i1 false, ptr %l739, !tbaa !21
  br label %bb483
bb482:
  %t1514 = load i1, ptr %l741, !tbaa !21
  store i1 %t1514, ptr %l739, !tbaa !21
  br label %bb483
bb483:
  %t1515 = load i1, ptr %l739, !tbaa !21
  br i1 %t1515, label %bb484, label %bb485
bb484:
  %t1516 = load ptr, ptr %l0, !tbaa !29
  %t1517 = load i64, ptr @G_2ecompiler_2fscope_2eWhyField, !tbaa !24
  %t1520 = getelementptr %"compiler/scope:Scoper", ptr %t1516, i32 0, i32 103
  store i64 %t1517, ptr %t1520, !tbaa !24
  %t1521 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1521, ptr %l744, !tbaa !29
  %t1522 = getelementptr %"compiler/scope:Val", ptr %l33, i32 0, i32 1
  %t1523 = load { i64, [2 x i64] }, ptr %t1522
  store { i64, [2 x i64] } %t1523, ptr %l745
  %t1524 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t1524, ptr %l746
  %t1525 = load ptr, ptr %l3, !tbaa !29
  %t1527 = icmp eq ptr %t1525, null
  br i1 %t1527, label %bb486, label %bb487
bb485:
  br label %bb490
bb486:
  call void @__olang_check_failed(ptr @olang_loc_3b2e5dd5e19962bb_2cdcb9ba8ccbb9af)
  unreachable
bb487:
  br label %bb488
bb488:
  %t1529 = load ptr, ptr %l3, !tbaa !29
  %t1530 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  %t1531 = load ptr, ptr %l744, !tbaa !29
  %t1532 = load { i64, [2 x i64] }, ptr %l745
  %t1533 = load { i64, [2 x i64] }, ptr %l746
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t1531, { i64, [2 x i64] } %t1532, { i64, [2 x i64] } %t1533, i1 false, ptr %t1529, i64 %t1530)
  br label %bb489
bb489:
  %t1536 = load ptr, ptr %l0, !tbaa !29
  %t1538 = getelementptr %"compiler/scope:Scoper", ptr %t1536, i32 0, i32 103
  store i64 0, ptr %t1538, !tbaa !24
  br label %bb490
bb490:
  %t1539 = getelementptr %"compiler/scope:Val", ptr %l33, i32 0, i32 0
  %t1540 = load i32, ptr %t1539, !range !{i32 0, i32 5}
  %t1542 = trunc i64 3 to i32
  %t1543 = icmp eq i32 %t1540, %t1542
  br i1 %t1543, label %bb491, label %bb492
bb491:
  %t1545 = load ptr, ptr %l0, !tbaa !29
  %t1546 = load i32, ptr %l5, !tbaa !23
  %t1549 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enarrowingMatters(ptr %v0, ptr %t1545, i32 %t1546)
  store i1 %t1549, ptr %l756
  br label %bb493
bb492:
  br label %bb505
bb493:
  %t1550 = load i1, ptr %l756, !tbaa !21
  store i1 %t1550, ptr %l36, !tbaa !21
  %t1551 = load i64, ptr @G_2ecompiler_2fscope_2eFitLocal, !tbaa !24
  store i64 %t1551, ptr %l37, !tbaa !24
  %t1553 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t1554 = load i32, ptr %t1553, !range !{i32 0, i32 7}
  %t1556 = trunc i64 6 to i32
  %t1557 = icmp eq i32 %t1554, %t1556
  br i1 %t1557, label %bb494, label %bb495
bb494:
  %t1559 = load ptr, ptr %l0, !tbaa !29
  %t1560 = load i32, ptr %l5, !tbaa !23
  %t1563 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t1559, i32 %t1560)
  store i1 %t1563, ptr %l762
  br label %bb496
bb495:
  br label %bb500
bb496:
  %t1564 = load i1, ptr %l762, !tbaa !21
  store i1 %t1564, ptr %l36, !tbaa !21
  %t1565 = load i1, ptr %l36, !tbaa !21
  br i1 %t1565, label %bb497, label %bb498
bb497:
  %t1567 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  store i64 %t1567, ptr %l764, !tbaa !24
  br label %bb499
bb498:
  %t1569 = load i64, ptr @G_2ecompiler_2fscope_2eFitDecl, !tbaa !24
  store i64 %t1569, ptr %l764, !tbaa !24
  br label %bb499
bb499:
  %t1571 = load i64, ptr %l764, !tbaa !24
  store i64 %t1571, ptr %l37, !tbaa !24
  %t1572 = load ptr, ptr %l0, !tbaa !29
  %t1573 = load i64, ptr @G_2ecompiler_2fscope_2eWhyHolds, !tbaa !24
  %t1576 = getelementptr %"compiler/scope:Scoper", ptr %t1572, i32 0, i32 103
  store i64 %t1573, ptr %t1576, !tbaa !24
  br label %bb500
bb500:
  %t1577 = load ptr, ptr %l0, !tbaa !29
  %t1578 = load i32, ptr %l2, !tbaa !23
  %t1580 = sext i32 %t1578 to i64
  %t1583 = getelementptr %"compiler/scope:Scoper", ptr %t1577, i32 0, i32 136
  store i64 %t1580, ptr %t1583, !tbaa !24
  %t1584 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1584, ptr %l772, !tbaa !29
  %t1585 = getelementptr %"compiler/scope:Val", ptr %l33, i32 0, i32 1
  %t1586 = load { i64, [2 x i64] }, ptr %t1585
  store { i64, [2 x i64] } %t1586, ptr %l773
  %t1587 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t1587, ptr %l774
  %t1588 = load i1, ptr %l36, !tbaa !21
  store i1 %t1588, ptr %l775, !tbaa !21
  %t1589 = load ptr, ptr %l3, !tbaa !29
  %t1591 = icmp eq ptr %t1589, null
  br i1 %t1591, label %bb501, label %bb502
bb501:
  call void @__olang_check_failed(ptr @olang_loc_3005b9c21f34ca3e_35904d8c355f64ba)
  unreachable
bb502:
  br label %bb503
bb503:
  %t1593 = load ptr, ptr %l3, !tbaa !29
  %t1594 = load i64, ptr %l37, !tbaa !24
  %t1595 = load ptr, ptr %l772, !tbaa !29
  %t1596 = load { i64, [2 x i64] }, ptr %l773
  %t1597 = load { i64, [2 x i64] }, ptr %l774
  %t1598 = load i1, ptr %l775, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t1595, { i64, [2 x i64] } %t1596, { i64, [2 x i64] } %t1597, i1 %t1598, ptr %t1593, i64 %t1594)
  br label %bb504
bb504:
  %t1601 = load ptr, ptr %l0, !tbaa !29
  %t1603 = getelementptr %"compiler/scope:Scoper", ptr %t1601, i32 0, i32 136
  store i64 -1, ptr %t1603, !tbaa !24
  %t1604 = load ptr, ptr %l0, !tbaa !29
  %t1606 = getelementptr %"compiler/scope:Scoper", ptr %t1604, i32 0, i32 103
  store i64 0, ptr %t1606, !tbaa !24
  br label %bb505
bb505:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftLocal(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i1
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca %"compiler/typed:Local"
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l22 = alloca ptr
  %l26 = alloca ptr
  %l35 = alloca %"compiler/typed:Local"
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l47 = alloca %"compiler/typed:Local"
  %l49 = alloca { i64, ptr }
  %l54 = alloca i1
  %l55 = alloca i64
  %l58 = alloca i64
  %l60 = alloca i1
  %l64 = alloca i64
  %l66 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l73 = alloca i1
  %l77 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i64
  %l84 = alloca i64
  %l87 = alloca ptr
  %l91 = alloca ptr
  %l100 = alloca %"compiler/typed:Local"
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, [2 x i64] }
  %l107 = alloca i64
  %l108 = alloca ptr
  %l117 = alloca %"compiler/typed:Local"
  %l119 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l126 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l127 = alloca { i64, [2 x i64] }
  %l131 = alloca { i64, [2 x i64] }
  %l132 = alloca i32
  %l136 = alloca { i64, [2 x i64] }
  %l138 = alloca i1
  %l139 = alloca { i64, [2 x i64] }
  %l143 = alloca { i64, [2 x i64] }
  %l146 = alloca i1
  %l148 = alloca i1
  %l150 = alloca i1
  %l152 = alloca i1
  %l153 = alloca { i64, [2 x i64] }
  %l155 = alloca { i64, [2 x i64] }
  %l157 = alloca i1
  %l159 = alloca i1
  %l160 = alloca { i64, [2 x i64] }
  %l162 = alloca { i64, [2 x i64] }
  %l164 = alloca i1
  %l165 = alloca i1
  %l169 = alloca i64
  %l175 = alloca { i64, [2 x i64] }
  %l177 = alloca { i64, [2 x i64] }
  %l179 = alloca i1
  %l181 = alloca ptr
  %l190 = alloca %"compiler/typed:Local"
  %l192 = alloca i1
  %l193 = alloca i1
  %l194 = alloca ptr
  %l203 = alloca %"compiler/typed:Local"
  %l205 = alloca i1
  %l208 = alloca i1
  %l210 = alloca i1
  %l212 = alloca i1
  %l214 = alloca i1
  %l218 = alloca i1
  %l245 = alloca %"compiler/typed:Local"
  %l247 = alloca ptr
  %l253 = alloca { i64, ptr }
  %l254 = alloca { i64, [2 x i64] }
  %l256 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l264 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.builder
  %s13room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l2
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenResult(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2)
  store i1 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i1, ptr %l12, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/scope:Scoper", ptr %t7, i32 0, i32 132
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsOwn(ptr %v0, ptr %t12, i64 %t13)
  store i1 %t16, ptr %l18
  br label %bb7
bb6:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  %t17 = load i1, ptr %l18, !tbaa !21
  store i1 %t17, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 148
  %t22 = load i1, ptr %t21, !tbaa !21
  br i1 %t22, label %bb11, label %bb12
bb10:
  br label %bb25
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 163
  store ptr %t26, ptr %l22, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/load:Loader", ptr %t33, i32 0, i32 3
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l26, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 25
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  br i1 %t42, label %bb13, label %bb14
bb12:
  br label %bb24
bb13:
  call void @__olang_check_failed(ptr @olang_loc_cf25d893b5e0925b_26a5f8a01e1a0e87)
  unreachable
bb14:
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 25
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t47, i32 0, i32 7
  %t51 = load i64, ptr %l1, !tbaa !24
  %t54 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t50, i64 %t51)
  store %"compiler/typed:Local" %t54, ptr %l35
  br label %bb16
bb16:
  %t55 = getelementptr %"compiler/typed:Local", ptr %l35, i32 0, i32 0
  %t56 = load i32, ptr %t55, !tbaa !23
  %t57 = load ptr, ptr %l26, !tbaa !29
  %t59 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s3, ptr %t57, i32 %t56)
  store { i64, ptr } %t59, ptr %l37
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l38, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/scope:Scoper", ptr %t61, i32 0, i32 25
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = icmp eq ptr %t64, null
  br i1 %t66, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_cf25d893b5e0925b_26a5f8a01e1a0e87)
  unreachable
bb19:
  br label %bb20
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 25
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 7
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t74, i64 %t75)
  store %"compiler/typed:Local" %t78, ptr %l47
  br label %bb21
bb21:
  %t79 = getelementptr %"compiler/typed:Local", ptr %l47, i32 0, i32 1
  %t80 = getelementptr %"compiler/source:Span", ptr %t79, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t84 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etraceAt(ptr %v0, ptr %s3, ptr %t82, i32 %t81)
  store { i64, ptr } %t84, ptr %l49
  br label %bb22
bb22:
  %t85 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t87 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = add i64 %t86, %t89
  %t91 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t94 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = add i64 %t93, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t85, i64 %t86)
  %t99 = getelementptr i8, ptr %t98, i64 %t86
  call void @olang_textcopy(ptr %t99, ptr %t88, i64 %t89)
  %t100 = getelementptr i8, ptr %t99, i64 %t89
  call void @olang_textcopy(ptr %t100, ptr %t91, i64 %t92)
  %t101 = getelementptr i8, ptr %t100, i64 %t92
  call void @olang_textcopy(ptr %t101, ptr %t95, i64 %t96)
  %t102 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t98, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = extractvalue { i64, ptr } %t103, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t111 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t111, { i64, ptr } %t110)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  %t113 = load i64, ptr %l1, !tbaa !24
  %t115 = icmp slt i64 %t113, 0
  br i1 %t115, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb29
bb27:
  %t117 = load i64, ptr %l1, !tbaa !24
  store i64 %t117, ptr %l55, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/scope:Scoper", ptr %t118, i32 0, i32 134
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t120)
  store i64 %t122, ptr %l58
  br label %bb28
bb28:
  %t123 = load i64, ptr %l55, !tbaa !24
  %t124 = load i64, ptr %l58, !tbaa !24
  %t125 = icmp sge i64 %t123, %t124
  store i1 %t125, ptr %l54, !tbaa !21
  br label %bb29
bb29:
  %t127 = load i1, ptr %l54, !tbaa !21
  br i1 %t127, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb33
bb31:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/scope:Scoper", ptr %t128, i32 0, i32 134
  %t131 = load i64, ptr %l1, !tbaa !24
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t130, i64 %t131)
  store i64 %t134, ptr %l64
  br label %bb32
bb32:
  %t135 = load i64, ptr %l64, !tbaa !24
  %t136 = icmp eq i64 %t135, -2
  store i1 %t136, ptr %l60, !tbaa !21
  br label %bb33
bb33:
  %t138 = load i1, ptr %l60, !tbaa !21
  br i1 %t138, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb37
bb35:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i64, ptr %l1, !tbaa !24
  %t143 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftable(ptr %v0, ptr %t139, i64 %t140)
  store i1 %t143, ptr %l69
  br label %bb36
bb36:
  %t144 = load i1, ptr %l69, !tbaa !21
  %t145 = xor i1 %t144, true
  store i1 %t145, ptr %l66, !tbaa !21
  br label %bb37
bb37:
  %t147 = load i1, ptr %l66, !tbaa !21
  br i1 %t147, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb41
bb39:
  %t148 = load { i64, [2 x i64] }, ptr %l2
  %t150 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t148)
  store i1 %t150, ptr %l73
  br label %bb40
bb40:
  %t151 = load i1, ptr %l73, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l71, !tbaa !21
  br label %bb41
bb41:
  %t154 = load i1, ptr %l71, !tbaa !21
  br i1 %t154, label %bb42, label %bb43
bb42:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/scope:Scoper", ptr %t155, i32 0, i32 148
  %t158 = load i1, ptr %t157, !tbaa !21
  br i1 %t158, label %bb44, label %bb45
bb43:
  br label %bb67
bb44:
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = icmp sge i64 %t160, 0
  store i1 %t162, ptr %l77, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb46
bb46:
  %t164 = load i1, ptr %l77, !tbaa !21
  br i1 %t164, label %bb47, label %bb48
bb47:
  %t165 = load i64, ptr %l1, !tbaa !24
  store i64 %t165, ptr %l81, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/scope:Scoper", ptr %t166, i32 0, i32 134
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t168)
  store i64 %t170, ptr %l84
  br label %bb49
bb48:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb50
bb49:
  %t171 = load i64, ptr %l81, !tbaa !24
  %t172 = load i64, ptr %l84, !tbaa !24
  %t173 = icmp slt i64 %t171, %t172
  store i1 %t173, ptr %l80, !tbaa !21
  br label %bb50
bb50:
  %t175 = load i1, ptr %l80, !tbaa !21
  br i1 %t175, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s6
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/scope:Scoper", ptr %t176, i32 0, i32 163
  store ptr %t178, ptr %l87, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/scope:Scoper", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 0
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/load:Loader", ptr %t185, i32 0, i32 3
  %t188 = load ptr, ptr %t187, !tbaa !29
  store ptr %t188, ptr %l91, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/scope:Scoper", ptr %t189, i32 0, i32 25
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = icmp eq ptr %t192, null
  br i1 %t194, label %bb53, label %bb54
bb52:
  br label %bb66
bb53:
  call void @__olang_check_failed(ptr @olang_loc_56753b57ce5c76c_5bd4f5104db7b168)
  unreachable
bb54:
  br label %bb55
bb55:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/scope:Scoper", ptr %t196, i32 0, i32 25
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Body", ptr %t199, i32 0, i32 7
  %t203 = load i64, ptr %l1, !tbaa !24
  %t206 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t202, i64 %t203)
  store %"compiler/typed:Local" %t206, ptr %l100
  br label %bb56
bb56:
  %t207 = getelementptr %"compiler/typed:Local", ptr %l100, i32 0, i32 0
  %t208 = load i32, ptr %t207, !tbaa !23
  %t209 = load ptr, ptr %l91, !tbaa !29
  %t211 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s6, ptr %t209, i32 %t208)
  store { i64, ptr } %t211, ptr %l102
  br label %bb57
bb57:
  %t212 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t212, ptr %l103
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/scope:Scoper", ptr %t213, i32 0, i32 134
  %t216 = load i64, ptr %l1, !tbaa !24
  %t219 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t215, i64 %t216)
  store i64 %t219, ptr %l107
  br label %bb58
bb58:
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l108, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/scope:Scoper", ptr %t221, i32 0, i32 25
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = icmp eq ptr %t224, null
  br i1 %t226, label %bb59, label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_56753b57ce5c76c_5bd4f5104db7b168)
  unreachable
bb60:
  br label %bb61
bb61:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/scope:Scoper", ptr %t228, i32 0, i32 25
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t234 = getelementptr %"compiler/typed:Body", ptr %t231, i32 0, i32 7
  %t235 = load i64, ptr %l1, !tbaa !24
  %t238 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t234, i64 %t235)
  store %"compiler/typed:Local" %t238, ptr %l117
  br label %bb62
bb62:
  %t239 = getelementptr %"compiler/typed:Local", ptr %l117, i32 0, i32 1
  %t240 = getelementptr %"compiler/source:Span", ptr %t239, i32 0, i32 0
  %t241 = load i32, ptr %t240, !tbaa !23
  %t242 = load ptr, ptr %l108, !tbaa !29
  %t244 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etraceAt(ptr %v0, ptr %s6, ptr %t242, i32 %t241)
  store { i64, ptr } %t244, ptr %l119
  br label %bb63
bb63:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t245 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t246 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t245, i64 %t246)
  %t247 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  call void @__olang_sb_put(ptr %s7, ptr %t248, i64 %t249)
  %t250 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t251 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t250, i64 %t251)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %s7, ptr %l103, i64 0)
  br label %bb64
bb64:
  %t253 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t253, i64 %t254)
  %t255 = load i64, ptr %l107, !tbaa !24
  %t256 = call ptr @__olang_sb_room(ptr %s7, i64 24)
  %t257 = call i64 @__olang_fmt_i64(ptr %t256, i64 %t255)
  call void @__olang_sb_add(ptr %s7, i64 %t257)
  %t258 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t259 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t258, i64 %t259)
  %t260 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  call void @__olang_sb_put(ptr %s7, ptr %t261, i64 %t262)
  %t263 = load ptr, ptr %s7
  %t264 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t265 = load i64, ptr %t264
  %t266 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t265)
  call void @olang_textcopy(ptr %t266, ptr %t263, i64 %t265)
  %t267 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l121, !tbaa !27
  %t269 = getelementptr %olang.builder, ptr %s7, i32 0, i32 3
  %t270 = load ptr, ptr %t269
  %t271 = icmp ne ptr %t270, null
  br i1 %t271, label %sbgrew.272, label %sbdone.273
sbgrew.272:
  call void @__olang_sb_done(ptr %s7)
  br label %sbdone.273
sbdone.273:
  %t274 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  %t276 = extractvalue { i64, ptr } %t274, 1
  %t277 = mul i64 %t275, 1
  %t278 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t277)
  call void @llvm.memcpy.p0.p0.i64(ptr %t278, ptr %t276, i64 %t277, i1 false)
  %t279 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  %t281 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t281, { i64, ptr } %t280)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb67:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/scope:Scoper", ptr %t283, i32 0, i32 26
  %t286 = load i64, ptr %t285, !tbaa !24
  %t287 = load i64, ptr %l1, !tbaa !24
  %t290 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t286, i64 %t287)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t290, ptr %l126
  br label %bb68
bb68:
  %t291 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l126
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t291, ptr %l4
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/scope:Scoper", ptr %t292, i32 0, i32 127
  %t295 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t298 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H568ce559fa980123a387c6ba9ed21aca(ptr %v0, ptr %t294, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t295)
  %t299 = extractvalue { i32, { i64, [2 x i64] } } %t298, 1
  %t300 = extractvalue { i32, { i64, [2 x i64] } } %t298, 0
  store i32 %t300, ptr %l132
  %t301 = icmp ne i32 %t300, 0
  br i1 %t301, label %bb70, label %ok.302, !prof !99
ok.302:
  store { i64, [2 x i64] } %t299, ptr %l131
  br label %bb69
bb69:
  %t303 = load { i64, [2 x i64] }, ptr %l131
  store { i64, [2 x i64] } %t303, ptr %l127
  br label %bb73
bb70:
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/scope:Scoper", ptr %t304, i32 0, i32 31
  %t307 = load i64, ptr %l1, !tbaa !24
  %t310 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t306, i64 %t307)
  store { i64, [2 x i64] } %t310, ptr %l136
  br label %bb72
bb72:
  %t311 = load { i64, [2 x i64] }, ptr %l136
  store { i64, [2 x i64] } %t311, ptr %l127
  br label %bb73
bb73:
  %t312 = load { i64, [2 x i64] }, ptr %l127
  store { i64, [2 x i64] } %t312, ptr %l5
  %t313 = load { i64, [2 x i64] }, ptr %l5
  %t315 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t313)
  store i1 %t315, ptr %l138
  br label %bb74
bb74:
  %t316 = load i1, ptr %l138, !tbaa !21
  br i1 %t316, label %bb75, label %bb76
bb75:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load { i64, [2 x i64] }, ptr %l5
  %t319 = load { i64, [2 x i64] }, ptr %l2
  %t323 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoinTerm(ptr %v0, ptr %t317, { i64, [2 x i64] } %t318, { i64, [2 x i64] } %t319)
  store { i64, [2 x i64] } %t323, ptr %l143
  br label %bb77
bb76:
  %t324 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t324, ptr %l139
  br label %bb78
bb77:
  %t326 = load { i64, [2 x i64] }, ptr %l143
  store { i64, [2 x i64] } %t326, ptr %l139
  br label %bb78
bb78:
  %t327 = load { i64, [2 x i64] }, ptr %l139
  store { i64, [2 x i64] } %t327, ptr %l6
  %t328 = load { i64, [2 x i64] }, ptr %l5
  %t330 = call i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %t328)
  store i1 %t330, ptr %l146
  br label %bb79
bb79:
  %t331 = load i1, ptr %l146, !tbaa !21
  %t332 = xor i1 %t331, true
  br i1 %t332, label %bb80, label %bb81
bb80:
  %t334 = load { i64, [2 x i64] }, ptr %l2
  %t336 = call i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %t334)
  store i1 %t336, ptr %l150
  br label %bb82
bb81:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb83
bb82:
  %t337 = load i1, ptr %l150, !tbaa !21
  %t338 = xor i1 %t337, true
  store i1 %t338, ptr %l148, !tbaa !21
  br label %bb83
bb83:
  %t340 = load i1, ptr %l148, !tbaa !21
  br i1 %t340, label %bb84, label %bb85
bb84:
  %t341 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t341, ptr %l153
  %t342 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t342, ptr %l155
  %t345 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l153, ptr %l155)
  store i1 %t345, ptr %l157
  br label %bb86
bb85:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb87
bb86:
  %t346 = load i1, ptr %l157, !tbaa !21
  %t347 = xor i1 %t346, true
  store i1 %t347, ptr %l152, !tbaa !21
  br label %bb87
bb87:
  %t349 = load i1, ptr %l152, !tbaa !21
  br i1 %t349, label %bb88, label %bb89
bb88:
  %t350 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t350, ptr %l160
  %t351 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t351, ptr %l162
  %t354 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l160, ptr %l162)
  store i1 %t354, ptr %l164
  br label %bb90
bb89:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb91
bb90:
  %t355 = load i1, ptr %l164, !tbaa !21
  store i1 %t355, ptr %l159, !tbaa !21
  br label %bb91
bb91:
  %t356 = load i1, ptr %l159, !tbaa !21
  br i1 %t356, label %bb92, label %bb93
bb92:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load { i64, [2 x i64] }, ptr %l5
  %t359 = load { i64, [2 x i64] }, ptr %l2
  %t363 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t357, { i64, [2 x i64] } %t358, { i64, [2 x i64] } %t359)
  store i64 %t363, ptr %l169
  br label %bb94
bb93:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb95
bb94:
  %t364 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t365 = load i64, ptr %l169, !tbaa !24
  %t367 = icmp ne i64 %t365, %t364
  store i1 %t367, ptr %l165, !tbaa !21
  br label %bb95
bb95:
  %t369 = load i1, ptr %l165, !tbaa !21
  br i1 %t369, label %bb96, label %bb97
bb96:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/scope:Scoper", ptr %t370, i32 0, i32 130
  %t373 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t372, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t373, i1 true)
  br label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb99
bb99:
  %t376 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t376, ptr %l175
  %t377 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t377, ptr %l177
  %t380 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l175, ptr %l177)
  store i1 %t380, ptr %l179
  br label %bb100
bb100:
  %t381 = load i1, ptr %l179, !tbaa !21
  %t382 = xor i1 %t381, true
  store i1 %t382, ptr %l7, !tbaa !21
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l181, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t387 = getelementptr %"compiler/scope:Scoper", ptr %t385, i32 0, i32 25
  %t388 = load ptr, ptr %t387, !tbaa !29
  %t390 = icmp eq ptr %t388, null
  br i1 %t390, label %bb101, label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_14a6577ead1cc721_32dce333731fd63d)
  unreachable
bb102:
  br label %bb103
bb103:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/scope:Scoper", ptr %t392, i32 0, i32 25
  %t395 = load ptr, ptr %t394, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Body", ptr %t395, i32 0, i32 7
  %t399 = load i64, ptr %l1, !tbaa !24
  %t402 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t398, i64 %t399)
  store %"compiler/typed:Local" %t402, ptr %l190
  br label %bb104
bb104:
  %t403 = getelementptr %"compiler/typed:Local", ptr %l190, i32 0, i32 2
  %t404 = load i32, ptr %t403, !tbaa !23
  %t405 = load ptr, ptr %l181, !tbaa !29
  %t407 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t405, i32 %t404)
  store i1 %t407, ptr %l192
  br label %bb105
bb105:
  %t408 = load i1, ptr %l192, !tbaa !21
  br i1 %t408, label %bb106, label %bb107
bb106:
  %t409 = load ptr, ptr %l0, !tbaa !29
  store ptr %t409, ptr %l194, !tbaa !29
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/scope:Scoper", ptr %t410, i32 0, i32 25
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  br i1 %t415, label %bb108, label %bb109
bb107:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb113
bb108:
  call void @__olang_check_failed(ptr @olang_loc_14a6577ead1cc721_32dce333731fd63d)
  unreachable
bb109:
  br label %bb110
bb110:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/scope:Scoper", ptr %t417, i32 0, i32 25
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t423 = getelementptr %"compiler/typed:Body", ptr %t420, i32 0, i32 7
  %t424 = load i64, ptr %l1, !tbaa !24
  %t427 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t423, i64 %t424)
  store %"compiler/typed:Local" %t427, ptr %l203
  br label %bb111
bb111:
  %t428 = getelementptr %"compiler/typed:Local", ptr %l203, i32 0, i32 2
  %t429 = load i32, ptr %t428, !tbaa !23
  %t430 = load ptr, ptr %l194, !tbaa !29
  %t432 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t430, i32 %t429)
  store i1 %t432, ptr %l205
  br label %bb112
bb112:
  %t433 = load i1, ptr %l205, !tbaa !21
  %t434 = xor i1 %t433, true
  store i1 %t434, ptr %l193, !tbaa !21
  br label %bb113
bb113:
  %t436 = load i1, ptr %l193, !tbaa !21
  store i1 %t436, ptr %l8, !tbaa !21
  %t437 = load i1, ptr %l3, !tbaa !21
  br i1 %t437, label %bb114, label %bb115
bb114:
  %t439 = load i1, ptr %l8, !tbaa !21
  br i1 %t439, label %bb116, label %bb117
bb115:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb120
bb116:
  store i1 true, ptr %l210, !tbaa !21
  br label %bb119
bb117:
  %t441 = load { i64, [2 x i64] }, ptr %l6
  %t443 = call i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %t441)
  store i1 %t443, ptr %l212
  br label %bb118
bb118:
  %t444 = load i1, ptr %l212, !tbaa !21
  %t445 = xor i1 %t444, true
  store i1 %t445, ptr %l210, !tbaa !21
  br label %bb119
bb119:
  %t447 = load i1, ptr %l210, !tbaa !21
  store i1 %t447, ptr %l208, !tbaa !21
  br label %bb120
bb120:
  %t448 = load i1, ptr %l208, !tbaa !21
  br i1 %t448, label %bb121, label %bb122
bb121:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/scope:Scoper", ptr %t449, i32 0, i32 129
  %t452 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t455 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t451, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t452)
  store i1 %t455, ptr %l218
  br label %bb123
bb122:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb124
bb123:
  %t456 = load i1, ptr %l218, !tbaa !21
  %t457 = xor i1 %t456, true
  store i1 %t457, ptr %l214, !tbaa !21
  br label %bb124
bb124:
  %t459 = load i1, ptr %l214, !tbaa !21
  br i1 %t459, label %bb125, label %bb126
bb125:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/scope:Scoper", ptr %t460, i32 0, i32 129
  %t463 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t462, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t463, i1 true)
  br label %bb127
bb126:
  br label %bb128
bb127:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb128
bb128:
  %t466 = load i1, ptr %l7, !tbaa !21
  %t468 = xor i1 %t466, true
  br i1 %t468, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb130:
  br label %bb131
bb131:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = getelementptr %"compiler/scope:Scoper", ptr %t470, i32 0, i32 127
  %t473 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t474 = load { i64, [2 x i64] }, ptr %l6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H240bd86caf003ea6de374cb77d0dbfc6(ptr %v0, ptr %t472, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t473, { i64, [2 x i64] } %t474)
  br label %bb132
bb132:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr %"compiler/scope:Scoper", ptr %t478, i32 0, i32 132
  %t481 = load i1, ptr %t480, !tbaa !21
  br i1 %t481, label %bb133, label %bb134
bb133:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t485 = getelementptr %"compiler/scope:Scoper", ptr %t483, i32 0, i32 131
  %t486 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t485, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t486, i1 true)
  br label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb136
bb136:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/scope:Scoper", ptr %t489, i32 0, i32 126
  store i1 true, ptr %t491, !tbaa !21
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = getelementptr %"compiler/scope:Scoper", ptr %t492, i32 0, i32 148
  %t495 = load i1, ptr %t494, !tbaa !21
  br i1 %t495, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s12
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/scope:Scoper", ptr %t497, i32 0, i32 25
  %t500 = load ptr, ptr %t499, !tbaa !29
  %t502 = icmp eq ptr %t500, null
  br i1 %t502, label %bb139, label %bb140
bb138:
  br label %bb153
bb139:
  call void @__olang_check_failed(ptr @olang_loc_5be7cf6889c0719a_fac8d756f0ba6a56)
  unreachable
bb140:
  br label %bb141
bb141:
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t506 = getelementptr %"compiler/scope:Scoper", ptr %t504, i32 0, i32 25
  %t507 = load ptr, ptr %t506, !tbaa !29
  %t510 = getelementptr %"compiler/typed:Body", ptr %t507, i32 0, i32 7
  %t511 = load i64, ptr %l1, !tbaa !24
  %t514 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t510, i64 %t511)
  store %"compiler/typed:Local" %t514, ptr %l245
  br label %bb142
bb142:
  %t515 = load %"compiler/typed:Local", ptr %l245
  store %"compiler/typed:Local" %t515, ptr %l9
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/scope:Scoper", ptr %t516, i32 0, i32 163
  store ptr %t518, ptr %l247, !tbaa !29
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = getelementptr %"compiler/scope:Scoper", ptr %t519, i32 0, i32 0
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t524 = getelementptr %"compiler/generic:Program", ptr %t522, i32 0, i32 0
  %t525 = load ptr, ptr %t524, !tbaa !29
  %t527 = getelementptr %"compiler/load:Loader", ptr %t525, i32 0, i32 3
  %t528 = load ptr, ptr %t527, !tbaa !29
  %t529 = getelementptr %"compiler/typed:Local", ptr %l9, i32 0, i32 0
  %t530 = load i32, ptr %t529, !tbaa !23
  %t533 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s12, ptr %t528, i32 %t530)
  store { i64, ptr } %t533, ptr %l253
  br label %bb143
bb143:
  %t534 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t534, ptr %l254
  %t535 = load i1, ptr %l3, !tbaa !21
  br i1 %t535, label %bb144, label %bb145
bb144:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l256, !tbaa !27
  br label %bb146
bb145:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l256, !tbaa !27
  br label %bb146
bb146:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = getelementptr %"compiler/scope:Scoper", ptr %t537, i32 0, i32 132
  %t540 = load i1, ptr %t539, !tbaa !21
  br i1 %t540, label %bb147, label %bb148
bb147:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l259, !tbaa !27
  br label %bb149
bb148:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l259, !tbaa !27
  br label %bb149
bb149:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = getelementptr %"compiler/typed:Local", ptr %l9, i32 0, i32 1
  %t544 = getelementptr %"compiler/source:Span", ptr %t543, i32 0, i32 0
  %t545 = load i32, ptr %t544, !tbaa !23
  %t548 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etraceAt(ptr %v0, ptr %s12, ptr %t542, i32 %t545)
  store { i64, ptr } %t548, ptr %l262
  br label %bb150
bb150:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s13
  store ptr %s13room, ptr %s13
  %t549 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t550 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t549, i64 %t550)
  %t551 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t551, 1
  %t553 = extractvalue { i64, ptr } %t551, 0
  call void @__olang_sb_put(ptr %s13, ptr %t552, i64 %t553)
  %t554 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t555 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t554, i64 %t555)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %s13, ptr %l254, i64 0)
  br label %bb151
bb151:
  %t557 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t558 = extractvalue { i64, ptr } %t557, 1
  %t559 = extractvalue { i64, ptr } %t557, 0
  call void @__olang_sb_put(ptr %s13, ptr %t558, i64 %t559)
  %t560 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t561 = extractvalue { i64, ptr } %t560, 1
  %t562 = extractvalue { i64, ptr } %t560, 0
  call void @__olang_sb_put(ptr %s13, ptr %t561, i64 %t562)
  %t563 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t564 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t563, i64 %t564)
  %t565 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 1
  %t567 = extractvalue { i64, ptr } %t565, 0
  call void @__olang_sb_put(ptr %s13, ptr %t566, i64 %t567)
  %t568 = load ptr, ptr %s13
  %t569 = getelementptr %olang.builder, ptr %s13, i32 0, i32 1
  %t570 = load i64, ptr %t569
  %t571 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t570)
  call void @olang_textcopy(ptr %t571, ptr %t568, i64 %t570)
  %t572 = insertvalue { i64, ptr } undef, i64 %t570, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t571, 1
  store { i64, ptr } %t573, ptr %l264, !tbaa !27
  %t574 = getelementptr %olang.builder, ptr %s13, i32 0, i32 3
  %t575 = load ptr, ptr %t574
  %t576 = icmp ne ptr %t575, null
  br i1 %t576, label %sbgrew.577, label %sbdone.578
sbgrew.577:
  call void @__olang_sb_done(ptr %s13)
  br label %sbdone.578
sbdone.578:
  %t579 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t580 = extractvalue { i64, ptr } %t579, 0
  %t581 = extractvalue { i64, ptr } %t579, 1
  %t582 = mul i64 %t580, 1
  %t583 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t582)
  call void @llvm.memcpy.p0.p0.i64(ptr %t583, ptr %t581, i64 %t582, i1 false)
  %t584 = insertvalue { i64, ptr } undef, i64 %t580, 0
  %t585 = insertvalue { i64, ptr } %t584, ptr %t583, 1
  %t586 = load ptr, ptr %l247, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t586, { i64, ptr } %t585)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s12)
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftedCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t7)
  store ptr %t8, ptr %l7
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = call ptr @compiler_2ftyped_2eCallOf(ptr %s0, ptr %s0, ptr %t9)
  store ptr %t11, ptr %l9
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l9, !tbaa !29
  store ptr %t12, ptr %l2, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Call", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t28 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esiteLift(ptr %v0, ptr %t19, i64 %t25)
  store { i64, [2 x i64] } %t28, ptr %l18
  br label %bb6
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb6:
  %t29 = load { i64, [2 x i64] }, ptr %l18
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 0
  %t34 = xor i1 %t32, true
  store i1 %t34, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t36 = load i1, ptr %l13, !tbaa !21
  store i1 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l52 = alloca i64
  %l55 = alloca i1
  %l64 = alloca %"compiler/typed:Local"
  %l67 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i32
  %l79 = alloca ptr
  %l81 = alloca i64
  %l84 = alloca i1
  %l93 = alloca %"compiler/typed:Local"
  %l96 = alloca i1
  %l99 = alloca i1
  %l104 = alloca ptr
  %l113 = alloca %"compiler/typed:Local"
  %l115 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i64
  %l118 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca i64
  %l122 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t6 = load ptr, ptr %l16, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb3, label %bb4
bb3:
  %t9 = load ptr, ptr %l16, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l17, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l17, !tbaa !21
  %t14 = xor i1 %t13, true
  store i1 %t14, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t16 = load i1, ptr %l15, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t17, ptr %l22, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l23, !tbaa !24
  %t20 = load i64, ptr %l23, !tbaa !24
  %t21 = mul i64 %t20, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l24, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l23, !tbaa !24
  %t30 = mul i64 %t29, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t26, ptr %t28, i64 %t30, i1 false)
  %t31 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t32, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t35, i32 0, i32 0
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l2
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l3, !tbaa !23
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t53, i32 0, i32 3
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  store ptr %t49, ptr %l6, !tbaa !29
  %t59 = load ptr, ptr %l6, !tbaa !29
  store ptr %t59, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t60 = load ptr, ptr %l34, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb9, label %bb10
bb9:
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 4
  store i1 %t66, ptr %l35, !tbaa !21
  br label %bb10
bb10:
  %t67 = load i1, ptr %l35, !tbaa !21
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t70, ptr %l40, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l41, !tbaa !24
  %t73 = load i64, ptr %l41, !tbaa !24
  %t74 = mul i64 %t73, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l42, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l41, !tbaa !24
  %t83 = mul i64 %t82, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t79, ptr %t81, i64 %t83, i1 false)
  %t84 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t84, ptr %l40, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t85 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t86 = load ptr, ptr %l6, !tbaa !29
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 0
  %t90 = load %"compiler/source:Span", ptr %t89
  store %"compiler/source:Span" %t90, ptr %l7
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t94, i32 0, i32 1
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l8, !tbaa !23
  %t98 = load ptr, ptr %l6, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  %t107 = getelementptr %"compiler/typed:Elem", ptr %t102, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = call i64 @compiler_2fscope_2eflRoot(ptr %v1, ptr %t108)
  store i64 %t110, ptr %l52
  br label %bb14
bb14:
  %t111 = load i64, ptr %l52, !tbaa !24
  store i64 %t111, ptr %l10, !tbaa !24
  store ptr null, ptr %l11, !tbaa !29
  %t112 = load i64, ptr %l10, !tbaa !24
  %t114 = icmp sge i64 %t112, 0
  br i1 %t114, label %bb15, label %bb16
bb15:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/scope:Scoper", ptr %t116, i32 0, i32 25
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  br i1 %t121, label %bb17, label %bb18
bb16:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb21
bb17:
  call void @__olang_check_failed(ptr @olang_loc_6982ea230ce803bc_74efee4e495ae4a0)
  unreachable
bb18:
  br label %bb19
bb19:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 25
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Body", ptr %t126, i32 0, i32 7
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t129, i64 %t130)
  store %"compiler/typed:Local" %t133, ptr %l64
  br label %bb20
bb20:
  %t134 = getelementptr %"compiler/typed:Local", ptr %l64, i32 0, i32 4
  %t135 = load i32, ptr %t134, !range !{i32 0, i32 7}
  %t137 = trunc i64 3 to i32
  %t138 = icmp eq i32 %t135, %t137
  store i1 %t138, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t140 = load i1, ptr %l55, !tbaa !21
  br i1 %t140, label %bb22, label %bb23
bb22:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/scope:Scoper", ptr %t141, i32 0, i32 42
  %t144 = load i64, ptr %l10, !tbaa !24
  %t147 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %s0, ptr %t143, i64 %t144)
  %t148 = extractvalue { i32, ptr } %t147, 1
  %t149 = extractvalue { i32, ptr } %t147, 0
  store i32 %t149, ptr %l72
  %t150 = icmp ne i32 %t149, 0
  br i1 %t150, label %bb25, label %ok.151, !prof !99
ok.151:
  store ptr %t148, ptr %l71
  br label %bb24
bb23:
  br label %bb28
bb24:
  %t152 = load ptr, ptr %l71, !tbaa !29
  store ptr %t152, ptr %l67, !tbaa !29
  br label %bb27
bb25:
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l67, !tbaa !29
  br label %bb27
bb27:
  %t153 = load ptr, ptr %l67, !tbaa !29
  store ptr %t153, ptr %l11, !tbaa !29
  br label %bb28
bb28:
  store i64 -1, ptr %l12, !tbaa !24
  %t154 = load ptr, ptr %l11, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l11, !tbaa !29
  %t165 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %s0, ptr %s4, ptr %t160, ptr %t161)
  store ptr %t165, ptr %l79
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t166 = load ptr, ptr %l79, !tbaa !29
  %t168 = call i64 @compiler_2fscope_2eflRootExpr(ptr %s4, ptr %t166)
  store i64 %t168, ptr %l81
  br label %bb32
bb32:
  %t169 = load i64, ptr %l81, !tbaa !24
  store i64 %t169, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t172 = icmp sge i64 %t170, 0
  br i1 %t172, label %bb34, label %bb35
bb34:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %t174, i32 0, i32 25
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = icmp eq ptr %t177, null
  br i1 %t179, label %bb36, label %bb37
bb35:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb40
bb36:
  call void @__olang_check_failed(ptr @olang_loc_40da86322e01ef2b_70b0fe12089116bf)
  unreachable
bb37:
  br label %bb38
bb38:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/scope:Scoper", ptr %t181, i32 0, i32 25
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t187 = getelementptr %"compiler/typed:Body", ptr %t184, i32 0, i32 7
  %t188 = load i64, ptr %l12, !tbaa !24
  %t191 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t187, i64 %t188)
  store %"compiler/typed:Local" %t191, ptr %l93
  br label %bb39
bb39:
  %t192 = getelementptr %"compiler/typed:Local", ptr %l93, i32 0, i32 4
  %t193 = load i32, ptr %t192, !range !{i32 0, i32 7}
  %t195 = trunc i64 1 to i32
  %t196 = icmp eq i32 %t193, %t195
  store i1 %t196, ptr %l84, !tbaa !21
  br label %bb40
bb40:
  %t198 = load i1, ptr %l84, !tbaa !21
  br i1 %t198, label %bb41, label %bb42
bb41:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i64, ptr %l12, !tbaa !24
  %t203 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %t199, i64 %t200)
  store i1 %t203, ptr %l99
  br label %bb43
bb42:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb44
bb43:
  %t204 = load i1, ptr %l99, !tbaa !21
  %t205 = xor i1 %t204, true
  store i1 %t205, ptr %l96, !tbaa !21
  br label %bb44
bb44:
  %t207 = load i1, ptr %l96, !tbaa !21
  br i1 %t207, label %bb45, label %bb46
bb45:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/scope:Scoper", ptr %t208, i32 0, i32 0
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/load:Loader", ptr %t214, i32 0, i32 3
  %t217 = load ptr, ptr %t216, !tbaa !29
  store ptr %t217, ptr %l104, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/scope:Scoper", ptr %t218, i32 0, i32 25
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = icmp eq ptr %t221, null
  br i1 %t223, label %bb47, label %bb48
bb46:
  br label %bb52
bb47:
  call void @__olang_check_failed(ptr @olang_loc_40da86322e01ef2b_70b0fe12089116bf)
  unreachable
bb48:
  br label %bb49
bb49:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/scope:Scoper", ptr %t225, i32 0, i32 25
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t231 = getelementptr %"compiler/typed:Body", ptr %t228, i32 0, i32 7
  %t232 = load i64, ptr %l12, !tbaa !24
  %t235 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t231, i64 %t232)
  store %"compiler/typed:Local" %t235, ptr %l113
  br label %bb50
bb50:
  %t236 = getelementptr %"compiler/typed:Local", ptr %l113, i32 0, i32 0
  %t237 = load i32, ptr %t236, !tbaa !23
  %t238 = load ptr, ptr %l104, !tbaa !29
  %t240 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v2, ptr %t238, i32 %t237)
  store { i64, ptr } %t240, ptr %l115
  br label %bb51
bb51:
  %t241 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t241, ptr %l116, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  store i64 %t243, ptr %l117, !tbaa !24
  %t244 = load i64, ptr %l117, !tbaa !24
  %t245 = mul i64 %t244, 1
  %t246 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t245)
  %t247 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t246, 1
  store { i64, ptr } %t248, ptr %l118, !tbaa !27
  %t249 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = load i64, ptr %l117, !tbaa !24
  %t254 = mul i64 %t253, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t250, ptr %t252, i64 %t254, i1 false)
  %t255 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t255, ptr %l116, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t256 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t256, ptr %rv
  br label %ret
bb52:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l119, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t257, ptr %l120, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 0
  store i64 %t259, ptr %l121, !tbaa !24
  %t260 = load i64, ptr %l121, !tbaa !24
  %t261 = mul i64 %t260, 1
  %t262 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t261)
  %t263 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t262, 1
  store { i64, ptr } %t264, ptr %l122, !tbaa !27
  %t265 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = load i64, ptr %l121, !tbaa !24
  %t270 = mul i64 %t269, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t266, ptr %t268, i64 %t270, i1 false)
  %t271 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t271, ptr %l120, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t272 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t272, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l19 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i1
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i1
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i64
  %l78 = alloca i1
  %l86 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca i1
  %l102 = alloca i1
  %l103 = alloca i1
  %l108 = alloca { i64, ptr }
  %l113 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t5, 32
  store i1 %t7, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t16 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v1, ptr %t11, ptr %t12)
  store ptr %t16, ptr %l19
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l19, !tbaa !29
  store ptr %t17, ptr %l1, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t20 = load ptr, ptr %l21, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t23 = load ptr, ptr %l21, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 5
  store i1 %t26, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l22, !tbaa !21
  br i1 %t27, label %bb10, label %bb11
bb10:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Promote", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = add i64 %t40, 1
  %t46 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t34, ptr %t38, i64 %t42)
  store i64 %t46, ptr %l33
  br label %bb13
bb13:
  %t47 = load i64, ptr %l33, !tbaa !24
  store i64 %t47, ptr %rv
  br label %ret
bb14:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t49 = load ptr, ptr %l34, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l34, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 2
  store i1 %t55, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t56 = load i1, ptr %l35, !tbaa !21
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l4, !tbaa !29
  br label %bb23
bb18:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t64 = load ptr, ptr %l40, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l40, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 3
  store i1 %t70, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l41, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t80 = load i64, ptr %l2, !tbaa !24
  %t82 = add i64 %t80, 1
  %t86 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadePlace(ptr %v0, ptr %v1, ptr %t78, ptr %t79, i64 %t82)
  store i64 %t86, ptr %l50
  br label %bb24
bb24:
  %t87 = load i64, ptr %l50, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
bb25:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 10
  store i1 %t95, ptr %l52, !tbaa !21
  br label %bb27
bb27:
  %t96 = load i1, ptr %l52, !tbaa !21
  br i1 %t96, label %bb28, label %bb29
bb28:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l5, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Slice", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t108 = load i64, ptr %l2, !tbaa !24
  %t110 = add i64 %t108, 1
  %t114 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadePlace(ptr %v0, ptr %v1, ptr %t103, ptr %t107, i64 %t110)
  store i64 %t114, ptr %l62
  br label %bb31
bb31:
  %t115 = load i64, ptr %l62, !tbaa !24
  store i64 %t115, ptr %rv
  br label %ret
bb32:
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t117 = load ptr, ptr %l63, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb33, label %bb34
bb33:
  %t120 = load ptr, ptr %l63, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 18}
  %t123 = icmp eq i64 %t121, 6
  store i1 %t123, ptr %l64, !tbaa !21
  br label %bb34
bb34:
  %t124 = load i1, ptr %l64, !tbaa !21
  br i1 %t124, label %bb35, label %bb36
bb35:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [5 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t127, i32 0, i32 2
  %t129 = load ptr, ptr %t128
  store ptr %t129, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb47
bb37:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/scope:Scoper", ptr %t131, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  store ptr %t136, ptr %l71, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t141 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t137, ptr %t138)
  store i32 %t141, ptr %l74
  br label %bb38
bb38:
  %t142 = load ptr, ptr %l71, !tbaa !29
  %t143 = load i32, ptr %l74, !tbaa !23
  %t144 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t142, i32 %t143, i64 0)
  store i64 %t144, ptr %l75
  br label %bb39
bb39:
  %t145 = load i64, ptr %l75, !tbaa !24
  store i64 %t145, ptr %l7, !tbaa !24
  %t146 = load i64, ptr %l7, !tbaa !24
  %t148 = icmp sge i64 %t146, 0
  br i1 %t148, label %bb40, label %bb41
bb40:
  %t150 = load i64, ptr %l7, !tbaa !24
  %t151 = load ptr, ptr %l6, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Call", ptr %t151, i32 0, i32 1
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t159 = icmp slt i64 %t150, %t156
  store i1 %t159, ptr %l78, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb42
bb42:
  %t161 = load i1, ptr %l78, !tbaa !21
  br i1 %t161, label %bb43, label %bb44
bb43:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %l6, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Call", ptr %t163, i32 0, i32 1
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %l86, !tbaa !27
  %t167 = load i64, ptr %l7, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr ptr, ptr %t170, i64 %t167
  %t172 = load ptr, ptr %t171, !tbaa !39
  %t174 = load i64, ptr %l2, !tbaa !24
  %t176 = add i64 %t174, 1
  %t180 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t162, ptr %t172, i64 %t176)
  store i64 %t180, ptr %l92
  br label %bb45
bb44:
  br label %bb46
bb45:
  %t181 = load i64, ptr %l92, !tbaa !24
  store i64 %t181, ptr %rv
  br label %ret
bb46:
  br label %bb66
bb47:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t183 = load ptr, ptr %l93, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb48, label %bb49
bb48:
  %t186 = load ptr, ptr %l93, !tbaa !29
  %t187 = load i64, ptr %t186, !range !{i64 0, i64 18}
  %t189 = icmp eq i64 %t187, 9
  store i1 %t189, ptr %l94, !tbaa !21
  br label %bb49
bb49:
  %t190 = load i1, ptr %l94, !tbaa !21
  br i1 %t190, label %bb50, label %bb51
bb50:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [5 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t193, i32 0, i32 2
  %t195 = load i32, ptr %t194, !range !{i32 0, i32 43}
  store i32 %t195, ptr %l8
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t199, i32 0, i32 4
  %t201 = load { i64, ptr }, ptr %t200
  store { i64, ptr } %t201, ptr %l9, !tbaa !27
  br label %bb52
bb51:
  br label %bb61
bb52:
  %t203 = load i32, ptr %l8, !range !{i32 0, i32 43}
  %t205 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t203)
  store i1 %t205, ptr %l102
  br label %bb53
bb53:
  %t206 = load i1, ptr %l102, !tbaa !21
  br i1 %t206, label %bb54, label %bb55
bb54:
  %t207 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t211 = icmp sgt i64 %t209, 0
  store i1 %t211, ptr %l103, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb56
bb56:
  %t213 = load i1, ptr %l103, !tbaa !21
  br i1 %t213, label %bb57, label %bb58
bb57:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t215, ptr %l108, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr ptr, ptr %t217, i64 0
  %t219 = load ptr, ptr %t218, !tbaa !39
  %t221 = load i64, ptr %l2, !tbaa !24
  %t223 = add i64 %t221, 1
  %t227 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t214, ptr %t219, i64 %t223)
  store i64 %t227, ptr %l113
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t228 = load i64, ptr %l113, !tbaa !24
  store i64 %t228, ptr %rv
  br label %ret
bb60:
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_7514114a5d4749ce_60914fcc95b5171a)
  unreachable
bb66:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ematchMadeHere(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l25 = alloca i1
  %l29 = alloca i1
  %l42 = alloca i1
  %l43 = alloca ptr
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Match", ptr %t9, i32 0, i32 1
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb16
bb6:
  br label %bb7
bb7:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  store ptr %t32, ptr %l5, !tbaa !29
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Arm", ptr %t34, i32 0, i32 4
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Arm", ptr %t44, i32 0, i32 4
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t50 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t43, ptr %t47)
  store i1 %t50, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  %t51 = load i1, ptr %l29, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t54 = load i1, ptr %l25, !tbaa !21
  br i1 %t54, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb4
bb16:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Match", ptr %t60, i32 0, i32 2
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bfbb893df1c35f5d_ebb7b8931b043491)
  unreachable
bb18:
  br label %bb19
bb19:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Match", ptr %t67, i32 0, i32 2
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Arm", ptr %t70, i32 0, i32 4
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = icmp eq ptr %t74, null
  br i1 %t76, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb26
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l43, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Match", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  br i1 %t84, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_bfbb893df1c35f5d_ebb7b8931b043491)
  unreachable
bb23:
  br label %bb24
bb24:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Match", ptr %t86, i32 0, i32 2
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Arm", ptr %t89, i32 0, i32 4
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load ptr, ptr %l43, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t94, ptr %t93)
  store i1 %t96, ptr %l51
  br label %bb25
bb25:
  %t97 = load i1, ptr %l51, !tbaa !21
  store i1 %t97, ptr %l42, !tbaa !21
  br label %bb26
bb26:
  %t98 = load i1, ptr %l42, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoBuildTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 64
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i64, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = icmp slt i64 %t16, %t17
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 64
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t22, i64 %t23)
  store i1 %t26, ptr %l16
  br label %bb7
bb6:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb8
bb7:
  %t27 = load i1, ptr %l16, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l12, !tbaa !21
  store i1 %t28, ptr %l3, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_a9ed640346de181b_d10bb16716ed4607)
  unreachable
bb14:
  %t29 = load i1, ptr %l3, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteGenArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, [2 x i64] }
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca ptr
  %l22 = alloca i64
  %l26 = alloca i1
  %l31 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l45 = alloca { i64, [2 x i64] }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l55 = alloca i1
  %l61 = alloca i64
  %l64 = alloca { i64, ptr }
  %l67 = alloca i64
  %t92 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l5
  %t13 = load { i64, [2 x i64] }, ptr %l5
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t21 = getelementptr { i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i64, ptr %t21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t31 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t27, i64 %t22)
  store i64 %t31, ptr %l22
  br label %bb5
bb5:
  %t32 = load i64, ptr %l22, !tbaa !24
  store i64 %t32, ptr %l7, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t36, i64 %t37)
  store i1 %t40, ptr %l26
  br label %bb6
bb6:
  %t41 = load i1, ptr %l26, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenElem(ptr %v0, ptr %t47, i64 %t48)
  store i64 %t51, ptr %l31
  br label %bb10
bb10:
  %t52 = load i64, ptr %l31, !tbaa !24
  store i64 %t52, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = icmp sge i64 %t54, 0
  br i1 %t56, label %bb11, label %bb12
bb11:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp slt i64 %t58, %t61
  store i1 %t64, ptr %l35, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb13
bb13:
  %t66 = load i1, ptr %l35, !tbaa !21
  br i1 %t66, label %bb14, label %bb15
bb14:
  %t67 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t67, ptr %l41, !tbaa !27
  %t68 = load i64, ptr %l8, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr i64, ptr %t71, i64 %t68
  %t73 = load i64, ptr %t72, !tbaa !34
  %t75 = icmp sge i64 %t73, 0
  store i1 %t75, ptr %l40, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l40, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  store { i64, ptr } %a2, ptr %l46, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t79, ptr %l47, !tbaa !27
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i64, ptr %t83, i64 %t80
  %t85 = load i64, ptr %t84, !tbaa !34
  %t87 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr { i64, [2 x i64] }, ptr %t88, i64 %t85
  %t90 = load { i64, [2 x i64] }, ptr %t89
  store { i64, [2 x i64] } %t90, ptr %l45
  br label %bb19
bb18:
  store { i64, [2 x i64] } zeroinitializer, ptr %t92
  %t93 = getelementptr { i64, [2 x i64] }, ptr %t92, i32 0, i32 0
  store i64 0, ptr %t93
  %t94 = load { i64, [2 x i64] }, ptr %t92
  store { i64, [2 x i64] } %t94, ptr %l45
  br label %bb19
bb19:
  %t96 = load { i64, [2 x i64] }, ptr %l45
  %t97 = load ptr, ptr %l32, !tbaa !29
  %t98 = getelementptr %"compiler/scope:Scoper", ptr %t97, i32 0, i32 67
  store { i64, [2 x i64] } %t96, ptr %t98
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l52, !tbaa !29
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sge i64 %t100, 0
  br i1 %t102, label %bb20, label %bb21
bb20:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t105 = load ptr, ptr %l4, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Call", ptr %t105, i32 0, i32 1
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t113 = icmp slt i64 %t104, %t110
  store i1 %t113, ptr %l55, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb22
bb22:
  %t115 = load i1, ptr %l55, !tbaa !21
  br i1 %t115, label %bb23, label %bb24
bb23:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l4, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Call", ptr %t117, i32 0, i32 1
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l64, !tbaa !27
  %t121 = load i64, ptr %l8, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 %t121
  %t126 = load ptr, ptr %t125, !tbaa !39
  %t129 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %v3, ptr %t116, ptr %t126)
  store i64 %t129, ptr %l67
  br label %bb25
bb24:
  store i64 -1, ptr %l61, !tbaa !24
  br label %bb26
bb25:
  %t130 = load i64, ptr %l67, !tbaa !24
  store i64 %t130, ptr %l61, !tbaa !24
  br label %bb26
bb26:
  %t131 = load i64, ptr %l61, !tbaa !24
  %t132 = load ptr, ptr %l52, !tbaa !29
  %t133 = getelementptr %"compiler/scope:Scoper", ptr %t132, i32 0, i32 69
  store i64 %t131, ptr %t133, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMakeWhere(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3, i64 %a4, i64 %a5, { i64, [2 x i64] } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l29 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i64
  %l38 = alloca ptr
  %l47 = alloca %"compiler/typed:Local"
  %l49 = alloca { i64, ptr }
  %l52 = alloca i1
  %l56 = alloca i64
  %l59 = alloca i1
  %l63 = alloca i1
  %l72 = alloca %"compiler/typed:Local"
  %l78 = alloca ptr
  %l87 = alloca %"compiler/typed:Local"
  %l89 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca i64
  %l98 = alloca i64
  %l99 = alloca ptr
  %l108 = alloca %"compiler/typed:Local"
  %l111 = alloca %"compiler/source:Span"
  %l114 = alloca %"compiler/msgs:Msg"
  %l124 = alloca ptr
  %l126 = alloca i64
  %l129 = alloca i1
  %l130 = alloca i1
  %l133 = alloca i1
  %l140 = alloca i1
  %l143 = alloca i1
  %l147 = alloca i1
  %l156 = alloca %"compiler/typed:Local"
  %l159 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i64
  %l169 = alloca i64
  %l170 = alloca %"compiler/source:Span"
  %l172 = alloca %"compiler/msgs:Msg"
  %l173 = alloca ptr
  %l175 = alloca i32
  %l176 = alloca i1
  %l177 = alloca i1
  %l181 = alloca i64
  %l185 = alloca %"compiler/source:Span"
  %l188 = alloca i1
  %l197 = alloca %"compiler/typed:Local"
  %l200 = alloca ptr
  %l204 = alloca ptr
  %l205 = alloca i32
  %l211 = alloca %"compiler/source:Span"
  %l212 = alloca ptr
  %l213 = alloca i64
  %l220 = alloca i64
  %l221 = alloca %"compiler/source:Span"
  %l223 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l18, !tbaa !27
  %t5 = load i64, ptr %l4, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l7, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Call", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l22, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %a5
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l25, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t29 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t24, ptr %t21)
  store ptr %t29, ptr %l29
  br label %bb1
bb1:
  %t30 = load ptr, ptr %l29, !tbaa !29
  %t32 = call i64 @compiler_2fscope_2eflRootExpr(ptr %s0, ptr %t30)
  store i64 %t32, ptr %l31
  br label %bb2
bb2:
  %t33 = load ptr, ptr %l25, !tbaa !29
  %t34 = load i64, ptr %l31, !tbaa !24
  %t35 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eshownLocal(ptr %v0, ptr %t33, i64 %t34, i64 0)
  store i64 %t35, ptr %l32
  br label %bb3
bb3:
  %t36 = load i64, ptr %l32, !tbaa !24
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i64, ptr %l9, !tbaa !24
  %t39 = icmp slt i64 %t37, 0
  br i1 %t39, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 3
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l38, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/scope:Scoper", ptr %t51, i32 0, i32 25
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  br i1 %t56, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3b124163f404c032_f61e7eda275eee66)
  unreachable
bb8:
  br label %bb9
bb9:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 25
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Body", ptr %t61, i32 0, i32 7
  %t65 = load i64, ptr %l9, !tbaa !24
  %t68 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t64, i64 %t65)
  store %"compiler/typed:Local" %t68, ptr %l47
  br label %bb10
bb10:
  %t69 = getelementptr %"compiler/typed:Local", ptr %l47, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t73 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t71, i32 %t70)
  store { i64, ptr } %t73, ptr %l49
  br label %bb11
bb11:
  %t74 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t74, ptr %l10, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t79 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoBuildTerm(ptr %v0, ptr %t75, { i64, [2 x i64] } %a6)
  store i1 %t79, ptr %l52
  br label %bb12
bb12:
  %t80 = load i1, ptr %l52, !tbaa !21
  br i1 %t80, label %bb13, label %bb14
bb13:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l7, !tbaa !29
  %t86 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t81, ptr %t82, i64 0)
  store i64 %t86, ptr %l56
  br label %bb15
bb14:
  br label %bb44
bb15:
  %t87 = load i64, ptr %l56, !tbaa !24
  store i64 %t87, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l11, !tbaa !24
  %t90 = icmp sge i64 %t88, 0
  br i1 %t90, label %bb16, label %bb17
bb16:
  %t92 = load i64, ptr %l11, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp ne i64 %t92, %t93
  store i1 %t96, ptr %l59, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb18
bb18:
  %t98 = load i1, ptr %l59, !tbaa !21
  br i1 %t98, label %bb19, label %bb20
bb19:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/scope:Scoper", ptr %t99, i32 0, i32 25
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb21, label %bb22
bb20:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb25
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4046876e7ea1d159_b2112eb816f2c84d)
  unreachable
bb22:
  br label %bb23
bb23:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/scope:Scoper", ptr %t106, i32 0, i32 25
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Body", ptr %t109, i32 0, i32 7
  %t113 = load i64, ptr %l11, !tbaa !24
  %t116 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t112, i64 %t113)
  store %"compiler/typed:Local" %t116, ptr %l72
  br label %bb24
bb24:
  %t117 = getelementptr %"compiler/typed:Local", ptr %l72, i32 0, i32 0
  %t118 = load i32, ptr %t117, !tbaa !23
  %t120 = icmp ne i32 %t118, 0
  store i1 %t120, ptr %l63, !tbaa !21
  br label %bb25
bb25:
  %t122 = load i1, ptr %l63, !tbaa !21
  br i1 %t122, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 3
  %t132 = load ptr, ptr %t131, !tbaa !29
  store ptr %t132, ptr %l78, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/scope:Scoper", ptr %t133, i32 0, i32 25
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = icmp eq ptr %t136, null
  br i1 %t138, label %bb28, label %bb29
bb27:
  br label %bb43
bb28:
  call void @__olang_check_failed(ptr @olang_loc_79d12197ff1a95a4_7d7576a4aa48dc38)
  unreachable
bb29:
  br label %bb30
bb30:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/scope:Scoper", ptr %t140, i32 0, i32 25
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Body", ptr %t143, i32 0, i32 7
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t146, i64 %t147)
  store %"compiler/typed:Local" %t150, ptr %l87
  br label %bb31
bb31:
  %t151 = getelementptr %"compiler/typed:Local", ptr %l87, i32 0, i32 0
  %t152 = load i32, ptr %t151, !tbaa !23
  %t153 = load ptr, ptr %l78, !tbaa !29
  %t155 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t153, i32 %t152)
  store { i64, ptr } %t155, ptr %l89
  br label %bb32
bb32:
  %t156 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t156, ptr %l12, !tbaa !27
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l90, !tbaa !29
  %t158 = load i64, ptr %l1, !tbaa !24
  store i64 %t158, ptr %l91, !tbaa !24
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/scope:Scoper", ptr %t159, i32 0, i32 25
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = icmp eq ptr %t162, null
  br i1 %t164, label %bb33, label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_2cb2f05c33c43f73_8008e731f94f8857)
  unreachable
bb34:
  br label %bb35
bb35:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/scope:Scoper", ptr %t166, i32 0, i32 25
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Body", ptr %t169, i32 0, i32 3
  %t173 = load i64, ptr %t172, !tbaa !24
  store i64 %t173, ptr %l98, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l99, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/scope:Scoper", ptr %t175, i32 0, i32 25
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = icmp eq ptr %t178, null
  br i1 %t180, label %bb36, label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_2cb2f05c33c43f73_8008e731f94f8857)
  unreachable
bb37:
  br label %bb38
bb38:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/scope:Scoper", ptr %t182, i32 0, i32 25
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Body", ptr %t185, i32 0, i32 7
  %t189 = load i64, ptr %l11, !tbaa !24
  %t192 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t188, i64 %t189)
  store %"compiler/typed:Local" %t192, ptr %l108
  br label %bb39
bb39:
  %t193 = getelementptr %"compiler/typed:Local", ptr %l108, i32 0, i32 1
  %t194 = load %"compiler/source:Span", ptr %t193
  %t195 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t196 = load ptr, ptr %l99, !tbaa !29
  %t199 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v0, ptr %t196, %"compiler/source:Span" %t194, { i64, ptr } %t195)
  store %"compiler/source:Span" %t199, ptr %l111
  br label %bb40
bb40:
  %t200 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t204 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrKeepCopies(ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t200, { i64, ptr } %t201)
  store %"compiler/msgs:Msg" %t204, ptr %l114
  br label %bb41
bb41:
  %t205 = load ptr, ptr %l90, !tbaa !29
  %t206 = load i64, ptr %l91, !tbaa !24
  %t207 = load i64, ptr %l98, !tbaa !24
  %t208 = load %"compiler/source:Span", ptr %l111
  %t209 = load %"compiler/msgs:Msg", ptr %l114
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s3, ptr %t205, i64 %t206, i64 %t207, %"compiler/source:Span" %t208, %"compiler/msgs:Msg" %t209)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb44:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i64, ptr %l1, !tbaa !24
  %t212 = load ptr, ptr %l7, !tbaa !29
  %t214 = load i64, ptr %l9, !tbaa !24
  %t215 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v0, ptr %t210, i64 %t211, ptr %t212, i64 %t214, { i64, ptr } %t215, i64 0)
  br label %bb45
bb45:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l7, !tbaa !29
  %t226 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t221, ptr %t222)
  store ptr %t226, ptr %l124
  br label %bb46
bb46:
  %t227 = load ptr, ptr %l124, !tbaa !29
  %t229 = call i64 @compiler_2fscope_2eflRootExpr(ptr %s0, ptr %t227)
  store i64 %t229, ptr %l126
  br label %bb47
bb47:
  %t230 = load i64, ptr %l126, !tbaa !24
  store i64 %t230, ptr %l13, !tbaa !24
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l3, !tbaa !29
  %t235 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %v1, ptr %t231, ptr %t232)
  store i1 %t235, ptr %l129
  br label %bb48
bb48:
  %t236 = load i1, ptr %l129, !tbaa !21
  br i1 %t236, label %bb49, label %bb50
bb49:
  %t237 = load i64, ptr %l4, !tbaa !24
  %t239 = icmp sgt i64 %t237, 0
  store i1 %t239, ptr %l130, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb51
bb51:
  %t241 = load i1, ptr %l130, !tbaa !21
  br i1 %t241, label %bb52, label %bb53
bb52:
  %t242 = load i64, ptr %l4, !tbaa !24
  %t243 = load ptr, ptr %l3, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Call", ptr %t243, i32 0, i32 1
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 0
  %t250 = sub i64 %t248, 1
  %t253 = icmp slt i64 %t242, %t250
  br i1 %t253, label %bb54, label %bb55
bb53:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb58
bb54:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb57
bb55:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load ptr, ptr %l3, !tbaa !29
  %t259 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetAtCall(ptr %v0, ptr %v1, ptr %t255, ptr %t256)
  store i1 %t259, ptr %l143
  br label %bb56
bb56:
  %t260 = load i1, ptr %l143, !tbaa !21
  %t261 = xor i1 %t260, true
  store i1 %t261, ptr %l140, !tbaa !21
  br label %bb57
bb57:
  %t263 = load i1, ptr %l140, !tbaa !21
  store i1 %t263, ptr %l133, !tbaa !21
  br label %bb58
bb58:
  %t264 = load i1, ptr %l133, !tbaa !21
  store i1 %t264, ptr %l14, !tbaa !21
  %t265 = load i64, ptr %l13, !tbaa !24
  %t267 = icmp sge i64 %t265, 0
  br i1 %t267, label %bb59, label %bb60
bb59:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/scope:Scoper", ptr %t269, i32 0, i32 25
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = icmp eq ptr %t272, null
  br i1 %t274, label %bb61, label %bb62
bb60:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb65
bb61:
  call void @__olang_check_failed(ptr @olang_loc_3be66b99fba73c4e_1215a57d292f746a)
  unreachable
bb62:
  br label %bb63
bb63:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/scope:Scoper", ptr %t276, i32 0, i32 25
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t282 = getelementptr %"compiler/typed:Body", ptr %t279, i32 0, i32 7
  %t283 = load i64, ptr %l13, !tbaa !24
  %t286 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t282, i64 %t283)
  store %"compiler/typed:Local" %t286, ptr %l156
  br label %bb64
bb64:
  %t287 = getelementptr %"compiler/typed:Local", ptr %l156, i32 0, i32 4
  %t288 = load i32, ptr %t287, !range !{i32 0, i32 7}
  %t290 = trunc i64 2 to i32
  %t291 = icmp eq i32 %t288, %t290
  store i1 %t291, ptr %l147, !tbaa !21
  br label %bb65
bb65:
  %t293 = load i1, ptr %l147, !tbaa !21
  br i1 %t293, label %bb66, label %bb67
bb66:
  %t294 = load i1, ptr %l14, !tbaa !21
  store i1 %t294, ptr %l159, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb68
bb68:
  %t296 = load i1, ptr %l159, !tbaa !21
  br i1 %t296, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s4
  %t297 = load ptr, ptr %l0, !tbaa !29
  store ptr %t297, ptr %l161, !tbaa !29
  %t298 = load i64, ptr %l1, !tbaa !24
  store i64 %t298, ptr %l162, !tbaa !24
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/scope:Scoper", ptr %t299, i32 0, i32 25
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = icmp eq ptr %t302, null
  br i1 %t304, label %bb71, label %bb72
bb70:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l173, !tbaa !29
  %t307 = load ptr, ptr %l7, !tbaa !29
  %t309 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t307)
  store i32 %t309, ptr %l175
  br label %bb76
bb71:
  call void @__olang_check_failed(ptr @olang_loc_9cb83d16c8558bf5_7c19eecf9e07b071)
  unreachable
bb72:
  br label %bb73
bb73:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/scope:Scoper", ptr %t310, i32 0, i32 25
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t316 = getelementptr %"compiler/typed:Body", ptr %t313, i32 0, i32 3
  %t317 = load i64, ptr %t316, !tbaa !24
  store i64 %t317, ptr %l169, !tbaa !24
  store %"compiler/source:Span" %a2, ptr %l170
  %t319 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t321 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHeldIndexWhere(ptr %v0, ptr %s4, { i64, ptr } %t319)
  store %"compiler/msgs:Msg" %t321, ptr %l172
  br label %bb74
bb74:
  %t322 = load ptr, ptr %l161, !tbaa !29
  %t323 = load i64, ptr %l162, !tbaa !24
  %t324 = load i64, ptr %l169, !tbaa !24
  %t325 = load %"compiler/source:Span", ptr %l170
  %t326 = load %"compiler/msgs:Msg", ptr %l172
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s4, ptr %t322, i64 %t323, i64 %t324, %"compiler/source:Span" %t325, %"compiler/msgs:Msg" %t326)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s4)
  br label %bb109
bb76:
  %t327 = load ptr, ptr %l173, !tbaa !29
  %t328 = load i32, ptr %l175, !tbaa !23
  %t329 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisText(ptr %v0, ptr %t327, i32 %t328)
  store i1 %t329, ptr %l176
  br label %bb77
bb77:
  %t330 = load i1, ptr %l176, !tbaa !21
  br i1 %t330, label %bb78, label %bb79
bb78:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l7, !tbaa !29
  %t336 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t331, ptr %t332, i64 0)
  store i64 %t336, ptr %l181
  br label %bb80
bb79:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb81
bb80:
  %t337 = load i64, ptr %l181, !tbaa !24
  %t338 = icmp sge i64 %t337, 0
  store i1 %t338, ptr %l177, !tbaa !21
  br label %bb81
bb81:
  %t340 = load i1, ptr %l177, !tbaa !21
  br i1 %t340, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s6
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load ptr, ptr %l7, !tbaa !29
  %t345 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v1, ptr %t341, ptr %t342)
  store %"compiler/source:Span" %t345, ptr %l185
  br label %bb84
bb83:
  br label %bb108
bb84:
  %t346 = load %"compiler/source:Span", ptr %l185
  store %"compiler/source:Span" %t346, ptr %l15
  %t347 = load i64, ptr %l13, !tbaa !24
  %t349 = icmp sge i64 %t347, 0
  br i1 %t349, label %bb85, label %bb86
bb85:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/scope:Scoper", ptr %t351, i32 0, i32 25
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t356 = icmp eq ptr %t354, null
  br i1 %t356, label %bb87, label %bb88
bb86:
  store i1 false, ptr %l188, !tbaa !21
  br label %bb91
bb87:
  call void @__olang_check_failed(ptr @olang_loc_98ba305d5e2403e0_d6869d4c9e18247c)
  unreachable
bb88:
  br label %bb89
bb89:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/scope:Scoper", ptr %t358, i32 0, i32 25
  %t361 = load ptr, ptr %t360, !tbaa !29
  %t364 = getelementptr %"compiler/typed:Body", ptr %t361, i32 0, i32 7
  %t365 = load i64, ptr %l13, !tbaa !24
  %t368 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t364, i64 %t365)
  store %"compiler/typed:Local" %t368, ptr %l197
  br label %bb90
bb90:
  %t369 = getelementptr %"compiler/typed:Local", ptr %l197, i32 0, i32 4
  %t370 = load i32, ptr %t369, !range !{i32 0, i32 7}
  %t372 = trunc i64 2 to i32
  %t373 = icmp eq i32 %t370, %t372
  store i1 %t373, ptr %l188, !tbaa !21
  br label %bb91
bb91:
  %t375 = load i1, ptr %l188, !tbaa !21
  br i1 %t375, label %bb92, label %bb93
bb92:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/scope:Scoper", ptr %t376, i32 0, i32 42
  %t379 = load i64, ptr %l13, !tbaa !24
  %t382 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t378, i64 %t379)
  %t383 = extractvalue { i32, ptr } %t382, 1
  %t384 = extractvalue { i32, ptr } %t382, 0
  store i32 %t384, ptr %l205
  %t385 = icmp ne i32 %t384, 0
  br i1 %t385, label %bb95, label %ok.386, !prof !99
ok.386:
  store ptr %t383, ptr %l204
  br label %bb94
bb93:
  br label %bb102
bb94:
  %t387 = load ptr, ptr %l204, !tbaa !29
  store ptr %t387, ptr %l200, !tbaa !29
  br label %bb97
bb95:
  br label %bb96
bb96:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l200, !tbaa !29
  br label %bb97
bb97:
  %t388 = load ptr, ptr %l200, !tbaa !29
  store ptr %t388, ptr %l16, !tbaa !29
  %t389 = load ptr, ptr %l16, !tbaa !29
  %t391 = icmp eq ptr %t389, null
  %t393 = xor i1 %t391, true
  br i1 %t393, label %bb98, label %bb99
bb98:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l16, !tbaa !29
  %t399 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v0, ptr %t395, ptr %t396)
  store %"compiler/source:Span" %t399, ptr %l211
  br label %bb100
bb99:
  br label %bb101
bb100:
  %t400 = load %"compiler/source:Span", ptr %l211
  store %"compiler/source:Span" %t400, ptr %l15
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t401 = load ptr, ptr %l0, !tbaa !29
  store ptr %t401, ptr %l212, !tbaa !29
  %t402 = load i64, ptr %l1, !tbaa !24
  store i64 %t402, ptr %l213, !tbaa !24
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/scope:Scoper", ptr %t403, i32 0, i32 25
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t408 = icmp eq ptr %t406, null
  br i1 %t408, label %bb103, label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_37fd0ede1d7e00ff_4f25c812a3c753eb)
  unreachable
bb104:
  br label %bb105
bb105:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/scope:Scoper", ptr %t410, i32 0, i32 25
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t416 = getelementptr %"compiler/typed:Body", ptr %t413, i32 0, i32 3
  %t417 = load i64, ptr %t416, !tbaa !24
  store i64 %t417, ptr %l220, !tbaa !24
  %t418 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t418, ptr %l221
  %t419 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t421 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteTextCopyWhere(ptr %v0, ptr %s6, { i64, ptr } %t419)
  store %"compiler/msgs:Msg" %t421, ptr %l223
  br label %bb106
bb106:
  %t422 = load ptr, ptr %l212, !tbaa !29
  %t423 = load i64, ptr %l213, !tbaa !24
  %t424 = load i64, ptr %l220, !tbaa !24
  %t425 = load %"compiler/source:Span", ptr %l221
  %t426 = load %"compiler/msgs:Msg", ptr %l223
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s6, ptr %t422, i64 %t423, i64 %t424, %"compiler/source:Span" %t425, %"compiler/msgs:Msg" %t426)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s6)
  br label %bb108
bb108:
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteRefill(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/typed:Local"
  %l12 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l21 = alloca ptr
  %l30 = alloca %"compiler/typed:Local"
  %l32 = alloca { i64, ptr }
  %l42 = alloca i64
  %l45 = alloca i1
  %l49 = alloca i1
  %l58 = alloca %"compiler/typed:Local"
  %l62 = alloca i32
  %l65 = alloca i1
  %l66 = alloca i32
  %l71 = alloca i32
  %l74 = alloca ptr
  %l75 = alloca i32
  %l80 = alloca i32
  %l81 = alloca i64
  %l83 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca i32
  %l96 = alloca %"compiler/source:Span"
  %l102 = alloca i1
  %l114 = alloca %"compiler/typed:Local"
  %l115 = alloca ptr
  %l116 = alloca i64
  %l123 = alloca i64
  %l124 = alloca ptr
  %l125 = alloca %"compiler/source:Span"
  %l131 = alloca { i64, ptr }
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca { i64, ptr }
  %l135 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i64
  %l144 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i64 @compiler_2fscope_2eflRoot(ptr %v1, ptr %t2)
  store i64 %t4, ptr %l14
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %l14, !tbaa !24
  %t7 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eshownLocal(ptr %v0, ptr %t5, i64 %t6, i64 0)
  store i64 %t7, ptr %l15
  br label %bb2
bb2:
  %t8 = load i64, ptr %l15, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/scope:Scoper", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/load:Loader", ptr %t19, i32 0, i32 3
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l21, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t23, i32 0, i32 25
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d1e09ab5654512c3_1949347ac845fe07)
  unreachable
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 25
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 7
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t36, i64 %t37)
  store %"compiler/typed:Local" %t40, ptr %l30
  br label %bb9
bb9:
  %t41 = getelementptr %"compiler/typed:Local", ptr %l30, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t45 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t43, i32 %t42)
  store { i64, ptr } %t45, ptr %l32
  br label %bb10
bb10:
  %t46 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t46, ptr %l5, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i64, ptr %l1, !tbaa !24
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v2, ptr %v0, ptr %t47, i64 %t48, ptr %t49, i64 %t51, { i64, ptr } %t52, i64 0)
  br label %bb11
bb11:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t63 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v2, ptr %t58, ptr %t59, i64 0)
  store i64 %t63, ptr %l42
  br label %bb12
bb12:
  %t64 = load i64, ptr %l42, !tbaa !24
  store i64 %t64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = icmp slt i64 %t65, 0
  br i1 %t67, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb15
bb14:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l4, !tbaa !24
  %t73 = icmp eq i64 %t69, %t70
  store i1 %t73, ptr %l45, !tbaa !21
  br label %bb15
bb15:
  %t75 = load i1, ptr %l45, !tbaa !21
  br i1 %t75, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb22
bb17:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/scope:Scoper", ptr %t76, i32 0, i32 25
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = icmp eq ptr %t79, null
  br i1 %t81, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9ec3c43f0dea0d34_4e7830eaf7e3a0e8)
  unreachable
bb19:
  br label %bb20
bb20:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 25
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Body", ptr %t86, i32 0, i32 7
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t89, i64 %t90)
  store %"compiler/typed:Local" %t93, ptr %l58
  br label %bb21
bb21:
  %t94 = getelementptr %"compiler/typed:Local", ptr %l58, i32 0, i32 0
  %t95 = load i32, ptr %t94, !tbaa !23
  %t97 = icmp eq i32 %t95, 0
  store i1 %t97, ptr %l49, !tbaa !21
  br label %bb22
bb22:
  %t99 = load i1, ptr %l49, !tbaa !21
  br i1 %t99, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  br label %bb25
bb25:
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t102 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t100)
  store i32 %t102, ptr %l62
  br label %bb26
bb26:
  %t103 = load i32, ptr %l62, !tbaa !23
  store i32 %t103, ptr %l7, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l7, !tbaa !23
  %t108 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t104, i32 %t105)
  store i1 %t108, ptr %l65
  br label %bb27
bb27:
  %t109 = load i1, ptr %l65, !tbaa !21
  br i1 %t109, label %bb28, label %bb29
bb28:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l7, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l71
  br label %bb30
bb29:
  %t120 = load i32, ptr %l7, !tbaa !23
  store i32 %t120, ptr %l66, !tbaa !23
  br label %bb31
bb30:
  %t122 = load i32, ptr %l71, !tbaa !23
  store i32 %t122, ptr %l66, !tbaa !23
  br label %bb31
bb31:
  %t123 = load i32, ptr %l66, !tbaa !23
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/scope:Scoper", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  store ptr %t127, ptr %l74, !tbaa !29
  store i32 %t123, ptr %l75, !tbaa !23
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/scope:Scoper", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 0
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/load:Loader", ptr %t135, i32 0, i32 3
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t138, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i32 %t140, ptr %l80
  br label %bb32
bb32:
  %t141 = load ptr, ptr %l74, !tbaa !29
  %t142 = load i32, ptr %l75, !tbaa !23
  %t143 = load i32, ptr %l80, !tbaa !23
  %t144 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t141, i32 %t142, i32 %t143)
  store i64 %t144, ptr %l81
  br label %bb33
bb33:
  %t145 = load i64, ptr %l81, !tbaa !24
  %t146 = icmp slt i64 %t145, 0
  br i1 %t146, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb35:
  br label %bb36
bb36:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/scope:Scoper", ptr %t148, i32 0, i32 10
  store ptr %t150, ptr %l85, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/scope:Scoper", ptr %t151, i32 0, i32 25
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  br i1 %t156, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_60a9277e2c5e0f29_25801f0e1d4bc5bd)
  unreachable
bb38:
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/scope:Scoper", ptr %t158, i32 0, i32 25
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Body", ptr %t161, i32 0, i32 3
  %t165 = load i64, ptr %t164, !tbaa !24
  %t166 = load ptr, ptr %l85, !tbaa !29
  %t168 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t166, i64 %t165)
  %t169 = extractvalue { i32, { i64, ptr } } %t168, 1
  %t170 = extractvalue { i32, { i64, ptr } } %t168, 0
  store i32 %t170, ptr %l94
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb41, label %ok.172, !prof !99
ok.172:
  store { i64, ptr } %t169, ptr %l93
  br label %bb40
bb40:
  %t173 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t173, ptr %l83, !tbaa !27
  br label %bb43
bb41:
  br label %bb42
bb42:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l83, !tbaa !27
  br label %bb43
bb43:
  %t174 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t174, ptr %l9, !tbaa !27
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t177 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t175)
  store %"compiler/source:Span" %t177, ptr %l96
  br label %bb44
bb44:
  %t178 = load %"compiler/source:Span", ptr %l96
  store %"compiler/source:Span" %t178, ptr %l10
  %t179 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 1
  %t180 = load i32, ptr %t179, !tbaa !23
  %t182 = sext i32 %t180 to i64
  %t183 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t188 = icmp sgt i64 %t182, %t185
  br i1 %t188, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb47
bb46:
  %t190 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t191 = load i32, ptr %t190, !tbaa !23
  %t192 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 1
  %t193 = load i32, ptr %t192, !tbaa !23
  %t196 = icmp sge i32 %t191, %t193
  store i1 %t196, ptr %l102, !tbaa !21
  br label %bb47
bb47:
  %t198 = load i1, ptr %l102, !tbaa !21
  br i1 %t198, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  br label %bb50
bb50:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/scope:Scoper", ptr %t199, i32 0, i32 25
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = icmp eq ptr %t202, null
  br i1 %t204, label %bb51, label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_32a2617be6fc2342_ed6c13319ae659d6)
  unreachable
bb52:
  br label %bb53
bb53:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/scope:Scoper", ptr %t206, i32 0, i32 25
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t212 = getelementptr %"compiler/typed:Body", ptr %t209, i32 0, i32 7
  %t213 = load i64, ptr %l6, !tbaa !24
  %t216 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t212, i64 %t213)
  store %"compiler/typed:Local" %t216, ptr %l114
  br label %bb54
bb54:
  %t217 = load %"compiler/typed:Local", ptr %l114
  store %"compiler/typed:Local" %t217, ptr %l11
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l115, !tbaa !29
  %t219 = load i64, ptr %l1, !tbaa !24
  store i64 %t219, ptr %l116, !tbaa !24
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/scope:Scoper", ptr %t220, i32 0, i32 25
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = icmp eq ptr %t223, null
  br i1 %t225, label %bb55, label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_466c52b9c16c208f_a374cdad5045efdb)
  unreachable
bb56:
  br label %bb57
bb57:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/scope:Scoper", ptr %t227, i32 0, i32 25
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t233 = getelementptr %"compiler/typed:Body", ptr %t230, i32 0, i32 3
  %t234 = load i64, ptr %t233, !tbaa !24
  store i64 %t234, ptr %l123, !tbaa !24
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l124, !tbaa !29
  %t236 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t237 = load %"compiler/source:Span", ptr %t236
  store %"compiler/source:Span" %t237, ptr %l125
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/scope:Scoper", ptr %t238, i32 0, i32 0
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = getelementptr %"compiler/generic:Program", ptr %t241, i32 0, i32 0
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = getelementptr %"compiler/load:Loader", ptr %t244, i32 0, i32 3
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t248 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 0
  %t249 = load i32, ptr %t248, !tbaa !23
  %t252 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t247, i32 %t249)
  store { i64, ptr } %t252, ptr %l131
  br label %bb58
bb58:
  %t253 = load ptr, ptr %l124, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l125
  %t255 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t256 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v0, ptr %t253, %"compiler/source:Span" %t254, { i64, ptr } %t255)
  store %"compiler/source:Span" %t256, ptr %l132
  br label %bb59
bb59:
  %t257 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t257, ptr %l133, !tbaa !27
  %t258 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t259 = load i32, ptr %t258, !tbaa !23
  %t261 = sext i32 %t259 to i64
  store i64 %t261, ptr %l135, !tbaa !24
  %t262 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 1
  %t263 = load i32, ptr %t262, !tbaa !23
  %t265 = sext i32 %t263 to i64
  store i64 %t265, ptr %l137, !tbaa !24
  %t266 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 0
  store i64 %t267, ptr %l138, !tbaa !24
  %t268 = load i64, ptr %l135, !tbaa !24
  %t269 = icmp sge i64 %t268, 0
  br i1 %t269, label %bb60, label %bb61
bb60:
  %t271 = load i64, ptr %l135, !tbaa !24
  %t272 = load i64, ptr %l137, !tbaa !24
  %t273 = icmp sle i64 %t271, %t272
  br i1 %t273, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_f99d36ce04cd5358_3c9954da82c615c4)
  unreachable
bb62:
  %t275 = load i64, ptr %l137, !tbaa !24
  %t276 = load i64, ptr %l138, !tbaa !24
  %t277 = icmp sle i64 %t275, %t276
  br i1 %t277, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_f99d36ce04cd5358_3c9954da82c615c4)
  unreachable
bb64:
  %t279 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = load i64, ptr %l135, !tbaa !24
  %t282 = load i64, ptr %l137, !tbaa !24
  %t283 = getelementptr i8, ptr %t280, i64 %t281
  %t284 = sub i64 %t282, %t281
  %t285 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t283, 1
  %t287 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t290 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteRefillKept(ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t286, { i64, ptr } %t287)
  store %"compiler/msgs:Msg" %t290, ptr %l144
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_f99d36ce04cd5358_3c9954da82c615c4)
  unreachable
bb66:
  %t291 = load ptr, ptr %l115, !tbaa !29
  %t292 = load i64, ptr %l116, !tbaa !24
  %t293 = load i64, ptr %l123, !tbaa !24
  %t294 = load %"compiler/source:Span", ptr %l132
  %t295 = load %"compiler/msgs:Msg", ptr %l144
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s0, ptr %t291, i64 %t292, i64 %t293, %"compiler/source:Span" %t294, %"compiler/msgs:Msg" %t295)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l42 = alloca i1
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca ptr
  %l54 = alloca i1
  %l61 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca ptr
  %l73 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l96 = alloca i1
  %l101 = alloca %"compiler/source:Span"
  %l102 = alloca ptr
  %l103 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca i1
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca ptr
  %l126 = alloca i64
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca %"compiler/source:Span"
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l15
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l15, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t9 = load ptr, ptr %l16, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l16, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 5
  store i1 %t15, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l17, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Promote", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t30 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  store %"compiler/source:Span" %t30, ptr %l25
  br label %bb7
bb7:
  %t31 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t31, ptr %rv
  br label %ret
bb8:
  %t32 = load ptr, ptr %l2, !tbaa !29
  store ptr %t32, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t33 = load ptr, ptr %l26, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l26, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 18}
  %t39 = icmp eq i64 %t37, 6
  store i1 %t39, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l27, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 0
  %t45 = load %"compiler/source:Span", ptr %t44
  store %"compiler/source:Span" %t45, ptr %l4
  br label %bb17
bb12:
  %t47 = load ptr, ptr %l2, !tbaa !29
  store ptr %t47, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t48 = load ptr, ptr %l32, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load ptr, ptr %l32, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 18}
  %t54 = icmp eq i64 %t52, 7
  store i1 %t54, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 0
  %t60 = load %"compiler/source:Span", ptr %t59
  store %"compiler/source:Span" %t60, ptr %l4
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l4
  %t66 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t62, %"compiler/source:Span" %t63)
  store %"compiler/source:Span" %t66, ptr %l40
  br label %bb18
bb18:
  %t67 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t67, ptr %rv
  br label %ret
bb19:
  %t68 = load ptr, ptr %l2, !tbaa !29
  store ptr %t68, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t69 = load ptr, ptr %l41, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load ptr, ptr %l41, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 18}
  %t75 = icmp eq i64 %t73, 10
  store i1 %t75, ptr %l42, !tbaa !21
  br label %bb21
bb21:
  %t76 = load i1, ptr %l42, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t79, i32 0, i32 0
  %t81 = load %"compiler/source:Span", ptr %t80
  store %"compiler/source:Span" %t81, ptr %l5
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l6, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l5
  %t91 = load ptr, ptr %l6, !tbaa !29
  %t95 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esliceAt(ptr %v0, ptr %v1, ptr %t89, %"compiler/source:Span" %t90, ptr %t91)
  store %"compiler/source:Span" %t95, ptr %l52
  br label %bb25
bb25:
  %t96 = load %"compiler/source:Span", ptr %l52
  store %"compiler/source:Span" %t96, ptr %rv
  br label %ret
bb26:
  %t97 = load ptr, ptr %l2, !tbaa !29
  store ptr %t97, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t98 = load ptr, ptr %l53, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb27, label %bb28
bb27:
  %t101 = load ptr, ptr %l53, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 18}
  %t104 = icmp eq i64 %t102, 11
  store i1 %t104, ptr %l54, !tbaa !21
  br label %bb28
bb28:
  %t105 = load i1, ptr %l54, !tbaa !21
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 0
  %t110 = load %"compiler/source:Span", ptr %t109
  store %"compiler/source:Span" %t110, ptr %l7
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t114, i32 0, i32 2
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l8, !tbaa !29
  br label %bb31
bb30:
  br label %bb38
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l61, !tbaa !29
  %t119 = load ptr, ptr %l8, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Cond", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  br i1 %t124, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8680c8bf7a40147c_d650a7d3d4e83170)
  unreachable
bb33:
  br label %bb34
bb34:
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Cond", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t129)
  store %"compiler/source:Span" %t131, ptr %l67
  br label %bb35
bb35:
  %t132 = getelementptr %"compiler/source:Span", ptr %l67, i32 0, i32 1
  %t133 = load i32, ptr %t132, !tbaa !23
  %t134 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t135 = load i32, ptr %t134, !tbaa !23
  %t138 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t133, i32 %t135)
  store %"compiler/source:Span" %t138, ptr %l70
  br label %bb36
bb36:
  %t139 = load ptr, ptr %l61, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l70
  %t141 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %s4, ptr %t139, %"compiler/source:Span" %t140, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store %"compiler/source:Span" %t141, ptr %l71
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  %t142 = load %"compiler/source:Span", ptr %l71
  store %"compiler/source:Span" %t142, ptr %rv
  br label %ret
bb38:
  %t143 = load ptr, ptr %l2, !tbaa !29
  store ptr %t143, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t144 = load ptr, ptr %l72, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb39, label %bb40
bb39:
  %t147 = load ptr, ptr %l72, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 18}
  %t150 = icmp eq i64 %t148, 2
  store i1 %t150, ptr %l73, !tbaa !21
  br label %bb40
bb40:
  %t151 = load i1, ptr %l73, !tbaa !21
  br i1 %t151, label %bb41, label %bb42
bb41:
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t154, i32 0, i32 0
  %t156 = load %"compiler/source:Span", ptr %t155
  store %"compiler/source:Span" %t156, ptr %l9
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t160, i32 0, i32 2
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l10, !tbaa !29
  br label %bb47
bb42:
  %t164 = load ptr, ptr %l2, !tbaa !29
  store ptr %t164, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t165 = load ptr, ptr %l80, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb43, label %bb44
bb43:
  %t168 = load ptr, ptr %l80, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 18}
  %t171 = icmp eq i64 %t169, 3
  store i1 %t171, ptr %l81, !tbaa !21
  br label %bb44
bb44:
  %t172 = load i1, ptr %l81, !tbaa !21
  br i1 %t172, label %bb45, label %bb46
bb45:
  %t173 = load ptr, ptr %l2, !tbaa !29
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t175, i32 0, i32 0
  %t177 = load %"compiler/source:Span", ptr %t176
  store %"compiler/source:Span" %t177, ptr %l9
  %t179 = load ptr, ptr %l2, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 2
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb80
bb47:
  %t185 = load ptr, ptr %l10, !tbaa !29
  store ptr %t185, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t186 = load ptr, ptr %l88, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb48, label %bb49
bb48:
  %t189 = load ptr, ptr %l88, !tbaa !29
  %t190 = load i64, ptr %t189, !range !{i64 0, i64 8}
  %t192 = icmp eq i64 %t190, 3
  store i1 %t192, ptr %l89, !tbaa !21
  br label %bb49
bb49:
  %t193 = load i1, ptr %l89, !tbaa !21
  br i1 %t193, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l9
  %t198 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t194, %"compiler/source:Span" %t195)
  store %"compiler/source:Span" %t198, ptr %l94
  br label %bb53
bb53:
  %t199 = load %"compiler/source:Span", ptr %l94
  store %"compiler/source:Span" %t199, ptr %rv
  br label %ret
bb54:
  %t200 = load ptr, ptr %l10, !tbaa !29
  store ptr %t200, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t201 = load ptr, ptr %l95, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb55, label %bb56
bb55:
  %t204 = load ptr, ptr %l95, !tbaa !29
  %t205 = load i64, ptr %t204, !range !{i64 0, i64 8}
  %t207 = icmp eq i64 %t205, 4
  store i1 %t207, ptr %l96, !tbaa !21
  br label %bb56
bb56:
  %t208 = load i1, ptr %l96, !tbaa !21
  br i1 %t208, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l9
  %t213 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastBracket(ptr %v0, ptr %t209, %"compiler/source:Span" %t210)
  store %"compiler/source:Span" %t213, ptr %l101
  br label %bb60
bb60:
  %t214 = load %"compiler/source:Span", ptr %l101
  store %"compiler/source:Span" %t214, ptr %rv
  br label %ret
bb61:
  %t215 = load ptr, ptr %l10, !tbaa !29
  store ptr %t215, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t216 = load ptr, ptr %l102, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb62, label %bb63
bb62:
  %t219 = load ptr, ptr %l102, !tbaa !29
  %t220 = load i64, ptr %t219, !range !{i64 0, i64 8}
  %t222 = icmp eq i64 %t220, 2
  store i1 %t222, ptr %l103, !tbaa !21
  br label %bb63
bb63:
  %t223 = load i1, ptr %l103, !tbaa !21
  br i1 %t223, label %bb64, label %bb65
bb64:
  %t224 = load ptr, ptr %l10, !tbaa !29
  %t226 = getelementptr { i64, [4 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t226, i32 0, i32 2
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l11, !tbaa !29
  br label %bb66
bb65:
  br label %bb74
bb66:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l11, !tbaa !29
  %t235 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v1, ptr %t230, ptr %t231)
  store ptr %t235, ptr %l111
  br label %bb67
bb67:
  %t236 = load ptr, ptr %l111, !tbaa !29
  store ptr %t236, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t237 = load ptr, ptr %l112, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb68, label %bb69
bb68:
  %t240 = load ptr, ptr %l112, !tbaa !29
  %t241 = load i64, ptr %t240, !range !{i64 0, i64 18}
  %t243 = icmp eq i64 %t241, 10
  store i1 %t243, ptr %l113, !tbaa !21
  br label %bb69
bb69:
  %t244 = load i1, ptr %l113, !tbaa !21
  br i1 %t244, label %bb70, label %bb71
bb70:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l11, !tbaa !29
  %t249 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t245, ptr %t246)
  store %"compiler/source:Span" %t249, ptr %l118
  br label %bb72
bb71:
  br label %bb73
bb72:
  %t250 = load %"compiler/source:Span", ptr %l118
  store %"compiler/source:Span" %t250, ptr %rv
  br label %ret
bb73:
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_22d8393d4f188012_8c9f9e39cb427896)
  unreachable
bb79:
  br label %bb85
bb80:
  br i1 true, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_7213214fb222d0c9_1eae7674ed2401ad)
  unreachable
bb85:
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l119, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/scope:Scoper", ptr %t252, i32 0, i32 25
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = icmp eq ptr %t255, null
  br i1 %t257, label %bb86, label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_2c141a427a2fa071_f343db408d9fc8c5)
  unreachable
bb87:
  br label %bb88
bb88:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/scope:Scoper", ptr %t259, i32 0, i32 25
  %t262 = load ptr, ptr %t261, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Body", ptr %t262, i32 0, i32 3
  %t266 = load i64, ptr %t265, !tbaa !24
  store i64 %t266, ptr %l126, !tbaa !24
  %t267 = load ptr, ptr %l2, !tbaa !29
  %t269 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t267)
  store %"compiler/source:Span" %t269, ptr %l128
  br label %bb89
bb89:
  %t270 = load ptr, ptr %l119, !tbaa !29
  %t271 = load i64, ptr %l126, !tbaa !24
  %t272 = load %"compiler/source:Span", ptr %l128
  %t273 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t270, i64 %t271, %"compiler/source:Span" %t272)
  store %"compiler/source:Span" %t273, ptr %l129
  br label %bb90
bb90:
  %t274 = load %"compiler/source:Span", ptr %l129
  store %"compiler/source:Span" %t274, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i1
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l8, !tbaa !24
  br label %bb51
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store i64 %t44, ptr %l27
  br label %bb13
bb13:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  br label %bb51
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t47 = load ptr, ptr %l28, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l28, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l29, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store i64 %t68, ptr %l37
  br label %bb20
bb20:
  %t69 = load i64, ptr %l37, !tbaa !24
  store i64 %t69, ptr %l8, !tbaa !24
  br label %bb51
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 2
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t90 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltCall(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  store i64 %t90, ptr %l47
  br label %bb27
bb27:
  %t91 = load i64, ptr %l47, !tbaa !24
  store i64 %t91, ptr %l8, !tbaa !24
  br label %bb51
bb28:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t93 = load ptr, ptr %l48, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 8}
  %t99 = icmp eq i64 %t97, 6
  store i1 %t99, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t100 = load i1, ptr %l49, !tbaa !21
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t112 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltCall(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  store i64 %t112, ptr %l57
  br label %bb34
bb34:
  %t113 = load i64, ptr %l57, !tbaa !24
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb51
bb35:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t115 = load ptr, ptr %l58, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb36, label %bb37
bb36:
  %t118 = load ptr, ptr %l58, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 8}
  %t121 = icmp eq i64 %t119, 0
  store i1 %t121, ptr %l59, !tbaa !21
  br label %bb37
bb37:
  %t122 = load i1, ptr %l59, !tbaa !21
  br i1 %t122, label %bb38, label %bb39
bb38:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t125, i32 0, i32 2
  %t127 = load i32, ptr %t126
  store i32 %t127, ptr %l7, !tbaa !23
  br label %bb40
bb39:
  br label %bb46
bb40:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l64, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/scope:Scoper", ptr %t130, i32 0, i32 40
  %t133 = load i32, ptr %l7, !tbaa !23
  %t135 = sext i32 %t133 to i64
  %t138 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t132, i64 %t135)
  %t139 = extractvalue { i32, ptr } %t138, 1
  %t140 = extractvalue { i32, ptr } %t138, 0
  store i32 %t140, ptr %l71
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb42, label %ok.142, !prof !99
ok.142:
  store ptr %t139, ptr %l70
  br label %bb41
bb41:
  %t143 = load ptr, ptr %l70, !tbaa !29
  store ptr %t143, ptr %l65, !tbaa !29
  br label %bb44
bb42:
  br label %bb43
bb43:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l65, !tbaa !29
  br label %bb44
bb44:
  %t144 = load ptr, ptr %l64, !tbaa !29
  %t145 = load ptr, ptr %l65, !tbaa !29
  %t146 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltCall(ptr %v0, ptr %v0, ptr %t144, ptr %t145)
  store i64 %t146, ptr %l72
  br label %bb45
bb45:
  %t147 = load i64, ptr %l72, !tbaa !24
  store i64 %t147, ptr %l8, !tbaa !24
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_da3e82aad0dc20bd_21e51e34c917c3d9)
  unreachable
bb51:
  %t148 = load i64, ptr %l8, !tbaa !24
  store i64 %t148, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartKept(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l33 = alloca %"compiler/source:Span"
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca i64
  %l46 = alloca %"compiler/source:Span"
  %l48 = alloca i64
  %l49 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l69 = alloca %"compiler/typed:Local"
  %l71 = alloca { i64, ptr }
  %l72 = alloca %"compiler/msgs:Msg"
  %l73 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOfOwn(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t15 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t10, ptr %t11)
  store ptr %t15, ptr %l15
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l15, !tbaa !29
  %t17 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t16)
  store ptr %t17, ptr %l16
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l16, !tbaa !29
  store ptr %t18, ptr %l3, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclaimRoot(ptr %v0, ptr %v1, ptr %t19, ptr %t20)
  store i64 %t23, ptr %l19
  br label %bb7
bb7:
  %t24 = load i64, ptr %l19, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 10
  store ptr %t27, ptr %l22, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/scope:Scoper", ptr %t28, i32 0, i32 25
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_178b2bff302b55ae_896b4874215d5e1a)
  unreachable
bb9:
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 25
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 3
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t45 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t43, i64 %t42)
  %t46 = extractvalue { i32, { i64, ptr } } %t45, 1
  %t47 = extractvalue { i32, { i64, ptr } } %t45, 0
  store i32 %t47, ptr %l31
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb12, label %ok.49, !prof !99
ok.49:
  store { i64, ptr } %t46, ptr %l30
  br label %bb11
bb11:
  %t50 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t50, ptr %l20, !tbaa !27
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l20, !tbaa !27
  br label %bb14
bb14:
  %t51 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t51, ptr %l5, !tbaa !27
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %s0, ptr %t52)
  store %"compiler/source:Span" %t54, ptr %l33
  br label %bb15
bb15:
  %t55 = getelementptr %"compiler/source:Span", ptr %l33, i32 0, i32 1
  %t56 = load i32, ptr %t55, !tbaa !23
  %t58 = sext i32 %t56 to i64
  %t59 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp sle i64 %t58, %t61
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t66, ptr %l40, !tbaa !27
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t69 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %s0, ptr %t67)
  store %"compiler/source:Span" %t69, ptr %l42
  br label %bb18
bb17:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l39, !tbaa !27
  br label %bb26
bb18:
  %t70 = getelementptr %"compiler/source:Span", ptr %l42, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t73 = sext i32 %t71 to i64
  store i64 %t73, ptr %l44, !tbaa !24
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %s0, ptr %t74)
  store %"compiler/source:Span" %t76, ptr %l46
  br label %bb19
bb19:
  %t77 = getelementptr %"compiler/source:Span", ptr %l46, i32 0, i32 1
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = sext i32 %t78 to i64
  store i64 %t80, ptr %l48, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l49, !tbaa !24
  %t83 = load i64, ptr %l44, !tbaa !24
  %t84 = icmp sge i64 %t83, 0
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t86 = load i64, ptr %l44, !tbaa !24
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_98dfeaa5663cde63_8f6c693e4f6dac2f)
  unreachable
bb22:
  %t90 = load i64, ptr %l48, !tbaa !24
  %t91 = load i64, ptr %l49, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_98dfeaa5663cde63_8f6c693e4f6dac2f)
  unreachable
bb24:
  %t94 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l44, !tbaa !24
  %t97 = load i64, ptr %l48, !tbaa !24
  %t98 = getelementptr i8, ptr %t95, i64 %t96
  %t99 = sub i64 %t97, %t96
  %t100 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t98, 1
  store { i64, ptr } %t101, ptr %l39, !tbaa !27
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_98dfeaa5663cde63_8f6c693e4f6dac2f)
  unreachable
bb26:
  %t103 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l54, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l55
  store { i64, ptr } %t103, ptr %l56, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/scope:Scoper", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 3
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l60, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/scope:Scoper", ptr %t117, i32 0, i32 25
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = icmp eq ptr %t120, null
  br i1 %t122, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_50915285e3e59b40_32eaccc11482b3ec)
  unreachable
bb28:
  br label %bb29
bb29:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/scope:Scoper", ptr %t124, i32 0, i32 25
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Body", ptr %t127, i32 0, i32 7
  %t131 = load i64, ptr %l4, !tbaa !24
  %t134 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t130, i64 %t131)
  store %"compiler/typed:Local" %t134, ptr %l69
  br label %bb30
bb30:
  %t135 = getelementptr %"compiler/typed:Local", ptr %l69, i32 0, i32 0
  %t136 = load i32, ptr %t135, !tbaa !23
  %t137 = load ptr, ptr %l60, !tbaa !29
  %t139 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t137, i32 %t136)
  store { i64, ptr } %t139, ptr %l71
  br label %bb31
bb31:
  %t140 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t142 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePartKept(ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t140, { i64, ptr } %t141)
  store %"compiler/msgs:Msg" %t142, ptr %l72
  br label %bb32
bb32:
  %t143 = load ptr, ptr %l54, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l55
  %t145 = load %"compiler/msgs:Msg", ptr %l72
  %t146 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s0, ptr %t143, %"compiler/source:Span" %t144, %"compiler/msgs:Msg" %t145)
  store i64 %t146, ptr %l73
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i32
  %l25 = alloca i1
  %l30 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i32
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l66 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l81 = alloca i32
  %l84 = alloca ptr
  %l89 = alloca i32
  %l96 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l121 = alloca ptr
  %l126 = alloca i32
  %l127 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l18
  br label %bb2
bb2:
  %t15 = load i32, ptr %l18, !range !{i32 0, i32 33}
  store i32 %t15, ptr %l3
  %t16 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb43
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l25
  br label %bb6
bb6:
  %t31 = load i1, ptr %l25, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %lp2
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l30, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l35
  br label %bb10
bb10:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load i32, ptr %l35, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t55, ptr %l36
  br label %bb11
bb11:
  %t56 = load i32, ptr %l36, !range !{i32 0, i32 6}
  store i32 %t56, ptr %l4
  %t57 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t59 = trunc i64 0 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  store ptr %t67, ptr %l41, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l46
  br label %bb15
bb15:
  %t78 = load ptr, ptr %l41, !tbaa !29
  %t79 = load i32, ptr %l46, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t78, i32 %t79)
  store { i64, ptr } %t80, ptr %l47
  br label %bb16
bb16:
  %t81 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t81, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t94 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t94, ptr %l54, !tbaa !27
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  %t102 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t102, i32 %t100)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l6, !tbaa !24
  br label %bb17
bb23:
  br label %bb42
bb24:
  %t110 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t112 = trunc i64 1 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb31
bb27:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l63, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/scope:Scoper", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  store ptr %t121, ptr %l66, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/scope:Scoper", ptr %t122, i32 0, i32 0
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = load i32, ptr %l1, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l71
  br label %bb28
bb28:
  %t132 = load ptr, ptr %l66, !tbaa !29
  %t133 = load i32, ptr %l71, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t132, i32 %t133)
  store { i64, ptr } %t134, ptr %l72
  br label %bb29
bb29:
  %t135 = load ptr, ptr %lp2
  %t136 = load ptr, ptr %l63, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l72, !tbaa !27
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecaseParts(ptr %v0, ptr %v0, ptr %v1, ptr %t136, { i64, ptr } %t137, ptr %t135)
  br label %bb30
bb30:
  br label %bb42
bb31:
  %t139 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t141 = trunc i64 4 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t144 = load ptr, ptr %lp2
  store ptr %t144, ptr %l76, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/scope:Scoper", ptr %t145, i32 0, i32 0
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l1, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l81
  br label %bb35
bb35:
  %t155 = load ptr, ptr %l76, !tbaa !29
  %t156 = load i32, ptr %l81, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t155, i32 %t156)
  br label %bb36
bb36:
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_74d9849f1cf072e4_d95edc215f7aa198)
  unreachable
bb42:
  br label %bb76
bb43:
  %t157 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t159 = trunc i64 19 to i32
  %t160 = icmp eq i32 %t157, %t159
  br i1 %t160, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t162 = load ptr, ptr %lp2
  store ptr %t162, ptr %l84, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/scope:Scoper", ptr %t163, i32 0, i32 0
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 2
  %t169 = load i32, ptr %l1, !tbaa !23
  %t172 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t168, i32 %t169)
  store i32 %t172, ptr %l89
  br label %bb47
bb47:
  %t173 = load ptr, ptr %l84, !tbaa !29
  %t174 = load i32, ptr %l89, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t173, i32 %t174)
  br label %bb48
bb48:
  br label %bb76
bb49:
  %t175 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t177 = trunc i64 22 to i32
  %t178 = icmp eq i32 %t175, %t177
  br i1 %t178, label %bb50, label %bb51
bb50:
  br label %bb54
bb51:
  %t180 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t182 = trunc i64 23 to i32
  %t183 = icmp eq i32 %t180, %t182
  br i1 %t183, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb64
bb54:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/scope:Scoper", ptr %t185, i32 0, i32 0
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 2
  store ptr %t190, ptr %l96, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/scope:Scoper", ptr %t191, i32 0, i32 0
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  %t197 = load i32, ptr %l1, !tbaa !23
  %t200 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t196, i32 %t197)
  store i32 %t200, ptr %l101
  br label %bb55
bb55:
  %t201 = load ptr, ptr %l96, !tbaa !29
  %t202 = load i32, ptr %l101, !tbaa !23
  %t203 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t201, i32 %t202)
  store { i64, ptr } %t203, ptr %l102
  br label %bb56
bb56:
  %t204 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t204, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  store i64 %t207, ptr %l11, !tbaa !24
  br label %bb57
bb57:
  %t209 = load i64, ptr %l10, !tbaa !24
  %t210 = load i64, ptr %l11, !tbaa !24
  %t213 = icmp slt i64 %t209, %t210
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb58, label %bb59
bb58:
  br label %bb63
bb59:
  br label %bb60
bb60:
  %t217 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t217, ptr %l109, !tbaa !27
  %t218 = load i64, ptr %l10, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr i32, ptr %t221, i64 %t218
  %t223 = load i32, ptr %t222, !tbaa !33
  %t225 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t225, i32 %t223)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t229 = load i64, ptr %l10, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l10, !tbaa !24
  br label %bb57
bb63:
  br label %bb76
bb64:
  %t233 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t235 = trunc i64 24 to i32
  %t236 = icmp eq i32 %t233, %t235
  br i1 %t236, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb71
bb67:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l118, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/scope:Scoper", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 2
  store ptr %t244, ptr %l121, !tbaa !29
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/scope:Scoper", ptr %t245, i32 0, i32 0
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t250 = getelementptr %"compiler/generic:Program", ptr %t248, i32 0, i32 2
  %t251 = load i32, ptr %l1, !tbaa !23
  %t254 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t250, i32 %t251)
  store i32 %t254, ptr %l126
  br label %bb68
bb68:
  %t255 = load ptr, ptr %l121, !tbaa !29
  %t256 = load i32, ptr %l126, !tbaa !23
  %t257 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t255, i32 %t256)
  store { i64, ptr } %t257, ptr %l127
  br label %bb69
bb69:
  %t258 = load ptr, ptr %lp2
  %t259 = load ptr, ptr %l118, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l127, !tbaa !27
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecaseParts(ptr %v0, ptr %v0, ptr %v1, ptr %t259, { i64, ptr } %t260, ptr %t258)
  br label %bb70
bb70:
  br label %bb76
bb71:
  br i1 true, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_b99a325748da8cd5_4eb62b65b3c79869)
  unreachable
bb76:
  %t262 = load ptr, ptr %lp2
  %t263 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t262
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t263, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2equalifiesMove(ptr %v0, ptr %v1, ptr %a0, %"compiler/typed:Local" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/typed:Local"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l50 = alloca i1
  %l55 = alloca i1
  %l61 = alloca i32
  %l64 = alloca i1
  %l67 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/typed:Local" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 2
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l14
  br label %bb5
bb5:
  %t16 = load i1, ptr %l14, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t17 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 5
  %t18 = load { i64, [1 x i64] }, ptr %t17
  store { i64, [1 x i64] } %t18, ptr %l4
  %t20 = load { i64, [1 x i64] }, ptr %l4
  %t22 = extractvalue { i64, [1 x i64] } %t20, 0
  %t23 = icmp eq i64 %t22, 1
  br i1 %t23, label %bb8, label %bb9
bb7:
  br label %bb32
bb8:
  br label %bb12
bb9:
  %t25 = load { i64, [1 x i64] }, ptr %l4
  %t27 = extractvalue { i64, [1 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 4
  br i1 %t28, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_554265ba1528b3d8_d73d8ae267adc184)
  unreachable
bb18:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t36 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t36, ptr %l24
  br label %bb19
bb19:
  %t37 = load i1, ptr %l24, !tbaa !21
  br i1 %t37, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb23
bb21:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t42 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  store i1 %t42, ptr %l28
  br label %bb22
bb22:
  %t43 = load i1, ptr %l28, !tbaa !21
  store i1 %t43, ptr %l25, !tbaa !21
  br label %bb23
bb23:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb27
bb25:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisData(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store i1 %t49, ptr %l32
  br label %bb26
bb26:
  %t50 = load i1, ptr %l32, !tbaa !21
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb27
bb27:
  %t51 = load i1, ptr %l29, !tbaa !21
  br i1 %t51, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb31
bb29:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t56 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  store i1 %t56, ptr %l36
  br label %bb30
bb30:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %l33, !tbaa !21
  br label %bb31
bb31:
  %t58 = load i1, ptr %l33, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
bb32:
  %t59 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 5
  %t60 = load { i64, [1 x i64] }, ptr %t59
  store { i64, [1 x i64] } %t60, ptr %l5
  %t62 = load { i64, [1 x i64] }, ptr %l5
  %t64 = extractvalue { i64, [1 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 0
  br i1 %t65, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t67 = load { i64, [1 x i64] }, ptr %l5
  %t69 = extractvalue { i64, [1 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 4
  br i1 %t70, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i1 false, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_c484f993348186a9_88a471068962d75)
  unreachable
bb43:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t78 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t73, ptr %t74)
  store i1 %t78, ptr %l46
  br label %bb44
bb44:
  %t79 = load i1, ptr %l46, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb45, label %bb46
bb45:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = call i1 @compiler_2fscope_2ecopiedRead(ptr %v1, ptr %t82)
  store i1 %t84, ptr %l50
  br label %bb47
bb46:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb48
bb47:
  %t85 = load i1, ptr %l50, !tbaa !21
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %l48, !tbaa !21
  br label %bb48
bb48:
  %t88 = load i1, ptr %l48, !tbaa !21
  br i1 %t88, label %bb49, label %bb50
bb49:
  store i1 false, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l55
  br label %bb52
bb52:
  %t95 = load i1, ptr %l55, !tbaa !21
  br i1 %t95, label %bb53, label %bb54
bb53:
  store i1 true, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/scope:Scoper", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l3, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l61
  br label %bb56
bb56:
  %t107 = load i32, ptr %l61, !range !{i32 0, i32 33}
  store i32 %t107, ptr %l6
  %t108 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t110 = trunc i64 19 to i32
  %t111 = icmp eq i32 %t108, %t110
  br i1 %t111, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb59
bb58:
  %t113 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t115 = trunc i64 18 to i32
  %t116 = icmp eq i32 %t113, %t115
  store i1 %t116, ptr %l64, !tbaa !21
  br label %bb59
bb59:
  %t118 = load i1, ptr %l64, !tbaa !21
  br i1 %t118, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb62
bb61:
  %t119 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t121 = trunc i64 22 to i32
  %t122 = icmp eq i32 %t119, %t121
  store i1 %t122, ptr %l67, !tbaa !21
  br label %bb62
bb62:
  %t124 = load i1, ptr %l67, !tbaa !21
  store i1 %t124, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eread(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca %"compiler/scope:Val"
  %l11 = alloca i64
  %l14 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca i1
  %l25 = alloca %"compiler/scope:Val"
  %l33 = alloca i1
  %rv = alloca %"compiler/scope:Val"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t4 = load { i64, [2 x i64] }, ptr %l3
  %t9 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartLand(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t3, { i64, [2 x i64] } %t4)
  store i64 %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 110
  %t14 = load i1, ptr %t13, !tbaa !21
  store i1 %t14, ptr %l5, !tbaa !21
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb5
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l19
  br label %bb4
bb4:
  %t24 = load i1, ptr %l19, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l16, !tbaa !21
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t28, i32 0, i32 110
  store i1 %t27, ptr %t29, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t33 = load { i64, [2 x i64] }, ptr %l3
  %t38 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereadPart(ptr %v0, ptr %v1, ptr %t30, ptr %t31, i32 %t32, { i64, [2 x i64] } %t33)
  store %"compiler/scope:Val" %t38, ptr %l25
  br label %bb6
bb6:
  %t39 = load %"compiler/scope:Val", ptr %l25
  store %"compiler/scope:Val" %t39, ptr %l6
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i1, ptr %l5, !tbaa !21
  %t44 = getelementptr %"compiler/scope:Scoper", ptr %t40, i32 0, i32 110
  store i1 %t41, ptr %t44, !tbaa !21
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  br i1 %t47, label %bb7, label %bb8
bb7:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 93
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb4ab14fd1aa8deeb21095c3402461540(ptr %v0, ptr %t51, i64 %t52)
  store i1 %t55, ptr %l33
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t56 = load %"compiler/scope:Val", ptr %l6
  store %"compiler/scope:Val" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultMark(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca ptr
  %l13 = alloca i32
  %l19 = alloca { i64, [2 x i64] }
  %l33 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca i64
  %l51 = alloca i64
  %l63 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t32 = alloca { i64, [1 x i64] }, align 8
  %t61 = alloca { i64, [1 x i64] }, align 8
  %t116 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/scope:Scoper", ptr %t7, i32 0, i32 25
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_59817874246b5c57_1f46b3df70232973)
  unreachable
bb2:
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 25
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 2
  %t21 = load i32, ptr %t20, !tbaa !23
  %t22 = load ptr, ptr %l5, !tbaa !29
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t22, i32 %t21)
  store i32 %t24, ptr %l13
  br label %bb4
bb4:
  %t25 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t27 = trunc i64 21 to i32
  %t28 = icmp eq i32 %t25, %t27
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  store { i64, [1 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [1 x i64] }, ptr %t32, i32 0, i32 0
  store i64 1, ptr %t33
  %t34 = load { i64, [1 x i64] }, ptr %t32
  store { i64, [1 x i64] } %t34, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %t36)
  store { i64, [2 x i64] } %t38, ptr %l19
  br label %bb8
bb8:
  %t39 = load { i64, [2 x i64] }, ptr %l19
  %t41 = extractvalue { i64, [2 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 0
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 25
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb11, label %bb12
bb10:
  br label %bb14
bb11:
  call void @__olang_check_failed(ptr @olang_loc_56ee07e6d564b038_6c64e51b3b797fa4)
  unreachable
bb12:
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 25
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 15
  %t60 = load i32, ptr %t59, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [1 x i64] }, ptr %t61, i32 0, i32 0
  store i64 2, ptr %t62
  %t64 = insertvalue { i32 } undef, i32 %t60, 0
  %t65 = getelementptr { i64, [1 x i64] }, ptr %t61, i32 0, i32 1
  store { i32 } %t64, ptr %t65
  %t66 = load { i64, [1 x i64] }, ptr %t61
  store { i64, [1 x i64] } %t66, ptr %rv
  br label %ret
bb14:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  store ptr %t73, ptr %l33, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/scope:Scoper", ptr %t74, i32 0, i32 25
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_8b89bffa420e9c4d_32da4af1bb00bb59)
  unreachable
bb16:
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 25
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t84, i32 0, i32 2
  %t88 = load i32, ptr %t87, !tbaa !23
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = load ptr, ptr %l33, !tbaa !29
  %t93 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t90, i32 %t88, i64 %t89)
  store i64 %t93, ptr %l42
  br label %bb18
bb18:
  %t94 = load i64, ptr %l42, !tbaa !24
  store i64 %t94, ptr %l43, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/scope:Scoper", ptr %t96, i32 0, i32 25
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = icmp eq ptr %t99, null
  br i1 %t101, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_cf97101c527ac266_2da604e73063aa32)
  unreachable
bb20:
  br label %bb21
bb21:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/scope:Scoper", ptr %t103, i32 0, i32 25
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Body", ptr %t106, i32 0, i32 5
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l51
  br label %bb22
bb22:
  %t112 = load i64, ptr %l43, !tbaa !24
  %t113 = load i64, ptr %l51, !tbaa !24
  %t114 = icmp sge i64 %t112, %t113
  br i1 %t114, label %bb23, label %bb24
bb23:
  store { i64, [1 x i64] } zeroinitializer, ptr %t116
  %t117 = getelementptr { i64, [1 x i64] }, ptr %t116, i32 0, i32 0
  store i64 5, ptr %t117
  %t118 = load { i64, [1 x i64] }, ptr %t116
  store { i64, [1 x i64] } %t118, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/scope:Scoper", ptr %t120, i32 0, i32 25
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  br i1 %t125, label %bb26, label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_289e5954cee327eb_2a90d26159dceaff)
  unreachable
bb27:
  br label %bb28
bb28:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/scope:Scoper", ptr %t127, i32 0, i32 25
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/scope:Scoper", ptr %t131, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i64, ptr %l1, !tbaa !24
  %t141 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eResultMark(ptr %v0, ptr %v0, ptr %t130, ptr %t136, i64 %t137)
  store { i64, [1 x i64] } %t141, ptr %l63
  br label %bb29
bb29:
  %t142 = load { i64, [1 x i64] }, ptr %l63
  store { i64, [1 x i64] } %t142, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t13, i32 %t14)
  store { i64, ptr } %t17, ptr %l17
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i64, ptr %l5, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb10
bb7:
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l26, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l26, !tbaa !24
  store i64 %t49, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l23, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb12, label %bb13
bb12:
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = mul i64 %t60, %t61
  %t67 = add i64 %t59, %t64
  store i64 %t67, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i64, ptr %t72, i64 %t69
  %t74 = load i64, ptr %t73, !tbaa !34
  %t75 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t78 = icmp eq i64 %t74, %t75
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t80 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t80, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb11
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, [1 x i64] }
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l24 = alloca { i64, [1 x i64] }
  %l25 = alloca i32
  %l26 = alloca %"compiler/scope:walked"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i32
  %l39 = alloca ptr
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l79 = alloca ptr
  %l86 = alloca %"compiler/typed:Local"
  %l89 = alloca i1
  %l96 = alloca %"compiler/typed:Local"
  %l99 = alloca i64
  %l109 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i64
  %l140 = alloca { i64, [1 x i64] }
  %l172 = alloca i64
  %l175 = alloca ptr
  %l181 = alloca i32
  %l192 = alloca i64
  %l196 = alloca i64
  %l199 = alloca i64
  %l223 = alloca i32
  %l231 = alloca %"compiler/typed:Local"
  %l240 = alloca { i64, [2 x i64] }
  %l244 = alloca ptr
  %l246 = alloca i64
  %l251 = alloca { i64, [2 x i64] }
  %l261 = alloca i1
  %l262 = alloca ptr
  %l266 = alloca i1
  %l267 = alloca %"compiler/scope:walked"
  %l279 = alloca i64
  %l281 = alloca i64
  %l286 = alloca i32
  %l289 = alloca ptr
  %l297 = alloca %"compiler/typed:Local"
  %l299 = alloca i32
  %l302 = alloca i1
  %l303 = alloca i1
  %l308 = alloca i32
  %l312 = alloca i1
  %l317 = alloca i32
  %l322 = alloca i1
  %l323 = alloca i1
  %l327 = alloca i1
  %l329 = alloca i64
  %l333 = alloca i64
  %l336 = alloca i64
  %l356 = alloca i64
  %l362 = alloca i32
  %l365 = alloca i1
  %l368 = alloca ptr
  %l373 = alloca i32
  %l374 = alloca i64
  %l389 = alloca ptr
  %l401 = alloca i32
  %l404 = alloca i32
  %l405 = alloca i32
  %s18 = alloca %olang.scope
  %t66 = alloca { i64, [2 x i64] }, align 8
  %t74 = alloca { i64, [2 x i64] }, align 8
  %t217 = alloca { i64, [2 x i64] }, align 8
  %t242 = alloca { i64, [2 x i64] }, align 8
  %t300 = alloca { i64, [2 x i64] }, align 8
  %t470 = alloca %"compiler/scope:walked", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_8136fe9cd009015e_effe087bfaf9a8aa)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 7
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l47
  br label %bb4
bb4:
  %t16 = load i64, ptr %l47, !tbaa !24
  store i64 %t16, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb10
bb7:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l54, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l54, !tbaa !24
  store i64 %t43, ptr %l51, !tbaa !24
  br label %bb10
bb10:
  %t44 = load i64, ptr %l51, !tbaa !24
  store i64 %t44, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb12, label %bb13
bb12:
  br label %bb34
bb13:
  br label %bb14
bb14:
  %t53 = load i64, ptr %l2, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l7, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 31
  store { i64, [2 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [2 x i64] }, ptr %t66, i32 0, i32 0
  store i64 0, ptr %t67
  %t68 = load { i64, [2 x i64] }, ptr %t66
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t65, { i64, [2 x i64] } %t68)
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/scope:Scoper", ptr %t71, i32 0, i32 32
  store { i64, [2 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 0
  store i64 1, ptr %t75
  %t76 = insertvalue { i32 } undef, i32 0, 0
  %t77 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 1
  store { i32 } %t76, ptr %t77
  %t78 = load { i64, [2 x i64] }, ptr %t74
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t73, { i64, [2 x i64] } %t78)
  br label %bb16
bb16:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 134
  store ptr %t83, ptr %l79, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_989f9a5853b8d905_f9638c70ccb394b1)
  unreachable
bb18:
  br label %bb19
bb19:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Body", ptr %t88, i32 0, i32 7
  %t92 = load i64, ptr %l7, !tbaa !24
  %t95 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t91, i64 %t92)
  store %"compiler/typed:Local" %t95, ptr %l86
  br label %bb20
bb20:
  %t96 = getelementptr %"compiler/typed:Local", ptr %l86, i32 0, i32 4
  %t97 = load i32, ptr %t96, !range !{i32 0, i32 7}
  %t99 = trunc i64 1 to i32
  %t100 = icmp eq i32 %t97, %t99
  br i1 %t100, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb27
bb22:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_989f9a5853b8d905_f9638c70ccb394b1)
  unreachable
bb24:
  br label %bb25
bb25:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Body", ptr %t106, i32 0, i32 7
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t109, i64 %t110)
  store %"compiler/typed:Local" %t113, ptr %l96
  br label %bb26
bb26:
  %t114 = getelementptr %"compiler/typed:Local", ptr %l96, i32 0, i32 4
  %t115 = load i32, ptr %t114, !range !{i32 0, i32 7}
  %t117 = trunc i64 3 to i32
  %t118 = icmp eq i32 %t115, %t117
  store i1 %t118, ptr %l89, !tbaa !21
  br label %bb27
bb27:
  %t120 = load i1, ptr %l89, !tbaa !21
  br i1 %t120, label %bb28, label %bb29
bb28:
  store i64 -1, ptr %l99, !tbaa !24
  br label %bb30
bb29:
  store i64 -2, ptr %l99, !tbaa !24
  br label %bb30
bb30:
  %t121 = load ptr, ptr %l79, !tbaa !29
  %t122 = load i64, ptr %l99, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t121, i64 %t122)
  br label %bb31
bb31:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 135
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t125, i64 -1)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t127 = load i64, ptr %l6, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l6, !tbaa !24
  br label %bb11
bb34:
  store i64 0, ptr %l8, !tbaa !24
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = icmp eq ptr %t131, null
  br i1 %t133, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_9ce8ff5a7c812fb0_6c28ecd338a0cbbc)
  unreachable
bb36:
  br label %bb37
bb37:
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Body", ptr %t135, i32 0, i32 6
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t138)
  store i64 %t140, ptr %l109
  br label %bb38
bb38:
  %t141 = load i64, ptr %l109, !tbaa !24
  store i64 %t141, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  %t143 = load i64, ptr %l8, !tbaa !24
  %t146 = icmp sgt i64 %t142, %t143
  br i1 %t146, label %bb39, label %bb40
bb39:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t150 = icmp sgt i64 %t148, 0
  br i1 %t150, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb44
bb41:
  %t152 = load i64, ptr %l9, !tbaa !24
  %t153 = load i64, ptr %l8, !tbaa !24
  %t156 = sub i64 %t152, %t153
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = add i64 %t156, %t157
  %t162 = sub i64 %t160, 1
  %t163 = load i64, ptr %l10, !tbaa !24
  %t166 = sdiv i64 %t162, %t163
  store i64 %t166, ptr %l116, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb43
bb43:
  %t168 = load i64, ptr %l116, !tbaa !24
  store i64 %t168, ptr %l113, !tbaa !24
  br label %bb44
bb44:
  %t169 = load i64, ptr %l113, !tbaa !24
  store i64 %t169, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb45
bb45:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l11, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb46, label %bb47
bb46:
  br label %bb87
bb47:
  br label %bb48
bb48:
  %t178 = load i64, ptr %l8, !tbaa !24
  %t179 = load i64, ptr %l12, !tbaa !24
  %t180 = load i64, ptr %l10, !tbaa !24
  %t183 = mul i64 %t179, %t180
  %t186 = add i64 %t178, %t183
  store i64 %t186, ptr %l13, !tbaa !24
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = icmp eq ptr %t188, null
  br i1 %t190, label %bb49, label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_5c3642998b37ea8f_438088e259bab72b)
  unreachable
bb50:
  br label %bb51
bb51:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Body", ptr %t192, i32 0, i32 6
  %t196 = load i64, ptr %l13, !tbaa !24
  %t199 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t195, i64 %t196)
  store { i64, [1 x i64] } %t199, ptr %l140
  br label %bb52
bb52:
  %t200 = load { i64, [1 x i64] }, ptr %l140
  store { i64, [1 x i64] } %t200, ptr %l14
  %t201 = load { i64, [1 x i64] }, ptr %l14
  %t203 = extractvalue { i64, [1 x i64] } %t201, 0
  %t204 = icmp eq i64 %t203, 0
  br i1 %t204, label %bb53, label %bb54
bb53:
  %t206 = getelementptr { i64, [1 x i64] }, ptr %l14, i32 0, i32 1
  %t207 = getelementptr { i32 }, ptr %t206, i32 0, i32 0
  %t208 = load i32, ptr %t207
  store i32 %t208, ptr %l15, !tbaa !23
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/scope:Scoper", ptr %t210, i32 0, i32 31
  %t213 = load i32, ptr %l15, !tbaa !23
  %t215 = sext i32 %t213 to i64
  %t216 = load i64, ptr %l13, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t217
  %t218 = getelementptr { i64, [2 x i64] }, ptr %t217, i32 0, i32 0
  store i64 2, ptr %t218
  %t220 = insertvalue { i64 } undef, i64 %t216, 0
  %t221 = getelementptr { i64, [2 x i64] }, ptr %t217, i32 0, i32 1
  store { i64 } %t220, ptr %t221
  %t222 = load { i64, [2 x i64] }, ptr %t217
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t212, i64 %t215, { i64, [2 x i64] } %t222)
  br label %bb56
bb56:
  br label %bb85
bb57:
  %t226 = load { i64, [1 x i64] }, ptr %l14
  %t228 = extractvalue { i64, [1 x i64] } %t226, 0
  %t229 = icmp eq i64 %t228, 4
  br i1 %t229, label %bb58, label %bb59
bb58:
  %t231 = getelementptr { i64, [1 x i64] }, ptr %l14, i32 0, i32 1
  %t232 = getelementptr { i32 }, ptr %t231, i32 0, i32 0
  %t233 = load i32, ptr %t232
  store i32 %t233, ptr %l16, !tbaa !23
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/scope:Scoper", ptr %t235, i32 0, i32 31
  %t238 = load i32, ptr %l16, !tbaa !23
  %t240 = sext i32 %t238 to i64
  %t241 = load i64, ptr %l13, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t242
  %t243 = getelementptr { i64, [2 x i64] }, ptr %t242, i32 0, i32 0
  store i64 2, ptr %t243
  %t245 = insertvalue { i64 } undef, i64 %t241, 0
  %t246 = getelementptr { i64, [2 x i64] }, ptr %t242, i32 0, i32 1
  store { i64 } %t245, ptr %t246
  %t247 = load { i64, [2 x i64] }, ptr %t242
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t237, i64 %t240, { i64, [2 x i64] } %t247)
  br label %bb61
bb61:
  br label %bb85
bb62:
  %t251 = load { i64, [1 x i64] }, ptr %l14
  %t253 = extractvalue { i64, [1 x i64] } %t251, 0
  %t254 = icmp eq i64 %t253, 1
  br i1 %t254, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  %t256 = load { i64, [1 x i64] }, ptr %l14
  %t258 = extractvalue { i64, [1 x i64] } %t256, 0
  %t259 = icmp eq i64 %t258, 2
  br i1 %t259, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i64, ptr %l13, !tbaa !24
  %t265 = getelementptr %"compiler/scope:Scoper", ptr %t261, i32 0, i32 39
  store i64 %t262, ptr %t265, !tbaa !24
  br label %bb85
bb68:
  %t266 = load { i64, [1 x i64] }, ptr %l14
  %t268 = extractvalue { i64, [1 x i64] } %t266, 0
  %t269 = icmp eq i64 %t268, 3
  br i1 %t269, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb84
bb71:
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = icmp eq ptr %t271, null
  br i1 %t273, label %bb72, label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_486c515bb0c7ed42_3dcfa333a8d1daa6)
  unreachable
bb73:
  br label %bb74
bb74:
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t278 = getelementptr %"compiler/typed:Body", ptr %t275, i32 0, i32 5
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t278)
  store i64 %t280, ptr %l172
  br label %bb75
bb75:
  %t281 = load i64, ptr %l172, !tbaa !24
  %t282 = icmp sgt i64 %t281, 0
  br i1 %t282, label %bb76, label %bb77
bb76:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/scope:Scoper", ptr %t284, i32 0, i32 31
  store ptr %t286, ptr %l175, !tbaa !29
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = icmp eq ptr %t287, null
  br i1 %t289, label %bb78, label %bb79
bb77:
  br label %bb83
bb78:
  call void @__olang_check_failed(ptr @olang_loc_486c515bb0c7ed42_3dcfa333a8d1daa6)
  unreachable
bb79:
  br label %bb80
bb80:
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Body", ptr %t291, i32 0, i32 5
  %t296 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t294, i64 0)
  store i32 %t296, ptr %l181
  br label %bb81
bb81:
  %t297 = load i32, ptr %l181, !tbaa !23
  %t298 = sext i32 %t297 to i64
  %t299 = load i64, ptr %l13, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t300
  %t301 = getelementptr { i64, [2 x i64] }, ptr %t300, i32 0, i32 0
  store i64 2, ptr %t301
  %t303 = insertvalue { i64 } undef, i64 %t299, 0
  %t304 = getelementptr { i64, [2 x i64] }, ptr %t300, i32 0, i32 1
  store { i64 } %t303, ptr %t304
  %t305 = load { i64, [2 x i64] }, ptr %t300
  %t306 = load ptr, ptr %l175, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t306, i64 %t298, { i64, [2 x i64] } %t305)
  br label %bb82
bb82:
  br label %bb83
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_ed4ec6d3513e2b60_3036131f8fea9d34)
  unreachable
bb85:
  br label %bb86
bb86:
  %t309 = load i64, ptr %l12, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l12, !tbaa !24
  br label %bb45
bb87:
  store i64 0, ptr %l17, !tbaa !24
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = icmp eq ptr %t313, null
  br i1 %t315, label %bb88, label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_b48db41ed7b5d734_952948d9de5cb478)
  unreachable
bb89:
  br label %bb90
bb90:
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t320 = getelementptr %"compiler/typed:Body", ptr %t317, i32 0, i32 5
  %t322 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t320)
  store i64 %t322, ptr %l192
  br label %bb91
bb91:
  %t323 = load i64, ptr %l192, !tbaa !24
  store i64 %t323, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t324 = load i64, ptr %l18, !tbaa !24
  %t325 = load i64, ptr %l17, !tbaa !24
  %t328 = icmp sgt i64 %t324, %t325
  br i1 %t328, label %bb92, label %bb93
bb92:
  %t330 = load i64, ptr %l19, !tbaa !24
  %t332 = icmp sgt i64 %t330, 0
  br i1 %t332, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb97
bb94:
  %t334 = load i64, ptr %l18, !tbaa !24
  %t335 = load i64, ptr %l17, !tbaa !24
  %t338 = sub i64 %t334, %t335
  %t339 = load i64, ptr %l19, !tbaa !24
  %t342 = add i64 %t338, %t339
  %t344 = sub i64 %t342, 1
  %t345 = load i64, ptr %l19, !tbaa !24
  %t348 = sdiv i64 %t344, %t345
  store i64 %t348, ptr %l199, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb96
bb96:
  %t350 = load i64, ptr %l199, !tbaa !24
  store i64 %t350, ptr %l196, !tbaa !24
  br label %bb97
bb97:
  %t351 = load i64, ptr %l196, !tbaa !24
  store i64 %t351, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb98
bb98:
  %t352 = load i64, ptr %l21, !tbaa !24
  %t353 = load i64, ptr %l20, !tbaa !24
  %t356 = icmp slt i64 %t352, %t353
  %t358 = xor i1 %t356, true
  br i1 %t358, label %bb99, label %bb100
bb99:
  br label %bb126
bb100:
  br label %bb101
bb101:
  %t360 = load i64, ptr %l17, !tbaa !24
  %t361 = load i64, ptr %l21, !tbaa !24
  %t362 = load i64, ptr %l19, !tbaa !24
  %t365 = mul i64 %t361, %t362
  %t368 = add i64 %t360, %t365
  store i64 %t368, ptr %l22, !tbaa !24
  %t370 = load ptr, ptr %l1, !tbaa !29
  %t372 = icmp eq ptr %t370, null
  br i1 %t372, label %bb102, label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_e7aa8a952f10dcc3_5e7ff2b7646c8097)
  unreachable
bb103:
  br label %bb104
bb104:
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t377 = getelementptr %"compiler/typed:Body", ptr %t374, i32 0, i32 5
  %t378 = load i64, ptr %l22, !tbaa !24
  %t381 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t377, i64 %t378)
  store i32 %t381, ptr %l223
  br label %bb105
bb105:
  %t382 = load i32, ptr %l223, !tbaa !23
  store i32 %t382, ptr %l23, !tbaa !23
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = icmp eq ptr %t383, null
  br i1 %t385, label %bb106, label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_dc4554eebbf8456_460c8fdf10d01e52)
  unreachable
bb107:
  br label %bb108
bb108:
  %t387 = load ptr, ptr %l1, !tbaa !29
  %t390 = getelementptr %"compiler/typed:Body", ptr %t387, i32 0, i32 7
  %t391 = load i32, ptr %l23, !tbaa !23
  %t393 = sext i32 %t391 to i64
  %t396 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t390, i64 %t393)
  store %"compiler/typed:Local" %t396, ptr %l231
  br label %bb109
bb109:
  %t397 = getelementptr %"compiler/typed:Local", ptr %l231, i32 0, i32 5
  %t398 = load { i64, [1 x i64] }, ptr %t397
  store { i64, [1 x i64] } %t398, ptr %l24
  %t400 = load { i64, [1 x i64] }, ptr %l24
  %t402 = extractvalue { i64, [1 x i64] } %t400, 0
  %t403 = icmp eq i64 %t402, 2
  br i1 %t403, label %bb110, label %bb111
bb110:
  %t405 = getelementptr { i64, [1 x i64] }, ptr %l24, i32 0, i32 1
  %t406 = getelementptr { i32 }, ptr %t405, i32 0, i32 0
  %t407 = load i32, ptr %t406
  store i32 %t407, ptr %l25, !tbaa !23
  br label %bb112
bb111:
  br label %bb119
bb112:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/scope:Scoper", ptr %t409, i32 0, i32 31
  %t412 = load i32, ptr %l23, !tbaa !23
  %t414 = sext i32 %t412 to i64
  %t417 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t411, i64 %t414)
  store { i64, [2 x i64] } %t417, ptr %l240
  br label %bb113
bb113:
  %t418 = load { i64, [2 x i64] }, ptr %l240
  %t420 = extractvalue { i64, [2 x i64] } %t418, 0
  %t421 = icmp eq i64 %t420, 0
  br i1 %t421, label %bb114, label %bb115
bb114:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/scope:Scoper", ptr %t423, i32 0, i32 31
  store ptr %t425, ptr %l244, !tbaa !29
  %t426 = load i32, ptr %l23, !tbaa !23
  %t428 = sext i32 %t426 to i64
  store i64 %t428, ptr %l246, !tbaa !24
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/scope:Scoper", ptr %t429, i32 0, i32 31
  %t432 = load i32, ptr %l25, !tbaa !23
  %t434 = sext i32 %t432 to i64
  %t437 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t431, i64 %t434)
  store { i64, [2 x i64] } %t437, ptr %l251
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t438 = load ptr, ptr %l244, !tbaa !29
  %t439 = load i64, ptr %l246, !tbaa !24
  %t440 = load { i64, [2 x i64] }, ptr %l251
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t438, i64 %t439, { i64, [2 x i64] } %t440)
  br label %bb117
bb117:
  br label %bb118
bb118:
  br label %bb124
bb119:
  br i1 true, label %bb120, label %bb121
bb120:
  br label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_check_failed(ptr @olang_loc_ab37e5456fd3bb64_ee38acc32440dcb0)
  unreachable
bb124:
  br label %bb125
bb125:
  %t441 = load i64, ptr %l21, !tbaa !24
  %t443 = add i64 %t441, 1
  store i64 %t443, ptr %l21, !tbaa !24
  br label %bb98
bb126:
  %t445 = load ptr, ptr %l1, !tbaa !29
  %t447 = icmp eq ptr %t445, null
  br i1 %t447, label %bb127, label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_c2f9290c57ed376d_cbd7590e0cb57901)
  unreachable
bb128:
  br label %bb129
bb129:
  %t449 = load ptr, ptr %l1, !tbaa !29
  %t452 = getelementptr %"compiler/typed:Body", ptr %t449, i32 0, i32 11
  %t453 = load ptr, ptr %t452, !tbaa !29
  %t455 = icmp eq ptr %t453, null
  %t457 = xor i1 %t455, true
  br i1 %t457, label %bb130, label %bb131
bb130:
  %t459 = load ptr, ptr %l0, !tbaa !29
  store ptr %t459, ptr %l262, !tbaa !29
  %t460 = load ptr, ptr %l1, !tbaa !29
  %t462 = icmp eq ptr %t460, null
  br i1 %t462, label %bb132, label %bb133
bb131:
  store i1 false, ptr %l261, !tbaa !21
  br label %bb136
bb132:
  call void @__olang_check_failed(ptr @olang_loc_c2f9290c57ed376d_cbd7590e0cb57901)
  unreachable
bb133:
  br label %bb134
bb134:
  %t464 = load ptr, ptr %l1, !tbaa !29
  %t465 = load ptr, ptr %l262, !tbaa !29
  %t467 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erunArrayParam(ptr %v0, ptr %v0, ptr %t465, ptr %t464)
  store i1 %t467, ptr %l266
  br label %bb135
bb135:
  %t468 = load i1, ptr %l266, !tbaa !21
  store i1 %t468, ptr %l261, !tbaa !21
  br label %bb136
bb136:
  %t469 = load i1, ptr %l261, !tbaa !21
  br i1 %t469, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s18
  call void @olang_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %t470, ptr %s18)
  call void @llvm.memmove.p0.p0.i64(ptr %l267, ptr %t470, i64 224, i1 false)
  br label %bb139
bb138:
  br label %bb207
bb139:
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %l267, i64 224, i1 false)
  %t471 = load ptr, ptr %l1, !tbaa !29
  %t473 = icmp eq ptr %t471, null
  br i1 %t473, label %bb140, label %bb141
bb140:
  call void @__olang_check_failed(ptr @olang_loc_c0d893db7e601486_f2e0d00716145a7a)
  unreachable
bb141:
  br label %bb142
bb142:
  %t475 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr %"compiler/typed:Body", ptr %t475, i32 0, i32 11
  %t479 = load ptr, ptr %t478, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %s18, ptr %t479, ptr %l26)
  br label %bb143
bb143:
  %t482 = load ptr, ptr %l1, !tbaa !29
  %t484 = icmp eq ptr %t482, null
  br i1 %t484, label %bb144, label %bb145
bb144:
  call void @__olang_check_failed(ptr @olang_loc_dcd7e57cabd1f877_41684d2a22884c3b)
  unreachable
bb145:
  br label %bb146
bb146:
  %t486 = load ptr, ptr %l1, !tbaa !29
  %t489 = getelementptr %"compiler/typed:Body", ptr %t486, i32 0, i32 5
  store ptr %t489, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb147
bb147:
  %t491 = load i64, ptr %l28, !tbaa !24
  store i64 %t491, ptr %l279, !tbaa !24
  %t492 = load ptr, ptr %l27, !tbaa !29
  %t494 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t492)
  store i64 %t494, ptr %l281
  br label %bb148
bb148:
  %t495 = load i64, ptr %l279, !tbaa !24
  %t496 = load i64, ptr %l281, !tbaa !24
  %t497 = icmp slt i64 %t495, %t496
  %t499 = xor i1 %t497, true
  br i1 %t499, label %bb149, label %bb150
bb149:
  br label %bb206
bb150:
  br label %bb151
bb151:
  %t501 = load ptr, ptr %l27, !tbaa !29
  %t502 = load i64, ptr %l28, !tbaa !24
  %t505 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t501, i64 %t502)
  store i32 %t505, ptr %l286
  br label %bb152
bb152:
  %t506 = load i32, ptr %l286, !tbaa !23
  store i32 %t506, ptr %l29, !tbaa !23
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/scope:Scoper", ptr %t507, i32 0, i32 0
  %t510 = load ptr, ptr %t509, !tbaa !29
  %t512 = getelementptr %"compiler/generic:Program", ptr %t510, i32 0, i32 2
  store ptr %t512, ptr %l289, !tbaa !29
  %t513 = load ptr, ptr %l1, !tbaa !29
  %t515 = icmp eq ptr %t513, null
  br i1 %t515, label %bb153, label %bb154
bb153:
  call void @__olang_check_failed(ptr @olang_loc_1d5cd0d51560a858_414b0c179bc0efcc)
  unreachable
bb154:
  br label %bb155
bb155:
  %t517 = load ptr, ptr %l1, !tbaa !29
  %t520 = getelementptr %"compiler/typed:Body", ptr %t517, i32 0, i32 7
  %t521 = load i32, ptr %l29, !tbaa !23
  %t523 = sext i32 %t521 to i64
  %t526 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t520, i64 %t523)
  store %"compiler/typed:Local" %t526, ptr %l297
  br label %bb156
bb156:
  %t527 = getelementptr %"compiler/typed:Local", ptr %l297, i32 0, i32 2
  %t528 = load i32, ptr %t527, !tbaa !23
  %t529 = load ptr, ptr %l289, !tbaa !29
  %t531 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t529, i32 %t528)
  store i32 %t531, ptr %l299
  br label %bb157
bb157:
  %t532 = load i32, ptr %l299, !tbaa !23
  store i32 %t532, ptr %l30, !tbaa !23
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load i32, ptr %l30, !tbaa !23
  %t537 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t533, i32 %t534)
  store i1 %t537, ptr %l302
  br label %bb158
bb158:
  %t538 = load i1, ptr %l302, !tbaa !21
  br i1 %t538, label %bb159, label %bb160
bb159:
  store i1 true, ptr %l303, !tbaa !21
  br label %bb162
bb160:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t541 = getelementptr %"compiler/scope:Scoper", ptr %t539, i32 0, i32 0
  %t542 = load ptr, ptr %t541, !tbaa !29
  %t544 = getelementptr %"compiler/generic:Program", ptr %t542, i32 0, i32 2
  %t545 = load i32, ptr %l30, !tbaa !23
  %t548 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t544, i32 %t545)
  store i32 %t548, ptr %l308
  br label %bb161
bb161:
  %t549 = load i32, ptr %l308, !range !{i32 0, i32 33}
  %t551 = trunc i64 19 to i32
  %t552 = icmp eq i32 %t549, %t551
  %t554 = xor i1 %t552, true
  store i1 %t554, ptr %l303, !tbaa !21
  br label %bb162
bb162:
  %t556 = load i1, ptr %l303, !tbaa !21
  br i1 %t556, label %bb163, label %bb164
bb163:
  store i1 true, ptr %l312, !tbaa !21
  br label %bb166
bb164:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t559 = getelementptr %"compiler/scope:Scoper", ptr %t557, i32 0, i32 0
  %t560 = load ptr, ptr %t559, !tbaa !29
  %t562 = getelementptr %"compiler/generic:Program", ptr %t560, i32 0, i32 2
  %t563 = load i32, ptr %l30, !tbaa !23
  %t566 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t562, i32 %t563)
  store i32 %t566, ptr %l317
  br label %bb165
bb165:
  %t567 = load i32, ptr %l317, !tbaa !23
  %t568 = icmp ne i32 %t567, 0
  store i1 %t568, ptr %l312, !tbaa !21
  br label %bb166
bb166:
  %t570 = load i1, ptr %l312, !tbaa !21
  br i1 %t570, label %bb167, label %bb168
bb167:
  br label %bb205
bb168:
  br label %bb169
bb169:
  %t571 = getelementptr %"compiler/scope:walked", ptr %l26, i32 0, i32 1
  %t572 = load i32, ptr %l29, !tbaa !23
  %t574 = sext i32 %t572 to i64
  %t577 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s18, ptr %t571, i64 %t574)
  store i1 %t577, ptr %l322
  br label %bb170
bb170:
  %t578 = load i1, ptr %l322, !tbaa !21
  br i1 %t578, label %bb171, label %bb172
bb171:
  store i1 true, ptr %l323, !tbaa !21
  br label %bb174
bb172:
  %t579 = getelementptr %"compiler/scope:walked", ptr %l26, i32 0, i32 4
  %t580 = load i32, ptr %l29, !tbaa !23
  %t582 = sext i32 %t580 to i64
  %t585 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s18, ptr %t579, i64 %t582)
  store i1 %t585, ptr %l327
  br label %bb173
bb173:
  %t586 = load i1, ptr %l327, !tbaa !21
  store i1 %t586, ptr %l323, !tbaa !21
  br label %bb174
bb174:
  %t587 = load i1, ptr %l323, !tbaa !21
  store i1 %t587, ptr %l31, !tbaa !21
  store i64 0, ptr %l32, !tbaa !24
  %t588 = getelementptr %"compiler/scope:walked", ptr %l26, i32 0, i32 2
  %t590 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %t588)
  store i64 %t590, ptr %l329
  br label %bb175
bb175:
  %t591 = load i64, ptr %l329, !tbaa !24
  store i64 %t591, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t592 = load i64, ptr %l33, !tbaa !24
  %t593 = load i64, ptr %l32, !tbaa !24
  %t596 = icmp sgt i64 %t592, %t593
  br i1 %t596, label %bb176, label %bb177
bb176:
  %t598 = load i64, ptr %l34, !tbaa !24
  %t600 = icmp sgt i64 %t598, 0
  br i1 %t600, label %bb178, label %bb179
bb177:
  store i64 0, ptr %l333, !tbaa !24
  br label %bb181
bb178:
  %t602 = load i64, ptr %l33, !tbaa !24
  %t603 = load i64, ptr %l32, !tbaa !24
  %t606 = sub i64 %t602, %t603
  %t607 = load i64, ptr %l34, !tbaa !24
  %t610 = add i64 %t606, %t607
  %t612 = sub i64 %t610, 1
  %t613 = load i64, ptr %l34, !tbaa !24
  %t616 = sdiv i64 %t612, %t613
  store i64 %t616, ptr %l336, !tbaa !24
  br label %bb180
bb179:
  store i64 0, ptr %l336, !tbaa !24
  br label %bb180
bb180:
  %t618 = load i64, ptr %l336, !tbaa !24
  store i64 %t618, ptr %l333, !tbaa !24
  br label %bb181
bb181:
  %t619 = load i64, ptr %l333, !tbaa !24
  store i64 %t619, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb182
bb182:
  %t620 = load i64, ptr %l36, !tbaa !24
  %t621 = load i64, ptr %l35, !tbaa !24
  %t624 = icmp slt i64 %t620, %t621
  %t626 = xor i1 %t624, true
  br i1 %t626, label %bb183, label %bb184
bb183:
  br label %bb200
bb184:
  br label %bb185
bb185:
  %t628 = load i64, ptr %l32, !tbaa !24
  %t629 = load i64, ptr %l36, !tbaa !24
  %t630 = load i64, ptr %l34, !tbaa !24
  %t633 = mul i64 %t629, %t630
  %t636 = add i64 %t628, %t633
  store i64 %t636, ptr %l37, !tbaa !24
  %t638 = getelementptr %"compiler/scope:walked", ptr %l26, i32 0, i32 2
  %t639 = load i64, ptr %l37, !tbaa !24
  %t642 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %t638, i64 %t639)
  store i64 %t642, ptr %l356
  br label %bb186
bb186:
  %t643 = load i32, ptr %l29, !tbaa !23
  %t645 = sext i32 %t643 to i64
  %t646 = load i64, ptr %l356, !tbaa !24
  %t648 = icmp ne i64 %t646, %t645
  br i1 %t648, label %bb187, label %bb188
bb187:
  br label %bb199
bb188:
  br label %bb189
bb189:
  %t650 = getelementptr %"compiler/scope:walked", ptr %l26, i32 0, i32 3
  %t651 = load i64, ptr %l37, !tbaa !24
  %t654 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s18, ptr %t650, i64 %t651)
  store i32 %t654, ptr %l362
  br label %bb190
bb190:
  %t655 = load i32, ptr %l362, !tbaa !23
  store i32 %t655, ptr %l38, !tbaa !23
  %t656 = load i32, ptr %l38, !tbaa !23
  %t658 = icmp eq i32 %t656, 0
  br i1 %t658, label %bb191, label %bb192
bb191:
  store i1 true, ptr %l365, !tbaa !21
  br label %bb195
bb192:
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t662 = getelementptr %"compiler/scope:Scoper", ptr %t660, i32 0, i32 0
  %t663 = load ptr, ptr %t662, !tbaa !29
  %t665 = getelementptr %"compiler/generic:Program", ptr %t663, i32 0, i32 2
  store ptr %t665, ptr %l368, !tbaa !29
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t668 = getelementptr %"compiler/scope:Scoper", ptr %t666, i32 0, i32 0
  %t669 = load ptr, ptr %t668, !tbaa !29
  %t671 = getelementptr %"compiler/generic:Program", ptr %t669, i32 0, i32 2
  %t672 = load i32, ptr %l38, !tbaa !23
  %t675 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t671, i32 %t672)
  store i32 %t675, ptr %l373
  br label %bb193
bb193:
  %t676 = load ptr, ptr %l368, !tbaa !29
  %t677 = load i32, ptr %l373, !tbaa !23
  %t678 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t676, i32 %t677)
  store i64 %t678, ptr %l374
  br label %bb194
bb194:
  %t679 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t680 = load i64, ptr %l374, !tbaa !24
  %t682 = and i64 %t680, %t679
  %t684 = icmp ne i64 %t682, 0
  store i1 %t684, ptr %l365, !tbaa !21
  br label %bb195
bb195:
  %t686 = load i1, ptr %l365, !tbaa !21
  br i1 %t686, label %bb196, label %bb197
bb196:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb198
bb197:
  br label %bb198
bb198:
  br label %bb199
bb199:
  %t687 = load i64, ptr %l36, !tbaa !24
  %t689 = add i64 %t687, 1
  store i64 %t689, ptr %l36, !tbaa !24
  br label %bb182
bb200:
  %t691 = load i1, ptr %l31, !tbaa !21
  br i1 %t691, label %bb201, label %bb202
bb201:
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t695 = getelementptr %"compiler/scope:Scoper", ptr %t693, i32 0, i32 33
  %t696 = load i32, ptr %l29, !tbaa !23
  %t698 = sext i32 %t696 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t695, i64 %t698, i1 true)
  br label %bb203
bb202:
  br label %bb204
bb203:
  br label %bb204
bb204:
  br label %bb205
bb205:
  %t701 = load i64, ptr %l28, !tbaa !24
  %t703 = add i64 %t701, 1
  store i64 %t703, ptr %l28, !tbaa !24
  br label %bb147
bb206:
  call void @__olang_scope_close(ptr %s18)
  br label %bb207
bb207:
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t707 = getelementptr %"compiler/scope:Scoper", ptr %t705, i32 0, i32 34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t707, i32 0)
  br label %bb208
bb208:
  %t709 = load ptr, ptr %l0, !tbaa !29
  store ptr %t709, ptr %l389, !tbaa !29
  %t710 = load ptr, ptr %l1, !tbaa !29
  %t712 = icmp eq ptr %t710, null
  br i1 %t712, label %bb209, label %bb210
bb209:
  call void @__olang_check_failed(ptr @olang_loc_83cb1a0080c88b91_4687383f0631b81d)
  unreachable
bb210:
  br label %bb211
bb211:
  %t714 = load ptr, ptr %l1, !tbaa !29
  %t717 = getelementptr %"compiler/typed:Body", ptr %t714, i32 0, i32 11
  %t718 = load ptr, ptr %t717, !tbaa !29
  store ptr %t718, ptr %l39, !tbaa !29
  %t720 = load ptr, ptr %l39, !tbaa !29
  %t722 = icmp eq ptr %t720, null
  br i1 %t722, label %bb212, label %bb213
bb212:
  call void @__olang_check_failed(ptr @olang_loc_83cb1a0080c88b91_4687383f0631b81d)
  unreachable
bb213:
  br label %bb214
bb214:
  %t724 = load ptr, ptr %l39, !tbaa !29
  %t727 = getelementptr %"compiler/typed:Block", ptr %t724, i32 0, i32 1
  %t728 = load { i64, ptr }, ptr %t727, !tbaa !27
  %t729 = load ptr, ptr %l389, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v0, ptr %t729, { i64, ptr } %t728)
  br label %bb215
bb215:
  %t731 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandHeld(ptr %v0, ptr %t731)
  br label %bb216
bb216:
  %t733 = load ptr, ptr %l0, !tbaa !29
  %t735 = getelementptr %"compiler/scope:Scoper", ptr %t733, i32 0, i32 34
  %t737 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t735)
  %t738 = extractvalue { i32, i32 } %t737, 1
  %t739 = extractvalue { i32, i32 } %t737, 0
  store i32 %t739, ptr %l405
  %t740 = icmp ne i32 %t739, 0
  br i1 %t740, label %bb218, label %ok.741, !prof !99
ok.741:
  store i32 %t738, ptr %l404
  br label %bb217
bb217:
  %t742 = load i32, ptr %l404, !tbaa !23
  store i32 %t742, ptr %l401, !tbaa !23
  br label %bb220
bb218:
  br label %bb219
bb219:
  call void @__olang_ert_req_clear()
  br label %bb220
bb220:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erunArrayParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i32
  %l18 = alloca ptr
  %l23 = alloca %"compiler/typed:Local"
  %l25 = alloca i32
  %l28 = alloca i1
  %l30 = alloca i1
  %l35 = alloca i32
  %l38 = alloca i1
  %l43 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 5
  store ptr %t3, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb22
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t15, i64 %t16)
  store i32 %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load i32, ptr %l15, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Body", ptr %t27, i32 0, i32 7
  %t32 = sext i32 %t20 to i64
  %t35 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t29, i64 %t32)
  store %"compiler/typed:Local" %t35, ptr %l23
  br label %bb7
bb7:
  %t36 = getelementptr %"compiler/typed:Local", ptr %l23, i32 0, i32 2
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t38, i32 %t37)
  store i32 %t40, ptr %l25
  br label %bb8
bb8:
  %t41 = load i32, ptr %l25, !tbaa !23
  store i32 %t41, ptr %l5, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l5, !tbaa !23
  %t46 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l28
  br label %bb9
bb9:
  %t47 = load i1, ptr %l28, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/scope:Scoper", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l5, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l35
  br label %bb12
bb11:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb13
bb12:
  %t60 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t62 = trunc i64 19 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb13
bb13:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l5, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l43
  br label %bb16
bb15:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb17
bb16:
  %t76 = load i32, ptr %l43, !tbaa !23
  %t77 = icmp eq i32 %t76, 0
  store i1 %t77, ptr %l38, !tbaa !21
  br label %bb17
bb17:
  %t79 = load i1, ptr %l38, !tbaa !21
  br i1 %t79, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t81 = load i64, ptr %l3, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l3, !tbaa !24
  br label %bb1
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = add i64 %t1, 1
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 36
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/scope:Scoper", ptr %t13, i32 0, i32 36
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = add i64 %t16, 1
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t15, i64 %t18)
  store i64 %t21, ptr %l13
  br label %bb4
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 37
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l16
  br label %bb5
bb4:
  %t27 = load i64, ptr %l13, !tbaa !24
  store i64 %t27, ptr %l8, !tbaa !24
  br label %bb6
bb5:
  %t28 = load i64, ptr %l16, !tbaa !24
  store i64 %t28, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t29 = load i64, ptr %l8, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eshownLocal(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:Local"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i1
  %l30 = alloca %"compiler/typed:Local"
  %l42 = alloca i1
  %l45 = alloca i1
  %l46 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i32
  %l55 = alloca ptr
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l65 = alloca i1
  %l70 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i1
  %l77 = alloca i1
  %l78 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l86 = alloca i64
  %l89 = alloca i64
  %l95 = alloca i64
  %l101 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i32
  %l110 = alloca i64
  %l113 = alloca i64
  %l137 = alloca ptr
  %l141 = alloca ptr
  %l144 = alloca i1
  %l149 = alloca i1
  %l152 = alloca i1
  %l153 = alloca i1
  %l156 = alloca i1
  %l159 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l166 = alloca i64
  %l169 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t5, 16
  store i1 %t7, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_e68b15b11e0abafb_13fbbcd2ac59787f)
  unreachable
bb8:
  br label %bb9
bb9:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t18, i32 0, i32 25
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 7
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t24, i64 %t25)
  store %"compiler/typed:Local" %t28, ptr %l30
  br label %bb10
bb10:
  %t29 = load %"compiler/typed:Local", ptr %l30
  store %"compiler/typed:Local" %t29, ptr %l3
  %t30 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t31 = load i32, ptr %t30, !range !{i32 0, i32 7}
  store i32 %t31, ptr %l4
  %t33 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t35 = trunc i64 1 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb11, label %bb12
bb11:
  br label %bb19
bb12:
  %t38 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t40 = trunc i64 0 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  %t43 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t45 = trunc i64 4 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  %t48 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t50 = trunc i64 6 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb59
bb19:
  %t53 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t54 = load i32, ptr %t53, !range !{i32 0, i32 7}
  %t56 = trunc i64 1 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t59, i32 %t61)
  store i1 %t64, ptr %l45
  br label %bb22
bb21:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb23
bb22:
  %t65 = load i1, ptr %l45, !tbaa !21
  store i1 %t65, ptr %l42, !tbaa !21
  br label %bb23
bb23:
  %t66 = load i1, ptr %l42, !tbaa !21
  br i1 %t66, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/scope:Scoper", ptr %t67, i32 0, i32 42
  %t70 = load i64, ptr %l1, !tbaa !24
  %t73 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  %t74 = extractvalue { i32, ptr } %t73, 1
  %t75 = extractvalue { i32, ptr } %t73, 0
  store i32 %t75, ptr %l51
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb27, label %ok.77, !prof !99
ok.77:
  store ptr %t74, ptr %l50
  br label %bb26
bb25:
  br label %bb55
bb26:
  %t78 = load ptr, ptr %l50, !tbaa !29
  store ptr %t78, ptr %l46, !tbaa !29
  br label %bb29
bb27:
  br label %bb28
bb28:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l46, !tbaa !29
  br label %bb29
bb29:
  %t79 = load ptr, ptr %l46, !tbaa !29
  store ptr %t79, ptr %l5, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb30, label %bb31
bb30:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l5, !tbaa !29
  %t91 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v0, ptr %s3, ptr %t86, ptr %t87)
  store ptr %t91, ptr %l59
  br label %bb32
bb31:
  store ptr null, ptr %l55, !tbaa !29
  br label %bb34
bb32:
  %t92 = load ptr, ptr %l59, !tbaa !29
  %t94 = call ptr @compiler_2ftyped_2eCallOf(ptr %s3, ptr %s3, ptr %t92)
  store ptr %t94, ptr %l61
  br label %bb33
bb33:
  %t95 = load ptr, ptr %l61, !tbaa !29
  store ptr %t95, ptr %l55, !tbaa !29
  br label %bb34
bb34:
  %t96 = load ptr, ptr %l55, !tbaa !29
  store ptr %t96, ptr %l6, !tbaa !29
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t99 = icmp eq ptr %t97, null
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb35, label %bb36
bb35:
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Call", ptr %t103, i32 0, i32 1
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t110 = icmp sgt i64 %t108, 0
  store i1 %t110, ptr %l65, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb37
bb37:
  %t112 = load i1, ptr %l65, !tbaa !21
  br i1 %t112, label %bb38, label %bb39
bb38:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t117 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %s3, ptr %t113, ptr %t114)
  store i1 %t117, ptr %l73
  br label %bb40
bb39:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb45
bb40:
  %t118 = load i1, ptr %l73, !tbaa !21
  br i1 %t118, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb44
bb42:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l6, !tbaa !29
  %t123 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %s3, ptr %t119, ptr %t120)
  store i1 %t123, ptr %l77
  br label %bb43
bb43:
  %t124 = load i1, ptr %l77, !tbaa !21
  store i1 %t124, ptr %l74, !tbaa !21
  br label %bb44
bb44:
  %t125 = load i1, ptr %l74, !tbaa !21
  store i1 %t125, ptr %l70, !tbaa !21
  br label %bb45
bb45:
  %t126 = load i1, ptr %l70, !tbaa !21
  br i1 %t126, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s4
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l78, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l6, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Call", ptr %t129, i32 0, i32 1
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l81, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr ptr, ptr %t134, i64 0
  %t136 = load ptr, ptr %t135, !tbaa !39
  %t140 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %s3, ptr %s4, ptr %t128, ptr %t136)
  store ptr %t140, ptr %l84
  br label %bb48
bb47:
  br label %bb54
bb48:
  %t141 = load ptr, ptr %l84, !tbaa !29
  %t143 = call i64 @compiler_2fscope_2eflRootExpr(ptr %s4, ptr %t141)
  store i64 %t143, ptr %l86
  br label %bb49
bb49:
  %t144 = load i64, ptr %l2, !tbaa !24
  %t146 = add i64 %t144, 1
  %t147 = load ptr, ptr %l78, !tbaa !29
  %t148 = load i64, ptr %l86, !tbaa !24
  %t150 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eshownLocal(ptr %v0, ptr %t147, i64 %t148, i64 %t146)
  store i64 %t150, ptr %l89
  br label %bb50
bb50:
  %t151 = load i64, ptr %l89, !tbaa !24
  store i64 %t151, ptr %l7, !tbaa !24
  %t152 = load i64, ptr %l7, !tbaa !24
  %t154 = icmp sge i64 %t152, 0
  br i1 %t154, label %bb51, label %bb52
bb51:
  %t156 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i64 %t156, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb55:
  %t158 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 0
  %t159 = load i32, ptr %t158, !tbaa !23
  %t161 = icmp ne i32 %t159, 0
  br i1 %t161, label %bb56, label %bb57
bb56:
  %t163 = load i64, ptr %l1, !tbaa !24
  store i64 %t163, ptr %l95, !tbaa !24
  br label %bb58
bb57:
  store i64 -1, ptr %l95, !tbaa !24
  br label %bb58
bb58:
  %t165 = load i64, ptr %l95, !tbaa !24
  store i64 %t165, ptr %rv
  br label %ret
bb59:
  %t166 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t168 = trunc i64 3 to i32
  %t169 = icmp eq i32 %t166, %t168
  br i1 %t169, label %bb60, label %bb61
bb60:
  br label %bb64
bb61:
  %t171 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t173 = trunc i64 2 to i32
  %t174 = icmp eq i32 %t171, %t173
  br i1 %t174, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb102
bb64:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/scope:Scoper", ptr %t176, i32 0, i32 42
  %t179 = load i64, ptr %l1, !tbaa !24
  %t182 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t178, i64 %t179)
  %t183 = extractvalue { i32, ptr } %t182, 1
  %t184 = extractvalue { i32, ptr } %t182, 0
  store i32 %t184, ptr %l106
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb66, label %ok.186, !prof !99
ok.186:
  store ptr %t183, ptr %l105
  br label %bb65
bb65:
  %t187 = load ptr, ptr %l105, !tbaa !29
  store ptr %t187, ptr %l101, !tbaa !29
  br label %bb68
bb66:
  br label %bb67
bb67:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l101, !tbaa !29
  br label %bb68
bb68:
  %t188 = load ptr, ptr %l101, !tbaa !29
  store ptr %t188, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  store i64 16, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t189 = load i64, ptr %l10, !tbaa !24
  %t190 = load i64, ptr %l9, !tbaa !24
  %t193 = icmp sgt i64 %t189, %t190
  br i1 %t193, label %bb69, label %bb70
bb69:
  %t195 = load i64, ptr %l11, !tbaa !24
  %t197 = icmp sgt i64 %t195, 0
  br i1 %t197, label %bb71, label %bb72
bb70:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb74
bb71:
  %t199 = load i64, ptr %l10, !tbaa !24
  %t200 = load i64, ptr %l9, !tbaa !24
  %t203 = sub i64 %t199, %t200
  %t204 = load i64, ptr %l11, !tbaa !24
  %t207 = add i64 %t203, %t204
  %t209 = sub i64 %t207, 1
  %t210 = load i64, ptr %l11, !tbaa !24
  %t213 = sdiv i64 %t209, %t210
  store i64 %t213, ptr %l113, !tbaa !24
  br label %bb73
bb72:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb73
bb73:
  %t215 = load i64, ptr %l113, !tbaa !24
  store i64 %t215, ptr %l110, !tbaa !24
  br label %bb74
bb74:
  %t216 = load i64, ptr %l110, !tbaa !24
  store i64 %t216, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb75
bb75:
  %t217 = load i64, ptr %l13, !tbaa !24
  %t218 = load i64, ptr %l12, !tbaa !24
  %t221 = icmp slt i64 %t217, %t218
  %t223 = xor i1 %t221, true
  br i1 %t223, label %bb76, label %bb77
bb76:
  br label %bb99
bb77:
  br label %bb78
bb78:
  %t225 = load i64, ptr %l9, !tbaa !24
  %t226 = load i64, ptr %l13, !tbaa !24
  %t227 = load i64, ptr %l11, !tbaa !24
  %t230 = mul i64 %t226, %t227
  %t233 = add i64 %t225, %t230
  store i64 %t233, ptr %l14, !tbaa !24
  %t235 = load ptr, ptr %l8, !tbaa !29
  %t237 = icmp eq ptr %t235, null
  br i1 %t237, label %bb79, label %bb80
bb79:
  store i64 -1, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l8, !tbaa !29
  %t245 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v0, ptr %v0, ptr %t240, ptr %t241)
  store ptr %t245, ptr %l137
  br label %bb82
bb82:
  %t246 = load ptr, ptr %l137, !tbaa !29
  store ptr %t246, ptr %l8, !tbaa !29
  %t248 = load ptr, ptr %l8, !tbaa !29
  %t251 = call ptr @compiler_2ftyped_2eCallOf(ptr %v0, ptr %v0, ptr %t248)
  store ptr %t251, ptr %l141
  br label %bb83
bb83:
  %t252 = load ptr, ptr %l141, !tbaa !29
  store ptr %t252, ptr %l15, !tbaa !29
  %t253 = load ptr, ptr %l15, !tbaa !29
  %t255 = icmp eq ptr %t253, null
  br i1 %t255, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb86
bb85:
  %t257 = load ptr, ptr %l15, !tbaa !29
  %t259 = getelementptr %"compiler/typed:Call", ptr %t257, i32 0, i32 1
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t264 = icmp eq i64 %t262, 0
  store i1 %t264, ptr %l144, !tbaa !21
  br label %bb86
bb86:
  %t266 = load i1, ptr %l144, !tbaa !21
  br i1 %t266, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l149, !tbaa !21
  br label %bb94
bb88:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load ptr, ptr %l15, !tbaa !29
  %t271 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %v0, ptr %t267, ptr %t268)
  store i1 %t271, ptr %l152
  br label %bb89
bb89:
  %t272 = load i1, ptr %l152, !tbaa !21
  br i1 %t272, label %bb90, label %bb91
bb90:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb93
bb91:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l15, !tbaa !29
  %t277 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %v0, ptr %t273, ptr %t274)
  store i1 %t277, ptr %l156
  br label %bb92
bb92:
  %t278 = load i1, ptr %l156, !tbaa !21
  store i1 %t278, ptr %l153, !tbaa !21
  br label %bb93
bb93:
  %t279 = load i1, ptr %l153, !tbaa !21
  %t280 = xor i1 %t279, true
  store i1 %t280, ptr %l149, !tbaa !21
  br label %bb94
bb94:
  %t282 = load i1, ptr %l149, !tbaa !21
  br i1 %t282, label %bb95, label %bb96
bb95:
  br label %bb99
bb96:
  br label %bb97
bb97:
  %t283 = load ptr, ptr %l15, !tbaa !29
  %t285 = getelementptr %"compiler/typed:Call", ptr %t283, i32 0, i32 1
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  store { i64, ptr } %t286, ptr %l159, !tbaa !27
  %t287 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr ptr, ptr %t288, i64 0
  %t290 = load ptr, ptr %t289, !tbaa !39
  store ptr %t290, ptr %l8, !tbaa !29
  br label %bb98
bb98:
  %t293 = load i64, ptr %l13, !tbaa !24
  %t295 = add i64 %t293, 1
  store i64 %t295, ptr %l13, !tbaa !24
  br label %bb75
bb99:
  %t297 = load ptr, ptr %l0, !tbaa !29
  store ptr %t297, ptr %l164, !tbaa !29
  %t298 = load ptr, ptr %l8, !tbaa !29
  %t300 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %t298)
  store i64 %t300, ptr %l166
  br label %bb100
bb100:
  %t301 = load i64, ptr %l2, !tbaa !24
  %t303 = add i64 %t301, 1
  %t304 = load ptr, ptr %l164, !tbaa !29
  %t305 = load i64, ptr %l166, !tbaa !24
  %t307 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eshownLocal(ptr %v0, ptr %t304, i64 %t305, i64 %t303)
  store i64 %t307, ptr %l169
  br label %bb101
bb101:
  %t308 = load i64, ptr %l169, !tbaa !24
  store i64 %t308, ptr %rv
  br label %ret
bb102:
  br i1 true, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  store i64 -1, ptr %rv
  br label %ret
bb106:
  call void @__olang_check_failed(ptr @olang_loc_5026d552222f1723_4b71b7547c4744a7)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esiteLift(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l4 = alloca ptr
  %l8 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t20 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 128
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 26
  %t7 = load i64, ptr %t6, !tbaa !24
  %t11 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t7, i64 %a1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t14 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H568ce559fa980123a387c6ba9ed21aca(ptr %v0, ptr %t12, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t13)
  %t15 = extractvalue { i32, { i64, [2 x i64] } } %t14, 1
  %t16 = extractvalue { i32, { i64, [2 x i64] } } %t14, 0
  store i32 %t16, ptr %l10
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18, !prof !99
ok.18:
  store { i64, [2 x i64] } %t15, ptr %l9
  br label %bb2
bb2:
  %t19 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t19, ptr %l2
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store { i64, [2 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 0
  store i64 0, ptr %t21
  %t22 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t22, ptr %l2
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t24, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l23 = alloca { i64, [2 x i64] }
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, [2 x i64] }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t31 = alloca { i64, [2 x i64] }, align 8
  %t104 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t17)
  store i32 %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i1, ptr %l15, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t26)
  store i1 %t28, ptr %l19
  br label %bb10
bb10:
  %t29 = load i1, ptr %l19, !tbaa !21
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  store { i64, [2 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t33 = load { i64, [2 x i64] }, ptr %t31
  store { i64, [2 x i64] } %t33, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t39 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t35, ptr %t36, i1 true)
  store { i64, [2 x i64] } %t39, ptr %l23
  br label %bb15
bb15:
  %t40 = load { i64, [2 x i64] }, ptr %l23
  store { i64, [2 x i64] } %t40, ptr %rv
  br label %ret
bb16:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb17, label %bb18
bb17:
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 18}
  %t48 = icmp eq i64 %t46, 9
  store i1 %t48, ptr %l25, !tbaa !21
  br label %bb18
bb18:
  %t49 = load i1, ptr %l25, !tbaa !21
  br i1 %t49, label %bb19, label %bb20
bb19:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t52, i32 0, i32 2
  %t54 = load i32, ptr %t53, !range !{i32 0, i32 43}
  store i32 %t54, ptr %l3
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t58, i32 0, i32 4
  %t60 = load { i64, ptr }, ptr %t59
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  br label %bb21
bb20:
  br label %bb30
bb21:
  %t62 = load i32, ptr %l3, !range !{i32 0, i32 43}
  %t64 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t62)
  store i1 %t64, ptr %l33
  br label %bb22
bb22:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t70 = icmp sgt i64 %t68, 0
  store i1 %t70, ptr %l34, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb25
bb25:
  %t72 = load i1, ptr %l34, !tbaa !21
  br i1 %t72, label %bb26, label %bb27
bb26:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t74, ptr %l39, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 0
  %t78 = load ptr, ptr %t77, !tbaa !39
  %t81 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %t73, ptr %t78)
  store { i64, [2 x i64] } %t81, ptr %l41
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t82 = load { i64, [2 x i64] }, ptr %l41
  store { i64, [2 x i64] } %t82, ptr %rv
  br label %ret
bb29:
  br label %bb42
bb30:
  %t83 = load ptr, ptr %l1, !tbaa !29
  store ptr %t83, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t84 = load ptr, ptr %l42, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb31, label %bb32
bb31:
  %t87 = load ptr, ptr %l42, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 18}
  %t90 = icmp eq i64 %t88, 17
  store i1 %t90, ptr %l43, !tbaa !21
  br label %bb32
bb32:
  %t91 = load i1, ptr %l43, !tbaa !21
  br i1 %t91, label %bb33, label %bb34
bb33:
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t94, i32 0, i32 2
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l5, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t102 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %t98, ptr %t99)
  store { i64, [2 x i64] } %t102, ptr %l50
  br label %bb36
bb36:
  %t103 = load { i64, [2 x i64] }, ptr %l50
  store { i64, [2 x i64] } %t103, ptr %rv
  br label %ret
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_9da86a51b48ec4c_4c8b634b3e5eba18)
  unreachable
bb42:
  store { i64, [2 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [2 x i64] }, ptr %t104, i32 0, i32 0
  store i64 0, ptr %t105
  %t106 = load { i64, [2 x i64] }, ptr %t104
  store { i64, [2 x i64] } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefused(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/msgs:Msg"
  %l15 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/msgs:Msg"
  %l21 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eatPart(ptr %v0, ptr %v1, ptr %v1, ptr %t1, ptr %t2)
  store ptr %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t15)
  store %"compiler/source:Span" %t17, ptr %l12
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l16, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t23 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v1, ptr %t19, ptr %t20)
  store %"compiler/source:Span" %t23, ptr %l19
  br label %bb8
bb4:
  %t24 = load ptr, ptr %l10, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l12
  %t26 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t24, %"compiler/source:Span" %t25)
  store %"compiler/source:Span" %t26, ptr %l13
  br label %bb5
bb5:
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtBuilds(ptr %s1)
  store %"compiler/msgs:Msg" %t27, ptr %l14
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l9, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l13
  %t30 = load %"compiler/msgs:Msg", ptr %l14
  %t31 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s1, ptr %t28, %"compiler/source:Span" %t29, %"compiler/msgs:Msg" %t30)
  store i64 %t31, ptr %l15
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb8:
  %t32 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBorrowSplitScopes(ptr %s2)
  store %"compiler/msgs:Msg" %t32, ptr %l20
  br label %bb9
bb9:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l19
  %t35 = load %"compiler/msgs:Msg", ptr %l20
  %t36 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s2, ptr %t33, %"compiler/source:Span" %t34, %"compiler/msgs:Msg" %t35)
  store i64 %t36, ptr %l21
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l25 = alloca i32
  %l29 = alloca i1
  %l34 = alloca i64
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l52 = alloca i1
  %l56 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [5 x i64] }, ptr %t13, i32 0, i32 1
  %t16 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  store %"compiler/source:Span" %t17, ptr %l2
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l4, !tbaa !29
  store i32 %t23, ptr %l5, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l5, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l25
  br label %bb6
bb6:
  %t43 = load i32, ptr %l25, !range !{i32 0, i32 33}
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb10
bb8:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/scope:Scoper", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l5, !tbaa !23
  %t59 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t55, i32 %t56)
  store i64 %t59, ptr %l34
  br label %bb9
bb9:
  %t60 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t61 = load i64, ptr %l34, !tbaa !24
  %t63 = and i64 %t61, %t60
  %t65 = icmp ne i64 %t63, 0
  store i1 %t65, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t67 = load i1, ptr %l29, !tbaa !21
  br i1 %t67, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Promote", ptr %t69, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  store ptr %t73, ptr %l6, !tbaa !29
  %t75 = load ptr, ptr %l6, !tbaa !29
  store ptr %t75, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t76 = load ptr, ptr %l43, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb14, label %bb15
bb14:
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 18}
  %t82 = icmp eq i64 %t80, 7
  store i1 %t82, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t83 = load i1, ptr %l44, !tbaa !21
  br i1 %t83, label %bb16, label %bb17
bb16:
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l7, !tbaa !29
  br label %bb18
bb17:
  br label %bb23
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t90 = load ptr, ptr %l7, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Make", ptr %t90, i32 0, i32 0
  %t93 = load i32, ptr %t92, !range !{i32 0, i32 5}
  %t95 = trunc i64 2 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb19, label %bb20
bb19:
  %t98 = load ptr, ptr %l7, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Make", ptr %t98, i32 0, i32 2
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t102 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_39, 0
  %t103 = insertvalue { ptr, ptr } %t102, ptr null, 1
  %t106 = extractvalue { ptr, ptr } %t103, 0
  %t107 = extractvalue { ptr, ptr } %t103, 1
  %t108 = call i1 @std_2fprelude_2farray_2eArray_3ccompiler_2ftyped_3aExpr_26_3e_2eEvery_3ccompiler_2ftyped_3aExpr_26_2c_20_3f_3e(ptr %v1, ptr %s3, { i64, ptr } %t101, ptr %t106, ptr %t107)
  store i1 %t108, ptr %l56
  br label %bb21
bb20:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb22
bb21:
  %t109 = load i1, ptr %l56, !tbaa !21
  store i1 %t109, ptr %l52, !tbaa !21
  br label %bb22
bb22:
  %t110 = load i1, ptr %l52, !tbaa !21
  store i1 %t110, ptr %l42, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_ecfbbef7cda902e1_3bafa02f8f932e5d)
  unreachable
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i1, ptr %l42, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estrReceiver(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/scope:rel"
  %l4 = alloca i1
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l24 = alloca %"compiler/scope:rel"
  %l29 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, [2 x i64] }
  %l42 = alloca { i64, [2 x i64] }
  %l44 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/msgs:Msg"
  %l64 = alloca i64
  %l69 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l97 = alloca i1
  %l99 = alloca i1
  %l103 = alloca i1
  %l105 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca %"compiler/msgs:Msg"
  %l111 = alloca i64
  %l115 = alloca i64
  %l124 = alloca i1
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca i32
  %l133 = alloca %"compiler/source:Span"
  %l136 = alloca ptr
  %l137 = alloca i64
  %l141 = alloca i64
  %l145 = alloca %"compiler/source:Span"
  %l146 = alloca %"compiler/msgs:Msg"
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 35
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l17, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l19
  br label %bb2
bb2:
  %t9 = load i64, ptr %l17, !tbaa !24
  %t10 = load i64, ptr %l19, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb39
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/scope:rel" %t19, ptr %l24
  br label %bb6
bb6:
  %t20 = load %"compiler/scope:rel", ptr %l24
  store %"compiler/scope:rel" %t20, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  %t21 = getelementptr %"compiler/scope:rel", ptr %l3, i32 0, i32 1
  %t22 = load { i64, [2 x i64] }, ptr %t21
  store { i64, [2 x i64] } %t22, ptr %l5
  %t24 = load { i64, [2 x i64] }, ptr %l5
  %t26 = extractvalue { i64, [2 x i64] } %t24, 0
  %t27 = icmp eq i64 %t26, 2
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t30 = getelementptr { i64 }, ptr %t29, i32 0, i32 0
  %t31 = load i64, ptr %t30
  store i64 %t31, ptr %l6, !tbaa !24
  br label %bb9
bb8:
  br label %bb19
bb9:
  %t33 = load i64, ptr %l6, !tbaa !24
  store i64 %t33, ptr %l29, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/scope:Scoper", ptr %t34, i32 0, i32 64
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t36)
  store i64 %t38, ptr %l32
  br label %bb10
bb10:
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = load i64, ptr %l32, !tbaa !24
  %t41 = icmp slt i64 %t39, %t40
  br i1 %t41, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t43, i32 0, i32 64
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t45, i64 %t46)
  store i1 %t49, ptr %l38
  br label %bb13
bb12:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb14
bb13:
  %t50 = load i1, ptr %l38, !tbaa !21
  store i1 %t50, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = getelementptr %"compiler/scope:rel", ptr %l3, i32 0, i32 0
  %t53 = load { i64, [2 x i64] }, ptr %t52
  store { i64, [2 x i64] } %t53, ptr %l40
  %t54 = getelementptr %"compiler/scope:rel", ptr %l3, i32 0, i32 1
  %t55 = load { i64, [2 x i64] }, ptr %t54
  store { i64, [2 x i64] } %t55, ptr %l42
  %t58 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l40, ptr %l42)
  store i1 %t58, ptr %l44
  br label %bb17
bb16:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb18
bb17:
  %t59 = load i1, ptr %l44, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l39, !tbaa !21
  br label %bb18
bb18:
  %t62 = load i1, ptr %l39, !tbaa !21
  store i1 %t62, ptr %l4, !tbaa !21
  br label %bb28
bb19:
  %t63 = load { i64, [2 x i64] }, ptr %l5
  %t65 = extractvalue { i64, [2 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 4
  br i1 %t66, label %bb20, label %bb21
bb20:
  %t68 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t69 = getelementptr { i64, i64 }, ptr %t68, i32 0, i32 0
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l7, !tbaa !24
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sge i64 %t72, 0
  store i1 %t74, ptr %l4, !tbaa !21
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_678543b1c51fd044_bcff5a6e112a6af8)
  unreachable
bb28:
  %t76 = load i1, ptr %l4, !tbaa !21
  br i1 %t76, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l52, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l53, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/scope:Scoper", ptr %t80, i32 0, i32 25
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  br i1 %t85, label %bb31, label %bb32
bb30:
  br label %bb37
bb31:
  call void @__olang_check_failed(ptr @olang_loc_90a9d28716f9cb6_29834bc9108cc36a)
  unreachable
bb32:
  br label %bb33
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/scope:Scoper", ptr %t87, i32 0, i32 25
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Body", ptr %t90, i32 0, i32 3
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = getelementptr %"compiler/scope:rel", ptr %l3, i32 0, i32 3
  %t96 = load %"compiler/source:Span", ptr %t95
  %t97 = load ptr, ptr %l53, !tbaa !29
  %t100 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t97, i64 %t94, %"compiler/source:Span" %t96)
  store %"compiler/source:Span" %t100, ptr %l62
  br label %bb34
bb34:
  %t101 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %s6)
  store %"compiler/msgs:Msg" %t101, ptr %l63
  br label %bb35
bb35:
  %t102 = load ptr, ptr %l52, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l62
  %t104 = load %"compiler/msgs:Msg", ptr %l63
  %t105 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s6, ptr %t102, %"compiler/source:Span" %t103, %"compiler/msgs:Msg" %t104)
  store i64 %t105, ptr %l64
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb37:
  br label %bb38
bb38:
  %t106 = load i64, ptr %l2, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l2, !tbaa !24
  br label %bb1
bb39:
  store i64 0, ptr %l8, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 64
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l69
  br label %bb40
bb40:
  %t115 = load i64, ptr %l69, !tbaa !24
  store i64 %t115, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l9, !tbaa !24
  %t117 = load i64, ptr %l8, !tbaa !24
  %t120 = icmp sgt i64 %t116, %t117
  br i1 %t120, label %bb41, label %bb42
bb41:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t124 = icmp sgt i64 %t122, 0
  br i1 %t124, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb46
bb43:
  %t126 = load i64, ptr %l9, !tbaa !24
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = sub i64 %t126, %t127
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = add i64 %t130, %t131
  %t136 = sub i64 %t134, 1
  %t137 = load i64, ptr %l10, !tbaa !24
  %t140 = sdiv i64 %t136, %t137
  store i64 %t140, ptr %l76, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb45
bb45:
  %t142 = load i64, ptr %l76, !tbaa !24
  store i64 %t142, ptr %l73, !tbaa !24
  br label %bb46
bb46:
  %t143 = load i64, ptr %l73, !tbaa !24
  store i64 %t143, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s9
  %t144 = load i64, ptr %l12, !tbaa !24
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s9)
  br label %bb79
bb49:
  br label %bb50
bb50:
  %t152 = load i64, ptr %l8, !tbaa !24
  %t153 = load i64, ptr %l12, !tbaa !24
  %t154 = load i64, ptr %l10, !tbaa !24
  %t157 = mul i64 %t153, %t154
  %t160 = add i64 %t152, %t157
  store i64 %t160, ptr %l13, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/scope:Scoper", ptr %t162, i32 0, i32 64
  %t165 = load i64, ptr %l13, !tbaa !24
  %t168 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t164, i64 %t165)
  store i1 %t168, ptr %l97
  br label %bb51
bb51:
  %t169 = load i1, ptr %l97, !tbaa !21
  %t170 = xor i1 %t169, true
  br i1 %t170, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb55
bb53:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/scope:Scoper", ptr %t172, i32 0, i32 58
  %t175 = load i64, ptr %l13, !tbaa !24
  %t178 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t174, i64 %t175)
  store i1 %t178, ptr %l103
  br label %bb54
bb54:
  %t179 = load i1, ptr %l103, !tbaa !21
  %t180 = xor i1 %t179, true
  store i1 %t180, ptr %l99, !tbaa !21
  br label %bb55
bb55:
  %t182 = load i1, ptr %l99, !tbaa !21
  br i1 %t182, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb78
bb57:
  br label %bb58
bb58:
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l105, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/scope:Scoper", ptr %t184, i32 0, i32 61
  %t187 = load i64, ptr %l13, !tbaa !24
  %t190 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t186, i64 %t187)
  store %"compiler/source:Span" %t190, ptr %l109
  br label %bb59
bb59:
  %t191 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %s9)
  store %"compiler/msgs:Msg" %t191, ptr %l110
  br label %bb60
bb60:
  %t192 = load ptr, ptr %l105, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l109
  %t194 = load %"compiler/msgs:Msg", ptr %l110
  %t195 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s9, ptr %t192, %"compiler/source:Span" %t193, %"compiler/msgs:Msg" %t194)
  store i64 %t195, ptr %l111
  br label %bb61
bb61:
  %t196 = load i64, ptr %l111, !tbaa !24
  store i64 %t196, ptr %l14, !tbaa !24
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/scope:Scoper", ptr %t197, i32 0, i32 62
  %t200 = load i64, ptr %l13, !tbaa !24
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t199, i64 %t200)
  store i64 %t203, ptr %l115
  br label %bb62
bb62:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/scope:Scoper", ptr %t204, i32 0, i32 25
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = icmp eq ptr %t207, null
  br i1 %t209, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_a7a579971a154b67_66936e5e8b24a2eb)
  unreachable
bb64:
  br label %bb65
bb65:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/scope:Scoper", ptr %t211, i32 0, i32 25
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Body", ptr %t214, i32 0, i32 3
  %t218 = load i64, ptr %t217, !tbaa !24
  %t219 = load i64, ptr %l115, !tbaa !24
  %t221 = icmp ne i64 %t219, %t218
  br i1 %t221, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb70
bb67:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/scope:Scoper", ptr %t223, i32 0, i32 63
  %t226 = load i64, ptr %l13, !tbaa !24
  %t229 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t225, i64 %t226)
  store %"compiler/source:Span" %t229, ptr %l128
  br label %bb68
bb68:
  %t230 = getelementptr %"compiler/source:Span", ptr %l128, i32 0, i32 0
  %t231 = load i32, ptr %t230, !tbaa !23
  store i32 %t231, ptr %l129, !tbaa !23
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/scope:Scoper", ptr %t232, i32 0, i32 61
  %t235 = load i64, ptr %l13, !tbaa !24
  %t238 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t234, i64 %t235)
  store %"compiler/source:Span" %t238, ptr %l133
  br label %bb69
bb69:
  %t239 = getelementptr %"compiler/source:Span", ptr %l133, i32 0, i32 0
  %t240 = load i32, ptr %t239, !tbaa !23
  %t241 = load i32, ptr %l129, !tbaa !23
  %t243 = icmp ne i32 %t241, %t240
  store i1 %t243, ptr %l124, !tbaa !21
  br label %bb70
bb70:
  %t245 = load i1, ptr %l124, !tbaa !21
  br i1 %t245, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s11
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l136, !tbaa !29
  %t247 = load i64, ptr %l14, !tbaa !24
  store i64 %t247, ptr %l137, !tbaa !24
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/scope:Scoper", ptr %t248, i32 0, i32 62
  %t251 = load i64, ptr %l13, !tbaa !24
  %t254 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t250, i64 %t251)
  store i64 %t254, ptr %l141
  br label %bb73
bb72:
  br label %bb77
bb73:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/scope:Scoper", ptr %t255, i32 0, i32 63
  %t258 = load i64, ptr %l13, !tbaa !24
  %t261 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t257, i64 %t258)
  store %"compiler/source:Span" %t261, ptr %l145
  br label %bb74
bb74:
  %t262 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrBuildsHere(ptr %s11)
  store %"compiler/msgs:Msg" %t262, ptr %l146
  br label %bb75
bb75:
  %t263 = load ptr, ptr %l136, !tbaa !29
  %t264 = load i64, ptr %l137, !tbaa !24
  %t265 = load i64, ptr %l141, !tbaa !24
  %t266 = load %"compiler/source:Span", ptr %l145
  %t267 = load %"compiler/msgs:Msg", ptr %l146
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s11, ptr %t263, i64 %t264, i64 %t265, %"compiler/source:Span" %t266, %"compiler/msgs:Msg" %t267)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s11)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s9)
  br label %ret
bb78:
  %t268 = load i64, ptr %l12, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l12, !tbaa !24
  br label %bb47
bb79:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etermName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca { i64, [1 x i64] }
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca i32
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, [2 x i64] }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load { i64, [2 x i64] }, ptr %l2
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 2
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t15 = getelementptr { i64 }, ptr %t14, i32 0, i32 0
  %t16 = load i64, ptr %t15
  store i64 %t16, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l15, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 6
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t22, i64 %t23)
  store { i64, [1 x i64] } %t26, ptr %l20
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = load { i64, [1 x i64] }, ptr %l20
  %t32 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evarName(ptr %v0, ptr %v0, ptr %v1, ptr %v2, ptr %t28, ptr %t29, { i64, [1 x i64] } %t30, ptr %t27)
  store { i64, ptr } %t32, ptr %l22
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t33, ptr %l11, !tbaa !27
  br label %bb23
bb7:
  %t34 = load { i64, [2 x i64] }, ptr %l2
  %t36 = extractvalue { i64, [2 x i64] } %t34, 0
  %t37 = icmp eq i64 %t36, 3
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t39, ptr %l11, !tbaa !27
  br label %bb23
bb11:
  %t41 = load { i64, [2 x i64] }, ptr %l2
  %t43 = extractvalue { i64, [2 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 4
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t47 = getelementptr { i64, i64 }, ptr %t46, i32 0, i32 0
  %t48 = load i64, ptr %t47
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb14
bb13:
  br label %bb17
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  %t51 = load ptr, ptr %l4, !tbaa !29
  store ptr %t51, ptr %l31, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 5
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t54, i64 %t55)
  store i32 %t58, ptr %l35
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t60 = load ptr, ptr %l30, !tbaa !29
  %t61 = load ptr, ptr %l31, !tbaa !29
  %t62 = load i32, ptr %l35, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elocalName(ptr %v0, ptr %v0, ptr %v1, ptr %s3, ptr %t60, ptr %t61, i32 %t62, ptr %t59)
  store { i64, ptr } %t64, ptr %l37
  br label %bb16
bb16:
  %t65 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t67 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = add i64 %t66, %t69
  %t71 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t65, i64 %t66)
  %t75 = getelementptr i8, ptr %t74, i64 %t66
  call void @olang_textcopy(ptr %t75, ptr %t68, i64 %t69)
  %t76 = getelementptr i8, ptr %t75, i64 %t69
  call void @olang_textcopy(ptr %t76, ptr %t71, i64 %t72)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t74, 1
  store { i64, ptr } %t78, ptr %l11, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t80 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t80, ptr %l39
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %s6, ptr %l39, i64 0)
  br label %bb21
bb21:
  %t82 = load ptr, ptr %s6
  %t83 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t84 = load i64, ptr %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t82, i64 %t84)
  %t86 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  store { i64, ptr } %t87, ptr %l41, !tbaa !27
  %t88 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t89 = load ptr, ptr %t88
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %sbgrew.91, label %sbdone.92
sbgrew.91:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.92
sbdone.92:
  %t93 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t93, ptr %l11, !tbaa !27
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_a29c887f84e1b245_5040fb81d2028cb9)
  unreachable
bb23:
  %t94 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l42, !tbaa !24
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l43, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l42, !tbaa !24
  %t106 = mul i64 %t105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t107, ptr %l11, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerivedExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l7, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 2
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb10
bb5:
  %t23 = load ptr, ptr %l2, !tbaa !29
  store ptr %t23, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 3
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t42 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerived(ptr %v0, ptr %s0, ptr %t38, ptr %t39)
  store i1 %t42, ptr %l23
  br label %bb11
bb11:
  %t43 = load i1, ptr %l23, !tbaa !21
  store i1 %t43, ptr %l8, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_c51808c26f3c8029_f1c25a88624d8cdd)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load i1, ptr %l8, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueCovered(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l10 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"compiler/scope:rel"
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  store ptr %a2, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %l12, !tbaa !24
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l14
  br label %bb3
bb3:
  %t15 = load i64, ptr %l12, !tbaa !24
  %t16 = load i64, ptr %l14, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb13
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v1, ptr %t21, i64 %t22)
  store %"compiler/scope:rel" %t25, ptr %l19
  br label %bb7
bb7:
  %t26 = load %"compiler/scope:rel", ptr %l19
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t33 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecoveredRel(ptr %v0, ptr %v0, ptr %t27, ptr %t28, %"compiler/scope:rel" %t26)
  store i1 %t33, ptr %l23
  br label %bb8
bb8:
  %t34 = load i1, ptr %l23, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l5, !tbaa !24
  br label %bb2
bb13:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueRels(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i1
  %l40 = alloca i64
  %l43 = alloca i64
  %l61 = alloca { i64, ptr }
  %l66 = alloca i1
  %l71 = alloca i1
  %l73 = alloca { i64, ptr }
  %l76 = alloca i1
  %l78 = alloca ptr
  %l84 = alloca %"compiler/scope:rel"
  %l86 = alloca i1
  %l88 = alloca { i64, ptr }
  %l91 = alloca i1
  %l92 = alloca ptr
  %l98 = alloca %"compiler/scope:rel"
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t135 = alloca { i64, [2 x i64] }, align 8
  %t142 = alloca { i64, [2 x i64] }, align 8
  %t172 = alloca { i64, [2 x i64] }, align 8
  %t179 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp5
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t4 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %lp5
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  store ptr %t17, ptr %l21, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l26
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l21, !tbaa !29
  %t29 = load i32, ptr %l26, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l27
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l28, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l33
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = load i32, ptr %l33, !tbaa !23
  %t45 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t43, i32 %t44)
  store i1 %t45, ptr %l34
  br label %bb8
bb8:
  %t46 = load i1, ptr %l34, !tbaa !21
  store i1 %t46, ptr %l7, !tbaa !21
  store i64 0, ptr %l8, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l9, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb9, label %bb10
bb9:
  %t57 = load i64, ptr %l10, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb14
bb11:
  %t61 = load i64, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l10, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l43, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb13
bb13:
  %t77 = load i64, ptr %l43, !tbaa !24
  store i64 %t77, ptr %l40, !tbaa !24
  br label %bb14
bb14:
  %t78 = load i64, ptr %l40, !tbaa !24
  store i64 %t78, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load i64, ptr %l12, !tbaa !24
  %t80 = load i64, ptr %l11, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb17:
  br label %bb18
bb18:
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l12, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l13, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t97, ptr %l61, !tbaa !27
  %t98 = load i64, ptr %l13, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i64, ptr %t101, i64 %t98
  %t103 = load i64, ptr %t102, !tbaa !34
  store i64 %t103, ptr %l14, !tbaa !24
  %t105 = load i64, ptr %l14, !tbaa !24
  %t107 = icmp slt i64 %t105, 0
  br i1 %t107, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb21
bb20:
  %t109 = load i64, ptr %l14, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t115 = icmp sge i64 %t109, %t112
  store i1 %t115, ptr %l66, !tbaa !21
  br label %bb21
bb21:
  %t117 = load i1, ptr %l66, !tbaa !21
  br i1 %t117, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb25
bb23:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t119, ptr %l73, !tbaa !27
  %t120 = load i64, ptr %l14, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i32, ptr %t123, i64 %t120
  %t125 = load i32, ptr %t124, !tbaa !33
  %t128 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t118, i32 %t125)
  store i1 %t128, ptr %l76
  br label %bb24
bb24:
  %t129 = load i1, ptr %l76, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l71, !tbaa !21
  br label %bb25
bb25:
  %t132 = load i1, ptr %l71, !tbaa !21
  br i1 %t132, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t133 = load ptr, ptr %lp5
  store ptr %t133, ptr %l78, !tbaa !29
  %t134 = load i64, ptr %l13, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t135
  %t136 = getelementptr { i64, [2 x i64] }, ptr %t135, i32 0, i32 0
  store i64 2, ptr %t136
  %t138 = insertvalue { i64 } undef, i64 %t134, 0
  %t139 = getelementptr { i64, [2 x i64] }, ptr %t135, i32 0, i32 1
  store { i64 } %t138, ptr %t139
  %t140 = load { i64, [2 x i64] }, ptr %t135
  %t141 = load i64, ptr %l3, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [2 x i64] }, ptr %t142, i32 0, i32 0
  store i64 2, ptr %t143
  %t145 = insertvalue { i64 } undef, i64 %t141, 0
  %t146 = getelementptr { i64, [2 x i64] }, ptr %t142, i32 0, i32 1
  store { i64 } %t145, ptr %t146
  %t147 = load { i64, [2 x i64] }, ptr %t142
  %t148 = load %"compiler/source:Span", ptr %l4
  %t152 = call %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %s3, { i64, [2 x i64] } %t140, { i64, [2 x i64] } %t147, i1 false, %"compiler/source:Span" %t148, i64 0, i1 true)
  store %"compiler/scope:rel" %t152, ptr %l84
  br label %bb29
bb29:
  %t153 = load ptr, ptr %l78, !tbaa !29
  %t154 = load %"compiler/scope:rel", ptr %l84
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v2, ptr %t153, %"compiler/scope:rel" %t154)
  br label %bb30
bb30:
  %t155 = load i1, ptr %l7, !tbaa !21
  br i1 %t155, label %bb31, label %bb32
bb31:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t158, ptr %l88, !tbaa !27
  %t159 = load i64, ptr %l14, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t167 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t157, i32 %t164)
  store i1 %t167, ptr %l91
  br label %bb33
bb32:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb34
bb33:
  %t168 = load i1, ptr %l91, !tbaa !21
  store i1 %t168, ptr %l86, !tbaa !21
  br label %bb34
bb34:
  %t169 = load i1, ptr %l86, !tbaa !21
  br i1 %t169, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t170 = load ptr, ptr %lp5
  store ptr %t170, ptr %l92, !tbaa !29
  %t171 = load i64, ptr %l3, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t172
  %t173 = getelementptr { i64, [2 x i64] }, ptr %t172, i32 0, i32 0
  store i64 2, ptr %t173
  %t175 = insertvalue { i64 } undef, i64 %t171, 0
  %t176 = getelementptr { i64, [2 x i64] }, ptr %t172, i32 0, i32 1
  store { i64 } %t175, ptr %t176
  %t177 = load { i64, [2 x i64] }, ptr %t172
  %t178 = load i64, ptr %l13, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [2 x i64] }, ptr %t179, i32 0, i32 0
  store i64 2, ptr %t180
  %t182 = insertvalue { i64 } undef, i64 %t178, 0
  %t183 = getelementptr { i64, [2 x i64] }, ptr %t179, i32 0, i32 1
  store { i64 } %t182, ptr %t183
  %t184 = load { i64, [2 x i64] }, ptr %t179
  %t185 = load %"compiler/source:Span", ptr %l4
  %t189 = call %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %s5, { i64, [2 x i64] } %t177, { i64, [2 x i64] } %t184, i1 false, %"compiler/source:Span" %t185, i64 0, i1 true)
  store %"compiler/scope:rel" %t189, ptr %l98
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t190 = load ptr, ptr %l92, !tbaa !29
  %t191 = load %"compiler/scope:rel", ptr %l98
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v2, ptr %t190, %"compiler/scope:rel" %t191)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb40:
  %t192 = load i64, ptr %l12, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l12, !tbaa !24
  br label %bb15
bb41:
  %t196 = load ptr, ptr %lp5
  %t197 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t196
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t197, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evarName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2, ptr %a3) #0 {
entry:
  %l2 = alloca { i64, [1 x i64] }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, [1 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l4, !tbaa !23
  br label %bb5
bb2:
  %t10 = load { i64, [1 x i64] }, ptr %l2
  %t12 = extractvalue { i64, [1 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 4
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load i32, ptr %l4, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elocalName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %t21, ptr %a3)
  store { i64, ptr } %t27, ptr %l16
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  br label %bb20
bb7:
  %t29 = load { i64, [1 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [1 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 1
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t34, ptr %l5, !tbaa !27
  br label %bb20
bb11:
  %t36 = load { i64, [1 x i64] }, ptr %l2
  %t38 = extractvalue { i64, [1 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 2
  br i1 %t39, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  br label %bb20
bb15:
  %t43 = load { i64, [1 x i64] }, ptr %l2
  %t45 = extractvalue { i64, [1 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 3
  br i1 %t46, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_33e8f6984fda8b38_987c5f6a5f702884)
  unreachable
bb20:
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l29, !tbaa !24
  %t52 = load i64, ptr %l29, !tbaa !24
  %t53 = mul i64 %t52, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l30, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l29, !tbaa !24
  %t62 = mul i64 %t61, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %t60, i64 %t62, i1 false)
  %t63 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t63, ptr %l5, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewantPromotionOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca i1
  %l10 = alloca i1
  %l16 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 139
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 142
  %t11 = load i1, ptr %t10, !tbaa !21
  %t13 = xor i1 %t11, true
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t20 = icmp eq i32 %t16, %t17
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %t23, i32 %t24)
  store i64 %t27, ptr %l16
  br label %bb10
bb10:
  %t28 = load i64, ptr %l16, !tbaa !24
  store i64 %t28, ptr %l2, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp sge i64 %t29, 0
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewant(ptr %v0, ptr %t33, i64 %t34)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l49 = alloca i64
  %l50 = alloca ptr
  %l56 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l10
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t7)
  store ptr %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l11, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l13, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l3, !tbaa !29
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i64 @compiler_2fscope_2eflRoot(ptr %s0, ptr %t25)
  store i64 %t27, ptr %l20
  br label %bb8
bb8:
  %t28 = load i64, ptr %l20, !tbaa !24
  store i64 %t28, ptr %l12, !tbaa !24
  br label %bb41
bb9:
  %t29 = load ptr, ptr %l2, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t48 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowRoot(ptr %v0, ptr %s0, ptr %t44, ptr %t45)
  store i64 %t48, ptr %l29
  br label %bb15
bb15:
  %t49 = load i64, ptr %l29, !tbaa !24
  store i64 %t49, ptr %l12, !tbaa !24
  br label %bb41
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 18}
  %t57 = icmp eq i64 %t55, 5
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l5, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Promote", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %s0, ptr %t65, ptr %t69)
  store i64 %t72, ptr %l39
  br label %bb22
bb22:
  %t73 = load i64, ptr %l39, !tbaa !24
  store i64 %t73, ptr %l12, !tbaa !24
  br label %bb41
bb23:
  %t74 = load ptr, ptr %l2, !tbaa !29
  store ptr %t74, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t75 = load ptr, ptr %l40, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 18}
  %t81 = icmp eq i64 %t79, 12
  store i1 %t81, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l41, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l6, !tbaa !29
  br label %bb28
bb27:
  br label %bb36
bb28:
  %t89 = load ptr, ptr %l6, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Seq", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb29, label %bb30
bb29:
  store i64 -1, ptr %l49, !tbaa !24
  br label %bb35
bb30:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l50, !tbaa !29
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Seq", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  br i1 %t102, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_2604b54ceaf5ac58_8a6d930b5e8314fc)
  unreachable
bb32:
  br label %bb33
bb33:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Seq", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t108 = load ptr, ptr %l50, !tbaa !29
  %t110 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %s0, ptr %t108, ptr %t107)
  store i64 %t110, ptr %l56
  br label %bb34
bb34:
  %t111 = load i64, ptr %l56, !tbaa !24
  store i64 %t111, ptr %l49, !tbaa !24
  br label %bb35
bb35:
  %t112 = load i64, ptr %l49, !tbaa !24
  store i64 %t112, ptr %l12, !tbaa !24
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_fee63ae15dece90e_627da4ca7452ed92)
  unreachable
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load i64, ptr %l12, !tbaa !24
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecopiedRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 6
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l3, !tbaa !21
  br label %bb20
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 17
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l2, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = call i1 @compiler_2fscope_2ecopiedRead(ptr %v0, ptr %t42)
  store i1 %t44, ptr %l22
  br label %bb14
bb14:
  %t45 = load i1, ptr %l22, !tbaa !21
  store i1 %t45, ptr %l3, !tbaa !21
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_825a81e7f5138d1b_866e780fc6f79e3f)
  unreachable
bb20:
  %t46 = load i1, ptr %l3, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t13, i64 %t14)
  store i1 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = add i64 %t21, 1
  store i64 %t23, ptr %l1, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = add i64 %t25, 1
  store i64 %t27, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %a0) #0 {
entry:
  %l3 = alloca %"compiler/scope:Val"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = call %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %s0, i32 3, { i64, [2 x i64] } %a0)
  store %"compiler/scope:Val" %t4, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t5 = load %"compiler/scope:Val", ptr %l3
  store %"compiler/scope:Val" %t5, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local i64 @compiler_2fscope_2eownField(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 3
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t41 = call i1 @compiler_2fscope_2eisParamRead(ptr %v0, ptr %t37, i64 %a1)
  store i1 %t41, ptr %l21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load i64, ptr %l3, !tbaa !24
  store i64 %t43, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_97a3337844e24daf_abbacdff6e992493)
  unreachable
bb20:
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_21f109796fa0acee_6e7b91baaed0fa92)
  unreachable
bb26:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2eregionLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l9, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_926310a74149af64_7456b8629edeed00)
  unreachable
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_d723be5f6d33c955_f64e13843779cd91)
  unreachable
bb22:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ewalkBody(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/scope:walked"
  %l8 = alloca ptr
  %l16 = alloca %"compiler/scope:walked"
  %t1 = alloca %"compiler/scope:walked", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @olang_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %t1, ptr %v1)
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %t1, i64 224, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 224, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l4, i64 224, i1 false)
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l8, !tbaa !29
  store ptr %t11, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 11
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 11
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load ptr, ptr %lp2
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t24, ptr %t25)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t28 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t28, i64 224, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l16, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/scope:fnUse" @compiler_2fscope_3afnUse_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i32 %a4) #0 {
entry:
  %rv = alloca %"compiler/scope:fnUse"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/scope:fnUse" undef, i64 %a0, 0
  %t14 = insertvalue %"compiler/scope:fnUse" %t12, %"compiler/source:Span" %a1, 1
  %t16 = insertvalue %"compiler/scope:fnUse" %t14, i64 %a2, 2
  %t18 = insertvalue %"compiler/scope:fnUse" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/scope:fnUse" %t18, i32 %a4, 4
  store %"compiler/scope:fnUse" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:fnUse", ptr %rv
  ret %"compiler/scope:fnUse" %rr
}

define dso_local %"compiler/scope:markRead" @compiler_2fscope_3amarkRead_2ector(ptr %v0, i64 %a0, i64 %a1, { i64, [1 x i64] } %a2) #0 {
entry:
  %rv = alloca %"compiler/scope:markRead"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/scope:markRead" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/scope:markRead" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/scope:markRead" %t10, { i64, [1 x i64] } %a2, 2
  store %"compiler/scope:markRead" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:markRead", ptr %rv
  ret %"compiler/scope:markRead" %rr
}

define dso_local %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %v0, { i64, [2 x i64] } %a0, { i64, [2 x i64] } %a1, i1 %a2, %"compiler/source:Span" %a3, i64 %a4, i1 %a5) #0 {
entry:
  %rv = alloca %"compiler/scope:rel"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/scope:rel" undef, { i64, [2 x i64] } %a0, 0
  %t16 = insertvalue %"compiler/scope:rel" %t14, { i64, [2 x i64] } %a1, 1
  %t18 = insertvalue %"compiler/scope:rel" %t16, i1 %a2, 2
  %t20 = insertvalue %"compiler/scope:rel" %t18, %"compiler/source:Span" %a3, 3
  %t22 = insertvalue %"compiler/scope:rel" %t20, i64 %a4, 4
  %t24 = insertvalue %"compiler/scope:rel" %t22, i1 %a5, 5
  store %"compiler/scope:rel" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:rel", ptr %rv
  ret %"compiler/scope:rel" %rr
}

define dso_local void @compiler_2fscope_3awalked_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"compiler/scope:walked"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l8
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l9
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l2
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l10
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l3
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l11
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l4
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l12
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l5
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l13
  br label %bb7
bb7:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t15 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 0
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t15
  %t17 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 1
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %t17
  %t19 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 2
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t19
  %t21 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 3
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %t21
  %t23 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 4
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %t23
  %t25 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 5
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t25
  %t27 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %t27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l14, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 176, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 9
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"blocks built into: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d1 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c", of them plain (what folding could reach): " }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d2 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" outlives " }>, align 8
declare void @__olang_ert_req_clear()
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d5 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"at" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 7}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 5, label %bb7 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load i1, ptr %l2, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d8 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"where the generator does" }>, align 8
@.d9 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"with what '" }>, align 8
@.d10 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"' refers to" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"at" }>, align 8
@.d13 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"setAt" }>, align 8
@.d15 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"instantiated here" }>, align 8
@.d16 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"an instance is built in one of them" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no lift " }>, align 8
@.d19 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" for a part kept | " }>, align 8
@.d20 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no lift " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  br label %bb1
bb3:
  %t6 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t8, i64 %t9)
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t15 = sext i32 %t13 to i64
  %t16 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %t15)
  call void @__olang_sb_add(ptr %v0, i64 %t17)
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t18, i64 %t19)
  br label %bb1
bb4:
  %t20 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t20, i64 %t21)
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t22, i64 %t23)
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 1
  %t26 = getelementptr { i64 }, ptr %t25, i32 0, i32 0
  %t27 = load i64, ptr %t26
  %t29 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %t27)
  call void @__olang_sb_add(ptr %v0, i64 %t30)
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb5:
  %t33 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb6:
  %t35 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 1
  %t41 = getelementptr { i64, i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  %t44 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t45 = call i64 @__olang_fmt_i64(ptr %t44, i64 %t42)
  call void @__olang_sb_add(ptr %v0, i64 %t45)
  %t46 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t46, i64 %t47)
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 1
  %t50 = getelementptr { i64, i64 }, ptr %t49, i32 0, i32 1
  %t51 = load i64, ptr %t50
  %t53 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t54 = call i64 @__olang_fmt_i64(ptr %t53, i64 %t51)
  call void @__olang_sb_add(ptr %v0, i64 %t54)
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb7:
  %t57 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr { i64, [2 x i64] }, ptr %t61, i32 0, i32 1
  %t63 = getelementptr { i64 }, ptr %t62, i32 0, i32 0
  %t64 = load i64, ptr %t63
  %t66 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t67 = call i64 @__olang_fmt_i64(ptr %t66, i64 %t64)
  call void @__olang_sb_add(ptr %v0, i64 %t67)
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t68, i64 %t69)
  br label %bb1
bb8:
  %t70 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t70, i64 %t71)
  br label %bb1
ret:
  ret void
}

@.d22 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" (origin " }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c") | " }>, align 8
declare void @__olang_sb_done(ptr)
@.d24 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" with its storage" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" for a part kept" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"lift " }>, align 8
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d30 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" | " }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d34 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Clear" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"if" }>, align 8
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"x" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"compiler/scope:walked"
  %t1 = alloca %"compiler/scope:walked", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fscope_3awalked_2ector(ptr %t1, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l0, ptr %t1, i64 224, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l0, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

define internal i1 @olang_lambda_39(ptr %env, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d40 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"the program" }>, align 8
@.d41 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"the scope " }>, align 8
@.d42 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"'s argument bound" }>, align 8
@.d43 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d44 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"the instance" }>, align 8
@.d45 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"the closing scope" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@.d46 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Term.None" }>, align 8
@.d47 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Term.Block" }>, align 8
@.d48 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d49 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d50 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Term.Var" }>, align 8
@.d51 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"Term.Program" }>, align 8
@.d52 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"Term.Derived" }>, align 8
@.d53 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d54 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Term.Set" }>, align 8
@.d55 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"Term.Untraced" }>, align 8
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %a0)
declare i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecollectField(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_1f46f0e2a5866641_40fe5c75700827d5 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %a0)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c4dcb08f8057e6b4_879f1d415f5e90f0 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_H9c3932eb53016bf6f47a08eef06aacbe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0)
declare %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorBuilt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8066e5da37f3a23b_ece6b8d6fabe8bf7 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsSum(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_a571972fdacfaed1_c7933b0216b7b5ad = external constant [0 x i8]
@olang_loc_9f9bf081c1674640_32724a584f79d5fc = external constant [0 x i8]
declare %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastsUntil(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
@olang_loc_9e4942b53b152c4c_8e08edd23a0a3ef8 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnCaptureTooShort(ptr %v0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evisit(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_be4231f99dfc50a7_6a00356b78c435db = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_badc8ccdfeb92288_a041b08d3fc96aec = external constant [0 x i8]
@olang_loc_58d2ded8d237a84_721cf65762561fa8 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultTerm(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereturnsArray(ptr %v0, ptr %a0)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorageTerm(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowStart(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowRun(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etiedToBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArray(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_36d9ea1b8e0be675_6ae7f20c6157de79 = external constant [0 x i8]
declare ptr @compiler_2ftyped_2eCallOf(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCallOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_318ee1b3da3da37b_dfd49c38f0c44407 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b8fb270bdd73210c_150398a92061e6e8 = external constant [0 x i8]
@olang_loc_6763258997513a41_ec0b86cc45ca0bbd = external constant [0 x i8]
declare i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_6767537ca10246ba_b3f77aefc3649fd6 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallRels(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewalkLocal(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5eb3bfaaf86e9baf_8dddb03606b5f843 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_8d9c16c9e7a15650_5ac0d9bfaf5af2b4 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumBuilds(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforced(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudgeOut(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
@G_2ecompiler_2fscope_2eObliged = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2, i1 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgsDisagree(ptr %v0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edischargeRels(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, ptr %a5, i1 %a6)
@olang_loc_7b1e363353e9e01f_5d568e34003a167b = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2eisNameChar(i8 %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportObligation(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_3d4ddf74a6173f57_410f107a77dd9b9b = external constant [0 x i8]
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2eunPassed(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e3d7361eb9c064f6_d6d91699ddbb69ea = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgHoldsShort(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeMayNotOutlive(ptr %v0)
@G_2ecompiler_2fscope_2eFitLocal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitPayload = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadOutlived(ptr %v0)
@G_2ecompiler_2fscope_2eFitOwn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitReturn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %a0)
@olang_loc_12677068e04dfe45_ab703d1ad408b711 = external constant [0 x i8]
@olang_loc_bf00db29bdc1b99e_9dc03d0b43789e0a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenYieldShorter(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnCannotOutlive(ptr %v0)
@G_2ecompiler_2fscope_2eFitField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoredRefOutlived(ptr %v0)
@G_2ecompiler_2fscope_2eFitElem = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitAnyCopy = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemNotInArrayScope(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemOutlived(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCopyOutlived(ptr %v0)
@G_2ecompiler_2fscope_2eFitGlobal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalHoldsShorter(ptr %v0)
@G_2ecompiler_2fscope_2eFitValue = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@olang_loc_2de0ba6211cb93cf_481b942389356f0b = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOwnStorage(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnOwnStorage(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueRefsOutlived(ptr %v0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExprRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e9ea5d5d3867ce51_dfb99b888a23f285 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturesNothing(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_7f2f0698823b265a_e0642f9ed23c39f6 = external constant [0 x i8]
@olang_loc_6b4093eaa9dab6e0_ebbf8088c45502d4 = external constant [0 x i8]
@olang_loc_a83726b6934b3ff_5f714cf565db93e3 = external constant [0 x i8]
@olang_loc_2e96c7acbe66a05d_c52c59876e2a2911 = external constant [0 x i8]
declare %"compiler/scope:Gap" @compiler_2fscope_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ePush_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/scope:Gap" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_96b0618960354e24_3d02a19520d5ec20 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_1224d6df3464748a_e87c09d967c04386 = external constant [0 x i8]
@olang_loc_fe279d5820b85dad_458b53b3da9c6ff1 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@olang_loc_6ed8db51a3dfced1_45a76436772cba65 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisParam(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2etermGiven({ i64, [2 x i64] } %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d375f47869e73b1e_ab7f910edbf0dc32 = external constant [0 x i8]
declare i1 @compiler_2fscope_2eisParamRead(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9c7ebd2b12e06561_d1b788b185a2a0b5 = external constant [0 x i8]
@olang_loc_e6e67a80e175cfd0_914d29e7454711c4 = external constant [0 x i8]
@olang_loc_9d00f6934855daa_c9673762d5df43fe = external constant [0 x i8]
declare i64 @compiler_2fscope_2eregionRoot(ptr %v0, ptr %a0)
@olang_loc_6f89170392198c6b_c18aa73f993179ff = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_2d8599dd2a60d272_f2da26d46793a2d6 = external constant [0 x i8]
@olang_loc_8dedfa134432c6f3_d3b15d93042206f7 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2ePush_3ccompiler_2fgeneric_3aOrigin_3e(ptr %v0, ptr %a0, %"compiler/generic:Origin" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eLen_3ccompiler_2fgeneric_3aOrigin_3e(ptr %v0, ptr %a0)
declare %"compiler/generic:Origin" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eAt_3ccompiler_2fgeneric_3aOrigin_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_74da5f49279f5443_41bd0bd1769c76af = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a5122b0b395bd8b_9870aa37c8b5f2ef = external constant [0 x i8]
@olang_loc_51a7ef38ab67534a_42b12633f9b5762e = external constant [0 x i8]
@olang_loc_d38420f770b56a25_293628bae4d10df9 = external constant [0 x i8]
@olang_loc_7d2ed71f654b640d_ba09ac545853f0c1 = external constant [0 x i8]
@olang_loc_4d20f13e93e5e00_8edf44d94b0465ac = external constant [0 x i8]
@olang_loc_6eab74aa3e0b63d9_475cda0f5b688a85 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehasLateLocals(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H075aca2c24d2905e4fa457b6b6d6570e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eClear_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eClea_Hf36a88772899b36a46c039ef55a38999(ptr %v0, ptr %a0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecaptureVar(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2ftyped_2eNewPlan(ptr %out, ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_75ea16a293881b53_a3e5ee6d3f4964f = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextDepth(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextBase(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeDestructor(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %v0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/msgs:Msg" %a4)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ekeepRel(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteFieldRecs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecomputeKeeps(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eSetAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, ptr %a3, i1 %a4, { i64, ptr } %a5)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamBinding(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_8c8a5a319e38c1bd_d671b8fda2886981 = external constant [0 x i8]
@olang_loc_d6d71e16ab160a8c_d85efb61f7dcc5f0 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
@G_2ecompiler_2fscope_2eHolds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H7e82b4dbdb79c77bc51fdaf9d4704834(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20compiler_2ftyped_3aExpr_2_H4ea279ff901448a8d94a2f42aa119fd2(ptr %v0, ptr %v1, ptr %a0)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ec2dd22d28cc6988_9d0975400b204864 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d50f79fefbee4394_12c4367532f3ae80 = external constant [0 x i8]
@olang_loc_42ddfa07d54a3511_7eb6b931dfed5aa5 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_133169b3f1711469_c566838c26ef218d = external constant [0 x i8]
@olang_loc_31030507f1509b32_81bbcae78c23c7f6 = external constant [0 x i8]
@olang_loc_16a749f285461106_b0e7908cc5ae695a = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftOf(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoinTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowed(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_18c7df235ed333ed_6cb02ce97018ae1 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4)
@olang_loc_732b86ec1c46a4d8_efc842c6ef92792c = external constant [0 x i8]
@olang_loc_32a69b93b2b7f4f7_279e7ae047adaf1b = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_cbe9d007f71e6f0a_66029137d6521816 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2, i1 %a3, ptr %a4, i64 %a5)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d999d01787ae8811_e9a058a4efe4c7fd = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLands(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildSite(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2, %"compiler/source:Span" %a3)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalTerm(ptr %v0, ptr %a0, %"compiler/scope:Val" %a1, { i64, [2 x i64] } %a2)
@olang_loc_63421958175545b3_aea9f7881c37205f = external constant [0 x i8]
@olang_loc_764527203cdb400b_6de4094d30d6c847 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarkTerm(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunknownMark(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_544377bbfc98dd_9d2d150d24c02431 = external constant [0 x i8]
@G_2ecompiler_2fscope_2eWhyField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f38c14401421162c_fbdeffc88600a020 = external constant [0 x i8]
@olang_loc_9ce531bc53dbe305_ec5af8173ba88031 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitBorrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitHeld(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H38f9aff1b0310316a48dc5a28922f96e(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2)
@olang_loc_f132d9555aa3b3ed_19b32ee1bad8ae89 = external constant [0 x i8]
@olang_loc_607bd9fd8b5af48f_3677f488c8afa2ab = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteOrigin(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/scope:Val" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_a12e96be7ca439b0_5f205879a795b73c = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7ab8aec1f64ce329_6f79d936f6de900d = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_4cb1e8bfb0eaf742_30c70eda17c6c626 = external constant [0 x i8]
@olang_loc_ebf021f92f33e6c3_51775e5dd3616c17 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownCall(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_b8d34b82d7d8e134_8820b4804d519ff8 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuild(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2)
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H65b4b9a6d1679f5b3ddedaa5b2e336bd(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4a1df88f6e47fa3d_f104cf9ebdc893f9 = external constant [0 x i8]
@olang_loc_1209ecb2ebe28e56_3903fb857fc509d2 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %v0)
@olang_loc_f4fc0aa0b05f02b5_215f839e2022cb11 = external constant [0 x i8]
@olang_loc_404d48eac542ce9d_9912d4e42165f0c9 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_bc57042d1b9aa9c8_42b203ed434388d4 = external constant [0 x i8]
@G_2ecompiler_2fscope_2eWhyHolds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_19aa55fe70facde7_b663d059e4ca19e3 = external constant [0 x i8]
@G_2ecompiler_2fscope_2eFitDecl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@olang_loc_eca6e0b2d52570fa_4fe6c0f0f8e0b5fe = external constant [0 x i8]
@olang_loc_acdf13ac8090b308_c550e3cb7d47705c = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunknownBinding(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_3b111cc35ad2064c_5bc510d97bfe7450 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRelatable({ i64, [2 x i64] } %a0)
@olang_loc_3b2e5dd5e19962bb_2cdcb9ba8ccbb9af = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enarrowingMatters(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3005b9c21f34ca3e_35904d8c355f64ba = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenResult(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_cf25d893b5e0925b_26a5f8a01e1a0e87 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etraceAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftable(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_56753b57ce5c76c_5bd4f5104db7b168 = external constant [0 x i8]
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H568ce559fa980123a387c6ba9ed21aca(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_14a6577ead1cc721_32dce333731fd63d = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H240bd86caf003ea6de374cb77d0dbfc6(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, { i64, [2 x i64] } %a2)
@olang_loc_5be7cf6889c0719a_fac8d756f0ba6a56 = external constant [0 x i8]
@olang_loc_6982ea230ce803bc_74efee4e495ae4a0 = external constant [0 x i8]
declare i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %a0)
@olang_loc_40da86322e01ef2b_70b0fe12089116bf = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_7514114a5d4749ce_60914fcc95b5171a = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_bfbb893df1c35f5d_ebb7b8931b043491 = external constant [0 x i8]
@olang_loc_a9ed640346de181b_d10bb16716ed4607 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenElem(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3b124163f404c032_f61e7eda275eee66 = external constant [0 x i8]
@olang_loc_4046876e7ea1d159_b2112eb816f2c84d = external constant [0 x i8]
@olang_loc_79d12197ff1a95a4_7d7576a4aa48dc38 = external constant [0 x i8]
@olang_loc_2cb2f05c33c43f73_8008e731f94f8857 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrKeepCopies(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetAtCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_3be66b99fba73c4e_1215a57d292f746a = external constant [0 x i8]
@olang_loc_9cb83d16c8558bf5_7c19eecf9e07b071 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHeldIndexWhere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisText(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_98ba305d5e2403e0_d6869d4c9e18247c = external constant [0 x i8]
@olang_loc_37fd0ede1d7e00ff_4f25c812a3c753eb = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteTextCopyWhere(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d1e09ab5654512c3_1949347ac845fe07 = external constant [0 x i8]
@olang_loc_9ec3c43f0dea0d34_4e7830eaf7e3a0e8 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_60a9277e2c5e0f29_25801f0e1d4bc5bd = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
@olang_loc_32a2617be6fc2342_ed6c13319ae659d6 = external constant [0 x i8]
@olang_loc_466c52b9c16c208f_a374cdad5045efdb = external constant [0 x i8]
@olang_loc_f99d36ce04cd5358_3c9954da82c615c4 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteRefillKept(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esliceAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_8680c8bf7a40147c_d650a7d3d4e83170 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastBracket(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_22d8393d4f188012_8c9f9e39cb427896 = external constant [0 x i8]
@olang_loc_7213214fb222d0c9_1eae7674ed2401ad = external constant [0 x i8]
@olang_loc_2c141a427a2fa071_f343db408d9fc8c5 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_da3e82aad0dc20bd_21e51e34c917c3d9 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOfOwn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclaimRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_178b2bff302b55ae_896b4874215d5e1a = external constant [0 x i8]
@olang_loc_98dfeaa5663cde63_8f6c693e4f6dac2f = external constant [0 x i8]
@olang_loc_50915285e3e59b40_32eaccc11482b3ec = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePartKept(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecaseParts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_74d9849f1cf072e4_d95edc215f7aa198 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b99a325748da8cd5_4eb62b65b3c79869 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_554265ba1528b3d8_d73d8ae267adc184 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisData(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c484f993348186a9_88a471068962d75 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartLand(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, { i64, [2 x i64] } %a3)
declare %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereadPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, { i64, [2 x i64] } %a3)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb4ab14fd1aa8deeb21095c3402461540(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_59817874246b5c57_1f46b3df70232973 = external constant [0 x i8]
@olang_loc_56ee07e6d564b038_6c64e51b3b797fa4 = external constant [0 x i8]
@olang_loc_8b89bffa420e9c4d_32da4af1bb00bb59 = external constant [0 x i8]
@olang_loc_cf97101c527ac266_2da604e73063aa32 = external constant [0 x i8]
@olang_loc_289e5954cee327eb_2a90d26159dceaff = external constant [0 x i8]
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eResultMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_8136fe9cd009015e_effe087bfaf9a8aa = external constant [0 x i8]
@olang_loc_989f9a5853b8d905_f9638c70ccb394b1 = external constant [0 x i8]
@olang_loc_9ce8ff5a7c812fb0_6c28ecd338a0cbbc = external constant [0 x i8]
@olang_loc_5c3642998b37ea8f_438088e259bab72b = external constant [0 x i8]
@olang_loc_486c515bb0c7ed42_3dcfa333a8d1daa6 = external constant [0 x i8]
@olang_loc_ed4ec6d3513e2b60_3036131f8fea9d34 = external constant [0 x i8]
@olang_loc_b48db41ed7b5d734_952948d9de5cb478 = external constant [0 x i8]
@olang_loc_e7aa8a952f10dcc3_5e7ff2b7646c8097 = external constant [0 x i8]
@olang_loc_dc4554eebbf8456_460c8fdf10d01e52 = external constant [0 x i8]
@olang_loc_ab37e5456fd3bb64_ee38acc32440dcb0 = external constant [0 x i8]
@olang_loc_c2f9290c57ed376d_cbd7590e0cb57901 = external constant [0 x i8]
@olang_loc_c0d893db7e601486_f2e0d00716145a7a = external constant [0 x i8]
@olang_loc_dcd7e57cabd1f877_41684d2a22884c3b = external constant [0 x i8]
@olang_loc_1d5cd0d51560a858_414b0c179bc0efcc = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_83cb1a0080c88b91_4687383f0631b81d = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_e68b15b11e0abafb_13fbbcd2ac59787f = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_5026d552222f1723_4b71b7547c4744a7 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_9da86a51b48ec4c_4c8b634b3e5eba18 = external constant [0 x i8]
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eatPart(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eWriteThroughAtBuilds(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBorrowSplitScopes(ptr %v0)
declare i1 @std_2fprelude_2farray_2eArray_3ccompiler_2ftyped_3aExpr_26_3e_2eEvery_3ccompiler_2ftyped_3aExpr_26_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
@olang_loc_ecfbbef7cda902e1_3bafa02f8f932e5d = external constant [0 x i8]
@olang_loc_678543b1c51fd044_bcff5a6e112a6af8 = external constant [0 x i8]
@olang_loc_90a9d28716f9cb6_29834bc9108cc36a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %v0)
@olang_loc_a7a579971a154b67_66936e5e8b24a2eb = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrBuildsHere(ptr %v0)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elocalName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3)
@olang_loc_a29c887f84e1b245_5040fb81d2028cb9 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerived(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c51808c26f3c8029_f1c25a88624d8cdd = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecoveredRel(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/scope:rel" %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1)
@olang_loc_33e8f6984fda8b38_987c5f6a5f702884 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewant(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2604b54ceaf5ac58_8a6d930b5e8314fc = external constant [0 x i8]
@olang_loc_fee63ae15dece90e_627da4ca7452ed92 = external constant [0 x i8]
@olang_loc_825a81e7f5138d1b_866e780fc6f79e3f = external constant [0 x i8]
declare %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %v0, i32 %a0, { i64, [2 x i64] } %a1)
@olang_loc_97a3337844e24daf_abbacdff6e992493 = external constant [0 x i8]
@olang_loc_21f109796fa0acee_6e7b91baaed0fa92 = external constant [0 x i8]
@olang_loc_926310a74149af64_7456b8629edeed00 = external constant [0 x i8]
@olang_loc_d723be5f6d33c955_f64e13843779cd91 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
