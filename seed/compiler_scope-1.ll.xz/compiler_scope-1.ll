; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/scope:walked" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/typed:Plan", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, [2 x i64] }, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:rel" = type { { i64, [2 x i64] }, { i64, [2 x i64] }, i1, %"compiler/source:Span", i64, i1 }
%"compiler/scope:summary" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/scope:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/scope:Val" = type { i32, { i64, [2 x i64] } }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/scope:fnUse" = type { i64, %"compiler/source:Span", i64, i64, i32 }
define dso_local void @compiler_2fscope_2ecollectStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca i64
  %l53 = alloca ptr
  %l55 = alloca i64
  %l57 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i64
  %l64 = alloca ptr
  %l66 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i1
  %l185 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca i1
  %l207 = alloca { i64, ptr }
  %l213 = alloca i64
  %l216 = alloca ptr
  %l218 = alloca i64
  %l220 = alloca i1
  %l222 = alloca i1
  %l224 = alloca i64
  %l227 = alloca ptr
  %l229 = alloca i64
  %l249 = alloca { i64, ptr }
  %l257 = alloca ptr
  %l258 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t6 = load ptr, ptr %l32, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l32, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 17}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l33, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l33, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t22)
  br label %bb9
bb9:
  br label %bb166
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t26 = load ptr, ptr %l41, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l41, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 17}
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l42, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l42, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb35
bb15:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l50
  br label %bb16
bb16:
  %t49 = load i64, ptr %l50, !tbaa !24
  %t50 = icmp sge i64 %t49, 0
  br i1 %t50, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/scope:walked", ptr %t52, i32 0, i32 1
  store ptr %t54, ptr %l53, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %t55)
  store i64 %t57, ptr %l55
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l53, !tbaa !29
  %t59 = load i64, ptr %l55, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t58, i64 %t59)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %t60)
  store i1 %t62, ptr %l57
  br label %bb22
bb22:
  %t63 = load i1, ptr %l57, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb23, label %bb24
bb23:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l61
  br label %bb25
bb24:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb26
bb25:
  %t69 = load i64, ptr %l61, !tbaa !24
  %t70 = icmp sge i64 %t69, 0
  store i1 %t70, ptr %l59, !tbaa !21
  br label %bb26
bb26:
  %t72 = load i1, ptr %l59, !tbaa !21
  br i1 %t72, label %bb27, label %bb28
bb27:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/scope:walked", ptr %t73, i32 0, i32 4
  store ptr %t75, ptr %l64, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t76)
  store i64 %t78, ptr %l66
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t79 = load ptr, ptr %l64, !tbaa !29
  %t80 = load i64, ptr %l66, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t79, i64 %t80)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectField(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  br label %bb32
bb32:
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %t85, ptr %t87)
  br label %bb33
bb33:
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t90, ptr %t92)
  br label %bb34
bb34:
  br label %bb166
bb35:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t96 = load ptr, ptr %l75, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load ptr, ptr %l75, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 17}
  %t102 = icmp eq i64 %t100, 2
  store i1 %t102, ptr %l76, !tbaa !21
  br label %bb37
bb37:
  %t103 = load i1, ptr %l76, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr { i64, [3 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", ptr }, ptr %t106, i32 0, i32 1
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l5, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t110 = load ptr, ptr %l5, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t110, ptr %t112)
  br label %bb41
bb41:
  br label %bb166
bb42:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t116 = load ptr, ptr %l84, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb43, label %bb44
bb43:
  %t119 = load ptr, ptr %l84, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 17}
  %t122 = icmp eq i64 %t120, 3
  store i1 %t122, ptr %l85, !tbaa !21
  br label %bb44
bb44:
  %t123 = load i1, ptr %l85, !tbaa !21
  br i1 %t123, label %bb45, label %bb46
bb45:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", ptr }, ptr %t126, i32 0, i32 1
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l6, !tbaa !29
  br label %bb47
bb46:
  br label %bb51
bb47:
  %t130 = load ptr, ptr %l6, !tbaa !29
  %t132 = getelementptr %"compiler/typed:If", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t133, ptr %t135)
  br label %bb48
bb48:
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t140 = getelementptr %"compiler/typed:If", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t141, ptr %t143)
  br label %bb49
bb49:
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t148 = getelementptr %"compiler/typed:If", ptr %t146, i32 0, i32 2
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t149, ptr %t150)
  br label %bb50
bb50:
  br label %bb166
bb51:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t154 = load ptr, ptr %l101, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb52, label %bb53
bb52:
  %t157 = load ptr, ptr %l101, !tbaa !29
  %t158 = load i64, ptr %t157, !range !{i64 0, i64 17}
  %t160 = icmp eq i64 %t158, 4
  store i1 %t160, ptr %l102, !tbaa !21
  br label %bb53
bb53:
  %t161 = load i1, ptr %l102, !tbaa !21
  br i1 %t161, label %bb54, label %bb55
bb54:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr { i64, [3 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t164, i32 0, i32 1
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l7, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l8, !tbaa !29
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t174 = load ptr, ptr %l7, !tbaa !29
  %t176 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t174, ptr %t176)
  br label %bb57
bb57:
  %t179 = load ptr, ptr %l8, !tbaa !29
  %t180 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  br label %bb58
bb58:
  br label %bb166
bb59:
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t184 = load ptr, ptr %l114, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb60, label %bb61
bb60:
  %t187 = load ptr, ptr %l114, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 17}
  %t190 = icmp eq i64 %t188, 6
  store i1 %t190, ptr %l115, !tbaa !21
  br label %bb61
bb61:
  %t191 = load i1, ptr %l115, !tbaa !21
  br i1 %t191, label %bb62, label %bb63
bb62:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l9, !tbaa !29
  br label %bb68
bb63:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t199 = load ptr, ptr %l120, !tbaa !29
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %bb64, label %bb65
bb64:
  %t202 = load ptr, ptr %l120, !tbaa !29
  %t203 = load i64, ptr %t202, !range !{i64 0, i64 17}
  %t205 = icmp eq i64 %t203, 16
  store i1 %t205, ptr %l121, !tbaa !21
  br label %bb65
bb65:
  %t206 = load i1, ptr %l121, !tbaa !21
  br i1 %t206, label %bb66, label %bb67
bb66:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr { i64, [3 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", ptr }, ptr %t209, i32 0, i32 1
  %t211 = load ptr, ptr %t210
  store ptr %t211, ptr %l9, !tbaa !29
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t213 = load ptr, ptr %l9, !tbaa !29
  %t214 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t213, ptr %t214)
  br label %bb69
bb69:
  br label %bb166
bb70:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t218 = load ptr, ptr %l128, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb71, label %bb72
bb71:
  %t221 = load ptr, ptr %l128, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 17}
  %t224 = icmp eq i64 %t222, 10
  store i1 %t224, ptr %l129, !tbaa !21
  br label %bb72
bb72:
  %t225 = load i1, ptr %l129, !tbaa !21
  br i1 %t225, label %bb73, label %bb74
bb73:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t228, i32 0, i32 1
  %t230 = load ptr, ptr %t229
  store ptr %t230, ptr %l10, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr { i64, [3 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t234, i32 0, i32 2
  %t236 = load ptr, ptr %t235
  store ptr %t236, ptr %l11, !tbaa !29
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t238 = load ptr, ptr %l10, !tbaa !29
  %t240 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t238, ptr %t240)
  br label %bb76
bb76:
  %t243 = load ptr, ptr %l11, !tbaa !29
  %t244 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t243, ptr %t244)
  br label %bb77
bb77:
  br label %bb166
bb78:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t248 = load ptr, ptr %l141, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb79, label %bb80
bb79:
  %t251 = load ptr, ptr %l141, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 17}
  %t254 = icmp eq i64 %t252, 9
  store i1 %t254, ptr %l142, !tbaa !21
  br label %bb80
bb80:
  %t255 = load i1, ptr %l142, !tbaa !21
  br i1 %t255, label %bb81, label %bb82
bb81:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 2
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l12, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t262 = load ptr, ptr %l12, !tbaa !29
  %t263 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t262, ptr %t263)
  br label %bb84
bb84:
  br label %bb166
bb85:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t267 = load ptr, ptr %l149, !tbaa !29
  %t268 = icmp ne ptr %t267, null
  br i1 %t268, label %bb86, label %bb87
bb86:
  %t270 = load ptr, ptr %l149, !tbaa !29
  %t271 = load i64, ptr %t270, !range !{i64 0, i64 17}
  %t273 = icmp eq i64 %t271, 11
  store i1 %t273, ptr %l150, !tbaa !21
  br label %bb87
bb87:
  %t274 = load i1, ptr %l150, !tbaa !21
  br i1 %t274, label %bb88, label %bb89
bb88:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", ptr }, ptr %t277, i32 0, i32 1
  %t279 = load ptr, ptr %t278
  store ptr %t279, ptr %l13, !tbaa !29
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t281 = load ptr, ptr %l13, !tbaa !29
  %t283 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t281, ptr %t283)
  br label %bb91
bb91:
  br label %bb166
bb92:
  %t286 = load ptr, ptr %l0, !tbaa !29
  store ptr %t286, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t287 = load ptr, ptr %l158, !tbaa !29
  %t288 = icmp ne ptr %t287, null
  br i1 %t288, label %bb93, label %bb94
bb93:
  %t290 = load ptr, ptr %l158, !tbaa !29
  %t291 = load i64, ptr %t290, !range !{i64 0, i64 17}
  %t293 = icmp eq i64 %t291, 12
  store i1 %t293, ptr %l159, !tbaa !21
  br label %bb94
bb94:
  %t294 = load i1, ptr %l159, !tbaa !21
  br i1 %t294, label %bb95, label %bb96
bb95:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr { i64, [3 x i64] }, ptr %t295, i32 0, i32 1
  %t298 = getelementptr { %"compiler/source:Span", ptr }, ptr %t297, i32 0, i32 1
  %t299 = load ptr, ptr %t298
  store ptr %t299, ptr %l14, !tbaa !29
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t301 = load ptr, ptr %l14, !tbaa !29
  %t303 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t301, ptr %t303)
  br label %bb98
bb98:
  br label %bb166
bb99:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l167, !tbaa !29
  store i1 false, ptr %l168, !tbaa !21
  %t307 = load ptr, ptr %l167, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb100, label %bb101
bb100:
  %t310 = load ptr, ptr %l167, !tbaa !29
  %t311 = load i64, ptr %t310, !range !{i64 0, i64 17}
  %t313 = icmp eq i64 %t311, 13
  store i1 %t313, ptr %l168, !tbaa !21
  br label %bb101
bb101:
  %t314 = load i1, ptr %l168, !tbaa !21
  br i1 %t314, label %bb102, label %bb103
bb102:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr { i64, [3 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", ptr }, ptr %t317, i32 0, i32 1
  %t319 = load ptr, ptr %t318
  store ptr %t319, ptr %l15, !tbaa !29
  br label %bb104
bb103:
  br label %bb113
bb104:
  %t321 = load ptr, ptr %l15, !tbaa !29
  %t323 = getelementptr %"compiler/typed:Join", ptr %t321, i32 0, i32 0
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t326 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t324, ptr %t326)
  br label %bb105
bb105:
  %t329 = load ptr, ptr %l15, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Join", ptr %t329, i32 0, i32 2
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  store { i64, ptr } %t332, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t334 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t334, 0
  store i64 %t336, ptr %l18, !tbaa !24
  br label %bb106
bb106:
  %t338 = load i64, ptr %l17, !tbaa !24
  %t339 = load i64, ptr %l18, !tbaa !24
  %t342 = icmp slt i64 %t338, %t339
  %t344 = xor i1 %t342, true
  br i1 %t344, label %bb107, label %bb108
bb107:
  br label %bb112
bb108:
  br label %bb109
bb109:
  %t346 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t346, ptr %l185, !tbaa !27
  %t347 = load i64, ptr %l17, !tbaa !24
  %t349 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr ptr, ptr %t350, i64 %t347
  %t352 = load ptr, ptr %t351, !tbaa !39
  %t356 = getelementptr %"compiler/typed:Clause", ptr %t352, i32 0, i32 3
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t358 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t357, ptr %t358)
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t361 = load i64, ptr %l17, !tbaa !24
  %t363 = add i64 %t361, 1
  store i64 %t363, ptr %l17, !tbaa !24
  br label %bb106
bb112:
  br label %bb166
bb113:
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t366 = load ptr, ptr %l193, !tbaa !29
  %t367 = icmp ne ptr %t366, null
  br i1 %t367, label %bb114, label %bb115
bb114:
  %t369 = load ptr, ptr %l193, !tbaa !29
  %t370 = load i64, ptr %t369, !range !{i64 0, i64 17}
  %t372 = icmp eq i64 %t370, 14
  store i1 %t372, ptr %l194, !tbaa !21
  br label %bb115
bb115:
  %t373 = load i1, ptr %l194, !tbaa !21
  br i1 %t373, label %bb116, label %bb117
bb116:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr { i64, [3 x i64] }, ptr %t374, i32 0, i32 1
  %t377 = getelementptr { %"compiler/source:Span", ptr }, ptr %t376, i32 0, i32 1
  %t378 = load ptr, ptr %t377
  store ptr %t378, ptr %l20, !tbaa !29
  br label %bb118
bb117:
  br label %bb154
bb118:
  %t380 = load ptr, ptr %l20, !tbaa !29
  %t382 = getelementptr %"compiler/typed:Spawn", ptr %t380, i32 0, i32 0
  %t383 = load { i64, ptr }, ptr %t382, !tbaa !27
  store { i64, ptr } %t383, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t385 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t385, 0
  store i64 %t387, ptr %l23, !tbaa !24
  br label %bb119
bb119:
  %t389 = load i64, ptr %l22, !tbaa !24
  %t390 = load i64, ptr %l23, !tbaa !24
  %t393 = icmp slt i64 %t389, %t390
  %t395 = xor i1 %t393, true
  br i1 %t395, label %bb120, label %bb121
bb120:
  br label %bb145
bb121:
  br label %bb122
bb122:
  %t397 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t397, ptr %l207, !tbaa !27
  %t398 = load i64, ptr %l22, !tbaa !24
  %t400 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr ptr, ptr %t401, i64 %t398
  %t403 = load ptr, ptr %t402, !tbaa !39
  store ptr %t403, ptr %l24, !tbaa !29
  %t405 = load ptr, ptr %l24, !tbaa !29
  %t407 = icmp eq ptr %t405, null
  br i1 %t407, label %bb123, label %bb124
bb123:
  br label %bb144
bb124:
  br label %bb125
bb125:
  %t409 = load ptr, ptr %l24, !tbaa !29
  %t411 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %t409)
  store i64 %t411, ptr %l213
  br label %bb126
bb126:
  %t412 = load i64, ptr %l213, !tbaa !24
  %t413 = icmp sge i64 %t412, 0
  br i1 %t413, label %bb127, label %bb128
bb127:
  %t415 = load ptr, ptr %l1, !tbaa !29
  %t417 = getelementptr %"compiler/scope:walked", ptr %t415, i32 0, i32 1
  store ptr %t417, ptr %l216, !tbaa !29
  %t418 = load ptr, ptr %l24, !tbaa !29
  %t420 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %t418)
  store i64 %t420, ptr %l218
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t421 = load ptr, ptr %l216, !tbaa !29
  %t422 = load i64, ptr %l218, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t421, i64 %t422)
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t423 = load ptr, ptr %l24, !tbaa !29
  %t425 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %t423)
  store i1 %t425, ptr %l220
  br label %bb132
bb132:
  %t426 = load i1, ptr %l220, !tbaa !21
  %t427 = xor i1 %t426, true
  br i1 %t427, label %bb133, label %bb134
bb133:
  %t429 = load ptr, ptr %l24, !tbaa !29
  %t431 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t429)
  store i64 %t431, ptr %l224
  br label %bb135
bb134:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb136
bb135:
  %t432 = load i64, ptr %l224, !tbaa !24
  %t433 = icmp sge i64 %t432, 0
  store i1 %t433, ptr %l222, !tbaa !21
  br label %bb136
bb136:
  %t435 = load i1, ptr %l222, !tbaa !21
  br i1 %t435, label %bb137, label %bb138
bb137:
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t438 = getelementptr %"compiler/scope:walked", ptr %t436, i32 0, i32 4
  store ptr %t438, ptr %l227, !tbaa !29
  %t439 = load ptr, ptr %l24, !tbaa !29
  %t441 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t439)
  store i64 %t441, ptr %l229
  br label %bb139
bb138:
  br label %bb141
bb139:
  %t442 = load ptr, ptr %l227, !tbaa !29
  %t443 = load i64, ptr %l229, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t442, i64 %t443)
  br label %bb140
bb140:
  br label %bb141
bb141:
  %t444 = load ptr, ptr %l24, !tbaa !29
  %t445 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectField(ptr %v0, ptr %v1, ptr %t444, ptr %t445)
  br label %bb142
bb142:
  %t448 = load ptr, ptr %l24, !tbaa !29
  %t450 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %t448, ptr %t450)
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t453 = load i64, ptr %l22, !tbaa !24
  %t455 = add i64 %t453, 1
  store i64 %t455, ptr %l22, !tbaa !24
  br label %bb119
bb145:
  %t457 = load ptr, ptr %l20, !tbaa !29
  %t459 = getelementptr %"compiler/typed:Spawn", ptr %t457, i32 0, i32 1
  %t460 = load ptr, ptr %t459, !tbaa !29
  %t462 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t460, ptr %t462)
  br label %bb146
bb146:
  %t465 = load ptr, ptr %l20, !tbaa !29
  %t467 = getelementptr %"compiler/typed:Spawn", ptr %t465, i32 0, i32 2
  %t468 = load { i64, ptr }, ptr %t467, !tbaa !27
  store { i64, ptr } %t468, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t470 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t470, 0
  store i64 %t472, ptr %l27, !tbaa !24
  br label %bb147
bb147:
  %t474 = load i64, ptr %l26, !tbaa !24
  %t475 = load i64, ptr %l27, !tbaa !24
  %t478 = icmp slt i64 %t474, %t475
  %t480 = xor i1 %t478, true
  br i1 %t480, label %bb148, label %bb149
bb148:
  br label %bb153
bb149:
  br label %bb150
bb150:
  %t482 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t482, ptr %l249, !tbaa !27
  %t483 = load i64, ptr %l26, !tbaa !24
  %t485 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !27
  %t487 = getelementptr ptr, ptr %t486, i64 %t483
  %t488 = load ptr, ptr %t487, !tbaa !39
  %t492 = getelementptr %"compiler/typed:TaskClause", ptr %t488, i32 0, i32 3
  %t493 = load ptr, ptr %t492, !tbaa !29
  %t494 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t493, ptr %t494)
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t497 = load i64, ptr %l26, !tbaa !24
  %t499 = add i64 %t497, 1
  store i64 %t499, ptr %l26, !tbaa !24
  br label %bb147
bb153:
  br label %bb166
bb154:
  %t501 = load ptr, ptr %l0, !tbaa !29
  store ptr %t501, ptr %l257, !tbaa !29
  store i1 false, ptr %l258, !tbaa !21
  %t502 = load ptr, ptr %l257, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb155, label %bb156
bb155:
  %t505 = load ptr, ptr %l257, !tbaa !29
  %t506 = load i64, ptr %t505, !range !{i64 0, i64 17}
  %t508 = icmp eq i64 %t506, 15
  store i1 %t508, ptr %l258, !tbaa !21
  br label %bb156
bb156:
  %t509 = load i1, ptr %l258, !tbaa !21
  br i1 %t509, label %bb157, label %bb158
bb157:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t512 = getelementptr { i64, [3 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", ptr }, ptr %t512, i32 0, i32 1
  %t514 = load ptr, ptr %t513
  store ptr %t514, ptr %l29, !tbaa !29
  br label %bb159
bb158:
  br label %bb161
bb159:
  %t516 = load ptr, ptr %l29, !tbaa !29
  %t518 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t516, ptr %t518)
  br label %bb160
bb160:
  br label %bb166
bb161:
  br i1 true, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_1f46f0e2a5866641_40fe5c75700827d5)
  unreachable
bb166:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesFirst(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 24
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %s0, ptr %t3)
  store { i64, ptr } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = mul i64 %t9, 8
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = mul i64 %t18, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eFoldStats(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca i32
  %l21 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l54 = alloca %"compiler/typed:Plan"
  %l56 = alloca %"compiler/typed:Plan"
  %l62 = alloca i64
  %l65 = alloca i64
  %l86 = alloca %"compiler/typed:Plan"
  %l88 = alloca %"compiler/typed:Plan"
  %l89 = alloca { i64, ptr }
  %l98 = alloca i1
  %l105 = alloca i64
  %l108 = alloca i64
  %l110 = alloca i1
  %l115 = alloca %"compiler/typed:BlockInfo"
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t67 = alloca %"compiler/typed:Plan", align 8
  %t70 = alloca %"compiler/typed:Plan", align 8
  %t127 = alloca %"compiler/typed:Plan", align 8
  %t130 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load i64, ptr %l21, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l28, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l28, !tbaa !24
  store i64 %t33, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l25, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l49
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l49, !tbaa !29
  store ptr %t60, ptr %l9, !tbaa !29
  %t61 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t61, ptr %l50
  br label %bb13
bb13:
  %t62 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l50
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t62, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 2
  %t66 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t67, ptr %v0, ptr %v0, ptr %t65, i64 %t66)
  call void @llvm.memmove.p0.p0.i64(ptr %l54, ptr %t67, i64 176, i1 false)
  br label %bb14
bb14:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t70, ptr %v0, ptr %l54)
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %t70, i64 176, i1 false)
  br label %bb15
bb15:
  %t72 = getelementptr %"compiler/typed:Plan", ptr %l56, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  store i64 %t75, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t77 = load i64, ptr %l12, !tbaa !24
  %t78 = load i64, ptr %l11, !tbaa !24
  %t81 = icmp sgt i64 %t77, %t78
  br i1 %t81, label %bb16, label %bb17
bb16:
  %t83 = load i64, ptr %l13, !tbaa !24
  %t85 = icmp sgt i64 %t83, 0
  br i1 %t85, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb21
bb18:
  %t87 = load i64, ptr %l12, !tbaa !24
  %t88 = load i64, ptr %l11, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t92 = load i64, ptr %l13, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  store i64 %t101, ptr %l65, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb20
bb20:
  %t103 = load i64, ptr %l65, !tbaa !24
  store i64 %t103, ptr %l62, !tbaa !24
  br label %bb21
bb21:
  %t104 = load i64, ptr %l62, !tbaa !24
  store i64 %t104, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb22
bb22:
  %t105 = load i64, ptr %l15, !tbaa !24
  %t106 = load i64, ptr %l14, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb23, label %bb24
bb23:
  br label %bb51
bb24:
  br label %bb25
bb25:
  %t113 = load i64, ptr %l11, !tbaa !24
  %t114 = load i64, ptr %l15, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = mul i64 %t114, %t115
  %t121 = add i64 %t113, %t118
  store i64 %t121, ptr %l16, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 2
  %t126 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t127, ptr %v0, ptr %v0, ptr %t125, i64 %t126)
  call void @llvm.memmove.p0.p0.i64(ptr %l86, ptr %t127, i64 176, i1 false)
  br label %bb26
bb26:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t130, ptr %v0, ptr %l86)
  call void @llvm.memmove.p0.p0.i64(ptr %l88, ptr %t130, i64 176, i1 false)
  br label %bb27
bb27:
  %t132 = getelementptr %"compiler/typed:Plan", ptr %l88, i32 0, i32 0
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l89, !tbaa !27
  %t134 = load i64, ptr %l16, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr { i64, [1 x i64] }, ptr %t137, i64 %t134
  %t139 = load { i64, [1 x i64] }, ptr %t138
  store { i64, [1 x i64] } %t139, ptr %l17
  %t141 = load { i64, [1 x i64] }, ptr %l17
  %t143 = extractvalue { i64, [1 x i64] } %t141, 0
  %t144 = icmp eq i64 %t143, 1
  br i1 %t144, label %bb28, label %bb29
bb28:
  %t146 = getelementptr { i64, [1 x i64] }, ptr %l17, i32 0, i32 1
  %t147 = getelementptr { i32 }, ptr %t146, i32 0, i32 0
  %t148 = load i32, ptr %t147
  store i32 %t148, ptr %l18, !tbaa !23
  br label %bb30
bb29:
  br label %bb44
bb30:
  %t150 = load i32, ptr %l18, !tbaa !23
  %t152 = sext i32 %t150 to i64
  %t155 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s2, ptr %l10, i64 %t152)
  store i1 %t155, ptr %l98
  br label %bb31
bb31:
  %t156 = load i1, ptr %l98, !tbaa !21
  br i1 %t156, label %bb32, label %bb33
bb32:
  br label %bb50
bb33:
  br label %bb34
bb34:
  %t157 = load i32, ptr %l18, !tbaa !23
  %t159 = sext i32 %t157 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s2, ptr %l10, i64 %t159, i1 true)
  br label %bb35
bb35:
  %t162 = load i64, ptr %l2, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l2, !tbaa !24
  %t166 = load i32, ptr %l18, !tbaa !23
  %t168 = sext i32 %t166 to i64
  store i64 %t168, ptr %l105, !tbaa !24
  %t169 = load ptr, ptr %l9, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Body", ptr %t169, i32 0, i32 8
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t171)
  store i64 %t173, ptr %l108
  br label %bb36
bb36:
  %t174 = load i64, ptr %l105, !tbaa !24
  %t175 = load i64, ptr %l108, !tbaa !24
  %t176 = icmp slt i64 %t174, %t175
  br i1 %t176, label %bb37, label %bb38
bb37:
  %t178 = load ptr, ptr %l9, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Body", ptr %t178, i32 0, i32 8
  %t181 = load i32, ptr %l18, !tbaa !23
  %t183 = sext i32 %t181 to i64
  %t186 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t180, i64 %t183)
  store %"compiler/typed:BlockInfo" %t186, ptr %l115
  br label %bb39
bb38:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb40
bb39:
  %t187 = getelementptr %"compiler/typed:BlockInfo", ptr %l115, i32 0, i32 1
  %t188 = load i32, ptr %t187, !range !{i32 0, i32 9}
  %t190 = trunc i64 1 to i32
  %t191 = icmp eq i32 %t188, %t190
  store i1 %t191, ptr %l110, !tbaa !21
  br label %bb40
bb40:
  %t193 = load i1, ptr %l110, !tbaa !21
  br i1 %t193, label %bb41, label %bb42
bb41:
  %t194 = load i64, ptr %l1, !tbaa !24
  %t196 = add i64 %t194, 1
  store i64 %t196, ptr %l1, !tbaa !24
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_c4dcb08f8057e6b4_879f1d415f5e90f0)
  unreachable
bb49:
  br label %bb50
bb50:
  %t198 = load i64, ptr %l15, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l15, !tbaa !24
  br label %bb22
bb51:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb52:
  %t202 = load i64, ptr %l7, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l7, !tbaa !24
  br label %bb8
bb53:
  %t206 = load i64, ptr %l2, !tbaa !24
  %t207 = load i64, ptr %l1, !tbaa !24
  %t208 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t211 = call i64 @__olang_fmt_i64(ptr null, i64 %t206)
  %t212 = add i64 %t209, %t211
  %t213 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t217 = call i64 @__olang_fmt_i64(ptr null, i64 %t207)
  %t218 = add i64 %t215, %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t208, i64 %t209)
  %t220 = getelementptr i8, ptr %t219, i64 %t209
  %t221 = call i64 @__olang_fmt_i64(ptr %t220, i64 %t206)
  %t222 = getelementptr i8, ptr %t220, i64 %t211
  call void @olang_textcopy(ptr %t222, ptr %t213, i64 %t214)
  %t223 = getelementptr i8, ptr %t222, i64 %t214
  %t224 = call i64 @__olang_fmt_i64(ptr %t223, i64 %t207)
  %t225 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t219, 1
  store { i64, ptr } %t226, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/scope:rel"
  %lp7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca %"compiler/scope:rel"
  %l37 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l46 = alloca i1
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 6
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_H9c3932eb53016bf6f47a08eef06aacbe(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %lp3
  %t17 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v2, ptr %v2, ptr %t15)
  store { i64, ptr } %t17, ptr %l15
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t18 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t18, ptr %l16, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l17, !tbaa !24
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = mul i64 %t21, 16
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l18, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l17, !tbaa !24
  %t31 = mul i64 %t30, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l16, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/scope:Scoper", ptr %t34, i32 0, i32 6
  %t37 = load i64, ptr %l1, !tbaa !24
  %t40 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t36, i64 %t37)
  store ptr %t40, ptr %l22
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t43 = getelementptr %"compiler/scope:summary", ptr %t41, i32 0, i32 0
  store ptr %t43, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i64, ptr %l5, !tbaa !24
  store i64 %t45, ptr %l25, !tbaa !24
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l27
  br label %bb9
bb9:
  %t49 = load i64, ptr %l25, !tbaa !24
  %t50 = load i64, ptr %l27, !tbaa !24
  %t51 = icmp slt i64 %t49, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb11:
  br label %bb12
bb12:
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t55, i64 %t56)
  store %"compiler/scope:rel" %t59, ptr %l32
  br label %bb13
bb13:
  %t60 = load %"compiler/scope:rel", ptr %l32
  store %"compiler/scope:rel" %t60, ptr %l6
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 0
  %t64 = load { i64, [2 x i64] }, ptr %t63
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t70 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etermName(ptr %v0, ptr %v1, ptr %s3, ptr %t61, i64 %t62, { i64, [2 x i64] } %t64, ptr %t65)
  store { i64, ptr } %t70, ptr %l37
  br label %bb14
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i64, ptr %l1, !tbaa !24
  %t73 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 1
  %t74 = load { i64, [2 x i64] }, ptr %t73
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t80 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etermName(ptr %v0, ptr %v1, ptr %s3, ptr %t71, i64 %t72, { i64, [2 x i64] } %t74, ptr %t75)
  store { i64, ptr } %t80, ptr %l42
  br label %bb15
bb15:
  %t81 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t87 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = add i64 %t86, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t82, i64 %t83)
  %t92 = getelementptr i8, ptr %t91, i64 %t83
  call void @olang_textcopy(ptr %t92, ptr %t84, i64 %t85)
  %t93 = getelementptr i8, ptr %t92, i64 %t85
  call void @olang_textcopy(ptr %t93, ptr %t88, i64 %t89)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t91, 1
  %t96 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t96, ptr %lp7
  %t98 = load ptr, ptr %lp7
  store { i64, ptr } %t95, ptr %t98, !tbaa !27
  %t99 = load ptr, ptr %lp3
  %t100 = load ptr, ptr %lp7
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t104 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v2, ptr %v2, ptr %t99, { i64, ptr } %t101)
  store i1 %t104, ptr %l46
  br label %bb16
bb16:
  %t105 = load i1, ptr %l46, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb17, label %bb18
bb17:
  %t108 = load ptr, ptr %lp3
  %t109 = load ptr, ptr %lp7
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t108, { i64, ptr } %t110)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t113 = load i64, ptr %l5, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l5, !tbaa !24
  br label %bb8
bb22:
  %t117 = load ptr, ptr %lp3
  %t119 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v2, ptr %v2, ptr %t117)
  store { i64, ptr } %t119, ptr %l53
  br label %bb23
bb23:
  %t120 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t120, ptr %l54, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  store i64 %t122, ptr %l55, !tbaa !24
  %t123 = load i64, ptr %l55, !tbaa !24
  %t124 = mul i64 %t123, 16
  %t125 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l56, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = load i64, ptr %l55, !tbaa !24
  %t133 = mul i64 %t132, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t129, ptr %t131, i64 %t133, i1 false)
  %t134 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t134, ptr %l54, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t135, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsOwn(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 42
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, ptr } %t12, 1
  %t14 = extractvalue { i32, ptr } %t12, 0
  store i32 %t14, ptr %l11
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  store ptr %t13, ptr %l10
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l10, !tbaa !29
  store ptr %t17, ptr %l6, !tbaa !29
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %rv
  br label %ret
bb7:
  %t19 = load ptr, ptr %l6, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorBuilt(ptr %v0, ptr %v0, ptr %t20, ptr %t19)
  store i1 %t24, ptr %l15
  br label %bb8
bb8:
  %t25 = load i1, ptr %l15, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeBuilds(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t15 = load ptr, ptr %l4, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 5}
  %t22 = icmp eq i64 %t20, 4
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8066e5da37f3a23b_ece6b8d6fabe8bf7)
  unreachable
bb15:
  %t31 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsSum(ptr %v0, ptr %a0, i64 %a2, i64 %a3)
  store i1 %t31, ptr %l19
  br label %bb16
bb16:
  %t32 = load i1, ptr %l19, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 1
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 1
  %t33 = load { i64, [2 x i64] }, ptr %t32
  store { i64, [2 x i64] } %t33, ptr %l4
  %t35 = load { i64, [2 x i64] }, ptr %l4
  %t37 = extractvalue { i64, [2 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 0
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t41 = getelementptr { i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l5, !tbaa !24
  br label %bb9
bb8:
  br label %bb13
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l27, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l29, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l33
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l29, !tbaa !29
  %t67 = load i64, ptr %l33, !tbaa !24
  %t68 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t66, i64 %t67)
  store ptr %t68, ptr %l34
  br label %bb11
bb11:
  %t69 = load ptr, ptr %l34, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Func", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  %t73 = load ptr, ptr %l27, !tbaa !29
  %t75 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t73, i32 %t72)
  store { i64, ptr } %t75, ptr %l37
  br label %bb12
bb12:
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t77, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t81, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_a571972fdacfaed1_c7933b0216b7b5ad)
  unreachable
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_9f9bf081c1674640_32724a584f79d5fc)
  unreachable
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t83, ptr %l40, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l41, !tbaa !24
  %t86 = load i64, ptr %l41, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l42, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l41, !tbaa !24
  %t96 = mul i64 %t95, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t92, ptr %t94, i64 %t96, i1 false)
  %t97 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t97, ptr %l40, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallsItself(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 12
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i64, ptr %l11, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/scope:Scoper", ptr %t9, i32 0, i32 12
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t12, 1
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t11, i64 %t14)
  store i64 %t17, ptr %l16
  br label %bb2
bb2:
  %t18 = load i64, ptr %l16, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l23, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l20, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l20, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/scope:Scoper", ptr %t65, i32 0, i32 13
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t67, i64 %t63)
  store i64 %t71, ptr %l44
  br label %bb13
bb13:
  %t72 = load i64, ptr %l1, !tbaa !24
  %t73 = load i64, ptr %l44, !tbaa !24
  %t75 = icmp eq i64 %t73, %t72
  br i1 %t75, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb9
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %a1, ptr %l2)
  br label %bb2
bb2:
  store ptr %l2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l12, !tbaa !24
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t11)
  store i64 %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = load i64, ptr %l14, !tbaa !24
  %t16 = icmp slt i64 %t14, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t20, i64 %t21)
  store i64 %t24, ptr %l19
  br label %bb8
bb8:
  %t25 = load i64, ptr %l19, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 110
  %t32 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t28, i64 %t25)
  store i1 %t32, ptr %l23
  br label %bb9
bb9:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb3
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecomponents(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/scope:walked"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca %"compiler/scope:walked"
  %l67 = alloca i64
  %l69 = alloca i64
  %l74 = alloca i64
  %l81 = alloca ptr
  %l84 = alloca i64
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca i64
  %l100 = alloca ptr
  %l103 = alloca i64
  %l105 = alloca i64
  %l107 = alloca i64
  %l112 = alloca i64
  %l119 = alloca i64
  %l123 = alloca i64
  %l126 = alloca i64
  %l145 = alloca ptr
  %l148 = alloca ptr
  %l151 = alloca i32
  %l152 = alloca i32
  %l153 = alloca i64
  %l156 = alloca i64
  %l157 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l169 = alloca ptr
  %l172 = alloca i64
  %l174 = alloca ptr
  %l177 = alloca i64
  %l179 = alloca ptr
  %l182 = alloca i64
  %l187 = alloca i64
  %l190 = alloca i64
  %l211 = alloca i64
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %t67 = alloca %"compiler/scope:walked", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l32
  br label %bb1
bb1:
  %t6 = load i64, ptr %l32, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l40, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l40, !tbaa !24
  store i64 %t35, ptr %l37, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l37, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb68
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %t55, i32 0, i32 12
  store ptr %t57, ptr %l59, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 13
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t60)
  store i64 %t62, ptr %l62
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l59, !tbaa !29
  %t64 = load i64, ptr %l62, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fscope_2ewalkBody(ptr %t67, ptr %v0, ptr %s2, ptr %t65, i64 %t66)
  call void @llvm.memmove.p0.p0.i64(ptr %l65, ptr %t67, i64 224, i1 false)
  br label %bb14
bb14:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l65, i64 224, i1 false)
  %t70 = getelementptr %"compiler/scope:walked", ptr %l8, i32 0, i32 0
  store ptr %t70, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  %t72 = load i64, ptr %l10, !tbaa !24
  store i64 %t72, ptr %l67, !tbaa !24
  %t73 = load ptr, ptr %l9, !tbaa !29
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t73)
  store i64 %t75, ptr %l69
  br label %bb16
bb16:
  %t76 = load i64, ptr %l67, !tbaa !24
  %t77 = load i64, ptr %l69, !tbaa !24
  %t78 = icmp slt i64 %t76, %t77
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l9, !tbaa !29
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l74
  br label %bb20
bb20:
  %t87 = load i64, ptr %l74, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/scope:Scoper", ptr %t88, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t90, i64 %t87)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t94 = load i64, ptr %l10, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l10, !tbaa !24
  br label %bb15
bb23:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/scope:Scoper", ptr %t98, i32 0, i32 14
  store ptr %t100, ptr %l81, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/scope:Scoper", ptr %t101, i32 0, i32 15
  %t105 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t103)
  store i64 %t105, ptr %l84
  br label %bb24
bb24:
  %t106 = load ptr, ptr %l81, !tbaa !29
  %t107 = load i64, ptr %l84, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t106, i64 %t107)
  br label %bb25
bb25:
  %t108 = getelementptr %"compiler/scope:walked", ptr %l8, i32 0, i32 1
  store ptr %t108, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t110 = load i64, ptr %l13, !tbaa !24
  store i64 %t110, ptr %l86, !tbaa !24
  %t111 = load ptr, ptr %l12, !tbaa !29
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t111)
  store i64 %t113, ptr %l88
  br label %bb27
bb27:
  %t114 = load i64, ptr %l86, !tbaa !24
  %t115 = load i64, ptr %l88, !tbaa !24
  %t116 = icmp slt i64 %t114, %t115
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb28, label %bb29
bb28:
  br label %bb34
bb29:
  br label %bb30
bb30:
  %t120 = load ptr, ptr %l12, !tbaa !29
  %t121 = load i64, ptr %l13, !tbaa !24
  %t124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t120, i64 %t121)
  store i64 %t124, ptr %l93
  br label %bb31
bb31:
  %t125 = load i64, ptr %l93, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/scope:Scoper", ptr %t126, i32 0, i32 15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t128, i64 %t125)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t132 = load i64, ptr %l13, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l13, !tbaa !24
  br label %bb26
bb34:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/scope:Scoper", ptr %t136, i32 0, i32 16
  store ptr %t138, ptr %l100, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %t139, i32 0, i32 17
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t141)
  store i64 %t143, ptr %l103
  br label %bb35
bb35:
  %t144 = load ptr, ptr %l100, !tbaa !29
  %t145 = load i64, ptr %l103, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t144, i64 %t145)
  br label %bb36
bb36:
  %t146 = getelementptr %"compiler/scope:walked", ptr %l8, i32 0, i32 2
  store ptr %t146, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb37
bb37:
  %t148 = load i64, ptr %l16, !tbaa !24
  store i64 %t148, ptr %l105, !tbaa !24
  %t149 = load ptr, ptr %l15, !tbaa !29
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t149)
  store i64 %t151, ptr %l107
  br label %bb38
bb38:
  %t152 = load i64, ptr %l105, !tbaa !24
  %t153 = load i64, ptr %l107, !tbaa !24
  %t154 = icmp slt i64 %t152, %t153
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb39, label %bb40
bb39:
  br label %bb45
bb40:
  br label %bb41
bb41:
  %t158 = load ptr, ptr %l15, !tbaa !29
  %t159 = load i64, ptr %l16, !tbaa !24
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t158, i64 %t159)
  store i64 %t162, ptr %l112
  br label %bb42
bb42:
  %t163 = load i64, ptr %l112, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/scope:Scoper", ptr %t164, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t166, i64 %t163)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t170 = load i64, ptr %l16, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l16, !tbaa !24
  br label %bb37
bb45:
  store i64 0, ptr %l18, !tbaa !24
  %t174 = getelementptr %"compiler/scope:walked", ptr %l8, i32 0, i32 5
  %t176 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s2, ptr %t174)
  store i64 %t176, ptr %l119
  br label %bb46
bb46:
  %t177 = load i64, ptr %l119, !tbaa !24
  store i64 %t177, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t178 = load i64, ptr %l19, !tbaa !24
  %t179 = load i64, ptr %l18, !tbaa !24
  %t182 = icmp sgt i64 %t178, %t179
  br i1 %t182, label %bb47, label %bb48
bb47:
  %t184 = load i64, ptr %l20, !tbaa !24
  %t186 = icmp sgt i64 %t184, 0
  br i1 %t186, label %bb49, label %bb50
bb48:
  store i64 0, ptr %l123, !tbaa !24
  br label %bb52
bb49:
  %t188 = load i64, ptr %l19, !tbaa !24
  %t189 = load i64, ptr %l18, !tbaa !24
  %t192 = sub i64 %t188, %t189
  %t193 = load i64, ptr %l20, !tbaa !24
  %t196 = add i64 %t192, %t193
  %t198 = sub i64 %t196, 1
  %t199 = load i64, ptr %l20, !tbaa !24
  %t202 = sdiv i64 %t198, %t199
  store i64 %t202, ptr %l126, !tbaa !24
  br label %bb51
bb50:
  store i64 0, ptr %l126, !tbaa !24
  br label %bb51
bb51:
  %t204 = load i64, ptr %l126, !tbaa !24
  store i64 %t204, ptr %l123, !tbaa !24
  br label %bb52
bb52:
  %t205 = load i64, ptr %l123, !tbaa !24
  store i64 %t205, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s13
  %t206 = load i64, ptr %l22, !tbaa !24
  %t207 = load i64, ptr %l21, !tbaa !24
  %t210 = icmp slt i64 %t206, %t207
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s13)
  br label %bb63
bb55:
  br label %bb56
bb56:
  %t214 = load i64, ptr %l18, !tbaa !24
  %t215 = load i64, ptr %l22, !tbaa !24
  %t216 = load i64, ptr %l20, !tbaa !24
  %t219 = mul i64 %t215, %t216
  %t222 = add i64 %t214, %t219
  store i64 %t222, ptr %l23, !tbaa !24
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/scope:Scoper", ptr %t224, i32 0, i32 47
  store ptr %t226, ptr %l145, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/scope:Scoper", ptr %t227, i32 0, i32 0
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = getelementptr %"compiler/generic:Program", ptr %t230, i32 0, i32 2
  store ptr %t232, ptr %l148, !tbaa !29
  %t233 = getelementptr %"compiler/scope:walked", ptr %l8, i32 0, i32 5
  %t234 = load i64, ptr %l23, !tbaa !24
  %t237 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s2, ptr %t233, i64 %t234)
  store i32 %t237, ptr %l151
  br label %bb57
bb57:
  %t238 = load ptr, ptr %l148, !tbaa !29
  %t239 = load i32, ptr %l151, !tbaa !23
  %t240 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t238, i32 %t239)
  store i32 %t240, ptr %l152
  br label %bb58
bb58:
  %t241 = load i32, ptr %l152, !tbaa !23
  %t242 = sext i32 %t241 to i64
  store i64 %t242, ptr %l153, !tbaa !24
  %t243 = getelementptr %"compiler/scope:walked", ptr %l8, i32 0, i32 6
  %t244 = load i64, ptr %l23, !tbaa !24
  %t247 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t243, i64 %t244)
  store i64 %t247, ptr %l156
  br label %bb59
bb59:
  %t248 = load i64, ptr %l153, !tbaa !24
  %t249 = load i64, ptr %l156, !tbaa !24
  %t250 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s13, i64 %t248, i64 %t249)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t250, ptr %l157
  br label %bb60
bb60:
  %t251 = load ptr, ptr %l145, !tbaa !29
  %t252 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l157
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t251, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t252, i1 true)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb62
bb62:
  %t253 = load i64, ptr %l22, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l22, !tbaa !24
  br label %bb53
bb63:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/scope:Scoper", ptr %t257, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t259, i64 -1)
  br label %bb64
bb64:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/scope:Scoper", ptr %t261, i32 0, i32 19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t263, i64 0)
  br label %bb65
bb65:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/scope:Scoper", ptr %t265, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t267, i1 false)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb67:
  %t269 = load i64, ptr %l6, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l6, !tbaa !24
  br label %bb8
bb68:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/scope:Scoper", ptr %t273, i32 0, i32 12
  store ptr %t275, ptr %l169, !tbaa !29
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/scope:Scoper", ptr %t276, i32 0, i32 13
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t278)
  store i64 %t280, ptr %l172
  br label %bb69
bb69:
  %t281 = load ptr, ptr %l169, !tbaa !29
  %t282 = load i64, ptr %l172, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t281, i64 %t282)
  br label %bb70
bb70:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/scope:Scoper", ptr %t283, i32 0, i32 14
  store ptr %t285, ptr %l174, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/scope:Scoper", ptr %t286, i32 0, i32 15
  %t290 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t288)
  store i64 %t290, ptr %l177
  br label %bb71
bb71:
  %t291 = load ptr, ptr %l174, !tbaa !29
  %t292 = load i64, ptr %l177, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t291, i64 %t292)
  br label %bb72
bb72:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/scope:Scoper", ptr %t293, i32 0, i32 16
  store ptr %t295, ptr %l179, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/scope:Scoper", ptr %t296, i32 0, i32 17
  %t300 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t298)
  store i64 %t300, ptr %l182
  br label %bb73
bb73:
  %t301 = load ptr, ptr %l179, !tbaa !29
  %t302 = load i64, ptr %l182, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t301, i64 %t302)
  br label %bb74
bb74:
  store i64 0, ptr %l24, !tbaa !24
  %t303 = load i64, ptr %l1, !tbaa !24
  store i64 %t303, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t305 = load i64, ptr %l25, !tbaa !24
  %t306 = load i64, ptr %l24, !tbaa !24
  %t309 = icmp sgt i64 %t305, %t306
  br i1 %t309, label %bb75, label %bb76
bb75:
  %t311 = load i64, ptr %l26, !tbaa !24
  %t313 = icmp sgt i64 %t311, 0
  br i1 %t313, label %bb77, label %bb78
bb76:
  store i64 0, ptr %l187, !tbaa !24
  br label %bb80
bb77:
  %t315 = load i64, ptr %l25, !tbaa !24
  %t316 = load i64, ptr %l24, !tbaa !24
  %t319 = sub i64 %t315, %t316
  %t320 = load i64, ptr %l26, !tbaa !24
  %t323 = add i64 %t319, %t320
  %t325 = sub i64 %t323, 1
  %t326 = load i64, ptr %l26, !tbaa !24
  %t329 = sdiv i64 %t325, %t326
  store i64 %t329, ptr %l190, !tbaa !24
  br label %bb79
bb78:
  store i64 0, ptr %l190, !tbaa !24
  br label %bb79
bb79:
  %t331 = load i64, ptr %l190, !tbaa !24
  store i64 %t331, ptr %l187, !tbaa !24
  br label %bb80
bb80:
  %t332 = load i64, ptr %l187, !tbaa !24
  store i64 %t332, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb81
bb81:
  %t333 = load i64, ptr %l28, !tbaa !24
  %t334 = load i64, ptr %l27, !tbaa !24
  %t337 = icmp slt i64 %t333, %t334
  %t339 = xor i1 %t337, true
  br i1 %t339, label %bb82, label %bb83
bb82:
  br label %bb91
bb83:
  br label %bb84
bb84:
  %t341 = load i64, ptr %l24, !tbaa !24
  %t342 = load i64, ptr %l28, !tbaa !24
  %t343 = load i64, ptr %l26, !tbaa !24
  %t346 = mul i64 %t342, %t343
  %t349 = add i64 %t341, %t346
  store i64 %t349, ptr %l29, !tbaa !24
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/scope:Scoper", ptr %t351, i32 0, i32 18
  %t354 = load i64, ptr %l29, !tbaa !24
  %t357 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t353, i64 %t354)
  store i64 %t357, ptr %l211
  br label %bb85
bb85:
  %t358 = load i64, ptr %l211, !tbaa !24
  %t359 = icmp slt i64 %t358, 0
  br i1 %t359, label %bb86, label %bb87
bb86:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i64, ptr %l29, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evisit(ptr %v0, ptr %t361, i64 %t362)
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t365 = load i64, ptr %l28, !tbaa !24
  %t367 = add i64 %t365, 1
  store i64 %t367, ptr %l28, !tbaa !24
  br label %bb81
bb91:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edecide(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca %"compiler/typed:Local"
  %l7 = alloca i1
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l26 = alloca %"compiler/typed:Local"
  %l36 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l50 = alloca i1
  %l53 = alloca { i64, [2 x i64] }
  %l56 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l63 = alloca i1
  %l65 = alloca { i64, [2 x i64] }
  %l67 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l100 = alloca i1
  %l102 = alloca { i64, ptr }
  %l104 = alloca i64
  %l110 = alloca i1
  %l113 = alloca i1
  %l123 = alloca ptr
  %l129 = alloca ptr
  %l133 = alloca ptr
  %l139 = alloca i64
  %l142 = alloca i1
  %l145 = alloca i1
  %l150 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca ptr
  %l158 = alloca i32
  %l159 = alloca i64
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l167 = alloca i32
  %l168 = alloca i64
  %l174 = alloca i1
  %l176 = alloca i1
  %l180 = alloca i1
  %t2 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t2
  %t3 = getelementptr { i64, [2 x i64] }, ptr %t2, i32 0, i32 0
  store i64 0, ptr %t3
  %t4 = load { i64, [2 x i64] }, ptr %t2
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 102
  store { i64, [2 x i64] } %t4, ptr %t7
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 103
  store i1 false, ptr %t10, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 106
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 25
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  br i1 %t19, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_be4231f99dfc50a7_6a00356b78c435db)
  unreachable
bb2:
  br label %bb3
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 25
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 7
  %t28 = load i32, ptr %l1, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t33 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t27, i64 %t30)
  store %"compiler/typed:Local" %t33, ptr %l26
  br label %bb4
bb4:
  %t34 = load %"compiler/typed:Local", ptr %l26
  store %"compiler/typed:Local" %t34, ptr %l5
  %t35 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t36 = load i32, ptr %t35, !range !{i32 0, i32 7}
  %t38 = trunc i64 2 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 25
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  br i1 %t46, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_badc8ccdfeb92288_a041b08d3fc96aec)
  unreachable
bb9:
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/scope:Scoper", ptr %t48, i32 0, i32 25
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t51, i32 0, i32 1
  %t55 = load { i64, [2 x i64] }, ptr %t54
  %t59 = extractvalue { i64, [2 x i64] } %t55, 0
  %t60 = icmp eq i64 %t59, 1
  br i1 %t60, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_58d2ded8d237a84_721cf65762561fa8)
  unreachable
bb19:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l7, !tbaa !21
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/typed:Local", ptr %l5
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t69 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2equalifiesMove(ptr %v0, ptr %v1, ptr %t63, %"compiler/typed:Local" %t64, ptr %t65)
  store i1 %t69, ptr %l42
  br label %bb20
bb20:
  %t70 = load i1, ptr %l42, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  %t71 = load i1, ptr %l7, !tbaa !21
  %t73 = xor i1 %t71, true
  store i1 %t73, ptr %l43, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l43, !tbaa !21
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l1, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t82 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %t76, i64 %t79)
  store i1 %t82, ptr %l50
  br label %bb26
bb25:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb27
bb26:
  %t83 = load i1, ptr %l50, !tbaa !21
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l46, !tbaa !21
  br label %bb27
bb27:
  %t86 = load i1, ptr %l46, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultTerm(ptr %v0, ptr %t87, i64 0)
  store { i64, [2 x i64] } %t89, ptr %l53
  br label %bb30
bb29:
  br label %bb71
bb30:
  %t90 = load { i64, [2 x i64] }, ptr %l53
  store { i64, [2 x i64] } %t90, ptr %l8
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load { i64, [2 x i64] }, ptr %l8
  %t95 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisBlock(ptr %v0, ptr %t91, { i64, [2 x i64] } %t92)
  store i1 %t95, ptr %l56
  br label %bb31
bb31:
  %t96 = load i1, ptr %l56, !tbaa !21
  br i1 %t96, label %bb32, label %bb33
bb32:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t99 = load i32, ptr %t98, !tbaa !23
  %t102 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t97, i32 %t99)
  store i1 %t102, ptr %l60
  br label %bb34
bb33:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb35
bb34:
  %t103 = load i1, ptr %l60, !tbaa !21
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb35
bb35:
  %t104 = load i1, ptr %l57, !tbaa !21
  br i1 %t104, label %bb36, label %bb37
bb36:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereturnsArray(ptr %v0, ptr %t105)
  store i1 %t107, ptr %l63
  br label %bb38
bb37:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb39
bb38:
  %t108 = load i1, ptr %l63, !tbaa !21
  store i1 %t108, ptr %l61, !tbaa !21
  br label %bb39
bb39:
  %t109 = load i1, ptr %l61, !tbaa !21
  br i1 %t109, label %bb40, label %bb41
bb40:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorageTerm(ptr %v0, ptr %t110)
  store { i64, [2 x i64] } %t112, ptr %l65
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t113 = load { i64, [2 x i64] }, ptr %l65
  store { i64, [2 x i64] } %t113, ptr %l8
  br label %bb43
bb43:
  %t114 = load { i64, [2 x i64] }, ptr %l8
  %t116 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t114)
  store i1 %t116, ptr %l67
  br label %bb44
bb44:
  %t117 = load i1, ptr %l67, !tbaa !21
  br i1 %t117, label %bb45, label %bb46
bb45:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load { i64, [2 x i64] }, ptr %l8
  %t122 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisBlock(ptr %v0, ptr %t118, { i64, [2 x i64] } %t119)
  store i1 %t122, ptr %l71
  br label %bb47
bb46:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb48
bb47:
  %t123 = load i1, ptr %l71, !tbaa !21
  %t124 = xor i1 %t123, true
  store i1 %t124, ptr %l68, !tbaa !21
  br label %bb48
bb48:
  %t126 = load i1, ptr %l68, !tbaa !21
  br i1 %t126, label %bb49, label %bb50
bb49:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowStart(ptr %v0, ptr %t127, i32 %t128, i64 0)
  br label %bb51
bb50:
  br label %bb70
bb51:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/scope:Scoper", ptr %t131, i32 0, i32 118
  store i1 false, ptr %t133, !tbaa !21
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t136 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowRun(ptr %v0, ptr %v2, ptr %t134, { i64, ptr } %t135, i64 %t136)
  br label %bb52
bb52:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/scope:Scoper", ptr %t140, i32 0, i32 118
  store i1 true, ptr %t142, !tbaa !21
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/scope:Scoper", ptr %t143, i32 0, i32 111
  %t146 = load i32, ptr %l1, !tbaa !23
  %t148 = sext i32 %t146 to i64
  %t151 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t145, i64 %t148)
  store i1 %t151, ptr %l84
  br label %bb53
bb53:
  %t152 = load i1, ptr %l84, !tbaa !21
  br i1 %t152, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb61
bb55:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/scope:Scoper", ptr %t153, i32 0, i32 110
  %t156 = load i32, ptr %l1, !tbaa !23
  %t158 = sext i32 %t156 to i64
  %t161 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t155, i64 %t158)
  store i1 %t161, ptr %l90
  br label %bb56
bb56:
  %t162 = load i1, ptr %l90, !tbaa !21
  br i1 %t162, label %bb57, label %bb58
bb57:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l2, !tbaa !29
  %t167 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etiedToBlock(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  store i1 %t167, ptr %l94
  br label %bb59
bb58:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb60
bb59:
  %t168 = load i1, ptr %l94, !tbaa !21
  %t169 = xor i1 %t168, true
  store i1 %t169, ptr %l91, !tbaa !21
  br label %bb60
bb60:
  %t171 = load i1, ptr %l91, !tbaa !21
  store i1 %t171, ptr %l85, !tbaa !21
  br label %bb61
bb61:
  %t172 = load i1, ptr %l85, !tbaa !21
  br i1 %t172, label %bb62, label %bb63
bb62:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load { i64, [2 x i64] }, ptr %l8
  %t177 = getelementptr %"compiler/scope:Scoper", ptr %t173, i32 0, i32 102
  store { i64, [2 x i64] } %t174, ptr %t177
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t180 = load i32, ptr %t179, !tbaa !23
  %t183 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t178, i32 %t180)
  store i1 %t183, ptr %l100
  br label %bb64
bb63:
  br label %bb69
bb64:
  %t184 = load i1, ptr %l100, !tbaa !21
  br i1 %t184, label %bb65, label %bb66
bb65:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/scope:Scoper", ptr %t185, i32 0, i32 30
  %t188 = getelementptr %"compiler/typed:Plan", ptr %t187, i32 0, i32 3
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  store { i64, ptr } %t189, ptr %l102, !tbaa !27
  %t190 = load i32, ptr %l1, !tbaa !23
  %t192 = sext i32 %t190 to i64
  store i64 %t192, ptr %l104, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i32, ptr %l1, !tbaa !23
  %t196 = sext i32 %t194 to i64
  %t197 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t198 = load i64, ptr %l4, !tbaa !24
  %t203 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArray(ptr %v0, ptr %v2, ptr %t193, i64 %t196, { i64, ptr } %t197, i64 %t198)
  store i1 %t203, ptr %l110
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t204 = load i1, ptr %l110, !tbaa !21
  %t205 = load i64, ptr %l104, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i1, ptr %t207, i64 %t205
  store i1 %t204, ptr %t208, !tbaa !31
  br label %bb68
bb68:
  br label %ret
bb69:
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 2
  %t211 = load i32, ptr %t210, !tbaa !23
  %t214 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t209, i32 %t211)
  store i1 %t214, ptr %l113
  br label %bb72
bb72:
  %t215 = load i1, ptr %l113, !tbaa !21
  %t216 = xor i1 %t215, true
  br i1 %t216, label %bb73, label %bb74
bb73:
  br label %ret
bb74:
  br label %bb75
bb75:
  %t218 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 5
  %t219 = load { i64, [2 x i64] }, ptr %t218
  store { i64, [2 x i64] } %t219, ptr %l9
  %t221 = load { i64, [2 x i64] }, ptr %l9
  %t223 = extractvalue { i64, [2 x i64] } %t221, 0
  %t224 = icmp eq i64 %t223, 0
  br i1 %t224, label %bb76, label %bb77
bb76:
  br label %bb80
bb77:
  %t226 = load { i64, [2 x i64] }, ptr %l9
  %t228 = extractvalue { i64, [2 x i64] } %t226, 0
  %t229 = icmp eq i64 %t228, 5
  br i1 %t229, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb86
bb81:
  br i1 true, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %ret
bb85:
  call void @__olang_check_failed(ptr @olang_loc_36d9ea1b8e0be675_6ae7f20c6157de79)
  unreachable
bb86:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l2, !tbaa !29
  %t236 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %v1, ptr %t231, ptr %t232)
  store ptr %t236, ptr %l123
  br label %bb87
bb87:
  %t237 = load ptr, ptr %l123, !tbaa !29
  store ptr %t237, ptr %l10, !tbaa !29
  %t238 = load ptr, ptr %l10, !tbaa !29
  %t240 = icmp eq ptr %t238, null
  br i1 %t240, label %bb88, label %bb89
bb88:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l2, !tbaa !29
  %t247 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCallOf(ptr %v0, ptr %v1, ptr %v1, ptr %t242, ptr %t243)
  store ptr %t247, ptr %l129
  br label %bb90
bb89:
  br label %bb94
bb90:
  %t248 = load ptr, ptr %l129, !tbaa !29
  store ptr %t248, ptr %l10, !tbaa !29
  %t249 = load ptr, ptr %l10, !tbaa !29
  %t251 = icmp eq ptr %t249, null
  br i1 %t251, label %bb91, label %bb92
bb91:
  br label %ret
bb92:
  br label %bb93
bb93:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/scope:Scoper", ptr %t253, i32 0, i32 106
  store i1 true, ptr %t255, !tbaa !21
  br label %bb94
bb94:
  %t256 = load ptr, ptr %l0, !tbaa !29
  store ptr %t256, ptr %l133, !tbaa !29
  %t257 = load ptr, ptr %l10, !tbaa !29
  %t259 = icmp eq ptr %t257, null
  br i1 %t259, label %bb95, label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_318ee1b3da3da37b_dfd49c38f0c44407)
  unreachable
bb96:
  br label %bb97
bb97:
  %t261 = load ptr, ptr %l10, !tbaa !29
  %t264 = getelementptr %"compiler/typed:Call", ptr %t261, i32 0, i32 0
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t266 = load ptr, ptr %l133, !tbaa !29
  %t268 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t266, ptr %t265)
  store i64 %t268, ptr %l139
  br label %bb98
bb98:
  %t269 = load i64, ptr %l139, !tbaa !24
  store i64 %t269, ptr %l11, !tbaa !24
  %t270 = load i64, ptr %l11, !tbaa !24
  %t272 = icmp slt i64 %t270, 0
  br i1 %t272, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l142, !tbaa !21
  br label %bb102
bb100:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i64, ptr %l11, !tbaa !24
  %t278 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t274, i64 %t275)
  store i1 %t278, ptr %l145
  br label %bb101
bb101:
  %t279 = load i1, ptr %l145, !tbaa !21
  %t280 = xor i1 %t279, true
  store i1 %t280, ptr %l142, !tbaa !21
  br label %bb102
bb102:
  %t282 = load i1, ptr %l142, !tbaa !21
  br i1 %t282, label %bb103, label %bb104
bb103:
  br label %ret
bb104:
  br label %bb105
bb105:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load i32, ptr %l1, !tbaa !23
  %t286 = sext i32 %t284 to i64
  %t289 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewalkLocal(ptr %v0, ptr %t283, i64 %t286)
  store i1 %t289, ptr %l150
  br label %bb106
bb106:
  %t290 = load i1, ptr %l150, !tbaa !21
  br i1 %t290, label %bb107, label %bb108
bb107:
  br label %ret
bb108:
  br label %bb109
bb109:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/scope:Scoper", ptr %t291, i32 0, i32 0
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 2
  store ptr %t296, ptr %l153, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  store ptr %t297, ptr %l154, !tbaa !29
  %t298 = load ptr, ptr %l10, !tbaa !29
  %t300 = icmp eq ptr %t298, null
  br i1 %t300, label %bb110, label %bb111
bb110:
  call void @__olang_check_failed(ptr @olang_loc_b8fb270bdd73210c_150398a92061e6e8)
  unreachable
bb111:
  br label %bb112
bb112:
  %t302 = load ptr, ptr %l10, !tbaa !29
  %t303 = load ptr, ptr %l154, !tbaa !29
  %t305 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t303, ptr %t302)
  store i32 %t305, ptr %l158
  br label %bb113
bb113:
  %t306 = load ptr, ptr %l153, !tbaa !29
  %t307 = load i32, ptr %l158, !tbaa !23
  %t308 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t306, i32 %t307)
  store i64 %t308, ptr %l159
  br label %bb114
bb114:
  %t309 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t310 = load i64, ptr %l159, !tbaa !24
  %t312 = icmp eq i64 %t310, %t309
  br i1 %t312, label %bb115, label %bb116
bb115:
  br label %ret
bb116:
  br label %bb117
bb117:
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l162, !tbaa !29
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l163, !tbaa !29
  %t316 = load ptr, ptr %l10, !tbaa !29
  %t318 = icmp eq ptr %t316, null
  br i1 %t318, label %bb118, label %bb119
bb118:
  call void @__olang_check_failed(ptr @olang_loc_6763258997513a41_ec0b86cc45ca0bbd)
  unreachable
bb119:
  br label %bb120
bb120:
  %t320 = load ptr, ptr %l10, !tbaa !29
  %t321 = load ptr, ptr %l163, !tbaa !29
  %t323 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t321, ptr %t320)
  store i32 %t323, ptr %l167
  br label %bb121
bb121:
  %t324 = load ptr, ptr %l162, !tbaa !29
  %t325 = load i32, ptr %l167, !tbaa !23
  %t326 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t324, i32 %t325)
  store i64 %t326, ptr %l168
  br label %bb122
bb122:
  %t327 = load i64, ptr %l168, !tbaa !24
  store i64 %t327, ptr %l12, !tbaa !24
  %t328 = load i64, ptr %l12, !tbaa !24
  %t330 = icmp slt i64 %t328, 0
  br i1 %t330, label %bb123, label %bb124
bb123:
  br label %ret
bb124:
  br label %bb125
bb125:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i64, ptr %l11, !tbaa !24
  %t334 = load i64, ptr %l12, !tbaa !24
  %t338 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumBuilds(ptr %v0, ptr %t332, i64 %t333, i64 %t334)
  store i1 %t338, ptr %l174
  br label %bb126
bb126:
  %t339 = load i1, ptr %l174, !tbaa !21
  %t340 = xor i1 %t339, true
  br i1 %t340, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l176, !tbaa !21
  br label %bb130
bb128:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load i64, ptr %l11, !tbaa !24
  %t344 = load i64, ptr %l12, !tbaa !24
  %t348 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforced(ptr %v0, ptr %t342, i64 %t343, i64 %t344)
  store i1 %t348, ptr %l180
  br label %bb129
bb129:
  %t349 = load i1, ptr %l180, !tbaa !21
  store i1 %t349, ptr %l176, !tbaa !21
  br label %bb130
bb130:
  %t350 = load i1, ptr %l176, !tbaa !21
  br i1 %t350, label %bb131, label %bb132
bb131:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/scope:Scoper", ptr %t351, i32 0, i32 103
  store i1 true, ptr %t353, !tbaa !21
  br label %ret
bb132:
  br label %bb133
bb133:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i32, ptr %l1, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowStart(ptr %v0, ptr %t354, i32 %t355, i64 1)
  br label %bb134
bb134:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t360 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowRun(ptr %v0, ptr %v2, ptr %t358, { i64, ptr } %t359, i64 %t360)
  br label %bb135
bb135:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/scope:Scoper", ptr %t365, i32 0, i32 112
  %t368 = load i1, ptr %t367, !tbaa !21
  %t371 = getelementptr %"compiler/scope:Scoper", ptr %t364, i32 0, i32 103
  store i1 %t368, ptr %t371, !tbaa !21
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/scope:Scoper", ptr %t372, i32 0, i32 113
  store i64 0, ptr %t374, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edisagree(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, { i64, [2 x i64] } %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l7 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/msgs:Msg"
  %l28 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l2
  %t3 = load { i64, [2 x i64] }, ptr %l3
  %t7 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudgeOut(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2, { i64, [2 x i64] } %t3)
  store i64 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp eq i64 %t9, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load { i64, [2 x i64] }, ptr %l3
  %t15 = load { i64, [2 x i64] }, ptr %l2
  %t19 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudgeOut(ptr %v0, ptr %t13, { i64, [2 x i64] } %t14, { i64, [2 x i64] } %t15)
  store i64 %t19, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t20 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t23 = icmp eq i64 %t21, %t20
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l10, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load { i64, [2 x i64] }, ptr %l2
  %t28 = load { i64, [2 x i64] }, ptr %l3
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %t26, { i64, [2 x i64] } %t27, { i64, [2 x i64] } %t28, i1 true)
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 27
  %t36 = load i1, ptr %t35, !tbaa !21
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l25, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l26
  %t43 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgsDisagree(ptr %s0)
  store %"compiler/msgs:Msg" %t43, ptr %l27
  br label %bb13
bb13:
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l26
  %t46 = load %"compiler/msgs:Msg", ptr %l27
  %t47 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s0, ptr %t44, %"compiler/source:Span" %t45, %"compiler/msgs:Msg" %t46)
  store i64 %t47, ptr %l28
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load i64, ptr %l28, !tbaa !24
  store i64 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edischarge(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/scope:rel"
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca i64
  %l31 = alloca ptr
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca %"compiler/scope:rel"
  %l46 = alloca { i64, [2 x i64] }
  %l51 = alloca { i64, [2 x i64] }
  %l54 = alloca i1
  %l60 = alloca i64
  %l66 = alloca i1
  %l70 = alloca i1
  %l80 = alloca i1
  %l87 = alloca i64
  %l90 = alloca i1
  %l93 = alloca { i64, ptr }
  %l96 = alloca i1
  %l99 = alloca { i64, ptr }
  %l105 = alloca i1
  %l108 = alloca ptr
  %l111 = alloca i32
  %l112 = alloca i32
  %l116 = alloca i1
  %l120 = alloca i1
  %l124 = alloca i1
  %l127 = alloca i1
  %l137 = alloca i1
  %l140 = alloca i1
  %l153 = alloca i1
  %l154 = alloca i1
  %l157 = alloca i1
  %l173 = alloca i1
  %l177 = alloca i1
  %l182 = alloca i1
  %l186 = alloca i1
  %l189 = alloca i1
  %l194 = alloca i1
  %l197 = alloca i1
  %l214 = alloca i1
  %l215 = alloca { i64, [2 x i64] }
  %l218 = alloca { i64, [2 x i64] }
  %l220 = alloca i1
  %l221 = alloca ptr
  %l223 = alloca %"compiler/source:Span"
  %l226 = alloca %"compiler/msgs:Msg"
  %l227 = alloca %"compiler/msgs:Msg"
  %l228 = alloca %"compiler/msgs:Msg"
  %l229 = alloca i64
  %l232 = alloca i1
  %l235 = alloca i1
  %l236 = alloca i64
  %l237 = alloca ptr
  %l240 = alloca i32
  %l241 = alloca i64
  %l243 = alloca i1
  %l247 = alloca i1
  %l248 = alloca ptr
  %l251 = alloca %"compiler/source:Span"
  %l259 = alloca %"compiler/msgs:Msg"
  %l260 = alloca %"compiler/msgs:Msg"
  %l261 = alloca %"compiler/msgs:Msg"
  %l262 = alloca i64
  %l270 = alloca i64
  %l276 = alloca i64
  %l279 = alloca %"compiler/source:Span"
  %l282 = alloca { i64, ptr }
  %l285 = alloca %"compiler/source:Span"
  %l288 = alloca %"compiler/source:Span"
  %l292 = alloca i1
  %l301 = alloca ptr
  %l302 = alloca %"compiler/source:Span"
  %l306 = alloca %"compiler/msgs:Msg"
  %l307 = alloca %"compiler/msgs:Msg"
  %l308 = alloca %"compiler/msgs:Msg"
  %l309 = alloca i64
  %l312 = alloca i64
  %l315 = alloca i1
  %l318 = alloca ptr
  %l319 = alloca i64
  %l321 = alloca { i64, ptr }
  %l324 = alloca ptr
  %l325 = alloca i64
  %l329 = alloca ptr
  %l338 = alloca %"compiler/typed:Local"
  %l340 = alloca { i64, ptr }
  %l344 = alloca i64
  %l347 = alloca i1
  %l351 = alloca { i64, ptr }
  %l354 = alloca i64
  %l357 = alloca i1
  %l360 = alloca i1
  %l362 = alloca ptr
  %l365 = alloca %"compiler/source:Span"
  %l369 = alloca ptr
  %l378 = alloca %"compiler/typed:Local"
  %l380 = alloca { i64, ptr }
  %l381 = alloca %"compiler/msgs:Msg"
  %l382 = alloca i64
  %l385 = alloca i1
  %l386 = alloca ptr
  %l388 = alloca { i64, ptr }
  %l390 = alloca ptr
  %l393 = alloca %"compiler/source:Span"
  %l394 = alloca i1
  %l397 = alloca i1
  %l398 = alloca ptr
  %l400 = alloca { i64, ptr }
  %l402 = alloca ptr
  %l405 = alloca %"compiler/source:Span"
  %l406 = alloca i1
  %l408 = alloca %"compiler/msgs:Msg"
  %l409 = alloca %"compiler/msgs:Msg"
  %l410 = alloca %"compiler/msgs:Msg"
  %l414 = alloca i1
  %l415 = alloca i1
  %l419 = alloca i1
  %l420 = alloca %"compiler/msgs:Msg"
  %l421 = alloca ptr
  %l424 = alloca %"compiler/source:Span"
  %l426 = alloca i64
  %l430 = alloca ptr
  %l431 = alloca ptr
  %l432 = alloca i64
  %l434 = alloca i64
  %l439 = alloca %"compiler/source:Span"
  %l440 = alloca %"compiler/msgs:Msg"
  %l444 = alloca i64
  %l448 = alloca i64
  %l451 = alloca i1
  %l454 = alloca { i64, ptr }
  %l457 = alloca i1
  %l461 = alloca { i64, ptr }
  %l466 = alloca i1
  %l469 = alloca ptr
  %l470 = alloca i64
  %l473 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s26 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l31
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l31, !tbaa !29
  %t10 = getelementptr %"compiler/scope:summary", ptr %t8, i32 0, i32 0
  store ptr %t10, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l34, !tbaa !24
  %t13 = load ptr, ptr %l6, !tbaa !29
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l36
  br label %bb3
bb3:
  %t16 = load i64, ptr %l34, !tbaa !24
  %t17 = load i64, ptr %l36, !tbaa !24
  %t18 = icmp slt i64 %t16, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb277
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l6, !tbaa !29
  %t23 = load i64, ptr %l7, !tbaa !24
  %t26 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t22, i64 %t23)
  store %"compiler/scope:rel" %t26, ptr %l41
  br label %bb7
bb7:
  %t27 = load %"compiler/scope:rel", ptr %l41
  store %"compiler/scope:rel" %t27, ptr %l8
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t30 = load { i64, [2 x i64] }, ptr %t29
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t37 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %t28, { i64, [2 x i64] } %t30, { i64, ptr } %t31, ptr %t32, i1 true)
  store { i64, [2 x i64] } %t37, ptr %l46
  br label %bb8
bb8:
  %t38 = load { i64, [2 x i64] }, ptr %l46
  store { i64, [2 x i64] } %t38, ptr %l9
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 1
  %t41 = load { i64, [2 x i64] }, ptr %t40
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t48 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %t39, { i64, [2 x i64] } %t41, { i64, ptr } %t42, ptr %t43, i1 false)
  store { i64, [2 x i64] } %t48, ptr %l51
  br label %bb9
bb9:
  %t49 = load { i64, [2 x i64] }, ptr %l51
  store { i64, [2 x i64] } %t49, ptr %l10
  %t50 = load { i64, [2 x i64] }, ptr %l9
  %t52 = extractvalue { i64, [2 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 0
  br i1 %t53, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb12
bb11:
  %t55 = load { i64, [2 x i64] }, ptr %l10
  %t57 = extractvalue { i64, [2 x i64] } %t55, 0
  %t58 = icmp eq i64 %t57, 0
  store i1 %t58, ptr %l54, !tbaa !21
  br label %bb12
bb12:
  %t60 = load i1, ptr %l54, !tbaa !21
  br i1 %t60, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb276
bb14:
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load { i64, [2 x i64] }, ptr %l9
  %t63 = load { i64, [2 x i64] }, ptr %l10
  %t67 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudgeOut(ptr %v0, ptr %t61, { i64, [2 x i64] } %t62, { i64, [2 x i64] } %t63)
  store i64 %t67, ptr %l60
  br label %bb16
bb16:
  %t68 = load i64, ptr %l60, !tbaa !24
  store i64 %t68, ptr %l11, !tbaa !24
  %t69 = load i64, ptr %l11, !tbaa !24
  %t70 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t73 = icmp eq i64 %t69, %t70
  br i1 %t73, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb276
bb18:
  br label %bb19
bb19:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/scope:Scoper", ptr %t75, i32 0, i32 123
  %t78 = load i1, ptr %t77, !tbaa !21
  br i1 %t78, label %bb20, label %bb21
bb20:
  %t80 = load i64, ptr %l11, !tbaa !24
  %t81 = load i64, ptr @G_2ecompiler_2fscope_2eFailsBlock, !tbaa !24
  %t84 = icmp eq i64 %t80, %t81
  store i1 %t84, ptr %l66, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l66, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  %t87 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 5
  %t88 = load i1, ptr %t87, !tbaa !21
  %t90 = xor i1 %t88, true
  store i1 %t90, ptr %l70, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb25
bb25:
  %t92 = load i1, ptr %l70, !tbaa !21
  br i1 %t92, label %bb26, label %bb27
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l4, !tbaa !29
  %t95 = load %"compiler/scope:rel", ptr %l8
  %t96 = load { i64, [2 x i64] }, ptr %l10
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftAtCall(ptr %v0, ptr %v2, ptr %t93, ptr %t94, %"compiler/scope:rel" %t95, { i64, [2 x i64] } %t96)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t101 = load i64, ptr %l11, !tbaa !24
  %t102 = load i64, ptr @G_2ecompiler_2fscope_2eFailsBlock, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  br i1 %t105, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb32
bb31:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr @G_2ecompiler_2fscope_2eFailsUnknown, !tbaa !24
  %t111 = icmp eq i64 %t107, %t108
  store i1 %t111, ptr %l80, !tbaa !21
  br label %bb32
bb32:
  %t113 = load i1, ptr %l80, !tbaa !21
  br i1 %t113, label %bb33, label %bb34
bb33:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l4, !tbaa !29
  %t116 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t117 = load { i64, [2 x i64] }, ptr %t116
  %t121 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v2, ptr %t114, ptr %t115, { i64, [2 x i64] } %t117)
  store i64 %t121, ptr %l87
  br label %bb35
bb34:
  br label %bb44
bb35:
  %t122 = load i64, ptr %l87, !tbaa !24
  store i64 %t122, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t125 = icmp sge i64 %t123, 0
  br i1 %t125, label %bb36, label %bb37
bb36:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l4, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Call", ptr %t128, i32 0, i32 1
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l93, !tbaa !27
  %t132 = load i64, ptr %l12, !tbaa !24
  %t134 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr ptr, ptr %t135, i64 %t132
  %t137 = load ptr, ptr %t136, !tbaa !39
  %t140 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOfOwn(ptr %v0, ptr %v2, ptr %t127, ptr %t137)
  store i1 %t140, ptr %l96
  br label %bb38
bb37:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb39
bb38:
  %t141 = load i1, ptr %l96, !tbaa !21
  store i1 %t141, ptr %l90, !tbaa !21
  br label %bb39
bb39:
  %t142 = load i1, ptr %l90, !tbaa !21
  br i1 %t142, label %bb40, label %bb41
bb40:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l4, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Call", ptr %t144, i32 0, i32 1
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  store { i64, ptr } %t147, ptr %l99, !tbaa !27
  %t148 = load i64, ptr %l12, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr ptr, ptr %t151, i64 %t148
  %t153 = load ptr, ptr %t152, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewantPromotion(ptr %v0, ptr %v2, ptr %t143, ptr %t153)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load ptr, ptr %l4, !tbaa !29
  %t158 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t159 = load { i64, [2 x i64] }, ptr %t158
  %t163 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonResult(ptr %v0, ptr %v2, ptr %t156, ptr %t157, { i64, [2 x i64] } %t159)
  store i1 %t163, ptr %l105
  br label %bb45
bb45:
  %t164 = load i1, ptr %l105, !tbaa !21
  br i1 %t164, label %bb46, label %bb47
bb46:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 0
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 2
  store ptr %t170, ptr %l108, !tbaa !29
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l4, !tbaa !29
  %t175 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v2, ptr %t171, ptr %t172)
  store i32 %t175, ptr %l111
  br label %bb48
bb47:
  br label %bb74
bb48:
  %t176 = load ptr, ptr %l108, !tbaa !29
  %t177 = load i32, ptr %l111, !tbaa !23
  %t178 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t176, i32 %t177)
  store i32 %t178, ptr %l112
  br label %bb49
bb49:
  %t179 = load i32, ptr %l112, !tbaa !23
  store i32 %t179, ptr %l13, !tbaa !23
  %t180 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 4
  %t181 = load i64, ptr %t180, !tbaa !24
  %t182 = load i64, ptr @G_2ecompiler_2fscope_2eWhyHolds, !tbaa !24
  %t185 = icmp eq i64 %t181, %t182
  br i1 %t185, label %bb50, label %bb51
bb50:
  %t187 = load i64, ptr %l11, !tbaa !24
  %t188 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t191 = icmp ne i64 %t187, %t188
  br i1 %t191, label %bb52, label %bb53
bb51:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb61
bb52:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb60
bb53:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/scope:Scoper", ptr %t193, i32 0, i32 39
  %t196 = load i64, ptr %t195, !tbaa !24
  %t198 = icmp sge i64 %t196, 0
  br i1 %t198, label %bb54, label %bb55
bb54:
  %t200 = load { i64, [2 x i64] }, ptr %l9
  %t202 = extractvalue { i64, [2 x i64] } %t200, 0
  %t203 = icmp eq i64 %t202, 2
  br i1 %t203, label %bb56, label %bb57
bb55:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb59
bb56:
  %t205 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t206 = getelementptr { i64 }, ptr %t205, i32 0, i32 0
  %t207 = load i64, ptr %t206
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/scope:Scoper", ptr %t208, i32 0, i32 39
  %t211 = load i64, ptr %t210, !tbaa !24
  %t214 = icmp eq i64 %t207, %t211
  store i1 %t214, ptr %l127, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb58
bb58:
  %t216 = load i1, ptr %l127, !tbaa !21
  store i1 %t216, ptr %l124, !tbaa !21
  br label %bb59
bb59:
  %t217 = load i1, ptr %l124, !tbaa !21
  store i1 %t217, ptr %l120, !tbaa !21
  br label %bb60
bb60:
  %t218 = load i1, ptr %l120, !tbaa !21
  store i1 %t218, ptr %l116, !tbaa !21
  br label %bb61
bb61:
  %t219 = load i1, ptr %l116, !tbaa !21
  br i1 %t219, label %bb62, label %bb63
bb62:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewantExact(ptr %v0, ptr %t220, i32 %t221)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  %t224 = load i64, ptr %l11, !tbaa !24
  %t225 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t228 = icmp ne i64 %t224, %t225
  br i1 %t228, label %bb66, label %bb67
bb66:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i32, ptr %l13, !tbaa !23
  %t234 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t230, i32 %t231)
  store i1 %t234, ptr %l140
  br label %bb68
bb67:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb69
bb68:
  %t235 = load i1, ptr %l140, !tbaa !21
  %t236 = xor i1 %t235, true
  store i1 %t236, ptr %l137, !tbaa !21
  br label %bb69
bb69:
  %t238 = load i1, ptr %l137, !tbaa !21
  br i1 %t238, label %bb70, label %bb71
bb70:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewantPromotionOf(ptr %v0, ptr %t239, i32 %t240)
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t243 = load i64, ptr %l11, !tbaa !24
  %t244 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t247 = icmp ne i64 %t243, %t244
  br i1 %t247, label %bb75, label %bb76
bb75:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load { i64, [2 x i64] }, ptr %l9
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackDerived(ptr %v0, ptr %t249, { i64, [2 x i64] } %t250)
  br label %bb77
bb76:
  br label %bb89
bb77:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load { i64, [2 x i64] }, ptr %l10
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackDerived(ptr %v0, ptr %t253, { i64, [2 x i64] } %t254)
  br label %bb78
bb78:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load { i64, [2 x i64] }, ptr %l9
  %t261 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedTerm(ptr %v0, ptr %t257, { i64, [2 x i64] } %t258)
  store i1 %t261, ptr %l153
  br label %bb79
bb79:
  %t262 = load i1, ptr %l153, !tbaa !21
  br i1 %t262, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l154, !tbaa !21
  br label %bb83
bb81:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load { i64, [2 x i64] }, ptr %l10
  %t267 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedTerm(ptr %v0, ptr %t263, { i64, [2 x i64] } %t264)
  store i1 %t267, ptr %l157
  br label %bb82
bb82:
  %t268 = load i1, ptr %l157, !tbaa !21
  store i1 %t268, ptr %l154, !tbaa !21
  br label %bb83
bb83:
  %t269 = load i1, ptr %l154, !tbaa !21
  br i1 %t269, label %bb84, label %bb85
bb84:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load ptr, ptr %l4, !tbaa !29
  %t272 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t273 = load { i64, [2 x i64] }, ptr %t272
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackArg(ptr %v0, ptr %v2, ptr %t270, ptr %t271, { i64, [2 x i64] } %t273)
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %l4, !tbaa !29
  %t279 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 1
  %t280 = load { i64, [2 x i64] }, ptr %t279
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackArg(ptr %v0, ptr %v2, ptr %t277, ptr %t278, { i64, [2 x i64] } %t280)
  br label %bb87
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t284 = load i64, ptr %l11, !tbaa !24
  %t285 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t288 = icmp eq i64 %t284, %t285
  br i1 %t288, label %bb90, label %bb91
bb90:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/scope:Scoper", ptr %t290, i32 0, i32 101
  %t293 = load i64, ptr %t292, !tbaa !24
  store i64 %t293, ptr %l14, !tbaa !24
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 5
  %t297 = load i1, ptr %t296, !tbaa !21
  %t300 = getelementptr %"compiler/scope:Scoper", ptr %t295, i32 0, i32 136
  store i1 %t297, ptr %t300, !tbaa !21
  %t301 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 4
  %t302 = load i64, ptr %t301, !tbaa !24
  %t304 = icmp ne i64 %t302, 0
  br i1 %t304, label %bb92, label %bb93
bb91:
  br label %bb116
bb92:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load { i64, [2 x i64] }, ptr %l9
  %t308 = load { i64, [2 x i64] }, ptr %l10
  %t312 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceRel(ptr %v0, ptr %t306, { i64, [2 x i64] } %t307, { i64, [2 x i64] } %t308)
  store i1 %t312, ptr %l177
  br label %bb94
bb93:
  store i1 false, ptr %l173, !tbaa !21
  br label %bb95
bb94:
  %t313 = load i1, ptr %l177, !tbaa !21
  store i1 %t313, ptr %l173, !tbaa !21
  br label %bb95
bb95:
  %t314 = load i1, ptr %l173, !tbaa !21
  br i1 %t314, label %bb96, label %bb97
bb96:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 4
  %t317 = load i64, ptr %t316, !tbaa !24
  %t320 = getelementptr %"compiler/scope:Scoper", ptr %t315, i32 0, i32 101
  store i64 %t317, ptr %t320, !tbaa !24
  br label %bb114
bb97:
  %t321 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 4
  %t322 = load i64, ptr %t321, !tbaa !24
  %t324 = icmp ne i64 %t322, 0
  br i1 %t324, label %bb98, label %bb99
bb98:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/scope:Scoper", ptr %t326, i32 0, i32 39
  %t329 = load i64, ptr %t328, !tbaa !24
  %t331 = icmp sge i64 %t329, 0
  store i1 %t331, ptr %l182, !tbaa !21
  br label %bb100
bb99:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb100
bb100:
  %t333 = load i1, ptr %l182, !tbaa !21
  br i1 %t333, label %bb101, label %bb102
bb101:
  %t334 = load { i64, [2 x i64] }, ptr %l10
  %t336 = extractvalue { i64, [2 x i64] } %t334, 0
  %t337 = icmp eq i64 %t336, 2
  br i1 %t337, label %bb103, label %bb104
bb102:
  store i1 false, ptr %l186, !tbaa !21
  br label %bb106
bb103:
  %t339 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t340 = getelementptr { i64 }, ptr %t339, i32 0, i32 0
  %t341 = load i64, ptr %t340
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/scope:Scoper", ptr %t342, i32 0, i32 39
  %t345 = load i64, ptr %t344, !tbaa !24
  %t348 = icmp eq i64 %t341, %t345
  store i1 %t348, ptr %l189, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb105
bb105:
  %t350 = load i1, ptr %l189, !tbaa !21
  store i1 %t350, ptr %l186, !tbaa !21
  br label %bb106
bb106:
  %t351 = load i1, ptr %l186, !tbaa !21
  br i1 %t351, label %bb107, label %bb108
bb107:
  %t352 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t353 = getelementptr { i64 }, ptr %t352, i32 0, i32 0
  %t354 = load i64, ptr %t353
  store i64 %t354, ptr %l15, !tbaa !24
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisCtor(ptr %v0, ptr %t356)
  store i1 %t358, ptr %l197
  br label %bb109
bb108:
  store i1 false, ptr %l194, !tbaa !21
  br label %bb110
bb109:
  %t359 = load i1, ptr %l197, !tbaa !21
  %t360 = xor i1 %t359, true
  store i1 %t360, ptr %l194, !tbaa !21
  br label %bb110
bb110:
  %t362 = load i1, ptr %l194, !tbaa !21
  br i1 %t362, label %bb111, label %bb112
bb111:
  %t363 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t364 = getelementptr { i64 }, ptr %t363, i32 0, i32 0
  %t365 = load i64, ptr %t364
  store i64 %t365, ptr %l16, !tbaa !24
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load i64, ptr @G_2ecompiler_2fscope_2eWhyResult, !tbaa !24
  %t371 = getelementptr %"compiler/scope:Scoper", ptr %t367, i32 0, i32 101
  store i64 %t368, ptr %t371, !tbaa !24
  br label %bb113
bb112:
  br label %bb113
bb113:
  br label %bb114
bb114:
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load { i64, [2 x i64] }, ptr %l9
  %t374 = load { i64, [2 x i64] }, ptr %l10
  %t375 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 2
  %t376 = load i1, ptr %t375, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %t372, { i64, [2 x i64] } %t373, { i64, [2 x i64] } %t374, i1 %t376)
  br label %bb115
bb115:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load i64, ptr %l14, !tbaa !24
  %t385 = getelementptr %"compiler/scope:Scoper", ptr %t381, i32 0, i32 101
  store i64 %t382, ptr %t385, !tbaa !24
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/scope:Scoper", ptr %t386, i32 0, i32 136
  store i1 false, ptr %t388, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb276
bb116:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/scope:Scoper", ptr %t389, i32 0, i32 27
  %t392 = load i1, ptr %t391, !tbaa !21
  %t394 = xor i1 %t392, true
  br i1 %t394, label %bb117, label %bb118
bb117:
  call void @__olang_scope_close(ptr %s2)
  br label %bb276
bb118:
  br label %bb119
bb119:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/scope:Scoper", ptr %t396, i32 0, i32 74
  %t399 = load i1, ptr %t398, !tbaa !21
  br i1 %t399, label %bb120, label %bb121
bb120:
  %t401 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t401, ptr %l215
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/scope:Scoper", ptr %t402, i32 0, i32 76
  %t405 = load { i64, [2 x i64] }, ptr %t404
  store { i64, [2 x i64] } %t405, ptr %l218
  %t408 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l215, ptr %l218)
  store i1 %t408, ptr %l220
  br label %bb122
bb121:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb123
bb122:
  %t409 = load i1, ptr %l220, !tbaa !21
  store i1 %t409, ptr %l214, !tbaa !21
  br label %bb123
bb123:
  %t410 = load i1, ptr %l214, !tbaa !21
  br i1 %t410, label %bb124, label %bb125
bb124:
  store %olang.scope zeroinitializer, ptr %s18
  %t411 = load ptr, ptr %l0, !tbaa !29
  store ptr %t411, ptr %l221, !tbaa !29
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = getelementptr %"compiler/scope:Scoper", ptr %t412, i32 0, i32 75
  %t415 = load %"compiler/source:Span", ptr %t414
  store %"compiler/source:Span" %t415, ptr %l223
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/scope:Scoper", ptr %t416, i32 0, i32 77
  %t419 = load i1, ptr %t418, !tbaa !21
  br i1 %t419, label %bb126, label %bb127
bb125:
  br label %bb132
bb126:
  %t421 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %s18)
  store %"compiler/msgs:Msg" %t421, ptr %l227
  br label %bb128
bb127:
  %t422 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgHoldsShort(ptr %s18)
  store %"compiler/msgs:Msg" %t422, ptr %l228
  br label %bb129
bb128:
  %t423 = load %"compiler/msgs:Msg", ptr %l227
  store %"compiler/msgs:Msg" %t423, ptr %l226
  br label %bb130
bb129:
  %t424 = load %"compiler/msgs:Msg", ptr %l228
  store %"compiler/msgs:Msg" %t424, ptr %l226
  br label %bb130
bb130:
  %t425 = load ptr, ptr %l221, !tbaa !29
  %t426 = load %"compiler/source:Span", ptr %l223
  %t427 = load %"compiler/msgs:Msg", ptr %l226
  %t428 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s18, ptr %t425, %"compiler/source:Span" %t426, %"compiler/msgs:Msg" %t427)
  store i64 %t428, ptr %l229
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s2)
  br label %bb276
bb132:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/scope:Scoper", ptr %t429, i32 0, i32 109
  %t432 = load i1, ptr %t431, !tbaa !21
  br i1 %t432, label %bb133, label %bb134
bb133:
  %t434 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 1
  %t435 = load { i64, [2 x i64] }, ptr %t434
  %t437 = extractvalue { i64, [2 x i64] } %t435, 0
  %t438 = icmp eq i64 %t437, 2
  br i1 %t438, label %bb135, label %bb136
bb134:
  store i1 false, ptr %l232, !tbaa !21
  br label %bb140
bb135:
  %t440 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 1
  %t441 = getelementptr { i64, [2 x i64] }, ptr %t440, i32 0, i32 1
  %t442 = getelementptr { i64 }, ptr %t441, i32 0, i32 0
  %t443 = load i64, ptr %t442
  store i64 %t443, ptr %l236, !tbaa !24
  %t444 = load ptr, ptr %l0, !tbaa !29
  store ptr %t444, ptr %l237, !tbaa !29
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load ptr, ptr %l4, !tbaa !29
  %t449 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v2, ptr %t445, ptr %t446)
  store i32 %t449, ptr %l240
  br label %bb137
bb136:
  store i1 false, ptr %l235, !tbaa !21
  br label %bb139
bb137:
  %t450 = load ptr, ptr %l237, !tbaa !29
  %t451 = load i32, ptr %l240, !tbaa !23
  %t452 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t450, i32 %t451)
  store i64 %t452, ptr %l241
  br label %bb138
bb138:
  %t453 = load i64, ptr %l236, !tbaa !24
  %t454 = load i64, ptr %l241, !tbaa !24
  %t455 = icmp eq i64 %t453, %t454
  store i1 %t455, ptr %l235, !tbaa !21
  br label %bb139
bb139:
  %t457 = load i1, ptr %l235, !tbaa !21
  store i1 %t457, ptr %l232, !tbaa !21
  br label %bb140
bb140:
  %t458 = load i1, ptr %l232, !tbaa !21
  br i1 %t458, label %bb141, label %bb142
bb141:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load { i64, [2 x i64] }, ptr %l9
  %t461 = load { i64, [2 x i64] }, ptr %l10
  %t465 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownIntoResult(ptr %v0, ptr %t459, { i64, [2 x i64] } %t460, { i64, [2 x i64] } %t461)
  store i1 %t465, ptr %l247
  br label %bb143
bb142:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb144
bb143:
  %t466 = load i1, ptr %l247, !tbaa !21
  store i1 %t466, ptr %l243, !tbaa !21
  br label %bb144
bb144:
  %t467 = load i1, ptr %l243, !tbaa !21
  br i1 %t467, label %bb145, label %bb146
bb145:
  store %olang.scope zeroinitializer, ptr %s19
  %t468 = load ptr, ptr %l0, !tbaa !29
  store ptr %t468, ptr %l248, !tbaa !29
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load %"compiler/source:Span", ptr %l1
  %t473 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t469, %"compiler/source:Span" %t470)
  store %"compiler/source:Span" %t473, ptr %l251
  br label %bb147
bb146:
  br label %bb157
bb147:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t476 = getelementptr %"compiler/scope:Scoper", ptr %t474, i32 0, i32 25
  %t477 = load ptr, ptr %t476, !tbaa !29
  %t479 = icmp eq ptr %t477, null
  br i1 %t479, label %bb148, label %bb149
bb148:
  call void @__olang_check_failed(ptr @olang_loc_b6014e02da5c726f_223b10c08168f803)
  unreachable
bb149:
  br label %bb150
bb150:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/scope:Scoper", ptr %t481, i32 0, i32 25
  %t484 = load ptr, ptr %t483, !tbaa !29
  %t487 = getelementptr %"compiler/typed:Body", ptr %t484, i32 0, i32 14
  %t488 = load i1, ptr %t487, !tbaa !21
  br i1 %t488, label %bb151, label %bb152
bb151:
  %t490 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOwnStorage(ptr %s19)
  store %"compiler/msgs:Msg" %t490, ptr %l260
  br label %bb153
bb152:
  %t491 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnOwnStorage(ptr %s19)
  store %"compiler/msgs:Msg" %t491, ptr %l261
  br label %bb154
bb153:
  %t492 = load %"compiler/msgs:Msg", ptr %l260
  store %"compiler/msgs:Msg" %t492, ptr %l259
  br label %bb155
bb154:
  %t493 = load %"compiler/msgs:Msg", ptr %l261
  store %"compiler/msgs:Msg" %t493, ptr %l259
  br label %bb155
bb155:
  %t494 = load ptr, ptr %l248, !tbaa !29
  %t495 = load %"compiler/source:Span", ptr %l251
  %t496 = load %"compiler/msgs:Msg", ptr %l259
  %t497 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s19, ptr %t494, %"compiler/source:Span" %t495, %"compiler/msgs:Msg" %t496)
  store i64 %t497, ptr %l262
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s2)
  br label %bb276
bb157:
  %t498 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 4
  %t499 = load i64, ptr %t498, !tbaa !24
  %t501 = icmp ne i64 %t499, 0
  br i1 %t501, label %bb158, label %bb159
bb158:
  store %olang.scope zeroinitializer, ptr %s20
  %t505 = xor i1 %a5, true
  br i1 %t505, label %bb160, label %bb161
bb159:
  br label %bb198
bb160:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s2)
  br label %bb276
bb161:
  br label %bb162
bb162:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load ptr, ptr %l4, !tbaa !29
  %t509 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t510 = load { i64, [2 x i64] }, ptr %t509
  %t514 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v2, ptr %t507, ptr %t508, { i64, [2 x i64] } %t510)
  store i64 %t514, ptr %l270
  br label %bb163
bb163:
  %t515 = load i64, ptr %l270, !tbaa !24
  store i64 %t515, ptr %l17, !tbaa !24
  %t516 = load i64, ptr %l17, !tbaa !24
  %t518 = icmp slt i64 %t516, 0
  br i1 %t518, label %bb164, label %bb165
bb164:
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t521 = load ptr, ptr %l4, !tbaa !29
  %t522 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 1
  %t523 = load { i64, [2 x i64] }, ptr %t522
  %t527 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v2, ptr %t520, ptr %t521, { i64, [2 x i64] } %t523)
  store i64 %t527, ptr %l276
  br label %bb166
bb165:
  br label %bb167
bb166:
  %t528 = load i64, ptr %l276, !tbaa !24
  store i64 %t528, ptr %l17, !tbaa !24
  br label %bb167
bb167:
  %t529 = load i64, ptr %l17, !tbaa !24
  %t531 = icmp sge i64 %t529, 0
  br i1 %t531, label %bb168, label %bb169
bb168:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load ptr, ptr %l4, !tbaa !29
  %t536 = getelementptr %"compiler/typed:Call", ptr %t534, i32 0, i32 1
  %t537 = load { i64, ptr }, ptr %t536, !tbaa !27
  store { i64, ptr } %t537, ptr %l282, !tbaa !27
  %t538 = load i64, ptr %l17, !tbaa !24
  %t540 = getelementptr { i64, ptr }, ptr %l282, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = getelementptr ptr, ptr %t541, i64 %t538
  %t543 = load ptr, ptr %t542, !tbaa !39
  %t546 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v2, ptr %t533, ptr %t543)
  store %"compiler/source:Span" %t546, ptr %l285
  br label %bb170
bb169:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load %"compiler/source:Span", ptr %l1
  %t551 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t547, %"compiler/source:Span" %t548)
  store %"compiler/source:Span" %t551, ptr %l288
  br label %bb171
bb170:
  %t552 = load %"compiler/source:Span", ptr %l285
  store %"compiler/source:Span" %t552, ptr %l279
  br label %bb172
bb171:
  %t553 = load %"compiler/source:Span", ptr %l288
  store %"compiler/source:Span" %t553, ptr %l279
  br label %bb172
bb172:
  %t554 = load %"compiler/source:Span", ptr %l279
  store %"compiler/source:Span" %t554, ptr %l18
  %t555 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 4
  %t556 = load i64, ptr %t555, !tbaa !24
  %t557 = load i64, ptr @G_2ecompiler_2fscope_2eWhyResult, !tbaa !24
  %t560 = icmp eq i64 %t556, %t557
  br i1 %t560, label %bb173, label %bb174
bb173:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/scope:Scoper", ptr %t562, i32 0, i32 121
  %t565 = load i64, ptr %t564, !tbaa !24
  %t566 = load ptr, ptr %l4, !tbaa !29
  %t568 = getelementptr %"compiler/typed:Call", ptr %t566, i32 0, i32 3
  %t569 = load i32, ptr %t568, !tbaa !23
  %t571 = sext i32 %t569 to i64
  %t574 = icmp eq i64 %t565, %t571
  store i1 %t574, ptr %l292, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l292, !tbaa !21
  br label %bb175
bb175:
  %t576 = load i1, ptr %l292, !tbaa !21
  br i1 %t576, label %bb176, label %bb177
bb176:
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t579 = getelementptr %"compiler/scope:Scoper", ptr %t577, i32 0, i32 122
  %t580 = load %"compiler/source:Span", ptr %t579
  store %"compiler/source:Span" %t580, ptr %l18
  br label %bb178
bb177:
  br label %bb178
bb178:
  %t582 = load ptr, ptr %l0, !tbaa !29
  store ptr %t582, ptr %l301, !tbaa !29
  %t583 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t583, ptr %l302
  %t584 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 4
  %t585 = load i64, ptr %t584, !tbaa !24
  %t586 = load i64, ptr @G_2ecompiler_2fscope_2eWhyField, !tbaa !24
  %t589 = icmp eq i64 %t585, %t586
  br i1 %t589, label %bb179, label %bb180
bb179:
  %t591 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eInstanceOutlivesReferent(ptr %s20)
  store %"compiler/msgs:Msg" %t591, ptr %l307
  br label %bb181
bb180:
  %t592 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eInstanceOutlivesArg(ptr %s20)
  store %"compiler/msgs:Msg" %t592, ptr %l308
  br label %bb182
bb181:
  %t593 = load %"compiler/msgs:Msg", ptr %l307
  store %"compiler/msgs:Msg" %t593, ptr %l306
  br label %bb183
bb182:
  %t594 = load %"compiler/msgs:Msg", ptr %l308
  store %"compiler/msgs:Msg" %t594, ptr %l306
  br label %bb183
bb183:
  %t595 = load ptr, ptr %l301, !tbaa !29
  %t596 = load %"compiler/source:Span", ptr %l302
  %t597 = load %"compiler/msgs:Msg", ptr %l306
  %t598 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s20, ptr %t595, %"compiler/source:Span" %t596, %"compiler/msgs:Msg" %t597)
  store i64 %t598, ptr %l309
  br label %bb184
bb184:
  %t599 = load i64, ptr %l309, !tbaa !24
  store i64 %t599, ptr %l19, !tbaa !24
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t601 = load { i64, [2 x i64] }, ptr %l10
  %t604 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamOfTerm(ptr %v0, ptr %t600, { i64, [2 x i64] } %t601)
  store i64 %t604, ptr %l312
  br label %bb185
bb185:
  %t605 = load i64, ptr %l312, !tbaa !24
  store i64 %t605, ptr %l20, !tbaa !24
  %t606 = load i64, ptr %l17, !tbaa !24
  %t608 = icmp sge i64 %t606, 0
  br i1 %t608, label %bb186, label %bb187
bb186:
  %t610 = load i64, ptr %l20, !tbaa !24
  %t612 = icmp sge i64 %t610, 0
  store i1 %t612, ptr %l315, !tbaa !21
  br label %bb188
bb187:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb188
bb188:
  %t614 = load i1, ptr %l315, !tbaa !21
  br i1 %t614, label %bb189, label %bb190
bb189:
  %t615 = load ptr, ptr %l0, !tbaa !29
  store ptr %t615, ptr %l318, !tbaa !29
  %t616 = load i64, ptr %l19, !tbaa !24
  store i64 %t616, ptr %l319, !tbaa !24
  %t617 = load ptr, ptr %l4, !tbaa !29
  %t619 = getelementptr %"compiler/typed:Call", ptr %t617, i32 0, i32 1
  %t620 = load { i64, ptr }, ptr %t619, !tbaa !27
  store { i64, ptr } %t620, ptr %l321, !tbaa !27
  %t621 = load i64, ptr %l17, !tbaa !24
  %t623 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t624 = load ptr, ptr %t623, !tbaa !27
  %t625 = getelementptr ptr, ptr %t624, i64 %t621
  %t626 = load ptr, ptr %t625, !tbaa !39
  store ptr %t626, ptr %l324, !tbaa !29
  %t628 = load i64, ptr %l20, !tbaa !24
  store i64 %t628, ptr %l325, !tbaa !24
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t631 = getelementptr %"compiler/scope:Scoper", ptr %t629, i32 0, i32 0
  %t632 = load ptr, ptr %t631, !tbaa !29
  %t634 = getelementptr %"compiler/generic:Program", ptr %t632, i32 0, i32 0
  %t635 = load ptr, ptr %t634, !tbaa !29
  %t637 = getelementptr %"compiler/load:Loader", ptr %t635, i32 0, i32 3
  %t638 = load ptr, ptr %t637, !tbaa !29
  store ptr %t638, ptr %l329, !tbaa !29
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t641 = getelementptr %"compiler/scope:Scoper", ptr %t639, i32 0, i32 25
  %t642 = load ptr, ptr %t641, !tbaa !29
  %t644 = icmp eq ptr %t642, null
  br i1 %t644, label %bb191, label %bb192
bb190:
  br label %bb197
bb191:
  call void @__olang_check_failed(ptr @olang_loc_34f683ba23edb410_12747076584ea874)
  unreachable
bb192:
  br label %bb193
bb193:
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t648 = getelementptr %"compiler/scope:Scoper", ptr %t646, i32 0, i32 25
  %t649 = load ptr, ptr %t648, !tbaa !29
  %t652 = getelementptr %"compiler/typed:Body", ptr %t649, i32 0, i32 7
  %t653 = load i64, ptr %l20, !tbaa !24
  %t656 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t652, i64 %t653)
  store %"compiler/typed:Local" %t656, ptr %l338
  br label %bb194
bb194:
  %t657 = getelementptr %"compiler/typed:Local", ptr %l338, i32 0, i32 0
  %t658 = load i32, ptr %t657, !tbaa !23
  %t659 = load ptr, ptr %l329, !tbaa !29
  %t661 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t659, i32 %t658)
  store { i64, ptr } %t661, ptr %l340
  br label %bb195
bb195:
  %t662 = load ptr, ptr %l318, !tbaa !29
  %t663 = load i64, ptr %l319, !tbaa !24
  %t664 = load ptr, ptr %l324, !tbaa !29
  %t665 = load i64, ptr %l325, !tbaa !24
  %t666 = load { i64, ptr }, ptr %l340, !tbaa !27
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v2, ptr %v0, ptr %t662, i64 %t663, ptr %t664, i64 %t665, { i64, ptr } %t666, i64 0)
  br label %bb196
bb196:
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s2)
  br label %bb276
bb198:
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t668 = load ptr, ptr %l4, !tbaa !29
  %t669 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t670 = load { i64, [2 x i64] }, ptr %t669
  %t674 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v2, ptr %t667, ptr %t668, { i64, [2 x i64] } %t670)
  store i64 %t674, ptr %l344
  br label %bb199
bb199:
  %t675 = load i64, ptr %l344, !tbaa !24
  store i64 %t675, ptr %l21, !tbaa !24
  %t676 = load i64, ptr %l21, !tbaa !24
  %t678 = icmp sge i64 %t676, 0
  br i1 %t678, label %bb200, label %bb201
bb200:
  %t680 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 5
  %t681 = load i1, ptr %t680, !tbaa !21
  store i1 %t681, ptr %l347, !tbaa !21
  br label %bb202
bb201:
  store i1 false, ptr %l347, !tbaa !21
  br label %bb202
bb202:
  %t683 = load i1, ptr %l347, !tbaa !21
  br i1 %t683, label %bb203, label %bb204
bb203:
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t685 = load ptr, ptr %l4, !tbaa !29
  %t687 = getelementptr %"compiler/typed:Call", ptr %t685, i32 0, i32 1
  %t688 = load { i64, ptr }, ptr %t687, !tbaa !27
  store { i64, ptr } %t688, ptr %l351, !tbaa !27
  %t689 = load i64, ptr %l21, !tbaa !24
  %t691 = getelementptr { i64, ptr }, ptr %l351, i32 0, i32 1
  %t692 = load ptr, ptr %t691, !tbaa !27
  %t693 = getelementptr ptr, ptr %t692, i64 %t689
  %t694 = load ptr, ptr %t693, !tbaa !39
  %t697 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %v2, ptr %t684, ptr %t694)
  store i64 %t697, ptr %l354
  br label %bb205
bb204:
  br label %bb221
bb205:
  %t698 = load i64, ptr %l354, !tbaa !24
  store i64 %t698, ptr %l22, !tbaa !24
  %t699 = load i64, ptr %l22, !tbaa !24
  %t701 = icmp sge i64 %t699, 0
  br i1 %t701, label %bb206, label %bb207
bb206:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load i64, ptr %l22, !tbaa !24
  %t707 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisParam(ptr %v0, ptr %t703, i64 %t704)
  store i1 %t707, ptr %l360
  br label %bb208
bb207:
  store i1 false, ptr %l357, !tbaa !21
  br label %bb209
bb208:
  %t708 = load i1, ptr %l360, !tbaa !21
  %t709 = xor i1 %t708, true
  store i1 %t709, ptr %l357, !tbaa !21
  br label %bb209
bb209:
  %t711 = load i1, ptr %l357, !tbaa !21
  br i1 %t711, label %bb210, label %bb211
bb210:
  store %olang.scope zeroinitializer, ptr %s26
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l362, !tbaa !29
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load %"compiler/source:Span", ptr %l1
  %t717 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t713, %"compiler/source:Span" %t714)
  store %"compiler/source:Span" %t717, ptr %l365
  br label %bb212
bb211:
  br label %bb220
bb212:
  %t718 = load ptr, ptr %l0, !tbaa !29
  %t720 = getelementptr %"compiler/scope:Scoper", ptr %t718, i32 0, i32 0
  %t721 = load ptr, ptr %t720, !tbaa !29
  %t723 = getelementptr %"compiler/generic:Program", ptr %t721, i32 0, i32 0
  %t724 = load ptr, ptr %t723, !tbaa !29
  %t726 = getelementptr %"compiler/load:Loader", ptr %t724, i32 0, i32 3
  %t727 = load ptr, ptr %t726, !tbaa !29
  store ptr %t727, ptr %l369, !tbaa !29
  %t728 = load ptr, ptr %l0, !tbaa !29
  %t730 = getelementptr %"compiler/scope:Scoper", ptr %t728, i32 0, i32 25
  %t731 = load ptr, ptr %t730, !tbaa !29
  %t733 = icmp eq ptr %t731, null
  br i1 %t733, label %bb213, label %bb214
bb213:
  call void @__olang_check_failed(ptr @olang_loc_6755090fbbb96f65_b19d41a2104e1b69)
  unreachable
bb214:
  br label %bb215
bb215:
  %t735 = load ptr, ptr %l0, !tbaa !29
  %t737 = getelementptr %"compiler/scope:Scoper", ptr %t735, i32 0, i32 25
  %t738 = load ptr, ptr %t737, !tbaa !29
  %t741 = getelementptr %"compiler/typed:Body", ptr %t738, i32 0, i32 7
  %t742 = load i64, ptr %l22, !tbaa !24
  %t745 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t741, i64 %t742)
  store %"compiler/typed:Local" %t745, ptr %l378
  br label %bb216
bb216:
  %t746 = getelementptr %"compiler/typed:Local", ptr %l378, i32 0, i32 0
  %t747 = load i32, ptr %t746, !tbaa !23
  %t748 = load ptr, ptr %l369, !tbaa !29
  %t750 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t748, i32 %t747)
  store { i64, ptr } %t750, ptr %l380
  br label %bb217
bb217:
  %t751 = load { i64, ptr }, ptr %l380, !tbaa !27
  %t752 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eViewKept(ptr %v0, ptr %s26, { i64, ptr } %t751)
  store %"compiler/msgs:Msg" %t752, ptr %l381
  br label %bb218
bb218:
  %t753 = load ptr, ptr %l362, !tbaa !29
  %t754 = load %"compiler/source:Span", ptr %l365
  %t755 = load %"compiler/msgs:Msg", ptr %l381
  %t756 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s26, ptr %t753, %"compiler/source:Span" %t754, %"compiler/msgs:Msg" %t755)
  store i64 %t756, ptr %l382
  br label %bb219
bb219:
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s2)
  br label %bb276
bb220:
  br label %bb221
bb221:
  %t757 = load i64, ptr %l21, !tbaa !24
  %t759 = icmp sge i64 %t757, 0
  br i1 %t759, label %bb222, label %bb223
bb222:
  %t761 = load ptr, ptr %l0, !tbaa !29
  store ptr %t761, ptr %l386, !tbaa !29
  %t762 = load ptr, ptr %l4, !tbaa !29
  %t764 = getelementptr %"compiler/typed:Call", ptr %t762, i32 0, i32 1
  %t765 = load { i64, ptr }, ptr %t764, !tbaa !27
  store { i64, ptr } %t765, ptr %l388, !tbaa !27
  %t766 = load i64, ptr %l21, !tbaa !24
  %t768 = getelementptr { i64, ptr }, ptr %l388, i32 0, i32 1
  %t769 = load ptr, ptr %t768, !tbaa !27
  %t770 = getelementptr ptr, ptr %t769, i64 %t766
  %t771 = load ptr, ptr %t770, !tbaa !39
  store ptr %t771, ptr %l390, !tbaa !29
  %t772 = load ptr, ptr %l0, !tbaa !29
  %t773 = load %"compiler/source:Span", ptr %l1
  %t776 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t772, %"compiler/source:Span" %t773)
  store %"compiler/source:Span" %t776, ptr %l393
  br label %bb224
bb223:
  store i1 false, ptr %l385, !tbaa !21
  br label %bb226
bb224:
  %t777 = load ptr, ptr %l386, !tbaa !29
  %t778 = load ptr, ptr %l390, !tbaa !29
  %t779 = load %"compiler/source:Span", ptr %l393
  %t780 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewKept(ptr %v0, ptr %v2, ptr %t777, ptr %t778, %"compiler/source:Span" %t779, i1 false)
  store i1 %t780, ptr %l394
  br label %bb225
bb225:
  %t781 = load i1, ptr %l394, !tbaa !21
  store i1 %t781, ptr %l385, !tbaa !21
  br label %bb226
bb226:
  %t782 = load i1, ptr %l385, !tbaa !21
  br i1 %t782, label %bb227, label %bb228
bb227:
  call void @__olang_scope_close(ptr %s2)
  br label %bb276
bb228:
  br label %bb229
bb229:
  %t783 = load i64, ptr %l21, !tbaa !24
  %t785 = icmp sge i64 %t783, 0
  br i1 %t785, label %bb230, label %bb231
bb230:
  %t787 = load ptr, ptr %l0, !tbaa !29
  store ptr %t787, ptr %l398, !tbaa !29
  %t788 = load ptr, ptr %l4, !tbaa !29
  %t790 = getelementptr %"compiler/typed:Call", ptr %t788, i32 0, i32 1
  %t791 = load { i64, ptr }, ptr %t790, !tbaa !27
  store { i64, ptr } %t791, ptr %l400, !tbaa !27
  %t792 = load i64, ptr %l21, !tbaa !24
  %t794 = getelementptr { i64, ptr }, ptr %l400, i32 0, i32 1
  %t795 = load ptr, ptr %t794, !tbaa !27
  %t796 = getelementptr ptr, ptr %t795, i64 %t792
  %t797 = load ptr, ptr %t796, !tbaa !39
  store ptr %t797, ptr %l402, !tbaa !29
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t799 = load %"compiler/source:Span", ptr %l1
  %t802 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t798, %"compiler/source:Span" %t799)
  store %"compiler/source:Span" %t802, ptr %l405
  br label %bb232
bb231:
  store i1 false, ptr %l397, !tbaa !21
  br label %bb234
bb232:
  %t803 = load ptr, ptr %l398, !tbaa !29
  %t804 = load ptr, ptr %l402, !tbaa !29
  %t805 = load %"compiler/source:Span", ptr %l405
  %t806 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartKept(ptr %v0, ptr %v2, ptr %t803, ptr %t804, %"compiler/source:Span" %t805)
  store i1 %t806, ptr %l406
  br label %bb233
bb233:
  %t807 = load i1, ptr %l406, !tbaa !21
  store i1 %t807, ptr %l397, !tbaa !21
  br label %bb234
bb234:
  %t808 = load i1, ptr %l397, !tbaa !21
  br i1 %t808, label %bb235, label %bb236
bb235:
  call void @__olang_scope_close(ptr %s2)
  br label %bb276
bb236:
  br label %bb237
bb237:
  %t809 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 2
  %t810 = load i1, ptr %t809, !tbaa !21
  br i1 %t810, label %bb238, label %bb239
bb238:
  %t812 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %s2)
  store %"compiler/msgs:Msg" %t812, ptr %l409
  br label %bb240
bb239:
  %t813 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeObligationUnmet(ptr %s2)
  store %"compiler/msgs:Msg" %t813, ptr %l410
  br label %bb241
bb240:
  %t814 = load %"compiler/msgs:Msg", ptr %l409
  store %"compiler/msgs:Msg" %t814, ptr %l408
  br label %bb242
bb241:
  %t815 = load %"compiler/msgs:Msg", ptr %l410
  store %"compiler/msgs:Msg" %t815, ptr %l408
  br label %bb242
bb242:
  %t816 = load %"compiler/msgs:Msg", ptr %l408
  store %"compiler/msgs:Msg" %t816, ptr %l23
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t818 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 1
  %t819 = load { i64, [2 x i64] }, ptr %t818
  %t820 = load ptr, ptr %l4, !tbaa !29
  %t824 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedThroughElem(ptr %v0, ptr %v2, ptr %t817, { i64, [2 x i64] } %t819, ptr %t820)
  store i1 %t824, ptr %l414
  br label %bb243
bb243:
  %t825 = load i1, ptr %l414, !tbaa !21
  br i1 %t825, label %bb244, label %bb245
bb244:
  store i1 true, ptr %l415, !tbaa !21
  br label %bb247
bb245:
  %t826 = load ptr, ptr %l0, !tbaa !29
  %t827 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t828 = load { i64, [2 x i64] }, ptr %t827
  %t829 = load ptr, ptr %l4, !tbaa !29
  %t833 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedThroughElem(ptr %v0, ptr %v2, ptr %t826, { i64, [2 x i64] } %t828, ptr %t829)
  store i1 %t833, ptr %l419
  br label %bb246
bb246:
  %t834 = load i1, ptr %l419, !tbaa !21
  store i1 %t834, ptr %l415, !tbaa !21
  br label %bb247
bb247:
  %t835 = load i1, ptr %l415, !tbaa !21
  br i1 %t835, label %bb248, label %bb249
bb248:
  %t836 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldBindingUnknown(ptr %s2)
  store %"compiler/msgs:Msg" %t836, ptr %l420
  br label %bb250
bb249:
  br label %bb251
bb250:
  %t837 = load %"compiler/msgs:Msg", ptr %l420
  store %"compiler/msgs:Msg" %t837, ptr %l23
  br label %bb251
bb251:
  %t838 = load ptr, ptr %l0, !tbaa !29
  store ptr %t838, ptr %l421, !tbaa !29
  %t839 = load ptr, ptr %l0, !tbaa !29
  %t840 = load %"compiler/source:Span", ptr %l1
  %t843 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t839, %"compiler/source:Span" %t840)
  store %"compiler/source:Span" %t843, ptr %l424
  br label %bb252
bb252:
  %t844 = load %"compiler/msgs:Msg", ptr %l23
  %t845 = load ptr, ptr %l421, !tbaa !29
  %t846 = load %"compiler/source:Span", ptr %l424
  %t848 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s2, ptr %t845, %"compiler/source:Span" %t846, %"compiler/msgs:Msg" %t844)
  store i64 %t848, ptr %l426
  br label %bb253
bb253:
  %t849 = load i64, ptr %l426, !tbaa !24
  store i64 %t849, ptr %l24, !tbaa !24
  %t850 = load ptr, ptr %l0, !tbaa !29
  %t852 = getelementptr %"compiler/scope:Scoper", ptr %t850, i32 0, i32 1
  %t853 = load i64, ptr %l2, !tbaa !24
  %t856 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t852, i64 %t853)
  store ptr %t856, ptr %l430
  br label %bb254
bb254:
  %t857 = load ptr, ptr %l430, !tbaa !29
  store ptr %t857, ptr %l25, !tbaa !29
  %t858 = load ptr, ptr %l0, !tbaa !29
  store ptr %t858, ptr %l431, !tbaa !29
  %t859 = load i64, ptr %l24, !tbaa !24
  store i64 %t859, ptr %l432, !tbaa !24
  %t860 = load ptr, ptr %l25, !tbaa !29
  %t862 = getelementptr %"compiler/typed:Body", ptr %t860, i32 0, i32 3
  %t863 = load i64, ptr %t862, !tbaa !24
  store i64 %t863, ptr %l434, !tbaa !24
  %t864 = load ptr, ptr %l0, !tbaa !29
  %t865 = load ptr, ptr %l25, !tbaa !29
  %t867 = getelementptr %"compiler/typed:Body", ptr %t865, i32 0, i32 3
  %t868 = load i64, ptr %t867, !tbaa !24
  %t869 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 3
  %t870 = load %"compiler/source:Span", ptr %t869
  %t874 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t864, i64 %t868, %"compiler/source:Span" %t870)
  store %"compiler/source:Span" %t874, ptr %l439
  br label %bb255
bb255:
  %t875 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteObligationOrigin(ptr %s2)
  store %"compiler/msgs:Msg" %t875, ptr %l440
  br label %bb256
bb256:
  %t876 = load ptr, ptr %l431, !tbaa !29
  %t877 = load i64, ptr %l432, !tbaa !24
  %t878 = load i64, ptr %l434, !tbaa !24
  %t879 = load %"compiler/source:Span", ptr %l439
  %t880 = load %"compiler/msgs:Msg", ptr %l440
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s2, ptr %t876, i64 %t877, i64 %t878, %"compiler/source:Span" %t879, %"compiler/msgs:Msg" %t880)
  br label %bb257
bb257:
  %t881 = load ptr, ptr %l0, !tbaa !29
  %t882 = load ptr, ptr %l4, !tbaa !29
  %t883 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t884 = load { i64, [2 x i64] }, ptr %t883
  %t888 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v2, ptr %t881, ptr %t882, { i64, [2 x i64] } %t884)
  store i64 %t888, ptr %l444
  br label %bb258
bb258:
  %t889 = load i64, ptr %l444, !tbaa !24
  store i64 %t889, ptr %l26, !tbaa !24
  %t890 = load ptr, ptr %l0, !tbaa !29
  %t891 = load ptr, ptr %l4, !tbaa !29
  %t892 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 1
  %t893 = load { i64, [2 x i64] }, ptr %t892
  %t897 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v2, ptr %t890, ptr %t891, { i64, [2 x i64] } %t893)
  store i64 %t897, ptr %l448
  br label %bb259
bb259:
  %t898 = load i64, ptr %l448, !tbaa !24
  store i64 %t898, ptr %l27, !tbaa !24
  %t899 = load i64, ptr %l26, !tbaa !24
  %t901 = icmp sge i64 %t899, 0
  br i1 %t901, label %bb260, label %bb261
bb260:
  %t903 = load ptr, ptr %l0, !tbaa !29
  %t904 = load ptr, ptr %l4, !tbaa !29
  %t906 = getelementptr %"compiler/typed:Call", ptr %t904, i32 0, i32 1
  %t907 = load { i64, ptr }, ptr %t906, !tbaa !27
  store { i64, ptr } %t907, ptr %l454, !tbaa !27
  %t908 = load i64, ptr %l26, !tbaa !24
  %t910 = getelementptr { i64, ptr }, ptr %l454, i32 0, i32 1
  %t911 = load ptr, ptr %t910, !tbaa !27
  %t912 = getelementptr ptr, ptr %t911, i64 %t908
  %t913 = load ptr, ptr %t912, !tbaa !39
  %t916 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elentLoopCopy(ptr %v0, ptr %v2, ptr %t903, ptr %t913)
  store i1 %t916, ptr %l457
  br label %bb262
bb261:
  store i1 false, ptr %l451, !tbaa !21
  br label %bb263
bb262:
  %t917 = load i1, ptr %l457, !tbaa !21
  store i1 %t917, ptr %l451, !tbaa !21
  br label %bb263
bb263:
  %t918 = load i1, ptr %l451, !tbaa !21
  br i1 %t918, label %bb264, label %bb265
bb264:
  %t919 = load ptr, ptr %l0, !tbaa !29
  %t920 = load i64, ptr %l24, !tbaa !24
  %t921 = load ptr, ptr %l4, !tbaa !29
  %t923 = getelementptr %"compiler/typed:Call", ptr %t921, i32 0, i32 1
  %t924 = load { i64, ptr }, ptr %t923, !tbaa !27
  store { i64, ptr } %t924, ptr %l461, !tbaa !27
  %t925 = load i64, ptr %l26, !tbaa !24
  %t927 = getelementptr { i64, ptr }, ptr %l461, i32 0, i32 1
  %t928 = load ptr, ptr %t927, !tbaa !27
  %t929 = getelementptr ptr, ptr %t928, i64 %t925
  %t930 = load ptr, ptr %t929, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteLoopCopy(ptr %v0, ptr %v2, ptr %t919, i64 %t920, ptr %t930)
  br label %bb266
bb265:
  %t934 = load i64, ptr %l26, !tbaa !24
  %t936 = icmp sge i64 %t934, 0
  br i1 %t936, label %bb267, label %bb268
bb266:
  br label %bb275
bb267:
  %t938 = load i64, ptr %l27, !tbaa !24
  %t940 = icmp sge i64 %t938, 0
  store i1 %t940, ptr %l466, !tbaa !21
  br label %bb269
bb268:
  store i1 false, ptr %l466, !tbaa !21
  br label %bb269
bb269:
  %t942 = load i1, ptr %l466, !tbaa !21
  br i1 %t942, label %bb270, label %bb271
bb270:
  %t943 = load ptr, ptr %l0, !tbaa !29
  store ptr %t943, ptr %l469, !tbaa !29
  %t944 = load i64, ptr %l24, !tbaa !24
  store i64 %t944, ptr %l470, !tbaa !24
  %t945 = load ptr, ptr %l0, !tbaa !29
  %t946 = load %"compiler/source:Span", ptr %l1
  %t949 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t945, %"compiler/source:Span" %t946)
  store %"compiler/source:Span" %t949, ptr %l473
  br label %bb272
bb271:
  br label %bb274
bb272:
  %t950 = load ptr, ptr %l4, !tbaa !29
  %t951 = load i64, ptr %l26, !tbaa !24
  %t952 = load i64, ptr %l27, !tbaa !24
  %t953 = load { i64, [2 x i64] }, ptr %l10
  %t954 = load ptr, ptr %l469, !tbaa !29
  %t955 = load i64, ptr %l470, !tbaa !24
  %t956 = load %"compiler/source:Span", ptr %l473
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMakeWhere(ptr %v0, ptr %v2, ptr %t954, i64 %t955, %"compiler/source:Span" %t956, ptr %t950, i64 %t951, i64 %t952, { i64, [2 x i64] } %t953)
  br label %bb273
bb273:
  br label %bb274
bb274:
  br label %bb275
bb275:
  call void @__olang_scope_close(ptr %s2)
  br label %bb276
bb276:
  %t961 = load i64, ptr %l7, !tbaa !24
  %t963 = add i64 %t961, 1
  store i64 %t963, ptr %l7, !tbaa !24
  br label %bb2
bb277:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eeqAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l39 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l56 = alloca i1
  %l64 = alloca i1
  %l65 = alloca { i64, ptr }
  %l77 = alloca i1
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l100 = alloca i1
  %l110 = alloca %"compiler/source:Span"
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 25
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_7b1e363353e9e01f_5d568e34003a167b)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l18
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l17
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l7, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  store i64 %t31, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t39 = icmp slt i64 %t33, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t41, ptr %l26, !tbaa !27
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = icmp ne i8 %t47, 10
  store i1 %t49, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l25, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb12, label %bb13
bb12:
  br label %bb66
bb13:
  br label %bb14
bb14:
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i8, ptr %t58, i64 %t55
  %t60 = load i8, ptr %t59, !tbaa !32
  store i8 %t60, ptr %l5, !tbaa !22
  %t62 = load i8, ptr %l5, !tbaa !22
  %t64 = icmp eq i8 %t62, 40
  br i1 %t64, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb17
bb16:
  %t66 = load i8, ptr %l5, !tbaa !22
  %t68 = icmp eq i8 %t66, 91
  store i1 %t68, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t70 = load i1, ptr %l36, !tbaa !21
  br i1 %t70, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb20
bb19:
  %t71 = load i8, ptr %l5, !tbaa !22
  %t73 = icmp eq i8 %t71, 123
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l4, !tbaa !24
  br label %bb64
bb22:
  %t80 = load i8, ptr %l5, !tbaa !22
  %t82 = icmp eq i8 %t80, 41
  br i1 %t82, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb25
bb24:
  %t84 = load i8, ptr %l5, !tbaa !22
  %t86 = icmp eq i8 %t84, 93
  store i1 %t86, ptr %l46, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l46, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb28
bb27:
  %t89 = load i8, ptr %l5, !tbaa !22
  %t91 = icmp eq i8 %t89, 125
  store i1 %t91, ptr %l49, !tbaa !21
  br label %bb28
bb28:
  %t93 = load i1, ptr %l49, !tbaa !21
  br i1 %t93, label %bb29, label %bb30
bb29:
  %t94 = load i64, ptr %l4, !tbaa !24
  %t96 = sub i64 %t94, 1
  store i64 %t96, ptr %l4, !tbaa !24
  br label %bb63
bb30:
  %t98 = load i8, ptr %l5, !tbaa !22
  %t100 = icmp eq i8 %t98, 61
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t102 = load i64, ptr %l4, !tbaa !24
  %t104 = icmp eq i64 %t102, 0
  store i1 %t104, ptr %l56, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb33
bb33:
  %t106 = load i1, ptr %l56, !tbaa !21
  br i1 %t106, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load i64, ptr %l3, !tbaa !24
  %t109 = add i64 %t107, 1
  %t110 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t115 = icmp slt i64 %t109, %t112
  br i1 %t115, label %bb36, label %bb37
bb35:
  br label %bb62
bb36:
  %t117 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t117, ptr %l65, !tbaa !27
  %t118 = load i64, ptr %l3, !tbaa !24
  %t120 = add i64 %t118, 1
  %t122 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i8, ptr %t123, i64 %t120
  %t125 = load i8, ptr %t124, !tbaa !32
  %t127 = icmp eq i8 %t125, 61
  store i1 %t127, ptr %l64, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb38
bb38:
  %t129 = load i1, ptr %l64, !tbaa !21
  br i1 %t129, label %bb39, label %bb40
bb39:
  %t130 = load i64, ptr %l3, !tbaa !24
  %t132 = add i64 %t130, 2
  store i64 %t132, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb65
bb40:
  br label %bb41
bb41:
  %t134 = load i64, ptr %l3, !tbaa !24
  store i64 %t134, ptr %l6, !tbaa !24
  br label %bb42
bb42:
  %t136 = load i64, ptr %l6, !tbaa !24
  %t137 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t138 = load i32, ptr %t137, !tbaa !23
  %t140 = sext i32 %t138 to i64
  %t143 = icmp sgt i64 %t136, %t140
  br i1 %t143, label %bb43, label %bb44
bb43:
  %t145 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t145, ptr %l78, !tbaa !27
  %t146 = load i64, ptr %l6, !tbaa !24
  %t148 = sub i64 %t146, 1
  %t150 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i8, ptr %t151, i64 %t148
  %t153 = load i8, ptr %t152, !tbaa !32
  %t155 = icmp ne i8 %t153, 32
  store i1 %t155, ptr %l77, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb45
bb45:
  %t157 = load i1, ptr %l77, !tbaa !21
  br i1 %t157, label %bb46, label %bb47
bb46:
  %t158 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t158, ptr %l84, !tbaa !27
  %t159 = load i64, ptr %l6, !tbaa !24
  %t161 = sub i64 %t159, 1
  %t163 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i8, ptr %t164, i64 %t161
  %t166 = load i8, ptr %t165, !tbaa !32
  %t168 = icmp ne i8 %t166, 41
  store i1 %t168, ptr %l83, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb48
bb48:
  %t170 = load i1, ptr %l83, !tbaa !21
  br i1 %t170, label %bb49, label %bb50
bb49:
  %t171 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t171, ptr %l90, !tbaa !27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t174 = sub i64 %t172, 1
  %t176 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 %t174
  %t179 = load i8, ptr %t178, !tbaa !32
  %t181 = icmp ne i8 %t179, 93
  store i1 %t181, ptr %l89, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb51
bb51:
  %t183 = load i1, ptr %l89, !tbaa !21
  br i1 %t183, label %bb52, label %bb53
bb52:
  %t184 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t184, ptr %l96, !tbaa !27
  %t185 = load i64, ptr %l6, !tbaa !24
  %t187 = sub i64 %t185, 1
  %t189 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i8, ptr %t190, i64 %t187
  %t192 = load i8, ptr %t191, !tbaa !32
  %t194 = call i1 @compiler_2fscope_2eisNameChar(i8 %t192)
  store i1 %t194, ptr %l100
  br label %bb54
bb53:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb55
bb54:
  %t195 = load i1, ptr %l100, !tbaa !21
  %t196 = xor i1 %t195, true
  store i1 %t196, ptr %l95, !tbaa !21
  br label %bb55
bb55:
  %t198 = load i1, ptr %l95, !tbaa !21
  %t199 = xor i1 %t198, true
  br i1 %t199, label %bb56, label %bb57
bb56:
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t201 = load i64, ptr %l6, !tbaa !24
  %t203 = sub i64 %t201, 1
  store i64 %t203, ptr %l6, !tbaa !24
  br label %bb59
bb59:
  br label %bb42
bb60:
  %t205 = load i64, ptr %l6, !tbaa !24
  %t207 = trunc i64 %t205 to i32
  %t208 = load i64, ptr %l3, !tbaa !24
  %t210 = add i64 %t208, 1
  %t212 = trunc i64 %t210 to i32
  %t215 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t207, i32 %t212)
  store %"compiler/source:Span" %t215, ptr %l110
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s6)
  %t216 = load %"compiler/source:Span", ptr %l110
  store %"compiler/source:Span" %t216, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t217 = load i64, ptr %l3, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l3, !tbaa !24
  br label %bb65
bb65:
  br label %bb8
bb66:
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eexports(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca ptr
  %l52 = alloca i64
  %l56 = alloca ptr
  %l60 = alloca i1
  %l64 = alloca ptr
  %l67 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l103 = alloca { i64, [3 x i64] }
  %l107 = alloca { i64, ptr }
  %l109 = alloca %"compiler/msgs:Msg"
  %l110 = alloca i64
  %s3 = alloca %olang.scope
  %t192 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load i64, ptr %l15, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l22, !tbaa !24
  store i64 %t33, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb42
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l43
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l43, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 1
  %t63 = load { i64, [2 x i64] }, ptr %t62
  store { i64, [2 x i64] } %t63, ptr %l7
  %t65 = load { i64, [2 x i64] }, ptr %l7
  %t67 = extractvalue { i64, [2 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 0
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t71 = getelementptr { i64 }, ptr %t70, i32 0, i32 0
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l8, !tbaa !24
  br label %bb15
bb14:
  br label %bb35
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/scope:Scoper", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t77, i64 %t78)
  store i64 %t81, ptr %l52
  br label %bb16
bb16:
  %t82 = load i64, ptr %l52, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s3, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l56
  br label %bb17
bb17:
  %t91 = load ptr, ptr %l56, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Func", ptr %t91, i32 0, i32 7
  %t94 = load i1, ptr %t93, !tbaa !21
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb22
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/scope:Scoper", ptr %t98, i32 0, i32 6
  %t101 = load i64, ptr %l6, !tbaa !24
  %t104 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t100, i64 %t101)
  store ptr %t104, ptr %l64
  br label %bb20
bb20:
  %t105 = load ptr, ptr %l64, !tbaa !29
  %t107 = getelementptr %"compiler/scope:summary", ptr %t105, i32 0, i32 0
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t107)
  store i64 %t109, ptr %l67
  br label %bb21
bb21:
  %t110 = load i64, ptr %l67, !tbaa !24
  %t111 = icmp eq i64 %t110, 0
  store i1 %t111, ptr %l60, !tbaa !21
  br label %bb22
bb22:
  %t113 = load i1, ptr %l60, !tbaa !21
  br i1 %t113, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb24:
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t117, i64 %t118)
  store ptr %t121, ptr %l72
  br label %bb26
bb26:
  %t122 = load ptr, ptr %l72, !tbaa !29
  store ptr %t122, ptr %l10, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 10
  store ptr %t131, ptr %l76, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/scope:Scoper", ptr %t132, i32 0, i32 0
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t136 = load i64, ptr %l9, !tbaa !24
  %t139 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t135, i64 %t136)
  store i64 %t139, ptr %l80
  br label %bb27
bb27:
  %t140 = load ptr, ptr %l76, !tbaa !29
  %t141 = load i64, ptr %l80, !tbaa !24
  %t142 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  store ptr %t142, ptr %l81
  br label %bb28
bb28:
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t145 = getelementptr %"compiler/load:Module", ptr %t143, i32 0, i32 4
  %t146 = load i64, ptr %t145, !tbaa !24
  store i64 %t146, ptr %l11, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i64, ptr %l6, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/scope:Scoper", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/load:Loader", ptr %t156, i32 0, i32 3
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t163 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v0, ptr %s3, ptr %t148, i64 %t149, ptr %t159)
  store { i64, ptr } %t163, ptr %l90
  br label %bb29
bb29:
  %t164 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t164, ptr %l12, !tbaa !27
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 0
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/load:Loader", ptr %t171, i32 0, i32 4
  %t174 = load ptr, ptr %t173, !tbaa !29
  store ptr %t174, ptr %l94, !tbaa !29
  %t175 = load i64, ptr %l11, !tbaa !24
  %t176 = load ptr, ptr %l10, !tbaa !29
  %t178 = getelementptr %"compiler/ast:Func", ptr %t176, i32 0, i32 0
  %t179 = getelementptr %"compiler/source:Span", ptr %t178, i32 0, i32 0
  %t180 = load i32, ptr %t179, !tbaa !23
  %t182 = sext i32 %t180 to i64
  %t183 = load ptr, ptr %l10, !tbaa !29
  %t185 = getelementptr %"compiler/ast:Func", ptr %t183, i32 0, i32 0
  %t186 = getelementptr %"compiler/source:Span", ptr %t185, i32 0, i32 0
  %t187 = load i32, ptr %t186, !tbaa !23
  %t189 = sext i32 %t187 to i64
  %t191 = add i64 %t189, 6
  store { i64, [3 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 0
  store i64 3, ptr %t193
  %t195 = insertvalue { i64, i64, i64 } undef, i64 %t175, 0
  %t197 = insertvalue { i64, i64, i64 } %t195, i64 %t182, 1
  %t199 = insertvalue { i64, i64, i64 } %t197, i64 %t191, 2
  %t200 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  store { i64, i64, i64 } %t199, ptr %t200
  %t201 = load { i64, [3 x i64] }, ptr %t192
  store { i64, [3 x i64] } %t201, ptr %l103
  %t202 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t206 = icmp sgt i64 %t204, 0
  br i1 %t206, label %bb30, label %bb31
bb30:
  %t208 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, ptr }, ptr %t209, i64 0
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !37
  store { i64, ptr } %t211, ptr %l107, !tbaa !27
  br label %bb32
bb31:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l107, !tbaa !27
  br label %bb32
bb32:
  %t213 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t214 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportObligation(ptr %s3, ptr %s3, { i64, ptr } %t213)
  store %"compiler/msgs:Msg" %t214, ptr %l109
  br label %bb33
bb33:
  %t215 = load ptr, ptr %l94, !tbaa !29
  %t216 = load { i64, [3 x i64] }, ptr %l103
  %t217 = load %"compiler/msgs:Msg", ptr %l109
  %t218 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t215, { i64, [3 x i64] } %t216, %"compiler/msgs:Msg" %t217)
  store i64 %t218, ptr %l110
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_3d4ddf74a6173f57_410f107a77dd9b9b)
  unreachable
bb40:
  br label %bb41
bb41:
  %t219 = load i64, ptr %l5, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l5, !tbaa !24
  br label %bb8
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t7)
  store ptr %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l8, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l3, !tbaa !29
  br label %bb11
bb6:
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 18}
  %t32 = icmp eq i64 %t30, 3
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t44 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceDecl(ptr %v0, ptr %s0, ptr %t40, ptr %t41)
  store i64 %t44, ptr %l24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l24, !tbaa !24
  store i64 %t45, ptr %l9, !tbaa !24
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_e3d7361eb9c064f6_d6d91699ddbb69ea)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t46 = load i64, ptr %l9, !tbaa !24
  store i64 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efitErrorAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca %"compiler/msgs:Msg"
  %l5 = alloca { i64, ptr }
  %l8 = alloca i1
  %l10 = alloca { i64, [2 x i64] }
  %l13 = alloca { i64, [2 x i64] }
  %l15 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca %"compiler/msgs:Msg"
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i64
  %l25 = alloca %"compiler/msgs:Msg"
  %l30 = alloca i1
  %l33 = alloca i1
  %l37 = alloca %"compiler/msgs:Msg"
  %l41 = alloca %"compiler/msgs:Msg"
  %l45 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l54 = alloca { i64, [2 x i64] }
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca [24 x i8]
  %l74 = alloca ptr
  %l81 = alloca ptr
  %l90 = alloca %"compiler/typed:Local"
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l98 = alloca %"compiler/msgs:Msg"
  %l102 = alloca %"compiler/msgs:Msg"
  %l106 = alloca %"compiler/msgs:Msg"
  %l111 = alloca %"compiler/msgs:Msg"
  %l112 = alloca %"compiler/msgs:Msg"
  %l113 = alloca %"compiler/msgs:Msg"
  %l117 = alloca %"compiler/msgs:Msg"
  %l121 = alloca %"compiler/msgs:Msg"
  %l132 = alloca %"compiler/msgs:Msg"
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca %"compiler/msgs:Msg"
  %l138 = alloca %"compiler/msgs:Msg"
  %l142 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 74
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 78
  %t9 = load { i64, [2 x i64] }, ptr %t8
  store { i64, [2 x i64] } %t9, ptr %l10
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 76
  %t13 = load { i64, [2 x i64] }, ptr %t12
  store { i64, [2 x i64] } %t13, ptr %l13
  %t16 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l10, ptr %l13)
  store i1 %t16, ptr %l15
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t17 = load i1, ptr %l15, !tbaa !21
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 75
  %t23 = load %"compiler/source:Span", ptr %t22
  store %"compiler/source:Span" %t23, ptr %l18
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 77
  %t27 = load i1, ptr %t26, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %s1)
  store %"compiler/msgs:Msg" %t29, ptr %l22
  br label %bb9
bb8:
  %t30 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgHoldsShort(ptr %s1)
  store %"compiler/msgs:Msg" %t30, ptr %l23
  br label %bb10
bb9:
  %t31 = load %"compiler/msgs:Msg", ptr %l22
  store %"compiler/msgs:Msg" %t31, ptr %l21
  br label %bb11
bb10:
  %t32 = load %"compiler/msgs:Msg", ptr %l23
  store %"compiler/msgs:Msg" %t32, ptr %l21
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l18
  %t35 = load %"compiler/msgs:Msg", ptr %l21
  %t36 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s1, ptr %t33, %"compiler/source:Span" %t34, %"compiler/msgs:Msg" %t35)
  store i64 %t36, ptr %l24
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i64, ptr %l24, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
bb13:
  %t38 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeMayNotOutlive(ptr %s0)
  store %"compiler/msgs:Msg" %t38, ptr %l25
  br label %bb14
bb14:
  %t39 = load %"compiler/msgs:Msg", ptr %l25
  store %"compiler/msgs:Msg" %t39, ptr %l4
  %t40 = load i64, ptr %l2, !tbaa !24
  %t41 = load i64, ptr @G_2ecompiler_2fscope_2eFitLocal, !tbaa !24
  %t44 = icmp eq i64 %t40, %t41
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t46 = load i1, ptr %l3, !tbaa !21
  br i1 %t46, label %bb17, label %bb18
bb16:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr @G_2ecompiler_2fscope_2eFitPayload, !tbaa !24
  %t52 = icmp eq i64 %t48, %t49
  br i1 %t52, label %bb27, label %bb28
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 79
  %t57 = load i1, ptr %t56, !tbaa !21
  br i1 %t57, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb22
bb19:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb21
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 80
  %t62 = load i1, ptr %t61, !tbaa !21
  %t64 = xor i1 %t62, true
  store i1 %t64, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l33, !tbaa !21
  store i1 %t66, ptr %l30, !tbaa !21
  br label %bb22
bb22:
  %t67 = load i1, ptr %l30, !tbaa !21
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t68 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %s0)
  store %"compiler/msgs:Msg" %t68, ptr %l37
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t69 = load %"compiler/msgs:Msg", ptr %l37
  store %"compiler/msgs:Msg" %t69, ptr %l4
  br label %bb26
bb26:
  br label %bb101
bb27:
  %t70 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t70, ptr %l41
  br label %bb29
bb28:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load i64, ptr @G_2ecompiler_2fscope_2eFitOwn, !tbaa !24
  %t75 = icmp eq i64 %t71, %t72
  br i1 %t75, label %bb30, label %bb31
bb29:
  %t77 = load %"compiler/msgs:Msg", ptr %l41
  store %"compiler/msgs:Msg" %t77, ptr %l4
  br label %bb100
bb30:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb32
bb31:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t79 = load i64, ptr @G_2ecompiler_2fscope_2eFitReturn, !tbaa !24
  %t82 = icmp eq i64 %t78, %t79
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t84 = load i1, ptr %l45, !tbaa !21
  br i1 %t84, label %bb33, label %bb34
bb33:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/scope:Scoper", ptr %t85, i32 0, i32 109
  %t88 = load i1, ptr %t87, !tbaa !21
  store i1 %t88, ptr %l49, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb35
bb35:
  %t90 = load i1, ptr %l49, !tbaa !21
  br i1 %t90, label %bb36, label %bb37
bb36:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %t91)
  store { i64, [2 x i64] } %t93, ptr %l54
  br label %bb38
bb37:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb39
bb38:
  %t94 = load { i64, [2 x i64] }, ptr %l54
  %t96 = extractvalue { i64, [2 x i64] } %t94, 0
  %t97 = icmp eq i64 %t96, 0
  %t99 = xor i1 %t97, true
  store i1 %t99, ptr %l52, !tbaa !21
  br label %bb39
bb39:
  %t101 = load i1, ptr %l52, !tbaa !21
  br i1 %t101, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  store { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l58, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t102, ptr %l59, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = mul i64 24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l60, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 24, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %l60, 1
  store { i64, ptr } %t108, ptr %l5, !tbaa !27
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 25
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = icmp eq ptr %t113, null
  br i1 %t115, label %bb42, label %bb43
bb41:
  %t117 = load i64, ptr %l2, !tbaa !24
  %t118 = load i64, ptr @G_2ecompiler_2fscope_2eFitOwn, !tbaa !24
  %t121 = icmp eq i64 %t117, %t118
  br i1 %t121, label %bb60, label %bb61
bb42:
  call void @__olang_check_failed(ptr @olang_loc_12677068e04dfe45_ab703d1ad408b711)
  unreachable
bb43:
  br label %bb44
bb44:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 25
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Body", ptr %t126, i32 0, i32 16
  %t130 = load i1, ptr %t129, !tbaa !21
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/scope:Scoper", ptr %t134, i32 0, i32 0
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 0
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/load:Loader", ptr %t140, i32 0, i32 3
  %t143 = load ptr, ptr %t142, !tbaa !29
  store ptr %t143, ptr %l74, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/scope:Scoper", ptr %t144, i32 0, i32 25
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  br i1 %t149, label %bb47, label %bb48
bb46:
  br label %bb58
bb47:
  call void @__olang_check_failed(ptr @olang_loc_bf00db29bdc1b99e_9dc03d0b43789e0a)
  unreachable
bb48:
  br label %bb49
bb49:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/scope:Scoper", ptr %t151, i32 0, i32 25
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Body", ptr %t154, i32 0, i32 7
  store ptr %t157, ptr %l81, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/scope:Scoper", ptr %t158, i32 0, i32 25
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_bf00db29bdc1b99e_9dc03d0b43789e0a)
  unreachable
bb51:
  br label %bb52
bb52:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 25
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Body", ptr %t168, i32 0, i32 15
  %t172 = load i32, ptr %t171, !tbaa !23
  %t174 = sext i32 %t172 to i64
  %t175 = load ptr, ptr %l81, !tbaa !29
  %t177 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t175, i64 %t174)
  store %"compiler/typed:Local" %t177, ptr %l90
  br label %bb53
bb53:
  %t178 = getelementptr %"compiler/typed:Local", ptr %l90, i32 0, i32 0
  %t179 = load i32, ptr %t178, !tbaa !23
  %t180 = load ptr, ptr %l74, !tbaa !29
  %t182 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s8, ptr %t180, i32 %t179)
  store { i64, ptr } %t182, ptr %l92
  br label %bb54
bb54:
  %t183 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t185 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = add i64 %t184, %t187
  %t189 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t190 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t191 = add i64 %t188, %t190
  %t192 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t191)
  call void @olang_textcopy(ptr %t192, ptr %t183, i64 %t184)
  %t193 = getelementptr i8, ptr %t192, i64 %t184
  call void @olang_textcopy(ptr %t193, ptr %t186, i64 %t187)
  %t194 = getelementptr i8, ptr %t193, i64 %t187
  call void @olang_textcopy(ptr %t194, ptr %t189, i64 %t190)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t192, 1
  store { i64, ptr } %t196, ptr %l93, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  %t199 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  store i64 %t200, ptr %l95, !tbaa !24
  %t202 = load i64, ptr %l95, !tbaa !24
  %t203 = icmp eq i64 %t198, %t202
  br i1 %t203, label %bb55, label %bb56
bb55:
  %t205 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = load i64, ptr %l95, !tbaa !24
  %t210 = mul i64 %t209, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t206, ptr %t208, i64 %t210, i1 false)
  br label %bb57
bb56:
  %t211 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t211, ptr %l5, !tbaa !27
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb58:
  %t212 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t214 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenYieldShorter(ptr %s7, ptr %s0, { i64, ptr } %t212)
  store %"compiler/msgs:Msg" %t214, ptr %l98
  br label %bb59
bb59:
  %t215 = load %"compiler/msgs:Msg", ptr %l98
  store %"compiler/msgs:Msg" %t215, ptr %l4
  call void @__olang_scope_close(ptr %s7)
  br label %bb99
bb60:
  %t216 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnCannotOutlive(ptr %s0)
  store %"compiler/msgs:Msg" %t216, ptr %l102
  br label %bb62
bb61:
  %t217 = load i64, ptr %l2, !tbaa !24
  %t218 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  %t221 = icmp eq i64 %t217, %t218
  br i1 %t221, label %bb63, label %bb64
bb62:
  %t223 = load %"compiler/msgs:Msg", ptr %l102
  store %"compiler/msgs:Msg" %t223, ptr %l4
  br label %bb98
bb63:
  %t224 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoredRefOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t224, ptr %l106
  br label %bb65
bb64:
  %t225 = load i64, ptr %l2, !tbaa !24
  %t226 = load i64, ptr @G_2ecompiler_2fscope_2eFitElem, !tbaa !24
  %t229 = icmp eq i64 %t225, %t226
  br i1 %t229, label %bb66, label %bb67
bb65:
  %t231 = load %"compiler/msgs:Msg", ptr %l106
  store %"compiler/msgs:Msg" %t231, ptr %l4
  br label %bb97
bb66:
  %t232 = load i1, ptr %l3, !tbaa !21
  br i1 %t232, label %bb68, label %bb69
bb67:
  %t234 = load i64, ptr %l2, !tbaa !24
  %t235 = load i64, ptr @G_2ecompiler_2fscope_2eFitAnyCopy, !tbaa !24
  %t238 = icmp eq i64 %t234, %t235
  br i1 %t238, label %bb73, label %bb74
bb68:
  %t240 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemNotInArrayScope(ptr %s0)
  store %"compiler/msgs:Msg" %t240, ptr %l112
  br label %bb70
bb69:
  %t241 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t241, ptr %l113
  br label %bb71
bb70:
  %t242 = load %"compiler/msgs:Msg", ptr %l112
  store %"compiler/msgs:Msg" %t242, ptr %l111
  br label %bb72
bb71:
  %t243 = load %"compiler/msgs:Msg", ptr %l113
  store %"compiler/msgs:Msg" %t243, ptr %l111
  br label %bb72
bb72:
  %t244 = load %"compiler/msgs:Msg", ptr %l111
  store %"compiler/msgs:Msg" %t244, ptr %l4
  br label %bb96
bb73:
  %t245 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCopyOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t245, ptr %l117
  br label %bb75
bb74:
  %t246 = load i64, ptr %l2, !tbaa !24
  %t247 = load i64, ptr @G_2ecompiler_2fscope_2eFitGlobal, !tbaa !24
  %t250 = icmp eq i64 %t246, %t247
  br i1 %t250, label %bb76, label %bb77
bb75:
  %t252 = load %"compiler/msgs:Msg", ptr %l117
  store %"compiler/msgs:Msg" %t252, ptr %l4
  br label %bb95
bb76:
  %t253 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalHoldsShorter(ptr %s0)
  store %"compiler/msgs:Msg" %t253, ptr %l121
  br label %bb78
bb77:
  %t254 = load i64, ptr %l2, !tbaa !24
  %t255 = load i64, ptr @G_2ecompiler_2fscope_2eFitReturn, !tbaa !24
  %t258 = icmp eq i64 %t254, %t255
  br i1 %t258, label %bb79, label %bb80
bb78:
  %t260 = load %"compiler/msgs:Msg", ptr %l121
  store %"compiler/msgs:Msg" %t260, ptr %l4
  br label %bb94
bb79:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/scope:Scoper", ptr %t261, i32 0, i32 25
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = icmp eq ptr %t264, null
  br i1 %t266, label %bb81, label %bb82
bb80:
  %t268 = load i64, ptr %l2, !tbaa !24
  %t269 = load i64, ptr @G_2ecompiler_2fscope_2eFitValue, !tbaa !24
  %t272 = icmp eq i64 %t268, %t269
  br i1 %t272, label %bb89, label %bb90
bb81:
  call void @__olang_check_failed(ptr @olang_loc_2de0ba6211cb93cf_481b942389356f0b)
  unreachable
bb82:
  br label %bb83
bb83:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/scope:Scoper", ptr %t274, i32 0, i32 25
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t280 = getelementptr %"compiler/typed:Body", ptr %t277, i32 0, i32 14
  %t281 = load i1, ptr %t280, !tbaa !21
  br i1 %t281, label %bb84, label %bb85
bb84:
  %t283 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOwnStorage(ptr %s0)
  store %"compiler/msgs:Msg" %t283, ptr %l133
  br label %bb86
bb85:
  %t284 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnOwnStorage(ptr %s0)
  store %"compiler/msgs:Msg" %t284, ptr %l134
  br label %bb87
bb86:
  %t285 = load %"compiler/msgs:Msg", ptr %l133
  store %"compiler/msgs:Msg" %t285, ptr %l132
  br label %bb88
bb87:
  %t286 = load %"compiler/msgs:Msg", ptr %l134
  store %"compiler/msgs:Msg" %t286, ptr %l132
  br label %bb88
bb88:
  %t287 = load %"compiler/msgs:Msg", ptr %l132
  store %"compiler/msgs:Msg" %t287, ptr %l4
  br label %bb93
bb89:
  %t288 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueRefsOutlived(ptr %s0)
  store %"compiler/msgs:Msg" %t288, ptr %l138
  br label %bb91
bb90:
  br label %bb92
bb91:
  %t289 = load %"compiler/msgs:Msg", ptr %l138
  store %"compiler/msgs:Msg" %t289, ptr %l4
  br label %bb92
bb92:
  br label %bb93
bb93:
  br label %bb94
bb94:
  br label %bb95
bb95:
  br label %bb96
bb96:
  br label %bb97
bb97:
  br label %bb98
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  br label %bb101
bb101:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = load %"compiler/msgs:Msg", ptr %l4
  %t296 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s0, ptr %t290, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %t292)
  store i64 %t296, ptr %l142
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s0)
  %t297 = load i64, ptr %l142, !tbaa !24
  store i64 %t297, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca i64
  %l58 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  br label %bb41
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store i64 %t44, ptr %l26
  br label %bb13
bb13:
  %t45 = load i64, ptr %l26, !tbaa !24
  store i64 %t45, ptr %l7, !tbaa !24
  br label %bb41
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l28, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store i64 %t68, ptr %l36
  br label %bb20
bb20:
  %t69 = load i64, ptr %l36, !tbaa !24
  store i64 %t69, ptr %l7, !tbaa !24
  br label %bb41
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l37, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 2
  store i1 %t77, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l38, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t90 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExprRoot(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  store i64 %t90, ptr %l46
  br label %bb27
bb27:
  %t91 = load i64, ptr %l46, !tbaa !24
  store i64 %t91, ptr %l7, !tbaa !24
  br label %bb41
bb28:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t93 = load ptr, ptr %l47, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l47, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 8}
  %t99 = icmp eq i64 %t97, 6
  store i1 %t99, ptr %l48, !tbaa !21
  br label %bb30
bb30:
  %t100 = load i1, ptr %l48, !tbaa !21
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t112 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExprRoot(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  store i64 %t112, ptr %l56
  br label %bb34
bb34:
  %t113 = load i64, ptr %l56, !tbaa !24
  store i64 %t113, ptr %l7, !tbaa !24
  br label %bb41
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = call i64 @compiler_2fscope_2eflRoot(ptr %v1, ptr %t114)
  store i64 %t116, ptr %l58
  br label %bb39
bb39:
  %t117 = load i64, ptr %l58, !tbaa !24
  store i64 %t117, ptr %l7, !tbaa !24
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_e9ea5d5d3867ce51_dfb99b888a23f285)
  unreachable
bb41:
  %t118 = load i64, ptr %l7, !tbaa !24
  store i64 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efnFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t20 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturesNothing(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %t17)
  store i1 %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load i1, ptr %l12, !tbaa !21
  store i1 %t21, ptr %l3, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7f2f0698823b265a_e0642f9ed23c39f6)
  unreachable
bb12:
  %t22 = load i1, ptr %l3, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforWrap(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l20 = alloca %"compiler/typed:BlockInfo"
  %l24 = alloca i1
  %l36 = alloca i64
  %l39 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca i1
  %l73 = alloca i1
  %l83 = alloca %"compiler/typed:Local"
  %l88 = alloca ptr
  %l89 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_6b4093eaa9dab6e0_ebbf8088c45502d4)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 8
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Block", ptr %t15, i32 0, i32 0
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t23 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t14, i64 %t20)
  store %"compiler/typed:BlockInfo" %t23, ptr %l20
  br label %bb4
bb4:
  %t24 = getelementptr %"compiler/typed:BlockInfo", ptr %l20, i32 0, i32 1
  %t25 = load i32, ptr %t24, !range !{i32 0, i32 9}
  %t27 = trunc i64 1 to i32
  %t28 = icmp eq i32 %t25, %t27
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb7
bb6:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Block", ptr %t32, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t39 = icmp slt i64 %t37, 2
  store i1 %t39, ptr %l24, !tbaa !21
  br label %bb7
bb7:
  %t41 = load i1, ptr %l24, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store i64 0, ptr %l2, !tbaa !24
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Block", ptr %t43, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  store i64 %t48, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb11, label %bb12
bb11:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb16
bb13:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t61 = load i64, ptr %l2, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l4, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l4, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l39, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb15
bb15:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l36, !tbaa !24
  br label %bb16
bb16:
  %t77 = load i64, ptr %l36, !tbaa !24
  store i64 %t77, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb18, label %bb19
bb18:
  br label %bb52
bb19:
  br label %bb20
bb20:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l7, !tbaa !24
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Block", ptr %t96, i32 0, i32 1
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l58, !tbaa !27
  %t100 = load i64, ptr %l7, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr ptr, ptr %t103, i64 %t100
  %t105 = load ptr, ptr %t104, !tbaa !39
  store ptr %t105, ptr %l8, !tbaa !29
  %t107 = load ptr, ptr %l8, !tbaa !29
  store ptr %t107, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t108 = load ptr, ptr %l61, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb21, label %bb22
bb21:
  %t111 = load ptr, ptr %l61, !tbaa !29
  %t112 = load i64, ptr %t111, !range !{i64 0, i64 17}
  %t114 = icmp eq i64 %t112, 0
  store i1 %t114, ptr %l62, !tbaa !21
  br label %bb22
bb22:
  %t115 = load i1, ptr %l62, !tbaa !21
  br i1 %t115, label %bb23, label %bb24
bb23:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t118 = getelementptr { i64, [3 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t118, i32 0, i32 1
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l9, !tbaa !23
  br label %bb25
bb24:
  br label %bb36
bb25:
  %t122 = load i64, ptr %l7, !tbaa !24
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Block", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t130 = sub i64 %t128, 1
  %t133 = icmp eq i64 %t122, %t130
  br i1 %t133, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb32
bb27:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/scope:Scoper", ptr %t135, i32 0, i32 25
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = icmp eq ptr %t138, null
  br i1 %t140, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_a83726b6934b3ff_5f714cf565db93e3)
  unreachable
bb29:
  br label %bb30
bb30:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/scope:Scoper", ptr %t142, i32 0, i32 25
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Body", ptr %t145, i32 0, i32 7
  %t149 = load i32, ptr %l9, !tbaa !23
  %t151 = sext i32 %t149 to i64
  %t154 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t148, i64 %t151)
  store %"compiler/typed:Local" %t154, ptr %l83
  br label %bb31
bb31:
  %t155 = getelementptr %"compiler/typed:Local", ptr %l83, i32 0, i32 4
  %t156 = load i32, ptr %t155, !range !{i32 0, i32 7}
  %t158 = trunc i64 1 to i32
  %t159 = icmp eq i32 %t156, %t158
  %t161 = xor i1 %t159, true
  store i1 %t161, ptr %l73, !tbaa !21
  br label %bb32
bb32:
  %t163 = load i1, ptr %l73, !tbaa !21
  br i1 %t163, label %bb33, label %bb34
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb50
bb36:
  %t165 = load ptr, ptr %l8, !tbaa !29
  store ptr %t165, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t166 = load ptr, ptr %l88, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb37, label %bb38
bb37:
  %t169 = load ptr, ptr %l88, !tbaa !29
  %t170 = load i64, ptr %t169, !range !{i64 0, i64 17}
  %t172 = icmp eq i64 %t170, 4
  store i1 %t172, ptr %l89, !tbaa !21
  br label %bb38
bb38:
  %t173 = load i1, ptr %l89, !tbaa !21
  br i1 %t173, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t174 = load i64, ptr %l7, !tbaa !24
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/typed:Block", ptr %t175, i32 0, i32 1
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t182 = sub i64 %t180, 1
  %t185 = icmp ne i64 %t174, %t182
  br i1 %t185, label %bb42, label %bb43
bb42:
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i1 false, ptr %rv
  br label %ret
bb49:
  call void @__olang_check_failed(ptr @olang_loc_2e96c7acbe66a05d_c52c59876e2a2911)
  unreachable
bb50:
  br label %bb51
bb51:
  %t189 = load i64, ptr %l6, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l6, !tbaa !24
  br label %bb17
bb52:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egap(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3) #0 {
entry:
  %l5 = alloca ptr
  %l11 = alloca %"compiler/scope:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 3
  store ptr %t3, ptr %l5, !tbaa !29
  %t8 = extractvalue { i64, ptr } %a3, 1
  %t9 = extractvalue { i64, ptr } %a3, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  %t23 = call %"compiler/scope:Gap" @compiler_2fscope_3aGap_2ector(ptr %v0, ptr %v0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %t19)
  store %"compiler/scope:Gap" %t23, ptr %l11
  br label %bb1
bb1:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t25 = load %"compiler/scope:Gap", ptr %l11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ePush_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %v0, ptr %t24, %"compiler/scope:Gap" %t25)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBack(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i1
  %l11 = alloca i1
  %l15 = alloca ptr
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 137
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 140
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 60
  %t15 = load i1, ptr %t14, !tbaa !21
  %t17 = xor i1 %t15, true
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l7, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  store i1 %t22, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 142
  store ptr %t27, ptr %l15, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s1, i64 %t28, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t30, ptr %l17
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32, i1 true)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l7 = alloca i64
  %l12 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t7 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v1, ptr %t1, ptr %t2, { i64, [2 x i64] } %a2)
  store i64 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i64, ptr %l7, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Call", ptr %t14, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l12, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackExpr(ptr %v0, ptr %v1, ptr %t13, ptr %t23)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackDerived(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l29 = alloca ptr
  %l38 = alloca i32
  %l40 = alloca %"compiler/typed:Local"
  %l42 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i64
  %l48 = alloca ptr
  %l55 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l56 = alloca i64
  %l57 = alloca i32
  %l60 = alloca i1
  %l63 = alloca i64
  %l66 = alloca i64
  %l68 = alloca ptr
  %l74 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  %t10 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t11 = getelementptr { i64, i64 }, ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb42
bb3:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l11, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 25
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb10
bb6:
  call void @__olang_check_failed(ptr @olang_loc_96b0618960354e24_3d02a19520d5ec20)
  unreachable
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 25
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 5
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l19
  br label %bb9
bb9:
  %t35 = load i64, ptr %l11, !tbaa !24
  %t36 = load i64, ptr %l19, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  store i1 %t37, ptr %l10, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l10, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l21, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l22, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/scope:Scoper", ptr %t42, i32 0, i32 25
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb13, label %bb14
bb12:
  br label %bb23
bb13:
  call void @__olang_check_failed(ptr @olang_loc_96b0618960354e24_3d02a19520d5ec20)
  unreachable
bb14:
  br label %bb15
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 25
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 7
  store ptr %t55, ptr %l29, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/scope:Scoper", ptr %t56, i32 0, i32 25
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  br i1 %t61, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_96b0618960354e24_3d02a19520d5ec20)
  unreachable
bb17:
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 25
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Body", ptr %t66, i32 0, i32 5
  %t70 = load i64, ptr %l2, !tbaa !24
  %t73 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t69, i64 %t70)
  store i32 %t73, ptr %l38
  br label %bb19
bb19:
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = sext i32 %t74 to i64
  %t76 = load ptr, ptr %l29, !tbaa !29
  %t78 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t76, i64 %t75)
  store %"compiler/typed:Local" %t78, ptr %l40
  br label %bb20
bb20:
  %t79 = getelementptr %"compiler/typed:Local", ptr %l40, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t81 = load ptr, ptr %l22, !tbaa !29
  %t83 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %t81, i32 %t80)
  store i64 %t83, ptr %l42
  br label %bb21
bb21:
  %t84 = load ptr, ptr %l21, !tbaa !29
  %t85 = load i64, ptr %l42, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBack(ptr %v0, ptr %t84, i64 %t85)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t88 = icmp sge i64 %t86, 0
  br i1 %t88, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l45, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/scope:Scoper", ptr %t91, i32 0, i32 131
  store ptr %t93, ptr %l48, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/scope:Scoper", ptr %t94, i32 0, i32 26
  %t97 = load i64, ptr %t96, !tbaa !24
  %t99 = mul i64 %t97, 65536
  %t100 = load i64, ptr %l2, !tbaa !24
  %t103 = add i64 %t99, %t100
  %t104 = load i64, ptr %l3, !tbaa !24
  %t107 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t103, i64 %t104)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t107, ptr %l55
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t109 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l55
  %t110 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t108, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t109)
  %t111 = extractvalue { i32, i64 } %t110, 1
  %t112 = extractvalue { i32, i64 } %t110, 0
  store i32 %t112, ptr %l57
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb28, label %ok.114, !prof !99
ok.114:
  store i64 %t111, ptr %l56
  br label %bb27
bb27:
  %t115 = load i64, ptr %l56, !tbaa !24
  store i64 %t115, ptr %l46, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l46, !tbaa !24
  br label %bb30
bb30:
  %t116 = load ptr, ptr %l45, !tbaa !29
  %t117 = load i64, ptr %l46, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBack(ptr %v0, ptr %t116, i64 %t117)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb32:
  %t118 = load i64, ptr %l2, !tbaa !24
  %t120 = icmp slt i64 %t118, 0
  br i1 %t120, label %bb33, label %bb34
bb33:
  %t122 = load i64, ptr %l2, !tbaa !24
  %t124 = sub i64 0, %t122
  %t126 = sub i64 %t124, 1
  store i64 %t126, ptr %l63, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/scope:Scoper", ptr %t127, i32 0, i32 89
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t129)
  store i64 %t131, ptr %l66
  br label %bb35
bb34:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb36
bb35:
  %t132 = load i64, ptr %l63, !tbaa !24
  %t133 = load i64, ptr %l66, !tbaa !24
  %t134 = icmp slt i64 %t132, %t133
  store i1 %t134, ptr %l60, !tbaa !21
  br label %bb36
bb36:
  %t136 = load i1, ptr %l60, !tbaa !21
  br i1 %t136, label %bb37, label %bb38
bb37:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l68, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/scope:Scoper", ptr %t138, i32 0, i32 89
  %t141 = load i64, ptr %l2, !tbaa !24
  %t143 = sub i64 0, %t141
  %t145 = sub i64 %t143, 1
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t140, i64 %t145)
  store i64 %t148, ptr %l74
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t149 = load ptr, ptr %l68, !tbaa !29
  %t150 = load i64, ptr %l74, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBack(ptr %v0, ptr %t149, i64 %t150)
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_1224d6df3464748a_e87c09d967c04386)
  unreachable
bb47:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 137
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 140
  %t11 = load i1, ptr %t10, !tbaa !21
  %t13 = xor i1 %t11, true
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l7, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t16, ptr %a1)
  store ptr %t21, ptr %l14
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t22)
  store ptr %t23, ptr %l15
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 18}
  %t32 = icmp eq i64 %t30, 2
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb17
bb12:
  %t40 = load ptr, ptr %l2, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 18}
  %t47 = icmp eq i64 %t45, 3
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l23, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackPlace(ptr %v0, ptr %s0, ptr %t55, ptr %t56)
  br label %bb18
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_fe279d5820b85dad_458b53b3da9c6ff1)
  unreachable
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 137
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 140
  %t11 = load i1, ptr %t10, !tbaa !21
  %t13 = xor i1 %t11, true
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l9, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 3
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t33)
  store i32 %t35, ptr %l22
  br label %bb12
bb12:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = load i32, ptr %l22, !tbaa !23
  %t38 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %t36, i32 %t37)
  store i64 %t38, ptr %l23
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l19, !tbaa !29
  %t40 = load i64, ptr %l23, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBack(ptr %v0, ptr %t39, i64 %t40)
  br label %bb14
bb14:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackPlace(ptr %v0, ptr %v1, ptr %t41, ptr %t42)
  br label %bb15
bb15:
  br label %bb42
bb16:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t46 = load ptr, ptr %l26, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t53 = load i1, ptr %l27, !tbaa !21
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l3, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Elem", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackPlace(ptr %v0, ptr %v1, ptr %t60, ptr %t64)
  br label %bb22
bb22:
  br label %bb42
bb23:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t68 = load ptr, ptr %l35, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb24, label %bb25
bb24:
  %t71 = load ptr, ptr %l35, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 8}
  %t74 = icmp eq i64 %t72, 5
  store i1 %t74, ptr %l36, !tbaa !21
  br label %bb25
bb25:
  %t75 = load i1, ptr %l36, !tbaa !21
  br i1 %t75, label %bb26, label %bb27
bb26:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l4, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l4, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Payload", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackPlace(ptr %v0, ptr %v1, ptr %t82, ptr %t86)
  br label %bb29
bb29:
  br label %bb42
bb30:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t90 = load ptr, ptr %l44, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb31, label %bb32
bb31:
  %t93 = load ptr, ptr %l44, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 2
  store i1 %t96, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t97 = load i1, ptr %l45, !tbaa !21
  br i1 %t97, label %bb33, label %bb34
bb33:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l5, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackExpr(ptr %v0, ptr %v1, ptr %t104, ptr %t105)
  br label %bb36
bb36:
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_6ed8db51a3dfced1_45a76436772cba65)
  unreachable
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l9 = alloca i1
  %l15 = alloca { i64, [2 x i64] }
  %l16 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisParam(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/scope:Scoper", ptr %t7, i32 0, i32 33
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t13, ptr %l9
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t14 = load i1, ptr %l9, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 32
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t21, i64 %t22)
  store { i64, [2 x i64] } %t25, ptr %l15
  br label %bb9
bb9:
  %t26 = load { i64, [2 x i64] }, ptr %l15
  %t27 = call i1 @compiler_2fscope_2etermGiven({ i64, [2 x i64] } %t26)
  store i1 %t27, ptr %l16
  br label %bb10
bb10:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l59 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t19 = sext i32 %t17 to i64
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenLocal(ptr %v0, ptr %t16, i64 %t19)
  store i1 %t22, ptr %l17
  br label %bb6
bb6:
  %t23 = load i1, ptr %l17, !tbaa !21
  store i1 %t23, ptr %l7, !tbaa !21
  br label %bb46
bb7:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t25 = load ptr, ptr %l18, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l18, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 8}
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb46
bb13:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb14, label %bb15
bb14:
  %t37 = load ptr, ptr %l22, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 8}
  %t40 = icmp eq i64 %t38, 3
  store i1 %t40, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t41 = load i1, ptr %l23, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t52 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenPlace(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store i1 %t52, ptr %l30
  br label %bb19
bb19:
  %t53 = load i1, ptr %l30, !tbaa !21
  store i1 %t53, ptr %l7, !tbaa !21
  br label %bb46
bb20:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb21, label %bb22
bb21:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 8}
  %t61 = icmp eq i64 %t59, 4
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb23, label %bb24
bb23:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Elem", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t76 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenPlace(ptr %v0, ptr %v1, ptr %t69, ptr %t73)
  store i1 %t76, ptr %l40
  br label %bb26
bb26:
  %t77 = load i1, ptr %l40, !tbaa !21
  store i1 %t77, ptr %l7, !tbaa !21
  br label %bb46
bb27:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t79 = load ptr, ptr %l41, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb28, label %bb29
bb28:
  %t82 = load ptr, ptr %l41, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l42, !tbaa !21
  br label %bb29
bb29:
  %t86 = load i1, ptr %l42, !tbaa !21
  br i1 %t86, label %bb30, label %bb31
bb30:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l5, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Payload", ptr %t94, i32 0, i32 0
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t100 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenPlace(ptr %v0, ptr %v1, ptr %t93, ptr %t97)
  store i1 %t100, ptr %l50
  br label %bb33
bb33:
  %t101 = load i1, ptr %l50, !tbaa !21
  store i1 %t101, ptr %l7, !tbaa !21
  br label %bb46
bb34:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb35, label %bb36
bb35:
  %t106 = load ptr, ptr %l51, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 8}
  %t109 = icmp eq i64 %t107, 2
  store i1 %t109, ptr %l52, !tbaa !21
  br label %bb36
bb36:
  %t110 = load i1, ptr %l52, !tbaa !21
  br i1 %t110, label %bb37, label %bb38
bb37:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l6, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t121 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenRef(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  store i1 %t121, ptr %l59
  br label %bb40
bb40:
  %t122 = load i1, ptr %l59, !tbaa !21
  store i1 %t122, ptr %l7, !tbaa !21
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_d375f47869e73b1e_ab7f910edbf0dc32)
  unreachable
bb46:
  %t123 = load i1, ptr %l7, !tbaa !21
  store i1 %t123, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandedOn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call i1 @compiler_2fscope_2eisParamRead(ptr %v1, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i1, ptr %l8, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i64 1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l1, !tbaa !29
  store ptr %t8, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 3
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb14
bb9:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = call i64 @compiler_2fscope_2eownField(ptr %v1, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l18
  br label %bb10
bb10:
  %t28 = load i64, ptr %l18, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  br i1 %t29, label %bb11, label %bb12
bb11:
  store i64 2, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb40
bb14:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb15, label %bb16
bb15:
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 18}
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb17, label %bb18
bb17:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb35
bb19:
  %t47 = load ptr, ptr %l4, !tbaa !29
  store ptr %t47, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t48 = load ptr, ptr %l27, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb20, label %bb21
bb20:
  %t51 = load ptr, ptr %l27, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 8}
  %t54 = icmp eq i64 %t52, 2
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb21
bb21:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l5, !tbaa !29
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = call i1 @compiler_2fscope_2eisParamRead(ptr %v1, ptr %t62, i64 %t63)
  store i1 %t66, ptr %l35
  br label %bb25
bb25:
  %t67 = load i1, ptr %l35, !tbaa !21
  br i1 %t67, label %bb26, label %bb27
bb26:
  store i64 3, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_9c7ebd2b12e06561_d1b788b185a2a0b5)
  unreachable
bb34:
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_e6e67a80e175cfd0_914d29e7454711c4)
  unreachable
bb40:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandedRegion(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca i64
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l3, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_9d00f6934855daa_c9673762d5df43fe)
  unreachable
bb16:
  br label %bb43
bb17:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t36 = load ptr, ptr %l21, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb18, label %bb19
bb18:
  %t39 = load ptr, ptr %l21, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 3
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb19
bb19:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb20, label %bb21
bb20:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = call i64 @compiler_2fscope_2eregionRoot(ptr %v1, ptr %t50)
  store i64 %t52, ptr %l28
  br label %bb23
bb23:
  %t53 = load i64, ptr %l28, !tbaa !24
  store i64 %t53, ptr %rv
  br label %ret
bb24:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb25, label %bb26
bb25:
  %t58 = load ptr, ptr %l29, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 10
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb26
bb26:
  %t62 = load i1, ptr %l30, !tbaa !21
  br i1 %t62, label %bb27, label %bb28
bb27:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Slice", ptr %t69, i32 0, i32 0
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = call i64 @compiler_2fscope_2eregionRoot(ptr %v1, ptr %t72)
  store i64 %t74, ptr %l37
  br label %bb30
bb30:
  %t75 = load i64, ptr %l37, !tbaa !24
  store i64 %t75, ptr %rv
  br label %ret
bb31:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t77 = load ptr, ptr %l38, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb32, label %bb33
bb32:
  %t80 = load ptr, ptr %l38, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 18}
  %t83 = icmp eq i64 %t81, 17
  store i1 %t83, ptr %l39, !tbaa !21
  br label %bb33
bb33:
  %t84 = load i1, ptr %l39, !tbaa !21
  br i1 %t84, label %bb34, label %bb35
bb34:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t95 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandedRegion(ptr %v0, ptr %v1, ptr %a0, ptr %t92)
  store i64 %t95, ptr %l46
  br label %bb37
bb37:
  %t96 = load i64, ptr %l46, !tbaa !24
  store i64 %t96, ptr %rv
  br label %ret
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_6f89170392198c6b_c18aa73f993179ff)
  unreachable
bb43:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t6, i32 %a1)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i1
  %l47 = alloca i1
  %l49 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb32
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 1
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l19
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 1
  %t33 = load { i64, [2 x i64] }, ptr %t32
  store { i64, [2 x i64] } %t33, ptr %l4
  %t35 = load { i64, [2 x i64] }, ptr %l4
  %t37 = extractvalue { i64, [2 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 0
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t41 = getelementptr { i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l5, !tbaa !24
  br label %bb9
bb8:
  br label %bb26
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l28, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l30, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l34
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l30, !tbaa !29
  %t67 = load i64, ptr %l34, !tbaa !24
  %t68 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t66, i64 %t67)
  store ptr %t68, ptr %l35
  br label %bb11
bb11:
  %t69 = load ptr, ptr %l35, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Func", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  %t73 = load ptr, ptr %l28, !tbaa !29
  %t75 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t73, i32 %t72)
  store { i64, ptr } %t75, ptr %l38
  br label %bb12
bb12:
  %t76 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t76, ptr %l6, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t77, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t79, ptr %l40
  br label %bb13
bb13:
  %t80 = load i1, ptr %l40, !tbaa !21
  br i1 %t80, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb17
bb15:
  %t81 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t81, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t83, ptr %l43
  br label %bb16
bb16:
  %t84 = load i1, ptr %l43, !tbaa !21
  store i1 %t84, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t85 = load i1, ptr %l41, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb21
bb19:
  %t86 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t86, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t88, ptr %l46
  br label %bb20
bb20:
  %t89 = load i1, ptr %l46, !tbaa !21
  store i1 %t89, ptr %l44, !tbaa !21
  br label %bb21
bb21:
  %t90 = load i1, ptr %l44, !tbaa !21
  br i1 %t90, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb25
bb23:
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t91, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t93, ptr %l49
  br label %bb24
bb24:
  %t94 = load i1, ptr %l49, !tbaa !21
  store i1 %t94, ptr %l47, !tbaa !21
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  %t95 = load i1, ptr %l47, !tbaa !21
  store i1 %t95, ptr %rv
  br label %ret
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_2d8599dd2a60d272_f2da26d46793a2d6)
  unreachable
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_8dedfa134432c6f3_d3b15d93042206f7)
  unreachable
bb37:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einferClaims(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 123
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 124
  store i1 false, ptr %t6, !tbaa !21
  %t7 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudge(ptr %v0, ptr %t7, i64 %a1, i1 false)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 123
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 124
  %t17 = load i1, ptr %t16, !tbaa !21
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstContexts(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/generic:Origin"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/generic:Origin"
  %l19 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l33 = alloca i64
  %l53 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l64 = alloca %"compiler/generic:Origin"
  %l77 = alloca i64
  %l81 = alloca i64
  %l84 = alloca i64
  %l102 = alloca ptr
  %l104 = alloca i64
  %l108 = alloca %"compiler/generic:Origin"
  %l109 = alloca ptr
  %l111 = alloca i64
  %l115 = alloca i64
  %l120 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l140 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i64
  %t241 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l24
  br label %bb4
bb4:
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l2
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l25
  br label %bb5
bb5:
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l3
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 32, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb11
bb8:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l33, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb10
bb10:
  %t38 = load i64, ptr %l33, !tbaa !24
  store i64 %t38, ptr %l30, !tbaa !24
  br label %bb11
bb11:
  %t39 = load i64, ptr %l30, !tbaa !24
  store i64 %t39, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb14:
  br label %bb15
bb15:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  store ptr %t63, ptr %l53, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/scope:Scoper", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t67, i64 %t68)
  store i32 %t71, ptr %l57
  br label %bb16
bb16:
  %t72 = load ptr, ptr %l53, !tbaa !29
  %t73 = load i32, ptr %l57, !tbaa !23
  %t74 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s3, ptr %t72, i32 %t73)
  store { i64, ptr } %t74, ptr %l58
  br label %bb17
bb17:
  %t75 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  %t78 = icmp eq i64 %t76, 0
  br i1 %t78, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb19:
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/scope:Scoper", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t84 = load i64, ptr %l4, !tbaa !24
  %t87 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t83, i64 %t84)
  store %"compiler/generic:Origin" %t87, ptr %l64
  br label %bb21
bb21:
  %t88 = load %"compiler/generic:Origin", ptr %l64
  store %"compiler/generic:Origin" %t88, ptr %l11
  %t89 = getelementptr %"compiler/generic:Origin", ptr %l11, i32 0, i32 0
  %t90 = load i64, ptr %t89, !tbaa !24
  %t92 = icmp slt i64 %t90, 0
  br i1 %t92, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t94 = load %"compiler/generic:Origin", ptr %l11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2ePush_3ccompiler_2fgeneric_3aOrigin_3e(ptr %s0, ptr %l2, %"compiler/generic:Origin" %t94)
  br label %bb25
bb25:
  %t97 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t97)
  br label %bb26
bb26:
  %t100 = getelementptr %"compiler/generic:Origin", ptr %l11, i32 0, i32 2
  %t101 = load i64, ptr %t100, !tbaa !24
  %t103 = icmp slt i64 %t101, 0
  br i1 %t103, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb28:
  br label %bb29
bb29:
  %t105 = getelementptr %"compiler/generic:Origin", ptr %l11, i32 0, i32 2
  %t106 = load i64, ptr %t105, !tbaa !24
  store i64 %t106, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t108 = load i64, ptr %l9, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l9, !tbaa !24
  br label %bb12
bb31:
  store i64 0, ptr %l12, !tbaa !24
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eLen_3ccompiler_2fgeneric_3aOrigin_3e(ptr %s0, ptr %l2)
  store i64 %t113, ptr %l77
  br label %bb32
bb32:
  %t114 = load i64, ptr %l77, !tbaa !24
  store i64 %t114, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb33, label %bb34
bb33:
  %t121 = load i64, ptr %l14, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb38
bb35:
  %t125 = load i64, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l14, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l84, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb37
bb37:
  %t141 = load i64, ptr %l84, !tbaa !24
  store i64 %t141, ptr %l81, !tbaa !24
  br label %bb38
bb38:
  %t142 = load i64, ptr %l81, !tbaa !24
  store i64 %t142, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s9
  %t143 = load i64, ptr %l16, !tbaa !24
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb41:
  br label %bb42
bb42:
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l16, !tbaa !24
  %t153 = load i64, ptr %l14, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l17, !tbaa !24
  store ptr %l2, ptr %l102, !tbaa !29
  %t162 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eLen_3ccompiler_2fgeneric_3aOrigin_3e(ptr %s0, ptr %l2)
  store i64 %t162, ptr %l104
  br label %bb43
bb43:
  %t163 = load i64, ptr %l104, !tbaa !24
  %t164 = sub i64 %t163, 1
  %t165 = load i64, ptr %l17, !tbaa !24
  %t168 = sub i64 %t164, %t165
  %t169 = load ptr, ptr %l102, !tbaa !29
  %t171 = call %"compiler/generic:Origin" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eAt_3ccompiler_2fgeneric_3aOrigin_3e(ptr %s0, ptr %t169, i64 %t168)
  store %"compiler/generic:Origin" %t171, ptr %l108
  br label %bb44
bb44:
  %t172 = load %"compiler/generic:Origin", ptr %l108
  store %"compiler/generic:Origin" %t172, ptr %l18
  store ptr %l3, ptr %l109, !tbaa !29
  %t174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eLen_3ccompiler_2fgeneric_3aOrigin_3e(ptr %s0, ptr %l2)
  store i64 %t174, ptr %l111
  br label %bb45
bb45:
  %t175 = load i64, ptr %l111, !tbaa !24
  %t176 = sub i64 %t175, 1
  %t177 = load i64, ptr %l17, !tbaa !24
  %t180 = sub i64 %t176, %t177
  %t181 = load ptr, ptr %l109, !tbaa !29
  %t183 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t181, i64 %t180)
  store i64 %t183, ptr %l115
  br label %bb46
bb46:
  %t184 = load i64, ptr %l115, !tbaa !24
  store i64 %t184, ptr %l19, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/scope:Scoper", ptr %t185, i32 0, i32 4
  %t188 = load { ptr, ptr }, ptr %t187
  %t190 = extractvalue { ptr, ptr } %t188, 0
  %t191 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t192 = icmp eq ptr %t190, %t191
  %t193 = extractvalue { ptr, ptr } %t188, 1
  %t194 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t195 = icmp eq ptr %t193, %t194
  %t196 = and i1 %t192, %t195
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb47, label %bb48
bb47:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/scope:Scoper", ptr %t200, i32 0, i32 4
  %t203 = load { ptr, ptr }, ptr %t202
  %t204 = load i64, ptr %l19, !tbaa !24
  %t206 = extractvalue { ptr, ptr } %t203, 0
  %t207 = extractvalue { ptr, ptr } %t203, 1
  %t209 = call { i64, ptr } %t206(ptr %t207, ptr %s9, i64 %t204)
  store { i64, ptr } %t209, ptr %l124
  br label %bb49
bb48:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l120, !tbaa !27
  br label %bb50
bb49:
  %t210 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  store { i64, ptr } %t216, ptr %l120, !tbaa !27
  br label %bb50
bb50:
  %t218 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/scope:Scoper", ptr %t219, i32 0, i32 0
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Program", ptr %t222, i32 0, i32 0
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/load:Loader", ptr %t225, i32 0, i32 4
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Origin", ptr %l18, i32 0, i32 0
  %t230 = load i64, ptr %t229, !tbaa !24
  %t231 = getelementptr %"compiler/generic:Origin", ptr %l18, i32 0, i32 1
  %t232 = getelementptr %"compiler/source:Span", ptr %t231, i32 0, i32 0
  %t233 = load i32, ptr %t232, !tbaa !23
  %t235 = sext i32 %t233 to i64
  %t236 = getelementptr %"compiler/generic:Origin", ptr %l18, i32 0, i32 1
  %t237 = getelementptr %"compiler/source:Span", ptr %t236, i32 0, i32 1
  %t238 = load i32, ptr %t237, !tbaa !23
  %t240 = sext i32 %t238 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t241
  %t242 = getelementptr { i64, [3 x i64] }, ptr %t241, i32 0, i32 0
  store i64 3, ptr %t242
  %t244 = insertvalue { i64, i64, i64 } undef, i64 %t230, 0
  %t246 = insertvalue { i64, i64, i64 } %t244, i64 %t235, 1
  %t248 = insertvalue { i64, i64, i64 } %t246, i64 %t240, 2
  %t249 = getelementptr { i64, [3 x i64] }, ptr %t241, i32 0, i32 1
  store { i64, i64, i64 } %t248, ptr %t249
  %t250 = load { i64, [3 x i64] }, ptr %t241
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %s9, ptr %t228, { i64, [3 x i64] } %t250, { i64, ptr } %t218)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb52:
  %t255 = load i64, ptr %l16, !tbaa !24
  %t257 = add i64 %t255, 1
  store i64 %t257, ptr %l16, !tbaa !24
  br label %bb39
bb53:
  %t260 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eLen_3ccompiler_2fgeneric_3aOrigin_3e(ptr %s0, ptr %l2)
  store i64 %t260, ptr %l140
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t261 = load i64, ptr %l140, !tbaa !24
  store i64 %t261, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceArgs(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l11 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t20, i64 %t21)
  store i32 %t24, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t25 = load ptr, ptr %l11, !tbaa !29
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t25, i32 %t26)
  store { i64, ptr } %t27, ptr %l16
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t31 = icmp sgt i64 %t29, 0
  store i1 %t31, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i1, ptr %l8, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisAdapter(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 3}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_a5122b0b395bd8b_9870aa37c8b5f2ef)
  unreachable
bb16:
  br label %bb29
bb17:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb18, label %bb19
bb18:
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 18}
  %t33 = icmp eq i64 %t31, 17
  store i1 %t33, ptr %l16, !tbaa !21
  br label %bb19
bb19:
  %t34 = load i1, ptr %l16, !tbaa !21
  br i1 %t34, label %bb20, label %bb21
bb20:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t45 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisAdapter(ptr %v0, ptr %v1, ptr %a0, ptr %t42)
  store i1 %t45, ptr %l23
  br label %bb23
bb23:
  %t46 = load i1, ptr %l23, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_51a7ef38ab67534a_42b12633f9b5762e)
  unreachable
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisBlock(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [2 x i64] } %a1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_2d0145e0fa45a88d_adbbe2dcd866b269)
  unreachable
bb9:
  %t6 = load i1, ptr %l2, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisCtor(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d38420f770b56a25_293628bae4d10df9)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 1
  %t15 = load { i64, [2 x i64] }, ptr %t14
  %t19 = extractvalue { i64, [2 x i64] } %t15, 0
  %t20 = icmp eq i64 %t19, 1
  br i1 %t20, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7d2ed71f654b640d_ba09ac545853f0c1)
  unreachable
bb12:
  %t22 = load i1, ptr %l9, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %a0, i32 %t17)
  store i1 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_4d20f13e93e5e00_8edf44d94b0465ac)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisParamVar(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [1 x i64] } %a1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_f39b1bd504b33948_8115a077853ab66c)
  unreachable
bb9:
  %t6 = load i1, ptr %l2, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eitemKind(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 5}
  %t3 = trunc i64 1 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load i64, ptr @G_2ecompiler_2fscope_2eFitPayload, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb15
bb4:
  %t8 = load i32, ptr %l1, !range !{i32 0, i32 5}
  %t10 = trunc i64 2 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t13 = load i32, ptr %l1, !range !{i32 0, i32 5}
  %t15 = trunc i64 3 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t18 = load i64, ptr @G_2ecompiler_2fscope_2eFitElem, !tbaa !24
  store i64 %t18, ptr %l2, !tbaa !24
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t20 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  store i64 %t20, ptr %l2, !tbaa !24
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_6eab74aa3e0b63d9_475cda0f5b688a85)
  unreachable
bb15:
  %t22 = load i64, ptr %l2, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudge(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:Local"
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca %"compiler/scope:rel"
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l48 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca i64
  %l61 = alloca %"compiler/typed:Local"
  %l68 = alloca i1
  %l73 = alloca i1
  %l76 = alloca i1
  %l141 = alloca i1
  %l144 = alloca i1
  %l148 = alloca ptr
  %l153 = alloca i64
  %l160 = alloca ptr
  %l162 = alloca %"compiler/typed:Plan"
  %l177 = alloca i1
  %l180 = alloca i64
  %l184 = alloca i64
  %l187 = alloca i64
  %l225 = alloca { i64, [1 x i64] }
  %l231 = alloca i64
  %l233 = alloca i1
  %l234 = alloca i32
  %l237 = alloca i32
  %l260 = alloca ptr
  %l265 = alloca i64
  %l266 = alloca i64
  %l267 = alloca ptr
  %l270 = alloca i64
  %l271 = alloca i64
  %l272 = alloca ptr
  %l273 = alloca %"compiler/source:Span"
  %l274 = alloca ptr
  %l275 = alloca %"compiler/source:Span"
  %l278 = alloca i1
  %l282 = alloca i1
  %l286 = alloca i1
  %l290 = alloca ptr
  %l292 = alloca %"compiler/source:Span"
  %l293 = alloca %"compiler/msgs:Msg"
  %l294 = alloca i64
  %l295 = alloca ptr
  %l296 = alloca i64
  %l298 = alloca i64
  %l300 = alloca %"compiler/source:Span"
  %l301 = alloca %"compiler/msgs:Msg"
  %l307 = alloca i64
  %l310 = alloca i64
  %l339 = alloca i64
  %l342 = alloca i64
  %l344 = alloca i64
  %l349 = alloca %"compiler/scope:rel"
  %l353 = alloca ptr
  %l362 = alloca ptr
  %l371 = alloca i64
  %l373 = alloca i64
  %l378 = alloca { i64, [2 x i64] }
  %l394 = alloca i64
  %l398 = alloca i64
  %l401 = alloca i64
  %l420 = alloca ptr
  %l424 = alloca i1
  %l426 = alloca ptr
  %l430 = alloca i1
  %l432 = alloca ptr
  %l436 = alloca i64
  %l438 = alloca ptr
  %l442 = alloca %"compiler/source:Span"
  %l449 = alloca i64
  %l453 = alloca i64
  %l456 = alloca i64
  %l480 = alloca { i64, ptr }
  %l481 = alloca i64
  %l485 = alloca i1
  %l490 = alloca ptr
  %l491 = alloca i64
  %l493 = alloca %"compiler/typed:Plan"
  %l495 = alloca %"compiler/typed:Plan"
  %s0 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %t236 = alloca { i64, [2 x i64] }, align 8
  %t249 = alloca %"compiler/typed:Plan", align 8
  %t932 = alloca %"compiler/typed:Plan", align 8
  %t936 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l48
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l48, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 7
  store ptr %t18, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  store i64 %t20, ptr %l54, !tbaa !24
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l56
  br label %bb6
bb6:
  %t24 = load i64, ptr %l54, !tbaa !24
  %t25 = load i64, ptr %l56, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t30, i64 %t31)
  store %"compiler/typed:Local" %t34, ptr %l61
  br label %bb10
bb10:
  %t35 = load %"compiler/typed:Local", ptr %l61
  store %"compiler/typed:Local" %t35, ptr %l6
  %t36 = getelementptr %"compiler/typed:Local", ptr %l6, i32 0, i32 2
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t41 = icmp eq i32 %t37, %t38
  br i1 %t41, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l5, !tbaa !24
  br label %bb5
bb15:
  %t47 = load i1, ptr %l2, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 48
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = icmp ne i64 %t52, %t53
  store i1 %t56, ptr %l68, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l68, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i64, ptr %l1, !tbaa !24
  %t63 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehasLateLocals(ptr %v0, ptr %t59, i64 %t60)
  store i1 %t63, ptr %l76
  br label %bb21
bb20:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb22
bb21:
  %t64 = load i1, ptr %l76, !tbaa !21
  store i1 %t64, ptr %l73, !tbaa !21
  br label %bb22
bb22:
  %t65 = load i1, ptr %l73, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 48
  store i64 %t67, ptr %t70, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/scope:Scoper", ptr %t71, i32 0, i32 50
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H075aca2c24d2905e4fa457b6b6d6570e(ptr %v0, ptr %t73)
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/scope:Scoper", ptr %t75, i32 0, i32 51
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t77)
  br label %bb26
bb26:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/scope:Scoper", ptr %t79, i32 0, i32 52
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t81)
  br label %bb27
bb27:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 49
  store i1 true, ptr %t85, !tbaa !21
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudge(ptr %v0, ptr %t86, i64 %t87, i1 false)
  br label %bb28
bb28:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/scope:Scoper", ptr %t90, i32 0, i32 49
  store i1 false, ptr %t92, !tbaa !21
  br label %bb29
bb29:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/scope:Scoper", ptr %t93, i32 0, i32 11
  %t96 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t95, i64 %t96, i1 true)
  br label %bb30
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t104 = getelementptr %"compiler/scope:Scoper", ptr %t99, i32 0, i32 25
  store ptr %t100, ptr %t104, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i64, ptr %l1, !tbaa !24
  %t109 = getelementptr %"compiler/scope:Scoper", ptr %t105, i32 0, i32 26
  store i64 %t106, ptr %t109, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t112)
  br label %bb31
bb31:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t116)
  br label %bb32
bb32:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/scope:Scoper", ptr %t118, i32 0, i32 132
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t120)
  br label %bb33
bb33:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/scope:Scoper", ptr %t122, i32 0, i32 133
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t124)
  br label %bb34
bb34:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/scope:Scoper", ptr %t126, i32 0, i32 33
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t128)
  br label %bb35
bb35:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/scope:Scoper", ptr %t130, i32 0, i32 34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t132)
  br label %bb36
bb36:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/scope:Scoper", ptr %t134, i32 0, i32 72
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t136)
  br label %bb37
bb37:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/scope:Scoper", ptr %t138, i32 0, i32 35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eClear_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t140)
  br label %bb38
bb38:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/scope:Scoper", ptr %t142, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t144)
  br label %bb39
bb39:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/scope:Scoper", ptr %t146, i32 0, i32 37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t148)
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/scope:Scoper", ptr %t150, i32 0, i32 40
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %t152)
  br label %bb41
bb41:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/scope:Scoper", ptr %t154, i32 0, i32 41
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %t156)
  br label %bb42
bb42:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/scope:Scoper", ptr %t158, i32 0, i32 42
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %t160)
  br label %bb43
bb43:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/scope:Scoper", ptr %t162, i32 0, i32 43
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t164)
  br label %bb44
bb44:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/scope:Scoper", ptr %t166, i32 0, i32 44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t168)
  br label %bb45
bb45:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/scope:Scoper", ptr %t170, i32 0, i32 45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t172)
  br label %bb46
bb46:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %t174, i32 0, i32 46
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t176)
  br label %bb47
bb47:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/scope:Scoper", ptr %t178, i32 0, i32 53
  store i64 -1, ptr %t180, !tbaa !24
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/scope:Scoper", ptr %t181, i32 0, i32 55
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t183)
  br label %bb48
bb48:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/scope:Scoper", ptr %t185, i32 0, i32 56
  store i1 false, ptr %t187, !tbaa !21
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/scope:Scoper", ptr %t188, i32 0, i32 57
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eClea_Hf36a88772899b36a46c039ef55a38999(ptr %v0, ptr %t190)
  br label %bb49
bb49:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/scope:Scoper", ptr %t192, i32 0, i32 39
  store i64 -1, ptr %t194, !tbaa !24
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/scope:Scoper", ptr %t195, i32 0, i32 65
  store i64 -1, ptr %t197, !tbaa !24
  %t198 = load ptr, ptr %l3, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Body", ptr %t198, i32 0, i32 14
  %t201 = load i1, ptr %t200, !tbaa !21
  br i1 %t201, label %bb50, label %bb51
bb50:
  %t203 = load ptr, ptr %l3, !tbaa !29
  %t205 = getelementptr %"compiler/typed:Body", ptr %t203, i32 0, i32 16
  %t206 = load i1, ptr %t205, !tbaa !21
  store i1 %t206, ptr %l141, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb52
bb52:
  %t208 = load i1, ptr %l141, !tbaa !21
  br i1 %t208, label %bb53, label %bb54
bb53:
  %t209 = load ptr, ptr %l3, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Body", ptr %t209, i32 0, i32 15
  %t212 = load i32, ptr %t211, !tbaa !23
  %t214 = icmp sge i32 %t212, 0
  store i1 %t214, ptr %l144, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb55
bb55:
  %t216 = load i1, ptr %l144, !tbaa !21
  br i1 %t216, label %bb56, label %bb57
bb56:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l148, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load i64, ptr %l1, !tbaa !24
  %t220 = load ptr, ptr %l3, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Body", ptr %t220, i32 0, i32 15
  %t223 = load i32, ptr %t222, !tbaa !23
  %t227 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecaptureVar(ptr %v0, ptr %t218, i64 %t219, i32 %t223)
  store i64 %t227, ptr %l153
  br label %bb58
bb57:
  br label %bb59
bb58:
  %t228 = load i64, ptr %l153, !tbaa !24
  %t229 = load ptr, ptr %l148, !tbaa !29
  %t230 = getelementptr %"compiler/scope:Scoper", ptr %t229, i32 0, i32 65
  store i64 %t228, ptr %t230, !tbaa !24
  br label %bb59
bb59:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/scope:Scoper", ptr %t231, i32 0, i32 66
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %t233)
  br label %bb60
bb60:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t236
  %t237 = getelementptr { i64, [2 x i64] }, ptr %t236, i32 0, i32 0
  store i64 0, ptr %t237
  %t238 = load { i64, [2 x i64] }, ptr %t236
  %t241 = getelementptr %"compiler/scope:Scoper", ptr %t235, i32 0, i32 67
  store { i64, [2 x i64] } %t238, ptr %t241
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i1, ptr %l2, !tbaa !21
  %t246 = getelementptr %"compiler/scope:Scoper", ptr %t242, i32 0, i32 27
  store i1 %t243, ptr %t246, !tbaa !21
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l160, !tbaa !29
  %t248 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2eNewPlan(ptr %t249, ptr %v0, ptr %v0, ptr %t248)
  call void @llvm.memmove.p0.p0.i64(ptr %l162, ptr %t249, i64 176, i1 false)
  br label %bb61
bb61:
  %t251 = load ptr, ptr %l160, !tbaa !29
  %t252 = getelementptr %"compiler/scope:Scoper", ptr %t251, i32 0, i32 30
  call void @llvm.memmove.p0.p0.i64(ptr %t252, ptr %l162, i64 176, i1 false)
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/scope:Scoper", ptr %t253, i32 0, i32 58
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t255)
  br label %bb62
bb62:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/scope:Scoper", ptr %t257, i32 0, i32 59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t259)
  br label %bb63
bb63:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/scope:Scoper", ptr %t261, i32 0, i32 61
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t263)
  br label %bb64
bb64:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/scope:Scoper", ptr %t265, i32 0, i32 62
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t267)
  br label %bb65
bb65:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/scope:Scoper", ptr %t269, i32 0, i32 63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t271)
  br label %bb66
bb66:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/scope:Scoper", ptr %t273, i32 0, i32 64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t275)
  br label %bb67
bb67:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %l3, !tbaa !29
  %t281 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStr(ptr %v0, ptr %v0, ptr %t277, ptr %t278)
  store i1 %t281, ptr %l177
  br label %bb68
bb68:
  %t282 = load i1, ptr %l177, !tbaa !21
  store i1 %t282, ptr %l7, !tbaa !21
  store i64 0, ptr %l8, !tbaa !24
  %t283 = load ptr, ptr %l3, !tbaa !29
  %t285 = getelementptr %"compiler/typed:Body", ptr %t283, i32 0, i32 6
  %t287 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t285)
  store i64 %t287, ptr %l180
  br label %bb69
bb69:
  %t288 = load i64, ptr %l180, !tbaa !24
  store i64 %t288, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t289 = load i64, ptr %l9, !tbaa !24
  %t290 = load i64, ptr %l8, !tbaa !24
  %t293 = icmp sgt i64 %t289, %t290
  br i1 %t293, label %bb70, label %bb71
bb70:
  %t295 = load i64, ptr %l10, !tbaa !24
  %t297 = icmp sgt i64 %t295, 0
  br i1 %t297, label %bb72, label %bb73
bb71:
  store i64 0, ptr %l184, !tbaa !24
  br label %bb75
bb72:
  %t299 = load i64, ptr %l9, !tbaa !24
  %t300 = load i64, ptr %l8, !tbaa !24
  %t303 = sub i64 %t299, %t300
  %t304 = load i64, ptr %l10, !tbaa !24
  %t307 = add i64 %t303, %t304
  %t309 = sub i64 %t307, 1
  %t310 = load i64, ptr %l10, !tbaa !24
  %t313 = sdiv i64 %t309, %t310
  store i64 %t313, ptr %l187, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l187, !tbaa !24
  br label %bb74
bb74:
  %t315 = load i64, ptr %l187, !tbaa !24
  store i64 %t315, ptr %l184, !tbaa !24
  br label %bb75
bb75:
  %t316 = load i64, ptr %l184, !tbaa !24
  store i64 %t316, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb76
bb76:
  %t317 = load i64, ptr %l12, !tbaa !24
  %t318 = load i64, ptr %l11, !tbaa !24
  %t321 = icmp slt i64 %t317, %t318
  %t323 = xor i1 %t321, true
  br i1 %t323, label %bb77, label %bb78
bb77:
  br label %bb105
bb78:
  br label %bb79
bb79:
  %t325 = load i64, ptr %l8, !tbaa !24
  %t326 = load i64, ptr %l12, !tbaa !24
  %t327 = load i64, ptr %l10, !tbaa !24
  %t330 = mul i64 %t326, %t327
  %t333 = add i64 %t325, %t330
  store i64 %t333, ptr %l13, !tbaa !24
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/scope:Scoper", ptr %t335, i32 0, i32 58
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t337, i1 false)
  br label %bb80
bb80:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/scope:Scoper", ptr %t339, i32 0, i32 59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t341, i1 false)
  br label %bb81
bb81:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/scope:Scoper", ptr %t343, i32 0, i32 61
  %t346 = load ptr, ptr %l3, !tbaa !29
  %t348 = getelementptr %"compiler/typed:Body", ptr %t346, i32 0, i32 4
  %t349 = load %"compiler/source:Span", ptr %t348
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t345, %"compiler/source:Span" %t349)
  br label %bb82
bb82:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/scope:Scoper", ptr %t352, i32 0, i32 62
  %t355 = load ptr, ptr %l3, !tbaa !29
  %t357 = getelementptr %"compiler/typed:Body", ptr %t355, i32 0, i32 3
  %t358 = load i64, ptr %t357, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t354, i64 %t358)
  br label %bb83
bb83:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/scope:Scoper", ptr %t361, i32 0, i32 63
  %t364 = load ptr, ptr %l3, !tbaa !29
  %t366 = getelementptr %"compiler/typed:Body", ptr %t364, i32 0, i32 4
  %t367 = load %"compiler/source:Span", ptr %t366
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t363, %"compiler/source:Span" %t367)
  br label %bb84
bb84:
  store i1 false, ptr %l14, !tbaa !21
  %t370 = load i1, ptr %l7, !tbaa !21
  br i1 %t370, label %bb85, label %bb86
bb85:
  %t372 = load ptr, ptr %l3, !tbaa !29
  %t374 = getelementptr %"compiler/typed:Body", ptr %t372, i32 0, i32 6
  %t375 = load i64, ptr %l13, !tbaa !24
  %t378 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t374, i64 %t375)
  store { i64, [1 x i64] } %t378, ptr %l225
  br label %bb87
bb86:
  br label %bb102
bb87:
  %t379 = load { i64, [1 x i64] }, ptr %l225
  store { i64, [1 x i64] } %t379, ptr %l15
  %t380 = load { i64, [1 x i64] }, ptr %l15
  %t382 = extractvalue { i64, [1 x i64] } %t380, 0
  %t383 = icmp eq i64 %t382, 0
  br i1 %t383, label %bb88, label %bb89
bb88:
  %t385 = getelementptr { i64, [1 x i64] }, ptr %l15, i32 0, i32 1
  %t386 = getelementptr { i32 }, ptr %t385, i32 0, i32 0
  %t387 = load i32, ptr %t386
  store i32 %t387, ptr %l16, !tbaa !23
  br label %bb90
bb89:
  br label %bb96
bb90:
  %t389 = load ptr, ptr %l3, !tbaa !29
  %t391 = getelementptr %"compiler/typed:Body", ptr %t389, i32 0, i32 5
  %t393 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t391)
  store i64 %t393, ptr %l231
  br label %bb91
bb91:
  %t394 = load i64, ptr %l231, !tbaa !24
  %t395 = icmp sgt i64 %t394, 0
  br i1 %t395, label %bb92, label %bb93
bb92:
  %t397 = load i32, ptr %l16, !tbaa !23
  store i32 %t397, ptr %l234, !tbaa !23
  %t398 = load ptr, ptr %l3, !tbaa !29
  %t400 = getelementptr %"compiler/typed:Body", ptr %t398, i32 0, i32 5
  %t402 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t400, i64 0)
  store i32 %t402, ptr %l237
  br label %bb94
bb93:
  store i1 false, ptr %l233, !tbaa !21
  br label %bb95
bb94:
  %t403 = load i32, ptr %l234, !tbaa !23
  %t404 = load i32, ptr %l237, !tbaa !23
  %t405 = icmp eq i32 %t403, %t404
  store i1 %t405, ptr %l233, !tbaa !21
  br label %bb95
bb95:
  %t407 = load i1, ptr %l233, !tbaa !21
  store i1 %t407, ptr %l14, !tbaa !21
  br label %bb101
bb96:
  br i1 true, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_75ea16a293881b53_a3e5ee6d3f4964f)
  unreachable
bb101:
  br label %bb102
bb102:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/scope:Scoper", ptr %t408, i32 0, i32 64
  %t411 = load i1, ptr %l14, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t410, i1 %t411)
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t414 = load i64, ptr %l12, !tbaa !24
  %t416 = add i64 %t414, 1
  store i64 %t416, ptr %l12, !tbaa !24
  br label %bb76
bb105:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/scope:Scoper", ptr %t418, i32 0, i32 87
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t420)
  br label %bb106
bb106:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/scope:Scoper", ptr %t422, i32 0, i32 88
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t424)
  br label %bb107
bb107:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/scope:Scoper", ptr %t426, i32 0, i32 89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t428)
  br label %bb108
bb108:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/scope:Scoper", ptr %t430, i32 0, i32 90
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %t432)
  br label %bb109
bb109:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/scope:Scoper", ptr %t434, i32 0, i32 91
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %t436)
  br label %bb110
bb110:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/scope:Scoper", ptr %t438, i32 0, i32 93
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t440)
  br label %bb111
bb111:
  store i64 0, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t442 = load i1, ptr %l2, !tbaa !21
  br i1 %t442, label %bb112, label %bb113
bb112:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/scope:Scoper", ptr %t444, i32 0, i32 0
  %t447 = load ptr, ptr %t446, !tbaa !29
  %t449 = getelementptr %"compiler/generic:Program", ptr %t447, i32 0, i32 0
  %t450 = load ptr, ptr %t449, !tbaa !29
  %t452 = getelementptr %"compiler/load:Loader", ptr %t450, i32 0, i32 4
  %t453 = load ptr, ptr %t452, !tbaa !29
  store ptr %t453, ptr %l260, !tbaa !29
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/scope:Scoper", ptr %t454, i32 0, i32 0
  %t457 = load ptr, ptr %t456, !tbaa !29
  %t459 = getelementptr %"compiler/generic:Program", ptr %t457, i32 0, i32 0
  %t460 = load ptr, ptr %t459, !tbaa !29
  %t462 = getelementptr %"compiler/load:Loader", ptr %t460, i32 0, i32 4
  %t463 = load ptr, ptr %t462, !tbaa !29
  %t465 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextDepth(ptr %v0, ptr %t463)
  store i64 %t465, ptr %l265
  br label %bb114
bb113:
  br label %bb118
bb114:
  %t466 = load ptr, ptr %l260, !tbaa !29
  %t467 = load i64, ptr %l265, !tbaa !24
  %t468 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextBase(ptr %v0, ptr %t466, i64 %t467)
  store i64 %t468, ptr %l266
  br label %bb115
bb115:
  %t469 = load i64, ptr %l266, !tbaa !24
  store i64 %t469, ptr %l18, !tbaa !24
  %t470 = load ptr, ptr %l0, !tbaa !29
  store ptr %t470, ptr %l267, !tbaa !29
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load i64, ptr %l1, !tbaa !24
  %t475 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %t471, i64 %t472)
  store i64 %t475, ptr %l270
  br label %bb116
bb116:
  %t476 = load ptr, ptr %l267, !tbaa !29
  %t477 = load i64, ptr %l270, !tbaa !24
  %t478 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstContexts(ptr %v0, ptr %t476, i64 %t477)
  store i64 %t478, ptr %l271
  br label %bb117
bb117:
  %t479 = load i64, ptr %l271, !tbaa !24
  store i64 %t479, ptr %l17, !tbaa !24
  br label %bb118
bb118:
  %t480 = load ptr, ptr %l0, !tbaa !29
  store ptr %t480, ptr %l272, !tbaa !29
  %t481 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t481, ptr %l273
  br label %bb119
bb119:
  %t482 = load %"compiler/source:Span", ptr %l273
  %t483 = load ptr, ptr %l272, !tbaa !29
  %t484 = getelementptr %"compiler/scope:Scoper", ptr %t483, i32 0, i32 28
  store %"compiler/source:Span" %t482, ptr %t484
  %t485 = load ptr, ptr %l0, !tbaa !29
  store ptr %t485, ptr %l274, !tbaa !29
  %t486 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t486, ptr %l275
  br label %bb120
bb120:
  %t487 = load %"compiler/source:Span", ptr %l275
  %t488 = load ptr, ptr %l274, !tbaa !29
  %t489 = getelementptr %"compiler/scope:Scoper", ptr %t488, i32 0, i32 29
  store %"compiler/source:Span" %t487, ptr %t489
  %t490 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erun(ptr %v0, ptr %t490)
  br label %bb121
bb121:
  %t492 = load i1, ptr %l2, !tbaa !21
  br i1 %t492, label %bb122, label %bb123
bb122:
  %t494 = load i1, ptr %l7, !tbaa !21
  store i1 %t494, ptr %l278, !tbaa !21
  br label %bb124
bb123:
  store i1 false, ptr %l278, !tbaa !21
  br label %bb124
bb124:
  %t496 = load i1, ptr %l278, !tbaa !21
  br i1 %t496, label %bb125, label %bb126
bb125:
  %t497 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estrReceiver(ptr %v0, ptr %t497)
  br label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb128
bb128:
  %t499 = load i1, ptr %l2, !tbaa !21
  br i1 %t499, label %bb129, label %bb130
bb129:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = getelementptr %"compiler/scope:Scoper", ptr %t501, i32 0, i32 28
  %t504 = getelementptr %"compiler/source:Span", ptr %t503, i32 0, i32 0
  %t505 = load i32, ptr %t504, !tbaa !23
  %t507 = icmp sge i32 %t505, 0
  store i1 %t507, ptr %l282, !tbaa !21
  br label %bb131
bb130:
  store i1 false, ptr %l282, !tbaa !21
  br label %bb131
bb131:
  %t509 = load i1, ptr %l282, !tbaa !21
  br i1 %t509, label %bb132, label %bb133
bb132:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t512 = getelementptr %"compiler/scope:Scoper", ptr %t510, i32 0, i32 29
  %t513 = getelementptr %"compiler/source:Span", ptr %t512, i32 0, i32 0
  %t514 = load i32, ptr %t513, !tbaa !23
  %t516 = icmp sge i32 %t514, 0
  store i1 %t516, ptr %l286, !tbaa !21
  br label %bb134
bb133:
  store i1 false, ptr %l286, !tbaa !21
  br label %bb134
bb134:
  %t518 = load i1, ptr %l286, !tbaa !21
  br i1 %t518, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s16
  %t519 = load ptr, ptr %l0, !tbaa !29
  store ptr %t519, ptr %l290, !tbaa !29
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t522 = getelementptr %"compiler/scope:Scoper", ptr %t520, i32 0, i32 28
  %t523 = load %"compiler/source:Span", ptr %t522
  store %"compiler/source:Span" %t523, ptr %l292
  %t524 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeDestructor(ptr %s16, ptr %s16, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t524, ptr %l293
  br label %bb137
bb136:
  br label %bb141
bb137:
  %t525 = load ptr, ptr %l290, !tbaa !29
  %t526 = load %"compiler/source:Span", ptr %l292
  %t527 = load %"compiler/msgs:Msg", ptr %l293
  %t528 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s16, ptr %t525, %"compiler/source:Span" %t526, %"compiler/msgs:Msg" %t527)
  store i64 %t528, ptr %l294
  br label %bb138
bb138:
  %t529 = load i64, ptr %l294, !tbaa !24
  %t530 = load ptr, ptr %l0, !tbaa !29
  store ptr %t530, ptr %l295, !tbaa !29
  store i64 %t529, ptr %l296, !tbaa !24
  %t532 = load ptr, ptr %l3, !tbaa !29
  %t534 = getelementptr %"compiler/typed:Body", ptr %t532, i32 0, i32 3
  %t535 = load i64, ptr %t534, !tbaa !24
  store i64 %t535, ptr %l298, !tbaa !24
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t538 = getelementptr %"compiler/scope:Scoper", ptr %t536, i32 0, i32 29
  %t539 = load %"compiler/source:Span", ptr %t538
  store %"compiler/source:Span" %t539, ptr %l300
  %t540 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s16)
  store %"compiler/msgs:Msg" %t540, ptr %l301
  br label %bb139
bb139:
  %t541 = load ptr, ptr %l295, !tbaa !29
  %t542 = load i64, ptr %l296, !tbaa !24
  %t543 = load i64, ptr %l298, !tbaa !24
  %t544 = load %"compiler/source:Span", ptr %l300
  %t545 = load %"compiler/msgs:Msg", ptr %l301
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s16, ptr %t541, i64 %t542, i64 %t543, %"compiler/source:Span" %t544, %"compiler/msgs:Msg" %t545)
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s16)
  br label %bb141
bb141:
  %t546 = load i1, ptr %l2, !tbaa !21
  br i1 %t546, label %bb142, label %bb143
bb142:
  store i64 0, ptr %l20, !tbaa !24
  %t548 = load i64, ptr %l17, !tbaa !24
  store i64 %t548, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t550 = load i64, ptr %l21, !tbaa !24
  %t551 = load i64, ptr %l20, !tbaa !24
  %t554 = icmp sgt i64 %t550, %t551
  br i1 %t554, label %bb144, label %bb145
bb143:
  br label %bb158
bb144:
  %t556 = load i64, ptr %l22, !tbaa !24
  %t558 = icmp sgt i64 %t556, 0
  br i1 %t558, label %bb146, label %bb147
bb145:
  store i64 0, ptr %l307, !tbaa !24
  br label %bb149
bb146:
  %t560 = load i64, ptr %l21, !tbaa !24
  %t561 = load i64, ptr %l20, !tbaa !24
  %t564 = sub i64 %t560, %t561
  %t565 = load i64, ptr %l22, !tbaa !24
  %t568 = add i64 %t564, %t565
  %t570 = sub i64 %t568, 1
  %t571 = load i64, ptr %l22, !tbaa !24
  %t574 = sdiv i64 %t570, %t571
  store i64 %t574, ptr %l310, !tbaa !24
  br label %bb148
bb147:
  store i64 0, ptr %l310, !tbaa !24
  br label %bb148
bb148:
  %t576 = load i64, ptr %l310, !tbaa !24
  store i64 %t576, ptr %l307, !tbaa !24
  br label %bb149
bb149:
  %t577 = load i64, ptr %l307, !tbaa !24
  store i64 %t577, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb150
bb150:
  %t578 = load i64, ptr %l24, !tbaa !24
  %t579 = load i64, ptr %l23, !tbaa !24
  %t582 = icmp slt i64 %t578, %t579
  %t584 = xor i1 %t582, true
  br i1 %t584, label %bb151, label %bb152
bb151:
  br label %bb156
bb152:
  br label %bb153
bb153:
  %t586 = load i64, ptr %l20, !tbaa !24
  %t587 = load i64, ptr %l24, !tbaa !24
  %t588 = load i64, ptr %l22, !tbaa !24
  %t591 = mul i64 %t587, %t588
  %t594 = add i64 %t586, %t591
  store i64 %t594, ptr %l25, !tbaa !24
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t598 = getelementptr %"compiler/scope:Scoper", ptr %t596, i32 0, i32 0
  %t599 = load ptr, ptr %t598, !tbaa !29
  %t601 = getelementptr %"compiler/generic:Program", ptr %t599, i32 0, i32 0
  %t602 = load ptr, ptr %t601, !tbaa !29
  %t604 = getelementptr %"compiler/load:Loader", ptr %t602, i32 0, i32 4
  %t605 = load ptr, ptr %t604, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %t605)
  br label %bb154
bb154:
  br label %bb155
bb155:
  %t607 = load i64, ptr %l24, !tbaa !24
  %t609 = add i64 %t607, 1
  store i64 %t609, ptr %l24, !tbaa !24
  br label %bb150
bb156:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t613 = getelementptr %"compiler/scope:Scoper", ptr %t611, i32 0, i32 0
  %t614 = load ptr, ptr %t613, !tbaa !29
  %t616 = getelementptr %"compiler/generic:Program", ptr %t614, i32 0, i32 0
  %t617 = load ptr, ptr %t616, !tbaa !29
  %t619 = getelementptr %"compiler/load:Loader", ptr %t617, i32 0, i32 4
  %t620 = load ptr, ptr %t619, !tbaa !29
  %t621 = load i64, ptr %l18, !tbaa !24
  %t624 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextBase(ptr %v0, ptr %t620, i64 %t621)
  store i64 %t624, ptr %l339
  br label %bb157
bb157:
  br label %bb158
bb158:
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/scope:Scoper", ptr %t625, i32 0, i32 35
  store ptr %t627, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb159
bb159:
  %t629 = load i64, ptr %l27, !tbaa !24
  store i64 %t629, ptr %l342, !tbaa !24
  %t630 = load ptr, ptr %l26, !tbaa !29
  %t632 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t630)
  store i64 %t632, ptr %l344
  br label %bb160
bb160:
  %t633 = load i64, ptr %l342, !tbaa !24
  %t634 = load i64, ptr %l344, !tbaa !24
  %t635 = icmp slt i64 %t633, %t634
  %t637 = xor i1 %t635, true
  br i1 %t637, label %bb161, label %bb162
bb161:
  br label %bb168
bb162:
  br label %bb163
bb163:
  %t639 = load ptr, ptr %l26, !tbaa !29
  %t640 = load i64, ptr %l27, !tbaa !24
  %t643 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t639, i64 %t640)
  store %"compiler/scope:rel" %t643, ptr %l349
  br label %bb164
bb164:
  %t644 = load %"compiler/scope:rel", ptr %l349
  store %"compiler/scope:rel" %t644, ptr %l28
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t647 = getelementptr %"compiler/scope:Scoper", ptr %t645, i32 0, i32 6
  %t648 = load i64, ptr %l1, !tbaa !24
  %t651 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t647, i64 %t648)
  store ptr %t651, ptr %l353
  br label %bb165
bb165:
  %t652 = load ptr, ptr %l353, !tbaa !29
  %t654 = getelementptr %"compiler/scope:summary", ptr %t652, i32 0, i32 0
  %t655 = load %"compiler/scope:rel", ptr %l28
  call void @compiler_2fscope_2ekeepRel(ptr %v0, ptr %t654, %"compiler/scope:rel" %t655)
  br label %bb166
bb166:
  br label %bb167
bb167:
  %t658 = load i64, ptr %l27, !tbaa !24
  %t660 = add i64 %t658, 1
  store i64 %t660, ptr %l27, !tbaa !24
  br label %bb159
bb168:
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t664 = getelementptr %"compiler/scope:Scoper", ptr %t662, i32 0, i32 6
  %t665 = load i64, ptr %l1, !tbaa !24
  %t668 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t664, i64 %t665)
  store ptr %t668, ptr %l362
  br label %bb169
bb169:
  %t669 = load ptr, ptr %l362, !tbaa !29
  store ptr %t669, ptr %l29, !tbaa !29
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteFieldRecs(ptr %v0, ptr %v0, ptr %t670, ptr %t671)
  br label %bb170
bb170:
  %t674 = load ptr, ptr %l29, !tbaa !29
  %t676 = getelementptr %"compiler/scope:summary", ptr %t674, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t676)
  br label %bb171
bb171:
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t680 = getelementptr %"compiler/scope:Scoper", ptr %t678, i32 0, i32 56
  %t681 = load i1, ptr %t680, !tbaa !21
  br i1 %t681, label %bb172, label %bb173
bb172:
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t685 = getelementptr %"compiler/scope:Scoper", ptr %t683, i32 0, i32 55
  store ptr %t685, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb174
bb173:
  br label %bb183
bb174:
  %t687 = load i64, ptr %l31, !tbaa !24
  store i64 %t687, ptr %l371, !tbaa !24
  %t688 = load ptr, ptr %l30, !tbaa !29
  %t690 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t688)
  store i64 %t690, ptr %l373
  br label %bb175
bb175:
  %t691 = load i64, ptr %l371, !tbaa !24
  %t692 = load i64, ptr %l373, !tbaa !24
  %t693 = icmp slt i64 %t691, %t692
  %t695 = xor i1 %t693, true
  br i1 %t695, label %bb176, label %bb177
bb176:
  br label %bb182
bb177:
  br label %bb178
bb178:
  %t697 = load ptr, ptr %l30, !tbaa !29
  %t698 = load i64, ptr %l31, !tbaa !24
  %t701 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t697, i64 %t698)
  store { i64, [2 x i64] } %t701, ptr %l378
  br label %bb179
bb179:
  %t702 = load { i64, [2 x i64] }, ptr %l378
  %t703 = load ptr, ptr %l29, !tbaa !29
  %t705 = getelementptr %"compiler/scope:summary", ptr %t703, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t705, { i64, [2 x i64] } %t702)
  br label %bb180
bb180:
  br label %bb181
bb181:
  %t709 = load i64, ptr %l31, !tbaa !24
  %t711 = add i64 %t709, 1
  store i64 %t711, ptr %l31, !tbaa !24
  br label %bb174
bb182:
  br label %bb183
bb183:
  %t713 = load ptr, ptr %l29, !tbaa !29
  %t715 = getelementptr %"compiler/scope:summary", ptr %t713, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t715)
  br label %bb184
bb184:
  %t717 = load ptr, ptr %l29, !tbaa !29
  %t719 = getelementptr %"compiler/scope:summary", ptr %t717, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t719)
  br label %bb185
bb185:
  %t721 = load ptr, ptr %l29, !tbaa !29
  %t723 = getelementptr %"compiler/scope:summary", ptr %t721, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t723)
  br label %bb186
bb186:
  %t725 = load ptr, ptr %l29, !tbaa !29
  %t727 = getelementptr %"compiler/scope:summary", ptr %t725, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t727)
  br label %bb187
bb187:
  store i64 0, ptr %l33, !tbaa !24
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t731 = getelementptr %"compiler/scope:Scoper", ptr %t729, i32 0, i32 58
  %t733 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t731)
  store i64 %t733, ptr %l394
  br label %bb188
bb188:
  %t734 = load i64, ptr %l394, !tbaa !24
  store i64 %t734, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t735 = load i64, ptr %l34, !tbaa !24
  %t736 = load i64, ptr %l33, !tbaa !24
  %t739 = icmp sgt i64 %t735, %t736
  br i1 %t739, label %bb189, label %bb190
bb189:
  %t741 = load i64, ptr %l35, !tbaa !24
  %t743 = icmp sgt i64 %t741, 0
  br i1 %t743, label %bb191, label %bb192
bb190:
  store i64 0, ptr %l398, !tbaa !24
  br label %bb194
bb191:
  %t745 = load i64, ptr %l34, !tbaa !24
  %t746 = load i64, ptr %l33, !tbaa !24
  %t749 = sub i64 %t745, %t746
  %t750 = load i64, ptr %l35, !tbaa !24
  %t753 = add i64 %t749, %t750
  %t755 = sub i64 %t753, 1
  %t756 = load i64, ptr %l35, !tbaa !24
  %t759 = sdiv i64 %t755, %t756
  store i64 %t759, ptr %l401, !tbaa !24
  br label %bb193
bb192:
  store i64 0, ptr %l401, !tbaa !24
  br label %bb193
bb193:
  %t761 = load i64, ptr %l401, !tbaa !24
  store i64 %t761, ptr %l398, !tbaa !24
  br label %bb194
bb194:
  %t762 = load i64, ptr %l398, !tbaa !24
  store i64 %t762, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb195
bb195:
  %t763 = load i64, ptr %l37, !tbaa !24
  %t764 = load i64, ptr %l36, !tbaa !24
  %t767 = icmp slt i64 %t763, %t764
  %t769 = xor i1 %t767, true
  br i1 %t769, label %bb196, label %bb197
bb196:
  br label %bb208
bb197:
  br label %bb198
bb198:
  %t771 = load i64, ptr %l33, !tbaa !24
  %t772 = load i64, ptr %l37, !tbaa !24
  %t773 = load i64, ptr %l35, !tbaa !24
  %t776 = mul i64 %t772, %t773
  %t779 = add i64 %t771, %t776
  store i64 %t779, ptr %l38, !tbaa !24
  %t781 = load ptr, ptr %l29, !tbaa !29
  %t783 = getelementptr %"compiler/scope:summary", ptr %t781, i32 0, i32 1
  store ptr %t783, ptr %l420, !tbaa !29
  %t784 = load ptr, ptr %l0, !tbaa !29
  %t786 = getelementptr %"compiler/scope:Scoper", ptr %t784, i32 0, i32 58
  %t787 = load i64, ptr %l38, !tbaa !24
  %t790 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t786, i64 %t787)
  store i1 %t790, ptr %l424
  br label %bb199
bb199:
  %t791 = load ptr, ptr %l420, !tbaa !29
  %t792 = load i1, ptr %l424, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t791, i1 %t792)
  br label %bb200
bb200:
  %t793 = load ptr, ptr %l29, !tbaa !29
  %t795 = getelementptr %"compiler/scope:summary", ptr %t793, i32 0, i32 2
  store ptr %t795, ptr %l426, !tbaa !29
  %t796 = load ptr, ptr %l0, !tbaa !29
  %t798 = getelementptr %"compiler/scope:Scoper", ptr %t796, i32 0, i32 59
  %t799 = load i64, ptr %l38, !tbaa !24
  %t802 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t798, i64 %t799)
  store i1 %t802, ptr %l430
  br label %bb201
bb201:
  %t803 = load ptr, ptr %l426, !tbaa !29
  %t804 = load i1, ptr %l430, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t803, i1 %t804)
  br label %bb202
bb202:
  %t805 = load ptr, ptr %l29, !tbaa !29
  %t807 = getelementptr %"compiler/scope:summary", ptr %t805, i32 0, i32 3
  store ptr %t807, ptr %l432, !tbaa !29
  %t808 = load ptr, ptr %l0, !tbaa !29
  %t810 = getelementptr %"compiler/scope:Scoper", ptr %t808, i32 0, i32 62
  %t811 = load i64, ptr %l38, !tbaa !24
  %t814 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t810, i64 %t811)
  store i64 %t814, ptr %l436
  br label %bb203
bb203:
  %t815 = load ptr, ptr %l432, !tbaa !29
  %t816 = load i64, ptr %l436, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t815, i64 %t816)
  br label %bb204
bb204:
  %t817 = load ptr, ptr %l29, !tbaa !29
  %t819 = getelementptr %"compiler/scope:summary", ptr %t817, i32 0, i32 4
  store ptr %t819, ptr %l438, !tbaa !29
  %t820 = load ptr, ptr %l0, !tbaa !29
  %t822 = getelementptr %"compiler/scope:Scoper", ptr %t820, i32 0, i32 63
  %t823 = load i64, ptr %l38, !tbaa !24
  %t826 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t822, i64 %t823)
  store %"compiler/source:Span" %t826, ptr %l442
  br label %bb205
bb205:
  %t827 = load ptr, ptr %l438, !tbaa !29
  %t828 = load %"compiler/source:Span", ptr %l442
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t827, %"compiler/source:Span" %t828)
  br label %bb206
bb206:
  br label %bb207
bb207:
  %t829 = load i64, ptr %l37, !tbaa !24
  %t831 = add i64 %t829, 1
  store i64 %t831, ptr %l37, !tbaa !24
  br label %bb195
bb208:
  %t833 = load ptr, ptr %l0, !tbaa !29
  %t834 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecomputeKeeps(ptr %v0, ptr %v0, ptr %t833, ptr %t834)
  br label %bb209
bb209:
  store i64 0, ptr %l39, !tbaa !24
  %t837 = load ptr, ptr %l0, !tbaa !29
  %t839 = getelementptr %"compiler/scope:Scoper", ptr %t837, i32 0, i32 58
  %t841 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t839)
  store i64 %t841, ptr %l449
  br label %bb210
bb210:
  %t842 = load i64, ptr %l449, !tbaa !24
  store i64 %t842, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t843 = load i64, ptr %l40, !tbaa !24
  %t844 = load i64, ptr %l39, !tbaa !24
  %t847 = icmp sgt i64 %t843, %t844
  br i1 %t847, label %bb211, label %bb212
bb211:
  %t849 = load i64, ptr %l41, !tbaa !24
  %t851 = icmp sgt i64 %t849, 0
  br i1 %t851, label %bb213, label %bb214
bb212:
  store i64 0, ptr %l453, !tbaa !24
  br label %bb216
bb213:
  %t853 = load i64, ptr %l40, !tbaa !24
  %t854 = load i64, ptr %l39, !tbaa !24
  %t857 = sub i64 %t853, %t854
  %t858 = load i64, ptr %l41, !tbaa !24
  %t861 = add i64 %t857, %t858
  %t863 = sub i64 %t861, 1
  %t864 = load i64, ptr %l41, !tbaa !24
  %t867 = sdiv i64 %t863, %t864
  store i64 %t867, ptr %l456, !tbaa !24
  br label %bb215
bb214:
  store i64 0, ptr %l456, !tbaa !24
  br label %bb215
bb215:
  %t869 = load i64, ptr %l456, !tbaa !24
  store i64 %t869, ptr %l453, !tbaa !24
  br label %bb216
bb216:
  %t870 = load i64, ptr %l453, !tbaa !24
  store i64 %t870, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb217
bb217:
  %t871 = load i64, ptr %l43, !tbaa !24
  %t872 = load i64, ptr %l42, !tbaa !24
  %t875 = icmp slt i64 %t871, %t872
  %t877 = xor i1 %t875, true
  br i1 %t877, label %bb218, label %bb219
bb218:
  br label %bb226
bb219:
  br label %bb220
bb220:
  %t879 = load i64, ptr %l39, !tbaa !24
  %t880 = load i64, ptr %l43, !tbaa !24
  %t881 = load i64, ptr %l41, !tbaa !24
  %t884 = mul i64 %t880, %t881
  %t887 = add i64 %t879, %t884
  store i64 %t887, ptr %l44, !tbaa !24
  %t889 = load i64, ptr %l44, !tbaa !24
  %t890 = load ptr, ptr %l0, !tbaa !29
  %t892 = getelementptr %"compiler/scope:Scoper", ptr %t890, i32 0, i32 30
  %t893 = getelementptr %"compiler/typed:Plan", ptr %t892, i32 0, i32 2
  %t894 = load { i64, ptr }, ptr %t893, !tbaa !27
  %t896 = extractvalue { i64, ptr } %t894, 0
  %t899 = icmp slt i64 %t889, %t896
  br i1 %t899, label %bb221, label %bb222
bb221:
  %t901 = load ptr, ptr %l0, !tbaa !29
  %t903 = getelementptr %"compiler/scope:Scoper", ptr %t901, i32 0, i32 30
  %t904 = getelementptr %"compiler/typed:Plan", ptr %t903, i32 0, i32 2
  %t905 = load { i64, ptr }, ptr %t904, !tbaa !27
  store { i64, ptr } %t905, ptr %l480, !tbaa !27
  %t906 = load i64, ptr %l44, !tbaa !24
  store i64 %t906, ptr %l481, !tbaa !24
  %t907 = load ptr, ptr %l0, !tbaa !29
  %t909 = getelementptr %"compiler/scope:Scoper", ptr %t907, i32 0, i32 58
  %t910 = load i64, ptr %l44, !tbaa !24
  %t913 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t909, i64 %t910)
  store i1 %t913, ptr %l485
  br label %bb223
bb222:
  br label %bb224
bb223:
  %t914 = load i1, ptr %l485, !tbaa !21
  %t915 = load i64, ptr %l481, !tbaa !24
  %t916 = getelementptr { i64, ptr }, ptr %l480, i32 0, i32 1
  %t917 = load ptr, ptr %t916, !tbaa !27
  %t918 = getelementptr i1, ptr %t917, i64 %t915
  store i1 %t914, ptr %t918, !tbaa !31
  br label %bb224
bb224:
  br label %bb225
bb225:
  %t919 = load i64, ptr %l43, !tbaa !24
  %t921 = add i64 %t919, 1
  store i64 %t921, ptr %l43, !tbaa !24
  br label %bb217
bb226:
  %t923 = load i1, ptr %l2, !tbaa !21
  br i1 %t923, label %bb227, label %bb228
bb227:
  %t925 = load ptr, ptr %l0, !tbaa !29
  %t927 = getelementptr %"compiler/scope:Scoper", ptr %t925, i32 0, i32 2
  store ptr %t927, ptr %l490, !tbaa !29
  %t928 = load i64, ptr %l1, !tbaa !24
  store i64 %t928, ptr %l491, !tbaa !24
  %t929 = load ptr, ptr %l0, !tbaa !29
  %t931 = getelementptr %"compiler/scope:Scoper", ptr %t929, i32 0, i32 30
  call void @llvm.memmove.p0.p0.i64(ptr %l493, ptr %t931, i64 176, i1 false)
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t932, ptr %v0, ptr %l493)
  call void @llvm.memmove.p0.p0.i64(ptr %l495, ptr %t932, i64 176, i1 false)
  br label %bb229
bb228:
  br label %bb231
bb229:
  %t934 = load ptr, ptr %l490, !tbaa !29
  %t935 = load i64, ptr %l491, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %t936, ptr %l495, i64 176, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eSetAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t934, i64 %t935, ptr %t936)
  br label %bb230
bb230:
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandByObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/scope:rel"
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i1
  %l23 = alloca i1
  %l30 = alloca ptr
  %l33 = alloca i64
  %l35 = alloca i64
  %l40 = alloca %"compiler/scope:rel"
  %l43 = alloca i1
  %l48 = alloca i1
  %l51 = alloca i1
  %l64 = alloca { i64, ptr }
  %l72 = alloca i1
  %l86 = alloca { i64, [2 x i64] }
  %l88 = alloca i1
  %l90 = alloca i1
  %l97 = alloca { i64, [2 x i64] }
  %l108 = alloca i1
  %l117 = alloca i64
  %l124 = alloca i64
  %rv = alloca { i64, [2 x i64] }
  %t23 = alloca { i64, [2 x i64] }, align 8
  %t27 = alloca { i64, [2 x i64] }, align 8
  %t93 = alloca { i64, [2 x i64] }, align 8
  %t140 = alloca { i64, [2 x i64] }, align 8
  %t195 = alloca { i64, [2 x i64] }, align 8
  %t222 = alloca { i64, [2 x i64] }, align 8
  %t226 = alloca { i64, [2 x i64] }, align 8
  %t263 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l17
  br label %bb1
bb1:
  %t9 = load i64, ptr %l17, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l23
  br label %bb4
bb4:
  %t19 = load i1, ptr %l23, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l20, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l20, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store { i64, [2 x i64] } zeroinitializer, ptr %t23
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 0
  store i64 0, ptr %t24
  %t25 = load { i64, [2 x i64] }, ptr %t23
  store { i64, [2 x i64] } %t25, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store { i64, [2 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [2 x i64] }, ptr %t27, i32 0, i32 0
  store i64 0, ptr %t28
  %t29 = load { i64, [2 x i64] }, ptr %t27
  store { i64, [2 x i64] } %t29, ptr %l5
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 6
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t33, i64 %t34)
  store ptr %t37, ptr %l30
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l30, !tbaa !29
  %t40 = getelementptr %"compiler/scope:summary", ptr %t38, i32 0, i32 0
  store ptr %t40, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t42 = load i64, ptr %l7, !tbaa !24
  store i64 %t42, ptr %l33, !tbaa !24
  %t43 = load ptr, ptr %l6, !tbaa !29
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l35
  br label %bb11
bb11:
  %t46 = load i64, ptr %l33, !tbaa !24
  %t47 = load i64, ptr %l35, !tbaa !24
  %t48 = icmp slt i64 %t46, %t47
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  br label %bb94
bb13:
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t52, i64 %t53)
  store %"compiler/scope:rel" %t56, ptr %l40
  br label %bb15
bb15:
  %t57 = load %"compiler/scope:rel", ptr %l40
  store %"compiler/scope:rel" %t57, ptr %l8
  %t58 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 1
  %t59 = load { i64, [2 x i64] }, ptr %t58
  %t61 = extractvalue { i64, [2 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 2
  br i1 %t62, label %bb16, label %bb17
bb16:
  %t64 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 1
  %t65 = getelementptr { i64, [2 x i64] }, ptr %t64, i32 0, i32 1
  %t66 = getelementptr { i64 }, ptr %t65, i32 0, i32 0
  %t67 = load i64, ptr %t66
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp eq i64 %t67, %t68
  store i1 %t71, ptr %l43, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb18
bb18:
  %t73 = load i1, ptr %l43, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb24
bb20:
  %t76 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t77 = load { i64, [2 x i64] }, ptr %t76
  %t79 = extractvalue { i64, [2 x i64] } %t77, 0
  %t80 = icmp eq i64 %t79, 2
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t83 = getelementptr { i64, [2 x i64] }, ptr %t82, i32 0, i32 1
  %t84 = getelementptr { i64 }, ptr %t83, i32 0, i32 0
  %t85 = load i64, ptr %t84
  %t86 = load i64, ptr %l2, !tbaa !24
  %t89 = icmp eq i64 %t85, %t86
  store i1 %t89, ptr %l51, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t91 = load i1, ptr %l51, !tbaa !21
  store i1 %t91, ptr %l48, !tbaa !21
  br label %bb24
bb24:
  %t92 = load i1, ptr %l48, !tbaa !21
  br i1 %t92, label %bb25, label %bb26
bb25:
  br label %bb93
bb26:
  br label %bb27
bb27:
  store { i64, [2 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [2 x i64] }, ptr %t93, i32 0, i32 0
  store i64 0, ptr %t94
  %t95 = load { i64, [2 x i64] }, ptr %t93
  store { i64, [2 x i64] } %t95, ptr %l9
  %t97 = getelementptr %"compiler/scope:rel", ptr %l8, i32 0, i32 0
  %t98 = load { i64, [2 x i64] }, ptr %t97
  store { i64, [2 x i64] } %t98, ptr %l10
  %t100 = load { i64, [2 x i64] }, ptr %l10
  %t102 = extractvalue { i64, [2 x i64] } %t100, 0
  %t103 = icmp eq i64 %t102, 2
  br i1 %t103, label %bb28, label %bb29
bb28:
  %t105 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t106 = getelementptr { i64 }, ptr %t105, i32 0, i32 0
  %t107 = load i64, ptr %t106
  store i64 %t107, ptr %l11, !tbaa !24
  br label %bb30
bb29:
  br label %bb41
bb30:
  %t109 = load i64, ptr %l11, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t115 = icmp slt i64 %t109, %t112
  br i1 %t115, label %bb31, label %bb32
bb31:
  %t117 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t117, ptr %l64, !tbaa !27
  %t118 = load i64, ptr %l11, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, [2 x i64] }, ptr %t121, i64 %t118
  %t123 = load { i64, [2 x i64] }, ptr %t122
  store { i64, [2 x i64] } %t123, ptr %l9
  br label %bb33
bb32:
  br label %bb33
bb33:
  %t125 = load { i64, [2 x i64] }, ptr %l9
  %t127 = extractvalue { i64, [2 x i64] } %t125, 0
  %t128 = icmp eq i64 %t127, 0
  br i1 %t128, label %bb34, label %bb35
bb34:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t132 = load i64, ptr %l11, !tbaa !24
  %t136 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticVar(ptr %v0, ptr %v1, ptr %t130, ptr %t131, i64 %t132)
  store i1 %t136, ptr %l72
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t137 = load i1, ptr %l72, !tbaa !21
  %t138 = xor i1 %t137, true
  br i1 %t138, label %bb37, label %bb38
bb37:
  br label %bb93
bb38:
  br label %bb39
bb39:
  store { i64, [2 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [2 x i64] }, ptr %t140, i32 0, i32 0
  store i64 3, ptr %t141
  %t142 = load { i64, [2 x i64] }, ptr %t140
  store { i64, [2 x i64] } %t142, ptr %l9
  br label %bb40
bb40:
  br label %bb62
bb41:
  %t144 = load { i64, [2 x i64] }, ptr %l10
  %t146 = extractvalue { i64, [2 x i64] } %t144, 0
  %t147 = icmp eq i64 %t146, 4
  br i1 %t147, label %bb42, label %bb43
bb42:
  %t149 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t150 = getelementptr { i64, i64 }, ptr %t149, i32 0, i32 0
  %t151 = load i64, ptr %t150
  store i64 %t151, ptr %l12, !tbaa !24
  %t153 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t154 = getelementptr { i64, i64 }, ptr %t153, i32 0, i32 1
  %t155 = load i64, ptr %t154
  store i64 %t155, ptr %l13, !tbaa !24
  br label %bb44
bb43:
  br label %bb57
bb44:
  %t157 = load i64, ptr %l12, !tbaa !24
  %t159 = icmp sge i64 %t157, 0
  br i1 %t159, label %bb45, label %bb46
bb45:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i64, ptr %l12, !tbaa !24
  %t163 = load i64, ptr %l13, !tbaa !24
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t171 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedAt(ptr %v0, ptr %v1, ptr %v2, ptr %t161, i64 %t162, i64 %t163, ptr %t164, i1 true, { i64, ptr } %t165)
  store { i64, [2 x i64] } %t171, ptr %l86
  br label %bb47
bb46:
  br label %bb56
bb47:
  %t172 = load { i64, [2 x i64] }, ptr %l86
  store { i64, [2 x i64] } %t172, ptr %l9
  %t173 = load { i64, [2 x i64] }, ptr %l9
  %t175 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t173)
  store i1 %t175, ptr %l88
  br label %bb48
bb48:
  %t176 = load i1, ptr %l88, !tbaa !21
  %t177 = xor i1 %t176, true
  br i1 %t177, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb51
bb50:
  %t179 = load { i64, [2 x i64] }, ptr %l9
  %t181 = extractvalue { i64, [2 x i64] } %t179, 0
  %t182 = icmp eq i64 %t181, 3
  store i1 %t182, ptr %l90, !tbaa !21
  br label %bb51
bb51:
  %t184 = load i1, ptr %l90, !tbaa !21
  br i1 %t184, label %bb52, label %bb53
bb52:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t187 = load i64, ptr %l12, !tbaa !24
  %t188 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t193 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamBinding(ptr %v0, ptr %v1, ptr %v2, ptr %t185, ptr %t186, i64 %t187, { i64, ptr } %t188)
  store { i64, [2 x i64] } %t193, ptr %l97
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t194 = load { i64, [2 x i64] }, ptr %l97
  store { i64, [2 x i64] } %t194, ptr %l9
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb62
bb57:
  br i1 true, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  store { i64, [2 x i64] } zeroinitializer, ptr %t195
  %t196 = getelementptr { i64, [2 x i64] }, ptr %t195, i32 0, i32 0
  store i64 0, ptr %t196
  %t197 = load { i64, [2 x i64] }, ptr %t195
  store { i64, [2 x i64] } %t197, ptr %rv
  br label %ret
bb61:
  call void @__olang_check_failed(ptr @olang_loc_8c8a5a319e38c1bd_d671b8fda2886981)
  unreachable
bb62:
  %t199 = load { i64, [2 x i64] }, ptr %l9
  %t201 = extractvalue { i64, [2 x i64] } %t199, 0
  %t202 = icmp eq i64 %t201, 1
  br i1 %t202, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  %t204 = load { i64, [2 x i64] }, ptr %l9
  %t206 = extractvalue { i64, [2 x i64] } %t204, 0
  %t207 = icmp eq i64 %t206, 2
  br i1 %t207, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb81
bb68:
  %t209 = load { i64, [2 x i64] }, ptr %l9
  %t211 = extractvalue { i64, [2 x i64] } %t209, 0
  %t212 = icmp eq i64 %t211, 3
  br i1 %t212, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb76
bb71:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i64, ptr %l4, !tbaa !24
  %t216 = load i64, ptr %l2, !tbaa !24
  %t220 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumBuilds(ptr %v0, ptr %t214, i64 %t215, i64 %t216)
  store i1 %t220, ptr %l108
  br label %bb72
bb72:
  %t221 = load i1, ptr %l108, !tbaa !21
  br i1 %t221, label %bb73, label %bb74
bb73:
  store { i64, [2 x i64] } zeroinitializer, ptr %t222
  %t223 = getelementptr { i64, [2 x i64] }, ptr %t222, i32 0, i32 0
  store i64 0, ptr %t223
  %t224 = load { i64, [2 x i64] }, ptr %t222
  store { i64, [2 x i64] } %t224, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  br label %bb81
bb76:
  br i1 true, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  store { i64, [2 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [2 x i64] }, ptr %t226, i32 0, i32 0
  store i64 0, ptr %t227
  %t228 = load { i64, [2 x i64] }, ptr %t226
  store { i64, [2 x i64] } %t228, ptr %rv
  br label %ret
bb80:
  call void @__olang_check_failed(ptr @olang_loc_d6d71e16ab160a8c_d85efb61f7dcc5f0)
  unreachable
bb81:
  %t230 = load { i64, [2 x i64] }, ptr %l5
  %t232 = extractvalue { i64, [2 x i64] } %t230, 0
  %t233 = icmp eq i64 %t232, 0
  br i1 %t233, label %bb82, label %bb83
bb82:
  %t235 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t235, ptr %l5
  br label %bb92
bb83:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load { i64, [2 x i64] }, ptr %l5
  %t239 = load { i64, [2 x i64] }, ptr %l9
  %t243 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t237, { i64, [2 x i64] } %t238, { i64, [2 x i64] } %t239)
  store i64 %t243, ptr %l117
  br label %bb84
bb84:
  %t244 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t245 = load i64, ptr %l117, !tbaa !24
  %t247 = icmp eq i64 %t245, %t244
  br i1 %t247, label %bb85, label %bb86
bb85:
  %t249 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t249, ptr %l5
  br label %bb91
bb86:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load { i64, [2 x i64] }, ptr %l9
  %t253 = load { i64, [2 x i64] }, ptr %l5
  %t257 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t251, { i64, [2 x i64] } %t252, { i64, [2 x i64] } %t253)
  store i64 %t257, ptr %l124
  br label %bb87
bb87:
  %t258 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t259 = load i64, ptr %l124, !tbaa !24
  %t261 = icmp ne i64 %t259, %t258
  br i1 %t261, label %bb88, label %bb89
bb88:
  store { i64, [2 x i64] } zeroinitializer, ptr %t263
  %t264 = getelementptr { i64, [2 x i64] }, ptr %t263, i32 0, i32 0
  store i64 0, ptr %t264
  %t265 = load { i64, [2 x i64] }, ptr %t263
  store { i64, [2 x i64] } %t265, ptr %rv
  br label %ret
bb89:
  br label %bb90
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t267 = load i64, ptr %l7, !tbaa !24
  %t269 = add i64 %t267, 1
  store i64 %t269, ptr %l7, !tbaa !24
  br label %bb10
bb94:
  %t271 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t271, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandHeld(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l2 = alloca %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78"
  %l5 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l6 = alloca %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78"
  %l8 = alloca %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78"
  %l9 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca { i64, [2 x i64] }
  %l17 = alloca %"compiler/scope:Val"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 40
  %t5 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H7e82b4dbdb79c77bc51fdaf9d4704834(ptr %v0, ptr %v0, ptr %t3)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l5
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t6, ptr %l1
  br label %bb2
bb2:
  %t8 = call { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20compiler_2ftyped_3aExpr_2_H4ea279ff901448a8d94a2f42aa119fd2(ptr %v0, ptr %v0, ptr %l1)
  %t9 = extractvalue { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } %t8, 1
  %t10 = extractvalue { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } %t8, 0
  store i32 %t10, ptr %l9
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t9, ptr %l8
  br label %bb3
bb3:
  %t13 = load %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %l8
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t13, ptr %l6
  br label %bb6
bb4:
  %t14 = load i32, ptr %l9, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  br label %bb10
bb6:
  %t18 = load %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %l6
  store %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" %t18, ptr %l2
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  %t20 = getelementptr %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78", ptr %l2, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t23)
  store { i64, [2 x i64] } %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load { i64, [2 x i64] }, ptr %l16
  %t29 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v0, ptr %t26, ptr %t27, { i64, [2 x i64] } %t28)
  store %"compiler/scope:Val" %t29, ptr %l17
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %bb2
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca ptr
  %l31 = alloca i32
  %l35 = alloca i64
  %l38 = alloca i1
  %l41 = alloca i1
  %l48 = alloca i64
  %l54 = alloca i64
  %l62 = alloca { i64, ptr }
  %l64 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l100 = alloca i64
  %l103 = alloca i64
  %l111 = alloca i64
  %l114 = alloca i64
  %l136 = alloca i1
  %l141 = alloca i64
  %l144 = alloca { i64, ptr }
  %l148 = alloca { i64, [2 x i64] }
  %l152 = alloca i64
  %l155 = alloca { i64, ptr }
  %l158 = alloca { i64, [2 x i64] }
  %l167 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t12 = alloca { i64, [2 x i64] }, align 8
  %t44 = alloca { i64, [2 x i64] }, align 8
  %t63 = alloca { i64, [2 x i64] }, align 8
  %t77 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l25
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l25, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [2 x i64] }, ptr %t12, i32 0, i32 0
  store i64 0, ptr %t13
  %t14 = load { i64, [2 x i64] }, ptr %t12
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t14, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i32 %t20, ptr %l31
  br label %bb5
bb5:
  %t21 = load i32, ptr %l31, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Call", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t29 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t22, ptr %t26)
  store i64 %t29, ptr %l35
  br label %bb6
bb6:
  %t30 = load i64, ptr %l35, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp slt i64 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb10
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t35, i64 %t36)
  store i1 %t39, ptr %l41
  br label %bb9
bb9:
  %t40 = load i1, ptr %l41, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l38, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l38, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  store { i64, [2 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [2 x i64] }, ptr %t44, i32 0, i32 0
  store i64 0, ptr %t45
  %t46 = load { i64, [2 x i64] }, ptr %t44
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t46, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/scope:Scoper", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l3, !tbaa !23
  %t57 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t53, i32 %t54)
  store i64 %t57, ptr %l48
  br label %bb14
bb14:
  %t58 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t59 = load i64, ptr %l48, !tbaa !24
  %t61 = icmp eq i64 %t59, %t58
  br i1 %t61, label %bb15, label %bb16
bb15:
  store { i64, [2 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [2 x i64] }, ptr %t63, i32 0, i32 0
  store i64 0, ptr %t64
  %t65 = load { i64, [2 x i64] }, ptr %t63
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t65, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l54
  br label %bb18
bb18:
  %t72 = load i64, ptr %l54, !tbaa !24
  store i64 %t72, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  br i1 %t75, label %bb19, label %bb20
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [2 x i64] }, ptr %t77, i32 0, i32 0
  store i64 0, ptr %t78
  %t79 = load { i64, [2 x i64] }, ptr %t77
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t79, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t86, i32 %t87)
  store { i64, ptr } %t90, ptr %l62
  br label %bb22
bb22:
  %t91 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t91, ptr %l6, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l64, !tbaa !24
  %t95 = load i64, ptr %l64, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  br i1 %t96, label %bb23, label %bb24
bb23:
  %t98 = load i64, ptr %l64, !tbaa !24
  %t99 = icmp sle i64 %t98, 384307168202282325
  br i1 %t99, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ec2dd22d28cc6988_9d0975400b204864)
  unreachable
bb25:
  %t101 = load i64, ptr %l64, !tbaa !24
  %t102 = mul i64 %t101, 24
  %t103 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t102)
  %t104 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Call", ptr %t107, i32 0, i32 1
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  store i64 %t112, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ec2dd22d28cc6988_9d0975400b204864)
  unreachable
bb27:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb32
bb29:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l8, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l10, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l10, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l77, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb31
bb31:
  %t140 = load i64, ptr %l77, !tbaa !24
  store i64 %t140, ptr %l74, !tbaa !24
  br label %bb32
bb32:
  %t141 = load i64, ptr %l74, !tbaa !24
  store i64 %t141, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb33
bb33:
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb34, label %bb35
bb34:
  br label %bb65
bb35:
  br label %bb36
bb36:
  %t150 = load i64, ptr %l8, !tbaa !24
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l10, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l13, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/scope:Scoper", ptr %t160, i32 0, i32 0
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/generic:Program", ptr %t163, i32 0, i32 2
  %t166 = load i32, ptr %l3, !tbaa !23
  %t167 = load i64, ptr %l13, !tbaa !24
  %t171 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t165, i32 %t166, i64 %t167)
  store i64 %t171, ptr %l100
  br label %bb37
bb37:
  %t172 = load i64, ptr %l100, !tbaa !24
  store i64 %t172, ptr %l14, !tbaa !24
  %t173 = load i64, ptr %l14, !tbaa !24
  %t175 = icmp sge i64 %t173, 0
  br i1 %t175, label %bb38, label %bb39
bb38:
  %t177 = load i64, ptr %l14, !tbaa !24
  store i64 %t177, ptr %l103, !tbaa !24
  br label %bb40
bb39:
  %t179 = load i64, ptr %l13, !tbaa !24
  store i64 %t179, ptr %l103, !tbaa !24
  br label %bb40
bb40:
  %t181 = load i64, ptr %l103, !tbaa !24
  store i64 %t181, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  store i64 %t184, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t186 = load i64, ptr %l17, !tbaa !24
  %t187 = load i64, ptr %l16, !tbaa !24
  %t190 = icmp sgt i64 %t186, %t187
  br i1 %t190, label %bb41, label %bb42
bb41:
  %t192 = load i64, ptr %l18, !tbaa !24
  %t194 = icmp sgt i64 %t192, 0
  br i1 %t194, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb46
bb43:
  %t196 = load i64, ptr %l17, !tbaa !24
  %t197 = load i64, ptr %l16, !tbaa !24
  %t200 = sub i64 %t196, %t197
  %t201 = load i64, ptr %l18, !tbaa !24
  %t204 = add i64 %t200, %t201
  %t206 = sub i64 %t204, 1
  %t207 = load i64, ptr %l18, !tbaa !24
  %t210 = sdiv i64 %t206, %t207
  store i64 %t210, ptr %l114, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb45
bb45:
  %t212 = load i64, ptr %l114, !tbaa !24
  store i64 %t212, ptr %l111, !tbaa !24
  br label %bb46
bb46:
  %t213 = load i64, ptr %l111, !tbaa !24
  store i64 %t213, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb47
bb47:
  %t214 = load i64, ptr %l20, !tbaa !24
  %t215 = load i64, ptr %l19, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb48, label %bb49
bb48:
  br label %bb63
bb49:
  br label %bb50
bb50:
  %t222 = load i64, ptr %l16, !tbaa !24
  %t223 = load i64, ptr %l20, !tbaa !24
  %t224 = load i64, ptr %l18, !tbaa !24
  %t227 = mul i64 %t223, %t224
  %t230 = add i64 %t222, %t227
  store i64 %t230, ptr %l21, !tbaa !24
  %t232 = load i64, ptr %l21, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i64, ptr %t235, i64 %t232
  %t237 = load i64, ptr %t236, !tbaa !34
  %t238 = load i64, ptr %l15, !tbaa !24
  %t241 = icmp ne i64 %t237, %t238
  br i1 %t241, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb53
bb52:
  %t243 = load i64, ptr %l21, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr { i64, [2 x i64] }, ptr %t246, i64 %t243
  %t248 = load { i64, [2 x i64] }, ptr %t247
  %t250 = extractvalue { i64, [2 x i64] } %t248, 0
  %t251 = icmp eq i64 %t250, 0
  %t253 = xor i1 %t251, true
  store i1 %t253, ptr %l136, !tbaa !21
  br label %bb53
bb53:
  %t255 = load i1, ptr %l136, !tbaa !21
  br i1 %t255, label %bb54, label %bb55
bb54:
  br label %bb62
bb55:
  br label %bb56
bb56:
  %t256 = load i64, ptr %l21, !tbaa !24
  store i64 %t256, ptr %l141, !tbaa !24
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l2, !tbaa !29
  %t260 = getelementptr %"compiler/typed:Call", ptr %t258, i32 0, i32 1
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  store { i64, ptr } %t261, ptr %l144, !tbaa !27
  %t262 = load i64, ptr %l13, !tbaa !24
  %t264 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr ptr, ptr %t265, i64 %t262
  %t267 = load ptr, ptr %t266, !tbaa !39
  %t271 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %t257, ptr %t267)
  store { i64, [2 x i64] } %t271, ptr %l148
  br label %bb57
bb57:
  %t272 = load { i64, [2 x i64] }, ptr %l148
  %t273 = load i64, ptr %l141, !tbaa !24
  %t274 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr { i64, [2 x i64] }, ptr %t275, i64 %t273
  store { i64, [2 x i64] } %t272, ptr %t276
  %t277 = load i64, ptr %l21, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr { i64, [2 x i64] }, ptr %t280, i64 %t277
  %t282 = load { i64, [2 x i64] }, ptr %t281
  %t284 = extractvalue { i64, [2 x i64] } %t282, 0
  %t285 = icmp eq i64 %t284, 0
  br i1 %t285, label %bb58, label %bb59
bb58:
  %t287 = load i64, ptr %l21, !tbaa !24
  store i64 %t287, ptr %l152, !tbaa !24
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l2, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Call", ptr %t289, i32 0, i32 1
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  store { i64, ptr } %t292, ptr %l155, !tbaa !27
  %t293 = load i64, ptr %l13, !tbaa !24
  %t295 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr ptr, ptr %t296, i64 %t293
  %t298 = load ptr, ptr %t297, !tbaa !39
  %t301 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandTerm(ptr %v0, ptr %v1, ptr %t288, ptr %t298)
  store { i64, [2 x i64] } %t301, ptr %l158
  br label %bb60
bb59:
  br label %bb61
bb60:
  %t302 = load { i64, [2 x i64] }, ptr %l158
  %t303 = load i64, ptr %l152, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr { i64, [2 x i64] }, ptr %t305, i64 %t303
  store { i64, [2 x i64] } %t302, ptr %t306
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t307 = load i64, ptr %l20, !tbaa !24
  %t309 = add i64 %t307, 1
  store i64 %t309, ptr %l20, !tbaa !24
  br label %bb47
bb63:
  br label %bb64
bb64:
  %t311 = load i64, ptr %l12, !tbaa !24
  %t313 = add i64 %t311, 1
  store i64 %t313, ptr %l12, !tbaa !24
  br label %bb33
bb65:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load ptr, ptr %l2, !tbaa !29
  %t317 = load i64, ptr %l5, !tbaa !24
  %t318 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t323 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandByObligations(ptr %v0, ptr %v1, ptr %s0, ptr %t315, ptr %t316, i64 %t317, { i64, ptr } %t318)
  store { i64, [2 x i64] } %t323, ptr %l167
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  %t324 = load { i64, [2 x i64] }, ptr %l167
  store { i64, [2 x i64] } %t324, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca i1
  %l53 = alloca %"compiler/source:Span"
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 25
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d50f79fefbee4394_12c4367532f3ae80)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l18
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l17
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l7, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  store i64 %t31, ptr %l3, !tbaa !24
  %t33 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t34 = load i32, ptr %t33, !tbaa !23
  %t36 = sext i32 %t34 to i64
  store i64 %t36, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = icmp sgt i64 %t38, %t41
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t46, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l5
  br label %bb11
bb11:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  br label %bb31
bb13:
  br label %bb14
bb14:
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t58, ptr %l33, !tbaa !27
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = call i1 @compiler_2fscope_2eisNameChar(i8 %t64)
  store i1 %t66, ptr %l36
  br label %bb15
bb15:
  %t67 = load i1, ptr %l36, !tbaa !21
  br i1 %t67, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l3, !tbaa !24
  store i64 %t68, ptr %l6, !tbaa !24
  br label %bb18
bb17:
  br label %bb29
bb18:
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t76, ptr %l42, !tbaa !27
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 %t77
  %t82 = load i8, ptr %t81, !tbaa !32
  %t84 = call i1 @compiler_2fscope_2eisNameChar(i8 %t82)
  store i1 %t84, ptr %l45
  br label %bb21
bb20:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb21:
  %t85 = load i1, ptr %l45, !tbaa !21
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l41, !tbaa !21
  %t87 = xor i1 %t86, true
  br i1 %t87, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t89 = load i64, ptr %l3, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l3, !tbaa !24
  br label %bb26
bb26:
  br label %bb18
bb27:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = trunc i64 %t93 to i32
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = trunc i64 %t96 to i32
  %t101 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t95, i32 %t98)
  store %"compiler/source:Span" %t101, ptr %l53
  br label %bb28
bb28:
  %t102 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t102, ptr %l5
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb29:
  %t103 = load i64, ptr %l3, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l3, !tbaa !24
  br label %bb30
bb30:
  br label %bb11
bb31:
  %t107 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t107, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elentLoopCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l36 = alloca %"compiler/typed:Local"
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l8, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 3
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb27
bb6:
  %t23 = load ptr, ptr %l3, !tbaa !29
  store ptr %t23, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 8}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l4, !tbaa !23
  br label %bb11
bb10:
  br label %bb21
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l4, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t44 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %t38, i64 %t41)
  store i1 %t44, ptr %l24
  br label %bb12
bb12:
  %t45 = load i1, ptr %l24, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 25
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  br i1 %t52, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb20
bb15:
  call void @__olang_check_failed(ptr @olang_loc_42ddfa07d54a3511_7eb6b931dfed5aa5)
  unreachable
bb16:
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 25
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t57, i32 0, i32 7
  %t61 = load i32, ptr %l4, !tbaa !23
  %t63 = sext i32 %t61 to i64
  %t66 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t60, i64 %t63)
  store %"compiler/typed:Local" %t66, ptr %l36
  br label %bb18
bb18:
  %t67 = getelementptr %"compiler/typed:Local", ptr %l36, i32 0, i32 2
  %t68 = load i32, ptr %t67, !tbaa !23
  %t69 = load ptr, ptr %l26, !tbaa !29
  %t71 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t69, i32 %t68)
  store i1 %t71, ptr %l38
  br label %bb19
bb19:
  %t72 = load i1, ptr %l38, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l25, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load i1, ptr %l25, !tbaa !21
  store i1 %t75, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_133169b3f1711469_c566838c26ef218d)
  unreachable
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_31030507f1509b32_81bbcae78c23c7f6)
  unreachable
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elet(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca i32
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca %"compiler/scope:Val"
  %l12 = alloca %"compiler/scope:Val"
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l17 = alloca { i64, [2 x i64] }
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, [2 x i64] }
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca { i64, [2 x i64] }
  %l25 = alloca %"compiler/scope:Val"
  %l26 = alloca { i64, [2 x i64] }
  %l27 = alloca { i64, [2 x i64] }
  %l28 = alloca i64
  %l30 = alloca %"compiler/scope:Val"
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i64
  %l44 = alloca %"compiler/typed:Local"
  %l67 = alloca { i64, [2 x i64] }
  %l71 = alloca i1
  %l73 = alloca ptr
  %l78 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l79 = alloca i1
  %l83 = alloca { i64, [2 x i64] }
  %l87 = alloca { i64, [2 x i64] }
  %l90 = alloca ptr
  %l92 = alloca i64
  %l95 = alloca { i64, [2 x i64] }
  %l98 = alloca i1
  %l101 = alloca i1
  %l103 = alloca i1
  %l106 = alloca i1
  %l110 = alloca i1
  %l111 = alloca i1
  %l116 = alloca i1
  %l118 = alloca { i64, [2 x i64] }
  %l120 = alloca i1
  %l127 = alloca { i64, ptr }
  %l129 = alloca i64
  %l132 = alloca { i64, [1 x i64] }
  %l133 = alloca ptr
  %l134 = alloca { i64, [2 x i64] }
  %l135 = alloca %"compiler/source:Span"
  %l158 = alloca { i64, ptr }
  %l160 = alloca i64
  %l163 = alloca { i64, [1 x i64] }
  %l164 = alloca ptr
  %l165 = alloca { i64, [2 x i64] }
  %l169 = alloca %"compiler/source:Span"
  %l176 = alloca i64
  %l180 = alloca %"compiler/source:Span"
  %l184 = alloca %"compiler/scope:Val"
  %l185 = alloca ptr
  %l186 = alloca i32
  %l192 = alloca ptr
  %l193 = alloca { i64, [2 x i64] }
  %l194 = alloca { i64, [2 x i64] }
  %l197 = alloca i1
  %l198 = alloca i1
  %l201 = alloca i1
  %l208 = alloca i1
  %l213 = alloca %"compiler/scope:Val"
  %l217 = alloca i1
  %l220 = alloca i1
  %l223 = alloca i1
  %l224 = alloca i1
  %l226 = alloca i1
  %l227 = alloca i1
  %l229 = alloca i1
  %l236 = alloca { i64, ptr }
  %l238 = alloca i64
  %l241 = alloca { i64, [1 x i64] }
  %l244 = alloca i1
  %l249 = alloca i32
  %l252 = alloca i1
  %l255 = alloca ptr
  %l260 = alloca i1
  %l262 = alloca i1
  %l265 = alloca i1
  %l267 = alloca ptr
  %l269 = alloca i64
  %l280 = alloca i1
  %l283 = alloca i1
  %l286 = alloca ptr
  %l287 = alloca ptr
  %l288 = alloca i1
  %l293 = alloca ptr
  %l296 = alloca i32
  %l297 = alloca i1
  %l298 = alloca i1
  %l303 = alloca i1
  %l304 = alloca i1
  %l308 = alloca i1
  %l309 = alloca ptr
  %l311 = alloca i32
  %l314 = alloca { i64, [2 x i64] }
  %l317 = alloca %"compiler/source:Span"
  %l324 = alloca %"compiler/scope:Val"
  %l327 = alloca ptr
  %l329 = alloca i64
  %l330 = alloca ptr
  %l331 = alloca %"compiler/scope:Val"
  %l334 = alloca { i64, [2 x i64] }
  %l335 = alloca { i64, [2 x i64] }
  %l338 = alloca i1
  %l339 = alloca ptr
  %l343 = alloca i1
  %l344 = alloca ptr
  %l345 = alloca ptr
  %l348 = alloca { i64, [2 x i64] }
  %l349 = alloca %"compiler/scope:Val"
  %l358 = alloca { i64, [2 x i64] }
  %l362 = alloca i1
  %l369 = alloca i1
  %l384 = alloca ptr
  %l394 = alloca %"compiler/typed:Local"
  %l396 = alloca { i64, ptr }
  %l397 = alloca { i64, ptr }
  %l398 = alloca ptr
  %l399 = alloca ptr
  %l401 = alloca %"compiler/source:Span"
  %l405 = alloca ptr
  %l415 = alloca %"compiler/typed:Local"
  %l417 = alloca { i64, ptr }
  %l418 = alloca %"compiler/source:Span"
  %l421 = alloca %"compiler/msgs:Msg"
  %l422 = alloca i64
  %l425 = alloca { i64, [2 x i64] }
  %l434 = alloca ptr
  %l437 = alloca { i64, [2 x i64] }
  %l439 = alloca { i64, [2 x i64] }
  %l442 = alloca { i64, [2 x i64] }
  %l445 = alloca i1
  %l446 = alloca i1
  %l450 = alloca i1
  %l454 = alloca ptr
  %l460 = alloca i1
  %l461 = alloca i1
  %l464 = alloca ptr
  %l465 = alloca i1
  %l472 = alloca i1
  %l473 = alloca i1
  %l476 = alloca i1
  %l478 = alloca ptr
  %l480 = alloca i64
  %l483 = alloca { i64, [2 x i64] }
  %l489 = alloca { i64, [2 x i64] }
  %l493 = alloca { i64, [2 x i64] }
  %l497 = alloca ptr
  %l499 = alloca i1
  %l502 = alloca i1
  %l506 = alloca ptr
  %l508 = alloca i1
  %l511 = alloca i64
  %l517 = alloca %"compiler/scope:Val"
  %l521 = alloca ptr
  %l523 = alloca i64
  %l530 = alloca i1
  %l531 = alloca i1
  %l535 = alloca i1
  %l544 = alloca ptr
  %l545 = alloca i32
  %l550 = alloca ptr
  %l552 = alloca i64
  %l556 = alloca { i64, [2 x i64] }
  %l557 = alloca ptr
  %l558 = alloca i32
  %l562 = alloca i1
  %l568 = alloca { i64, [2 x i64] }
  %l573 = alloca { i64, [2 x i64] }
  %l574 = alloca i32
  %l590 = alloca i1
  %l593 = alloca i64
  %l596 = alloca i64
  %l598 = alloca i1
  %l604 = alloca i1
  %l605 = alloca ptr
  %l611 = alloca ptr
  %l612 = alloca ptr
  %l616 = alloca %"compiler/source:Span"
  %l617 = alloca %"compiler/source:Span"
  %l618 = alloca %"compiler/msgs:Msg"
  %l619 = alloca i64
  %l627 = alloca i1
  %l630 = alloca i1
  %l631 = alloca i1
  %l632 = alloca ptr
  %l636 = alloca i1
  %l642 = alloca %"compiler/scope:Val"
  %l644 = alloca ptr
  %l645 = alloca i32
  %l656 = alloca i1
  %l659 = alloca ptr
  %l660 = alloca { i64, [2 x i64] }
  %l661 = alloca { i64, [2 x i64] }
  %l662 = alloca i1
  %l665 = alloca ptr
  %l667 = alloca i64
  %l673 = alloca i1
  %l676 = alloca i1
  %l677 = alloca i1
  %l678 = alloca ptr
  %l682 = alloca i1
  %l690 = alloca i1
  %l693 = alloca i1
  %l696 = alloca i1
  %l697 = alloca ptr
  %l698 = alloca ptr
  %l702 = alloca %"compiler/source:Span"
  %l703 = alloca %"compiler/msgs:Msg"
  %l704 = alloca i64
  %l707 = alloca i1
  %l710 = alloca i1
  %l711 = alloca { i64, [2 x i64] }
  %l713 = alloca { i64, [2 x i64] }
  %l715 = alloca i1
  %l717 = alloca i1
  %l719 = alloca i1
  %l722 = alloca ptr
  %l723 = alloca { i64, [2 x i64] }
  %l724 = alloca { i64, [2 x i64] }
  %l734 = alloca i1
  %l740 = alloca i1
  %l742 = alloca i64
  %l750 = alloca ptr
  %l751 = alloca { i64, [2 x i64] }
  %l752 = alloca { i64, [2 x i64] }
  %l753 = alloca i1
  %s0 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %t57 = alloca { i64, [2 x i64] }, align 8
  %t380 = alloca { i64, [2 x i64] }, align 8
  %t518 = alloca { i64, [2 x i64] }, align 8
  %t620 = alloca { i64, [2 x i64] }, align 8
  %t687 = alloca { i64, [2 x i64] }, align 8
  %t733 = alloca { i64, [2 x i64] }, align 8
  %t1047 = alloca { i64, [2 x i64] }, align 8
  %t1114 = alloca { i64, [2 x i64] }, align 8
  %t1182 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_16a749f285461106_b0e7908cc5ae695a)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t15 = load i32, ptr %l2, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t20 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %t17)
  store %"compiler/typed:Local" %t20, ptr %l44
  br label %bb4
bb4:
  %t21 = load %"compiler/typed:Local", ptr %l44
  store %"compiler/typed:Local" %t21, ptr %l4
  %t22 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  store i32 %t23, ptr %l5, !tbaa !23
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 42
  %t34 = load i32, ptr %l2, !tbaa !23
  %t36 = sext i32 %t34 to i64
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %t33, i64 %t36, ptr %t37)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 102
  %t44 = load { i64, [2 x i64] }, ptr %t43
  store { i64, [2 x i64] } %t44, ptr %l6
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 103
  %t49 = load i1, ptr %t48, !tbaa !21
  store i1 %t49, ptr %l7, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/scope:Scoper", ptr %t51, i32 0, i32 106
  %t54 = load i1, ptr %t53, !tbaa !21
  store i1 %t54, ptr %l8, !tbaa !21
  %t56 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [2 x i64] }, ptr %t57, i32 0, i32 0
  store i64 0, ptr %t58
  %t59 = load { i64, [2 x i64] }, ptr %t57
  %t62 = getelementptr %"compiler/scope:Scoper", ptr %t56, i32 0, i32 102
  store { i64, [2 x i64] } %t59, ptr %t62
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 103
  store i1 false, ptr %t65, !tbaa !21
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 106
  store i1 false, ptr %t68, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t72 = sext i32 %t70 to i64
  %t75 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftOf(ptr %v0, ptr %t69, i64 %t72)
  store { i64, [2 x i64] } %t75, ptr %l67
  br label %bb9
bb9:
  %t76 = load { i64, [2 x i64] }, ptr %l67
  store { i64, [2 x i64] } %t76, ptr %l9
  %t77 = load { i64, [2 x i64] }, ptr %l9
  %t79 = extractvalue { i64, [2 x i64] } %t77, 0
  %t80 = icmp eq i64 %t79, 0
  %t82 = xor i1 %t80, true
  br i1 %t82, label %bb10, label %bb11
bb10:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/scope:Scoper", ptr %t84, i32 0, i32 127
  store ptr %t86, ptr %l73, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/scope:Scoper", ptr %t87, i32 0, i32 26
  %t90 = load i64, ptr %t89, !tbaa !24
  %t91 = load i32, ptr %l2, !tbaa !23
  %t93 = sext i32 %t91 to i64
  %t96 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t90, i64 %t93)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t96, ptr %l78
  br label %bb12
bb11:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb14
bb12:
  %t97 = load ptr, ptr %l73, !tbaa !29
  %t98 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l78
  %t99 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t97, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t98)
  store i1 %t99, ptr %l79
  br label %bb13
bb13:
  %t100 = load i1, ptr %l79, !tbaa !21
  store i1 %t100, ptr %l71, !tbaa !21
  br label %bb14
bb14:
  %t101 = load i1, ptr %l71, !tbaa !21
  br i1 %t101, label %bb15, label %bb16
bb15:
  %t102 = load { i64, [2 x i64] }, ptr %l6
  %t104 = extractvalue { i64, [2 x i64] } %t102, 0
  %t105 = icmp eq i64 %t104, 0
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb17, label %bb18
bb16:
  br label %bb21
bb17:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load { i64, [2 x i64] }, ptr %l6
  %t111 = load { i64, [2 x i64] }, ptr %l9
  %t115 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoinTerm(ptr %v0, ptr %t109, { i64, [2 x i64] } %t110, { i64, [2 x i64] } %t111)
  store { i64, [2 x i64] } %t115, ptr %l87
  br label %bb19
bb18:
  %t116 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t116, ptr %l83
  br label %bb20
bb19:
  %t118 = load { i64, [2 x i64] }, ptr %l87
  store { i64, [2 x i64] } %t118, ptr %l83
  br label %bb20
bb20:
  %t119 = load { i64, [2 x i64] }, ptr %l83
  store { i64, [2 x i64] } %t119, ptr %l6
  br label %bb21
bb21:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/scope:Scoper", ptr %t120, i32 0, i32 32
  store ptr %t122, ptr %l90, !tbaa !29
  %t123 = load i32, ptr %l2, !tbaa !23
  %t125 = sext i32 %t123 to i64
  store i64 %t125, ptr %l92, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t128 = load i32, ptr %t127, !tbaa !23
  %t131 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t126, i32 %t128)
  store { i64, [2 x i64] } %t131, ptr %l95
  br label %bb22
bb22:
  %t132 = load ptr, ptr %l90, !tbaa !29
  %t133 = load i64, ptr %l92, !tbaa !24
  %t134 = load { i64, [2 x i64] }, ptr %l95
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t132, i64 %t133, { i64, [2 x i64] } %t134)
  br label %bb23
bb23:
  %t135 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t136 = load i32, ptr %t135, !range !{i32 0, i32 7}
  %t138 = trunc i64 6 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb24, label %bb25
bb24:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i32, ptr %l5, !tbaa !23
  %t145 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t141, i32 %t142)
  store i1 %t145, ptr %l101
  br label %bb26
bb25:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb27
bb26:
  %t146 = load i1, ptr %l101, !tbaa !21
  %t147 = xor i1 %t146, true
  store i1 %t147, ptr %l98, !tbaa !21
  br label %bb27
bb27:
  %t149 = load i1, ptr %l98, !tbaa !21
  br i1 %t149, label %bb28, label %bb29
bb28:
  %t150 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t151 = load i32, ptr %t150, !tbaa !23
  %t153 = icmp eq i32 %t151, 0
  store i1 %t153, ptr %l103, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb30
bb30:
  %t155 = load i1, ptr %l103, !tbaa !21
  br i1 %t155, label %bb31, label %bb32
bb31:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i32, ptr %l2, !tbaa !23
  %t159 = sext i32 %t157 to i64
  %t162 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowed(ptr %v0, ptr %t156, i64 %t159)
  store i1 %t162, ptr %l110
  br label %bb33
bb32:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb38
bb33:
  %t163 = load i1, ptr %l110, !tbaa !21
  br i1 %t163, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb37
bb35:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/scope:Scoper", ptr %t164, i32 0, i32 0
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  %t170 = load i32, ptr %l5, !tbaa !23
  %t173 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t169, i32 %t170)
  store i1 %t173, ptr %l116
  br label %bb36
bb36:
  %t174 = load i1, ptr %l116, !tbaa !21
  store i1 %t174, ptr %l111, !tbaa !21
  br label %bb37
bb37:
  %t175 = load i1, ptr %l111, !tbaa !21
  store i1 %t175, ptr %l106, !tbaa !21
  br label %bb38
bb38:
  %t176 = load i1, ptr %l106, !tbaa !21
  br i1 %t176, label %bb39, label %bb40
bb39:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t177, i32 0)
  store { i64, [2 x i64] } %t179, ptr %l118
  br label %bb41
bb40:
  br label %bb52
bb41:
  %t180 = load { i64, [2 x i64] }, ptr %l118
  store { i64, [2 x i64] } %t180, ptr %l10
  %t181 = load { i64, [2 x i64] }, ptr %l10
  %t183 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t181)
  store i1 %t183, ptr %l120
  br label %bb42
bb42:
  %t184 = load i1, ptr %l120, !tbaa !21
  br i1 %t184, label %bb43, label %bb44
bb43:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/scope:Scoper", ptr %t185, i32 0, i32 32
  %t188 = load i32, ptr %l2, !tbaa !23
  %t190 = sext i32 %t188 to i64
  %t191 = load { i64, [2 x i64] }, ptr %l10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t187, i64 %t190, { i64, [2 x i64] } %t191)
  br label %bb45
bb44:
  br label %bb51
bb45:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/scope:Scoper", ptr %t195, i32 0, i32 30
  %t198 = getelementptr %"compiler/typed:Plan", ptr %t197, i32 0, i32 1
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  store { i64, ptr } %t199, ptr %l127, !tbaa !27
  %t200 = load i32, ptr %l2, !tbaa !23
  %t202 = sext i32 %t200 to i64
  store i64 %t202, ptr %l129, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load { i64, [2 x i64] }, ptr %l10
  %t207 = call { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %t203, { i64, [2 x i64] } %t204)
  store { i64, [1 x i64] } %t207, ptr %l132
  br label %bb46
bb46:
  %t208 = load { i64, [1 x i64] }, ptr %l132
  %t209 = load i64, ptr %l129, !tbaa !24
  %t210 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr { i64, [1 x i64] }, ptr %t211, i64 %t209
  store { i64, [1 x i64] } %t208, ptr %t212
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l133, !tbaa !29
  %t214 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t214, ptr %l134
  %t215 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t215, ptr %l135
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/scope:Scoper", ptr %t216, i32 0, i32 25
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = icmp eq ptr %t219, null
  br i1 %t221, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_18c7df235ed333ed_6cb02ce97018ae1)
  unreachable
bb48:
  br label %bb49
bb49:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/scope:Scoper", ptr %t223, i32 0, i32 25
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t229 = getelementptr %"compiler/typed:Body", ptr %t226, i32 0, i32 3
  %t230 = load i64, ptr %t229, !tbaa !24
  %t231 = load %"compiler/source:Span", ptr %l1
  %t232 = load ptr, ptr %l133, !tbaa !29
  %t233 = load { i64, [2 x i64] }, ptr %l134
  %t234 = load %"compiler/source:Span", ptr %l135
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t232, { i64, [2 x i64] } %t233, %"compiler/source:Span" %t234, i64 %t230, %"compiler/source:Span" %t231)
  br label %bb50
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t237 = load { i64, [2 x i64] }, ptr %l6
  %t239 = extractvalue { i64, [2 x i64] } %t237, 0
  %t240 = icmp eq i64 %t239, 0
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb53, label %bb54
bb53:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/scope:Scoper", ptr %t244, i32 0, i32 31
  %t247 = load i32, ptr %l2, !tbaa !23
  %t249 = sext i32 %t247 to i64
  %t250 = load { i64, [2 x i64] }, ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t246, i64 %t249, { i64, [2 x i64] } %t250)
  br label %bb55
bb54:
  br label %bb87
bb55:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/scope:Scoper", ptr %t254, i32 0, i32 32
  %t257 = load i32, ptr %l2, !tbaa !23
  %t259 = sext i32 %t257 to i64
  %t260 = load { i64, [2 x i64] }, ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t256, i64 %t259, { i64, [2 x i64] } %t260)
  br label %bb56
bb56:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/scope:Scoper", ptr %t264, i32 0, i32 30
  %t267 = getelementptr %"compiler/typed:Plan", ptr %t266, i32 0, i32 1
  %t268 = load { i64, ptr }, ptr %t267, !tbaa !27
  store { i64, ptr } %t268, ptr %l158, !tbaa !27
  %t269 = load i32, ptr %l2, !tbaa !23
  %t271 = sext i32 %t269 to i64
  store i64 %t271, ptr %l160, !tbaa !24
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load { i64, [2 x i64] }, ptr %l6
  %t276 = call { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %t272, { i64, [2 x i64] } %t273)
  store { i64, [1 x i64] } %t276, ptr %l163
  br label %bb57
bb57:
  %t277 = load { i64, [1 x i64] }, ptr %l163
  %t278 = load i64, ptr %l160, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr { i64, [1 x i64] }, ptr %t280, i64 %t278
  store { i64, [1 x i64] } %t277, ptr %t281
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l164, !tbaa !29
  %t283 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t283, ptr %l165
  %t284 = load ptr, ptr %l3, !tbaa !29
  %t286 = icmp eq ptr %t284, null
  br i1 %t286, label %bb58, label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_732b86ec1c46a4d8_efc842c6ef92792c)
  unreachable
bb59:
  br label %bb60
bb60:
  %t288 = load ptr, ptr %l3, !tbaa !29
  %t290 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t288)
  store %"compiler/source:Span" %t290, ptr %l169
  br label %bb61
bb61:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/scope:Scoper", ptr %t291, i32 0, i32 25
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = icmp eq ptr %t294, null
  br i1 %t296, label %bb62, label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_732b86ec1c46a4d8_efc842c6ef92792c)
  unreachable
bb63:
  br label %bb64
bb64:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/scope:Scoper", ptr %t298, i32 0, i32 25
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t304 = getelementptr %"compiler/typed:Body", ptr %t301, i32 0, i32 3
  %t305 = load i64, ptr %t304, !tbaa !24
  store i64 %t305, ptr %l176, !tbaa !24
  %t306 = load ptr, ptr %l3, !tbaa !29
  %t308 = icmp eq ptr %t306, null
  br i1 %t308, label %bb65, label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_732b86ec1c46a4d8_efc842c6ef92792c)
  unreachable
bb66:
  br label %bb67
bb67:
  %t310 = load ptr, ptr %l3, !tbaa !29
  %t312 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t310)
  store %"compiler/source:Span" %t312, ptr %l180
  br label %bb68
bb68:
  %t313 = load ptr, ptr %l164, !tbaa !29
  %t314 = load { i64, [2 x i64] }, ptr %l165
  %t315 = load %"compiler/source:Span", ptr %l169
  %t316 = load i64, ptr %l176, !tbaa !24
  %t317 = load %"compiler/source:Span", ptr %l180
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t313, { i64, [2 x i64] } %t314, %"compiler/source:Span" %t315, i64 %t316, %"compiler/source:Span" %t317)
  br label %bb69
bb69:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load ptr, ptr %l3, !tbaa !29
  %t320 = load { i64, [2 x i64] }, ptr %l6
  %t324 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t318, ptr %t319, { i64, [2 x i64] } %t320)
  store %"compiler/scope:Val" %t324, ptr %l184
  br label %bb70
bb70:
  %t325 = load %"compiler/scope:Val", ptr %l184
  store %"compiler/scope:Val" %t325, ptr %l11
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l185, !tbaa !29
  %t327 = load i32, ptr %l2, !tbaa !23
  store i32 %t327, ptr %l186, !tbaa !23
  %t328 = load ptr, ptr %l3, !tbaa !29
  %t330 = icmp eq ptr %t328, null
  br i1 %t330, label %bb71, label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_32a69b93b2b7f4f7_279e7ae047adaf1b)
  unreachable
bb72:
  br label %bb73
bb73:
  %t332 = load ptr, ptr %l3, !tbaa !29
  %t333 = load ptr, ptr %l185, !tbaa !29
  %t334 = load i32, ptr %l186, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %t333, i32 %t334, ptr %t332)
  br label %bb74
bb74:
  %t336 = getelementptr %"compiler/scope:Val", ptr %l11, i32 0, i32 0
  %t337 = load i32, ptr %t336, !range !{i32 0, i32 5}
  %t339 = trunc i64 3 to i32
  %t340 = icmp eq i32 %t337, %t339
  br i1 %t340, label %bb75, label %bb76
bb75:
  %t342 = load ptr, ptr %l0, !tbaa !29
  store ptr %t342, ptr %l192, !tbaa !29
  %t343 = getelementptr %"compiler/scope:Val", ptr %l11, i32 0, i32 1
  %t344 = load { i64, [2 x i64] }, ptr %t343
  store { i64, [2 x i64] } %t344, ptr %l193
  %t345 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t345, ptr %l194
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load i32, ptr %l5, !tbaa !23
  %t350 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t346, i32 %t347)
  store i1 %t350, ptr %l197
  br label %bb77
bb76:
  br label %bb86
bb77:
  %t351 = load i1, ptr %l197, !tbaa !21
  br i1 %t351, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l198, !tbaa !21
  br label %bb81
bb79:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i32, ptr %l5, !tbaa !23
  %t356 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t352, i32 %t353)
  store i1 %t356, ptr %l201
  br label %bb80
bb80:
  %t357 = load i1, ptr %l201, !tbaa !21
  store i1 %t357, ptr %l198, !tbaa !21
  br label %bb81
bb81:
  %t358 = load ptr, ptr %l3, !tbaa !29
  %t360 = icmp eq ptr %t358, null
  br i1 %t360, label %bb82, label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_cbe9d007f71e6f0a_66029137d6521816)
  unreachable
bb83:
  br label %bb84
bb84:
  %t362 = load ptr, ptr %l3, !tbaa !29
  %t363 = load i64, ptr @G_2ecompiler_2fscope_2eFitLocal, !tbaa !24
  %t364 = load ptr, ptr %l192, !tbaa !29
  %t365 = load { i64, [2 x i64] }, ptr %l193
  %t366 = load { i64, [2 x i64] }, ptr %l194
  %t367 = load i1, ptr %l198, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t364, { i64, [2 x i64] } %t365, { i64, [2 x i64] } %t366, i1 %t367, ptr %t362, i64 %t363)
  br label %bb85
bb85:
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb87:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load i32, ptr %l5, !tbaa !23
  %t374 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t370, i32 %t371)
  store i1 %t374, ptr %l208
  br label %bb88
bb88:
  %t375 = load i1, ptr %l208, !tbaa !21
  %t376 = xor i1 %t375, true
  br i1 %t376, label %bb89, label %bb90
bb89:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load ptr, ptr %l3, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t380
  %t381 = getelementptr { i64, [2 x i64] }, ptr %t380, i32 0, i32 0
  store i64 0, ptr %t381
  %t382 = load { i64, [2 x i64] }, ptr %t380
  %t386 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t378, ptr %t379, { i64, [2 x i64] } %t382)
  store %"compiler/scope:Val" %t386, ptr %l213
  br label %bb91
bb90:
  br label %bb112
bb91:
  %t387 = load %"compiler/scope:Val", ptr %l213
  store %"compiler/scope:Val" %t387, ptr %l12
  %t388 = load ptr, ptr %l3, !tbaa !29
  %t390 = icmp eq ptr %t388, null
  %t392 = xor i1 %t390, true
  br i1 %t392, label %bb92, label %bb93
bb92:
  %t394 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 0
  %t395 = load i32, ptr %t394, !range !{i32 0, i32 5}
  %t397 = trunc i64 3 to i32
  %t398 = icmp eq i32 %t395, %t397
  store i1 %t398, ptr %l217, !tbaa !21
  br label %bb94
bb93:
  store i1 false, ptr %l217, !tbaa !21
  br label %bb94
bb94:
  %t400 = load i1, ptr %l217, !tbaa !21
  br i1 %t400, label %bb95, label %bb96
bb95:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load i32, ptr %l5, !tbaa !23
  %t405 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t401, i32 %t402)
  store i1 %t405, ptr %l223
  br label %bb97
bb96:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb98
bb97:
  %t406 = load i1, ptr %l223, !tbaa !21
  store i1 %t406, ptr %l220, !tbaa !21
  br label %bb98
bb98:
  %t407 = load i1, ptr %l220, !tbaa !21
  br i1 %t407, label %bb99, label %bb100
bb99:
  %t408 = load ptr, ptr %l3, !tbaa !29
  %t410 = call i1 @compiler_2ftyped_2eScopedArray(ptr %v1, ptr %t408)
  store i1 %t410, ptr %l226
  br label %bb101
bb100:
  store i1 false, ptr %l224, !tbaa !21
  br label %bb102
bb101:
  %t411 = load i1, ptr %l226, !tbaa !21
  store i1 %t411, ptr %l224, !tbaa !21
  br label %bb102
bb102:
  %t412 = load i1, ptr %l224, !tbaa !21
  br i1 %t412, label %bb103, label %bb104
bb103:
  %t413 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t414 = load { i64, [2 x i64] }, ptr %t413
  %t416 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t414)
  store i1 %t416, ptr %l229
  br label %bb105
bb104:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb106
bb105:
  %t417 = load i1, ptr %l229, !tbaa !21
  store i1 %t417, ptr %l227, !tbaa !21
  br label %bb106
bb106:
  %t418 = load i1, ptr %l227, !tbaa !21
  br i1 %t418, label %bb107, label %bb108
bb107:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr %"compiler/scope:Scoper", ptr %t419, i32 0, i32 32
  %t422 = load i32, ptr %l2, !tbaa !23
  %t424 = sext i32 %t422 to i64
  %t425 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t426 = load { i64, [2 x i64] }, ptr %t425
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t421, i64 %t424, { i64, [2 x i64] } %t426)
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/scope:Scoper", ptr %t430, i32 0, i32 30
  %t433 = getelementptr %"compiler/typed:Plan", ptr %t432, i32 0, i32 1
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  store { i64, ptr } %t434, ptr %l236, !tbaa !27
  %t435 = load i32, ptr %l2, !tbaa !23
  %t437 = sext i32 %t435 to i64
  store i64 %t437, ptr %l238, !tbaa !24
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t440 = load { i64, [2 x i64] }, ptr %t439
  %t443 = call { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %t438, { i64, [2 x i64] } %t440)
  store { i64, [1 x i64] } %t443, ptr %l241
  br label %bb110
bb110:
  %t444 = load { i64, [1 x i64] }, ptr %l241
  %t445 = load i64, ptr %l238, !tbaa !24
  %t446 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr { i64, [1 x i64] }, ptr %t447, i64 %t445
  store { i64, [1 x i64] } %t444, ptr %t448
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb112:
  %t449 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t450 = load i32, ptr %t449, !range !{i32 0, i32 7}
  %t452 = trunc i64 3 to i32
  %t453 = icmp eq i32 %t450, %t452
  br i1 %t453, label %bb113, label %bb114
bb113:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/scope:Scoper", ptr %t455, i32 0, i32 0
  %t458 = load ptr, ptr %t457, !tbaa !29
  %t460 = getelementptr %"compiler/generic:Program", ptr %t458, i32 0, i32 2
  %t461 = load i32, ptr %l5, !tbaa !23
  %t464 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t460, i32 %t461)
  store i32 %t464, ptr %l249
  br label %bb115
bb114:
  store i1 false, ptr %l244, !tbaa !21
  br label %bb116
bb115:
  %t465 = load i32, ptr %l249, !range !{i32 0, i32 33}
  %t467 = trunc i64 22 to i32
  %t468 = icmp eq i32 %t465, %t467
  store i1 %t468, ptr %l244, !tbaa !21
  br label %bb116
bb116:
  %t470 = load i1, ptr %l244, !tbaa !21
  br i1 %t470, label %bb117, label %bb118
bb117:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load ptr, ptr %l3, !tbaa !29
  %t475 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %s0, ptr %t471, ptr %t472)
  store ptr %t475, ptr %l255
  br label %bb119
bb118:
  store i1 false, ptr %l252, !tbaa !21
  br label %bb120
bb119:
  %t476 = load ptr, ptr %l255, !tbaa !29
  %t477 = icmp eq ptr %t476, null
  %t479 = xor i1 %t477, true
  store i1 %t479, ptr %l252, !tbaa !21
  br label %bb120
bb120:
  %t481 = load i1, ptr %l252, !tbaa !21
  store i1 %t481, ptr %l13, !tbaa !21
  %t482 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t483 = load i32, ptr %t482, !range !{i32 0, i32 7}
  %t485 = trunc i64 2 to i32
  %t486 = icmp eq i32 %t483, %t485
  br i1 %t486, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l260, !tbaa !21
  br label %bb123
bb122:
  %t488 = load i1, ptr %l13, !tbaa !21
  store i1 %t488, ptr %l260, !tbaa !21
  br label %bb123
bb123:
  %t490 = load i1, ptr %l260, !tbaa !21
  br i1 %t490, label %bb124, label %bb125
bb124:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load ptr, ptr %l3, !tbaa !29
  %t495 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t491, ptr %t492)
  store i1 %t495, ptr %l265
  br label %bb126
bb125:
  store i1 false, ptr %l262, !tbaa !21
  br label %bb127
bb126:
  %t496 = load i1, ptr %l265, !tbaa !21
  store i1 %t496, ptr %l262, !tbaa !21
  br label %bb127
bb127:
  %t497 = load i1, ptr %l262, !tbaa !21
  br i1 %t497, label %bb128, label %bb129
bb128:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = getelementptr %"compiler/scope:Scoper", ptr %t498, i32 0, i32 40
  store ptr %t500, ptr %l267, !tbaa !29
  %t501 = load i32, ptr %l2, !tbaa !23
  %t503 = sext i32 %t501 to i64
  store i64 %t503, ptr %l269, !tbaa !24
  %t504 = load ptr, ptr %l3, !tbaa !29
  %t506 = icmp eq ptr %t504, null
  br i1 %t506, label %bb130, label %bb131
bb129:
  br label %bb135
bb130:
  call void @__olang_check_failed(ptr @olang_loc_d999d01787ae8811_e9a058a4efe4c7fd)
  unreachable
bb131:
  br label %bb132
bb132:
  %t508 = load ptr, ptr %l3, !tbaa !29
  %t509 = load ptr, ptr %l267, !tbaa !29
  %t510 = load i64, ptr %l269, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %t509, i64 %t510, ptr %t508)
  br label %bb133
bb133:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = getelementptr %"compiler/scope:Scoper", ptr %t512, i32 0, i32 31
  %t515 = load i32, ptr %l2, !tbaa !23
  %t517 = sext i32 %t515 to i64
  store { i64, [2 x i64] } zeroinitializer, ptr %t518
  %t519 = getelementptr { i64, [2 x i64] }, ptr %t518, i32 0, i32 0
  store i64 0, ptr %t519
  %t520 = load { i64, [2 x i64] }, ptr %t518
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t514, i64 %t517, { i64, [2 x i64] } %t520)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb135:
  %t524 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t525 = load i32, ptr %t524, !range !{i32 0, i32 7}
  %t527 = trunc i64 3 to i32
  %t528 = icmp eq i32 %t525, %t527
  br i1 %t528, label %bb136, label %bb137
bb136:
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load i32, ptr %l5, !tbaa !23
  %t534 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t530, i32 %t531)
  store i1 %t534, ptr %l283
  br label %bb138
bb137:
  store i1 false, ptr %l280, !tbaa !21
  br label %bb139
bb138:
  %t535 = load i1, ptr %l283, !tbaa !21
  store i1 %t535, ptr %l280, !tbaa !21
  br label %bb139
bb139:
  %t536 = load i1, ptr %l280, !tbaa !21
  br i1 %t536, label %bb140, label %bb141
bb140:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = load ptr, ptr %l3, !tbaa !29
  %t541 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v0, ptr %t537, ptr %t538)
  store ptr %t541, ptr %l286
  br label %bb142
bb141:
  br label %bb174
bb142:
  %t542 = load ptr, ptr %l286, !tbaa !29
  store ptr %t542, ptr %l14, !tbaa !29
  %t543 = load ptr, ptr %l14, !tbaa !29
  store ptr %t543, ptr %l287, !tbaa !29
  store i1 false, ptr %l288, !tbaa !21
  %t544 = load ptr, ptr %l287, !tbaa !29
  %t545 = icmp ne ptr %t544, null
  br i1 %t545, label %bb143, label %bb144
bb143:
  %t547 = load ptr, ptr %l287, !tbaa !29
  %t548 = load i64, ptr %t547, !range !{i64 0, i64 18}
  %t550 = icmp eq i64 %t548, 5
  store i1 %t550, ptr %l288, !tbaa !21
  br label %bb144
bb144:
  %t551 = load i1, ptr %l288, !tbaa !21
  br i1 %t551, label %bb145, label %bb146
bb145:
  %t552 = load ptr, ptr %l14, !tbaa !29
  %t554 = getelementptr { i64, [5 x i64] }, ptr %t552, i32 0, i32 1
  %t555 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t554, i32 0, i32 2
  %t556 = load ptr, ptr %t555
  store ptr %t556, ptr %l15, !tbaa !29
  br label %bb147
bb146:
  br label %bb168
bb147:
  %t558 = load ptr, ptr %l0, !tbaa !29
  store ptr %t558, ptr %l293, !tbaa !29
  %t559 = load ptr, ptr %l15, !tbaa !29
  %t561 = getelementptr %"compiler/typed:Promote", ptr %t559, i32 0, i32 0
  %t562 = load ptr, ptr %t561, !tbaa !29
  %t564 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t562)
  store i32 %t564, ptr %l296
  br label %bb148
bb148:
  %t565 = load ptr, ptr %l293, !tbaa !29
  %t566 = load i32, ptr %l296, !tbaa !23
  %t567 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t565, i32 %t566)
  store i1 %t567, ptr %l297
  br label %bb149
bb149:
  %t568 = load i1, ptr %l297, !tbaa !21
  br i1 %t568, label %bb150, label %bb151
bb150:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load ptr, ptr %l15, !tbaa !29
  %t572 = getelementptr %"compiler/typed:Promote", ptr %t570, i32 0, i32 0
  %t573 = load ptr, ptr %t572, !tbaa !29
  %t577 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v0, ptr %t569, ptr %t573)
  store i1 %t577, ptr %l303
  br label %bb152
bb151:
  store i1 false, ptr %l298, !tbaa !21
  br label %bb153
bb152:
  %t578 = load i1, ptr %l303, !tbaa !21
  store i1 %t578, ptr %l298, !tbaa !21
  br label %bb153
bb153:
  %t579 = load i1, ptr %l298, !tbaa !21
  br i1 %t579, label %bb154, label %bb155
bb154:
  %t580 = load ptr, ptr %l0, !tbaa !29
  %t581 = load ptr, ptr %l15, !tbaa !29
  %t583 = getelementptr %"compiler/typed:Promote", ptr %t581, i32 0, i32 0
  %t584 = load ptr, ptr %t583, !tbaa !29
  %t587 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLands(ptr %v0, ptr %v0, ptr %t580, ptr %t584)
  store i1 %t587, ptr %l308
  br label %bb156
bb155:
  store i1 false, ptr %l304, !tbaa !21
  br label %bb157
bb156:
  %t588 = load i1, ptr %l308, !tbaa !21
  store i1 %t588, ptr %l304, !tbaa !21
  br label %bb157
bb157:
  %t589 = load i1, ptr %l304, !tbaa !21
  br i1 %t589, label %bb158, label %bb159
bb158:
  %t590 = load ptr, ptr %l0, !tbaa !29
  store ptr %t590, ptr %l309, !tbaa !29
  %t591 = load ptr, ptr %l15, !tbaa !29
  %t593 = getelementptr %"compiler/typed:Promote", ptr %t591, i32 0, i32 1
  %t594 = load i32, ptr %t593, !tbaa !23
  store i32 %t594, ptr %l311, !tbaa !23
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t597 = load i32, ptr %t596, !tbaa !23
  %t600 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t595, i32 %t597)
  store { i64, [2 x i64] } %t600, ptr %l314
  br label %bb160
bb159:
  br label %bb167
bb160:
  %t601 = load ptr, ptr %l15, !tbaa !29
  %t603 = getelementptr %"compiler/typed:Promote", ptr %t601, i32 0, i32 0
  %t604 = load ptr, ptr %t603, !tbaa !29
  %t606 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t604)
  store %"compiler/source:Span" %t606, ptr %l317
  br label %bb161
bb161:
  %t607 = load ptr, ptr %l309, !tbaa !29
  %t608 = load i32, ptr %l311, !tbaa !23
  %t609 = load { i64, [2 x i64] }, ptr %l314
  %t610 = load %"compiler/source:Span", ptr %l317
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildSite(ptr %v0, ptr %t607, i32 %t608, { i64, [2 x i64] } %t609, %"compiler/source:Span" %t610)
  br label %bb162
bb162:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t613 = getelementptr %"compiler/scope:Scoper", ptr %t611, i32 0, i32 104
  store i1 true, ptr %t613, !tbaa !21
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load ptr, ptr %l15, !tbaa !29
  %t617 = getelementptr %"compiler/typed:Promote", ptr %t615, i32 0, i32 0
  %t618 = load ptr, ptr %t617, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t620
  %t621 = getelementptr { i64, [2 x i64] }, ptr %t620, i32 0, i32 0
  store i64 0, ptr %t621
  %t622 = load { i64, [2 x i64] }, ptr %t620
  %t626 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v0, ptr %t614, ptr %t618, { i64, [2 x i64] } %t622)
  store %"compiler/scope:Val" %t626, ptr %l324
  br label %bb163
bb163:
  %t627 = load %"compiler/scope:Val", ptr %l324
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr %"compiler/scope:Scoper", ptr %t628, i32 0, i32 104
  store i1 false, ptr %t630, !tbaa !21
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t633 = getelementptr %"compiler/scope:Scoper", ptr %t631, i32 0, i32 31
  store ptr %t633, ptr %l327, !tbaa !29
  %t634 = load i32, ptr %l2, !tbaa !23
  %t636 = sext i32 %t634 to i64
  store i64 %t636, ptr %l329, !tbaa !24
  %t637 = load ptr, ptr %l0, !tbaa !29
  store ptr %t637, ptr %l330, !tbaa !29
  store %"compiler/scope:Val" %t627, ptr %l331
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t640 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t641 = load i32, ptr %t640, !tbaa !23
  %t644 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t639, i32 %t641)
  store { i64, [2 x i64] } %t644, ptr %l334
  br label %bb164
bb164:
  %t645 = load ptr, ptr %l330, !tbaa !29
  %t646 = load %"compiler/scope:Val", ptr %l331
  %t647 = load { i64, [2 x i64] }, ptr %l334
  %t648 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalTerm(ptr %v0, ptr %t645, %"compiler/scope:Val" %t646, { i64, [2 x i64] } %t647)
  store { i64, [2 x i64] } %t648, ptr %l335
  br label %bb165
bb165:
  %t649 = load ptr, ptr %l327, !tbaa !29
  %t650 = load i64, ptr %l329, !tbaa !24
  %t651 = load { i64, [2 x i64] }, ptr %l335
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t649, i64 %t650, { i64, [2 x i64] } %t651)
  br label %bb166
bb166:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb167:
  br label %bb173
bb168:
  br i1 true, label %bb169, label %bb170
bb169:
  br label %bb171
bb170:
  br label %bb172
bb171:
  br label %bb173
bb172:
  call void @__olang_check_failed(ptr @olang_loc_63421958175545b3_aea9f7881c37205f)
  unreachable
bb173:
  br label %bb174
bb174:
  %t652 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t653 = load i32, ptr %t652, !range !{i32 0, i32 7}
  %t655 = trunc i64 3 to i32
  %t656 = icmp eq i32 %t653, %t655
  br i1 %t656, label %bb175, label %bb176
bb175:
  %t658 = load ptr, ptr %l0, !tbaa !29
  store ptr %t658, ptr %l339, !tbaa !29
  %t659 = load ptr, ptr %l3, !tbaa !29
  %t661 = icmp eq ptr %t659, null
  br i1 %t661, label %bb177, label %bb178
bb176:
  store i1 false, ptr %l338, !tbaa !21
  br label %bb181
bb177:
  call void @__olang_check_failed(ptr @olang_loc_764527203cdb400b_6de4094d30d6c847)
  unreachable
bb178:
  br label %bb179
bb179:
  %t663 = load ptr, ptr %l3, !tbaa !29
  %t664 = load ptr, ptr %l339, !tbaa !29
  %t666 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %t664, ptr %t663)
  store i1 %t666, ptr %l343
  br label %bb180
bb180:
  %t667 = load i1, ptr %l343, !tbaa !21
  store i1 %t667, ptr %l338, !tbaa !21
  br label %bb181
bb181:
  %t668 = load i1, ptr %l338, !tbaa !21
  br i1 %t668, label %bb182, label %bb183
bb182:
  %t669 = load ptr, ptr %l0, !tbaa !29
  store ptr %t669, ptr %l344, !tbaa !29
  %t670 = load ptr, ptr %l3, !tbaa !29
  store ptr %t670, ptr %l345, !tbaa !29
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t672 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t673 = load i32, ptr %t672, !tbaa !23
  %t676 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t671, i32 %t673)
  store { i64, [2 x i64] } %t676, ptr %l348
  br label %bb184
bb183:
  br label %bb187
bb184:
  %t677 = load ptr, ptr %l344, !tbaa !29
  %t678 = load ptr, ptr %l345, !tbaa !29
  %t679 = load { i64, [2 x i64] }, ptr %l348
  %t680 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t677, ptr %t678, { i64, [2 x i64] } %t679)
  store %"compiler/scope:Val" %t680, ptr %l349
  br label %bb185
bb185:
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t683 = getelementptr %"compiler/scope:Scoper", ptr %t681, i32 0, i32 31
  %t684 = load i32, ptr %l2, !tbaa !23
  %t686 = sext i32 %t684 to i64
  store { i64, [2 x i64] } zeroinitializer, ptr %t687
  %t688 = getelementptr { i64, [2 x i64] }, ptr %t687, i32 0, i32 0
  store i64 3, ptr %t688
  %t689 = load { i64, [2 x i64] }, ptr %t687
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t683, i64 %t686, { i64, [2 x i64] } %t689)
  br label %bb186
bb186:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb187:
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t694 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t695 = load { i64, [2 x i64] }, ptr %t694
  %t696 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t697 = load i32, ptr %t696, !tbaa !23
  %t701 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarkTerm(ptr %v0, ptr %t693, { i64, [2 x i64] } %t695, i32 %t697)
  store { i64, [2 x i64] } %t701, ptr %l358
  br label %bb188
bb188:
  %t702 = load { i64, [2 x i64] }, ptr %l358
  store { i64, [2 x i64] } %t702, ptr %l17
  %t703 = load { i64, [2 x i64] }, ptr %l9
  %t705 = extractvalue { i64, [2 x i64] } %t703, 0
  %t706 = icmp eq i64 %t705, 0
  %t708 = xor i1 %t706, true
  br i1 %t708, label %bb189, label %bb190
bb189:
  %t710 = load { i64, [2 x i64] }, ptr %l17
  %t712 = extractvalue { i64, [2 x i64] } %t710, 0
  %t713 = icmp eq i64 %t712, 0
  %t715 = xor i1 %t713, true
  store i1 %t715, ptr %l362, !tbaa !21
  br label %bb191
bb190:
  store i1 false, ptr %l362, !tbaa !21
  br label %bb191
bb191:
  %t717 = load i1, ptr %l362, !tbaa !21
  br i1 %t717, label %bb192, label %bb193
bb192:
  %t718 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t718, ptr %l17
  br label %bb194
bb193:
  br label %bb194
bb194:
  %t720 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t721 = load i32, ptr %t720, !range !{i32 0, i32 7}
  %t723 = trunc i64 1 to i32
  %t724 = icmp eq i32 %t721, %t723
  br i1 %t724, label %bb195, label %bb196
bb195:
  %t726 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t727 = load { i64, [2 x i64] }, ptr %t726
  %t729 = extractvalue { i64, [2 x i64] } %t727, 0
  %t730 = icmp eq i64 %t729, 1
  store i1 %t730, ptr %l369, !tbaa !21
  br label %bb197
bb196:
  store i1 false, ptr %l369, !tbaa !21
  br label %bb197
bb197:
  %t732 = load i1, ptr %l369, !tbaa !21
  br i1 %t732, label %bb198, label %bb199
bb198:
  store { i64, [2 x i64] } zeroinitializer, ptr %t733
  %t734 = getelementptr { i64, [2 x i64] }, ptr %t733, i32 0, i32 0
  store i64 0, ptr %t734
  %t735 = load { i64, [2 x i64] }, ptr %t733
  store { i64, [2 x i64] } %t735, ptr %l17
  br label %bb200
bb199:
  br label %bb200
bb200:
  %t737 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t738 = load { i64, [2 x i64] }, ptr %t737
  store { i64, [2 x i64] } %t738, ptr %l18
  %t740 = load { i64, [2 x i64] }, ptr %l18
  %t742 = extractvalue { i64, [2 x i64] } %t740, 0
  %t743 = icmp eq i64 %t742, 2
  br i1 %t743, label %bb201, label %bb202
bb201:
  %t745 = getelementptr { i64, [2 x i64] }, ptr %l18, i32 0, i32 1
  %t746 = getelementptr { i32 }, ptr %t745, i32 0, i32 0
  %t747 = load i32, ptr %t746
  store i32 %t747, ptr %l19, !tbaa !23
  br label %bb203
bb202:
  br label %bb231
bb203:
  %t749 = load { i64, [2 x i64] }, ptr %l17
  %t751 = extractvalue { i64, [2 x i64] } %t749, 0
  %t752 = icmp eq i64 %t751, 5
  br i1 %t752, label %bb204, label %bb205
bb204:
  br label %bb206
bb205:
  br label %bb225
bb206:
  %t754 = load ptr, ptr %l0, !tbaa !29
  %t756 = getelementptr %"compiler/scope:Scoper", ptr %t754, i32 0, i32 27
  %t757 = load i1, ptr %t756, !tbaa !21
  br i1 %t757, label %bb207, label %bb208
bb207:
  store %olang.scope zeroinitializer, ptr %s19
  %t759 = load ptr, ptr %l0, !tbaa !29
  %t761 = getelementptr %"compiler/scope:Scoper", ptr %t759, i32 0, i32 0
  %t762 = load ptr, ptr %t761, !tbaa !29
  %t764 = getelementptr %"compiler/generic:Program", ptr %t762, i32 0, i32 0
  %t765 = load ptr, ptr %t764, !tbaa !29
  %t767 = getelementptr %"compiler/load:Loader", ptr %t765, i32 0, i32 3
  %t768 = load ptr, ptr %t767, !tbaa !29
  store ptr %t768, ptr %l384, !tbaa !29
  %t769 = load ptr, ptr %l0, !tbaa !29
  %t771 = getelementptr %"compiler/scope:Scoper", ptr %t769, i32 0, i32 25
  %t772 = load ptr, ptr %t771, !tbaa !29
  %t774 = icmp eq ptr %t772, null
  br i1 %t774, label %bb209, label %bb210
bb208:
  br label %bb223
bb209:
  call void @__olang_check_failed(ptr @olang_loc_81ac2c90f12200ce_a13e1abdf1b4e702)
  unreachable
bb210:
  br label %bb211
bb211:
  %t776 = load ptr, ptr %l0, !tbaa !29
  %t778 = getelementptr %"compiler/scope:Scoper", ptr %t776, i32 0, i32 25
  %t779 = load ptr, ptr %t778, !tbaa !29
  %t782 = getelementptr %"compiler/typed:Body", ptr %t779, i32 0, i32 7
  %t783 = load i32, ptr %l19, !tbaa !23
  %t785 = sext i32 %t783 to i64
  %t788 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t782, i64 %t785)
  store %"compiler/typed:Local" %t788, ptr %l394
  br label %bb212
bb212:
  %t789 = getelementptr %"compiler/typed:Local", ptr %l394, i32 0, i32 0
  %t790 = load i32, ptr %t789, !tbaa !23
  %t791 = load ptr, ptr %l384, !tbaa !29
  %t793 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t791, i32 %t790)
  store { i64, ptr } %t793, ptr %l396
  br label %bb213
bb213:
  %t794 = load { i64, ptr }, ptr %l396, !tbaa !27
  %t795 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s19, { i64, ptr } %t794)
  store { i64, ptr } %t795, ptr %l397
  br label %bb214
bb214:
  %t796 = load { i64, ptr }, ptr %l397, !tbaa !27
  store { i64, ptr } %t796, ptr %l20, !tbaa !27
  %t797 = load ptr, ptr %l0, !tbaa !29
  store ptr %t797, ptr %l398, !tbaa !29
  %t798 = load ptr, ptr %l0, !tbaa !29
  store ptr %t798, ptr %l399, !tbaa !29
  %t799 = load ptr, ptr %l0, !tbaa !29
  %t801 = getelementptr %"compiler/scope:Scoper", ptr %t799, i32 0, i32 38
  %t802 = load %"compiler/source:Span", ptr %t801
  store %"compiler/source:Span" %t802, ptr %l401
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t805 = getelementptr %"compiler/scope:Scoper", ptr %t803, i32 0, i32 0
  %t806 = load ptr, ptr %t805, !tbaa !29
  %t808 = getelementptr %"compiler/generic:Program", ptr %t806, i32 0, i32 0
  %t809 = load ptr, ptr %t808, !tbaa !29
  %t811 = getelementptr %"compiler/load:Loader", ptr %t809, i32 0, i32 3
  %t812 = load ptr, ptr %t811, !tbaa !29
  store ptr %t812, ptr %l405, !tbaa !29
  %t813 = load ptr, ptr %l0, !tbaa !29
  %t815 = getelementptr %"compiler/scope:Scoper", ptr %t813, i32 0, i32 25
  %t816 = load ptr, ptr %t815, !tbaa !29
  %t818 = icmp eq ptr %t816, null
  br i1 %t818, label %bb215, label %bb216
bb215:
  call void @__olang_check_failed(ptr @olang_loc_e27dfe0dbdd05075_f93f741ca3f66de9)
  unreachable
bb216:
  br label %bb217
bb217:
  %t820 = load ptr, ptr %l0, !tbaa !29
  %t822 = getelementptr %"compiler/scope:Scoper", ptr %t820, i32 0, i32 25
  %t823 = load ptr, ptr %t822, !tbaa !29
  %t826 = getelementptr %"compiler/typed:Body", ptr %t823, i32 0, i32 7
  %t827 = load i32, ptr %l19, !tbaa !23
  %t829 = sext i32 %t827 to i64
  %t832 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t826, i64 %t829)
  store %"compiler/typed:Local" %t832, ptr %l415
  br label %bb218
bb218:
  %t833 = getelementptr %"compiler/typed:Local", ptr %l415, i32 0, i32 0
  %t834 = load i32, ptr %t833, !tbaa !23
  %t835 = load ptr, ptr %l405, !tbaa !29
  %t837 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t835, i32 %t834)
  store { i64, ptr } %t837, ptr %l417
  br label %bb219
bb219:
  %t838 = load ptr, ptr %l399, !tbaa !29
  %t839 = load %"compiler/source:Span", ptr %l401
  %t840 = load { i64, ptr }, ptr %l417, !tbaa !27
  %t841 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarkAt(ptr %v0, ptr %v0, ptr %t838, %"compiler/source:Span" %t839, { i64, ptr } %t840)
  store %"compiler/source:Span" %t841, ptr %l418
  br label %bb220
bb220:
  %t842 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t843 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t846 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTagUnknownScope(ptr %s19, ptr %s19, ptr %s19, { i64, ptr } %t842, { i64, ptr } %t843)
  store %"compiler/msgs:Msg" %t846, ptr %l421
  br label %bb221
bb221:
  %t847 = load ptr, ptr %l398, !tbaa !29
  %t848 = load %"compiler/source:Span", ptr %l418
  %t849 = load %"compiler/msgs:Msg", ptr %l421
  %t850 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s19, ptr %t847, %"compiler/source:Span" %t848, %"compiler/msgs:Msg" %t849)
  store i64 %t850, ptr %l422
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s19)
  br label %bb223
bb223:
  %t851 = load ptr, ptr %l0, !tbaa !29
  %t852 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t853 = load i32, ptr %t852, !tbaa !23
  %t856 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t851, i32 %t853)
  store { i64, [2 x i64] } %t856, ptr %l425
  br label %bb224
bb224:
  %t857 = load { i64, [2 x i64] }, ptr %l425
  store { i64, [2 x i64] } %t857, ptr %l17
  br label %bb230
bb225:
  br i1 true, label %bb226, label %bb227
bb226:
  br label %bb228
bb227:
  br label %bb229
bb228:
  br label %bb230
bb229:
  call void @__olang_check_failed(ptr @olang_loc_c869693a02d1a83c_142e5cc4d32f88b8)
  unreachable
bb230:
  br label %bb236
bb231:
  br i1 true, label %bb232, label %bb233
bb232:
  br label %bb234
bb233:
  br label %bb235
bb234:
  br label %bb236
bb235:
  call void @__olang_check_failed(ptr @olang_loc_f132d9555aa3b3ed_19b32ee1bad8ae89)
  unreachable
bb236:
  %t858 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t859 = load i32, ptr %t858, !range !{i32 0, i32 7}
  %t861 = trunc i64 6 to i32
  %t862 = icmp eq i32 %t859, %t861
  br i1 %t862, label %bb237, label %bb238
bb237:
  %t864 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t865 = load { i64, [2 x i64] }, ptr %t864
  store { i64, [2 x i64] } %t865, ptr %l21
  %t867 = load { i64, [2 x i64] }, ptr %l21
  %t869 = extractvalue { i64, [2 x i64] } %t867, 0
  %t870 = icmp eq i64 %t869, 2
  br i1 %t870, label %bb239, label %bb240
bb238:
  br label %bb252
bb239:
  %t872 = getelementptr { i64, [2 x i64] }, ptr %l21, i32 0, i32 1
  %t873 = getelementptr { i32 }, ptr %t872, i32 0, i32 0
  %t874 = load i32, ptr %t873
  store i32 %t874, ptr %l22, !tbaa !23
  br label %bb241
bb240:
  br label %bb245
bb241:
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t877 = load i64, ptr @G_2ecompiler_2fscope_2eWhyField, !tbaa !24
  %t880 = getelementptr %"compiler/scope:Scoper", ptr %t876, i32 0, i32 101
  store i64 %t877, ptr %t880, !tbaa !24
  %t881 = load ptr, ptr %l0, !tbaa !29
  store ptr %t881, ptr %l434, !tbaa !29
  %t882 = load ptr, ptr %l0, !tbaa !29
  %t883 = load i32, ptr %l22, !tbaa !23
  %t886 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %t882, i32 %t883)
  store { i64, [2 x i64] } %t886, ptr %l437
  br label %bb242
bb242:
  %t887 = load ptr, ptr %l0, !tbaa !29
  %t889 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t887, i32 0)
  store { i64, [2 x i64] } %t889, ptr %l439
  br label %bb243
bb243:
  %t890 = load ptr, ptr %l434, !tbaa !29
  %t891 = load { i64, [2 x i64] }, ptr %l437
  %t892 = load { i64, [2 x i64] }, ptr %l439
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %t890, { i64, [2 x i64] } %t891, { i64, [2 x i64] } %t892, i1 false)
  br label %bb244
bb244:
  %t893 = load ptr, ptr %l0, !tbaa !29
  %t895 = getelementptr %"compiler/scope:Scoper", ptr %t893, i32 0, i32 101
  store i64 0, ptr %t895, !tbaa !24
  br label %bb251
bb245:
  br i1 true, label %bb246, label %bb247
bb246:
  br label %bb248
bb247:
  br label %bb250
bb248:
  %t896 = load ptr, ptr %l0, !tbaa !29
  %t898 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t896, i32 0)
  store { i64, [2 x i64] } %t898, ptr %l442
  br label %bb249
bb249:
  %t899 = load { i64, [2 x i64] }, ptr %l442
  store { i64, [2 x i64] } %t899, ptr %l17
  br label %bb251
bb250:
  call void @__olang_check_failed(ptr @olang_loc_359aef4ec584f7d6_183b185e371796d2)
  unreachable
bb251:
  br label %bb252
bb252:
  %t900 = load ptr, ptr %l0, !tbaa !29
  %t901 = load i32, ptr %l5, !tbaa !23
  %t904 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t900, i32 %t901)
  store i1 %t904, ptr %l445
  br label %bb253
bb253:
  %t905 = load i1, ptr %l445, !tbaa !21
  br i1 %t905, label %bb254, label %bb255
bb254:
  %t906 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t907 = load i32, ptr %t906, !range !{i32 0, i32 7}
  %t909 = trunc i64 3 to i32
  %t910 = icmp eq i32 %t907, %t909
  %t912 = xor i1 %t910, true
  store i1 %t912, ptr %l446, !tbaa !21
  br label %bb256
bb255:
  store i1 false, ptr %l446, !tbaa !21
  br label %bb256
bb256:
  %t914 = load i1, ptr %l446, !tbaa !21
  br i1 %t914, label %bb257, label %bb258
bb257:
  %t915 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t916 = load i32, ptr %t915, !range !{i32 0, i32 7}
  %t918 = trunc i64 2 to i32
  %t919 = icmp eq i32 %t916, %t918
  %t921 = xor i1 %t919, true
  store i1 %t921, ptr %l450, !tbaa !21
  br label %bb259
bb258:
  store i1 false, ptr %l450, !tbaa !21
  br label %bb259
bb259:
  %t923 = load i1, ptr %l450, !tbaa !21
  br i1 %t923, label %bb260, label %bb261
bb260:
  %t924 = load ptr, ptr %l0, !tbaa !29
  store ptr %t924, ptr %l454, !tbaa !29
  %t925 = load ptr, ptr %l3, !tbaa !29
  %t927 = icmp eq ptr %t925, null
  br i1 %t927, label %bb262, label %bb263
bb261:
  br label %bb266
bb262:
  call void @__olang_check_failed(ptr @olang_loc_a12e96be7ca439b0_5f205879a795b73c)
  unreachable
bb263:
  br label %bb264
bb264:
  %t929 = load ptr, ptr %l3, !tbaa !29
  %t930 = load ptr, ptr %l454, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitBorrow(ptr %v0, ptr %v1, ptr %t930, ptr %t929)
  br label %bb265
bb265:
  br label %bb266
bb266:
  %t932 = load ptr, ptr %l0, !tbaa !29
  %t933 = load i32, ptr %l5, !tbaa !23
  %t936 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t932, i32 %t933)
  store i1 %t936, ptr %l460
  br label %bb267
bb267:
  %t937 = load i1, ptr %l460, !tbaa !21
  br i1 %t937, label %bb268, label %bb269
bb268:
  %t938 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t939 = load i32, ptr %t938, !range !{i32 0, i32 7}
  %t941 = trunc i64 3 to i32
  %t942 = icmp eq i32 %t939, %t941
  store i1 %t942, ptr %l461, !tbaa !21
  br label %bb270
bb269:
  store i1 false, ptr %l461, !tbaa !21
  br label %bb270
bb270:
  %t944 = load i1, ptr %l461, !tbaa !21
  br i1 %t944, label %bb271, label %bb272
bb271:
  %t945 = load ptr, ptr %l3, !tbaa !29
  store ptr %t945, ptr %l464, !tbaa !29
  store i1 false, ptr %l465, !tbaa !21
  %t946 = load ptr, ptr %l464, !tbaa !29
  %t947 = icmp ne ptr %t946, null
  br i1 %t947, label %bb273, label %bb274
bb272:
  br label %bb294
bb273:
  %t949 = load ptr, ptr %l464, !tbaa !29
  %t950 = load i64, ptr %t949, !range !{i64 0, i64 18}
  %t952 = icmp eq i64 %t950, 3
  store i1 %t952, ptr %l465, !tbaa !21
  br label %bb274
bb274:
  %t953 = load i1, ptr %l465, !tbaa !21
  br i1 %t953, label %bb275, label %bb276
bb275:
  %t954 = load ptr, ptr %l3, !tbaa !29
  %t956 = getelementptr { i64, [5 x i64] }, ptr %t954, i32 0, i32 1
  %t957 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t956, i32 0, i32 2
  %t958 = load ptr, ptr %t957
  store ptr %t958, ptr %l23, !tbaa !29
  br label %bb277
bb276:
  br label %bb288
bb277:
  %t960 = load ptr, ptr %l0, !tbaa !29
  %t961 = load ptr, ptr %l23, !tbaa !29
  %t964 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitPlace(ptr %v0, ptr %v1, ptr %t960, ptr %t961)
  store i1 %t964, ptr %l472
  br label %bb278
bb278:
  %t965 = load i1, ptr %l472, !tbaa !21
  br i1 %t965, label %bb279, label %bb280
bb279:
  store i1 true, ptr %l473, !tbaa !21
  br label %bb282
bb280:
  %t966 = load ptr, ptr %l0, !tbaa !29
  %t967 = load ptr, ptr %l23, !tbaa !29
  %t970 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitHeld(ptr %v0, ptr %v1, ptr %t966, ptr %t967)
  store i1 %t970, ptr %l476
  br label %bb281
bb281:
  %t971 = load i1, ptr %l476, !tbaa !21
  store i1 %t971, ptr %l473, !tbaa !21
  br label %bb282
bb282:
  %t972 = load i1, ptr %l473, !tbaa !21
  br i1 %t972, label %bb283, label %bb284
bb283:
  %t973 = load ptr, ptr %l0, !tbaa !29
  %t975 = getelementptr %"compiler/scope:Scoper", ptr %t973, i32 0, i32 41
  store ptr %t975, ptr %l478, !tbaa !29
  %t976 = load i32, ptr %l2, !tbaa !23
  %t978 = sext i32 %t976 to i64
  store i64 %t978, ptr %l480, !tbaa !24
  %t979 = load ptr, ptr %l0, !tbaa !29
  %t980 = load ptr, ptr %l23, !tbaa !29
  %t983 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %t979, ptr %t980)
  store { i64, [2 x i64] } %t983, ptr %l483
  br label %bb285
bb284:
  br label %bb287
bb285:
  %t984 = load ptr, ptr %l478, !tbaa !29
  %t985 = load i64, ptr %l480, !tbaa !24
  %t986 = load { i64, [2 x i64] }, ptr %l483
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H38f9aff1b0310316a48dc5a28922f96e(ptr %v0, ptr %t984, i64 %t985, { i64, [2 x i64] } %t986)
  br label %bb286
bb286:
  br label %bb287
bb287:
  br label %bb293
bb288:
  br i1 true, label %bb289, label %bb290
bb289:
  br label %bb291
bb290:
  br label %bb292
bb291:
  br label %bb293
bb292:
  call void @__olang_check_failed(ptr @olang_loc_332fe8876b6bb960_cfa416e6ff1f13b4)
  unreachable
bb293:
  br label %bb294
bb294:
  %t987 = load { i64, [2 x i64] }, ptr %l17
  %t989 = extractvalue { i64, [2 x i64] } %t987, 0
  %t990 = icmp eq i64 %t989, 0
  br i1 %t990, label %bb295, label %bb296
bb295:
  %t992 = load { i64, [2 x i64] }, ptr %l9
  %t994 = extractvalue { i64, [2 x i64] } %t992, 0
  %t995 = icmp eq i64 %t994, 0
  %t997 = xor i1 %t995, true
  br i1 %t997, label %bb297, label %bb298
bb296:
  br label %bb386
bb297:
  %t999 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t999, ptr %l489
  br label %bb300
bb298:
  %t1001 = load ptr, ptr %l0, !tbaa !29
  %t1002 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t1003 = load i32, ptr %t1002, !tbaa !23
  %t1006 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t1001, i32 %t1003)
  store { i64, [2 x i64] } %t1006, ptr %l493
  br label %bb299
bb299:
  %t1007 = load { i64, [2 x i64] }, ptr %l493
  store { i64, [2 x i64] } %t1007, ptr %l489
  br label %bb300
bb300:
  %t1008 = load { i64, [2 x i64] }, ptr %l489
  store { i64, [2 x i64] } %t1008, ptr %l24
  %t1009 = load ptr, ptr %l0, !tbaa !29
  %t1010 = load i32, ptr %l2, !tbaa !23
  %t1012 = sext i32 %t1010 to i64
  %t1015 = getelementptr %"compiler/scope:Scoper", ptr %t1009, i32 0, i32 135
  store i64 %t1012, ptr %t1015, !tbaa !24
  %t1016 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1016, ptr %l497, !tbaa !29
  %t1017 = load i1, ptr %l7, !tbaa !21
  br i1 %t1017, label %bb301, label %bb302
bb301:
  %t1019 = load i1, ptr %l8, !tbaa !21
  %t1021 = xor i1 %t1019, true
  store i1 %t1021, ptr %l499, !tbaa !21
  br label %bb303
bb302:
  store i1 false, ptr %l499, !tbaa !21
  br label %bb303
bb303:
  %t1023 = load i1, ptr %l499, !tbaa !21
  br i1 %t1023, label %bb304, label %bb305
bb304:
  %t1024 = load { i64, [2 x i64] }, ptr %l9
  %t1026 = extractvalue { i64, [2 x i64] } %t1024, 0
  %t1027 = icmp eq i64 %t1026, 0
  store i1 %t1027, ptr %l502, !tbaa !21
  br label %bb306
bb305:
  store i1 false, ptr %l502, !tbaa !21
  br label %bb306
bb306:
  %t1029 = load i1, ptr %l502, !tbaa !21
  %t1030 = load ptr, ptr %l497, !tbaa !29
  %t1031 = getelementptr %"compiler/scope:Scoper", ptr %t1030, i32 0, i32 104
  store i1 %t1029, ptr %t1031, !tbaa !21
  %t1032 = load i1, ptr %l8, !tbaa !21
  br i1 %t1032, label %bb307, label %bb308
bb307:
  %t1034 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1034, ptr %l506, !tbaa !29
  %t1035 = load i1, ptr %l7, !tbaa !21
  br i1 %t1035, label %bb309, label %bb310
bb308:
  br label %bb315
bb309:
  %t1037 = load { i64, [2 x i64] }, ptr %l9
  %t1039 = extractvalue { i64, [2 x i64] } %t1037, 0
  %t1040 = icmp eq i64 %t1039, 0
  store i1 %t1040, ptr %l508, !tbaa !21
  br label %bb311
bb310:
  store i1 false, ptr %l508, !tbaa !21
  br label %bb311
bb311:
  %t1042 = load i1, ptr %l508, !tbaa !21
  br i1 %t1042, label %bb312, label %bb313
bb312:
  store i64 1, ptr %l511, !tbaa !24
  br label %bb314
bb313:
  store i64 0, ptr %l511, !tbaa !24
  br label %bb314
bb314:
  %t1043 = load i64, ptr %l511, !tbaa !24
  %t1044 = load ptr, ptr %l506, !tbaa !29
  %t1045 = getelementptr %"compiler/scope:Scoper", ptr %t1044, i32 0, i32 107
  store i64 %t1043, ptr %t1045, !tbaa !24
  br label %bb315
bb315:
  %t1046 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t1047
  %t1048 = getelementptr { i64, [2 x i64] }, ptr %t1047, i32 0, i32 0
  store i64 0, ptr %t1048
  %t1049 = load { i64, [2 x i64] }, ptr %t1047
  %t1052 = getelementptr %"compiler/scope:Scoper", ptr %t1046, i32 0, i32 67
  store { i64, [2 x i64] } %t1049, ptr %t1052
  %t1053 = load ptr, ptr %l0, !tbaa !29
  %t1054 = load ptr, ptr %l3, !tbaa !29
  %t1055 = load { i64, [2 x i64] }, ptr %l24
  %t1059 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1053, ptr %t1054, { i64, [2 x i64] } %t1055)
  store %"compiler/scope:Val" %t1059, ptr %l517
  br label %bb316
bb316:
  %t1060 = load %"compiler/scope:Val", ptr %l517
  store %"compiler/scope:Val" %t1060, ptr %l25
  %t1061 = load ptr, ptr %l0, !tbaa !29
  %t1063 = getelementptr %"compiler/scope:Scoper", ptr %t1061, i32 0, i32 135
  store i64 -1, ptr %t1063, !tbaa !24
  %t1064 = load ptr, ptr %l0, !tbaa !29
  %t1066 = getelementptr %"compiler/scope:Scoper", ptr %t1064, i32 0, i32 104
  store i1 false, ptr %t1066, !tbaa !21
  %t1067 = load ptr, ptr %l0, !tbaa !29
  %t1069 = getelementptr %"compiler/scope:Scoper", ptr %t1067, i32 0, i32 107
  store i64 -1, ptr %t1069, !tbaa !24
  %t1070 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1070, ptr %l521, !tbaa !29
  %t1071 = load i32, ptr %l2, !tbaa !23
  %t1073 = sext i32 %t1071 to i64
  store i64 %t1073, ptr %l523, !tbaa !24
  %t1074 = load ptr, ptr %l3, !tbaa !29
  %t1076 = icmp eq ptr %t1074, null
  br i1 %t1076, label %bb317, label %bb318
bb317:
  call void @__olang_check_failed(ptr @olang_loc_4cb1e8bfb0eaf742_30c70eda17c6c626)
  unreachable
bb318:
  br label %bb319
bb319:
  %t1078 = load ptr, ptr %l3, !tbaa !29
  %t1079 = load %"compiler/scope:Val", ptr %l25
  %t1080 = load ptr, ptr %l521, !tbaa !29
  %t1081 = load i64, ptr %l523, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteOrigin(ptr %v0, ptr %v1, ptr %t1080, i64 %t1081, ptr %t1078, %"compiler/scope:Val" %t1079)
  br label %bb320
bb320:
  %t1084 = load ptr, ptr %l0, !tbaa !29
  %t1086 = getelementptr %"compiler/scope:Scoper", ptr %t1084, i32 0, i32 67
  %t1087 = load { i64, [2 x i64] }, ptr %t1086
  %t1089 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t1087)
  store i1 %t1089, ptr %l530
  br label %bb321
bb321:
  %t1090 = load i1, ptr %l530, !tbaa !21
  br i1 %t1090, label %bb322, label %bb323
bb322:
  %t1091 = load ptr, ptr %l0, !tbaa !29
  %t1092 = load i32, ptr %l2, !tbaa !23
  %t1094 = sext i32 %t1092 to i64
  %t1097 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewalkLocal(ptr %v0, ptr %t1091, i64 %t1094)
  store i1 %t1097, ptr %l535
  br label %bb324
bb323:
  store i1 false, ptr %l531, !tbaa !21
  br label %bb325
bb324:
  %t1098 = load i1, ptr %l535, !tbaa !21
  store i1 %t1098, ptr %l531, !tbaa !21
  br label %bb325
bb325:
  %t1099 = load i1, ptr %l531, !tbaa !21
  br i1 %t1099, label %bb326, label %bb327
bb326:
  %t1100 = load ptr, ptr %l0, !tbaa !29
  %t1102 = getelementptr %"compiler/scope:Scoper", ptr %t1100, i32 0, i32 66
  %t1103 = load i32, ptr %l2, !tbaa !23
  %t1105 = sext i32 %t1103 to i64
  %t1106 = load ptr, ptr %l0, !tbaa !29
  %t1108 = getelementptr %"compiler/scope:Scoper", ptr %t1106, i32 0, i32 67
  %t1109 = load { i64, [2 x i64] }, ptr %t1108
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H38f9aff1b0310316a48dc5a28922f96e(ptr %v0, ptr %t1102, i64 %t1105, { i64, [2 x i64] } %t1109)
  br label %bb328
bb327:
  br label %bb329
bb328:
  br label %bb329
bb329:
  %t1113 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t1114
  %t1115 = getelementptr { i64, [2 x i64] }, ptr %t1114, i32 0, i32 0
  store i64 0, ptr %t1115
  %t1116 = load { i64, [2 x i64] }, ptr %t1114
  %t1119 = getelementptr %"compiler/scope:Scoper", ptr %t1113, i32 0, i32 67
  store { i64, [2 x i64] } %t1116, ptr %t1119
  %t1120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1120, ptr %l544, !tbaa !29
  %t1121 = load i32, ptr %l2, !tbaa !23
  store i32 %t1121, ptr %l545, !tbaa !23
  %t1122 = load ptr, ptr %l3, !tbaa !29
  %t1124 = icmp eq ptr %t1122, null
  br i1 %t1124, label %bb330, label %bb331
bb330:
  call void @__olang_check_failed(ptr @olang_loc_ebf021f92f33e6c3_51775e5dd3616c17)
  unreachable
bb331:
  br label %bb332
bb332:
  %t1126 = load ptr, ptr %l3, !tbaa !29
  %t1127 = load ptr, ptr %l544, !tbaa !29
  %t1128 = load i32, ptr %l545, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %t1127, i32 %t1128, ptr %t1126)
  br label %bb333
bb333:
  %t1130 = load ptr, ptr %l0, !tbaa !29
  %t1132 = getelementptr %"compiler/scope:Scoper", ptr %t1130, i32 0, i32 31
  store ptr %t1132, ptr %l550, !tbaa !29
  %t1133 = load i32, ptr %l2, !tbaa !23
  %t1135 = sext i32 %t1133 to i64
  store i64 %t1135, ptr %l552, !tbaa !24
  %t1136 = load ptr, ptr %l0, !tbaa !29
  %t1137 = load %"compiler/scope:Val", ptr %l25
  %t1138 = load { i64, [2 x i64] }, ptr %l24
  %t1142 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalTerm(ptr %v0, ptr %t1136, %"compiler/scope:Val" %t1137, { i64, [2 x i64] } %t1138)
  store { i64, [2 x i64] } %t1142, ptr %l556
  br label %bb334
bb334:
  %t1143 = load ptr, ptr %l550, !tbaa !29
  %t1144 = load i64, ptr %l552, !tbaa !24
  %t1145 = load { i64, [2 x i64] }, ptr %l556
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1143, i64 %t1144, { i64, [2 x i64] } %t1145)
  br label %bb335
bb335:
  %t1146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1146, ptr %l557, !tbaa !29
  %t1147 = load i32, ptr %l5, !tbaa !23
  store i32 %t1147, ptr %l558, !tbaa !23
  %t1148 = load ptr, ptr %l3, !tbaa !29
  %t1150 = icmp eq ptr %t1148, null
  br i1 %t1150, label %bb336, label %bb337
bb336:
  call void @__olang_check_failed(ptr @olang_loc_b8d34b82d7d8e134_8820b4804d519ff8)
  unreachable
bb337:
  br label %bb338
bb338:
  %t1152 = load ptr, ptr %l3, !tbaa !29
  %t1153 = load ptr, ptr %l557, !tbaa !29
  %t1154 = load i32, ptr %l558, !tbaa !23
  %t1156 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownCall(ptr %v0, ptr %v1, ptr %t1153, i32 %t1154, ptr %t1152)
  store i1 %t1156, ptr %l562
  br label %bb339
bb339:
  %t1157 = load i1, ptr %l562, !tbaa !21
  br i1 %t1157, label %bb340, label %bb341
bb340:
  %t1158 = load ptr, ptr %l0, !tbaa !29
  %t1160 = getelementptr %"compiler/scope:Scoper", ptr %t1158, i32 0, i32 31
  %t1161 = load i32, ptr %l2, !tbaa !23
  %t1163 = sext i32 %t1161 to i64
  %t1164 = load { i64, [2 x i64] }, ptr %l24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1160, i64 %t1163, { i64, [2 x i64] } %t1164)
  br label %bb342
bb341:
  br label %bb343
bb342:
  br label %bb343
bb343:
  %t1168 = load ptr, ptr %l0, !tbaa !29
  %t1170 = getelementptr %"compiler/scope:Scoper", ptr %t1168, i32 0, i32 41
  %t1171 = load i32, ptr %l2, !tbaa !23
  %t1173 = sext i32 %t1171 to i64
  %t1176 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H65b4b9a6d1679f5b3ddedaa5b2e336bd(ptr %v0, ptr %t1170, i64 %t1173)
  %t1177 = extractvalue { i32, { i64, [2 x i64] } } %t1176, 1
  %t1178 = extractvalue { i32, { i64, [2 x i64] } } %t1176, 0
  store i32 %t1178, ptr %l574
  %t1179 = icmp ne i32 %t1178, 0
  br i1 %t1179, label %bb345, label %ok.1180, !prof !99
ok.1180:
  store { i64, [2 x i64] } %t1177, ptr %l573
  br label %bb344
bb344:
  %t1181 = load { i64, [2 x i64] }, ptr %l573
  store { i64, [2 x i64] } %t1181, ptr %l568
  br label %bb347
bb345:
  br label %bb346
bb346:
  call void @__olang_ert_req_clear()
  store { i64, [2 x i64] } zeroinitializer, ptr %t1182
  %t1183 = getelementptr { i64, [2 x i64] }, ptr %t1182, i32 0, i32 0
  store i64 0, ptr %t1183
  %t1184 = load { i64, [2 x i64] }, ptr %t1182
  store { i64, [2 x i64] } %t1184, ptr %l568
  br label %bb347
bb347:
  %t1186 = load { i64, [2 x i64] }, ptr %l568
  store { i64, [2 x i64] } %t1186, ptr %l26
  %t1187 = load { i64, [2 x i64] }, ptr %l26
  %t1189 = extractvalue { i64, [2 x i64] } %t1187, 0
  %t1190 = icmp eq i64 %t1189, 0
  %t1192 = xor i1 %t1190, true
  br i1 %t1192, label %bb348, label %bb349
bb348:
  %t1194 = load ptr, ptr %l0, !tbaa !29
  %t1196 = getelementptr %"compiler/scope:Scoper", ptr %t1194, i32 0, i32 31
  %t1197 = load i32, ptr %l2, !tbaa !23
  %t1199 = sext i32 %t1197 to i64
  %t1200 = load { i64, [2 x i64] }, ptr %l26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1196, i64 %t1199, { i64, [2 x i64] } %t1200)
  br label %bb350
bb349:
  br label %bb351
bb350:
  br label %bb351
bb351:
  %t1204 = getelementptr %"compiler/scope:Val", ptr %l25, i32 0, i32 1
  %t1205 = load { i64, [2 x i64] }, ptr %t1204
  store { i64, [2 x i64] } %t1205, ptr %l27
  %t1207 = load { i64, [2 x i64] }, ptr %l27
  %t1209 = extractvalue { i64, [2 x i64] } %t1207, 0
  %t1210 = icmp eq i64 %t1209, 4
  br i1 %t1210, label %bb352, label %bb353
bb352:
  %t1212 = getelementptr { i64, [2 x i64] }, ptr %l27, i32 0, i32 1
  %t1213 = getelementptr { i64, i64 }, ptr %t1212, i32 0, i32 0
  %t1214 = load i64, ptr %t1213
  store i64 %t1214, ptr %l28, !tbaa !24
  br label %bb354
bb353:
  br label %bb380
bb354:
  %t1216 = load i64, ptr %l28, !tbaa !24
  %t1218 = icmp slt i64 %t1216, 0
  br i1 %t1218, label %bb355, label %bb356
bb355:
  %t1220 = load i64, ptr %l28, !tbaa !24
  %t1222 = sub i64 0, %t1220
  %t1224 = sub i64 %t1222, 1
  store i64 %t1224, ptr %l593, !tbaa !24
  %t1225 = load ptr, ptr %l0, !tbaa !29
  %t1227 = getelementptr %"compiler/scope:Scoper", ptr %t1225, i32 0, i32 88
  %t1229 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t1227)
  store i64 %t1229, ptr %l596
  br label %bb357
bb356:
  store i1 false, ptr %l590, !tbaa !21
  br label %bb358
bb357:
  %t1230 = load i64, ptr %l593, !tbaa !24
  %t1231 = load i64, ptr %l596, !tbaa !24
  %t1232 = icmp slt i64 %t1230, %t1231
  store i1 %t1232, ptr %l590, !tbaa !21
  br label %bb358
bb358:
  %t1234 = load i1, ptr %l590, !tbaa !21
  br i1 %t1234, label %bb359, label %bb360
bb359:
  %t1235 = load ptr, ptr %l0, !tbaa !29
  %t1237 = getelementptr %"compiler/scope:Scoper", ptr %t1235, i32 0, i32 88
  %t1238 = load i64, ptr %l28, !tbaa !24
  %t1240 = sub i64 0, %t1238
  %t1242 = sub i64 %t1240, 1
  %t1245 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1237, i64 %t1242)
  store i1 %t1245, ptr %l604
  br label %bb361
bb360:
  store i1 false, ptr %l598, !tbaa !21
  br label %bb362
bb361:
  %t1246 = load i1, ptr %l604, !tbaa !21
  store i1 %t1246, ptr %l598, !tbaa !21
  br label %bb362
bb362:
  %t1247 = load i1, ptr %l598, !tbaa !21
  br i1 %t1247, label %bb363, label %bb364
bb363:
  %t1248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1248, ptr %l605, !tbaa !29
  %t1249 = load ptr, ptr %l3, !tbaa !29
  %t1251 = icmp eq ptr %t1249, null
  br i1 %t1251, label %bb365, label %bb366
bb364:
  br label %bb379
bb365:
  call void @__olang_check_failed(ptr @olang_loc_4a1df88f6e47fa3d_f104cf9ebdc893f9)
  unreachable
bb366:
  br label %bb367
bb367:
  %t1253 = load ptr, ptr %l3, !tbaa !29
  %t1254 = load ptr, ptr %l605, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackExpr(ptr %v0, ptr %v1, ptr %t1254, ptr %t1253)
  br label %bb368
bb368:
  %t1256 = load ptr, ptr %l0, !tbaa !29
  %t1258 = getelementptr %"compiler/scope:Scoper", ptr %t1256, i32 0, i32 27
  %t1259 = load i1, ptr %t1258, !tbaa !21
  br i1 %t1259, label %bb369, label %bb370
bb369:
  store %olang.scope zeroinitializer, ptr %s37
  %t1261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1261, ptr %l611, !tbaa !29
  %t1262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1262, ptr %l612, !tbaa !29
  %t1263 = load ptr, ptr %l3, !tbaa !29
  %t1265 = icmp eq ptr %t1263, null
  br i1 %t1265, label %bb371, label %bb372
bb370:
  br label %bb378
bb371:
  call void @__olang_check_failed(ptr @olang_loc_1209ecb2ebe28e56_3903fb857fc509d2)
  unreachable
bb372:
  br label %bb373
bb373:
  %t1267 = load ptr, ptr %l3, !tbaa !29
  %t1269 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t1267)
  store %"compiler/source:Span" %t1269, ptr %l616
  br label %bb374
bb374:
  %t1270 = load ptr, ptr %l612, !tbaa !29
  %t1271 = load %"compiler/source:Span", ptr %l616
  %t1272 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t1270, %"compiler/source:Span" %t1271)
  store %"compiler/source:Span" %t1272, ptr %l617
  br label %bb375
bb375:
  %t1273 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %s37)
  store %"compiler/msgs:Msg" %t1273, ptr %l618
  br label %bb376
bb376:
  %t1274 = load ptr, ptr %l611, !tbaa !29
  %t1275 = load %"compiler/source:Span", ptr %l617
  %t1276 = load %"compiler/msgs:Msg", ptr %l618
  %t1277 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s37, ptr %t1274, %"compiler/source:Span" %t1275, %"compiler/msgs:Msg" %t1276)
  store i64 %t1277, ptr %l619
  br label %bb377
bb377:
  call void @__olang_scope_close(ptr %s37)
  br label %bb378
bb378:
  br label %bb379
bb379:
  br label %bb385
bb380:
  br i1 true, label %bb381, label %bb382
bb381:
  br label %bb383
bb382:
  br label %bb384
bb383:
  br label %bb385
bb384:
  call void @__olang_check_failed(ptr @olang_loc_f4fc0aa0b05f02b5_215f839e2022cb11)
  unreachable
bb385:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb386:
  %t1278 = load ptr, ptr %l0, !tbaa !29
  %t1280 = getelementptr %"compiler/scope:Scoper", ptr %t1278, i32 0, i32 31
  %t1281 = load i32, ptr %l2, !tbaa !23
  %t1283 = sext i32 %t1281 to i64
  %t1284 = load { i64, [2 x i64] }, ptr %l17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1280, i64 %t1283, { i64, [2 x i64] } %t1284)
  br label %bb387
bb387:
  %t1288 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t1289 = load { i64, [2 x i64] }, ptr %t1288
  %t1291 = extractvalue { i64, [2 x i64] } %t1289, 0
  %t1292 = icmp eq i64 %t1291, 1
  br i1 %t1292, label %bb388, label %bb389
bb388:
  %t1294 = load ptr, ptr %l0, !tbaa !29
  %t1295 = load i32, ptr %l5, !tbaa !23
  %t1298 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t1294, i32 %t1295)
  store i1 %t1298, ptr %l630
  br label %bb390
bb389:
  store i1 false, ptr %l627, !tbaa !21
  br label %bb391
bb390:
  %t1299 = load i1, ptr %l630, !tbaa !21
  store i1 %t1299, ptr %l627, !tbaa !21
  br label %bb391
bb391:
  %t1300 = load i1, ptr %l627, !tbaa !21
  br i1 %t1300, label %bb392, label %bb393
bb392:
  %t1301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1301, ptr %l632, !tbaa !29
  %t1302 = load ptr, ptr %l3, !tbaa !29
  %t1304 = icmp eq ptr %t1302, null
  br i1 %t1304, label %bb394, label %bb395
bb393:
  store i1 false, ptr %l631, !tbaa !21
  br label %bb398
bb394:
  call void @__olang_check_failed(ptr @olang_loc_404d48eac542ce9d_9912d4e42165f0c9)
  unreachable
bb395:
  br label %bb396
bb396:
  %t1306 = load ptr, ptr %l3, !tbaa !29
  %t1307 = load ptr, ptr %l632, !tbaa !29
  %t1309 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfRefs(ptr %v0, ptr %v1, ptr %t1307, ptr %t1306)
  store i1 %t1309, ptr %l636
  br label %bb397
bb397:
  %t1310 = load i1, ptr %l636, !tbaa !21
  store i1 %t1310, ptr %l631, !tbaa !21
  br label %bb398
bb398:
  %t1311 = load i1, ptr %l631, !tbaa !21
  %t1312 = load ptr, ptr %l0, !tbaa !29
  %t1316 = getelementptr %"compiler/scope:Scoper", ptr %t1312, i32 0, i32 120
  store i1 %t1311, ptr %t1316, !tbaa !21
  %t1317 = load ptr, ptr %l0, !tbaa !29
  %t1318 = load ptr, ptr %l3, !tbaa !29
  %t1319 = load { i64, [2 x i64] }, ptr %l17
  %t1323 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1317, ptr %t1318, { i64, [2 x i64] } %t1319)
  store %"compiler/scope:Val" %t1323, ptr %l642
  br label %bb399
bb399:
  %t1324 = load %"compiler/scope:Val", ptr %l642
  store %"compiler/scope:Val" %t1324, ptr %l30
  %t1325 = load ptr, ptr %l0, !tbaa !29
  %t1327 = getelementptr %"compiler/scope:Scoper", ptr %t1325, i32 0, i32 120
  store i1 false, ptr %t1327, !tbaa !21
  %t1328 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1328, ptr %l644, !tbaa !29
  %t1329 = load i32, ptr %l2, !tbaa !23
  store i32 %t1329, ptr %l645, !tbaa !23
  %t1330 = load ptr, ptr %l3, !tbaa !29
  %t1332 = icmp eq ptr %t1330, null
  br i1 %t1332, label %bb400, label %bb401
bb400:
  call void @__olang_check_failed(ptr @olang_loc_bc57042d1b9aa9c8_42b203ed434388d4)
  unreachable
bb401:
  br label %bb402
bb402:
  %t1334 = load ptr, ptr %l3, !tbaa !29
  %t1335 = load ptr, ptr %l644, !tbaa !29
  %t1336 = load i32, ptr %l645, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %t1335, i32 %t1336, ptr %t1334)
  br label %bb403
bb403:
  %t1338 = getelementptr %"compiler/scope:Val", ptr %l30, i32 0, i32 1
  %t1339 = load { i64, [2 x i64] }, ptr %t1338
  %t1343 = extractvalue { i64, [2 x i64] } %t1339, 0
  %t1344 = icmp eq i64 %t1343, 5
  br i1 %t1344, label %bb404, label %bb405
bb404:
  br label %bb406
bb405:
  br label %bb433
bb406:
  %t1346 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t1347 = load i32, ptr %t1346, !range !{i32 0, i32 7}
  %t1349 = trunc i64 6 to i32
  %t1350 = icmp eq i32 %t1347, %t1349
  br i1 %t1350, label %bb407, label %bb408
bb407:
  %t1352 = load ptr, ptr %l0, !tbaa !29
  %t1353 = load i32, ptr %l5, !tbaa !23
  %t1356 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t1352, i32 %t1353)
  store i1 %t1356, ptr %l656
  br label %bb409
bb408:
  br label %bb417
bb409:
  %t1357 = load i1, ptr %l656, !tbaa !21
  store i1 %t1357, ptr %l32, !tbaa !21
  %t1358 = load ptr, ptr %l0, !tbaa !29
  %t1359 = load i64, ptr @G_2ecompiler_2fscope_2eWhyHolds, !tbaa !24
  %t1362 = getelementptr %"compiler/scope:Scoper", ptr %t1358, i32 0, i32 101
  store i64 %t1359, ptr %t1362, !tbaa !24
  %t1363 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1363, ptr %l659, !tbaa !29
  %t1364 = getelementptr %"compiler/scope:Val", ptr %l30, i32 0, i32 1
  %t1365 = load { i64, [2 x i64] }, ptr %t1364
  store { i64, [2 x i64] } %t1365, ptr %l660
  %t1366 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t1366, ptr %l661
  %t1367 = load i1, ptr %l32, !tbaa !21
  store i1 %t1367, ptr %l662, !tbaa !21
  %t1368 = load ptr, ptr %l3, !tbaa !29
  %t1370 = icmp eq ptr %t1368, null
  br i1 %t1370, label %bb410, label %bb411
bb410:
  call void @__olang_check_failed(ptr @olang_loc_19aa55fe70facde7_b663d059e4ca19e3)
  unreachable
bb411:
  br label %bb412
bb412:
  %t1372 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1372, ptr %l665, !tbaa !29
  %t1373 = load i1, ptr %l32, !tbaa !21
  br i1 %t1373, label %bb413, label %bb414
bb413:
  %t1375 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  store i64 %t1375, ptr %l667, !tbaa !24
  br label %bb415
bb414:
  %t1377 = load i64, ptr @G_2ecompiler_2fscope_2eFitDecl, !tbaa !24
  store i64 %t1377, ptr %l667, !tbaa !24
  br label %bb415
bb415:
  %t1379 = load ptr, ptr %l659, !tbaa !29
  %t1380 = load { i64, [2 x i64] }, ptr %l660
  %t1381 = load { i64, [2 x i64] }, ptr %l661
  %t1382 = load i1, ptr %l662, !tbaa !21
  %t1383 = load ptr, ptr %l665, !tbaa !29
  %t1384 = load i64, ptr %l667, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t1379, { i64, [2 x i64] } %t1380, { i64, [2 x i64] } %t1381, i1 %t1382, ptr %t1383, i64 %t1384)
  br label %bb416
bb416:
  %t1385 = load ptr, ptr %l0, !tbaa !29
  %t1387 = getelementptr %"compiler/scope:Scoper", ptr %t1385, i32 0, i32 101
  store i64 0, ptr %t1387, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb417:
  %t1388 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t1389 = load { i64, [2 x i64] }, ptr %t1388
  %t1391 = extractvalue { i64, [2 x i64] } %t1389, 0
  %t1392 = icmp eq i64 %t1391, 1
  br i1 %t1392, label %bb418, label %bb419
bb418:
  %t1394 = load ptr, ptr %l0, !tbaa !29
  %t1395 = load i32, ptr %l5, !tbaa !23
  %t1398 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t1394, i32 %t1395)
  store i1 %t1398, ptr %l676
  br label %bb420
bb419:
  store i1 false, ptr %l673, !tbaa !21
  br label %bb421
bb420:
  %t1399 = load i1, ptr %l676, !tbaa !21
  store i1 %t1399, ptr %l673, !tbaa !21
  br label %bb421
bb421:
  %t1400 = load i1, ptr %l673, !tbaa !21
  br i1 %t1400, label %bb422, label %bb423
bb422:
  %t1401 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1401, ptr %l678, !tbaa !29
  %t1402 = load ptr, ptr %l3, !tbaa !29
  %t1404 = icmp eq ptr %t1402, null
  br i1 %t1404, label %bb424, label %bb425
bb423:
  store i1 false, ptr %l677, !tbaa !21
  br label %bb428
bb424:
  call void @__olang_check_failed(ptr @olang_loc_eca6e0b2d52570fa_4fe6c0f0f8e0b5fe)
  unreachable
bb425:
  br label %bb426
bb426:
  %t1406 = load ptr, ptr %l3, !tbaa !29
  %t1407 = load ptr, ptr %l678, !tbaa !29
  %t1409 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfRefs(ptr %v0, ptr %v1, ptr %t1407, ptr %t1406)
  store i1 %t1409, ptr %l682
  br label %bb427
bb427:
  %t1410 = load i1, ptr %l682, !tbaa !21
  store i1 %t1410, ptr %l677, !tbaa !21
  br label %bb428
bb428:
  %t1411 = load i1, ptr %l677, !tbaa !21
  br i1 %t1411, label %bb429, label %bb430
bb429:
  %t1412 = load ptr, ptr %l0, !tbaa !29
  %t1414 = getelementptr %"compiler/scope:Scoper", ptr %t1412, i32 0, i32 31
  %t1415 = load i32, ptr %l2, !tbaa !23
  %t1417 = sext i32 %t1415 to i64
  %t1418 = getelementptr %"compiler/scope:Val", ptr %l30, i32 0, i32 1
  %t1419 = load { i64, [2 x i64] }, ptr %t1418
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1414, i64 %t1417, { i64, [2 x i64] } %t1419)
  br label %bb431
bb430:
  br label %bb432
bb431:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb432:
  br label %bb438
bb433:
  br i1 true, label %bb434, label %bb435
bb434:
  br label %bb436
bb435:
  br label %bb437
bb436:
  br label %bb438
bb437:
  call void @__olang_check_failed(ptr @olang_loc_acdf13ac8090b308_c550e3cb7d47705c)
  unreachable
bb438:
  %t1423 = getelementptr %"compiler/scope:Val", ptr %l30, i32 0, i32 0
  %t1424 = load i32, ptr %t1423, !range !{i32 0, i32 5}
  %t1426 = trunc i64 2 to i32
  %t1427 = icmp eq i32 %t1424, %t1426
  br i1 %t1427, label %bb439, label %bb440
bb439:
  %t1429 = load ptr, ptr %l0, !tbaa !29
  %t1431 = getelementptr %"compiler/scope:Scoper", ptr %t1429, i32 0, i32 27
  %t1432 = load i1, ptr %t1431, !tbaa !21
  store i1 %t1432, ptr %l690, !tbaa !21
  br label %bb441
bb440:
  store i1 false, ptr %l690, !tbaa !21
  br label %bb441
bb441:
  %t1434 = load i1, ptr %l690, !tbaa !21
  br i1 %t1434, label %bb442, label %bb443
bb442:
  %t1435 = load ptr, ptr %l0, !tbaa !29
  %t1436 = load { i64, [2 x i64] }, ptr %l17
  %t1439 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunknownBinding(ptr %v0, ptr %t1435, { i64, [2 x i64] } %t1436)
  store i1 %t1439, ptr %l696
  br label %bb444
bb443:
  store i1 false, ptr %l693, !tbaa !21
  br label %bb445
bb444:
  %t1440 = load i1, ptr %l696, !tbaa !21
  store i1 %t1440, ptr %l693, !tbaa !21
  br label %bb445
bb445:
  %t1441 = load i1, ptr %l693, !tbaa !21
  br i1 %t1441, label %bb446, label %bb447
bb446:
  store %olang.scope zeroinitializer, ptr %s43
  %t1442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1442, ptr %l697, !tbaa !29
  %t1443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1443, ptr %l698, !tbaa !29
  %t1444 = load ptr, ptr %l3, !tbaa !29
  %t1446 = icmp eq ptr %t1444, null
  br i1 %t1446, label %bb448, label %bb449
bb447:
  br label %bb454
bb448:
  call void @__olang_check_failed(ptr @olang_loc_3b111cc35ad2064c_5bc510d97bfe7450)
  unreachable
bb449:
  br label %bb450
bb450:
  %t1448 = load ptr, ptr %l3, !tbaa !29
  %t1449 = load ptr, ptr %l698, !tbaa !29
  %t1451 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t1449, ptr %t1448)
  store %"compiler/source:Span" %t1451, ptr %l702
  br label %bb451
bb451:
  %t1452 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %s43)
  store %"compiler/msgs:Msg" %t1452, ptr %l703
  br label %bb452
bb452:
  %t1453 = load ptr, ptr %l697, !tbaa !29
  %t1454 = load %"compiler/source:Span", ptr %l702
  %t1455 = load %"compiler/msgs:Msg", ptr %l703
  %t1456 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s43, ptr %t1453, %"compiler/source:Span" %t1454, %"compiler/msgs:Msg" %t1455)
  store i64 %t1456, ptr %l704
  br label %bb453
bb453:
  call void @__olang_scope_close(ptr %s43)
  br label %bb454
bb454:
  %t1457 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t1458 = load i32, ptr %t1457, !range !{i32 0, i32 7}
  %t1460 = trunc i64 6 to i32
  %t1461 = icmp eq i32 %t1458, %t1460
  br i1 %t1461, label %bb455, label %bb456
bb455:
  %t1463 = getelementptr %"compiler/scope:Val", ptr %l30, i32 0, i32 0
  %t1464 = load i32, ptr %t1463, !range !{i32 0, i32 5}
  %t1466 = trunc i64 2 to i32
  %t1467 = icmp eq i32 %t1464, %t1466
  store i1 %t1467, ptr %l707, !tbaa !21
  br label %bb457
bb456:
  store i1 false, ptr %l707, !tbaa !21
  br label %bb457
bb457:
  %t1469 = load i1, ptr %l707, !tbaa !21
  br i1 %t1469, label %bb458, label %bb459
bb458:
  %t1470 = getelementptr %"compiler/scope:Val", ptr %l30, i32 0, i32 1
  %t1471 = load { i64, [2 x i64] }, ptr %t1470
  store { i64, [2 x i64] } %t1471, ptr %l711
  %t1472 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t1472, ptr %l713
  %t1475 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l711, ptr %l713)
  store i1 %t1475, ptr %l715
  br label %bb460
bb459:
  store i1 false, ptr %l710, !tbaa !21
  br label %bb461
bb460:
  %t1476 = load i1, ptr %l715, !tbaa !21
  %t1477 = xor i1 %t1476, true
  store i1 %t1477, ptr %l710, !tbaa !21
  br label %bb461
bb461:
  %t1479 = load i1, ptr %l710, !tbaa !21
  br i1 %t1479, label %bb462, label %bb463
bb462:
  %t1480 = getelementptr %"compiler/scope:Val", ptr %l30, i32 0, i32 1
  %t1481 = load { i64, [2 x i64] }, ptr %t1480
  %t1483 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRelatable({ i64, [2 x i64] } %t1481)
  store i1 %t1483, ptr %l719
  br label %bb464
bb463:
  store i1 false, ptr %l717, !tbaa !21
  br label %bb465
bb464:
  %t1484 = load i1, ptr %l719, !tbaa !21
  store i1 %t1484, ptr %l717, !tbaa !21
  br label %bb465
bb465:
  %t1485 = load i1, ptr %l717, !tbaa !21
  br i1 %t1485, label %bb466, label %bb467
bb466:
  %t1486 = load ptr, ptr %l0, !tbaa !29
  %t1487 = load i64, ptr @G_2ecompiler_2fscope_2eWhyField, !tbaa !24
  %t1490 = getelementptr %"compiler/scope:Scoper", ptr %t1486, i32 0, i32 101
  store i64 %t1487, ptr %t1490, !tbaa !24
  %t1491 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1491, ptr %l722, !tbaa !29
  %t1492 = getelementptr %"compiler/scope:Val", ptr %l30, i32 0, i32 1
  %t1493 = load { i64, [2 x i64] }, ptr %t1492
  store { i64, [2 x i64] } %t1493, ptr %l723
  %t1494 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t1494, ptr %l724
  %t1495 = load ptr, ptr %l3, !tbaa !29
  %t1497 = icmp eq ptr %t1495, null
  br i1 %t1497, label %bb468, label %bb469
bb467:
  br label %bb472
bb468:
  call void @__olang_check_failed(ptr @olang_loc_3b2e5dd5e19962bb_2cdcb9ba8ccbb9af)
  unreachable
bb469:
  br label %bb470
bb470:
  %t1499 = load ptr, ptr %l3, !tbaa !29
  %t1500 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  %t1501 = load ptr, ptr %l722, !tbaa !29
  %t1502 = load { i64, [2 x i64] }, ptr %l723
  %t1503 = load { i64, [2 x i64] }, ptr %l724
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t1501, { i64, [2 x i64] } %t1502, { i64, [2 x i64] } %t1503, i1 false, ptr %t1499, i64 %t1500)
  br label %bb471
bb471:
  %t1506 = load ptr, ptr %l0, !tbaa !29
  %t1508 = getelementptr %"compiler/scope:Scoper", ptr %t1506, i32 0, i32 101
  store i64 0, ptr %t1508, !tbaa !24
  br label %bb472
bb472:
  %t1509 = getelementptr %"compiler/scope:Val", ptr %l30, i32 0, i32 0
  %t1510 = load i32, ptr %t1509, !range !{i32 0, i32 5}
  %t1512 = trunc i64 3 to i32
  %t1513 = icmp eq i32 %t1510, %t1512
  br i1 %t1513, label %bb473, label %bb474
bb473:
  %t1515 = load ptr, ptr %l0, !tbaa !29
  %t1516 = load i32, ptr %l5, !tbaa !23
  %t1519 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enarrowingMatters(ptr %v0, ptr %t1515, i32 %t1516)
  store i1 %t1519, ptr %l734
  br label %bb475
bb474:
  br label %bb487
bb475:
  %t1520 = load i1, ptr %l734, !tbaa !21
  store i1 %t1520, ptr %l33, !tbaa !21
  %t1521 = load i64, ptr @G_2ecompiler_2fscope_2eFitLocal, !tbaa !24
  store i64 %t1521, ptr %l34, !tbaa !24
  %t1523 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t1524 = load i32, ptr %t1523, !range !{i32 0, i32 7}
  %t1526 = trunc i64 6 to i32
  %t1527 = icmp eq i32 %t1524, %t1526
  br i1 %t1527, label %bb476, label %bb477
bb476:
  %t1529 = load ptr, ptr %l0, !tbaa !29
  %t1530 = load i32, ptr %l5, !tbaa !23
  %t1533 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t1529, i32 %t1530)
  store i1 %t1533, ptr %l740
  br label %bb478
bb477:
  br label %bb482
bb478:
  %t1534 = load i1, ptr %l740, !tbaa !21
  store i1 %t1534, ptr %l33, !tbaa !21
  %t1535 = load i1, ptr %l33, !tbaa !21
  br i1 %t1535, label %bb479, label %bb480
bb479:
  %t1537 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  store i64 %t1537, ptr %l742, !tbaa !24
  br label %bb481
bb480:
  %t1539 = load i64, ptr @G_2ecompiler_2fscope_2eFitDecl, !tbaa !24
  store i64 %t1539, ptr %l742, !tbaa !24
  br label %bb481
bb481:
  %t1541 = load i64, ptr %l742, !tbaa !24
  store i64 %t1541, ptr %l34, !tbaa !24
  %t1542 = load ptr, ptr %l0, !tbaa !29
  %t1543 = load i64, ptr @G_2ecompiler_2fscope_2eWhyHolds, !tbaa !24
  %t1546 = getelementptr %"compiler/scope:Scoper", ptr %t1542, i32 0, i32 101
  store i64 %t1543, ptr %t1546, !tbaa !24
  br label %bb482
bb482:
  %t1547 = load ptr, ptr %l0, !tbaa !29
  %t1548 = load i32, ptr %l2, !tbaa !23
  %t1550 = sext i32 %t1548 to i64
  %t1553 = getelementptr %"compiler/scope:Scoper", ptr %t1547, i32 0, i32 134
  store i64 %t1550, ptr %t1553, !tbaa !24
  %t1554 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1554, ptr %l750, !tbaa !29
  %t1555 = getelementptr %"compiler/scope:Val", ptr %l30, i32 0, i32 1
  %t1556 = load { i64, [2 x i64] }, ptr %t1555
  store { i64, [2 x i64] } %t1556, ptr %l751
  %t1557 = load { i64, [2 x i64] }, ptr %l17
  store { i64, [2 x i64] } %t1557, ptr %l752
  %t1558 = load i1, ptr %l33, !tbaa !21
  store i1 %t1558, ptr %l753, !tbaa !21
  %t1559 = load ptr, ptr %l3, !tbaa !29
  %t1561 = icmp eq ptr %t1559, null
  br i1 %t1561, label %bb483, label %bb484
bb483:
  call void @__olang_check_failed(ptr @olang_loc_3005b9c21f34ca3e_35904d8c355f64ba)
  unreachable
bb484:
  br label %bb485
bb485:
  %t1563 = load ptr, ptr %l3, !tbaa !29
  %t1564 = load i64, ptr %l34, !tbaa !24
  %t1565 = load ptr, ptr %l750, !tbaa !29
  %t1566 = load { i64, [2 x i64] }, ptr %l751
  %t1567 = load { i64, [2 x i64] }, ptr %l752
  %t1568 = load i1, ptr %l753, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t1565, { i64, [2 x i64] } %t1566, { i64, [2 x i64] } %t1567, i1 %t1568, ptr %t1563, i64 %t1564)
  br label %bb486
bb486:
  %t1571 = load ptr, ptr %l0, !tbaa !29
  %t1573 = getelementptr %"compiler/scope:Scoper", ptr %t1571, i32 0, i32 134
  store i64 -1, ptr %t1573, !tbaa !24
  %t1574 = load ptr, ptr %l0, !tbaa !29
  %t1576 = getelementptr %"compiler/scope:Scoper", ptr %t1574, i32 0, i32 101
  store i64 0, ptr %t1576, !tbaa !24
  br label %bb487
bb487:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftLocal(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i1
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca %"compiler/typed:Local"
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l22 = alloca ptr
  %l26 = alloca ptr
  %l35 = alloca %"compiler/typed:Local"
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l47 = alloca %"compiler/typed:Local"
  %l49 = alloca { i64, ptr }
  %l54 = alloca i1
  %l55 = alloca i64
  %l58 = alloca i64
  %l60 = alloca i1
  %l64 = alloca i64
  %l66 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l73 = alloca i1
  %l77 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i64
  %l84 = alloca i64
  %l87 = alloca ptr
  %l91 = alloca ptr
  %l100 = alloca %"compiler/typed:Local"
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, [2 x i64] }
  %l107 = alloca i64
  %l108 = alloca ptr
  %l117 = alloca %"compiler/typed:Local"
  %l119 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l126 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l127 = alloca { i64, [2 x i64] }
  %l131 = alloca { i64, [2 x i64] }
  %l132 = alloca i32
  %l136 = alloca { i64, [2 x i64] }
  %l138 = alloca i1
  %l139 = alloca { i64, [2 x i64] }
  %l143 = alloca { i64, [2 x i64] }
  %l146 = alloca i1
  %l148 = alloca i1
  %l150 = alloca i1
  %l152 = alloca i1
  %l153 = alloca { i64, [2 x i64] }
  %l155 = alloca { i64, [2 x i64] }
  %l157 = alloca i1
  %l159 = alloca i1
  %l160 = alloca { i64, [2 x i64] }
  %l162 = alloca { i64, [2 x i64] }
  %l164 = alloca i1
  %l165 = alloca i1
  %l169 = alloca i64
  %l175 = alloca { i64, [2 x i64] }
  %l177 = alloca { i64, [2 x i64] }
  %l179 = alloca i1
  %l181 = alloca ptr
  %l190 = alloca %"compiler/typed:Local"
  %l192 = alloca i1
  %l193 = alloca i1
  %l194 = alloca ptr
  %l203 = alloca %"compiler/typed:Local"
  %l205 = alloca i1
  %l208 = alloca i1
  %l210 = alloca i1
  %l212 = alloca i1
  %l214 = alloca i1
  %l218 = alloca i1
  %l245 = alloca %"compiler/typed:Local"
  %l247 = alloca ptr
  %l253 = alloca { i64, ptr }
  %l254 = alloca { i64, [2 x i64] }
  %l256 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l264 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.builder
  %s13room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, [2 x i64] }, ptr %l2
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenResult(ptr %v0, ptr %t1, { i64, [2 x i64] } %t2)
  store i1 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i1, ptr %l12, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/scope:Scoper", ptr %t7, i32 0, i32 130
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsOwn(ptr %v0, ptr %t12, i64 %t13)
  store i1 %t16, ptr %l18
  br label %bb7
bb6:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb7:
  %t17 = load i1, ptr %l18, !tbaa !21
  store i1 %t17, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 146
  %t22 = load i1, ptr %t21, !tbaa !21
  br i1 %t22, label %bb11, label %bb12
bb10:
  br label %bb25
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 147
  store ptr %t26, ptr %l22, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/load:Loader", ptr %t33, i32 0, i32 3
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l26, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 25
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  br i1 %t42, label %bb13, label %bb14
bb12:
  br label %bb24
bb13:
  call void @__olang_check_failed(ptr @olang_loc_cf25d893b5e0925b_26a5f8a01e1a0e87)
  unreachable
bb14:
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 25
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t47, i32 0, i32 7
  %t51 = load i64, ptr %l1, !tbaa !24
  %t54 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t50, i64 %t51)
  store %"compiler/typed:Local" %t54, ptr %l35
  br label %bb16
bb16:
  %t55 = getelementptr %"compiler/typed:Local", ptr %l35, i32 0, i32 0
  %t56 = load i32, ptr %t55, !tbaa !23
  %t57 = load ptr, ptr %l26, !tbaa !29
  %t59 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s3, ptr %t57, i32 %t56)
  store { i64, ptr } %t59, ptr %l37
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l38, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/scope:Scoper", ptr %t61, i32 0, i32 25
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = icmp eq ptr %t64, null
  br i1 %t66, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_cf25d893b5e0925b_26a5f8a01e1a0e87)
  unreachable
bb19:
  br label %bb20
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 25
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 7
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t74, i64 %t75)
  store %"compiler/typed:Local" %t78, ptr %l47
  br label %bb21
bb21:
  %t79 = getelementptr %"compiler/typed:Local", ptr %l47, i32 0, i32 1
  %t80 = getelementptr %"compiler/source:Span", ptr %t79, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t84 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etraceAt(ptr %v0, ptr %s3, ptr %t82, i32 %t81)
  store { i64, ptr } %t84, ptr %l49
  br label %bb22
bb22:
  %t85 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t87 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = add i64 %t86, %t89
  %t91 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t94 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = add i64 %t93, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t85, i64 %t86)
  %t99 = getelementptr i8, ptr %t98, i64 %t86
  call void @olang_textcopy(ptr %t99, ptr %t88, i64 %t89)
  %t100 = getelementptr i8, ptr %t99, i64 %t89
  call void @olang_textcopy(ptr %t100, ptr %t91, i64 %t92)
  %t101 = getelementptr i8, ptr %t100, i64 %t92
  call void @olang_textcopy(ptr %t101, ptr %t95, i64 %t96)
  %t102 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t98, 1
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t106 = extractvalue { i64, ptr } %t103, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t111 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t111, { i64, ptr } %t110)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  %t113 = load i64, ptr %l1, !tbaa !24
  %t115 = icmp slt i64 %t113, 0
  br i1 %t115, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb29
bb27:
  %t117 = load i64, ptr %l1, !tbaa !24
  store i64 %t117, ptr %l55, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/scope:Scoper", ptr %t118, i32 0, i32 132
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t120)
  store i64 %t122, ptr %l58
  br label %bb28
bb28:
  %t123 = load i64, ptr %l55, !tbaa !24
  %t124 = load i64, ptr %l58, !tbaa !24
  %t125 = icmp sge i64 %t123, %t124
  store i1 %t125, ptr %l54, !tbaa !21
  br label %bb29
bb29:
  %t127 = load i1, ptr %l54, !tbaa !21
  br i1 %t127, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb33
bb31:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/scope:Scoper", ptr %t128, i32 0, i32 132
  %t131 = load i64, ptr %l1, !tbaa !24
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t130, i64 %t131)
  store i64 %t134, ptr %l64
  br label %bb32
bb32:
  %t135 = load i64, ptr %l64, !tbaa !24
  %t136 = icmp eq i64 %t135, -2
  store i1 %t136, ptr %l60, !tbaa !21
  br label %bb33
bb33:
  %t138 = load i1, ptr %l60, !tbaa !21
  br i1 %t138, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb37
bb35:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i64, ptr %l1, !tbaa !24
  %t143 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftable(ptr %v0, ptr %t139, i64 %t140)
  store i1 %t143, ptr %l69
  br label %bb36
bb36:
  %t144 = load i1, ptr %l69, !tbaa !21
  %t145 = xor i1 %t144, true
  store i1 %t145, ptr %l66, !tbaa !21
  br label %bb37
bb37:
  %t147 = load i1, ptr %l66, !tbaa !21
  br i1 %t147, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb41
bb39:
  %t148 = load { i64, [2 x i64] }, ptr %l2
  %t150 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t148)
  store i1 %t150, ptr %l73
  br label %bb40
bb40:
  %t151 = load i1, ptr %l73, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l71, !tbaa !21
  br label %bb41
bb41:
  %t154 = load i1, ptr %l71, !tbaa !21
  br i1 %t154, label %bb42, label %bb43
bb42:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/scope:Scoper", ptr %t155, i32 0, i32 146
  %t158 = load i1, ptr %t157, !tbaa !21
  br i1 %t158, label %bb44, label %bb45
bb43:
  br label %bb67
bb44:
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = icmp sge i64 %t160, 0
  store i1 %t162, ptr %l77, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb46
bb46:
  %t164 = load i1, ptr %l77, !tbaa !21
  br i1 %t164, label %bb47, label %bb48
bb47:
  %t165 = load i64, ptr %l1, !tbaa !24
  store i64 %t165, ptr %l81, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/scope:Scoper", ptr %t166, i32 0, i32 132
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t168)
  store i64 %t170, ptr %l84
  br label %bb49
bb48:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb50
bb49:
  %t171 = load i64, ptr %l81, !tbaa !24
  %t172 = load i64, ptr %l84, !tbaa !24
  %t173 = icmp slt i64 %t171, %t172
  store i1 %t173, ptr %l80, !tbaa !21
  br label %bb50
bb50:
  %t175 = load i1, ptr %l80, !tbaa !21
  br i1 %t175, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s6
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/scope:Scoper", ptr %t176, i32 0, i32 147
  store ptr %t178, ptr %l87, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/scope:Scoper", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 0
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/load:Loader", ptr %t185, i32 0, i32 3
  %t188 = load ptr, ptr %t187, !tbaa !29
  store ptr %t188, ptr %l91, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/scope:Scoper", ptr %t189, i32 0, i32 25
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = icmp eq ptr %t192, null
  br i1 %t194, label %bb53, label %bb54
bb52:
  br label %bb66
bb53:
  call void @__olang_check_failed(ptr @olang_loc_56753b57ce5c76c_5bd4f5104db7b168)
  unreachable
bb54:
  br label %bb55
bb55:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/scope:Scoper", ptr %t196, i32 0, i32 25
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Body", ptr %t199, i32 0, i32 7
  %t203 = load i64, ptr %l1, !tbaa !24
  %t206 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t202, i64 %t203)
  store %"compiler/typed:Local" %t206, ptr %l100
  br label %bb56
bb56:
  %t207 = getelementptr %"compiler/typed:Local", ptr %l100, i32 0, i32 0
  %t208 = load i32, ptr %t207, !tbaa !23
  %t209 = load ptr, ptr %l91, !tbaa !29
  %t211 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s6, ptr %t209, i32 %t208)
  store { i64, ptr } %t211, ptr %l102
  br label %bb57
bb57:
  %t212 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t212, ptr %l103
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/scope:Scoper", ptr %t213, i32 0, i32 132
  %t216 = load i64, ptr %l1, !tbaa !24
  %t219 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t215, i64 %t216)
  store i64 %t219, ptr %l107
  br label %bb58
bb58:
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l108, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/scope:Scoper", ptr %t221, i32 0, i32 25
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = icmp eq ptr %t224, null
  br i1 %t226, label %bb59, label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_56753b57ce5c76c_5bd4f5104db7b168)
  unreachable
bb60:
  br label %bb61
bb61:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/scope:Scoper", ptr %t228, i32 0, i32 25
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t234 = getelementptr %"compiler/typed:Body", ptr %t231, i32 0, i32 7
  %t235 = load i64, ptr %l1, !tbaa !24
  %t238 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t234, i64 %t235)
  store %"compiler/typed:Local" %t238, ptr %l117
  br label %bb62
bb62:
  %t239 = getelementptr %"compiler/typed:Local", ptr %l117, i32 0, i32 1
  %t240 = getelementptr %"compiler/source:Span", ptr %t239, i32 0, i32 0
  %t241 = load i32, ptr %t240, !tbaa !23
  %t242 = load ptr, ptr %l108, !tbaa !29
  %t244 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etraceAt(ptr %v0, ptr %s6, ptr %t242, i32 %t241)
  store { i64, ptr } %t244, ptr %l119
  br label %bb63
bb63:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t245 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t246 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t245, i64 %t246)
  %t247 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 1
  %t249 = extractvalue { i64, ptr } %t247, 0
  call void @__olang_sb_put(ptr %s7, ptr %t248, i64 %t249)
  %t250 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t251 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t250, i64 %t251)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %s7, ptr %l103, i64 0)
  br label %bb64
bb64:
  %t253 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t253, i64 %t254)
  %t255 = load i64, ptr %l107, !tbaa !24
  %t256 = call ptr @__olang_sb_room(ptr %s7, i64 24)
  %t257 = call i64 @__olang_fmt_i64(ptr %t256, i64 %t255)
  call void @__olang_sb_add(ptr %s7, i64 %t257)
  %t258 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t259 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t258, i64 %t259)
  %t260 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  call void @__olang_sb_put(ptr %s7, ptr %t261, i64 %t262)
  %t263 = load ptr, ptr %s7
  %t264 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t265 = load i64, ptr %t264
  %t266 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t265)
  call void @olang_textcopy(ptr %t266, ptr %t263, i64 %t265)
  %t267 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l121, !tbaa !27
  %t269 = getelementptr %olang.builder, ptr %s7, i32 0, i32 3
  %t270 = load ptr, ptr %t269
  %t271 = icmp ne ptr %t270, null
  br i1 %t271, label %sbgrew.272, label %sbdone.273
sbgrew.272:
  call void @__olang_sb_done(ptr %s7)
  br label %sbdone.273
sbdone.273:
  %t274 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  %t276 = extractvalue { i64, ptr } %t274, 1
  %t277 = mul i64 %t275, 1
  %t278 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t277)
  call void @llvm.memcpy.p0.p0.i64(ptr %t278, ptr %t276, i64 %t277, i1 false)
  %t279 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  %t281 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t281, { i64, ptr } %t280)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb67:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/scope:Scoper", ptr %t283, i32 0, i32 26
  %t286 = load i64, ptr %t285, !tbaa !24
  %t287 = load i64, ptr %l1, !tbaa !24
  %t290 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t286, i64 %t287)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t290, ptr %l126
  br label %bb68
bb68:
  %t291 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l126
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t291, ptr %l4
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/scope:Scoper", ptr %t292, i32 0, i32 125
  %t295 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t298 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H568ce559fa980123a387c6ba9ed21aca(ptr %v0, ptr %t294, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t295)
  %t299 = extractvalue { i32, { i64, [2 x i64] } } %t298, 1
  %t300 = extractvalue { i32, { i64, [2 x i64] } } %t298, 0
  store i32 %t300, ptr %l132
  %t301 = icmp ne i32 %t300, 0
  br i1 %t301, label %bb70, label %ok.302, !prof !99
ok.302:
  store { i64, [2 x i64] } %t299, ptr %l131
  br label %bb69
bb69:
  %t303 = load { i64, [2 x i64] }, ptr %l131
  store { i64, [2 x i64] } %t303, ptr %l127
  br label %bb73
bb70:
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/scope:Scoper", ptr %t304, i32 0, i32 31
  %t307 = load i64, ptr %l1, !tbaa !24
  %t310 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t306, i64 %t307)
  store { i64, [2 x i64] } %t310, ptr %l136
  br label %bb72
bb72:
  %t311 = load { i64, [2 x i64] }, ptr %l136
  store { i64, [2 x i64] } %t311, ptr %l127
  br label %bb73
bb73:
  %t312 = load { i64, [2 x i64] }, ptr %l127
  store { i64, [2 x i64] } %t312, ptr %l5
  %t313 = load { i64, [2 x i64] }, ptr %l5
  %t315 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t313)
  store i1 %t315, ptr %l138
  br label %bb74
bb74:
  %t316 = load i1, ptr %l138, !tbaa !21
  br i1 %t316, label %bb75, label %bb76
bb75:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load { i64, [2 x i64] }, ptr %l5
  %t319 = load { i64, [2 x i64] }, ptr %l2
  %t323 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoinTerm(ptr %v0, ptr %t317, { i64, [2 x i64] } %t318, { i64, [2 x i64] } %t319)
  store { i64, [2 x i64] } %t323, ptr %l143
  br label %bb77
bb76:
  %t324 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t324, ptr %l139
  br label %bb78
bb77:
  %t326 = load { i64, [2 x i64] }, ptr %l143
  store { i64, [2 x i64] } %t326, ptr %l139
  br label %bb78
bb78:
  %t327 = load { i64, [2 x i64] }, ptr %l139
  store { i64, [2 x i64] } %t327, ptr %l6
  %t328 = load { i64, [2 x i64] }, ptr %l5
  %t330 = call i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %t328)
  store i1 %t330, ptr %l146
  br label %bb79
bb79:
  %t331 = load i1, ptr %l146, !tbaa !21
  %t332 = xor i1 %t331, true
  br i1 %t332, label %bb80, label %bb81
bb80:
  %t334 = load { i64, [2 x i64] }, ptr %l2
  %t336 = call i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %t334)
  store i1 %t336, ptr %l150
  br label %bb82
bb81:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb83
bb82:
  %t337 = load i1, ptr %l150, !tbaa !21
  %t338 = xor i1 %t337, true
  store i1 %t338, ptr %l148, !tbaa !21
  br label %bb83
bb83:
  %t340 = load i1, ptr %l148, !tbaa !21
  br i1 %t340, label %bb84, label %bb85
bb84:
  %t341 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t341, ptr %l153
  %t342 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t342, ptr %l155
  %t345 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l153, ptr %l155)
  store i1 %t345, ptr %l157
  br label %bb86
bb85:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb87
bb86:
  %t346 = load i1, ptr %l157, !tbaa !21
  %t347 = xor i1 %t346, true
  store i1 %t347, ptr %l152, !tbaa !21
  br label %bb87
bb87:
  %t349 = load i1, ptr %l152, !tbaa !21
  br i1 %t349, label %bb88, label %bb89
bb88:
  %t350 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t350, ptr %l160
  %t351 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t351, ptr %l162
  %t354 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l160, ptr %l162)
  store i1 %t354, ptr %l164
  br label %bb90
bb89:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb91
bb90:
  %t355 = load i1, ptr %l164, !tbaa !21
  store i1 %t355, ptr %l159, !tbaa !21
  br label %bb91
bb91:
  %t356 = load i1, ptr %l159, !tbaa !21
  br i1 %t356, label %bb92, label %bb93
bb92:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load { i64, [2 x i64] }, ptr %l5
  %t359 = load { i64, [2 x i64] }, ptr %l2
  %t363 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t357, { i64, [2 x i64] } %t358, { i64, [2 x i64] } %t359)
  store i64 %t363, ptr %l169
  br label %bb94
bb93:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb95
bb94:
  %t364 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t365 = load i64, ptr %l169, !tbaa !24
  %t367 = icmp ne i64 %t365, %t364
  store i1 %t367, ptr %l165, !tbaa !21
  br label %bb95
bb95:
  %t369 = load i1, ptr %l165, !tbaa !21
  br i1 %t369, label %bb96, label %bb97
bb96:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/scope:Scoper", ptr %t370, i32 0, i32 128
  %t373 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t372, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t373, i1 true)
  br label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb99
bb99:
  %t376 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t376, ptr %l175
  %t377 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t377, ptr %l177
  %t380 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l175, ptr %l177)
  store i1 %t380, ptr %l179
  br label %bb100
bb100:
  %t381 = load i1, ptr %l179, !tbaa !21
  %t382 = xor i1 %t381, true
  store i1 %t382, ptr %l7, !tbaa !21
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l181, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t387 = getelementptr %"compiler/scope:Scoper", ptr %t385, i32 0, i32 25
  %t388 = load ptr, ptr %t387, !tbaa !29
  %t390 = icmp eq ptr %t388, null
  br i1 %t390, label %bb101, label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_14a6577ead1cc721_32dce333731fd63d)
  unreachable
bb102:
  br label %bb103
bb103:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/scope:Scoper", ptr %t392, i32 0, i32 25
  %t395 = load ptr, ptr %t394, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Body", ptr %t395, i32 0, i32 7
  %t399 = load i64, ptr %l1, !tbaa !24
  %t402 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t398, i64 %t399)
  store %"compiler/typed:Local" %t402, ptr %l190
  br label %bb104
bb104:
  %t403 = getelementptr %"compiler/typed:Local", ptr %l190, i32 0, i32 2
  %t404 = load i32, ptr %t403, !tbaa !23
  %t405 = load ptr, ptr %l181, !tbaa !29
  %t407 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t405, i32 %t404)
  store i1 %t407, ptr %l192
  br label %bb105
bb105:
  %t408 = load i1, ptr %l192, !tbaa !21
  br i1 %t408, label %bb106, label %bb107
bb106:
  %t409 = load ptr, ptr %l0, !tbaa !29
  store ptr %t409, ptr %l194, !tbaa !29
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/scope:Scoper", ptr %t410, i32 0, i32 25
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  br i1 %t415, label %bb108, label %bb109
bb107:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb113
bb108:
  call void @__olang_check_failed(ptr @olang_loc_14a6577ead1cc721_32dce333731fd63d)
  unreachable
bb109:
  br label %bb110
bb110:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/scope:Scoper", ptr %t417, i32 0, i32 25
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t423 = getelementptr %"compiler/typed:Body", ptr %t420, i32 0, i32 7
  %t424 = load i64, ptr %l1, !tbaa !24
  %t427 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t423, i64 %t424)
  store %"compiler/typed:Local" %t427, ptr %l203
  br label %bb111
bb111:
  %t428 = getelementptr %"compiler/typed:Local", ptr %l203, i32 0, i32 2
  %t429 = load i32, ptr %t428, !tbaa !23
  %t430 = load ptr, ptr %l194, !tbaa !29
  %t432 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t430, i32 %t429)
  store i1 %t432, ptr %l205
  br label %bb112
bb112:
  %t433 = load i1, ptr %l205, !tbaa !21
  %t434 = xor i1 %t433, true
  store i1 %t434, ptr %l193, !tbaa !21
  br label %bb113
bb113:
  %t436 = load i1, ptr %l193, !tbaa !21
  store i1 %t436, ptr %l8, !tbaa !21
  %t437 = load i1, ptr %l3, !tbaa !21
  br i1 %t437, label %bb114, label %bb115
bb114:
  %t439 = load i1, ptr %l8, !tbaa !21
  br i1 %t439, label %bb116, label %bb117
bb115:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb120
bb116:
  store i1 true, ptr %l210, !tbaa !21
  br label %bb119
bb117:
  %t441 = load { i64, [2 x i64] }, ptr %l6
  %t443 = call i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %t441)
  store i1 %t443, ptr %l212
  br label %bb118
bb118:
  %t444 = load i1, ptr %l212, !tbaa !21
  %t445 = xor i1 %t444, true
  store i1 %t445, ptr %l210, !tbaa !21
  br label %bb119
bb119:
  %t447 = load i1, ptr %l210, !tbaa !21
  store i1 %t447, ptr %l208, !tbaa !21
  br label %bb120
bb120:
  %t448 = load i1, ptr %l208, !tbaa !21
  br i1 %t448, label %bb121, label %bb122
bb121:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/scope:Scoper", ptr %t449, i32 0, i32 127
  %t452 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t455 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t451, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t452)
  store i1 %t455, ptr %l218
  br label %bb123
bb122:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb124
bb123:
  %t456 = load i1, ptr %l218, !tbaa !21
  %t457 = xor i1 %t456, true
  store i1 %t457, ptr %l214, !tbaa !21
  br label %bb124
bb124:
  %t459 = load i1, ptr %l214, !tbaa !21
  br i1 %t459, label %bb125, label %bb126
bb125:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/scope:Scoper", ptr %t460, i32 0, i32 127
  %t463 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t462, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t463, i1 true)
  br label %bb127
bb126:
  br label %bb128
bb127:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb128
bb128:
  %t466 = load i1, ptr %l7, !tbaa !21
  %t468 = xor i1 %t466, true
  br i1 %t468, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb130:
  br label %bb131
bb131:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = getelementptr %"compiler/scope:Scoper", ptr %t470, i32 0, i32 125
  %t473 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t474 = load { i64, [2 x i64] }, ptr %l6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H240bd86caf003ea6de374cb77d0dbfc6(ptr %v0, ptr %t472, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t473, { i64, [2 x i64] } %t474)
  br label %bb132
bb132:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr %"compiler/scope:Scoper", ptr %t478, i32 0, i32 130
  %t481 = load i1, ptr %t480, !tbaa !21
  br i1 %t481, label %bb133, label %bb134
bb133:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t485 = getelementptr %"compiler/scope:Scoper", ptr %t483, i32 0, i32 129
  %t486 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t485, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t486, i1 true)
  br label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb136
bb136:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/scope:Scoper", ptr %t489, i32 0, i32 124
  store i1 true, ptr %t491, !tbaa !21
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = getelementptr %"compiler/scope:Scoper", ptr %t492, i32 0, i32 146
  %t495 = load i1, ptr %t494, !tbaa !21
  br i1 %t495, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s12
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t499 = getelementptr %"compiler/scope:Scoper", ptr %t497, i32 0, i32 25
  %t500 = load ptr, ptr %t499, !tbaa !29
  %t502 = icmp eq ptr %t500, null
  br i1 %t502, label %bb139, label %bb140
bb138:
  br label %bb153
bb139:
  call void @__olang_check_failed(ptr @olang_loc_5be7cf6889c0719a_fac8d756f0ba6a56)
  unreachable
bb140:
  br label %bb141
bb141:
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t506 = getelementptr %"compiler/scope:Scoper", ptr %t504, i32 0, i32 25
  %t507 = load ptr, ptr %t506, !tbaa !29
  %t510 = getelementptr %"compiler/typed:Body", ptr %t507, i32 0, i32 7
  %t511 = load i64, ptr %l1, !tbaa !24
  %t514 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t510, i64 %t511)
  store %"compiler/typed:Local" %t514, ptr %l245
  br label %bb142
bb142:
  %t515 = load %"compiler/typed:Local", ptr %l245
  store %"compiler/typed:Local" %t515, ptr %l9
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/scope:Scoper", ptr %t516, i32 0, i32 147
  store ptr %t518, ptr %l247, !tbaa !29
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t521 = getelementptr %"compiler/scope:Scoper", ptr %t519, i32 0, i32 0
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t524 = getelementptr %"compiler/generic:Program", ptr %t522, i32 0, i32 0
  %t525 = load ptr, ptr %t524, !tbaa !29
  %t527 = getelementptr %"compiler/load:Loader", ptr %t525, i32 0, i32 3
  %t528 = load ptr, ptr %t527, !tbaa !29
  %t529 = getelementptr %"compiler/typed:Local", ptr %l9, i32 0, i32 0
  %t530 = load i32, ptr %t529, !tbaa !23
  %t533 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s12, ptr %t528, i32 %t530)
  store { i64, ptr } %t533, ptr %l253
  br label %bb143
bb143:
  %t534 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t534, ptr %l254
  %t535 = load i1, ptr %l3, !tbaa !21
  br i1 %t535, label %bb144, label %bb145
bb144:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l256, !tbaa !27
  br label %bb146
bb145:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l256, !tbaa !27
  br label %bb146
bb146:
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t539 = getelementptr %"compiler/scope:Scoper", ptr %t537, i32 0, i32 130
  %t540 = load i1, ptr %t539, !tbaa !21
  br i1 %t540, label %bb147, label %bb148
bb147:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l259, !tbaa !27
  br label %bb149
bb148:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l259, !tbaa !27
  br label %bb149
bb149:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t543 = getelementptr %"compiler/typed:Local", ptr %l9, i32 0, i32 1
  %t544 = getelementptr %"compiler/source:Span", ptr %t543, i32 0, i32 0
  %t545 = load i32, ptr %t544, !tbaa !23
  %t548 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etraceAt(ptr %v0, ptr %s12, ptr %t542, i32 %t545)
  store { i64, ptr } %t548, ptr %l262
  br label %bb150
bb150:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s13
  store ptr %s13room, ptr %s13
  %t549 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t550 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t549, i64 %t550)
  %t551 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t551, 1
  %t553 = extractvalue { i64, ptr } %t551, 0
  call void @__olang_sb_put(ptr %s13, ptr %t552, i64 %t553)
  %t554 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t555 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t554, i64 %t555)
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %s13, ptr %l254, i64 0)
  br label %bb151
bb151:
  %t557 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t558 = extractvalue { i64, ptr } %t557, 1
  %t559 = extractvalue { i64, ptr } %t557, 0
  call void @__olang_sb_put(ptr %s13, ptr %t558, i64 %t559)
  %t560 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t561 = extractvalue { i64, ptr } %t560, 1
  %t562 = extractvalue { i64, ptr } %t560, 0
  call void @__olang_sb_put(ptr %s13, ptr %t561, i64 %t562)
  %t563 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t564 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s13, ptr %t563, i64 %t564)
  %t565 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 1
  %t567 = extractvalue { i64, ptr } %t565, 0
  call void @__olang_sb_put(ptr %s13, ptr %t566, i64 %t567)
  %t568 = load ptr, ptr %s13
  %t569 = getelementptr %olang.builder, ptr %s13, i32 0, i32 1
  %t570 = load i64, ptr %t569
  %t571 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t570)
  call void @olang_textcopy(ptr %t571, ptr %t568, i64 %t570)
  %t572 = insertvalue { i64, ptr } undef, i64 %t570, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t571, 1
  store { i64, ptr } %t573, ptr %l264, !tbaa !27
  %t574 = getelementptr %olang.builder, ptr %s13, i32 0, i32 3
  %t575 = load ptr, ptr %t574
  %t576 = icmp ne ptr %t575, null
  br i1 %t576, label %sbgrew.577, label %sbdone.578
sbgrew.577:
  call void @__olang_sb_done(ptr %s13)
  br label %sbdone.578
sbdone.578:
  %t579 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t580 = extractvalue { i64, ptr } %t579, 0
  %t581 = extractvalue { i64, ptr } %t579, 1
  %t582 = mul i64 %t580, 1
  %t583 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t582)
  call void @llvm.memcpy.p0.p0.i64(ptr %t583, ptr %t581, i64 %t582, i1 false)
  %t584 = insertvalue { i64, ptr } undef, i64 %t580, 0
  %t585 = insertvalue { i64, ptr } %t584, ptr %t583, 1
  %t586 = load ptr, ptr %l247, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t586, { i64, ptr } %t585)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s12)
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftedCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t2, ptr %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t9 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t8)
  store ptr %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %s0, ptr %s0, ptr %t11, ptr %t10)
  store ptr %t13, ptr %l10
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l10, !tbaa !29
  store ptr %t14, ptr %l2, !tbaa !29
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Call", ptr %t22, i32 0, i32 3
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = sext i32 %t25 to i64
  %t30 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esiteLift(ptr %v0, ptr %t21, i64 %t27)
  store { i64, [2 x i64] } %t30, ptr %l19
  br label %bb6
bb5:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t31 = load { i64, [2 x i64] }, ptr %l19
  %t33 = extractvalue { i64, [2 x i64] } %t31, 0
  %t34 = icmp eq i64 %t33, 0
  %t36 = xor i1 %t34, true
  store i1 %t36, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i1, ptr %l14, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l19 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i1
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i1
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i64
  %l78 = alloca i1
  %l86 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca i1
  %l102 = alloca i1
  %l103 = alloca i1
  %l108 = alloca { i64, ptr }
  %l113 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t5, 32
  store i1 %t7, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t16 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v1, ptr %t11, ptr %t12)
  store ptr %t16, ptr %l19
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l19, !tbaa !29
  store ptr %t17, ptr %l1, !tbaa !29
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t20 = load ptr, ptr %l21, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t23 = load ptr, ptr %l21, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 5
  store i1 %t26, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l22, !tbaa !21
  br i1 %t27, label %bb10, label %bb11
bb10:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Promote", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = add i64 %t40, 1
  %t46 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t34, ptr %t38, i64 %t42)
  store i64 %t46, ptr %l33
  br label %bb13
bb13:
  %t47 = load i64, ptr %l33, !tbaa !24
  store i64 %t47, ptr %rv
  br label %ret
bb14:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t49 = load ptr, ptr %l34, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l34, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 2
  store i1 %t55, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t56 = load i1, ptr %l35, !tbaa !21
  br i1 %t56, label %bb17, label %bb18
bb17:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l4, !tbaa !29
  br label %bb23
bb18:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t64 = load ptr, ptr %l40, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l40, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 3
  store i1 %t70, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l41, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t80 = load i64, ptr %l2, !tbaa !24
  %t82 = add i64 %t80, 1
  %t86 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadePlace(ptr %v0, ptr %v1, ptr %t78, ptr %t79, i64 %t82)
  store i64 %t86, ptr %l50
  br label %bb24
bb24:
  %t87 = load i64, ptr %l50, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
bb25:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb26, label %bb27
bb26:
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 10
  store i1 %t95, ptr %l52, !tbaa !21
  br label %bb27
bb27:
  %t96 = load i1, ptr %l52, !tbaa !21
  br i1 %t96, label %bb28, label %bb29
bb28:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l5, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Slice", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t108 = load i64, ptr %l2, !tbaa !24
  %t110 = add i64 %t108, 1
  %t114 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadePlace(ptr %v0, ptr %v1, ptr %t103, ptr %t107, i64 %t110)
  store i64 %t114, ptr %l62
  br label %bb31
bb31:
  %t115 = load i64, ptr %l62, !tbaa !24
  store i64 %t115, ptr %rv
  br label %ret
bb32:
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t117 = load ptr, ptr %l63, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb33, label %bb34
bb33:
  %t120 = load ptr, ptr %l63, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 18}
  %t123 = icmp eq i64 %t121, 6
  store i1 %t123, ptr %l64, !tbaa !21
  br label %bb34
bb34:
  %t124 = load i1, ptr %l64, !tbaa !21
  br i1 %t124, label %bb35, label %bb36
bb35:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [5 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t127, i32 0, i32 2
  %t129 = load ptr, ptr %t128
  store ptr %t129, ptr %l6, !tbaa !29
  br label %bb37
bb36:
  br label %bb47
bb37:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/scope:Scoper", ptr %t131, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  store ptr %t136, ptr %l71, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t141 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t137, ptr %t138)
  store i32 %t141, ptr %l74
  br label %bb38
bb38:
  %t142 = load ptr, ptr %l71, !tbaa !29
  %t143 = load i32, ptr %l74, !tbaa !23
  %t144 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t142, i32 %t143, i64 0)
  store i64 %t144, ptr %l75
  br label %bb39
bb39:
  %t145 = load i64, ptr %l75, !tbaa !24
  store i64 %t145, ptr %l7, !tbaa !24
  %t146 = load i64, ptr %l7, !tbaa !24
  %t148 = icmp sge i64 %t146, 0
  br i1 %t148, label %bb40, label %bb41
bb40:
  %t150 = load i64, ptr %l7, !tbaa !24
  %t151 = load ptr, ptr %l6, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Call", ptr %t151, i32 0, i32 1
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t159 = icmp slt i64 %t150, %t156
  store i1 %t159, ptr %l78, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb42
bb42:
  %t161 = load i1, ptr %l78, !tbaa !21
  br i1 %t161, label %bb43, label %bb44
bb43:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load ptr, ptr %l6, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Call", ptr %t163, i32 0, i32 1
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %l86, !tbaa !27
  %t167 = load i64, ptr %l7, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr ptr, ptr %t170, i64 %t167
  %t172 = load ptr, ptr %t171, !tbaa !39
  %t174 = load i64, ptr %l2, !tbaa !24
  %t176 = add i64 %t174, 1
  %t180 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t162, ptr %t172, i64 %t176)
  store i64 %t180, ptr %l92
  br label %bb45
bb44:
  br label %bb46
bb45:
  %t181 = load i64, ptr %l92, !tbaa !24
  store i64 %t181, ptr %rv
  br label %ret
bb46:
  br label %bb66
bb47:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t183 = load ptr, ptr %l93, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb48, label %bb49
bb48:
  %t186 = load ptr, ptr %l93, !tbaa !29
  %t187 = load i64, ptr %t186, !range !{i64 0, i64 18}
  %t189 = icmp eq i64 %t187, 9
  store i1 %t189, ptr %l94, !tbaa !21
  br label %bb49
bb49:
  %t190 = load i1, ptr %l94, !tbaa !21
  br i1 %t190, label %bb50, label %bb51
bb50:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [5 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t193, i32 0, i32 2
  %t195 = load i32, ptr %t194, !range !{i32 0, i32 43}
  store i32 %t195, ptr %l8
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t199, i32 0, i32 4
  %t201 = load { i64, ptr }, ptr %t200
  store { i64, ptr } %t201, ptr %l9, !tbaa !27
  br label %bb52
bb51:
  br label %bb61
bb52:
  %t203 = load i32, ptr %l8, !range !{i32 0, i32 43}
  %t205 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t203)
  store i1 %t205, ptr %l102
  br label %bb53
bb53:
  %t206 = load i1, ptr %l102, !tbaa !21
  br i1 %t206, label %bb54, label %bb55
bb54:
  %t207 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t211 = icmp sgt i64 %t209, 0
  store i1 %t211, ptr %l103, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb56
bb56:
  %t213 = load i1, ptr %l103, !tbaa !21
  br i1 %t213, label %bb57, label %bb58
bb57:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t215, ptr %l108, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr ptr, ptr %t217, i64 0
  %t219 = load ptr, ptr %t218, !tbaa !39
  %t221 = load i64, ptr %l2, !tbaa !24
  %t223 = add i64 %t221, 1
  %t227 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t214, ptr %t219, i64 %t223)
  store i64 %t227, ptr %l113
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t228 = load i64, ptr %l113, !tbaa !24
  store i64 %t228, ptr %rv
  br label %ret
bb60:
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_7514114a5d4749ce_60914fcc95b5171a)
  unreachable
bb66:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ematchMadeHere(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l25 = alloca i1
  %l29 = alloca i1
  %l42 = alloca i1
  %l43 = alloca ptr
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Match", ptr %t9, i32 0, i32 1
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb16
bb6:
  br label %bb7
bb7:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  store ptr %t32, ptr %l5, !tbaa !29
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Arm", ptr %t34, i32 0, i32 4
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Arm", ptr %t44, i32 0, i32 4
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t50 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t43, ptr %t47)
  store i1 %t50, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  %t51 = load i1, ptr %l29, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t54 = load i1, ptr %l25, !tbaa !21
  br i1 %t54, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t56, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb4
bb16:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Match", ptr %t60, i32 0, i32 2
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bfbb893df1c35f5d_ebb7b8931b043491)
  unreachable
bb18:
  br label %bb19
bb19:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Match", ptr %t67, i32 0, i32 2
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Arm", ptr %t70, i32 0, i32 4
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = icmp eq ptr %t74, null
  br i1 %t76, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb26
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l43, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Match", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  br i1 %t84, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_bfbb893df1c35f5d_ebb7b8931b043491)
  unreachable
bb23:
  br label %bb24
bb24:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Match", ptr %t86, i32 0, i32 2
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Arm", ptr %t89, i32 0, i32 4
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load ptr, ptr %l43, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t94, ptr %t93)
  store i1 %t96, ptr %l51
  br label %bb25
bb25:
  %t97 = load i1, ptr %l51, !tbaa !21
  store i1 %t97, ptr %l42, !tbaa !21
  br label %bb26
bb26:
  %t98 = load i1, ptr %l42, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoBuildTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 64
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i64, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = icmp slt i64 %t16, %t17
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 64
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t22, i64 %t23)
  store i1 %t26, ptr %l16
  br label %bb7
bb6:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb8
bb7:
  %t27 = load i1, ptr %l16, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l12, !tbaa !21
  store i1 %t28, ptr %l3, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_a9ed640346de181b_d10bb16716ed4607)
  unreachable
bb14:
  %t29 = load i1, ptr %l3, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMakeWhere(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3, i64 %a4, i64 %a5, { i64, [2 x i64] } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l29 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i64
  %l38 = alloca ptr
  %l47 = alloca %"compiler/typed:Local"
  %l49 = alloca { i64, ptr }
  %l52 = alloca i1
  %l56 = alloca i64
  %l59 = alloca i1
  %l63 = alloca i1
  %l72 = alloca %"compiler/typed:Local"
  %l78 = alloca ptr
  %l87 = alloca %"compiler/typed:Local"
  %l89 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca i64
  %l98 = alloca i64
  %l99 = alloca ptr
  %l108 = alloca %"compiler/typed:Local"
  %l111 = alloca %"compiler/source:Span"
  %l114 = alloca %"compiler/msgs:Msg"
  %l124 = alloca ptr
  %l126 = alloca i64
  %l129 = alloca i1
  %l130 = alloca i1
  %l133 = alloca i1
  %l140 = alloca i1
  %l143 = alloca i1
  %l147 = alloca i1
  %l156 = alloca %"compiler/typed:Local"
  %l159 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i64
  %l169 = alloca i64
  %l170 = alloca %"compiler/source:Span"
  %l172 = alloca %"compiler/msgs:Msg"
  %l173 = alloca ptr
  %l175 = alloca i32
  %l176 = alloca i1
  %l177 = alloca i1
  %l181 = alloca i64
  %l185 = alloca %"compiler/source:Span"
  %l188 = alloca i1
  %l197 = alloca %"compiler/typed:Local"
  %l200 = alloca ptr
  %l204 = alloca ptr
  %l205 = alloca i32
  %l211 = alloca %"compiler/source:Span"
  %l212 = alloca ptr
  %l213 = alloca i64
  %l220 = alloca i64
  %l221 = alloca %"compiler/source:Span"
  %l223 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l18, !tbaa !27
  %t5 = load i64, ptr %l4, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l7, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Call", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l22, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %a5
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l25, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t29 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t24, ptr %t21)
  store ptr %t29, ptr %l29
  br label %bb1
bb1:
  %t30 = load ptr, ptr %l29, !tbaa !29
  %t32 = call i64 @compiler_2fscope_2eflRootExpr(ptr %s0, ptr %t30)
  store i64 %t32, ptr %l31
  br label %bb2
bb2:
  %t33 = load ptr, ptr %l25, !tbaa !29
  %t34 = load i64, ptr %l31, !tbaa !24
  %t35 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eshownLocal(ptr %v0, ptr %t33, i64 %t34, i64 0)
  store i64 %t35, ptr %l32
  br label %bb3
bb3:
  %t36 = load i64, ptr %l32, !tbaa !24
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i64, ptr %l9, !tbaa !24
  %t39 = icmp slt i64 %t37, 0
  br i1 %t39, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/load:Loader", ptr %t47, i32 0, i32 3
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %l38, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/scope:Scoper", ptr %t51, i32 0, i32 25
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  br i1 %t56, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3b124163f404c032_f61e7eda275eee66)
  unreachable
bb8:
  br label %bb9
bb9:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 25
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Body", ptr %t61, i32 0, i32 7
  %t65 = load i64, ptr %l9, !tbaa !24
  %t68 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t64, i64 %t65)
  store %"compiler/typed:Local" %t68, ptr %l47
  br label %bb10
bb10:
  %t69 = getelementptr %"compiler/typed:Local", ptr %l47, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t73 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t71, i32 %t70)
  store { i64, ptr } %t73, ptr %l49
  br label %bb11
bb11:
  %t74 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t74, ptr %l10, !tbaa !27
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t79 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoBuildTerm(ptr %v0, ptr %t75, { i64, [2 x i64] } %a6)
  store i1 %t79, ptr %l52
  br label %bb12
bb12:
  %t80 = load i1, ptr %l52, !tbaa !21
  br i1 %t80, label %bb13, label %bb14
bb13:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l7, !tbaa !29
  %t86 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t81, ptr %t82, i64 0)
  store i64 %t86, ptr %l56
  br label %bb15
bb14:
  br label %bb44
bb15:
  %t87 = load i64, ptr %l56, !tbaa !24
  store i64 %t87, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l11, !tbaa !24
  %t90 = icmp sge i64 %t88, 0
  br i1 %t90, label %bb16, label %bb17
bb16:
  %t92 = load i64, ptr %l11, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = icmp ne i64 %t92, %t93
  store i1 %t96, ptr %l59, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb18
bb18:
  %t98 = load i1, ptr %l59, !tbaa !21
  br i1 %t98, label %bb19, label %bb20
bb19:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/scope:Scoper", ptr %t99, i32 0, i32 25
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb21, label %bb22
bb20:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb25
bb21:
  call void @__olang_check_failed(ptr @olang_loc_4046876e7ea1d159_b2112eb816f2c84d)
  unreachable
bb22:
  br label %bb23
bb23:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/scope:Scoper", ptr %t106, i32 0, i32 25
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Body", ptr %t109, i32 0, i32 7
  %t113 = load i64, ptr %l11, !tbaa !24
  %t116 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t112, i64 %t113)
  store %"compiler/typed:Local" %t116, ptr %l72
  br label %bb24
bb24:
  %t117 = getelementptr %"compiler/typed:Local", ptr %l72, i32 0, i32 0
  %t118 = load i32, ptr %t117, !tbaa !23
  %t120 = icmp ne i32 %t118, 0
  store i1 %t120, ptr %l63, !tbaa !21
  br label %bb25
bb25:
  %t122 = load i1, ptr %l63, !tbaa !21
  br i1 %t122, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 3
  %t132 = load ptr, ptr %t131, !tbaa !29
  store ptr %t132, ptr %l78, !tbaa !29
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/scope:Scoper", ptr %t133, i32 0, i32 25
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = icmp eq ptr %t136, null
  br i1 %t138, label %bb28, label %bb29
bb27:
  br label %bb43
bb28:
  call void @__olang_check_failed(ptr @olang_loc_79d12197ff1a95a4_7d7576a4aa48dc38)
  unreachable
bb29:
  br label %bb30
bb30:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/scope:Scoper", ptr %t140, i32 0, i32 25
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Body", ptr %t143, i32 0, i32 7
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t146, i64 %t147)
  store %"compiler/typed:Local" %t150, ptr %l87
  br label %bb31
bb31:
  %t151 = getelementptr %"compiler/typed:Local", ptr %l87, i32 0, i32 0
  %t152 = load i32, ptr %t151, !tbaa !23
  %t153 = load ptr, ptr %l78, !tbaa !29
  %t155 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t153, i32 %t152)
  store { i64, ptr } %t155, ptr %l89
  br label %bb32
bb32:
  %t156 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t156, ptr %l12, !tbaa !27
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l90, !tbaa !29
  %t158 = load i64, ptr %l1, !tbaa !24
  store i64 %t158, ptr %l91, !tbaa !24
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/scope:Scoper", ptr %t159, i32 0, i32 25
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = icmp eq ptr %t162, null
  br i1 %t164, label %bb33, label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_2cb2f05c33c43f73_8008e731f94f8857)
  unreachable
bb34:
  br label %bb35
bb35:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/scope:Scoper", ptr %t166, i32 0, i32 25
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Body", ptr %t169, i32 0, i32 3
  %t173 = load i64, ptr %t172, !tbaa !24
  store i64 %t173, ptr %l98, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l99, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/scope:Scoper", ptr %t175, i32 0, i32 25
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = icmp eq ptr %t178, null
  br i1 %t180, label %bb36, label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_2cb2f05c33c43f73_8008e731f94f8857)
  unreachable
bb37:
  br label %bb38
bb38:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/scope:Scoper", ptr %t182, i32 0, i32 25
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Body", ptr %t185, i32 0, i32 7
  %t189 = load i64, ptr %l11, !tbaa !24
  %t192 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t188, i64 %t189)
  store %"compiler/typed:Local" %t192, ptr %l108
  br label %bb39
bb39:
  %t193 = getelementptr %"compiler/typed:Local", ptr %l108, i32 0, i32 1
  %t194 = load %"compiler/source:Span", ptr %t193
  %t195 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t196 = load ptr, ptr %l99, !tbaa !29
  %t199 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v0, ptr %t196, %"compiler/source:Span" %t194, { i64, ptr } %t195)
  store %"compiler/source:Span" %t199, ptr %l111
  br label %bb40
bb40:
  %t200 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t204 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrKeepCopies(ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t200, { i64, ptr } %t201)
  store %"compiler/msgs:Msg" %t204, ptr %l114
  br label %bb41
bb41:
  %t205 = load ptr, ptr %l90, !tbaa !29
  %t206 = load i64, ptr %l91, !tbaa !24
  %t207 = load i64, ptr %l98, !tbaa !24
  %t208 = load %"compiler/source:Span", ptr %l111
  %t209 = load %"compiler/msgs:Msg", ptr %l114
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s3, ptr %t205, i64 %t206, i64 %t207, %"compiler/source:Span" %t208, %"compiler/msgs:Msg" %t209)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb44:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i64, ptr %l1, !tbaa !24
  %t212 = load ptr, ptr %l7, !tbaa !29
  %t214 = load i64, ptr %l9, !tbaa !24
  %t215 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v0, ptr %t210, i64 %t211, ptr %t212, i64 %t214, { i64, ptr } %t215, i64 0)
  br label %bb45
bb45:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l7, !tbaa !29
  %t226 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t221, ptr %t222)
  store ptr %t226, ptr %l124
  br label %bb46
bb46:
  %t227 = load ptr, ptr %l124, !tbaa !29
  %t229 = call i64 @compiler_2fscope_2eflRootExpr(ptr %s0, ptr %t227)
  store i64 %t229, ptr %l126
  br label %bb47
bb47:
  %t230 = load i64, ptr %l126, !tbaa !24
  store i64 %t230, ptr %l13, !tbaa !24
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l3, !tbaa !29
  %t235 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %v1, ptr %t231, ptr %t232)
  store i1 %t235, ptr %l129
  br label %bb48
bb48:
  %t236 = load i1, ptr %l129, !tbaa !21
  br i1 %t236, label %bb49, label %bb50
bb49:
  %t237 = load i64, ptr %l4, !tbaa !24
  %t239 = icmp sgt i64 %t237, 0
  store i1 %t239, ptr %l130, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb51
bb51:
  %t241 = load i1, ptr %l130, !tbaa !21
  br i1 %t241, label %bb52, label %bb53
bb52:
  %t242 = load i64, ptr %l4, !tbaa !24
  %t243 = load ptr, ptr %l3, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Call", ptr %t243, i32 0, i32 1
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 0
  %t250 = sub i64 %t248, 1
  %t253 = icmp slt i64 %t242, %t250
  br i1 %t253, label %bb54, label %bb55
bb53:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb58
bb54:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb57
bb55:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load ptr, ptr %l3, !tbaa !29
  %t259 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetAtCall(ptr %v0, ptr %v1, ptr %t255, ptr %t256)
  store i1 %t259, ptr %l143
  br label %bb56
bb56:
  %t260 = load i1, ptr %l143, !tbaa !21
  %t261 = xor i1 %t260, true
  store i1 %t261, ptr %l140, !tbaa !21
  br label %bb57
bb57:
  %t263 = load i1, ptr %l140, !tbaa !21
  store i1 %t263, ptr %l133, !tbaa !21
  br label %bb58
bb58:
  %t264 = load i1, ptr %l133, !tbaa !21
  store i1 %t264, ptr %l14, !tbaa !21
  %t265 = load i64, ptr %l13, !tbaa !24
  %t267 = icmp sge i64 %t265, 0
  br i1 %t267, label %bb59, label %bb60
bb59:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/scope:Scoper", ptr %t269, i32 0, i32 25
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = icmp eq ptr %t272, null
  br i1 %t274, label %bb61, label %bb62
bb60:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb65
bb61:
  call void @__olang_check_failed(ptr @olang_loc_3be66b99fba73c4e_1215a57d292f746a)
  unreachable
bb62:
  br label %bb63
bb63:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/scope:Scoper", ptr %t276, i32 0, i32 25
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t282 = getelementptr %"compiler/typed:Body", ptr %t279, i32 0, i32 7
  %t283 = load i64, ptr %l13, !tbaa !24
  %t286 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t282, i64 %t283)
  store %"compiler/typed:Local" %t286, ptr %l156
  br label %bb64
bb64:
  %t287 = getelementptr %"compiler/typed:Local", ptr %l156, i32 0, i32 4
  %t288 = load i32, ptr %t287, !range !{i32 0, i32 7}
  %t290 = trunc i64 2 to i32
  %t291 = icmp eq i32 %t288, %t290
  store i1 %t291, ptr %l147, !tbaa !21
  br label %bb65
bb65:
  %t293 = load i1, ptr %l147, !tbaa !21
  br i1 %t293, label %bb66, label %bb67
bb66:
  %t294 = load i1, ptr %l14, !tbaa !21
  store i1 %t294, ptr %l159, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb68
bb68:
  %t296 = load i1, ptr %l159, !tbaa !21
  br i1 %t296, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s4
  %t297 = load ptr, ptr %l0, !tbaa !29
  store ptr %t297, ptr %l161, !tbaa !29
  %t298 = load i64, ptr %l1, !tbaa !24
  store i64 %t298, ptr %l162, !tbaa !24
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/scope:Scoper", ptr %t299, i32 0, i32 25
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = icmp eq ptr %t302, null
  br i1 %t304, label %bb71, label %bb72
bb70:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l173, !tbaa !29
  %t307 = load ptr, ptr %l7, !tbaa !29
  %t309 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t307)
  store i32 %t309, ptr %l175
  br label %bb76
bb71:
  call void @__olang_check_failed(ptr @olang_loc_9cb83d16c8558bf5_7c19eecf9e07b071)
  unreachable
bb72:
  br label %bb73
bb73:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/scope:Scoper", ptr %t310, i32 0, i32 25
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t316 = getelementptr %"compiler/typed:Body", ptr %t313, i32 0, i32 3
  %t317 = load i64, ptr %t316, !tbaa !24
  store i64 %t317, ptr %l169, !tbaa !24
  store %"compiler/source:Span" %a2, ptr %l170
  %t319 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t321 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHeldIndexWhere(ptr %v0, ptr %s4, { i64, ptr } %t319)
  store %"compiler/msgs:Msg" %t321, ptr %l172
  br label %bb74
bb74:
  %t322 = load ptr, ptr %l161, !tbaa !29
  %t323 = load i64, ptr %l162, !tbaa !24
  %t324 = load i64, ptr %l169, !tbaa !24
  %t325 = load %"compiler/source:Span", ptr %l170
  %t326 = load %"compiler/msgs:Msg", ptr %l172
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s4, ptr %t322, i64 %t323, i64 %t324, %"compiler/source:Span" %t325, %"compiler/msgs:Msg" %t326)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s4)
  br label %bb109
bb76:
  %t327 = load ptr, ptr %l173, !tbaa !29
  %t328 = load i32, ptr %l175, !tbaa !23
  %t329 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisText(ptr %v0, ptr %t327, i32 %t328)
  store i1 %t329, ptr %l176
  br label %bb77
bb77:
  %t330 = load i1, ptr %l176, !tbaa !21
  br i1 %t330, label %bb78, label %bb79
bb78:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l7, !tbaa !29
  %t336 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v1, ptr %t331, ptr %t332, i64 0)
  store i64 %t336, ptr %l181
  br label %bb80
bb79:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb81
bb80:
  %t337 = load i64, ptr %l181, !tbaa !24
  %t338 = icmp sge i64 %t337, 0
  store i1 %t338, ptr %l177, !tbaa !21
  br label %bb81
bb81:
  %t340 = load i1, ptr %l177, !tbaa !21
  br i1 %t340, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s6
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load ptr, ptr %l7, !tbaa !29
  %t345 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v1, ptr %t341, ptr %t342)
  store %"compiler/source:Span" %t345, ptr %l185
  br label %bb84
bb83:
  br label %bb108
bb84:
  %t346 = load %"compiler/source:Span", ptr %l185
  store %"compiler/source:Span" %t346, ptr %l15
  %t347 = load i64, ptr %l13, !tbaa !24
  %t349 = icmp sge i64 %t347, 0
  br i1 %t349, label %bb85, label %bb86
bb85:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/scope:Scoper", ptr %t351, i32 0, i32 25
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t356 = icmp eq ptr %t354, null
  br i1 %t356, label %bb87, label %bb88
bb86:
  store i1 false, ptr %l188, !tbaa !21
  br label %bb91
bb87:
  call void @__olang_check_failed(ptr @olang_loc_98ba305d5e2403e0_d6869d4c9e18247c)
  unreachable
bb88:
  br label %bb89
bb89:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/scope:Scoper", ptr %t358, i32 0, i32 25
  %t361 = load ptr, ptr %t360, !tbaa !29
  %t364 = getelementptr %"compiler/typed:Body", ptr %t361, i32 0, i32 7
  %t365 = load i64, ptr %l13, !tbaa !24
  %t368 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t364, i64 %t365)
  store %"compiler/typed:Local" %t368, ptr %l197
  br label %bb90
bb90:
  %t369 = getelementptr %"compiler/typed:Local", ptr %l197, i32 0, i32 4
  %t370 = load i32, ptr %t369, !range !{i32 0, i32 7}
  %t372 = trunc i64 2 to i32
  %t373 = icmp eq i32 %t370, %t372
  store i1 %t373, ptr %l188, !tbaa !21
  br label %bb91
bb91:
  %t375 = load i1, ptr %l188, !tbaa !21
  br i1 %t375, label %bb92, label %bb93
bb92:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/scope:Scoper", ptr %t376, i32 0, i32 42
  %t379 = load i64, ptr %l13, !tbaa !24
  %t382 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t378, i64 %t379)
  %t383 = extractvalue { i32, ptr } %t382, 1
  %t384 = extractvalue { i32, ptr } %t382, 0
  store i32 %t384, ptr %l205
  %t385 = icmp ne i32 %t384, 0
  br i1 %t385, label %bb95, label %ok.386, !prof !99
ok.386:
  store ptr %t383, ptr %l204
  br label %bb94
bb93:
  br label %bb102
bb94:
  %t387 = load ptr, ptr %l204, !tbaa !29
  store ptr %t387, ptr %l200, !tbaa !29
  br label %bb97
bb95:
  br label %bb96
bb96:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l200, !tbaa !29
  br label %bb97
bb97:
  %t388 = load ptr, ptr %l200, !tbaa !29
  store ptr %t388, ptr %l16, !tbaa !29
  %t389 = load ptr, ptr %l16, !tbaa !29
  %t391 = icmp eq ptr %t389, null
  %t393 = xor i1 %t391, true
  br i1 %t393, label %bb98, label %bb99
bb98:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load ptr, ptr %l16, !tbaa !29
  %t399 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v0, ptr %t395, ptr %t396)
  store %"compiler/source:Span" %t399, ptr %l211
  br label %bb100
bb99:
  br label %bb101
bb100:
  %t400 = load %"compiler/source:Span", ptr %l211
  store %"compiler/source:Span" %t400, ptr %l15
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t401 = load ptr, ptr %l0, !tbaa !29
  store ptr %t401, ptr %l212, !tbaa !29
  %t402 = load i64, ptr %l1, !tbaa !24
  store i64 %t402, ptr %l213, !tbaa !24
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/scope:Scoper", ptr %t403, i32 0, i32 25
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t408 = icmp eq ptr %t406, null
  br i1 %t408, label %bb103, label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_37fd0ede1d7e00ff_4f25c812a3c753eb)
  unreachable
bb104:
  br label %bb105
bb105:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/scope:Scoper", ptr %t410, i32 0, i32 25
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t416 = getelementptr %"compiler/typed:Body", ptr %t413, i32 0, i32 3
  %t417 = load i64, ptr %t416, !tbaa !24
  store i64 %t417, ptr %l220, !tbaa !24
  %t418 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t418, ptr %l221
  %t419 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t421 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteTextCopyWhere(ptr %v0, ptr %s6, { i64, ptr } %t419)
  store %"compiler/msgs:Msg" %t421, ptr %l223
  br label %bb106
bb106:
  %t422 = load ptr, ptr %l212, !tbaa !29
  %t423 = load i64, ptr %l213, !tbaa !24
  %t424 = load i64, ptr %l220, !tbaa !24
  %t425 = load %"compiler/source:Span", ptr %l221
  %t426 = load %"compiler/msgs:Msg", ptr %l223
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s6, ptr %t422, i64 %t423, i64 %t424, %"compiler/source:Span" %t425, %"compiler/msgs:Msg" %t426)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s6)
  br label %bb108
bb108:
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteRefill(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/typed:Local"
  %l12 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l21 = alloca ptr
  %l30 = alloca %"compiler/typed:Local"
  %l32 = alloca { i64, ptr }
  %l42 = alloca i64
  %l45 = alloca i1
  %l49 = alloca i1
  %l58 = alloca %"compiler/typed:Local"
  %l62 = alloca i32
  %l65 = alloca i1
  %l66 = alloca i32
  %l71 = alloca i32
  %l74 = alloca ptr
  %l75 = alloca i32
  %l80 = alloca i32
  %l81 = alloca i64
  %l83 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca i32
  %l96 = alloca %"compiler/source:Span"
  %l102 = alloca i1
  %l114 = alloca %"compiler/typed:Local"
  %l115 = alloca ptr
  %l116 = alloca i64
  %l123 = alloca i64
  %l124 = alloca ptr
  %l125 = alloca %"compiler/source:Span"
  %l131 = alloca { i64, ptr }
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca { i64, ptr }
  %l135 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i64
  %l144 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i64 @compiler_2fscope_2eflRoot(ptr %v1, ptr %t2)
  store i64 %t4, ptr %l14
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %l14, !tbaa !24
  %t7 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eshownLocal(ptr %v0, ptr %t5, i64 %t6, i64 0)
  store i64 %t7, ptr %l15
  br label %bb2
bb2:
  %t8 = load i64, ptr %l15, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/scope:Scoper", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/load:Loader", ptr %t19, i32 0, i32 3
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l21, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t23, i32 0, i32 25
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d1e09ab5654512c3_1949347ac845fe07)
  unreachable
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 25
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Body", ptr %t33, i32 0, i32 7
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t36, i64 %t37)
  store %"compiler/typed:Local" %t40, ptr %l30
  br label %bb9
bb9:
  %t41 = getelementptr %"compiler/typed:Local", ptr %l30, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t45 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t43, i32 %t42)
  store { i64, ptr } %t45, ptr %l32
  br label %bb10
bb10:
  %t46 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t46, ptr %l5, !tbaa !27
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i64, ptr %l1, !tbaa !24
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = load i64, ptr %l4, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v2, ptr %v0, ptr %t47, i64 %t48, ptr %t49, i64 %t51, { i64, ptr } %t52, i64 0)
  br label %bb11
bb11:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t63 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeLocal(ptr %v0, ptr %v2, ptr %t58, ptr %t59, i64 0)
  store i64 %t63, ptr %l42
  br label %bb12
bb12:
  %t64 = load i64, ptr %l42, !tbaa !24
  store i64 %t64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = icmp slt i64 %t65, 0
  br i1 %t67, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb15
bb14:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l4, !tbaa !24
  %t73 = icmp eq i64 %t69, %t70
  store i1 %t73, ptr %l45, !tbaa !21
  br label %bb15
bb15:
  %t75 = load i1, ptr %l45, !tbaa !21
  br i1 %t75, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb22
bb17:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/scope:Scoper", ptr %t76, i32 0, i32 25
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = icmp eq ptr %t79, null
  br i1 %t81, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9ec3c43f0dea0d34_4e7830eaf7e3a0e8)
  unreachable
bb19:
  br label %bb20
bb20:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 25
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Body", ptr %t86, i32 0, i32 7
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t89, i64 %t90)
  store %"compiler/typed:Local" %t93, ptr %l58
  br label %bb21
bb21:
  %t94 = getelementptr %"compiler/typed:Local", ptr %l58, i32 0, i32 0
  %t95 = load i32, ptr %t94, !tbaa !23
  %t97 = icmp eq i32 %t95, 0
  store i1 %t97, ptr %l49, !tbaa !21
  br label %bb22
bb22:
  %t99 = load i1, ptr %l49, !tbaa !21
  br i1 %t99, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  br label %bb25
bb25:
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t102 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t100)
  store i32 %t102, ptr %l62
  br label %bb26
bb26:
  %t103 = load i32, ptr %l62, !tbaa !23
  store i32 %t103, ptr %l7, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i32, ptr %l7, !tbaa !23
  %t108 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t104, i32 %t105)
  store i1 %t108, ptr %l65
  br label %bb27
bb27:
  %t109 = load i1, ptr %l65, !tbaa !21
  br i1 %t109, label %bb28, label %bb29
bb28:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l7, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l71
  br label %bb30
bb29:
  %t120 = load i32, ptr %l7, !tbaa !23
  store i32 %t120, ptr %l66, !tbaa !23
  br label %bb31
bb30:
  %t122 = load i32, ptr %l71, !tbaa !23
  store i32 %t122, ptr %l66, !tbaa !23
  br label %bb31
bb31:
  %t123 = load i32, ptr %l66, !tbaa !23
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/scope:Scoper", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  store ptr %t127, ptr %l74, !tbaa !29
  store i32 %t123, ptr %l75, !tbaa !23
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/scope:Scoper", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 0
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/load:Loader", ptr %t135, i32 0, i32 3
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t138, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i32 %t140, ptr %l80
  br label %bb32
bb32:
  %t141 = load ptr, ptr %l74, !tbaa !29
  %t142 = load i32, ptr %l75, !tbaa !23
  %t143 = load i32, ptr %l80, !tbaa !23
  %t144 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t141, i32 %t142, i32 %t143)
  store i64 %t144, ptr %l81
  br label %bb33
bb33:
  %t145 = load i64, ptr %l81, !tbaa !24
  %t146 = icmp slt i64 %t145, 0
  br i1 %t146, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb35:
  br label %bb36
bb36:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/scope:Scoper", ptr %t148, i32 0, i32 10
  store ptr %t150, ptr %l85, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/scope:Scoper", ptr %t151, i32 0, i32 25
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  br i1 %t156, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_60a9277e2c5e0f29_25801f0e1d4bc5bd)
  unreachable
bb38:
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/scope:Scoper", ptr %t158, i32 0, i32 25
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Body", ptr %t161, i32 0, i32 3
  %t165 = load i64, ptr %t164, !tbaa !24
  %t166 = load ptr, ptr %l85, !tbaa !29
  %t168 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t166, i64 %t165)
  %t169 = extractvalue { i32, { i64, ptr } } %t168, 1
  %t170 = extractvalue { i32, { i64, ptr } } %t168, 0
  store i32 %t170, ptr %l94
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb41, label %ok.172, !prof !99
ok.172:
  store { i64, ptr } %t169, ptr %l93
  br label %bb40
bb40:
  %t173 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t173, ptr %l83, !tbaa !27
  br label %bb43
bb41:
  br label %bb42
bb42:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l83, !tbaa !27
  br label %bb43
bb43:
  %t174 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t174, ptr %l9, !tbaa !27
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t177 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t175)
  store %"compiler/source:Span" %t177, ptr %l96
  br label %bb44
bb44:
  %t178 = load %"compiler/source:Span", ptr %l96
  store %"compiler/source:Span" %t178, ptr %l10
  %t179 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 1
  %t180 = load i32, ptr %t179, !tbaa !23
  %t182 = sext i32 %t180 to i64
  %t183 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t188 = icmp sgt i64 %t182, %t185
  br i1 %t188, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb47
bb46:
  %t190 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t191 = load i32, ptr %t190, !tbaa !23
  %t192 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 1
  %t193 = load i32, ptr %t192, !tbaa !23
  %t196 = icmp sge i32 %t191, %t193
  store i1 %t196, ptr %l102, !tbaa !21
  br label %bb47
bb47:
  %t198 = load i1, ptr %l102, !tbaa !21
  br i1 %t198, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  br label %bb50
bb50:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/scope:Scoper", ptr %t199, i32 0, i32 25
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = icmp eq ptr %t202, null
  br i1 %t204, label %bb51, label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_32a2617be6fc2342_ed6c13319ae659d6)
  unreachable
bb52:
  br label %bb53
bb53:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/scope:Scoper", ptr %t206, i32 0, i32 25
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t212 = getelementptr %"compiler/typed:Body", ptr %t209, i32 0, i32 7
  %t213 = load i64, ptr %l6, !tbaa !24
  %t216 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t212, i64 %t213)
  store %"compiler/typed:Local" %t216, ptr %l114
  br label %bb54
bb54:
  %t217 = load %"compiler/typed:Local", ptr %l114
  store %"compiler/typed:Local" %t217, ptr %l11
  %t218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t218, ptr %l115, !tbaa !29
  %t219 = load i64, ptr %l1, !tbaa !24
  store i64 %t219, ptr %l116, !tbaa !24
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/scope:Scoper", ptr %t220, i32 0, i32 25
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = icmp eq ptr %t223, null
  br i1 %t225, label %bb55, label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_466c52b9c16c208f_a374cdad5045efdb)
  unreachable
bb56:
  br label %bb57
bb57:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/scope:Scoper", ptr %t227, i32 0, i32 25
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t233 = getelementptr %"compiler/typed:Body", ptr %t230, i32 0, i32 3
  %t234 = load i64, ptr %t233, !tbaa !24
  store i64 %t234, ptr %l123, !tbaa !24
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l124, !tbaa !29
  %t236 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t237 = load %"compiler/source:Span", ptr %t236
  store %"compiler/source:Span" %t237, ptr %l125
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/scope:Scoper", ptr %t238, i32 0, i32 0
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = getelementptr %"compiler/generic:Program", ptr %t241, i32 0, i32 0
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = getelementptr %"compiler/load:Loader", ptr %t244, i32 0, i32 3
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t248 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 0
  %t249 = load i32, ptr %t248, !tbaa !23
  %t252 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t247, i32 %t249)
  store { i64, ptr } %t252, ptr %l131
  br label %bb58
bb58:
  %t253 = load ptr, ptr %l124, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l125
  %t255 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t256 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v0, ptr %t253, %"compiler/source:Span" %t254, { i64, ptr } %t255)
  store %"compiler/source:Span" %t256, ptr %l132
  br label %bb59
bb59:
  %t257 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t257, ptr %l133, !tbaa !27
  %t258 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t259 = load i32, ptr %t258, !tbaa !23
  %t261 = sext i32 %t259 to i64
  store i64 %t261, ptr %l135, !tbaa !24
  %t262 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 1
  %t263 = load i32, ptr %t262, !tbaa !23
  %t265 = sext i32 %t263 to i64
  store i64 %t265, ptr %l137, !tbaa !24
  %t266 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 0
  store i64 %t267, ptr %l138, !tbaa !24
  %t268 = load i64, ptr %l135, !tbaa !24
  %t269 = icmp sge i64 %t268, 0
  br i1 %t269, label %bb60, label %bb61
bb60:
  %t271 = load i64, ptr %l135, !tbaa !24
  %t272 = load i64, ptr %l137, !tbaa !24
  %t273 = icmp sle i64 %t271, %t272
  br i1 %t273, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_f99d36ce04cd5358_3c9954da82c615c4)
  unreachable
bb62:
  %t275 = load i64, ptr %l137, !tbaa !24
  %t276 = load i64, ptr %l138, !tbaa !24
  %t277 = icmp sle i64 %t275, %t276
  br i1 %t277, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_f99d36ce04cd5358_3c9954da82c615c4)
  unreachable
bb64:
  %t279 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = load i64, ptr %l135, !tbaa !24
  %t282 = load i64, ptr %l137, !tbaa !24
  %t283 = getelementptr i8, ptr %t280, i64 %t281
  %t284 = sub i64 %t282, %t281
  %t285 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t283, 1
  %t287 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t290 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteRefillKept(ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t286, { i64, ptr } %t287)
  store %"compiler/msgs:Msg" %t290, ptr %l144
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_f99d36ce04cd5358_3c9954da82c615c4)
  unreachable
bb66:
  %t291 = load ptr, ptr %l115, !tbaa !29
  %t292 = load i64, ptr %l116, !tbaa !24
  %t293 = load i64, ptr %l123, !tbaa !24
  %t294 = load %"compiler/source:Span", ptr %l132
  %t295 = load %"compiler/msgs:Msg", ptr %l144
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s0, ptr %t291, i64 %t292, i64 %t293, %"compiler/source:Span" %t294, %"compiler/msgs:Msg" %t295)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca ptr
  %l28 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca ptr
  %l43 = alloca i1
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca ptr
  %l55 = alloca i1
  %l62 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca ptr
  %l74 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca ptr
  %l97 = alloca i1
  %l102 = alloca %"compiler/source:Span"
  %l103 = alloca ptr
  %l104 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca i1
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l127 = alloca i64
  %l129 = alloca %"compiler/source:Span"
  %l130 = alloca %"compiler/source:Span"
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l16
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l16, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t9 = load ptr, ptr %l17, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l17, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 5
  store i1 %t15, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l18, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Promote", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t30 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  store %"compiler/source:Span" %t30, ptr %l26
  br label %bb7
bb7:
  %t31 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t31, ptr %rv
  br label %ret
bb8:
  %t32 = load ptr, ptr %l2, !tbaa !29
  store ptr %t32, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t33 = load ptr, ptr %l27, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l27, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 18}
  %t39 = icmp eq i64 %t37, 6
  store i1 %t39, ptr %l28, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l28, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 0
  %t45 = load %"compiler/source:Span", ptr %t44
  store %"compiler/source:Span" %t45, ptr %l4
  br label %bb17
bb12:
  %t47 = load ptr, ptr %l2, !tbaa !29
  store ptr %t47, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t48 = load ptr, ptr %l33, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load ptr, ptr %l33, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 18}
  %t54 = icmp eq i64 %t52, 7
  store i1 %t54, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t55 = load i1, ptr %l34, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 0
  %t60 = load %"compiler/source:Span", ptr %t59
  store %"compiler/source:Span" %t60, ptr %l4
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l4
  %t66 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t62, %"compiler/source:Span" %t63)
  store %"compiler/source:Span" %t66, ptr %l41
  br label %bb18
bb18:
  %t67 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t67, ptr %rv
  br label %ret
bb19:
  %t68 = load ptr, ptr %l2, !tbaa !29
  store ptr %t68, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t69 = load ptr, ptr %l42, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 18}
  %t75 = icmp eq i64 %t73, 10
  store i1 %t75, ptr %l43, !tbaa !21
  br label %bb21
bb21:
  %t76 = load i1, ptr %l43, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t79, i32 0, i32 0
  %t81 = load %"compiler/source:Span", ptr %t80
  store %"compiler/source:Span" %t81, ptr %l5
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l6, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l5
  %t91 = load ptr, ptr %l6, !tbaa !29
  %t95 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esliceAt(ptr %v0, ptr %v1, ptr %t89, %"compiler/source:Span" %t90, ptr %t91)
  store %"compiler/source:Span" %t95, ptr %l53
  br label %bb25
bb25:
  %t96 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t96, ptr %rv
  br label %ret
bb26:
  %t97 = load ptr, ptr %l2, !tbaa !29
  store ptr %t97, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t98 = load ptr, ptr %l54, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb27, label %bb28
bb27:
  %t101 = load ptr, ptr %l54, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 18}
  %t104 = icmp eq i64 %t102, 11
  store i1 %t104, ptr %l55, !tbaa !21
  br label %bb28
bb28:
  %t105 = load i1, ptr %l55, !tbaa !21
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 0
  %t110 = load %"compiler/source:Span", ptr %t109
  store %"compiler/source:Span" %t110, ptr %l7
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t114, i32 0, i32 2
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l8, !tbaa !29
  br label %bb31
bb30:
  br label %bb38
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l62, !tbaa !29
  %t119 = load ptr, ptr %l8, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Cond", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  br i1 %t124, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8680c8bf7a40147c_d650a7d3d4e83170)
  unreachable
bb33:
  br label %bb34
bb34:
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Cond", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t129)
  store %"compiler/source:Span" %t131, ptr %l68
  br label %bb35
bb35:
  %t132 = getelementptr %"compiler/source:Span", ptr %l68, i32 0, i32 1
  %t133 = load i32, ptr %t132, !tbaa !23
  %t134 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t135 = load i32, ptr %t134, !tbaa !23
  %t138 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t133, i32 %t135)
  store %"compiler/source:Span" %t138, ptr %l71
  br label %bb36
bb36:
  %t139 = load ptr, ptr %l62, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l71
  %t141 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %s4, ptr %t139, %"compiler/source:Span" %t140, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store %"compiler/source:Span" %t141, ptr %l72
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  %t142 = load %"compiler/source:Span", ptr %l72
  store %"compiler/source:Span" %t142, ptr %rv
  br label %ret
bb38:
  %t143 = load ptr, ptr %l2, !tbaa !29
  store ptr %t143, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t144 = load ptr, ptr %l73, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb39, label %bb40
bb39:
  %t147 = load ptr, ptr %l73, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 18}
  %t150 = icmp eq i64 %t148, 2
  store i1 %t150, ptr %l74, !tbaa !21
  br label %bb40
bb40:
  %t151 = load i1, ptr %l74, !tbaa !21
  br i1 %t151, label %bb41, label %bb42
bb41:
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t154, i32 0, i32 0
  %t156 = load %"compiler/source:Span", ptr %t155
  store %"compiler/source:Span" %t156, ptr %l9
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t160, i32 0, i32 2
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l10, !tbaa !29
  br label %bb47
bb42:
  %t164 = load ptr, ptr %l2, !tbaa !29
  store ptr %t164, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t165 = load ptr, ptr %l81, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb43, label %bb44
bb43:
  %t168 = load ptr, ptr %l81, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 18}
  %t171 = icmp eq i64 %t169, 3
  store i1 %t171, ptr %l82, !tbaa !21
  br label %bb44
bb44:
  %t172 = load i1, ptr %l82, !tbaa !21
  br i1 %t172, label %bb45, label %bb46
bb45:
  %t173 = load ptr, ptr %l2, !tbaa !29
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t175, i32 0, i32 0
  %t177 = load %"compiler/source:Span", ptr %t176
  store %"compiler/source:Span" %t177, ptr %l9
  %t179 = load ptr, ptr %l2, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 2
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb86
bb47:
  %t185 = load ptr, ptr %l10, !tbaa !29
  store ptr %t185, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t186 = load ptr, ptr %l89, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb48, label %bb49
bb48:
  %t189 = load ptr, ptr %l89, !tbaa !29
  %t190 = load i64, ptr %t189, !range !{i64 0, i64 8}
  %t192 = icmp eq i64 %t190, 3
  store i1 %t192, ptr %l90, !tbaa !21
  br label %bb49
bb49:
  %t193 = load i1, ptr %l90, !tbaa !21
  br i1 %t193, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l9
  %t198 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t194, %"compiler/source:Span" %t195)
  store %"compiler/source:Span" %t198, ptr %l95
  br label %bb53
bb53:
  %t199 = load %"compiler/source:Span", ptr %l95
  store %"compiler/source:Span" %t199, ptr %rv
  br label %ret
bb54:
  %t200 = load ptr, ptr %l10, !tbaa !29
  store ptr %t200, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t201 = load ptr, ptr %l96, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb55, label %bb56
bb55:
  %t204 = load ptr, ptr %l96, !tbaa !29
  %t205 = load i64, ptr %t204, !range !{i64 0, i64 8}
  %t207 = icmp eq i64 %t205, 4
  store i1 %t207, ptr %l97, !tbaa !21
  br label %bb56
bb56:
  %t208 = load i1, ptr %l97, !tbaa !21
  br i1 %t208, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l9
  %t213 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastBracket(ptr %v0, ptr %t209, %"compiler/source:Span" %t210)
  store %"compiler/source:Span" %t213, ptr %l102
  br label %bb60
bb60:
  %t214 = load %"compiler/source:Span", ptr %l102
  store %"compiler/source:Span" %t214, ptr %rv
  br label %ret
bb61:
  %t215 = load ptr, ptr %l10, !tbaa !29
  store ptr %t215, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t216 = load ptr, ptr %l103, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb62, label %bb63
bb62:
  %t219 = load ptr, ptr %l103, !tbaa !29
  %t220 = load i64, ptr %t219, !range !{i64 0, i64 8}
  %t222 = icmp eq i64 %t220, 2
  store i1 %t222, ptr %l104, !tbaa !21
  br label %bb63
bb63:
  %t223 = load i1, ptr %l104, !tbaa !21
  br i1 %t223, label %bb64, label %bb65
bb64:
  %t224 = load ptr, ptr %l10, !tbaa !29
  %t226 = getelementptr { i64, [4 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t226, i32 0, i32 2
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l11, !tbaa !29
  br label %bb66
bb65:
  br label %bb80
bb66:
  store %olang.scope zeroinitializer, ptr %s8
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l11, !tbaa !29
  %t235 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s8, ptr %t230, ptr %t231)
  store ptr %t235, ptr %l112
  br label %bb67
bb67:
  %t236 = load ptr, ptr %l112, !tbaa !29
  store ptr %t236, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t238 = load ptr, ptr %l113, !tbaa !29
  %t239 = icmp ne ptr %t238, null
  br i1 %t239, label %bb68, label %bb69
bb68:
  %t241 = load ptr, ptr %l113, !tbaa !29
  %t242 = load i64, ptr %t241, !range !{i64 0, i64 18}
  %t244 = icmp eq i64 %t242, 10
  store i1 %t244, ptr %l114, !tbaa !21
  br label %bb69
bb69:
  %t245 = load i1, ptr %l114, !tbaa !21
  br i1 %t245, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load ptr, ptr %l11, !tbaa !29
  %t250 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t246, ptr %t247)
  store %"compiler/source:Span" %t250, ptr %l119
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s8)
  %t251 = load %"compiler/source:Span", ptr %l119
  store %"compiler/source:Span" %t251, ptr %rv
  br label %ret
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_22d8393d4f188012_8c9f9e39cb427896)
  unreachable
bb79:
  call void @__olang_scope_close(ptr %s8)
  br label %bb85
bb80:
  br i1 true, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_7213214fb222d0c9_1eae7674ed2401ad)
  unreachable
bb85:
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_7794e183659425f8_898d85cb25e621fc)
  unreachable
bb91:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l120, !tbaa !29
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/scope:Scoper", ptr %t253, i32 0, i32 25
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = icmp eq ptr %t256, null
  br i1 %t258, label %bb92, label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_2d6fa2178670cc38_6a7a96bf0e7e73f4)
  unreachable
bb93:
  br label %bb94
bb94:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/scope:Scoper", ptr %t260, i32 0, i32 25
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t266 = getelementptr %"compiler/typed:Body", ptr %t263, i32 0, i32 3
  %t267 = load i64, ptr %t266, !tbaa !24
  store i64 %t267, ptr %l127, !tbaa !24
  %t268 = load ptr, ptr %l2, !tbaa !29
  %t270 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t268)
  store %"compiler/source:Span" %t270, ptr %l129
  br label %bb95
bb95:
  %t271 = load ptr, ptr %l120, !tbaa !29
  %t272 = load i64, ptr %l127, !tbaa !24
  %t273 = load %"compiler/source:Span", ptr %l129
  %t274 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t271, i64 %t272, %"compiler/source:Span" %t273)
  store %"compiler/source:Span" %t274, ptr %l130
  br label %bb96
bb96:
  %t275 = load %"compiler/source:Span", ptr %l130
  store %"compiler/source:Span" %t275, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i1
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l8, !tbaa !24
  br label %bb51
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store i64 %t44, ptr %l27
  br label %bb13
bb13:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  br label %bb51
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t47 = load ptr, ptr %l28, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l28, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l29, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store i64 %t68, ptr %l37
  br label %bb20
bb20:
  %t69 = load i64, ptr %l37, !tbaa !24
  store i64 %t69, ptr %l8, !tbaa !24
  br label %bb51
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 2
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t90 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltCall(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  store i64 %t90, ptr %l47
  br label %bb27
bb27:
  %t91 = load i64, ptr %l47, !tbaa !24
  store i64 %t91, ptr %l8, !tbaa !24
  br label %bb51
bb28:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t93 = load ptr, ptr %l48, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 8}
  %t99 = icmp eq i64 %t97, 6
  store i1 %t99, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t100 = load i1, ptr %l49, !tbaa !21
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t112 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltCall(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  store i64 %t112, ptr %l57
  br label %bb34
bb34:
  %t113 = load i64, ptr %l57, !tbaa !24
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb51
bb35:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t115 = load ptr, ptr %l58, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb36, label %bb37
bb36:
  %t118 = load ptr, ptr %l58, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 8}
  %t121 = icmp eq i64 %t119, 0
  store i1 %t121, ptr %l59, !tbaa !21
  br label %bb37
bb37:
  %t122 = load i1, ptr %l59, !tbaa !21
  br i1 %t122, label %bb38, label %bb39
bb38:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t125, i32 0, i32 2
  %t127 = load i32, ptr %t126
  store i32 %t127, ptr %l7, !tbaa !23
  br label %bb40
bb39:
  br label %bb46
bb40:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l64, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/scope:Scoper", ptr %t130, i32 0, i32 40
  %t133 = load i32, ptr %l7, !tbaa !23
  %t135 = sext i32 %t133 to i64
  %t138 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t132, i64 %t135)
  %t139 = extractvalue { i32, ptr } %t138, 1
  %t140 = extractvalue { i32, ptr } %t138, 0
  store i32 %t140, ptr %l71
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb42, label %ok.142, !prof !99
ok.142:
  store ptr %t139, ptr %l70
  br label %bb41
bb41:
  %t143 = load ptr, ptr %l70, !tbaa !29
  store ptr %t143, ptr %l65, !tbaa !29
  br label %bb44
bb42:
  br label %bb43
bb43:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l65, !tbaa !29
  br label %bb44
bb44:
  %t144 = load ptr, ptr %l64, !tbaa !29
  %t145 = load ptr, ptr %l65, !tbaa !29
  %t146 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltCall(ptr %v0, ptr %v0, ptr %t144, ptr %t145)
  store i64 %t146, ptr %l72
  br label %bb45
bb45:
  %t147 = load i64, ptr %l72, !tbaa !24
  store i64 %t147, ptr %l8, !tbaa !24
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_da3e82aad0dc20bd_21e51e34c917c3d9)
  unreachable
bb51:
  %t148 = load i64, ptr %l8, !tbaa !24
  store i64 %t148, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartKept(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l9 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l33 = alloca %"compiler/source:Span"
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca i64
  %l46 = alloca %"compiler/source:Span"
  %l48 = alloca i64
  %l49 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l69 = alloca %"compiler/typed:Local"
  %l71 = alloca { i64, ptr }
  %l72 = alloca %"compiler/msgs:Msg"
  %l73 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOfOwn(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t15 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t10, ptr %t11)
  store ptr %t15, ptr %l15
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l15, !tbaa !29
  %t17 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t16)
  store ptr %t17, ptr %l16
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l16, !tbaa !29
  store ptr %t18, ptr %l3, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclaimRoot(ptr %v0, ptr %v1, ptr %t19, ptr %t20)
  store i64 %t23, ptr %l19
  br label %bb7
bb7:
  %t24 = load i64, ptr %l19, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 10
  store ptr %t27, ptr %l22, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/scope:Scoper", ptr %t28, i32 0, i32 25
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_178b2bff302b55ae_896b4874215d5e1a)
  unreachable
bb9:
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 25
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 3
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t45 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t43, i64 %t42)
  %t46 = extractvalue { i32, { i64, ptr } } %t45, 1
  %t47 = extractvalue { i32, { i64, ptr } } %t45, 0
  store i32 %t47, ptr %l31
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb12, label %ok.49, !prof !99
ok.49:
  store { i64, ptr } %t46, ptr %l30
  br label %bb11
bb11:
  %t50 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t50, ptr %l20, !tbaa !27
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l20, !tbaa !27
  br label %bb14
bb14:
  %t51 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t51, ptr %l5, !tbaa !27
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %s0, ptr %t52)
  store %"compiler/source:Span" %t54, ptr %l33
  br label %bb15
bb15:
  %t55 = getelementptr %"compiler/source:Span", ptr %l33, i32 0, i32 1
  %t56 = load i32, ptr %t55, !tbaa !23
  %t58 = sext i32 %t56 to i64
  %t59 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp sle i64 %t58, %t61
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t66, ptr %l40, !tbaa !27
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t69 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %s0, ptr %t67)
  store %"compiler/source:Span" %t69, ptr %l42
  br label %bb18
bb17:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l39, !tbaa !27
  br label %bb26
bb18:
  %t70 = getelementptr %"compiler/source:Span", ptr %l42, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t73 = sext i32 %t71 to i64
  store i64 %t73, ptr %l44, !tbaa !24
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %s0, ptr %t74)
  store %"compiler/source:Span" %t76, ptr %l46
  br label %bb19
bb19:
  %t77 = getelementptr %"compiler/source:Span", ptr %l46, i32 0, i32 1
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = sext i32 %t78 to i64
  store i64 %t80, ptr %l48, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l49, !tbaa !24
  %t83 = load i64, ptr %l44, !tbaa !24
  %t84 = icmp sge i64 %t83, 0
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t86 = load i64, ptr %l44, !tbaa !24
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_98dfeaa5663cde63_8f6c693e4f6dac2f)
  unreachable
bb22:
  %t90 = load i64, ptr %l48, !tbaa !24
  %t91 = load i64, ptr %l49, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_98dfeaa5663cde63_8f6c693e4f6dac2f)
  unreachable
bb24:
  %t94 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l44, !tbaa !24
  %t97 = load i64, ptr %l48, !tbaa !24
  %t98 = getelementptr i8, ptr %t95, i64 %t96
  %t99 = sub i64 %t97, %t96
  %t100 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t98, 1
  store { i64, ptr } %t101, ptr %l39, !tbaa !27
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_98dfeaa5663cde63_8f6c693e4f6dac2f)
  unreachable
bb26:
  %t103 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l54, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l55
  store { i64, ptr } %t103, ptr %l56, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/scope:Scoper", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 3
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l60, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/scope:Scoper", ptr %t117, i32 0, i32 25
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = icmp eq ptr %t120, null
  br i1 %t122, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_50915285e3e59b40_32eaccc11482b3ec)
  unreachable
bb28:
  br label %bb29
bb29:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/scope:Scoper", ptr %t124, i32 0, i32 25
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Body", ptr %t127, i32 0, i32 7
  %t131 = load i64, ptr %l4, !tbaa !24
  %t134 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t130, i64 %t131)
  store %"compiler/typed:Local" %t134, ptr %l69
  br label %bb30
bb30:
  %t135 = getelementptr %"compiler/typed:Local", ptr %l69, i32 0, i32 0
  %t136 = load i32, ptr %t135, !tbaa !23
  %t137 = load ptr, ptr %l60, !tbaa !29
  %t139 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t137, i32 %t136)
  store { i64, ptr } %t139, ptr %l71
  br label %bb31
bb31:
  %t140 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t142 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePartKept(ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t140, { i64, ptr } %t141)
  store %"compiler/msgs:Msg" %t142, ptr %l72
  br label %bb32
bb32:
  %t143 = load ptr, ptr %l54, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l55
  %t145 = load %"compiler/msgs:Msg", ptr %l72
  %t146 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s0, ptr %t143, %"compiler/source:Span" %t144, %"compiler/msgs:Msg" %t145)
  store i64 %t146, ptr %l73
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca i32
  %l39 = alloca i1
  %l44 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca i32
  %l55 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l99 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca i64
  %l103 = alloca i64
  %l108 = alloca i32
  %l117 = alloca ptr
  %l122 = alloca i32
  %l125 = alloca ptr
  %l130 = alloca i32
  %l137 = alloca ptr
  %l142 = alloca i32
  %l143 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l166 = alloca i32
  %l167 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l181 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l183 = alloca i64
  %l185 = alloca i64
  %l190 = alloca i32
  %s11 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l32
  br label %bb2
bb2:
  %t15 = load i32, ptr %l32, !range !{i32 0, i32 33}
  store i32 %t15, ptr %l3
  %t16 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb61
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l1, !tbaa !23
  %t30 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t30, ptr %l39
  br label %bb6
bb6:
  %t31 = load i1, ptr %l39, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %lp2
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l44, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l49
  br label %bb10
bb10:
  %t53 = load ptr, ptr %l44, !tbaa !29
  %t54 = load i32, ptr %l49, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t55, ptr %l50
  br label %bb11
bb11:
  %t56 = load i32, ptr %l50, !range !{i32 0, i32 6}
  store i32 %t56, ptr %l4
  %t57 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t59 = trunc i64 0 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  store ptr %t67, ptr %l55, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l60
  br label %bb15
bb15:
  %t78 = load ptr, ptr %l55, !tbaa !29
  %t79 = load i32, ptr %l60, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t78, i32 %t79)
  store { i64, ptr } %t80, ptr %l61
  br label %bb16
bb16:
  %t81 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t81, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t86 = load i64, ptr %l6, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t94 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t94, ptr %l68, !tbaa !27
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  %t102 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t102, i32 %t100)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l6, !tbaa !24
  br label %bb17
bb23:
  br label %bb60
bb24:
  %t110 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t112 = trunc i64 1 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb49
bb27:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/scope:Scoper", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  store ptr %t120, ptr %l79, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/scope:Scoper", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %l1, !tbaa !23
  %t130 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t126, i32 %t127)
  store i32 %t130, ptr %l84
  br label %bb28
bb28:
  %t131 = load ptr, ptr %l79, !tbaa !29
  %t132 = load i32, ptr %l84, !tbaa !23
  %t133 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t131, i32 %t132)
  store { i64, ptr } %t133, ptr %l85
  br label %bb29
bb29:
  %t134 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t134, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l11, !tbaa !24
  br label %bb30
bb30:
  %t139 = load i64, ptr %l10, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb31, label %bb32
bb31:
  br label %bb48
bb32:
  br label %bb33
bb33:
  %t147 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t147, ptr %l92, !tbaa !27
  %t148 = load i64, ptr %l10, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 %t148
  %t153 = load i32, ptr %t152, !tbaa !33
  store i32 %t153, ptr %l12, !tbaa !23
  %t155 = load i32, ptr %l12, !tbaa !23
  %t157 = icmp ne i32 %t155, 0
  br i1 %t157, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s11
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l12, !tbaa !23
  %t163 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s11, ptr %t159, i32 %t160)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %l99
  br label %bb36
bb35:
  br label %bb46
bb36:
  %t164 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l99
  %t165 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %t165
  store ptr %t165, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb37
bb37:
  %t167 = load i64, ptr %l14, !tbaa !24
  store i64 %t167, ptr %l101, !tbaa !24
  %t168 = load ptr, ptr %l13, !tbaa !29
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s11, ptr %t168)
  store i64 %t170, ptr %l103
  br label %bb38
bb38:
  %t171 = load i64, ptr %l101, !tbaa !24
  %t172 = load i64, ptr %l103, !tbaa !24
  %t173 = icmp slt i64 %t171, %t172
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb39, label %bb40
bb39:
  br label %bb45
bb40:
  br label %bb41
bb41:
  %t177 = load ptr, ptr %l13, !tbaa !29
  %t178 = load i64, ptr %l14, !tbaa !24
  %t181 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s11, ptr %t177, i64 %t178)
  store i32 %t181, ptr %l108
  br label %bb42
bb42:
  %t182 = load i32, ptr %l108, !tbaa !23
  %t183 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t183, i32 %t182)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t187 = load i64, ptr %l14, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l14, !tbaa !24
  br label %bb37
bb45:
  call void @__olang_scope_close(ptr %s11)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t191 = load i64, ptr %l10, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l10, !tbaa !24
  br label %bb30
bb48:
  br label %bb60
bb49:
  %t195 = load i32, ptr %l4, !range !{i32 0, i32 6}
  %t197 = trunc i64 4 to i32
  %t198 = icmp eq i32 %t195, %t197
  br i1 %t198, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb55
bb52:
  %t200 = load ptr, ptr %lp2
  store ptr %t200, ptr %l117, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/scope:Scoper", ptr %t201, i32 0, i32 0
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/generic:Program", ptr %t204, i32 0, i32 2
  %t207 = load i32, ptr %l1, !tbaa !23
  %t210 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t206, i32 %t207)
  store i32 %t210, ptr %l122
  br label %bb53
bb53:
  %t211 = load ptr, ptr %l117, !tbaa !29
  %t212 = load i32, ptr %l122, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t211, i32 %t212)
  br label %bb54
bb54:
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_74d9849f1cf072e4_d95edc215f7aa198)
  unreachable
bb60:
  br label %bb112
bb61:
  %t213 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t215 = trunc i64 19 to i32
  %t216 = icmp eq i32 %t213, %t215
  br i1 %t216, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t218 = load ptr, ptr %lp2
  store ptr %t218, ptr %l125, !tbaa !29
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/scope:Scoper", ptr %t219, i32 0, i32 0
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t224 = getelementptr %"compiler/generic:Program", ptr %t222, i32 0, i32 2
  %t225 = load i32, ptr %l1, !tbaa !23
  %t228 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t224, i32 %t225)
  store i32 %t228, ptr %l130
  br label %bb65
bb65:
  %t229 = load ptr, ptr %l125, !tbaa !29
  %t230 = load i32, ptr %l130, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t229, i32 %t230)
  br label %bb66
bb66:
  br label %bb112
bb67:
  %t231 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t233 = trunc i64 22 to i32
  %t234 = icmp eq i32 %t231, %t233
  br i1 %t234, label %bb68, label %bb69
bb68:
  br label %bb72
bb69:
  %t236 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t238 = trunc i64 23 to i32
  %t239 = icmp eq i32 %t236, %t238
  br i1 %t239, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb82
bb72:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/scope:Scoper", ptr %t241, i32 0, i32 0
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = getelementptr %"compiler/generic:Program", ptr %t244, i32 0, i32 2
  store ptr %t246, ptr %l137, !tbaa !29
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/scope:Scoper", ptr %t247, i32 0, i32 0
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = getelementptr %"compiler/generic:Program", ptr %t250, i32 0, i32 2
  %t253 = load i32, ptr %l1, !tbaa !23
  %t256 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t252, i32 %t253)
  store i32 %t256, ptr %l142
  br label %bb73
bb73:
  %t257 = load ptr, ptr %l137, !tbaa !29
  %t258 = load i32, ptr %l142, !tbaa !23
  %t259 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t257, i32 %t258)
  store { i64, ptr } %t259, ptr %l143
  br label %bb74
bb74:
  %t260 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t260, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t261 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t261, 0
  store i64 %t263, ptr %l18, !tbaa !24
  br label %bb75
bb75:
  %t265 = load i64, ptr %l17, !tbaa !24
  %t266 = load i64, ptr %l18, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb76, label %bb77
bb76:
  br label %bb81
bb77:
  br label %bb78
bb78:
  %t273 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t273, ptr %l150, !tbaa !27
  %t274 = load i64, ptr %l17, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr i32, ptr %t277, i64 %t274
  %t279 = load i32, ptr %t278, !tbaa !33
  %t281 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t281, i32 %t279)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t285 = load i64, ptr %l17, !tbaa !24
  %t287 = add i64 %t285, 1
  store i64 %t287, ptr %l17, !tbaa !24
  br label %bb75
bb81:
  br label %bb112
bb82:
  %t289 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t291 = trunc i64 24 to i32
  %t292 = icmp eq i32 %t289, %t291
  br i1 %t292, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb107
bb85:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/scope:Scoper", ptr %t294, i32 0, i32 0
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/generic:Program", ptr %t297, i32 0, i32 2
  store ptr %t299, ptr %l161, !tbaa !29
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/scope:Scoper", ptr %t300, i32 0, i32 0
  %t303 = load ptr, ptr %t302, !tbaa !29
  %t305 = getelementptr %"compiler/generic:Program", ptr %t303, i32 0, i32 2
  %t306 = load i32, ptr %l1, !tbaa !23
  %t309 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t305, i32 %t306)
  store i32 %t309, ptr %l166
  br label %bb86
bb86:
  %t310 = load ptr, ptr %l161, !tbaa !29
  %t311 = load i32, ptr %l166, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t310, i32 %t311)
  store { i64, ptr } %t312, ptr %l167
  br label %bb87
bb87:
  %t313 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t313, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t314 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t314, 0
  store i64 %t316, ptr %l22, !tbaa !24
  br label %bb88
bb88:
  %t318 = load i64, ptr %l21, !tbaa !24
  %t319 = load i64, ptr %l22, !tbaa !24
  %t322 = icmp slt i64 %t318, %t319
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb89, label %bb90
bb89:
  br label %bb106
bb90:
  br label %bb91
bb91:
  %t326 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t326, ptr %l174, !tbaa !27
  %t327 = load i64, ptr %l21, !tbaa !24
  %t329 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = getelementptr i32, ptr %t330, i64 %t327
  %t332 = load i32, ptr %t331, !tbaa !33
  store i32 %t332, ptr %l23, !tbaa !23
  %t334 = load i32, ptr %l23, !tbaa !23
  %t336 = icmp ne i32 %t334, 0
  br i1 %t336, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s26
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i32, ptr %l23, !tbaa !23
  %t342 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s26, ptr %t338, i32 %t339)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t342, ptr %l181
  br label %bb94
bb93:
  br label %bb104
bb94:
  %t343 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l181
  %t344 = call ptr @__olang_scope_alloc_a(ptr %s26, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t343, ptr %t344
  store ptr %t344, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb95
bb95:
  %t346 = load i64, ptr %l25, !tbaa !24
  store i64 %t346, ptr %l183, !tbaa !24
  %t347 = load ptr, ptr %l24, !tbaa !29
  %t349 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s26, ptr %t347)
  store i64 %t349, ptr %l185
  br label %bb96
bb96:
  %t350 = load i64, ptr %l183, !tbaa !24
  %t351 = load i64, ptr %l185, !tbaa !24
  %t352 = icmp slt i64 %t350, %t351
  %t354 = xor i1 %t352, true
  br i1 %t354, label %bb97, label %bb98
bb97:
  br label %bb103
bb98:
  br label %bb99
bb99:
  %t356 = load ptr, ptr %l24, !tbaa !29
  %t357 = load i64, ptr %l25, !tbaa !24
  %t360 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s26, ptr %t356, i64 %t357)
  store i32 %t360, ptr %l190
  br label %bb100
bb100:
  %t361 = load i32, ptr %l190, !tbaa !23
  %t362 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t362, i32 %t361)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t366 = load i64, ptr %l25, !tbaa !24
  %t368 = add i64 %t366, 1
  store i64 %t368, ptr %l25, !tbaa !24
  br label %bb95
bb103:
  call void @__olang_scope_close(ptr %s26)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t370 = load i64, ptr %l21, !tbaa !24
  %t372 = add i64 %t370, 1
  store i64 %t372, ptr %l21, !tbaa !24
  br label %bb88
bb106:
  br label %bb112
bb107:
  br i1 true, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_b99a325748da8cd5_4eb62b65b3c79869)
  unreachable
bb112:
  %t374 = load ptr, ptr %lp2
  %t375 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t374
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t375, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2equalifiesMove(ptr %v0, ptr %v1, ptr %a0, %"compiler/typed:Local" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/typed:Local"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l46 = alloca i1
  %l51 = alloca i1
  %l57 = alloca i32
  %l60 = alloca i1
  %l63 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/typed:Local" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 2
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l3, !tbaa !23
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l14
  br label %bb5
bb5:
  %t16 = load i1, ptr %l14, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  %t17 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 5
  %t18 = load { i64, [2 x i64] }, ptr %t17
  store { i64, [2 x i64] } %t18, ptr %l4
  %t20 = load { i64, [2 x i64] }, ptr %l4
  %t22 = extractvalue { i64, [2 x i64] } %t20, 0
  %t23 = icmp eq i64 %t22, 1
  br i1 %t23, label %bb8, label %bb9
bb7:
  br label %bb32
bb8:
  br label %bb12
bb9:
  %t25 = load { i64, [2 x i64] }, ptr %l4
  %t27 = extractvalue { i64, [2 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 5
  br i1 %t28, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_554265ba1528b3d8_d73d8ae267adc184)
  unreachable
bb18:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t36 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t36, ptr %l24
  br label %bb19
bb19:
  %t37 = load i1, ptr %l24, !tbaa !21
  br i1 %t37, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb23
bb21:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t42 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  store i1 %t42, ptr %l28
  br label %bb22
bb22:
  %t43 = load i1, ptr %l28, !tbaa !21
  store i1 %t43, ptr %l25, !tbaa !21
  br label %bb23
bb23:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb27
bb25:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisData(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store i1 %t49, ptr %l32
  br label %bb26
bb26:
  %t50 = load i1, ptr %l32, !tbaa !21
  store i1 %t50, ptr %l29, !tbaa !21
  br label %bb27
bb27:
  %t51 = load i1, ptr %l29, !tbaa !21
  br i1 %t51, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb31
bb29:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t56 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  store i1 %t56, ptr %l36
  br label %bb30
bb30:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %l33, !tbaa !21
  br label %bb31
bb31:
  %t58 = load i1, ptr %l33, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
bb32:
  %t59 = getelementptr %"compiler/typed:Local", ptr %l1, i32 0, i32 5
  %t60 = load { i64, [2 x i64] }, ptr %t59
  store { i64, [2 x i64] } %t60, ptr %l5
  %t62 = load { i64, [2 x i64] }, ptr %l5
  %t64 = extractvalue { i64, [2 x i64] } %t62, 0
  %t65 = icmp eq i64 %t64, 0
  br i1 %t65, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  %t67 = load { i64, [2 x i64] }, ptr %l5
  %t69 = extractvalue { i64, [2 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 5
  br i1 %t70, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i1 false, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_c484f993348186a9_88a471068962d75)
  unreachable
bb43:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t78 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t73, ptr %t74)
  store i1 %t78, ptr %l46
  br label %bb44
bb44:
  %t79 = load i1, ptr %l46, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb45, label %bb46
bb45:
  store i1 false, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l3, !tbaa !23
  %t87 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l51
  br label %bb48
bb48:
  %t88 = load i1, ptr %l51, !tbaa !21
  br i1 %t88, label %bb49, label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/scope:Scoper", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l3, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l57
  br label %bb52
bb52:
  %t100 = load i32, ptr %l57, !range !{i32 0, i32 33}
  store i32 %t100, ptr %l6
  %t101 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t103 = trunc i64 19 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb55
bb54:
  %t106 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t108 = trunc i64 18 to i32
  %t109 = icmp eq i32 %t106, %t108
  store i1 %t109, ptr %l60, !tbaa !21
  br label %bb55
bb55:
  %t111 = load i1, ptr %l60, !tbaa !21
  br i1 %t111, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb58
bb57:
  %t112 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t114 = trunc i64 22 to i32
  %t115 = icmp eq i32 %t112, %t114
  store i1 %t115, ptr %l63, !tbaa !21
  br label %bb58
bb58:
  %t117 = load i1, ptr %l63, !tbaa !21
  store i1 %t117, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eread(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca %"compiler/scope:Val"
  %l11 = alloca i64
  %l14 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca i1
  %l25 = alloca %"compiler/scope:Val"
  %l33 = alloca i1
  %rv = alloca %"compiler/scope:Val"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t4 = load { i64, [2 x i64] }, ptr %l3
  %t9 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartLand(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t3, { i64, [2 x i64] } %t4)
  store i64 %t9, ptr %l11
  br label %bb1
bb1:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 108
  %t14 = load i1, ptr %t13, !tbaa !21
  store i1 %t14, ptr %l5, !tbaa !21
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb5
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l19
  br label %bb4
bb4:
  %t24 = load i1, ptr %l19, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l16, !tbaa !21
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t28, i32 0, i32 108
  store i1 %t27, ptr %t29, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t33 = load { i64, [2 x i64] }, ptr %l3
  %t38 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereadPart(ptr %v0, ptr %v1, ptr %t30, ptr %t31, i32 %t32, { i64, [2 x i64] } %t33)
  store %"compiler/scope:Val" %t38, ptr %l25
  br label %bb6
bb6:
  %t39 = load %"compiler/scope:Val", ptr %l25
  store %"compiler/scope:Val" %t39, ptr %l6
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i1, ptr %l5, !tbaa !21
  %t44 = getelementptr %"compiler/scope:Scoper", ptr %t40, i32 0, i32 108
  store i1 %t41, ptr %t44, !tbaa !21
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  br i1 %t47, label %bb7, label %bb8
bb7:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 91
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb4ab14fd1aa8deeb21095c3402461540(ptr %v0, ptr %t51, i64 %t52)
  store i1 %t55, ptr %l33
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t56 = load %"compiler/scope:Val", ptr %l6
  store %"compiler/scope:Val" %t56, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultMark(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca ptr
  %l13 = alloca i32
  %l19 = alloca { i64, [2 x i64] }
  %l33 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca i64
  %l51 = alloca i64
  %l63 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t32 = alloca { i64, [2 x i64] }, align 8
  %t61 = alloca { i64, [2 x i64] }, align 8
  %t116 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/scope:Scoper", ptr %t7, i32 0, i32 25
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_59817874246b5c57_1f46b3df70232973)
  unreachable
bb2:
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 25
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 2
  %t21 = load i32, ptr %t20, !tbaa !23
  %t22 = load ptr, ptr %l5, !tbaa !29
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t22, i32 %t21)
  store i32 %t24, ptr %l13
  br label %bb4
bb4:
  %t25 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t27 = trunc i64 21 to i32
  %t28 = icmp eq i32 %t25, %t27
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  store { i64, [2 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [2 x i64] }, ptr %t32, i32 0, i32 0
  store i64 1, ptr %t33
  %t34 = load { i64, [2 x i64] }, ptr %t32
  store { i64, [2 x i64] } %t34, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %t36)
  store { i64, [2 x i64] } %t38, ptr %l19
  br label %bb8
bb8:
  %t39 = load { i64, [2 x i64] }, ptr %l19
  %t41 = extractvalue { i64, [2 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 0
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 25
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb11, label %bb12
bb10:
  br label %bb14
bb11:
  call void @__olang_check_failed(ptr @olang_loc_56ee07e6d564b038_6c64e51b3b797fa4)
  unreachable
bb12:
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 25
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 15
  %t60 = load i32, ptr %t59, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [2 x i64] }, ptr %t61, i32 0, i32 0
  store i64 2, ptr %t62
  %t64 = insertvalue { i32 } undef, i32 %t60, 0
  %t65 = getelementptr { i64, [2 x i64] }, ptr %t61, i32 0, i32 1
  store { i32 } %t64, ptr %t65
  %t66 = load { i64, [2 x i64] }, ptr %t61
  store { i64, [2 x i64] } %t66, ptr %rv
  br label %ret
bb14:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  store ptr %t73, ptr %l33, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/scope:Scoper", ptr %t74, i32 0, i32 25
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_8b89bffa420e9c4d_32da4af1bb00bb59)
  unreachable
bb16:
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 25
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t84, i32 0, i32 2
  %t88 = load i32, ptr %t87, !tbaa !23
  %t89 = load i64, ptr %l1, !tbaa !24
  %t90 = load ptr, ptr %l33, !tbaa !29
  %t93 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t90, i32 %t88, i64 %t89)
  store i64 %t93, ptr %l42
  br label %bb18
bb18:
  %t94 = load i64, ptr %l42, !tbaa !24
  store i64 %t94, ptr %l43, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/scope:Scoper", ptr %t96, i32 0, i32 25
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = icmp eq ptr %t99, null
  br i1 %t101, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_cf97101c527ac266_2da604e73063aa32)
  unreachable
bb20:
  br label %bb21
bb21:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/scope:Scoper", ptr %t103, i32 0, i32 25
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Body", ptr %t106, i32 0, i32 5
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l51
  br label %bb22
bb22:
  %t112 = load i64, ptr %l43, !tbaa !24
  %t113 = load i64, ptr %l51, !tbaa !24
  %t114 = icmp sge i64 %t112, %t113
  br i1 %t114, label %bb23, label %bb24
bb23:
  store { i64, [2 x i64] } zeroinitializer, ptr %t116
  %t117 = getelementptr { i64, [2 x i64] }, ptr %t116, i32 0, i32 0
  store i64 6, ptr %t117
  %t118 = load { i64, [2 x i64] }, ptr %t116
  store { i64, [2 x i64] } %t118, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/scope:Scoper", ptr %t120, i32 0, i32 25
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = icmp eq ptr %t123, null
  br i1 %t125, label %bb26, label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_289e5954cee327eb_2a90d26159dceaff)
  unreachable
bb27:
  br label %bb28
bb28:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/scope:Scoper", ptr %t127, i32 0, i32 25
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/scope:Scoper", ptr %t131, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i64, ptr %l1, !tbaa !24
  %t141 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eResultMark(ptr %v0, ptr %v0, ptr %t130, ptr %t136, i64 %t137)
  store { i64, [2 x i64] } %t141, ptr %l63
  br label %bb29
bb29:
  %t142 = load { i64, [2 x i64] }, ptr %l63
  store { i64, [2 x i64] } %t142, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t13, i32 %t14)
  store { i64, ptr } %t17, ptr %l17
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i64, ptr %l5, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb10
bb7:
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l26, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l26, !tbaa !24
  store i64 %t49, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l23, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb12, label %bb13
bb12:
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = mul i64 %t60, %t61
  %t67 = add i64 %t59, %t64
  store i64 %t67, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i64, ptr %t72, i64 %t69
  %t74 = load i64, ptr %t73, !tbaa !34
  %t75 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t78 = icmp eq i64 %t74, %t75
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t80 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t80, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb11
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, [1 x i64] }
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l24 = alloca { i64, [2 x i64] }
  %l25 = alloca i32
  %l26 = alloca %"compiler/scope:walked"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i32
  %l39 = alloca ptr
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l79 = alloca ptr
  %l86 = alloca %"compiler/typed:Local"
  %l89 = alloca i1
  %l96 = alloca %"compiler/typed:Local"
  %l99 = alloca i64
  %l109 = alloca i64
  %l113 = alloca i64
  %l116 = alloca i64
  %l140 = alloca { i64, [1 x i64] }
  %l172 = alloca i64
  %l175 = alloca ptr
  %l181 = alloca i32
  %l192 = alloca i64
  %l196 = alloca i64
  %l199 = alloca i64
  %l223 = alloca i32
  %l231 = alloca %"compiler/typed:Local"
  %l240 = alloca { i64, [2 x i64] }
  %l244 = alloca ptr
  %l246 = alloca i64
  %l251 = alloca { i64, [2 x i64] }
  %l261 = alloca %"compiler/scope:walked"
  %l273 = alloca i64
  %l275 = alloca i64
  %l280 = alloca i32
  %l283 = alloca ptr
  %l291 = alloca %"compiler/typed:Local"
  %l293 = alloca i32
  %l296 = alloca i1
  %l297 = alloca i1
  %l302 = alloca i32
  %l306 = alloca i1
  %l311 = alloca i32
  %l316 = alloca i1
  %l317 = alloca i1
  %l321 = alloca i1
  %l323 = alloca i64
  %l327 = alloca i64
  %l330 = alloca i64
  %l350 = alloca i64
  %l356 = alloca i32
  %l359 = alloca i1
  %l362 = alloca ptr
  %l367 = alloca i32
  %l368 = alloca i64
  %l383 = alloca ptr
  %l395 = alloca i32
  %l398 = alloca i32
  %l399 = alloca i32
  %s18 = alloca %olang.scope
  %t66 = alloca { i64, [2 x i64] }, align 8
  %t74 = alloca { i64, [2 x i64] }, align 8
  %t217 = alloca { i64, [2 x i64] }, align 8
  %t242 = alloca { i64, [2 x i64] }, align 8
  %t300 = alloca { i64, [2 x i64] }, align 8
  %t459 = alloca %"compiler/scope:walked", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_8136fe9cd009015e_effe087bfaf9a8aa)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 7
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l47
  br label %bb4
bb4:
  %t16 = load i64, ptr %l47, !tbaa !24
  store i64 %t16, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb10
bb7:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l54, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l54, !tbaa !24
  store i64 %t43, ptr %l51, !tbaa !24
  br label %bb10
bb10:
  %t44 = load i64, ptr %l51, !tbaa !24
  store i64 %t44, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb12, label %bb13
bb12:
  br label %bb34
bb13:
  br label %bb14
bb14:
  %t53 = load i64, ptr %l2, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l7, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 31
  store { i64, [2 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [2 x i64] }, ptr %t66, i32 0, i32 0
  store i64 0, ptr %t67
  %t68 = load { i64, [2 x i64] }, ptr %t66
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t65, { i64, [2 x i64] } %t68)
  br label %bb15
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/scope:Scoper", ptr %t71, i32 0, i32 32
  store { i64, [2 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 0
  store i64 1, ptr %t75
  %t76 = insertvalue { i32 } undef, i32 0, 0
  %t77 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 1
  store { i32 } %t76, ptr %t77
  %t78 = load { i64, [2 x i64] }, ptr %t74
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t73, { i64, [2 x i64] } %t78)
  br label %bb16
bb16:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 132
  store ptr %t83, ptr %l79, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_989f9a5853b8d905_f9638c70ccb394b1)
  unreachable
bb18:
  br label %bb19
bb19:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Body", ptr %t88, i32 0, i32 7
  %t92 = load i64, ptr %l7, !tbaa !24
  %t95 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t91, i64 %t92)
  store %"compiler/typed:Local" %t95, ptr %l86
  br label %bb20
bb20:
  %t96 = getelementptr %"compiler/typed:Local", ptr %l86, i32 0, i32 4
  %t97 = load i32, ptr %t96, !range !{i32 0, i32 7}
  %t99 = trunc i64 1 to i32
  %t100 = icmp eq i32 %t97, %t99
  br i1 %t100, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb27
bb22:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_989f9a5853b8d905_f9638c70ccb394b1)
  unreachable
bb24:
  br label %bb25
bb25:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Body", ptr %t106, i32 0, i32 7
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t109, i64 %t110)
  store %"compiler/typed:Local" %t113, ptr %l96
  br label %bb26
bb26:
  %t114 = getelementptr %"compiler/typed:Local", ptr %l96, i32 0, i32 4
  %t115 = load i32, ptr %t114, !range !{i32 0, i32 7}
  %t117 = trunc i64 3 to i32
  %t118 = icmp eq i32 %t115, %t117
  store i1 %t118, ptr %l89, !tbaa !21
  br label %bb27
bb27:
  %t120 = load i1, ptr %l89, !tbaa !21
  br i1 %t120, label %bb28, label %bb29
bb28:
  store i64 -1, ptr %l99, !tbaa !24
  br label %bb30
bb29:
  store i64 -2, ptr %l99, !tbaa !24
  br label %bb30
bb30:
  %t121 = load ptr, ptr %l79, !tbaa !29
  %t122 = load i64, ptr %l99, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t121, i64 %t122)
  br label %bb31
bb31:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 133
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t125, i64 -1)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t127 = load i64, ptr %l6, !tbaa !24
  %t129 = add i64 %t127, 1
  store i64 %t129, ptr %l6, !tbaa !24
  br label %bb11
bb34:
  store i64 0, ptr %l8, !tbaa !24
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = icmp eq ptr %t131, null
  br i1 %t133, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_9ce8ff5a7c812fb0_6c28ecd338a0cbbc)
  unreachable
bb36:
  br label %bb37
bb37:
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Body", ptr %t135, i32 0, i32 6
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t138)
  store i64 %t140, ptr %l109
  br label %bb38
bb38:
  %t141 = load i64, ptr %l109, !tbaa !24
  store i64 %t141, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  %t143 = load i64, ptr %l8, !tbaa !24
  %t146 = icmp sgt i64 %t142, %t143
  br i1 %t146, label %bb39, label %bb40
bb39:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t150 = icmp sgt i64 %t148, 0
  br i1 %t150, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb44
bb41:
  %t152 = load i64, ptr %l9, !tbaa !24
  %t153 = load i64, ptr %l8, !tbaa !24
  %t156 = sub i64 %t152, %t153
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = add i64 %t156, %t157
  %t162 = sub i64 %t160, 1
  %t163 = load i64, ptr %l10, !tbaa !24
  %t166 = sdiv i64 %t162, %t163
  store i64 %t166, ptr %l116, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb43
bb43:
  %t168 = load i64, ptr %l116, !tbaa !24
  store i64 %t168, ptr %l113, !tbaa !24
  br label %bb44
bb44:
  %t169 = load i64, ptr %l113, !tbaa !24
  store i64 %t169, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb45
bb45:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l11, !tbaa !24
  %t174 = icmp slt i64 %t170, %t171
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb46, label %bb47
bb46:
  br label %bb87
bb47:
  br label %bb48
bb48:
  %t178 = load i64, ptr %l8, !tbaa !24
  %t179 = load i64, ptr %l12, !tbaa !24
  %t180 = load i64, ptr %l10, !tbaa !24
  %t183 = mul i64 %t179, %t180
  %t186 = add i64 %t178, %t183
  store i64 %t186, ptr %l13, !tbaa !24
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = icmp eq ptr %t188, null
  br i1 %t190, label %bb49, label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_5c3642998b37ea8f_438088e259bab72b)
  unreachable
bb50:
  br label %bb51
bb51:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Body", ptr %t192, i32 0, i32 6
  %t196 = load i64, ptr %l13, !tbaa !24
  %t199 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t195, i64 %t196)
  store { i64, [1 x i64] } %t199, ptr %l140
  br label %bb52
bb52:
  %t200 = load { i64, [1 x i64] }, ptr %l140
  store { i64, [1 x i64] } %t200, ptr %l14
  %t201 = load { i64, [1 x i64] }, ptr %l14
  %t203 = extractvalue { i64, [1 x i64] } %t201, 0
  %t204 = icmp eq i64 %t203, 0
  br i1 %t204, label %bb53, label %bb54
bb53:
  %t206 = getelementptr { i64, [1 x i64] }, ptr %l14, i32 0, i32 1
  %t207 = getelementptr { i32 }, ptr %t206, i32 0, i32 0
  %t208 = load i32, ptr %t207
  store i32 %t208, ptr %l15, !tbaa !23
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/scope:Scoper", ptr %t210, i32 0, i32 31
  %t213 = load i32, ptr %l15, !tbaa !23
  %t215 = sext i32 %t213 to i64
  %t216 = load i64, ptr %l13, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t217
  %t218 = getelementptr { i64, [2 x i64] }, ptr %t217, i32 0, i32 0
  store i64 2, ptr %t218
  %t220 = insertvalue { i64 } undef, i64 %t216, 0
  %t221 = getelementptr { i64, [2 x i64] }, ptr %t217, i32 0, i32 1
  store { i64 } %t220, ptr %t221
  %t222 = load { i64, [2 x i64] }, ptr %t217
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t212, i64 %t215, { i64, [2 x i64] } %t222)
  br label %bb56
bb56:
  br label %bb85
bb57:
  %t226 = load { i64, [1 x i64] }, ptr %l14
  %t228 = extractvalue { i64, [1 x i64] } %t226, 0
  %t229 = icmp eq i64 %t228, 4
  br i1 %t229, label %bb58, label %bb59
bb58:
  %t231 = getelementptr { i64, [1 x i64] }, ptr %l14, i32 0, i32 1
  %t232 = getelementptr { i32 }, ptr %t231, i32 0, i32 0
  %t233 = load i32, ptr %t232
  store i32 %t233, ptr %l16, !tbaa !23
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/scope:Scoper", ptr %t235, i32 0, i32 31
  %t238 = load i32, ptr %l16, !tbaa !23
  %t240 = sext i32 %t238 to i64
  %t241 = load i64, ptr %l13, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t242
  %t243 = getelementptr { i64, [2 x i64] }, ptr %t242, i32 0, i32 0
  store i64 2, ptr %t243
  %t245 = insertvalue { i64 } undef, i64 %t241, 0
  %t246 = getelementptr { i64, [2 x i64] }, ptr %t242, i32 0, i32 1
  store { i64 } %t245, ptr %t246
  %t247 = load { i64, [2 x i64] }, ptr %t242
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t237, i64 %t240, { i64, [2 x i64] } %t247)
  br label %bb61
bb61:
  br label %bb85
bb62:
  %t251 = load { i64, [1 x i64] }, ptr %l14
  %t253 = extractvalue { i64, [1 x i64] } %t251, 0
  %t254 = icmp eq i64 %t253, 1
  br i1 %t254, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  %t256 = load { i64, [1 x i64] }, ptr %l14
  %t258 = extractvalue { i64, [1 x i64] } %t256, 0
  %t259 = icmp eq i64 %t258, 2
  br i1 %t259, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i64, ptr %l13, !tbaa !24
  %t265 = getelementptr %"compiler/scope:Scoper", ptr %t261, i32 0, i32 39
  store i64 %t262, ptr %t265, !tbaa !24
  br label %bb85
bb68:
  %t266 = load { i64, [1 x i64] }, ptr %l14
  %t268 = extractvalue { i64, [1 x i64] } %t266, 0
  %t269 = icmp eq i64 %t268, 3
  br i1 %t269, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb84
bb71:
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = icmp eq ptr %t271, null
  br i1 %t273, label %bb72, label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_486c515bb0c7ed42_3dcfa333a8d1daa6)
  unreachable
bb73:
  br label %bb74
bb74:
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t278 = getelementptr %"compiler/typed:Body", ptr %t275, i32 0, i32 5
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t278)
  store i64 %t280, ptr %l172
  br label %bb75
bb75:
  %t281 = load i64, ptr %l172, !tbaa !24
  %t282 = icmp sgt i64 %t281, 0
  br i1 %t282, label %bb76, label %bb77
bb76:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/scope:Scoper", ptr %t284, i32 0, i32 31
  store ptr %t286, ptr %l175, !tbaa !29
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = icmp eq ptr %t287, null
  br i1 %t289, label %bb78, label %bb79
bb77:
  br label %bb83
bb78:
  call void @__olang_check_failed(ptr @olang_loc_486c515bb0c7ed42_3dcfa333a8d1daa6)
  unreachable
bb79:
  br label %bb80
bb80:
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Body", ptr %t291, i32 0, i32 5
  %t296 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t294, i64 0)
  store i32 %t296, ptr %l181
  br label %bb81
bb81:
  %t297 = load i32, ptr %l181, !tbaa !23
  %t298 = sext i32 %t297 to i64
  %t299 = load i64, ptr %l13, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t300
  %t301 = getelementptr { i64, [2 x i64] }, ptr %t300, i32 0, i32 0
  store i64 2, ptr %t301
  %t303 = insertvalue { i64 } undef, i64 %t299, 0
  %t304 = getelementptr { i64, [2 x i64] }, ptr %t300, i32 0, i32 1
  store { i64 } %t303, ptr %t304
  %t305 = load { i64, [2 x i64] }, ptr %t300
  %t306 = load ptr, ptr %l175, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t306, i64 %t298, { i64, [2 x i64] } %t305)
  br label %bb82
bb82:
  br label %bb83
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_ed4ec6d3513e2b60_3036131f8fea9d34)
  unreachable
bb85:
  br label %bb86
bb86:
  %t309 = load i64, ptr %l12, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l12, !tbaa !24
  br label %bb45
bb87:
  store i64 0, ptr %l17, !tbaa !24
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = icmp eq ptr %t313, null
  br i1 %t315, label %bb88, label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_b48db41ed7b5d734_952948d9de5cb478)
  unreachable
bb89:
  br label %bb90
bb90:
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t320 = getelementptr %"compiler/typed:Body", ptr %t317, i32 0, i32 5
  %t322 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t320)
  store i64 %t322, ptr %l192
  br label %bb91
bb91:
  %t323 = load i64, ptr %l192, !tbaa !24
  store i64 %t323, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t324 = load i64, ptr %l18, !tbaa !24
  %t325 = load i64, ptr %l17, !tbaa !24
  %t328 = icmp sgt i64 %t324, %t325
  br i1 %t328, label %bb92, label %bb93
bb92:
  %t330 = load i64, ptr %l19, !tbaa !24
  %t332 = icmp sgt i64 %t330, 0
  br i1 %t332, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb97
bb94:
  %t334 = load i64, ptr %l18, !tbaa !24
  %t335 = load i64, ptr %l17, !tbaa !24
  %t338 = sub i64 %t334, %t335
  %t339 = load i64, ptr %l19, !tbaa !24
  %t342 = add i64 %t338, %t339
  %t344 = sub i64 %t342, 1
  %t345 = load i64, ptr %l19, !tbaa !24
  %t348 = sdiv i64 %t344, %t345
  store i64 %t348, ptr %l199, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb96
bb96:
  %t350 = load i64, ptr %l199, !tbaa !24
  store i64 %t350, ptr %l196, !tbaa !24
  br label %bb97
bb97:
  %t351 = load i64, ptr %l196, !tbaa !24
  store i64 %t351, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb98
bb98:
  %t352 = load i64, ptr %l21, !tbaa !24
  %t353 = load i64, ptr %l20, !tbaa !24
  %t356 = icmp slt i64 %t352, %t353
  %t358 = xor i1 %t356, true
  br i1 %t358, label %bb99, label %bb100
bb99:
  br label %bb126
bb100:
  br label %bb101
bb101:
  %t360 = load i64, ptr %l17, !tbaa !24
  %t361 = load i64, ptr %l21, !tbaa !24
  %t362 = load i64, ptr %l19, !tbaa !24
  %t365 = mul i64 %t361, %t362
  %t368 = add i64 %t360, %t365
  store i64 %t368, ptr %l22, !tbaa !24
  %t370 = load ptr, ptr %l1, !tbaa !29
  %t372 = icmp eq ptr %t370, null
  br i1 %t372, label %bb102, label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_e7aa8a952f10dcc3_5e7ff2b7646c8097)
  unreachable
bb103:
  br label %bb104
bb104:
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t377 = getelementptr %"compiler/typed:Body", ptr %t374, i32 0, i32 5
  %t378 = load i64, ptr %l22, !tbaa !24
  %t381 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t377, i64 %t378)
  store i32 %t381, ptr %l223
  br label %bb105
bb105:
  %t382 = load i32, ptr %l223, !tbaa !23
  store i32 %t382, ptr %l23, !tbaa !23
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = icmp eq ptr %t383, null
  br i1 %t385, label %bb106, label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_dc4554eebbf8456_460c8fdf10d01e52)
  unreachable
bb107:
  br label %bb108
bb108:
  %t387 = load ptr, ptr %l1, !tbaa !29
  %t390 = getelementptr %"compiler/typed:Body", ptr %t387, i32 0, i32 7
  %t391 = load i32, ptr %l23, !tbaa !23
  %t393 = sext i32 %t391 to i64
  %t396 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t390, i64 %t393)
  store %"compiler/typed:Local" %t396, ptr %l231
  br label %bb109
bb109:
  %t397 = getelementptr %"compiler/typed:Local", ptr %l231, i32 0, i32 5
  %t398 = load { i64, [2 x i64] }, ptr %t397
  store { i64, [2 x i64] } %t398, ptr %l24
  %t400 = load { i64, [2 x i64] }, ptr %l24
  %t402 = extractvalue { i64, [2 x i64] } %t400, 0
  %t403 = icmp eq i64 %t402, 2
  br i1 %t403, label %bb110, label %bb111
bb110:
  %t405 = getelementptr { i64, [2 x i64] }, ptr %l24, i32 0, i32 1
  %t406 = getelementptr { i32 }, ptr %t405, i32 0, i32 0
  %t407 = load i32, ptr %t406
  store i32 %t407, ptr %l25, !tbaa !23
  br label %bb112
bb111:
  br label %bb119
bb112:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/scope:Scoper", ptr %t409, i32 0, i32 31
  %t412 = load i32, ptr %l23, !tbaa !23
  %t414 = sext i32 %t412 to i64
  %t417 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t411, i64 %t414)
  store { i64, [2 x i64] } %t417, ptr %l240
  br label %bb113
bb113:
  %t418 = load { i64, [2 x i64] }, ptr %l240
  %t420 = extractvalue { i64, [2 x i64] } %t418, 0
  %t421 = icmp eq i64 %t420, 0
  br i1 %t421, label %bb114, label %bb115
bb114:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/scope:Scoper", ptr %t423, i32 0, i32 31
  store ptr %t425, ptr %l244, !tbaa !29
  %t426 = load i32, ptr %l23, !tbaa !23
  %t428 = sext i32 %t426 to i64
  store i64 %t428, ptr %l246, !tbaa !24
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/scope:Scoper", ptr %t429, i32 0, i32 31
  %t432 = load i32, ptr %l25, !tbaa !23
  %t434 = sext i32 %t432 to i64
  %t437 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t431, i64 %t434)
  store { i64, [2 x i64] } %t437, ptr %l251
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t438 = load ptr, ptr %l244, !tbaa !29
  %t439 = load i64, ptr %l246, !tbaa !24
  %t440 = load { i64, [2 x i64] }, ptr %l251
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t438, i64 %t439, { i64, [2 x i64] } %t440)
  br label %bb117
bb117:
  br label %bb118
bb118:
  br label %bb124
bb119:
  br i1 true, label %bb120, label %bb121
bb120:
  br label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_check_failed(ptr @olang_loc_ab37e5456fd3bb64_ee38acc32440dcb0)
  unreachable
bb124:
  br label %bb125
bb125:
  %t441 = load i64, ptr %l21, !tbaa !24
  %t443 = add i64 %t441, 1
  store i64 %t443, ptr %l21, !tbaa !24
  br label %bb98
bb126:
  %t445 = load ptr, ptr %l1, !tbaa !29
  %t447 = icmp eq ptr %t445, null
  br i1 %t447, label %bb127, label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_c2f9290c57ed376d_cbd7590e0cb57901)
  unreachable
bb128:
  br label %bb129
bb129:
  %t449 = load ptr, ptr %l1, !tbaa !29
  %t452 = getelementptr %"compiler/typed:Body", ptr %t449, i32 0, i32 11
  %t453 = load ptr, ptr %t452, !tbaa !29
  %t455 = icmp eq ptr %t453, null
  %t457 = xor i1 %t455, true
  br i1 %t457, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s18
  call void @olang_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %t459, ptr %s18)
  call void @llvm.memmove.p0.p0.i64(ptr %l261, ptr %t459, i64 224, i1 false)
  br label %bb132
bb131:
  br label %bb200
bb132:
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %l261, i64 224, i1 false)
  %t460 = load ptr, ptr %l1, !tbaa !29
  %t462 = icmp eq ptr %t460, null
  br i1 %t462, label %bb133, label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_c0d893db7e601486_f2e0d00716145a7a)
  unreachable
bb134:
  br label %bb135
bb135:
  %t464 = load ptr, ptr %l1, !tbaa !29
  %t467 = getelementptr %"compiler/typed:Body", ptr %t464, i32 0, i32 11
  %t468 = load ptr, ptr %t467, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %s18, ptr %t468, ptr %l26)
  br label %bb136
bb136:
  %t471 = load ptr, ptr %l1, !tbaa !29
  %t473 = icmp eq ptr %t471, null
  br i1 %t473, label %bb137, label %bb138
bb137:
  call void @__olang_check_failed(ptr @olang_loc_dcd7e57cabd1f877_41684d2a22884c3b)
  unreachable
bb138:
  br label %bb139
bb139:
  %t475 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr %"compiler/typed:Body", ptr %t475, i32 0, i32 5
  store ptr %t478, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb140
bb140:
  %t480 = load i64, ptr %l28, !tbaa !24
  store i64 %t480, ptr %l273, !tbaa !24
  %t481 = load ptr, ptr %l27, !tbaa !29
  %t483 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t481)
  store i64 %t483, ptr %l275
  br label %bb141
bb141:
  %t484 = load i64, ptr %l273, !tbaa !24
  %t485 = load i64, ptr %l275, !tbaa !24
  %t486 = icmp slt i64 %t484, %t485
  %t488 = xor i1 %t486, true
  br i1 %t488, label %bb142, label %bb143
bb142:
  br label %bb199
bb143:
  br label %bb144
bb144:
  %t490 = load ptr, ptr %l27, !tbaa !29
  %t491 = load i64, ptr %l28, !tbaa !24
  %t494 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t490, i64 %t491)
  store i32 %t494, ptr %l280
  br label %bb145
bb145:
  %t495 = load i32, ptr %l280, !tbaa !23
  store i32 %t495, ptr %l29, !tbaa !23
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/scope:Scoper", ptr %t496, i32 0, i32 0
  %t499 = load ptr, ptr %t498, !tbaa !29
  %t501 = getelementptr %"compiler/generic:Program", ptr %t499, i32 0, i32 2
  store ptr %t501, ptr %l283, !tbaa !29
  %t502 = load ptr, ptr %l1, !tbaa !29
  %t504 = icmp eq ptr %t502, null
  br i1 %t504, label %bb146, label %bb147
bb146:
  call void @__olang_check_failed(ptr @olang_loc_1d5cd0d51560a858_414b0c179bc0efcc)
  unreachable
bb147:
  br label %bb148
bb148:
  %t506 = load ptr, ptr %l1, !tbaa !29
  %t509 = getelementptr %"compiler/typed:Body", ptr %t506, i32 0, i32 7
  %t510 = load i32, ptr %l29, !tbaa !23
  %t512 = sext i32 %t510 to i64
  %t515 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t509, i64 %t512)
  store %"compiler/typed:Local" %t515, ptr %l291
  br label %bb149
bb149:
  %t516 = getelementptr %"compiler/typed:Local", ptr %l291, i32 0, i32 2
  %t517 = load i32, ptr %t516, !tbaa !23
  %t518 = load ptr, ptr %l283, !tbaa !29
  %t520 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t518, i32 %t517)
  store i32 %t520, ptr %l293
  br label %bb150
bb150:
  %t521 = load i32, ptr %l293, !tbaa !23
  store i32 %t521, ptr %l30, !tbaa !23
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load i32, ptr %l30, !tbaa !23
  %t526 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t522, i32 %t523)
  store i1 %t526, ptr %l296
  br label %bb151
bb151:
  %t527 = load i1, ptr %l296, !tbaa !21
  br i1 %t527, label %bb152, label %bb153
bb152:
  store i1 true, ptr %l297, !tbaa !21
  br label %bb155
bb153:
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = getelementptr %"compiler/scope:Scoper", ptr %t528, i32 0, i32 0
  %t531 = load ptr, ptr %t530, !tbaa !29
  %t533 = getelementptr %"compiler/generic:Program", ptr %t531, i32 0, i32 2
  %t534 = load i32, ptr %l30, !tbaa !23
  %t537 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t533, i32 %t534)
  store i32 %t537, ptr %l302
  br label %bb154
bb154:
  %t538 = load i32, ptr %l302, !range !{i32 0, i32 33}
  %t540 = trunc i64 19 to i32
  %t541 = icmp eq i32 %t538, %t540
  %t543 = xor i1 %t541, true
  store i1 %t543, ptr %l297, !tbaa !21
  br label %bb155
bb155:
  %t545 = load i1, ptr %l297, !tbaa !21
  br i1 %t545, label %bb156, label %bb157
bb156:
  store i1 true, ptr %l306, !tbaa !21
  br label %bb159
bb157:
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t548 = getelementptr %"compiler/scope:Scoper", ptr %t546, i32 0, i32 0
  %t549 = load ptr, ptr %t548, !tbaa !29
  %t551 = getelementptr %"compiler/generic:Program", ptr %t549, i32 0, i32 2
  %t552 = load i32, ptr %l30, !tbaa !23
  %t555 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t551, i32 %t552)
  store i32 %t555, ptr %l311
  br label %bb158
bb158:
  %t556 = load i32, ptr %l311, !tbaa !23
  %t557 = icmp ne i32 %t556, 0
  store i1 %t557, ptr %l306, !tbaa !21
  br label %bb159
bb159:
  %t559 = load i1, ptr %l306, !tbaa !21
  br i1 %t559, label %bb160, label %bb161
bb160:
  br label %bb198
bb161:
  br label %bb162
bb162:
  %t560 = getelementptr %"compiler/scope:walked", ptr %l26, i32 0, i32 1
  %t561 = load i32, ptr %l29, !tbaa !23
  %t563 = sext i32 %t561 to i64
  %t566 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s18, ptr %t560, i64 %t563)
  store i1 %t566, ptr %l316
  br label %bb163
bb163:
  %t567 = load i1, ptr %l316, !tbaa !21
  br i1 %t567, label %bb164, label %bb165
bb164:
  store i1 true, ptr %l317, !tbaa !21
  br label %bb167
bb165:
  %t568 = getelementptr %"compiler/scope:walked", ptr %l26, i32 0, i32 4
  %t569 = load i32, ptr %l29, !tbaa !23
  %t571 = sext i32 %t569 to i64
  %t574 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s18, ptr %t568, i64 %t571)
  store i1 %t574, ptr %l321
  br label %bb166
bb166:
  %t575 = load i1, ptr %l321, !tbaa !21
  store i1 %t575, ptr %l317, !tbaa !21
  br label %bb167
bb167:
  %t576 = load i1, ptr %l317, !tbaa !21
  store i1 %t576, ptr %l31, !tbaa !21
  store i64 0, ptr %l32, !tbaa !24
  %t577 = getelementptr %"compiler/scope:walked", ptr %l26, i32 0, i32 2
  %t579 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %t577)
  store i64 %t579, ptr %l323
  br label %bb168
bb168:
  %t580 = load i64, ptr %l323, !tbaa !24
  store i64 %t580, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t581 = load i64, ptr %l33, !tbaa !24
  %t582 = load i64, ptr %l32, !tbaa !24
  %t585 = icmp sgt i64 %t581, %t582
  br i1 %t585, label %bb169, label %bb170
bb169:
  %t587 = load i64, ptr %l34, !tbaa !24
  %t589 = icmp sgt i64 %t587, 0
  br i1 %t589, label %bb171, label %bb172
bb170:
  store i64 0, ptr %l327, !tbaa !24
  br label %bb174
bb171:
  %t591 = load i64, ptr %l33, !tbaa !24
  %t592 = load i64, ptr %l32, !tbaa !24
  %t595 = sub i64 %t591, %t592
  %t596 = load i64, ptr %l34, !tbaa !24
  %t599 = add i64 %t595, %t596
  %t601 = sub i64 %t599, 1
  %t602 = load i64, ptr %l34, !tbaa !24
  %t605 = sdiv i64 %t601, %t602
  store i64 %t605, ptr %l330, !tbaa !24
  br label %bb173
bb172:
  store i64 0, ptr %l330, !tbaa !24
  br label %bb173
bb173:
  %t607 = load i64, ptr %l330, !tbaa !24
  store i64 %t607, ptr %l327, !tbaa !24
  br label %bb174
bb174:
  %t608 = load i64, ptr %l327, !tbaa !24
  store i64 %t608, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb175
bb175:
  %t609 = load i64, ptr %l36, !tbaa !24
  %t610 = load i64, ptr %l35, !tbaa !24
  %t613 = icmp slt i64 %t609, %t610
  %t615 = xor i1 %t613, true
  br i1 %t615, label %bb176, label %bb177
bb176:
  br label %bb193
bb177:
  br label %bb178
bb178:
  %t617 = load i64, ptr %l32, !tbaa !24
  %t618 = load i64, ptr %l36, !tbaa !24
  %t619 = load i64, ptr %l34, !tbaa !24
  %t622 = mul i64 %t618, %t619
  %t625 = add i64 %t617, %t622
  store i64 %t625, ptr %l37, !tbaa !24
  %t627 = getelementptr %"compiler/scope:walked", ptr %l26, i32 0, i32 2
  %t628 = load i64, ptr %l37, !tbaa !24
  %t631 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %t627, i64 %t628)
  store i64 %t631, ptr %l350
  br label %bb179
bb179:
  %t632 = load i32, ptr %l29, !tbaa !23
  %t634 = sext i32 %t632 to i64
  %t635 = load i64, ptr %l350, !tbaa !24
  %t637 = icmp ne i64 %t635, %t634
  br i1 %t637, label %bb180, label %bb181
bb180:
  br label %bb192
bb181:
  br label %bb182
bb182:
  %t639 = getelementptr %"compiler/scope:walked", ptr %l26, i32 0, i32 3
  %t640 = load i64, ptr %l37, !tbaa !24
  %t643 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s18, ptr %t639, i64 %t640)
  store i32 %t643, ptr %l356
  br label %bb183
bb183:
  %t644 = load i32, ptr %l356, !tbaa !23
  store i32 %t644, ptr %l38, !tbaa !23
  %t645 = load i32, ptr %l38, !tbaa !23
  %t647 = icmp eq i32 %t645, 0
  br i1 %t647, label %bb184, label %bb185
bb184:
  store i1 true, ptr %l359, !tbaa !21
  br label %bb188
bb185:
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t651 = getelementptr %"compiler/scope:Scoper", ptr %t649, i32 0, i32 0
  %t652 = load ptr, ptr %t651, !tbaa !29
  %t654 = getelementptr %"compiler/generic:Program", ptr %t652, i32 0, i32 2
  store ptr %t654, ptr %l362, !tbaa !29
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t657 = getelementptr %"compiler/scope:Scoper", ptr %t655, i32 0, i32 0
  %t658 = load ptr, ptr %t657, !tbaa !29
  %t660 = getelementptr %"compiler/generic:Program", ptr %t658, i32 0, i32 2
  %t661 = load i32, ptr %l38, !tbaa !23
  %t664 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t660, i32 %t661)
  store i32 %t664, ptr %l367
  br label %bb186
bb186:
  %t665 = load ptr, ptr %l362, !tbaa !29
  %t666 = load i32, ptr %l367, !tbaa !23
  %t667 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t665, i32 %t666)
  store i64 %t667, ptr %l368
  br label %bb187
bb187:
  %t668 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t669 = load i64, ptr %l368, !tbaa !24
  %t671 = and i64 %t669, %t668
  %t673 = icmp ne i64 %t671, 0
  store i1 %t673, ptr %l359, !tbaa !21
  br label %bb188
bb188:
  %t675 = load i1, ptr %l359, !tbaa !21
  br i1 %t675, label %bb189, label %bb190
bb189:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb191
bb190:
  br label %bb191
bb191:
  br label %bb192
bb192:
  %t676 = load i64, ptr %l36, !tbaa !24
  %t678 = add i64 %t676, 1
  store i64 %t678, ptr %l36, !tbaa !24
  br label %bb175
bb193:
  %t680 = load i1, ptr %l31, !tbaa !21
  br i1 %t680, label %bb194, label %bb195
bb194:
  %t682 = load ptr, ptr %l0, !tbaa !29
  %t684 = getelementptr %"compiler/scope:Scoper", ptr %t682, i32 0, i32 33
  %t685 = load i32, ptr %l29, !tbaa !23
  %t687 = sext i32 %t685 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t684, i64 %t687, i1 true)
  br label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb197
bb197:
  br label %bb198
bb198:
  %t690 = load i64, ptr %l28, !tbaa !24
  %t692 = add i64 %t690, 1
  store i64 %t692, ptr %l28, !tbaa !24
  br label %bb140
bb199:
  call void @__olang_scope_close(ptr %s18)
  br label %bb200
bb200:
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t696 = getelementptr %"compiler/scope:Scoper", ptr %t694, i32 0, i32 34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t696, i32 0)
  br label %bb201
bb201:
  %t698 = load ptr, ptr %l0, !tbaa !29
  store ptr %t698, ptr %l383, !tbaa !29
  %t699 = load ptr, ptr %l1, !tbaa !29
  %t701 = icmp eq ptr %t699, null
  br i1 %t701, label %bb202, label %bb203
bb202:
  call void @__olang_check_failed(ptr @olang_loc_83cb1a0080c88b91_4687383f0631b81d)
  unreachable
bb203:
  br label %bb204
bb204:
  %t703 = load ptr, ptr %l1, !tbaa !29
  %t706 = getelementptr %"compiler/typed:Body", ptr %t703, i32 0, i32 11
  %t707 = load ptr, ptr %t706, !tbaa !29
  store ptr %t707, ptr %l39, !tbaa !29
  %t709 = load ptr, ptr %l39, !tbaa !29
  %t711 = icmp eq ptr %t709, null
  br i1 %t711, label %bb205, label %bb206
bb205:
  call void @__olang_check_failed(ptr @olang_loc_83cb1a0080c88b91_4687383f0631b81d)
  unreachable
bb206:
  br label %bb207
bb207:
  %t713 = load ptr, ptr %l39, !tbaa !29
  %t716 = getelementptr %"compiler/typed:Block", ptr %t713, i32 0, i32 1
  %t717 = load { i64, ptr }, ptr %t716, !tbaa !27
  %t718 = load ptr, ptr %l383, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v0, ptr %t718, { i64, ptr } %t717)
  br label %bb208
bb208:
  %t720 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandHeld(ptr %v0, ptr %t720)
  br label %bb209
bb209:
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t724 = getelementptr %"compiler/scope:Scoper", ptr %t722, i32 0, i32 34
  %t726 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t724)
  %t727 = extractvalue { i32, i32 } %t726, 1
  %t728 = extractvalue { i32, i32 } %t726, 0
  store i32 %t728, ptr %l399
  %t729 = icmp ne i32 %t728, 0
  br i1 %t729, label %bb211, label %ok.730, !prof !99
ok.730:
  store i32 %t727, ptr %l398
  br label %bb210
bb210:
  %t731 = load i32, ptr %l398, !tbaa !23
  store i32 %t731, ptr %l395, !tbaa !23
  br label %bb213
bb211:
  br label %bb212
bb212:
  call void @__olang_ert_req_clear()
  br label %bb213
bb213:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = add i64 %t1, 1
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 36
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/scope:Scoper", ptr %t13, i32 0, i32 36
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = add i64 %t16, 1
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t15, i64 %t18)
  store i64 %t21, ptr %l13
  br label %bb4
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 37
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l16
  br label %bb5
bb4:
  %t27 = load i64, ptr %l13, !tbaa !24
  store i64 %t27, ptr %l8, !tbaa !24
  br label %bb6
bb5:
  %t28 = load i64, ptr %l16, !tbaa !24
  store i64 %t28, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t29 = load i64, ptr %l8, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eshownLocal(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/typed:Local"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i1
  %l30 = alloca %"compiler/typed:Local"
  %l42 = alloca i1
  %l45 = alloca i1
  %l46 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i32
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l60 = alloca ptr
  %l62 = alloca ptr
  %l66 = alloca i1
  %l71 = alloca i1
  %l74 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i1
  %l79 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l87 = alloca i64
  %l90 = alloca i64
  %l96 = alloca i64
  %l102 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca i32
  %l111 = alloca i64
  %l114 = alloca i64
  %l138 = alloca ptr
  %l143 = alloca ptr
  %l146 = alloca i1
  %l151 = alloca i1
  %l154 = alloca i1
  %l155 = alloca i1
  %l158 = alloca i1
  %l161 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l168 = alloca i64
  %l171 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t5, 16
  store i1 %t7, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_e68b15b11e0abafb_13fbbcd2ac59787f)
  unreachable
bb8:
  br label %bb9
bb9:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t18, i32 0, i32 25
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 7
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t24, i64 %t25)
  store %"compiler/typed:Local" %t28, ptr %l30
  br label %bb10
bb10:
  %t29 = load %"compiler/typed:Local", ptr %l30
  store %"compiler/typed:Local" %t29, ptr %l3
  %t30 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t31 = load i32, ptr %t30, !range !{i32 0, i32 7}
  store i32 %t31, ptr %l4
  %t33 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t35 = trunc i64 1 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb11, label %bb12
bb11:
  br label %bb19
bb12:
  %t38 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t40 = trunc i64 0 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  %t43 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t45 = trunc i64 4 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  %t48 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t50 = trunc i64 6 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb59
bb19:
  %t53 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 4
  %t54 = load i32, ptr %t53, !range !{i32 0, i32 7}
  %t56 = trunc i64 1 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t59, i32 %t61)
  store i1 %t64, ptr %l45
  br label %bb22
bb21:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb23
bb22:
  %t65 = load i1, ptr %l45, !tbaa !21
  store i1 %t65, ptr %l42, !tbaa !21
  br label %bb23
bb23:
  %t66 = load i1, ptr %l42, !tbaa !21
  br i1 %t66, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s3
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/scope:Scoper", ptr %t67, i32 0, i32 42
  %t70 = load i64, ptr %l1, !tbaa !24
  %t73 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  %t74 = extractvalue { i32, ptr } %t73, 1
  %t75 = extractvalue { i32, ptr } %t73, 0
  store i32 %t75, ptr %l51
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb27, label %ok.77, !prof !99
ok.77:
  store ptr %t74, ptr %l50
  br label %bb26
bb25:
  br label %bb55
bb26:
  %t78 = load ptr, ptr %l50, !tbaa !29
  store ptr %t78, ptr %l46, !tbaa !29
  br label %bb29
bb27:
  br label %bb28
bb28:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l46, !tbaa !29
  br label %bb29
bb29:
  %t79 = load ptr, ptr %l46, !tbaa !29
  store ptr %t79, ptr %l5, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb30, label %bb31
bb30:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l56, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t92 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v0, ptr %s3, ptr %t87, ptr %t88)
  store ptr %t92, ptr %l60
  br label %bb32
bb31:
  store ptr null, ptr %l55, !tbaa !29
  br label %bb34
bb32:
  %t93 = load ptr, ptr %l60, !tbaa !29
  %t94 = load ptr, ptr %l56, !tbaa !29
  %t96 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %s3, ptr %s3, ptr %t94, ptr %t93)
  store ptr %t96, ptr %l62
  br label %bb33
bb33:
  %t97 = load ptr, ptr %l62, !tbaa !29
  store ptr %t97, ptr %l55, !tbaa !29
  br label %bb34
bb34:
  %t98 = load ptr, ptr %l55, !tbaa !29
  store ptr %t98, ptr %l6, !tbaa !29
  %t99 = load ptr, ptr %l6, !tbaa !29
  %t101 = icmp eq ptr %t99, null
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb35, label %bb36
bb35:
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Call", ptr %t105, i32 0, i32 1
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t112 = icmp sgt i64 %t110, 0
  store i1 %t112, ptr %l66, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb37
bb37:
  %t114 = load i1, ptr %l66, !tbaa !21
  br i1 %t114, label %bb38, label %bb39
bb38:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l6, !tbaa !29
  %t119 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %s3, ptr %t115, ptr %t116)
  store i1 %t119, ptr %l74
  br label %bb40
bb39:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb45
bb40:
  %t120 = load i1, ptr %l74, !tbaa !21
  br i1 %t120, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb44
bb42:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l6, !tbaa !29
  %t125 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %s3, ptr %t121, ptr %t122)
  store i1 %t125, ptr %l78
  br label %bb43
bb43:
  %t126 = load i1, ptr %l78, !tbaa !21
  store i1 %t126, ptr %l75, !tbaa !21
  br label %bb44
bb44:
  %t127 = load i1, ptr %l75, !tbaa !21
  store i1 %t127, ptr %l71, !tbaa !21
  br label %bb45
bb45:
  %t128 = load i1, ptr %l71, !tbaa !21
  br i1 %t128, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s4
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l79, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l6, !tbaa !29
  %t133 = getelementptr %"compiler/typed:Call", ptr %t131, i32 0, i32 1
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l82, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr ptr, ptr %t136, i64 0
  %t138 = load ptr, ptr %t137, !tbaa !39
  %t142 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %s3, ptr %s4, ptr %t130, ptr %t138)
  store ptr %t142, ptr %l85
  br label %bb48
bb47:
  br label %bb54
bb48:
  %t143 = load ptr, ptr %l85, !tbaa !29
  %t145 = call i64 @compiler_2fscope_2eflRootExpr(ptr %s4, ptr %t143)
  store i64 %t145, ptr %l87
  br label %bb49
bb49:
  %t146 = load i64, ptr %l2, !tbaa !24
  %t148 = add i64 %t146, 1
  %t149 = load ptr, ptr %l79, !tbaa !29
  %t150 = load i64, ptr %l87, !tbaa !24
  %t152 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eshownLocal(ptr %v0, ptr %t149, i64 %t150, i64 %t148)
  store i64 %t152, ptr %l90
  br label %bb50
bb50:
  %t153 = load i64, ptr %l90, !tbaa !24
  store i64 %t153, ptr %l7, !tbaa !24
  %t154 = load i64, ptr %l7, !tbaa !24
  %t156 = icmp sge i64 %t154, 0
  br i1 %t156, label %bb51, label %bb52
bb51:
  %t158 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i64 %t158, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb55:
  %t160 = getelementptr %"compiler/typed:Local", ptr %l3, i32 0, i32 0
  %t161 = load i32, ptr %t160, !tbaa !23
  %t163 = icmp ne i32 %t161, 0
  br i1 %t163, label %bb56, label %bb57
bb56:
  %t165 = load i64, ptr %l1, !tbaa !24
  store i64 %t165, ptr %l96, !tbaa !24
  br label %bb58
bb57:
  store i64 -1, ptr %l96, !tbaa !24
  br label %bb58
bb58:
  %t167 = load i64, ptr %l96, !tbaa !24
  store i64 %t167, ptr %rv
  br label %ret
bb59:
  %t168 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t170 = trunc i64 3 to i32
  %t171 = icmp eq i32 %t168, %t170
  br i1 %t171, label %bb60, label %bb61
bb60:
  br label %bb64
bb61:
  %t173 = load i32, ptr %l4, !range !{i32 0, i32 7}
  %t175 = trunc i64 2 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb102
bb64:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/scope:Scoper", ptr %t178, i32 0, i32 42
  %t181 = load i64, ptr %l1, !tbaa !24
  %t184 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t180, i64 %t181)
  %t185 = extractvalue { i32, ptr } %t184, 1
  %t186 = extractvalue { i32, ptr } %t184, 0
  store i32 %t186, ptr %l107
  %t187 = icmp ne i32 %t186, 0
  br i1 %t187, label %bb66, label %ok.188, !prof !99
ok.188:
  store ptr %t185, ptr %l106
  br label %bb65
bb65:
  %t189 = load ptr, ptr %l106, !tbaa !29
  store ptr %t189, ptr %l102, !tbaa !29
  br label %bb68
bb66:
  br label %bb67
bb67:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l102, !tbaa !29
  br label %bb68
bb68:
  %t190 = load ptr, ptr %l102, !tbaa !29
  store ptr %t190, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  store i64 16, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t191 = load i64, ptr %l10, !tbaa !24
  %t192 = load i64, ptr %l9, !tbaa !24
  %t195 = icmp sgt i64 %t191, %t192
  br i1 %t195, label %bb69, label %bb70
bb69:
  %t197 = load i64, ptr %l11, !tbaa !24
  %t199 = icmp sgt i64 %t197, 0
  br i1 %t199, label %bb71, label %bb72
bb70:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb74
bb71:
  %t201 = load i64, ptr %l10, !tbaa !24
  %t202 = load i64, ptr %l9, !tbaa !24
  %t205 = sub i64 %t201, %t202
  %t206 = load i64, ptr %l11, !tbaa !24
  %t209 = add i64 %t205, %t206
  %t211 = sub i64 %t209, 1
  %t212 = load i64, ptr %l11, !tbaa !24
  %t215 = sdiv i64 %t211, %t212
  store i64 %t215, ptr %l114, !tbaa !24
  br label %bb73
bb72:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb73
bb73:
  %t217 = load i64, ptr %l114, !tbaa !24
  store i64 %t217, ptr %l111, !tbaa !24
  br label %bb74
bb74:
  %t218 = load i64, ptr %l111, !tbaa !24
  store i64 %t218, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb75
bb75:
  %t219 = load i64, ptr %l13, !tbaa !24
  %t220 = load i64, ptr %l12, !tbaa !24
  %t223 = icmp slt i64 %t219, %t220
  %t225 = xor i1 %t223, true
  br i1 %t225, label %bb76, label %bb77
bb76:
  br label %bb99
bb77:
  br label %bb78
bb78:
  %t227 = load i64, ptr %l9, !tbaa !24
  %t228 = load i64, ptr %l13, !tbaa !24
  %t229 = load i64, ptr %l11, !tbaa !24
  %t232 = mul i64 %t228, %t229
  %t235 = add i64 %t227, %t232
  store i64 %t235, ptr %l14, !tbaa !24
  %t237 = load ptr, ptr %l8, !tbaa !29
  %t239 = icmp eq ptr %t237, null
  br i1 %t239, label %bb79, label %bb80
bb79:
  store i64 -1, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l8, !tbaa !29
  %t247 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v0, ptr %v0, ptr %t242, ptr %t243)
  store ptr %t247, ptr %l138
  br label %bb82
bb82:
  %t248 = load ptr, ptr %l138, !tbaa !29
  store ptr %t248, ptr %l8, !tbaa !29
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l8, !tbaa !29
  %t255 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v0, ptr %v0, ptr %t250, ptr %t251)
  store ptr %t255, ptr %l143
  br label %bb83
bb83:
  %t256 = load ptr, ptr %l143, !tbaa !29
  store ptr %t256, ptr %l15, !tbaa !29
  %t257 = load ptr, ptr %l15, !tbaa !29
  %t259 = icmp eq ptr %t257, null
  br i1 %t259, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l146, !tbaa !21
  br label %bb86
bb85:
  %t261 = load ptr, ptr %l15, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Call", ptr %t261, i32 0, i32 1
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t268 = icmp eq i64 %t266, 0
  store i1 %t268, ptr %l146, !tbaa !21
  br label %bb86
bb86:
  %t270 = load i1, ptr %l146, !tbaa !21
  br i1 %t270, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l151, !tbaa !21
  br label %bb94
bb88:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load ptr, ptr %l15, !tbaa !29
  %t275 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %v0, ptr %t271, ptr %t272)
  store i1 %t275, ptr %l154
  br label %bb89
bb89:
  %t276 = load i1, ptr %l154, !tbaa !21
  br i1 %t276, label %bb90, label %bb91
bb90:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb93
bb91:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %l15, !tbaa !29
  %t281 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eindexCall(ptr %v0, ptr %v0, ptr %t277, ptr %t278)
  store i1 %t281, ptr %l158
  br label %bb92
bb92:
  %t282 = load i1, ptr %l158, !tbaa !21
  store i1 %t282, ptr %l155, !tbaa !21
  br label %bb93
bb93:
  %t283 = load i1, ptr %l155, !tbaa !21
  %t284 = xor i1 %t283, true
  store i1 %t284, ptr %l151, !tbaa !21
  br label %bb94
bb94:
  %t286 = load i1, ptr %l151, !tbaa !21
  br i1 %t286, label %bb95, label %bb96
bb95:
  br label %bb99
bb96:
  br label %bb97
bb97:
  %t287 = load ptr, ptr %l15, !tbaa !29
  %t289 = getelementptr %"compiler/typed:Call", ptr %t287, i32 0, i32 1
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  store { i64, ptr } %t290, ptr %l161, !tbaa !27
  %t291 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !27
  %t293 = getelementptr ptr, ptr %t292, i64 0
  %t294 = load ptr, ptr %t293, !tbaa !39
  store ptr %t294, ptr %l8, !tbaa !29
  br label %bb98
bb98:
  %t297 = load i64, ptr %l13, !tbaa !24
  %t299 = add i64 %t297, 1
  store i64 %t299, ptr %l13, !tbaa !24
  br label %bb75
bb99:
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l166, !tbaa !29
  %t302 = load ptr, ptr %l8, !tbaa !29
  %t304 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %t302)
  store i64 %t304, ptr %l168
  br label %bb100
bb100:
  %t305 = load i64, ptr %l2, !tbaa !24
  %t307 = add i64 %t305, 1
  %t308 = load ptr, ptr %l166, !tbaa !29
  %t309 = load i64, ptr %l168, !tbaa !24
  %t311 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eshownLocal(ptr %v0, ptr %t308, i64 %t309, i64 %t307)
  store i64 %t311, ptr %l171
  br label %bb101
bb101:
  %t312 = load i64, ptr %l171, !tbaa !24
  store i64 %t312, ptr %rv
  br label %ret
bb102:
  br i1 true, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  store i64 -1, ptr %rv
  br label %ret
bb106:
  call void @__olang_check_failed(ptr @olang_loc_5026d552222f1723_4b71b7547c4744a7)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esiteLift(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l4 = alloca ptr
  %l8 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t20 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 126
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 26
  %t7 = load i64, ptr %t6, !tbaa !24
  %t11 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t7, i64 %a1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l8
  %t14 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H568ce559fa980123a387c6ba9ed21aca(ptr %v0, ptr %t12, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t13)
  %t15 = extractvalue { i32, { i64, [2 x i64] } } %t14, 1
  %t16 = extractvalue { i32, { i64, [2 x i64] } } %t14, 0
  store i32 %t16, ptr %l10
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb3, label %ok.18, !prof !99
ok.18:
  store { i64, [2 x i64] } %t15, ptr %l9
  br label %bb2
bb2:
  %t19 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t19, ptr %l2
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store { i64, [2 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 0
  store i64 0, ptr %t21
  %t22 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t22, ptr %l2
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t24, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l17 = alloca i1
  %l19 = alloca i1
  %l23 = alloca { i64, [2 x i64] }
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, [2 x i64] }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t31 = alloca { i64, [2 x i64] }, align 8
  %t104 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t17)
  store i32 %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i1, ptr %l15, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t26)
  store i1 %t28, ptr %l19
  br label %bb10
bb10:
  %t29 = load i1, ptr %l19, !tbaa !21
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  store { i64, [2 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t33 = load { i64, [2 x i64] }, ptr %t31
  store { i64, [2 x i64] } %t33, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t39 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t35, ptr %t36, i1 true)
  store { i64, [2 x i64] } %t39, ptr %l23
  br label %bb15
bb15:
  %t40 = load { i64, [2 x i64] }, ptr %l23
  store { i64, [2 x i64] } %t40, ptr %rv
  br label %ret
bb16:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb17, label %bb18
bb17:
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 18}
  %t48 = icmp eq i64 %t46, 9
  store i1 %t48, ptr %l25, !tbaa !21
  br label %bb18
bb18:
  %t49 = load i1, ptr %l25, !tbaa !21
  br i1 %t49, label %bb19, label %bb20
bb19:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [5 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t52, i32 0, i32 2
  %t54 = load i32, ptr %t53, !range !{i32 0, i32 43}
  store i32 %t54, ptr %l3
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t58, i32 0, i32 4
  %t60 = load { i64, ptr }, ptr %t59
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  br label %bb21
bb20:
  br label %bb30
bb21:
  %t62 = load i32, ptr %l3, !range !{i32 0, i32 43}
  %t64 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t62)
  store i1 %t64, ptr %l33
  br label %bb22
bb22:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t70 = icmp sgt i64 %t68, 0
  store i1 %t70, ptr %l34, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb25
bb25:
  %t72 = load i1, ptr %l34, !tbaa !21
  br i1 %t72, label %bb26, label %bb27
bb26:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t74, ptr %l39, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 0
  %t78 = load ptr, ptr %t77, !tbaa !39
  %t81 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %t73, ptr %t78)
  store { i64, [2 x i64] } %t81, ptr %l41
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t82 = load { i64, [2 x i64] }, ptr %l41
  store { i64, [2 x i64] } %t82, ptr %rv
  br label %ret
bb29:
  br label %bb42
bb30:
  %t83 = load ptr, ptr %l1, !tbaa !29
  store ptr %t83, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t84 = load ptr, ptr %l42, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb31, label %bb32
bb31:
  %t87 = load ptr, ptr %l42, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 18}
  %t90 = icmp eq i64 %t88, 17
  store i1 %t90, ptr %l43, !tbaa !21
  br label %bb32
bb32:
  %t91 = load i1, ptr %l43, !tbaa !21
  br i1 %t91, label %bb33, label %bb34
bb33:
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t94, i32 0, i32 2
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l5, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t102 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %t98, ptr %t99)
  store { i64, [2 x i64] } %t102, ptr %l50
  br label %bb36
bb36:
  %t103 = load { i64, [2 x i64] }, ptr %l50
  store { i64, [2 x i64] } %t103, ptr %rv
  br label %ret
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_9da86a51b48ec4c_4c8b634b3e5eba18)
  unreachable
bb42:
  store { i64, [2 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [2 x i64] }, ptr %t104, i32 0, i32 0
  store i64 0, ptr %t105
  %t106 = load { i64, [2 x i64] }, ptr %t104
  store { i64, [2 x i64] } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l22 = alloca i32
  %l26 = alloca i1
  %l31 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i1
  %l57 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb45
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l22
  br label %bb6
bb6:
  %t32 = load i32, ptr %l22, !range !{i32 0, i32 33}
  %t34 = trunc i64 20 to i32
  %t35 = icmp eq i32 %t32, %t34
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb10
bb8:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/scope:Scoper", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l2, !tbaa !23
  %t48 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t44, i32 %t45)
  store i64 %t48, ptr %l31
  br label %bb9
bb9:
  %t49 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t50 = load i64, ptr %l31, !tbaa !24
  %t52 = and i64 %t50, %t49
  %t54 = icmp ne i64 %t52, 0
  store i1 %t54, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t56 = load i1, ptr %l26, !tbaa !21
  br i1 %t56, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Promote", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l4, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  store ptr %t63, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t64 = load ptr, ptr %l38, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t67 = load ptr, ptr %l38, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 7
  store i1 %t70, ptr %l39, !tbaa !21
  br label %bb15
bb15:
  %t71 = load i1, ptr %l39, !tbaa !21
  br i1 %t71, label %bb16, label %bb17
bb16:
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l5, !tbaa !29
  br label %bb18
bb17:
  br label %bb39
bb18:
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Make", ptr %t78, i32 0, i32 0
  %t81 = load i32, ptr %t80, !range !{i32 0, i32 5}
  %t83 = trunc i64 2 to i32
  %t84 = icmp eq i32 %t81, %t83
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Make", ptr %t89, i32 0, i32 2
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  store i64 %t96, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb23, label %bb24
bb23:
  br label %bb38
bb24:
  br label %bb25
bb25:
  %t106 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t106, ptr %l57, !tbaa !27
  %t107 = load i64, ptr %l7, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 %t107
  %t112 = load ptr, ptr %t111, !tbaa !39
  store ptr %t112, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t115 = load ptr, ptr %l60, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb26, label %bb27
bb26:
  %t118 = load ptr, ptr %l60, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 18}
  %t121 = icmp eq i64 %t119, 1
  store i1 %t121, ptr %l61, !tbaa !21
  br label %bb27
bb27:
  %t122 = load i1, ptr %l61, !tbaa !21
  br i1 %t122, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_ecfbbef7cda902e1_3bafa02f8f932e5d)
  unreachable
bb36:
  br label %bb37
bb37:
  %t124 = load i64, ptr %l7, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l7, !tbaa !24
  br label %bb22
bb38:
  store i1 true, ptr %rv
  br label %ret
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_37637c4d9c3e6d50_2ee770f7e7b7abac)
  unreachable
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_3254ddf6344cc8b_4503cdf23e4eb927)
  unreachable
bb50:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estrReceiver(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/scope:rel"
  %l4 = alloca i1
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l24 = alloca %"compiler/scope:rel"
  %l29 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, [2 x i64] }
  %l42 = alloca { i64, [2 x i64] }
  %l44 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/msgs:Msg"
  %l64 = alloca i64
  %l69 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l97 = alloca i1
  %l99 = alloca i1
  %l103 = alloca i1
  %l105 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca %"compiler/msgs:Msg"
  %l111 = alloca i64
  %l115 = alloca i64
  %l124 = alloca i1
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca i32
  %l133 = alloca %"compiler/source:Span"
  %l136 = alloca ptr
  %l137 = alloca i64
  %l141 = alloca i64
  %l145 = alloca %"compiler/source:Span"
  %l146 = alloca %"compiler/msgs:Msg"
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 35
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l17, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l19
  br label %bb2
bb2:
  %t9 = load i64, ptr %l17, !tbaa !24
  %t10 = load i64, ptr %l19, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb39
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/scope:rel" %t19, ptr %l24
  br label %bb6
bb6:
  %t20 = load %"compiler/scope:rel", ptr %l24
  store %"compiler/scope:rel" %t20, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  %t21 = getelementptr %"compiler/scope:rel", ptr %l3, i32 0, i32 1
  %t22 = load { i64, [2 x i64] }, ptr %t21
  store { i64, [2 x i64] } %t22, ptr %l5
  %t24 = load { i64, [2 x i64] }, ptr %l5
  %t26 = extractvalue { i64, [2 x i64] } %t24, 0
  %t27 = icmp eq i64 %t26, 2
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t30 = getelementptr { i64 }, ptr %t29, i32 0, i32 0
  %t31 = load i64, ptr %t30
  store i64 %t31, ptr %l6, !tbaa !24
  br label %bb9
bb8:
  br label %bb19
bb9:
  %t33 = load i64, ptr %l6, !tbaa !24
  store i64 %t33, ptr %l29, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/scope:Scoper", ptr %t34, i32 0, i32 64
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t36)
  store i64 %t38, ptr %l32
  br label %bb10
bb10:
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = load i64, ptr %l32, !tbaa !24
  %t41 = icmp slt i64 %t39, %t40
  br i1 %t41, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t43, i32 0, i32 64
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t45, i64 %t46)
  store i1 %t49, ptr %l38
  br label %bb13
bb12:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb14
bb13:
  %t50 = load i1, ptr %l38, !tbaa !21
  store i1 %t50, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = getelementptr %"compiler/scope:rel", ptr %l3, i32 0, i32 0
  %t53 = load { i64, [2 x i64] }, ptr %t52
  store { i64, [2 x i64] } %t53, ptr %l40
  %t54 = getelementptr %"compiler/scope:rel", ptr %l3, i32 0, i32 1
  %t55 = load { i64, [2 x i64] }, ptr %t54
  store { i64, [2 x i64] } %t55, ptr %l42
  %t58 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l40, ptr %l42)
  store i1 %t58, ptr %l44
  br label %bb17
bb16:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb18
bb17:
  %t59 = load i1, ptr %l44, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l39, !tbaa !21
  br label %bb18
bb18:
  %t62 = load i1, ptr %l39, !tbaa !21
  store i1 %t62, ptr %l4, !tbaa !21
  br label %bb28
bb19:
  %t63 = load { i64, [2 x i64] }, ptr %l5
  %t65 = extractvalue { i64, [2 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 4
  br i1 %t66, label %bb20, label %bb21
bb20:
  %t68 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t69 = getelementptr { i64, i64 }, ptr %t68, i32 0, i32 0
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l7, !tbaa !24
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sge i64 %t72, 0
  store i1 %t74, ptr %l4, !tbaa !21
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_678543b1c51fd044_bcff5a6e112a6af8)
  unreachable
bb28:
  %t76 = load i1, ptr %l4, !tbaa !21
  br i1 %t76, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l52, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l53, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/scope:Scoper", ptr %t80, i32 0, i32 25
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  br i1 %t85, label %bb31, label %bb32
bb30:
  br label %bb37
bb31:
  call void @__olang_check_failed(ptr @olang_loc_90a9d28716f9cb6_29834bc9108cc36a)
  unreachable
bb32:
  br label %bb33
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/scope:Scoper", ptr %t87, i32 0, i32 25
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Body", ptr %t90, i32 0, i32 3
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = getelementptr %"compiler/scope:rel", ptr %l3, i32 0, i32 3
  %t96 = load %"compiler/source:Span", ptr %t95
  %t97 = load ptr, ptr %l53, !tbaa !29
  %t100 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t97, i64 %t94, %"compiler/source:Span" %t96)
  store %"compiler/source:Span" %t100, ptr %l62
  br label %bb34
bb34:
  %t101 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %s6)
  store %"compiler/msgs:Msg" %t101, ptr %l63
  br label %bb35
bb35:
  %t102 = load ptr, ptr %l52, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l62
  %t104 = load %"compiler/msgs:Msg", ptr %l63
  %t105 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s6, ptr %t102, %"compiler/source:Span" %t103, %"compiler/msgs:Msg" %t104)
  store i64 %t105, ptr %l64
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb37:
  br label %bb38
bb38:
  %t106 = load i64, ptr %l2, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l2, !tbaa !24
  br label %bb1
bb39:
  store i64 0, ptr %l8, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 64
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l69
  br label %bb40
bb40:
  %t115 = load i64, ptr %l69, !tbaa !24
  store i64 %t115, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t116 = load i64, ptr %l9, !tbaa !24
  %t117 = load i64, ptr %l8, !tbaa !24
  %t120 = icmp sgt i64 %t116, %t117
  br i1 %t120, label %bb41, label %bb42
bb41:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t124 = icmp sgt i64 %t122, 0
  br i1 %t124, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb46
bb43:
  %t126 = load i64, ptr %l9, !tbaa !24
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = sub i64 %t126, %t127
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = add i64 %t130, %t131
  %t136 = sub i64 %t134, 1
  %t137 = load i64, ptr %l10, !tbaa !24
  %t140 = sdiv i64 %t136, %t137
  store i64 %t140, ptr %l76, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb45
bb45:
  %t142 = load i64, ptr %l76, !tbaa !24
  store i64 %t142, ptr %l73, !tbaa !24
  br label %bb46
bb46:
  %t143 = load i64, ptr %l73, !tbaa !24
  store i64 %t143, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s9
  %t144 = load i64, ptr %l12, !tbaa !24
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s9)
  br label %bb79
bb49:
  br label %bb50
bb50:
  %t152 = load i64, ptr %l8, !tbaa !24
  %t153 = load i64, ptr %l12, !tbaa !24
  %t154 = load i64, ptr %l10, !tbaa !24
  %t157 = mul i64 %t153, %t154
  %t160 = add i64 %t152, %t157
  store i64 %t160, ptr %l13, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/scope:Scoper", ptr %t162, i32 0, i32 64
  %t165 = load i64, ptr %l13, !tbaa !24
  %t168 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t164, i64 %t165)
  store i1 %t168, ptr %l97
  br label %bb51
bb51:
  %t169 = load i1, ptr %l97, !tbaa !21
  %t170 = xor i1 %t169, true
  br i1 %t170, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb55
bb53:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/scope:Scoper", ptr %t172, i32 0, i32 58
  %t175 = load i64, ptr %l13, !tbaa !24
  %t178 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t174, i64 %t175)
  store i1 %t178, ptr %l103
  br label %bb54
bb54:
  %t179 = load i1, ptr %l103, !tbaa !21
  %t180 = xor i1 %t179, true
  store i1 %t180, ptr %l99, !tbaa !21
  br label %bb55
bb55:
  %t182 = load i1, ptr %l99, !tbaa !21
  br i1 %t182, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb78
bb57:
  br label %bb58
bb58:
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l105, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/scope:Scoper", ptr %t184, i32 0, i32 61
  %t187 = load i64, ptr %l13, !tbaa !24
  %t190 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t186, i64 %t187)
  store %"compiler/source:Span" %t190, ptr %l109
  br label %bb59
bb59:
  %t191 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %s9)
  store %"compiler/msgs:Msg" %t191, ptr %l110
  br label %bb60
bb60:
  %t192 = load ptr, ptr %l105, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l109
  %t194 = load %"compiler/msgs:Msg", ptr %l110
  %t195 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s9, ptr %t192, %"compiler/source:Span" %t193, %"compiler/msgs:Msg" %t194)
  store i64 %t195, ptr %l111
  br label %bb61
bb61:
  %t196 = load i64, ptr %l111, !tbaa !24
  store i64 %t196, ptr %l14, !tbaa !24
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/scope:Scoper", ptr %t197, i32 0, i32 62
  %t200 = load i64, ptr %l13, !tbaa !24
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t199, i64 %t200)
  store i64 %t203, ptr %l115
  br label %bb62
bb62:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/scope:Scoper", ptr %t204, i32 0, i32 25
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = icmp eq ptr %t207, null
  br i1 %t209, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_a7a579971a154b67_66936e5e8b24a2eb)
  unreachable
bb64:
  br label %bb65
bb65:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/scope:Scoper", ptr %t211, i32 0, i32 25
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Body", ptr %t214, i32 0, i32 3
  %t218 = load i64, ptr %t217, !tbaa !24
  %t219 = load i64, ptr %l115, !tbaa !24
  %t221 = icmp ne i64 %t219, %t218
  br i1 %t221, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb70
bb67:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/scope:Scoper", ptr %t223, i32 0, i32 63
  %t226 = load i64, ptr %l13, !tbaa !24
  %t229 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t225, i64 %t226)
  store %"compiler/source:Span" %t229, ptr %l128
  br label %bb68
bb68:
  %t230 = getelementptr %"compiler/source:Span", ptr %l128, i32 0, i32 0
  %t231 = load i32, ptr %t230, !tbaa !23
  store i32 %t231, ptr %l129, !tbaa !23
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/scope:Scoper", ptr %t232, i32 0, i32 61
  %t235 = load i64, ptr %l13, !tbaa !24
  %t238 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t234, i64 %t235)
  store %"compiler/source:Span" %t238, ptr %l133
  br label %bb69
bb69:
  %t239 = getelementptr %"compiler/source:Span", ptr %l133, i32 0, i32 0
  %t240 = load i32, ptr %t239, !tbaa !23
  %t241 = load i32, ptr %l129, !tbaa !23
  %t243 = icmp ne i32 %t241, %t240
  store i1 %t243, ptr %l124, !tbaa !21
  br label %bb70
bb70:
  %t245 = load i1, ptr %l124, !tbaa !21
  br i1 %t245, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s11
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l136, !tbaa !29
  %t247 = load i64, ptr %l14, !tbaa !24
  store i64 %t247, ptr %l137, !tbaa !24
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/scope:Scoper", ptr %t248, i32 0, i32 62
  %t251 = load i64, ptr %l13, !tbaa !24
  %t254 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t250, i64 %t251)
  store i64 %t254, ptr %l141
  br label %bb73
bb72:
  br label %bb77
bb73:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/scope:Scoper", ptr %t255, i32 0, i32 63
  %t258 = load i64, ptr %l13, !tbaa !24
  %t261 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t257, i64 %t258)
  store %"compiler/source:Span" %t261, ptr %l145
  br label %bb74
bb74:
  %t262 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrBuildsHere(ptr %s11)
  store %"compiler/msgs:Msg" %t262, ptr %l146
  br label %bb75
bb75:
  %t263 = load ptr, ptr %l136, !tbaa !29
  %t264 = load i64, ptr %l137, !tbaa !24
  %t265 = load i64, ptr %l141, !tbaa !24
  %t266 = load %"compiler/source:Span", ptr %l145
  %t267 = load %"compiler/msgs:Msg", ptr %l146
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s11, ptr %t263, i64 %t264, i64 %t265, %"compiler/source:Span" %t266, %"compiler/msgs:Msg" %t267)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s11)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s9)
  br label %ret
bb78:
  %t268 = load i64, ptr %l12, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l12, !tbaa !24
  br label %bb47
bb79:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etermName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca { i64, [1 x i64] }
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca i32
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, [2 x i64] }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load { i64, [2 x i64] }, ptr %l2
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 2
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t15 = getelementptr { i64 }, ptr %t14, i32 0, i32 0
  %t16 = load i64, ptr %t15
  store i64 %t16, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l15, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 6
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t22, i64 %t23)
  store { i64, [1 x i64] } %t26, ptr %l20
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = load { i64, [1 x i64] }, ptr %l20
  %t32 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evarName(ptr %v0, ptr %v0, ptr %v1, ptr %v2, ptr %t28, ptr %t29, { i64, [1 x i64] } %t30, ptr %t27)
  store { i64, ptr } %t32, ptr %l22
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t33, ptr %l11, !tbaa !27
  br label %bb23
bb7:
  %t34 = load { i64, [2 x i64] }, ptr %l2
  %t36 = extractvalue { i64, [2 x i64] } %t34, 0
  %t37 = icmp eq i64 %t36, 3
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t39, ptr %l11, !tbaa !27
  br label %bb23
bb11:
  %t41 = load { i64, [2 x i64] }, ptr %l2
  %t43 = extractvalue { i64, [2 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 4
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t47 = getelementptr { i64, i64 }, ptr %t46, i32 0, i32 0
  %t48 = load i64, ptr %t47
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb14
bb13:
  br label %bb17
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  %t51 = load ptr, ptr %l4, !tbaa !29
  store ptr %t51, ptr %l31, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 5
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t54, i64 %t55)
  store i32 %t58, ptr %l35
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t60 = load ptr, ptr %l30, !tbaa !29
  %t61 = load ptr, ptr %l31, !tbaa !29
  %t62 = load i32, ptr %l35, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elocalName(ptr %v0, ptr %v0, ptr %v1, ptr %s3, ptr %t60, ptr %t61, i32 %t62, ptr %t59)
  store { i64, ptr } %t64, ptr %l37
  br label %bb16
bb16:
  %t65 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t67 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = add i64 %t66, %t69
  %t71 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t65, i64 %t66)
  %t75 = getelementptr i8, ptr %t74, i64 %t66
  call void @olang_textcopy(ptr %t75, ptr %t68, i64 %t69)
  %t76 = getelementptr i8, ptr %t75, i64 %t69
  call void @olang_textcopy(ptr %t76, ptr %t71, i64 %t72)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t74, 1
  store { i64, ptr } %t78, ptr %l11, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t80 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t80, ptr %l39
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  call void @olang_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %s6, ptr %l39, i64 0)
  br label %bb21
bb21:
  %t82 = load ptr, ptr %s6
  %t83 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t84 = load i64, ptr %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t84)
  call void @olang_textcopy(ptr %t85, ptr %t82, i64 %t84)
  %t86 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  store { i64, ptr } %t87, ptr %l41, !tbaa !27
  %t88 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t89 = load ptr, ptr %t88
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %sbgrew.91, label %sbdone.92
sbgrew.91:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.92
sbdone.92:
  %t93 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t93, ptr %l11, !tbaa !27
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_a29c887f84e1b245_5040fb81d2028cb9)
  unreachable
bb23:
  %t94 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l42, !tbaa !24
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l43, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l42, !tbaa !24
  %t106 = mul i64 %t105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t107, ptr %l11, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerivedExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l7, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 2
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb10
bb5:
  %t23 = load ptr, ptr %l2, !tbaa !29
  store ptr %t23, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 3
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t42 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerived(ptr %v0, ptr %s0, ptr %t38, ptr %t39)
  store i1 %t42, ptr %l23
  br label %bb11
bb11:
  %t43 = load i1, ptr %l23, !tbaa !21
  store i1 %t43, ptr %l8, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_c51808c26f3c8029_f1c25a88624d8cdd)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load i1, ptr %l8, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evarName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2, ptr %a3) #0 {
entry:
  %l2 = alloca { i64, [1 x i64] }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, [1 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l4, !tbaa !23
  br label %bb5
bb2:
  %t10 = load { i64, [1 x i64] }, ptr %l2
  %t12 = extractvalue { i64, [1 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 4
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [1 x i64] }, ptr %l2, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  store i32 %t17, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load i32, ptr %l4, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elocalName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %t21, ptr %a3)
  store { i64, ptr } %t27, ptr %l16
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  br label %bb20
bb7:
  %t29 = load { i64, [1 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [1 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 1
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t34, ptr %l5, !tbaa !27
  br label %bb20
bb11:
  %t36 = load { i64, [1 x i64] }, ptr %l2
  %t38 = extractvalue { i64, [1 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 2
  br i1 %t39, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  br label %bb20
bb15:
  %t43 = load { i64, [1 x i64] }, ptr %l2
  %t45 = extractvalue { i64, [1 x i64] } %t43, 0
  %t46 = icmp eq i64 %t45, 3
  br i1 %t46, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t48, ptr %l5, !tbaa !27
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_33e8f6984fda8b38_987c5f6a5f702884)
  unreachable
bb20:
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l29, !tbaa !24
  %t52 = load i64, ptr %l29, !tbaa !24
  %t53 = mul i64 %t52, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t53)
  %t55 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l30, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l29, !tbaa !24
  %t62 = mul i64 %t61, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %t60, i64 %t62, i1 false)
  %t63 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t63, ptr %l5, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewantPromotionOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca i1
  %l10 = alloca i1
  %l16 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 137
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 140
  %t11 = load i1, ptr %t10, !tbaa !21
  %t13 = xor i1 %t11, true
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t20 = icmp eq i32 %t16, %t17
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l10, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %t23, i32 %t24)
  store i64 %t27, ptr %l16
  br label %bb10
bb10:
  %t28 = load i64, ptr %l16, !tbaa !24
  store i64 %t28, ptr %l2, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp sge i64 %t29, 0
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 141
  %t36 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t35, i64 %t36, i1 true)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l49 = alloca i64
  %l50 = alloca ptr
  %l56 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l10
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t7)
  store ptr %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l11, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l13, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l3, !tbaa !29
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i64 @compiler_2fscope_2eflRoot(ptr %s0, ptr %t25)
  store i64 %t27, ptr %l20
  br label %bb8
bb8:
  %t28 = load i64, ptr %l20, !tbaa !24
  store i64 %t28, ptr %l12, !tbaa !24
  br label %bb41
bb9:
  %t29 = load ptr, ptr %l2, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t48 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowRoot(ptr %v0, ptr %s0, ptr %t44, ptr %t45)
  store i64 %t48, ptr %l29
  br label %bb15
bb15:
  %t49 = load i64, ptr %l29, !tbaa !24
  store i64 %t49, ptr %l12, !tbaa !24
  br label %bb41
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 18}
  %t57 = icmp eq i64 %t55, 5
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l5, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Promote", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %s0, ptr %t65, ptr %t69)
  store i64 %t72, ptr %l39
  br label %bb22
bb22:
  %t73 = load i64, ptr %l39, !tbaa !24
  store i64 %t73, ptr %l12, !tbaa !24
  br label %bb41
bb23:
  %t74 = load ptr, ptr %l2, !tbaa !29
  store ptr %t74, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t75 = load ptr, ptr %l40, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 18}
  %t81 = icmp eq i64 %t79, 12
  store i1 %t81, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l41, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l6, !tbaa !29
  br label %bb28
bb27:
  br label %bb36
bb28:
  %t89 = load ptr, ptr %l6, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Seq", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb29, label %bb30
bb29:
  store i64 -1, ptr %l49, !tbaa !24
  br label %bb35
bb30:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l50, !tbaa !29
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Seq", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  br i1 %t102, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_2604b54ceaf5ac58_8a6d930b5e8314fc)
  unreachable
bb32:
  br label %bb33
bb33:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Seq", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t108 = load ptr, ptr %l50, !tbaa !29
  %t110 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %s0, ptr %t108, ptr %t107)
  store i64 %t110, ptr %l56
  br label %bb34
bb34:
  %t111 = load i64, ptr %l56, !tbaa !24
  store i64 %t111, ptr %l49, !tbaa !24
  br label %bb35
bb35:
  %t112 = load i64, ptr %l49, !tbaa !24
  store i64 %t112, ptr %l12, !tbaa !24
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_fee63ae15dece90e_627da4ca7452ed92)
  unreachable
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load i64, ptr %l12, !tbaa !24
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t13, i64 %t14)
  store i1 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = add i64 %t21, 1
  store i64 %t23, ptr %l1, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = add i64 %t25, 1
  store i64 %t27, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %a0) #0 {
entry:
  %l3 = alloca %"compiler/scope:Val"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = call %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %s0, i32 3, { i64, [2 x i64] } %a0)
  store %"compiler/scope:Val" %t4, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t5 = load %"compiler/scope:Val", ptr %l3
  store %"compiler/scope:Val" %t5, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local i64 @compiler_2fscope_2eownField(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 3
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t41 = call i1 @compiler_2fscope_2eisParamRead(ptr %v0, ptr %t37, i64 %a1)
  store i1 %t41, ptr %l21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load i64, ptr %l3, !tbaa !24
  store i64 %t43, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_97a3337844e24daf_abbacdff6e992493)
  unreachable
bb20:
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_21f109796fa0acee_6e7b91baaed0fa92)
  unreachable
bb26:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2epartOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 4
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 5
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_39d6ad994c5e59db_206986dc8e84ce1f)
  unreachable
bb19:
  %t28 = load i1, ptr %l1, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2eregionLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l9, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_926310a74149af64_7456b8629edeed00)
  unreachable
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_d723be5f6d33c955_f64e13843779cd91)
  unreachable
bb22:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ewalkBody(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/scope:walked"
  %l8 = alloca ptr
  %l16 = alloca %"compiler/scope:walked"
  %t1 = alloca %"compiler/scope:walked", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @olang_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %t1, ptr %v1)
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %t1, i64 224, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 224, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l4, i64 224, i1 false)
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l8
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l8, !tbaa !29
  store ptr %t11, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 11
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 11
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t25 = load ptr, ptr %lp2
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t24, ptr %t25)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t28 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t28, i64 224, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l16, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/scope:fnUse" @compiler_2fscope_3afnUse_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i32 %a4) #0 {
entry:
  %rv = alloca %"compiler/scope:fnUse"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/scope:fnUse" undef, i64 %a0, 0
  %t14 = insertvalue %"compiler/scope:fnUse" %t12, %"compiler/source:Span" %a1, 1
  %t16 = insertvalue %"compiler/scope:fnUse" %t14, i64 %a2, 2
  %t18 = insertvalue %"compiler/scope:fnUse" %t16, i64 %a3, 3
  %t20 = insertvalue %"compiler/scope:fnUse" %t18, i32 %a4, 4
  store %"compiler/scope:fnUse" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:fnUse", ptr %rv
  ret %"compiler/scope:fnUse" %rr
}

define dso_local %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %v0, { i64, [2 x i64] } %a0, { i64, [2 x i64] } %a1, i1 %a2, %"compiler/source:Span" %a3, i64 %a4, i1 %a5) #0 {
entry:
  %rv = alloca %"compiler/scope:rel"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/scope:rel" undef, { i64, [2 x i64] } %a0, 0
  %t16 = insertvalue %"compiler/scope:rel" %t14, { i64, [2 x i64] } %a1, 1
  %t18 = insertvalue %"compiler/scope:rel" %t16, i1 %a2, 2
  %t20 = insertvalue %"compiler/scope:rel" %t18, %"compiler/source:Span" %a3, 3
  %t22 = insertvalue %"compiler/scope:rel" %t20, i64 %a4, 4
  %t24 = insertvalue %"compiler/scope:rel" %t22, i1 %a5, 5
  store %"compiler/scope:rel" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:rel", ptr %rv
  ret %"compiler/scope:rel" %rr
}

define dso_local void @compiler_2fscope_3awalked_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"compiler/scope:walked"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l8
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l9
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l2
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l10
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l3
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l11
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l4
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l12
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l5
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l13
  br label %bb7
bb7:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t15 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 0
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t15
  %t17 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 1
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %t17
  %t19 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 2
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t19
  %t21 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 3
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %t21
  %t23 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 4
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %t23
  %t25 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 5
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t25
  %t27 = getelementptr %"compiler/scope:walked", ptr %l14, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %t27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l14, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 176, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 9
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"blocks built into: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d1 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c", of them plain (what folding could reach): " }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d2 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" outlives " }>, align 8
declare void @__olang_ert_req_clear()
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 7}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 5, label %bb7 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load i1, ptr %l2, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"where the generator does" }>, align 8
@.d7 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"with what '" }>, align 8
@.d8 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"' refers to" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"at" }>, align 8
@.d11 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d12 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"setAt" }>, align 8
@.d13 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"instantiated here" }>, align 8
@.d14 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"an instance is built in one of them" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no lift " }>, align 8
@.d17 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" for a part kept | " }>, align 8
@.d18 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"no lift " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d19 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  br label %bb1
bb3:
  %t6 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t8, i64 %t9)
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t15 = sext i32 %t13 to i64
  %t16 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %t15)
  call void @__olang_sb_add(ptr %v0, i64 %t17)
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t18, i64 %t19)
  br label %bb1
bb4:
  %t20 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t20, i64 %t21)
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t22, i64 %t23)
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 1
  %t26 = getelementptr { i64 }, ptr %t25, i32 0, i32 0
  %t27 = load i64, ptr %t26
  %t29 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %t27)
  call void @__olang_sb_add(ptr %v0, i64 %t30)
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb5:
  %t33 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb6:
  %t35 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 1
  %t41 = getelementptr { i64, i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  %t44 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t45 = call i64 @__olang_fmt_i64(ptr %t44, i64 %t42)
  call void @__olang_sb_add(ptr %v0, i64 %t45)
  %t46 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t46, i64 %t47)
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 1
  %t50 = getelementptr { i64, i64 }, ptr %t49, i32 0, i32 1
  %t51 = load i64, ptr %t50
  %t53 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t54 = call i64 @__olang_fmt_i64(ptr %t53, i64 %t51)
  call void @__olang_sb_add(ptr %v0, i64 %t54)
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb7:
  %t57 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr { i64, [2 x i64] }, ptr %t61, i32 0, i32 1
  %t63 = getelementptr { i64 }, ptr %t62, i32 0, i32 0
  %t64 = load i64, ptr %t63
  %t66 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t67 = call i64 @__olang_fmt_i64(ptr %t66, i64 %t64)
  call void @__olang_sb_add(ptr %v0, i64 %t67)
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t68, i64 %t69)
  br label %bb1
bb8:
  %t70 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t70, i64 %t71)
  br label %bb1
ret:
  ret void
}

@.d20 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" (origin " }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c") | " }>, align 8
declare void @__olang_sb_done(ptr)
@.d22 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" with its storage" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" for a part kept" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"lift " }>, align 8
@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@.d28 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" | " }>, align 8
@.d29 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Clear" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"if" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"x" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eZero_2ecompiler_2fscope_3awalked(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"compiler/scope:walked"
  %t1 = alloca %"compiler/scope:walked", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fscope_3awalked_2ector(ptr %t1, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l0, ptr %t1, i64 224, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l0, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

@.d34 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"the program" }>, align 8
@.d35 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"the scope " }>, align 8
@.d36 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"'s argument bound" }>, align 8
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"return" }>, align 8
@.d38 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"the instance" }>, align 8
@.d39 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"the closing scope" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@.d40 = private unnamed_addr constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Term.None" }>, align 8
@.d41 = private unnamed_addr constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Term.Block" }>, align 8
@.d42 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d43 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d44 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Term.Var" }>, align 8
@.d45 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"Term.Program" }>, align 8
@.d46 = private unnamed_addr constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"Term.Derived" }>, align 8
@.d47 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d48 = private unnamed_addr constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Term.Set" }>, align 8
@.d49 = private unnamed_addr constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"Term.Untraced" }>, align 8
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %a0)
declare i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecollectField(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_1f46f0e2a5866641_40fe5c75700827d5 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %a0)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c4dcb08f8057e6b4_879f1d415f5e90f0 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_H9c3932eb53016bf6f47a08eef06aacbe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0)
declare %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorBuilt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8066e5da37f3a23b_ece6b8d6fabe8bf7 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsSum(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_a571972fdacfaed1_c7933b0216b7b5ad = external constant [0 x i8]
@olang_loc_9f9bf081c1674640_32724a584f79d5fc = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evisit(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_be4231f99dfc50a7_6a00356b78c435db = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_badc8ccdfeb92288_a041b08d3fc96aec = external constant [0 x i8]
@olang_loc_58d2ded8d237a84_721cf65762561fa8 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultTerm(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereturnsArray(ptr %v0, ptr %a0)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorageTerm(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowStart(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflowRun(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etiedToBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleArray(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_36d9ea1b8e0be675_6ae7f20c6157de79 = external constant [0 x i8]
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCallOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_318ee1b3da3da37b_dfd49c38f0c44407 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewalkLocal(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b8fb270bdd73210c_150398a92061e6e8 = external constant [0 x i8]
declare i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_6763258997513a41_ec0b86cc45ca0bbd = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumBuilds(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforced(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudgeOut(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
@G_2ecompiler_2fscope_2eObliged = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2, i1 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgsDisagree(ptr %v0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2, ptr %a3, i1 %a4)
@G_2ecompiler_2fscope_2eHolds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFailsBlock = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftAtCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/scope:rel" %a2, { i64, [2 x i64] } %a3)
@G_2ecompiler_2fscope_2eFailsUnknown = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargOfVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOfOwn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewantPromotion(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fscope_2eWhyHolds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewantExact(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceRel(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
@G_2ecompiler_2fscope_2eWhyResult = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnArgHoldsShort(ptr %v0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownIntoResult(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_b6014e02da5c726f_223b10c08168f803 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eYieldOwnStorage(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnOwnStorage(ptr %v0)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fscope_2eWhyField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eInstanceOutlivesReferent(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eInstanceOutlivesArg(ptr %v0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamOfTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_34f683ba23edb410_12747076584ea874 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisParam(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6755090fbbb96f65_b19d41a2104e1b69 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eViewKept(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewKept(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeObligationUnmet(ptr %v0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedThroughElem(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldBindingUnknown(ptr %v0)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteObligationOrigin(ptr %v0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/msgs:Msg" %a4)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteLoopCopy(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_7b1e363353e9e01f_5d568e34003a167b = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2eisNameChar(i8 %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportObligation(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_3d4ddf74a6173f57_410f107a77dd9b9b = external constant [0 x i8]
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2eunPassed(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceDecl(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e3d7361eb9c064f6_d6d91699ddbb69ea = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeMayNotOutlive(ptr %v0)
@G_2ecompiler_2fscope_2eFitLocal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitPayload = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePayloadOutlived(ptr %v0)
@G_2ecompiler_2fscope_2eFitOwn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitReturn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %a0)
@olang_loc_12677068e04dfe45_ab703d1ad408b711 = external constant [0 x i8]
@olang_loc_bf00db29bdc1b99e_9dc03d0b43789e0a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenYieldShorter(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOwnCannotOutlive(ptr %v0)
@G_2ecompiler_2fscope_2eFitField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStoredRefOutlived(ptr %v0)
@G_2ecompiler_2fscope_2eFitElem = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitAnyCopy = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemNotInArrayScope(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eElemOutlived(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCopyOutlived(ptr %v0)
@G_2ecompiler_2fscope_2eFitGlobal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGlobalHoldsShorter(ptr %v0)
@G_2ecompiler_2fscope_2eFitValue = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@olang_loc_2de0ba6211cb93cf_481b942389356f0b = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eValueRefsOutlived(ptr %v0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExprRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e9ea5d5d3867ce51_dfb99b888a23f285 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturesNothing(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_7f2f0698823b265a_e0642f9ed23c39f6 = external constant [0 x i8]
@olang_loc_6b4093eaa9dab6e0_ebbf8088c45502d4 = external constant [0 x i8]
@olang_loc_a83726b6934b3ff_5f714cf565db93e3 = external constant [0 x i8]
@olang_loc_2e96c7acbe66a05d_c52c59876e2a2911 = external constant [0 x i8]
declare %"compiler/scope:Gap" @compiler_2fscope_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2ePush_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/scope:Gap" %a1)
@olang_loc_96b0618960354e24_3d02a19520d5ec20 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_1224d6df3464748a_e87c09d967c04386 = external constant [0 x i8]
@olang_loc_fe279d5820b85dad_458b53b3da9c6ff1 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@olang_loc_6ed8db51a3dfced1_45a76436772cba65 = external constant [0 x i8]
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2etermGiven({ i64, [2 x i64] } %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egivenRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d375f47869e73b1e_ab7f910edbf0dc32 = external constant [0 x i8]
declare i1 @compiler_2fscope_2eisParamRead(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9c7ebd2b12e06561_d1b788b185a2a0b5 = external constant [0 x i8]
@olang_loc_e6e67a80e175cfd0_914d29e7454711c4 = external constant [0 x i8]
@olang_loc_9d00f6934855daa_c9673762d5df43fe = external constant [0 x i8]
declare i64 @compiler_2fscope_2eregionRoot(ptr %v0, ptr %a0)
@olang_loc_6f89170392198c6b_c18aa73f993179ff = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2d8599dd2a60d272_f2da26d46793a2d6 = external constant [0 x i8]
@olang_loc_8dedfa134432c6f3_d3b15d93042206f7 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2ePush_3ccompiler_2fgeneric_3aOrigin_3e(ptr %v0, ptr %a0, %"compiler/generic:Origin" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eLen_3ccompiler_2fgeneric_3aOrigin_3e(ptr %v0, ptr %a0)
declare %"compiler/generic:Origin" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aOrigin_3e_2eAt_3ccompiler_2fgeneric_3aOrigin_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a5122b0b395bd8b_9870aa37c8b5f2ef = external constant [0 x i8]
@olang_loc_51a7ef38ab67534a_42b12633f9b5762e = external constant [0 x i8]
@olang_loc_2d0145e0fa45a88d_adbbe2dcd866b269 = external constant [0 x i8]
@olang_loc_d38420f770b56a25_293628bae4d10df9 = external constant [0 x i8]
@olang_loc_7d2ed71f654b640d_ba09ac545853f0c1 = external constant [0 x i8]
@olang_loc_4d20f13e93e5e00_8edf44d94b0465ac = external constant [0 x i8]
@olang_loc_f39b1bd504b33948_8115a077853ab66c = external constant [0 x i8]
@olang_loc_6eab74aa3e0b63d9_475cda0f5b688a85 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehasLateLocals(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H075aca2c24d2905e4fa457b6b6d6570e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eClear_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eClea_Hf36a88772899b36a46c039ef55a38999(ptr %v0, ptr %a0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecaptureVar(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2ftyped_2eNewPlan(ptr %out, ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_75ea16a293881b53_a3e5ee6d3f4964f = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextDepth(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextBase(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeDestructor(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ekeepRel(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteFieldRecs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecomputeKeeps(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eSetAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, ptr %a3, i1 %a4, { i64, ptr } %a5)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamBinding(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_8c8a5a319e38c1bd_d671b8fda2886981 = external constant [0 x i8]
@olang_loc_d6d71e16ab160a8c_d85efb61f7dcc5f0 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H7e82b4dbdb79c77bc51fdaf9d4704834(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.1eb2466213689e002f25e81e83536e78" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cI64_2c_20compiler_2ftyped_3aExpr_2_H4ea279ff901448a8d94a2f42aa119fd2(ptr %v0, ptr %v1, ptr %a0)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %a0)
declare %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ec2dd22d28cc6988_9d0975400b204864 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d50f79fefbee4394_12c4367532f3ae80 = external constant [0 x i8]
@olang_loc_42ddfa07d54a3511_7eb6b931dfed5aa5 = external constant [0 x i8]
@olang_loc_133169b3f1711469_c566838c26ef218d = external constant [0 x i8]
@olang_loc_31030507f1509b32_81bbcae78c23c7f6 = external constant [0 x i8]
@olang_loc_16a749f285461106_b0e7908cc5ae695a = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftOf(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoinTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowed(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_18c7df235ed333ed_6cb02ce97018ae1 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4)
@olang_loc_732b86ec1c46a4d8_efc842c6ef92792c = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_32a69b93b2b7f4f7_279e7ae047adaf1b = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_cbe9d007f71e6f0a_66029137d6521816 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2, i1 %a3, ptr %a4, i64 %a5)
declare i1 @compiler_2ftyped_2eScopedArray(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d999d01787ae8811_e9a058a4efe4c7fd = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLands(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildSite(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2, %"compiler/source:Span" %a3)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalTerm(ptr %v0, ptr %a0, %"compiler/scope:Val" %a1, { i64, [2 x i64] } %a2)
@olang_loc_63421958175545b3_aea9f7881c37205f = external constant [0 x i8]
@olang_loc_764527203cdb400b_6de4094d30d6c847 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarkTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
@olang_loc_81ac2c90f12200ce_a13e1abdf1b4e702 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e27dfe0dbdd05075_f93f741ca3f66de9 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarkAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTagUnknownScope(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_c869693a02d1a83c_142e5cc4d32f88b8 = external constant [0 x i8]
@olang_loc_f132d9555aa3b3ed_19b32ee1bad8ae89 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_359aef4ec584f7d6_183b185e371796d2 = external constant [0 x i8]
@olang_loc_a12e96be7ca439b0_5f205879a795b73c = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitBorrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitHeld(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H38f9aff1b0310316a48dc5a28922f96e(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2)
@olang_loc_332fe8876b6bb960_cfa416e6ff1f13b4 = external constant [0 x i8]
@olang_loc_4cb1e8bfb0eaf742_30c70eda17c6c626 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteOrigin(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/scope:Val" %a3)
@olang_loc_ebf021f92f33e6c3_51775e5dd3616c17 = external constant [0 x i8]
@olang_loc_b8d34b82d7d8e134_8820b4804d519ff8 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownCall(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H65b4b9a6d1679f5b3ddedaa5b2e336bd(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4a1df88f6e47fa3d_f104cf9ebdc893f9 = external constant [0 x i8]
@olang_loc_1209ecb2ebe28e56_3903fb857fc509d2 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %v0)
@olang_loc_f4fc0aa0b05f02b5_215f839e2022cb11 = external constant [0 x i8]
@olang_loc_404d48eac542ce9d_9912d4e42165f0c9 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_bc57042d1b9aa9c8_42b203ed434388d4 = external constant [0 x i8]
@olang_loc_19aa55fe70facde7_b663d059e4ca19e3 = external constant [0 x i8]
@G_2ecompiler_2fscope_2eFitDecl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@olang_loc_eca6e0b2d52570fa_4fe6c0f0f8e0b5fe = external constant [0 x i8]
@olang_loc_acdf13ac8090b308_c550e3cb7d47705c = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunknownBinding(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_3b111cc35ad2064c_5bc510d97bfe7450 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRelatable({ i64, [2 x i64] } %a0)
@olang_loc_3b2e5dd5e19962bb_2cdcb9ba8ccbb9af = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enarrowingMatters(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3005b9c21f34ca3e_35904d8c355f64ba = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenResult(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_cf25d893b5e0925b_26a5f8a01e1a0e87 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etraceAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftable(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_56753b57ce5c76c_5bd4f5104db7b168 = external constant [0 x i8]
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H568ce559fa980123a387c6ba9ed21aca(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fscope_2eisBlockTerm({ i64, [2 x i64] } %a0)
@olang_loc_14a6577ead1cc721_32dce333731fd63d = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H240bd86caf003ea6de374cb77d0dbfc6(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, { i64, [2 x i64] } %a2)
@olang_loc_5be7cf6889c0719a_fac8d756f0ba6a56 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_7514114a5d4749ce_60914fcc95b5171a = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_bfbb893df1c35f5d_ebb7b8931b043491 = external constant [0 x i8]
@olang_loc_a9ed640346de181b_d10bb16716ed4607 = external constant [0 x i8]
declare i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %a0)
@olang_loc_3b124163f404c032_f61e7eda275eee66 = external constant [0 x i8]
@olang_loc_4046876e7ea1d159_b2112eb816f2c84d = external constant [0 x i8]
@olang_loc_79d12197ff1a95a4_7d7576a4aa48dc38 = external constant [0 x i8]
@olang_loc_2cb2f05c33c43f73_8008e731f94f8857 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrKeepCopies(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetAtCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_3be66b99fba73c4e_1215a57d292f746a = external constant [0 x i8]
@olang_loc_9cb83d16c8558bf5_7c19eecf9e07b071 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHeldIndexWhere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisText(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98ba305d5e2403e0_d6869d4c9e18247c = external constant [0 x i8]
@olang_loc_37fd0ede1d7e00ff_4f25c812a3c753eb = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteTextCopyWhere(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d1e09ab5654512c3_1949347ac845fe07 = external constant [0 x i8]
@olang_loc_9ec3c43f0dea0d34_4e7830eaf7e3a0e8 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_60a9277e2c5e0f29_25801f0e1d4bc5bd = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
@olang_loc_32a2617be6fc2342_ed6c13319ae659d6 = external constant [0 x i8]
@olang_loc_466c52b9c16c208f_a374cdad5045efdb = external constant [0 x i8]
@olang_loc_f99d36ce04cd5358_3c9954da82c615c4 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteRefillKept(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esliceAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_8680c8bf7a40147c_d650a7d3d4e83170 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastBracket(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_22d8393d4f188012_8c9f9e39cb427896 = external constant [0 x i8]
@olang_loc_7213214fb222d0c9_1eae7674ed2401ad = external constant [0 x i8]
@olang_loc_7794e183659425f8_898d85cb25e621fc = external constant [0 x i8]
@olang_loc_2d6fa2178670cc38_6a7a96bf0e7e73f4 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_da3e82aad0dc20bd_21e51e34c917c3d9 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclaimRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_178b2bff302b55ae_896b4874215d5e1a = external constant [0 x i8]
@olang_loc_98dfeaa5663cde63_8f6c693e4f6dac2f = external constant [0 x i8]
@olang_loc_50915285e3e59b40_32eaccc11482b3ec = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePartKept(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_74d9849f1cf072e4_d95edc215f7aa198 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b99a325748da8cd5_4eb62b65b3c79869 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_554265ba1528b3d8_d73d8ae267adc184 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisData(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c484f993348186a9_88a471068962d75 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartLand(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, { i64, [2 x i64] } %a3)
declare %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereadPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, { i64, [2 x i64] } %a3)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb4ab14fd1aa8deeb21095c3402461540(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_59817874246b5c57_1f46b3df70232973 = external constant [0 x i8]
@olang_loc_56ee07e6d564b038_6c64e51b3b797fa4 = external constant [0 x i8]
@olang_loc_8b89bffa420e9c4d_32da4af1bb00bb59 = external constant [0 x i8]
@olang_loc_cf97101c527ac266_2da604e73063aa32 = external constant [0 x i8]
@olang_loc_289e5954cee327eb_2a90d26159dceaff = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eResultMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_8136fe9cd009015e_effe087bfaf9a8aa = external constant [0 x i8]
@olang_loc_989f9a5853b8d905_f9638c70ccb394b1 = external constant [0 x i8]
@olang_loc_9ce8ff5a7c812fb0_6c28ecd338a0cbbc = external constant [0 x i8]
@olang_loc_5c3642998b37ea8f_438088e259bab72b = external constant [0 x i8]
@olang_loc_486c515bb0c7ed42_3dcfa333a8d1daa6 = external constant [0 x i8]
@olang_loc_ed4ec6d3513e2b60_3036131f8fea9d34 = external constant [0 x i8]
@olang_loc_b48db41ed7b5d734_952948d9de5cb478 = external constant [0 x i8]
@olang_loc_e7aa8a952f10dcc3_5e7ff2b7646c8097 = external constant [0 x i8]
@olang_loc_dc4554eebbf8456_460c8fdf10d01e52 = external constant [0 x i8]
@olang_loc_ab37e5456fd3bb64_ee38acc32440dcb0 = external constant [0 x i8]
@olang_loc_c2f9290c57ed376d_cbd7590e0cb57901 = external constant [0 x i8]
@olang_loc_c0d893db7e601486_f2e0d00716145a7a = external constant [0 x i8]
@olang_loc_dcd7e57cabd1f877_41684d2a22884c3b = external constant [0 x i8]
@olang_loc_1d5cd0d51560a858_414b0c179bc0efcc = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_83cb1a0080c88b91_4687383f0631b81d = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_e68b15b11e0abafb_13fbbcd2ac59787f = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_5026d552222f1723_4b71b7547c4744a7 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_9da86a51b48ec4c_4c8b634b3e5eba18 = external constant [0 x i8]
@olang_loc_ecfbbef7cda902e1_3bafa02f8f932e5d = external constant [0 x i8]
@olang_loc_37637c4d9c3e6d50_2ee770f7e7b7abac = external constant [0 x i8]
@olang_loc_3254ddf6344cc8b_4503cdf23e4eb927 = external constant [0 x i8]
@olang_loc_678543b1c51fd044_bcff5a6e112a6af8 = external constant [0 x i8]
@olang_loc_90a9d28716f9cb6_29834bc9108cc36a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eStrStoresInReceiver(ptr %v0)
@olang_loc_a7a579971a154b67_66936e5e8b24a2eb = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteStrBuildsHere(ptr %v0)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elocalName(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, ptr %a3)
@olang_loc_a29c887f84e1b245_5040fb81d2028cb9 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughDerived(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c51808c26f3c8029_f1c25a88624d8cdd = external constant [0 x i8]
@olang_loc_33e8f6984fda8b38_987c5f6a5f702884 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2604b54ceaf5ac58_8a6d930b5e8314fc = external constant [0 x i8]
@olang_loc_fee63ae15dece90e_627da4ca7452ed92 = external constant [0 x i8]
declare %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %v0, i32 %a0, { i64, [2 x i64] } %a1)
@olang_loc_97a3337844e24daf_abbacdff6e992493 = external constant [0 x i8]
@olang_loc_21f109796fa0acee_6e7b91baaed0fa92 = external constant [0 x i8]
@olang_loc_39d6ad994c5e59db_206986dc8e84ce1f = external constant [0 x i8]
@olang_loc_926310a74149af64_7456b8629edeed00 = external constant [0 x i8]
@olang_loc_d723be5f6d33c955_f64e13843779cd91 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
