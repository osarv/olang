; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/scope:Val" = type { i32, { i64, [2 x i64] } }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/scope:walked" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/typed:Plan", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:fnRecs", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, { i64, [2 x i64] }, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i1, i1, i1, i1, i64, i1, i1, i64, i1, i1, i1, i1, i64, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:fnRecs" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Versions" = type { ptr, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/scope:placeSlot" = type { { i64, [2 x i64] }, i1, i64 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/scope:verAtom" = type { i64, i64, i64, i64, i64, i64, i1, i64 }
%"compiler/scope:rel" = type { { i64, [2 x i64] }, { i64, [2 x i64] }, i1, %"compiler/source:Span", i64, i1 }
%"compiler/scope:summary" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/scope:fnRecs", i1, i1, i1, i1 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/scope:fnRec" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/types:DtorWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/scope:sumRead" = type { i64, ptr }
define dso_local %"compiler/scope:Val" @compiler_2fscope_2eVal_2eexisting({ i64, [2 x i64] } %a0) #0 {
entry:
  %l3 = alloca %"compiler/scope:Val"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = call %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %s0, i32 3, { i64, [2 x i64] } %a0)
  store %"compiler/scope:Val" %t4, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t5 = load %"compiler/scope:Val", ptr %l3
  store %"compiler/scope:Val" %t5, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local void @compiler_2fscope_2ecollectArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l20 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Alt", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t33, ptr %t35)
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Alt", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  %t65 = getelementptr %"compiler/typed:Bind", ptr %t61, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t66, ptr %t68)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb9
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l3, !tbaa !24
  br label %bb4
bb17:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Arm", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Arm", ptr %t86, i32 0, i32 3
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t89, ptr %t90)
  br label %bb19
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Arm", ptr %t93, i32 0, i32 4
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecollectStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca i64
  %l53 = alloca ptr
  %l55 = alloca i64
  %l57 = alloca i1
  %l59 = alloca i1
  %l61 = alloca i64
  %l64 = alloca ptr
  %l66 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i1
  %l185 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca i1
  %l207 = alloca { i64, ptr }
  %l213 = alloca i64
  %l216 = alloca ptr
  %l218 = alloca i64
  %l220 = alloca i1
  %l222 = alloca i1
  %l224 = alloca i64
  %l227 = alloca ptr
  %l229 = alloca i64
  %l249 = alloca { i64, ptr }
  %l257 = alloca ptr
  %l258 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t6 = load ptr, ptr %l32, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l32, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 17}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l33, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l33, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t22)
  br label %bb9
bb9:
  br label %bb166
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t26 = load ptr, ptr %l41, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l41, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 17}
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l42, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l42, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb35
bb15:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l50
  br label %bb16
bb16:
  %t49 = load i64, ptr %l50, !tbaa !24
  %t50 = icmp sge i64 %t49, 0
  br i1 %t50, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/scope:walked", ptr %t52, i32 0, i32 1
  store ptr %t54, ptr %l53, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %t55)
  store i64 %t57, ptr %l55
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l53, !tbaa !29
  %t59 = load i64, ptr %l55, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t58, i64 %t59)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %t60)
  store i1 %t62, ptr %l57
  br label %bb22
bb22:
  %t63 = load i1, ptr %l57, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb23, label %bb24
bb23:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l61
  br label %bb25
bb24:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb26
bb25:
  %t69 = load i64, ptr %l61, !tbaa !24
  %t70 = icmp sge i64 %t69, 0
  store i1 %t70, ptr %l59, !tbaa !21
  br label %bb26
bb26:
  %t72 = load i1, ptr %l59, !tbaa !21
  br i1 %t72, label %bb27, label %bb28
bb27:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/scope:walked", ptr %t73, i32 0, i32 4
  store ptr %t75, ptr %l64, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t76)
  store i64 %t78, ptr %l66
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t79 = load ptr, ptr %l64, !tbaa !29
  %t80 = load i64, ptr %l66, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t79, i64 %t80)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectField(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  br label %bb32
bb32:
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %t85, ptr %t87)
  br label %bb33
bb33:
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t90, ptr %t92)
  br label %bb34
bb34:
  br label %bb166
bb35:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t96 = load ptr, ptr %l75, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load ptr, ptr %l75, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 17}
  %t102 = icmp eq i64 %t100, 2
  store i1 %t102, ptr %l76, !tbaa !21
  br label %bb37
bb37:
  %t103 = load i1, ptr %l76, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr { i64, [3 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", ptr }, ptr %t106, i32 0, i32 1
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l5, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t110 = load ptr, ptr %l5, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t110, ptr %t112)
  br label %bb41
bb41:
  br label %bb166
bb42:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t116 = load ptr, ptr %l84, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb43, label %bb44
bb43:
  %t119 = load ptr, ptr %l84, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 17}
  %t122 = icmp eq i64 %t120, 3
  store i1 %t122, ptr %l85, !tbaa !21
  br label %bb44
bb44:
  %t123 = load i1, ptr %l85, !tbaa !21
  br i1 %t123, label %bb45, label %bb46
bb45:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", ptr }, ptr %t126, i32 0, i32 1
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l6, !tbaa !29
  br label %bb47
bb46:
  br label %bb51
bb47:
  %t130 = load ptr, ptr %l6, !tbaa !29
  %t132 = getelementptr %"compiler/typed:If", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t133, ptr %t135)
  br label %bb48
bb48:
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t140 = getelementptr %"compiler/typed:If", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t141, ptr %t143)
  br label %bb49
bb49:
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t148 = getelementptr %"compiler/typed:If", ptr %t146, i32 0, i32 2
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t149, ptr %t150)
  br label %bb50
bb50:
  br label %bb166
bb51:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t154 = load ptr, ptr %l101, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb52, label %bb53
bb52:
  %t157 = load ptr, ptr %l101, !tbaa !29
  %t158 = load i64, ptr %t157, !range !{i64 0, i64 17}
  %t160 = icmp eq i64 %t158, 4
  store i1 %t160, ptr %l102, !tbaa !21
  br label %bb53
bb53:
  %t161 = load i1, ptr %l102, !tbaa !21
  br i1 %t161, label %bb54, label %bb55
bb54:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr { i64, [3 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t164, i32 0, i32 1
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l7, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l8, !tbaa !29
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t174 = load ptr, ptr %l7, !tbaa !29
  %t176 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t174, ptr %t176)
  br label %bb57
bb57:
  %t179 = load ptr, ptr %l8, !tbaa !29
  %t180 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  br label %bb58
bb58:
  br label %bb166
bb59:
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t184 = load ptr, ptr %l114, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb60, label %bb61
bb60:
  %t187 = load ptr, ptr %l114, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 17}
  %t190 = icmp eq i64 %t188, 6
  store i1 %t190, ptr %l115, !tbaa !21
  br label %bb61
bb61:
  %t191 = load i1, ptr %l115, !tbaa !21
  br i1 %t191, label %bb62, label %bb63
bb62:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l9, !tbaa !29
  br label %bb68
bb63:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t199 = load ptr, ptr %l120, !tbaa !29
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %bb64, label %bb65
bb64:
  %t202 = load ptr, ptr %l120, !tbaa !29
  %t203 = load i64, ptr %t202, !range !{i64 0, i64 17}
  %t205 = icmp eq i64 %t203, 16
  store i1 %t205, ptr %l121, !tbaa !21
  br label %bb65
bb65:
  %t206 = load i1, ptr %l121, !tbaa !21
  br i1 %t206, label %bb66, label %bb67
bb66:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr { i64, [3 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", ptr }, ptr %t209, i32 0, i32 1
  %t211 = load ptr, ptr %t210
  store ptr %t211, ptr %l9, !tbaa !29
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t213 = load ptr, ptr %l9, !tbaa !29
  %t214 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t213, ptr %t214)
  br label %bb69
bb69:
  br label %bb166
bb70:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t218 = load ptr, ptr %l128, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb71, label %bb72
bb71:
  %t221 = load ptr, ptr %l128, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 17}
  %t224 = icmp eq i64 %t222, 10
  store i1 %t224, ptr %l129, !tbaa !21
  br label %bb72
bb72:
  %t225 = load i1, ptr %l129, !tbaa !21
  br i1 %t225, label %bb73, label %bb74
bb73:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t228, i32 0, i32 1
  %t230 = load ptr, ptr %t229
  store ptr %t230, ptr %l10, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr { i64, [3 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t234, i32 0, i32 2
  %t236 = load ptr, ptr %t235
  store ptr %t236, ptr %l11, !tbaa !29
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t238 = load ptr, ptr %l10, !tbaa !29
  %t240 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t238, ptr %t240)
  br label %bb76
bb76:
  %t243 = load ptr, ptr %l11, !tbaa !29
  %t244 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t243, ptr %t244)
  br label %bb77
bb77:
  br label %bb166
bb78:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t248 = load ptr, ptr %l141, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb79, label %bb80
bb79:
  %t251 = load ptr, ptr %l141, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 17}
  %t254 = icmp eq i64 %t252, 9
  store i1 %t254, ptr %l142, !tbaa !21
  br label %bb80
bb80:
  %t255 = load i1, ptr %l142, !tbaa !21
  br i1 %t255, label %bb81, label %bb82
bb81:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 2
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l12, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t262 = load ptr, ptr %l12, !tbaa !29
  %t263 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t262, ptr %t263)
  br label %bb84
bb84:
  br label %bb166
bb85:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t267 = load ptr, ptr %l149, !tbaa !29
  %t268 = icmp ne ptr %t267, null
  br i1 %t268, label %bb86, label %bb87
bb86:
  %t270 = load ptr, ptr %l149, !tbaa !29
  %t271 = load i64, ptr %t270, !range !{i64 0, i64 17}
  %t273 = icmp eq i64 %t271, 11
  store i1 %t273, ptr %l150, !tbaa !21
  br label %bb87
bb87:
  %t274 = load i1, ptr %l150, !tbaa !21
  br i1 %t274, label %bb88, label %bb89
bb88:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", ptr }, ptr %t277, i32 0, i32 1
  %t279 = load ptr, ptr %t278
  store ptr %t279, ptr %l13, !tbaa !29
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t281 = load ptr, ptr %l13, !tbaa !29
  %t283 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t281, ptr %t283)
  br label %bb91
bb91:
  br label %bb166
bb92:
  %t286 = load ptr, ptr %l0, !tbaa !29
  store ptr %t286, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t287 = load ptr, ptr %l158, !tbaa !29
  %t288 = icmp ne ptr %t287, null
  br i1 %t288, label %bb93, label %bb94
bb93:
  %t290 = load ptr, ptr %l158, !tbaa !29
  %t291 = load i64, ptr %t290, !range !{i64 0, i64 17}
  %t293 = icmp eq i64 %t291, 12
  store i1 %t293, ptr %l159, !tbaa !21
  br label %bb94
bb94:
  %t294 = load i1, ptr %l159, !tbaa !21
  br i1 %t294, label %bb95, label %bb96
bb95:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr { i64, [3 x i64] }, ptr %t295, i32 0, i32 1
  %t298 = getelementptr { %"compiler/source:Span", ptr }, ptr %t297, i32 0, i32 1
  %t299 = load ptr, ptr %t298
  store ptr %t299, ptr %l14, !tbaa !29
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t301 = load ptr, ptr %l14, !tbaa !29
  %t303 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t301, ptr %t303)
  br label %bb98
bb98:
  br label %bb166
bb99:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l167, !tbaa !29
  store i1 false, ptr %l168, !tbaa !21
  %t307 = load ptr, ptr %l167, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb100, label %bb101
bb100:
  %t310 = load ptr, ptr %l167, !tbaa !29
  %t311 = load i64, ptr %t310, !range !{i64 0, i64 17}
  %t313 = icmp eq i64 %t311, 13
  store i1 %t313, ptr %l168, !tbaa !21
  br label %bb101
bb101:
  %t314 = load i1, ptr %l168, !tbaa !21
  br i1 %t314, label %bb102, label %bb103
bb102:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr { i64, [3 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", ptr }, ptr %t317, i32 0, i32 1
  %t319 = load ptr, ptr %t318
  store ptr %t319, ptr %l15, !tbaa !29
  br label %bb104
bb103:
  br label %bb113
bb104:
  %t321 = load ptr, ptr %l15, !tbaa !29
  %t323 = getelementptr %"compiler/typed:Join", ptr %t321, i32 0, i32 0
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t326 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t324, ptr %t326)
  br label %bb105
bb105:
  %t329 = load ptr, ptr %l15, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Join", ptr %t329, i32 0, i32 2
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  store { i64, ptr } %t332, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t334 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t334, 0
  store i64 %t336, ptr %l18, !tbaa !24
  br label %bb106
bb106:
  %t338 = load i64, ptr %l17, !tbaa !24
  %t339 = load i64, ptr %l18, !tbaa !24
  %t342 = icmp slt i64 %t338, %t339
  %t344 = xor i1 %t342, true
  br i1 %t344, label %bb107, label %bb108
bb107:
  br label %bb112
bb108:
  br label %bb109
bb109:
  %t346 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t346, ptr %l185, !tbaa !27
  %t347 = load i64, ptr %l17, !tbaa !24
  %t349 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr ptr, ptr %t350, i64 %t347
  %t352 = load ptr, ptr %t351, !tbaa !39
  %t356 = getelementptr %"compiler/typed:Clause", ptr %t352, i32 0, i32 3
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t358 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t357, ptr %t358)
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t361 = load i64, ptr %l17, !tbaa !24
  %t363 = add i64 %t361, 1
  store i64 %t363, ptr %l17, !tbaa !24
  br label %bb106
bb112:
  br label %bb166
bb113:
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t366 = load ptr, ptr %l193, !tbaa !29
  %t367 = icmp ne ptr %t366, null
  br i1 %t367, label %bb114, label %bb115
bb114:
  %t369 = load ptr, ptr %l193, !tbaa !29
  %t370 = load i64, ptr %t369, !range !{i64 0, i64 17}
  %t372 = icmp eq i64 %t370, 14
  store i1 %t372, ptr %l194, !tbaa !21
  br label %bb115
bb115:
  %t373 = load i1, ptr %l194, !tbaa !21
  br i1 %t373, label %bb116, label %bb117
bb116:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr { i64, [3 x i64] }, ptr %t374, i32 0, i32 1
  %t377 = getelementptr { %"compiler/source:Span", ptr }, ptr %t376, i32 0, i32 1
  %t378 = load ptr, ptr %t377
  store ptr %t378, ptr %l20, !tbaa !29
  br label %bb118
bb117:
  br label %bb154
bb118:
  %t380 = load ptr, ptr %l20, !tbaa !29
  %t382 = getelementptr %"compiler/typed:Spawn", ptr %t380, i32 0, i32 0
  %t383 = load { i64, ptr }, ptr %t382, !tbaa !27
  store { i64, ptr } %t383, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t385 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t385, 0
  store i64 %t387, ptr %l23, !tbaa !24
  br label %bb119
bb119:
  %t389 = load i64, ptr %l22, !tbaa !24
  %t390 = load i64, ptr %l23, !tbaa !24
  %t393 = icmp slt i64 %t389, %t390
  %t395 = xor i1 %t393, true
  br i1 %t395, label %bb120, label %bb121
bb120:
  br label %bb145
bb121:
  br label %bb122
bb122:
  %t397 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t397, ptr %l207, !tbaa !27
  %t398 = load i64, ptr %l22, !tbaa !24
  %t400 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr ptr, ptr %t401, i64 %t398
  %t403 = load ptr, ptr %t402, !tbaa !39
  store ptr %t403, ptr %l24, !tbaa !29
  %t405 = load ptr, ptr %l24, !tbaa !29
  %t407 = icmp eq ptr %t405, null
  br i1 %t407, label %bb123, label %bb124
bb123:
  br label %bb144
bb124:
  br label %bb125
bb125:
  %t409 = load ptr, ptr %l24, !tbaa !29
  %t411 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %t409)
  store i64 %t411, ptr %l213
  br label %bb126
bb126:
  %t412 = load i64, ptr %l213, !tbaa !24
  %t413 = icmp sge i64 %t412, 0
  br i1 %t413, label %bb127, label %bb128
bb127:
  %t415 = load ptr, ptr %l1, !tbaa !29
  %t417 = getelementptr %"compiler/scope:walked", ptr %t415, i32 0, i32 1
  store ptr %t417, ptr %l216, !tbaa !29
  %t418 = load ptr, ptr %l24, !tbaa !29
  %t420 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %t418)
  store i64 %t420, ptr %l218
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t421 = load ptr, ptr %l216, !tbaa !29
  %t422 = load i64, ptr %l218, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t421, i64 %t422)
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t423 = load ptr, ptr %l24, !tbaa !29
  %t425 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %t423)
  store i1 %t425, ptr %l220
  br label %bb132
bb132:
  %t426 = load i1, ptr %l220, !tbaa !21
  %t427 = xor i1 %t426, true
  br i1 %t427, label %bb133, label %bb134
bb133:
  %t429 = load ptr, ptr %l24, !tbaa !29
  %t431 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t429)
  store i64 %t431, ptr %l224
  br label %bb135
bb134:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb136
bb135:
  %t432 = load i64, ptr %l224, !tbaa !24
  %t433 = icmp sge i64 %t432, 0
  store i1 %t433, ptr %l222, !tbaa !21
  br label %bb136
bb136:
  %t435 = load i1, ptr %l222, !tbaa !21
  br i1 %t435, label %bb137, label %bb138
bb137:
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t438 = getelementptr %"compiler/scope:walked", ptr %t436, i32 0, i32 4
  store ptr %t438, ptr %l227, !tbaa !29
  %t439 = load ptr, ptr %l24, !tbaa !29
  %t441 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t439)
  store i64 %t441, ptr %l229
  br label %bb139
bb138:
  br label %bb141
bb139:
  %t442 = load ptr, ptr %l227, !tbaa !29
  %t443 = load i64, ptr %l229, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t442, i64 %t443)
  br label %bb140
bb140:
  br label %bb141
bb141:
  %t444 = load ptr, ptr %l24, !tbaa !29
  %t445 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectField(ptr %v0, ptr %v1, ptr %t444, ptr %t445)
  br label %bb142
bb142:
  %t448 = load ptr, ptr %l24, !tbaa !29
  %t450 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %t448, ptr %t450)
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t453 = load i64, ptr %l22, !tbaa !24
  %t455 = add i64 %t453, 1
  store i64 %t455, ptr %l22, !tbaa !24
  br label %bb119
bb145:
  %t457 = load ptr, ptr %l20, !tbaa !29
  %t459 = getelementptr %"compiler/typed:Spawn", ptr %t457, i32 0, i32 1
  %t460 = load ptr, ptr %t459, !tbaa !29
  %t462 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t460, ptr %t462)
  br label %bb146
bb146:
  %t465 = load ptr, ptr %l20, !tbaa !29
  %t467 = getelementptr %"compiler/typed:Spawn", ptr %t465, i32 0, i32 2
  %t468 = load { i64, ptr }, ptr %t467, !tbaa !27
  store { i64, ptr } %t468, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t470 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t470, 0
  store i64 %t472, ptr %l27, !tbaa !24
  br label %bb147
bb147:
  %t474 = load i64, ptr %l26, !tbaa !24
  %t475 = load i64, ptr %l27, !tbaa !24
  %t478 = icmp slt i64 %t474, %t475
  %t480 = xor i1 %t478, true
  br i1 %t480, label %bb148, label %bb149
bb148:
  br label %bb153
bb149:
  br label %bb150
bb150:
  %t482 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t482, ptr %l249, !tbaa !27
  %t483 = load i64, ptr %l26, !tbaa !24
  %t485 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !27
  %t487 = getelementptr ptr, ptr %t486, i64 %t483
  %t488 = load ptr, ptr %t487, !tbaa !39
  %t492 = getelementptr %"compiler/typed:TaskClause", ptr %t488, i32 0, i32 3
  %t493 = load ptr, ptr %t492, !tbaa !29
  %t494 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t493, ptr %t494)
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t497 = load i64, ptr %l26, !tbaa !24
  %t499 = add i64 %t497, 1
  store i64 %t499, ptr %l26, !tbaa !24
  br label %bb147
bb153:
  br label %bb166
bb154:
  %t501 = load ptr, ptr %l0, !tbaa !29
  store ptr %t501, ptr %l257, !tbaa !29
  store i1 false, ptr %l258, !tbaa !21
  %t502 = load ptr, ptr %l257, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb155, label %bb156
bb155:
  %t505 = load ptr, ptr %l257, !tbaa !29
  %t506 = load i64, ptr %t505, !range !{i64 0, i64 17}
  %t508 = icmp eq i64 %t506, 15
  store i1 %t508, ptr %l258, !tbaa !21
  br label %bb156
bb156:
  %t509 = load i1, ptr %l258, !tbaa !21
  br i1 %t509, label %bb157, label %bb158
bb157:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t512 = getelementptr { i64, [3 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", ptr }, ptr %t512, i32 0, i32 1
  %t514 = load ptr, ptr %t513
  store ptr %t514, ptr %l29, !tbaa !29
  br label %bb159
bb158:
  br label %bb161
bb159:
  %t516 = load ptr, ptr %l29, !tbaa !29
  %t518 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t516, ptr %t518)
  br label %bb160
bb160:
  br label %bb166
bb161:
  br i1 true, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_1f46f0e2a5866641_40fe5c75700827d5)
  unreachable
bb166:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eJudged(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 11
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %a1)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddLocalRecs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/scope:fnRecs"
  %l11 = alloca i1
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca i64
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca %"compiler/scope:fnRecs"
  %l38 = alloca %"compiler/scope:fnRecs"
  %l39 = alloca i32
  %l41 = alloca %"compiler/scope:fnRecs"
  %l42 = alloca %"compiler/scope:fnRecs"
  %l47 = alloca %"compiler/source:Span"
  %l50 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca i1
  %l61 = alloca i1
  %l71 = alloca i1
  %l76 = alloca i1
  %l84 = alloca i1
  %l85 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca i32
  %l96 = alloca %"compiler/scope:fnRecs"
  %l100 = alloca %"compiler/scope:fnRecs"
  %l101 = alloca i32
  %l103 = alloca %"compiler/scope:fnRecs"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisCursorLocal(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/scope:Scoper", ptr %t7, i32 0, i32 149
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb4, label %bb5
bb3:
  br label %bb40
bb4:
  call void @__olang_check_failed(ptr @olang_loc_f0350fc91fe6e1d6_3a4336dcacad1f0a)
  unreachable
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 149
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l3, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereachFor(ptr %v0, ptr %s2, ptr %t19, i64 %t20, i64 -1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l19
  br label %bb7
bb7:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t25 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %t25
  store ptr %t25, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t27 = load i64, ptr %l5, !tbaa !24
  store i64 %t27, ptr %l21, !tbaa !24
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t28)
  store i64 %t30, ptr %l23
  br label %bb9
bb9:
  %t31 = load i64, ptr %l21, !tbaa !24
  %t32 = load i64, ptr %l23, !tbaa !24
  %t33 = icmp slt i64 %t31, %t32
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb10, label %bb11
bb10:
  br label %bb39
bb11:
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t37, i64 %t38)
  store i64 %t41, ptr %l28
  br label %bb13
bb13:
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %l6, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t43, i32 0, i32 87
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3afnRecs_3e__H4d9dd4678cabff1b2f88ea0996ab01db(ptr %v0, ptr %t45, i64 %t46)
  store i1 %t49, ptr %l32
  br label %bb14
bb14:
  %t50 = load i1, ptr %l32, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l33, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/scope:Scoper", ptr %t52, i32 0, i32 87
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = call { i32, %"compiler/scope:fnRecs" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3afnRecs_3e__Hf28901f23b5d22676a93f0159a8b63c2(ptr %v0, ptr %v0, ptr %t54, i64 %t55)
  %t59 = extractvalue { i32, %"compiler/scope:fnRecs" } %t58, 1
  %t60 = extractvalue { i32, %"compiler/scope:fnRecs" } %t58, 0
  store i32 %t60, ptr %l39
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb18, label %ok.62, !prof !99
ok.62:
  store %"compiler/scope:fnRecs" %t59, ptr %l38
  br label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Versions", ptr %t63, i32 0, i32 4
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t65, i64 %t66)
  store %"compiler/source:Span" %t69, ptr %l47
  br label %bb24
bb17:
  %t71 = call %"compiler/scope:fnRecs" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fscope_3afnRecs(ptr %v0, ptr %l38)
  store %"compiler/scope:fnRecs" %t71, ptr %l41
  br label %bb20
bb18:
  br label %bb19
bb19:
  %t72 = call %"compiler/scope:fnRecs" @compiler_2fscope_3afnRecs_2ector(ptr %v0)
  store %"compiler/scope:fnRecs" %t72, ptr %l42
  br label %bb21
bb20:
  %t73 = load %"compiler/scope:fnRecs", ptr %l41
  store %"compiler/scope:fnRecs" %t73, ptr %l34
  br label %bb22
bb21:
  %t74 = load %"compiler/scope:fnRecs", ptr %l42
  store %"compiler/scope:fnRecs" %t74, ptr %l34
  br label %bb22
bb22:
  %t75 = load %"compiler/scope:fnRecs", ptr %l34
  %t76 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 104, i64 8)
  store %"compiler/scope:fnRecs" %t75, ptr %t76
  %t77 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2fscope_2emergeRecs(ptr %v1, ptr %v0, ptr %t77, ptr %t76)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb24:
  %t79 = getelementptr %"compiler/source:Span", ptr %l47, i32 0, i32 0
  %t80 = load i32, ptr %t79, !tbaa !23
  %t82 = icmp sge i32 %t80, 0
  br i1 %t82, label %bb25, label %bb26
bb25:
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Versions", ptr %t84, i32 0, i32 6
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %s5, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l54
  br label %bb27
bb26:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb28
bb27:
  %t91 = load ptr, ptr %l54, !tbaa !29
  %t92 = icmp eq ptr %t91, null
  %t94 = xor i1 %t92, true
  store i1 %t94, ptr %l50, !tbaa !21
  br label %bb28
bb28:
  %t96 = load i1, ptr %l50, !tbaa !21
  br i1 %t96, label %bb29, label %bb30
bb29:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/scope:Scoper", ptr %t97, i32 0, i32 155
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t99, i64 %t100)
  store i1 %t103, ptr %l61
  br label %bb31
bb30:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb32
bb31:
  %t104 = load i1, ptr %l61, !tbaa !21
  %t105 = xor i1 %t104, true
  store i1 %t105, ptr %l57, !tbaa !21
  br label %bb32
bb32:
  %t107 = load i1, ptr %l57, !tbaa !21
  br i1 %t107, label %bb33, label %bb34
bb33:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t110 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elateDef(ptr %v0, ptr %v1, ptr %t108, ptr %t109, i64 %t110)
  br label %bb35
bb34:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/scope:fnRecs", ptr %t114, i32 0, i32 1
  store i1 false, ptr %t116, !tbaa !21
  br label %bb36
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t117 = load i64, ptr %l5, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l5, !tbaa !24
  br label %bb8
bb39:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb40:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i64, ptr %l2, !tbaa !24
  %t125 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eassignedWhole(ptr %v0, ptr %t121, i64 %t122)
  store i1 %t125, ptr %l71
  br label %bb41
bb41:
  %t126 = load i1, ptr %l71, !tbaa !21
  br i1 %t126, label %bb42, label %bb43
bb42:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"compiler/scope:fnRecs", ptr %t127, i32 0, i32 1
  store i1 false, ptr %t129, !tbaa !21
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr %"compiler/scope:fnRecs", ptr %t130, i32 0, i32 3
  %t133 = load i64, ptr %l2, !tbaa !24
  %t136 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t132, i64 %t133)
  store i1 %t136, ptr %l76
  br label %bb44
bb43:
  br label %bb49
bb44:
  %t137 = load i1, ptr %l76, !tbaa !21
  %t138 = xor i1 %t137, true
  br i1 %t138, label %bb45, label %bb46
bb45:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr %"compiler/scope:fnRecs", ptr %t140, i32 0, i32 3
  %t143 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t142, i64 %t143)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/scope:Scoper", ptr %t146, i32 0, i32 40
  %t149 = load i64, ptr %l2, !tbaa !24
  %t152 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc57530578add1ad359c6d87470cc4752(ptr %v0, ptr %t148, i64 %t149)
  store i1 %t152, ptr %l84
  br label %bb50
bb50:
  %t153 = load i1, ptr %l84, !tbaa !21
  br i1 %t153, label %bb51, label %bb52
bb51:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/scope:Scoper", ptr %t154, i32 0, i32 40
  %t157 = load i64, ptr %l2, !tbaa !24
  %t160 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t156, i64 %t157)
  %t161 = extractvalue { i32, ptr } %t160, 1
  %t162 = extractvalue { i32, ptr } %t160, 0
  store i32 %t162, ptr %l90
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb54, label %ok.164, !prof !99
ok.164:
  store ptr %t161, ptr %l89
  br label %bb53
bb52:
  br label %bb58
bb53:
  %t165 = load ptr, ptr %l89, !tbaa !29
  store ptr %t165, ptr %l85, !tbaa !29
  br label %bb56
bb54:
  br label %bb55
bb55:
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr %"compiler/scope:fnRecs", ptr %t166, i32 0, i32 1
  store i1 false, ptr %t168, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  %t169 = load ptr, ptr %l85, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddRecs(ptr %v0, ptr %v1, ptr %v0, ptr %t170, ptr %t171, ptr %t169)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb58:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/scope:Scoper", ptr %t177, i32 0, i32 86
  %t180 = load i64, ptr %l2, !tbaa !24
  %t183 = call { i32, %"compiler/scope:fnRecs" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3afnRecs_3e__Hf28901f23b5d22676a93f0159a8b63c2(ptr %v0, ptr %v0, ptr %t179, i64 %t180)
  %t184 = extractvalue { i32, %"compiler/scope:fnRecs" } %t183, 1
  %t185 = extractvalue { i32, %"compiler/scope:fnRecs" } %t183, 0
  store i32 %t185, ptr %l101
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb60, label %ok.187, !prof !99
ok.187:
  store %"compiler/scope:fnRecs" %t184, ptr %l100
  br label %bb59
bb59:
  %t189 = call %"compiler/scope:fnRecs" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fscope_3afnRecs(ptr %s0, ptr %l100)
  store %"compiler/scope:fnRecs" %t189, ptr %l103
  br label %bb62
bb60:
  br label %bb61
bb61:
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = getelementptr %"compiler/scope:fnRecs", ptr %t190, i32 0, i32 1
  store i1 false, ptr %t192, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb62:
  %t193 = load %"compiler/scope:fnRecs", ptr %l103
  store %"compiler/scope:fnRecs" %t193, ptr %l96
  br label %bb63
bb63:
  %t194 = load %"compiler/scope:fnRecs", ptr %l96
  store %"compiler/scope:fnRecs" %t194, ptr %l8
  %t195 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2emergeRecs(ptr %v1, ptr %s0, ptr %t195, ptr %l8)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l41 = alloca i64
  %l51 = alloca %"compiler/typed:Local"
  %l57 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %l67 = alloca ptr
  %l77 = alloca %"compiler/typed:Local"
  %l79 = alloca i1
  %l80 = alloca i1
  %l81 = alloca ptr
  %l90 = alloca %"compiler/typed:Local"
  %l92 = alloca i1
  %l96 = alloca i64
  %l101 = alloca i64
  %l104 = alloca i1
  %l105 = alloca i1
  %l108 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l155 = alloca ptr
  %l156 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb106
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l27, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t31 = load ptr, ptr %l30, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l30, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 17}
  %t37 = icmp eq i64 %t35, 0
  store i1 %t37, ptr %l31, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l31, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l6, !tbaa !23
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l7, !tbaa !29
  br label %bb12
bb11:
  br label %bb58
bb12:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l6, !tbaa !23
  %t53 = load ptr, ptr %l7, !tbaa !29
  %t57 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eletRegion(ptr %v0, ptr %v1, ptr %t51, i32 %t52, ptr %t53)
  store i64 %t57, ptr %l41
  br label %bb13
bb13:
  %t58 = load i64, ptr %l41, !tbaa !24
  store i64 %t58, ptr %l8, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 25
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb14, label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_94d65e4b75f62e06_97039da03323bd42)
  unreachable
bb15:
  br label %bb16
bb16:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 25
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t69, i32 0, i32 7
  %t73 = load i32, ptr %l6, !tbaa !23
  %t75 = sext i32 %t73 to i64
  %t78 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t72, i64 %t75)
  store %"compiler/typed:Local" %t78, ptr %l51
  br label %bb17
bb17:
  %t79 = getelementptr %"compiler/typed:Local", ptr %l51, i32 0, i32 4
  %t80 = load i32, ptr %t79, !range !{i32 0, i32 7}
  %t82 = trunc i64 6 to i32
  %t83 = icmp eq i32 %t80, %t82
  store i1 %t83, ptr %l9, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l6, !tbaa !23
  %t88 = sext i32 %t86 to i64
  %t91 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisCursorLocal(ptr %v0, ptr %t85, i64 %t88)
  store i1 %t91, ptr %l57
  br label %bb18
bb18:
  %t92 = load i1, ptr %l57, !tbaa !21
  store i1 %t92, ptr %l10, !tbaa !21
  %t93 = load i64, ptr %l8, !tbaa !24
  %t95 = icmp sge i64 %t93, 0
  br i1 %t95, label %bb19, label %bb20
bb19:
  %t97 = load i1, ptr %l9, !tbaa !21
  %t99 = xor i1 %t97, true
  store i1 %t99, ptr %l60, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb21
bb21:
  %t101 = load i1, ptr %l60, !tbaa !21
  br i1 %t101, label %bb22, label %bb23
bb22:
  %t102 = load i1, ptr %l10, !tbaa !21
  %t104 = xor i1 %t102, true
  store i1 %t104, ptr %l63, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb24
bb24:
  %t106 = load i1, ptr %l63, !tbaa !21
  br i1 %t106, label %bb25, label %bb26
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l67, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/scope:Scoper", ptr %t108, i32 0, i32 25
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  br i1 %t113, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb32
bb27:
  call void @__olang_check_failed(ptr @olang_loc_96f6f37c4f8350ed_c50a63a27885a929)
  unreachable
bb28:
  br label %bb29
bb29:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/scope:Scoper", ptr %t115, i32 0, i32 25
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Body", ptr %t118, i32 0, i32 7
  %t122 = load i32, ptr %l6, !tbaa !23
  %t124 = sext i32 %t122 to i64
  %t127 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t121, i64 %t124)
  store %"compiler/typed:Local" %t127, ptr %l77
  br label %bb30
bb30:
  %t128 = getelementptr %"compiler/typed:Local", ptr %l77, i32 0, i32 2
  %t129 = load i32, ptr %t128, !tbaa !23
  %t130 = load ptr, ptr %l67, !tbaa !29
  %t132 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t130, i32 %t129)
  store i1 %t132, ptr %l79
  br label %bb31
bb31:
  %t133 = load i1, ptr %l79, !tbaa !21
  store i1 %t133, ptr %l66, !tbaa !21
  br label %bb32
bb32:
  %t134 = load i1, ptr %l66, !tbaa !21
  br i1 %t134, label %bb33, label %bb34
bb33:
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l81, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/scope:Scoper", ptr %t136, i32 0, i32 25
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  br i1 %t141, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb40
bb35:
  call void @__olang_check_failed(ptr @olang_loc_96f6f37c4f8350ed_c50a63a27885a929)
  unreachable
bb36:
  br label %bb37
bb37:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/scope:Scoper", ptr %t143, i32 0, i32 25
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Body", ptr %t146, i32 0, i32 7
  %t150 = load i64, ptr %l8, !tbaa !24
  %t153 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t149, i64 %t150)
  store %"compiler/typed:Local" %t153, ptr %l90
  br label %bb38
bb38:
  %t154 = getelementptr %"compiler/typed:Local", ptr %l90, i32 0, i32 2
  %t155 = load i32, ptr %t154, !tbaa !23
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t158 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t156, i32 %t155)
  store i1 %t158, ptr %l92
  br label %bb39
bb39:
  %t159 = load i1, ptr %l92, !tbaa !21
  store i1 %t159, ptr %l80, !tbaa !21
  br label %bb40
bb40:
  %t160 = load i1, ptr %l80, !tbaa !21
  br i1 %t160, label %bb41, label %bb42
bb41:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/scope:Scoper", ptr %t161, i32 0, i32 113
  %t164 = load i64, ptr %l8, !tbaa !24
  %t167 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t163, i64 %t164)
  store i64 %t167, ptr %l96
  br label %bb43
bb42:
  br label %bb57
bb43:
  %t168 = load i64, ptr %l96, !tbaa !24
  %t169 = icmp sge i64 %t168, 0
  br i1 %t169, label %bb44, label %bb45
bb44:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/scope:Scoper", ptr %t171, i32 0, i32 113
  %t174 = load i64, ptr %l8, !tbaa !24
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t173, i64 %t174)
  store i64 %t177, ptr %l101
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t178 = load i64, ptr %l101, !tbaa !24
  store i64 %t178, ptr %l8, !tbaa !24
  br label %bb47
bb47:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l8, !tbaa !24
  %t183 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionKind(ptr %v0, ptr %t179, i64 %t180)
  store i1 %t183, ptr %l104
  br label %bb48
bb48:
  %t184 = load i1, ptr %l104, !tbaa !21
  br i1 %t184, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb52
bb50:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i64, ptr %l8, !tbaa !24
  %t189 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisCursorLocal(ptr %v0, ptr %t185, i64 %t186)
  store i1 %t189, ptr %l108
  br label %bb51
bb51:
  %t190 = load i1, ptr %l108, !tbaa !21
  store i1 %t190, ptr %l105, !tbaa !21
  br label %bb52
bb52:
  %t191 = load i1, ptr %l105, !tbaa !21
  br i1 %t191, label %bb53, label %bb54
bb53:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/scope:Scoper", ptr %t192, i32 0, i32 113
  %t195 = load i32, ptr %l6, !tbaa !23
  %t197 = sext i32 %t195 to i64
  %t198 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t194, i64 %t197, i64 %t198)
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb104
bb58:
  %t202 = load ptr, ptr %l5, !tbaa !29
  store ptr %t202, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t203 = load ptr, ptr %l114, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l114, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 3
  store i1 %t209, ptr %l115, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l115, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l5, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l11, !tbaa !29
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l11, !tbaa !29
  %t220 = getelementptr %"compiler/typed:If", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasBlock(ptr %v0, ptr %v1, ptr %t217, ptr %t221)
  br label %bb64
bb64:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l11, !tbaa !29
  %t228 = getelementptr %"compiler/typed:If", ptr %t226, i32 0, i32 2
  %t229 = load ptr, ptr %t228, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasBlock(ptr %v0, ptr %v1, ptr %t225, ptr %t229)
  br label %bb65
bb65:
  br label %bb104
bb66:
  %t232 = load ptr, ptr %l5, !tbaa !29
  store ptr %t232, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t233 = load ptr, ptr %l127, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l127, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 17}
  %t239 = icmp eq i64 %t237, 4
  store i1 %t239, ptr %l128, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l128, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l5, !tbaa !29
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t243, i32 0, i32 1
  %t245 = load ptr, ptr %t244
  store ptr %t245, ptr %l12, !tbaa !29
  %t247 = load ptr, ptr %l5, !tbaa !29
  %t249 = getelementptr { i64, [3 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t249, i32 0, i32 2
  %t251 = load ptr, ptr %t250
  store ptr %t251, ptr %l13, !tbaa !29
  br label %bb71
bb70:
  br label %bb74
bb71:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasBlock(ptr %v0, ptr %v1, ptr %t253, ptr %t254)
  br label %bb72
bb72:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasBlock(ptr %v0, ptr %v1, ptr %t258, ptr %t259)
  br label %bb73
bb73:
  br label %bb104
bb74:
  %t262 = load ptr, ptr %l5, !tbaa !29
  store ptr %t262, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t263 = load ptr, ptr %l140, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb75, label %bb76
bb75:
  %t266 = load ptr, ptr %l140, !tbaa !29
  %t267 = load i64, ptr %t266, !range !{i64 0, i64 17}
  %t269 = icmp eq i64 %t267, 11
  store i1 %t269, ptr %l141, !tbaa !21
  br label %bb76
bb76:
  %t270 = load i1, ptr %l141, !tbaa !21
  br i1 %t270, label %bb77, label %bb78
bb77:
  %t271 = load ptr, ptr %l5, !tbaa !29
  %t273 = getelementptr { i64, [3 x i64] }, ptr %t271, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", ptr }, ptr %t273, i32 0, i32 1
  %t275 = load ptr, ptr %t274
  store ptr %t275, ptr %l14, !tbaa !29
  br label %bb83
bb78:
  %t277 = load ptr, ptr %l5, !tbaa !29
  store ptr %t277, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t278 = load ptr, ptr %l146, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb79, label %bb80
bb79:
  %t281 = load ptr, ptr %l146, !tbaa !29
  %t282 = load i64, ptr %t281, !range !{i64 0, i64 17}
  %t284 = icmp eq i64 %t282, 12
  store i1 %t284, ptr %l147, !tbaa !21
  br label %bb80
bb80:
  %t285 = load i1, ptr %l147, !tbaa !21
  br i1 %t285, label %bb81, label %bb82
bb81:
  %t286 = load ptr, ptr %l5, !tbaa !29
  %t288 = getelementptr { i64, [3 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", ptr }, ptr %t288, i32 0, i32 1
  %t290 = load ptr, ptr %t289
  store ptr %t290, ptr %l14, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasBlock(ptr %v0, ptr %v1, ptr %t292, ptr %t293)
  br label %bb84
bb84:
  br label %bb104
bb85:
  %t297 = load ptr, ptr %l5, !tbaa !29
  store ptr %t297, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t298 = load ptr, ptr %l155, !tbaa !29
  %t299 = icmp ne ptr %t298, null
  br i1 %t299, label %bb86, label %bb87
bb86:
  %t301 = load ptr, ptr %l155, !tbaa !29
  %t302 = load i64, ptr %t301, !range !{i64 0, i64 17}
  %t304 = icmp eq i64 %t302, 13
  store i1 %t304, ptr %l156, !tbaa !21
  br label %bb87
bb87:
  %t305 = load i1, ptr %l156, !tbaa !21
  br i1 %t305, label %bb88, label %bb89
bb88:
  %t306 = load ptr, ptr %l5, !tbaa !29
  %t308 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 1
  %t309 = getelementptr { %"compiler/source:Span", ptr }, ptr %t308, i32 0, i32 1
  %t310 = load ptr, ptr %t309
  store ptr %t310, ptr %l15, !tbaa !29
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load ptr, ptr %l15, !tbaa !29
  %t315 = getelementptr %"compiler/typed:Join", ptr %t313, i32 0, i32 0
  %t316 = load ptr, ptr %t315, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasBlock(ptr %v0, ptr %v1, ptr %t312, ptr %t316)
  br label %bb91
bb91:
  br label %bb104
bb92:
  %t320 = load ptr, ptr %l5, !tbaa !29
  store ptr %t320, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t321 = load ptr, ptr %l165, !tbaa !29
  %t322 = icmp ne ptr %t321, null
  br i1 %t322, label %bb93, label %bb94
bb93:
  %t324 = load ptr, ptr %l165, !tbaa !29
  %t325 = load i64, ptr %t324, !range !{i64 0, i64 17}
  %t327 = icmp eq i64 %t325, 2
  store i1 %t327, ptr %l166, !tbaa !21
  br label %bb94
bb94:
  %t328 = load i1, ptr %l166, !tbaa !21
  br i1 %t328, label %bb95, label %bb96
bb95:
  %t329 = load ptr, ptr %l5, !tbaa !29
  %t331 = getelementptr { i64, [3 x i64] }, ptr %t329, i32 0, i32 1
  %t332 = getelementptr { %"compiler/source:Span", ptr }, ptr %t331, i32 0, i32 1
  %t333 = load ptr, ptr %t332
  store ptr %t333, ptr %l16, !tbaa !29
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasExpr(ptr %v0, ptr %v1, ptr %t335, ptr %t336)
  br label %bb98
bb98:
  br label %bb104
bb99:
  br i1 true, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_e45607aaa9337dcf_7e22bcf5356f305b)
  unreachable
bb104:
  br label %bb105
bb105:
  %t340 = load i64, ptr %l3, !tbaa !24
  %t342 = add i64 %t340, 1
  store i64 %t342, ptr %l3, !tbaa !24
  br label %bb4
bb106:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargExisting(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i64 %a5, { i64, [2 x i64] } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/scope:Val"
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca i1
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca i1
  %l39 = alloca i64
  %l44 = alloca %"compiler/scope:Val"
  %l50 = alloca i1
  %l54 = alloca { i64, [2 x i64] }
  %l57 = alloca { i64, [2 x i64] }
  %l63 = alloca { i64, [2 x i64] }
  %l64 = alloca %"compiler/scope:Val"
  %l67 = alloca i1
  %l68 = alloca { i64, [2 x i64] }
  %l70 = alloca { i64, [2 x i64] }
  %l72 = alloca i1
  %l75 = alloca i1
  %l76 = alloca i1
  %l81 = alloca i1
  %l84 = alloca i1
  %l87 = alloca i1
  %l88 = alloca ptr
  %l90 = alloca i32
  %l91 = alloca i1
  %l92 = alloca i32
  %l95 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i32
  %l100 = alloca i32
  %l103 = alloca i1
  %l107 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i1
  %l117 = alloca i1
  %l118 = alloca i1
  %l122 = alloca i1
  %l124 = alloca i1
  %l128 = alloca i1
  %l141 = alloca i1
  %l143 = alloca i1
  %l145 = alloca i1
  %l149 = alloca %"compiler/scope:Val"
  %rv = alloca %"compiler/scope:Val"
  %t56 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l17, !tbaa !27
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l7, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t16 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %t12, ptr %t13)
  store i1 %t16, ptr %l22
  br label %bb1
bb1:
  %t17 = load i1, ptr %l22, !tbaa !21
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l24, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Call", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t26 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t19, ptr %t23)
  store i64 %t26, ptr %l28
  br label %bb4
bb3:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb6
bb4:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load ptr, ptr %l24, !tbaa !29
  %t29 = load i64, ptr %l28, !tbaa !24
  %t31 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransient(ptr %v0, ptr %t28, i64 %t29, i64 %t27)
  store i1 %t31, ptr %l30
  br label %bb5
bb5:
  %t32 = load i1, ptr %l30, !tbaa !21
  store i1 %t32, ptr %l23, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/scope:Scoper", ptr %t34, i32 0, i32 70
  store i1 true, ptr %t36, !tbaa !21
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = load i64, ptr %l2, !tbaa !24
  %t51 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandArgPart(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t37, ptr %t38, i64 %t39, { i64, ptr } %a3, { i64, ptr } %a4, i64 %a5, { i64, [2 x i64] } %a6)
  store i64 %t51, ptr %l39
  br label %bb10
bb10:
  %t52 = load i64, ptr %l39, !tbaa !24
  store i64 %t52, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l7, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t56
  %t57 = getelementptr { i64, [2 x i64] }, ptr %t56, i32 0, i32 0
  store i64 0, ptr %t57
  %t58 = load { i64, [2 x i64] }, ptr %t56
  %t62 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t53, ptr %t54, { i64, [2 x i64] } %t58)
  store %"compiler/scope:Val" %t62, ptr %l44
  br label %bb11
bb11:
  %t63 = load %"compiler/scope:Val", ptr %l44
  store %"compiler/scope:Val" %t63, ptr %l9
  %t64 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp sge i64 %t64, 0
  br i1 %t66, label %bb12, label %bb13
bb12:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t68, i32 0, i32 105
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb4ab14fd1aa8deeb21095c3402461540(ptr %v0, ptr %t70, i64 %t71)
  store i1 %t74, ptr %l50
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/scope:Scoper", ptr %t75, i32 0, i32 70
  store i1 false, ptr %t77, !tbaa !21
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t82 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %t78, ptr %t79)
  store { i64, [2 x i64] } %t82, ptr %l54
  br label %bb16
bb16:
  %t83 = load { i64, [2 x i64] }, ptr %l54
  store { i64, [2 x i64] } %t83, ptr %l10
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t88 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceRefs(ptr %v0, ptr %v1, ptr %t84, ptr %t85)
  store { i64, [2 x i64] } %t88, ptr %l57
  br label %bb17
bb17:
  %t89 = load { i64, [2 x i64] }, ptr %l57
  store { i64, [2 x i64] } %t89, ptr %l11
  %t90 = load { i64, [2 x i64] }, ptr %l11
  %t92 = extractvalue { i64, [2 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 0
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb18, label %bb19
bb18:
  %t97 = load { i64, [2 x i64] }, ptr %l11
  store { i64, [2 x i64] } %t97, ptr %l10
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t99)
  store { i64, [2 x i64] } %t101, ptr %l63
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t102 = load { i64, [2 x i64] }, ptr %l63
  %t103 = call %"compiler/scope:Val" @compiler_2fscope_2eVal_2eexisting({ i64, [2 x i64] } %t102)
  store %"compiler/scope:Val" %t103, ptr %l64
  br label %bb21
bb21:
  %t104 = load %"compiler/scope:Val", ptr %l64
  store %"compiler/scope:Val" %t104, ptr %l9
  br label %bb22
bb22:
  %t105 = load { i64, [2 x i64] }, ptr %l10
  %t107 = extractvalue { i64, [2 x i64] } %t105, 0
  %t108 = icmp eq i64 %t107, 0
  br i1 %t108, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb26
bb24:
  %t110 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t110, ptr %l68
  %t111 = getelementptr %"compiler/scope:Val", ptr %l9, i32 0, i32 1
  %t112 = load { i64, [2 x i64] }, ptr %t111
  store { i64, [2 x i64] } %t112, ptr %l70
  %t115 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l68, ptr %l70)
  store i1 %t115, ptr %l72
  br label %bb25
bb25:
  %t116 = load i1, ptr %l72, !tbaa !21
  store i1 %t116, ptr %l67, !tbaa !21
  br label %bb26
bb26:
  %t117 = load i1, ptr %l67, !tbaa !21
  br i1 %t117, label %bb27, label %bb28
bb27:
  %t118 = load %"compiler/scope:Val", ptr %l9
  store %"compiler/scope:Val" %t118, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t120 = load { i64, [2 x i64] }, ptr %l10
  %t122 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t120)
  store i1 %t122, ptr %l75
  br label %bb30
bb30:
  %t123 = load i1, ptr %l75, !tbaa !21
  br i1 %t123, label %bb31, label %bb32
bb31:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t126 = load i64, ptr %l2, !tbaa !24
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t132 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandleLent(ptr %v0, ptr %v1, ptr %v1, ptr %t124, ptr %t125, i64 %t126, ptr %t127)
  store i1 %t132, ptr %l81
  br label %bb33
bb32:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb34
bb33:
  %t133 = load i1, ptr %l81, !tbaa !21
  store i1 %t133, ptr %l76, !tbaa !21
  br label %bb34
bb34:
  %t134 = load i1, ptr %l76, !tbaa !21
  store i1 %t134, ptr %l12, !tbaa !21
  %t135 = load { i64, [2 x i64] }, ptr %l11
  %t137 = extractvalue { i64, [2 x i64] } %t135, 0
  %t138 = icmp eq i64 %t137, 0
  br i1 %t138, label %bb35, label %bb36
bb35:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l7, !tbaa !29
  %t144 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elentLoopCopy(ptr %v0, ptr %v1, ptr %t140, ptr %t141)
  store i1 %t144, ptr %l87
  br label %bb37
bb36:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb38
bb37:
  %t145 = load i1, ptr %l87, !tbaa !21
  store i1 %t145, ptr %l84, !tbaa !21
  br label %bb38
bb38:
  %t146 = load i1, ptr %l84, !tbaa !21
  store i1 %t146, ptr %l13, !tbaa !21
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l88, !tbaa !29
  %t148 = load ptr, ptr %l7, !tbaa !29
  %t150 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t148)
  store i32 %t150, ptr %l90
  br label %bb39
bb39:
  %t151 = load ptr, ptr %l88, !tbaa !29
  %t152 = load i32, ptr %l90, !tbaa !23
  %t153 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t151, i32 %t152)
  store i1 %t153, ptr %l91
  br label %bb40
bb40:
  %t154 = load i1, ptr %l91, !tbaa !21
  br i1 %t154, label %bb41, label %bb42
bb41:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/scope:Scoper", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/generic:Program", ptr %t158, i32 0, i32 2
  store ptr %t160, ptr %l95, !tbaa !29
  %t161 = load ptr, ptr %l7, !tbaa !29
  %t163 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t161)
  store i32 %t163, ptr %l97
  br label %bb43
bb42:
  %t164 = load ptr, ptr %l7, !tbaa !29
  %t166 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t164)
  store i32 %t166, ptr %l100
  br label %bb45
bb43:
  %t167 = load ptr, ptr %l95, !tbaa !29
  %t168 = load i32, ptr %l97, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t167, i32 %t168)
  store i32 %t169, ptr %l98
  br label %bb44
bb44:
  %t170 = load i32, ptr %l98, !tbaa !23
  store i32 %t170, ptr %l92, !tbaa !23
  br label %bb46
bb45:
  %t171 = load i32, ptr %l100, !tbaa !23
  store i32 %t171, ptr %l92, !tbaa !23
  br label %bb46
bb46:
  %t172 = load i32, ptr %l92, !tbaa !23
  store i32 %t172, ptr %l14, !tbaa !23
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l14, !tbaa !23
  %t177 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownsUnshared(ptr %v0, ptr %t173, i32 %t174)
  store i1 %t177, ptr %l103
  br label %bb47
bb47:
  %t178 = load i1, ptr %l103, !tbaa !21
  store i1 %t178, ptr %l15, !tbaa !21
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t181 = load i64, ptr %l2, !tbaa !24
  %t185 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeKeepsArg(ptr %v0, ptr %v1, ptr %t179, ptr %t180, i64 %t181)
  store i1 %t185, ptr %l107
  br label %bb48
bb48:
  %t186 = load i1, ptr %l107, !tbaa !21
  br i1 %t186, label %bb49, label %bb50
bb49:
  %t187 = load i1, ptr %l12, !tbaa !21
  %t189 = xor i1 %t187, true
  store i1 %t189, ptr %l108, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb51
bb51:
  %t191 = load i1, ptr %l108, !tbaa !21
  br i1 %t191, label %bb52, label %bb53
bb52:
  %t192 = load i1, ptr %l15, !tbaa !21
  br i1 %t192, label %bb54, label %bb55
bb53:
  br label %bb74
bb54:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb65
bb55:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/scope:Scoper", ptr %t194, i32 0, i32 0
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/generic:Program", ptr %t197, i32 0, i32 2
  %t200 = load i32, ptr %l14, !tbaa !23
  %t203 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t199, i32 %t200)
  store i1 %t203, ptr %l117
  br label %bb56
bb56:
  %t204 = load i1, ptr %l117, !tbaa !21
  br i1 %t204, label %bb57, label %bb58
bb57:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t207 = load i64, ptr %l2, !tbaa !24
  %t211 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeStoresArg(ptr %v0, ptr %v1, ptr %t205, ptr %t206, i64 %t207)
  store i1 %t211, ptr %l122
  br label %bb59
bb58:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb60
bb59:
  %t212 = load i1, ptr %l122, !tbaa !21
  %t213 = xor i1 %t212, true
  store i1 %t213, ptr %l118, !tbaa !21
  br label %bb60
bb60:
  %t215 = load i1, ptr %l118, !tbaa !21
  br i1 %t215, label %bb61, label %bb62
bb61:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t218 = load i64, ptr %l2, !tbaa !24
  %t222 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleePutsArg(ptr %v0, ptr %v1, ptr %t216, ptr %t217, i64 %t218)
  store i1 %t222, ptr %l128
  br label %bb63
bb62:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb64
bb63:
  %t223 = load i1, ptr %l128, !tbaa !21
  %t224 = xor i1 %t223, true
  store i1 %t224, ptr %l124, !tbaa !21
  br label %bb64
bb64:
  %t226 = load i1, ptr %l124, !tbaa !21
  store i1 %t226, ptr %l112, !tbaa !21
  br label %bb65
bb65:
  %t227 = load i1, ptr %l112, !tbaa !21
  br i1 %t227, label %bb66, label %bb67
bb66:
  %t228 = load %"compiler/scope:Val", ptr %l9
  store %"compiler/scope:Val" %t228, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewantPromotion(ptr %v0, ptr %v1, ptr %t230, ptr %t231)
  br label %bb69
bb69:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/scope:Scoper", ptr %t234, i32 0, i32 27
  %t237 = load i1, ptr %t236, !tbaa !21
  br i1 %t237, label %bb70, label %bb71
bb70:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefused(ptr %v0, ptr %v1, ptr %t239, ptr %t240)
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb73
bb73:
  %t243 = load %"compiler/scope:Val", ptr %l9
  store %"compiler/scope:Val" %t243, ptr %rv
  br label %ret
bb74:
  %t245 = load { i64, [2 x i64] }, ptr %l11
  %t247 = extractvalue { i64, [2 x i64] } %t245, 0
  %t248 = icmp eq i64 %t247, 0
  %t250 = xor i1 %t248, true
  br i1 %t250, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb77
bb76:
  %t252 = load i1, ptr %l12, !tbaa !21
  store i1 %t252, ptr %l141, !tbaa !21
  br label %bb77
bb77:
  %t254 = load i1, ptr %l141, !tbaa !21
  br i1 %t254, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb80
bb79:
  %t255 = load i1, ptr %l15, !tbaa !21
  store i1 %t255, ptr %l143, !tbaa !21
  br label %bb80
bb80:
  %t257 = load i1, ptr %l143, !tbaa !21
  br i1 %t257, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb83
bb82:
  %t258 = load i1, ptr %l13, !tbaa !21
  %t260 = xor i1 %t258, true
  store i1 %t260, ptr %l145, !tbaa !21
  br label %bb83
bb83:
  %t262 = load i1, ptr %l145, !tbaa !21
  br i1 %t262, label %bb84, label %bb85
bb84:
  %t263 = load { i64, [2 x i64] }, ptr %l10
  %t265 = call %"compiler/scope:Val" @compiler_2fscope_2eVal_2eexisting({ i64, [2 x i64] } %t263)
  store %"compiler/scope:Val" %t265, ptr %l149
  br label %bb86
bb85:
  br label %bb87
bb86:
  %t266 = load %"compiler/scope:Val", ptr %l149
  store %"compiler/scope:Val" %t266, ptr %rv
  br label %ret
bb87:
  %t267 = load %"compiler/scope:Val", ptr %l9
  store %"compiler/scope:Val" %t267, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %a0, ptr %a1)
  store ptr %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l8, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 3
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = call i64 @compiler_2fscope_2ewholeLocal(ptr %s0, ptr %t23)
  store i64 %t25, ptr %l17
  br label %bb7
bb7:
  %t26 = load i64, ptr %l17, !tbaa !24
  store i64 %t26, ptr %l9, !tbaa !24
  br label %bb20
bb8:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t28 = load ptr, ptr %l18, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 2
  store i1 %t34, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l19, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = call i64 @compiler_2fscope_2ewholeLocal(ptr %s0, ptr %t42)
  store i64 %t44, ptr %l25
  br label %bb14
bb14:
  %t45 = load i64, ptr %l25, !tbaa !24
  store i64 %t45, ptr %l9, !tbaa !24
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_aa04e26a4d7578a7_d714aefedcea6ccb)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t46 = load i64, ptr %l9, !tbaa !24
  store i64 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/scope:placeSlot"
  %l6 = alloca %"compiler/scope:Val"
  %l7 = alloca %"compiler/scope:placeSlot"
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"compiler/scope:Val"
  %l19 = alloca i1
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i1
  %l34 = alloca i32
  %l41 = alloca i1
  %l42 = alloca i1
  %l47 = alloca i1
  %l50 = alloca %"compiler/scope:placeSlot"
  %l51 = alloca ptr
  %l53 = alloca ptr
  %l55 = alloca i1
  %l56 = alloca { i64, [2 x i64] }
  %l59 = alloca { i64, [2 x i64] }
  %l60 = alloca %"compiler/scope:Val"
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l82 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca i32
  %l89 = alloca i1
  %l91 = alloca ptr
  %l93 = alloca ptr
  %l96 = alloca i1
  %l97 = alloca { i64, [2 x i64] }
  %l100 = alloca { i64, [2 x i64] }
  %l102 = alloca %"compiler/scope:Val"
  %l103 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca i32
  %l110 = alloca %"compiler/scope:placeSlot"
  %l116 = alloca i1
  %l125 = alloca ptr
  %l132 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca %"compiler/source:Span"
  %l140 = alloca ptr
  %l142 = alloca i64
  %l143 = alloca ptr
  %l145 = alloca ptr
  %l147 = alloca i1
  %l148 = alloca { i64, [2 x i64] }
  %l151 = alloca { i64, [2 x i64] }
  %l152 = alloca %"compiler/scope:Val"
  %l160 = alloca i64
  %l162 = alloca ptr
  %l164 = alloca i64
  %l168 = alloca i1
  %l172 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca ptr
  %l180 = alloca %"compiler/source:Span"
  %l181 = alloca %"compiler/source:Span"
  %l182 = alloca %"compiler/diagmsg:Msg"
  %l183 = alloca i64
  %l184 = alloca ptr
  %l187 = alloca ptr
  %l188 = alloca i32
  %l191 = alloca i1
  %l195 = alloca i1
  %l199 = alloca i1
  %l200 = alloca ptr
  %l203 = alloca ptr
  %l204 = alloca i32
  %l214 = alloca ptr
  %l216 = alloca %"compiler/source:Span"
  %l217 = alloca %"compiler/source:Span"
  %l222 = alloca ptr
  %l224 = alloca i64
  %l226 = alloca i64
  %l228 = alloca i64
  %l232 = alloca i64
  %l248 = alloca i1
  %l250 = alloca i1
  %l252 = alloca i1
  %l260 = alloca ptr
  %l263 = alloca ptr
  %l264 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t156 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l25, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v1, ptr %t2)
  store i64 %t4, ptr %l27
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l25, !tbaa !29
  %t6 = load i64, ptr %l27, !tbaa !24
  %t7 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisCursorLocal(ptr %v0, ptr %t5, i64 %t6)
  store i1 %t7, ptr %l28
  br label %bb2
bb2:
  %t8 = load i1, ptr %l28, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecursorAssign(ptr %v0, ptr %v1, ptr %v2, ptr %t9, %"compiler/source:Span" %t10, ptr %t11, ptr %t12)
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t17)
  store i32 %t19, ptr %l34
  br label %bb7
bb7:
  %t20 = load i32, ptr %l34, !tbaa !23
  store i32 %t20, ptr %l4, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 57
  %t24 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceOperands(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = call i1 @compiler_2ftyped_2ePartOf(ptr %v1, ptr %t31)
  store i1 %t33, ptr %l41
  br label %bb10
bb10:
  %t34 = load i1, ptr %l41, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l4, !tbaa !23
  %t44 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t44, ptr %l47
  br label %bb13
bb12:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb14
bb13:
  %t45 = load i1, ptr %l47, !tbaa !21
  store i1 %t45, ptr %l42, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l42, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t51 = call %"compiler/scope:placeSlot" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotOf(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  store %"compiler/scope:placeSlot" %t51, ptr %l50
  br label %bb17
bb16:
  br label %bb43
bb17:
  %t52 = load %"compiler/scope:placeSlot", ptr %l50
  store %"compiler/scope:placeSlot" %t52, ptr %l5
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l51, !tbaa !29
  %t54 = load ptr, ptr %l3, !tbaa !29
  store ptr %t54, ptr %l53, !tbaa !29
  %t56 = getelementptr %"compiler/scope:placeSlot", ptr %l5, i32 0, i32 0
  %t57 = load { i64, [2 x i64] }, ptr %t56
  %t59 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t57)
  store i1 %t59, ptr %l55
  br label %bb18
bb18:
  %t60 = load i1, ptr %l55, !tbaa !21
  br i1 %t60, label %bb19, label %bb20
bb19:
  %t61 = getelementptr %"compiler/scope:placeSlot", ptr %l5, i32 0, i32 0
  %t62 = load { i64, [2 x i64] }, ptr %t61
  store { i64, [2 x i64] } %t62, ptr %l56
  br label %bb22
bb20:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t64)
  store { i64, [2 x i64] } %t66, ptr %l59
  br label %bb21
bb21:
  %t67 = load { i64, [2 x i64] }, ptr %l59
  store { i64, [2 x i64] } %t67, ptr %l56
  br label %bb22
bb22:
  %t68 = load ptr, ptr %l51, !tbaa !29
  %t69 = load ptr, ptr %l53, !tbaa !29
  %t70 = load { i64, [2 x i64] }, ptr %l56
  %t71 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v2, ptr %t68, ptr %t69, { i64, [2 x i64] } %t70)
  store %"compiler/scope:Val" %t71, ptr %l60
  br label %bb23
bb23:
  %t72 = load %"compiler/scope:Val", ptr %l60
  store %"compiler/scope:Val" %t72, ptr %l6
  %t73 = getelementptr %"compiler/scope:Val", ptr %l6, i32 0, i32 0
  %t74 = load i32, ptr %t73, !range !{i32 0, i32 5}
  %t76 = trunc i64 3 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/scope:Val", ptr %l6, i32 0, i32 1
  %t81 = load { i64, [2 x i64] }, ptr %t80
  %t82 = getelementptr %"compiler/scope:placeSlot", ptr %l5, i32 0, i32 0
  %t83 = load { i64, [2 x i64] }, ptr %t82
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t85 = getelementptr %"compiler/scope:placeSlot", ptr %l5, i32 0, i32 2
  %t86 = load i64, ptr %t85, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v2, ptr %t79, { i64, [2 x i64] } %t81, { i64, [2 x i64] } %t83, i1 true, ptr %t84, i64 %t86)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t92 = getelementptr %"compiler/scope:Val", ptr %l6, i32 0, i32 0
  %t93 = load i32, ptr %t92, !range !{i32 0, i32 5}
  %t95 = trunc i64 2 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb28, label %bb29
bb28:
  %t98 = getelementptr %"compiler/scope:placeSlot", ptr %l5, i32 0, i32 0
  %t99 = load { i64, [2 x i64] }, ptr %t98
  %t101 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t99)
  store i1 %t101, ptr %l72
  br label %bb30
bb29:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb31
bb30:
  %t102 = load i1, ptr %l72, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l70, !tbaa !21
  br label %bb31
bb31:
  %t105 = load i1, ptr %l70, !tbaa !21
  br i1 %t105, label %bb32, label %bb33
bb32:
  %t106 = getelementptr %"compiler/scope:placeSlot", ptr %l5, i32 0, i32 0
  %t107 = load { i64, [2 x i64] }, ptr %t106
  %t109 = extractvalue { i64, [2 x i64] } %t107, 0
  %t110 = icmp eq i64 %t109, 0
  %t112 = xor i1 %t110, true
  store i1 %t112, ptr %l74, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb34
bb34:
  %t114 = load i1, ptr %l74, !tbaa !21
  br i1 %t114, label %bb35, label %bb36
bb35:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l1
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr %"compiler/scope:placeSlot", ptr %l5, i32 0, i32 0
  %t119 = load { i64, [2 x i64] }, ptr %t118
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efreshIntoUnknown(ptr %v0, ptr %v1, ptr %t115, %"compiler/source:Span" %t116, ptr %t117, { i64, [2 x i64] } %t119)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/scope:Scoper", ptr %t124, i32 0, i32 57
  %t128 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePop__He26954e073d6f40019e862398a9b5f5c(ptr %v0, ptr %s2, ptr %t126)
  %t129 = extractvalue { i32, ptr } %t128, 1
  %t130 = extractvalue { i32, ptr } %t128, 0
  store i32 %t130, ptr %l86
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb40, label %ok.132, !prof !99
ok.132:
  store ptr %t129, ptr %l85
  br label %bb39
bb39:
  %t133 = load ptr, ptr %l85, !tbaa !29
  store ptr %t133, ptr %l82, !tbaa !29
  br label %bb42
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb43:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l4, !tbaa !23
  %t138 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t134, i32 %t135)
  store i1 %t138, ptr %l89
  br label %bb44
bb44:
  %t139 = load i1, ptr %l89, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s6
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l91, !tbaa !29
  %t143 = load ptr, ptr %l3, !tbaa !29
  store ptr %t143, ptr %l93, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l4, !tbaa !23
  %t149 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t145, i32 %t146)
  store i1 %t149, ptr %l96
  br label %bb47
bb46:
  br label %bb57
bb47:
  %t150 = load i1, ptr %l96, !tbaa !21
  br i1 %t150, label %bb48, label %bb49
bb48:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t155 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t151, ptr %t152, i1 false)
  store { i64, [2 x i64] } %t155, ptr %l100
  br label %bb50
bb49:
  store { i64, [2 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 0
  store i64 0, ptr %t157
  %t158 = load { i64, [2 x i64] }, ptr %t156
  store { i64, [2 x i64] } %t158, ptr %l97
  br label %bb51
bb50:
  %t160 = load { i64, [2 x i64] }, ptr %l100
  store { i64, [2 x i64] } %t160, ptr %l97
  br label %bb51
bb51:
  %t161 = load ptr, ptr %l91, !tbaa !29
  %t162 = load ptr, ptr %l93, !tbaa !29
  %t163 = load { i64, [2 x i64] }, ptr %l97
  %t164 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v2, ptr %t161, ptr %t162, { i64, [2 x i64] } %t163)
  store %"compiler/scope:Val" %t164, ptr %l102
  br label %bb52
bb52:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 57
  %t169 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePop__He26954e073d6f40019e862398a9b5f5c(ptr %v0, ptr %s6, ptr %t167)
  %t170 = extractvalue { i32, ptr } %t169, 1
  %t171 = extractvalue { i32, ptr } %t169, 0
  store i32 %t171, ptr %l107
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb54, label %ok.173, !prof !99
ok.173:
  store ptr %t170, ptr %l106
  br label %bb53
bb53:
  %t174 = load ptr, ptr %l106, !tbaa !29
  store ptr %t174, ptr %l103, !tbaa !29
  br label %bb56
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb57:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t179 = call %"compiler/scope:placeSlot" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotOf(ptr %v0, ptr %v1, ptr %t175, ptr %t176)
  store %"compiler/scope:placeSlot" %t179, ptr %l110
  br label %bb58
bb58:
  %t180 = load %"compiler/scope:placeSlot", ptr %l110
  store %"compiler/scope:placeSlot" %t180, ptr %l7
  %t181 = getelementptr %"compiler/scope:placeSlot", ptr %l7, i32 0, i32 0
  %t182 = load { i64, [2 x i64] }, ptr %t181
  store { i64, [2 x i64] } %t182, ptr %l8
  %t184 = getelementptr %"compiler/scope:placeSlot", ptr %l7, i32 0, i32 1
  %t185 = load i1, ptr %t184, !tbaa !21
  store i1 %t185, ptr %l9, !tbaa !21
  %t187 = getelementptr %"compiler/scope:placeSlot", ptr %l7, i32 0, i32 2
  %t188 = load i64, ptr %t187, !tbaa !24
  store i64 %t188, ptr %l10, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i32, ptr %l4, !tbaa !23
  %t194 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t190, i32 %t191)
  store i1 %t194, ptr %l116
  br label %bb59
bb59:
  %t195 = load i1, ptr %l116, !tbaa !21
  br i1 %t195, label %bb60, label %bb61
bb60:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitBorrow(ptr %v0, ptr %v2, ptr %t196, ptr %t197)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/scope:Scoper", ptr %t200, i32 0, i32 136
  %t203 = load i64, ptr %t202, !tbaa !24
  store i64 %t203, ptr %l11, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/scope:Scoper", ptr %t205, i32 0, i32 137
  %t208 = load %"compiler/source:Span", ptr %t207
  store %"compiler/source:Span" %t208, ptr %l12
  %t210 = load ptr, ptr %l3, !tbaa !29
  %t213 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v2, ptr %v2, ptr %t210)
  store ptr %t213, ptr %l125
  br label %bb64
bb64:
  %t214 = load ptr, ptr %l125, !tbaa !29
  store ptr %t214, ptr %l13, !tbaa !29
  %t215 = load ptr, ptr %l13, !tbaa !29
  %t217 = icmp eq ptr %t215, null
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb65, label %bb66
bb65:
  %t221 = load ptr, ptr %l13, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Call", ptr %t221, i32 0, i32 2
  %t224 = load i32, ptr %t223, !tbaa !23
  %t226 = sext i32 %t224 to i64
  store i64 %t226, ptr %l14, !tbaa !24
  %t228 = load ptr, ptr %l0, !tbaa !29
  store ptr %t228, ptr %l132, !tbaa !29
  %t229 = load ptr, ptr %l2, !tbaa !29
  %t231 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t229)
  store %"compiler/source:Span" %t231, ptr %l134
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t232 = load ptr, ptr %l132, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l134
  %t234 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eeqAfter(ptr %v0, ptr %t232, %"compiler/source:Span" %t233)
  store %"compiler/source:Span" %t234, ptr %l135
  br label %bb68
bb68:
  %t235 = load %"compiler/source:Span", ptr %l135
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load i64, ptr %l14, !tbaa !24
  %t240 = getelementptr %"compiler/scope:Scoper", ptr %t236, i32 0, i32 136
  store i64 %t237, ptr %t240, !tbaa !24
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/scope:Scoper", ptr %t241, i32 0, i32 137
  store %"compiler/source:Span" %t235, ptr %t245
  br label %bb69
bb69:
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l140, !tbaa !29
  %t247 = load ptr, ptr %l2, !tbaa !29
  %t249 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v1, ptr %t247)
  store i64 %t249, ptr %l142
  br label %bb70
bb70:
  %t250 = load i64, ptr %l142, !tbaa !24
  %t251 = load ptr, ptr %l140, !tbaa !29
  %t252 = getelementptr %"compiler/scope:Scoper", ptr %t251, i32 0, i32 188
  store i64 %t250, ptr %t252, !tbaa !24
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l143, !tbaa !29
  %t254 = load ptr, ptr %l3, !tbaa !29
  store ptr %t254, ptr %l145, !tbaa !29
  %t256 = load { i64, [2 x i64] }, ptr %l8
  %t258 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t256)
  store i1 %t258, ptr %l147
  br label %bb71
bb71:
  %t259 = load i1, ptr %l147, !tbaa !21
  br i1 %t259, label %bb72, label %bb73
bb72:
  %t260 = load { i64, [2 x i64] }, ptr %l8
  store { i64, [2 x i64] } %t260, ptr %l148
  br label %bb75
bb73:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t262)
  store { i64, [2 x i64] } %t264, ptr %l151
  br label %bb74
bb74:
  %t265 = load { i64, [2 x i64] }, ptr %l151
  store { i64, [2 x i64] } %t265, ptr %l148
  br label %bb75
bb75:
  %t266 = load ptr, ptr %l143, !tbaa !29
  %t267 = load ptr, ptr %l145, !tbaa !29
  %t268 = load { i64, [2 x i64] }, ptr %l148
  %t269 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v2, ptr %t266, ptr %t267, { i64, [2 x i64] } %t268)
  store %"compiler/scope:Val" %t269, ptr %l152
  br label %bb76
bb76:
  %t270 = load %"compiler/scope:Val", ptr %l152
  store %"compiler/scope:Val" %t270, ptr %l16
  %t271 = load i64, ptr %l11, !tbaa !24
  %t273 = load %"compiler/source:Span", ptr %l12
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/scope:Scoper", ptr %t275, i32 0, i32 136
  store i64 %t271, ptr %t279, !tbaa !24
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/scope:Scoper", ptr %t280, i32 0, i32 137
  store %"compiler/source:Span" %t273, ptr %t284
  %t285 = load ptr, ptr %l2, !tbaa !29
  %t287 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v1, ptr %t285)
  store i64 %t287, ptr %l160
  br label %bb77
bb77:
  %t288 = load i64, ptr %l160, !tbaa !24
  %t289 = icmp sge i64 %t288, 0
  br i1 %t289, label %bb78, label %bb79
bb78:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l162, !tbaa !29
  %t292 = load ptr, ptr %l2, !tbaa !29
  %t294 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v1, ptr %t292)
  store i64 %t294, ptr %l164
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t295 = load ptr, ptr %l3, !tbaa !29
  %t296 = load ptr, ptr %l162, !tbaa !29
  %t297 = load i64, ptr %l164, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteLate(ptr %v0, ptr %v2, ptr %t296, i64 %t297, ptr %t295)
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t299 = getelementptr %"compiler/scope:Val", ptr %l16, i32 0, i32 0
  %t300 = load i32, ptr %t299, !range !{i32 0, i32 5}
  %t302 = trunc i64 3 to i32
  %t303 = icmp eq i32 %t300, %t302
  br i1 %t303, label %bb83, label %bb84
bb83:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load ptr, ptr %l2, !tbaa !29
  %t307 = load { i64, [2 x i64] }, ptr %l8
  %t311 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindingUnknown(ptr %v0, ptr %v1, ptr %t305, ptr %t306, { i64, [2 x i64] } %t307)
  store i1 %t311, ptr %l172
  br label %bb85
bb84:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb86
bb85:
  %t312 = load i1, ptr %l172, !tbaa !21
  store i1 %t312, ptr %l168, !tbaa !21
  br label %bb86
bb86:
  %t313 = load i1, ptr %l168, !tbaa !21
  br i1 %t313, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s11
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackPlace(ptr %v0, ptr %v1, ptr %t314, ptr %t315)
  br label %bb89
bb88:
  br label %bb101
bb89:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/scope:Scoper", ptr %t318, i32 0, i32 27
  %t321 = load i1, ptr %t320, !tbaa !21
  br i1 %t321, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s12
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l177, !tbaa !29
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l178, !tbaa !29
  %t325 = load ptr, ptr %l2, !tbaa !29
  %t327 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t325)
  store %"compiler/source:Span" %t327, ptr %l180
  br label %bb92
bb91:
  br label %bb96
bb92:
  %t328 = load ptr, ptr %l178, !tbaa !29
  %t329 = load %"compiler/source:Span", ptr %l180
  %t330 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eeqAfter(ptr %v0, ptr %t328, %"compiler/source:Span" %t329)
  store %"compiler/source:Span" %t330, ptr %l181
  br label %bb93
bb93:
  %t331 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFieldBindingUnknown(ptr %s12)
  store %"compiler/diagmsg:Msg" %t331, ptr %l182
  br label %bb94
bb94:
  %t332 = load ptr, ptr %l177, !tbaa !29
  %t333 = load %"compiler/source:Span", ptr %l181
  %t334 = load %"compiler/diagmsg:Msg", ptr %l182
  %t335 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s12, ptr %t332, %"compiler/source:Span" %t333, %"compiler/diagmsg:Msg" %t334)
  store i64 %t335, ptr %l183
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s12)
  br label %bb96
bb96:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/scope:Scoper", ptr %t336, i32 0, i32 57
  %t340 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePop__He26954e073d6f40019e862398a9b5f5c(ptr %v0, ptr %s11, ptr %t338)
  %t341 = extractvalue { i32, ptr } %t340, 1
  %t342 = extractvalue { i32, ptr } %t340, 0
  store i32 %t342, ptr %l188
  %t343 = icmp ne i32 %t342, 0
  br i1 %t343, label %bb98, label %ok.344, !prof !99
ok.344:
  store ptr %t341, ptr %l187
  br label %bb97
bb97:
  %t345 = load ptr, ptr %l187, !tbaa !29
  store ptr %t345, ptr %l184, !tbaa !29
  br label %bb100
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb101:
  %t346 = getelementptr %"compiler/scope:Val", ptr %l16, i32 0, i32 0
  %t347 = load i32, ptr %t346, !range !{i32 0, i32 5}
  %t349 = trunc i64 3 to i32
  %t350 = icmp eq i32 %t347, %t349
  br i1 %t350, label %bb102, label %bb103
bb102:
  %t352 = load i64, ptr %l10, !tbaa !24
  %t353 = load i64, ptr @G_2ecompiler_2fscope_2eFitGlobal, !tbaa !24
  %t356 = icmp ne i64 %t352, %t353
  store i1 %t356, ptr %l191, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb104
bb104:
  %t358 = load i1, ptr %l191, !tbaa !21
  br i1 %t358, label %bb105, label %bb106
bb105:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load ptr, ptr %l3, !tbaa !29
  %t361 = load { i64, [2 x i64] }, ptr %l8
  %t365 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOutlivesArg(ptr %v0, ptr %v2, ptr %t359, ptr %t360, { i64, [2 x i64] } %t361)
  store i1 %t365, ptr %l199
  br label %bb107
bb106:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb108
bb107:
  %t366 = load i1, ptr %l199, !tbaa !21
  store i1 %t366, ptr %l195, !tbaa !21
  br label %bb108
bb108:
  %t367 = load i1, ptr %l195, !tbaa !21
  br i1 %t367, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s14
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/scope:Scoper", ptr %t368, i32 0, i32 57
  %t372 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePop__He26954e073d6f40019e862398a9b5f5c(ptr %v0, ptr %s14, ptr %t370)
  %t373 = extractvalue { i32, ptr } %t372, 1
  %t374 = extractvalue { i32, ptr } %t372, 0
  store i32 %t374, ptr %l204
  %t375 = icmp ne i32 %t374, 0
  br i1 %t375, label %bb112, label %ok.376, !prof !99
ok.376:
  store ptr %t373, ptr %l203
  br label %bb111
bb110:
  br label %bb115
bb111:
  %t377 = load ptr, ptr %l203, !tbaa !29
  store ptr %t377, ptr %l200, !tbaa !29
  br label %bb114
bb112:
  br label %bb113
bb113:
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb115:
  %t378 = getelementptr %"compiler/scope:Val", ptr %l16, i32 0, i32 0
  %t379 = load i32, ptr %t378, !range !{i32 0, i32 5}
  %t381 = trunc i64 3 to i32
  %t382 = icmp eq i32 %t379, %t381
  br i1 %t382, label %bb116, label %bb117
bb116:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/scope:Scoper", ptr %t384, i32 0, i32 83
  %t387 = load i1, ptr %t386, !tbaa !21
  store i1 %t387, ptr %l19, !tbaa !21
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/scope:Scoper", ptr %t389, i32 0, i32 84
  %t392 = load %"compiler/source:Span", ptr %t391
  store %"compiler/source:Span" %t392, ptr %l20
  %t394 = load i64, ptr %l10, !tbaa !24
  %t395 = load i64, ptr @G_2ecompiler_2fscope_2eFitGlobal, !tbaa !24
  %t398 = icmp ne i64 %t394, %t395
  store i1 %t398, ptr %l21, !tbaa !21
  %t400 = load ptr, ptr %l0, !tbaa !29
  store ptr %t400, ptr %l214, !tbaa !29
  %t401 = load ptr, ptr %l2, !tbaa !29
  %t403 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t401)
  store %"compiler/source:Span" %t403, ptr %l216
  br label %bb118
bb117:
  br label %bb127
bb118:
  %t404 = load ptr, ptr %l214, !tbaa !29
  %t405 = load %"compiler/source:Span", ptr %l216
  %t406 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eeqAfter(ptr %v0, ptr %t404, %"compiler/source:Span" %t405)
  store %"compiler/source:Span" %t406, ptr %l217
  br label %bb119
bb119:
  %t407 = load %"compiler/source:Span", ptr %l217
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load i1, ptr %l21, !tbaa !21
  %t412 = getelementptr %"compiler/scope:Scoper", ptr %t408, i32 0, i32 83
  store i1 %t409, ptr %t412, !tbaa !21
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/scope:Scoper", ptr %t413, i32 0, i32 84
  store %"compiler/source:Span" %t407, ptr %t417
  %t418 = load ptr, ptr %l0, !tbaa !29
  store ptr %t418, ptr %l222, !tbaa !29
  %t419 = load ptr, ptr %l2, !tbaa !29
  %t421 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v1, ptr %t419)
  store i64 %t421, ptr %l224
  br label %bb120
bb120:
  %t422 = load i64, ptr %l224, !tbaa !24
  %t423 = icmp sge i64 %t422, 0
  br i1 %t423, label %bb121, label %bb122
bb121:
  %t425 = load ptr, ptr %l2, !tbaa !29
  %t427 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v1, ptr %t425)
  store i64 %t427, ptr %l228
  br label %bb123
bb122:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load ptr, ptr %l2, !tbaa !29
  %t430 = load { i64, [2 x i64] }, ptr %l8
  %t434 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughLocal(ptr %v0, ptr %v1, ptr %t428, ptr %t429, { i64, [2 x i64] } %t430)
  store i64 %t434, ptr %l232
  br label %bb124
bb123:
  %t435 = load i64, ptr %l228, !tbaa !24
  store i64 %t435, ptr %l226, !tbaa !24
  br label %bb125
bb124:
  %t436 = load i64, ptr %l232, !tbaa !24
  store i64 %t436, ptr %l226, !tbaa !24
  br label %bb125
bb125:
  %t437 = load i64, ptr %l226, !tbaa !24
  %t438 = load ptr, ptr %l222, !tbaa !29
  %t439 = getelementptr %"compiler/scope:Scoper", ptr %t438, i32 0, i32 186
  store i64 %t437, ptr %t439, !tbaa !24
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/scope:Val", ptr %l16, i32 0, i32 1
  %t442 = load { i64, [2 x i64] }, ptr %t441
  %t443 = load { i64, [2 x i64] }, ptr %l8
  %t444 = load i1, ptr %l9, !tbaa !21
  %t445 = load ptr, ptr %l3, !tbaa !29
  %t446 = load i64, ptr %l10, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v2, ptr %t440, { i64, [2 x i64] } %t442, { i64, [2 x i64] } %t443, i1 %t444, ptr %t445, i64 %t446)
  br label %bb126
bb126:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/scope:Scoper", ptr %t453, i32 0, i32 186
  store i64 -1, ptr %t455, !tbaa !24
  %t456 = load i1, ptr %l19, !tbaa !21
  %t458 = load %"compiler/source:Span", ptr %l20
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/scope:Scoper", ptr %t460, i32 0, i32 83
  store i1 %t456, ptr %t464, !tbaa !21
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t469 = getelementptr %"compiler/scope:Scoper", ptr %t465, i32 0, i32 84
  store %"compiler/source:Span" %t458, ptr %t469
  br label %bb127
bb127:
  %t470 = getelementptr %"compiler/scope:Val", ptr %l16, i32 0, i32 0
  %t471 = load i32, ptr %t470, !range !{i32 0, i32 5}
  %t473 = trunc i64 2 to i32
  %t474 = icmp eq i32 %t471, %t473
  br i1 %t474, label %bb128, label %bb129
bb128:
  %t476 = load { i64, [2 x i64] }, ptr %l8
  %t478 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t476)
  store i1 %t478, ptr %l250
  br label %bb130
bb129:
  store i1 false, ptr %l248, !tbaa !21
  br label %bb131
bb130:
  %t479 = load i1, ptr %l250, !tbaa !21
  %t480 = xor i1 %t479, true
  store i1 %t480, ptr %l248, !tbaa !21
  br label %bb131
bb131:
  %t482 = load i1, ptr %l248, !tbaa !21
  br i1 %t482, label %bb132, label %bb133
bb132:
  %t483 = load { i64, [2 x i64] }, ptr %l8
  %t485 = extractvalue { i64, [2 x i64] } %t483, 0
  %t486 = icmp eq i64 %t485, 0
  %t488 = xor i1 %t486, true
  store i1 %t488, ptr %l252, !tbaa !21
  br label %bb134
bb133:
  store i1 false, ptr %l252, !tbaa !21
  br label %bb134
bb134:
  %t490 = load i1, ptr %l252, !tbaa !21
  br i1 %t490, label %bb135, label %bb136
bb135:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load %"compiler/source:Span", ptr %l1
  %t493 = load ptr, ptr %l2, !tbaa !29
  %t494 = load { i64, [2 x i64] }, ptr %l8
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efreshIntoUnknown(ptr %v0, ptr %v1, ptr %t491, %"compiler/source:Span" %t492, ptr %t493, { i64, [2 x i64] } %t494)
  br label %bb137
bb136:
  br label %bb138
bb137:
  br label %bb138
bb138:
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t501 = getelementptr %"compiler/scope:Scoper", ptr %t499, i32 0, i32 57
  %t503 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePop__He26954e073d6f40019e862398a9b5f5c(ptr %v0, ptr %s0, ptr %t501)
  %t504 = extractvalue { i32, ptr } %t503, 1
  %t505 = extractvalue { i32, ptr } %t503, 0
  store i32 %t505, ptr %l264
  %t506 = icmp ne i32 %t505, 0
  br i1 %t506, label %bb140, label %ok.507, !prof !99
ok.507:
  store ptr %t504, ptr %l263
  br label %bb139
bb139:
  %t508 = load ptr, ptr %l263, !tbaa !29
  store ptr %t508, ptr %l260, !tbaa !29
  br label %bb142
bb140:
  br label %bb141
bb141:
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eatomTerm(ptr %v0, ptr %a0, %"compiler/scope:verAtom" %a1) #0 {
entry:
  %l1 = alloca %"compiler/scope:verAtom"
  %l2 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l27 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t13 = alloca { i64, [2 x i64] }, align 8
  %t26 = alloca { i64, [2 x i64] }, align 8
  %t37 = alloca { i64, [2 x i64] }, align 8
  %t49 = alloca { i64, [2 x i64] }, align 8
  %t68 = alloca { i64, [2 x i64] }, align 8
  store %"compiler/scope:verAtom" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/scope:verAtom", ptr %l1, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  store i64 %t2, ptr %l2, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t6 = icmp eq i64 %t4, 1
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t8 = getelementptr %"compiler/scope:verAtom", ptr %l1, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = trunc i64 %t9 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 1, ptr %t14
  %t16 = insertvalue { i32 } undef, i32 %t11, 0
  %t17 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 1
  store { i32 } %t16, ptr %t17
  %t18 = load { i64, [2 x i64] }, ptr %t13
  store { i64, [2 x i64] } %t18, ptr %l4
  br label %bb26
bb4:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = icmp eq i64 %t20, 2
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/scope:verAtom", ptr %l1, i32 0, i32 1
  %t25 = load i64, ptr %t24, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 0
  store i64 2, ptr %t27
  %t29 = insertvalue { i64 } undef, i64 %t25, 0
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  store { i64 } %t29, ptr %t30
  %t31 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t31, ptr %l4
  br label %bb26
bb8:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = icmp eq i64 %t33, 3
  br i1 %t35, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, [2 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 0
  store i64 3, ptr %t38
  %t39 = load { i64, [2 x i64] }, ptr %t37
  store { i64, [2 x i64] } %t39, ptr %l4
  br label %bb26
bb12:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t43 = icmp eq i64 %t41, 4
  br i1 %t43, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t45 = getelementptr %"compiler/scope:verAtom", ptr %l1, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = getelementptr %"compiler/scope:verAtom", ptr %l1, i32 0, i32 2
  %t48 = load i64, ptr %t47, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [2 x i64] }, ptr %t49, i32 0, i32 0
  store i64 4, ptr %t50
  %t52 = insertvalue { i64, i64 } undef, i64 %t46, 0
  %t54 = insertvalue { i64, i64 } %t52, i64 %t48, 1
  %t55 = getelementptr { i64, [2 x i64] }, ptr %t49, i32 0, i32 1
  store { i64, i64 } %t54, ptr %t55
  %t56 = load { i64, [2 x i64] }, ptr %t49
  store { i64, [2 x i64] } %t56, ptr %l4
  br label %bb26
bb16:
  %t58 = load i64, ptr %l2, !tbaa !24
  %t60 = icmp eq i64 %t58, 6
  br i1 %t60, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t63 = load %"compiler/scope:verAtom", ptr %l1
  %t66 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunderOf(ptr %v0, ptr %a0, %"compiler/scope:verAtom" %t63)
  store { i64, [2 x i64] } %t66, ptr %l27
  br label %bb20
bb20:
  %t67 = load { i64, [2 x i64] }, ptr %l27
  store { i64, [2 x i64] } %t67, ptr %l4
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store { i64, [2 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [2 x i64] }, ptr %t68, i32 0, i32 0
  store i64 6, ptr %t69
  %t70 = load { i64, [2 x i64] }, ptr %t68
  store { i64, [2 x i64] } %t70, ptr %l4
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_707d6e13efba424b_e32702988c40a9af)
  unreachable
bb26:
  %t72 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindingArg(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/scope:rel"
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l13 = alloca i1
  %l16 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca i1
  %l27 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l40 = alloca i64
  %l42 = alloca i64
  %l47 = alloca %"compiler/scope:rel"
  %l50 = alloca i1
  %l63 = alloca i1
  %l64 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t1, ptr %l9, !tbaa !27
  %t2 = load i64, ptr %l2, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i64, ptr %t5, i64 %t2
  %t7 = load i64, ptr %t6, !tbaa !34
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  store i1 %t13, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l13, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 6
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t18, i64 %t19)
  store ptr %t22, ptr %l20
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t25 = getelementptr %"compiler/scope:summary", ptr %t23, i32 0, i32 17
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/scope:Scoper", ptr %t28, i32 0, i32 6
  %t31 = load i64, ptr %l1, !tbaa !24
  %t34 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store ptr %t34, ptr %l27
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l27, !tbaa !29
  %t37 = getelementptr %"compiler/scope:summary", ptr %t35, i32 0, i32 18
  %t38 = load i1, ptr %t37, !tbaa !21
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l23, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t43 = load i1, ptr %l16, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i64, ptr %t48, i64 %t45
  %t50 = load i64, ptr %t49, !tbaa !34
  store i64 %t50, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/scope:Scoper", ptr %t52, i32 0, i32 6
  %t55 = load i64, ptr %l1, !tbaa !24
  %t58 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t54, i64 %t55)
  store ptr %t58, ptr %l37
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l37, !tbaa !29
  %t61 = getelementptr %"compiler/scope:summary", ptr %t59, i32 0, i32 0
  store ptr %t61, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  %t63 = load i64, ptr %l5, !tbaa !24
  store i64 %t63, ptr %l40, !tbaa !24
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l42
  br label %bb17
bb17:
  %t67 = load i64, ptr %l40, !tbaa !24
  %t68 = load i64, ptr %l42, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb18, label %bb19
bb18:
  br label %bb44
bb19:
  br label %bb20
bb20:
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t74 = load i64, ptr %l5, !tbaa !24
  %t77 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t73, i64 %t74)
  store %"compiler/scope:rel" %t77, ptr %l47
  br label %bb21
bb21:
  %t78 = load %"compiler/scope:rel", ptr %l47
  store %"compiler/scope:rel" %t78, ptr %l6
  %t79 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 0
  %t80 = load { i64, [2 x i64] }, ptr %t79
  %t82 = extractvalue { i64, [2 x i64] } %t80, 0
  %t83 = icmp eq i64 %t82, 2
  br i1 %t83, label %bb22, label %bb23
bb22:
  %t85 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 0
  %t86 = getelementptr { i64, [2 x i64] }, ptr %t85, i32 0, i32 1
  %t87 = getelementptr { i64 }, ptr %t86, i32 0, i32 0
  %t88 = load i64, ptr %t87
  %t89 = load i64, ptr %l2, !tbaa !24
  %t92 = icmp eq i64 %t88, %t89
  store i1 %t92, ptr %l50, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb24
bb24:
  %t94 = load i1, ptr %l50, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb25, label %bb26
bb25:
  br label %bb43
bb26:
  br label %bb27
bb27:
  %t97 = getelementptr %"compiler/scope:rel", ptr %l6, i32 0, i32 1
  %t98 = load { i64, [2 x i64] }, ptr %t97
  store { i64, [2 x i64] } %t98, ptr %l7
  %t100 = load { i64, [2 x i64] }, ptr %l7
  %t102 = extractvalue { i64, [2 x i64] } %t100, 0
  %t103 = icmp eq i64 %t102, 2
  br i1 %t103, label %bb28, label %bb29
bb28:
  %t105 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t106 = getelementptr { i64 }, ptr %t105, i32 0, i32 0
  %t107 = load i64, ptr %t106
  store i64 %t107, ptr %l8, !tbaa !24
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t109 = load i64, ptr %l8, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t115 = icmp slt i64 %t109, %t112
  br i1 %t115, label %bb31, label %bb32
bb31:
  %t117 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t117, ptr %l64, !tbaa !27
  %t118 = load i64, ptr %l8, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i64, ptr %t121, i64 %t118
  %t123 = load i64, ptr %t122, !tbaa !34
  %t125 = icmp sge i64 %t123, 0
  store i1 %t125, ptr %l63, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb33
bb33:
  %t127 = load i1, ptr %l63, !tbaa !21
  br i1 %t127, label %bb34, label %bb35
bb34:
  %t128 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t128, ptr %l68, !tbaa !27
  %t129 = load i64, ptr %l8, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i64, ptr %t132, i64 %t129
  %t134 = load i64, ptr %t133, !tbaa !34
  store i64 %t134, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_e450486563db1063_185cf2ae254ae0bf)
  unreachable
bb42:
  br label %bb43
bb43:
  %t136 = load i64, ptr %l5, !tbaa !24
  %t138 = add i64 %t136, 1
  store i64 %t138, ptr %l5, !tbaa !24
  br label %bb16
bb44:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 34
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Block", ptr %t8, i32 0, i32 0
  %t11 = load i32, ptr %t10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t7, i32 %t11)
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Block", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v1, ptr %t14, { i64, ptr } %t18)
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 34
  %t25 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t23)
  %t26 = extractvalue { i32, i32 } %t25, 1
  %t27 = extractvalue { i32, i32 } %t25, 0
  store i32 %t27, ptr %l15
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb7, label %ok.29, !prof !99
ok.29:
  store i32 %t26, ptr %l14
  br label %bb6
bb6:
  %t30 = load i32, ptr %l14, !tbaa !23
  store i32 %t30, ptr %l11, !tbaa !23
  br label %bb9
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebndBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebndStmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebndTask(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i1
  %l38 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %t1)
  store ptr %t4, ptr %l11
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  store ptr %t5, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = load i64, ptr @G_2ecompiler_2fscope_2eBndTask, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebndExpr(ptr %v0, ptr %v1, ptr %t10, ptr %t11, i64 %t13)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %ret
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Call", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l20, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 5}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr { i64, [3 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { ptr }, ptr %t33, i32 0, i32 0
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t40 = load i64, ptr @G_2ecompiler_2fscope_2eBndTask, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebndExpr(ptr %v0, ptr %v1, ptr %t37, ptr %t38, i64 %t40)
  br label %bb11
bb11:
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_2b4fe6e94d6a7479_c916946ab1cc6fcd)
  unreachable
bb17:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Call", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  store i64 %t51, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb19, label %bb20
bb19:
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t61, ptr %l38, !tbaa !27
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i64, ptr @G_2ecompiler_2fscope_2eBndTask, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebndExpr(ptr %v0, ptr %v1, ptr %t69, ptr %t67, i64 %t72)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l6, !tbaa !24
  br label %bb18
bb24:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l3, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_1cbcbb68212d18c9_a0b41c71999484fd)
  unreachable
bb11:
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildSite(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [2 x i64] }
  %l7 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, [2 x i64] }
  %l19 = alloca { i64, [2 x i64] }
  %l21 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca { i64, [1 x i64] }
  %l27 = alloca ptr
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 30
  %t11 = getelementptr %"compiler/typed:Plan", ptr %t10, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t17 = icmp sge i64 %t7, %t14
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l7, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = load { i64, [2 x i64] }, ptr %l2
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t20)
  store i1 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i1, ptr %l15, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t24, ptr %l16
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t26)
  store { i64, [2 x i64] } %t28, ptr %l19
  br label %bb10
bb10:
  %t29 = load { i64, [2 x i64] }, ptr %l19
  store { i64, [2 x i64] } %t29, ptr %l16
  br label %bb11
bb11:
  %t30 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t30, ptr %l4
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 30
  %t34 = getelementptr %"compiler/typed:Plan", ptr %t33, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l21, !tbaa !27
  %t36 = load i32, ptr %l1, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l23, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [2 x i64] }, ptr %l4
  %t43 = call { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %t39, { i64, [2 x i64] } %t40)
  store { i64, [1 x i64] } %t43, ptr %l26
  br label %bb12
bb12:
  %t44 = load { i64, [1 x i64] }, ptr %l26
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, [1 x i64] }, ptr %t47, i64 %t45
  store { i64, [1 x i64] } %t44, ptr %t48
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l27, !tbaa !29
  %t50 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t50, ptr %l28
  %t51 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t51, ptr %l29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/scope:Scoper", ptr %t52, i32 0, i32 25
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_3e89652ff7706bd0_4686e7e94f816f94)
  unreachable
bb14:
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 25
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 3
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = load %"compiler/source:Span", ptr %l3
  %t68 = load ptr, ptr %l27, !tbaa !29
  %t69 = load { i64, [2 x i64] }, ptr %l28
  %t70 = load %"compiler/source:Span", ptr %l29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t68, { i64, [2 x i64] } %t69, %"compiler/source:Span" %t70, i64 %t66, %"compiler/source:Span" %t67)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsIntoSet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, i64 %a4, { i64, [2 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l25 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [2 x i64] } %a5, 0
  %t4 = icmp eq i64 %t3, 5
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_ae19eb3dd0d17d29_4ac15fb0aa0c6205)
  unreachable
bb9:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l11
  br label %bb10
bb10:
  %t12 = load i1, ptr %l11, !tbaa !21
  %t13 = xor i1 %t12, true
  br i1 %t13, label %bb11, label %bb12
bb11:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l15
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t20 = load i1, ptr %l15, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
bb14:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsStores(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l18
  br label %bb15
bb15:
  %t26 = load i1, ptr %l18, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t35, i32 %t36)
  store i64 %t39, ptr %l25
  br label %bb19
bb19:
  %t40 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t41 = load i64, ptr %l25, !tbaa !24
  %t43 = and i64 %t41, %t40
  %t45 = icmp ne i64 %t43, 0
  br i1 %t45, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l30, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l31, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Call", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t57 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t50, ptr %t54)
  store i64 %t57, ptr %l35
  br label %bb23
bb23:
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t60 = load ptr, ptr %l31, !tbaa !29
  %t61 = load i64, ptr %l35, !tbaa !24
  %t63 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeBuilds(ptr %v0, ptr %v1, ptr %t59, ptr %t60, i64 %t61, i64 %a4)
  store i1 %t63, ptr %l37
  br label %bb24
bb24:
  %t64 = load i1, ptr %l37, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsOwn(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 42
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, ptr } %t12, 1
  %t14 = extractvalue { i32, ptr } %t12, 0
  store i32 %t14, ptr %l11
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  store ptr %t13, ptr %l10
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l10, !tbaa !29
  store ptr %t17, ptr %l6, !tbaa !29
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  %t19 = load ptr, ptr %l6, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorBuilt(ptr %v0, ptr %v0, ptr %t20, ptr %t19)
  store i1 %t24, ptr %l15
  br label %bb8
bb8:
  %t25 = load i1, ptr %l15, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallBuilds(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i1
  %l12 = alloca i32
  %l21 = alloca i64
  %l29 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t1, i32 %a2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t10, ptr %a1)
  store i32 %t14, ptr %l12
  br label %bb5
bb5:
  %t15 = load i32, ptr %l12, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = load i32, ptr %l3, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t20 = icmp eq i32 %t16, %t17
  br i1 %t20, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t28, i32 %t29)
  store i64 %t32, ptr %l21
  br label %bb9
bb9:
  %t33 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t34 = load i64, ptr %l21, !tbaa !24
  %t36 = icmp eq i64 %t34, %t33
  br i1 %t36, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/scope:Scoper", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t44, i32 %t45, i64 0)
  store i64 %t48, ptr %l29
  br label %bb13
bb13:
  %t49 = load i64, ptr %l29, !tbaa !24
  %t52 = icmp slt i64 %t49, 0
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 1
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 1
  %t33 = load { i64, [2 x i64] }, ptr %t32
  store { i64, [2 x i64] } %t33, ptr %l4
  %t35 = load { i64, [2 x i64] }, ptr %l4
  %t37 = extractvalue { i64, [2 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 0
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t41 = getelementptr { i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l5, !tbaa !24
  br label %bb9
bb8:
  br label %bb13
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l27, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l29, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t65 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l33
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l29, !tbaa !29
  %t67 = load i64, ptr %l33, !tbaa !24
  %t68 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t66, i64 %t67)
  store ptr %t68, ptr %l34
  br label %bb11
bb11:
  %t69 = load ptr, ptr %l34, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Func", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %t71, !tbaa !23
  %t73 = load ptr, ptr %l27, !tbaa !29
  %t75 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t73, i32 %t72)
  store { i64, ptr } %t75, ptr %l37
  br label %bb12
bb12:
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 1
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t79 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t77, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t81, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_a571972fdacfaed1_c7933b0216b7b5ad)
  unreachable
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_9f9bf081c1674640_32724a584f79d5fc)
  unreachable
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t83, ptr %l40, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l41, !tbaa !24
  %t86 = load i64, ptr %l41, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l42, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l41, !tbaa !24
  %t96 = mul i64 %t95, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t92, ptr %t94, i64 %t96, i1 false)
  %t97 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t97, ptr %l40, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i1
  %l9 = alloca i1
  %l13 = alloca %"compiler/scope:Val"
  %l18 = alloca ptr
  %l19 = alloca i1
  %l34 = alloca i1
  %l39 = alloca %"compiler/source:Span"
  %l53 = alloca %"compiler/scope:Val"
  %l69 = alloca i1
  %l73 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l91 = alloca i64
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca %"compiler/diagmsg:Msg"
  %l96 = alloca i64
  %l97 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca %"compiler/diagmsg:Msg"
  %l102 = alloca i64
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t2 = load ptr, ptr %l18, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l18, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l19, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l19, !tbaa !21
  store i1 %t9, ptr %l4, !tbaa !21
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i1, ptr %l2, !tbaa !21
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 73
  store i1 %t13, ptr %t16, !tbaa !21
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 76
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l5, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 77
  %t25 = load %"compiler/source:Span", ptr %t24
  store %"compiler/source:Span" %t25, ptr %l6
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 78
  %t30 = load { i64, [2 x i64] }, ptr %t29
  store { i64, [2 x i64] } %t30, ptr %l7
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/scope:Scoper", ptr %t32, i32 0, i32 79
  %t35 = load i1, ptr %t34, !tbaa !21
  store i1 %t35, ptr %l8, !tbaa !21
  %t37 = load i1, ptr %l2, !tbaa !21
  br i1 %t37, label %bb6, label %bb7
bb6:
  %t39 = load i1, ptr %l4, !tbaa !21
  %t41 = xor i1 %t39, true
  store i1 %t41, ptr %l34, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb8
bb8:
  %t43 = load i1, ptr %l34, !tbaa !21
  br i1 %t43, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l9, !tbaa !21
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t48 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  store %"compiler/source:Span" %t48, ptr %l39
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t49 = load %"compiler/source:Span", ptr %l39
  %t50 = load { i64, [2 x i64] }, ptr %l3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i1, ptr %l9, !tbaa !21
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t52, i32 0, i32 76
  store i1 %t53, ptr %t56, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t57, i32 0, i32 77
  store %"compiler/source:Span" %t49, ptr %t61
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 78
  store { i64, [2 x i64] } %t50, ptr %t66
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/scope:Scoper", ptr %t67, i32 0, i32 79
  store i1 true, ptr %t71, !tbaa !21
  br label %bb12
bb12:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = load { i64, [2 x i64] }, ptr %l3
  %t79 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t72, ptr %t73, { i64, [2 x i64] } %t75)
  store %"compiler/scope:Val" %t79, ptr %l53
  br label %bb13
bb13:
  %t80 = load %"compiler/scope:Val", ptr %l53
  store %"compiler/scope:Val" %t80, ptr %l13
  %t81 = load i1, ptr %l5, !tbaa !21
  %t83 = load %"compiler/source:Span", ptr %l6
  %t85 = load { i64, [2 x i64] }, ptr %l7
  %t87 = load i1, ptr %l8, !tbaa !21
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/scope:Scoper", ptr %t89, i32 0, i32 76
  store i1 %t81, ptr %t93, !tbaa !21
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/scope:Scoper", ptr %t94, i32 0, i32 77
  store %"compiler/source:Span" %t83, ptr %t98
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/scope:Scoper", ptr %t99, i32 0, i32 78
  store { i64, [2 x i64] } %t85, ptr %t103
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/scope:Scoper", ptr %t104, i32 0, i32 79
  store i1 %t87, ptr %t108, !tbaa !21
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/scope:Scoper", ptr %t109, i32 0, i32 73
  store i1 false, ptr %t111, !tbaa !21
  %t112 = load i1, ptr %l2, !tbaa !21
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb16
bb15:
  %t116 = getelementptr %"compiler/scope:Val", ptr %l13, i32 0, i32 0
  %t117 = load i32, ptr %t116, !range !{i32 0, i32 5}
  %t119 = trunc i64 3 to i32
  %t120 = icmp eq i32 %t117, %t119
  %t122 = xor i1 %t120, true
  store i1 %t122, ptr %l69, !tbaa !21
  br label %bb16
bb16:
  %t124 = load i1, ptr %l69, !tbaa !21
  br i1 %t124, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb20
bb18:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/scope:Val", ptr %l13, i32 0, i32 1
  %t127 = load { i64, [2 x i64] }, ptr %t126
  %t128 = load { i64, [2 x i64] }, ptr %l3
  %t132 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastsUntil(ptr %v0, ptr %t125, { i64, [2 x i64] } %t127, { i64, [2 x i64] } %t128)
  store i1 %t132, ptr %l77
  br label %bb19
bb19:
  %t133 = load i1, ptr %l77, !tbaa !21
  store i1 %t133, ptr %l73, !tbaa !21
  br label %bb20
bb20:
  %t134 = load i1, ptr %l73, !tbaa !21
  br i1 %t134, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb23
bb22:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/scope:Scoper", ptr %t135, i32 0, i32 27
  %t138 = load i1, ptr %t137, !tbaa !21
  %t140 = xor i1 %t138, true
  store i1 %t140, ptr %l78, !tbaa !21
  br label %bb23
bb23:
  %t142 = load i1, ptr %l78, !tbaa !21
  br i1 %t142, label %bb24, label %bb25
bb24:
  br label %ret
bb25:
  br label %bb26
bb26:
  %t143 = load i1, ptr %l4, !tbaa !21
  br i1 %t143, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l83, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l84, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/scope:Scoper", ptr %t147, i32 0, i32 25
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb29, label %bb30
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l97, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t159 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t155, ptr %t156)
  store %"compiler/source:Span" %t159, ptr %l100
  br label %bb36
bb29:
  call void @__olang_check_failed(ptr @olang_loc_9e4942b53b152c4c_8e08edd23a0a3ef8)
  unreachable
bb30:
  br label %bb31
bb31:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/scope:Scoper", ptr %t160, i32 0, i32 25
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Body", ptr %t163, i32 0, i32 3
  %t167 = load i64, ptr %t166, !tbaa !24
  store i64 %t167, ptr %l91, !tbaa !24
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t168)
  store %"compiler/source:Span" %t170, ptr %l93
  br label %bb32
bb32:
  %t171 = load ptr, ptr %l84, !tbaa !29
  %t172 = load i64, ptr %l91, !tbaa !24
  %t173 = load %"compiler/source:Span", ptr %l93
  %t174 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t171, i64 %t172, %"compiler/source:Span" %t173)
  store %"compiler/source:Span" %t174, ptr %l94
  br label %bb33
bb33:
  %t175 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnCaptureTooShort(ptr %s4)
  store %"compiler/diagmsg:Msg" %t175, ptr %l95
  br label %bb34
bb34:
  %t176 = load ptr, ptr %l83, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l94
  %t178 = load %"compiler/diagmsg:Msg", ptr %l95
  %t179 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s4, ptr %t176, %"compiler/source:Span" %t177, %"compiler/diagmsg:Msg" %t178)
  store i64 %t179, ptr %l96
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb36:
  %t180 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %s5)
  store %"compiler/diagmsg:Msg" %t180, ptr %l101
  br label %bb37
bb37:
  %t181 = load ptr, ptr %l97, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l100
  %t183 = load %"compiler/diagmsg:Msg", ptr %l101
  %t184 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s5, ptr %t181, %"compiler/source:Span" %t182, %"compiler/diagmsg:Msg" %t183)
  store i64 %t184, ptr %l102
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"compiler/scope:rel"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca %"compiler/scope:rel"
  %l40 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l61 = alloca i64
  %l68 = alloca i64
  %l75 = alloca { i64, ptr }
  %l79 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i64
  %l108 = alloca i64
  %l112 = alloca i1
  %l119 = alloca i1
  %l123 = alloca i1
  %l127 = alloca i64
  %l139 = alloca i64
  %l142 = alloca i64
  %l166 = alloca i64
  %l170 = alloca i1
  %l174 = alloca i1
  %l177 = alloca i1
  %l181 = alloca i1
  %l191 = alloca i64
  %l194 = alloca i1
  %l198 = alloca ptr
  %l202 = alloca i1
  %l206 = alloca ptr
  %l214 = alloca { i64, ptr }
  %l220 = alloca i64
  %l223 = alloca i64
  %l231 = alloca i64
  %l234 = alloca i64
  %l259 = alloca ptr
  %l262 = alloca i64
  %l264 = alloca i64
  %l269 = alloca %"compiler/scope:rel"
  %l272 = alloca i1
  %l276 = alloca i1
  %l278 = alloca i1
  %l281 = alloca i1
  %l293 = alloca ptr
  %l296 = alloca i64
  %l298 = alloca i64
  %l303 = alloca %"compiler/scope:rel"
  %l306 = alloca i1
  %l307 = alloca i1
  %l309 = alloca i1
  %l312 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l40
  br label %bb1
bb1:
  %t6 = load i32, ptr %l40, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Call", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l4, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  store ptr %t19, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t20 = load ptr, ptr %l47, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l47, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 5}
  %t26 = icmp eq i64 %t24, 1
  store i1 %t26, ptr %l48, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l48, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t28 = load ptr, ptr %l4, !tbaa !29
  store ptr %t28, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t29 = load ptr, ptr %l51, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l51, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 5}
  %t35 = icmp eq i64 %t33, 4
  store i1 %t35, ptr %l52, !tbaa !21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l52, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e7f077513292cd77_7cc56e961d13405b)
  unreachable
bb19:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l5, !tbaa !29
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t46 = load i32, ptr %l3, !tbaa !23
  %t49 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t45, i32 %t46)
  store i64 %t49, ptr %l61
  br label %bb20
bb20:
  %t50 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t51 = load i64, ptr %l61, !tbaa !24
  %t53 = icmp eq i64 %t51, %t50
  br i1 %t53, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t57 = load i32, ptr %l3, !tbaa !23
  %t58 = load i64, ptr %l2, !tbaa !24
  %t62 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t56, i32 %t57, i64 %t58)
  store i64 %t62, ptr %l68
  br label %bb24
bb24:
  %t63 = load i64, ptr %l68, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t68 = icmp eq i64 %t64, %t65
  br i1 %t68, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t72 = load i32, ptr %l3, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t71, i32 %t72)
  store { i64, ptr } %t75, ptr %l75
  br label %bb28
bb28:
  %t76 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb29, label %bb30
bb29:
  %t83 = load i64, ptr %l7, !tbaa !24
  store i64 %t83, ptr %l79, !tbaa !24
  br label %bb31
bb30:
  store i64 1, ptr %l79, !tbaa !24
  br label %bb31
bb31:
  %t85 = load i64, ptr %l79, !tbaa !24
  store i64 %t85, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb32, label %bb33
bb32:
  %t92 = load i64, ptr %l10, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb37
bb34:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l8, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l10, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l87, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb36
bb36:
  %t112 = load i64, ptr %l87, !tbaa !24
  store i64 %t112, ptr %l84, !tbaa !24
  br label %bb37
bb37:
  %t113 = load i64, ptr %l84, !tbaa !24
  store i64 %t113, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  %t114 = load i64, ptr %l12, !tbaa !24
  %t115 = load i64, ptr %l11, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb39, label %bb40
bb39:
  br label %bb60
bb40:
  br label %bb41
bb41:
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l12, !tbaa !24
  %t124 = load i64, ptr %l10, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  %t132 = load ptr, ptr %l5, !tbaa !29
  %t133 = load i32, ptr %l3, !tbaa !23
  %t138 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t132, i32 %t133, i64 %t130)
  store i64 %t138, ptr %l108
  br label %bb42
bb42:
  %t139 = load i64, ptr %l108, !tbaa !24
  store i64 %t139, ptr %l14, !tbaa !24
  %t140 = load i64, ptr %l14, !tbaa !24
  %t141 = load i64, ptr %l2, !tbaa !24
  %t144 = icmp eq i64 %t140, %t141
  br i1 %t144, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb45
bb44:
  %t146 = load i64, ptr %l14, !tbaa !24
  %t147 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t150 = icmp eq i64 %t146, %t147
  store i1 %t150, ptr %l112, !tbaa !21
  br label %bb45
bb45:
  %t152 = load i1, ptr %l112, !tbaa !21
  br i1 %t152, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t154 = load i64, ptr %l14, !tbaa !24
  %t156 = icmp sge i64 %t154, 0
  br i1 %t156, label %bb49, label %bb50
bb49:
  %t158 = load i64, ptr %l6, !tbaa !24
  %t159 = load i64, ptr %l14, !tbaa !24
  %t162 = icmp eq i64 %t158, %t159
  br i1 %t162, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb55
bb51:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb54
bb52:
  %t164 = load ptr, ptr %l5, !tbaa !29
  %t165 = load i32, ptr %l3, !tbaa !23
  %t166 = load i64, ptr %l14, !tbaa !24
  %t170 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t164, i32 %t165, i64 %t166)
  store i64 %t170, ptr %l127
  br label %bb53
bb53:
  %t171 = load i64, ptr %l2, !tbaa !24
  %t172 = load i64, ptr %l127, !tbaa !24
  %t174 = icmp eq i64 %t172, %t171
  store i1 %t174, ptr %l123, !tbaa !21
  br label %bb54
bb54:
  %t176 = load i1, ptr %l123, !tbaa !21
  store i1 %t176, ptr %l119, !tbaa !21
  br label %bb55
bb55:
  %t177 = load i1, ptr %l119, !tbaa !21
  br i1 %t177, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t179 = load i64, ptr %l12, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l12, !tbaa !24
  br label %bb38
bb60:
  store i64 0, ptr %l15, !tbaa !24
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Call", ptr %t183, i32 0, i32 1
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t186, 0
  store i64 %t188, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t190 = load i64, ptr %l16, !tbaa !24
  %t191 = load i64, ptr %l15, !tbaa !24
  %t194 = icmp sgt i64 %t190, %t191
  br i1 %t194, label %bb61, label %bb62
bb61:
  %t196 = load i64, ptr %l17, !tbaa !24
  %t198 = icmp sgt i64 %t196, 0
  br i1 %t198, label %bb63, label %bb64
bb62:
  store i64 0, ptr %l139, !tbaa !24
  br label %bb66
bb63:
  %t200 = load i64, ptr %l16, !tbaa !24
  %t201 = load i64, ptr %l15, !tbaa !24
  %t204 = sub i64 %t200, %t201
  %t205 = load i64, ptr %l17, !tbaa !24
  %t208 = add i64 %t204, %t205
  %t210 = sub i64 %t208, 1
  %t211 = load i64, ptr %l17, !tbaa !24
  %t214 = sdiv i64 %t210, %t211
  store i64 %t214, ptr %l142, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l142, !tbaa !24
  br label %bb65
bb65:
  %t216 = load i64, ptr %l142, !tbaa !24
  store i64 %t216, ptr %l139, !tbaa !24
  br label %bb66
bb66:
  %t217 = load i64, ptr %l139, !tbaa !24
  store i64 %t217, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb67
bb67:
  %t218 = load i64, ptr %l19, !tbaa !24
  %t219 = load i64, ptr %l18, !tbaa !24
  %t222 = icmp slt i64 %t218, %t219
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb68, label %bb69
bb68:
  br label %bb91
bb69:
  br label %bb70
bb70:
  %t226 = load i64, ptr %l15, !tbaa !24
  %t227 = load i64, ptr %l19, !tbaa !24
  %t228 = load i64, ptr %l17, !tbaa !24
  %t231 = mul i64 %t227, %t228
  %t234 = add i64 %t226, %t231
  store i64 %t234, ptr %l20, !tbaa !24
  %t236 = load i64, ptr %l20, !tbaa !24
  %t237 = load i64, ptr %l2, !tbaa !24
  %t240 = icmp eq i64 %t236, %t237
  br i1 %t240, label %bb71, label %bb72
bb71:
  br label %bb90
bb72:
  br label %bb73
bb73:
  %t242 = load ptr, ptr %l5, !tbaa !29
  %t243 = load i32, ptr %l3, !tbaa !23
  %t244 = load i64, ptr %l20, !tbaa !24
  %t248 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t242, i32 %t243, i64 %t244)
  store i64 %t248, ptr %l166
  br label %bb74
bb74:
  %t249 = load i64, ptr %l166, !tbaa !24
  store i64 %t249, ptr %l21, !tbaa !24
  %t250 = load i64, ptr %l21, !tbaa !24
  %t251 = load i64, ptr %l2, !tbaa !24
  %t254 = icmp eq i64 %t250, %t251
  br i1 %t254, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l170, !tbaa !21
  br label %bb77
bb76:
  %t256 = load i64, ptr %l6, !tbaa !24
  %t257 = load i64, ptr %l20, !tbaa !24
  %t260 = icmp eq i64 %t256, %t257
  store i1 %t260, ptr %l170, !tbaa !21
  br label %bb77
bb77:
  %t262 = load i1, ptr %l170, !tbaa !21
  br i1 %t262, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l174, !tbaa !21
  br label %bb83
bb79:
  %t263 = load i64, ptr %l6, !tbaa !24
  %t265 = icmp sge i64 %t263, 0
  br i1 %t265, label %bb80, label %bb81
bb80:
  %t267 = load i64, ptr %l21, !tbaa !24
  %t268 = load i64, ptr %l6, !tbaa !24
  %t271 = icmp eq i64 %t267, %t268
  store i1 %t271, ptr %l177, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb82
bb82:
  %t273 = load i1, ptr %l177, !tbaa !21
  store i1 %t273, ptr %l174, !tbaa !21
  br label %bb83
bb83:
  %t274 = load i1, ptr %l174, !tbaa !21
  br i1 %t274, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb86
bb85:
  %t275 = load i64, ptr %l21, !tbaa !24
  %t276 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t279 = icmp eq i64 %t275, %t276
  store i1 %t279, ptr %l181, !tbaa !21
  br label %bb86
bb86:
  %t281 = load i1, ptr %l181, !tbaa !21
  br i1 %t281, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t283 = load i64, ptr %l19, !tbaa !24
  %t285 = add i64 %t283, 1
  store i64 %t285, ptr %l19, !tbaa !24
  br label %bb67
bb91:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = getelementptr %"compiler/typed:Call", ptr %t288, i32 0, i32 0
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t294 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t287, ptr %t291)
  store i64 %t294, ptr %l191
  br label %bb92
bb92:
  %t295 = load i64, ptr %l191, !tbaa !24
  store i64 %t295, ptr %l22, !tbaa !24
  %t296 = load i64, ptr %l22, !tbaa !24
  %t298 = icmp slt i64 %t296, 0
  br i1 %t298, label %bb93, label %bb94
bb93:
  store i1 true, ptr %l194, !tbaa !21
  br label %bb96
bb94:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/scope:Scoper", ptr %t300, i32 0, i32 6
  %t303 = load i64, ptr %l22, !tbaa !24
  %t306 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t302, i64 %t303)
  store ptr %t306, ptr %l198
  br label %bb95
bb95:
  %t307 = load ptr, ptr %l198, !tbaa !29
  %t309 = getelementptr %"compiler/scope:summary", ptr %t307, i32 0, i32 17
  %t310 = load i1, ptr %t309, !tbaa !21
  %t312 = xor i1 %t310, true
  store i1 %t312, ptr %l194, !tbaa !21
  br label %bb96
bb96:
  %t314 = load i1, ptr %l194, !tbaa !21
  br i1 %t314, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l202, !tbaa !21
  br label %bb100
bb98:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/scope:Scoper", ptr %t315, i32 0, i32 6
  %t318 = load i64, ptr %l22, !tbaa !24
  %t321 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t317, i64 %t318)
  store ptr %t321, ptr %l206
  br label %bb99
bb99:
  %t322 = load ptr, ptr %l206, !tbaa !29
  %t324 = getelementptr %"compiler/scope:summary", ptr %t322, i32 0, i32 18
  %t325 = load i1, ptr %t324, !tbaa !21
  store i1 %t325, ptr %l202, !tbaa !21
  br label %bb100
bb100:
  %t327 = load i1, ptr %l202, !tbaa !21
  br i1 %t327, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb102:
  br label %bb103
bb103:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/scope:Scoper", ptr %t329, i32 0, i32 0
  %t332 = load ptr, ptr %t331, !tbaa !29
  %t334 = getelementptr %"compiler/generic:Program", ptr %t332, i32 0, i32 2
  %t335 = load i32, ptr %l3, !tbaa !23
  %t338 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t334, i32 %t335)
  store { i64, ptr } %t338, ptr %l214
  br label %bb104
bb104:
  %t339 = load { i64, ptr }, ptr %l214, !tbaa !27
  store { i64, ptr } %t339, ptr %l23, !tbaa !27
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/scope:Scoper", ptr %t340, i32 0, i32 0
  %t343 = load ptr, ptr %t342, !tbaa !29
  %t345 = getelementptr %"compiler/generic:Program", ptr %t343, i32 0, i32 2
  %t346 = load i32, ptr %l3, !tbaa !23
  %t347 = load i64, ptr %l2, !tbaa !24
  %t351 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t345, i32 %t346, i64 %t347)
  store i64 %t351, ptr %l220
  br label %bb105
bb105:
  %t352 = load i64, ptr %l220, !tbaa !24
  store i64 %t352, ptr %l24, !tbaa !24
  %t353 = load i64, ptr %l24, !tbaa !24
  %t355 = icmp sge i64 %t353, 0
  br i1 %t355, label %bb106, label %bb107
bb106:
  %t357 = load i64, ptr %l24, !tbaa !24
  store i64 %t357, ptr %l223, !tbaa !24
  br label %bb108
bb107:
  %t359 = load i64, ptr %l2, !tbaa !24
  store i64 %t359, ptr %l223, !tbaa !24
  br label %bb108
bb108:
  %t361 = load i64, ptr %l223, !tbaa !24
  store i64 %t361, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  %t362 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  store i64 %t364, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t366 = load i64, ptr %l27, !tbaa !24
  %t367 = load i64, ptr %l26, !tbaa !24
  %t370 = icmp sgt i64 %t366, %t367
  br i1 %t370, label %bb109, label %bb110
bb109:
  %t372 = load i64, ptr %l28, !tbaa !24
  %t374 = icmp sgt i64 %t372, 0
  br i1 %t374, label %bb111, label %bb112
bb110:
  store i64 0, ptr %l231, !tbaa !24
  br label %bb114
bb111:
  %t376 = load i64, ptr %l27, !tbaa !24
  %t377 = load i64, ptr %l26, !tbaa !24
  %t380 = sub i64 %t376, %t377
  %t381 = load i64, ptr %l28, !tbaa !24
  %t384 = add i64 %t380, %t381
  %t386 = sub i64 %t384, 1
  %t387 = load i64, ptr %l28, !tbaa !24
  %t390 = sdiv i64 %t386, %t387
  store i64 %t390, ptr %l234, !tbaa !24
  br label %bb113
bb112:
  store i64 0, ptr %l234, !tbaa !24
  br label %bb113
bb113:
  %t392 = load i64, ptr %l234, !tbaa !24
  store i64 %t392, ptr %l231, !tbaa !24
  br label %bb114
bb114:
  %t393 = load i64, ptr %l231, !tbaa !24
  store i64 %t393, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb115
bb115:
  %t394 = load i64, ptr %l30, !tbaa !24
  %t395 = load i64, ptr %l29, !tbaa !24
  %t398 = icmp slt i64 %t394, %t395
  %t400 = xor i1 %t398, true
  br i1 %t400, label %bb116, label %bb117
bb116:
  br label %bb147
bb117:
  br label %bb118
bb118:
  %t402 = load i64, ptr %l26, !tbaa !24
  %t403 = load i64, ptr %l30, !tbaa !24
  %t404 = load i64, ptr %l28, !tbaa !24
  %t407 = mul i64 %t403, %t404
  %t410 = add i64 %t402, %t407
  store i64 %t410, ptr %l31, !tbaa !24
  %t412 = load i64, ptr %l31, !tbaa !24
  %t414 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t415 = load ptr, ptr %t414, !tbaa !27
  %t416 = getelementptr i64, ptr %t415, i64 %t412
  %t417 = load i64, ptr %t416, !tbaa !34
  %t418 = load i64, ptr %l25, !tbaa !24
  %t421 = icmp ne i64 %t417, %t418
  br i1 %t421, label %bb119, label %bb120
bb119:
  br label %bb146
bb120:
  br label %bb121
bb121:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/scope:Scoper", ptr %t423, i32 0, i32 6
  %t426 = load i64, ptr %l22, !tbaa !24
  %t429 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t425, i64 %t426)
  store ptr %t429, ptr %l259
  br label %bb122
bb122:
  %t430 = load ptr, ptr %l259, !tbaa !29
  %t432 = getelementptr %"compiler/scope:summary", ptr %t430, i32 0, i32 0
  store ptr %t432, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb123
bb123:
  %t434 = load i64, ptr %l33, !tbaa !24
  store i64 %t434, ptr %l262, !tbaa !24
  %t435 = load ptr, ptr %l32, !tbaa !29
  %t437 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t435)
  store i64 %t437, ptr %l264
  br label %bb124
bb124:
  %t438 = load i64, ptr %l262, !tbaa !24
  %t439 = load i64, ptr %l264, !tbaa !24
  %t440 = icmp slt i64 %t438, %t439
  %t442 = xor i1 %t440, true
  br i1 %t442, label %bb125, label %bb126
bb125:
  br label %bb145
bb126:
  br label %bb127
bb127:
  %t444 = load ptr, ptr %l32, !tbaa !29
  %t445 = load i64, ptr %l33, !tbaa !24
  %t448 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t444, i64 %t445)
  store %"compiler/scope:rel" %t448, ptr %l269
  br label %bb128
bb128:
  %t449 = load %"compiler/scope:rel", ptr %l269
  store %"compiler/scope:rel" %t449, ptr %l34
  %t450 = getelementptr %"compiler/scope:rel", ptr %l34, i32 0, i32 0
  %t451 = load { i64, [2 x i64] }, ptr %t450
  %t453 = extractvalue { i64, [2 x i64] } %t451, 0
  %t454 = icmp eq i64 %t453, 2
  br i1 %t454, label %bb129, label %bb130
bb129:
  %t456 = getelementptr %"compiler/scope:rel", ptr %l34, i32 0, i32 0
  %t457 = getelementptr { i64, [2 x i64] }, ptr %t456, i32 0, i32 1
  %t458 = getelementptr { i64 }, ptr %t457, i32 0, i32 0
  %t459 = load i64, ptr %t458
  %t460 = load i64, ptr %l31, !tbaa !24
  %t463 = icmp eq i64 %t459, %t460
  store i1 %t463, ptr %l272, !tbaa !21
  br label %bb131
bb130:
  store i1 false, ptr %l272, !tbaa !21
  br label %bb131
bb131:
  %t465 = load i1, ptr %l272, !tbaa !21
  br i1 %t465, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l276, !tbaa !21
  br label %bb140
bb133:
  %t466 = getelementptr %"compiler/scope:rel", ptr %l34, i32 0, i32 2
  %t467 = load i1, ptr %t466, !tbaa !21
  br i1 %t467, label %bb134, label %bb135
bb134:
  %t469 = getelementptr %"compiler/scope:rel", ptr %l34, i32 0, i32 1
  %t470 = load { i64, [2 x i64] }, ptr %t469
  %t472 = extractvalue { i64, [2 x i64] } %t470, 0
  %t473 = icmp eq i64 %t472, 2
  br i1 %t473, label %bb136, label %bb137
bb135:
  store i1 false, ptr %l278, !tbaa !21
  br label %bb139
bb136:
  %t475 = getelementptr %"compiler/scope:rel", ptr %l34, i32 0, i32 1
  %t476 = getelementptr { i64, [2 x i64] }, ptr %t475, i32 0, i32 1
  %t477 = getelementptr { i64 }, ptr %t476, i32 0, i32 0
  %t478 = load i64, ptr %t477
  %t479 = load i64, ptr %l31, !tbaa !24
  %t482 = icmp eq i64 %t478, %t479
  store i1 %t482, ptr %l281, !tbaa !21
  br label %bb138
bb137:
  store i1 false, ptr %l281, !tbaa !21
  br label %bb138
bb138:
  %t484 = load i1, ptr %l281, !tbaa !21
  store i1 %t484, ptr %l278, !tbaa !21
  br label %bb139
bb139:
  %t485 = load i1, ptr %l278, !tbaa !21
  store i1 %t485, ptr %l276, !tbaa !21
  br label %bb140
bb140:
  %t486 = load i1, ptr %l276, !tbaa !21
  br i1 %t486, label %bb141, label %bb142
bb141:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb142:
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t488 = load i64, ptr %l33, !tbaa !24
  %t490 = add i64 %t488, 1
  store i64 %t490, ptr %l33, !tbaa !24
  br label %bb123
bb145:
  br label %bb146
bb146:
  %t492 = load i64, ptr %l30, !tbaa !24
  %t494 = add i64 %t492, 1
  store i64 %t494, ptr %l30, !tbaa !24
  br label %bb115
bb147:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/scope:Scoper", ptr %t496, i32 0, i32 6
  %t499 = load i64, ptr %l22, !tbaa !24
  %t502 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t498, i64 %t499)
  store ptr %t502, ptr %l293
  br label %bb148
bb148:
  %t503 = load ptr, ptr %l293, !tbaa !29
  %t505 = getelementptr %"compiler/scope:summary", ptr %t503, i32 0, i32 0
  store ptr %t505, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb149
bb149:
  %t507 = load i64, ptr %l36, !tbaa !24
  store i64 %t507, ptr %l296, !tbaa !24
  %t508 = load ptr, ptr %l35, !tbaa !29
  %t510 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t508)
  store i64 %t510, ptr %l298
  br label %bb150
bb150:
  %t511 = load i64, ptr %l296, !tbaa !24
  %t512 = load i64, ptr %l298, !tbaa !24
  %t513 = icmp slt i64 %t511, %t512
  %t515 = xor i1 %t513, true
  br i1 %t515, label %bb151, label %bb152
bb151:
  br label %bb167
bb152:
  br label %bb153
bb153:
  %t517 = load ptr, ptr %l35, !tbaa !29
  %t518 = load i64, ptr %l36, !tbaa !24
  %t521 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t517, i64 %t518)
  store %"compiler/scope:rel" %t521, ptr %l303
  br label %bb154
bb154:
  %t522 = load %"compiler/scope:rel", ptr %l303
  store %"compiler/scope:rel" %t522, ptr %l37
  %t523 = getelementptr %"compiler/scope:rel", ptr %l37, i32 0, i32 0
  %t524 = load { i64, [2 x i64] }, ptr %t523
  %t525 = load i64, ptr %l2, !tbaa !24
  %t528 = call i1 @compiler_2fscope_2ederivedOf({ i64, [2 x i64] } %t524, i64 %t525)
  store i1 %t528, ptr %l306
  br label %bb155
bb155:
  %t529 = load i1, ptr %l306, !tbaa !21
  br i1 %t529, label %bb156, label %bb157
bb156:
  store i1 true, ptr %l307, !tbaa !21
  br label %bb162
bb157:
  %t530 = getelementptr %"compiler/scope:rel", ptr %l37, i32 0, i32 2
  %t531 = load i1, ptr %t530, !tbaa !21
  br i1 %t531, label %bb158, label %bb159
bb158:
  %t533 = getelementptr %"compiler/scope:rel", ptr %l37, i32 0, i32 1
  %t534 = load { i64, [2 x i64] }, ptr %t533
  %t535 = load i64, ptr %l2, !tbaa !24
  %t538 = call i1 @compiler_2fscope_2ederivedOf({ i64, [2 x i64] } %t534, i64 %t535)
  store i1 %t538, ptr %l312
  br label %bb160
bb159:
  store i1 false, ptr %l309, !tbaa !21
  br label %bb161
bb160:
  %t539 = load i1, ptr %l312, !tbaa !21
  store i1 %t539, ptr %l309, !tbaa !21
  br label %bb161
bb161:
  %t540 = load i1, ptr %l309, !tbaa !21
  store i1 %t540, ptr %l307, !tbaa !21
  br label %bb162
bb162:
  %t541 = load i1, ptr %l307, !tbaa !21
  br i1 %t541, label %bb163, label %bb164
bb163:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb164:
  br label %bb165
bb165:
  br label %bb166
bb166:
  %t543 = load i64, ptr %l36, !tbaa !24
  %t545 = add i64 %t543, 1
  store i64 %t545, ptr %l36, !tbaa !24
  br label %bb149
bb167:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapsDiffer(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, [2 x i64] }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i1
  %l66 = alloca { i64, [2 x i64] }
  %l72 = alloca { i64, [2 x i64] }
  %l74 = alloca { i64, [2 x i64] }
  %l76 = alloca i1
  %rv = alloca i1
  %t70 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l19
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l19, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t9 = load ptr, ptr %l20, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l20, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 15
  store i1 %t15, ptr %l21, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l21, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t22, i32 0, i32 0
  %t24 = load %"compiler/source:Span", ptr %t23
  store %"compiler/source:Span" %t24, ptr %l3
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l4, !tbaa !23
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l6, !tbaa !29
  %t40 = load ptr, ptr %l6, !tbaa !29
  store ptr %t40, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t41 = load ptr, ptr %l33, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %l33, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 3}
  %t47 = icmp eq i64 %t45, 1
  store i1 %t47, ptr %l34, !tbaa !21
  br label %bb8
bb8:
  %t48 = load i1, ptr %l34, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t54, i32 0, i32 0
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l7, !tbaa !23
  %t58 = load ptr, ptr %l6, !tbaa !29
  %t60 = getelementptr { i64, [4 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t60, i32 0, i32 1
  %t62 = load { i64, ptr }, ptr %t61
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t66, i32 0, i32 2
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l9, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 0, ptr %t71
  %t72 = load { i64, [2 x i64] }, ptr %t70
  store { i64, [2 x i64] } %t72, ptr %l10
  store { i64, ptr } %t62, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  store i64 %t78, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  %t80 = load i64, ptr %l12, !tbaa !24
  %t81 = load i64, ptr %l13, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb13, label %bb14
bb13:
  br label %bb33
bb14:
  br label %bb15
bb15:
  %t88 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t88, ptr %l53, !tbaa !27
  %t89 = load i64, ptr %l12, !tbaa !24
  %t91 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr ptr, ptr %t92, i64 %t89
  %t94 = load ptr, ptr %t93, !tbaa !39
  store ptr %t94, ptr %l14, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l56, !tbaa !29
  %t97 = load ptr, ptr %l14, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Capture", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t100)
  store i32 %t102, ptr %l59
  br label %bb16
bb16:
  %t103 = load ptr, ptr %l56, !tbaa !29
  %t104 = load i32, ptr %l59, !tbaa !23
  %t105 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t103, i32 %t104)
  store i1 %t105, ptr %l60
  br label %bb17
bb17:
  %t106 = load i1, ptr %l60, !tbaa !21
  %t107 = xor i1 %t106, true
  br i1 %t107, label %bb18, label %bb19
bb18:
  br label %bb32
bb19:
  br label %bb20
bb20:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l14, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Capture", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t117 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %t109, ptr %t113)
  store { i64, [2 x i64] } %t117, ptr %l66
  br label %bb21
bb21:
  %t118 = load { i64, [2 x i64] }, ptr %l66
  store { i64, [2 x i64] } %t118, ptr %l15
  %t119 = load { i64, [2 x i64] }, ptr %l15
  %t121 = extractvalue { i64, [2 x i64] } %t119, 0
  %t122 = icmp eq i64 %t121, 0
  br i1 %t122, label %bb22, label %bb23
bb22:
  br label %bb32
bb23:
  br label %bb24
bb24:
  %t124 = load { i64, [2 x i64] }, ptr %l10
  %t126 = extractvalue { i64, [2 x i64] } %t124, 0
  %t127 = icmp eq i64 %t126, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  %t129 = load { i64, [2 x i64] }, ptr %l15
  store { i64, [2 x i64] } %t129, ptr %l10
  br label %bb31
bb26:
  %t131 = load { i64, [2 x i64] }, ptr %l15
  store { i64, [2 x i64] } %t131, ptr %l72
  %t132 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t132, ptr %l74
  %t135 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l72, ptr %l74)
  store i1 %t135, ptr %l76
  br label %bb27
bb27:
  %t136 = load i1, ptr %l76, !tbaa !21
  %t137 = xor i1 %t136, true
  br i1 %t137, label %bb28, label %bb29
bb28:
  store i1 true, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t140 = load i64, ptr %l12, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l12, !tbaa !24
  br label %bb12
bb33:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %a1, ptr %l2)
  br label %bb2
bb2:
  store ptr %l2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l12, !tbaa !24
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t11)
  store i64 %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = load i64, ptr %l14, !tbaa !24
  %t16 = icmp slt i64 %t14, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t20, i64 %t21)
  store i64 %t24, ptr %l19
  br label %bb8
bb8:
  %t25 = load i64, ptr %l19, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 125
  %t32 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t28, i64 %t25)
  store i1 %t32, ptr %l23
  br label %bb9
bb9:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb3
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecomputeKeeps(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l31 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l110 = alloca ptr
  %l117 = alloca ptr
  %l124 = alloca ptr
  %l129 = alloca i64
  %l131 = alloca i64
  %l136 = alloca i32
  %l141 = alloca ptr
  %l143 = alloca ptr
  %l148 = alloca i1
  %l153 = alloca ptr
  %l155 = alloca ptr
  %l160 = alloca i1
  %l165 = alloca ptr
  %l167 = alloca ptr
  %l172 = alloca i1
  %l179 = alloca ptr
  %l186 = alloca ptr
  %l193 = alloca ptr
  %l198 = alloca i1
  %l201 = alloca i64
  %l205 = alloca i64
  %l208 = alloca i64
  %l230 = alloca ptr
  %l232 = alloca ptr
  %l236 = alloca i1
  %l241 = alloca ptr
  %l243 = alloca ptr
  %l247 = alloca i1
  %l252 = alloca ptr
  %l254 = alloca ptr
  %l258 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 98
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t3)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 99
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t7)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/scope:Scoper", ptr %t9, i32 0, i32 100
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t11)
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 7
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t15)
  store i64 %t17, ptr %l31
  br label %bb4
bb4:
  %t18 = load i64, ptr %l31, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb10
bb7:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l38, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb9
bb9:
  %t45 = load i64, ptr %l38, !tbaa !24
  store i64 %t45, ptr %l35, !tbaa !24
  br label %bb10
bb10:
  %t46 = load i64, ptr %l35, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb12, label %bb13
bb12:
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t55 = load i64, ptr %l2, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l7, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/scope:Scoper", ptr %t65, i32 0, i32 98
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t67, i1 false)
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/scope:Scoper", ptr %t69, i32 0, i32 99
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t71, i1 false)
  br label %bb16
bb16:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/scope:Scoper", ptr %t73, i32 0, i32 100
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t75, i1 false)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb11
bb19:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 113
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t83)
  br label %bb20
bb20:
  store i64 0, ptr %l8, !tbaa !24
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t85, i32 0, i32 7
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t87)
  store i64 %t89, ptr %l68
  br label %bb21
bb21:
  %t90 = load i64, ptr %l68, !tbaa !24
  store i64 %t90, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t91 = load i64, ptr %l9, !tbaa !24
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = icmp sgt i64 %t91, %t92
  br i1 %t95, label %bb22, label %bb23
bb22:
  %t97 = load i64, ptr %l10, !tbaa !24
  %t99 = icmp sgt i64 %t97, 0
  br i1 %t99, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb27
bb24:
  %t101 = load i64, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = sub i64 %t101, %t102
  %t106 = load i64, ptr %l10, !tbaa !24
  %t109 = add i64 %t105, %t106
  %t111 = sub i64 %t109, 1
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = sdiv i64 %t111, %t112
  store i64 %t115, ptr %l75, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb26
bb26:
  %t117 = load i64, ptr %l75, !tbaa !24
  store i64 %t117, ptr %l72, !tbaa !24
  br label %bb27
bb27:
  %t118 = load i64, ptr %l72, !tbaa !24
  store i64 %t118, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb28
bb28:
  %t119 = load i64, ptr %l12, !tbaa !24
  %t120 = load i64, ptr %l11, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb29, label %bb30
bb29:
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t127 = load i64, ptr %l8, !tbaa !24
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l10, !tbaa !24
  %t132 = mul i64 %t128, %t129
  %t135 = add i64 %t127, %t132
  store i64 %t135, ptr %l13, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/scope:Scoper", ptr %t137, i32 0, i32 113
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t139, i64 -1)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t141 = load i64, ptr %l12, !tbaa !24
  %t143 = add i64 %t141, 1
  store i64 %t143, ptr %l12, !tbaa !24
  br label %bb28
bb34:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Body", ptr %t146, i32 0, i32 11
  %t149 = load ptr, ptr %t148, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasBlock(ptr %v0, ptr %v1, ptr %t145, ptr %t149)
  br label %bb35
bb35:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionLocals(ptr %v0, ptr %v1, ptr %t152, ptr %t153)
  br label %bb36
bb36:
  %t156 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecursorRegions(ptr %v0, ptr %t156)
  br label %bb37
bb37:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Body", ptr %t159, i32 0, i32 11
  %t162 = load ptr, ptr %t161, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwBlock(ptr %v0, ptr %v1, ptr %t158, ptr %t162)
  br label %bb38
bb38:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 6
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/scope:Scoper", ptr %t168, i32 0, i32 26
  %t171 = load i64, ptr %t170, !tbaa !24
  %t174 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t167, i64 %t171)
  store ptr %t174, ptr %l110
  br label %bb39
bb39:
  %t175 = load ptr, ptr %l110, !tbaa !29
  %t177 = getelementptr %"compiler/scope:summary", ptr %t175, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t177)
  br label %bb40
bb40:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/scope:Scoper", ptr %t179, i32 0, i32 6
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/scope:Scoper", ptr %t182, i32 0, i32 26
  %t185 = load i64, ptr %t184, !tbaa !24
  %t188 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t181, i64 %t185)
  store ptr %t188, ptr %l117
  br label %bb41
bb41:
  %t189 = load ptr, ptr %l117, !tbaa !29
  %t191 = getelementptr %"compiler/scope:summary", ptr %t189, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t191)
  br label %bb42
bb42:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/scope:Scoper", ptr %t193, i32 0, i32 6
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/scope:Scoper", ptr %t196, i32 0, i32 26
  %t199 = load i64, ptr %t198, !tbaa !24
  %t202 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t195, i64 %t199)
  store ptr %t202, ptr %l124
  br label %bb43
bb43:
  %t203 = load ptr, ptr %l124, !tbaa !29
  %t205 = getelementptr %"compiler/scope:summary", ptr %t203, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t205)
  br label %bb44
bb44:
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/typed:Body", ptr %t207, i32 0, i32 5
  store ptr %t209, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb45
bb45:
  %t211 = load i64, ptr %l15, !tbaa !24
  store i64 %t211, ptr %l129, !tbaa !24
  %t212 = load ptr, ptr %l14, !tbaa !29
  %t214 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t212)
  store i64 %t214, ptr %l131
  br label %bb46
bb46:
  %t215 = load i64, ptr %l129, !tbaa !24
  %t216 = load i64, ptr %l131, !tbaa !24
  %t217 = icmp slt i64 %t215, %t216
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb47, label %bb48
bb47:
  br label %bb61
bb48:
  br label %bb49
bb49:
  %t221 = load ptr, ptr %l14, !tbaa !29
  %t222 = load i64, ptr %l15, !tbaa !24
  %t225 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t221, i64 %t222)
  store i32 %t225, ptr %l136
  br label %bb50
bb50:
  %t226 = load i32, ptr %l136, !tbaa !23
  store i32 %t226, ptr %l16, !tbaa !23
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/scope:Scoper", ptr %t227, i32 0, i32 6
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/scope:Scoper", ptr %t230, i32 0, i32 26
  %t233 = load i64, ptr %t232, !tbaa !24
  %t236 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t229, i64 %t233)
  store ptr %t236, ptr %l141
  br label %bb51
bb51:
  %t237 = load ptr, ptr %l141, !tbaa !29
  %t239 = getelementptr %"compiler/scope:summary", ptr %t237, i32 0, i32 5
  store ptr %t239, ptr %l143, !tbaa !29
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/scope:Scoper", ptr %t240, i32 0, i32 98
  %t243 = load i32, ptr %l16, !tbaa !23
  %t245 = sext i32 %t243 to i64
  %t248 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t242, i64 %t245)
  store i1 %t248, ptr %l148
  br label %bb52
bb52:
  %t249 = load ptr, ptr %l143, !tbaa !29
  %t250 = load i1, ptr %l148, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t249, i1 %t250)
  br label %bb53
bb53:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/scope:Scoper", ptr %t251, i32 0, i32 6
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/scope:Scoper", ptr %t254, i32 0, i32 26
  %t257 = load i64, ptr %t256, !tbaa !24
  %t260 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t253, i64 %t257)
  store ptr %t260, ptr %l153
  br label %bb54
bb54:
  %t261 = load ptr, ptr %l153, !tbaa !29
  %t263 = getelementptr %"compiler/scope:summary", ptr %t261, i32 0, i32 6
  store ptr %t263, ptr %l155, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/scope:Scoper", ptr %t264, i32 0, i32 99
  %t267 = load i32, ptr %l16, !tbaa !23
  %t269 = sext i32 %t267 to i64
  %t272 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t266, i64 %t269)
  store i1 %t272, ptr %l160
  br label %bb55
bb55:
  %t273 = load ptr, ptr %l155, !tbaa !29
  %t274 = load i1, ptr %l160, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t273, i1 %t274)
  br label %bb56
bb56:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/scope:Scoper", ptr %t275, i32 0, i32 6
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/scope:Scoper", ptr %t278, i32 0, i32 26
  %t281 = load i64, ptr %t280, !tbaa !24
  %t284 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t277, i64 %t281)
  store ptr %t284, ptr %l165
  br label %bb57
bb57:
  %t285 = load ptr, ptr %l165, !tbaa !29
  %t287 = getelementptr %"compiler/scope:summary", ptr %t285, i32 0, i32 7
  store ptr %t287, ptr %l167, !tbaa !29
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/scope:Scoper", ptr %t288, i32 0, i32 100
  %t291 = load i32, ptr %l16, !tbaa !23
  %t293 = sext i32 %t291 to i64
  %t296 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t290, i64 %t293)
  store i1 %t296, ptr %l172
  br label %bb58
bb58:
  %t297 = load ptr, ptr %l167, !tbaa !29
  %t298 = load i1, ptr %l172, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t297, i1 %t298)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t299 = load i64, ptr %l15, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l15, !tbaa !24
  br label %bb45
bb61:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/scope:Scoper", ptr %t303, i32 0, i32 6
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/scope:Scoper", ptr %t306, i32 0, i32 26
  %t309 = load i64, ptr %t308, !tbaa !24
  %t312 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t305, i64 %t309)
  store ptr %t312, ptr %l179
  br label %bb62
bb62:
  %t313 = load ptr, ptr %l179, !tbaa !29
  %t315 = getelementptr %"compiler/scope:summary", ptr %t313, i32 0, i32 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t315)
  br label %bb63
bb63:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/scope:Scoper", ptr %t317, i32 0, i32 6
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"compiler/scope:Scoper", ptr %t320, i32 0, i32 26
  %t323 = load i64, ptr %t322, !tbaa !24
  %t326 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t319, i64 %t323)
  store ptr %t326, ptr %l186
  br label %bb64
bb64:
  %t327 = load ptr, ptr %l186, !tbaa !29
  %t329 = getelementptr %"compiler/scope:summary", ptr %t327, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t329)
  br label %bb65
bb65:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/scope:Scoper", ptr %t331, i32 0, i32 6
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/scope:Scoper", ptr %t334, i32 0, i32 26
  %t337 = load i64, ptr %t336, !tbaa !24
  %t340 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t333, i64 %t337)
  store ptr %t340, ptr %l193
  br label %bb66
bb66:
  %t341 = load ptr, ptr %l193, !tbaa !29
  %t343 = getelementptr %"compiler/scope:summary", ptr %t341, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t343)
  br label %bb67
bb67:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load ptr, ptr %l1, !tbaa !29
  %t349 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisLambda(ptr %v0, ptr %v1, ptr %t345, ptr %t346)
  store i1 %t349, ptr %l198
  br label %bb68
bb68:
  %t350 = load i1, ptr %l198, !tbaa !21
  br i1 %t350, label %bb69, label %bb70
bb69:
  store i64 0, ptr %l17, !tbaa !24
  %t351 = load ptr, ptr %l1, !tbaa !29
  %t353 = getelementptr %"compiler/typed:Body", ptr %t351, i32 0, i32 7
  %t355 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v1, ptr %t353)
  store i64 %t355, ptr %l201
  br label %bb71
bb70:
  br label %bb93
bb71:
  %t356 = load i64, ptr %l201, !tbaa !24
  store i64 %t356, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t357 = load i64, ptr %l18, !tbaa !24
  %t358 = load i64, ptr %l17, !tbaa !24
  %t361 = icmp sgt i64 %t357, %t358
  br i1 %t361, label %bb72, label %bb73
bb72:
  %t363 = load i64, ptr %l19, !tbaa !24
  %t365 = icmp sgt i64 %t363, 0
  br i1 %t365, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l205, !tbaa !24
  br label %bb77
bb74:
  %t367 = load i64, ptr %l18, !tbaa !24
  %t368 = load i64, ptr %l17, !tbaa !24
  %t371 = sub i64 %t367, %t368
  %t372 = load i64, ptr %l19, !tbaa !24
  %t375 = add i64 %t371, %t372
  %t377 = sub i64 %t375, 1
  %t378 = load i64, ptr %l19, !tbaa !24
  %t381 = sdiv i64 %t377, %t378
  store i64 %t381, ptr %l208, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l208, !tbaa !24
  br label %bb76
bb76:
  %t383 = load i64, ptr %l208, !tbaa !24
  store i64 %t383, ptr %l205, !tbaa !24
  br label %bb77
bb77:
  %t384 = load i64, ptr %l205, !tbaa !24
  store i64 %t384, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb78
bb78:
  %t385 = load i64, ptr %l21, !tbaa !24
  %t386 = load i64, ptr %l20, !tbaa !24
  %t389 = icmp slt i64 %t385, %t386
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb79, label %bb80
bb79:
  br label %bb92
bb80:
  br label %bb81
bb81:
  %t393 = load i64, ptr %l17, !tbaa !24
  %t394 = load i64, ptr %l21, !tbaa !24
  %t395 = load i64, ptr %l19, !tbaa !24
  %t398 = mul i64 %t394, %t395
  %t401 = add i64 %t393, %t398
  store i64 %t401, ptr %l22, !tbaa !24
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/scope:Scoper", ptr %t403, i32 0, i32 6
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/scope:Scoper", ptr %t406, i32 0, i32 26
  %t409 = load i64, ptr %t408, !tbaa !24
  %t412 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t405, i64 %t409)
  store ptr %t412, ptr %l230
  br label %bb82
bb82:
  %t413 = load ptr, ptr %l230, !tbaa !29
  %t415 = getelementptr %"compiler/scope:summary", ptr %t413, i32 0, i32 8
  store ptr %t415, ptr %l232, !tbaa !29
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/scope:Scoper", ptr %t416, i32 0, i32 98
  %t419 = load i64, ptr %l22, !tbaa !24
  %t422 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t418, i64 %t419)
  store i1 %t422, ptr %l236
  br label %bb83
bb83:
  %t423 = load ptr, ptr %l232, !tbaa !29
  %t424 = load i1, ptr %l236, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t423, i1 %t424)
  br label %bb84
bb84:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/scope:Scoper", ptr %t425, i32 0, i32 6
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/scope:Scoper", ptr %t428, i32 0, i32 26
  %t431 = load i64, ptr %t430, !tbaa !24
  %t434 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t427, i64 %t431)
  store ptr %t434, ptr %l241
  br label %bb85
bb85:
  %t435 = load ptr, ptr %l241, !tbaa !29
  %t437 = getelementptr %"compiler/scope:summary", ptr %t435, i32 0, i32 9
  store ptr %t437, ptr %l243, !tbaa !29
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/scope:Scoper", ptr %t438, i32 0, i32 99
  %t441 = load i64, ptr %l22, !tbaa !24
  %t444 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t440, i64 %t441)
  store i1 %t444, ptr %l247
  br label %bb86
bb86:
  %t445 = load ptr, ptr %l243, !tbaa !29
  %t446 = load i1, ptr %l247, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t445, i1 %t446)
  br label %bb87
bb87:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/scope:Scoper", ptr %t447, i32 0, i32 6
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/scope:Scoper", ptr %t450, i32 0, i32 26
  %t453 = load i64, ptr %t452, !tbaa !24
  %t456 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t449, i64 %t453)
  store ptr %t456, ptr %l252
  br label %bb88
bb88:
  %t457 = load ptr, ptr %l252, !tbaa !29
  %t459 = getelementptr %"compiler/scope:summary", ptr %t457, i32 0, i32 10
  store ptr %t459, ptr %l254, !tbaa !29
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/scope:Scoper", ptr %t460, i32 0, i32 100
  %t463 = load i64, ptr %l22, !tbaa !24
  %t466 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t462, i64 %t463)
  store i1 %t466, ptr %l258
  br label %bb89
bb89:
  %t467 = load ptr, ptr %l254, !tbaa !29
  %t468 = load i1, ptr %l258, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t467, i1 %t468)
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t469 = load i64, ptr %l21, !tbaa !24
  %t471 = add i64 %t469, 1
  store i64 %t471, ptr %l21, !tbaa !24
  br label %bb78
bb92:
  br label %bb93
bb93:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2econvertedPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i1
  %l27 = alloca i1
  %l31 = alloca i1
  %l34 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i32
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %l62 = alloca i32
  %l66 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l13, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t9 = load ptr, ptr %l14, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l14, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 9
  store i1 %t15, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l15, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t19, i32 0, i32 1
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l3, !tbaa !23
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr { i64, [5 x i64] }, ptr %t23, i32 0, i32 1
  %t26 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t25, i32 0, i32 2
  %t27 = load i32, ptr %t26, !range !{i32 0, i32 49}
  store i32 %t27, ptr %l4
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t31, i32 0, i32 4
  %t33 = load { i64, ptr }, ptr %t32
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  br label %bb6
bb5:
  br label %bb42
bb6:
  %t35 = load i32, ptr %l4, !range !{i32 0, i32 49}
  %t37 = trunc i64 20 to i32
  %t38 = icmp eq i32 %t35, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb9
bb8:
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = icmp ne i64 %t44, 1
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l27, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb14
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  store ptr %t54, ptr %l34, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l39
  br label %bb12
bb12:
  %t65 = load ptr, ptr %l34, !tbaa !29
  %t66 = load i32, ptr %l39, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t67, ptr %l40
  br label %bb13
bb13:
  %t68 = load i32, ptr %l40, !range !{i32 0, i32 33}
  %t70 = trunc i64 18 to i32
  %t71 = icmp eq i32 %t68, %t70
  %t73 = xor i1 %t71, true
  store i1 %t73, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t75 = load i1, ptr %l31, !tbaa !21
  br i1 %t75, label %bb15, label %bb16
bb15:
  store ptr null, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t78, ptr %l46, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr ptr, ptr %t80, i64 0
  %t82 = load ptr, ptr %t81, !tbaa !39
  %t86 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v2, ptr %v2, ptr %t77, ptr %t82)
  store ptr %t86, ptr %l49
  br label %bb18
bb18:
  %t87 = load ptr, ptr %l49, !tbaa !29
  store ptr %t87, ptr %l6, !tbaa !29
  %t88 = load ptr, ptr %l6, !tbaa !29
  store ptr %t88, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t89 = load ptr, ptr %l50, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = load ptr, ptr %l50, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 2
  store i1 %t95, ptr %l51, !tbaa !21
  br label %bb20
bb20:
  %t96 = load i1, ptr %l51, !tbaa !21
  br i1 %t96, label %bb21, label %bb22
bb21:
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t99, i32 0, i32 1
  %t101 = load i32, ptr %t100
  store i32 %t101, ptr %l7, !tbaa !23
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l8, !tbaa !29
  br label %bb23
bb22:
  br label %bb36
bb23:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/scope:Scoper", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l7, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l62
  br label %bb24
bb24:
  %t119 = load i32, ptr %l62, !range !{i32 0, i32 33}
  store i32 %t119, ptr %l9
  %t120 = load i32, ptr %l9, !range !{i32 0, i32 33}
  %t122 = trunc i64 19 to i32
  %t123 = icmp eq i32 %t120, %t122
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb25, label %bb26
bb25:
  %t127 = load i32, ptr %l9, !range !{i32 0, i32 33}
  %t129 = trunc i64 18 to i32
  %t130 = icmp eq i32 %t127, %t129
  %t132 = xor i1 %t130, true
  store i1 %t132, ptr %l66, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb27
bb27:
  %t134 = load i1, ptr %l66, !tbaa !21
  br i1 %t134, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb32
bb29:
  %t135 = load ptr, ptr %l8, !tbaa !29
  store ptr %t135, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t136 = load ptr, ptr %l71, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %bb30, label %bb31
bb30:
  %t139 = load ptr, ptr %l71, !tbaa !29
  %t140 = load i64, ptr %t139, !range !{i64 0, i64 8}
  %t142 = icmp eq i64 %t140, 6
  store i1 %t142, ptr %l72, !tbaa !21
  br label %bb31
bb31:
  %t143 = load i1, ptr %l72, !tbaa !21
  store i1 %t143, ptr %l70, !tbaa !21
  br label %bb32
bb32:
  %t144 = load i1, ptr %l70, !tbaa !21
  br i1 %t144, label %bb33, label %bb34
bb33:
  store ptr null, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t146 = load ptr, ptr %l8, !tbaa !29
  store ptr %t146, ptr %rv
  br label %ret
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_24c83be0c0349755_6420fa2832beca31)
  unreachable
bb41:
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_e0078e28944a7d64_c2d2e4e393ff4620)
  unreachable
bb47:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecoveredRel(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/scope:rel" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/scope:rel"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l8 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i64
  %l26 = alloca i64
  %l32 = alloca { i64, [1 x i64] }
  %l38 = alloca i32
  %l42 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l52 = alloca { i64, [1 x i64] }
  %l60 = alloca i32
  %l64 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/scope:rel" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/scope:rel", ptr %l2, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  %t4 = call i64 @compiler_2fscope_2evarOf({ i64, [2 x i64] } %t2)
  store i64 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i64, ptr %l8, !tbaa !24
  store i64 %t5, ptr %l3, !tbaa !24
  %t6 = getelementptr %"compiler/scope:rel", ptr %l2, i32 0, i32 1
  %t7 = load { i64, [2 x i64] }, ptr %t6
  %t9 = call i64 @compiler_2fscope_2evarOf({ i64, [2 x i64] } %t7)
  store i64 %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load i64, ptr %l10, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l13, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb7:
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 6
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v1, ptr %t23)
  store i64 %t25, ptr %l20
  br label %bb8
bb8:
  %t26 = load i64, ptr %l17, !tbaa !24
  %t27 = load i64, ptr %l20, !tbaa !24
  %t28 = icmp sge i64 %t26, %t27
  store i1 %t28, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb13
bb11:
  %t31 = load i64, ptr %l4, !tbaa !24
  store i64 %t31, ptr %l23, !tbaa !24
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 6
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v1, ptr %t34)
  store i64 %t36, ptr %l26
  br label %bb12
bb12:
  %t37 = load i64, ptr %l23, !tbaa !24
  %t38 = load i64, ptr %l26, !tbaa !24
  %t39 = icmp sge i64 %t37, %t38
  store i1 %t39, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t41 = load i1, ptr %l22, !tbaa !21
  br i1 %t41, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 6
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v1, ptr %t45, i64 %t46)
  store { i64, [1 x i64] } %t49, ptr %l32
  br label %bb17
bb17:
  %t50 = load { i64, [1 x i64] }, ptr %l32
  %t52 = extractvalue { i64, [1 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 1
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t57 = load i64, ptr %l3, !tbaa !24
  %t61 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamVarType(ptr %v0, ptr %v1, ptr %t55, ptr %t56, i64 %t57)
  store i32 %t61, ptr %l38
  br label %bb20
bb19:
  br label %bb28
bb20:
  %t62 = load i32, ptr %l38, !tbaa !23
  store i32 %t62, ptr %l5, !tbaa !23
  %t63 = load i32, ptr %l5, !tbaa !23
  %t64 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t67 = icmp ne i32 %t63, %t64
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l5, !tbaa !23
  %t73 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t73, ptr %l45
  br label %bb23
bb22:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb24
bb23:
  %t74 = load i1, ptr %l45, !tbaa !21
  store i1 %t74, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t75 = load i1, ptr %l42, !tbaa !21
  br i1 %t75, label %bb25, label %bb26
bb25:
  %t76 = getelementptr %"compiler/scope:rel", ptr %l2, i32 0, i32 2
  %t77 = load i1, ptr %t76, !tbaa !21
  %t79 = xor i1 %t77, true
  store i1 %t79, ptr %l46, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb27
bb27:
  %t81 = load i1, ptr %l46, !tbaa !21
  store i1 %t81, ptr %rv
  br label %ret
bb28:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Body", ptr %t82, i32 0, i32 6
  %t85 = load i64, ptr %l3, !tbaa !24
  %t88 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v1, ptr %t84, i64 %t85)
  store { i64, [1 x i64] } %t88, ptr %l52
  br label %bb29
bb29:
  %t89 = load { i64, [1 x i64] }, ptr %l52
  %t91 = extractvalue { i64, [1 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 1
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb30, label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t99 = load i64, ptr %l4, !tbaa !24
  %t103 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamVarType(ptr %v0, ptr %v1, ptr %t97, ptr %t98, i64 %t99)
  store i32 %t103, ptr %l60
  br label %bb33
bb33:
  %t104 = load i32, ptr %l60, !tbaa !23
  store i32 %t104, ptr %l6, !tbaa !23
  %t105 = load i32, ptr %l6, !tbaa !23
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t109 = icmp ne i32 %t105, %t106
  br i1 %t109, label %bb34, label %bb35
bb34:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l6, !tbaa !23
  %t115 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l67
  br label %bb36
bb35:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb37
bb36:
  %t116 = load i1, ptr %l67, !tbaa !21
  store i1 %t116, ptr %l64, !tbaa !21
  br label %bb37
bb37:
  %t117 = load i1, ptr %l64, !tbaa !21
  br i1 %t117, label %bb38, label %bb39
bb38:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l6, !tbaa !23
  %t122 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t118, i32 %t119)
  store i1 %t122, ptr %l71
  br label %bb40
bb39:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb41
bb40:
  %t123 = load i1, ptr %l71, !tbaa !21
  store i1 %t123, ptr %l68, !tbaa !21
  br label %bb41
bb41:
  %t124 = load i1, ptr %l68, !tbaa !21
  br i1 %t124, label %bb42, label %bb43
bb42:
  %t125 = getelementptr %"compiler/scope:rel", ptr %l2, i32 0, i32 2
  %t126 = load i1, ptr %t125, !tbaa !21
  %t128 = xor i1 %t126, true
  store i1 %t128, ptr %l72, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb44
bb44:
  %t130 = load i1, ptr %l72, !tbaa !21
  store i1 %t130, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecursorRegions(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca ptr
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l34 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l62 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l90 = alloca i64
  %l91 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l95 = alloca ptr
  %l100 = alloca i1
  %l101 = alloca i1
  %l102 = alloca ptr
  %l111 = alloca %"compiler/typed:Local"
  %l113 = alloca i1
  %l120 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l124 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l125 = alloca i32
  %l127 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l128 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l130 = alloca i64
  %l132 = alloca i64
  %l137 = alloca i64
  %l140 = alloca i1
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 114
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H84f9774226d7b378ef632445c463492d(ptr %v0, ptr %t3)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 149
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 149
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  br i1 %t17, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8eda7b5b464b0834_f721fd871dc79a60)
  unreachable
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 149
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Versions", ptr %t24, i32 0, i32 3
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l34
  br label %bb8
bb8:
  %t29 = load i64, ptr %l34, !tbaa !24
  %t30 = add i64 %t29, 1
  store i64 %t30, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb14
bb11:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l2, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l42, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb13
bb13:
  %t58 = load i64, ptr %l42, !tbaa !24
  store i64 %t58, ptr %l39, !tbaa !24
  br label %bb14
bb14:
  %t59 = load i64, ptr %l39, !tbaa !24
  store i64 %t59, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb16, label %bb17
bb16:
  br label %bb76
bb17:
  br label %bb18
bb18:
  %t68 = load i64, ptr %l2, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l4, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l7, !tbaa !24
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Versions", ptr %t78, i32 0, i32 3
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t80)
  store i64 %t82, ptr %l62
  br label %bb19
bb19:
  %t83 = load i64, ptr %l62, !tbaa !24
  store i64 %t83, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t84 = load i64, ptr %l10, !tbaa !24
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = icmp sgt i64 %t84, %t85
  br i1 %t88, label %bb20, label %bb21
bb20:
  %t90 = load i64, ptr %l11, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb25
bb22:
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = load i64, ptr %l9, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t99 = load i64, ptr %l11, !tbaa !24
  %t102 = add i64 %t98, %t99
  %t104 = sub i64 %t102, 1
  %t105 = load i64, ptr %l11, !tbaa !24
  %t108 = sdiv i64 %t104, %t105
  store i64 %t108, ptr %l69, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb24
bb24:
  %t110 = load i64, ptr %l69, !tbaa !24
  store i64 %t110, ptr %l66, !tbaa !24
  br label %bb25
bb25:
  %t111 = load i64, ptr %l66, !tbaa !24
  store i64 %t111, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t112 = load i64, ptr %l13, !tbaa !24
  %t113 = load i64, ptr %l12, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb71
bb28:
  br label %bb29
bb29:
  %t120 = load i64, ptr %l9, !tbaa !24
  %t121 = load i64, ptr %l13, !tbaa !24
  %t122 = load i64, ptr %l11, !tbaa !24
  %t125 = mul i64 %t121, %t122
  %t128 = add i64 %t120, %t125
  store i64 %t128, ptr %l14, !tbaa !24
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Versions", ptr %t130, i32 0, i32 3
  %t133 = load i64, ptr %l14, !tbaa !24
  %t136 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t132, i64 %t133)
  store i64 %t136, ptr %l90
  br label %bb30
bb30:
  %t137 = load i64, ptr %l90, !tbaa !24
  store i64 %t137, ptr %l15, !tbaa !24
  %t138 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %l91
  br label %bb31
bb31:
  %t139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l91
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %l16
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Versions", ptr %t140, i32 0, i32 6
  %t143 = load i64, ptr %l14, !tbaa !24
  %t146 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v0, ptr %t142, i64 %t143)
  store ptr %t146, ptr %l95
  br label %bb32
bb32:
  %t147 = load ptr, ptr %l95, !tbaa !29
  store ptr %t147, ptr %l17, !tbaa !29
  %t148 = load ptr, ptr %l17, !tbaa !29
  %t150 = icmp eq ptr %t148, null
  br i1 %t150, label %bb33, label %bb34
bb33:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l15, !tbaa !24
  %t156 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionKind(ptr %v0, ptr %t152, i64 %t153)
  store i1 %t156, ptr %l100
  br label %bb35
bb34:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueRegions(ptr %v0, ptr %v0, ptr %s5, ptr %t157, ptr %t158, ptr %l16)
  br label %bb48
bb35:
  %t163 = load i1, ptr %l100, !tbaa !21
  br i1 %t163, label %bb36, label %bb37
bb36:
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l102, !tbaa !29
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 25
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = icmp eq ptr %t168, null
  br i1 %t170, label %bb38, label %bb39
bb37:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb43
bb38:
  call void @__olang_check_failed(ptr @olang_loc_c1f751d19da60dc3_9664dc07dd21977f)
  unreachable
bb39:
  br label %bb40
bb40:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/scope:Scoper", ptr %t172, i32 0, i32 25
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Body", ptr %t175, i32 0, i32 7
  %t179 = load i64, ptr %l15, !tbaa !24
  %t182 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t178, i64 %t179)
  store %"compiler/typed:Local" %t182, ptr %l111
  br label %bb41
bb41:
  %t183 = getelementptr %"compiler/typed:Local", ptr %l111, i32 0, i32 2
  %t184 = load i32, ptr %t183, !tbaa !23
  %t185 = load ptr, ptr %l102, !tbaa !29
  %t187 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t185, i32 %t184)
  store i1 %t187, ptr %l113
  br label %bb42
bb42:
  %t188 = load i1, ptr %l113, !tbaa !21
  store i1 %t188, ptr %l101, !tbaa !21
  br label %bb43
bb43:
  %t189 = load i1, ptr %l101, !tbaa !21
  br i1 %t189, label %bb44, label %bb45
bb44:
  %t190 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s5, ptr %l16, i64 %t190)
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb49
bb48:
  br label %bb49
bb49:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/scope:Scoper", ptr %t193, i32 0, i32 114
  %t196 = load i64, ptr %l15, !tbaa !24
  %t199 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Heebd28230b8fdd871dbb93ccdeb5ff7f(ptr %v0, ptr %v0, ptr %t195, i64 %t196)
  %t200 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t199, 1
  %t201 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t199, 0
  store i32 %t201, ptr %l125
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb51, label %ok.203, !prof !99
ok.203:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t200, ptr %l124
  br label %bb50
bb50:
  %t205 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s5, ptr %l124)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l127
  br label %bb53
bb51:
  br label %bb52
bb52:
  %t206 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t206, ptr %l128
  br label %bb54
bb53:
  %t207 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l127
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t207, ptr %l120
  br label %bb55
bb54:
  %t208 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l128
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t208, ptr %l120
  br label %bb55
bb55:
  %t209 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l120
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t209, ptr %l18
  store ptr %l16, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb56
bb56:
  %t211 = load i64, ptr %l20, !tbaa !24
  store i64 %t211, ptr %l130, !tbaa !24
  %t212 = load ptr, ptr %l19, !tbaa !29
  %t214 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s5, ptr %t212)
  store i64 %t214, ptr %l132
  br label %bb57
bb57:
  %t215 = load i64, ptr %l130, !tbaa !24
  %t216 = load i64, ptr %l132, !tbaa !24
  %t217 = icmp slt i64 %t215, %t216
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb58, label %bb59
bb58:
  br label %bb68
bb59:
  br label %bb60
bb60:
  %t221 = load ptr, ptr %l19, !tbaa !29
  %t222 = load i64, ptr %l20, !tbaa !24
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s5, ptr %t221, i64 %t222)
  store i64 %t225, ptr %l137
  br label %bb61
bb61:
  %t226 = load i64, ptr %l137, !tbaa !24
  store i64 %t226, ptr %l21, !tbaa !24
  %t227 = load i64, ptr %l21, !tbaa !24
  %t230 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s5, ptr %l18, i64 %t227)
  store i1 %t230, ptr %l140
  br label %bb62
bb62:
  %t231 = load i1, ptr %l140, !tbaa !21
  br i1 %t231, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  br label %bb65
bb65:
  %t232 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s5, ptr %l18, i64 %t232)
  br label %bb66
bb66:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb67
bb67:
  %t235 = load i64, ptr %l20, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l20, !tbaa !24
  br label %bb56
bb68:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/scope:Scoper", ptr %t239, i32 0, i32 114
  %t242 = load i64, ptr %l15, !tbaa !24
  %t243 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v0, ptr %s5, ptr %t241, i64 %t242, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t243)
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s5)
  br label %bb70
bb70:
  %t247 = load i64, ptr %l13, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l13, !tbaa !24
  br label %bb26
bb71:
  %t251 = load i1, ptr %l8, !tbaa !21
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb72, label %bb73
bb72:
  br label %bb76
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t255 = load i64, ptr %l6, !tbaa !24
  %t257 = add i64 %t255, 1
  store i64 %t257, ptr %l6, !tbaa !24
  br label %bb15
bb76:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecursorTerms(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca { i64, [2 x i64] }
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l30 = alloca i64
  %l32 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l49 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca i64
  %l59 = alloca { i64, [2 x i64] }
  %l69 = alloca i64
  %l71 = alloca i64
  %l76 = alloca i64
  %l79 = alloca { i64, [2 x i64] }
  %l89 = alloca ptr
  %l93 = alloca { i64, [2 x i64] }
  %l96 = alloca i1
  %l97 = alloca { i64, [2 x i64] }
  %l101 = alloca { i64, [2 x i64] }
  %l105 = alloca { i64, [2 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 149
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_f5c0dd4304aa3f4e_d3ec1bfd2e5f3d82)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 149
  %t11 = load ptr, ptr %t10, !tbaa !29
  store ptr %t11, ptr %l2, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t17 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eRowOf(ptr %v0, ptr %t13, i64 %a1)
  store i64 %t17, ptr %l23
  br label %bb4
bb4:
  %t18 = load i64, ptr %l23, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eSigOf(ptr %v0, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l26
  br label %bb5
bb5:
  %t24 = load i64, ptr %l26, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l4, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 152
  store ptr %t29, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l6, !tbaa !24
  store i64 %t31, ptr %l30, !tbaa !24
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l32
  br label %bb7
bb7:
  %t35 = load i64, ptr %l30, !tbaa !24
  %t36 = load i64, ptr %l32, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb55
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l6, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t43, i64 %t44)
  store i64 %t47, ptr %l38
  br label %bb11
bb11:
  %t48 = load i64, ptr %l38, !tbaa !24
  store i64 %t48, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  store i64 %t49, ptr %l39, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/scope:Scoper", ptr %t50, i32 0, i32 152
  %t54 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t52)
  store i64 %t54, ptr %l42
  br label %bb12
bb12:
  %t55 = load i64, ptr %l39, !tbaa !24
  %t56 = load i64, ptr %l42, !tbaa !24
  %t57 = mul i64 %t55, %t56
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = add i64 %t57, %t58
  store i64 %t61, ptr %l9, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 169
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t65, i64 %t66)
  store i64 %t69, ptr %l49
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/scope:Scoper", ptr %t70, i32 0, i32 168
  %t73 = load i64, ptr %t72, !tbaa !24
  %t74 = load i64, ptr %l49, !tbaa !24
  %t76 = icmp eq i64 %t74, %t73
  br i1 %t76, label %bb14, label %bb15
bb14:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/scope:Scoper", ptr %t78, i32 0, i32 31
  store ptr %t80, ptr %l54, !tbaa !29
  %t81 = load i64, ptr %l8, !tbaa !24
  store i64 %t81, ptr %l55, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/scope:Scoper", ptr %t82, i32 0, i32 170
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t84, i64 %t85)
  store { i64, [2 x i64] } %t88, ptr %l59
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t89 = load ptr, ptr %l54, !tbaa !29
  %t90 = load i64, ptr %l55, !tbaa !24
  %t91 = load { i64, [2 x i64] }, ptr %l59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t89, i64 %t90, { i64, [2 x i64] } %t91)
  br label %bb17
bb17:
  br label %bb54
bb18:
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t93 = load i64, ptr %l3, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/scope:Scoper", ptr %t95, i32 0, i32 164
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eReachRow(ptr %v0, ptr %v0, ptr %t92, i64 %t93, i64 %t94, ptr %t97)
  br label %bb19
bb19:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/scope:Scoper", ptr %t102, i32 0, i32 173
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t104)
  br label %bb20
bb20:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/scope:Scoper", ptr %t106, i32 0, i32 164
  store ptr %t108, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb21
bb21:
  %t110 = load i64, ptr %l11, !tbaa !24
  store i64 %t110, ptr %l69, !tbaa !24
  %t111 = load ptr, ptr %l10, !tbaa !29
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t111)
  store i64 %t113, ptr %l71
  br label %bb22
bb22:
  %t114 = load i64, ptr %l69, !tbaa !24
  %t115 = load i64, ptr %l71, !tbaa !24
  %t116 = icmp slt i64 %t114, %t115
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb23, label %bb24
bb23:
  br label %bb33
bb24:
  br label %bb25
bb25:
  %t120 = load ptr, ptr %l10, !tbaa !29
  %t121 = load i64, ptr %l11, !tbaa !24
  %t124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t120, i64 %t121)
  store i64 %t124, ptr %l76
  br label %bb26
bb26:
  %t125 = load i64, ptr %l76, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t130 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edefTermAt(ptr %v0, ptr %t126, i64 %t125)
  store { i64, [2 x i64] } %t130, ptr %l79
  br label %bb27
bb27:
  %t131 = load { i64, [2 x i64] }, ptr %l79
  store { i64, [2 x i64] } %t131, ptr %l13
  %t132 = load { i64, [2 x i64] }, ptr %l13
  %t134 = extractvalue { i64, [2 x i64] } %t132, 0
  %t135 = icmp eq i64 %t134, 0
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb28, label %bb29
bb28:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/scope:Scoper", ptr %t140, i32 0, i32 173
  %t143 = load { i64, [2 x i64] }, ptr %l13
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddToSet(ptr %v0, ptr %v0, ptr %t139, ptr %t142, { i64, [2 x i64] } %t143)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t147 = load i64, ptr %l11, !tbaa !24
  %t149 = add i64 %t147, 1
  store i64 %t149, ptr %l11, !tbaa !24
  br label %bb21
bb33:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l89, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/scope:Scoper", ptr %t152, i32 0, i32 31
  %t155 = load i64, ptr %l8, !tbaa !24
  %t158 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t154, i64 %t155)
  store { i64, [2 x i64] } %t158, ptr %l93
  br label %bb34
bb34:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/scope:Scoper", ptr %t159, i32 0, i32 173
  %t162 = load ptr, ptr %l89, !tbaa !29
  %t163 = load { i64, [2 x i64] }, ptr %l93
  %t165 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esameTerms(ptr %v0, ptr %v0, ptr %t162, { i64, [2 x i64] } %t163, ptr %t161)
  store i1 %t165, ptr %l96
  br label %bb35
bb35:
  %t166 = load i1, ptr %l96, !tbaa !21
  br i1 %t166, label %bb36, label %bb37
bb36:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/scope:Scoper", ptr %t167, i32 0, i32 31
  %t170 = load i64, ptr %l8, !tbaa !24
  %t173 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t169, i64 %t170)
  store { i64, [2 x i64] } %t173, ptr %l101
  br label %bb38
bb37:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/scope:Scoper", ptr %t175, i32 0, i32 173
  %t180 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etermOf(ptr %v0, ptr %v0, ptr %t174, ptr %t177)
  store { i64, [2 x i64] } %t180, ptr %l105
  br label %bb39
bb38:
  %t181 = load { i64, [2 x i64] }, ptr %l101
  store { i64, [2 x i64] } %t181, ptr %l97
  br label %bb40
bb39:
  %t182 = load { i64, [2 x i64] }, ptr %l105
  store { i64, [2 x i64] } %t182, ptr %l97
  br label %bb40
bb40:
  %t183 = load { i64, [2 x i64] }, ptr %l97
  store { i64, [2 x i64] } %t183, ptr %l14
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/scope:Scoper", ptr %t184, i32 0, i32 169
  %t187 = load i64, ptr %l9, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/scope:Scoper", ptr %t188, i32 0, i32 168
  %t191 = load i64, ptr %t190, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t186, i64 %t187, i64 %t191)
  br label %bb41
bb41:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/scope:Scoper", ptr %t195, i32 0, i32 170
  %t198 = load i64, ptr %l9, !tbaa !24
  %t199 = load { i64, [2 x i64] }, ptr %l14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t197, i64 %t198, { i64, [2 x i64] } %t199)
  br label %bb42
bb42:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/scope:Scoper", ptr %t203, i32 0, i32 31
  %t206 = load i64, ptr %l8, !tbaa !24
  %t207 = load { i64, [2 x i64] }, ptr %l14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t205, i64 %t206, { i64, [2 x i64] } %t207)
  br label %bb43
bb43:
  %t211 = load { i64, [2 x i64] }, ptr %l14
  %t213 = extractvalue { i64, [2 x i64] } %t211, 0
  %t214 = icmp eq i64 %t213, 5
  br i1 %t214, label %bb44, label %bb45
bb44:
  %t216 = getelementptr { i64, [2 x i64] }, ptr %l14, i32 0, i32 1
  %t217 = getelementptr { i64 }, ptr %t216, i32 0, i32 0
  %t218 = load i64, ptr %t217
  store i64 %t218, ptr %l15, !tbaa !24
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/scope:Scoper", ptr %t220, i32 0, i32 177
  %t223 = load i64, ptr %l15, !tbaa !24
  %t224 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t222, i64 %t223, i64 %t224)
  br label %bb47
bb47:
  br label %bb53
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_b79eb6ae90738dac_dd72f768f22d9fa0)
  unreachable
bb53:
  br label %bb54
bb54:
  %t228 = load i64, ptr %l6, !tbaa !24
  %t230 = add i64 %t228, 1
  store i64 %t230, ptr %l6, !tbaa !24
  br label %bb6
bb55:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  store i1 %t12, ptr %l3, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d29996678377eee3_d1b974339c283baf)
  unreachable
bb9:
  %t14 = load i1, ptr %l3, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l20 = alloca i64
  %rv = alloca i64
  %t34 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_f1651a5ea92fc764_7e198d85ea96f48)
  unreachable
bb2:
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t18, i32 0, i32 25
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = sext i32 %t27 to i64
  %t30 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t31 = load i32, ptr %t30, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 3, ptr %t35
  %t37 = insertvalue { i64, i64, i64 } undef, i64 %t25, 0
  %t39 = insertvalue { i64, i64, i64 } %t37, i64 %t29, 1
  %t41 = insertvalue { i64, i64, i64 } %t39, i64 %t33, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { i64, i64, i64 } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t48 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %t45, { i64, [3 x i64] } %t43, %"compiler/diagmsg:Msg" %a2)
  store i64 %t48, ptr %l20
  br label %bb4
bb4:
  %t49 = load i64, ptr %l20, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eexports(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca ptr
  %l52 = alloca i64
  %l56 = alloca ptr
  %l60 = alloca i1
  %l64 = alloca ptr
  %l67 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l103 = alloca { i64, [3 x i64] }
  %l107 = alloca { i64, ptr }
  %l109 = alloca %"compiler/diagmsg:Msg"
  %l110 = alloca i64
  %s3 = alloca %olang.scope
  %t192 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load i64, ptr %l15, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l22, !tbaa !24
  store i64 %t33, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb42
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l43
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l43, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 1
  %t63 = load { i64, [2 x i64] }, ptr %t62
  store { i64, [2 x i64] } %t63, ptr %l7
  %t65 = load { i64, [2 x i64] }, ptr %l7
  %t67 = extractvalue { i64, [2 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 0
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t71 = getelementptr { i64 }, ptr %t70, i32 0, i32 0
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l8, !tbaa !24
  br label %bb15
bb14:
  br label %bb35
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/scope:Scoper", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t77, i64 %t78)
  store i64 %t81, ptr %l52
  br label %bb16
bb16:
  %t82 = load i64, ptr %l52, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s3, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l56
  br label %bb17
bb17:
  %t91 = load ptr, ptr %l56, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Func", ptr %t91, i32 0, i32 7
  %t94 = load i1, ptr %t93, !tbaa !21
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb22
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/scope:Scoper", ptr %t98, i32 0, i32 6
  %t101 = load i64, ptr %l6, !tbaa !24
  %t104 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t100, i64 %t101)
  store ptr %t104, ptr %l64
  br label %bb20
bb20:
  %t105 = load ptr, ptr %l64, !tbaa !29
  %t107 = getelementptr %"compiler/scope:summary", ptr %t105, i32 0, i32 0
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t107)
  store i64 %t109, ptr %l67
  br label %bb21
bb21:
  %t110 = load i64, ptr %l67, !tbaa !24
  %t111 = icmp eq i64 %t110, 0
  store i1 %t111, ptr %l60, !tbaa !21
  br label %bb22
bb22:
  %t113 = load i1, ptr %l60, !tbaa !21
  br i1 %t113, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb24:
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t117, i64 %t118)
  store ptr %t121, ptr %l72
  br label %bb26
bb26:
  %t122 = load ptr, ptr %l72, !tbaa !29
  store ptr %t122, ptr %l10, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 10
  store ptr %t131, ptr %l76, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/scope:Scoper", ptr %t132, i32 0, i32 0
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t136 = load i64, ptr %l9, !tbaa !24
  %t139 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t135, i64 %t136)
  store i64 %t139, ptr %l80
  br label %bb27
bb27:
  %t140 = load ptr, ptr %l76, !tbaa !29
  %t141 = load i64, ptr %l80, !tbaa !24
  %t142 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  store ptr %t142, ptr %l81
  br label %bb28
bb28:
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t145 = getelementptr %"compiler/load:Module", ptr %t143, i32 0, i32 4
  %t146 = load i64, ptr %t145, !tbaa !24
  store i64 %t146, ptr %l11, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i64, ptr %l6, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/scope:Scoper", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/load:Loader", ptr %t156, i32 0, i32 3
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t163 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v0, ptr %s3, ptr %t148, i64 %t149, ptr %t159)
  store { i64, ptr } %t163, ptr %l90
  br label %bb29
bb29:
  %t164 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t164, ptr %l12, !tbaa !27
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 0
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/load:Loader", ptr %t171, i32 0, i32 4
  %t174 = load ptr, ptr %t173, !tbaa !29
  store ptr %t174, ptr %l94, !tbaa !29
  %t175 = load i64, ptr %l11, !tbaa !24
  %t176 = load ptr, ptr %l10, !tbaa !29
  %t178 = getelementptr %"compiler/ast:Func", ptr %t176, i32 0, i32 0
  %t179 = getelementptr %"compiler/source:Span", ptr %t178, i32 0, i32 0
  %t180 = load i32, ptr %t179, !tbaa !23
  %t182 = sext i32 %t180 to i64
  %t183 = load ptr, ptr %l10, !tbaa !29
  %t185 = getelementptr %"compiler/ast:Func", ptr %t183, i32 0, i32 0
  %t186 = getelementptr %"compiler/source:Span", ptr %t185, i32 0, i32 0
  %t187 = load i32, ptr %t186, !tbaa !23
  %t189 = sext i32 %t187 to i64
  %t191 = add i64 %t189, 6
  store { i64, [3 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 0
  store i64 3, ptr %t193
  %t195 = insertvalue { i64, i64, i64 } undef, i64 %t175, 0
  %t197 = insertvalue { i64, i64, i64 } %t195, i64 %t182, 1
  %t199 = insertvalue { i64, i64, i64 } %t197, i64 %t191, 2
  %t200 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  store { i64, i64, i64 } %t199, ptr %t200
  %t201 = load { i64, [3 x i64] }, ptr %t192
  store { i64, [3 x i64] } %t201, ptr %l103
  %t202 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t206 = icmp sgt i64 %t204, 0
  br i1 %t206, label %bb30, label %bb31
bb30:
  %t208 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, ptr }, ptr %t209, i64 0
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !37
  store { i64, ptr } %t211, ptr %l107, !tbaa !27
  br label %bb32
bb31:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l107, !tbaa !27
  br label %bb32
bb32:
  %t213 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t214 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eExportObligation(ptr %s3, ptr %s3, { i64, ptr } %t213)
  store %"compiler/diagmsg:Msg" %t214, ptr %l109
  br label %bb33
bb33:
  %t215 = load ptr, ptr %l94, !tbaa !29
  %t216 = load { i64, [3 x i64] }, ptr %l103
  %t217 = load %"compiler/diagmsg:Msg", ptr %l109
  %t218 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t215, { i64, [3 x i64] } %t216, %"compiler/diagmsg:Msg" %t217)
  store i64 %t218, ptr %l110
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_3d4ddf74a6173f57_410f107a77dd9b9b)
  unreachable
bb40:
  br label %bb41
bb41:
  %t219 = load i64, ptr %l5, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l5, !tbaa !24
  br label %bb8
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efacts(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l40 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 6
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/scope:summary", ptr %t9, i32 0, i32 1
  %t13 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/scope:summary", ptr %t14, i32 0, i32 2
  %t18 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l12
  br label %bb3
bb3:
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = add i64 %t19, %t20
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/scope:summary", ptr %t22, i32 0, i32 5
  %t26 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l16
  br label %bb4
bb4:
  %t27 = load i64, ptr %l13, !tbaa !24
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = add i64 %t27, %t28
  store i64 %t29, ptr %l17, !tbaa !24
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/scope:summary", ptr %t30, i32 0, i32 6
  %t34 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l20
  br label %bb5
bb5:
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = load i64, ptr %l20, !tbaa !24
  %t37 = add i64 %t35, %t36
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr %"compiler/scope:summary", ptr %t38, i32 0, i32 7
  %t42 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t40)
  store i64 %t42, ptr %l24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l21, !tbaa !24
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = add i64 %t43, %t44
  store i64 %t45, ptr %l25, !tbaa !24
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/scope:summary", ptr %t46, i32 0, i32 8
  %t50 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t48)
  store i64 %t50, ptr %l28
  br label %bb7
bb7:
  %t51 = load i64, ptr %l25, !tbaa !24
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = add i64 %t51, %t52
  store i64 %t53, ptr %l29, !tbaa !24
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = getelementptr %"compiler/scope:summary", ptr %t54, i32 0, i32 9
  %t58 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l32
  br label %bb8
bb8:
  %t59 = load i64, ptr %l29, !tbaa !24
  %t60 = load i64, ptr %l32, !tbaa !24
  %t61 = add i64 %t59, %t60
  store i64 %t61, ptr %l33, !tbaa !24
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/scope:summary", ptr %t62, i32 0, i32 10
  %t66 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l36
  br label %bb9
bb9:
  %t67 = load i64, ptr %l33, !tbaa !24
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = add i64 %t67, %t68
  store i64 %t69, ptr %l37, !tbaa !24
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t72 = getelementptr %"compiler/scope:summary", ptr %t70, i32 0, i32 15
  %t73 = load i1, ptr %t72, !tbaa !21
  br i1 %t73, label %bb10, label %bb11
bb10:
  store i64 1, ptr %l40, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb12
bb12:
  %t75 = load i64, ptr %l37, !tbaa !24
  %t76 = load i64, ptr %l40, !tbaa !24
  %t77 = add i64 %t75, %t76
  store i64 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldMark(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, [1 x i64] }
  %l6 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i32
  %l32 = alloca %"compiler/typed:Local"
  %l35 = alloca ptr
  %l38 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [1 x i64] }
  %t18 = alloca { i64, [1 x i64] }, align 8
  %t40 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 7
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t3, i32 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l11
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l10
  br label %bb1
bb1:
  %t12 = load i64, ptr %l10, !tbaa !24
  store i64 %t12, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  store i64 %t13, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp slt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  store { i64, [1 x i64] } zeroinitializer, ptr %t18
  %t19 = getelementptr { i64, [1 x i64] }, ptr %t18, i32 0, i32 0
  store i64 0, ptr %t19
  %t20 = load { i64, [1 x i64] }, ptr %t18
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t20, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 1
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store ptr %t28, ptr %l18
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l18, !tbaa !29
  store ptr %t29, ptr %l4, !tbaa !29
  %t30 = load i64, ptr %l2, !tbaa !24
  store i64 %t30, ptr %l19, !tbaa !24
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Body", ptr %t31, i32 0, i32 10
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l22
  br label %bb9
bb9:
  %t36 = load i64, ptr %l19, !tbaa !24
  %t37 = load i64, ptr %l22, !tbaa !24
  %t38 = icmp sge i64 %t36, %t37
  br i1 %t38, label %bb10, label %bb11
bb10:
  store { i64, [1 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [1 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t42 = load { i64, [1 x i64] }, ptr %t40
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t42, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Body", ptr %t44, i32 0, i32 7
  store ptr %t46, ptr %l26, !tbaa !29
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Body", ptr %t47, i32 0, i32 10
  %t50 = load i64, ptr %l2, !tbaa !24
  %t53 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t49, i64 %t50)
  store i32 %t53, ptr %l30
  br label %bb13
bb13:
  %t54 = load i32, ptr %l30, !tbaa !23
  %t55 = sext i32 %t54 to i64
  %t56 = load ptr, ptr %l26, !tbaa !29
  %t58 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t56, i64 %t55)
  store %"compiler/typed:Local" %t58, ptr %l32
  br label %bb14
bb14:
  %t59 = getelementptr %"compiler/typed:Local", ptr %l32, i32 0, i32 5
  %t60 = load { i64, [1 x i64] }, ptr %t59
  store { i64, [1 x i64] } %t60, ptr %l5
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 223
  store ptr %t64, ptr %l35, !tbaa !29
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l2, !tbaa !24
  %t69 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t65, i64 %t66)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t69, ptr %l38
  br label %bb15
bb15:
  %t70 = load { i64, [1 x i64] }, ptr %l5
  %t71 = load ptr, ptr %l35, !tbaa !29
  %t72 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l38
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd10c34cdbfb7fa3abdb8b5399b1b7292(ptr %v0, ptr %t71, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72, { i64, [1 x i64] } %t70)
  br label %bb16
bb16:
  %t74 = load { i64, [1 x i64] }, ptr %l5
  call void @__olang_scope_close(ptr %s0)
  store { i64, [1 x i64] } %t74, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb41
bb7:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t22 = load ptr, ptr %l16, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l16, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 8}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l17, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlace(ptr %v0, ptr %v1, ptr %t36, ptr %t37)
  br label %bb13
bb13:
  br label %bb41
bb14:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t41 = load ptr, ptr %l24, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 8}
  %t47 = icmp eq i64 %t45, 4
  store i1 %t47, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Elem", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlace(ptr %v0, ptr %v1, ptr %t55, ptr %t59)
  br label %bb20
bb20:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Elem", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t62, ptr %t66)
  br label %bb21
bb21:
  br label %bb41
bb22:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l37, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 5
  store i1 %t77, ptr %l38, !tbaa !21
  br label %bb24
bb24:
  %t78 = load i1, ptr %l38, !tbaa !21
  br i1 %t78, label %bb25, label %bb26
bb25:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Payload", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlace(ptr %v0, ptr %v1, ptr %t85, ptr %t89)
  br label %bb28
bb28:
  br label %bb41
bb29:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb30, label %bb31
bb30:
  %t96 = load ptr, ptr %l46, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 8}
  %t99 = icmp eq i64 %t97, 6
  store i1 %t99, ptr %l47, !tbaa !21
  br label %bb31
bb31:
  %t100 = load i1, ptr %l47, !tbaa !21
  br i1 %t100, label %bb32, label %bb33
bb32:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  br label %bb35
bb35:
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_7fbb74a7c576c4fd_63f758b49396c059)
  unreachable
bb41:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca i64
  %l58 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  br label %bb41
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store i64 %t44, ptr %l26
  br label %bb13
bb13:
  %t45 = load i64, ptr %l26, !tbaa !24
  store i64 %t45, ptr %l7, !tbaa !24
  br label %bb41
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l28, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflPlaceRoot(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store i64 %t68, ptr %l36
  br label %bb20
bb20:
  %t69 = load i64, ptr %l36, !tbaa !24
  store i64 %t69, ptr %l7, !tbaa !24
  br label %bb41
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l37, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 2
  store i1 %t77, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l38, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t90 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExprRoot(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  store i64 %t90, ptr %l46
  br label %bb27
bb27:
  %t91 = load i64, ptr %l46, !tbaa !24
  store i64 %t91, ptr %l7, !tbaa !24
  br label %bb41
bb28:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t93 = load ptr, ptr %l47, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l47, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 8}
  %t99 = icmp eq i64 %t97, 6
  store i1 %t99, ptr %l48, !tbaa !21
  br label %bb30
bb30:
  %t100 = load i1, ptr %l48, !tbaa !21
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t112 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExprRoot(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  store i64 %t112, ptr %l56
  br label %bb34
bb34:
  %t113 = load i64, ptr %l56, !tbaa !24
  store i64 %t113, ptr %l7, !tbaa !24
  br label %bb41
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = call i64 @compiler_2fscope_2eflRoot(ptr %v1, ptr %t114)
  store i64 %t116, ptr %l58
  br label %bb39
bb39:
  %t117 = load i64, ptr %l58, !tbaa !24
  store i64 %t117, ptr %l7, !tbaa !24
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_e9ea5d5d3867ce51_dfb99b888a23f285)
  unreachable
bb41:
  %t118 = load i64, ptr %l7, !tbaa !24
  store i64 %t118, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efnBoundsDefs(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 95
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4527323723b724269d0557de47b57e0e(ptr %v0, ptr %t3)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 97
  store i1 true, ptr %t7, !tbaa !21
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/scope:Scoper", ptr %t9, i32 0, i32 25
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_9860a08c2c4d05d2_294127fb02ae07ae)
  unreachable
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 25
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t19, i32 0, i32 11
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebndBlock(ptr %v0, ptr %v0, ptr %t24, ptr %t23)
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 97
  store i1 false, ptr %t28, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egammaHolds(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/scope:rel"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l21 = alloca { i64, [2 x i64] }
  %l23 = alloca { i64, [2 x i64] }
  %l24 = alloca i32
  %l25 = alloca { i64, [2 x i64] }
  %l27 = alloca { i64, [2 x i64] }
  %l29 = alloca i1
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca { i64, [2 x i64] }
  %l42 = alloca { i64, [2 x i64] }
  %l44 = alloca { i64, [2 x i64] }
  %l46 = alloca i1
  %l54 = alloca i64
  %l56 = alloca i64
  %l61 = alloca %"compiler/scope:rel"
  %l62 = alloca { i64, [2 x i64] }
  %l64 = alloca { i64, [2 x i64] }
  %l66 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l14
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %l4, { i64, [2 x i64] } %a1)
  br label %bb3
bb3:
  br label %bb4
bb4:
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %l4)
  store i64 %t9, ptr %l18
  br label %bb5
bb5:
  %t10 = load i64, ptr %l18, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb50
bb7:
  br label %bb8
bb8:
  %t16 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePop_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %l4)
  %t17 = extractvalue { i32, { i64, [2 x i64] } } %t16, 1
  %t18 = extractvalue { i32, { i64, [2 x i64] } } %t16, 0
  store i32 %t18, ptr %l24
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb10, label %ok.20, !prof !99
ok.20:
  store { i64, [2 x i64] } %t17, ptr %l23
  br label %bb9
bb9:
  %t21 = load { i64, [2 x i64] }, ptr %l23
  store { i64, [2 x i64] } %t21, ptr %l21
  br label %bb12
bb10:
  br label %bb11
bb11:
  br label %bb50
bb12:
  %t22 = load { i64, [2 x i64] }, ptr %l21
  store { i64, [2 x i64] } %t22, ptr %l5
  %t23 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t23, ptr %l25
  store { i64, [2 x i64] } %a2, ptr %l27
  %t27 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l25, ptr %l27)
  store i1 %t27, ptr %l29
  br label %bb13
bb13:
  %t28 = load i1, ptr %l29, !tbaa !21
  br i1 %t28, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t30 = load { i64, [2 x i64] }, ptr %l5
  %t32 = extractvalue { i64, [2 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 3
  br i1 %t33, label %bb17, label %bb18
bb17:
  br label %bb49
bb18:
  br label %bb19
bb19:
  store i1 false, ptr %l6, !tbaa !21
  store ptr %l3, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  %t36 = load i64, ptr %l8, !tbaa !24
  store i64 %t36, ptr %l34, !tbaa !24
  %t37 = load ptr, ptr %l7, !tbaa !29
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %t37)
  store i64 %t39, ptr %l36
  br label %bb21
bb21:
  %t40 = load i64, ptr %l34, !tbaa !24
  %t41 = load i64, ptr %l36, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t46 = load ptr, ptr %l7, !tbaa !29
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %t46, i64 %t47)
  store { i64, [2 x i64] } %t50, ptr %l41
  br label %bb25
bb25:
  %t51 = load { i64, [2 x i64] }, ptr %l41
  store { i64, [2 x i64] } %t51, ptr %l42
  %t53 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t53, ptr %l44
  %t56 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l42, ptr %l44)
  store i1 %t56, ptr %l46
  br label %bb26
bb26:
  %t57 = load i1, ptr %l46, !tbaa !21
  br i1 %t57, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb29
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l8, !tbaa !24
  br label %bb20
bb31:
  %t62 = load i1, ptr %l6, !tbaa !21
  br i1 %t62, label %bb32, label %bb33
bb32:
  br label %bb49
bb33:
  br label %bb34
bb34:
  %t64 = load { i64, [2 x i64] }, ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %l3, { i64, [2 x i64] } %t64)
  br label %bb35
bb35:
  %t69 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 35
  store ptr %t69, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb36
bb36:
  %t71 = load i64, ptr %l11, !tbaa !24
  store i64 %t71, ptr %l54, !tbaa !24
  %t72 = load ptr, ptr %l10, !tbaa !29
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t72)
  store i64 %t74, ptr %l56
  br label %bb37
bb37:
  %t75 = load i64, ptr %l54, !tbaa !24
  %t76 = load i64, ptr %l56, !tbaa !24
  %t77 = icmp slt i64 %t75, %t76
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb38, label %bb39
bb38:
  br label %bb48
bb39:
  br label %bb40
bb40:
  %t81 = load ptr, ptr %l10, !tbaa !29
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t81, i64 %t82)
  store %"compiler/scope:rel" %t85, ptr %l61
  br label %bb41
bb41:
  %t86 = load %"compiler/scope:rel", ptr %l61
  store %"compiler/scope:rel" %t86, ptr %l12
  %t87 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 0
  %t88 = load { i64, [2 x i64] }, ptr %t87
  store { i64, [2 x i64] } %t88, ptr %l62
  %t89 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t89, ptr %l64
  %t92 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l62, ptr %l64)
  store i1 %t92, ptr %l66
  br label %bb42
bb42:
  %t93 = load i1, ptr %l66, !tbaa !21
  br i1 %t93, label %bb43, label %bb44
bb43:
  %t94 = getelementptr %"compiler/scope:rel", ptr %l12, i32 0, i32 1
  %t95 = load { i64, [2 x i64] }, ptr %t94
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %l4, { i64, [2 x i64] } %t95)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t98 = load i64, ptr %l11, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l11, !tbaa !24
  br label %bb36
bb48:
  br label %bb49
bb49:
  br label %bb4
bb50:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandleLent(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca i32
  %l17 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l28 = alloca i1
  %l30 = alloca { i64, ptr }
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l43 = alloca i32
  %l44 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l60 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  store ptr %t19, ptr %l17, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l4, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l22
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = load i32, ptr %l22, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t30, i32 %t31)
  store { i64, ptr } %t32, ptr %l23
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = icmp sge i64 %t34, %t37
  br i1 %t40, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb10
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i32, ptr %t47, i64 %t44
  %t49 = load i32, ptr %t48, !tbaa !33
  %t52 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t42, i32 %t49)
  store i1 %t52, ptr %l33
  br label %bb9
bb9:
  %t53 = load i1, ptr %l33, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb10
bb10:
  %t56 = load i1, ptr %l28, !tbaa !21
  br i1 %t56, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb15
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l36, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t64, ptr %l40, !tbaa !27
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i32, ptr %t68, i64 %t65
  %t70 = load i32, ptr %t69, !tbaa !33
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t63, i32 %t70)
  store i32 %t73, ptr %l43
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load i32, ptr %l43, !tbaa !23
  %t76 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t76, ptr %l44
  br label %bb14
bb14:
  %t77 = load i1, ptr %l44, !tbaa !21
  %t78 = xor i1 %t77, true
  store i1 %t78, ptr %l35, !tbaa !21
  br label %bb15
bb15:
  %t80 = load i1, ptr %l35, !tbaa !21
  br i1 %t80, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Call", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l6, !tbaa !29
  %t87 = load ptr, ptr %l6, !tbaa !29
  store ptr %t87, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t88 = load ptr, ptr %l49, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t91 = load ptr, ptr %l49, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 5}
  %t94 = icmp eq i64 %t92, 0
  store i1 %t94, ptr %l50, !tbaa !21
  br label %bb20
bb20:
  %t95 = load i1, ptr %l50, !tbaa !21
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t96 = load ptr, ptr %l6, !tbaa !29
  %t98 = getelementptr { i64, [3 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { i32 }, ptr %t98, i32 0, i32 0
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l7, !tbaa !23
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l7, !tbaa !23
  %t105 = sext i32 %t103 to i64
  %t106 = load i64, ptr %l2, !tbaa !24
  %t107 = load i64, ptr @G_2ecompiler_2fscope_2eUseThru, !tbaa !24
  %t112 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euses(ptr %v0, ptr %t102, i64 %t105, i64 %t106, i64 %t107)
  store i1 %t112, ptr %l60
  br label %bb24
bb24:
  %t113 = load i1, ptr %l60, !tbaa !21
  store i1 %t113, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_10bab568b406970b_66071842e5074daf)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eheldCall(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l20 = alloca %"compiler/typed:Local"
  %l25 = alloca i1
  %l32 = alloca ptr
  %l36 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 42
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store ptr %t8, ptr %l9
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l9, !tbaa !29
  store ptr %t12, ptr %l5, !tbaa !29
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %rv
  br label %ret
bb4:
  %t14 = load ptr, ptr %l5, !tbaa !29
  store ptr %t14, ptr %l2, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 25
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_eb97c951d9e697cc_139ecfedaca533c8)
  unreachable
bb6:
  br label %bb7
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 25
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 7
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t28, i64 %t29)
  store %"compiler/typed:Local" %t32, ptr %l20
  br label %bb8
bb8:
  %t33 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 4
  %t34 = load i32, ptr %t33, !range !{i32 0, i32 7}
  store i32 %t34, ptr %l3
  %t36 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t38 = trunc i64 3 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t43 = load i32, ptr %l3, !range !{i32 0, i32 7}
  %t45 = trunc i64 2 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  store i1 %t48, ptr %l25, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t50 = load i1, ptr %l25, !tbaa !21
  br i1 %t50, label %bb12, label %bb13
bb12:
  store i64 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t55 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v0, ptr %v0, ptr %t52)
  store ptr %t55, ptr %l32
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l32, !tbaa !29
  store ptr %t56, ptr %l4, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Call", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %t65, !tbaa !23
  %t68 = sext i32 %t66 to i64
  store i64 %t68, ptr %l36, !tbaa !24
  br label %bb18
bb17:
  store i64 -1, ptr %l36, !tbaa !24
  br label %bb18
bb18:
  %t70 = load i64, ptr %l36, !tbaa !24
  store i64 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisMethodCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l25 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca ptr
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 1
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 1
  %t33 = load { i64, [2 x i64] }, ptr %t32
  store { i64, [2 x i64] } %t33, ptr %l4
  %t35 = load { i64, [2 x i64] }, ptr %l4
  %t37 = extractvalue { i64, [2 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 0
  br i1 %t38, label %bb7, label %bb8
bb7:
  %t40 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t41 = getelementptr { i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l5, !tbaa !24
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l25, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/scope:Scoper", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t51, i64 %t52)
  store i64 %t55, ptr %l29
  br label %bb10
bb10:
  %t56 = load ptr, ptr %l25, !tbaa !29
  %t57 = load i64, ptr %l29, !tbaa !24
  %t58 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t56, i64 %t57)
  store ptr %t58, ptr %l30
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  %t66 = xor i1 %t64, true
  store i1 %t66, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_97396c871582ed15_57852cddb00c7721)
  unreachable
bb17:
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_4e30153e8dd87e24_c063a5f8ea87c90)
  unreachable
bb23:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t13 = trunc i64 20 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisText(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l21 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d2, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i32 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load i32, ptr %l5, !tbaa !23
  store i32 %t7, ptr %l2, !tbaa !23
  %t8 = load i32, ptr %l2, !tbaa !23
  %t10 = icmp slt i32 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = icmp eq i32 %t13, %t14
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l15
  br label %bb7
bb7:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l21
  br label %bb10
bb9:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb11
bb10:
  %t35 = load i32, ptr %l2, !tbaa !23
  %t36 = load i32, ptr %l21, !tbaa !23
  %t38 = icmp eq i32 %t36, %t35
  store i1 %t38, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l16, !tbaa !21
  store i1 %t40, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i1, ptr %l12, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudgeOut(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l6 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
  store i64 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l63 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb9
bb6:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l22, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l22, !tbaa !24
  store i64 %t38, ptr %l19, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l19, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb11, label %bb12
bb11:
  br label %bb35
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Block", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l41, !tbaa !27
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  store ptr %t67, ptr %l8, !tbaa !29
  %t69 = load ptr, ptr %l8, !tbaa !29
  store ptr %t69, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t70 = load ptr, ptr %l44, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l44, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 17}
  %t76 = icmp eq i64 %t74, 0
  store i1 %t76, ptr %l45, !tbaa !21
  br label %bb15
bb15:
  %t77 = load i1, ptr %l45, !tbaa !21
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t78 = load ptr, ptr %l8, !tbaa !29
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t80, i32 0, i32 1
  %t82 = load i32, ptr %t81
  store i32 %t82, ptr %l9, !tbaa !23
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l10, !tbaa !29
  br label %bb18
bb17:
  br label %bb27
bb18:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l10, !tbaa !29
  %t94 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %t90, ptr %t91)
  store i1 %t94, ptr %l54
  br label %bb19
bb19:
  %t95 = load i1, ptr %l54, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Block", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t101 = load i64, ptr %l7, !tbaa !24
  %t103 = add i64 %t101, 1
  %t104 = load i32, ptr %l9, !tbaa !23
  %t106 = sext i32 %t104 to i64
  %t111 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonlyCalled(ptr %v0, ptr %v1, ptr %t96, { i64, ptr } %t100, i64 %t103, i64 %t106)
  store i1 %t111, ptr %l63
  br label %bb22
bb21:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb23
bb22:
  %t112 = load i1, ptr %l63, !tbaa !21
  store i1 %t112, ptr %l55, !tbaa !21
  br label %bb23
bb23:
  %t113 = load i1, ptr %l55, !tbaa !21
  br i1 %t113, label %bb24, label %bb25
bb24:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 134
  store i1 true, ptr %t116, !tbaa !21
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_fc6a508fadcedae3_fc22fb2e32e5f087)
  unreachable
bb32:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwStmt(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  br label %bb33
bb33:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/scope:Scoper", ptr %t122, i32 0, i32 134
  store i1 false, ptr %t124, !tbaa !21
  br label %bb34
bb34:
  %t125 = load i64, ptr %l6, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l6, !tbaa !24
  br label %bb10
bb35:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l95 = alloca ptr
  %l97 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %l136 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l145 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l170 = alloca { i64, ptr }
  %l178 = alloca ptr
  %l179 = alloca i1
  %l186 = alloca ptr
  %l189 = alloca i64
  %l201 = alloca ptr
  %l202 = alloca i1
  %l220 = alloca ptr
  %l221 = alloca i1
  %l234 = alloca { i64, ptr }
  %l246 = alloca ptr
  %l247 = alloca i1
  %l260 = alloca { i64, ptr }
  %l276 = alloca { i64, ptr }
  %l289 = alloca ptr
  %l290 = alloca i1
  %l307 = alloca { i64, ptr }
  %l321 = alloca { i64, ptr }
  %l332 = alloca ptr
  %l333 = alloca i1
  %l338 = alloca ptr
  %l339 = alloca i1
  %l356 = alloca { i64, ptr }
  %l366 = alloca ptr
  %l367 = alloca i1
  %l375 = alloca ptr
  %l376 = alloca i1
  %l389 = alloca { i64, ptr }
  %l392 = alloca ptr
  %l393 = alloca i1
  %l403 = alloca ptr
  %l404 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t6 = load ptr, ptr %l62, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l62, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l63, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l63, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l3, !tbaa !29
  br label %bb12
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t21 = load ptr, ptr %l68, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l68, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 4
  store i1 %t27, ptr %l69, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l69, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb29
bb12:
  %t35 = load ptr, ptr %l3, !tbaa !29
  store ptr %t35, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t36 = load ptr, ptr %l74, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb13, label %bb14
bb13:
  %t39 = load ptr, ptr %l74, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 8}
  %t42 = icmp eq i64 %t40, 0
  store i1 %t42, ptr %l75, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l75, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t46, i32 0, i32 2
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l4, !tbaa !23
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t50 = load i1, ptr %l2, !tbaa !21
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb18, label %bb19
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l4, !tbaa !23
  %t57 = sext i32 %t55 to i64
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeepParam(ptr %v0, ptr %t54, i64 %t57)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_8b1069152ab8ab4d_46bfa78d80464041)
  unreachable
bb27:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  br label %bb28
bb28:
  br label %bb236
bb29:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t65 = load ptr, ptr %l87, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb30, label %bb31
bb30:
  %t68 = load ptr, ptr %l87, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 18}
  %t71 = icmp eq i64 %t69, 3
  store i1 %t71, ptr %l88, !tbaa !21
  br label %bb31
bb31:
  %t72 = load i1, ptr %l88, !tbaa !21
  br i1 %t72, label %bb32, label %bb33
bb32:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l5, !tbaa !29
  br label %bb34
bb33:
  br label %bb41
bb34:
  %t79 = load i1, ptr %l2, !tbaa !21
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb35, label %bb36
bb35:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l95, !tbaa !29
  %t84 = load ptr, ptr %l5, !tbaa !29
  %t86 = call i64 @compiler_2fscope_2eregionRoot(ptr %v1, ptr %t84)
  store i64 %t86, ptr %l97
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t87 = load ptr, ptr %l95, !tbaa !29
  %t88 = load i64, ptr %l97, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeepParam(ptr %v0, ptr %t87, i64 %t88)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %v1, ptr %t89, ptr %t90)
  br label %bb40
bb40:
  br label %bb236
bb41:
  %t93 = load ptr, ptr %l1, !tbaa !29
  store ptr %t93, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t94 = load ptr, ptr %l100, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb42, label %bb43
bb42:
  %t97 = load ptr, ptr %l100, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 18}
  %t100 = icmp eq i64 %t98, 5
  store i1 %t100, ptr %l101, !tbaa !21
  br label %bb43
bb43:
  %t101 = load i1, ptr %l101, !tbaa !21
  br i1 %t101, label %bb44, label %bb45
bb44:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 2
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l6, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l6, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Promote", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t108, ptr %t112, i1 %t114)
  br label %bb47
bb47:
  br label %bb236
bb48:
  %t118 = load ptr, ptr %l1, !tbaa !29
  store ptr %t118, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t119 = load ptr, ptr %l111, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb49, label %bb50
bb49:
  %t122 = load ptr, ptr %l111, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 18}
  %t125 = icmp eq i64 %t123, 6
  store i1 %t125, ptr %l112, !tbaa !21
  br label %bb50
bb50:
  %t126 = load i1, ptr %l112, !tbaa !21
  br i1 %t126, label %bb51, label %bb52
bb51:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t129, i32 0, i32 2
  %t131 = load ptr, ptr %t130
  store ptr %t131, ptr %l7, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwCall(ptr %v0, ptr %v1, ptr %t133, ptr %t134)
  br label %bb54
bb54:
  br label %bb236
bb55:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t138 = load ptr, ptr %l119, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb56, label %bb57
bb56:
  %t141 = load ptr, ptr %l119, !tbaa !29
  %t142 = load i64, ptr %t141, !range !{i64 0, i64 18}
  %t144 = icmp eq i64 %t142, 7
  store i1 %t144, ptr %l120, !tbaa !21
  br label %bb57
bb57:
  %t145 = load i1, ptr %l120, !tbaa !21
  br i1 %t145, label %bb58, label %bb59
bb58:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l8, !tbaa !29
  br label %bb60
bb59:
  br label %bb69
bb60:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l8, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Make", ptr %t153, i32 0, i32 3
  %t156 = load ptr, ptr %t155, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t152, ptr %t156, i1 true)
  br label %bb61
bb61:
  %t159 = load ptr, ptr %l8, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Make", ptr %t159, i32 0, i32 2
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t164 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  store i64 %t166, ptr %l11, !tbaa !24
  br label %bb62
bb62:
  %t168 = load i64, ptr %l10, !tbaa !24
  %t169 = load i64, ptr %l11, !tbaa !24
  %t172 = icmp slt i64 %t168, %t169
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb63, label %bb64
bb63:
  br label %bb68
bb64:
  br label %bb65
bb65:
  %t176 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t176, ptr %l136, !tbaa !27
  %t177 = load i64, ptr %l10, !tbaa !24
  %t179 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr ptr, ptr %t180, i64 %t177
  %t182 = load ptr, ptr %t181, !tbaa !39
  %t184 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t184, ptr %t182, i1 false)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t189 = load i64, ptr %l10, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l10, !tbaa !24
  br label %bb62
bb68:
  br label %bb236
bb69:
  %t193 = load ptr, ptr %l1, !tbaa !29
  store ptr %t193, ptr %l144, !tbaa !29
  store i1 false, ptr %l145, !tbaa !21
  %t194 = load ptr, ptr %l144, !tbaa !29
  %t195 = icmp ne ptr %t194, null
  br i1 %t195, label %bb70, label %bb71
bb70:
  %t197 = load ptr, ptr %l144, !tbaa !29
  %t198 = load i64, ptr %t197, !range !{i64 0, i64 18}
  %t200 = icmp eq i64 %t198, 8
  store i1 %t200, ptr %l145, !tbaa !21
  br label %bb71
bb71:
  %t201 = load i1, ptr %l145, !tbaa !21
  br i1 %t201, label %bb72, label %bb73
bb72:
  %t202 = load ptr, ptr %l1, !tbaa !29
  %t204 = getelementptr { i64, [5 x i64] }, ptr %t202, i32 0, i32 1
  %t205 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t204, i32 0, i32 2
  %t206 = load ptr, ptr %t205
  store ptr %t206, ptr %l13, !tbaa !29
  br label %bb74
bb73:
  br label %bb77
bb74:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l13, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Collect", ptr %t209, i32 0, i32 0
  %t212 = load ptr, ptr %t211, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t208, ptr %t212, i1 true)
  br label %bb75
bb75:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l13, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Collect", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwBlock(ptr %v0, ptr %v1, ptr %t215, ptr %t219)
  br label %bb76
bb76:
  br label %bb236
bb77:
  %t223 = load ptr, ptr %l1, !tbaa !29
  store ptr %t223, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t224 = load ptr, ptr %l157, !tbaa !29
  %t225 = icmp ne ptr %t224, null
  br i1 %t225, label %bb78, label %bb79
bb78:
  %t227 = load ptr, ptr %l157, !tbaa !29
  %t228 = load i64, ptr %t227, !range !{i64 0, i64 18}
  %t230 = icmp eq i64 %t228, 9
  store i1 %t230, ptr %l158, !tbaa !21
  br label %bb79
bb79:
  %t231 = load i1, ptr %l158, !tbaa !21
  br i1 %t231, label %bb80, label %bb81
bb80:
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr { i64, [5 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t234, i32 0, i32 4
  %t236 = load { i64, ptr }, ptr %t235
  store { i64, ptr } %t236, ptr %l14, !tbaa !27
  br label %bb82
bb81:
  br label %bb90
bb82:
  %t238 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t238, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t240 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t240, 0
  store i64 %t242, ptr %l17, !tbaa !24
  br label %bb83
bb83:
  %t244 = load i64, ptr %l16, !tbaa !24
  %t245 = load i64, ptr %l17, !tbaa !24
  %t248 = icmp slt i64 %t244, %t245
  %t250 = xor i1 %t248, true
  br i1 %t250, label %bb84, label %bb85
bb84:
  br label %bb89
bb85:
  br label %bb86
bb86:
  %t252 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t252, ptr %l170, !tbaa !27
  %t253 = load i64, ptr %l16, !tbaa !24
  %t255 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr ptr, ptr %t256, i64 %t253
  %t258 = load ptr, ptr %t257, !tbaa !39
  %t260 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t260, ptr %t258, i1 true)
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t265 = load i64, ptr %l16, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l16, !tbaa !24
  br label %bb83
bb89:
  br label %bb236
bb90:
  %t269 = load ptr, ptr %l1, !tbaa !29
  store ptr %t269, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t270 = load ptr, ptr %l178, !tbaa !29
  %t271 = icmp ne ptr %t270, null
  br i1 %t271, label %bb91, label %bb92
bb91:
  %t273 = load ptr, ptr %l178, !tbaa !29
  %t274 = load i64, ptr %t273, !range !{i64 0, i64 18}
  %t276 = icmp eq i64 %t274, 10
  store i1 %t276, ptr %l179, !tbaa !21
  br label %bb92
bb92:
  %t277 = load i1, ptr %l179, !tbaa !21
  br i1 %t277, label %bb93, label %bb94
bb93:
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t280 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 1
  %t281 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t280, i32 0, i32 2
  %t282 = load ptr, ptr %t281
  store ptr %t282, ptr %l19, !tbaa !29
  br label %bb95
bb94:
  br label %bb104
bb95:
  %t284 = load i1, ptr %l2, !tbaa !21
  %t286 = xor i1 %t284, true
  br i1 %t286, label %bb96, label %bb97
bb96:
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l186, !tbaa !29
  %t289 = load ptr, ptr %l19, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Slice", ptr %t289, i32 0, i32 0
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = call i64 @compiler_2fscope_2eregionRoot(ptr %v1, ptr %t292)
  store i64 %t294, ptr %l189
  br label %bb98
bb97:
  br label %bb100
bb98:
  %t295 = load ptr, ptr %l186, !tbaa !29
  %t296 = load i64, ptr %l189, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeepParam(ptr %v0, ptr %t295, i64 %t296)
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l19, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Slice", ptr %t298, i32 0, i32 0
  %t301 = load ptr, ptr %t300, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %v1, ptr %t297, ptr %t301)
  br label %bb101
bb101:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load ptr, ptr %l19, !tbaa !29
  %t307 = getelementptr %"compiler/typed:Slice", ptr %t305, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t304, ptr %t308, i1 true)
  br label %bb102
bb102:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load ptr, ptr %l19, !tbaa !29
  %t315 = getelementptr %"compiler/typed:Slice", ptr %t313, i32 0, i32 2
  %t316 = load ptr, ptr %t315, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t312, ptr %t316, i1 true)
  br label %bb103
bb103:
  br label %bb236
bb104:
  %t320 = load ptr, ptr %l1, !tbaa !29
  store ptr %t320, ptr %l201, !tbaa !29
  store i1 false, ptr %l202, !tbaa !21
  %t321 = load ptr, ptr %l201, !tbaa !29
  %t322 = icmp ne ptr %t321, null
  br i1 %t322, label %bb105, label %bb106
bb105:
  %t324 = load ptr, ptr %l201, !tbaa !29
  %t325 = load i64, ptr %t324, !range !{i64 0, i64 18}
  %t327 = icmp eq i64 %t325, 11
  store i1 %t327, ptr %l202, !tbaa !21
  br label %bb106
bb106:
  %t328 = load i1, ptr %l202, !tbaa !21
  br i1 %t328, label %bb107, label %bb108
bb107:
  %t329 = load ptr, ptr %l1, !tbaa !29
  %t331 = getelementptr { i64, [5 x i64] }, ptr %t329, i32 0, i32 1
  %t332 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t331, i32 0, i32 2
  %t333 = load ptr, ptr %t332
  store ptr %t333, ptr %l20, !tbaa !29
  br label %bb109
bb108:
  br label %bb113
bb109:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load ptr, ptr %l20, !tbaa !29
  %t338 = getelementptr %"compiler/typed:Cond", ptr %t336, i32 0, i32 0
  %t339 = load ptr, ptr %t338, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t335, ptr %t339, i1 true)
  br label %bb110
bb110:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l20, !tbaa !29
  %t346 = getelementptr %"compiler/typed:Cond", ptr %t344, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !29
  %t348 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t343, ptr %t347, i1 %t348)
  br label %bb111
bb111:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l20, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Cond", ptr %t353, i32 0, i32 2
  %t356 = load ptr, ptr %t355, !tbaa !29
  %t358 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t352, ptr %t356, i1 %t358)
  br label %bb112
bb112:
  br label %bb236
bb113:
  %t362 = load ptr, ptr %l1, !tbaa !29
  store ptr %t362, ptr %l220, !tbaa !29
  store i1 false, ptr %l221, !tbaa !21
  %t363 = load ptr, ptr %l220, !tbaa !29
  %t364 = icmp ne ptr %t363, null
  br i1 %t364, label %bb114, label %bb115
bb114:
  %t366 = load ptr, ptr %l220, !tbaa !29
  %t367 = load i64, ptr %t366, !range !{i64 0, i64 18}
  %t369 = icmp eq i64 %t367, 12
  store i1 %t369, ptr %l221, !tbaa !21
  br label %bb115
bb115:
  %t370 = load i1, ptr %l221, !tbaa !21
  br i1 %t370, label %bb116, label %bb117
bb116:
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [5 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t373, i32 0, i32 2
  %t375 = load ptr, ptr %t374
  store ptr %t375, ptr %l21, !tbaa !29
  br label %bb118
bb117:
  br label %bb127
bb118:
  %t377 = load ptr, ptr %l21, !tbaa !29
  %t379 = getelementptr %"compiler/typed:Seq", ptr %t377, i32 0, i32 0
  %t380 = load { i64, ptr }, ptr %t379, !tbaa !27
  store { i64, ptr } %t380, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t382 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t382, 0
  store i64 %t384, ptr %l24, !tbaa !24
  br label %bb119
bb119:
  %t386 = load i64, ptr %l23, !tbaa !24
  %t387 = load i64, ptr %l24, !tbaa !24
  %t390 = icmp slt i64 %t386, %t387
  %t392 = xor i1 %t390, true
  br i1 %t392, label %bb120, label %bb121
bb120:
  br label %bb125
bb121:
  br label %bb122
bb122:
  %t394 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t394, ptr %l234, !tbaa !27
  %t395 = load i64, ptr %l23, !tbaa !24
  %t397 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t398 = load ptr, ptr %t397, !tbaa !27
  %t399 = getelementptr ptr, ptr %t398, i64 %t395
  %t400 = load ptr, ptr %t399, !tbaa !39
  %t402 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwStmt(ptr %v0, ptr %v1, ptr %t402, ptr %t400)
  br label %bb123
bb123:
  br label %bb124
bb124:
  %t407 = load i64, ptr %l23, !tbaa !24
  %t409 = add i64 %t407, 1
  store i64 %t409, ptr %l23, !tbaa !24
  br label %bb119
bb125:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load ptr, ptr %l21, !tbaa !29
  %t414 = getelementptr %"compiler/typed:Seq", ptr %t412, i32 0, i32 1
  %t415 = load ptr, ptr %t414, !tbaa !29
  %t416 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t411, ptr %t415, i1 %t416)
  br label %bb126
bb126:
  br label %bb236
bb127:
  %t420 = load ptr, ptr %l1, !tbaa !29
  store ptr %t420, ptr %l246, !tbaa !29
  store i1 false, ptr %l247, !tbaa !21
  %t421 = load ptr, ptr %l246, !tbaa !29
  %t422 = icmp ne ptr %t421, null
  br i1 %t422, label %bb128, label %bb129
bb128:
  %t424 = load ptr, ptr %l246, !tbaa !29
  %t425 = load i64, ptr %t424, !range !{i64 0, i64 18}
  %t427 = icmp eq i64 %t425, 13
  store i1 %t427, ptr %l247, !tbaa !21
  br label %bb129
bb129:
  %t428 = load i1, ptr %l247, !tbaa !21
  br i1 %t428, label %bb130, label %bb131
bb130:
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t431 = getelementptr { i64, [5 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t431, i32 0, i32 2
  %t433 = load ptr, ptr %t432
  store ptr %t433, ptr %l26, !tbaa !29
  br label %bb132
bb131:
  br label %bb148
bb132:
  %t435 = load ptr, ptr %l26, !tbaa !29
  %t437 = getelementptr %"compiler/typed:Match", ptr %t435, i32 0, i32 0
  %t438 = load { i64, ptr }, ptr %t437, !tbaa !27
  store { i64, ptr } %t438, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t440 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t442 = extractvalue { i64, ptr } %t440, 0
  store i64 %t442, ptr %l29, !tbaa !24
  br label %bb133
bb133:
  %t444 = load i64, ptr %l28, !tbaa !24
  %t445 = load i64, ptr %l29, !tbaa !24
  %t448 = icmp slt i64 %t444, %t445
  %t450 = xor i1 %t448, true
  br i1 %t450, label %bb134, label %bb135
bb134:
  br label %bb139
bb135:
  br label %bb136
bb136:
  %t452 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t452, ptr %l260, !tbaa !27
  %t453 = load i64, ptr %l28, !tbaa !24
  %t455 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !27
  %t457 = getelementptr ptr, ptr %t456, i64 %t453
  %t458 = load ptr, ptr %t457, !tbaa !39
  %t460 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwStmt(ptr %v0, ptr %v1, ptr %t460, ptr %t458)
  br label %bb137
bb137:
  br label %bb138
bb138:
  %t465 = load i64, ptr %l28, !tbaa !24
  %t467 = add i64 %t465, 1
  store i64 %t467, ptr %l28, !tbaa !24
  br label %bb133
bb139:
  %t469 = load ptr, ptr %l26, !tbaa !29
  %t471 = getelementptr %"compiler/typed:Match", ptr %t469, i32 0, i32 1
  %t472 = load { i64, ptr }, ptr %t471, !tbaa !27
  store { i64, ptr } %t472, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t474 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t476 = extractvalue { i64, ptr } %t474, 0
  store i64 %t476, ptr %l33, !tbaa !24
  br label %bb140
bb140:
  %t478 = load i64, ptr %l32, !tbaa !24
  %t479 = load i64, ptr %l33, !tbaa !24
  %t482 = icmp slt i64 %t478, %t479
  %t484 = xor i1 %t482, true
  br i1 %t484, label %bb141, label %bb142
bb141:
  br label %bb146
bb142:
  br label %bb143
bb143:
  %t486 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t486, ptr %l276, !tbaa !27
  %t487 = load i64, ptr %l32, !tbaa !24
  %t489 = getelementptr { i64, ptr }, ptr %l276, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = getelementptr ptr, ptr %t490, i64 %t487
  %t492 = load ptr, ptr %t491, !tbaa !39
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t497 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwArm(ptr %v0, ptr %v1, ptr %t494, ptr %t492, i1 %t497)
  br label %bb144
bb144:
  br label %bb145
bb145:
  %t501 = load i64, ptr %l32, !tbaa !24
  %t503 = add i64 %t501, 1
  store i64 %t503, ptr %l32, !tbaa !24
  br label %bb140
bb146:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load ptr, ptr %l26, !tbaa !29
  %t508 = getelementptr %"compiler/typed:Match", ptr %t506, i32 0, i32 2
  %t509 = load ptr, ptr %t508, !tbaa !29
  %t510 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwArm(ptr %v0, ptr %v1, ptr %t505, ptr %t509, i1 %t510)
  br label %bb147
bb147:
  br label %bb236
bb148:
  %t514 = load ptr, ptr %l1, !tbaa !29
  store ptr %t514, ptr %l289, !tbaa !29
  store i1 false, ptr %l290, !tbaa !21
  %t515 = load ptr, ptr %l289, !tbaa !29
  %t516 = icmp ne ptr %t515, null
  br i1 %t516, label %bb149, label %bb150
bb149:
  %t518 = load ptr, ptr %l289, !tbaa !29
  %t519 = load i64, ptr %t518, !range !{i64 0, i64 18}
  %t521 = icmp eq i64 %t519, 14
  store i1 %t521, ptr %l290, !tbaa !21
  br label %bb150
bb150:
  %t522 = load i1, ptr %l290, !tbaa !21
  br i1 %t522, label %bb151, label %bb152
bb151:
  %t523 = load ptr, ptr %l1, !tbaa !29
  %t525 = getelementptr { i64, [5 x i64] }, ptr %t523, i32 0, i32 1
  %t526 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t525, i32 0, i32 2
  %t527 = load ptr, ptr %t526
  store ptr %t527, ptr %l35, !tbaa !29
  br label %bb153
bb152:
  br label %bb169
bb153:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load ptr, ptr %l35, !tbaa !29
  %t532 = getelementptr %"compiler/typed:Try", ptr %t530, i32 0, i32 0
  %t533 = load ptr, ptr %t532, !tbaa !29
  %t534 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t529, ptr %t533, i1 %t534)
  br label %bb154
bb154:
  %t538 = load ptr, ptr %l35, !tbaa !29
  %t540 = getelementptr %"compiler/typed:Try", ptr %t538, i32 0, i32 1
  %t541 = load { i64, ptr }, ptr %t540, !tbaa !27
  store { i64, ptr } %t541, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t543 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t545 = extractvalue { i64, ptr } %t543, 0
  store i64 %t545, ptr %l38, !tbaa !24
  br label %bb155
bb155:
  %t547 = load i64, ptr %l37, !tbaa !24
  %t548 = load i64, ptr %l38, !tbaa !24
  %t551 = icmp slt i64 %t547, %t548
  %t553 = xor i1 %t551, true
  br i1 %t553, label %bb156, label %bb157
bb156:
  br label %bb168
bb157:
  br label %bb158
bb158:
  %t555 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t555, ptr %l307, !tbaa !27
  %t556 = load i64, ptr %l37, !tbaa !24
  %t558 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t559 = load ptr, ptr %t558, !tbaa !27
  %t560 = getelementptr ptr, ptr %t559, i64 %t556
  %t561 = load ptr, ptr %t560, !tbaa !39
  store ptr %t561, ptr %l39, !tbaa !29
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load ptr, ptr %l39, !tbaa !29
  %t566 = getelementptr %"compiler/typed:Clause", ptr %t564, i32 0, i32 3
  %t567 = load ptr, ptr %t566, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwBlock(ptr %v0, ptr %v1, ptr %t563, ptr %t567)
  br label %bb159
bb159:
  %t570 = load ptr, ptr %l39, !tbaa !29
  %t572 = getelementptr %"compiler/typed:Clause", ptr %t570, i32 0, i32 4
  %t573 = load { i64, ptr }, ptr %t572, !tbaa !27
  store { i64, ptr } %t573, ptr %l40, !tbaa !27
  store i64 0, ptr %l41, !tbaa !24
  %t575 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t577 = extractvalue { i64, ptr } %t575, 0
  store i64 %t577, ptr %l42, !tbaa !24
  br label %bb160
bb160:
  %t579 = load i64, ptr %l41, !tbaa !24
  %t580 = load i64, ptr %l42, !tbaa !24
  %t583 = icmp slt i64 %t579, %t580
  %t585 = xor i1 %t583, true
  br i1 %t585, label %bb161, label %bb162
bb161:
  br label %bb166
bb162:
  br label %bb163
bb163:
  %t587 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t587, ptr %l321, !tbaa !27
  %t588 = load i64, ptr %l41, !tbaa !24
  %t590 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = getelementptr ptr, ptr %t591, i64 %t588
  %t593 = load ptr, ptr %t592, !tbaa !39
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t598 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t595, ptr %t593, i1 %t598)
  br label %bb164
bb164:
  br label %bb165
bb165:
  %t602 = load i64, ptr %l41, !tbaa !24
  %t604 = add i64 %t602, 1
  store i64 %t604, ptr %l41, !tbaa !24
  br label %bb160
bb166:
  br label %bb167
bb167:
  %t606 = load i64, ptr %l37, !tbaa !24
  %t608 = add i64 %t606, 1
  store i64 %t608, ptr %l37, !tbaa !24
  br label %bb155
bb168:
  br label %bb236
bb169:
  %t610 = load ptr, ptr %l1, !tbaa !29
  store ptr %t610, ptr %l332, !tbaa !29
  store i1 false, ptr %l333, !tbaa !21
  %t611 = load ptr, ptr %l332, !tbaa !29
  %t612 = icmp ne ptr %t611, null
  br i1 %t612, label %bb170, label %bb171
bb170:
  %t614 = load ptr, ptr %l332, !tbaa !29
  %t615 = load i64, ptr %t614, !range !{i64 0, i64 18}
  %t617 = icmp eq i64 %t615, 15
  store i1 %t617, ptr %l333, !tbaa !21
  br label %bb171
bb171:
  %t618 = load i1, ptr %l333, !tbaa !21
  br i1 %t618, label %bb172, label %bb173
bb172:
  %t619 = load ptr, ptr %l1, !tbaa !29
  %t621 = getelementptr { i64, [5 x i64] }, ptr %t619, i32 0, i32 1
  %t622 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t621, i32 0, i32 2
  %t623 = load ptr, ptr %t622
  store ptr %t623, ptr %l44, !tbaa !29
  br label %bb174
bb173:
  br label %bb200
bb174:
  %t625 = load ptr, ptr %l44, !tbaa !29
  store ptr %t625, ptr %l338, !tbaa !29
  store i1 false, ptr %l339, !tbaa !21
  %t626 = load ptr, ptr %l338, !tbaa !29
  %t627 = icmp ne ptr %t626, null
  br i1 %t627, label %bb175, label %bb176
bb175:
  %t629 = load ptr, ptr %l338, !tbaa !29
  %t630 = load i64, ptr %t629, !range !{i64 0, i64 3}
  %t632 = icmp eq i64 %t630, 1
  store i1 %t632, ptr %l339, !tbaa !21
  br label %bb176
bb176:
  %t633 = load i1, ptr %l339, !tbaa !21
  br i1 %t633, label %bb177, label %bb178
bb177:
  %t634 = load ptr, ptr %l44, !tbaa !29
  %t636 = getelementptr { i64, [4 x i64] }, ptr %t634, i32 0, i32 1
  %t637 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t636, i32 0, i32 0
  %t638 = load i32, ptr %t637
  store i32 %t638, ptr %l45, !tbaa !23
  %t640 = load ptr, ptr %l44, !tbaa !29
  %t642 = getelementptr { i64, [4 x i64] }, ptr %t640, i32 0, i32 1
  %t643 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t642, i32 0, i32 1
  %t644 = load { i64, ptr }, ptr %t643
  store { i64, ptr } %t644, ptr %l46, !tbaa !27
  br label %bb179
bb178:
  br label %bb187
bb179:
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t648 = getelementptr %"compiler/scope:Scoper", ptr %t646, i32 0, i32 134
  %t649 = load i1, ptr %t648, !tbaa !21
  store i1 %t649, ptr %l47, !tbaa !21
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = getelementptr %"compiler/scope:Scoper", ptr %t651, i32 0, i32 134
  store i1 false, ptr %t653, !tbaa !21
  %t654 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t654, ptr %l48, !tbaa !27
  store i64 0, ptr %l49, !tbaa !24
  %t656 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t658 = extractvalue { i64, ptr } %t656, 0
  store i64 %t658, ptr %l50, !tbaa !24
  br label %bb180
bb180:
  %t660 = load i64, ptr %l49, !tbaa !24
  %t661 = load i64, ptr %l50, !tbaa !24
  %t664 = icmp slt i64 %t660, %t661
  %t666 = xor i1 %t664, true
  br i1 %t666, label %bb181, label %bb182
bb181:
  br label %bb186
bb182:
  br label %bb183
bb183:
  %t668 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t668, ptr %l356, !tbaa !27
  %t669 = load i64, ptr %l49, !tbaa !24
  %t671 = getelementptr { i64, ptr }, ptr %l356, i32 0, i32 1
  %t672 = load ptr, ptr %t671, !tbaa !27
  %t673 = getelementptr ptr, ptr %t672, i64 %t669
  %t674 = load ptr, ptr %t673, !tbaa !39
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t677 = load i32, ptr %l45, !tbaa !23
  %t679 = sext i32 %t677 to i64
  %t681 = load i1, ptr %l47, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwCapture(ptr %v0, ptr %v1, ptr %t676, i64 %t679, ptr %t674, i1 %t681)
  br label %bb184
bb184:
  br label %bb185
bb185:
  %t686 = load i64, ptr %l49, !tbaa !24
  %t688 = add i64 %t686, 1
  store i64 %t688, ptr %l49, !tbaa !24
  br label %bb180
bb186:
  br label %bb199
bb187:
  %t690 = load ptr, ptr %l44, !tbaa !29
  store ptr %t690, ptr %l366, !tbaa !29
  store i1 false, ptr %l367, !tbaa !21
  %t691 = load ptr, ptr %l366, !tbaa !29
  %t692 = icmp ne ptr %t691, null
  br i1 %t692, label %bb188, label %bb189
bb188:
  %t694 = load ptr, ptr %l366, !tbaa !29
  %t695 = load i64, ptr %t694, !range !{i64 0, i64 3}
  %t697 = icmp eq i64 %t695, 2
  store i1 %t697, ptr %l367, !tbaa !21
  br label %bb189
bb189:
  %t698 = load i1, ptr %l367, !tbaa !21
  br i1 %t698, label %bb190, label %bb191
bb190:
  %t699 = load ptr, ptr %l44, !tbaa !29
  %t701 = getelementptr { i64, [4 x i64] }, ptr %t699, i32 0, i32 1
  %t702 = getelementptr { i32, ptr, i32 }, ptr %t701, i32 0, i32 1
  %t703 = load ptr, ptr %t702
  store ptr %t703, ptr %l52, !tbaa !29
  br label %bb192
bb191:
  br label %bb194
bb192:
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load ptr, ptr %l52, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t705, ptr %t706, i1 false)
  br label %bb193
bb193:
  br label %bb199
bb194:
  br i1 true, label %bb195, label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb198
bb197:
  br label %bb199
bb198:
  call void @__olang_check_failed(ptr @olang_loc_da7e2501b5a1c31c_336a9d74a1bc00b0)
  unreachable
bb199:
  br label %bb236
bb200:
  %t710 = load ptr, ptr %l1, !tbaa !29
  store ptr %t710, ptr %l375, !tbaa !29
  store i1 false, ptr %l376, !tbaa !21
  %t711 = load ptr, ptr %l375, !tbaa !29
  %t712 = icmp ne ptr %t711, null
  br i1 %t712, label %bb201, label %bb202
bb201:
  %t714 = load ptr, ptr %l375, !tbaa !29
  %t715 = load i64, ptr %t714, !range !{i64 0, i64 18}
  %t717 = icmp eq i64 %t715, 16
  store i1 %t717, ptr %l376, !tbaa !21
  br label %bb202
bb202:
  %t718 = load i1, ptr %l376, !tbaa !21
  br i1 %t718, label %bb203, label %bb204
bb203:
  %t719 = load ptr, ptr %l1, !tbaa !29
  %t721 = getelementptr { i64, [5 x i64] }, ptr %t719, i32 0, i32 1
  %t722 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t721, i32 0, i32 2
  %t723 = load ptr, ptr %t722
  store ptr %t723, ptr %l53, !tbaa !29
  br label %bb205
bb204:
  br label %bb224
bb205:
  %t725 = load ptr, ptr %l53, !tbaa !29
  %t727 = getelementptr %"compiler/typed:Text", ptr %t725, i32 0, i32 0
  %t728 = load { i64, ptr }, ptr %t727, !tbaa !27
  store { i64, ptr } %t728, ptr %l54, !tbaa !27
  store i64 0, ptr %l55, !tbaa !24
  %t730 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t732 = extractvalue { i64, ptr } %t730, 0
  store i64 %t732, ptr %l56, !tbaa !24
  br label %bb206
bb206:
  %t734 = load i64, ptr %l55, !tbaa !24
  %t735 = load i64, ptr %l56, !tbaa !24
  %t738 = icmp slt i64 %t734, %t735
  %t740 = xor i1 %t738, true
  br i1 %t740, label %bb207, label %bb208
bb207:
  br label %bb223
bb208:
  br label %bb209
bb209:
  %t742 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t742, ptr %l389, !tbaa !27
  %t743 = load i64, ptr %l55, !tbaa !24
  %t745 = getelementptr { i64, ptr }, ptr %l389, i32 0, i32 1
  %t746 = load ptr, ptr %t745, !tbaa !27
  %t747 = getelementptr ptr, ptr %t746, i64 %t743
  %t748 = load ptr, ptr %t747, !tbaa !39
  store ptr %t748, ptr %l57, !tbaa !29
  %t750 = load ptr, ptr %l57, !tbaa !29
  store ptr %t750, ptr %l392, !tbaa !29
  store i1 false, ptr %l393, !tbaa !21
  %t751 = load ptr, ptr %l392, !tbaa !29
  %t752 = icmp ne ptr %t751, null
  br i1 %t752, label %bb210, label %bb211
bb210:
  %t754 = load ptr, ptr %l392, !tbaa !29
  %t755 = load i64, ptr %t754, !range !{i64 0, i64 2}
  %t757 = icmp eq i64 %t755, 1
  store i1 %t757, ptr %l393, !tbaa !21
  br label %bb211
bb211:
  %t758 = load i1, ptr %l393, !tbaa !21
  br i1 %t758, label %bb212, label %bb213
bb212:
  %t759 = load ptr, ptr %l57, !tbaa !29
  %t761 = getelementptr { i64, [2 x i64] }, ptr %t759, i32 0, i32 1
  %t762 = getelementptr { ptr }, ptr %t761, i32 0, i32 0
  %t763 = load ptr, ptr %t762
  store ptr %t763, ptr %l58, !tbaa !29
  br label %bb214
bb213:
  br label %bb216
bb214:
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t766 = load ptr, ptr %l58, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t765, ptr %t766, i1 true)
  br label %bb215
bb215:
  br label %bb221
bb216:
  br i1 true, label %bb217, label %bb218
bb217:
  br label %bb219
bb218:
  br label %bb220
bb219:
  br label %bb221
bb220:
  call void @__olang_check_failed(ptr @olang_loc_1bad1049d3f03857_11a2742c169a90eb)
  unreachable
bb221:
  br label %bb222
bb222:
  %t770 = load i64, ptr %l55, !tbaa !24
  %t772 = add i64 %t770, 1
  store i64 %t772, ptr %l55, !tbaa !24
  br label %bb206
bb223:
  br label %bb236
bb224:
  %t774 = load ptr, ptr %l1, !tbaa !29
  store ptr %t774, ptr %l403, !tbaa !29
  store i1 false, ptr %l404, !tbaa !21
  %t775 = load ptr, ptr %l403, !tbaa !29
  %t776 = icmp ne ptr %t775, null
  br i1 %t776, label %bb225, label %bb226
bb225:
  %t778 = load ptr, ptr %l403, !tbaa !29
  %t779 = load i64, ptr %t778, !range !{i64 0, i64 18}
  %t781 = icmp eq i64 %t779, 17
  store i1 %t781, ptr %l404, !tbaa !21
  br label %bb226
bb226:
  %t782 = load i1, ptr %l404, !tbaa !21
  br i1 %t782, label %bb227, label %bb228
bb227:
  %t783 = load ptr, ptr %l1, !tbaa !29
  %t785 = getelementptr { i64, [5 x i64] }, ptr %t783, i32 0, i32 1
  %t786 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t785, i32 0, i32 2
  %t787 = load ptr, ptr %t786
  store ptr %t787, ptr %l59, !tbaa !29
  br label %bb229
bb228:
  br label %bb231
bb229:
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t790 = load ptr, ptr %l59, !tbaa !29
  %t792 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwExpr(ptr %v0, ptr %v1, ptr %t789, ptr %t790, i1 %t792)
  br label %bb230
bb230:
  br label %bb236
bb231:
  br i1 true, label %bb232, label %bb233
bb232:
  br label %bb234
bb233:
  br label %bb235
bb234:
  br label %bb236
bb235:
  call void @__olang_check_failed(ptr @olang_loc_38b65f81bf15a4b6_abe96c91b906622a)
  unreachable
bb236:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwOutOfRegion(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, ptr %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca i1
  %l7 = alloca %"compiler/scope:fnRecs"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/scope:fnRec"
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l17 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i64
  %l36 = alloca i1
  %l37 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i1
  %l41 = alloca i1
  %l43 = alloca %"compiler/scope:fnRecs"
  %l49 = alloca %"compiler/scope:fnRecs"
  %l50 = alloca i32
  %l52 = alloca %"compiler/scope:fnRecs"
  %l53 = alloca %"compiler/scope:fnRecs"
  %l59 = alloca i64
  %l61 = alloca i64
  %l66 = alloca %"compiler/scope:fnRec"
  %l68 = alloca i64
  %l75 = alloca i1
  %l76 = alloca i1
  %l80 = alloca i1
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = icmp ne ptr %t5, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l13, !tbaa !29
  %t9 = load i64, ptr %t8, !range !{i64 0, i64 5}
  %t11 = icmp eq i64 %t9, 2
  store i1 %t11, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t12 = load i1, ptr %l14, !tbaa !21
  store i1 %t12, ptr %l6, !tbaa !21
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l17, !tbaa !29
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t14)
  store i32 %t16, ptr %l19
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l17, !tbaa !29
  %t18 = load i32, ptr %l19, !tbaa !23
  %t19 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t19, ptr %l20
  br label %bb4
bb4:
  %t20 = load i1, ptr %l20, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t21 = load i1, ptr %l6, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb6:
  br label %bb17
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t25 = load i64, ptr %l2, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwValueArg(ptr %v0, ptr %v1, ptr %v3, ptr %t23, ptr %t24, i64 %t25, i64 %t26, { i64, ptr } %a5, i1 false)
  br label %bb9
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t35 = load i64, ptr %l2, !tbaa !24
  %t39 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeStoresArg(ptr %v0, ptr %v1, ptr %t33, ptr %t34, i64 %t35)
  store i1 %t39, ptr %l30
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t40 = load i1, ptr %l30, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l31, !tbaa !29
  %t42 = load i64, ptr %l4, !tbaa !24
  store i64 %t42, ptr %l32, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load i64, ptr %l2, !tbaa !24
  %t49 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleePutsArg(ptr %v0, ptr %v1, ptr %t43, ptr %t44, i64 %t45)
  store i1 %t49, ptr %l36
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t50 = load ptr, ptr %l31, !tbaa !29
  %t51 = load i64, ptr %l32, !tbaa !24
  %t52 = load i1, ptr %l36, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t50, i64 %t51, i1 %t52)
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %ret
bb17:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l37, !tbaa !29
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t54)
  store i32 %t56, ptr %l39
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l37, !tbaa !29
  %t58 = load i32, ptr %l39, !tbaa !23
  %t59 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t57, i32 %t58)
  store i1 %t59, ptr %l40
  br label %bb19
bb19:
  %t60 = load i1, ptr %l40, !tbaa !21
  br i1 %t60, label %bb20, label %bb21
bb20:
  %t61 = load i1, ptr %l6, !tbaa !21
  store i1 %t61, ptr %l41, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l41, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/scope:Scoper", ptr %t64, i32 0, i32 89
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Call", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %t69, !tbaa !23
  %t72 = sext i32 %t70 to i64
  %t75 = call { i32, %"compiler/scope:fnRecs" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3afnRecs_3e__Hf28901f23b5d22676a93f0159a8b63c2(ptr %v0, ptr %v0, ptr %t66, i64 %t72)
  %t76 = extractvalue { i32, %"compiler/scope:fnRecs" } %t75, 1
  %t77 = extractvalue { i32, %"compiler/scope:fnRecs" } %t75, 0
  store i32 %t77, ptr %l50
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb26, label %ok.79, !prof !99
ok.79:
  store %"compiler/scope:fnRecs" %t76, ptr %l49
  br label %bb25
bb24:
  br label %bb55
bb25:
  %t81 = call %"compiler/scope:fnRecs" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fscope_3afnRecs(ptr %s5, ptr %l49)
  store %"compiler/scope:fnRecs" %t81, ptr %l52
  br label %bb28
bb26:
  br label %bb27
bb27:
  %t82 = call %"compiler/scope:fnRecs" @compiler_2fscope_3afnRecs_2ector(ptr %v0)
  store %"compiler/scope:fnRecs" %t82, ptr %l53
  br label %bb29
bb28:
  %t83 = load %"compiler/scope:fnRecs", ptr %l52
  store %"compiler/scope:fnRecs" %t83, ptr %l43
  br label %bb30
bb29:
  %t84 = load %"compiler/scope:fnRecs", ptr %l53
  store %"compiler/scope:fnRecs" %t84, ptr %l43
  br label %bb30
bb30:
  %t85 = load %"compiler/scope:fnRecs", ptr %l43
  store %"compiler/scope:fnRecs" %t85, ptr %l7
  %t86 = getelementptr %"compiler/scope:fnRecs", ptr %l7, i32 0, i32 1
  %t87 = load i1, ptr %t86, !tbaa !21
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb31, label %bb32
bb31:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t91, i64 %t92, i1 true)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t95 = getelementptr %"compiler/scope:fnRecs", ptr %l7, i32 0, i32 0
  store ptr %t95, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb35
bb35:
  %t97 = load i64, ptr %l9, !tbaa !24
  store i64 %t97, ptr %l59, !tbaa !24
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eLen_3ccompiler_2fscope_3afnRec_3e(ptr %s5, ptr %t98)
  store i64 %t100, ptr %l61
  br label %bb36
bb36:
  %t101 = load i64, ptr %l59, !tbaa !24
  %t102 = load i64, ptr %l61, !tbaa !24
  %t103 = icmp slt i64 %t101, %t102
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb37, label %bb38
bb37:
  br label %bb54
bb38:
  br label %bb39
bb39:
  %t107 = load ptr, ptr %l8, !tbaa !29
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = call %"compiler/scope:fnRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eAt_3ccompiler_2fscope_3afnRec_3e(ptr %s5, ptr %s5, ptr %t107, i64 %t108)
  store %"compiler/scope:fnRec" %t111, ptr %l66
  br label %bb40
bb40:
  %t112 = load %"compiler/scope:fnRec", ptr %l66
  store %"compiler/scope:fnRec" %t112, ptr %l10
  %t113 = getelementptr %"compiler/scope:fnRec", ptr %l10, i32 0, i32 2
  %t114 = load i1, ptr %t113, !tbaa !21
  br i1 %t114, label %bb41, label %bb42
bb41:
  %t116 = load i64, ptr %l2, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l68, !tbaa !24
  br label %bb43
bb42:
  %t120 = load i64, ptr %l2, !tbaa !24
  store i64 %t120, ptr %l68, !tbaa !24
  br label %bb43
bb43:
  %t122 = load i64, ptr %l68, !tbaa !24
  store i64 %t122, ptr %l11, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/scope:fnRec", ptr %l10, i32 0, i32 0
  %t125 = load i64, ptr %t124, !tbaa !24
  %t126 = load i64, ptr %l11, !tbaa !24
  %t130 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumStores(ptr %v0, ptr %t123, i64 %t125, i64 %t126)
  store i1 %t130, ptr %l75
  br label %bb44
bb44:
  %t131 = load i1, ptr %l75, !tbaa !21
  br i1 %t131, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb48
bb46:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/scope:fnRec", ptr %l10, i32 0, i32 0
  %t134 = load i64, ptr %t133, !tbaa !24
  %t135 = load i64, ptr %l11, !tbaa !24
  %t139 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumKeeps(ptr %v0, ptr %t132, i64 %t134, i64 %t135)
  store i1 %t139, ptr %l80
  br label %bb47
bb47:
  %t140 = load i1, ptr %l80, !tbaa !21
  store i1 %t140, ptr %l76, !tbaa !21
  br label %bb48
bb48:
  %t141 = load i1, ptr %l76, !tbaa !21
  br i1 %t141, label %bb49, label %bb50
bb49:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %t142, i64 %t143, i1 true)
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t146 = load i64, ptr %l9, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l9, !tbaa !24
  br label %bb35
bb54:
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb55:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elateDef(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca i1
  %l26 = alloca i1
  %l32 = alloca i64
  %l34 = alloca i64
  %l39 = alloca %"compiler/scope:fnRec"
  %l41 = alloca %"compiler/scope:fnRec"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 149
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_40f69a1a72292384_3f2388abecda0b30)
  unreachable
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 149
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Versions", ptr %t14, i32 0, i32 6
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %s0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l17
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l8, !tbaa !29
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t25 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enamedRecs(ptr %v0, ptr %s0, ptr %s0, ptr %t22, ptr %t23, ptr %l3)
  store i32 %t25, ptr %l19
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb7, label %ok.27, !prof !99
ok.27:
  br label %bb6
bb6:
  br label %bb14
bb7:
  %t28 = load i32, ptr %l19, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/scope:fnRecs", ptr %t32, i32 0, i32 1
  store i1 false, ptr %t34, !tbaa !21
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/scope:fnRecs", ptr %t35, i32 0, i32 2
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t37, i64 %t38)
  store i1 %t41, ptr %l26
  br label %bb9
bb9:
  %t42 = load i1, ptr %l26, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr %"compiler/scope:fnRecs", ptr %t45, i32 0, i32 2
  %t48 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t47, i64 %t48)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  store ptr %l3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t52 = load i64, ptr %l5, !tbaa !24
  store i64 %t52, ptr %l32, !tbaa !24
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eLen_3ccompiler_2fscope_3afnRec_3e(ptr %s0, ptr %t53)
  store i64 %t55, ptr %l34
  br label %bb16
bb16:
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = load i64, ptr %l34, !tbaa !24
  %t58 = icmp slt i64 %t56, %t57
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb18:
  br label %bb19
bb19:
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = call %"compiler/scope:fnRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eAt_3ccompiler_2fscope_3afnRec_3e(ptr %s0, ptr %s0, ptr %t62, i64 %t63)
  store %"compiler/scope:fnRec" %t66, ptr %l39
  br label %bb20
bb20:
  %t68 = call %"compiler/scope:fnRec" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fscope_3afnRec(ptr %s4, ptr %l39)
  store %"compiler/scope:fnRec" %t68, ptr %l41
  br label %bb21
bb21:
  %t69 = load %"compiler/scope:fnRec", ptr %l41
  %t70 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2eaddRec(ptr %v1, ptr %s4, ptr %t70, %"compiler/scope:fnRec" %t69)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t74 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l5, !tbaa !24
  br label %bb15
bb24:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eletBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca i32
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca %"compiler/scope:Val"
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca { i64, [2 x i64] }
  %l17 = alloca { i64, [1 x i64] }
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca { i64, [1 x i64] }
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca { i64, [2 x i64] }
  %l24 = alloca ptr
  %l25 = alloca %"compiler/scope:Val"
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca { i64, [2 x i64] }
  %l31 = alloca { i64, [2 x i64] }
  %l32 = alloca i64
  %l34 = alloca %"compiler/scope:Val"
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i64
  %l48 = alloca %"compiler/typed:Local"
  %l77 = alloca i1
  %l90 = alloca { i64, [2 x i64] }
  %l94 = alloca i1
  %l96 = alloca ptr
  %l101 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l102 = alloca i1
  %l106 = alloca { i64, [2 x i64] }
  %l110 = alloca { i64, [2 x i64] }
  %l113 = alloca ptr
  %l115 = alloca i64
  %l118 = alloca { i64, [2 x i64] }
  %l121 = alloca i1
  %l124 = alloca i1
  %l126 = alloca i1
  %l129 = alloca i1
  %l133 = alloca i1
  %l134 = alloca i1
  %l139 = alloca i1
  %l141 = alloca { i64, [2 x i64] }
  %l143 = alloca i1
  %l150 = alloca { i64, ptr }
  %l152 = alloca i64
  %l155 = alloca { i64, [1 x i64] }
  %l156 = alloca ptr
  %l157 = alloca { i64, [2 x i64] }
  %l158 = alloca %"compiler/source:Span"
  %l177 = alloca i1
  %l185 = alloca { i64, ptr }
  %l187 = alloca i64
  %l190 = alloca { i64, [1 x i64] }
  %l191 = alloca ptr
  %l192 = alloca { i64, [2 x i64] }
  %l196 = alloca %"compiler/source:Span"
  %l203 = alloca i64
  %l207 = alloca %"compiler/source:Span"
  %l211 = alloca %"compiler/scope:Val"
  %l212 = alloca ptr
  %l213 = alloca i32
  %l219 = alloca ptr
  %l220 = alloca { i64, [2 x i64] }
  %l221 = alloca { i64, [2 x i64] }
  %l224 = alloca i1
  %l225 = alloca i1
  %l228 = alloca i1
  %l235 = alloca i1
  %l240 = alloca %"compiler/scope:Val"
  %l243 = alloca i1
  %l248 = alloca i32
  %l251 = alloca i1
  %l253 = alloca ptr
  %l258 = alloca i1
  %l260 = alloca i1
  %l263 = alloca i1
  %l265 = alloca ptr
  %l267 = alloca i64
  %l278 = alloca i1
  %l281 = alloca i1
  %l284 = alloca ptr
  %l285 = alloca ptr
  %l286 = alloca i1
  %l291 = alloca ptr
  %l294 = alloca i32
  %l295 = alloca i1
  %l296 = alloca i1
  %l301 = alloca i1
  %l302 = alloca i1
  %l306 = alloca i1
  %l307 = alloca ptr
  %l309 = alloca i32
  %l312 = alloca { i64, [2 x i64] }
  %l315 = alloca %"compiler/source:Span"
  %l322 = alloca %"compiler/scope:Val"
  %l325 = alloca ptr
  %l327 = alloca i64
  %l328 = alloca ptr
  %l329 = alloca %"compiler/scope:Val"
  %l332 = alloca { i64, [2 x i64] }
  %l333 = alloca { i64, [2 x i64] }
  %l336 = alloca i1
  %l337 = alloca ptr
  %l341 = alloca i1
  %l342 = alloca ptr
  %l343 = alloca ptr
  %l346 = alloca { i64, [2 x i64] }
  %l347 = alloca %"compiler/scope:Val"
  %l356 = alloca { i64, [2 x i64] }
  %l360 = alloca i1
  %l367 = alloca i1
  %l384 = alloca { i64, [2 x i64] }
  %l393 = alloca ptr
  %l396 = alloca { i64, [2 x i64] }
  %l398 = alloca { i64, [2 x i64] }
  %l401 = alloca { i64, [2 x i64] }
  %l404 = alloca i1
  %l405 = alloca i1
  %l409 = alloca i1
  %l413 = alloca ptr
  %l419 = alloca i1
  %l420 = alloca i1
  %l423 = alloca ptr
  %l424 = alloca i1
  %l431 = alloca i1
  %l432 = alloca i1
  %l435 = alloca i1
  %l437 = alloca ptr
  %l439 = alloca i64
  %l442 = alloca { i64, [2 x i64] }
  %l448 = alloca { i64, [2 x i64] }
  %l452 = alloca { i64, [2 x i64] }
  %l461 = alloca i1
  %l463 = alloca i1
  %l468 = alloca i1
  %l469 = alloca ptr
  %l470 = alloca ptr
  %l475 = alloca ptr
  %l477 = alloca ptr
  %l478 = alloca ptr
  %l482 = alloca i64
  %l486 = alloca ptr
  %l488 = alloca i1
  %l491 = alloca i1
  %l495 = alloca ptr
  %l497 = alloca i1
  %l500 = alloca i64
  %l506 = alloca %"compiler/scope:Val"
  %l512 = alloca ptr
  %l514 = alloca i64
  %l521 = alloca i1
  %l522 = alloca i1
  %l526 = alloca i1
  %l542 = alloca ptr
  %l546 = alloca i64
  %l549 = alloca i1
  %l553 = alloca i1
  %l555 = alloca ptr
  %l557 = alloca i64
  %l558 = alloca i64
  %l562 = alloca i64
  %l563 = alloca i32
  %l567 = alloca ptr
  %l572 = alloca ptr
  %l573 = alloca ptr
  %l575 = alloca ptr
  %l579 = alloca i1
  %l586 = alloca { i64, ptr }
  %l588 = alloca i64
  %l591 = alloca i1
  %l595 = alloca i1
  %l597 = alloca ptr
  %l599 = alloca i64
  %l600 = alloca i64
  %l604 = alloca i64
  %l605 = alloca i32
  %l606 = alloca ptr
  %l607 = alloca i32
  %l612 = alloca ptr
  %l614 = alloca i64
  %l618 = alloca { i64, [2 x i64] }
  %l619 = alloca ptr
  %l620 = alloca i32
  %l624 = alloca i1
  %l634 = alloca ptr
  %l642 = alloca { i64, [2 x i64] }
  %l647 = alloca { i64, [2 x i64] }
  %l648 = alloca i32
  %l664 = alloca i1
  %l667 = alloca i64
  %l670 = alloca i64
  %l672 = alloca i1
  %l678 = alloca i1
  %l679 = alloca ptr
  %l685 = alloca ptr
  %l686 = alloca ptr
  %l690 = alloca %"compiler/source:Span"
  %l691 = alloca %"compiler/source:Span"
  %l692 = alloca %"compiler/diagmsg:Msg"
  %l693 = alloca i64
  %l701 = alloca i1
  %l704 = alloca i1
  %l705 = alloca i1
  %l706 = alloca ptr
  %l710 = alloca i1
  %l716 = alloca %"compiler/scope:Val"
  %l718 = alloca ptr
  %l719 = alloca i32
  %l730 = alloca i1
  %l733 = alloca ptr
  %l734 = alloca { i64, [2 x i64] }
  %l735 = alloca { i64, [2 x i64] }
  %l736 = alloca i1
  %l739 = alloca ptr
  %l741 = alloca i64
  %l747 = alloca i1
  %l750 = alloca i1
  %l751 = alloca i1
  %l752 = alloca ptr
  %l756 = alloca i1
  %l764 = alloca i1
  %l767 = alloca i1
  %l770 = alloca i1
  %l771 = alloca ptr
  %l772 = alloca ptr
  %l776 = alloca %"compiler/source:Span"
  %l777 = alloca %"compiler/diagmsg:Msg"
  %l778 = alloca i64
  %l781 = alloca i1
  %l784 = alloca i1
  %l785 = alloca { i64, [2 x i64] }
  %l787 = alloca { i64, [2 x i64] }
  %l789 = alloca i1
  %l791 = alloca i1
  %l793 = alloca i1
  %l796 = alloca ptr
  %l797 = alloca { i64, [2 x i64] }
  %l798 = alloca { i64, [2 x i64] }
  %l808 = alloca i1
  %l814 = alloca i1
  %l816 = alloca i64
  %l824 = alloca ptr
  %l825 = alloca { i64, [2 x i64] }
  %l826 = alloca { i64, [2 x i64] }
  %l827 = alloca i1
  %s0 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %t97 = alloca { i64, [2 x i64] }, align 8
  %t428 = alloca { i64, [2 x i64] }, align 8
  %t502 = alloca { i64, [2 x i64] }, align 8
  %t604 = alloca { i64, [2 x i64] }, align 8
  %t671 = alloca { i64, [2 x i64] }, align 8
  %t717 = alloca { i64, [2 x i64] }, align 8
  %t1006 = alloca { i64, [2 x i64] }, align 8
  %t1143 = alloca { i64, [2 x i64] }, align 8
  %t1317 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_2b2b1c5bca7382ee_3254cae318351912)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t15 = load i32, ptr %l2, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t20 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %t17)
  store %"compiler/typed:Local" %t20, ptr %l48
  br label %bb4
bb4:
  %t21 = load %"compiler/typed:Local", ptr %l48
  store %"compiler/typed:Local" %t21, ptr %l4
  %t22 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t23 = load i32, ptr %t22, !tbaa !23
  store i32 %t23, ptr %l5, !tbaa !23
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 42
  %t34 = load i32, ptr %l2, !tbaa !23
  %t36 = sext i32 %t34 to i64
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %t33, i64 %t36, ptr %t37)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 117
  %t44 = load { i64, [2 x i64] }, ptr %t43
  store { i64, [2 x i64] } %t44, ptr %l6
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 118
  %t49 = load i1, ptr %t48, !tbaa !21
  store i1 %t49, ptr %l7, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/scope:Scoper", ptr %t51, i32 0, i32 121
  %t54 = load i1, ptr %t53, !tbaa !21
  store i1 %t54, ptr %l8, !tbaa !21
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/scope:Scoper", ptr %t56, i32 0, i32 149
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb9, label %bb10
bb9:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/scope:Scoper", ptr %t65, i32 0, i32 179
  %t68 = load i32, ptr %l2, !tbaa !23
  %t70 = sext i32 %t68 to i64
  %t71 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = sext i32 %t72 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t67, i64 %t70, i64 %t74)
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  %t81 = sext i32 %t79 to i64
  %t84 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisCursorLocal(ptr %v0, ptr %t78, i64 %t81)
  store i1 %t84, ptr %l77
  br label %bb12
bb12:
  %t85 = load i1, ptr %l77, !tbaa !21
  br i1 %t85, label %bb13, label %bb14
bb13:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/scope:Scoper", ptr %t86, i32 0, i32 178
  %t89 = load i32, ptr %l2, !tbaa !23
  %t91 = sext i32 %t89 to i64
  %t92 = load { i64, [2 x i64] }, ptr %l6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H38f9aff1b0310316a48dc5a28922f96e(ptr %v0, ptr %t88, i64 %t91, { i64, [2 x i64] } %t92)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [2 x i64] }, ptr %t97, i32 0, i32 0
  store i64 0, ptr %t98
  %t99 = load { i64, [2 x i64] }, ptr %t97
  %t102 = getelementptr %"compiler/scope:Scoper", ptr %t96, i32 0, i32 117
  store { i64, [2 x i64] } %t99, ptr %t102
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/scope:Scoper", ptr %t103, i32 0, i32 118
  store i1 false, ptr %t105, !tbaa !21
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/scope:Scoper", ptr %t106, i32 0, i32 121
  store i1 false, ptr %t108, !tbaa !21
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l2, !tbaa !23
  %t112 = sext i32 %t110 to i64
  %t115 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftOf(ptr %v0, ptr %t109, i64 %t112)
  store { i64, [2 x i64] } %t115, ptr %l90
  br label %bb18
bb18:
  %t116 = load { i64, [2 x i64] }, ptr %l90
  store { i64, [2 x i64] } %t116, ptr %l9
  %t117 = load { i64, [2 x i64] }, ptr %l9
  %t119 = extractvalue { i64, [2 x i64] } %t117, 0
  %t120 = icmp eq i64 %t119, 0
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb19, label %bb20
bb19:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/scope:Scoper", ptr %t124, i32 0, i32 142
  store ptr %t126, ptr %l96, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/scope:Scoper", ptr %t127, i32 0, i32 26
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load i32, ptr %l2, !tbaa !23
  %t133 = sext i32 %t131 to i64
  %t136 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t130, i64 %t133)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t136, ptr %l101
  br label %bb21
bb20:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb23
bb21:
  %t137 = load ptr, ptr %l96, !tbaa !29
  %t138 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l101
  %t139 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t137, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t138)
  store i1 %t139, ptr %l102
  br label %bb22
bb22:
  %t140 = load i1, ptr %l102, !tbaa !21
  store i1 %t140, ptr %l94, !tbaa !21
  br label %bb23
bb23:
  %t141 = load i1, ptr %l94, !tbaa !21
  br i1 %t141, label %bb24, label %bb25
bb24:
  %t142 = load { i64, [2 x i64] }, ptr %l6
  %t144 = extractvalue { i64, [2 x i64] } %t142, 0
  %t145 = icmp eq i64 %t144, 0
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb26, label %bb27
bb25:
  br label %bb30
bb26:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load { i64, [2 x i64] }, ptr %l6
  %t151 = load { i64, [2 x i64] }, ptr %l9
  %t155 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoinTerm(ptr %v0, ptr %t149, { i64, [2 x i64] } %t150, { i64, [2 x i64] } %t151)
  store { i64, [2 x i64] } %t155, ptr %l110
  br label %bb28
bb27:
  %t156 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t156, ptr %l106
  br label %bb29
bb28:
  %t158 = load { i64, [2 x i64] }, ptr %l110
  store { i64, [2 x i64] } %t158, ptr %l106
  br label %bb29
bb29:
  %t159 = load { i64, [2 x i64] }, ptr %l106
  store { i64, [2 x i64] } %t159, ptr %l6
  br label %bb30
bb30:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/scope:Scoper", ptr %t160, i32 0, i32 32
  store ptr %t162, ptr %l113, !tbaa !29
  %t163 = load i32, ptr %l2, !tbaa !23
  %t165 = sext i32 %t163 to i64
  store i64 %t165, ptr %l115, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t168 = load i32, ptr %t167, !tbaa !23
  %t171 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t166, i32 %t168)
  store { i64, [2 x i64] } %t171, ptr %l118
  br label %bb31
bb31:
  %t172 = load ptr, ptr %l113, !tbaa !29
  %t173 = load i64, ptr %l115, !tbaa !24
  %t174 = load { i64, [2 x i64] }, ptr %l118
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t172, i64 %t173, { i64, [2 x i64] } %t174)
  br label %bb32
bb32:
  %t175 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t176 = load i32, ptr %t175, !range !{i32 0, i32 7}
  %t178 = trunc i64 6 to i32
  %t179 = icmp eq i32 %t176, %t178
  br i1 %t179, label %bb33, label %bb34
bb33:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l5, !tbaa !23
  %t185 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t181, i32 %t182)
  store i1 %t185, ptr %l124
  br label %bb35
bb34:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb36
bb35:
  %t186 = load i1, ptr %l124, !tbaa !21
  %t187 = xor i1 %t186, true
  store i1 %t187, ptr %l121, !tbaa !21
  br label %bb36
bb36:
  %t189 = load i1, ptr %l121, !tbaa !21
  br i1 %t189, label %bb37, label %bb38
bb37:
  %t190 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t191 = load i32, ptr %t190, !tbaa !23
  %t193 = icmp eq i32 %t191, 0
  store i1 %t193, ptr %l126, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb39
bb39:
  %t195 = load i1, ptr %l126, !tbaa !21
  br i1 %t195, label %bb40, label %bb41
bb40:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i32, ptr %l2, !tbaa !23
  %t199 = sext i32 %t197 to i64
  %t202 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowed(ptr %v0, ptr %t196, i64 %t199)
  store i1 %t202, ptr %l133
  br label %bb42
bb41:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb47
bb42:
  %t203 = load i1, ptr %l133, !tbaa !21
  br i1 %t203, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb46
bb44:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/scope:Scoper", ptr %t204, i32 0, i32 0
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = getelementptr %"compiler/generic:Program", ptr %t207, i32 0, i32 2
  %t210 = load i32, ptr %l5, !tbaa !23
  %t213 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t209, i32 %t210)
  store i1 %t213, ptr %l139
  br label %bb45
bb45:
  %t214 = load i1, ptr %l139, !tbaa !21
  store i1 %t214, ptr %l134, !tbaa !21
  br label %bb46
bb46:
  %t215 = load i1, ptr %l134, !tbaa !21
  store i1 %t215, ptr %l129, !tbaa !21
  br label %bb47
bb47:
  %t216 = load i1, ptr %l129, !tbaa !21
  br i1 %t216, label %bb48, label %bb49
bb48:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t217, i32 0)
  store { i64, [2 x i64] } %t219, ptr %l141
  br label %bb50
bb49:
  br label %bb61
bb50:
  %t220 = load { i64, [2 x i64] }, ptr %l141
  store { i64, [2 x i64] } %t220, ptr %l10
  %t221 = load { i64, [2 x i64] }, ptr %l10
  %t223 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t221)
  store i1 %t223, ptr %l143
  br label %bb51
bb51:
  %t224 = load i1, ptr %l143, !tbaa !21
  br i1 %t224, label %bb52, label %bb53
bb52:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/scope:Scoper", ptr %t225, i32 0, i32 32
  %t228 = load i32, ptr %l2, !tbaa !23
  %t230 = sext i32 %t228 to i64
  %t231 = load { i64, [2 x i64] }, ptr %l10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t227, i64 %t230, { i64, [2 x i64] } %t231)
  br label %bb54
bb53:
  br label %bb60
bb54:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/scope:Scoper", ptr %t235, i32 0, i32 30
  %t238 = getelementptr %"compiler/typed:Plan", ptr %t237, i32 0, i32 1
  %t239 = load { i64, ptr }, ptr %t238, !tbaa !27
  store { i64, ptr } %t239, ptr %l150, !tbaa !27
  %t240 = load i32, ptr %l2, !tbaa !23
  %t242 = sext i32 %t240 to i64
  store i64 %t242, ptr %l152, !tbaa !24
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load { i64, [2 x i64] }, ptr %l10
  %t247 = call { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %t243, { i64, [2 x i64] } %t244)
  store { i64, [1 x i64] } %t247, ptr %l155
  br label %bb55
bb55:
  %t248 = load { i64, [1 x i64] }, ptr %l155
  %t249 = load i64, ptr %l152, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr { i64, [1 x i64] }, ptr %t251, i64 %t249
  store { i64, [1 x i64] } %t248, ptr %t252
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l156, !tbaa !29
  %t254 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t254, ptr %l157
  %t255 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t255, ptr %l158
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/scope:Scoper", ptr %t256, i32 0, i32 25
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = icmp eq ptr %t259, null
  br i1 %t261, label %bb56, label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_3615f8c81297be95_8f4c76758aae1d39)
  unreachable
bb57:
  br label %bb58
bb58:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/scope:Scoper", ptr %t263, i32 0, i32 25
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Body", ptr %t266, i32 0, i32 3
  %t270 = load i64, ptr %t269, !tbaa !24
  %t271 = load %"compiler/source:Span", ptr %l1
  %t272 = load ptr, ptr %l156, !tbaa !29
  %t273 = load { i64, [2 x i64] }, ptr %l157
  %t274 = load %"compiler/source:Span", ptr %l158
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t272, { i64, [2 x i64] } %t273, %"compiler/source:Span" %t274, i64 %t270, %"compiler/source:Span" %t271)
  br label %bb59
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t277 = load { i64, [2 x i64] }, ptr %l6
  %t279 = extractvalue { i64, [2 x i64] } %t277, 0
  %t280 = icmp eq i64 %t279, 0
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb62, label %bb63
bb62:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/scope:Scoper", ptr %t284, i32 0, i32 31
  %t287 = load i32, ptr %l2, !tbaa !23
  %t289 = sext i32 %t287 to i64
  %t290 = load { i64, [2 x i64] }, ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t286, i64 %t289, { i64, [2 x i64] } %t290)
  br label %bb64
bb63:
  br label %bb100
bb64:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i32, ptr %l5, !tbaa !23
  %t298 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t294, i32 %t295)
  store i1 %t298, ptr %l177
  br label %bb65
bb65:
  %t299 = load i1, ptr %l177, !tbaa !21
  %t300 = xor i1 %t299, true
  br i1 %t300, label %bb66, label %bb67
bb66:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/scope:Scoper", ptr %t302, i32 0, i32 32
  %t305 = load i32, ptr %l2, !tbaa !23
  %t307 = sext i32 %t305 to i64
  %t308 = load { i64, [2 x i64] }, ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t304, i64 %t307, { i64, [2 x i64] } %t308)
  br label %bb68
bb67:
  br label %bb82
bb68:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/scope:Scoper", ptr %t312, i32 0, i32 30
  %t315 = getelementptr %"compiler/typed:Plan", ptr %t314, i32 0, i32 1
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  store { i64, ptr } %t316, ptr %l185, !tbaa !27
  %t317 = load i32, ptr %l2, !tbaa !23
  %t319 = sext i32 %t317 to i64
  store i64 %t319, ptr %l187, !tbaa !24
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load { i64, [2 x i64] }, ptr %l6
  %t324 = call { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %t320, { i64, [2 x i64] } %t321)
  store { i64, [1 x i64] } %t324, ptr %l190
  br label %bb69
bb69:
  %t325 = load { i64, [1 x i64] }, ptr %l190
  %t326 = load i64, ptr %l187, !tbaa !24
  %t327 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr { i64, [1 x i64] }, ptr %t328, i64 %t326
  store { i64, [1 x i64] } %t325, ptr %t329
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l191, !tbaa !29
  %t331 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t331, ptr %l192
  %t332 = load ptr, ptr %l3, !tbaa !29
  %t334 = icmp eq ptr %t332, null
  br i1 %t334, label %bb70, label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_8512c8e5a34c1680_11a04901f462dc84)
  unreachable
bb71:
  br label %bb72
bb72:
  %t336 = load ptr, ptr %l3, !tbaa !29
  %t338 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t336)
  store %"compiler/source:Span" %t338, ptr %l196
  br label %bb73
bb73:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/scope:Scoper", ptr %t339, i32 0, i32 25
  %t342 = load ptr, ptr %t341, !tbaa !29
  %t344 = icmp eq ptr %t342, null
  br i1 %t344, label %bb74, label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_8512c8e5a34c1680_11a04901f462dc84)
  unreachable
bb75:
  br label %bb76
bb76:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/scope:Scoper", ptr %t346, i32 0, i32 25
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t352 = getelementptr %"compiler/typed:Body", ptr %t349, i32 0, i32 3
  %t353 = load i64, ptr %t352, !tbaa !24
  store i64 %t353, ptr %l203, !tbaa !24
  %t354 = load ptr, ptr %l3, !tbaa !29
  %t356 = icmp eq ptr %t354, null
  br i1 %t356, label %bb77, label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_8512c8e5a34c1680_11a04901f462dc84)
  unreachable
bb78:
  br label %bb79
bb79:
  %t358 = load ptr, ptr %l3, !tbaa !29
  %t360 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t358)
  store %"compiler/source:Span" %t360, ptr %l207
  br label %bb80
bb80:
  %t361 = load ptr, ptr %l191, !tbaa !29
  %t362 = load { i64, [2 x i64] }, ptr %l192
  %t363 = load %"compiler/source:Span", ptr %l196
  %t364 = load i64, ptr %l203, !tbaa !24
  %t365 = load %"compiler/source:Span", ptr %l207
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t361, { i64, [2 x i64] } %t362, %"compiler/source:Span" %t363, i64 %t364, %"compiler/source:Span" %t365)
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load ptr, ptr %l3, !tbaa !29
  %t368 = load { i64, [2 x i64] }, ptr %l6
  %t372 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t366, ptr %t367, { i64, [2 x i64] } %t368)
  store %"compiler/scope:Val" %t372, ptr %l211
  br label %bb83
bb83:
  %t373 = load %"compiler/scope:Val", ptr %l211
  store %"compiler/scope:Val" %t373, ptr %l11
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l212, !tbaa !29
  %t375 = load i32, ptr %l2, !tbaa !23
  store i32 %t375, ptr %l213, !tbaa !23
  %t376 = load ptr, ptr %l3, !tbaa !29
  %t378 = icmp eq ptr %t376, null
  br i1 %t378, label %bb84, label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_271e9ecf5549331f_fa1bdfb41feb4a53)
  unreachable
bb85:
  br label %bb86
bb86:
  %t380 = load ptr, ptr %l3, !tbaa !29
  %t381 = load ptr, ptr %l212, !tbaa !29
  %t382 = load i32, ptr %l213, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %t381, i32 %t382, ptr %t380)
  br label %bb87
bb87:
  %t384 = getelementptr %"compiler/scope:Val", ptr %l11, i32 0, i32 0
  %t385 = load i32, ptr %t384, !range !{i32 0, i32 5}
  %t387 = trunc i64 3 to i32
  %t388 = icmp eq i32 %t385, %t387
  br i1 %t388, label %bb88, label %bb89
bb88:
  %t390 = load ptr, ptr %l0, !tbaa !29
  store ptr %t390, ptr %l219, !tbaa !29
  %t391 = getelementptr %"compiler/scope:Val", ptr %l11, i32 0, i32 1
  %t392 = load { i64, [2 x i64] }, ptr %t391
  store { i64, [2 x i64] } %t392, ptr %l220
  %t393 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t393, ptr %l221
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load i32, ptr %l5, !tbaa !23
  %t398 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t394, i32 %t395)
  store i1 %t398, ptr %l224
  br label %bb90
bb89:
  br label %bb99
bb90:
  %t399 = load i1, ptr %l224, !tbaa !21
  br i1 %t399, label %bb91, label %bb92
bb91:
  store i1 true, ptr %l225, !tbaa !21
  br label %bb94
bb92:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load i32, ptr %l5, !tbaa !23
  %t404 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t400, i32 %t401)
  store i1 %t404, ptr %l228
  br label %bb93
bb93:
  %t405 = load i1, ptr %l228, !tbaa !21
  store i1 %t405, ptr %l225, !tbaa !21
  br label %bb94
bb94:
  %t406 = load ptr, ptr %l3, !tbaa !29
  %t408 = icmp eq ptr %t406, null
  br i1 %t408, label %bb95, label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_333095c8aa3d0ed2_eefb3089191ecb2e)
  unreachable
bb96:
  br label %bb97
bb97:
  %t410 = load ptr, ptr %l3, !tbaa !29
  %t411 = load i64, ptr @G_2ecompiler_2fscope_2eFitLocal, !tbaa !24
  %t412 = load ptr, ptr %l219, !tbaa !29
  %t413 = load { i64, [2 x i64] }, ptr %l220
  %t414 = load { i64, [2 x i64] }, ptr %l221
  %t415 = load i1, ptr %l225, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t412, { i64, [2 x i64] } %t413, { i64, [2 x i64] } %t414, i1 %t415, ptr %t410, i64 %t411)
  br label %bb98
bb98:
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb100:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load i32, ptr %l5, !tbaa !23
  %t422 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t418, i32 %t419)
  store i1 %t422, ptr %l235
  br label %bb101
bb101:
  %t423 = load i1, ptr %l235, !tbaa !21
  %t424 = xor i1 %t423, true
  br i1 %t424, label %bb102, label %bb103
bb102:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l3, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t428
  %t429 = getelementptr { i64, [2 x i64] }, ptr %t428, i32 0, i32 0
  store i64 0, ptr %t429
  %t430 = load { i64, [2 x i64] }, ptr %t428
  %t434 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t426, ptr %t427, { i64, [2 x i64] } %t430)
  store %"compiler/scope:Val" %t434, ptr %l240
  br label %bb104
bb103:
  br label %bb105
bb104:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb105:
  %t435 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t436 = load i32, ptr %t435, !range !{i32 0, i32 7}
  %t438 = trunc i64 3 to i32
  %t439 = icmp eq i32 %t436, %t438
  br i1 %t439, label %bb106, label %bb107
bb106:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/scope:Scoper", ptr %t441, i32 0, i32 0
  %t444 = load ptr, ptr %t443, !tbaa !29
  %t446 = getelementptr %"compiler/generic:Program", ptr %t444, i32 0, i32 2
  %t447 = load i32, ptr %l5, !tbaa !23
  %t450 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t446, i32 %t447)
  store i32 %t450, ptr %l248
  br label %bb108
bb107:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb109
bb108:
  %t451 = load i32, ptr %l248, !range !{i32 0, i32 33}
  %t453 = trunc i64 22 to i32
  %t454 = icmp eq i32 %t451, %t453
  store i1 %t454, ptr %l243, !tbaa !21
  br label %bb109
bb109:
  %t456 = load i1, ptr %l243, !tbaa !21
  br i1 %t456, label %bb110, label %bb111
bb110:
  %t457 = load ptr, ptr %l3, !tbaa !29
  %t459 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %s0, ptr %t457)
  store ptr %t459, ptr %l253
  br label %bb112
bb111:
  store i1 false, ptr %l251, !tbaa !21
  br label %bb113
bb112:
  %t460 = load ptr, ptr %l253, !tbaa !29
  %t461 = icmp eq ptr %t460, null
  %t463 = xor i1 %t461, true
  store i1 %t463, ptr %l251, !tbaa !21
  br label %bb113
bb113:
  %t465 = load i1, ptr %l251, !tbaa !21
  store i1 %t465, ptr %l12, !tbaa !21
  %t466 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t467 = load i32, ptr %t466, !range !{i32 0, i32 7}
  %t469 = trunc i64 2 to i32
  %t470 = icmp eq i32 %t467, %t469
  br i1 %t470, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l258, !tbaa !21
  br label %bb116
bb115:
  %t472 = load i1, ptr %l12, !tbaa !21
  store i1 %t472, ptr %l258, !tbaa !21
  br label %bb116
bb116:
  %t474 = load i1, ptr %l258, !tbaa !21
  br i1 %t474, label %bb117, label %bb118
bb117:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t476 = load ptr, ptr %l3, !tbaa !29
  %t479 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t475, ptr %t476)
  store i1 %t479, ptr %l263
  br label %bb119
bb118:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb120
bb119:
  %t480 = load i1, ptr %l263, !tbaa !21
  store i1 %t480, ptr %l260, !tbaa !21
  br label %bb120
bb120:
  %t481 = load i1, ptr %l260, !tbaa !21
  br i1 %t481, label %bb121, label %bb122
bb121:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/scope:Scoper", ptr %t482, i32 0, i32 40
  store ptr %t484, ptr %l265, !tbaa !29
  %t485 = load i32, ptr %l2, !tbaa !23
  %t487 = sext i32 %t485 to i64
  store i64 %t487, ptr %l267, !tbaa !24
  %t488 = load ptr, ptr %l3, !tbaa !29
  %t490 = icmp eq ptr %t488, null
  br i1 %t490, label %bb123, label %bb124
bb122:
  br label %bb128
bb123:
  call void @__olang_check_failed(ptr @olang_loc_eb3169e1e84098f9_8a2d6a085cc5aad5)
  unreachable
bb124:
  br label %bb125
bb125:
  %t492 = load ptr, ptr %l3, !tbaa !29
  %t493 = load ptr, ptr %l265, !tbaa !29
  %t494 = load i64, ptr %l267, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %t493, i64 %t494, ptr %t492)
  br label %bb126
bb126:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/scope:Scoper", ptr %t496, i32 0, i32 31
  %t499 = load i32, ptr %l2, !tbaa !23
  %t501 = sext i32 %t499 to i64
  store { i64, [2 x i64] } zeroinitializer, ptr %t502
  %t503 = getelementptr { i64, [2 x i64] }, ptr %t502, i32 0, i32 0
  store i64 0, ptr %t503
  %t504 = load { i64, [2 x i64] }, ptr %t502
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t498, i64 %t501, { i64, [2 x i64] } %t504)
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb128:
  %t508 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t509 = load i32, ptr %t508, !range !{i32 0, i32 7}
  %t511 = trunc i64 3 to i32
  %t512 = icmp eq i32 %t509, %t511
  br i1 %t512, label %bb129, label %bb130
bb129:
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i32, ptr %l5, !tbaa !23
  %t518 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t514, i32 %t515)
  store i1 %t518, ptr %l281
  br label %bb131
bb130:
  store i1 false, ptr %l278, !tbaa !21
  br label %bb132
bb131:
  %t519 = load i1, ptr %l281, !tbaa !21
  store i1 %t519, ptr %l278, !tbaa !21
  br label %bb132
bb132:
  %t520 = load i1, ptr %l278, !tbaa !21
  br i1 %t520, label %bb133, label %bb134
bb133:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load ptr, ptr %l3, !tbaa !29
  %t525 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v0, ptr %t521, ptr %t522)
  store ptr %t525, ptr %l284
  br label %bb135
bb134:
  br label %bb167
bb135:
  %t526 = load ptr, ptr %l284, !tbaa !29
  store ptr %t526, ptr %l13, !tbaa !29
  %t527 = load ptr, ptr %l13, !tbaa !29
  store ptr %t527, ptr %l285, !tbaa !29
  store i1 false, ptr %l286, !tbaa !21
  %t528 = load ptr, ptr %l285, !tbaa !29
  %t529 = icmp ne ptr %t528, null
  br i1 %t529, label %bb136, label %bb137
bb136:
  %t531 = load ptr, ptr %l285, !tbaa !29
  %t532 = load i64, ptr %t531, !range !{i64 0, i64 18}
  %t534 = icmp eq i64 %t532, 5
  store i1 %t534, ptr %l286, !tbaa !21
  br label %bb137
bb137:
  %t535 = load i1, ptr %l286, !tbaa !21
  br i1 %t535, label %bb138, label %bb139
bb138:
  %t536 = load ptr, ptr %l13, !tbaa !29
  %t538 = getelementptr { i64, [5 x i64] }, ptr %t536, i32 0, i32 1
  %t539 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t538, i32 0, i32 2
  %t540 = load ptr, ptr %t539
  store ptr %t540, ptr %l14, !tbaa !29
  br label %bb140
bb139:
  br label %bb161
bb140:
  %t542 = load ptr, ptr %l0, !tbaa !29
  store ptr %t542, ptr %l291, !tbaa !29
  %t543 = load ptr, ptr %l14, !tbaa !29
  %t545 = getelementptr %"compiler/typed:Promote", ptr %t543, i32 0, i32 0
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t548 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t546)
  store i32 %t548, ptr %l294
  br label %bb141
bb141:
  %t549 = load ptr, ptr %l291, !tbaa !29
  %t550 = load i32, ptr %l294, !tbaa !23
  %t551 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t549, i32 %t550)
  store i1 %t551, ptr %l295
  br label %bb142
bb142:
  %t552 = load i1, ptr %l295, !tbaa !21
  br i1 %t552, label %bb143, label %bb144
bb143:
  %t553 = load ptr, ptr %l0, !tbaa !29
  %t554 = load ptr, ptr %l14, !tbaa !29
  %t556 = getelementptr %"compiler/typed:Promote", ptr %t554, i32 0, i32 0
  %t557 = load ptr, ptr %t556, !tbaa !29
  %t561 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v0, ptr %t553, ptr %t557)
  store i1 %t561, ptr %l301
  br label %bb145
bb144:
  store i1 false, ptr %l296, !tbaa !21
  br label %bb146
bb145:
  %t562 = load i1, ptr %l301, !tbaa !21
  store i1 %t562, ptr %l296, !tbaa !21
  br label %bb146
bb146:
  %t563 = load i1, ptr %l296, !tbaa !21
  br i1 %t563, label %bb147, label %bb148
bb147:
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t565 = load ptr, ptr %l14, !tbaa !29
  %t567 = getelementptr %"compiler/typed:Promote", ptr %t565, i32 0, i32 0
  %t568 = load ptr, ptr %t567, !tbaa !29
  %t571 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLands(ptr %v0, ptr %v0, ptr %t564, ptr %t568)
  store i1 %t571, ptr %l306
  br label %bb149
bb148:
  store i1 false, ptr %l302, !tbaa !21
  br label %bb150
bb149:
  %t572 = load i1, ptr %l306, !tbaa !21
  store i1 %t572, ptr %l302, !tbaa !21
  br label %bb150
bb150:
  %t573 = load i1, ptr %l302, !tbaa !21
  br i1 %t573, label %bb151, label %bb152
bb151:
  %t574 = load ptr, ptr %l0, !tbaa !29
  store ptr %t574, ptr %l307, !tbaa !29
  %t575 = load ptr, ptr %l14, !tbaa !29
  %t577 = getelementptr %"compiler/typed:Promote", ptr %t575, i32 0, i32 1
  %t578 = load i32, ptr %t577, !tbaa !23
  store i32 %t578, ptr %l309, !tbaa !23
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t580 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t581 = load i32, ptr %t580, !tbaa !23
  %t584 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t579, i32 %t581)
  store { i64, [2 x i64] } %t584, ptr %l312
  br label %bb153
bb152:
  br label %bb160
bb153:
  %t585 = load ptr, ptr %l14, !tbaa !29
  %t587 = getelementptr %"compiler/typed:Promote", ptr %t585, i32 0, i32 0
  %t588 = load ptr, ptr %t587, !tbaa !29
  %t590 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t588)
  store %"compiler/source:Span" %t590, ptr %l315
  br label %bb154
bb154:
  %t591 = load ptr, ptr %l307, !tbaa !29
  %t592 = load i32, ptr %l309, !tbaa !23
  %t593 = load { i64, [2 x i64] }, ptr %l312
  %t594 = load %"compiler/source:Span", ptr %l315
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildSite(ptr %v0, ptr %t591, i32 %t592, { i64, [2 x i64] } %t593, %"compiler/source:Span" %t594)
  br label %bb155
bb155:
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t597 = getelementptr %"compiler/scope:Scoper", ptr %t595, i32 0, i32 119
  store i1 true, ptr %t597, !tbaa !21
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load ptr, ptr %l14, !tbaa !29
  %t601 = getelementptr %"compiler/typed:Promote", ptr %t599, i32 0, i32 0
  %t602 = load ptr, ptr %t601, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t604
  %t605 = getelementptr { i64, [2 x i64] }, ptr %t604, i32 0, i32 0
  store i64 0, ptr %t605
  %t606 = load { i64, [2 x i64] }, ptr %t604
  %t610 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v0, ptr %t598, ptr %t602, { i64, [2 x i64] } %t606)
  store %"compiler/scope:Val" %t610, ptr %l322
  br label %bb156
bb156:
  %t611 = load %"compiler/scope:Val", ptr %l322
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t614 = getelementptr %"compiler/scope:Scoper", ptr %t612, i32 0, i32 119
  store i1 false, ptr %t614, !tbaa !21
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t617 = getelementptr %"compiler/scope:Scoper", ptr %t615, i32 0, i32 31
  store ptr %t617, ptr %l325, !tbaa !29
  %t618 = load i32, ptr %l2, !tbaa !23
  %t620 = sext i32 %t618 to i64
  store i64 %t620, ptr %l327, !tbaa !24
  %t621 = load ptr, ptr %l0, !tbaa !29
  store ptr %t621, ptr %l328, !tbaa !29
  store %"compiler/scope:Val" %t611, ptr %l329
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t625 = load i32, ptr %t624, !tbaa !23
  %t628 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t623, i32 %t625)
  store { i64, [2 x i64] } %t628, ptr %l332
  br label %bb157
bb157:
  %t629 = load ptr, ptr %l328, !tbaa !29
  %t630 = load %"compiler/scope:Val", ptr %l329
  %t631 = load { i64, [2 x i64] }, ptr %l332
  %t632 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalTerm(ptr %v0, ptr %t629, %"compiler/scope:Val" %t630, { i64, [2 x i64] } %t631)
  store { i64, [2 x i64] } %t632, ptr %l333
  br label %bb158
bb158:
  %t633 = load ptr, ptr %l325, !tbaa !29
  %t634 = load i64, ptr %l327, !tbaa !24
  %t635 = load { i64, [2 x i64] }, ptr %l333
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t633, i64 %t634, { i64, [2 x i64] } %t635)
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb160:
  br label %bb166
bb161:
  br i1 true, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_9577440ef01a2a6b_ad29297969b69207)
  unreachable
bb166:
  br label %bb167
bb167:
  %t636 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t637 = load i32, ptr %t636, !range !{i32 0, i32 7}
  %t639 = trunc i64 3 to i32
  %t640 = icmp eq i32 %t637, %t639
  br i1 %t640, label %bb168, label %bb169
bb168:
  %t642 = load ptr, ptr %l0, !tbaa !29
  store ptr %t642, ptr %l337, !tbaa !29
  %t643 = load ptr, ptr %l3, !tbaa !29
  %t645 = icmp eq ptr %t643, null
  br i1 %t645, label %bb170, label %bb171
bb169:
  store i1 false, ptr %l336, !tbaa !21
  br label %bb174
bb170:
  call void @__olang_check_failed(ptr @olang_loc_24ce0aa2bd73a813_181dbbf328082c5f)
  unreachable
bb171:
  br label %bb172
bb172:
  %t647 = load ptr, ptr %l3, !tbaa !29
  %t648 = load ptr, ptr %l337, !tbaa !29
  %t650 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %t648, ptr %t647)
  store i1 %t650, ptr %l341
  br label %bb173
bb173:
  %t651 = load i1, ptr %l341, !tbaa !21
  store i1 %t651, ptr %l336, !tbaa !21
  br label %bb174
bb174:
  %t652 = load i1, ptr %l336, !tbaa !21
  br i1 %t652, label %bb175, label %bb176
bb175:
  %t653 = load ptr, ptr %l0, !tbaa !29
  store ptr %t653, ptr %l342, !tbaa !29
  %t654 = load ptr, ptr %l3, !tbaa !29
  store ptr %t654, ptr %l343, !tbaa !29
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t656 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t657 = load i32, ptr %t656, !tbaa !23
  %t660 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t655, i32 %t657)
  store { i64, [2 x i64] } %t660, ptr %l346
  br label %bb177
bb176:
  br label %bb180
bb177:
  %t661 = load ptr, ptr %l342, !tbaa !29
  %t662 = load ptr, ptr %l343, !tbaa !29
  %t663 = load { i64, [2 x i64] }, ptr %l346
  %t664 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t661, ptr %t662, { i64, [2 x i64] } %t663)
  store %"compiler/scope:Val" %t664, ptr %l347
  br label %bb178
bb178:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t667 = getelementptr %"compiler/scope:Scoper", ptr %t665, i32 0, i32 31
  %t668 = load i32, ptr %l2, !tbaa !23
  %t670 = sext i32 %t668 to i64
  store { i64, [2 x i64] } zeroinitializer, ptr %t671
  %t672 = getelementptr { i64, [2 x i64] }, ptr %t671, i32 0, i32 0
  store i64 3, ptr %t672
  %t673 = load { i64, [2 x i64] }, ptr %t671
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t667, i64 %t670, { i64, [2 x i64] } %t673)
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb180:
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t678 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t679 = load { i64, [1 x i64] }, ptr %t678
  %t680 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t681 = load i32, ptr %t680, !tbaa !23
  %t685 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarkTerm(ptr %v0, ptr %t677, { i64, [1 x i64] } %t679, i32 %t681)
  store { i64, [2 x i64] } %t685, ptr %l356
  br label %bb181
bb181:
  %t686 = load { i64, [2 x i64] }, ptr %l356
  store { i64, [2 x i64] } %t686, ptr %l16
  %t687 = load { i64, [2 x i64] }, ptr %l9
  %t689 = extractvalue { i64, [2 x i64] } %t687, 0
  %t690 = icmp eq i64 %t689, 0
  %t692 = xor i1 %t690, true
  br i1 %t692, label %bb182, label %bb183
bb182:
  %t694 = load { i64, [2 x i64] }, ptr %l16
  %t696 = extractvalue { i64, [2 x i64] } %t694, 0
  %t697 = icmp eq i64 %t696, 0
  %t699 = xor i1 %t697, true
  store i1 %t699, ptr %l360, !tbaa !21
  br label %bb184
bb183:
  store i1 false, ptr %l360, !tbaa !21
  br label %bb184
bb184:
  %t701 = load i1, ptr %l360, !tbaa !21
  br i1 %t701, label %bb185, label %bb186
bb185:
  %t702 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t702, ptr %l16
  br label %bb187
bb186:
  br label %bb187
bb187:
  %t704 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t705 = load i32, ptr %t704, !range !{i32 0, i32 7}
  %t707 = trunc i64 1 to i32
  %t708 = icmp eq i32 %t705, %t707
  br i1 %t708, label %bb188, label %bb189
bb188:
  %t710 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t711 = load { i64, [1 x i64] }, ptr %t710
  %t713 = extractvalue { i64, [1 x i64] } %t711, 0
  %t714 = icmp eq i64 %t713, 1
  store i1 %t714, ptr %l367, !tbaa !21
  br label %bb190
bb189:
  store i1 false, ptr %l367, !tbaa !21
  br label %bb190
bb190:
  %t716 = load i1, ptr %l367, !tbaa !21
  br i1 %t716, label %bb191, label %bb192
bb191:
  store { i64, [2 x i64] } zeroinitializer, ptr %t717
  %t718 = getelementptr { i64, [2 x i64] }, ptr %t717, i32 0, i32 0
  store i64 0, ptr %t718
  %t719 = load { i64, [2 x i64] }, ptr %t717
  store { i64, [2 x i64] } %t719, ptr %l16
  br label %bb193
bb192:
  br label %bb193
bb193:
  %t721 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t722 = load { i64, [1 x i64] }, ptr %t721
  store { i64, [1 x i64] } %t722, ptr %l17
  %t724 = load { i64, [1 x i64] }, ptr %l17
  %t726 = extractvalue { i64, [1 x i64] } %t724, 0
  %t727 = icmp eq i64 %t726, 2
  br i1 %t727, label %bb194, label %bb195
bb194:
  %t729 = getelementptr { i64, [1 x i64] }, ptr %l17, i32 0, i32 1
  %t730 = getelementptr { i32 }, ptr %t729, i32 0, i32 0
  %t731 = load i32, ptr %t730
  store i32 %t731, ptr %l18, !tbaa !23
  br label %bb196
bb195:
  br label %bb205
bb196:
  %t733 = load { i64, [2 x i64] }, ptr %l16
  %t735 = extractvalue { i64, [2 x i64] } %t733, 0
  %t736 = icmp eq i64 %t735, 5
  br i1 %t736, label %bb197, label %bb198
bb197:
  %t738 = getelementptr { i64, [2 x i64] }, ptr %l16, i32 0, i32 1
  %t739 = getelementptr { i64 }, ptr %t738, i32 0, i32 0
  %t740 = load i64, ptr %t739
  store i64 %t740, ptr %l19, !tbaa !24
  %t742 = load ptr, ptr %l0, !tbaa !29
  %t744 = getelementptr %"compiler/scope:Scoper", ptr %t742, i32 0, i32 27
  %t745 = load i1, ptr %t744, !tbaa !21
  br i1 %t745, label %bb199, label %bb200
bb198:
  br label %bb204
bb199:
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t748 = load i32, ptr %l18, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunknownMark(ptr %v0, ptr %t747, i32 %t748)
  br label %bb201
bb200:
  br label %bb202
bb201:
  br label %bb202
bb202:
  %t751 = load ptr, ptr %l0, !tbaa !29
  %t752 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t753 = load i32, ptr %t752, !tbaa !23
  %t756 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t751, i32 %t753)
  store { i64, [2 x i64] } %t756, ptr %l384
  br label %bb203
bb203:
  %t757 = load { i64, [2 x i64] }, ptr %l384
  store { i64, [2 x i64] } %t757, ptr %l16
  br label %bb204
bb204:
  br label %bb210
bb205:
  br i1 true, label %bb206, label %bb207
bb206:
  br label %bb208
bb207:
  br label %bb209
bb208:
  br label %bb210
bb209:
  call void @__olang_check_failed(ptr @olang_loc_4e3f45266a1861e5_407b603c1e8329c9)
  unreachable
bb210:
  %t758 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t759 = load i32, ptr %t758, !range !{i32 0, i32 7}
  %t761 = trunc i64 6 to i32
  %t762 = icmp eq i32 %t759, %t761
  br i1 %t762, label %bb211, label %bb212
bb211:
  %t764 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t765 = load { i64, [1 x i64] }, ptr %t764
  store { i64, [1 x i64] } %t765, ptr %l20
  %t767 = load { i64, [1 x i64] }, ptr %l20
  %t769 = extractvalue { i64, [1 x i64] } %t767, 0
  %t770 = icmp eq i64 %t769, 2
  br i1 %t770, label %bb213, label %bb214
bb212:
  br label %bb226
bb213:
  %t772 = getelementptr { i64, [1 x i64] }, ptr %l20, i32 0, i32 1
  %t773 = getelementptr { i32 }, ptr %t772, i32 0, i32 0
  %t774 = load i32, ptr %t773
  store i32 %t774, ptr %l21, !tbaa !23
  br label %bb215
bb214:
  br label %bb219
bb215:
  %t776 = load ptr, ptr %l0, !tbaa !29
  %t777 = load i64, ptr @G_2ecompiler_2fscope_2eWhyField, !tbaa !24
  %t780 = getelementptr %"compiler/scope:Scoper", ptr %t776, i32 0, i32 116
  store i64 %t777, ptr %t780, !tbaa !24
  %t781 = load ptr, ptr %l0, !tbaa !29
  store ptr %t781, ptr %l393, !tbaa !29
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t783 = load i32, ptr %l21, !tbaa !23
  %t786 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %t782, i32 %t783)
  store { i64, [2 x i64] } %t786, ptr %l396
  br label %bb216
bb216:
  %t787 = load ptr, ptr %l0, !tbaa !29
  %t789 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t787, i32 0)
  store { i64, [2 x i64] } %t789, ptr %l398
  br label %bb217
bb217:
  %t790 = load ptr, ptr %l393, !tbaa !29
  %t791 = load { i64, [2 x i64] }, ptr %l396
  %t792 = load { i64, [2 x i64] }, ptr %l398
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %t790, { i64, [2 x i64] } %t791, { i64, [2 x i64] } %t792, i1 false)
  br label %bb218
bb218:
  %t793 = load ptr, ptr %l0, !tbaa !29
  %t795 = getelementptr %"compiler/scope:Scoper", ptr %t793, i32 0, i32 116
  store i64 0, ptr %t795, !tbaa !24
  br label %bb225
bb219:
  br i1 true, label %bb220, label %bb221
bb220:
  br label %bb222
bb221:
  br label %bb224
bb222:
  %t796 = load ptr, ptr %l0, !tbaa !29
  %t798 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t796, i32 0)
  store { i64, [2 x i64] } %t798, ptr %l401
  br label %bb223
bb223:
  %t799 = load { i64, [2 x i64] }, ptr %l401
  store { i64, [2 x i64] } %t799, ptr %l16
  br label %bb225
bb224:
  call void @__olang_check_failed(ptr @olang_loc_f93cd3b3e6e55ab4_45fd206fd1f47ef8)
  unreachable
bb225:
  br label %bb226
bb226:
  %t800 = load ptr, ptr %l0, !tbaa !29
  %t801 = load i32, ptr %l5, !tbaa !23
  %t804 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t800, i32 %t801)
  store i1 %t804, ptr %l404
  br label %bb227
bb227:
  %t805 = load i1, ptr %l404, !tbaa !21
  br i1 %t805, label %bb228, label %bb229
bb228:
  %t806 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t807 = load i32, ptr %t806, !range !{i32 0, i32 7}
  %t809 = trunc i64 3 to i32
  %t810 = icmp eq i32 %t807, %t809
  %t812 = xor i1 %t810, true
  store i1 %t812, ptr %l405, !tbaa !21
  br label %bb230
bb229:
  store i1 false, ptr %l405, !tbaa !21
  br label %bb230
bb230:
  %t814 = load i1, ptr %l405, !tbaa !21
  br i1 %t814, label %bb231, label %bb232
bb231:
  %t815 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t816 = load i32, ptr %t815, !range !{i32 0, i32 7}
  %t818 = trunc i64 2 to i32
  %t819 = icmp eq i32 %t816, %t818
  %t821 = xor i1 %t819, true
  store i1 %t821, ptr %l409, !tbaa !21
  br label %bb233
bb232:
  store i1 false, ptr %l409, !tbaa !21
  br label %bb233
bb233:
  %t823 = load i1, ptr %l409, !tbaa !21
  br i1 %t823, label %bb234, label %bb235
bb234:
  %t824 = load ptr, ptr %l0, !tbaa !29
  store ptr %t824, ptr %l413, !tbaa !29
  %t825 = load ptr, ptr %l3, !tbaa !29
  %t827 = icmp eq ptr %t825, null
  br i1 %t827, label %bb236, label %bb237
bb235:
  br label %bb240
bb236:
  call void @__olang_check_failed(ptr @olang_loc_cdf46faaecc001bd_4d9c5c30fc95ab59)
  unreachable
bb237:
  br label %bb238
bb238:
  %t829 = load ptr, ptr %l3, !tbaa !29
  %t830 = load ptr, ptr %l413, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitBorrow(ptr %v0, ptr %v1, ptr %t830, ptr %t829)
  br label %bb239
bb239:
  br label %bb240
bb240:
  %t832 = load ptr, ptr %l0, !tbaa !29
  %t833 = load i32, ptr %l5, !tbaa !23
  %t836 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t832, i32 %t833)
  store i1 %t836, ptr %l419
  br label %bb241
bb241:
  %t837 = load i1, ptr %l419, !tbaa !21
  br i1 %t837, label %bb242, label %bb243
bb242:
  %t838 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t839 = load i32, ptr %t838, !range !{i32 0, i32 7}
  %t841 = trunc i64 3 to i32
  %t842 = icmp eq i32 %t839, %t841
  store i1 %t842, ptr %l420, !tbaa !21
  br label %bb244
bb243:
  store i1 false, ptr %l420, !tbaa !21
  br label %bb244
bb244:
  %t844 = load i1, ptr %l420, !tbaa !21
  br i1 %t844, label %bb245, label %bb246
bb245:
  %t845 = load ptr, ptr %l3, !tbaa !29
  store ptr %t845, ptr %l423, !tbaa !29
  store i1 false, ptr %l424, !tbaa !21
  %t846 = load ptr, ptr %l423, !tbaa !29
  %t847 = icmp ne ptr %t846, null
  br i1 %t847, label %bb247, label %bb248
bb246:
  br label %bb268
bb247:
  %t849 = load ptr, ptr %l423, !tbaa !29
  %t850 = load i64, ptr %t849, !range !{i64 0, i64 18}
  %t852 = icmp eq i64 %t850, 3
  store i1 %t852, ptr %l424, !tbaa !21
  br label %bb248
bb248:
  %t853 = load i1, ptr %l424, !tbaa !21
  br i1 %t853, label %bb249, label %bb250
bb249:
  %t854 = load ptr, ptr %l3, !tbaa !29
  %t856 = getelementptr { i64, [5 x i64] }, ptr %t854, i32 0, i32 1
  %t857 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t856, i32 0, i32 2
  %t858 = load ptr, ptr %t857
  store ptr %t858, ptr %l22, !tbaa !29
  br label %bb251
bb250:
  br label %bb262
bb251:
  %t860 = load ptr, ptr %l0, !tbaa !29
  %t861 = load ptr, ptr %l22, !tbaa !29
  %t864 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitPlace(ptr %v0, ptr %v1, ptr %t860, ptr %t861)
  store i1 %t864, ptr %l431
  br label %bb252
bb252:
  %t865 = load i1, ptr %l431, !tbaa !21
  br i1 %t865, label %bb253, label %bb254
bb253:
  store i1 true, ptr %l432, !tbaa !21
  br label %bb256
bb254:
  %t866 = load ptr, ptr %l0, !tbaa !29
  %t867 = load ptr, ptr %l22, !tbaa !29
  %t870 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitHeld(ptr %v0, ptr %v1, ptr %t866, ptr %t867)
  store i1 %t870, ptr %l435
  br label %bb255
bb255:
  %t871 = load i1, ptr %l435, !tbaa !21
  store i1 %t871, ptr %l432, !tbaa !21
  br label %bb256
bb256:
  %t872 = load i1, ptr %l432, !tbaa !21
  br i1 %t872, label %bb257, label %bb258
bb257:
  %t873 = load ptr, ptr %l0, !tbaa !29
  %t875 = getelementptr %"compiler/scope:Scoper", ptr %t873, i32 0, i32 41
  store ptr %t875, ptr %l437, !tbaa !29
  %t876 = load i32, ptr %l2, !tbaa !23
  %t878 = sext i32 %t876 to i64
  store i64 %t878, ptr %l439, !tbaa !24
  %t879 = load ptr, ptr %l0, !tbaa !29
  %t880 = load ptr, ptr %l22, !tbaa !29
  %t883 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %t879, ptr %t880)
  store { i64, [2 x i64] } %t883, ptr %l442
  br label %bb259
bb258:
  br label %bb261
bb259:
  %t884 = load ptr, ptr %l437, !tbaa !29
  %t885 = load i64, ptr %l439, !tbaa !24
  %t886 = load { i64, [2 x i64] }, ptr %l442
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H38f9aff1b0310316a48dc5a28922f96e(ptr %v0, ptr %t884, i64 %t885, { i64, [2 x i64] } %t886)
  br label %bb260
bb260:
  br label %bb261
bb261:
  br label %bb267
bb262:
  br i1 true, label %bb263, label %bb264
bb263:
  br label %bb265
bb264:
  br label %bb266
bb265:
  br label %bb267
bb266:
  call void @__olang_check_failed(ptr @olang_loc_8a01e9430b40cdd5_116fbcb2b32a38a1)
  unreachable
bb267:
  br label %bb268
bb268:
  %t887 = load { i64, [2 x i64] }, ptr %l16
  %t889 = extractvalue { i64, [2 x i64] } %t887, 0
  %t890 = icmp eq i64 %t889, 0
  br i1 %t890, label %bb269, label %bb270
bb269:
  store %olang.scope zeroinitializer, ptr %s31
  %t892 = load { i64, [2 x i64] }, ptr %l9
  %t894 = extractvalue { i64, [2 x i64] } %t892, 0
  %t895 = icmp eq i64 %t894, 0
  %t897 = xor i1 %t895, true
  br i1 %t897, label %bb271, label %bb272
bb270:
  br label %bb429
bb271:
  %t899 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t899, ptr %l448
  br label %bb274
bb272:
  %t901 = load ptr, ptr %l0, !tbaa !29
  %t902 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 3
  %t903 = load i32, ptr %t902, !tbaa !23
  %t906 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t901, i32 %t903)
  store { i64, [2 x i64] } %t906, ptr %l452
  br label %bb273
bb273:
  %t907 = load { i64, [2 x i64] }, ptr %l452
  store { i64, [2 x i64] } %t907, ptr %l448
  br label %bb274
bb274:
  %t908 = load { i64, [2 x i64] }, ptr %l448
  store { i64, [2 x i64] } %t908, ptr %l23
  %t909 = load ptr, ptr %l0, !tbaa !29
  %t910 = load i32, ptr %l2, !tbaa !23
  %t912 = sext i32 %t910 to i64
  %t915 = getelementptr %"compiler/scope:Scoper", ptr %t909, i32 0, i32 187
  store i64 %t912, ptr %t915, !tbaa !24
  %t916 = load ptr, ptr %l0, !tbaa !29
  %t917 = load i32, ptr %l2, !tbaa !23
  %t919 = sext i32 %t917 to i64
  %t922 = getelementptr %"compiler/scope:Scoper", ptr %t916, i32 0, i32 188
  store i64 %t919, ptr %t922, !tbaa !24
  %t923 = load ptr, ptr %l0, !tbaa !29
  %t924 = load i32, ptr %l5, !tbaa !23
  %t927 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t923, i32 %t924)
  store i1 %t927, ptr %l461
  br label %bb275
bb275:
  %t928 = load i1, ptr %l461, !tbaa !21
  %t929 = xor i1 %t928, true
  br i1 %t929, label %bb276, label %bb277
bb276:
  %t931 = load ptr, ptr %l0, !tbaa !29
  %t933 = getelementptr %"compiler/scope:Scoper", ptr %t931, i32 0, i32 0
  %t934 = load ptr, ptr %t933, !tbaa !29
  %t936 = getelementptr %"compiler/generic:Program", ptr %t934, i32 0, i32 2
  %t937 = load i32, ptr %l5, !tbaa !23
  %t940 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t936, i32 %t937)
  store i1 %t940, ptr %l468
  br label %bb278
bb277:
  store i1 false, ptr %l463, !tbaa !21
  br label %bb279
bb278:
  %t941 = load i1, ptr %l468, !tbaa !21
  store i1 %t941, ptr %l463, !tbaa !21
  br label %bb279
bb279:
  %t942 = load i1, ptr %l463, !tbaa !21
  br i1 %t942, label %bb280, label %bb281
bb280:
  %t943 = load ptr, ptr %l0, !tbaa !29
  store ptr %t943, ptr %l470, !tbaa !29
  %t944 = load ptr, ptr %l3, !tbaa !29
  %t946 = icmp eq ptr %t944, null
  br i1 %t946, label %bb282, label %bb283
bb281:
  store ptr null, ptr %l469, !tbaa !29
  br label %bb287
bb282:
  call void @__olang_check_failed(ptr @olang_loc_c1bd851797ba3a07_3a08c51eb1b81973)
  unreachable
bb283:
  br label %bb284
bb284:
  %t948 = load ptr, ptr %l3, !tbaa !29
  %t950 = load ptr, ptr %l470, !tbaa !29
  %t952 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s31, ptr %t950, ptr %t948)
  store ptr %t952, ptr %l475
  br label %bb285
bb285:
  %t953 = load ptr, ptr %l475, !tbaa !29
  %t955 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %s31, ptr %s31, ptr %t953)
  store ptr %t955, ptr %l477
  br label %bb286
bb286:
  %t956 = load ptr, ptr %l477, !tbaa !29
  store ptr %t956, ptr %l469, !tbaa !29
  br label %bb287
bb287:
  %t957 = load ptr, ptr %l469, !tbaa !29
  store ptr %t957, ptr %l24, !tbaa !29
  %t958 = load ptr, ptr %l0, !tbaa !29
  store ptr %t958, ptr %l478, !tbaa !29
  %t959 = load ptr, ptr %l24, !tbaa !29
  %t961 = icmp eq ptr %t959, null
  %t963 = xor i1 %t961, true
  br i1 %t963, label %bb288, label %bb289
bb288:
  %t965 = load ptr, ptr %l24, !tbaa !29
  %t967 = getelementptr %"compiler/typed:Call", ptr %t965, i32 0, i32 2
  %t968 = load i32, ptr %t967, !tbaa !23
  %t970 = sext i32 %t968 to i64
  store i64 %t970, ptr %l482, !tbaa !24
  br label %bb290
bb289:
  store i64 -1, ptr %l482, !tbaa !24
  br label %bb290
bb290:
  %t972 = load i64, ptr %l482, !tbaa !24
  %t973 = load ptr, ptr %l478, !tbaa !29
  %t974 = getelementptr %"compiler/scope:Scoper", ptr %t973, i32 0, i32 193
  store i64 %t972, ptr %t974, !tbaa !24
  %t975 = load ptr, ptr %l0, !tbaa !29
  store ptr %t975, ptr %l486, !tbaa !29
  %t976 = load i1, ptr %l7, !tbaa !21
  br i1 %t976, label %bb291, label %bb292
bb291:
  %t978 = load i1, ptr %l8, !tbaa !21
  %t980 = xor i1 %t978, true
  store i1 %t980, ptr %l488, !tbaa !21
  br label %bb293
bb292:
  store i1 false, ptr %l488, !tbaa !21
  br label %bb293
bb293:
  %t982 = load i1, ptr %l488, !tbaa !21
  br i1 %t982, label %bb294, label %bb295
bb294:
  %t983 = load { i64, [2 x i64] }, ptr %l9
  %t985 = extractvalue { i64, [2 x i64] } %t983, 0
  %t986 = icmp eq i64 %t985, 0
  store i1 %t986, ptr %l491, !tbaa !21
  br label %bb296
bb295:
  store i1 false, ptr %l491, !tbaa !21
  br label %bb296
bb296:
  %t988 = load i1, ptr %l491, !tbaa !21
  %t989 = load ptr, ptr %l486, !tbaa !29
  %t990 = getelementptr %"compiler/scope:Scoper", ptr %t989, i32 0, i32 119
  store i1 %t988, ptr %t990, !tbaa !21
  %t991 = load i1, ptr %l8, !tbaa !21
  br i1 %t991, label %bb297, label %bb298
bb297:
  %t993 = load ptr, ptr %l0, !tbaa !29
  store ptr %t993, ptr %l495, !tbaa !29
  %t994 = load i1, ptr %l7, !tbaa !21
  br i1 %t994, label %bb299, label %bb300
bb298:
  br label %bb305
bb299:
  %t996 = load { i64, [2 x i64] }, ptr %l9
  %t998 = extractvalue { i64, [2 x i64] } %t996, 0
  %t999 = icmp eq i64 %t998, 0
  store i1 %t999, ptr %l497, !tbaa !21
  br label %bb301
bb300:
  store i1 false, ptr %l497, !tbaa !21
  br label %bb301
bb301:
  %t1001 = load i1, ptr %l497, !tbaa !21
  br i1 %t1001, label %bb302, label %bb303
bb302:
  store i64 1, ptr %l500, !tbaa !24
  br label %bb304
bb303:
  store i64 0, ptr %l500, !tbaa !24
  br label %bb304
bb304:
  %t1002 = load i64, ptr %l500, !tbaa !24
  %t1003 = load ptr, ptr %l495, !tbaa !29
  %t1004 = getelementptr %"compiler/scope:Scoper", ptr %t1003, i32 0, i32 122
  store i64 %t1002, ptr %t1004, !tbaa !24
  br label %bb305
bb305:
  %t1005 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t1006
  %t1007 = getelementptr { i64, [2 x i64] }, ptr %t1006, i32 0, i32 0
  store i64 0, ptr %t1007
  %t1008 = load { i64, [2 x i64] }, ptr %t1006
  %t1011 = getelementptr %"compiler/scope:Scoper", ptr %t1005, i32 0, i32 67
  store { i64, [2 x i64] } %t1008, ptr %t1011
  %t1012 = load ptr, ptr %l0, !tbaa !29
  %t1013 = load ptr, ptr %l3, !tbaa !29
  %t1014 = load { i64, [2 x i64] }, ptr %l23
  %t1018 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1012, ptr %t1013, { i64, [2 x i64] } %t1014)
  store %"compiler/scope:Val" %t1018, ptr %l506
  br label %bb306
bb306:
  %t1019 = load %"compiler/scope:Val", ptr %l506
  store %"compiler/scope:Val" %t1019, ptr %l25
  %t1020 = load ptr, ptr %l0, !tbaa !29
  %t1022 = getelementptr %"compiler/scope:Scoper", ptr %t1020, i32 0, i32 187
  store i64 -1, ptr %t1022, !tbaa !24
  %t1023 = load ptr, ptr %l0, !tbaa !29
  %t1025 = getelementptr %"compiler/scope:Scoper", ptr %t1023, i32 0, i32 188
  store i64 -1, ptr %t1025, !tbaa !24
  %t1026 = load ptr, ptr %l0, !tbaa !29
  %t1028 = getelementptr %"compiler/scope:Scoper", ptr %t1026, i32 0, i32 193
  store i64 -1, ptr %t1028, !tbaa !24
  %t1029 = load ptr, ptr %l0, !tbaa !29
  %t1031 = getelementptr %"compiler/scope:Scoper", ptr %t1029, i32 0, i32 119
  store i1 false, ptr %t1031, !tbaa !21
  %t1032 = load ptr, ptr %l0, !tbaa !29
  %t1034 = getelementptr %"compiler/scope:Scoper", ptr %t1032, i32 0, i32 122
  store i64 -1, ptr %t1034, !tbaa !24
  %t1035 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1035, ptr %l512, !tbaa !29
  %t1036 = load i32, ptr %l2, !tbaa !23
  %t1038 = sext i32 %t1036 to i64
  store i64 %t1038, ptr %l514, !tbaa !24
  %t1039 = load ptr, ptr %l3, !tbaa !29
  %t1041 = icmp eq ptr %t1039, null
  br i1 %t1041, label %bb307, label %bb308
bb307:
  call void @__olang_check_failed(ptr @olang_loc_f6ec8187c757dce8_8726f65a7d0e6fa4)
  unreachable
bb308:
  br label %bb309
bb309:
  %t1043 = load ptr, ptr %l3, !tbaa !29
  %t1044 = load %"compiler/scope:Val", ptr %l25
  %t1045 = load ptr, ptr %l512, !tbaa !29
  %t1046 = load i64, ptr %l514, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteOrigin(ptr %v0, ptr %v1, ptr %t1045, i64 %t1046, ptr %t1043, %"compiler/scope:Val" %t1044)
  br label %bb310
bb310:
  %t1049 = load ptr, ptr %l0, !tbaa !29
  %t1051 = getelementptr %"compiler/scope:Scoper", ptr %t1049, i32 0, i32 67
  %t1052 = load { i64, [2 x i64] }, ptr %t1051
  %t1054 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t1052)
  store i1 %t1054, ptr %l521
  br label %bb311
bb311:
  %t1055 = load i1, ptr %l521, !tbaa !21
  br i1 %t1055, label %bb312, label %bb313
bb312:
  %t1056 = load ptr, ptr %l0, !tbaa !29
  %t1057 = load i32, ptr %l2, !tbaa !23
  %t1059 = sext i32 %t1057 to i64
  %t1062 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewalkLocal(ptr %v0, ptr %t1056, i64 %t1059)
  store i1 %t1062, ptr %l526
  br label %bb314
bb313:
  store i1 false, ptr %l522, !tbaa !21
  br label %bb315
bb314:
  %t1063 = load i1, ptr %l526, !tbaa !21
  store i1 %t1063, ptr %l522, !tbaa !21
  br label %bb315
bb315:
  %t1064 = load i1, ptr %l522, !tbaa !21
  br i1 %t1064, label %bb316, label %bb317
bb316:
  %t1065 = load ptr, ptr %l0, !tbaa !29
  %t1067 = getelementptr %"compiler/scope:Scoper", ptr %t1065, i32 0, i32 66
  %t1068 = load i32, ptr %l2, !tbaa !23
  %t1070 = sext i32 %t1068 to i64
  %t1071 = load ptr, ptr %l0, !tbaa !29
  %t1073 = getelementptr %"compiler/scope:Scoper", ptr %t1071, i32 0, i32 67
  %t1074 = load { i64, [2 x i64] }, ptr %t1073
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H38f9aff1b0310316a48dc5a28922f96e(ptr %v0, ptr %t1067, i64 %t1070, { i64, [2 x i64] } %t1074)
  br label %bb318
bb317:
  br label %bb319
bb318:
  br label %bb319
bb319:
  %t1078 = load ptr, ptr %l0, !tbaa !29
  %t1080 = getelementptr %"compiler/scope:Scoper", ptr %t1078, i32 0, i32 69
  %t1081 = load i64, ptr %t1080, !tbaa !24
  %t1083 = icmp sge i64 %t1081, 0
  br i1 %t1083, label %bb320, label %bb321
bb320:
  %t1085 = load ptr, ptr %l0, !tbaa !29
  %t1087 = getelementptr %"compiler/scope:Scoper", ptr %t1085, i32 0, i32 68
  %t1088 = load i32, ptr %l2, !tbaa !23
  %t1090 = sext i32 %t1088 to i64
  %t1091 = load ptr, ptr %l0, !tbaa !29
  %t1093 = getelementptr %"compiler/scope:Scoper", ptr %t1091, i32 0, i32 69
  %t1094 = load i64, ptr %t1093, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t1087, i64 %t1090, i64 %t1094)
  br label %bb322
bb321:
  br label %bb323
bb322:
  br label %bb323
bb323:
  %t1098 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1098, ptr %l542, !tbaa !29
  %t1099 = load ptr, ptr %l3, !tbaa !29
  %t1101 = icmp eq ptr %t1099, null
  br i1 %t1101, label %bb324, label %bb325
bb324:
  call void @__olang_check_failed(ptr @olang_loc_91699d3516f660a1_aa0e11d9464965f5)
  unreachable
bb325:
  br label %bb326
bb326:
  %t1103 = load ptr, ptr %l3, !tbaa !29
  %t1104 = load ptr, ptr %l542, !tbaa !29
  %t1106 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %v1, ptr %t1104, ptr %t1103)
  store i64 %t1106, ptr %l546
  br label %bb327
bb327:
  %t1107 = load i64, ptr %l546, !tbaa !24
  store i64 %t1107, ptr %l26, !tbaa !24
  %t1108 = load i64, ptr %l26, !tbaa !24
  %t1110 = icmp sge i64 %t1108, 0
  br i1 %t1110, label %bb328, label %bb329
bb328:
  %t1112 = load ptr, ptr %l0, !tbaa !29
  %t1114 = getelementptr %"compiler/scope:Scoper", ptr %t1112, i32 0, i32 68
  %t1115 = load i64, ptr %l26, !tbaa !24
  %t1118 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t1114, i64 %t1115)
  store i1 %t1118, ptr %l553
  br label %bb330
bb329:
  store i1 false, ptr %l549, !tbaa !21
  br label %bb331
bb330:
  %t1119 = load i1, ptr %l553, !tbaa !21
  store i1 %t1119, ptr %l549, !tbaa !21
  br label %bb331
bb331:
  %t1120 = load i1, ptr %l549, !tbaa !21
  br i1 %t1120, label %bb332, label %bb333
bb332:
  %t1121 = load ptr, ptr %l0, !tbaa !29
  %t1123 = getelementptr %"compiler/scope:Scoper", ptr %t1121, i32 0, i32 68
  store ptr %t1123, ptr %l555, !tbaa !29
  %t1124 = load i32, ptr %l2, !tbaa !23
  %t1126 = sext i32 %t1124 to i64
  store i64 %t1126, ptr %l557, !tbaa !24
  %t1127 = load ptr, ptr %l0, !tbaa !29
  %t1129 = getelementptr %"compiler/scope:Scoper", ptr %t1127, i32 0, i32 68
  %t1130 = load i64, ptr %l26, !tbaa !24
  %t1133 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t1129, i64 %t1130)
  %t1134 = extractvalue { i32, i64 } %t1133, 1
  %t1135 = extractvalue { i32, i64 } %t1133, 0
  store i32 %t1135, ptr %l563
  %t1136 = icmp ne i32 %t1135, 0
  br i1 %t1136, label %bb335, label %ok.1137, !prof !99
ok.1137:
  store i64 %t1134, ptr %l562
  br label %bb334
bb333:
  br label %bb339
bb334:
  %t1138 = load i64, ptr %l562, !tbaa !24
  store i64 %t1138, ptr %l558, !tbaa !24
  br label %bb337
bb335:
  br label %bb336
bb336:
  store i64 -1, ptr %l558, !tbaa !24
  br label %bb337
bb337:
  %t1139 = load ptr, ptr %l555, !tbaa !29
  %t1140 = load i64, ptr %l557, !tbaa !24
  %t1141 = load i64, ptr %l558, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t1139, i64 %t1140, i64 %t1141)
  br label %bb338
bb338:
  br label %bb339
bb339:
  %t1142 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t1143
  %t1144 = getelementptr { i64, [2 x i64] }, ptr %t1143, i32 0, i32 0
  store i64 0, ptr %t1144
  %t1145 = load { i64, [2 x i64] }, ptr %t1143
  %t1148 = getelementptr %"compiler/scope:Scoper", ptr %t1142, i32 0, i32 67
  store { i64, [2 x i64] } %t1145, ptr %t1148
  %t1149 = load ptr, ptr %l0, !tbaa !29
  %t1151 = getelementptr %"compiler/scope:Scoper", ptr %t1149, i32 0, i32 69
  store i64 -1, ptr %t1151, !tbaa !24
  %t1152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1152, ptr %l567, !tbaa !29
  %t1153 = load ptr, ptr %l3, !tbaa !29
  %t1155 = icmp eq ptr %t1153, null
  br i1 %t1155, label %bb340, label %bb341
bb340:
  call void @__olang_check_failed(ptr @olang_loc_d8ab151ef39a0b1a_493c405c799b164e)
  unreachable
bb341:
  br label %bb342
bb342:
  %t1157 = load ptr, ptr %l3, !tbaa !29
  %t1159 = load ptr, ptr %l567, !tbaa !29
  %t1161 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s31, ptr %t1159, ptr %t1157)
  store ptr %t1161, ptr %l572
  br label %bb343
bb343:
  %t1162 = load ptr, ptr %l572, !tbaa !29
  %t1163 = call ptr @compiler_2fscope_2eunPassed(ptr %s31, ptr %s31, ptr %t1162)
  store ptr %t1163, ptr %l573
  br label %bb344
bb344:
  %t1164 = load ptr, ptr %l573, !tbaa !29
  %t1166 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %s31, ptr %s31, ptr %t1164)
  store ptr %t1166, ptr %l575
  br label %bb345
bb345:
  %t1167 = load ptr, ptr %l575, !tbaa !29
  store ptr %t1167, ptr %l27, !tbaa !29
  %t1168 = load ptr, ptr %l27, !tbaa !29
  %t1170 = icmp eq ptr %t1168, null
  %t1172 = xor i1 %t1170, true
  br i1 %t1172, label %bb346, label %bb347
bb346:
  %t1174 = load ptr, ptr %l27, !tbaa !29
  %t1176 = getelementptr %"compiler/typed:Call", ptr %t1174, i32 0, i32 1
  %t1177 = load { i64, ptr }, ptr %t1176, !tbaa !27
  %t1179 = extractvalue { i64, ptr } %t1177, 0
  %t1181 = icmp sgt i64 %t1179, 0
  store i1 %t1181, ptr %l579, !tbaa !21
  br label %bb348
bb347:
  store i1 false, ptr %l579, !tbaa !21
  br label %bb348
bb348:
  %t1183 = load i1, ptr %l579, !tbaa !21
  br i1 %t1183, label %bb349, label %bb350
bb349:
  %t1184 = load ptr, ptr %l0, !tbaa !29
  %t1185 = load ptr, ptr %l27, !tbaa !29
  %t1187 = getelementptr %"compiler/typed:Call", ptr %t1185, i32 0, i32 1
  %t1188 = load { i64, ptr }, ptr %t1187, !tbaa !27
  store { i64, ptr } %t1188, ptr %l586, !tbaa !27
  %t1189 = getelementptr { i64, ptr }, ptr %l586, i32 0, i32 1
  %t1190 = load ptr, ptr %t1189, !tbaa !27
  %t1191 = getelementptr ptr, ptr %t1190, i64 0
  %t1192 = load ptr, ptr %t1191, !tbaa !39
  %t1195 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLocal(ptr %v0, ptr %s31, ptr %t1184, ptr %t1192)
  store i64 %t1195, ptr %l588
  br label %bb351
bb350:
  br label %bb364
bb351:
  %t1196 = load i64, ptr %l588, !tbaa !24
  store i64 %t1196, ptr %l28, !tbaa !24
  %t1197 = load i64, ptr %l28, !tbaa !24
  %t1199 = icmp sge i64 %t1197, 0
  br i1 %t1199, label %bb352, label %bb353
bb352:
  %t1201 = load ptr, ptr %l0, !tbaa !29
  %t1203 = getelementptr %"compiler/scope:Scoper", ptr %t1201, i32 0, i32 68
  %t1204 = load i64, ptr %l28, !tbaa !24
  %t1207 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t1203, i64 %t1204)
  store i1 %t1207, ptr %l595
  br label %bb354
bb353:
  store i1 false, ptr %l591, !tbaa !21
  br label %bb355
bb354:
  %t1208 = load i1, ptr %l595, !tbaa !21
  store i1 %t1208, ptr %l591, !tbaa !21
  br label %bb355
bb355:
  %t1209 = load i1, ptr %l591, !tbaa !21
  br i1 %t1209, label %bb356, label %bb357
bb356:
  %t1210 = load ptr, ptr %l0, !tbaa !29
  %t1212 = getelementptr %"compiler/scope:Scoper", ptr %t1210, i32 0, i32 68
  store ptr %t1212, ptr %l597, !tbaa !29
  %t1213 = load i32, ptr %l2, !tbaa !23
  %t1215 = sext i32 %t1213 to i64
  store i64 %t1215, ptr %l599, !tbaa !24
  %t1216 = load ptr, ptr %l0, !tbaa !29
  %t1218 = getelementptr %"compiler/scope:Scoper", ptr %t1216, i32 0, i32 68
  %t1219 = load i64, ptr %l28, !tbaa !24
  %t1222 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t1218, i64 %t1219)
  %t1223 = extractvalue { i32, i64 } %t1222, 1
  %t1224 = extractvalue { i32, i64 } %t1222, 0
  store i32 %t1224, ptr %l605
  %t1225 = icmp ne i32 %t1224, 0
  br i1 %t1225, label %bb359, label %ok.1226, !prof !99
ok.1226:
  store i64 %t1223, ptr %l604
  br label %bb358
bb357:
  br label %bb363
bb358:
  %t1227 = load i64, ptr %l604, !tbaa !24
  store i64 %t1227, ptr %l600, !tbaa !24
  br label %bb361
bb359:
  br label %bb360
bb360:
  store i64 -1, ptr %l600, !tbaa !24
  br label %bb361
bb361:
  %t1228 = load ptr, ptr %l597, !tbaa !29
  %t1229 = load i64, ptr %l599, !tbaa !24
  %t1230 = load i64, ptr %l600, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t1228, i64 %t1229, i64 %t1230)
  br label %bb362
bb362:
  br label %bb363
bb363:
  br label %bb364
bb364:
  %t1231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1231, ptr %l606, !tbaa !29
  %t1232 = load i32, ptr %l2, !tbaa !23
  store i32 %t1232, ptr %l607, !tbaa !23
  %t1233 = load ptr, ptr %l3, !tbaa !29
  %t1235 = icmp eq ptr %t1233, null
  br i1 %t1235, label %bb365, label %bb366
bb365:
  call void @__olang_check_failed(ptr @olang_loc_4be91e4a1fba2bdb_4552e3a09b71daff)
  unreachable
bb366:
  br label %bb367
bb367:
  %t1237 = load ptr, ptr %l3, !tbaa !29
  %t1238 = load ptr, ptr %l606, !tbaa !29
  %t1239 = load i32, ptr %l607, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %t1238, i32 %t1239, ptr %t1237)
  br label %bb368
bb368:
  %t1241 = load ptr, ptr %l0, !tbaa !29
  %t1243 = getelementptr %"compiler/scope:Scoper", ptr %t1241, i32 0, i32 31
  store ptr %t1243, ptr %l612, !tbaa !29
  %t1244 = load i32, ptr %l2, !tbaa !23
  %t1246 = sext i32 %t1244 to i64
  store i64 %t1246, ptr %l614, !tbaa !24
  %t1247 = load ptr, ptr %l0, !tbaa !29
  %t1248 = load %"compiler/scope:Val", ptr %l25
  %t1249 = load { i64, [2 x i64] }, ptr %l23
  %t1253 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalTerm(ptr %v0, ptr %t1247, %"compiler/scope:Val" %t1248, { i64, [2 x i64] } %t1249)
  store { i64, [2 x i64] } %t1253, ptr %l618
  br label %bb369
bb369:
  %t1254 = load ptr, ptr %l612, !tbaa !29
  %t1255 = load i64, ptr %l614, !tbaa !24
  %t1256 = load { i64, [2 x i64] }, ptr %l618
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1254, i64 %t1255, { i64, [2 x i64] } %t1256)
  br label %bb370
bb370:
  %t1257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1257, ptr %l619, !tbaa !29
  %t1258 = load i32, ptr %l5, !tbaa !23
  store i32 %t1258, ptr %l620, !tbaa !23
  %t1259 = load ptr, ptr %l3, !tbaa !29
  %t1261 = icmp eq ptr %t1259, null
  br i1 %t1261, label %bb371, label %bb372
bb371:
  call void @__olang_check_failed(ptr @olang_loc_822a996be6bf60ec_a610051fdc17dde0)
  unreachable
bb372:
  br label %bb373
bb373:
  %t1263 = load ptr, ptr %l3, !tbaa !29
  %t1264 = load ptr, ptr %l619, !tbaa !29
  %t1265 = load i32, ptr %l620, !tbaa !23
  %t1267 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownCall(ptr %v0, ptr %v1, ptr %t1264, i32 %t1265, ptr %t1263)
  store i1 %t1267, ptr %l624
  br label %bb374
bb374:
  %t1268 = load i1, ptr %l624, !tbaa !21
  br i1 %t1268, label %bb375, label %bb376
bb375:
  %t1269 = load ptr, ptr %l0, !tbaa !29
  %t1271 = getelementptr %"compiler/scope:Scoper", ptr %t1269, i32 0, i32 31
  %t1272 = load i32, ptr %l2, !tbaa !23
  %t1274 = sext i32 %t1272 to i64
  %t1275 = load { i64, [2 x i64] }, ptr %l23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1271, i64 %t1274, { i64, [2 x i64] } %t1275)
  br label %bb377
bb376:
  br label %bb386
bb377:
  %t1279 = load ptr, ptr %l3, !tbaa !29
  %t1281 = icmp eq ptr %t1279, null
  br i1 %t1281, label %bb378, label %bb379
bb378:
  call void @__olang_check_failed(ptr @olang_loc_20bba8d7d253ea85_a129e3e310279d91)
  unreachable
bb379:
  br label %bb380
bb380:
  %t1283 = load ptr, ptr %l3, !tbaa !29
  %t1286 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %t1283)
  store ptr %t1286, ptr %l634
  br label %bb381
bb381:
  %t1287 = load ptr, ptr %l634, !tbaa !29
  store ptr %t1287, ptr %l29, !tbaa !29
  %t1288 = load ptr, ptr %l29, !tbaa !29
  %t1290 = icmp eq ptr %t1288, null
  %t1292 = xor i1 %t1290, true
  br i1 %t1292, label %bb382, label %bb383
bb382:
  %t1294 = load ptr, ptr %l0, !tbaa !29
  %t1295 = load ptr, ptr %l29, !tbaa !29
  %t1297 = getelementptr %"compiler/typed:Call", ptr %t1295, i32 0, i32 2
  %t1298 = load i32, ptr %t1297, !tbaa !23
  %t1299 = load { i64, [2 x i64] }, ptr %l23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuild(ptr %v0, ptr %t1294, i32 %t1298, { i64, [2 x i64] } %t1299)
  br label %bb384
bb383:
  br label %bb385
bb384:
  br label %bb385
bb385:
  br label %bb386
bb386:
  %t1303 = load ptr, ptr %l0, !tbaa !29
  %t1305 = getelementptr %"compiler/scope:Scoper", ptr %t1303, i32 0, i32 41
  %t1306 = load i32, ptr %l2, !tbaa !23
  %t1308 = sext i32 %t1306 to i64
  %t1311 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H65b4b9a6d1679f5b3ddedaa5b2e336bd(ptr %v0, ptr %t1305, i64 %t1308)
  %t1312 = extractvalue { i32, { i64, [2 x i64] } } %t1311, 1
  %t1313 = extractvalue { i32, { i64, [2 x i64] } } %t1311, 0
  store i32 %t1313, ptr %l648
  %t1314 = icmp ne i32 %t1313, 0
  br i1 %t1314, label %bb388, label %ok.1315, !prof !99
ok.1315:
  store { i64, [2 x i64] } %t1312, ptr %l647
  br label %bb387
bb387:
  %t1316 = load { i64, [2 x i64] }, ptr %l647
  store { i64, [2 x i64] } %t1316, ptr %l642
  br label %bb390
bb388:
  br label %bb389
bb389:
  store { i64, [2 x i64] } zeroinitializer, ptr %t1317
  %t1318 = getelementptr { i64, [2 x i64] }, ptr %t1317, i32 0, i32 0
  store i64 0, ptr %t1318
  %t1319 = load { i64, [2 x i64] }, ptr %t1317
  store { i64, [2 x i64] } %t1319, ptr %l642
  br label %bb390
bb390:
  %t1321 = load { i64, [2 x i64] }, ptr %l642
  store { i64, [2 x i64] } %t1321, ptr %l30
  %t1322 = load { i64, [2 x i64] }, ptr %l30
  %t1324 = extractvalue { i64, [2 x i64] } %t1322, 0
  %t1325 = icmp eq i64 %t1324, 0
  %t1327 = xor i1 %t1325, true
  br i1 %t1327, label %bb391, label %bb392
bb391:
  %t1329 = load ptr, ptr %l0, !tbaa !29
  %t1331 = getelementptr %"compiler/scope:Scoper", ptr %t1329, i32 0, i32 31
  %t1332 = load i32, ptr %l2, !tbaa !23
  %t1334 = sext i32 %t1332 to i64
  %t1335 = load { i64, [2 x i64] }, ptr %l30
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1331, i64 %t1334, { i64, [2 x i64] } %t1335)
  br label %bb393
bb392:
  br label %bb394
bb393:
  br label %bb394
bb394:
  %t1339 = getelementptr %"compiler/scope:Val", ptr %l25, i32 0, i32 1
  %t1340 = load { i64, [2 x i64] }, ptr %t1339
  store { i64, [2 x i64] } %t1340, ptr %l31
  %t1342 = load { i64, [2 x i64] }, ptr %l31
  %t1344 = extractvalue { i64, [2 x i64] } %t1342, 0
  %t1345 = icmp eq i64 %t1344, 4
  br i1 %t1345, label %bb395, label %bb396
bb395:
  %t1347 = getelementptr { i64, [2 x i64] }, ptr %l31, i32 0, i32 1
  %t1348 = getelementptr { i64, i64 }, ptr %t1347, i32 0, i32 0
  %t1349 = load i64, ptr %t1348
  store i64 %t1349, ptr %l32, !tbaa !24
  br label %bb397
bb396:
  br label %bb423
bb397:
  %t1351 = load i64, ptr %l32, !tbaa !24
  %t1353 = icmp slt i64 %t1351, 0
  br i1 %t1353, label %bb398, label %bb399
bb398:
  %t1355 = load i64, ptr %l32, !tbaa !24
  %t1357 = sub i64 0, %t1355
  %t1359 = sub i64 %t1357, 1
  store i64 %t1359, ptr %l667, !tbaa !24
  %t1360 = load ptr, ptr %l0, !tbaa !29
  %t1362 = getelementptr %"compiler/scope:Scoper", ptr %t1360, i32 0, i32 102
  %t1364 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t1362)
  store i64 %t1364, ptr %l670
  br label %bb400
bb399:
  store i1 false, ptr %l664, !tbaa !21
  br label %bb401
bb400:
  %t1365 = load i64, ptr %l667, !tbaa !24
  %t1366 = load i64, ptr %l670, !tbaa !24
  %t1367 = icmp slt i64 %t1365, %t1366
  store i1 %t1367, ptr %l664, !tbaa !21
  br label %bb401
bb401:
  %t1369 = load i1, ptr %l664, !tbaa !21
  br i1 %t1369, label %bb402, label %bb403
bb402:
  %t1370 = load ptr, ptr %l0, !tbaa !29
  %t1372 = getelementptr %"compiler/scope:Scoper", ptr %t1370, i32 0, i32 102
  %t1373 = load i64, ptr %l32, !tbaa !24
  %t1375 = sub i64 0, %t1373
  %t1377 = sub i64 %t1375, 1
  %t1380 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1372, i64 %t1377)
  store i1 %t1380, ptr %l678
  br label %bb404
bb403:
  store i1 false, ptr %l672, !tbaa !21
  br label %bb405
bb404:
  %t1381 = load i1, ptr %l678, !tbaa !21
  store i1 %t1381, ptr %l672, !tbaa !21
  br label %bb405
bb405:
  %t1382 = load i1, ptr %l672, !tbaa !21
  br i1 %t1382, label %bb406, label %bb407
bb406:
  %t1383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1383, ptr %l679, !tbaa !29
  %t1384 = load ptr, ptr %l3, !tbaa !29
  %t1386 = icmp eq ptr %t1384, null
  br i1 %t1386, label %bb408, label %bb409
bb407:
  br label %bb422
bb408:
  call void @__olang_check_failed(ptr @olang_loc_9530d1c4ea412de_9379e3d37f97848a)
  unreachable
bb409:
  br label %bb410
bb410:
  %t1388 = load ptr, ptr %l3, !tbaa !29
  %t1389 = load ptr, ptr %l679, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackExpr(ptr %v0, ptr %v1, ptr %t1389, ptr %t1388)
  br label %bb411
bb411:
  %t1391 = load ptr, ptr %l0, !tbaa !29
  %t1393 = getelementptr %"compiler/scope:Scoper", ptr %t1391, i32 0, i32 27
  %t1394 = load i1, ptr %t1393, !tbaa !21
  br i1 %t1394, label %bb412, label %bb413
bb412:
  store %olang.scope zeroinitializer, ptr %s43
  %t1396 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1396, ptr %l685, !tbaa !29
  %t1397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1397, ptr %l686, !tbaa !29
  %t1398 = load ptr, ptr %l3, !tbaa !29
  %t1400 = icmp eq ptr %t1398, null
  br i1 %t1400, label %bb414, label %bb415
bb413:
  br label %bb421
bb414:
  call void @__olang_check_failed(ptr @olang_loc_ac920da97f69d3ae_2bb2c283cdbb4f6a)
  unreachable
bb415:
  br label %bb416
bb416:
  %t1402 = load ptr, ptr %l3, !tbaa !29
  %t1404 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t1402)
  store %"compiler/source:Span" %t1404, ptr %l690
  br label %bb417
bb417:
  %t1405 = load ptr, ptr %l686, !tbaa !29
  %t1406 = load %"compiler/source:Span", ptr %l690
  %t1407 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t1405, %"compiler/source:Span" %t1406)
  store %"compiler/source:Span" %t1407, ptr %l691
  br label %bb418
bb418:
  %t1408 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %s43)
  store %"compiler/diagmsg:Msg" %t1408, ptr %l692
  br label %bb419
bb419:
  %t1409 = load ptr, ptr %l685, !tbaa !29
  %t1410 = load %"compiler/source:Span", ptr %l691
  %t1411 = load %"compiler/diagmsg:Msg", ptr %l692
  %t1412 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s43, ptr %t1409, %"compiler/source:Span" %t1410, %"compiler/diagmsg:Msg" %t1411)
  store i64 %t1412, ptr %l693
  br label %bb420
bb420:
  call void @__olang_scope_close(ptr %s43)
  br label %bb421
bb421:
  br label %bb422
bb422:
  br label %bb428
bb423:
  br i1 true, label %bb424, label %bb425
bb424:
  br label %bb426
bb425:
  br label %bb427
bb426:
  br label %bb428
bb427:
  call void @__olang_check_failed(ptr @olang_loc_5c49853202d9fa8c_ad203b077ad42ef8)
  unreachable
bb428:
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb429:
  %t1413 = load ptr, ptr %l0, !tbaa !29
  %t1415 = getelementptr %"compiler/scope:Scoper", ptr %t1413, i32 0, i32 31
  %t1416 = load i32, ptr %l2, !tbaa !23
  %t1418 = sext i32 %t1416 to i64
  %t1419 = load { i64, [2 x i64] }, ptr %l16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1415, i64 %t1418, { i64, [2 x i64] } %t1419)
  br label %bb430
bb430:
  %t1423 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t1424 = load { i64, [1 x i64] }, ptr %t1423
  %t1426 = extractvalue { i64, [1 x i64] } %t1424, 0
  %t1427 = icmp eq i64 %t1426, 1
  br i1 %t1427, label %bb431, label %bb432
bb431:
  %t1429 = load ptr, ptr %l0, !tbaa !29
  %t1430 = load i32, ptr %l5, !tbaa !23
  %t1433 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t1429, i32 %t1430)
  store i1 %t1433, ptr %l704
  br label %bb433
bb432:
  store i1 false, ptr %l701, !tbaa !21
  br label %bb434
bb433:
  %t1434 = load i1, ptr %l704, !tbaa !21
  store i1 %t1434, ptr %l701, !tbaa !21
  br label %bb434
bb434:
  %t1435 = load i1, ptr %l701, !tbaa !21
  br i1 %t1435, label %bb435, label %bb436
bb435:
  %t1436 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1436, ptr %l706, !tbaa !29
  %t1437 = load ptr, ptr %l3, !tbaa !29
  %t1439 = icmp eq ptr %t1437, null
  br i1 %t1439, label %bb437, label %bb438
bb436:
  store i1 false, ptr %l705, !tbaa !21
  br label %bb441
bb437:
  call void @__olang_check_failed(ptr @olang_loc_e598343033241940_f023ba5342a3ff7c)
  unreachable
bb438:
  br label %bb439
bb439:
  %t1441 = load ptr, ptr %l3, !tbaa !29
  %t1442 = load ptr, ptr %l706, !tbaa !29
  %t1444 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfRefs(ptr %v0, ptr %v1, ptr %t1442, ptr %t1441)
  store i1 %t1444, ptr %l710
  br label %bb440
bb440:
  %t1445 = load i1, ptr %l710, !tbaa !21
  store i1 %t1445, ptr %l705, !tbaa !21
  br label %bb441
bb441:
  %t1446 = load i1, ptr %l705, !tbaa !21
  %t1447 = load ptr, ptr %l0, !tbaa !29
  %t1451 = getelementptr %"compiler/scope:Scoper", ptr %t1447, i32 0, i32 135
  store i1 %t1446, ptr %t1451, !tbaa !21
  %t1452 = load ptr, ptr %l0, !tbaa !29
  %t1453 = load ptr, ptr %l3, !tbaa !29
  %t1454 = load { i64, [2 x i64] }, ptr %l16
  %t1458 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1452, ptr %t1453, { i64, [2 x i64] } %t1454)
  store %"compiler/scope:Val" %t1458, ptr %l716
  br label %bb442
bb442:
  %t1459 = load %"compiler/scope:Val", ptr %l716
  store %"compiler/scope:Val" %t1459, ptr %l34
  %t1460 = load ptr, ptr %l0, !tbaa !29
  %t1462 = getelementptr %"compiler/scope:Scoper", ptr %t1460, i32 0, i32 135
  store i1 false, ptr %t1462, !tbaa !21
  %t1463 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1463, ptr %l718, !tbaa !29
  %t1464 = load i32, ptr %l2, !tbaa !23
  store i32 %t1464, ptr %l719, !tbaa !23
  %t1465 = load ptr, ptr %l3, !tbaa !29
  %t1467 = icmp eq ptr %t1465, null
  br i1 %t1467, label %bb443, label %bb444
bb443:
  call void @__olang_check_failed(ptr @olang_loc_d5b499138e5334df_68c2e51948532eeb)
  unreachable
bb444:
  br label %bb445
bb445:
  %t1469 = load ptr, ptr %l3, !tbaa !29
  %t1470 = load ptr, ptr %l718, !tbaa !29
  %t1471 = load i32, ptr %l719, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %t1470, i32 %t1471, ptr %t1469)
  br label %bb446
bb446:
  %t1473 = getelementptr %"compiler/scope:Val", ptr %l34, i32 0, i32 1
  %t1474 = load { i64, [2 x i64] }, ptr %t1473
  %t1478 = extractvalue { i64, [2 x i64] } %t1474, 0
  %t1479 = icmp eq i64 %t1478, 5
  br i1 %t1479, label %bb447, label %bb448
bb447:
  br label %bb449
bb448:
  br label %bb476
bb449:
  %t1481 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t1482 = load i32, ptr %t1481, !range !{i32 0, i32 7}
  %t1484 = trunc i64 6 to i32
  %t1485 = icmp eq i32 %t1482, %t1484
  br i1 %t1485, label %bb450, label %bb451
bb450:
  %t1487 = load ptr, ptr %l0, !tbaa !29
  %t1488 = load i32, ptr %l5, !tbaa !23
  %t1491 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t1487, i32 %t1488)
  store i1 %t1491, ptr %l730
  br label %bb452
bb451:
  br label %bb460
bb452:
  %t1492 = load i1, ptr %l730, !tbaa !21
  store i1 %t1492, ptr %l36, !tbaa !21
  %t1493 = load ptr, ptr %l0, !tbaa !29
  %t1494 = load i64, ptr @G_2ecompiler_2fscope_2eWhyHolds, !tbaa !24
  %t1497 = getelementptr %"compiler/scope:Scoper", ptr %t1493, i32 0, i32 116
  store i64 %t1494, ptr %t1497, !tbaa !24
  %t1498 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1498, ptr %l733, !tbaa !29
  %t1499 = getelementptr %"compiler/scope:Val", ptr %l34, i32 0, i32 1
  %t1500 = load { i64, [2 x i64] }, ptr %t1499
  store { i64, [2 x i64] } %t1500, ptr %l734
  %t1501 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t1501, ptr %l735
  %t1502 = load i1, ptr %l36, !tbaa !21
  store i1 %t1502, ptr %l736, !tbaa !21
  %t1503 = load ptr, ptr %l3, !tbaa !29
  %t1505 = icmp eq ptr %t1503, null
  br i1 %t1505, label %bb453, label %bb454
bb453:
  call void @__olang_check_failed(ptr @olang_loc_efeba8037e802192_fbb9be0cbeac966)
  unreachable
bb454:
  br label %bb455
bb455:
  %t1507 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1507, ptr %l739, !tbaa !29
  %t1508 = load i1, ptr %l36, !tbaa !21
  br i1 %t1508, label %bb456, label %bb457
bb456:
  %t1510 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  store i64 %t1510, ptr %l741, !tbaa !24
  br label %bb458
bb457:
  %t1512 = load i64, ptr @G_2ecompiler_2fscope_2eFitDecl, !tbaa !24
  store i64 %t1512, ptr %l741, !tbaa !24
  br label %bb458
bb458:
  %t1514 = load ptr, ptr %l733, !tbaa !29
  %t1515 = load { i64, [2 x i64] }, ptr %l734
  %t1516 = load { i64, [2 x i64] }, ptr %l735
  %t1517 = load i1, ptr %l736, !tbaa !21
  %t1518 = load ptr, ptr %l739, !tbaa !29
  %t1519 = load i64, ptr %l741, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t1514, { i64, [2 x i64] } %t1515, { i64, [2 x i64] } %t1516, i1 %t1517, ptr %t1518, i64 %t1519)
  br label %bb459
bb459:
  %t1520 = load ptr, ptr %l0, !tbaa !29
  %t1522 = getelementptr %"compiler/scope:Scoper", ptr %t1520, i32 0, i32 116
  store i64 0, ptr %t1522, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb460:
  %t1523 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 5
  %t1524 = load { i64, [1 x i64] }, ptr %t1523
  %t1526 = extractvalue { i64, [1 x i64] } %t1524, 0
  %t1527 = icmp eq i64 %t1526, 1
  br i1 %t1527, label %bb461, label %bb462
bb461:
  %t1529 = load ptr, ptr %l0, !tbaa !29
  %t1530 = load i32, ptr %l5, !tbaa !23
  %t1533 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t1529, i32 %t1530)
  store i1 %t1533, ptr %l750
  br label %bb463
bb462:
  store i1 false, ptr %l747, !tbaa !21
  br label %bb464
bb463:
  %t1534 = load i1, ptr %l750, !tbaa !21
  store i1 %t1534, ptr %l747, !tbaa !21
  br label %bb464
bb464:
  %t1535 = load i1, ptr %l747, !tbaa !21
  br i1 %t1535, label %bb465, label %bb466
bb465:
  %t1536 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1536, ptr %l752, !tbaa !29
  %t1537 = load ptr, ptr %l3, !tbaa !29
  %t1539 = icmp eq ptr %t1537, null
  br i1 %t1539, label %bb467, label %bb468
bb466:
  store i1 false, ptr %l751, !tbaa !21
  br label %bb471
bb467:
  call void @__olang_check_failed(ptr @olang_loc_4ce35395f0f925b9_cbae4bbebb7ea34d)
  unreachable
bb468:
  br label %bb469
bb469:
  %t1541 = load ptr, ptr %l3, !tbaa !29
  %t1542 = load ptr, ptr %l752, !tbaa !29
  %t1544 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfRefs(ptr %v0, ptr %v1, ptr %t1542, ptr %t1541)
  store i1 %t1544, ptr %l756
  br label %bb470
bb470:
  %t1545 = load i1, ptr %l756, !tbaa !21
  store i1 %t1545, ptr %l751, !tbaa !21
  br label %bb471
bb471:
  %t1546 = load i1, ptr %l751, !tbaa !21
  br i1 %t1546, label %bb472, label %bb473
bb472:
  %t1547 = load ptr, ptr %l0, !tbaa !29
  %t1549 = getelementptr %"compiler/scope:Scoper", ptr %t1547, i32 0, i32 31
  %t1550 = load i32, ptr %l2, !tbaa !23
  %t1552 = sext i32 %t1550 to i64
  %t1553 = getelementptr %"compiler/scope:Val", ptr %l34, i32 0, i32 1
  %t1554 = load { i64, [2 x i64] }, ptr %t1553
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t1549, i64 %t1552, { i64, [2 x i64] } %t1554)
  br label %bb474
bb473:
  br label %bb475
bb474:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb475:
  br label %bb481
bb476:
  br i1 true, label %bb477, label %bb478
bb477:
  br label %bb479
bb478:
  br label %bb480
bb479:
  br label %bb481
bb480:
  call void @__olang_check_failed(ptr @olang_loc_ef194281b7e9372b_4f5022b99d00b52f)
  unreachable
bb481:
  %t1558 = getelementptr %"compiler/scope:Val", ptr %l34, i32 0, i32 0
  %t1559 = load i32, ptr %t1558, !range !{i32 0, i32 5}
  %t1561 = trunc i64 2 to i32
  %t1562 = icmp eq i32 %t1559, %t1561
  br i1 %t1562, label %bb482, label %bb483
bb482:
  %t1564 = load ptr, ptr %l0, !tbaa !29
  %t1566 = getelementptr %"compiler/scope:Scoper", ptr %t1564, i32 0, i32 27
  %t1567 = load i1, ptr %t1566, !tbaa !21
  store i1 %t1567, ptr %l764, !tbaa !21
  br label %bb484
bb483:
  store i1 false, ptr %l764, !tbaa !21
  br label %bb484
bb484:
  %t1569 = load i1, ptr %l764, !tbaa !21
  br i1 %t1569, label %bb485, label %bb486
bb485:
  %t1570 = load ptr, ptr %l0, !tbaa !29
  %t1571 = load { i64, [2 x i64] }, ptr %l16
  %t1574 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunknownBinding(ptr %v0, ptr %t1570, { i64, [2 x i64] } %t1571)
  store i1 %t1574, ptr %l770
  br label %bb487
bb486:
  store i1 false, ptr %l767, !tbaa !21
  br label %bb488
bb487:
  %t1575 = load i1, ptr %l770, !tbaa !21
  store i1 %t1575, ptr %l767, !tbaa !21
  br label %bb488
bb488:
  %t1576 = load i1, ptr %l767, !tbaa !21
  br i1 %t1576, label %bb489, label %bb490
bb489:
  store %olang.scope zeroinitializer, ptr %s49
  %t1577 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1577, ptr %l771, !tbaa !29
  %t1578 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1578, ptr %l772, !tbaa !29
  %t1579 = load ptr, ptr %l3, !tbaa !29
  %t1581 = icmp eq ptr %t1579, null
  br i1 %t1581, label %bb491, label %bb492
bb490:
  br label %bb497
bb491:
  call void @__olang_check_failed(ptr @olang_loc_b7b2bcd4863652d3_99a604389ddb6357)
  unreachable
bb492:
  br label %bb493
bb493:
  %t1583 = load ptr, ptr %l3, !tbaa !29
  %t1584 = load ptr, ptr %l772, !tbaa !29
  %t1586 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t1584, ptr %t1583)
  store %"compiler/source:Span" %t1586, ptr %l776
  br label %bb494
bb494:
  %t1587 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %s49)
  store %"compiler/diagmsg:Msg" %t1587, ptr %l777
  br label %bb495
bb495:
  %t1588 = load ptr, ptr %l771, !tbaa !29
  %t1589 = load %"compiler/source:Span", ptr %l776
  %t1590 = load %"compiler/diagmsg:Msg", ptr %l777
  %t1591 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s49, ptr %t1588, %"compiler/source:Span" %t1589, %"compiler/diagmsg:Msg" %t1590)
  store i64 %t1591, ptr %l778
  br label %bb496
bb496:
  call void @__olang_scope_close(ptr %s49)
  br label %bb497
bb497:
  %t1592 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t1593 = load i32, ptr %t1592, !range !{i32 0, i32 7}
  %t1595 = trunc i64 6 to i32
  %t1596 = icmp eq i32 %t1593, %t1595
  br i1 %t1596, label %bb498, label %bb499
bb498:
  %t1598 = getelementptr %"compiler/scope:Val", ptr %l34, i32 0, i32 0
  %t1599 = load i32, ptr %t1598, !range !{i32 0, i32 5}
  %t1601 = trunc i64 2 to i32
  %t1602 = icmp eq i32 %t1599, %t1601
  store i1 %t1602, ptr %l781, !tbaa !21
  br label %bb500
bb499:
  store i1 false, ptr %l781, !tbaa !21
  br label %bb500
bb500:
  %t1604 = load i1, ptr %l781, !tbaa !21
  br i1 %t1604, label %bb501, label %bb502
bb501:
  %t1605 = getelementptr %"compiler/scope:Val", ptr %l34, i32 0, i32 1
  %t1606 = load { i64, [2 x i64] }, ptr %t1605
  store { i64, [2 x i64] } %t1606, ptr %l785
  %t1607 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t1607, ptr %l787
  %t1610 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l785, ptr %l787)
  store i1 %t1610, ptr %l789
  br label %bb503
bb502:
  store i1 false, ptr %l784, !tbaa !21
  br label %bb504
bb503:
  %t1611 = load i1, ptr %l789, !tbaa !21
  %t1612 = xor i1 %t1611, true
  store i1 %t1612, ptr %l784, !tbaa !21
  br label %bb504
bb504:
  %t1614 = load i1, ptr %l784, !tbaa !21
  br i1 %t1614, label %bb505, label %bb506
bb505:
  %t1615 = getelementptr %"compiler/scope:Val", ptr %l34, i32 0, i32 1
  %t1616 = load { i64, [2 x i64] }, ptr %t1615
  %t1618 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRelatable({ i64, [2 x i64] } %t1616)
  store i1 %t1618, ptr %l793
  br label %bb507
bb506:
  store i1 false, ptr %l791, !tbaa !21
  br label %bb508
bb507:
  %t1619 = load i1, ptr %l793, !tbaa !21
  store i1 %t1619, ptr %l791, !tbaa !21
  br label %bb508
bb508:
  %t1620 = load i1, ptr %l791, !tbaa !21
  br i1 %t1620, label %bb509, label %bb510
bb509:
  %t1621 = load ptr, ptr %l0, !tbaa !29
  %t1622 = load i64, ptr @G_2ecompiler_2fscope_2eWhyField, !tbaa !24
  %t1625 = getelementptr %"compiler/scope:Scoper", ptr %t1621, i32 0, i32 116
  store i64 %t1622, ptr %t1625, !tbaa !24
  %t1626 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1626, ptr %l796, !tbaa !29
  %t1627 = getelementptr %"compiler/scope:Val", ptr %l34, i32 0, i32 1
  %t1628 = load { i64, [2 x i64] }, ptr %t1627
  store { i64, [2 x i64] } %t1628, ptr %l797
  %t1629 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t1629, ptr %l798
  %t1630 = load ptr, ptr %l3, !tbaa !29
  %t1632 = icmp eq ptr %t1630, null
  br i1 %t1632, label %bb511, label %bb512
bb510:
  br label %bb515
bb511:
  call void @__olang_check_failed(ptr @olang_loc_867a81ac657fc1e6_792cc237e4eb2912)
  unreachable
bb512:
  br label %bb513
bb513:
  %t1634 = load ptr, ptr %l3, !tbaa !29
  %t1635 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  %t1636 = load ptr, ptr %l796, !tbaa !29
  %t1637 = load { i64, [2 x i64] }, ptr %l797
  %t1638 = load { i64, [2 x i64] }, ptr %l798
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t1636, { i64, [2 x i64] } %t1637, { i64, [2 x i64] } %t1638, i1 false, ptr %t1634, i64 %t1635)
  br label %bb514
bb514:
  %t1641 = load ptr, ptr %l0, !tbaa !29
  %t1643 = getelementptr %"compiler/scope:Scoper", ptr %t1641, i32 0, i32 116
  store i64 0, ptr %t1643, !tbaa !24
  br label %bb515
bb515:
  %t1644 = getelementptr %"compiler/scope:Val", ptr %l34, i32 0, i32 0
  %t1645 = load i32, ptr %t1644, !range !{i32 0, i32 5}
  %t1647 = trunc i64 3 to i32
  %t1648 = icmp eq i32 %t1645, %t1647
  br i1 %t1648, label %bb516, label %bb517
bb516:
  %t1650 = load ptr, ptr %l0, !tbaa !29
  %t1651 = load i32, ptr %l5, !tbaa !23
  %t1654 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enarrowingMatters(ptr %v0, ptr %t1650, i32 %t1651)
  store i1 %t1654, ptr %l808
  br label %bb518
bb517:
  br label %bb530
bb518:
  %t1655 = load i1, ptr %l808, !tbaa !21
  store i1 %t1655, ptr %l37, !tbaa !21
  %t1656 = load i64, ptr @G_2ecompiler_2fscope_2eFitLocal, !tbaa !24
  store i64 %t1656, ptr %l38, !tbaa !24
  %t1658 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 4
  %t1659 = load i32, ptr %t1658, !range !{i32 0, i32 7}
  %t1661 = trunc i64 6 to i32
  %t1662 = icmp eq i32 %t1659, %t1661
  br i1 %t1662, label %bb519, label %bb520
bb519:
  %t1664 = load ptr, ptr %l0, !tbaa !29
  %t1665 = load i32, ptr %l5, !tbaa !23
  %t1668 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t1664, i32 %t1665)
  store i1 %t1668, ptr %l814
  br label %bb521
bb520:
  br label %bb525
bb521:
  %t1669 = load i1, ptr %l814, !tbaa !21
  store i1 %t1669, ptr %l37, !tbaa !21
  %t1670 = load i1, ptr %l37, !tbaa !21
  br i1 %t1670, label %bb522, label %bb523
bb522:
  %t1672 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  store i64 %t1672, ptr %l816, !tbaa !24
  br label %bb524
bb523:
  %t1674 = load i64, ptr @G_2ecompiler_2fscope_2eFitDecl, !tbaa !24
  store i64 %t1674, ptr %l816, !tbaa !24
  br label %bb524
bb524:
  %t1676 = load i64, ptr %l816, !tbaa !24
  store i64 %t1676, ptr %l38, !tbaa !24
  %t1677 = load ptr, ptr %l0, !tbaa !29
  %t1678 = load i64, ptr @G_2ecompiler_2fscope_2eWhyHolds, !tbaa !24
  %t1681 = getelementptr %"compiler/scope:Scoper", ptr %t1677, i32 0, i32 116
  store i64 %t1678, ptr %t1681, !tbaa !24
  br label %bb525
bb525:
  %t1682 = load ptr, ptr %l0, !tbaa !29
  %t1683 = load i32, ptr %l2, !tbaa !23
  %t1685 = sext i32 %t1683 to i64
  %t1688 = getelementptr %"compiler/scope:Scoper", ptr %t1682, i32 0, i32 186
  store i64 %t1685, ptr %t1688, !tbaa !24
  %t1689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1689, ptr %l824, !tbaa !29
  %t1690 = getelementptr %"compiler/scope:Val", ptr %l34, i32 0, i32 1
  %t1691 = load { i64, [2 x i64] }, ptr %t1690
  store { i64, [2 x i64] } %t1691, ptr %l825
  %t1692 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t1692, ptr %l826
  %t1693 = load i1, ptr %l37, !tbaa !21
  store i1 %t1693, ptr %l827, !tbaa !21
  %t1694 = load ptr, ptr %l3, !tbaa !29
  %t1696 = icmp eq ptr %t1694, null
  br i1 %t1696, label %bb526, label %bb527
bb526:
  call void @__olang_check_failed(ptr @olang_loc_426d318a55139bcd_d6246dca57642d39)
  unreachable
bb527:
  br label %bb528
bb528:
  %t1698 = load ptr, ptr %l3, !tbaa !29
  %t1699 = load i64, ptr %l38, !tbaa !24
  %t1700 = load ptr, ptr %l824, !tbaa !29
  %t1701 = load { i64, [2 x i64] }, ptr %l825
  %t1702 = load { i64, [2 x i64] }, ptr %l826
  %t1703 = load i1, ptr %l827, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t1700, { i64, [2 x i64] } %t1701, { i64, [2 x i64] } %t1702, i1 %t1703, ptr %t1698, i64 %t1699)
  br label %bb529
bb529:
  %t1706 = load ptr, ptr %l0, !tbaa !29
  %t1708 = getelementptr %"compiler/scope:Scoper", ptr %t1706, i32 0, i32 186
  store i64 -1, ptr %t1708, !tbaa !24
  %t1709 = load ptr, ptr %l0, !tbaa !29
  %t1711 = getelementptr %"compiler/scope:Scoper", ptr %t1709, i32 0, i32 116
  store i64 0, ptr %t1711, !tbaa !24
  br label %bb530
bb530:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eletRegion(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i1
  %l31 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %t2)
  store ptr %t6, ptr %l9
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = call i64 @compiler_2fscope_2eregionLocal(ptr %s0, ptr %t7)
  store i64 %t8, ptr %l10
  br label %bb2
bb2:
  %t9 = load i64, ptr %l10, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t17 = sext i32 %a1 to i64
  %t20 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereassigned(ptr %v0, ptr %t14, i64 %t17)
  store i1 %t20, ptr %l17
  br label %bb5
bb5:
  %t21 = load i1, ptr %l17, !tbaa !21
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t23, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t30 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t25, ptr %t26)
  store ptr %t30, ptr %l22
  br label %bb10
bb10:
  %t31 = load ptr, ptr %l22, !tbaa !29
  store ptr %t31, ptr %l4, !tbaa !29
  %t32 = load ptr, ptr %l4, !tbaa !29
  store ptr %t32, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t33 = load ptr, ptr %l24, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l24, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 18}
  %t39 = icmp eq i64 %t37, 3
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = call i64 @compiler_2fscope_2eregionRoot(ptr %s0, ptr %t47)
  store i64 %t49, ptr %l31
  br label %bb16
bb16:
  %t50 = load i64, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l23, !tbaa !24
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t51 = load i64, ptr %l3, !tbaa !24
  store i64 %t51, ptr %l23, !tbaa !24
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5522d97a67b9c6cd_b4761099589b85d1)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load i64, ptr %l23, !tbaa !24
  store i64 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emayHoldDtor(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"compiler/types:DtorWalk"
  %l6 = alloca %"compiler/types:DtorWalk"
  %l9 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t8 = call %"compiler/types:DtorWalk" @compiler_2ftypes_3aDtorWalk_2ector(ptr %v0, ptr %s0, ptr %t6)
  store %"compiler/types:DtorWalk" %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load %"compiler/types:DtorWalk", ptr %l6
  store %"compiler/types:DtorWalk" %t9, ptr %l2
  %t13 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %s0, ptr %l2, i32 %a1)
  store i1 %t13, ptr %l9
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enarrowingMatters(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t8, i32 %t9)
  store i1 %t12, ptr %l8
  br label %bb5
bb5:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l1, !tbaa !23
  %t18 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l12
  br label %bb8
bb8:
  %t19 = load i1, ptr %l12, !tbaa !21
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t20 = load i1, ptr %l9, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteLoopCopy(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l12 = alloca i64
  %l18 = alloca ptr
  %l27 = alloca %"compiler/typed:Local"
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l39 = alloca %"compiler/typed:Local"
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i64
  %l62 = alloca i64
  %l63 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/diagmsg:Msg"
  %l68 = alloca ptr
  %l77 = alloca %"compiler/typed:Local"
  %l79 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i64
  %l88 = alloca i64
  %l89 = alloca %"compiler/source:Span"
  %l91 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a2)
  store ptr %t6, ptr %l10
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t9 = call i64 @compiler_2fscope_2eflRootExpr(ptr %s0, ptr %t7)
  store i64 %t9, ptr %l12
  br label %bb2
bb2:
  %t10 = load i64, ptr %l12, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 3
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l18, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 25
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_963cba883dc4bd20_64c99da4a40e3f44)
  unreachable
bb7:
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/scope:Scoper", ptr %t32, i32 0, i32 25
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 7
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t38, i64 %t39)
  store %"compiler/typed:Local" %t42, ptr %l27
  br label %bb9
bb9:
  %t43 = getelementptr %"compiler/typed:Local", ptr %l27, i32 0, i32 0
  %t44 = load i32, ptr %t43, !tbaa !23
  %t45 = load ptr, ptr %l18, !tbaa !29
  %t47 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t45, i32 %t44)
  store { i64, ptr } %t47, ptr %l29
  br label %bb10
bb10:
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t48, ptr %l4, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/scope:Scoper", ptr %t50, i32 0, i32 25
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_91fdca4bfcfaef3f_360ec22200b0b313)
  unreachable
bb12:
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/scope:Scoper", ptr %t57, i32 0, i32 25
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 7
  %t64 = load i64, ptr %l3, !tbaa !24
  %t67 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t63, i64 %t64)
  store %"compiler/typed:Local" %t67, ptr %l39
  br label %bb14
bb14:
  %t68 = getelementptr %"compiler/typed:Local", ptr %l39, i32 0, i32 1
  %t69 = load %"compiler/source:Span", ptr %t68
  %t70 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t71 = load ptr, ptr %l30, !tbaa !29
  %t74 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v0, ptr %t71, %"compiler/source:Span" %t69, { i64, ptr } %t70)
  store %"compiler/source:Span" %t74, ptr %l42
  br label %bb15
bb15:
  %t75 = load %"compiler/source:Span", ptr %l42
  store %"compiler/source:Span" %t75, ptr %l5
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l43, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/scope:Scoper", ptr %t77, i32 0, i32 42
  %t80 = load i64, ptr %l3, !tbaa !24
  %t83 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  %t84 = extractvalue { i32, ptr } %t83, 1
  %t85 = extractvalue { i32, ptr } %t83, 0
  store i32 %t85, ptr %l49
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb17, label %ok.87, !prof !99
ok.87:
  store ptr %t84, ptr %l48
  br label %bb16
bb16:
  %t88 = load ptr, ptr %l48, !tbaa !29
  store ptr %t88, ptr %l44, !tbaa !29
  br label %bb19
bb17:
  br label %bb18
bb18:
  store ptr null, ptr %l44, !tbaa !29
  br label %bb19
bb19:
  %t89 = load ptr, ptr %l43, !tbaa !29
  %t90 = load ptr, ptr %l44, !tbaa !29
  %t91 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopArray(ptr %v0, ptr %v0, ptr %s0, ptr %t89, ptr %t90)
  store { i64, ptr } %t91, ptr %l50
  br label %bb20
bb20:
  %t92 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t92, ptr %l6, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t93, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t95, ptr %l52
  br label %bb21
bb21:
  %t96 = load i1, ptr %l52, !tbaa !21
  %t97 = xor i1 %t96, true
  br i1 %t97, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s2
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l54, !tbaa !29
  %t100 = load i64, ptr %l1, !tbaa !24
  store i64 %t100, ptr %l55, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/scope:Scoper", ptr %t101, i32 0, i32 25
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb24, label %bb25
bb23:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l68, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/scope:Scoper", ptr %t109, i32 0, i32 25
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = icmp eq ptr %t112, null
  br i1 %t114, label %bb29, label %bb30
bb24:
  call void @__olang_check_failed(ptr @olang_loc_540f6a9ea70b2c8e_44714d47ed7a19d2)
  unreachable
bb25:
  br label %bb26
bb26:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/scope:Scoper", ptr %t116, i32 0, i32 25
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Body", ptr %t119, i32 0, i32 3
  %t123 = load i64, ptr %t122, !tbaa !24
  store i64 %t123, ptr %l62, !tbaa !24
  %t124 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t124, ptr %l63
  %t125 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t131 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLoopCopy(ptr %v0, ptr %s0, ptr %s0, ptr %s2, { i64, ptr } %t125, { i64, ptr } %t126, { i64, ptr } %t127)
  store %"compiler/diagmsg:Msg" %t131, ptr %l67
  br label %bb27
bb27:
  %t132 = load ptr, ptr %l54, !tbaa !29
  %t133 = load i64, ptr %l55, !tbaa !24
  %t134 = load i64, ptr %l62, !tbaa !24
  %t135 = load %"compiler/source:Span", ptr %l63
  %t136 = load %"compiler/diagmsg:Msg", ptr %l67
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s2, ptr %t132, i64 %t133, i64 %t134, %"compiler/source:Span" %t135, %"compiler/diagmsg:Msg" %t136)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb29:
  call void @__olang_check_failed(ptr @olang_loc_64a11eda2e926835_fc7221612b7da3f9)
  unreachable
bb30:
  br label %bb31
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/scope:Scoper", ptr %t137, i32 0, i32 25
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Body", ptr %t140, i32 0, i32 7
  %t144 = load i64, ptr %l3, !tbaa !24
  %t147 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t143, i64 %t144)
  store %"compiler/typed:Local" %t147, ptr %l77
  br label %bb32
bb32:
  %t148 = getelementptr %"compiler/typed:Local", ptr %l77, i32 0, i32 2
  %t149 = load i32, ptr %t148, !tbaa !23
  %t150 = load ptr, ptr %l68, !tbaa !29
  %t152 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t150, i32 %t149)
  store i1 %t152, ptr %l79
  br label %bb33
bb33:
  %t153 = load i1, ptr %l79, !tbaa !21
  br i1 %t153, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s4
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l80, !tbaa !29
  %t155 = load i64, ptr %l1, !tbaa !24
  store i64 %t155, ptr %l81, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/scope:Scoper", ptr %t156, i32 0, i32 25
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = icmp eq ptr %t159, null
  br i1 %t161, label %bb36, label %bb37
bb35:
  br label %bb41
bb36:
  call void @__olang_check_failed(ptr @olang_loc_9739f96f1cdf87e4_96538064e6892180)
  unreachable
bb37:
  br label %bb38
bb38:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/scope:Scoper", ptr %t163, i32 0, i32 25
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t169 = getelementptr %"compiler/typed:Body", ptr %t166, i32 0, i32 3
  %t170 = load i64, ptr %t169, !tbaa !24
  store i64 %t170, ptr %l88, !tbaa !24
  %t171 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t171, ptr %l89
  %t172 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t174 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLoopCopyLent(ptr %v0, ptr %s4, { i64, ptr } %t172)
  store %"compiler/diagmsg:Msg" %t174, ptr %l91
  br label %bb39
bb39:
  %t175 = load ptr, ptr %l80, !tbaa !29
  %t176 = load i64, ptr %l81, !tbaa !24
  %t177 = load i64, ptr %l88, !tbaa !24
  %t178 = load %"compiler/source:Span", ptr %l89
  %t179 = load %"compiler/diagmsg:Msg", ptr %l91
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s4, ptr %t175, i64 %t176, i64 %t177, %"compiler/source:Span" %t178, %"compiler/diagmsg:Msg" %t179)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonFrameAt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l12 = alloca { i64, ptr }
  %t28 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 30
  %t11 = getelementptr %"compiler/typed:Plan", ptr %t10, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t17 = icmp slt i64 %t7, %t14
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 30
  %t23 = getelementptr %"compiler/typed:Plan", ptr %t22, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l12, !tbaa !27
  %t25 = load i32, ptr %l1, !tbaa !23
  %t27 = sext i32 %t25 to i64
  store { i64, [1 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 0
  store i64 5, ptr %t29
  %t30 = load { i64, [1 x i64] }, ptr %t28
  %t33 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i64 %t27
  store { i64, [1 x i64] } %t30, ptr %t35
  br label %bb6
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca ptr
  %l5 = alloca %"compiler/scope:Val"
  %l19 = alloca { i64, ptr }
  %l25 = alloca %"compiler/scope:Val"
  %l28 = alloca i1
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca { i64, [2 x i64] }
  %l36 = alloca { i64, [2 x i64] }
  %l39 = alloca i1
  %l43 = alloca %"compiler/scope:Val"
  %rv = alloca %"compiler/scope:Val"
  %t40 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Make", ptr %t1, i32 0, i32 4
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp sge i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Make", ptr %t9, i32 0, i32 4
  %t12 = load i32, ptr %t11, !tbaa !23
  %t13 = load { i64, [2 x i64] }, ptr %l3
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuild(ptr %v0, ptr %t8, i32 %t12, { i64, [2 x i64] } %t13)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 138
  %t20 = load i1, ptr %t19, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t24 = load { i64, [2 x i64] }, ptr %l3
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftCopied(ptr %v0, ptr %v1, ptr %t22, ptr %t23, { i64, [2 x i64] } %t24)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Make", ptr %t28, i32 0, i32 2
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l19, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr ptr, ptr %t33, i64 0
  %t35 = load ptr, ptr %t34, !tbaa !39
  store ptr %t35, ptr %l4, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l4, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t40
  %t46 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t37, ptr %t38, { i64, [2 x i64] } %t42)
  store %"compiler/scope:Val" %t46, ptr %l25
  br label %bb9
bb9:
  %t47 = load %"compiler/scope:Val", ptr %l25
  store %"compiler/scope:Val" %t47, ptr %l5
  %t48 = getelementptr %"compiler/scope:Val", ptr %l5, i32 0, i32 0
  %t49 = load i32, ptr %t48, !range !{i32 0, i32 5}
  %t51 = trunc i64 3 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l2, !tbaa !23
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSharesRefs(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t63, ptr %l33
  br label %bb12
bb11:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb13
bb12:
  %t64 = load i1, ptr %l33, !tbaa !21
  store i1 %t64, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t65 = load i1, ptr %l28, !tbaa !21
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l34, !tbaa !29
  %t67 = getelementptr %"compiler/scope:Val", ptr %l5, i32 0, i32 1
  %t68 = load { i64, [2 x i64] }, ptr %t67
  store { i64, [2 x i64] } %t68, ptr %l35
  %t69 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t69, ptr %l36
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l2, !tbaa !23
  %t74 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t70, i32 %t71)
  store i1 %t74, ptr %l39
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t76 = load i64, ptr @G_2ecompiler_2fscope_2eFitValue, !tbaa !24
  %t77 = load ptr, ptr %l34, !tbaa !29
  %t78 = load { i64, [2 x i64] }, ptr %l35
  %t79 = load { i64, [2 x i64] }, ptr %l36
  %t80 = load i1, ptr %l39, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t77, { i64, [2 x i64] } %t78, { i64, [2 x i64] } %t79, i1 %t80, ptr %t75, i64 %t76)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t83 = load { i64, [2 x i64] }, ptr %l3
  %t85 = call %"compiler/scope:Val" @compiler_2fscope_2eVal_2efresh({ i64, [2 x i64] } %t83)
  store %"compiler/scope:Val" %t85, ptr %l43
  br label %bb19
bb19:
  %t86 = load %"compiler/scope:Val", ptr %l43
  store %"compiler/scope:Val" %t86, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i64
  %l38 = alloca i1
  %l47 = alloca %"compiler/typed:Local"
  %l50 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i1
  %l66 = alloca %"compiler/typed:Local"
  %l69 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l10
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l10, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t9 = load ptr, ptr %l11, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 6
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l12, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb11
bb6:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Call", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Call", ptr %t33, i32 0, i32 1
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l23, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 0
  %t40 = load ptr, ptr %t39, !tbaa !39
  %t43 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamRoot(ptr %v0, ptr %v1, ptr %t32, ptr %t40)
  store i64 %t43, ptr %l25
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t44 = load i64, ptr %l25, !tbaa !24
  store i64 %t44, ptr %rv
  br label %ret
bb10:
  store i64 -1, ptr %rv
  br label %ret
bb11:
  %t46 = load ptr, ptr %l2, !tbaa !29
  store ptr %t46, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t50 = load ptr, ptr %l27, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 10
  store i1 %t53, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t54 = load i1, ptr %l28, !tbaa !21
  br i1 %t54, label %bb14, label %bb15
bb14:
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb28
bb16:
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Slice", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = call i64 @compiler_2fscope_2eflRoot(ptr %v1, ptr %t64)
  store i64 %t66, ptr %l35
  br label %bb17
bb17:
  %t67 = load i64, ptr %l35, !tbaa !24
  store i64 %t67, ptr %l5, !tbaa !24
  %t68 = load i64, ptr %l5, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/scope:Scoper", ptr %t72, i32 0, i32 25
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  br i1 %t77, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb24
bb20:
  call void @__olang_check_failed(ptr @olang_loc_702142de3e583242_5b34302bf43ef4be)
  unreachable
bb21:
  br label %bb22
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/scope:Scoper", ptr %t79, i32 0, i32 25
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Body", ptr %t82, i32 0, i32 7
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t85, i64 %t86)
  store %"compiler/typed:Local" %t89, ptr %l47
  br label %bb23
bb23:
  %t90 = getelementptr %"compiler/typed:Local", ptr %l47, i32 0, i32 4
  %t91 = load i32, ptr %t90, !range !{i32 0, i32 7}
  %t93 = trunc i64 0 to i32
  %t94 = icmp eq i32 %t91, %t93
  store i1 %t94, ptr %l38, !tbaa !21
  br label %bb24
bb24:
  %t96 = load i1, ptr %l38, !tbaa !21
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t97 = load i64, ptr %l5, !tbaa !24
  store i64 %t97, ptr %l50, !tbaa !24
  br label %bb27
bb26:
  store i64 -1, ptr %l50, !tbaa !24
  br label %bb27
bb27:
  %t99 = load i64, ptr %l50, !tbaa !24
  store i64 %t99, ptr %rv
  br label %ret
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_6b87ff60a3433260_ddeea5c0b8316e1c)
  unreachable
bb33:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t103 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v1, ptr %t100)
  store i64 %t103, ptr %l54
  br label %bb34
bb34:
  %t104 = load i64, ptr %l54, !tbaa !24
  store i64 %t104, ptr %l6, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t107 = icmp sge i64 %t105, 0
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/scope:Scoper", ptr %t109, i32 0, i32 25
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = icmp eq ptr %t112, null
  br i1 %t114, label %bb37, label %bb38
bb36:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb41
bb37:
  call void @__olang_check_failed(ptr @olang_loc_dc42a5a165461c34_eb9bc5161264db10)
  unreachable
bb38:
  br label %bb39
bb39:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/scope:Scoper", ptr %t116, i32 0, i32 25
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Body", ptr %t119, i32 0, i32 7
  %t123 = load i64, ptr %l6, !tbaa !24
  %t126 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t122, i64 %t123)
  store %"compiler/typed:Local" %t126, ptr %l66
  br label %bb40
bb40:
  %t127 = getelementptr %"compiler/typed:Local", ptr %l66, i32 0, i32 4
  %t128 = load i32, ptr %t127, !range !{i32 0, i32 7}
  %t130 = trunc i64 0 to i32
  %t131 = icmp eq i32 %t128, %t130
  store i1 %t131, ptr %l57, !tbaa !21
  br label %bb41
bb41:
  %t133 = load i1, ptr %l57, !tbaa !21
  br i1 %t133, label %bb42, label %bb43
bb42:
  %t134 = load i64, ptr %l6, !tbaa !24
  store i64 %t134, ptr %l69, !tbaa !24
  br label %bb44
bb43:
  store i64 -1, ptr %l69, !tbaa !24
  br label %bb44
bb44:
  %t136 = load i64, ptr %l69, !tbaa !24
  store i64 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i1
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l8, !tbaa !24
  br label %bb51
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store i64 %t44, ptr %l27
  br label %bb13
bb13:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  br label %bb51
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t47 = load ptr, ptr %l28, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l28, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l29, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartCall(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store i64 %t68, ptr %l37
  br label %bb20
bb20:
  %t69 = load i64, ptr %l37, !tbaa !24
  store i64 %t69, ptr %l8, !tbaa !24
  br label %bb51
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 2
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t90 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltCall(ptr %v0, ptr %v1, ptr %t85, ptr %t86)
  store i64 %t90, ptr %l47
  br label %bb27
bb27:
  %t91 = load i64, ptr %l47, !tbaa !24
  store i64 %t91, ptr %l8, !tbaa !24
  br label %bb51
bb28:
  %t92 = load ptr, ptr %l1, !tbaa !29
  store ptr %t92, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t93 = load ptr, ptr %l48, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = load i64, ptr %t96, !range !{i64 0, i64 8}
  %t99 = icmp eq i64 %t97, 6
  store i1 %t99, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t100 = load i1, ptr %l49, !tbaa !21
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t112 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltCall(ptr %v0, ptr %v1, ptr %t107, ptr %t108)
  store i64 %t112, ptr %l57
  br label %bb34
bb34:
  %t113 = load i64, ptr %l57, !tbaa !24
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb51
bb35:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t115 = load ptr, ptr %l58, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb36, label %bb37
bb36:
  %t118 = load ptr, ptr %l58, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 8}
  %t121 = icmp eq i64 %t119, 0
  store i1 %t121, ptr %l59, !tbaa !21
  br label %bb37
bb37:
  %t122 = load i1, ptr %l59, !tbaa !21
  br i1 %t122, label %bb38, label %bb39
bb38:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t125, i32 0, i32 2
  %t127 = load i32, ptr %t126
  store i32 %t127, ptr %l7, !tbaa !23
  br label %bb40
bb39:
  br label %bb46
bb40:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l64, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/scope:Scoper", ptr %t130, i32 0, i32 40
  %t133 = load i32, ptr %l7, !tbaa !23
  %t135 = sext i32 %t133 to i64
  %t138 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t132, i64 %t135)
  %t139 = extractvalue { i32, ptr } %t138, 1
  %t140 = extractvalue { i32, ptr } %t138, 0
  store i32 %t140, ptr %l71
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb42, label %ok.142, !prof !99
ok.142:
  store ptr %t139, ptr %l70
  br label %bb41
bb41:
  %t143 = load ptr, ptr %l70, !tbaa !29
  store ptr %t143, ptr %l65, !tbaa !29
  br label %bb44
bb42:
  br label %bb43
bb43:
  store ptr null, ptr %l65, !tbaa !29
  br label %bb44
bb44:
  %t144 = load ptr, ptr %l64, !tbaa !29
  %t145 = load ptr, ptr %l65, !tbaa !29
  %t146 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltCall(ptr %v0, ptr %v0, ptr %t144, ptr %t145)
  store i64 %t146, ptr %l72
  br label %bb45
bb45:
  %t147 = load i64, ptr %l72, !tbaa !24
  store i64 %t147, ptr %l8, !tbaa !24
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_da3e82aad0dc20bd_21e51e34c917c3d9)
  unreachable
bb51:
  %t148 = load i64, ptr %l8, !tbaa !24
  store i64 %t148, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartKept(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l10 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l34 = alloca %"compiler/source:Span"
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l43 = alloca %"compiler/source:Span"
  %l45 = alloca i64
  %l47 = alloca %"compiler/source:Span"
  %l49 = alloca i64
  %l50 = alloca i64
  %l58 = alloca ptr
  %l67 = alloca %"compiler/typed:Local"
  %l69 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca ptr
  %l81 = alloca %"compiler/typed:Local"
  %l83 = alloca i1
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l87 = alloca %"compiler/diagmsg:Msg"
  %l90 = alloca %"compiler/diagmsg:Msg"
  %l91 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOfOwn(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i1, ptr %l10, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t15 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t10, ptr %t11)
  store ptr %t15, ptr %l16
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l16, !tbaa !29
  %t17 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t16)
  store ptr %t17, ptr %l17
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l17, !tbaa !29
  store ptr %t18, ptr %l3, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclaimRoot(ptr %v0, ptr %v1, ptr %t19, ptr %t20)
  store i64 %t23, ptr %l20
  br label %bb7
bb7:
  %t24 = load i64, ptr %l20, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 10
  store ptr %t27, ptr %l23, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/scope:Scoper", ptr %t28, i32 0, i32 25
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb8, label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_178b2bff302b55ae_896b4874215d5e1a)
  unreachable
bb9:
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 25
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 3
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load ptr, ptr %l23, !tbaa !29
  %t45 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t43, i64 %t42)
  %t46 = extractvalue { i32, { i64, ptr } } %t45, 1
  %t47 = extractvalue { i32, { i64, ptr } } %t45, 0
  store i32 %t47, ptr %l32
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb12, label %ok.49, !prof !99
ok.49:
  store { i64, ptr } %t46, ptr %l31
  br label %bb11
bb11:
  %t50 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t50, ptr %l21, !tbaa !27
  br label %bb14
bb12:
  br label %bb13
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l21, !tbaa !27
  br label %bb14
bb14:
  %t51 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t51, ptr %l5, !tbaa !27
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %s0, ptr %t52)
  store %"compiler/source:Span" %t54, ptr %l34
  br label %bb15
bb15:
  %t55 = getelementptr %"compiler/source:Span", ptr %l34, i32 0, i32 1
  %t56 = load i32, ptr %t55, !tbaa !23
  %t58 = sext i32 %t56 to i64
  %t59 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp sle i64 %t58, %t61
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t66 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t66, ptr %l41, !tbaa !27
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t69 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %s0, ptr %t67)
  store %"compiler/source:Span" %t69, ptr %l43
  br label %bb18
bb17:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb26
bb18:
  %t70 = getelementptr %"compiler/source:Span", ptr %l43, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t73 = sext i32 %t71 to i64
  store i64 %t73, ptr %l45, !tbaa !24
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %s0, ptr %t74)
  store %"compiler/source:Span" %t76, ptr %l47
  br label %bb19
bb19:
  %t77 = getelementptr %"compiler/source:Span", ptr %l47, i32 0, i32 1
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = sext i32 %t78 to i64
  store i64 %t80, ptr %l49, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l50, !tbaa !24
  %t83 = load i64, ptr %l45, !tbaa !24
  %t84 = icmp sge i64 %t83, 0
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t86 = load i64, ptr %l45, !tbaa !24
  %t87 = load i64, ptr %l49, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_98dfeaa5663cde63_8f6c693e4f6dac2f)
  unreachable
bb22:
  %t90 = load i64, ptr %l49, !tbaa !24
  %t91 = load i64, ptr %l50, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_98dfeaa5663cde63_8f6c693e4f6dac2f)
  unreachable
bb24:
  %t94 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l45, !tbaa !24
  %t97 = load i64, ptr %l49, !tbaa !24
  %t98 = getelementptr i8, ptr %t95, i64 %t96
  %t99 = sub i64 %t97, %t96
  %t100 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t98, 1
  store { i64, ptr } %t101, ptr %l40, !tbaa !27
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_98dfeaa5663cde63_8f6c693e4f6dac2f)
  unreachable
bb26:
  %t103 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t103, ptr %l6, !tbaa !27
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/scope:Scoper", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/load:Loader", ptr %t110, i32 0, i32 3
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l58, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 25
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = icmp eq ptr %t117, null
  br i1 %t119, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_50915285e3e59b40_32eaccc11482b3ec)
  unreachable
bb28:
  br label %bb29
bb29:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/scope:Scoper", ptr %t121, i32 0, i32 25
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Body", ptr %t124, i32 0, i32 7
  %t128 = load i64, ptr %l4, !tbaa !24
  %t131 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t127, i64 %t128)
  store %"compiler/typed:Local" %t131, ptr %l67
  br label %bb30
bb30:
  %t132 = getelementptr %"compiler/typed:Local", ptr %l67, i32 0, i32 0
  %t133 = load i32, ptr %t132, !tbaa !23
  %t134 = load ptr, ptr %l58, !tbaa !29
  %t136 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t134, i32 %t133)
  store { i64, ptr } %t136, ptr %l69
  br label %bb31
bb31:
  %t137 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t137, ptr %l7, !tbaa !27
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l70, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l71
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l72, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/scope:Scoper", ptr %t141, i32 0, i32 25
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = icmp eq ptr %t144, null
  br i1 %t146, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_40adb7693f14b6df_fca9519f4d7d7edb)
  unreachable
bb33:
  br label %bb34
bb34:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/scope:Scoper", ptr %t148, i32 0, i32 25
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Body", ptr %t151, i32 0, i32 7
  %t155 = load i64, ptr %l4, !tbaa !24
  %t158 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t154, i64 %t155)
  store %"compiler/typed:Local" %t158, ptr %l81
  br label %bb35
bb35:
  %t159 = getelementptr %"compiler/typed:Local", ptr %l81, i32 0, i32 2
  %t160 = load i32, ptr %t159, !tbaa !23
  %t161 = load ptr, ptr %l72, !tbaa !29
  %t163 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emayHoldDtor(ptr %v0, ptr %t161, i32 %t160)
  store i1 %t163, ptr %l83
  br label %bb36
bb36:
  %t164 = load i1, ptr %l83, !tbaa !21
  br i1 %t164, label %bb37, label %bb38
bb37:
  %t165 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t169 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePartKeptDestructor(ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t165, { i64, ptr } %t166)
  store %"compiler/diagmsg:Msg" %t169, ptr %l87
  br label %bb39
bb38:
  %t170 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t171 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t174 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePartKept(ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t170, { i64, ptr } %t171)
  store %"compiler/diagmsg:Msg" %t174, ptr %l90
  br label %bb40
bb39:
  %t175 = load %"compiler/diagmsg:Msg", ptr %l87
  store %"compiler/diagmsg:Msg" %t175, ptr %l84
  br label %bb41
bb40:
  %t176 = load %"compiler/diagmsg:Msg", ptr %l90
  store %"compiler/diagmsg:Msg" %t176, ptr %l84
  br label %bb41
bb41:
  %t177 = load ptr, ptr %l70, !tbaa !29
  %t178 = load %"compiler/source:Span", ptr %l71
  %t179 = load %"compiler/diagmsg:Msg", ptr %l84
  %t180 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s0, ptr %t177, %"compiler/source:Span" %t178, %"compiler/diagmsg:Msg" %t179)
  store i64 %t180, ptr %l91
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load { i64, [2 x i64] }, ptr %l2
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %t16, ptr %t17, { i64, [2 x i64] } %t18)
  store i1 %t22, ptr %l19
  br label %bb6
bb6:
  %t23 = load i1, ptr %l19, !tbaa !21
  store i1 %t23, ptr %l9, !tbaa !21
  br label %bb51
bb7:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l20, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 8}
  %t31 = icmp eq i64 %t29, 4
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Elem", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load { i64, [2 x i64] }, ptr %l2
  %t48 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %t39, ptr %t43, { i64, [2 x i64] } %t44)
  store i1 %t48, ptr %l30
  br label %bb13
bb13:
  %t49 = load i1, ptr %l30, !tbaa !21
  store i1 %t49, ptr %l9, !tbaa !21
  br label %bb51
bb14:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t51 = load ptr, ptr %l31, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 5
  store i1 %t57, ptr %l32, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l32, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l5, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Payload", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load { i64, [2 x i64] }, ptr %l2
  %t74 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %t65, ptr %t69, { i64, [2 x i64] } %t70)
  store i1 %t74, ptr %l41
  br label %bb20
bb20:
  %t75 = load i1, ptr %l41, !tbaa !21
  store i1 %t75, ptr %l9, !tbaa !21
  br label %bb51
bb21:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t77 = load ptr, ptr %l42, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 2
  store i1 %t83, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t84 = load i1, ptr %l43, !tbaa !21
  br i1 %t84, label %bb24, label %bb25
bb24:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l6, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = load { i64, [2 x i64] }, ptr %l2
  %t98 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltOK(ptr %v0, ptr %v1, ptr %t91, ptr %t92, { i64, [2 x i64] } %t94)
  store i1 %t98, ptr %l52
  br label %bb27
bb27:
  %t99 = load i1, ptr %l52, !tbaa !21
  store i1 %t99, ptr %l9, !tbaa !21
  br label %bb51
bb28:
  %t100 = load ptr, ptr %l1, !tbaa !29
  store ptr %t100, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t101 = load ptr, ptr %l53, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb29, label %bb30
bb29:
  %t104 = load ptr, ptr %l53, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 8}
  %t107 = icmp eq i64 %t105, 6
  store i1 %t107, ptr %l54, !tbaa !21
  br label %bb30
bb30:
  %t108 = load i1, ptr %l54, !tbaa !21
  br i1 %t108, label %bb31, label %bb32
bb31:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t111, i32 0, i32 2
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l7, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l7, !tbaa !29
  %t118 = load { i64, [2 x i64] }, ptr %l2
  %t122 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltOK(ptr %v0, ptr %v1, ptr %t115, ptr %t116, { i64, [2 x i64] } %t118)
  store i1 %t122, ptr %l63
  br label %bb34
bb34:
  %t123 = load i1, ptr %l63, !tbaa !21
  store i1 %t123, ptr %l9, !tbaa !21
  br label %bb51
bb35:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t125 = load ptr, ptr %l64, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb36, label %bb37
bb36:
  %t128 = load ptr, ptr %l64, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 8}
  %t131 = icmp eq i64 %t129, 0
  store i1 %t131, ptr %l65, !tbaa !21
  br label %bb37
bb37:
  %t132 = load i1, ptr %l65, !tbaa !21
  br i1 %t132, label %bb38, label %bb39
bb38:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t135, i32 0, i32 2
  %t137 = load i32, ptr %t136
  store i32 %t137, ptr %l8, !tbaa !23
  br label %bb40
bb39:
  br label %bb46
bb40:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l70, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/scope:Scoper", ptr %t140, i32 0, i32 40
  %t143 = load i32, ptr %l8, !tbaa !23
  %t145 = sext i32 %t143 to i64
  %t148 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t142, i64 %t145)
  %t149 = extractvalue { i32, ptr } %t148, 1
  %t150 = extractvalue { i32, ptr } %t148, 0
  store i32 %t150, ptr %l77
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb42, label %ok.152, !prof !99
ok.152:
  store ptr %t149, ptr %l76
  br label %bb41
bb41:
  %t153 = load ptr, ptr %l76, !tbaa !29
  store ptr %t153, ptr %l71, !tbaa !29
  br label %bb44
bb42:
  br label %bb43
bb43:
  store ptr null, ptr %l71, !tbaa !29
  br label %bb44
bb44:
  %t154 = load { i64, [2 x i64] }, ptr %l2
  %t155 = load ptr, ptr %l70, !tbaa !29
  %t156 = load ptr, ptr %l71, !tbaa !29
  %t158 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltOK(ptr %v0, ptr %v0, ptr %t155, ptr %t156, { i64, [2 x i64] } %t154)
  store i1 %t158, ptr %l79
  br label %bb45
bb45:
  %t159 = load i1, ptr %l79, !tbaa !21
  store i1 %t159, ptr %l9, !tbaa !21
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_eb55abbe133e6e93_c0f65549c24d0e87)
  unreachable
bb51:
  %t160 = load i1, ptr %l9, !tbaa !21
  store i1 %t160, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsReach(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  store i32 %t21, ptr %l5, !tbaa !23
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = icmp ne i32 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edtorThroughRef(ptr %v0, ptr %a0, i32 %t28)
  store i1 %t31, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb8
bb7:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb1
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceOperands(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca %"compiler/scope:Val"
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l41 = alloca %"compiler/scope:Val"
  %l42 = alloca ptr
  %l43 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l62 = alloca { i64, [2 x i64] }
  %t19 = alloca { i64, [2 x i64] }, align 8
  %t73 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 0
  store i64 0, ptr %t20
  %t21 = load { i64, [2 x i64] }, ptr %t19
  %t25 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t16, ptr %t17, { i64, [2 x i64] } %t21)
  store %"compiler/scope:Val" %t25, ptr %l18
  br label %bb6
bb6:
  br label %bb41
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 3
  store i1 %t33, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceOperands(ptr %v0, ptr %v1, ptr %t41, ptr %t42)
  br label %bb13
bb13:
  br label %bb41
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 8}
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Elem", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceOperands(ptr %v0, ptr %v1, ptr %t60, ptr %t64)
  br label %bb20
bb20:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Elem", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [2 x i64] }, ptr %t73, i32 0, i32 0
  store i64 0, ptr %t74
  %t75 = load { i64, [2 x i64] }, ptr %t73
  %t79 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t67, ptr %t71, { i64, [2 x i64] } %t75)
  store %"compiler/scope:Val" %t79, ptr %l41
  br label %bb21
bb21:
  br label %bb41
bb22:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t81 = load ptr, ptr %l42, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb23, label %bb24
bb23:
  %t84 = load ptr, ptr %l42, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 8}
  %t87 = icmp eq i64 %t85, 5
  store i1 %t87, ptr %l43, !tbaa !21
  br label %bb24
bb24:
  %t88 = load i1, ptr %l43, !tbaa !21
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t91, i32 0, i32 2
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l5, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Payload", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceOperands(ptr %v0, ptr %v1, ptr %t95, ptr %t99)
  br label %bb28
bb28:
  br label %bb41
bb29:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t103 = load ptr, ptr %l51, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l51, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 8}
  %t109 = icmp eq i64 %t107, 6
  store i1 %t109, ptr %l52, !tbaa !21
  br label %bb31
bb31:
  %t110 = load i1, ptr %l52, !tbaa !21
  br i1 %t110, label %bb32, label %bb33
bb32:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l6, !tbaa !29
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t119, i32 0, i32 3
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l7, !tbaa !23
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t125 = load i32, ptr %l7, !tbaa !23
  %t129 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etempTerm(ptr %v0, ptr %v1, ptr %t123, ptr %t124, i32 %t125)
  store { i64, [2 x i64] } %t129, ptr %l62
  br label %bb35
bb35:
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_b55787a4eb4fe241_8ea57e4945f8f00d)
  unreachable
bb41:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeDef(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i64
  %l10 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l24 = alloca ptr
  %l29 = alloca i64
  %l34 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l35 = alloca { i64, [2 x i64] }
  %l39 = alloca { i64, [2 x i64] }
  %l40 = alloca i32
  %l43 = alloca i1
  %l44 = alloca { i64, [2 x i64] }
  %l48 = alloca { i64, [2 x i64] }
  %l50 = alloca { i64, [2 x i64] }
  %l52 = alloca { i64, [2 x i64] }
  %l54 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca { i64, [2 x i64] }
  %l68 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %t67 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t1)
  store i1 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i1, ptr %l10, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load { i64, [2 x i64] }, ptr %l2
  %t11 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenResult(ptr %v0, ptr %t7, { i64, [2 x i64] } %t8)
  store i1 %t11, ptr %l15
  br label %bb4
bb4:
  %t12 = load i1, ptr %l15, !tbaa !21
  store i1 %t12, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l12, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 149
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  br i1 %t19, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_8b2906635595db32_8dcfaafc9c909d36)
  unreachable
bb10:
  br label %bb11
bb11:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 149
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l3, !tbaa !29
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Versions", ptr %t26, i32 0, i32 6
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store ptr %t32, ptr %l24
  br label %bb12
bb12:
  %t33 = load ptr, ptr %l24, !tbaa !29
  store ptr %t33, ptr %l4, !tbaa !29
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb13, label %bb14
bb13:
  br label %ret
bb14:
  br label %bb15
bb15:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  %t42 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclaimRoot(ptr %v0, ptr %v0, ptr %t38, ptr %t39)
  store i64 %t42, ptr %l29
  br label %bb16
bb16:
  %t43 = load i64, ptr %l29, !tbaa !24
  %t44 = icmp slt i64 %t43, 0
  br i1 %t44, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 26
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t49, i64 %t50)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t53, ptr %l34
  br label %bb19
bb18:
  br label %bb41
bb19:
  %t54 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l34
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t54, ptr %l5
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %t55, i32 0, i32 161
  %t58 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t61 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H568ce559fa980123a387c6ba9ed21aca(ptr %v0, ptr %t57, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t58)
  %t62 = extractvalue { i32, { i64, [2 x i64] } } %t61, 1
  %t63 = extractvalue { i32, { i64, [2 x i64] } } %t61, 0
  store i32 %t63, ptr %l40
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb21, label %ok.65, !prof !99
ok.65:
  store { i64, [2 x i64] } %t62, ptr %l39
  br label %bb20
bb20:
  %t66 = load { i64, [2 x i64] }, ptr %l39
  store { i64, [2 x i64] } %t66, ptr %l35
  br label %bb23
bb21:
  br label %bb22
bb22:
  store { i64, [2 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [2 x i64] }, ptr %t67, i32 0, i32 0
  store i64 0, ptr %t68
  %t69 = load { i64, [2 x i64] }, ptr %t67
  store { i64, [2 x i64] } %t69, ptr %l35
  br label %bb23
bb23:
  %t71 = load { i64, [2 x i64] }, ptr %l35
  store { i64, [2 x i64] } %t71, ptr %l6
  %t72 = load { i64, [2 x i64] }, ptr %l6
  %t74 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t72)
  store i1 %t74, ptr %l43
  br label %bb24
bb24:
  %t75 = load i1, ptr %l43, !tbaa !21
  br i1 %t75, label %bb25, label %bb26
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load { i64, [2 x i64] }, ptr %l6
  %t78 = load { i64, [2 x i64] }, ptr %l2
  %t82 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoinTerm(ptr %v0, ptr %t76, { i64, [2 x i64] } %t77, { i64, [2 x i64] } %t78)
  store { i64, [2 x i64] } %t82, ptr %l48
  br label %bb27
bb26:
  %t83 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t83, ptr %l44
  br label %bb28
bb27:
  %t85 = load { i64, [2 x i64] }, ptr %l48
  store { i64, [2 x i64] } %t85, ptr %l44
  br label %bb28
bb28:
  %t86 = load { i64, [2 x i64] }, ptr %l44
  store { i64, [2 x i64] } %t86, ptr %l7
  %t87 = load { i64, [2 x i64] }, ptr %l7
  store { i64, [2 x i64] } %t87, ptr %l50
  %t88 = load { i64, [2 x i64] }, ptr %l6
  store { i64, [2 x i64] } %t88, ptr %l52
  %t91 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l50, ptr %l52)
  store i1 %t91, ptr %l54
  br label %bb29
bb29:
  %t92 = load i1, ptr %l54, !tbaa !21
  %t93 = xor i1 %t92, true
  br i1 %t93, label %bb30, label %bb31
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/scope:Scoper", ptr %t95, i32 0, i32 161
  %t98 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t99 = load { i64, [2 x i64] }, ptr %l7
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H240bd86caf003ea6de374cb77d0dbfc6(ptr %v0, ptr %t97, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t98, { i64, [2 x i64] } %t99)
  br label %bb32
bb31:
  br label %bb40
bb32:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/scope:Scoper", ptr %t103, i32 0, i32 139
  store i1 true, ptr %t105, !tbaa !21
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/scope:Scoper", ptr %t106, i32 0, i32 175
  store i1 true, ptr %t108, !tbaa !21
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/scope:Scoper", ptr %t109, i32 0, i32 214
  %t112 = load i1, ptr %t111, !tbaa !21
  br i1 %t112, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 229
  store ptr %t116, ptr %l65, !tbaa !29
  %t117 = load i64, ptr %l1, !tbaa !24
  store i64 %t117, ptr %l66, !tbaa !24
  %t118 = load { i64, [2 x i64] }, ptr %l7
  store { i64, [2 x i64] } %t118, ptr %l67
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l68, !tbaa !29
  %t120 = load ptr, ptr %l3, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Versions", ptr %t120, i32 0, i32 4
  %t123 = load i64, ptr %l1, !tbaa !24
  %t126 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t122, i64 %t123)
  store %"compiler/source:Span" %t126, ptr %l72
  br label %bb35
bb34:
  br label %bb39
bb35:
  %t127 = getelementptr %"compiler/source:Span", ptr %l72, i32 0, i32 0
  %t128 = load i32, ptr %t127, !tbaa !23
  %t129 = load ptr, ptr %l68, !tbaa !29
  %t131 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etraceAt(ptr %v0, ptr %s5, ptr %t129, i32 %t128)
  store { i64, ptr } %t131, ptr %l74
  br label %bb36
bb36:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t132 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t132, i64 %t133)
  %t134 = load i64, ptr %l66, !tbaa !24
  %t135 = call ptr @__olang_sb_room(ptr %s6, i64 24)
  %t136 = call i64 @__olang_fmt_i64(ptr %t135, i64 %t134)
  call void @__olang_sb_add(ptr %s6, i64 %t136)
  %t137 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t137, i64 %t138)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %s6, ptr %l67, i64 0)
  br label %bb37
bb37:
  %t140 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t140, i64 %t141)
  %t142 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  call void @__olang_sb_put(ptr %s6, ptr %t143, i64 %t144)
  %t145 = load ptr, ptr %s6
  %t146 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t147 = load i64, ptr %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t145, i64 %t147)
  %t149 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l76, !tbaa !27
  %t151 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t152 = load ptr, ptr %t151
  %t153 = icmp ne ptr %t152, null
  br i1 %t153, label %sbgrew.154, label %sbdone.155
sbgrew.154:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.155
sbdone.155:
  %t156 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t163, { i64, ptr } %t162)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb41:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 180
  %t168 = load i64, ptr %t167, !tbaa !24
  store i64 %t168, ptr %l8, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l80, !tbaa !29
  %t171 = load ptr, ptr %l3, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Versions", ptr %t171, i32 0, i32 4
  %t174 = load i64, ptr %l1, !tbaa !24
  %t177 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t173, i64 %t174)
  store %"compiler/source:Span" %t177, ptr %l84
  br label %bb42
bb42:
  %t178 = getelementptr %"compiler/source:Span", ptr %l84, i32 0, i32 0
  %t179 = load i32, ptr %t178, !tbaa !23
  %t181 = sext i32 %t179 to i64
  %t183 = load ptr, ptr %l80, !tbaa !29
  %t184 = getelementptr %"compiler/scope:Scoper", ptr %t183, i32 0, i32 180
  store i64 %t181, ptr %t184, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l4, !tbaa !29
  %t187 = load { i64, [2 x i64] }, ptr %l2
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epropose(ptr %v0, ptr %v0, ptr %t185, ptr %t186, { i64, [2 x i64] } %t187)
  br label %bb43
bb43:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i64, ptr %l8, !tbaa !24
  %t195 = getelementptr %"compiler/scope:Scoper", ptr %t191, i32 0, i32 180
  store i64 %t192, ptr %t195, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l37 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i1
  %l62 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l82 = alloca i1
  %l92 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca i1
  %l114 = alloca i1
  %l118 = alloca i1
  %l126 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca i1
  %l171 = alloca i64
  %l179 = alloca i64
  %l185 = alloca i1
  %l189 = alloca ptr
  %l191 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i64
  %l194 = alloca { i64, [2 x i64] }
  %l197 = alloca i1
  %l198 = alloca i1
  %l201 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %t2)
  store ptr %t6, ptr %l25
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l25, !tbaa !29
  %t8 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t7)
  store ptr %t8, ptr %l26
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l26, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  store ptr %t10, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t11 = load ptr, ptr %l27, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l27, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 11
  store i1 %t17, ptr %l28, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l28, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l4, !tbaa !29
  br label %bb7
bb6:
  br label %bb16
bb7:
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Cond", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l37, !tbaa !29
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Cond", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb10, label %bb11
bb9:
  br label %bb14
bb10:
  call void @__olang_check_failed(ptr @olang_loc_fba7553b6c5e0ea_50fdebea86f99ab6)
  unreachable
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Cond", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load { i64, [2 x i64] }, ptr %l2
  %t47 = load ptr, ptr %l37, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeIn(ptr %v0, ptr %s0, ptr %t47, ptr %t45, { i64, [2 x i64] } %t46)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Cond", ptr %t51, i32 0, i32 2
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load { i64, [2 x i64] }, ptr %l2
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeIn(ptr %v0, ptr %s0, ptr %t50, ptr %t54, { i64, [2 x i64] } %t55)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t59 = load ptr, ptr %l3, !tbaa !29
  store ptr %t59, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t60 = load ptr, ptr %l48, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb17, label %bb18
bb17:
  %t63 = load ptr, ptr %l48, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 18}
  %t66 = icmp eq i64 %t64, 13
  store i1 %t66, ptr %l49, !tbaa !21
  br label %bb18
bb18:
  %t67 = load i1, ptr %l49, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb19:
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l5, !tbaa !29
  br label %bb21
bb20:
  br label %bb51
bb21:
  %t74 = load ptr, ptr %l5, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Match", ptr %t74, i32 0, i32 1
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  store i64 %t81, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb23, label %bb24
bb23:
  br label %bb34
bb24:
  br label %bb25
bb25:
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t91, ptr %l62, !tbaa !27
  %t92 = load i64, ptr %l7, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 %t92
  %t97 = load ptr, ptr %t96, !tbaa !39
  store ptr %t97, ptr %l9, !tbaa !29
  %t99 = load ptr, ptr %l9, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Arm", ptr %t99, i32 0, i32 4
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb26, label %bb27
bb26:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l69, !tbaa !29
  %t109 = load ptr, ptr %l9, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Arm", ptr %t109, i32 0, i32 4
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = icmp eq ptr %t112, null
  br i1 %t114, label %bb28, label %bb29
bb27:
  br label %bb32
bb28:
  call void @__olang_check_failed(ptr @olang_loc_79bebea62b9e1cf1_163bbb4583e74a1d)
  unreachable
bb29:
  br label %bb30
bb30:
  %t116 = load ptr, ptr %l9, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Arm", ptr %t116, i32 0, i32 4
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load { i64, [2 x i64] }, ptr %l2
  %t121 = load ptr, ptr %l69, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeIn(ptr %v0, ptr %s0, ptr %t121, ptr %t119, { i64, [2 x i64] } %t120)
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t124 = load i64, ptr %l7, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l7, !tbaa !24
  br label %bb22
bb34:
  %t128 = load ptr, ptr %l5, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Match", ptr %t128, i32 0, i32 2
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = icmp eq ptr %t131, null
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb35, label %bb36
bb35:
  %t137 = load ptr, ptr %l5, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Match", ptr %t137, i32 0, i32 2
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb37, label %bb38
bb36:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb40
bb37:
  call void @__olang_check_failed(ptr @olang_loc_d42b6d232bae90fc_92457687da3f2548)
  unreachable
bb38:
  br label %bb39
bb39:
  %t144 = load ptr, ptr %l5, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Match", ptr %t144, i32 0, i32 2
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t150 = getelementptr %"compiler/typed:Arm", ptr %t147, i32 0, i32 4
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  %t155 = xor i1 %t153, true
  store i1 %t155, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t157 = load i1, ptr %l82, !tbaa !21
  br i1 %t157, label %bb41, label %bb42
bb41:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l92, !tbaa !29
  %t159 = load ptr, ptr %l5, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Match", ptr %t159, i32 0, i32 2
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = icmp eq ptr %t162, null
  br i1 %t164, label %bb43, label %bb44
bb42:
  br label %bb50
bb43:
  call void @__olang_check_failed(ptr @olang_loc_d42b6d232bae90fc_92457687da3f2548)
  unreachable
bb44:
  br label %bb45
bb45:
  %t166 = load ptr, ptr %l5, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Match", ptr %t166, i32 0, i32 2
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Arm", ptr %t169, i32 0, i32 4
  %t173 = load ptr, ptr %t172, !tbaa !29
  store ptr %t173, ptr %l10, !tbaa !29
  %t175 = load ptr, ptr %l10, !tbaa !29
  %t177 = icmp eq ptr %t175, null
  br i1 %t177, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_d42b6d232bae90fc_92457687da3f2548)
  unreachable
bb47:
  br label %bb48
bb48:
  %t179 = load ptr, ptr %l10, !tbaa !29
  %t180 = load { i64, [2 x i64] }, ptr %l2
  %t181 = load ptr, ptr %l92, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeIn(ptr %v0, ptr %s0, ptr %t181, ptr %t179, { i64, [2 x i64] } %t180)
  br label %bb49
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb51:
  %t184 = load ptr, ptr %l3, !tbaa !29
  store ptr %t184, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t185 = load ptr, ptr %l104, !tbaa !29
  %t186 = icmp ne ptr %t185, null
  br i1 %t186, label %bb52, label %bb53
bb52:
  %t188 = load ptr, ptr %l104, !tbaa !29
  %t189 = load i64, ptr %t188, !range !{i64 0, i64 18}
  %t191 = icmp eq i64 %t189, 14
  store i1 %t191, ptr %l105, !tbaa !21
  br label %bb53
bb53:
  %t192 = load i1, ptr %l105, !tbaa !21
  br i1 %t192, label %bb54, label %bb55
bb54:
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t195 = getelementptr { i64, [5 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t195, i32 0, i32 2
  %t197 = load ptr, ptr %t196
  store ptr %t197, ptr %l11, !tbaa !29
  br label %bb56
bb55:
  br label %bb85
bb56:
  %t199 = load ptr, ptr %l11, !tbaa !29
  %t201 = getelementptr %"compiler/typed:Try", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = icmp eq ptr %t202, null
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb57, label %bb58
bb57:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l11, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Try", ptr %t209, i32 0, i32 0
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t215 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %s0, ptr %t208, ptr %t212)
  store i1 %t215, ptr %l118
  br label %bb59
bb58:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb60
bb59:
  %t216 = load i1, ptr %l118, !tbaa !21
  store i1 %t216, ptr %l114, !tbaa !21
  br label %bb60
bb60:
  %t217 = load i1, ptr %l114, !tbaa !21
  br i1 %t217, label %bb61, label %bb62
bb61:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l3, !tbaa !29
  %t220 = load { i64, [2 x i64] }, ptr %l2
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeCall(ptr %v0, ptr %s0, ptr %t218, ptr %t219, { i64, [2 x i64] } %t220)
  br label %bb63
bb62:
  %t224 = load ptr, ptr %l11, !tbaa !29
  %t226 = getelementptr %"compiler/typed:Try", ptr %t224, i32 0, i32 0
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = icmp eq ptr %t227, null
  %t231 = xor i1 %t229, true
  br i1 %t231, label %bb64, label %bb65
bb63:
  br label %bb71
bb64:
  %t233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t233, ptr %l126, !tbaa !29
  %t234 = load ptr, ptr %l11, !tbaa !29
  %t236 = getelementptr %"compiler/typed:Try", ptr %t234, i32 0, i32 0
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = icmp eq ptr %t237, null
  br i1 %t239, label %bb66, label %bb67
bb65:
  br label %bb70
bb66:
  call void @__olang_check_failed(ptr @olang_loc_4cca97e9315dc06b_ef98c8592f9f4967)
  unreachable
bb67:
  br label %bb68
bb68:
  %t241 = load ptr, ptr %l11, !tbaa !29
  %t243 = getelementptr %"compiler/typed:Try", ptr %t241, i32 0, i32 0
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t245 = load { i64, [2 x i64] }, ptr %l2
  %t246 = load ptr, ptr %l126, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeIn(ptr %v0, ptr %s0, ptr %t246, ptr %t244, { i64, [2 x i64] } %t245)
  br label %bb69
bb69:
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t249 = load ptr, ptr %l11, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Try", ptr %t249, i32 0, i32 1
  %t252 = load { i64, ptr }, ptr %t251, !tbaa !27
  store { i64, ptr } %t252, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t254 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t254, 0
  store i64 %t256, ptr %l14, !tbaa !24
  br label %bb72
bb72:
  %t258 = load i64, ptr %l13, !tbaa !24
  %t259 = load i64, ptr %l14, !tbaa !24
  %t262 = icmp slt i64 %t258, %t259
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb73, label %bb74
bb73:
  br label %bb84
bb74:
  br label %bb75
bb75:
  %t266 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t266, ptr %l141, !tbaa !27
  %t267 = load i64, ptr %l13, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr ptr, ptr %t270, i64 %t267
  %t272 = load ptr, ptr %t271, !tbaa !39
  %t276 = getelementptr %"compiler/typed:Clause", ptr %t272, i32 0, i32 4
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !27
  store { i64, ptr } %t277, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t279 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t279, 0
  store i64 %t281, ptr %l18, !tbaa !24
  br label %bb76
bb76:
  %t283 = load i64, ptr %l17, !tbaa !24
  %t284 = load i64, ptr %l18, !tbaa !24
  %t287 = icmp slt i64 %t283, %t284
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb77, label %bb78
bb77:
  br label %bb82
bb78:
  br label %bb79
bb79:
  %t291 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t291, ptr %l152, !tbaa !27
  %t292 = load i64, ptr %l17, !tbaa !24
  %t294 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr ptr, ptr %t295, i64 %t292
  %t297 = load ptr, ptr %t296, !tbaa !39
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = load { i64, [2 x i64] }, ptr %l2
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeIn(ptr %v0, ptr %s0, ptr %t299, ptr %t297, { i64, [2 x i64] } %t301)
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t305 = load i64, ptr %l17, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l17, !tbaa !24
  br label %bb76
bb82:
  br label %bb83
bb83:
  %t309 = load i64, ptr %l13, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l13, !tbaa !24
  br label %bb72
bb84:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb85:
  %t313 = load ptr, ptr %l3, !tbaa !29
  store ptr %t313, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t314 = load ptr, ptr %l162, !tbaa !29
  %t315 = icmp ne ptr %t314, null
  br i1 %t315, label %bb86, label %bb87
bb86:
  %t317 = load ptr, ptr %l162, !tbaa !29
  %t318 = load i64, ptr %t317, !range !{i64 0, i64 18}
  %t320 = icmp eq i64 %t318, 5
  store i1 %t320, ptr %l163, !tbaa !21
  br label %bb87
bb87:
  %t321 = load i1, ptr %l163, !tbaa !21
  br i1 %t321, label %bb88, label %bb89
bb88:
  %t322 = load ptr, ptr %l3, !tbaa !29
  %t324 = getelementptr { i64, [5 x i64] }, ptr %t322, i32 0, i32 1
  %t325 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t324, i32 0, i32 2
  %t326 = load ptr, ptr %t325
  store ptr %t326, ptr %l20, !tbaa !29
  br label %bb90
bb89:
  br label %bb96
bb90:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load ptr, ptr %l20, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Promote", ptr %t329, i32 0, i32 0
  %t332 = load ptr, ptr %t331, !tbaa !29
  %t335 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %s0, ptr %t328, ptr %t332)
  store i64 %t335, ptr %l171
  br label %bb91
bb91:
  %t336 = load i64, ptr %l171, !tbaa !24
  %t337 = icmp slt i64 %t336, 0
  br i1 %t337, label %bb92, label %bb93
bb92:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load ptr, ptr %l20, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Promote", ptr %t340, i32 0, i32 0
  %t343 = load ptr, ptr %t342, !tbaa !29
  %t344 = load { i64, [2 x i64] }, ptr %l2
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeCall(ptr %v0, ptr %s0, ptr %t339, ptr %t343, { i64, [2 x i64] } %t344)
  br label %bb94
bb93:
  br label %bb95
bb94:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb95:
  br label %bb101
bb96:
  br i1 true, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_6bff29c0022268a5_acca8b13a06d359)
  unreachable
bb101:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l1, !tbaa !29
  %t352 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclaimRoot(ptr %v0, ptr %v1, ptr %t348, ptr %t349)
  store i64 %t352, ptr %l179
  br label %bb102
bb102:
  %t353 = load i64, ptr %l179, !tbaa !24
  store i64 %t353, ptr %l21, !tbaa !24
  %t354 = load i64, ptr %l21, !tbaa !24
  %t356 = icmp slt i64 %t354, 0
  br i1 %t356, label %bb103, label %bb104
bb103:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load ptr, ptr %l3, !tbaa !29
  %t360 = load { i64, [2 x i64] }, ptr %l2
  %t364 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeView(ptr %v0, ptr %s0, ptr %t358, ptr %t359, { i64, [2 x i64] } %t360)
  store i1 %t364, ptr %l185
  br label %bb105
bb104:
  br label %bb110
bb105:
  %t365 = load i1, ptr %l185, !tbaa !21
  br i1 %t365, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb107:
  br label %bb108
bb108:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load ptr, ptr %l3, !tbaa !29
  %t368 = load { i64, [2 x i64] }, ptr %l2
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeCall(ptr %v0, ptr %s0, ptr %t366, ptr %t367, { i64, [2 x i64] } %t368)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb110:
  %t372 = load ptr, ptr %l0, !tbaa !29
  store ptr %t372, ptr %l189, !tbaa !29
  %t373 = load ptr, ptr %l3, !tbaa !29
  %t375 = call i1 @compiler_2fscope_2epartRead(ptr %s0, ptr %t373)
  store i1 %t375, ptr %l191
  br label %bb111
bb111:
  %t376 = load i1, ptr %l191, !tbaa !21
  %t377 = load ptr, ptr %l189, !tbaa !29
  %t378 = getelementptr %"compiler/scope:Scoper", ptr %t377, i32 0, i32 147
  store i1 %t376, ptr %t378, !tbaa !21
  %t379 = load ptr, ptr %l0, !tbaa !29
  store ptr %t379, ptr %l192, !tbaa !29
  %t380 = load i64, ptr %l21, !tbaa !24
  store i64 %t380, ptr %l193, !tbaa !24
  %t381 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t381, ptr %l194
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t386 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeepsStorage(ptr %v0, ptr %v1, ptr %t382, ptr %t383)
  store i1 %t386, ptr %l197
  br label %bb112
bb112:
  %t387 = load i1, ptr %l197, !tbaa !21
  br i1 %t387, label %bb113, label %bb114
bb113:
  store i1 true, ptr %l198, !tbaa !21
  br label %bb116
bb114:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load ptr, ptr %l1, !tbaa !29
  %t392 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2econvertsStorage(ptr %v0, ptr %v1, ptr %t388, ptr %t389)
  store i1 %t392, ptr %l201
  br label %bb115
bb115:
  %t393 = load i1, ptr %l201, !tbaa !21
  store i1 %t393, ptr %l198, !tbaa !21
  br label %bb116
bb116:
  %t394 = load ptr, ptr %l192, !tbaa !29
  %t395 = load i64, ptr %l193, !tbaa !24
  %t396 = load { i64, [2 x i64] }, ptr %l194
  %t397 = load i1, ptr %l198, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeLocal(ptr %v0, ptr %t394, i64 %t395, { i64, [2 x i64] } %t396, i1 %t397)
  br label %bb117
bb117:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/scope:Scoper", ptr %t398, i32 0, i32 147
  store i1 false, ptr %t400, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereadPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca ptr
  %l5 = alloca %"compiler/scope:Val"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/scope:Val"
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca %"compiler/scope:Val"
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l50 = alloca %"compiler/scope:Val"
  %l53 = alloca i1
  %l55 = alloca %"compiler/scope:Val"
  %l57 = alloca %"compiler/scope:Val"
  %l58 = alloca ptr
  %l59 = alloca i1
  %l62 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i1
  %l83 = alloca i1
  %l94 = alloca %"compiler/scope:Val"
  %l97 = alloca ptr
  %l98 = alloca i1
  %l103 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i32
  %l117 = alloca i1
  %l122 = alloca %"compiler/scope:Val"
  %l130 = alloca i64
  %l133 = alloca i1
  %l135 = alloca i1
  %l137 = alloca ptr
  %l141 = alloca ptr
  %l142 = alloca i32
  %l149 = alloca i1
  %l154 = alloca %"compiler/scope:Val"
  %l161 = alloca i1
  %l163 = alloca %"compiler/scope:Val"
  %l164 = alloca ptr
  %l165 = alloca i1
  %l172 = alloca { i64, [2 x i64] }
  %l173 = alloca %"compiler/scope:Val"
  %l174 = alloca ptr
  %l175 = alloca i1
  %l184 = alloca %"compiler/scope:Val"
  %l186 = alloca %"compiler/scope:Val"
  %l189 = alloca { i64, [2 x i64] }
  %l190 = alloca %"compiler/scope:Val"
  %s5 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  %t156 = alloca { i64, [2 x i64] }, align 8
  %t344 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, [2 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb28
bb5:
  %t16 = load { i64, [2 x i64] }, ptr %l3
  %t18 = extractvalue { i64, [2 x i64] } %t16, 0
  %t19 = icmp eq i64 %t18, 0
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l2, !tbaa !23
  %t27 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l35
  br label %bb8
bb7:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb9
bb8:
  %t28 = load i1, ptr %l35, !tbaa !21
  store i1 %t28, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l32, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t35 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  store i1 %t35, ptr %l40
  br label %bb12
bb11:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb13
bb12:
  %t36 = load i1, ptr %l40, !tbaa !21
  store i1 %t36, ptr %l36, !tbaa !21
  br label %bb13
bb13:
  %t37 = load i1, ptr %l36, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load ptr, ptr %l4, !tbaa !29
  %t42 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeptCall(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  store i1 %t42, ptr %l44
  br label %bb16
bb15:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb17
bb16:
  %t43 = load i1, ptr %l44, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t46 = load i1, ptr %l41, !tbaa !21
  br i1 %t46, label %bb18, label %bb19
bb18:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = load { i64, [2 x i64] }, ptr %l3
  %t54 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t47, ptr %t48, { i64, [2 x i64] } %t50)
  store %"compiler/scope:Val" %t54, ptr %l50
  br label %bb20
bb19:
  br label %bb27
bb20:
  %t55 = load %"compiler/scope:Val", ptr %l50
  store %"compiler/scope:Val" %t55, ptr %l5
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l2, !tbaa !23
  %t60 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t60, ptr %l53
  br label %bb21
bb21:
  %t61 = load i1, ptr %l53, !tbaa !21
  %t62 = xor i1 %t61, true
  br i1 %t62, label %bb22, label %bb23
bb22:
  %t64 = call %"compiler/scope:Val" @compiler_2fscope_2eVal_2eplain()
  store %"compiler/scope:Val" %t64, ptr %l55
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t65 = load %"compiler/scope:Val", ptr %l55
  store %"compiler/scope:Val" %t65, ptr %rv
  br label %ret
bb25:
  %t66 = getelementptr %"compiler/scope:Val", ptr %l5, i32 0, i32 1
  %t67 = load { i64, [2 x i64] }, ptr %t66
  %t69 = call %"compiler/scope:Val" @compiler_2fscope_2eVal_2eexisting({ i64, [2 x i64] } %t67)
  store %"compiler/scope:Val" %t69, ptr %l57
  br label %bb26
bb26:
  %t70 = load %"compiler/scope:Val", ptr %l57
  store %"compiler/scope:Val" %t70, ptr %rv
  br label %ret
bb27:
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_c91b1cdc23aab6c5_bcff614648d867b1)
  unreachable
bb33:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t72 = load ptr, ptr %l58, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb34, label %bb35
bb34:
  %t75 = load ptr, ptr %l58, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 8}
  %t78 = icmp eq i64 %t76, 4
  store i1 %t78, ptr %l59, !tbaa !21
  br label %bb35
bb35:
  %t79 = load i1, ptr %l59, !tbaa !21
  br i1 %t79, label %bb36, label %bb37
bb36:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 0
  %t84 = load %"compiler/source:Span", ptr %t83
  store %"compiler/source:Span" %t84, ptr %l6
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 1
  %t90 = load i32, ptr %t89
  store i32 %t90, ptr %l7, !tbaa !23
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t94, i32 0, i32 2
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l8, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l2, !tbaa !23
  %t102 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t98, i32 %t99)
  store i1 %t102, ptr %l71
  br label %bb38
bb37:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb39
bb38:
  %t103 = load i1, ptr %l71, !tbaa !21
  store i1 %t103, ptr %l62, !tbaa !21
  br label %bb39
bb39:
  %t104 = load i1, ptr %l62, !tbaa !21
  br i1 %t104, label %bb40, label %bb41
bb40:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr { i64, [4 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t107, i32 0, i32 0
  %t109 = load %"compiler/source:Span", ptr %t108
  store %"compiler/source:Span" %t109, ptr %l9
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t113, i32 0, i32 1
  %t115 = load i32, ptr %t114
  store i32 %t115, ptr %l10, !tbaa !23
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Elem", ptr %t121, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t131 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2econstLiteral(ptr %v0, ptr %v1, ptr %t123, ptr %t128)
  store i1 %t131, ptr %l83
  br label %bb42
bb41:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb43
bb42:
  %t132 = load i1, ptr %l83, !tbaa !21
  store i1 %t132, ptr %l72, !tbaa !21
  br label %bb43
bb43:
  %t133 = load i1, ptr %l72, !tbaa !21
  br i1 %t133, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s5
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l12
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143
  store i32 %t144, ptr %l13, !tbaa !23
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l14, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceOperands(ptr %v0, ptr %v1, ptr %t152, ptr %t153)
  br label %bb46
bb45:
  br label %bb48
bb46:
  store { i64, [2 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 0
  store i64 3, ptr %t157
  %t158 = load { i64, [2 x i64] }, ptr %t156
  %t161 = call %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %s5, i32 4, { i64, [2 x i64] } %t158)
  store %"compiler/scope:Val" %t161, ptr %l94
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  %t162 = load %"compiler/scope:Val", ptr %l94
  store %"compiler/scope:Val" %t162, ptr %rv
  br label %ret
bb48:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceOperands(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  br label %bb49
bb49:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t168 = load ptr, ptr %l97, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb50, label %bb51
bb50:
  %t171 = load ptr, ptr %l97, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 8}
  %t174 = icmp eq i64 %t172, 0
  store i1 %t174, ptr %l98, !tbaa !21
  br label %bb51
bb51:
  %t175 = load i1, ptr %l98, !tbaa !21
  br i1 %t175, label %bb52, label %bb53
bb52:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t178, i32 0, i32 2
  %t180 = load i32, ptr %t179
  store i32 %t180, ptr %l15, !tbaa !23
  br label %bb54
bb53:
  br label %bb65
bb54:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/scope:Scoper", ptr %t182, i32 0, i32 40
  %t185 = load i32, ptr %l15, !tbaa !23
  %t187 = sext i32 %t185 to i64
  %t190 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t184, i64 %t187)
  %t191 = extractvalue { i32, ptr } %t190, 1
  %t192 = extractvalue { i32, ptr } %t190, 0
  store i32 %t192, ptr %l109
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb56, label %ok.194, !prof !99
ok.194:
  store ptr %t191, ptr %l108
  br label %bb55
bb55:
  %t195 = load ptr, ptr %l108, !tbaa !29
  store ptr %t195, ptr %l103, !tbaa !29
  br label %bb58
bb56:
  br label %bb57
bb57:
  store ptr null, ptr %l103, !tbaa !29
  br label %bb58
bb58:
  %t196 = load ptr, ptr %l103, !tbaa !29
  store ptr %t196, ptr %l16, !tbaa !29
  %t197 = load ptr, ptr %l16, !tbaa !29
  %t199 = icmp eq ptr %t197, null
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb59, label %bb60
bb59:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/scope:Scoper", ptr %t203, i32 0, i32 40
  %t206 = load i32, ptr %l15, !tbaa !23
  %t208 = sext i32 %t206 to i64
  %t211 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hb9b7b1d0a60c104971d2bbda63d84eec(ptr %v0, ptr %t205, i64 %t208)
  store i1 %t211, ptr %l117
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load ptr, ptr %l16, !tbaa !29
  %t215 = load { i64, [2 x i64] }, ptr %l3
  %t219 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v0, ptr %t212, ptr %t213, { i64, [2 x i64] } %t215)
  store %"compiler/scope:Val" %t219, ptr %l122
  br label %bb62
bb62:
  %t220 = load %"compiler/scope:Val", ptr %l122
  store %"compiler/scope:Val" %t220, ptr %l17
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/scope:Scoper", ptr %t221, i32 0, i32 31
  %t224 = load i32, ptr %l15, !tbaa !23
  %t226 = sext i32 %t224 to i64
  %t227 = getelementptr %"compiler/scope:Val", ptr %l17, i32 0, i32 1
  %t228 = load { i64, [2 x i64] }, ptr %t227
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t223, i64 %t226, { i64, [2 x i64] } %t228)
  br label %bb63
bb63:
  %t232 = load %"compiler/scope:Val", ptr %l17
  store %"compiler/scope:Val" %t232, ptr %rv
  br label %ret
bb64:
  br label %bb88
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb87
bb68:
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t236 = call i64 @compiler_2fscope_2eflRoot(ptr %v1, ptr %t234)
  store i64 %t236, ptr %l130
  br label %bb69
bb69:
  %t237 = load i64, ptr %l130, !tbaa !24
  store i64 %t237, ptr %l18, !tbaa !24
  %t238 = load i64, ptr %l18, !tbaa !24
  %t240 = icmp sge i64 %t238, 0
  br i1 %t240, label %bb70, label %bb71
bb70:
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t242)
  store i1 %t244, ptr %l135
  br label %bb72
bb71:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb73
bb72:
  %t245 = load i1, ptr %l135, !tbaa !21
  %t246 = xor i1 %t245, true
  store i1 %t246, ptr %l133, !tbaa !21
  br label %bb73
bb73:
  %t248 = load i1, ptr %l133, !tbaa !21
  br i1 %t248, label %bb74, label %bb75
bb74:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/scope:Scoper", ptr %t249, i32 0, i32 40
  %t252 = load i64, ptr %l18, !tbaa !24
  %t255 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t251, i64 %t252)
  %t256 = extractvalue { i32, ptr } %t255, 1
  %t257 = extractvalue { i32, ptr } %t255, 0
  store i32 %t257, ptr %l142
  %t258 = icmp ne i32 %t257, 0
  br i1 %t258, label %bb77, label %ok.259, !prof !99
ok.259:
  store ptr %t256, ptr %l141
  br label %bb76
bb75:
  br label %bb86
bb76:
  %t260 = load ptr, ptr %l141, !tbaa !29
  store ptr %t260, ptr %l137, !tbaa !29
  br label %bb79
bb77:
  br label %bb78
bb78:
  store ptr null, ptr %l137, !tbaa !29
  br label %bb79
bb79:
  %t261 = load ptr, ptr %l137, !tbaa !29
  store ptr %t261, ptr %l19, !tbaa !29
  %t262 = load ptr, ptr %l19, !tbaa !29
  %t264 = icmp eq ptr %t262, null
  %t266 = xor i1 %t264, true
  br i1 %t266, label %bb80, label %bb81
bb80:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/scope:Scoper", ptr %t268, i32 0, i32 40
  %t271 = load i64, ptr %l18, !tbaa !24
  %t274 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hb9b7b1d0a60c104971d2bbda63d84eec(ptr %v0, ptr %t270, i64 %t271)
  store i1 %t274, ptr %l149
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load ptr, ptr %l19, !tbaa !29
  %t278 = load { i64, [2 x i64] }, ptr %l3
  %t282 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v0, ptr %t275, ptr %t276, { i64, [2 x i64] } %t278)
  store %"compiler/scope:Val" %t282, ptr %l154
  br label %bb83
bb83:
  %t283 = load %"compiler/scope:Val", ptr %l154
  store %"compiler/scope:Val" %t283, ptr %l20
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/scope:Scoper", ptr %t284, i32 0, i32 31
  %t287 = load i64, ptr %l18, !tbaa !24
  %t288 = getelementptr %"compiler/scope:Val", ptr %l20, i32 0, i32 1
  %t289 = load { i64, [2 x i64] }, ptr %t288
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t286, i64 %t287, { i64, [2 x i64] } %t289)
  br label %bb84
bb84:
  br label %bb85
bb85:
  br label %bb86
bb86:
  br label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_9b2b18bf4fb48614_1bb14c01aa18e3a0)
  unreachable
bb88:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load i32, ptr %l2, !tbaa !23
  %t297 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t293, i32 %t294)
  store i1 %t297, ptr %l161
  br label %bb89
bb89:
  %t298 = load i1, ptr %l161, !tbaa !21
  %t299 = xor i1 %t298, true
  br i1 %t299, label %bb90, label %bb91
bb90:
  %t301 = call %"compiler/scope:Val" @compiler_2fscope_2eVal_2eplain()
  store %"compiler/scope:Val" %t301, ptr %l163
  br label %bb92
bb91:
  br label %bb93
bb92:
  %t302 = load %"compiler/scope:Val", ptr %l163
  store %"compiler/scope:Val" %t302, ptr %rv
  br label %ret
bb93:
  %t303 = load ptr, ptr %l1, !tbaa !29
  store ptr %t303, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t304 = load ptr, ptr %l164, !tbaa !29
  %t305 = icmp ne ptr %t304, null
  br i1 %t305, label %bb94, label %bb95
bb94:
  %t307 = load ptr, ptr %l164, !tbaa !29
  %t308 = load i64, ptr %t307, !range !{i64 0, i64 8}
  %t310 = icmp eq i64 %t308, 0
  store i1 %t310, ptr %l165, !tbaa !21
  br label %bb95
bb95:
  %t311 = load i1, ptr %l165, !tbaa !21
  br i1 %t311, label %bb96, label %bb97
bb96:
  %t312 = load ptr, ptr %l1, !tbaa !29
  %t314 = getelementptr { i64, [4 x i64] }, ptr %t312, i32 0, i32 1
  %t315 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t314, i32 0, i32 2
  %t316 = load i32, ptr %t315
  store i32 %t316, ptr %l21, !tbaa !23
  br label %bb98
bb97:
  br label %bb101
bb98:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load i32, ptr %l21, !tbaa !23
  %t322 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %t318, i32 %t319)
  store { i64, [2 x i64] } %t322, ptr %l172
  br label %bb99
bb99:
  %t323 = load { i64, [2 x i64] }, ptr %l172
  %t324 = call %"compiler/scope:Val" @compiler_2fscope_2eVal_2eexisting({ i64, [2 x i64] } %t323)
  store %"compiler/scope:Val" %t324, ptr %l173
  br label %bb100
bb100:
  %t325 = load %"compiler/scope:Val", ptr %l173
  store %"compiler/scope:Val" %t325, ptr %rv
  br label %ret
bb101:
  %t326 = load ptr, ptr %l1, !tbaa !29
  store ptr %t326, ptr %l174, !tbaa !29
  store i1 false, ptr %l175, !tbaa !21
  %t327 = load ptr, ptr %l174, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb102, label %bb103
bb102:
  %t330 = load ptr, ptr %l174, !tbaa !29
  %t331 = load i64, ptr %t330, !range !{i64 0, i64 8}
  %t333 = icmp eq i64 %t331, 2
  store i1 %t333, ptr %l175, !tbaa !21
  br label %bb103
bb103:
  %t334 = load i1, ptr %l175, !tbaa !21
  br i1 %t334, label %bb104, label %bb105
bb104:
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr { i64, [4 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t337, i32 0, i32 2
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l22, !tbaa !29
  br label %bb106
bb105:
  br label %bb109
bb106:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load ptr, ptr %l22, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t344
  %t345 = getelementptr { i64, [2 x i64] }, ptr %t344, i32 0, i32 0
  store i64 0, ptr %t345
  %t346 = load { i64, [2 x i64] }, ptr %t344
  %t350 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t341, ptr %t342, { i64, [2 x i64] } %t346)
  store %"compiler/scope:Val" %t350, ptr %l184
  br label %bb107
bb107:
  %t351 = getelementptr %"compiler/scope:Val", ptr %l184, i32 0, i32 1
  %t352 = load { i64, [2 x i64] }, ptr %t351
  %t354 = call %"compiler/scope:Val" @compiler_2fscope_2eVal_2eexisting({ i64, [2 x i64] } %t352)
  store %"compiler/scope:Val" %t354, ptr %l186
  br label %bb108
bb108:
  %t355 = load %"compiler/scope:Val", ptr %l186
  store %"compiler/scope:Val" %t355, ptr %rv
  br label %ret
bb109:
  br i1 true, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb115
bb112:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load ptr, ptr %l1, !tbaa !29
  %t360 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %t356, ptr %t357)
  store { i64, [2 x i64] } %t360, ptr %l189
  br label %bb113
bb113:
  %t361 = load { i64, [2 x i64] }, ptr %l189
  %t362 = call %"compiler/scope:Val" @compiler_2fscope_2eVal_2eexisting({ i64, [2 x i64] } %t361)
  store %"compiler/scope:Val" %t362, ptr %l190
  br label %bb114
bb114:
  %t363 = load %"compiler/scope:Val", ptr %l190
  store %"compiler/scope:Val" %t363, ptr %rv
  br label %ret
bb115:
  call void @__olang_check_failed(ptr @olang_loc_99a14be980ef284f_7692c216cde3a19b)
  unreachable
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i64
  %l15 = alloca i64
  %l23 = alloca { i64, [2 x i64] }
  %l25 = alloca i1
  %l26 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t25 = alloca { i64, [2 x i64] }, align 8
  %t47 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  store i1 %t7, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb5:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = add i64 %t10, %t11
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 44
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l15, !tbaa !24
  %t22 = icmp sge i64 %t20, %t21
  store i1 %t22, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store { i64, [2 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 0
  store i64 0, ptr %t26
  %t27 = load { i64, [2 x i64] }, ptr %t25
  store { i64, [2 x i64] } %t27, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/scope:Scoper", ptr %t29, i32 0, i32 44
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t39 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t31, i64 %t36)
  store { i64, [2 x i64] } %t39, ptr %l23
  br label %bb11
bb11:
  %t40 = load { i64, [2 x i64] }, ptr %l23
  store { i64, [2 x i64] } %t40, ptr %l3
  %t41 = load { i64, [2 x i64] }, ptr %l3
  %t43 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t41)
  store i1 %t43, ptr %l25
  br label %bb12
bb12:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t45 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t45, ptr %l26
  br label %bb15
bb14:
  store { i64, [2 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [2 x i64] }, ptr %t47, i32 0, i32 0
  store i64 0, ptr %t48
  %t49 = load { i64, [2 x i64] }, ptr %t47
  store { i64, [2 x i64] } %t49, ptr %l26
  br label %bb15
bb15:
  %t51 = load { i64, [2 x i64] }, ptr %l26
  store { i64, [2 x i64] } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultTerm(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca ptr
  %l15 = alloca i32
  %l20 = alloca { i64, [2 x i64] }
  %l22 = alloca { i64, [2 x i64] }
  %l29 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca i64
  %l49 = alloca i64
  %l59 = alloca i32
  %l64 = alloca { i64, [2 x i64] }
  %l67 = alloca i1
  %l71 = alloca i1
  %l76 = alloca { i64, [2 x i64] }
  %l81 = alloca { i64, [2 x i64] }
  %l86 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t143 = alloca { i64, [2 x i64] }, align 8
  %t155 = alloca { i64, [2 x i64] }, align 8
  %t170 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/scope:Scoper", ptr %t7, i32 0, i32 25
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_17b5555e490eca40_3a72f19dfd1cef0c)
  unreachable
bb2:
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 25
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 2
  %t21 = load i32, ptr %t20, !tbaa !23
  %t22 = load ptr, ptr %l7, !tbaa !29
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t22, i32 %t21)
  store i32 %t24, ptr %l15
  br label %bb4
bb4:
  %t25 = load i32, ptr %l15, !range !{i32 0, i32 33}
  %t27 = trunc i64 21 to i32
  %t28 = icmp eq i32 %t25, %t27
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t32)
  store { i64, [2 x i64] } %t34, ptr %l20
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t35 = load { i64, [2 x i64] }, ptr %l20
  store { i64, [2 x i64] } %t35, ptr %rv
  br label %ret
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %t36)
  store { i64, [2 x i64] } %t38, ptr %l22
  br label %bb9
bb9:
  %t39 = load { i64, [2 x i64] }, ptr %l22
  store { i64, [2 x i64] } %t39, ptr %l2
  %t40 = load { i64, [2 x i64] }, ptr %l2
  %t42 = extractvalue { i64, [2 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 0
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t47, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  store ptr %t54, ptr %l29, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %t55, i32 0, i32 25
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  br i1 %t60, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_7d1ba41a43de5df_b306ac45f9e7717b)
  unreachable
bb14:
  br label %bb15
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 25
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Body", ptr %t65, i32 0, i32 2
  %t69 = load i32, ptr %t68, !tbaa !23
  %t71 = load ptr, ptr %l29, !tbaa !29
  %t74 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t71, i32 %t69, i64 %a1)
  store i64 %t74, ptr %l38
  br label %bb16
bb16:
  %t75 = load i64, ptr %l38, !tbaa !24
  store i64 %t75, ptr %l3, !tbaa !24
  %t76 = load i64, ptr %l3, !tbaa !24
  %t78 = icmp sge i64 %t76, 0
  br i1 %t78, label %bb17, label %bb18
bb17:
  %t80 = load i64, ptr %l3, !tbaa !24
  store i64 %t80, ptr %l41, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 25
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb19, label %bb20
bb18:
  br label %bb39
bb19:
  call void @__olang_check_failed(ptr @olang_loc_deaf2ed7955484ae_e8df1e0ec0ac14ba)
  unreachable
bb20:
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/scope:Scoper", ptr %t88, i32 0, i32 25
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Body", ptr %t91, i32 0, i32 5
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t94)
  store i64 %t96, ptr %l49
  br label %bb22
bb22:
  %t97 = load i64, ptr %l41, !tbaa !24
  %t98 = load i64, ptr %l49, !tbaa !24
  %t99 = icmp slt i64 %t97, %t98
  br i1 %t99, label %bb23, label %bb24
bb23:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/scope:Scoper", ptr %t101, i32 0, i32 25
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb25, label %bb26
bb24:
  br label %bb38
bb25:
  call void @__olang_check_failed(ptr @olang_loc_79e16856d8fb6455_e8daf01bb6fb0841)
  unreachable
bb26:
  br label %bb27
bb27:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/scope:Scoper", ptr %t108, i32 0, i32 25
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Body", ptr %t111, i32 0, i32 5
  %t115 = load i64, ptr %l3, !tbaa !24
  %t118 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t114, i64 %t115)
  store i32 %t118, ptr %l59
  br label %bb28
bb28:
  %t119 = load i32, ptr %l59, !tbaa !23
  %t120 = sext i32 %t119 to i64
  store i64 %t120, ptr %l4, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/scope:Scoper", ptr %t122, i32 0, i32 31
  %t125 = load i64, ptr %l4, !tbaa !24
  %t128 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t124, i64 %t125)
  store { i64, [2 x i64] } %t128, ptr %l64
  br label %bb29
bb29:
  %t129 = load { i64, [2 x i64] }, ptr %l64
  %t131 = extractvalue { i64, [2 x i64] } %t129, 0
  %t132 = icmp eq i64 %t131, 0
  br i1 %t132, label %bb30, label %bb31
bb30:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/scope:Scoper", ptr %t134, i32 0, i32 33
  %t137 = load i64, ptr %l4, !tbaa !24
  %t140 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t136, i64 %t137)
  store i1 %t140, ptr %l71
  br label %bb32
bb31:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb33
bb32:
  %t141 = load i1, ptr %l71, !tbaa !21
  store i1 %t141, ptr %l67, !tbaa !21
  br label %bb33
bb33:
  %t142 = load i1, ptr %l67, !tbaa !21
  br i1 %t142, label %bb34, label %bb35
bb34:
  store { i64, [2 x i64] } zeroinitializer, ptr %t143
  %t144 = getelementptr { i64, [2 x i64] }, ptr %t143, i32 0, i32 0
  store i64 3, ptr %t144
  %t145 = load { i64, [2 x i64] }, ptr %t143
  store { i64, [2 x i64] } %t145, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/scope:Scoper", ptr %t147, i32 0, i32 31
  %t150 = load i64, ptr %l4, !tbaa !24
  %t153 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t149, i64 %t150)
  store { i64, [2 x i64] } %t153, ptr %l76
  br label %bb37
bb37:
  %t154 = load { i64, [2 x i64] }, ptr %l76
  store { i64, [2 x i64] } %t154, ptr %rv
  br label %ret
bb38:
  store { i64, [2 x i64] } zeroinitializer, ptr %t155
  %t156 = getelementptr { i64, [2 x i64] }, ptr %t155, i32 0, i32 0
  store i64 6, ptr %t156
  %t157 = load { i64, [2 x i64] }, ptr %t155
  store { i64, [2 x i64] } %t157, ptr %rv
  br label %ret
bb39:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/scope:Scoper", ptr %t159, i32 0, i32 39
  %t162 = load i64, ptr %t161, !tbaa !24
  %t164 = icmp sge i64 %t162, 0
  br i1 %t164, label %bb40, label %bb41
bb40:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/scope:Scoper", ptr %t166, i32 0, i32 39
  %t169 = load i64, ptr %t168, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t170
  %t171 = getelementptr { i64, [2 x i64] }, ptr %t170, i32 0, i32 0
  store i64 2, ptr %t171
  %t173 = insertvalue { i64 } undef, i64 %t169, 0
  %t174 = getelementptr { i64, [2 x i64] }, ptr %t170, i32 0, i32 1
  store { i64 } %t173, ptr %t174
  %t175 = load { i64, [2 x i64] }, ptr %t170
  store { i64, [2 x i64] } %t175, ptr %l81
  br label %bb43
bb41:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t177)
  store { i64, [2 x i64] } %t179, ptr %l86
  br label %bb42
bb42:
  %t180 = load { i64, [2 x i64] }, ptr %l86
  store { i64, [2 x i64] } %t180, ptr %l81
  br label %bb43
bb43:
  %t181 = load { i64, [2 x i64] }, ptr %l81
  store { i64, [2 x i64] } %t181, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l17 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlStmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28, i64 %a2)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l62 = alloca i1
  %l64 = alloca i1
  %l69 = alloca i64
  %l73 = alloca ptr
  %l75 = alloca i64
  %l76 = alloca ptr
  %l77 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l101 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l111 = alloca i1
  %l124 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l134 = alloca i1
  %l146 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l156 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l184 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l198 = alloca i1
  %l211 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l245 = alloca ptr
  %l254 = alloca ptr
  %l255 = alloca i1
  %l272 = alloca { i64, ptr }
  %l281 = alloca ptr
  %l282 = alloca i1
  %l287 = alloca ptr
  %l288 = alloca i1
  %l300 = alloca { i64, ptr }
  %l310 = alloca ptr
  %l311 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  store i1 %t7, ptr %l50, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l50, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t11 = load ptr, ptr %l53, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l53, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l54, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l54, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l3, !tbaa !23
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l4, !tbaa !29
  br label %bb11
bb10:
  br label %bb22
bb11:
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t33 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t31)
  store i1 %t33, ptr %l62
  br label %bb12
bb12:
  %t34 = load i1, ptr %l62, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t42, i32 %t43)
  store i64 %t46, ptr %l69
  br label %bb15
bb14:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb16
bb15:
  %t47 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t48 = load i64, ptr %l69, !tbaa !24
  %t50 = and i64 %t48, %t47
  %t52 = icmp ne i64 %t50, 0
  store i1 %t52, ptr %l64, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l64, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l73, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = call i64 @compiler_2fscope_2eflRoot(ptr %v1, ptr %t56)
  store i64 %t58, ptr %l75
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t59 = load ptr, ptr %l73, !tbaa !29
  %t60 = load i64, ptr %l75, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlDrop(ptr %v0, ptr %t59, i64 %t60)
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb168
bb22:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t62 = load ptr, ptr %l76, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t65 = load ptr, ptr %l76, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 18}
  %t68 = icmp eq i64 %t66, 5
  store i1 %t68, ptr %l77, !tbaa !21
  br label %bb24
bb24:
  %t69 = load i1, ptr %l77, !tbaa !21
  br i1 %t69, label %bb25, label %bb26
bb25:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Promote", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t76, ptr %t80, i64 %t82)
  br label %bb28
bb28:
  br label %bb168
bb29:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t87 = load ptr, ptr %l87, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb30, label %bb31
bb30:
  %t90 = load ptr, ptr %l87, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 18}
  %t93 = icmp eq i64 %t91, 6
  store i1 %t93, ptr %l88, !tbaa !21
  br label %bb31
bb31:
  %t94 = load i1, ptr %l88, !tbaa !21
  br i1 %t94, label %bb32, label %bb33
bb32:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [5 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb42
bb34:
  %t101 = load ptr, ptr %l6, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Call", ptr %t101, i32 0, i32 1
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t106 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  store i64 %t108, ptr %l9, !tbaa !24
  br label %bb35
bb35:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t118 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t118, ptr %l101, !tbaa !27
  %t119 = load i64, ptr %l8, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 %t119
  %t124 = load ptr, ptr %t123, !tbaa !39
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t126, ptr %t124, i64 %t129)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t133 = load i64, ptr %l8, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l8, !tbaa !24
  br label %bb35
bb41:
  br label %bb168
bb42:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t138 = load ptr, ptr %l110, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb43, label %bb44
bb43:
  %t141 = load ptr, ptr %l110, !tbaa !29
  %t142 = load i64, ptr %t141, !range !{i64 0, i64 18}
  %t144 = icmp eq i64 %t142, 7
  store i1 %t144, ptr %l111, !tbaa !21
  br label %bb44
bb44:
  %t145 = load i1, ptr %l111, !tbaa !21
  br i1 %t145, label %bb45, label %bb46
bb45:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l11, !tbaa !29
  br label %bb47
bb46:
  br label %bb55
bb47:
  %t152 = load ptr, ptr %l11, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Make", ptr %t152, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  store i64 %t159, ptr %l14, !tbaa !24
  br label %bb48
bb48:
  %t161 = load i64, ptr %l13, !tbaa !24
  %t162 = load i64, ptr %l14, !tbaa !24
  %t165 = icmp slt i64 %t161, %t162
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb49, label %bb50
bb49:
  br label %bb54
bb50:
  br label %bb51
bb51:
  %t169 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t169, ptr %l124, !tbaa !27
  %t170 = load i64, ptr %l13, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr ptr, ptr %t173, i64 %t170
  %t175 = load ptr, ptr %t174, !tbaa !39
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t177, ptr %t175, i64 %t180)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t184 = load i64, ptr %l13, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l13, !tbaa !24
  br label %bb48
bb54:
  br label %bb168
bb55:
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t189 = load ptr, ptr %l133, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb56, label %bb57
bb56:
  %t192 = load ptr, ptr %l133, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 18}
  %t195 = icmp eq i64 %t193, 9
  store i1 %t195, ptr %l134, !tbaa !21
  br label %bb57
bb57:
  %t196 = load i1, ptr %l134, !tbaa !21
  br i1 %t196, label %bb58, label %bb59
bb58:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t199, i32 0, i32 4
  %t201 = load { i64, ptr }, ptr %t200
  store { i64, ptr } %t201, ptr %l16, !tbaa !27
  br label %bb60
bb59:
  br label %bb68
bb60:
  %t203 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t203, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  store i64 %t207, ptr %l19, !tbaa !24
  br label %bb61
bb61:
  %t209 = load i64, ptr %l18, !tbaa !24
  %t210 = load i64, ptr %l19, !tbaa !24
  %t213 = icmp slt i64 %t209, %t210
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb62, label %bb63
bb62:
  br label %bb67
bb63:
  br label %bb64
bb64:
  %t217 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t217, ptr %l146, !tbaa !27
  %t218 = load i64, ptr %l18, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr ptr, ptr %t221, i64 %t218
  %t223 = load ptr, ptr %t222, !tbaa !39
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t225, ptr %t223, i64 %t228)
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t232 = load i64, ptr %l18, !tbaa !24
  %t234 = add i64 %t232, 1
  store i64 %t234, ptr %l18, !tbaa !24
  br label %bb61
bb67:
  br label %bb168
bb68:
  %t236 = load ptr, ptr %l1, !tbaa !29
  store ptr %t236, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t237 = load ptr, ptr %l155, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb69, label %bb70
bb69:
  %t240 = load ptr, ptr %l155, !tbaa !29
  %t241 = load i64, ptr %t240, !range !{i64 0, i64 18}
  %t243 = icmp eq i64 %t241, 11
  store i1 %t243, ptr %l156, !tbaa !21
  br label %bb70
bb70:
  %t244 = load i1, ptr %l156, !tbaa !21
  br i1 %t244, label %bb71, label %bb72
bb71:
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [5 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t247, i32 0, i32 2
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l21, !tbaa !29
  br label %bb73
bb72:
  br label %bb76
bb73:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l21, !tbaa !29
  %t254 = getelementptr %"compiler/typed:Cond", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t251, ptr %t255, i64 %t256)
  br label %bb74
bb74:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l21, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Cond", ptr %t261, i32 0, i32 2
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t260, ptr %t264, i64 %t266)
  br label %bb75
bb75:
  br label %bb168
bb76:
  %t270 = load ptr, ptr %l1, !tbaa !29
  store ptr %t270, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t271 = load ptr, ptr %l170, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb77, label %bb78
bb77:
  %t274 = load ptr, ptr %l170, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 18}
  %t277 = icmp eq i64 %t275, 12
  store i1 %t277, ptr %l171, !tbaa !21
  br label %bb78
bb78:
  %t278 = load i1, ptr %l171, !tbaa !21
  br i1 %t278, label %bb79, label %bb80
bb79:
  %t279 = load ptr, ptr %l1, !tbaa !29
  %t281 = getelementptr { i64, [5 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t281, i32 0, i32 2
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l22, !tbaa !29
  br label %bb81
bb80:
  br label %bb90
bb81:
  %t285 = load ptr, ptr %l22, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Seq", ptr %t285, i32 0, i32 0
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  store { i64, ptr } %t288, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t290 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  store i64 %t292, ptr %l25, !tbaa !24
  br label %bb82
bb82:
  %t294 = load i64, ptr %l24, !tbaa !24
  %t295 = load i64, ptr %l25, !tbaa !24
  %t298 = icmp slt i64 %t294, %t295
  %t300 = xor i1 %t298, true
  br i1 %t300, label %bb83, label %bb84
bb83:
  br label %bb88
bb84:
  br label %bb85
bb85:
  %t302 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t302, ptr %l184, !tbaa !27
  %t303 = load i64, ptr %l24, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr ptr, ptr %t306, i64 %t303
  %t308 = load ptr, ptr %t307, !tbaa !39
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t313 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlStmt(ptr %v0, ptr %v1, ptr %t310, ptr %t308, i64 %t313)
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t317 = load i64, ptr %l24, !tbaa !24
  %t319 = add i64 %t317, 1
  store i64 %t319, ptr %l24, !tbaa !24
  br label %bb82
bb88:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l22, !tbaa !29
  %t324 = getelementptr %"compiler/typed:Seq", ptr %t322, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t326 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t321, ptr %t325, i64 %t326)
  br label %bb89
bb89:
  br label %bb168
bb90:
  %t330 = load ptr, ptr %l1, !tbaa !29
  store ptr %t330, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t331 = load ptr, ptr %l197, !tbaa !29
  %t332 = icmp ne ptr %t331, null
  br i1 %t332, label %bb91, label %bb92
bb91:
  %t334 = load ptr, ptr %l197, !tbaa !29
  %t335 = load i64, ptr %t334, !range !{i64 0, i64 18}
  %t337 = icmp eq i64 %t335, 13
  store i1 %t337, ptr %l198, !tbaa !21
  br label %bb92
bb92:
  %t338 = load i1, ptr %l198, !tbaa !21
  br i1 %t338, label %bb93, label %bb94
bb93:
  %t339 = load ptr, ptr %l1, !tbaa !29
  %t341 = getelementptr { i64, [5 x i64] }, ptr %t339, i32 0, i32 1
  %t342 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t341, i32 0, i32 2
  %t343 = load ptr, ptr %t342
  store ptr %t343, ptr %l27, !tbaa !29
  br label %bb95
bb94:
  br label %bb118
bb95:
  %t345 = load ptr, ptr %l27, !tbaa !29
  %t347 = getelementptr %"compiler/typed:Match", ptr %t345, i32 0, i32 0
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !27
  store { i64, ptr } %t348, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t350 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t350, 0
  store i64 %t352, ptr %l30, !tbaa !24
  br label %bb96
bb96:
  %t354 = load i64, ptr %l29, !tbaa !24
  %t355 = load i64, ptr %l30, !tbaa !24
  %t358 = icmp slt i64 %t354, %t355
  %t360 = xor i1 %t358, true
  br i1 %t360, label %bb97, label %bb98
bb97:
  br label %bb102
bb98:
  br label %bb99
bb99:
  %t362 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t362, ptr %l211, !tbaa !27
  %t363 = load i64, ptr %l29, !tbaa !24
  %t365 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !27
  %t367 = getelementptr ptr, ptr %t366, i64 %t363
  %t368 = load ptr, ptr %t367, !tbaa !39
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t373 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlStmt(ptr %v0, ptr %v1, ptr %t370, ptr %t368, i64 %t373)
  br label %bb100
bb100:
  br label %bb101
bb101:
  %t377 = load i64, ptr %l29, !tbaa !24
  %t379 = add i64 %t377, 1
  store i64 %t379, ptr %l29, !tbaa !24
  br label %bb96
bb102:
  %t381 = load ptr, ptr %l27, !tbaa !29
  %t383 = getelementptr %"compiler/typed:Match", ptr %t381, i32 0, i32 1
  %t384 = load { i64, ptr }, ptr %t383, !tbaa !27
  store { i64, ptr } %t384, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t386 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t386, 0
  store i64 %t388, ptr %l34, !tbaa !24
  br label %bb103
bb103:
  %t390 = load i64, ptr %l33, !tbaa !24
  %t391 = load i64, ptr %l34, !tbaa !24
  %t394 = icmp slt i64 %t390, %t391
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb104, label %bb105
bb104:
  br label %bb110
bb105:
  br label %bb106
bb106:
  %t398 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t398, ptr %l228, !tbaa !27
  %t399 = load i64, ptr %l33, !tbaa !24
  %t401 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = getelementptr ptr, ptr %t402, i64 %t399
  %t404 = load ptr, ptr %t403, !tbaa !39
  store ptr %t404, ptr %l35, !tbaa !29
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load ptr, ptr %l35, !tbaa !29
  %t409 = getelementptr %"compiler/typed:Arm", ptr %t407, i32 0, i32 3
  %t410 = load ptr, ptr %t409, !tbaa !29
  %t411 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlBlock(ptr %v0, ptr %v1, ptr %t406, ptr %t410, i64 %t411)
  br label %bb107
bb107:
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t416 = load ptr, ptr %l35, !tbaa !29
  %t418 = getelementptr %"compiler/typed:Arm", ptr %t416, i32 0, i32 4
  %t419 = load ptr, ptr %t418, !tbaa !29
  %t420 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t415, ptr %t419, i64 %t420)
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t424 = load i64, ptr %l33, !tbaa !24
  %t426 = add i64 %t424, 1
  store i64 %t426, ptr %l33, !tbaa !24
  br label %bb103
bb110:
  %t428 = load ptr, ptr %l27, !tbaa !29
  %t430 = getelementptr %"compiler/typed:Match", ptr %t428, i32 0, i32 2
  %t431 = load ptr, ptr %t430, !tbaa !29
  %t433 = icmp eq ptr %t431, null
  %t435 = xor i1 %t433, true
  br i1 %t435, label %bb111, label %bb112
bb111:
  %t437 = load ptr, ptr %l0, !tbaa !29
  store ptr %t437, ptr %l245, !tbaa !29
  %t438 = load ptr, ptr %l27, !tbaa !29
  %t440 = getelementptr %"compiler/typed:Match", ptr %t438, i32 0, i32 2
  %t441 = load ptr, ptr %t440, !tbaa !29
  %t443 = icmp eq ptr %t441, null
  br i1 %t443, label %bb113, label %bb114
bb112:
  br label %bb117
bb113:
  call void @__olang_check_failed(ptr @olang_loc_dba8079c89f8629e_846fd2cd4d9758c2)
  unreachable
bb114:
  br label %bb115
bb115:
  %t445 = load ptr, ptr %l27, !tbaa !29
  %t447 = getelementptr %"compiler/typed:Match", ptr %t445, i32 0, i32 2
  %t448 = load ptr, ptr %t447, !tbaa !29
  %t451 = getelementptr %"compiler/typed:Arm", ptr %t448, i32 0, i32 3
  %t452 = load ptr, ptr %t451, !tbaa !29
  %t453 = load i64, ptr %l2, !tbaa !24
  %t454 = load ptr, ptr %l245, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlBlock(ptr %v0, ptr %v1, ptr %t454, ptr %t452, i64 %t453)
  br label %bb116
bb116:
  br label %bb117
bb117:
  br label %bb168
bb118:
  %t457 = load ptr, ptr %l1, !tbaa !29
  store ptr %t457, ptr %l254, !tbaa !29
  store i1 false, ptr %l255, !tbaa !21
  %t458 = load ptr, ptr %l254, !tbaa !29
  %t459 = icmp ne ptr %t458, null
  br i1 %t459, label %bb119, label %bb120
bb119:
  %t461 = load ptr, ptr %l254, !tbaa !29
  %t462 = load i64, ptr %t461, !range !{i64 0, i64 18}
  %t464 = icmp eq i64 %t462, 14
  store i1 %t464, ptr %l255, !tbaa !21
  br label %bb120
bb120:
  %t465 = load i1, ptr %l255, !tbaa !21
  br i1 %t465, label %bb121, label %bb122
bb121:
  %t466 = load ptr, ptr %l1, !tbaa !29
  %t468 = getelementptr { i64, [5 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t468, i32 0, i32 2
  %t470 = load ptr, ptr %t469
  store ptr %t470, ptr %l36, !tbaa !29
  br label %bb123
bb122:
  br label %bb132
bb123:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load ptr, ptr %l36, !tbaa !29
  %t475 = getelementptr %"compiler/typed:Try", ptr %t473, i32 0, i32 0
  %t476 = load ptr, ptr %t475, !tbaa !29
  %t477 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t472, ptr %t476, i64 %t477)
  br label %bb124
bb124:
  %t481 = load ptr, ptr %l36, !tbaa !29
  %t483 = getelementptr %"compiler/typed:Try", ptr %t481, i32 0, i32 1
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  store { i64, ptr } %t484, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t486 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t488 = extractvalue { i64, ptr } %t486, 0
  store i64 %t488, ptr %l39, !tbaa !24
  br label %bb125
bb125:
  %t490 = load i64, ptr %l38, !tbaa !24
  %t491 = load i64, ptr %l39, !tbaa !24
  %t494 = icmp slt i64 %t490, %t491
  %t496 = xor i1 %t494, true
  br i1 %t496, label %bb126, label %bb127
bb126:
  br label %bb131
bb127:
  br label %bb128
bb128:
  %t498 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t498, ptr %l272, !tbaa !27
  %t499 = load i64, ptr %l38, !tbaa !24
  %t501 = getelementptr { i64, ptr }, ptr %l272, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr ptr, ptr %t502, i64 %t499
  %t504 = load ptr, ptr %t503, !tbaa !39
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/typed:Clause", ptr %t504, i32 0, i32 3
  %t510 = load ptr, ptr %t509, !tbaa !29
  %t511 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlBlock(ptr %v0, ptr %v1, ptr %t506, ptr %t510, i64 %t511)
  br label %bb129
bb129:
  br label %bb130
bb130:
  %t515 = load i64, ptr %l38, !tbaa !24
  %t517 = add i64 %t515, 1
  store i64 %t517, ptr %l38, !tbaa !24
  br label %bb125
bb131:
  br label %bb168
bb132:
  %t519 = load ptr, ptr %l1, !tbaa !29
  store ptr %t519, ptr %l281, !tbaa !29
  store i1 false, ptr %l282, !tbaa !21
  %t520 = load ptr, ptr %l281, !tbaa !29
  %t521 = icmp ne ptr %t520, null
  br i1 %t521, label %bb133, label %bb134
bb133:
  %t523 = load ptr, ptr %l281, !tbaa !29
  %t524 = load i64, ptr %t523, !range !{i64 0, i64 18}
  %t526 = icmp eq i64 %t524, 15
  store i1 %t526, ptr %l282, !tbaa !21
  br label %bb134
bb134:
  %t527 = load i1, ptr %l282, !tbaa !21
  br i1 %t527, label %bb135, label %bb136
bb135:
  %t528 = load ptr, ptr %l1, !tbaa !29
  %t530 = getelementptr { i64, [5 x i64] }, ptr %t528, i32 0, i32 1
  %t531 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t530, i32 0, i32 2
  %t532 = load ptr, ptr %t531
  store ptr %t532, ptr %l41, !tbaa !29
  br label %bb137
bb136:
  br label %bb156
bb137:
  %t534 = load ptr, ptr %l41, !tbaa !29
  store ptr %t534, ptr %l287, !tbaa !29
  store i1 false, ptr %l288, !tbaa !21
  %t535 = load ptr, ptr %l287, !tbaa !29
  %t536 = icmp ne ptr %t535, null
  br i1 %t536, label %bb138, label %bb139
bb138:
  %t538 = load ptr, ptr %l287, !tbaa !29
  %t539 = load i64, ptr %t538, !range !{i64 0, i64 3}
  %t541 = icmp eq i64 %t539, 1
  store i1 %t541, ptr %l288, !tbaa !21
  br label %bb139
bb139:
  %t542 = load i1, ptr %l288, !tbaa !21
  br i1 %t542, label %bb140, label %bb141
bb140:
  %t543 = load ptr, ptr %l41, !tbaa !29
  %t545 = getelementptr { i64, [4 x i64] }, ptr %t543, i32 0, i32 1
  %t546 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t545, i32 0, i32 1
  %t547 = load { i64, ptr }, ptr %t546
  store { i64, ptr } %t547, ptr %l42, !tbaa !27
  br label %bb142
bb141:
  br label %bb150
bb142:
  %t549 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t549, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t551 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t553 = extractvalue { i64, ptr } %t551, 0
  store i64 %t553, ptr %l45, !tbaa !24
  br label %bb143
bb143:
  %t555 = load i64, ptr %l44, !tbaa !24
  %t556 = load i64, ptr %l45, !tbaa !24
  %t559 = icmp slt i64 %t555, %t556
  %t561 = xor i1 %t559, true
  br i1 %t561, label %bb144, label %bb145
bb144:
  br label %bb149
bb145:
  br label %bb146
bb146:
  %t563 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t563, ptr %l300, !tbaa !27
  %t564 = load i64, ptr %l44, !tbaa !24
  %t566 = getelementptr { i64, ptr }, ptr %l300, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !27
  %t568 = getelementptr ptr, ptr %t567, i64 %t564
  %t569 = load ptr, ptr %t568, !tbaa !39
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t574 = getelementptr %"compiler/typed:Capture", ptr %t569, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !29
  %t577 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t571, ptr %t575, i64 %t577)
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t581 = load i64, ptr %l44, !tbaa !24
  %t583 = add i64 %t581, 1
  store i64 %t583, ptr %l44, !tbaa !24
  br label %bb143
bb149:
  br label %bb155
bb150:
  br i1 true, label %bb151, label %bb152
bb151:
  br label %bb153
bb152:
  br label %bb154
bb153:
  br label %bb155
bb154:
  call void @__olang_check_failed(ptr @olang_loc_dbab6e035b5797c_e736089fb75e21e0)
  unreachable
bb155:
  br label %bb168
bb156:
  %t585 = load ptr, ptr %l1, !tbaa !29
  store ptr %t585, ptr %l310, !tbaa !29
  store i1 false, ptr %l311, !tbaa !21
  %t586 = load ptr, ptr %l310, !tbaa !29
  %t587 = icmp ne ptr %t586, null
  br i1 %t587, label %bb157, label %bb158
bb157:
  %t589 = load ptr, ptr %l310, !tbaa !29
  %t590 = load i64, ptr %t589, !range !{i64 0, i64 18}
  %t592 = icmp eq i64 %t590, 17
  store i1 %t592, ptr %l311, !tbaa !21
  br label %bb158
bb158:
  %t593 = load i1, ptr %l311, !tbaa !21
  br i1 %t593, label %bb159, label %bb160
bb159:
  %t594 = load ptr, ptr %l1, !tbaa !29
  %t596 = getelementptr { i64, [5 x i64] }, ptr %t594, i32 0, i32 1
  %t597 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t596, i32 0, i32 2
  %t598 = load ptr, ptr %t597
  store ptr %t598, ptr %l47, !tbaa !29
  br label %bb161
bb160:
  br label %bb163
bb161:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t601 = load ptr, ptr %l47, !tbaa !29
  %t603 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlExpr(ptr %v0, ptr %v1, ptr %t600, ptr %t601, i64 %t603)
  br label %bb162
bb162:
  br label %bb168
bb163:
  br i1 true, label %bb164, label %bb165
bb164:
  br label %bb166
bb165:
  br label %bb167
bb166:
  br label %bb168
bb167:
  call void @__olang_check_failed(ptr @olang_loc_207e75e919c85f37_93e6eeba566436db)
  unreachable
bb168:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erunLength(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca i32
  %l9 = alloca i1
  %l14 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t13 = trunc i64 19 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t26 = load i32, ptr %l14, !tbaa !23
  %t27 = icmp eq i32 %t26, 0
  store i1 %t27, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l9, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = add i64 %t1, 1
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 36
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/scope:Scoper", ptr %t13, i32 0, i32 36
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = add i64 %t16, 1
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t15, i64 %t18)
  store i64 %t21, ptr %l13
  br label %bb4
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 37
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l16
  br label %bb5
bb4:
  %t27 = load i64, ptr %l13, !tbaa !24
  store i64 %t27, ptr %l8, !tbaa !24
  br label %bb6
bb5:
  %t28 = load i64, ptr %l16, !tbaa !24
  store i64 %t28, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t29 = load i64, ptr %l8, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetFieldMark(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [1 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l45 = alloca ptr
  %l55 = alloca i32
  %l60 = alloca i32
  %l64 = alloca i1
  %l69 = alloca i32
  %l73 = alloca i1
  %l74 = alloca i64
  %l78 = alloca ptr
  %l81 = alloca i64
  %l86 = alloca ptr
  %l90 = alloca i32
  %l95 = alloca ptr
  %l99 = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i64, ptr %l17, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l24, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l24, !tbaa !24
  store i64 %t33, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l21, !tbaa !24
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb41
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l9, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l9, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l45
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l45, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 1
  %t63 = load { i64, [2 x i64] }, ptr %t62
  store { i64, [2 x i64] } %t63, ptr %l10
  %t65 = load { i64, [2 x i64] }, ptr %l10
  %t67 = extractvalue { i64, [2 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 1
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t71 = getelementptr { i32, i32 }, ptr %t70, i32 0, i32 0
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l11, !tbaa !23
  br label %bb15
bb14:
  br label %bb34
bb15:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/scope:Scoper", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l11, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l55
  br label %bb16
bb16:
  %t84 = load i32, ptr %l55, !tbaa !23
  store i32 %t84, ptr %l12, !tbaa !23
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/scope:Scoper", ptr %t85, i32 0, i32 0
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l12, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l60
  br label %bb17
bb17:
  %t95 = load i32, ptr %l60, !range !{i32 0, i32 33}
  %t97 = trunc i64 18 to i32
  %t98 = icmp eq i32 %t95, %t97
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb21
bb19:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/scope:Scoper", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l12, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l69
  br label %bb20
bb20:
  %t112 = load i32, ptr %l69, !tbaa !23
  %t113 = sext i32 %t112 to i64
  %t117 = icmp ne i64 %t113, %a1
  store i1 %t117, ptr %l64, !tbaa !21
  br label %bb21
bb21:
  %t119 = load i1, ptr %l64, !tbaa !21
  br i1 %t119, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb26
bb23:
  %t120 = load i64, ptr %l2, !tbaa !24
  store i64 %t120, ptr %l74, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/scope:Scoper", ptr %t121, i32 0, i32 1
  %t124 = load i64, ptr %l9, !tbaa !24
  %t127 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t123, i64 %t124)
  store ptr %t127, ptr %l78
  br label %bb24
bb24:
  %t128 = load ptr, ptr %l78, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Body", ptr %t128, i32 0, i32 10
  %t132 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t130)
  store i64 %t132, ptr %l81
  br label %bb25
bb25:
  %t133 = load i64, ptr %l74, !tbaa !24
  %t134 = load i64, ptr %l81, !tbaa !24
  %t135 = icmp sge i64 %t133, %t134
  store i1 %t135, ptr %l73, !tbaa !21
  br label %bb26
bb26:
  %t137 = load i1, ptr %l73, !tbaa !21
  br i1 %t137, label %bb27, label %bb28
bb27:
  br label %bb40
bb28:
  br label %bb29
bb29:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/scope:Scoper", ptr %t138, i32 0, i32 1
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  store ptr %t144, ptr %l86
  br label %bb30
bb30:
  %t145 = load ptr, ptr %l86, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Body", ptr %t145, i32 0, i32 10
  %t148 = load i64, ptr %l2, !tbaa !24
  %t151 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t147, i64 %t148)
  store i32 %t151, ptr %l90
  br label %bb31
bb31:
  %t152 = load i32, ptr %l90, !tbaa !23
  %t153 = sext i32 %t152 to i64
  store i64 %t153, ptr %l13, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/scope:Scoper", ptr %t155, i32 0, i32 1
  %t158 = load i64, ptr %l9, !tbaa !24
  %t161 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t157, i64 %t158)
  store ptr %t161, ptr %l95
  br label %bb32
bb32:
  %t162 = load ptr, ptr %l95, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Body", ptr %t162, i32 0, i32 7
  %t165 = load i64, ptr %l13, !tbaa !24
  %t168 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v0, ptr %t164, i64 %t165)
  store ptr %t168, ptr %l99
  br label %bb33
bb33:
  %t169 = load ptr, ptr %l99, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Local", ptr %t169, i32 0, i32 5
  store { i64, [1 x i64] } %a3, ptr %t174
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_5a6d5e4fff6c8f59_c596a548624aa6f5)
  unreachable
bb39:
  br label %bb40
bb40:
  %t175 = load i64, ptr %l8, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l8, !tbaa !24
  br label %bb8
bb41:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l18 = alloca { i64, [2 x i64] }
  %l20 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca { i64, [2 x i64] }
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t65 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddToSet(ptr %v0, ptr %s0, ptr %t3, ptr %l3, { i64, [2 x i64] } %a1)
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddToSet(ptr %v0, ptr %s0, ptr %t8, ptr %l3, { i64, [2 x i64] } %a2)
  br label %bb3
bb3:
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %l3)
  store i64 %t14, ptr %l15
  br label %bb4
bb4:
  %t15 = load i64, ptr %l15, !tbaa !24
  %t16 = icmp eq i64 %t15, 1
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t19 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %l3, i64 0)
  store { i64, [2 x i64] } %t19, ptr %l18
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, [2 x i64] }, ptr %l18
  store { i64, [2 x i64] } %t20, ptr %rv
  br label %ret
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t21, i32 0, i32 36
  store ptr %t23, ptr %l20, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 37
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l23
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = load i64, ptr %l23, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t29, i64 %t30)
  br label %bb10
bb10:
  store ptr %l3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  %t32 = load i64, ptr %l5, !tbaa !24
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %t33)
  store i64 %t35, ptr %l27
  br label %bb12
bb12:
  %t36 = load i64, ptr %l25, !tbaa !24
  %t37 = load i64, ptr %l27, !tbaa !24
  %t38 = icmp slt i64 %t36, %t37
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %s0, ptr %t42, i64 %t43)
  store { i64, [2 x i64] } %t46, ptr %l32
  br label %bb16
bb16:
  %t47 = load { i64, [2 x i64] }, ptr %l32
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/scope:Scoper", ptr %t48, i32 0, i32 37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t50, { i64, [2 x i64] } %t47)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l5, !tbaa !24
  br label %bb11
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 36
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t60)
  store i64 %t62, ptr %l40
  br label %bb20
bb20:
  %t63 = load i64, ptr %l40, !tbaa !24
  %t64 = sub i64 %t63, 1
  store { i64, [2 x i64] } zeroinitializer, ptr %t65
  %t66 = getelementptr { i64, [2 x i64] }, ptr %t65, i32 0, i32 0
  store i64 5, ptr %t66
  %t68 = insertvalue { i64 } undef, i64 %t64, 0
  %t69 = getelementptr { i64, [2 x i64] }, ptr %t65, i32 0, i32 1
  store { i64 } %t68, ptr %t69
  %t70 = load { i64, [2 x i64] }, ptr %t65
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t70, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetOpenAt(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca ptr
  %l44 = alloca { i64, [2 x i64] }
  %l46 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 36
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load i64, ptr %l12, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %t9, i64 %t10)
  store i64 %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load i64, ptr %l15, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l22, !tbaa !24
  store i64 %t41, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l19, !tbaa !24
  store i64 %t42, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l40, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 37
  %t68 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t64, i64 %t59)
  store { i64, [2 x i64] } %t68, ptr %l44
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l40, !tbaa !29
  %t71 = load { i64, [2 x i64] }, ptr %l44
  %t73 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopenAt(ptr %v0, ptr %t70, { i64, [2 x i64] } %t71, i32 %a2)
  store i1 %t73, ptr %l46
  br label %bb14
bb14:
  %t74 = load i1, ptr %l46, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l7, !tbaa !24
  br label %bb9
bb19:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitHeld(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i1
  %l19 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i1
  %l30 = alloca { i64, [2 x i64] }
  %l33 = alloca { i64, [2 x i64] }
  %l44 = alloca i1
  %l48 = alloca i1
  %l49 = alloca { i64, [2 x i64] }
  %l51 = alloca { i64, [2 x i64] }
  %l53 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t6)
  store i32 %t8, ptr %l9
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t11, ptr %l10
  br label %bb5
bb5:
  %t12 = load i1, ptr %l10, !tbaa !21
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t13 = load i1, ptr %l6, !tbaa !21
  br i1 %t13, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb11
bb8:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  store ptr %t19, ptr %l14, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t20)
  store i32 %t22, ptr %l16
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load i32, ptr %l16, !tbaa !23
  %t25 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t25, ptr %l17
  br label %bb10
bb10:
  %t26 = load i1, ptr %l17, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l11, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb16
bb13:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  store ptr %t35, ptr %l22, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t36)
  store i32 %t38, ptr %l24
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load i32, ptr %l24, !tbaa !23
  %t41 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSharesRefs(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t41, ptr %l25
  br label %bb15
bb15:
  %t42 = load i1, ptr %l25, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l19, !tbaa !21
  br label %bb16
bb16:
  %t45 = load i1, ptr %l19, !tbaa !21
  br i1 %t45, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t51 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t47, ptr %t48, i1 true)
  store { i64, [2 x i64] } %t51, ptr %l30
  br label %bb20
bb20:
  %t52 = load { i64, [2 x i64] }, ptr %l30
  store { i64, [2 x i64] } %t52, ptr %l2
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t57 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t53, ptr %t54, i1 false)
  store { i64, [2 x i64] } %t57, ptr %l33
  br label %bb21
bb21:
  %t58 = load { i64, [2 x i64] }, ptr %l33
  store { i64, [2 x i64] } %t58, ptr %l3
  %t59 = load { i64, [2 x i64] }, ptr %l2
  %t61 = extractvalue { i64, [2 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 5
  br i1 %t62, label %bb22, label %bb23
bb22:
  br label %bb28
bb23:
  %t64 = load { i64, [2 x i64] }, ptr %l2
  %t66 = extractvalue { i64, [2 x i64] } %t64, 0
  %t67 = icmp eq i64 %t66, 0
  br i1 %t67, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  %t69 = load { i64, [2 x i64] }, ptr %l2
  %t71 = extractvalue { i64, [2 x i64] } %t69, 0
  %t72 = icmp eq i64 %t71, 6
  br i1 %t72, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_3adcdc5611d30137_893c219db59797b)
  unreachable
bb34:
  %t75 = load { i64, [2 x i64] }, ptr %l3
  %t77 = extractvalue { i64, [2 x i64] } %t75, 0
  %t78 = icmp eq i64 %t77, 0
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb35, label %bb36
bb35:
  %t82 = load { i64, [2 x i64] }, ptr %l3
  %t84 = extractvalue { i64, [2 x i64] } %t82, 0
  %t85 = icmp eq i64 %t84, 6
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l44, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb37
bb37:
  %t89 = load i1, ptr %l44, !tbaa !21
  br i1 %t89, label %bb38, label %bb39
bb38:
  %t90 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t90, ptr %l49
  %t91 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t91, ptr %l51
  %t94 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l49, ptr %l51)
  store i1 %t94, ptr %l53
  br label %bb40
bb39:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb41
bb40:
  %t95 = load i1, ptr %l53, !tbaa !21
  %t96 = xor i1 %t95, true
  store i1 %t96, ptr %l48, !tbaa !21
  br label %bb41
bb41:
  %t98 = load i1, ptr %l48, !tbaa !21
  store i1 %t98, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i1
  %l15 = alloca { i64, [2 x i64] }
  %l18 = alloca { i64, [2 x i64] }
  %l30 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, [2 x i64] }
  %l37 = alloca { i64, [2 x i64] }
  %l39 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t6)
  store i32 %t8, ptr %l9
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t11, ptr %l10
  br label %bb5
bb5:
  %t12 = load i1, ptr %l10, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t21 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t17, ptr %t18, i1 true)
  store { i64, [2 x i64] } %t21, ptr %l15
  br label %bb10
bb10:
  %t22 = load { i64, [2 x i64] }, ptr %l15
  store { i64, [2 x i64] } %t22, ptr %l2
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t23, ptr %t24, i1 false)
  store { i64, [2 x i64] } %t27, ptr %l18
  br label %bb11
bb11:
  %t28 = load { i64, [2 x i64] }, ptr %l18
  store { i64, [2 x i64] } %t28, ptr %l3
  %t29 = load { i64, [2 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 5
  br i1 %t32, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  %t35 = load { i64, [2 x i64] }, ptr %l2
  %t37 = extractvalue { i64, [2 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 0
  br i1 %t38, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  %t40 = load { i64, [2 x i64] }, ptr %l2
  %t42 = extractvalue { i64, [2 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 6
  br i1 %t43, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_d14ac281d7095de3_5cf23a39181ab0c7)
  unreachable
bb26:
  %t46 = load { i64, [2 x i64] }, ptr %l3
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 0
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb27, label %bb28
bb27:
  %t53 = load { i64, [2 x i64] }, ptr %l3
  %t55 = extractvalue { i64, [2 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 6
  %t58 = xor i1 %t56, true
  store i1 %t58, ptr %l30, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb29
bb29:
  %t60 = load i1, ptr %l30, !tbaa !21
  br i1 %t60, label %bb30, label %bb31
bb30:
  %t61 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t61, ptr %l35
  %t62 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t62, ptr %l37
  %t65 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l35, ptr %l37)
  store i1 %t65, ptr %l39
  br label %bb32
bb31:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb33
bb32:
  %t66 = load i1, ptr %l39, !tbaa !21
  %t67 = xor i1 %t66, true
  store i1 %t67, ptr %l34, !tbaa !21
  br label %bb33
bb33:
  %t69 = load i1, ptr %l34, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticLiteral(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l25 = alloca i32
  %l29 = alloca i1
  %l34 = alloca i64
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l52 = alloca i1
  %l56 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [5 x i64] }, ptr %t13, i32 0, i32 1
  %t16 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  store %"compiler/source:Span" %t17, ptr %l2
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l4, !tbaa !29
  store i32 %t23, ptr %l5, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l5, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l25
  br label %bb6
bb6:
  %t43 = load i32, ptr %l25, !range !{i32 0, i32 33}
  %t45 = trunc i64 20 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb10
bb8:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/scope:Scoper", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l5, !tbaa !23
  %t59 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t55, i32 %t56)
  store i64 %t59, ptr %l34
  br label %bb9
bb9:
  %t60 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t61 = load i64, ptr %l34, !tbaa !24
  %t63 = and i64 %t61, %t60
  %t65 = icmp ne i64 %t63, 0
  store i1 %t65, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t67 = load i1, ptr %l29, !tbaa !21
  br i1 %t67, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Promote", ptr %t69, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  store ptr %t73, ptr %l6, !tbaa !29
  %t75 = load ptr, ptr %l6, !tbaa !29
  store ptr %t75, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t76 = load ptr, ptr %l43, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb14, label %bb15
bb14:
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 18}
  %t82 = icmp eq i64 %t80, 7
  store i1 %t82, ptr %l44, !tbaa !21
  br label %bb15
bb15:
  %t83 = load i1, ptr %l44, !tbaa !21
  br i1 %t83, label %bb16, label %bb17
bb16:
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l7, !tbaa !29
  br label %bb18
bb17:
  br label %bb23
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t90 = load ptr, ptr %l7, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Make", ptr %t90, i32 0, i32 0
  %t93 = load i32, ptr %t92, !range !{i32 0, i32 5}
  %t95 = trunc i64 2 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb19, label %bb20
bb19:
  %t98 = load ptr, ptr %l7, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Make", ptr %t98, i32 0, i32 2
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t102 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_10, 0
  %t103 = insertvalue { ptr, ptr } %t102, ptr null, 1
  %t106 = extractvalue { ptr, ptr } %t103, 0
  %t107 = extractvalue { ptr, ptr } %t103, 1
  %t108 = call i1 @std_2fprelude_2farray_2eArray_3ccompiler_2ftyped_3aExpr_26_3e_2eEvery_3ccompiler_2ftyped_3aExpr_26_2c_20_3f_3e(ptr %v1, ptr %s3, { i64, ptr } %t101, ptr %t106, ptr %t107)
  store i1 %t108, ptr %l56
  br label %bb21
bb20:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb22
bb21:
  %t109 = load i1, ptr %l56, !tbaa !21
  store i1 %t109, ptr %l52, !tbaa !21
  br label %bb22
bb22:
  %t110 = load i1, ptr %l52, !tbaa !21
  store i1 %t110, ptr %l42, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_ecfbbef7cda902e1_3bafa02f8f932e5d)
  unreachable
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i1, ptr %l42, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l17 = alloca i32
  %l26 = alloca { i64, ptr }
  %l38 = alloca i64
  %l41 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i64
  %l76 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i32, ptr %l17, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t19, i32 %t20)
  store { i64, ptr } %t23, ptr %l26
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t31 = icmp sge i64 %t25, %t28
  br i1 %t31, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store i1 false, ptr %l5, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Call", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i64, ptr %l8, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb14
bb11:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l41, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l41, !tbaa !24
  store i64 %t67, ptr %l38, !tbaa !24
  br label %bb14
bb14:
  %t68 = load i64, ptr %l38, !tbaa !24
  store i64 %t68, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = load i64, ptr %l10, !tbaa !24
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb17:
  br label %bb18
bb18:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t78 = load i64, ptr %l10, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l11, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/scope:Scoper", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l3, !tbaa !23
  %t94 = load i64, ptr %l11, !tbaa !24
  %t98 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t92, i32 %t93, i64 %t94)
  store i64 %t98, ptr %l64
  br label %bb19
bb19:
  %t99 = load i64, ptr %l64, !tbaa !24
  store i64 %t99, ptr %l12, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t102 = icmp sge i64 %t100, 0
  br i1 %t102, label %bb20, label %bb21
bb20:
  %t104 = load i64, ptr %l12, !tbaa !24
  store i64 %t104, ptr %l67, !tbaa !24
  br label %bb22
bb21:
  %t106 = load i64, ptr %l11, !tbaa !24
  store i64 %t106, ptr %l67, !tbaa !24
  br label %bb22
bb22:
  %t108 = load i64, ptr %l67, !tbaa !24
  %t109 = load i64, ptr %l2, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i64, ptr %t112, i64 %t109
  %t114 = load i64, ptr %t113, !tbaa !34
  %t118 = icmp ne i64 %t114, %t108
  br i1 %t118, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb24:
  br label %bb25
bb25:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Call", ptr %t121, i32 0, i32 1
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l76, !tbaa !27
  %t125 = load i64, ptr %l11, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr ptr, ptr %t128, i64 %t125
  %t130 = load ptr, ptr %t129, !tbaa !39
  %t134 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s4, ptr %t120, ptr %t130)
  store ptr %t134, ptr %l80
  br label %bb26
bb26:
  %t135 = load ptr, ptr %l80, !tbaa !29
  store ptr %t135, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t137 = load ptr, ptr %l81, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb27, label %bb28
bb27:
  %t140 = load ptr, ptr %l81, !tbaa !29
  %t141 = load i64, ptr %t140, !range !{i64 0, i64 18}
  %t143 = icmp eq i64 %t141, 1
  store i1 %t143, ptr %l82, !tbaa !21
  br label %bb28
bb28:
  %t144 = load i1, ptr %l82, !tbaa !21
  br i1 %t144, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb36:
  call void @__olang_check_failed(ptr @olang_loc_e22ca2126d036b2f_5c370e93157d3a93)
  unreachable
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb38:
  %t146 = load i64, ptr %l10, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l10, !tbaa !24
  br label %bb15
bb39:
  %t150 = load i1, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t150, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l68 = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l19, !tbaa !24
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l16, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb37
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t51, ptr %l37, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  store ptr %t57, ptr %l8, !tbaa !29
  %t59 = load ptr, ptr %l8, !tbaa !29
  store ptr %t59, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t60 = load ptr, ptr %l40, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t63 = load ptr, ptr %l40, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 17}
  %t66 = icmp eq i64 %t64, 0
  store i1 %t66, ptr %l41, !tbaa !21
  br label %bb12
bb12:
  %t67 = load i1, ptr %l41, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  %t68 = load ptr, ptr %l8, !tbaa !29
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l9, !tbaa !23
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l10, !tbaa !29
  br label %bb15
bb14:
  br label %bb29
bb15:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l9, !tbaa !23
  %t82 = load ptr, ptr %l10, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t84 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t84, 1
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edecide(ptr %v0, ptr %v1, ptr %v1, ptr %t80, i32 %t81, ptr %t82, { i64, ptr } %t83, i64 %t86)
  br label %bb16
bb16:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l10, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store i1 %t96, ptr %l56
  br label %bb17
bb17:
  %t97 = load i1, ptr %l56, !tbaa !21
  br i1 %t97, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb21
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l10, !tbaa !29
  %t102 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisAdapter(ptr %v0, ptr %v1, ptr %t98, ptr %t99)
  store i1 %t102, ptr %l60
  br label %bb20
bb20:
  %t103 = load i1, ptr %l60, !tbaa !21
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb21
bb21:
  %t104 = load i1, ptr %l57, !tbaa !21
  br i1 %t104, label %bb22, label %bb23
bb22:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = load i64, ptr %l7, !tbaa !24
  %t109 = add i64 %t107, 1
  %t110 = load i32, ptr %l9, !tbaa !23
  %t112 = sext i32 %t110 to i64
  %t117 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonlyCalled(ptr %v0, ptr %v1, ptr %t105, { i64, ptr } %t106, i64 %t109, i64 %t112)
  store i1 %t117, ptr %l68
  br label %bb24
bb23:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb25
bb24:
  %t118 = load i1, ptr %l68, !tbaa !21
  store i1 %t118, ptr %l61, !tbaa !21
  br label %bb25
bb25:
  %t119 = load i1, ptr %l61, !tbaa !21
  br i1 %t119, label %bb26, label %bb27
bb26:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/scope:Scoper", ptr %t120, i32 0, i32 70
  store i1 true, ptr %t122, !tbaa !21
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_894def51c550c10b_edf695233d65cd0f)
  unreachable
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmt(ptr %v0, ptr %v1, ptr %t123, ptr %t124)
  br label %bb35
bb35:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/scope:Scoper", ptr %t128, i32 0, i32 70
  store i1 false, ptr %t130, !tbaa !21
  br label %bb36
bb36:
  %t131 = load i64, ptr %l6, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l6, !tbaa !24
  br label %bb7
bb37:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumPuts(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca i1
  %l22 = alloca ptr
  %l26 = alloca i1
  %l30 = alloca ptr
  %l34 = alloca i1
  %l35 = alloca i64
  %l39 = alloca ptr
  %l42 = alloca i64
  %l48 = alloca ptr
  %l52 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/scope:summary", ptr %t8, i32 0, i32 18
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l9, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 6
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l13
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t23 = getelementptr %"compiler/scope:summary", ptr %t21, i32 0, i32 7
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l16
  br label %bb5
bb5:
  %t26 = load i64, ptr %l9, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = icmp slt i64 %t26, %t27
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 6
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t32, i64 %t33)
  store ptr %t36, ptr %l22
  br label %bb8
bb7:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb8:
  %t37 = load ptr, ptr %l22, !tbaa !29
  %t39 = getelementptr %"compiler/scope:summary", ptr %t37, i32 0, i32 7
  %t40 = load i64, ptr %l2, !tbaa !24
  %t43 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t39, i64 %t40)
  store i1 %t43, ptr %l26
  br label %bb9
bb9:
  %t44 = load i1, ptr %l26, !tbaa !21
  store i1 %t44, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t45 = load i1, ptr %l18, !tbaa !21
  store i1 %t45, ptr %rv
  br label %ret
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 6
  %t49 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store ptr %t52, ptr %l30
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t55 = getelementptr %"compiler/scope:summary", ptr %t53, i32 0, i32 17
  %t56 = load i1, ptr %t55, !tbaa !21
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb17
bb14:
  %t60 = load i64, ptr %l2, !tbaa !24
  store i64 %t60, ptr %l35, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/scope:Scoper", ptr %t61, i32 0, i32 6
  %t64 = load i64, ptr %l1, !tbaa !24
  %t67 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t63, i64 %t64)
  store ptr %t67, ptr %l39
  br label %bb15
bb15:
  %t68 = load ptr, ptr %l39, !tbaa !29
  %t70 = getelementptr %"compiler/scope:summary", ptr %t68, i32 0, i32 7
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t70)
  store i64 %t72, ptr %l42
  br label %bb16
bb16:
  %t73 = load i64, ptr %l35, !tbaa !24
  %t74 = load i64, ptr %l42, !tbaa !24
  %t75 = icmp sge i64 %t73, %t74
  store i1 %t75, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t77 = load i1, ptr %l34, !tbaa !21
  br i1 %t77, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/scope:Scoper", ptr %t79, i32 0, i32 6
  %t82 = load i64, ptr %l1, !tbaa !24
  %t85 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t81, i64 %t82)
  store ptr %t85, ptr %l48
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l48, !tbaa !29
  %t88 = getelementptr %"compiler/scope:summary", ptr %t86, i32 0, i32 7
  %t89 = load i64, ptr %l2, !tbaa !24
  %t92 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t88, i64 %t89)
  store i1 %t92, ptr %l52
  br label %bb22
bb22:
  %t93 = load i1, ptr %l52, !tbaa !21
  store i1 %t93, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etempVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca i1
  %l25 = alloca i1
  %l30 = alloca %"compiler/scope:Val"
  %l33 = alloca ptr
  %l36 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l49 = alloca %"compiler/scope:Val"
  %l52 = alloca ptr
  %l54 = alloca ptr
  %l56 = alloca { i64, [2 x i64] }
  %l57 = alloca %"compiler/scope:Val"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  %t45 = alloca { i64, [2 x i64] }, align 8
  %t81 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 122
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 122
  store i64 -1, ptr %t8, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/scope:Scoper", ptr %t9, i32 0, i32 123
  %t12 = load i1, ptr %t11, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 123
  store i1 false, ptr %t16, !tbaa !21
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp eq i64 %t19, -1
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %s0, ptr %t24)
  store ptr %t27, ptr %l18
  br label %bb6
bb5:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  %t28 = load ptr, ptr %l18, !tbaa !29
  %t29 = icmp eq ptr %t28, null
  %t31 = xor i1 %t29, true
  store i1 %t31, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l15, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t39 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t34, ptr %t35)
  store i1 %t39, ptr %l25
  br label %bb10
bb9:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb10:
  %t40 = load i1, ptr %l25, !tbaa !21
  store i1 %t40, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t45
  %t46 = getelementptr { i64, [2 x i64] }, ptr %t45, i32 0, i32 0
  store i64 0, ptr %t46
  %t47 = load { i64, [2 x i64] }, ptr %t45
  %t51 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t42, ptr %t43, { i64, [2 x i64] } %t47)
  store %"compiler/scope:Val" %t51, ptr %l30
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t52 = load %"compiler/scope:Val", ptr %l30
  store %"compiler/scope:Val" %t52, ptr %rv
  br label %ret
bb15:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t56 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %s0, ptr %t53)
  store ptr %t56, ptr %l33
  br label %bb16
bb16:
  %t57 = load ptr, ptr %l33, !tbaa !29
  %t58 = icmp eq ptr %t57, null
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t67 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store i1 %t67, ptr %l40
  br label %bb19
bb18:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb20
bb19:
  %t68 = load i1, ptr %l40, !tbaa !21
  store i1 %t68, ptr %l36, !tbaa !21
  br label %bb20
bb20:
  %t69 = load i1, ptr %l36, !tbaa !21
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t70 = load i64, ptr %l2, !tbaa !24
  %t72 = icmp ne i64 %t70, 0
  store i1 %t72, ptr %l41, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb23
bb23:
  %t74 = load i1, ptr %l41, !tbaa !21
  br i1 %t74, label %bb24, label %bb25
bb24:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/scope:Scoper", ptr %t75, i32 0, i32 119
  store i1 true, ptr %t77, !tbaa !21
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [2 x i64] }, ptr %t81, i32 0, i32 0
  store i64 0, ptr %t82
  %t83 = load { i64, [2 x i64] }, ptr %t81
  %t87 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t78, ptr %t79, { i64, [2 x i64] } %t83)
  store %"compiler/scope:Val" %t87, ptr %l49
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t88 = load %"compiler/scope:Val", ptr %l49
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/scope:Scoper", ptr %t89, i32 0, i32 119
  store i1 false, ptr %t91, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/scope:Val" %t88, ptr %rv
  br label %ret
bb27:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l52, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l54, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t97)
  store { i64, [2 x i64] } %t99, ptr %l56
  br label %bb28
bb28:
  %t100 = load ptr, ptr %l52, !tbaa !29
  %t101 = load ptr, ptr %l54, !tbaa !29
  %t102 = load { i64, [2 x i64] }, ptr %l56
  %t103 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t100, ptr %t101, { i64, [2 x i64] } %t102)
  store %"compiler/scope:Val" %t103, ptr %l57
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t104 = load %"compiler/scope:Val", ptr %l57
  store %"compiler/scope:Val" %t104, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransRecs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, { i64, ptr } %a4, i1 %a5, { i64, ptr } %a6) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/scope:fnRec"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, [2 x i64] }
  %l14 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca %"compiler/scope:fnRec"
  %l30 = alloca %"compiler/scope:fnRec"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i64
  %l35 = alloca i64
  %l40 = alloca { i64, [2 x i64] }
  %l44 = alloca { i64, [2 x i64] }
  %l45 = alloca ptr
  %l48 = alloca { i64, [2 x i64] }
  %l54 = alloca { i64, [2 x i64] }
  %l57 = alloca ptr
  %l61 = alloca %"compiler/scope:fnRec"
  %s3 = alloca %olang.scope
  %t66 = alloca { i64, [2 x i64] }, align 8
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/scope:fnRecs", ptr %t1, i32 0, i32 1
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/scope:fnRecs", ptr %t8, i32 0, i32 1
  store i1 false, ptr %t10, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/scope:fnRecs", ptr %t11, i32 0, i32 0
  store ptr %t13, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %l21, !tbaa !24
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eLen_3ccompiler_2fscope_3afnRec_3e(ptr %v2, ptr %t16)
  store i64 %t18, ptr %l23
  br label %bb5
bb5:
  %t19 = load i64, ptr %l21, !tbaa !24
  %t20 = load i64, ptr %l23, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l7, !tbaa !29
  %t26 = load i64, ptr %l8, !tbaa !24
  %t29 = call %"compiler/scope:fnRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eAt_3ccompiler_2fscope_3afnRec_3e(ptr %v2, ptr %v2, ptr %t25, i64 %t26)
  store %"compiler/scope:fnRec" %t29, ptr %l28
  br label %bb9
bb9:
  %t31 = call %"compiler/scope:fnRec" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fscope_3afnRec(ptr %s3, ptr %l28)
  store %"compiler/scope:fnRec" %t31, ptr %l30
  br label %bb10
bb10:
  %t32 = load %"compiler/scope:fnRec", ptr %l30
  store %"compiler/scope:fnRec" %t32, ptr %l9
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l31
  br label %bb11
bb11:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l10
  %t35 = getelementptr %"compiler/scope:fnRec", ptr %l9, i32 0, i32 1
  store ptr %t35, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb12
bb12:
  %t37 = load i64, ptr %l12, !tbaa !24
  store i64 %t37, ptr %l33, !tbaa !24
  %t38 = load ptr, ptr %l11, !tbaa !29
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %s3, ptr %t38)
  store i64 %t40, ptr %l35
  br label %bb13
bb13:
  %t41 = load i64, ptr %l33, !tbaa !24
  %t42 = load i64, ptr %l35, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb14, label %bb15
bb14:
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t47 = load ptr, ptr %l11, !tbaa !29
  %t48 = load i64, ptr %l12, !tbaa !24
  %t51 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %s3, ptr %t47, i64 %t48)
  store { i64, [2 x i64] } %t51, ptr %l40
  br label %bb17
bb17:
  %t52 = load { i64, [2 x i64] }, ptr %l40
  store { i64, [2 x i64] } %t52, ptr %l13
  %t53 = load { i64, [2 x i64] }, ptr %l13
  %t59 = call { i64, [2 x i64] } @compiler_2fscope_2erecTerm(ptr %v4, { i64, [2 x i64] } %t53, { i64, ptr } %a4, i1 %a5)
  store { i64, [2 x i64] } %t59, ptr %l44
  br label %bb18
bb18:
  %t60 = load { i64, [2 x i64] }, ptr %l44
  store { i64, [2 x i64] } %t60, ptr %l14
  store ptr %l10, ptr %l45, !tbaa !29
  %t61 = load { i64, [2 x i64] }, ptr %l13
  %t63 = extractvalue { i64, [2 x i64] } %t61, 0
  %t64 = icmp eq i64 %t63, 0
  br i1 %t64, label %bb19, label %bb20
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [2 x i64] }, ptr %t66, i32 0, i32 0
  store i64 0, ptr %t67
  %t68 = load { i64, [2 x i64] }, ptr %t66
  store { i64, [2 x i64] } %t68, ptr %l48
  br label %bb22
bb20:
  %t71 = load { i64, [2 x i64] }, ptr %l14
  %t78 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethrough(ptr %v0, ptr %v5, ptr %v3, ptr %a0, { i64, [2 x i64] } %t71, { i64, ptr } %a6, ptr %a3, i1 false)
  store { i64, [2 x i64] } %t78, ptr %l54
  br label %bb21
bb21:
  %t79 = load { i64, [2 x i64] }, ptr %l54
  store { i64, [2 x i64] } %t79, ptr %l48
  br label %bb22
bb22:
  %t80 = load ptr, ptr %l45, !tbaa !29
  %t81 = load { i64, [2 x i64] }, ptr %l48
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %s3, ptr %t80, { i64, [2 x i64] } %t81)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t82 = load i64, ptr %l12, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l12, !tbaa !24
  br label %bb12
bb25:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l57, !tbaa !29
  %t87 = getelementptr %"compiler/scope:fnRec", ptr %l9, i32 0, i32 0
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t90 = getelementptr %"compiler/scope:fnRec", ptr %l9, i32 0, i32 2
  %t91 = load i1, ptr %t90, !tbaa !21
  %t95 = call %"compiler/scope:fnRec" @compiler_2fscope_3afnRec_2ector(ptr %s3, ptr %s3, i64 %t88, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, i1 %t91)
  store %"compiler/scope:fnRec" %t95, ptr %l61
  br label %bb26
bb26:
  %t96 = load ptr, ptr %l57, !tbaa !29
  %t97 = load %"compiler/scope:fnRec", ptr %l61
  call void @compiler_2fscope_2eaddRec(ptr %v1, ptr %s3, ptr %t96, %"compiler/scope:fnRec" %t97)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l8, !tbaa !24
  br label %bb4
bb29:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l29 = alloca i1
  %l34 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l8, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l8, !tbaa !29
  %t42 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t31, ptr %a1, ptr %t33, i64 %a3, i64 %a4)
  store i1 %t42, ptr %l29
  br label %bb8
bb8:
  %t43 = load i1, ptr %l29, !tbaa !21
  %t44 = xor i1 %t43, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 111
  %t49 = getelementptr %"compiler/source:Span", ptr %t48, i32 0, i32 1
  %t50 = load i32, ptr %t49, !tbaa !23
  %t52 = icmp eq i32 %t50, 0
  br i1 %t52, label %bb11, label %bb12
bb10:
  br label %bb15
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l34, !tbaa !29
  %t55 = load ptr, ptr %l8, !tbaa !29
  %t57 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v2, ptr %t55)
  store %"compiler/source:Span" %t57, ptr %l36
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t58 = load %"compiler/source:Span", ptr %l36
  %t59 = load ptr, ptr %l34, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 111
  store %"compiler/source:Span" %t58, ptr %t60
  br label %bb14
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb4
bb17:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i32
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i1
  %l67 = alloca i64
  %l77 = alloca i32
  %l80 = alloca i1
  %l83 = alloca i1
  %l86 = alloca i1
  %l92 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l110 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l124 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i1
  %l136 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l149 = alloca i1
  %l150 = alloca i1
  %l157 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l170 = alloca i1
  %l171 = alloca i1
  %l179 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i1
  %l191 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i1
  %l204 = alloca i1
  %l205 = alloca i1
  %l213 = alloca i1
  %l214 = alloca i1
  %l222 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca i1
  %l236 = alloca i1
  %l237 = alloca i1
  %l244 = alloca i1
  %l245 = alloca i1
  %l253 = alloca i1
  %l254 = alloca ptr
  %l255 = alloca i1
  %l268 = alloca { i64, ptr }
  %l277 = alloca i1
  %l288 = alloca i1
  %l289 = alloca ptr
  %l290 = alloca i1
  %l303 = alloca { i64, ptr }
  %l312 = alloca i1
  %l325 = alloca { i64, ptr }
  %l334 = alloca i1
  %l345 = alloca i1
  %l346 = alloca ptr
  %l347 = alloca i1
  %l358 = alloca i1
  %l369 = alloca { i64, ptr }
  %l378 = alloca i1
  %l380 = alloca i1
  %l387 = alloca i1
  %l393 = alloca ptr
  %l394 = alloca i1
  %l399 = alloca ptr
  %l400 = alloca i1
  %l411 = alloca i64
  %l414 = alloca i1
  %l421 = alloca i1
  %l422 = alloca ptr
  %l423 = alloca i1
  %l441 = alloca { i64, ptr }
  %l447 = alloca i64
  %l450 = alloca i1
  %l458 = alloca i1
  %l464 = alloca ptr
  %l465 = alloca i1
  %l478 = alloca { i64, ptr }
  %l481 = alloca ptr
  %l482 = alloca i1
  %l485 = alloca i1
  %l490 = alloca i64
  %l493 = alloca i1
  %l500 = alloca i1
  %l508 = alloca ptr
  %l509 = alloca i1
  %l520 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t7 = load ptr, ptr %l57, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l57, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l58, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l58, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l5, !tbaa !23
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l6, !tbaa !29
  br label %bb8
bb7:
  br label %bb25
bb8:
  %t27 = load ptr, ptr %l6, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call i64 @compiler_2fscope_2eownField(ptr %v2, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l67
  br label %bb9
bb9:
  %t32 = load i64, ptr %l67, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr @G_2ecompiler_2fscope_2eUseThru, !tbaa !24
  %t39 = icmp eq i64 %t35, %t36
  br i1 %t39, label %bb12, label %bb13
bb11:
  br label %bb23
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/scope:Scoper", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l5, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l77
  br label %bb15
bb15:
  %t52 = load i32, ptr %l77, !range !{i32 0, i32 33}
  store i32 %t52, ptr %l7
  %t53 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t55 = trunc i64 20 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb18
bb17:
  %t58 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t60 = trunc i64 21 to i32
  %t61 = icmp eq i32 %t58, %t60
  store i1 %t61, ptr %l80, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l80, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb22
bb20:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l5, !tbaa !23
  %t68 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNumberLike(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t68, ptr %l86
  br label %bb21
bb21:
  %t69 = load i1, ptr %l86, !tbaa !21
  store i1 %t69, ptr %l83, !tbaa !21
  br label %bb22
bb22:
  %t70 = load i1, ptr %l83, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t73 = load ptr, ptr %l6, !tbaa !29
  %t74 = load i64, ptr %l3, !tbaa !24
  %t75 = load i64, ptr %l4, !tbaa !24
  %t81 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t71, ptr %t72, ptr %t73, i64 %t74, i64 %t75)
  store i1 %t81, ptr %l92
  br label %bb24
bb24:
  %t82 = load i1, ptr %l92, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
bb25:
  %t83 = load ptr, ptr %l2, !tbaa !29
  store ptr %t83, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t84 = load ptr, ptr %l93, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb26, label %bb27
bb26:
  %t87 = load ptr, ptr %l93, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 18}
  %t90 = icmp eq i64 %t88, 3
  store i1 %t90, ptr %l94, !tbaa !21
  br label %bb27
bb27:
  %t91 = load i1, ptr %l94, !tbaa !21
  br i1 %t91, label %bb28, label %bb29
bb28:
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t94, i32 0, i32 2
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l8, !tbaa !29
  br label %bb34
bb29:
  %t98 = load ptr, ptr %l2, !tbaa !29
  store ptr %t98, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t99 = load ptr, ptr %l99, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb30, label %bb31
bb30:
  %t102 = load ptr, ptr %l99, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 18}
  %t105 = icmp eq i64 %t103, 4
  store i1 %t105, ptr %l100, !tbaa !21
  br label %bb31
bb31:
  %t106 = load i1, ptr %l100, !tbaa !21
  br i1 %t106, label %bb32, label %bb33
bb32:
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l8, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t115 = load ptr, ptr %l8, !tbaa !29
  %t116 = load i64, ptr %l3, !tbaa !24
  %t117 = load i64, ptr %l4, !tbaa !24
  %t123 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t113, ptr %t114, ptr %t115, i64 %t116, i64 %t117)
  store i1 %t123, ptr %l110
  br label %bb35
bb35:
  %t124 = load i1, ptr %l110, !tbaa !21
  store i1 %t124, ptr %rv
  br label %ret
bb36:
  %t125 = load ptr, ptr %l2, !tbaa !29
  store ptr %t125, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t126 = load ptr, ptr %l111, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l111, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 18}
  %t132 = icmp eq i64 %t130, 5
  store i1 %t132, ptr %l112, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l112, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l2, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 2
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l9, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t142 = load ptr, ptr %l9, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Promote", ptr %t142, i32 0, i32 0
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = load i64, ptr %l3, !tbaa !24
  %t148 = load i64, ptr %l4, !tbaa !24
  %t154 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t140, ptr %t141, ptr %t145, i64 %t147, i64 %t148)
  store i1 %t154, ptr %l124
  br label %bb42
bb42:
  %t155 = load i1, ptr %l124, !tbaa !21
  store i1 %t155, ptr %rv
  br label %ret
bb43:
  %t156 = load ptr, ptr %l2, !tbaa !29
  store ptr %t156, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t157 = load ptr, ptr %l125, !tbaa !29
  %t158 = icmp ne ptr %t157, null
  br i1 %t158, label %bb44, label %bb45
bb44:
  %t160 = load ptr, ptr %l125, !tbaa !29
  %t161 = load i64, ptr %t160, !range !{i64 0, i64 18}
  %t163 = icmp eq i64 %t161, 6
  store i1 %t163, ptr %l126, !tbaa !21
  br label %bb45
bb45:
  %t164 = load i1, ptr %l126, !tbaa !21
  br i1 %t164, label %bb46, label %bb47
bb46:
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t167 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t167, i32 0, i32 2
  %t169 = load ptr, ptr %t168
  store ptr %t169, ptr %l10, !tbaa !29
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t173 = load ptr, ptr %l10, !tbaa !29
  %t174 = load i64, ptr %l3, !tbaa !24
  %t175 = load i64, ptr %l4, !tbaa !24
  %t181 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueCall(ptr %v0, ptr %v1, ptr %v2, ptr %t171, ptr %t172, ptr %t173, i64 %t174, i64 %t175)
  store i1 %t181, ptr %l136
  br label %bb49
bb49:
  %t182 = load i1, ptr %l136, !tbaa !21
  store i1 %t182, ptr %rv
  br label %ret
bb50:
  %t183 = load ptr, ptr %l2, !tbaa !29
  store ptr %t183, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t184 = load ptr, ptr %l137, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb51, label %bb52
bb51:
  %t187 = load ptr, ptr %l137, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 18}
  %t190 = icmp eq i64 %t188, 7
  store i1 %t190, ptr %l138, !tbaa !21
  br label %bb52
bb52:
  %t191 = load i1, ptr %l138, !tbaa !21
  br i1 %t191, label %bb53, label %bb54
bb53:
  %t192 = load ptr, ptr %l2, !tbaa !29
  %t194 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t194, i32 0, i32 2
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l11, !tbaa !29
  br label %bb55
bb54:
  br label %bb61
bb55:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t200 = load ptr, ptr %l11, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Make", ptr %t200, i32 0, i32 2
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  %t204 = load i64, ptr %l3, !tbaa !24
  %t205 = load i64, ptr %l4, !tbaa !24
  %t211 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExprs(ptr %v0, ptr %v1, ptr %v2, ptr %t198, ptr %t199, { i64, ptr } %t203, i64 %t204, i64 %t205)
  store i1 %t211, ptr %l149
  br label %bb56
bb56:
  %t212 = load i1, ptr %l149, !tbaa !21
  br i1 %t212, label %bb57, label %bb58
bb57:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t215 = load ptr, ptr %l11, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Make", ptr %t215, i32 0, i32 3
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t219 = load i64, ptr %l3, !tbaa !24
  %t220 = load i64, ptr %l4, !tbaa !24
  %t226 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t213, ptr %t214, ptr %t218, i64 %t219, i64 %t220)
  store i1 %t226, ptr %l157
  br label %bb59
bb58:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb60
bb59:
  %t227 = load i1, ptr %l157, !tbaa !21
  store i1 %t227, ptr %l150, !tbaa !21
  br label %bb60
bb60:
  %t228 = load i1, ptr %l150, !tbaa !21
  store i1 %t228, ptr %rv
  br label %ret
bb61:
  %t229 = load ptr, ptr %l2, !tbaa !29
  store ptr %t229, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t230 = load ptr, ptr %l158, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb62, label %bb63
bb62:
  %t233 = load ptr, ptr %l158, !tbaa !29
  %t234 = load i64, ptr %t233, !range !{i64 0, i64 18}
  %t236 = icmp eq i64 %t234, 8
  store i1 %t236, ptr %l159, !tbaa !21
  br label %bb63
bb63:
  %t237 = load i1, ptr %l159, !tbaa !21
  br i1 %t237, label %bb64, label %bb65
bb64:
  %t238 = load ptr, ptr %l2, !tbaa !29
  %t240 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t240, i32 0, i32 2
  %t242 = load ptr, ptr %t241
  store ptr %t242, ptr %l12, !tbaa !29
  br label %bb66
bb65:
  br label %bb72
bb66:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t246 = load ptr, ptr %l12, !tbaa !29
  %t248 = getelementptr %"compiler/typed:Collect", ptr %t246, i32 0, i32 0
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t250 = load i64, ptr %l3, !tbaa !24
  %t251 = load i64, ptr %l4, !tbaa !24
  %t257 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t244, ptr %t245, ptr %t249, i64 %t250, i64 %t251)
  store i1 %t257, ptr %l170
  br label %bb67
bb67:
  %t258 = load i1, ptr %l170, !tbaa !21
  br i1 %t258, label %bb68, label %bb69
bb68:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l1, !tbaa !29
  %t261 = load ptr, ptr %l12, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Collect", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = load i64, ptr %l3, !tbaa !24
  %t267 = load i64, ptr %l4, !tbaa !24
  %t273 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t259, ptr %t260, ptr %t264, i64 %t266, i64 %t267)
  store i1 %t273, ptr %l179
  br label %bb70
bb69:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb71
bb70:
  %t274 = load i1, ptr %l179, !tbaa !21
  store i1 %t274, ptr %l171, !tbaa !21
  br label %bb71
bb71:
  %t275 = load i1, ptr %l171, !tbaa !21
  store i1 %t275, ptr %rv
  br label %ret
bb72:
  %t276 = load ptr, ptr %l2, !tbaa !29
  store ptr %t276, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t277 = load ptr, ptr %l180, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb73, label %bb74
bb73:
  %t280 = load ptr, ptr %l180, !tbaa !29
  %t281 = load i64, ptr %t280, !range !{i64 0, i64 18}
  %t283 = icmp eq i64 %t281, 9
  store i1 %t283, ptr %l181, !tbaa !21
  br label %bb74
bb74:
  %t284 = load i1, ptr %l181, !tbaa !21
  br i1 %t284, label %bb75, label %bb76
bb75:
  %t285 = load ptr, ptr %l2, !tbaa !29
  %t287 = getelementptr { i64, [5 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t287, i32 0, i32 4
  %t289 = load { i64, ptr }, ptr %t288
  store { i64, ptr } %t289, ptr %l13, !tbaa !27
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t294 = load i64, ptr %l3, !tbaa !24
  %t295 = load i64, ptr %l4, !tbaa !24
  %t301 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExprs(ptr %v0, ptr %v1, ptr %v2, ptr %t291, ptr %t292, { i64, ptr } %t293, i64 %t294, i64 %t295)
  store i1 %t301, ptr %l191
  br label %bb78
bb78:
  %t302 = load i1, ptr %l191, !tbaa !21
  store i1 %t302, ptr %rv
  br label %ret
bb79:
  %t303 = load ptr, ptr %l2, !tbaa !29
  store ptr %t303, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t304 = load ptr, ptr %l192, !tbaa !29
  %t305 = icmp ne ptr %t304, null
  br i1 %t305, label %bb80, label %bb81
bb80:
  %t307 = load ptr, ptr %l192, !tbaa !29
  %t308 = load i64, ptr %t307, !range !{i64 0, i64 18}
  %t310 = icmp eq i64 %t308, 10
  store i1 %t310, ptr %l193, !tbaa !21
  br label %bb81
bb81:
  %t311 = load i1, ptr %l193, !tbaa !21
  br i1 %t311, label %bb82, label %bb83
bb82:
  %t312 = load ptr, ptr %l2, !tbaa !29
  %t314 = getelementptr { i64, [5 x i64] }, ptr %t312, i32 0, i32 1
  %t315 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t314, i32 0, i32 2
  %t316 = load ptr, ptr %t315
  store ptr %t316, ptr %l14, !tbaa !29
  br label %bb84
bb83:
  br label %bb94
bb84:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load ptr, ptr %l1, !tbaa !29
  %t320 = load ptr, ptr %l14, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Slice", ptr %t320, i32 0, i32 0
  %t323 = load ptr, ptr %t322, !tbaa !29
  %t324 = load i64, ptr %l3, !tbaa !24
  %t325 = load i64, ptr %l4, !tbaa !24
  %t331 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t318, ptr %t319, ptr %t323, i64 %t324, i64 %t325)
  store i1 %t331, ptr %l204
  br label %bb85
bb85:
  %t332 = load i1, ptr %l204, !tbaa !21
  br i1 %t332, label %bb86, label %bb87
bb86:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load ptr, ptr %l1, !tbaa !29
  %t335 = load ptr, ptr %l14, !tbaa !29
  %t337 = getelementptr %"compiler/typed:Slice", ptr %t335, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t340 = load i64, ptr %l3, !tbaa !24
  %t341 = load i64, ptr %l4, !tbaa !24
  %t347 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t333, ptr %t334, ptr %t338, i64 %t340, i64 %t341)
  store i1 %t347, ptr %l213
  br label %bb88
bb87:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb89
bb88:
  %t348 = load i1, ptr %l213, !tbaa !21
  store i1 %t348, ptr %l205, !tbaa !21
  br label %bb89
bb89:
  %t349 = load i1, ptr %l205, !tbaa !21
  br i1 %t349, label %bb90, label %bb91
bb90:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load ptr, ptr %l1, !tbaa !29
  %t352 = load ptr, ptr %l14, !tbaa !29
  %t354 = getelementptr %"compiler/typed:Slice", ptr %t352, i32 0, i32 2
  %t355 = load ptr, ptr %t354, !tbaa !29
  %t357 = load i64, ptr %l3, !tbaa !24
  %t358 = load i64, ptr %l4, !tbaa !24
  %t364 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t350, ptr %t351, ptr %t355, i64 %t357, i64 %t358)
  store i1 %t364, ptr %l222
  br label %bb92
bb91:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb93
bb92:
  %t365 = load i1, ptr %l222, !tbaa !21
  store i1 %t365, ptr %l214, !tbaa !21
  br label %bb93
bb93:
  %t366 = load i1, ptr %l214, !tbaa !21
  store i1 %t366, ptr %rv
  br label %ret
bb94:
  %t367 = load ptr, ptr %l2, !tbaa !29
  store ptr %t367, ptr %l223, !tbaa !29
  store i1 false, ptr %l224, !tbaa !21
  %t368 = load ptr, ptr %l223, !tbaa !29
  %t369 = icmp ne ptr %t368, null
  br i1 %t369, label %bb95, label %bb96
bb95:
  %t371 = load ptr, ptr %l223, !tbaa !29
  %t372 = load i64, ptr %t371, !range !{i64 0, i64 18}
  %t374 = icmp eq i64 %t372, 11
  store i1 %t374, ptr %l224, !tbaa !21
  br label %bb96
bb96:
  %t375 = load i1, ptr %l224, !tbaa !21
  br i1 %t375, label %bb97, label %bb98
bb97:
  %t376 = load ptr, ptr %l2, !tbaa !29
  %t378 = getelementptr { i64, [5 x i64] }, ptr %t376, i32 0, i32 1
  %t379 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t378, i32 0, i32 2
  %t380 = load ptr, ptr %t379
  store ptr %t380, ptr %l15, !tbaa !29
  br label %bb99
bb98:
  br label %bb109
bb99:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t384 = load ptr, ptr %l15, !tbaa !29
  %t386 = getelementptr %"compiler/typed:Cond", ptr %t384, i32 0, i32 0
  %t387 = load ptr, ptr %t386, !tbaa !29
  %t389 = load i64, ptr %l3, !tbaa !24
  %t390 = load i64, ptr %l4, !tbaa !24
  %t396 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t382, ptr %t383, ptr %t387, i64 %t389, i64 %t390)
  store i1 %t396, ptr %l236
  br label %bb100
bb100:
  %t397 = load i1, ptr %l236, !tbaa !21
  br i1 %t397, label %bb101, label %bb102
bb101:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load ptr, ptr %l1, !tbaa !29
  %t400 = load ptr, ptr %l15, !tbaa !29
  %t402 = getelementptr %"compiler/typed:Cond", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t404 = load i64, ptr %l3, !tbaa !24
  %t405 = load i64, ptr %l4, !tbaa !24
  %t411 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t398, ptr %t399, ptr %t403, i64 %t404, i64 %t405)
  store i1 %t411, ptr %l244
  br label %bb103
bb102:
  store i1 false, ptr %l237, !tbaa !21
  br label %bb104
bb103:
  %t412 = load i1, ptr %l244, !tbaa !21
  store i1 %t412, ptr %l237, !tbaa !21
  br label %bb104
bb104:
  %t413 = load i1, ptr %l237, !tbaa !21
  br i1 %t413, label %bb105, label %bb106
bb105:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load ptr, ptr %l1, !tbaa !29
  %t416 = load ptr, ptr %l15, !tbaa !29
  %t418 = getelementptr %"compiler/typed:Cond", ptr %t416, i32 0, i32 2
  %t419 = load ptr, ptr %t418, !tbaa !29
  %t421 = load i64, ptr %l3, !tbaa !24
  %t422 = load i64, ptr %l4, !tbaa !24
  %t428 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t414, ptr %t415, ptr %t419, i64 %t421, i64 %t422)
  store i1 %t428, ptr %l253
  br label %bb107
bb106:
  store i1 false, ptr %l245, !tbaa !21
  br label %bb108
bb107:
  %t429 = load i1, ptr %l253, !tbaa !21
  store i1 %t429, ptr %l245, !tbaa !21
  br label %bb108
bb108:
  %t430 = load i1, ptr %l245, !tbaa !21
  store i1 %t430, ptr %rv
  br label %ret
bb109:
  %t431 = load ptr, ptr %l2, !tbaa !29
  store ptr %t431, ptr %l254, !tbaa !29
  store i1 false, ptr %l255, !tbaa !21
  %t432 = load ptr, ptr %l254, !tbaa !29
  %t433 = icmp ne ptr %t432, null
  br i1 %t433, label %bb110, label %bb111
bb110:
  %t435 = load ptr, ptr %l254, !tbaa !29
  %t436 = load i64, ptr %t435, !range !{i64 0, i64 18}
  %t438 = icmp eq i64 %t436, 12
  store i1 %t438, ptr %l255, !tbaa !21
  br label %bb111
bb111:
  %t439 = load i1, ptr %l255, !tbaa !21
  br i1 %t439, label %bb112, label %bb113
bb112:
  %t440 = load ptr, ptr %l2, !tbaa !29
  %t442 = getelementptr { i64, [5 x i64] }, ptr %t440, i32 0, i32 1
  %t443 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t442, i32 0, i32 2
  %t444 = load ptr, ptr %t443
  store ptr %t444, ptr %l16, !tbaa !29
  br label %bb114
bb113:
  br label %bb126
bb114:
  %t446 = load ptr, ptr %l16, !tbaa !29
  %t448 = getelementptr %"compiler/typed:Seq", ptr %t446, i32 0, i32 0
  %t449 = load { i64, ptr }, ptr %t448, !tbaa !27
  store { i64, ptr } %t449, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t451 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t451, 0
  store i64 %t453, ptr %l19, !tbaa !24
  br label %bb115
bb115:
  %t455 = load i64, ptr %l18, !tbaa !24
  %t456 = load i64, ptr %l19, !tbaa !24
  %t459 = icmp slt i64 %t455, %t456
  %t461 = xor i1 %t459, true
  br i1 %t461, label %bb116, label %bb117
bb116:
  br label %bb124
bb117:
  br label %bb118
bb118:
  %t463 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t463, ptr %l268, !tbaa !27
  %t464 = load i64, ptr %l18, !tbaa !24
  %t466 = getelementptr { i64, ptr }, ptr %l268, i32 0, i32 1
  %t467 = load ptr, ptr %t466, !tbaa !27
  %t468 = getelementptr ptr, ptr %t467, i64 %t464
  %t469 = load ptr, ptr %t468, !tbaa !39
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load ptr, ptr %l1, !tbaa !29
  %t475 = load i64, ptr %l3, !tbaa !24
  %t476 = load i64, ptr %l4, !tbaa !24
  %t482 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t471, ptr %t472, ptr %t469, i64 %t475, i64 %t476)
  store i1 %t482, ptr %l277
  br label %bb119
bb119:
  %t483 = load i1, ptr %l277, !tbaa !21
  %t484 = xor i1 %t483, true
  br i1 %t484, label %bb120, label %bb121
bb120:
  store i1 false, ptr %rv
  br label %ret
bb121:
  br label %bb122
bb122:
  br label %bb123
bb123:
  %t487 = load i64, ptr %l18, !tbaa !24
  %t489 = add i64 %t487, 1
  store i64 %t489, ptr %l18, !tbaa !24
  br label %bb115
bb124:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load ptr, ptr %l1, !tbaa !29
  %t493 = load ptr, ptr %l16, !tbaa !29
  %t495 = getelementptr %"compiler/typed:Seq", ptr %t493, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !29
  %t497 = load i64, ptr %l3, !tbaa !24
  %t498 = load i64, ptr %l4, !tbaa !24
  %t504 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t491, ptr %t492, ptr %t496, i64 %t497, i64 %t498)
  store i1 %t504, ptr %l288
  br label %bb125
bb125:
  %t505 = load i1, ptr %l288, !tbaa !21
  store i1 %t505, ptr %rv
  br label %ret
bb126:
  %t506 = load ptr, ptr %l2, !tbaa !29
  store ptr %t506, ptr %l289, !tbaa !29
  store i1 false, ptr %l290, !tbaa !21
  %t507 = load ptr, ptr %l289, !tbaa !29
  %t508 = icmp ne ptr %t507, null
  br i1 %t508, label %bb127, label %bb128
bb127:
  %t510 = load ptr, ptr %l289, !tbaa !29
  %t511 = load i64, ptr %t510, !range !{i64 0, i64 18}
  %t513 = icmp eq i64 %t511, 13
  store i1 %t513, ptr %l290, !tbaa !21
  br label %bb128
bb128:
  %t514 = load i1, ptr %l290, !tbaa !21
  br i1 %t514, label %bb129, label %bb130
bb129:
  %t515 = load ptr, ptr %l2, !tbaa !29
  %t517 = getelementptr { i64, [5 x i64] }, ptr %t515, i32 0, i32 1
  %t518 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t517, i32 0, i32 2
  %t519 = load ptr, ptr %t518
  store ptr %t519, ptr %l21, !tbaa !29
  br label %bb131
bb130:
  br label %bb153
bb131:
  %t521 = load ptr, ptr %l21, !tbaa !29
  %t523 = getelementptr %"compiler/typed:Match", ptr %t521, i32 0, i32 0
  %t524 = load { i64, ptr }, ptr %t523, !tbaa !27
  store { i64, ptr } %t524, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t526 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t526, 0
  store i64 %t528, ptr %l24, !tbaa !24
  br label %bb132
bb132:
  %t530 = load i64, ptr %l23, !tbaa !24
  %t531 = load i64, ptr %l24, !tbaa !24
  %t534 = icmp slt i64 %t530, %t531
  %t536 = xor i1 %t534, true
  br i1 %t536, label %bb133, label %bb134
bb133:
  br label %bb141
bb134:
  br label %bb135
bb135:
  %t538 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t538, ptr %l303, !tbaa !27
  %t539 = load i64, ptr %l23, !tbaa !24
  %t541 = getelementptr { i64, ptr }, ptr %l303, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr ptr, ptr %t542, i64 %t539
  %t544 = load ptr, ptr %t543, !tbaa !39
  %t546 = load ptr, ptr %l0, !tbaa !29
  %t547 = load ptr, ptr %l1, !tbaa !29
  %t550 = load i64, ptr %l3, !tbaa !24
  %t551 = load i64, ptr %l4, !tbaa !24
  %t557 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t546, ptr %t547, ptr %t544, i64 %t550, i64 %t551)
  store i1 %t557, ptr %l312
  br label %bb136
bb136:
  %t558 = load i1, ptr %l312, !tbaa !21
  %t559 = xor i1 %t558, true
  br i1 %t559, label %bb137, label %bb138
bb137:
  store i1 false, ptr %rv
  br label %ret
bb138:
  br label %bb139
bb139:
  br label %bb140
bb140:
  %t562 = load i64, ptr %l23, !tbaa !24
  %t564 = add i64 %t562, 1
  store i64 %t564, ptr %l23, !tbaa !24
  br label %bb132
bb141:
  %t566 = load ptr, ptr %l21, !tbaa !29
  %t568 = getelementptr %"compiler/typed:Match", ptr %t566, i32 0, i32 1
  %t569 = load { i64, ptr }, ptr %t568, !tbaa !27
  store { i64, ptr } %t569, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t571 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t573 = extractvalue { i64, ptr } %t571, 0
  store i64 %t573, ptr %l28, !tbaa !24
  br label %bb142
bb142:
  %t575 = load i64, ptr %l27, !tbaa !24
  %t576 = load i64, ptr %l28, !tbaa !24
  %t579 = icmp slt i64 %t575, %t576
  %t581 = xor i1 %t579, true
  br i1 %t581, label %bb143, label %bb144
bb143:
  br label %bb151
bb144:
  br label %bb145
bb145:
  %t583 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t583, ptr %l325, !tbaa !27
  %t584 = load i64, ptr %l27, !tbaa !24
  %t586 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t587 = load ptr, ptr %t586, !tbaa !27
  %t588 = getelementptr ptr, ptr %t587, i64 %t584
  %t589 = load ptr, ptr %t588, !tbaa !39
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t592 = load ptr, ptr %l1, !tbaa !29
  %t595 = load i64, ptr %l3, !tbaa !24
  %t596 = load i64, ptr %l4, !tbaa !24
  %t602 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueArm(ptr %v0, ptr %v1, ptr %v2, ptr %t591, ptr %t592, ptr %t589, i64 %t595, i64 %t596)
  store i1 %t602, ptr %l334
  br label %bb146
bb146:
  %t603 = load i1, ptr %l334, !tbaa !21
  %t604 = xor i1 %t603, true
  br i1 %t604, label %bb147, label %bb148
bb147:
  store i1 false, ptr %rv
  br label %ret
bb148:
  br label %bb149
bb149:
  br label %bb150
bb150:
  %t607 = load i64, ptr %l27, !tbaa !24
  %t609 = add i64 %t607, 1
  store i64 %t609, ptr %l27, !tbaa !24
  br label %bb142
bb151:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t612 = load ptr, ptr %l1, !tbaa !29
  %t613 = load ptr, ptr %l21, !tbaa !29
  %t615 = getelementptr %"compiler/typed:Match", ptr %t613, i32 0, i32 2
  %t616 = load ptr, ptr %t615, !tbaa !29
  %t617 = load i64, ptr %l3, !tbaa !24
  %t618 = load i64, ptr %l4, !tbaa !24
  %t624 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueArm(ptr %v0, ptr %v1, ptr %v2, ptr %t611, ptr %t612, ptr %t616, i64 %t617, i64 %t618)
  store i1 %t624, ptr %l345
  br label %bb152
bb152:
  %t625 = load i1, ptr %l345, !tbaa !21
  store i1 %t625, ptr %rv
  br label %ret
bb153:
  %t626 = load ptr, ptr %l2, !tbaa !29
  store ptr %t626, ptr %l346, !tbaa !29
  store i1 false, ptr %l347, !tbaa !21
  %t627 = load ptr, ptr %l346, !tbaa !29
  %t628 = icmp ne ptr %t627, null
  br i1 %t628, label %bb154, label %bb155
bb154:
  %t630 = load ptr, ptr %l346, !tbaa !29
  %t631 = load i64, ptr %t630, !range !{i64 0, i64 18}
  %t633 = icmp eq i64 %t631, 14
  store i1 %t633, ptr %l347, !tbaa !21
  br label %bb155
bb155:
  %t634 = load i1, ptr %l347, !tbaa !21
  br i1 %t634, label %bb156, label %bb157
bb156:
  %t635 = load ptr, ptr %l2, !tbaa !29
  %t637 = getelementptr { i64, [5 x i64] }, ptr %t635, i32 0, i32 1
  %t638 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t637, i32 0, i32 2
  %t639 = load ptr, ptr %t638
  store ptr %t639, ptr %l30, !tbaa !29
  br label %bb158
bb157:
  br label %bb177
bb158:
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load ptr, ptr %l1, !tbaa !29
  %t643 = load ptr, ptr %l30, !tbaa !29
  %t645 = getelementptr %"compiler/typed:Try", ptr %t643, i32 0, i32 0
  %t646 = load ptr, ptr %t645, !tbaa !29
  %t647 = load i64, ptr %l3, !tbaa !24
  %t648 = load i64, ptr %l4, !tbaa !24
  %t654 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t641, ptr %t642, ptr %t646, i64 %t647, i64 %t648)
  store i1 %t654, ptr %l358
  br label %bb159
bb159:
  %t655 = load i1, ptr %l358, !tbaa !21
  %t656 = xor i1 %t655, true
  br i1 %t656, label %bb160, label %bb161
bb160:
  store i1 false, ptr %rv
  br label %ret
bb161:
  br label %bb162
bb162:
  %t659 = load ptr, ptr %l30, !tbaa !29
  %t661 = getelementptr %"compiler/typed:Try", ptr %t659, i32 0, i32 1
  %t662 = load { i64, ptr }, ptr %t661, !tbaa !27
  store { i64, ptr } %t662, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t664 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t666 = extractvalue { i64, ptr } %t664, 0
  store i64 %t666, ptr %l33, !tbaa !24
  br label %bb163
bb163:
  %t668 = load i64, ptr %l32, !tbaa !24
  %t669 = load i64, ptr %l33, !tbaa !24
  %t672 = icmp slt i64 %t668, %t669
  %t674 = xor i1 %t672, true
  br i1 %t674, label %bb164, label %bb165
bb164:
  br label %bb176
bb165:
  br label %bb166
bb166:
  %t676 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t676, ptr %l369, !tbaa !27
  %t677 = load i64, ptr %l32, !tbaa !24
  %t679 = getelementptr { i64, ptr }, ptr %l369, i32 0, i32 1
  %t680 = load ptr, ptr %t679, !tbaa !27
  %t681 = getelementptr ptr, ptr %t680, i64 %t677
  %t682 = load ptr, ptr %t681, !tbaa !39
  store ptr %t682, ptr %l34, !tbaa !29
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t685 = load ptr, ptr %l1, !tbaa !29
  %t686 = load ptr, ptr %l34, !tbaa !29
  %t688 = getelementptr %"compiler/typed:Clause", ptr %t686, i32 0, i32 3
  %t689 = load ptr, ptr %t688, !tbaa !29
  %t690 = load i64, ptr %l3, !tbaa !24
  %t691 = load i64, ptr %l4, !tbaa !24
  %t697 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t684, ptr %t685, ptr %t689, i64 %t690, i64 %t691)
  store i1 %t697, ptr %l378
  br label %bb167
bb167:
  %t698 = load i1, ptr %l378, !tbaa !21
  %t699 = xor i1 %t698, true
  br i1 %t699, label %bb168, label %bb169
bb168:
  store i1 true, ptr %l380, !tbaa !21
  br label %bb171
bb169:
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t702 = load ptr, ptr %l1, !tbaa !29
  %t703 = load ptr, ptr %l34, !tbaa !29
  %t705 = getelementptr %"compiler/typed:Clause", ptr %t703, i32 0, i32 4
  %t706 = load { i64, ptr }, ptr %t705, !tbaa !27
  %t707 = load i64, ptr %l3, !tbaa !24
  %t708 = load i64, ptr %l4, !tbaa !24
  %t714 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExprs(ptr %v0, ptr %v1, ptr %v2, ptr %t701, ptr %t702, { i64, ptr } %t706, i64 %t707, i64 %t708)
  store i1 %t714, ptr %l387
  br label %bb170
bb170:
  %t715 = load i1, ptr %l387, !tbaa !21
  %t716 = xor i1 %t715, true
  store i1 %t716, ptr %l380, !tbaa !21
  br label %bb171
bb171:
  %t718 = load i1, ptr %l380, !tbaa !21
  br i1 %t718, label %bb172, label %bb173
bb172:
  store i1 false, ptr %rv
  br label %ret
bb173:
  br label %bb174
bb174:
  br label %bb175
bb175:
  %t720 = load i64, ptr %l32, !tbaa !24
  %t722 = add i64 %t720, 1
  store i64 %t722, ptr %l32, !tbaa !24
  br label %bb163
bb176:
  store i1 true, ptr %rv
  br label %ret
bb177:
  %t725 = load ptr, ptr %l2, !tbaa !29
  store ptr %t725, ptr %l393, !tbaa !29
  store i1 false, ptr %l394, !tbaa !21
  %t726 = load ptr, ptr %l393, !tbaa !29
  %t727 = icmp ne ptr %t726, null
  br i1 %t727, label %bb178, label %bb179
bb178:
  %t729 = load ptr, ptr %l393, !tbaa !29
  %t730 = load i64, ptr %t729, !range !{i64 0, i64 18}
  %t732 = icmp eq i64 %t730, 15
  store i1 %t732, ptr %l394, !tbaa !21
  br label %bb179
bb179:
  %t733 = load i1, ptr %l394, !tbaa !21
  br i1 %t733, label %bb180, label %bb181
bb180:
  %t734 = load ptr, ptr %l2, !tbaa !29
  %t736 = getelementptr { i64, [5 x i64] }, ptr %t734, i32 0, i32 1
  %t737 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t736, i32 0, i32 2
  %t738 = load ptr, ptr %t737
  store ptr %t738, ptr %l35, !tbaa !29
  br label %bb182
bb181:
  br label %bb212
bb182:
  %t740 = load ptr, ptr %l35, !tbaa !29
  store ptr %t740, ptr %l399, !tbaa !29
  store i1 false, ptr %l400, !tbaa !21
  %t741 = load ptr, ptr %l399, !tbaa !29
  %t742 = icmp ne ptr %t741, null
  br i1 %t742, label %bb183, label %bb184
bb183:
  %t744 = load ptr, ptr %l399, !tbaa !29
  %t745 = load i64, ptr %t744, !range !{i64 0, i64 3}
  %t747 = icmp eq i64 %t745, 2
  store i1 %t747, ptr %l400, !tbaa !21
  br label %bb184
bb184:
  %t748 = load i1, ptr %l400, !tbaa !21
  br i1 %t748, label %bb185, label %bb186
bb185:
  %t749 = load ptr, ptr %l35, !tbaa !29
  %t751 = getelementptr { i64, [4 x i64] }, ptr %t749, i32 0, i32 1
  %t752 = getelementptr { i32, ptr, i32 }, ptr %t751, i32 0, i32 0
  %t753 = load i32, ptr %t752
  store i32 %t753, ptr %l36, !tbaa !23
  %t755 = load ptr, ptr %l35, !tbaa !29
  %t757 = getelementptr { i64, [4 x i64] }, ptr %t755, i32 0, i32 1
  %t758 = getelementptr { i32, ptr, i32 }, ptr %t757, i32 0, i32 1
  %t759 = load ptr, ptr %t758
  store ptr %t759, ptr %l37, !tbaa !29
  %t761 = load ptr, ptr %l35, !tbaa !29
  %t763 = getelementptr { i64, [4 x i64] }, ptr %t761, i32 0, i32 1
  %t764 = getelementptr { i32, ptr, i32 }, ptr %t763, i32 0, i32 2
  %t765 = load i32, ptr %t764
  store i32 %t765, ptr %l38, !tbaa !23
  %t767 = load ptr, ptr %l37, !tbaa !29
  %t770 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v2, ptr %t767)
  store i64 %t770, ptr %l411
  br label %bb187
bb186:
  br label %bb192
bb187:
  %t771 = load i64, ptr %l3, !tbaa !24
  %t772 = load i64, ptr %l411, !tbaa !24
  %t774 = icmp ne i64 %t772, %t771
  br i1 %t774, label %bb188, label %bb189
bb188:
  %t776 = load ptr, ptr %l0, !tbaa !29
  %t777 = load ptr, ptr %l1, !tbaa !29
  %t778 = load ptr, ptr %l37, !tbaa !29
  %t780 = load i64, ptr %l3, !tbaa !24
  %t781 = load i64, ptr %l4, !tbaa !24
  %t787 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t776, ptr %t777, ptr %t778, i64 %t780, i64 %t781)
  store i1 %t787, ptr %l421
  br label %bb190
bb189:
  store i1 false, ptr %l414, !tbaa !21
  br label %bb191
bb190:
  %t788 = load i1, ptr %l421, !tbaa !21
  store i1 %t788, ptr %l414, !tbaa !21
  br label %bb191
bb191:
  %t789 = load i1, ptr %l414, !tbaa !21
  store i1 %t789, ptr %rv
  br label %ret
bb192:
  %t790 = load ptr, ptr %l35, !tbaa !29
  store ptr %t790, ptr %l422, !tbaa !29
  store i1 false, ptr %l423, !tbaa !21
  %t791 = load ptr, ptr %l422, !tbaa !29
  %t792 = icmp ne ptr %t791, null
  br i1 %t792, label %bb193, label %bb194
bb193:
  %t794 = load ptr, ptr %l422, !tbaa !29
  %t795 = load i64, ptr %t794, !range !{i64 0, i64 3}
  %t797 = icmp eq i64 %t795, 1
  store i1 %t797, ptr %l423, !tbaa !21
  br label %bb194
bb194:
  %t798 = load i1, ptr %l423, !tbaa !21
  %t799 = xor i1 %t798, true
  br i1 %t799, label %bb195, label %bb196
bb195:
  store i1 true, ptr %rv
  br label %ret
bb196:
  br label %bb197
bb197:
  %t802 = load ptr, ptr %l35, !tbaa !29
  %t804 = getelementptr { i64, [4 x i64] }, ptr %t802, i32 0, i32 1
  %t805 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t804, i32 0, i32 0
  %t806 = load i32, ptr %t805
  store i32 %t806, ptr %l39, !tbaa !23
  %t808 = load ptr, ptr %l35, !tbaa !29
  %t810 = getelementptr { i64, [4 x i64] }, ptr %t808, i32 0, i32 1
  %t811 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t810, i32 0, i32 1
  %t812 = load { i64, ptr }, ptr %t811
  %t814 = load ptr, ptr %l35, !tbaa !29
  %t816 = getelementptr { i64, [4 x i64] }, ptr %t814, i32 0, i32 1
  %t817 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t816, i32 0, i32 2
  %t818 = load i32, ptr %t817
  store i32 %t818, ptr %l41, !tbaa !23
  store { i64, ptr } %t812, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t822 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t824 = extractvalue { i64, ptr } %t822, 0
  store i64 %t824, ptr %l44, !tbaa !24
  br label %bb198
bb198:
  %t826 = load i64, ptr %l43, !tbaa !24
  %t827 = load i64, ptr %l44, !tbaa !24
  %t830 = icmp slt i64 %t826, %t827
  %t832 = xor i1 %t830, true
  br i1 %t832, label %bb199, label %bb200
bb199:
  br label %bb211
bb200:
  br label %bb201
bb201:
  %t834 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t834, ptr %l441, !tbaa !27
  %t835 = load i64, ptr %l43, !tbaa !24
  %t837 = getelementptr { i64, ptr }, ptr %l441, i32 0, i32 1
  %t838 = load ptr, ptr %t837, !tbaa !27
  %t839 = getelementptr ptr, ptr %t838, i64 %t835
  %t840 = load ptr, ptr %t839, !tbaa !39
  store ptr %t840, ptr %l45, !tbaa !29
  %t842 = load ptr, ptr %l45, !tbaa !29
  %t844 = getelementptr %"compiler/typed:Capture", ptr %t842, i32 0, i32 1
  %t845 = load ptr, ptr %t844, !tbaa !29
  %t848 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v2, ptr %t845)
  store i64 %t848, ptr %l447
  br label %bb202
bb202:
  %t849 = load i64, ptr %l3, !tbaa !24
  %t850 = load i64, ptr %l447, !tbaa !24
  %t852 = icmp eq i64 %t850, %t849
  br i1 %t852, label %bb203, label %bb204
bb203:
  store i1 true, ptr %l450, !tbaa !21
  br label %bb206
bb204:
  %t854 = load ptr, ptr %l0, !tbaa !29
  %t855 = load ptr, ptr %l1, !tbaa !29
  %t856 = load ptr, ptr %l45, !tbaa !29
  %t858 = getelementptr %"compiler/typed:Capture", ptr %t856, i32 0, i32 1
  %t859 = load ptr, ptr %t858, !tbaa !29
  %t861 = load i64, ptr %l3, !tbaa !24
  %t862 = load i64, ptr %l4, !tbaa !24
  %t868 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t854, ptr %t855, ptr %t859, i64 %t861, i64 %t862)
  store i1 %t868, ptr %l458
  br label %bb205
bb205:
  %t869 = load i1, ptr %l458, !tbaa !21
  %t870 = xor i1 %t869, true
  store i1 %t870, ptr %l450, !tbaa !21
  br label %bb206
bb206:
  %t872 = load i1, ptr %l450, !tbaa !21
  br i1 %t872, label %bb207, label %bb208
bb207:
  store i1 false, ptr %rv
  br label %ret
bb208:
  br label %bb209
bb209:
  br label %bb210
bb210:
  %t874 = load i64, ptr %l43, !tbaa !24
  %t876 = add i64 %t874, 1
  store i64 %t876, ptr %l43, !tbaa !24
  br label %bb198
bb211:
  store i1 true, ptr %rv
  br label %ret
bb212:
  %t879 = load ptr, ptr %l2, !tbaa !29
  store ptr %t879, ptr %l464, !tbaa !29
  store i1 false, ptr %l465, !tbaa !21
  %t880 = load ptr, ptr %l464, !tbaa !29
  %t881 = icmp ne ptr %t880, null
  br i1 %t881, label %bb213, label %bb214
bb213:
  %t883 = load ptr, ptr %l464, !tbaa !29
  %t884 = load i64, ptr %t883, !range !{i64 0, i64 18}
  %t886 = icmp eq i64 %t884, 16
  store i1 %t886, ptr %l465, !tbaa !21
  br label %bb214
bb214:
  %t887 = load i1, ptr %l465, !tbaa !21
  br i1 %t887, label %bb215, label %bb216
bb215:
  %t888 = load ptr, ptr %l2, !tbaa !29
  %t890 = getelementptr { i64, [5 x i64] }, ptr %t888, i32 0, i32 1
  %t891 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t890, i32 0, i32 2
  %t892 = load ptr, ptr %t891
  store ptr %t892, ptr %l46, !tbaa !29
  br label %bb217
bb216:
  br label %bb237
bb217:
  %t894 = load ptr, ptr %l46, !tbaa !29
  %t896 = getelementptr %"compiler/typed:Text", ptr %t894, i32 0, i32 0
  %t897 = load { i64, ptr }, ptr %t896, !tbaa !27
  store { i64, ptr } %t897, ptr %l47, !tbaa !27
  store i64 0, ptr %l48, !tbaa !24
  %t899 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t901 = extractvalue { i64, ptr } %t899, 0
  store i64 %t901, ptr %l49, !tbaa !24
  br label %bb218
bb218:
  %t903 = load i64, ptr %l48, !tbaa !24
  %t904 = load i64, ptr %l49, !tbaa !24
  %t907 = icmp slt i64 %t903, %t904
  %t909 = xor i1 %t907, true
  br i1 %t909, label %bb219, label %bb220
bb219:
  br label %bb236
bb220:
  br label %bb221
bb221:
  %t911 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t911, ptr %l478, !tbaa !27
  %t912 = load i64, ptr %l48, !tbaa !24
  %t914 = getelementptr { i64, ptr }, ptr %l478, i32 0, i32 1
  %t915 = load ptr, ptr %t914, !tbaa !27
  %t916 = getelementptr ptr, ptr %t915, i64 %t912
  %t917 = load ptr, ptr %t916, !tbaa !39
  store ptr %t917, ptr %l50, !tbaa !29
  %t919 = load ptr, ptr %l50, !tbaa !29
  store ptr %t919, ptr %l481, !tbaa !29
  store i1 false, ptr %l482, !tbaa !21
  %t920 = load ptr, ptr %l481, !tbaa !29
  %t921 = icmp ne ptr %t920, null
  br i1 %t921, label %bb222, label %bb223
bb222:
  %t923 = load ptr, ptr %l481, !tbaa !29
  %t924 = load i64, ptr %t923, !range !{i64 0, i64 2}
  %t926 = icmp eq i64 %t924, 1
  store i1 %t926, ptr %l482, !tbaa !21
  br label %bb223
bb223:
  %t927 = load i1, ptr %l482, !tbaa !21
  br i1 %t927, label %bb224, label %bb225
bb224:
  %t928 = load ptr, ptr %l50, !tbaa !29
  %t930 = getelementptr { i64, [2 x i64] }, ptr %t928, i32 0, i32 1
  %t931 = getelementptr { ptr }, ptr %t930, i32 0, i32 0
  %t932 = load ptr, ptr %t931
  store ptr %t932, ptr %l51, !tbaa !29
  %t934 = load ptr, ptr %l51, !tbaa !29
  %t937 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v2, ptr %t934)
  store i64 %t937, ptr %l490
  br label %bb226
bb225:
  store i1 false, ptr %l485, !tbaa !21
  br label %bb231
bb226:
  %t938 = load i64, ptr %l3, !tbaa !24
  %t939 = load i64, ptr %l490, !tbaa !24
  %t941 = icmp eq i64 %t939, %t938
  br i1 %t941, label %bb227, label %bb228
bb227:
  store i1 true, ptr %l493, !tbaa !21
  br label %bb230
bb228:
  %t943 = load ptr, ptr %l0, !tbaa !29
  %t944 = load ptr, ptr %l1, !tbaa !29
  %t945 = load ptr, ptr %l51, !tbaa !29
  %t947 = load i64, ptr %l3, !tbaa !24
  %t948 = load i64, ptr %l4, !tbaa !24
  %t954 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t943, ptr %t944, ptr %t945, i64 %t947, i64 %t948)
  store i1 %t954, ptr %l500
  br label %bb229
bb229:
  %t955 = load i1, ptr %l500, !tbaa !21
  %t956 = xor i1 %t955, true
  store i1 %t956, ptr %l493, !tbaa !21
  br label %bb230
bb230:
  %t958 = load i1, ptr %l493, !tbaa !21
  store i1 %t958, ptr %l485, !tbaa !21
  br label %bb231
bb231:
  %t959 = load i1, ptr %l485, !tbaa !21
  br i1 %t959, label %bb232, label %bb233
bb232:
  %t960 = load ptr, ptr %l50, !tbaa !29
  %t962 = getelementptr { i64, [2 x i64] }, ptr %t960, i32 0, i32 1
  %t963 = getelementptr { ptr }, ptr %t962, i32 0, i32 0
  %t964 = load ptr, ptr %t963
  store ptr %t964, ptr %l52, !tbaa !29
  store i1 false, ptr %rv
  br label %ret
bb233:
  br label %bb234
bb234:
  br label %bb235
bb235:
  %t967 = load i64, ptr %l48, !tbaa !24
  %t969 = add i64 %t967, 1
  store i64 %t969, ptr %l48, !tbaa !24
  br label %bb218
bb236:
  store i1 true, ptr %rv
  br label %ret
bb237:
  %t972 = load ptr, ptr %l2, !tbaa !29
  store ptr %t972, ptr %l508, !tbaa !29
  store i1 false, ptr %l509, !tbaa !21
  %t973 = load ptr, ptr %l508, !tbaa !29
  %t974 = icmp ne ptr %t973, null
  br i1 %t974, label %bb238, label %bb239
bb238:
  %t976 = load ptr, ptr %l508, !tbaa !29
  %t977 = load i64, ptr %t976, !range !{i64 0, i64 18}
  %t979 = icmp eq i64 %t977, 17
  store i1 %t979, ptr %l509, !tbaa !21
  br label %bb239
bb239:
  %t980 = load i1, ptr %l509, !tbaa !21
  br i1 %t980, label %bb240, label %bb241
bb240:
  %t981 = load ptr, ptr %l2, !tbaa !29
  %t983 = getelementptr { i64, [5 x i64] }, ptr %t981, i32 0, i32 1
  %t984 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t983, i32 0, i32 2
  %t985 = load ptr, ptr %t984
  store ptr %t985, ptr %l53, !tbaa !29
  br label %bb242
bb241:
  br label %bb244
bb242:
  %t987 = load ptr, ptr %l0, !tbaa !29
  %t988 = load ptr, ptr %l1, !tbaa !29
  %t989 = load ptr, ptr %l53, !tbaa !29
  %t991 = load i64, ptr %l3, !tbaa !24
  %t992 = load i64, ptr %l4, !tbaa !24
  %t998 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t987, ptr %t988, ptr %t989, i64 %t991, i64 %t992)
  store i1 %t998, ptr %l520
  br label %bb243
bb243:
  %t999 = load i1, ptr %l520, !tbaa !21
  store i1 %t999, ptr %rv
  br label %ret
bb244:
  br i1 true, label %bb245, label %bb246
bb245:
  br label %bb247
bb246:
  br label %bb248
bb247:
  store i1 true, ptr %rv
  br label %ret
bb248:
  call void @__olang_check_failed(ptr @olang_loc_94ea3fd5578d6989_449fcf7b944ae615)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunionRels(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i1 %a2, i32 %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %lp6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca i64
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca %"compiler/scope:rel"
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i64
  %l54 = alloca i64
  %l59 = alloca %"compiler/scope:rel"
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t2, ptr %lp6
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  %t4 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store ptr %a1, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l8, !tbaa !24
  store i64 %t7, ptr %l18, !tbaa !24
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H2a2e2bb73cbe78787fa6ff6d095e1956(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l20
  br label %bb3
bb3:
  %t11 = load i64, ptr %l18, !tbaa !24
  %t12 = load i64, ptr %l20, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t18 = load i64, ptr %l8, !tbaa !24
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H69e10a266f1cb5d26290bb9f760bc181(ptr %v1, ptr %v1, ptr %t17, i64 %t18)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l25
  br label %bb7
bb7:
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e(ptr %s2, ptr %l25)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l27
  br label %bb8
bb8:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l9
  store ptr %l9, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb9
bb9:
  %t26 = load i64, ptr %l11, !tbaa !24
  store i64 %t26, ptr %l29, !tbaa !24
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %s2, ptr %t27)
  store i64 %t29, ptr %l31
  br label %bb10
bb10:
  %t30 = load i64, ptr %l29, !tbaa !24
  %t31 = load i64, ptr %l31, !tbaa !24
  %t32 = icmp slt i64 %t30, %t31
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l10, !tbaa !29
  %t37 = load i64, ptr %l11, !tbaa !24
  %t40 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %s2, ptr %t36, i64 %t37)
  store %"compiler/scope:rel" %t40, ptr %l36
  br label %bb14
bb14:
  %t41 = load %"compiler/scope:rel", ptr %l36
  %t42 = load ptr, ptr %lp6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v3, ptr %t42, %"compiler/scope:rel" %t41)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t46 = load i64, ptr %l11, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l11, !tbaa !24
  br label %bb9
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t50 = load i64, ptr %l8, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l8, !tbaa !24
  br label %bb2
bb19:
  %t56 = xor i1 %a2, true
  br i1 %t56, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %a0, ptr %l45, !tbaa !29
  store i32 %a3, ptr %l46, !tbaa !23
  store { i64, ptr } %a4, ptr %l47, !tbaa !27
  store i64 %a5, ptr %l48, !tbaa !24
  %t62 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 0, i32 0)
  store %"compiler/source:Span" %t62, ptr %l49
  br label %bb22
bb21:
  br label %bb33
bb22:
  %t63 = load ptr, ptr %l45, !tbaa !29
  %t64 = load i32, ptr %l46, !tbaa !23
  %t65 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t66 = load i64, ptr %l48, !tbaa !24
  %t67 = load %"compiler/source:Span", ptr %l49
  %t68 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueRels(ptr %v0, ptr %v2, ptr %s8, ptr %t63, i32 %t64, { i64, ptr } %t65, i64 %t66, %"compiler/source:Span" %t67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l50
  br label %bb23
bb23:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  %t70 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %t70
  store ptr %t70, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb24
bb24:
  %t72 = load i64, ptr %l14, !tbaa !24
  store i64 %t72, ptr %l52, !tbaa !24
  %t73 = load ptr, ptr %l13, !tbaa !29
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %s8, ptr %t73)
  store i64 %t75, ptr %l54
  br label %bb25
bb25:
  %t76 = load i64, ptr %l52, !tbaa !24
  %t77 = load i64, ptr %l54, !tbaa !24
  %t78 = icmp slt i64 %t76, %t77
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb26, label %bb27
bb26:
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t82 = load ptr, ptr %l13, !tbaa !29
  %t83 = load i64, ptr %l14, !tbaa !24
  %t86 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %s8, ptr %t82, i64 %t83)
  store %"compiler/scope:rel" %t86, ptr %l59
  br label %bb29
bb29:
  %t87 = load %"compiler/scope:rel", ptr %l59
  %t88 = load ptr, ptr %lp6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v3, ptr %t88, %"compiler/scope:rel" %t87)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t92 = load i64, ptr %l14, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l14, !tbaa !24
  br label %bb24
bb32:
  call void @__olang_scope_close(ptr %s8)
  br label %bb33
bb33:
  %t96 = load ptr, ptr %lp6
  %t97 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t96
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunknownBinding(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb12
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb11
bb5:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = sub i64 0, %t14
  %t18 = sub i64 %t16, 1
  store i64 %t18, ptr %l12, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 102
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load i64, ptr %l12, !tbaa !24
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/scope:Scoper", ptr %t28, i32 0, i32 102
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 0, %t31
  %t35 = sub i64 %t33, 1
  %t38 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t30, i64 %t35)
  store i1 %t38, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb10
bb9:
  %t39 = load i1, ptr %l23, !tbaa !21
  store i1 %t39, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l17, !tbaa !21
  store i1 %t40, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  %t41 = load i1, ptr %l9, !tbaa !21
  store i1 %t41, ptr %l3, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_32e8be698fa34edf_ce62f399ed2770f3)
  unreachable
bb17:
  %t42 = load i1, ptr %l3, !tbaa !21
  store i1 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueRels(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i1
  %l40 = alloca i64
  %l43 = alloca i64
  %l61 = alloca { i64, ptr }
  %l66 = alloca i1
  %l71 = alloca i1
  %l73 = alloca { i64, ptr }
  %l76 = alloca i1
  %l78 = alloca ptr
  %l84 = alloca %"compiler/scope:rel"
  %l86 = alloca i1
  %l88 = alloca { i64, ptr }
  %l91 = alloca i1
  %l92 = alloca ptr
  %l98 = alloca %"compiler/scope:rel"
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t135 = alloca { i64, [2 x i64] }, align 8
  %t142 = alloca { i64, [2 x i64] }, align 8
  %t172 = alloca { i64, [2 x i64] }, align 8
  %t179 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp5
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t4 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %lp5
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  store ptr %t17, ptr %l21, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l26
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l21, !tbaa !29
  %t29 = load i32, ptr %l26, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l27
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l28, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l33
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = load i32, ptr %l33, !tbaa !23
  %t45 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t43, i32 %t44)
  store i1 %t45, ptr %l34
  br label %bb8
bb8:
  %t46 = load i1, ptr %l34, !tbaa !21
  store i1 %t46, ptr %l7, !tbaa !21
  store i64 0, ptr %l8, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l9, !tbaa !24
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb9, label %bb10
bb9:
  %t57 = load i64, ptr %l10, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb14
bb11:
  %t61 = load i64, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l10, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l10, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l43, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb13
bb13:
  %t77 = load i64, ptr %l43, !tbaa !24
  store i64 %t77, ptr %l40, !tbaa !24
  br label %bb14
bb14:
  %t78 = load i64, ptr %l40, !tbaa !24
  store i64 %t78, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load i64, ptr %l12, !tbaa !24
  %t80 = load i64, ptr %l11, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb17:
  br label %bb18
bb18:
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l12, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l13, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t97, ptr %l61, !tbaa !27
  %t98 = load i64, ptr %l13, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i64, ptr %t101, i64 %t98
  %t103 = load i64, ptr %t102, !tbaa !34
  store i64 %t103, ptr %l14, !tbaa !24
  %t105 = load i64, ptr %l14, !tbaa !24
  %t107 = icmp slt i64 %t105, 0
  br i1 %t107, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb21
bb20:
  %t109 = load i64, ptr %l14, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  %t115 = icmp sge i64 %t109, %t112
  store i1 %t115, ptr %l66, !tbaa !21
  br label %bb21
bb21:
  %t117 = load i1, ptr %l66, !tbaa !21
  br i1 %t117, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb25
bb23:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t119, ptr %l73, !tbaa !27
  %t120 = load i64, ptr %l14, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i32, ptr %t123, i64 %t120
  %t125 = load i32, ptr %t124, !tbaa !33
  %t128 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t118, i32 %t125)
  store i1 %t128, ptr %l76
  br label %bb24
bb24:
  %t129 = load i1, ptr %l76, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l71, !tbaa !21
  br label %bb25
bb25:
  %t132 = load i1, ptr %l71, !tbaa !21
  br i1 %t132, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t133 = load ptr, ptr %lp5
  store ptr %t133, ptr %l78, !tbaa !29
  %t134 = load i64, ptr %l13, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t135
  %t136 = getelementptr { i64, [2 x i64] }, ptr %t135, i32 0, i32 0
  store i64 2, ptr %t136
  %t138 = insertvalue { i64 } undef, i64 %t134, 0
  %t139 = getelementptr { i64, [2 x i64] }, ptr %t135, i32 0, i32 1
  store { i64 } %t138, ptr %t139
  %t140 = load { i64, [2 x i64] }, ptr %t135
  %t141 = load i64, ptr %l3, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [2 x i64] }, ptr %t142, i32 0, i32 0
  store i64 2, ptr %t143
  %t145 = insertvalue { i64 } undef, i64 %t141, 0
  %t146 = getelementptr { i64, [2 x i64] }, ptr %t142, i32 0, i32 1
  store { i64 } %t145, ptr %t146
  %t147 = load { i64, [2 x i64] }, ptr %t142
  %t148 = load %"compiler/source:Span", ptr %l4
  %t152 = call %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %s3, { i64, [2 x i64] } %t140, { i64, [2 x i64] } %t147, i1 false, %"compiler/source:Span" %t148, i64 0, i1 true)
  store %"compiler/scope:rel" %t152, ptr %l84
  br label %bb29
bb29:
  %t153 = load ptr, ptr %l78, !tbaa !29
  %t154 = load %"compiler/scope:rel", ptr %l84
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v2, ptr %t153, %"compiler/scope:rel" %t154)
  br label %bb30
bb30:
  %t155 = load i1, ptr %l7, !tbaa !21
  br i1 %t155, label %bb31, label %bb32
bb31:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t158, ptr %l88, !tbaa !27
  %t159 = load i64, ptr %l14, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t167 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t157, i32 %t164)
  store i1 %t167, ptr %l91
  br label %bb33
bb32:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb34
bb33:
  %t168 = load i1, ptr %l91, !tbaa !21
  store i1 %t168, ptr %l86, !tbaa !21
  br label %bb34
bb34:
  %t169 = load i1, ptr %l86, !tbaa !21
  br i1 %t169, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t170 = load ptr, ptr %lp5
  store ptr %t170, ptr %l92, !tbaa !29
  %t171 = load i64, ptr %l3, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t172
  %t173 = getelementptr { i64, [2 x i64] }, ptr %t172, i32 0, i32 0
  store i64 2, ptr %t173
  %t175 = insertvalue { i64 } undef, i64 %t171, 0
  %t176 = getelementptr { i64, [2 x i64] }, ptr %t172, i32 0, i32 1
  store { i64 } %t175, ptr %t176
  %t177 = load { i64, [2 x i64] }, ptr %t172
  %t178 = load i64, ptr %l13, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [2 x i64] }, ptr %t179, i32 0, i32 0
  store i64 2, ptr %t180
  %t182 = insertvalue { i64 } undef, i64 %t178, 0
  %t183 = getelementptr { i64, [2 x i64] }, ptr %t179, i32 0, i32 1
  store { i64 } %t182, ptr %t183
  %t184 = load { i64, [2 x i64] }, ptr %t179
  %t185 = load %"compiler/source:Span", ptr %l4
  %t189 = call %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %s5, { i64, [2 x i64] } %t177, { i64, [2 x i64] } %t184, i1 false, %"compiler/source:Span" %t185, i64 0, i1 true)
  store %"compiler/scope:rel" %t189, ptr %l98
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t190 = load ptr, ptr %l92, !tbaa !29
  %t191 = load %"compiler/scope:rel", ptr %l98
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v2, ptr %t190, %"compiler/scope:rel" %t191)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb40:
  %t192 = load i64, ptr %l12, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l12, !tbaa !24
  br label %bb15
bb41:
  %t196 = load ptr, ptr %lp5
  %t197 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t196
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t197, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2everEnter(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 149
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v1, ptr %a1)
  store %"compiler/source:Span" %t10, ptr %l7
  br label %bb4
bb4:
  %t11 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  %t14 = sext i32 %t12 to i64
  store i64 %t14, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 153
  %t19 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecursorTerms(ptr %v0, ptr %t22, i64 %t23)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eviewedBy(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 185
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i64 -1, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/scope:Scoper", ptr %t17, i32 0, i32 185
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l14
  br label %bb8
bb8:
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 185
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t29, i64 %t30)
  store i64 %t33, ptr %l19
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %rv
  br label %ret
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 68
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t37, i64 %t38)
  %t42 = extractvalue { i32, i64 } %t41, 1
  %t43 = extractvalue { i32, i64 } %t41, 0
  store i32 %t43, ptr %l25
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb14, label %ok.45, !prof !99
ok.45:
  store i64 %t42, ptr %l24
  br label %bb13
bb13:
  %t46 = load i64, ptr %l24, !tbaa !24
  store i64 %t46, ptr %l20, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb16
bb16:
  %t47 = load i64, ptr %l20, !tbaa !24
  store i64 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evisit(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l20 = alloca ptr
  %l32 = alloca i64
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i1
  %l69 = alloca i64
  %l72 = alloca i64
  %l77 = alloca i64
  %l84 = alloca i64
  %l88 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca i64
  %l96 = alloca i64
  %l100 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i64
  %l109 = alloca i64
  %l112 = alloca ptr
  %l113 = alloca i64
  %l117 = alloca i64
  %l123 = alloca i64
  %l127 = alloca i64
  %l130 = alloca ptr
  %l133 = alloca i64
  %l134 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 18
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 22
  %t8 = load i64, ptr %t7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4, i64 %t8)
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 19
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 22
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t14, i64 %t15, i64 %t19)
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l20, !tbaa !29
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 22
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = add i64 %t26, 1
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 22
  store i64 %t28, ptr %t31, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/scope:Scoper", ptr %t32, i32 0, i32 21
  %t35 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  br label %bb3
bb3:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 20
  %t41 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t40, i64 %t41, i1 true)
  br label %bb4
bb4:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 12
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t46, i64 %t47)
  store i64 %t50, ptr %l32
  br label %bb5
bb5:
  %t51 = load i64, ptr %l32, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/scope:Scoper", ptr %t52, i32 0, i32 12
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = add i64 %t55, 1
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t54, i64 %t57)
  store i64 %t60, ptr %l37
  br label %bb6
bb6:
  %t61 = load i64, ptr %l37, !tbaa !24
  store i64 %t61, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t62 = load i64, ptr %l3, !tbaa !24
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb7, label %bb8
bb7:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb12
bb9:
  %t72 = load i64, ptr %l3, !tbaa !24
  %t73 = load i64, ptr %l2, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l44, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb11
bb11:
  %t88 = load i64, ptr %l44, !tbaa !24
  store i64 %t88, ptr %l41, !tbaa !24
  br label %bb12
bb12:
  %t89 = load i64, ptr %l41, !tbaa !24
  store i64 %t89, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t90 = load i64, ptr %l6, !tbaa !24
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb14, label %bb15
bb14:
  br label %bb49
bb15:
  br label %bb16
bb16:
  %t98 = load i64, ptr %l2, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t100 = load i64, ptr %l4, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/scope:Scoper", ptr %t108, i32 0, i32 13
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t110, i64 %t106)
  store i64 %t114, ptr %l65
  br label %bb17
bb17:
  %t115 = load i64, ptr %l65, !tbaa !24
  store i64 %t115, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb21
bb19:
  %t120 = load i64, ptr %l8, !tbaa !24
  store i64 %t120, ptr %l69, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/scope:Scoper", ptr %t121, i32 0, i32 18
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t123)
  store i64 %t125, ptr %l72
  br label %bb20
bb20:
  %t126 = load i64, ptr %l69, !tbaa !24
  %t127 = load i64, ptr %l72, !tbaa !24
  %t128 = icmp sge i64 %t126, %t127
  store i1 %t128, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t130 = load i1, ptr %l68, !tbaa !21
  br i1 %t130, label %bb22, label %bb23
bb22:
  br label %bb48
bb23:
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/scope:Scoper", ptr %t131, i32 0, i32 18
  %t134 = load i64, ptr %l8, !tbaa !24
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t133, i64 %t134)
  store i64 %t137, ptr %l77
  br label %bb25
bb25:
  %t138 = load i64, ptr %l77, !tbaa !24
  %t139 = icmp slt i64 %t138, 0
  br i1 %t139, label %bb26, label %bb27
bb26:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evisit(ptr %v0, ptr %t141, i64 %t142)
  br label %bb28
bb27:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/scope:Scoper", ptr %t145, i32 0, i32 20
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t147, i64 %t148)
  store i1 %t151, ptr %l100
  br label %bb36
bb28:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/scope:Scoper", ptr %t152, i32 0, i32 19
  %t155 = load i64, ptr %l8, !tbaa !24
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t154, i64 %t155)
  store i64 %t158, ptr %l84
  br label %bb29
bb29:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/scope:Scoper", ptr %t159, i32 0, i32 19
  %t162 = load i64, ptr %l1, !tbaa !24
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t161, i64 %t162)
  store i64 %t165, ptr %l88
  br label %bb30
bb30:
  %t166 = load i64, ptr %l84, !tbaa !24
  %t167 = load i64, ptr %l88, !tbaa !24
  %t168 = icmp slt i64 %t166, %t167
  br i1 %t168, label %bb31, label %bb32
bb31:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/scope:Scoper", ptr %t170, i32 0, i32 19
  store ptr %t172, ptr %l91, !tbaa !29
  %t173 = load i64, ptr %l1, !tbaa !24
  store i64 %t173, ptr %l92, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %t174, i32 0, i32 19
  %t177 = load i64, ptr %l8, !tbaa !24
  %t180 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t176, i64 %t177)
  store i64 %t180, ptr %l96
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t181 = load ptr, ptr %l91, !tbaa !29
  %t182 = load i64, ptr %l92, !tbaa !24
  %t183 = load i64, ptr %l96, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t181, i64 %t182, i64 %t183)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb47
bb36:
  %t184 = load i1, ptr %l100, !tbaa !21
  br i1 %t184, label %bb37, label %bb38
bb37:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/scope:Scoper", ptr %t185, i32 0, i32 18
  %t188 = load i64, ptr %l8, !tbaa !24
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t187, i64 %t188)
  store i64 %t191, ptr %l105
  br label %bb39
bb38:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb41
bb39:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/scope:Scoper", ptr %t192, i32 0, i32 19
  %t195 = load i64, ptr %l1, !tbaa !24
  %t198 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t194, i64 %t195)
  store i64 %t198, ptr %l109
  br label %bb40
bb40:
  %t199 = load i64, ptr %l105, !tbaa !24
  %t200 = load i64, ptr %l109, !tbaa !24
  %t201 = icmp slt i64 %t199, %t200
  store i1 %t201, ptr %l101, !tbaa !21
  br label %bb41
bb41:
  %t203 = load i1, ptr %l101, !tbaa !21
  br i1 %t203, label %bb42, label %bb43
bb42:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/scope:Scoper", ptr %t204, i32 0, i32 19
  store ptr %t206, ptr %l112, !tbaa !29
  %t207 = load i64, ptr %l1, !tbaa !24
  store i64 %t207, ptr %l113, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/scope:Scoper", ptr %t208, i32 0, i32 18
  %t211 = load i64, ptr %l8, !tbaa !24
  %t214 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t210, i64 %t211)
  store i64 %t214, ptr %l117
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t215 = load ptr, ptr %l112, !tbaa !29
  %t216 = load i64, ptr %l113, !tbaa !24
  %t217 = load i64, ptr %l117, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t215, i64 %t216, i64 %t217)
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l6, !tbaa !24
  br label %bb13
bb49:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/scope:Scoper", ptr %t222, i32 0, i32 19
  %t225 = load i64, ptr %l1, !tbaa !24
  %t228 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t224, i64 %t225)
  store i64 %t228, ptr %l123
  br label %bb50
bb50:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/scope:Scoper", ptr %t229, i32 0, i32 18
  %t232 = load i64, ptr %l1, !tbaa !24
  %t235 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t231, i64 %t232)
  store i64 %t235, ptr %l127
  br label %bb51
bb51:
  %t236 = load i64, ptr %l123, !tbaa !24
  %t237 = load i64, ptr %l127, !tbaa !24
  %t238 = icmp eq i64 %t236, %t237
  br i1 %t238, label %bb52, label %bb53
bb52:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/scope:Scoper", ptr %t240, i32 0, i32 23
  store ptr %t242, ptr %l130, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/scope:Scoper", ptr %t243, i32 0, i32 24
  %t247 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t245)
  store i64 %t247, ptr %l133
  br label %bb54
bb53:
  br label %bb68
bb54:
  %t248 = load ptr, ptr %l130, !tbaa !29
  %t249 = load i64, ptr %l133, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t248, i64 %t249)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/scope:Scoper", ptr %t250, i32 0, i32 21
  %t254 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t252)
  %t255 = extractvalue { i32, i64 } %t254, 1
  %t256 = extractvalue { i32, i64 } %t254, 0
  store i32 %t256, ptr %l138
  %t257 = icmp ne i32 %t256, 0
  br i1 %t257, label %bb58, label %ok.258, !prof !99
ok.258:
  store i64 %t255, ptr %l137
  br label %bb57
bb57:
  %t259 = load i64, ptr %l137, !tbaa !24
  store i64 %t259, ptr %l134, !tbaa !24
  br label %bb60
bb58:
  br label %bb59
bb59:
  br label %bb67
bb60:
  %t260 = load i64, ptr %l134, !tbaa !24
  store i64 %t260, ptr %l9, !tbaa !24
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/scope:Scoper", ptr %t261, i32 0, i32 20
  %t264 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t263, i64 %t264, i1 false)
  br label %bb61
bb61:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/scope:Scoper", ptr %t267, i32 0, i32 24
  %t270 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t269, i64 %t270)
  br label %bb62
bb62:
  %t273 = load i64, ptr %l9, !tbaa !24
  %t274 = load i64, ptr %l1, !tbaa !24
  %t277 = icmp eq i64 %t273, %t274
  br i1 %t277, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb56
bb67:
  br label %bb68
bb68:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l49 = alloca i64
  %l50 = alloca ptr
  %l56 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l10
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = call ptr @compiler_2fscope_2eunPassed(ptr %s0, ptr %s0, ptr %t7)
  store ptr %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l11, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l13, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l3, !tbaa !29
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i64 @compiler_2fscope_2eflRoot(ptr %s0, ptr %t25)
  store i64 %t27, ptr %l20
  br label %bb8
bb8:
  %t28 = load i64, ptr %l20, !tbaa !24
  store i64 %t28, ptr %l12, !tbaa !24
  br label %bb41
bb9:
  %t29 = load ptr, ptr %l2, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t48 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowRoot(ptr %v0, ptr %s0, ptr %t44, ptr %t45)
  store i64 %t48, ptr %l29
  br label %bb15
bb15:
  %t49 = load i64, ptr %l29, !tbaa !24
  store i64 %t49, ptr %l12, !tbaa !24
  br label %bb41
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 18}
  %t57 = icmp eq i64 %t55, 5
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l5, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Promote", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t72 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %s0, ptr %t65, ptr %t69)
  store i64 %t72, ptr %l39
  br label %bb22
bb22:
  %t73 = load i64, ptr %l39, !tbaa !24
  store i64 %t73, ptr %l12, !tbaa !24
  br label %bb41
bb23:
  %t74 = load ptr, ptr %l2, !tbaa !29
  store ptr %t74, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t75 = load ptr, ptr %l40, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 18}
  %t81 = icmp eq i64 %t79, 12
  store i1 %t81, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t82 = load i1, ptr %l41, !tbaa !21
  br i1 %t82, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l6, !tbaa !29
  br label %bb28
bb27:
  br label %bb36
bb28:
  %t89 = load ptr, ptr %l6, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Seq", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb29, label %bb30
bb29:
  store i64 -1, ptr %l49, !tbaa !24
  br label %bb35
bb30:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l50, !tbaa !29
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Seq", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  br i1 %t102, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_2604b54ceaf5ac58_8a6d930b5e8314fc)
  unreachable
bb32:
  br label %bb33
bb33:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Seq", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t108 = load ptr, ptr %l50, !tbaa !29
  %t110 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewholeRoot(ptr %v0, ptr %s0, ptr %t108, ptr %t107)
  store i64 %t110, ptr %l56
  br label %bb34
bb34:
  %t111 = load i64, ptr %l56, !tbaa !24
  store i64 %t111, ptr %l49, !tbaa !24
  br label %bb35
bb35:
  %t112 = load i64, ptr %l49, !tbaa !24
  store i64 %t112, ptr %l12, !tbaa !24
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_fee63ae15dece90e_627da4ca7452ed92)
  unreachable
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load i64, ptr %l12, !tbaa !24
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l70 = alloca i1
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l83 = alloca i1
  %l87 = alloca i1
  %l88 = alloca { i64, ptr }
  %l92 = alloca i1
  %l100 = alloca i1
  %l101 = alloca { i64, ptr }
  %l107 = alloca i1
  %l115 = alloca %"compiler/source:Span"
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l13, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 25
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_eb4644f0af45390e_1376074f3833ad62)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l13, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l22
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l21
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t26, ptr %l11, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l11, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  store i64 %t31, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t39 = icmp slt i64 %t33, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l30, !tbaa !27
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = icmp ne i8 %t47, 10
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l29, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l4, !tbaa !24
  br label %bb15
bb15:
  br label %bb8
bb16:
  %t58 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  store i64 %t61, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb17, label %bb18
bb17:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb22
bb19:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t76 = load i64, ptr %l5, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l7, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l46, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb21
bb21:
  %t91 = load i64, ptr %l46, !tbaa !24
  store i64 %t91, ptr %l43, !tbaa !24
  br label %bb22
bb22:
  %t92 = load i64, ptr %l43, !tbaa !24
  store i64 %t92, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb56
bb25:
  br label %bb26
bb26:
  %t101 = load i64, ptr %l5, !tbaa !24
  %t102 = load i64, ptr %l9, !tbaa !24
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l10, !tbaa !24
  %t111 = load i64, ptr %l10, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = add i64 %t111, %t114
  %t118 = load i64, ptr %l4, !tbaa !24
  %t121 = icmp sgt i64 %t117, %t118
  br i1 %t121, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb36
bb28:
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t123, ptr %l71, !tbaa !27
  %t124 = load i64, ptr %l10, !tbaa !24
  store i64 %t124, ptr %l72, !tbaa !24
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t131 = add i64 %t125, %t128
  store i64 %t131, ptr %l76, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 0
  store i64 %t133, ptr %l77, !tbaa !24
  %t134 = load i64, ptr %l72, !tbaa !24
  %t135 = icmp sge i64 %t134, 0
  br i1 %t135, label %bb29, label %bb30
bb29:
  %t137 = load i64, ptr %l72, !tbaa !24
  %t138 = load i64, ptr %l76, !tbaa !24
  %t139 = icmp sle i64 %t137, %t138
  br i1 %t139, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_d7bea1f8c4fc6c43_c97bd86ee0afa2f7)
  unreachable
bb31:
  %t141 = load i64, ptr %l76, !tbaa !24
  %t142 = load i64, ptr %l77, !tbaa !24
  %t143 = icmp sle i64 %t141, %t142
  br i1 %t143, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_d7bea1f8c4fc6c43_c97bd86ee0afa2f7)
  unreachable
bb33:
  %t145 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l72, !tbaa !24
  %t148 = load i64, ptr %l76, !tbaa !24
  %t149 = getelementptr i8, ptr %t146, i64 %t147
  %t150 = sub i64 %t148, %t147
  %t151 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t149, 1
  %t153 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t156 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t152, { i64, ptr } %t153)
  store i1 %t156, ptr %l83
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d7bea1f8c4fc6c43_c97bd86ee0afa2f7)
  unreachable
bb35:
  %t157 = load i1, ptr %l83, !tbaa !21
  %t158 = xor i1 %t157, true
  store i1 %t158, ptr %l70, !tbaa !21
  br label %bb36
bb36:
  %t160 = load i1, ptr %l70, !tbaa !21
  br i1 %t160, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb38:
  br label %bb39
bb39:
  %t161 = load i64, ptr %l10, !tbaa !24
  %t163 = icmp sgt i64 %t161, 0
  br i1 %t163, label %bb40, label %bb41
bb40:
  %t165 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t165, ptr %l88, !tbaa !27
  %t166 = load i64, ptr %l10, !tbaa !24
  %t168 = sub i64 %t166, 1
  %t170 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i8, ptr %t171, i64 %t168
  %t173 = load i8, ptr %t172, !tbaa !32
  %t175 = call i1 @compiler_2fscope_2eisNameChar(i8 %t173)
  store i1 %t175, ptr %l92
  br label %bb42
bb41:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb43
bb42:
  %t176 = load i1, ptr %l92, !tbaa !21
  store i1 %t176, ptr %l87, !tbaa !21
  br label %bb43
bb43:
  %t177 = load i1, ptr %l87, !tbaa !21
  br i1 %t177, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb45:
  br label %bb46
bb46:
  %t178 = load i64, ptr %l10, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t184 = add i64 %t178, %t181
  %t185 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t190 = icmp slt i64 %t184, %t187
  br i1 %t190, label %bb47, label %bb48
bb47:
  %t192 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t192, ptr %l101, !tbaa !27
  %t193 = load i64, ptr %l10, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t199 = add i64 %t193, %t196
  %t201 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr i8, ptr %t202, i64 %t199
  %t204 = load i8, ptr %t203, !tbaa !32
  %t206 = call i1 @compiler_2fscope_2eisNameChar(i8 %t204)
  store i1 %t206, ptr %l107
  br label %bb49
bb48:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb50
bb49:
  %t207 = load i1, ptr %l107, !tbaa !21
  store i1 %t207, ptr %l100, !tbaa !21
  br label %bb50
bb50:
  %t208 = load i1, ptr %l100, !tbaa !21
  br i1 %t208, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s3)
  br label %bb55
bb52:
  br label %bb53
bb53:
  %t209 = load i64, ptr %l10, !tbaa !24
  %t211 = trunc i64 %t209 to i32
  %t212 = load i64, ptr %l10, !tbaa !24
  %t213 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t218 = add i64 %t212, %t215
  %t220 = trunc i64 %t218 to i32
  %t223 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t211, i32 %t220)
  store %"compiler/source:Span" %t223, ptr %l115
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s3)
  %t224 = load %"compiler/source:Span", ptr %l115
  store %"compiler/source:Span" %t224, ptr %rv
  br label %ret
bb55:
  %t225 = load i64, ptr %l9, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l9, !tbaa !24
  br label %bb23
bb56:
  %t229 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t229, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fscope_2ecopiedRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 6
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l3, !tbaa !21
  br label %bb20
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 17
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l2, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = call i1 @compiler_2fscope_2ecopiedRead(ptr %v0, ptr %t42)
  store i1 %t44, ptr %l22
  br label %bb14
bb14:
  %t45 = load i1, ptr %l22, !tbaa !21
  store i1 %t45, ptr %l3, !tbaa !21
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_825a81e7f5138d1b_866e780fc6f79e3f)
  unreachable
bb20:
  %t46 = load i1, ptr %l3, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ekeepRel(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/scope:rel"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i1
  %l12 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l40 = alloca %"compiler/scope:rel"
  %l41 = alloca { i64, [2 x i64] }
  %l43 = alloca { i64, [2 x i64] }
  %l45 = alloca i1
  %l47 = alloca i1
  %l51 = alloca %"compiler/scope:rel"
  %l52 = alloca { i64, [2 x i64] }
  %l54 = alloca { i64, [2 x i64] }
  %l56 = alloca i1
  %l58 = alloca i1
  %l62 = alloca %"compiler/scope:rel"
  %l72 = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/scope:rel" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load i64, ptr %l12, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l19, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l19, !tbaa !24
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l16, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb31
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t51, i64 %t53)
  store %"compiler/scope:rel" %t56, ptr %l40
  br label %bb12
bb12:
  %t57 = getelementptr %"compiler/scope:rel", ptr %l40, i32 0, i32 0
  %t58 = load { i64, [2 x i64] }, ptr %t57
  store { i64, [2 x i64] } %t58, ptr %l41
  %t59 = getelementptr %"compiler/scope:rel", ptr %l1, i32 0, i32 0
  %t60 = load { i64, [2 x i64] }, ptr %t59
  store { i64, [2 x i64] } %t60, ptr %l43
  %t63 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l41, ptr %l43)
  store i1 %t63, ptr %l45
  br label %bb13
bb13:
  %t64 = load i1, ptr %l45, !tbaa !21
  %t65 = xor i1 %t64, true
  br i1 %t65, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb18
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t67, i64 %t69)
  store %"compiler/scope:rel" %t72, ptr %l51
  br label %bb16
bb16:
  %t73 = getelementptr %"compiler/scope:rel", ptr %l51, i32 0, i32 1
  %t74 = load { i64, [2 x i64] }, ptr %t73
  store { i64, [2 x i64] } %t74, ptr %l52
  %t75 = getelementptr %"compiler/scope:rel", ptr %l1, i32 0, i32 1
  %t76 = load { i64, [2 x i64] }, ptr %t75
  store { i64, [2 x i64] } %t76, ptr %l54
  %t79 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l52, ptr %l54)
  store i1 %t79, ptr %l56
  br label %bb17
bb17:
  %t80 = load i1, ptr %l56, !tbaa !21
  %t81 = xor i1 %t80, true
  store i1 %t81, ptr %l47, !tbaa !21
  br label %bb18
bb18:
  %t83 = load i1, ptr %l47, !tbaa !21
  br i1 %t83, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb22
bb20:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l7, !tbaa !24
  %t89 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t84, i64 %t86)
  store %"compiler/scope:rel" %t89, ptr %l62
  br label %bb21
bb21:
  %t90 = getelementptr %"compiler/scope:rel", ptr %l62, i32 0, i32 2
  %t91 = load i1, ptr %t90, !tbaa !21
  %t92 = getelementptr %"compiler/scope:rel", ptr %l1, i32 0, i32 2
  %t93 = load i1, ptr %t92, !tbaa !21
  %t96 = icmp ne i1 %t91, %t93
  store i1 %t96, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t98 = load i1, ptr %l58, !tbaa !21
  br i1 %t98, label %bb23, label %bb24
bb23:
  br label %bb30
bb24:
  br label %bb25
bb25:
  %t99 = getelementptr %"compiler/scope:rel", ptr %l1, i32 0, i32 5
  %t100 = load i1, ptr %t99, !tbaa !21
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb26, label %bb27
bb26:
  %t104 = load i64, ptr %l7, !tbaa !24
  store i1 false, ptr %l9, !tbaa !21
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t111 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eRefMut_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %v0, ptr %t106, i64 %t104)
  store ptr %t111, ptr %l72
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t112 = load ptr, ptr %l72, !tbaa !29
  %t114 = load i1, ptr %l9, !tbaa !21
  %t117 = getelementptr %"compiler/scope:rel", ptr %t112, i32 0, i32 5
  store i1 %t114, ptr %t117, !tbaa !21
  br label %bb29
bb29:
  br label %ret
bb30:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l6, !tbaa !24
  br label %bb8
bb31:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load %"compiler/scope:rel", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t122, %"compiler/scope:rel" %t123)
  br label %bb32
bb32:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %v0, i32 %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %rv = alloca %"compiler/scope:Val"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/scope:Val" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/scope:Val" %t6, { i64, [2 x i64] } %a1, 1
  store %"compiler/scope:Val" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local %"compiler/scope:placeSlot" @compiler_2fscope_3aplaceSlot_2ector(ptr %v0, { i64, [2 x i64] } %a0, i1 %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/scope:placeSlot"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/scope:placeSlot" undef, { i64, [2 x i64] } %a0, 0
  %t10 = insertvalue %"compiler/scope:placeSlot" %t8, i1 %a1, 1
  %t12 = insertvalue %"compiler/scope:placeSlot" %t10, i64 %a2, 2
  store %"compiler/scope:placeSlot" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:placeSlot", ptr %rv
  ret %"compiler/scope:placeSlot" %rr
}

define dso_local %"compiler/scope:rel" @compiler_2fscope_3arel_2ector(ptr %v0, { i64, [2 x i64] } %a0, { i64, [2 x i64] } %a1, i1 %a2, %"compiler/source:Span" %a3, i64 %a4, i1 %a5) #0 {
entry:
  %rv = alloca %"compiler/scope:rel"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/scope:rel" undef, { i64, [2 x i64] } %a0, 0
  %t16 = insertvalue %"compiler/scope:rel" %t14, { i64, [2 x i64] } %a1, 1
  %t18 = insertvalue %"compiler/scope:rel" %t16, i1 %a2, 2
  %t20 = insertvalue %"compiler/scope:rel" %t18, %"compiler/source:Span" %a3, 3
  %t22 = insertvalue %"compiler/scope:rel" %t20, i64 %a4, 4
  %t24 = insertvalue %"compiler/scope:rel" %t22, i1 %a5, 5
  store %"compiler/scope:rel" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:rel", ptr %rv
  ret %"compiler/scope:rel" %rr
}

define dso_local %"compiler/scope:sumRead" @compiler_2fscope_3asumRead_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1) #0 {
entry:
  %rv = alloca %"compiler/scope:sumRead"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/scope:sumRead" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/scope:sumRead" %t6, ptr %a1, 1
  store %"compiler/scope:sumRead" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:sumRead", ptr %rv
  ret %"compiler/scope:sumRead" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"compiler/scope:fnRecs" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fscope_3afnRecs(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/scope:fnRecs"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/scope:fnRecs"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/scope:fnRecs", ptr %a0
  store %"compiler/scope:fnRecs" %t2, ptr %l1
  %t3 = getelementptr %"compiler/scope:fnRecs", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/scope:fnRecs", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = getelementptr %"compiler/scope:fnRecs", ptr %l1, i32 0, i32 2
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l5
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t12 = getelementptr %"compiler/scope:fnRecs", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %t12
  %t13 = getelementptr %"compiler/scope:fnRecs", ptr %l1, i32 0, i32 3
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l7
  br label %bb3
bb3:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t17 = getelementptr %"compiler/scope:fnRecs", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t17
  %t18 = load %"compiler/scope:fnRecs", ptr %l1
  store %"compiler/scope:fnRecs" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:fnRecs", ptr %rv
  ret %"compiler/scope:fnRecs" %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 7}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 5, label %bb7 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load i1, ptr %l2, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d3 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
define linkonce_odr %"compiler/scope:fnRec" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fscope_3afnRec(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/scope:fnRec"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/scope:fnRec"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/scope:fnRec", ptr %a0
  store %"compiler/scope:fnRec" %t2, ptr %l1
  %t3 = getelementptr %"compiler/scope:fnRec", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/scope:fnRec", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/scope:fnRec", ptr %l1
  store %"compiler/scope:fnRec" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:fnRec", ptr %rv
  ret %"compiler/scope:fnRec" %rr
}

@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"x" }>, align 8
@.d7 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"lift version " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2fscope_3aTerm(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 7}
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  br label %bb1
bb3:
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t8, i64 %t9)
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t15 = sext i32 %t13 to i64
  %t16 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %t15)
  call void @__olang_sb_add(ptr %v0, i64 %t17)
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t18, i64 %t19)
  br label %bb1
bb4:
  %t20 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t20, i64 %t21)
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t22, i64 %t23)
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 1
  %t26 = getelementptr { i64 }, ptr %t25, i32 0, i32 0
  %t27 = load i64, ptr %t26
  %t29 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %t27)
  call void @__olang_sb_add(ptr %v0, i64 %t30)
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb5:
  %t33 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb6:
  %t35 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 1
  %t41 = getelementptr { i64, i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  %t44 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t45 = call i64 @__olang_fmt_i64(ptr %t44, i64 %t42)
  call void @__olang_sb_add(ptr %v0, i64 %t45)
  %t46 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t46, i64 %t47)
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 1
  %t50 = getelementptr { i64, i64 }, ptr %t49, i32 0, i32 1
  %t51 = load i64, ptr %t50
  %t53 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t54 = call i64 @__olang_fmt_i64(ptr %t53, i64 %t51)
  call void @__olang_sb_add(ptr %v0, i64 %t54)
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  br label %bb1
bb7:
  %t57 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t57, i64 %t58)
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t59, i64 %t60)
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr { i64, [2 x i64] }, ptr %t61, i32 0, i32 1
  %t63 = getelementptr { i64 }, ptr %t62, i32 0, i32 0
  %t64 = load i64, ptr %t63
  %t66 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t67 = call i64 @__olang_fmt_i64(ptr %t66, i64 %t64)
  call void @__olang_sb_add(ptr %v0, i64 %t67)
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t68, i64 %t69)
  br label %bb1
bb8:
  %t70 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t70, i64 %t71)
  br label %bb1
ret:
  ret void
}

@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" | " }>, align 8
declare void @__olang_sb_done(ptr)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define internal i1 @olang_lambda_10(ptr %env, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 80
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 80
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2fscope_3afnRec_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare ptr @__olang_sb_grow(ptr, i64) noinline
@.d12 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"scope.Term.None" }>, align 8
@.d13 = private unnamed_addr constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"scope.Term.Block" }>, align 8
@.d14 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d15 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d16 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"scope.Term.Var" }>, align 8
@.d17 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"scope.Term.Program" }>, align 8
@.d18 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"scope.Term.Derived" }>, align 8
@.d19 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d20 = private unnamed_addr constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"scope.Term.Set" }>, align 8
@.d21 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"scope.Term.Untraced" }>, align 8
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2fscope_3afnRec_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/scope:fnRec"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 48
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/scope:fnRec", ptr %t14, i64 %t12
  %t17 = call %"compiler/scope:fnRec" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fscope_3afnRec(ptr %v0, ptr %t15)
  store %"compiler/scope:fnRec" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/scope:fnRec", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/scope:fnRec", ptr %t22, i64 %t20
  store %"compiler/scope:fnRec" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %a0)
declare i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecollectField(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecollectPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_1f46f0e2a5866641_40fe5c75700827d5 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisCursorLocal(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f0350fc91fe6e1d6_3a4336dcacad1f0a = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereachFor(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3afnRecs_3e__H4d9dd4678cabff1b2f88ea0996ab01db(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/scope:fnRecs" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3afnRecs_3e__Hf28901f23b5d22676a93f0159a8b63c2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/scope:fnRecs" @compiler_2fscope_3afnRecs_2ector(ptr %v0)
declare void @compiler_2fscope_2emergeRecs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eassignedWhole(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc57530578add1ad359c6d87470cc4752(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddRecs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_94d65e4b75f62e06_97039da03323bd42 = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_96f6f37c4f8350ed_c50a63a27885a929 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionKind(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e45607aaa9337dcf_7e22bcf5356f305b = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etransient(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandArgPart(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4, i64 %a5, { i64, [2 x i64] } %a6)
declare %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb4ab14fd1aa8deeb21095c3402461540(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elentLoopCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownsUnshared(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeKeepsArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeStoresArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleePutsArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewantPromotion(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitRefused(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_aa04e26a4d7578a7_d714aefedcea6ccb = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecursorAssign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ePartOf(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/scope:placeSlot" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2, i1 %a3, ptr %a4, i64 %a5)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efreshIntoUnknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, [2 x i64] } %a3)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePop__He26954e073d6f40019e862398a9b5f5c(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitBorrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2ftyped_2eCall_2eOf(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eeqAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteLate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindingUnknown(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFieldBindingUnknown(ptr %v0)
@G_2ecompiler_2fscope_2eFitGlobal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOutlivesArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethroughLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunderOf(ptr %v0, ptr %a0, %"compiler/scope:verAtom" %a1)
@olang_loc_707d6e13efba424b_e32702988c40a9af = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0)
declare %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e450486563db1063_185cf2ae254ae0bf = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebndStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fscope_2eBndTask = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebndExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_2b4fe6e94d6a7479_c916946ab1cc6fcd = external constant [0 x i8]
@olang_loc_1cbcbb68212d18c9_a0b41c71999484fd = external constant [0 x i8]
declare { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_3e89652ff7706bd0_4686e7e94f816f94 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4)
@olang_loc_ae19eb3dd0d17d29_4ac15fb0aa0c6205 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsStores(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeBuilds(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorBuilt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_a571972fdacfaed1_c7933b0216b7b5ad = external constant [0 x i8]
@olang_loc_9f9bf081c1674640_32724a584f79d5fc = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastsUntil(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
@olang_loc_9e4942b53b152c4c_8e08edd23a0a3ef8 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnCaptureTooShort(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnFuncTooShort(ptr %v0)
@olang_loc_e7f077513292cd77_7cc56e961d13405b = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ederivedOf({ i64, [2 x i64] } %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eregionLocals(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisLambda(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_24c83be0c0349755_6420fa2832beca31 = external constant [0 x i8]
@olang_loc_e0078e28944a7d64_c2d2e4e393ff4620 = external constant [0 x i8]
declare i64 @compiler_2fscope_2evarOf({ i64, [2 x i64] } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamVarType(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H84f9774226d7b378ef632445c463492d(ptr %v0, ptr %a0)
@olang_loc_8eda7b5b464b0834_f721fd871dc79a60 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueRegions(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_c1f751d19da60dc3_9664dc07dd21977f = external constant [0 x i8]
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Heebd28230b8fdd871dbb93ccdeb5ff7f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
@olang_loc_f5c0dd4304aa3f4e_d3ec1bfd2e5f3d82 = external constant [0 x i8]
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eRowOf(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eSigOf(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eSetAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eReachRow(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edefTermAt(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eaddToSet(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esameTerms(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, ptr %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etermOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_b79eb6ae90738dac_dd72f768f22d9fa0 = external constant [0 x i8]
@olang_loc_d29996678377eee3_d1b974339c283baf = external constant [0 x i8]
@olang_loc_f1651a5ea92fc764_7e198d85ea96f48 = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eExportObligation(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3d4ddf74a6173f57_410f107a77dd9b9b = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd10c34cdbfb7fa3abdb8b5399b1b7292(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, { i64, [1 x i64] } %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_7fbb74a7c576c4fd_63f758b49396c059 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eflExprRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e9ea5d5d3867ce51_dfb99b888a23f285 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4527323723b724269d0557de47b57e0e(ptr %v0, ptr %a0)
@olang_loc_9860a08c2c4d05d2_294127fb02ae07ae = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePop_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fscope_2eUseThru = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euses(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
@olang_loc_10bab568b406970b_66071842e5074daf = external constant [0 x i8]
@olang_loc_eb97c951d9e697cc_139ecfedaca533c8 = external constant [0 x i8]
@olang_loc_97396c871582ed15_57852cddb00c7721 = external constant [0 x i8]
@olang_loc_4e30153e8dd87e24_c063a5f8ea87c90 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonlyCalled(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
@olang_loc_fc6a508fadcedae3_fc22fb2e32e5f087 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeepParam(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8b1069152ab8ab4d_46bfa78d80464041 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2eregionRoot(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwCapture(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i1 %a3)
@olang_loc_da7e2501b5a1c31c_336a9d74a1bc00b0 = external constant [0 x i8]
@olang_loc_1bad1049d3f03857_11a2742c169a90eb = external constant [0 x i8]
@olang_loc_38b65f81bf15a4b6_abe96c91b906622a = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwValueArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, { i64, ptr } %a4, i1 %a5)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreParam(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eLen_3ccompiler_2fscope_3afnRec_3e(ptr %v0, ptr %a0)
declare %"compiler/scope:fnRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2eAt_3ccompiler_2fscope_3afnRec_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumStores(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esumKeeps(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnRec_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_40f69a1a72292384_3f2388abecda0b30 = external constant [0 x i8]
declare i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enamedRecs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fscope_2eaddRec(ptr %v0, ptr %v1, ptr %a0, %"compiler/scope:fnRec" %a1)
@olang_loc_2b2b1c5bca7382ee_3254cae318351912 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_He8fa2eab054d0b98ccbd3d6295fac885(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H38f9aff1b0310316a48dc5a28922f96e(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftOf(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoinTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowed(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3615f8c81297be95_8f4c76758aae1d39 = external constant [0 x i8]
@olang_loc_8512c8e5a34c1680_11a04901f462dc84 = external constant [0 x i8]
@olang_loc_271e9ecf5549331f_fa1bdfb41feb4a53 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindLocal(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_333095c8aa3d0ed2_eefb3089191ecb2e = external constant [0 x i8]
@G_2ecompiler_2fscope_2eFitLocal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_eb3169e1e84098f9_8a2d6a085cc5aad5 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLands(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalTerm(ptr %v0, ptr %a0, %"compiler/scope:Val" %a1, { i64, [2 x i64] } %a2)
@olang_loc_9577440ef01a2a6b_ad29297969b69207 = external constant [0 x i8]
@olang_loc_24ce0aa2bd73a813_181dbbf328082c5f = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarkTerm(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1, i32 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunknownMark(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4e3f45266a1861e5_407b603c1e8329c9 = external constant [0 x i8]
@G_2ecompiler_2fscope_2eWhyField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2, i1 %a3)
@olang_loc_f93cd3b3e6e55ab4_45fd206fd1f47ef8 = external constant [0 x i8]
@olang_loc_cdf46faaecc001bd_4d9c5c30fc95ab59 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8a01e9430b40cdd5_116fbcb2b32a38a1 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_c1bd851797ba3a07_3a08c51eb1b81973 = external constant [0 x i8]
@olang_loc_f6ec8187c757dce8_8726f65a7d0e6fa4 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteOrigin(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/scope:Val" %a3)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewalkLocal(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_91699d3516f660a1_aa0e11d9464965f5 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d8ab151ef39a0b1a_493c405c799b164e = external constant [0 x i8]
declare ptr @compiler_2fscope_2eunPassed(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_4be91e4a1fba2bdb_4552e3a09b71daff = external constant [0 x i8]
@olang_loc_822a996be6bf60ec_a610051fdc17dde0 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownCall(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_20bba8d7d253ea85_a129e3e310279d91 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuild(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2)
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_H65b4b9a6d1679f5b3ddedaa5b2e336bd(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_9530d1c4ea412de_9379e3d37f97848a = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egiveBackExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ac920da97f69d3ae_2bb2c283cdbb4f6a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %v0)
@olang_loc_5c49853202d9fa8c_ad203b077ad42ef8 = external constant [0 x i8]
@olang_loc_e598343033241940_f023ba5342a3ff7c = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceOfRefs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_d5b499138e5334df_68c2e51948532eeb = external constant [0 x i8]
@G_2ecompiler_2fscope_2eWhyHolds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_efeba8037e802192_fbb9be0cbeac966 = external constant [0 x i8]
@G_2ecompiler_2fscope_2eFitField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFitDecl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@olang_loc_4ce35395f0f925b9_cbae4bbebb7ea34d = external constant [0 x i8]
@olang_loc_ef194281b7e9372b_4f5022b99d00b52f = external constant [0 x i8]
@olang_loc_b7b2bcd4863652d3_99a604389ddb6357 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRelatable({ i64, [2 x i64] } %a0)
@olang_loc_867a81ac657fc1e6_792cc237e4eb2912 = external constant [0 x i8]
@olang_loc_426d318a55139bcd_d6246dca57642d39 = external constant [0 x i8]
declare i64 @compiler_2fscope_2eregionLocal(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ereassigned(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5522d97a67b9c6cd_b4761099589b85d1 = external constant [0 x i8]
declare %"compiler/types:DtorWalk" @compiler_2ftypes_3aDtorWalk_2ector(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %a0)
@olang_loc_963cba883dc4bd20_64c99da4a40e3f44 = external constant [0 x i8]
@olang_loc_91fdca4bfcfaef3f_360ec22200b0b313 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_540f6a9ea70b2c8e_44714d47ed7a19d2 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLoopCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/diagmsg:Msg" %a4)
@olang_loc_64a11eda2e926835_fc7221612b7da3f9 = external constant [0 x i8]
@olang_loc_9739f96f1cdf87e4_96538064e6892180 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLoopCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eliftCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSharesRefs(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fscope_2eFitValue = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/scope:Val" @compiler_2fscope_2eVal_2efresh({ i64, [2 x i64] } %a0)
@olang_loc_702142de3e583242_5b34302bf43ef4be = external constant [0 x i8]
@olang_loc_6b87ff60a3433260_ddeea5c0b8316e1c = external constant [0 x i8]
@olang_loc_dc42a5a165461c34_eb9bc5161264db10 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_da3e82aad0dc20bd_21e51e34c917c3d9 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOfOwn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclaimRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_178b2bff302b55ae_896b4874215d5e1a = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_98dfeaa5663cde63_8f6c693e4f6dac2f = external constant [0 x i8]
@olang_loc_50915285e3e59b40_32eaccc11482b3ec = external constant [0 x i8]
@olang_loc_40adb7693f14b6df_fca9519f4d7d7edb = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePartKeptDestructor(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePartKept(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltOK(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_eb55abbe133e6e93_c0f65549c24d0e87 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edtorThroughRef(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etempTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_b55787a4eb4fe241_8ea57e4945f8f00d = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenResult(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_8b2906635595db32_8dcfaafc9c909d36 = external constant [0 x i8]
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H568ce559fa980123a387c6ba9ed21aca(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H240bd86caf003ea6de374cb77d0dbfc6(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, { i64, [2 x i64] } %a2)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etraceAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epropose(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_fba7553b6c5e0ea_50fdebea86f99ab6 = external constant [0 x i8]
@olang_loc_79bebea62b9e1cf1_163bbb4583e74a1d = external constant [0 x i8]
@olang_loc_d42b6d232bae90fc_92457687da3f2548 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_4cca97e9315dc06b_ef98c8592f9f4967 = external constant [0 x i8]
@olang_loc_6bff29c0022268a5_acca8b13a06d359 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeView(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2fscope_2epartRead(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeepsStorage(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2econvertsStorage(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eproposeLocal(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2, i1 %a3)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekeptCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/scope:Val" @compiler_2fscope_2eVal_2eplain()
@olang_loc_c91b1cdc23aab6c5_bcff614648d867b1 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2econstLiteral(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hb9b7b1d0a60c104971d2bbda63d84eec(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9b2b18bf4fb48614_1bb14c01aa18e3a0 = external constant [0 x i8]
@olang_loc_99a14be980ef284f_7692c216cde3a19b = external constant [0 x i8]
@olang_loc_17b5555e490eca40_3a72f19dfd1cef0c = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %a0)
@olang_loc_7d1ba41a43de5df_b306ac45f9e7717b = external constant [0 x i8]
@olang_loc_deaf2ed7955484ae_e8df1e0ec0ac14ba = external constant [0 x i8]
@olang_loc_79e16856d8fb6455_e8daf01bb6fb0841 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlDrop(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_dba8079c89f8629e_846fd2cd4d9758c2 = external constant [0 x i8]
@olang_loc_dbab6e035b5797c_e736089fb75e21e0 = external constant [0 x i8]
@olang_loc_207e75e919c85f37_93e6eeba566436db = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_5a6d5e4fff6c8f59_c596a548624aa6f5 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopenAt(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2)
@olang_loc_3adcdc5611d30137_893c219db59797b = external constant [0 x i8]
@olang_loc_d14ac281d7095de3_5cf23a39181ab0c7 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3ccompiler_2ftyped_3aExpr_26_3e_2eEvery_3ccompiler_2ftyped_3aExpr_26_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
@olang_loc_ecfbbef7cda902e1_3bafa02f8f932e5d = external constant [0 x i8]
@olang_loc_e22ca2126d036b2f_5c370e93157d3a93 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edecide(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3, i64 %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisAdapter(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_894def51c550c10b_edf695233d65cd0f = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2erecTerm(ptr %v0, { i64, [2 x i64] } %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2, ptr %a3, i1 %a4)
declare %"compiler/scope:fnRec" @compiler_2fscope_3afnRec_2ector(ptr %v0, ptr %v1, i64 %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, i1 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fscope_2eownField(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNumberLike(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euePlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueExprs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueArm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
@olang_loc_94ea3fd5578d6989_449fcf7b944ae615 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H2a2e2bb73cbe78787fa6ff6d095e1956(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H69e10a266f1cb5d26290bb9f760bc181(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
@olang_loc_32e8be698fa34edf_ce62f399ed2770f3 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eborrowRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2604b54ceaf5ac58_8a6d930b5e8314fc = external constant [0 x i8]
@olang_loc_fee63ae15dece90e_627da4ca7452ed92 = external constant [0 x i8]
@olang_loc_eb4644f0af45390e_1376074f3833ad62 = external constant [0 x i8]
@olang_loc_d7bea1f8c4fc6c43_c97bd86ee0afa2f7 = external constant [0 x i8]
declare i1 @compiler_2fscope_2eisNameChar(i8 %a0)
@olang_loc_825a81e7f5138d1b_866e780fc6f79e3f = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eRefMut_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
