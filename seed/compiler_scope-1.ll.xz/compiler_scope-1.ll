; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/typed:Plan", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, { i64, [2 x i64] }, i1, i1, i1, i64, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/scope:summary" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/scope:rel" = type { { i64, [2 x i64] }, { i64, [2 x i64] }, i1, %"compiler/source:Span", i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/scope:Val" = type { i32, { i64, [2 x i64] } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/scope:fnUse" = type { i64, %"compiler/source:Span", i64, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
define dso_local void @compiler_2fscope_2eFitValue_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2fscope_2eFitValue, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2eFnCall_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2fscope_2eFnCall, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2eHolds_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2eObliged_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2eUseThru_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2fscope_2eUseThru, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2eUseView_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2fscope_2eUseView, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2eWhyHolds_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2fscope_2eWhyHolds, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecollectArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l20 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Alt", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t33, ptr %t35)
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Alt", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  %t65 = getelementptr %"compiler/typed:Bind", ptr %t61, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t66, ptr %t68)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb9
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l3, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l3, !tbaa !24
  br label %bb4
bb17:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Arm", ptr %t79, i32 0, i32 2
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  br label %bb18
bb18:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Arm", ptr %t86, i32 0, i32 3
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %t89, ptr %t90)
  br label %bb19
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Arm", ptr %t93, i32 0, i32 4
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesFirst(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 24
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %t3)
  store { i64, ptr } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = mul i64 %t9, 8
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = mul i64 %t18, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsAt(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l36 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i1
  %l50 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i32
  %l61 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca i64
  %l65 = alloca i64
  %l70 = alloca i32
  %l74 = alloca i1
  %l87 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca i64
  %l91 = alloca i64
  %l96 = alloca i32
  %l100 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l107 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = sext i32 %t1 to i64
  store i64 %t3, ptr %l15, !tbaa !24
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l17, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb3
bb3:
  %t6 = load i64, ptr %l15, !tbaa !24
  %t7 = load i64, ptr %l17, !tbaa !24
  %t8 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t6, i64 %t7)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l18
  br label %bb4
bb4:
  %t9 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t9, ptr %l3
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 9
  %t13 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t12, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l24
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb6, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l23
  br label %bb5
bb5:
  %t21 = load i64, ptr %l23, !tbaa !24
  store i64 %t21, ptr %l19, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t22 = load i64, ptr %l19, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp ne i64 %t23, 0
  br i1 %t25, label %bb9, label %bb10
bb9:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp eq i64 %t27, 3
  call void @__olang_scope_close(ptr %s0)
  store i1 %t29, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 9
  %t34 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t33, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, i64 1)
  br label %bb12
bb12:
  store i1 false, ptr %l5, !tbaa !21
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l36
  br label %bb13
bb13:
  %t47 = load i32, ptr %l36
  store i32 %t47, ptr %l6
  %t48 = load i32, ptr %l6
  %t50 = trunc i64 25 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb71
bb17:
  %t53 = load i32, ptr %l6
  %t55 = trunc i64 18 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb43
bb20:
  %t58 = load i1, ptr %l2, !tbaa !21
  store i1 %t58, ptr %l7, !tbaa !21
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/scope:Scoper", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l46
  br label %bb21
bb21:
  %t70 = load i1, ptr %l46, !tbaa !21
  br i1 %t70, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/scope:Scoper", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  store ptr %t76, ptr %l50, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/scope:Scoper", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l55
  br label %bb24
bb23:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb26
bb24:
  %t87 = load ptr, ptr %l50, !tbaa !29
  %t88 = load i32, ptr %l55, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t89, ptr %l56
  br label %bb25
bb25:
  %t90 = load i32, ptr %l56
  %t92 = trunc i64 1 to i32
  %t93 = icmp eq i32 %t90, %t92
  store i1 %t93, ptr %l47, !tbaa !21
  br label %bb26
bb26:
  %t95 = load i1, ptr %l47, !tbaa !21
  br i1 %t95, label %bb27, label %bb28
bb27:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb29
bb28:
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s5, ptr %t96, i32 %t97)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %l61
  br label %bb30
bb30:
  %t101 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  %t102 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t101, ptr %t102
  store ptr %t102, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb31
bb31:
  %t104 = load i64, ptr %l9, !tbaa !24
  store i64 %t104, ptr %l63, !tbaa !24
  %t105 = load ptr, ptr %l8, !tbaa !29
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s5, ptr %t105)
  store i64 %t107, ptr %l65
  br label %bb32
bb32:
  %t108 = load i64, ptr %l63, !tbaa !24
  %t109 = load i64, ptr %l65, !tbaa !24
  %t110 = icmp slt i64 %t108, %t109
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb33, label %bb34
bb33:
  br label %bb42
bb34:
  br label %bb35
bb35:
  %t114 = load ptr, ptr %l8, !tbaa !29
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s5, ptr %t114, i64 %t115)
  store i32 %t118, ptr %l70
  br label %bb36
bb36:
  %t119 = load i32, ptr %l70, !tbaa !23
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i1, ptr %l7, !tbaa !21
  %t126 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartAdmits(ptr %v0, ptr %t120, i32 %t119, i1 %t122)
  store i1 %t126, ptr %l74
  br label %bb37
bb37:
  %t127 = load i1, ptr %l74, !tbaa !21
  br i1 %t127, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l9, !tbaa !24
  br label %bb31
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb71
bb43:
  %t132 = load i32, ptr %l6
  %t134 = trunc i64 19 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb44, label %bb45
bb44:
  br label %bb52
bb45:
  %t137 = load i32, ptr %l6
  %t139 = trunc i64 22 to i32
  %t140 = icmp eq i32 %t137, %t139
  br i1 %t140, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  %t142 = load i32, ptr %l6
  %t144 = trunc i64 23 to i32
  %t145 = icmp eq i32 %t142, %t144
  br i1 %t145, label %bb48, label %bb49
bb48:
  br label %bb52
bb49:
  %t147 = load i32, ptr %l6
  %t149 = trunc i64 24 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb66
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i32, ptr %l1, !tbaa !23
  %t156 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s10, ptr %t152, i32 %t153)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t156, ptr %l87
  br label %bb53
bb53:
  %t157 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  %t158 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t157, ptr %t158
  store ptr %t158, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb54
bb54:
  %t160 = load i64, ptr %l12, !tbaa !24
  store i64 %t160, ptr %l89, !tbaa !24
  %t161 = load ptr, ptr %l11, !tbaa !29
  %t163 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s10, ptr %t161)
  store i64 %t163, ptr %l91
  br label %bb55
bb55:
  %t164 = load i64, ptr %l89, !tbaa !24
  %t165 = load i64, ptr %l91, !tbaa !24
  %t166 = icmp slt i64 %t164, %t165
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb56, label %bb57
bb56:
  br label %bb65
bb57:
  br label %bb58
bb58:
  %t170 = load ptr, ptr %l11, !tbaa !29
  %t171 = load i64, ptr %l12, !tbaa !24
  %t174 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s10, ptr %t170, i64 %t171)
  store i32 %t174, ptr %l96
  br label %bb59
bb59:
  %t175 = load i32, ptr %l96, !tbaa !23
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i1, ptr %l2, !tbaa !21
  %t182 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartAdmits(ptr %v0, ptr %t176, i32 %t175, i1 %t178)
  store i1 %t182, ptr %l100
  br label %bb60
bb60:
  %t183 = load i1, ptr %l100, !tbaa !21
  br i1 %t183, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t184 = load i64, ptr %l12, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l12, !tbaa !24
  br label %bb54
bb65:
  call void @__olang_scope_close(ptr %s10)
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_7ac300513ffc0d8b_1ff73281fb7180bf)
  unreachable
bb71:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/scope:Scoper", ptr %t188, i32 0, i32 9
  store ptr %t190, ptr %l104, !tbaa !29
  %t191 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t191, ptr %l105
  %t192 = load i1, ptr %l5, !tbaa !21
  br i1 %t192, label %bb72, label %bb73
bb72:
  store i64 3, ptr %l107, !tbaa !24
  br label %bb74
bb73:
  store i64 2, ptr %l107, !tbaa !24
  br label %bb74
bb74:
  %t194 = load ptr, ptr %l104, !tbaa !29
  %t195 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l105
  %t196 = load i64, ptr %l107, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t194, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t195, i64 %t196)
  br label %bb75
bb75:
  %t197 = load i1, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t197, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca %"compiler/typed:Block"
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 14
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Try", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t24)
  br label %bb9
bb9:
  br label %bb23
bb10:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 12
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb18
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l21, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Seq", ptr %t43, i32 0, i32 0
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t48 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v1, ptr %s3, i32 -1, { i64, ptr } %t46)
  store %"compiler/typed:Block" %t48, ptr %l24
  br label %bb16
bb16:
  %t49 = load %"compiler/typed:Block", ptr %l24
  %t50 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 24, i64 8)
  store %"compiler/typed:Block" %t49, ptr %t50
  %t51 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasBlock(ptr %v0, ptr %s3, ptr %t51, ptr %t50)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_75e5f2eb37e26097_1cabe39736605273)
  unreachable
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eanyTables(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/generic:AnyTable"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, [3 x i64] }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca %"compiler/generic:AnyTable"
  %l30 = alloca { i64, ptr }
  %l32 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l65 = alloca i1
  %l69 = alloca ptr
  %l72 = alloca i64
  %l83 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l129 = alloca { i64, [3 x i64] }
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca i64
  %s4 = alloca %olang.scope
  %t128 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 47
  store ptr %t6, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l19, !tbaa !24
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eLen_H9daf28210c013890fd7cb07d1d61ba6e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l21
  br label %bb2
bb2:
  %t12 = load i64, ptr %l19, !tbaa !24
  %t13 = load i64, ptr %l21, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb48
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v0, ptr %t18, i64 %t19)
  store %"compiler/generic:AnyTable" %t22, ptr %l26
  br label %bb6
bb6:
  %t23 = load %"compiler/generic:AnyTable", ptr %l26
  store %"compiler/generic:AnyTable" %t23, ptr %l3
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 1
  %t29 = load i32, ptr %t28, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t27, i32 %t29)
  store { i64, ptr } %t32, ptr %l30
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t34 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 5
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l32
  br label %bb8
bb8:
  %t37 = load i64, ptr %l32, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t44 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb14
bb11:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l39, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb13
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  store i64 %t64, ptr %l36, !tbaa !24
  br label %bb14
bb14:
  %t65 = load i64, ptr %l36, !tbaa !24
  store i64 %t65, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load i64, ptr %l9, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb46
bb17:
  br label %bb18
bb18:
  %t74 = load i64, ptr %l5, !tbaa !24
  %t75 = load i64, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store i64 %t82, ptr %l10, !tbaa !24
  %t84 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 5
  %t85 = load i64, ptr %l10, !tbaa !24
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t84, i64 %t85)
  store i64 %t88, ptr %l59
  br label %bb19
bb19:
  %t89 = load i64, ptr %l59, !tbaa !24
  store i64 %t89, ptr %l11, !tbaa !24
  %t90 = load i64, ptr %l11, !tbaa !24
  store i64 %t90, ptr %l60, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/scope:Scoper", ptr %t91, i32 0, i32 6
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_H9c3932eb53016bf6f47a08eef06aacbe(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l63
  br label %bb20
bb20:
  %t96 = load i64, ptr %l60, !tbaa !24
  %t97 = load i64, ptr %l63, !tbaa !24
  %t98 = icmp sge i64 %t96, %t97
  br i1 %t98, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb25
bb22:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/scope:Scoper", ptr %t100, i32 0, i32 6
  %t103 = load i64, ptr %l11, !tbaa !24
  %t106 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t102, i64 %t103)
  store ptr %t106, ptr %l69
  br label %bb23
bb23:
  %t107 = load ptr, ptr %l69, !tbaa !29
  %t109 = getelementptr %"compiler/scope:summary", ptr %t107, i32 0, i32 0
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t109)
  store i64 %t111, ptr %l72
  br label %bb24
bb24:
  %t112 = load i64, ptr %l72, !tbaa !24
  %t113 = icmp eq i64 %t112, 0
  store i1 %t113, ptr %l65, !tbaa !21
  br label %bb25
bb25:
  %t115 = load i1, ptr %l65, !tbaa !21
  br i1 %t115, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb27:
  br label %bb28
bb28:
  %t116 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 3
  %t117 = load i64, ptr %t116, !tbaa !24
  %t118 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 4
  %t119 = getelementptr %"compiler/source:Span", ptr %t118, i32 0, i32 0
  %t120 = load i32, ptr %t119, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t123 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 4
  %t124 = getelementptr %"compiler/source:Span", ptr %t123, i32 0, i32 1
  %t125 = load i32, ptr %t124, !tbaa !23
  %t127 = sext i32 %t125 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 0
  store i64 3, ptr %t129
  %t131 = insertvalue { i64, i64, i64 } undef, i64 %t117, 0
  %t133 = insertvalue { i64, i64, i64 } %t131, i64 %t122, 1
  %t135 = insertvalue { i64, i64, i64 } %t133, i64 %t127, 2
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  store { i64, i64, i64 } %t135, ptr %t136
  %t137 = load { i64, [3 x i64] }, ptr %t128
  store { i64, [3 x i64] } %t137, ptr %l12
  %t139 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t143 = icmp sgt i64 %t141, 0
  br i1 %t143, label %bb29, label %bb30
bb29:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/scope:Scoper", ptr %t145, i32 0, i32 0
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 0
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/load:Loader", ptr %t151, i32 0, i32 3
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t155, ptr %l88, !tbaa !27
  %t156 = load i64, ptr %l10, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t162 = srem i64 %t156, %t159
  %t164 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr %"compiler/generic:AnySlot", ptr %t165, i64 %t162
  %t167 = getelementptr %"compiler/generic:AnySlot", ptr %t166, i32 0, i32 0
  %t168 = load i32, ptr %t167, !tbaa !23
  %t171 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t154, i32 %t168)
  store { i64, ptr } %t171, ptr %l94
  br label %bb31
bb30:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l83, !tbaa !27
  br label %bb32
bb31:
  %t172 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t174 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t174, 1
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = add i64 %t173, %t176
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t180 = add i64 %t177, %t179
  %t181 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t172, i64 %t173)
  %t182 = getelementptr i8, ptr %t181, i64 %t173
  call void @olang_textcopy(ptr %t182, ptr %t175, i64 %t176)
  %t183 = getelementptr i8, ptr %t182, i64 %t176
  call void @olang_textcopy(ptr %t183, ptr %t178, i64 %t179)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t181, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = extractvalue { i64, ptr } %t185, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l83, !tbaa !27
  br label %bb32
bb32:
  %t194 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t194, ptr %l13, !tbaa !27
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/scope:Scoper", ptr %t195, i32 0, i32 5
  %t198 = load { ptr, ptr }, ptr %t197
  %t200 = extractvalue { ptr, ptr } %t198, 0
  %t201 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t202 = icmp eq ptr %t200, %t201
  %t203 = extractvalue { ptr, ptr } %t198, 1
  %t204 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t205 = icmp eq ptr %t203, %t204
  %t206 = and i1 %t202, %t205
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb33, label %bb34
bb33:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/scope:Scoper", ptr %t210, i32 0, i32 5
  %t213 = load { ptr, ptr }, ptr %t212
  %t214 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 0
  %t215 = load i32, ptr %t214, !tbaa !23
  %t217 = extractvalue { ptr, ptr } %t213, 0
  %t218 = extractvalue { ptr, ptr } %t213, 1
  %t220 = call { i64, ptr } %t217(ptr %t218, ptr %s4, i32 %t215)
  store { i64, ptr } %t220, ptr %l105
  br label %bb35
bb34:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/scope:Scoper", ptr %t221, i32 0, i32 0
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/generic:Program", ptr %t224, i32 0, i32 2
  %t227 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 0
  %t228 = load i32, ptr %t227, !tbaa !23
  %t231 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s4, ptr %t226, i32 %t228)
  store { i64, ptr } %t231, ptr %l110
  br label %bb36
bb35:
  %t232 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t232, ptr %l101, !tbaa !27
  br label %bb37
bb36:
  %t233 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t233, ptr %l101, !tbaa !27
  br label %bb37
bb37:
  %t234 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t234, ptr %l14, !tbaa !27
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/scope:Scoper", ptr %t235, i32 0, i32 5
  %t238 = load { ptr, ptr }, ptr %t237
  %t240 = extractvalue { ptr, ptr } %t238, 0
  %t241 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t242 = icmp eq ptr %t240, %t241
  %t243 = extractvalue { ptr, ptr } %t238, 1
  %t244 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t245 = icmp eq ptr %t243, %t244
  %t246 = and i1 %t242, %t245
  %t248 = xor i1 %t246, true
  br i1 %t248, label %bb38, label %bb39
bb38:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/scope:Scoper", ptr %t250, i32 0, i32 5
  %t253 = load { ptr, ptr }, ptr %t252
  %t254 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 1
  %t255 = load i32, ptr %t254, !tbaa !23
  %t257 = extractvalue { ptr, ptr } %t253, 0
  %t258 = extractvalue { ptr, ptr } %t253, 1
  %t260 = call { i64, ptr } %t257(ptr %t258, ptr %s4, i32 %t255)
  store { i64, ptr } %t260, ptr %l119
  br label %bb40
bb39:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/scope:Scoper", ptr %t261, i32 0, i32 0
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = getelementptr %"compiler/generic:Program", ptr %t264, i32 0, i32 2
  %t267 = getelementptr %"compiler/generic:AnyTable", ptr %l3, i32 0, i32 1
  %t268 = load i32, ptr %t267, !tbaa !23
  %t271 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s4, ptr %t266, i32 %t268)
  store { i64, ptr } %t271, ptr %l124
  br label %bb41
bb40:
  %t272 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t272, ptr %l115, !tbaa !27
  br label %bb42
bb41:
  %t273 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t273, ptr %l115, !tbaa !27
  br label %bb42
bb42:
  %t274 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/scope:Scoper", ptr %t275, i32 0, i32 0
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t280 = getelementptr %"compiler/generic:Program", ptr %t278, i32 0, i32 0
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t283 = getelementptr %"compiler/load:Loader", ptr %t281, i32 0, i32 4
  %t284 = load ptr, ptr %t283, !tbaa !29
  store ptr %t284, ptr %l128, !tbaa !29
  %t285 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t285, ptr %l129
  %t286 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t287 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t292 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyMethodObligations(ptr %s4, ptr %s4, ptr %s4, ptr %s4, { i64, ptr } %t286, { i64, ptr } %t287, { i64, ptr } %t274)
  store %"compiler/msgs:Msg" %t292, ptr %l133
  br label %bb43
bb43:
  %t293 = load ptr, ptr %l128, !tbaa !29
  %t294 = load { i64, [3 x i64] }, ptr %l129
  %t295 = load %"compiler/msgs:Msg", ptr %l133
  %t296 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t293, { i64, [3 x i64] } %t294, %"compiler/msgs:Msg" %t295)
  store i64 %t296, ptr %l134
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s4)
  br label %bb46
bb45:
  %t297 = load i64, ptr %l9, !tbaa !24
  %t299 = add i64 %t297, 1
  store i64 %t299, ptr %l9, !tbaa !24
  br label %bb15
bb46:
  br label %bb47
bb47:
  %t301 = load i64, ptr %l2, !tbaa !24
  %t303 = add i64 %t301, 1
  store i64 %t303, ptr %l2, !tbaa !24
  br label %bb1
bb48:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  store ptr %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l8, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i64, ptr %t12
  %t15 = icmp eq i64 %t13, 3
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v1, ptr %t23)
  store i64 %t25, ptr %l17
  br label %bb7
bb7:
  %t26 = load i64, ptr %l17, !tbaa !24
  store i64 %t26, ptr %l9, !tbaa !24
  br label %bb20
bb8:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t28 = load ptr, ptr %l18, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 2
  store i1 %t34, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l19, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v1, ptr %t42)
  store i64 %t44, ptr %l25
  br label %bb14
bb14:
  %t45 = load i64, ptr %l25, !tbaa !24
  store i64 %t45, ptr %l9, !tbaa !24
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_aa04e26a4d7578a7_d714aefedcea6ccb)
  unreachable
bb20:
  %t46 = load i64, ptr %l9, !tbaa !24
  store i64 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargPartOK(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t1)
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t8, ptr %a1)
  store ptr %t13, ptr %l12
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  store ptr %t14, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l3, !tbaa !29
  store ptr %t15, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %l13, !tbaa !29
  %t20 = load i64, ptr %t19
  %t22 = icmp eq i64 %t20, 2
  store i1 %t22, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t32 = load { i64, [2 x i64] }, ptr %l2
  %t36 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %t30, ptr %t31, { i64, [2 x i64] } %t32)
  store i1 %t36, ptr %l22
  br label %bb11
bb11:
  %t37 = load i1, ptr %l22, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  call void @__olang_check_failed(ptr @olang_loc_5ad8ce5e83291793_3404c81b33ceede7)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargsAgree(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i64 %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca %"compiler/scope:rel"
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca { i64, [2 x i64] }
  %l26 = alloca { { i64, [2 x i64] }, i1, i1 }
  %l27 = alloca { i64, [2 x i64] }
  %l28 = alloca i1
  %l34 = alloca i32
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l77 = alloca i1
  %l81 = alloca i1
  %l82 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l93 = alloca i64
  %l95 = alloca i64
  %l100 = alloca %"compiler/scope:rel"
  %l105 = alloca i1
  %l109 = alloca i1
  %l112 = alloca i1
  %l127 = alloca i32
  %l128 = alloca { i64, ptr }
  %l134 = alloca i1
  %l138 = alloca i1
  %l141 = alloca i1
  %l142 = alloca i1
  %l145 = alloca i1
  %l148 = alloca i1
  %l149 = alloca { i64, ptr }
  %l153 = alloca i1
  %l160 = alloca { { i64, [2 x i64] }, i1, i1 }
  %l166 = alloca ptr
  %l169 = alloca { i64, ptr }
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca %"compiler/msgs:Msg"
  %l174 = alloca i64
  %s12 = alloca %olang.scope
  %rv = alloca i1
  %t27 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l34
  br label %bb1
bb1:
  %t6 = load i32, ptr %l34, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/scope:Scoper", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l37, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/scope:Scoper", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t18, i32 %t6)
  store i32 %t22, ptr %l42
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l37, !tbaa !29
  %t24 = load i32, ptr %l42, !tbaa !23
  %t25 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t23, i32 %t24)
  store { i64, ptr } %t25, ptr %l43
  br label %bb3
bb3:
  %t26 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t26, ptr %l8, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [2 x i64] }, ptr %t27, i32 0, i32 0
  store i64 0, ptr %t28
  %t29 = load { i64, [2 x i64] }, ptr %t27
  store { i64, [2 x i64] } %t29, ptr %l9
  store i1 false, ptr %l10, !tbaa !21
  store i64 0, ptr %l11, !tbaa !24
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Call", ptr %t31, i32 0, i32 1
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t38 = load i64, ptr %l12, !tbaa !24
  %t39 = load i64, ptr %l11, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb4, label %bb5
bb4:
  %t44 = load i64, ptr %l13, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb9
bb6:
  %t48 = load i64, ptr %l12, !tbaa !24
  %t49 = load i64, ptr %l11, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l13, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l13, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l54, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb8
bb8:
  %t64 = load i64, ptr %l54, !tbaa !24
  store i64 %t64, ptr %l51, !tbaa !24
  br label %bb9
bb9:
  %t65 = load i64, ptr %l51, !tbaa !24
  store i64 %t65, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb10
bb10:
  %t66 = load i64, ptr %l15, !tbaa !24
  %t67 = load i64, ptr %l14, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb11, label %bb12
bb11:
  br label %bb80
bb12:
  br label %bb13
bb13:
  %t74 = load i64, ptr %l11, !tbaa !24
  %t75 = load i64, ptr %l15, !tbaa !24
  %t76 = load i64, ptr %l13, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store i64 %t82, ptr %l16, !tbaa !24
  store { i64, ptr } %a4, ptr %l72, !tbaa !27
  %t85 = load i64, ptr %l16, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i64, ptr %t88, i64 %t85
  %t90 = load i64, ptr %t89, !tbaa !34
  store i64 %t90, ptr %l17, !tbaa !24
  %t92 = load i64, ptr %l17, !tbaa !24
  %t94 = icmp slt i64 %t92, 0
  br i1 %t94, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb16
bb15:
  %t96 = load i64, ptr %l17, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  %t100 = icmp eq i64 %t96, %t97
  store i1 %t100, ptr %l77, !tbaa !21
  br label %bb16
bb16:
  %t102 = load i1, ptr %l77, !tbaa !21
  br i1 %t102, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb19
bb18:
  store { i64, ptr } %a5, ptr %l82, !tbaa !27
  %t104 = load i64, ptr %l16, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr %"compiler/scope:Val", ptr %t107, i64 %t104
  %t109 = getelementptr %"compiler/scope:Val", ptr %t108, i32 0, i32 0
  %t110 = load i32, ptr %t109
  %t112 = trunc i64 3 to i32
  %t113 = icmp eq i32 %t110, %t112
  %t115 = xor i1 %t113, true
  store i1 %t115, ptr %l81, !tbaa !21
  br label %bb19
bb19:
  %t117 = load i1, ptr %l81, !tbaa !21
  br i1 %t117, label %bb20, label %bb21
bb20:
  br label %bb79
bb21:
  br label %bb22
bb22:
  store i1 false, ptr %l18, !tbaa !21
  store i1 false, ptr %l19, !tbaa !21
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/scope:Scoper", ptr %t118, i32 0, i32 6
  %t124 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t120, i64 %a2)
  store ptr %t124, ptr %l90
  br label %bb23
bb23:
  %t125 = load ptr, ptr %l90, !tbaa !29
  %t127 = getelementptr %"compiler/scope:summary", ptr %t125, i32 0, i32 0
  store ptr %t127, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb24
bb24:
  %t129 = load i64, ptr %l21, !tbaa !24
  store i64 %t129, ptr %l93, !tbaa !24
  %t130 = load ptr, ptr %l20, !tbaa !29
  %t132 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t130)
  store i64 %t132, ptr %l95
  br label %bb25
bb25:
  %t133 = load i64, ptr %l93, !tbaa !24
  %t134 = load i64, ptr %l95, !tbaa !24
  %t135 = icmp slt i64 %t133, %t134
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb26, label %bb27
bb26:
  br label %bb49
bb27:
  br label %bb28
bb28:
  %t139 = load ptr, ptr %l20, !tbaa !29
  %t140 = load i64, ptr %l21, !tbaa !24
  %t143 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t139, i64 %t140)
  store %"compiler/scope:rel" %t143, ptr %l100
  br label %bb29
bb29:
  %t144 = load %"compiler/scope:rel", ptr %l100
  store %"compiler/scope:rel" %t144, ptr %l22
  %t145 = getelementptr %"compiler/scope:rel", ptr %l22, i32 0, i32 4
  %t146 = load i64, ptr %t145, !tbaa !24
  %t148 = icmp eq i64 %t146, 0
  br i1 %t148, label %bb30, label %bb31
bb30:
  br label %bb48
bb31:
  br label %bb32
bb32:
  %t150 = getelementptr %"compiler/scope:rel", ptr %l22, i32 0, i32 0
  %t151 = load { i64, [2 x i64] }, ptr %t150
  %t153 = extractvalue { i64, [2 x i64] } %t151, 0
  %t154 = icmp eq i64 %t153, 2
  br i1 %t154, label %bb33, label %bb34
bb33:
  %t156 = getelementptr %"compiler/scope:rel", ptr %l22, i32 0, i32 0
  %t157 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 1
  %t158 = getelementptr { i64 }, ptr %t157, i32 0, i32 0
  %t159 = load i64, ptr %t158
  %t160 = load i64, ptr %l17, !tbaa !24
  %t163 = icmp eq i64 %t159, %t160
  store i1 %t163, ptr %l105, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb35
bb35:
  %t165 = load i1, ptr %l105, !tbaa !21
  br i1 %t165, label %bb36, label %bb37
bb36:
  %t166 = getelementptr %"compiler/scope:rel", ptr %l22, i32 0, i32 1
  %t167 = load { i64, [2 x i64] }, ptr %t166
  %t169 = extractvalue { i64, [2 x i64] } %t167, 0
  %t170 = icmp eq i64 %t169, 2
  br i1 %t170, label %bb38, label %bb39
bb37:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb41
bb38:
  %t172 = getelementptr %"compiler/scope:rel", ptr %l22, i32 0, i32 1
  %t173 = getelementptr { i64, [2 x i64] }, ptr %t172, i32 0, i32 1
  %t174 = getelementptr { i64 }, ptr %t173, i32 0, i32 0
  %t175 = load i64, ptr %t174
  %t176 = load i64, ptr %l3, !tbaa !24
  %t179 = icmp eq i64 %t175, %t176
  store i1 %t179, ptr %l112, !tbaa !21
  br label %bb40
bb39:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb40
bb40:
  %t181 = load i1, ptr %l112, !tbaa !21
  store i1 %t181, ptr %l109, !tbaa !21
  br label %bb41
bb41:
  %t182 = load i1, ptr %l109, !tbaa !21
  br i1 %t182, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l18, !tbaa !21
  %t183 = getelementptr %"compiler/scope:rel", ptr %l22, i32 0, i32 4
  %t184 = load i64, ptr %t183, !tbaa !24
  %t185 = load i64, ptr @G_2ecompiler_2fscope_2eWhyField, !tbaa !24
  %t188 = icmp eq i64 %t184, %t185
  br i1 %t188, label %bb44, label %bb45
bb43:
  br label %bb47
bb44:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t190 = load i64, ptr %l21, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l21, !tbaa !24
  br label %bb24
bb49:
  %t194 = load i1, ptr %l18, !tbaa !21
  %t196 = xor i1 %t194, true
  br i1 %t196, label %bb50, label %bb51
bb50:
  br label %bb79
bb51:
  br label %bb52
bb52:
  %t198 = load i64, ptr %l16, !tbaa !24
  %t199 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t204 = icmp slt i64 %t198, %t201
  br i1 %t204, label %bb53, label %bb54
bb53:
  %t206 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t206, ptr %l128, !tbaa !27
  %t207 = load i64, ptr %l16, !tbaa !24
  %t209 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr i32, ptr %t210, i64 %t207
  %t212 = load i32, ptr %t211, !tbaa !33
  store i32 %t212, ptr %l127, !tbaa !23
  br label %bb55
bb54:
  %t214 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t214, ptr %l127, !tbaa !23
  br label %bb55
bb55:
  %t216 = load i32, ptr %l127, !tbaa !23
  store i32 %t216, ptr %l23, !tbaa !23
  %t217 = load i1, ptr %l19, !tbaa !21
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb56, label %bb57
bb56:
  %t221 = load i32, ptr %l23, !tbaa !23
  %t222 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t225 = icmp ne i32 %t221, %t222
  store i1 %t225, ptr %l134, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb58
bb58:
  %t227 = load i1, ptr %l134, !tbaa !21
  br i1 %t227, label %bb59, label %bb60
bb59:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i32, ptr %l23, !tbaa !23
  %t232 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t228, i32 %t229)
  store i1 %t232, ptr %l141
  br label %bb61
bb60:
  store i1 false, ptr %l138, !tbaa !21
  br label %bb67
bb61:
  %t233 = load i1, ptr %l141, !tbaa !21
  br i1 %t233, label %bb62, label %bb63
bb62:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i32, ptr %l23, !tbaa !23
  %t238 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsStores(ptr %v0, ptr %t234, i32 %t235)
  store i1 %t238, ptr %l145
  br label %bb64
bb63:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l23, !tbaa !23
  %t243 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %t239, i32 %t240)
  store i1 %t243, ptr %l148
  br label %bb65
bb64:
  %t244 = load i1, ptr %l145, !tbaa !21
  store i1 %t244, ptr %l142, !tbaa !21
  br label %bb66
bb65:
  %t245 = load i1, ptr %l148, !tbaa !21
  store i1 %t245, ptr %l142, !tbaa !21
  br label %bb66
bb66:
  %t246 = load i1, ptr %l142, !tbaa !21
  store i1 %t246, ptr %l138, !tbaa !21
  br label %bb67
bb67:
  %t247 = load i1, ptr %l138, !tbaa !21
  store i1 %t247, ptr %l24, !tbaa !21
  store { i64, ptr } %a6, ptr %l149, !tbaa !27
  %t249 = load i64, ptr %l17, !tbaa !24
  %t251 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr { i64, [2 x i64] }, ptr %t252, i64 %t249
  %t254 = load { i64, [2 x i64] }, ptr %t253
  store { i64, [2 x i64] } %t254, ptr %l25
  %t256 = load { i64, [2 x i64] }, ptr %l25
  %t258 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t256)
  store i1 %t258, ptr %l153
  br label %bb68
bb68:
  %t259 = load i1, ptr %l153, !tbaa !21
  %t260 = xor i1 %t259, true
  br i1 %t260, label %bb69, label %bb70
bb69:
  br label %bb79
bb70:
  br label %bb71
bb71:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load { i64, [2 x i64] }, ptr %l9
  %t264 = load i1, ptr %l10, !tbaa !21
  %t265 = load { i64, [2 x i64] }, ptr %l25
  %t266 = load i1, ptr %l24, !tbaa !21
  %t272 = call { { i64, [2 x i64] }, i1, i1 } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eagreeStep(ptr %v0, ptr %t262, { i64, [2 x i64] } %t263, i1 %t264, { i64, [2 x i64] } %t265, i1 %t266)
  store { { i64, [2 x i64] }, i1, i1 } %t272, ptr %l160
  br label %bb72
bb72:
  %t273 = load { { i64, [2 x i64] }, i1, i1 }, ptr %l160
  store { { i64, [2 x i64] }, i1, i1 } %t273, ptr %l26
  %t274 = getelementptr { { i64, [2 x i64] }, i1, i1 }, ptr %l26, i32 0, i32 0
  %t275 = load { i64, [2 x i64] }, ptr %t274
  store { i64, [2 x i64] } %t275, ptr %l27
  %t277 = getelementptr { { i64, [2 x i64] }, i1, i1 }, ptr %l26, i32 0, i32 1
  %t278 = load i1, ptr %t277, !tbaa !21
  store i1 %t278, ptr %l28, !tbaa !21
  %t280 = getelementptr { { i64, [2 x i64] }, i1, i1 }, ptr %l26, i32 0, i32 2
  %t281 = load i1, ptr %t280, !tbaa !21
  %t285 = xor i1 %t281, true
  br i1 %t285, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s12
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l166, !tbaa !29
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Call", ptr %t289, i32 0, i32 1
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  store { i64, ptr } %t292, ptr %l169, !tbaa !27
  %t293 = load i64, ptr %l16, !tbaa !24
  %t295 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr ptr, ptr %t296, i64 %t293
  %t298 = load ptr, ptr %t297, !tbaa !39
  %t301 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v1, ptr %t288, ptr %t298)
  store %"compiler/source:Span" %t301, ptr %l172
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t302 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgsDisagree(ptr %s12)
  store %"compiler/msgs:Msg" %t302, ptr %l173
  br label %bb76
bb76:
  %t303 = load ptr, ptr %l166, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l172
  %t305 = load %"compiler/msgs:Msg", ptr %l173
  %t306 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s12, ptr %t303, %"compiler/source:Span" %t304, %"compiler/msgs:Msg" %t305)
  store i64 %t306, ptr %l174
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s12)
  store i1 false, ptr %rv
  br label %ret
bb78:
  %t308 = load { i64, [2 x i64] }, ptr %l27
  %t310 = load i1, ptr %l28, !tbaa !21
  store { i64, [2 x i64] } %t308, ptr %l9
  store i1 %t310, ptr %l10, !tbaa !21
  br label %bb79
bb79:
  %t316 = load i64, ptr %l15, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l15, !tbaa !24
  br label %bb10
bb80:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [2 x i64] }
  %l6 = alloca i32
  %rv = alloca { i64, [2 x i64] }
  %t43 = alloca { i64, [2 x i64] }, align 8
  %t60 = alloca { i64, [2 x i64] }, align 8
  %t65 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elift(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t9 = icmp eq i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb4, label %bb5
bb3:
  br label %bb25
bb4:
  call void @__olang_check_failed(ptr @olang_loc_2dbc08d4832115c_eb31bc54ed1b9440)
  unreachable
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t18, i32 0, i32 25
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 1
  %t25 = load { i64, [2 x i64] }, ptr %t24
  store { i64, [2 x i64] } %t25, ptr %l3
  %t27 = load { i64, [2 x i64] }, ptr %l3
  %t29 = extractvalue { i64, [2 x i64] } %t27, 0
  %t30 = icmp eq i64 %t29, 1
  br i1 %t30, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/scope:Scoper", ptr %t32, i32 0, i32 39
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/scope:Scoper", ptr %t39, i32 0, i32 39
  %t42 = load i64, ptr %t41, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [2 x i64] }, ptr %t43, i32 0, i32 0
  store i64 2, ptr %t44
  %t46 = insertvalue { i64 } undef, i64 %t42, 0
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t43, i32 0, i32 1
  store { i64 } %t46, ptr %t47
  %t48 = load { i64, [2 x i64] }, ptr %t43
  store { i64, [2 x i64] } %t48, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb24
bb13:
  %t50 = load { i64, [2 x i64] }, ptr %l3
  %t52 = extractvalue { i64, [2 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 6
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  %t55 = load { i64, [2 x i64] }, ptr %l3
  %t57 = extractvalue { i64, [2 x i64] } %t55, 0
  %t58 = icmp eq i64 %t57, 7
  br i1 %t58, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store { i64, [2 x i64] } zeroinitializer, ptr %t60
  %t61 = getelementptr { i64, [2 x i64] }, ptr %t60, i32 0, i32 0
  store i64 3, ptr %t61
  %t62 = load { i64, [2 x i64] }, ptr %t60
  store { i64, [2 x i64] } %t62, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_1fe97746d4c06972_784e8262c547b126)
  unreachable
bb24:
  br label %bb25
bb25:
  %t64 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t65
  %t66 = getelementptr { i64, [2 x i64] }, ptr %t65, i32 0, i32 0
  store i64 1, ptr %t66
  %t68 = insertvalue { i32 } undef, i32 %t64, 0
  %t69 = getelementptr { i64, [2 x i64] }, ptr %t65, i32 0, i32 1
  store { i32 } %t68, ptr %t69
  %t70 = load { i64, [2 x i64] }, ptr %t65
  store { i64, [2 x i64] } %t70, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildSite(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, [2 x i64] }
  %l7 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, [2 x i64] }
  %l19 = alloca { i64, [2 x i64] }
  %l21 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca { i64, [1 x i64] }
  %l27 = alloca ptr
  %l28 = alloca { i64, [2 x i64] }
  %l29 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp slt i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 30
  %t11 = getelementptr %"compiler/typed:Plan", ptr %t10, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t17 = icmp sge i64 %t7, %t14
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l7, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = load { i64, [2 x i64] }, ptr %l2
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t20)
  store i1 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i1, ptr %l15, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t24, ptr %l16
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t26)
  store { i64, [2 x i64] } %t28, ptr %l19
  br label %bb10
bb10:
  %t29 = load { i64, [2 x i64] }, ptr %l19
  store { i64, [2 x i64] } %t29, ptr %l16
  br label %bb11
bb11:
  %t30 = load { i64, [2 x i64] }, ptr %l16
  store { i64, [2 x i64] } %t30, ptr %l4
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 30
  %t34 = getelementptr %"compiler/typed:Plan", ptr %t33, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l21, !tbaa !27
  %t36 = load i32, ptr %l1, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l23, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load { i64, [2 x i64] }, ptr %l4
  %t43 = call { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %t39, { i64, [2 x i64] } %t40)
  store { i64, [1 x i64] } %t43, ptr %l26
  br label %bb12
bb12:
  %t44 = load { i64, [1 x i64] }, ptr %l26
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, [1 x i64] }, ptr %t47, i64 %t45
  store { i64, [1 x i64] } %t44, ptr %t48
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l27, !tbaa !29
  %t50 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t50, ptr %l28
  %t51 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t51, ptr %l29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/scope:Scoper", ptr %t52, i32 0, i32 25
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_3e89652ff7706bd0_4686e7e94f816f94)
  unreachable
bb14:
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 25
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Body", ptr %t62, i32 0, i32 3
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = load %"compiler/source:Span", ptr %l3
  %t68 = load ptr, ptr %l27, !tbaa !29
  %t69 = load { i64, [2 x i64] }, ptr %l28
  %t70 = load %"compiler/source:Span", ptr %l29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t68, { i64, [2 x i64] } %t69, %"compiler/source:Span" %t70, i64 %t66, %"compiler/source:Span" %t67)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l10 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca %"compiler/msgs:Msg"
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i1
  %l30 = alloca i1
  %l47 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb12
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 27
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 60
  %t14 = load i1, ptr %t13, !tbaa !21
  %t16 = xor i1 %t14, true
  store i1 %t16, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t20, ptr %l15
  %t21 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %s2)
  store %"compiler/msgs:Msg" %t21, ptr %l16
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l15
  %t24 = load %"compiler/msgs:Msg", ptr %l16
  %t25 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s2, ptr %t22, %"compiler/source:Span" %t23, %"compiler/msgs:Msg" %t24)
  store i64 %t25, ptr %l17
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %bb41
bb12:
  %t26 = load { i64, [2 x i64] }, ptr %l1
  %t28 = extractvalue { i64, [2 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 2
  br i1 %t29, label %bb13, label %bb14
bb13:
  %t31 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t32 = getelementptr { i64 }, ptr %t31, i32 0, i32 0
  %t33 = load i64, ptr %t32
  store i64 %t33, ptr %l5, !tbaa !24
  br label %bb15
bb14:
  br label %bb36
bb15:
  %t35 = load i64, ptr %l5, !tbaa !24
  store i64 %t35, ptr %l21, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/scope:Scoper", ptr %t36, i32 0, i32 58
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l24
  br label %bb16
bb16:
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = load i64, ptr %l24, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  br i1 %t43, label %bb17, label %bb18
bb17:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/scope:Scoper", ptr %t45, i32 0, i32 58
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t47, i64 %t48)
  store i1 %t51, ptr %l30
  br label %bb19
bb18:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb20
bb19:
  %t52 = load i1, ptr %l30, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb20
bb20:
  %t55 = load i1, ptr %l26, !tbaa !21
  br i1 %t55, label %bb21, label %bb22
bb21:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/scope:Scoper", ptr %t56, i32 0, i32 58
  %t59 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t58, i64 %t59, i1 true)
  br label %bb23
bb22:
  br label %bb27
bb23:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 61
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load %"compiler/source:Span", ptr %l2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t64, i64 %t65, %"compiler/source:Span" %t66)
  br label %bb24
bb24:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/scope:Scoper", ptr %t70, i32 0, i32 62
  %t73 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t72, i64 %t73, i64 %a3)
  br label %bb25
bb25:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/scope:Scoper", ptr %t78, i32 0, i32 63
  %t81 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t80, i64 %t81, %"compiler/source:Span" %a4)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t86 = load i64, ptr %l5, !tbaa !24
  store i64 %t86, ptr %l47, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/scope:Scoper", ptr %t87, i32 0, i32 59
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t89)
  store i64 %t91, ptr %l50
  br label %bb28
bb28:
  %t92 = load i64, ptr %l47, !tbaa !24
  %t93 = load i64, ptr %l50, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  br i1 %t94, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/scope:Scoper", ptr %t96, i32 0, i32 60
  %t99 = load i1, ptr %t98, !tbaa !21
  %t101 = xor i1 %t99, true
  store i1 %t101, ptr %l52, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb31
bb31:
  %t103 = load i1, ptr %l52, !tbaa !21
  br i1 %t103, label %bb32, label %bb33
bb32:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/scope:Scoper", ptr %t104, i32 0, i32 59
  %t107 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t106, i64 %t107, i1 true)
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_d867a1bfd37ee6cf_dcf5a89f84b878b3)
  unreachable
bb41:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeBuilds(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t15 = load ptr, ptr %l4, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l11, !tbaa !29
  %t20 = load i64, ptr %t19
  %t22 = icmp eq i64 %t20, 4
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8066e5da37f3a23b_ece6b8d6fabe8bf7)
  unreachable
bb15:
  %t31 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsSum(ptr %v0, ptr %a0, i64 %a2, i64 %a3)
  store i1 %t31, ptr %l19
  br label %bb16
bb16:
  %t32 = load i1, ptr %l19, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecanKeep(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"compiler/types:Table"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"compiler/scope:rel"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca %"compiler/scope:rel"
  %l40 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l58 = alloca %"compiler/types:Table"
  %l61 = alloca i64
  %l68 = alloca i64
  %l75 = alloca { i64, ptr }
  %l79 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i64
  %l108 = alloca i64
  %l112 = alloca i1
  %l119 = alloca i1
  %l123 = alloca i1
  %l127 = alloca i64
  %l139 = alloca i64
  %l142 = alloca i64
  %l166 = alloca i64
  %l170 = alloca i1
  %l174 = alloca i1
  %l177 = alloca i1
  %l181 = alloca i1
  %l191 = alloca i64
  %l194 = alloca i1
  %l198 = alloca ptr
  %l202 = alloca i1
  %l206 = alloca ptr
  %l214 = alloca { i64, ptr }
  %l220 = alloca i64
  %l223 = alloca i64
  %l231 = alloca i64
  %l234 = alloca i64
  %l259 = alloca ptr
  %l262 = alloca i64
  %l264 = alloca i64
  %l269 = alloca %"compiler/scope:rel"
  %l272 = alloca i1
  %l276 = alloca i1
  %l278 = alloca i1
  %l281 = alloca i1
  %l293 = alloca ptr
  %l296 = alloca i64
  %l298 = alloca i64
  %l303 = alloca %"compiler/scope:rel"
  %l306 = alloca i1
  %l307 = alloca i1
  %l309 = alloca i1
  %l312 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l40
  br label %bb1
bb1:
  %t6 = load i32, ptr %l40, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Call", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l4, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  store ptr %t19, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t20 = load ptr, ptr %l47, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l47, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 1
  store i1 %t26, ptr %l48, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l48, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t28 = load ptr, ptr %l4, !tbaa !29
  store ptr %t28, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t29 = load ptr, ptr %l51, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l51, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 4
  store i1 %t35, ptr %l52, !tbaa !21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l52, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e7f077513292cd77_7cc56e961d13405b)
  unreachable
bb19:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %t43, i64 272, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l58, i64 272, i1 false)
  %t44 = load i32, ptr %l3, !tbaa !23
  %t47 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %l5, i32 %t44)
  store i64 %t47, ptr %l61
  br label %bb20
bb20:
  %t48 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t49 = load i64, ptr %l61, !tbaa !24
  %t51 = icmp eq i64 %t49, %t48
  br i1 %t51, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t54 = load i32, ptr %l3, !tbaa !23
  %t55 = load i64, ptr %l2, !tbaa !24
  %t59 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %l5, i32 %t54, i64 %t55)
  store i64 %t59, ptr %l68
  br label %bb24
bb24:
  %t60 = load i64, ptr %l68, !tbaa !24
  store i64 %t60, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t65 = icmp eq i64 %t61, %t62
  br i1 %t65, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %l5, i32 %t68)
  store { i64, ptr } %t71, ptr %l75
  br label %bb28
bb28:
  %t72 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb29, label %bb30
bb29:
  %t79 = load i64, ptr %l7, !tbaa !24
  store i64 %t79, ptr %l79, !tbaa !24
  br label %bb31
bb30:
  store i64 1, ptr %l79, !tbaa !24
  br label %bb31
bb31:
  %t81 = load i64, ptr %l79, !tbaa !24
  store i64 %t81, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t82 = load i64, ptr %l9, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t86 = icmp sgt i64 %t82, %t83
  br i1 %t86, label %bb32, label %bb33
bb32:
  %t88 = load i64, ptr %l10, !tbaa !24
  %t90 = icmp sgt i64 %t88, 0
  br i1 %t90, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb37
bb34:
  %t92 = load i64, ptr %l9, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = sub i64 %t92, %t93
  %t97 = load i64, ptr %l10, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = sub i64 %t100, 1
  %t103 = load i64, ptr %l10, !tbaa !24
  %t106 = sdiv i64 %t102, %t103
  store i64 %t106, ptr %l87, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb36
bb36:
  %t108 = load i64, ptr %l87, !tbaa !24
  store i64 %t108, ptr %l84, !tbaa !24
  br label %bb37
bb37:
  %t109 = load i64, ptr %l84, !tbaa !24
  store i64 %t109, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  %t110 = load i64, ptr %l12, !tbaa !24
  %t111 = load i64, ptr %l11, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb39, label %bb40
bb39:
  br label %bb60
bb40:
  br label %bb41
bb41:
  %t118 = load i64, ptr %l8, !tbaa !24
  %t119 = load i64, ptr %l12, !tbaa !24
  %t120 = load i64, ptr %l10, !tbaa !24
  %t123 = mul i64 %t119, %t120
  %t126 = add i64 %t118, %t123
  %t128 = load i32, ptr %l3, !tbaa !23
  %t133 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %l5, i32 %t128, i64 %t126)
  store i64 %t133, ptr %l108
  br label %bb42
bb42:
  %t134 = load i64, ptr %l108, !tbaa !24
  store i64 %t134, ptr %l14, !tbaa !24
  %t135 = load i64, ptr %l14, !tbaa !24
  %t136 = load i64, ptr %l2, !tbaa !24
  %t139 = icmp eq i64 %t135, %t136
  br i1 %t139, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb45
bb44:
  %t141 = load i64, ptr %l14, !tbaa !24
  %t142 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t145 = icmp eq i64 %t141, %t142
  store i1 %t145, ptr %l112, !tbaa !21
  br label %bb45
bb45:
  %t147 = load i1, ptr %l112, !tbaa !21
  br i1 %t147, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t149 = load i64, ptr %l14, !tbaa !24
  %t151 = icmp sge i64 %t149, 0
  br i1 %t151, label %bb49, label %bb50
bb49:
  %t153 = load i64, ptr %l6, !tbaa !24
  %t154 = load i64, ptr %l14, !tbaa !24
  %t157 = icmp eq i64 %t153, %t154
  br i1 %t157, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb55
bb51:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb54
bb52:
  %t159 = load i32, ptr %l3, !tbaa !23
  %t160 = load i64, ptr %l14, !tbaa !24
  %t164 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %l5, i32 %t159, i64 %t160)
  store i64 %t164, ptr %l127
  br label %bb53
bb53:
  %t165 = load i64, ptr %l2, !tbaa !24
  %t166 = load i64, ptr %l127, !tbaa !24
  %t168 = icmp eq i64 %t166, %t165
  store i1 %t168, ptr %l123, !tbaa !21
  br label %bb54
bb54:
  %t170 = load i1, ptr %l123, !tbaa !21
  store i1 %t170, ptr %l119, !tbaa !21
  br label %bb55
bb55:
  %t171 = load i1, ptr %l119, !tbaa !21
  br i1 %t171, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t173 = load i64, ptr %l12, !tbaa !24
  %t175 = add i64 %t173, 1
  store i64 %t175, ptr %l12, !tbaa !24
  br label %bb38
bb60:
  store i64 0, ptr %l15, !tbaa !24
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr %"compiler/typed:Call", ptr %t177, i32 0, i32 1
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t180, 0
  store i64 %t182, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load i64, ptr %l15, !tbaa !24
  %t188 = icmp sgt i64 %t184, %t185
  br i1 %t188, label %bb61, label %bb62
bb61:
  %t190 = load i64, ptr %l17, !tbaa !24
  %t192 = icmp sgt i64 %t190, 0
  br i1 %t192, label %bb63, label %bb64
bb62:
  store i64 0, ptr %l139, !tbaa !24
  br label %bb66
bb63:
  %t194 = load i64, ptr %l16, !tbaa !24
  %t195 = load i64, ptr %l15, !tbaa !24
  %t198 = sub i64 %t194, %t195
  %t199 = load i64, ptr %l17, !tbaa !24
  %t202 = add i64 %t198, %t199
  %t204 = sub i64 %t202, 1
  %t205 = load i64, ptr %l17, !tbaa !24
  %t208 = sdiv i64 %t204, %t205
  store i64 %t208, ptr %l142, !tbaa !24
  br label %bb65
bb64:
  store i64 0, ptr %l142, !tbaa !24
  br label %bb65
bb65:
  %t210 = load i64, ptr %l142, !tbaa !24
  store i64 %t210, ptr %l139, !tbaa !24
  br label %bb66
bb66:
  %t211 = load i64, ptr %l139, !tbaa !24
  store i64 %t211, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb67
bb67:
  %t212 = load i64, ptr %l19, !tbaa !24
  %t213 = load i64, ptr %l18, !tbaa !24
  %t216 = icmp slt i64 %t212, %t213
  %t218 = xor i1 %t216, true
  br i1 %t218, label %bb68, label %bb69
bb68:
  br label %bb91
bb69:
  br label %bb70
bb70:
  %t220 = load i64, ptr %l15, !tbaa !24
  %t221 = load i64, ptr %l19, !tbaa !24
  %t222 = load i64, ptr %l17, !tbaa !24
  %t225 = mul i64 %t221, %t222
  %t228 = add i64 %t220, %t225
  store i64 %t228, ptr %l20, !tbaa !24
  %t230 = load i64, ptr %l20, !tbaa !24
  %t231 = load i64, ptr %l2, !tbaa !24
  %t234 = icmp eq i64 %t230, %t231
  br i1 %t234, label %bb71, label %bb72
bb71:
  br label %bb90
bb72:
  br label %bb73
bb73:
  %t236 = load i32, ptr %l3, !tbaa !23
  %t237 = load i64, ptr %l20, !tbaa !24
  %t241 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %l5, i32 %t236, i64 %t237)
  store i64 %t241, ptr %l166
  br label %bb74
bb74:
  %t242 = load i64, ptr %l166, !tbaa !24
  store i64 %t242, ptr %l21, !tbaa !24
  %t243 = load i64, ptr %l21, !tbaa !24
  %t244 = load i64, ptr %l2, !tbaa !24
  %t247 = icmp eq i64 %t243, %t244
  br i1 %t247, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l170, !tbaa !21
  br label %bb77
bb76:
  %t249 = load i64, ptr %l6, !tbaa !24
  %t250 = load i64, ptr %l20, !tbaa !24
  %t253 = icmp eq i64 %t249, %t250
  store i1 %t253, ptr %l170, !tbaa !21
  br label %bb77
bb77:
  %t255 = load i1, ptr %l170, !tbaa !21
  br i1 %t255, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l174, !tbaa !21
  br label %bb83
bb79:
  %t256 = load i64, ptr %l6, !tbaa !24
  %t258 = icmp sge i64 %t256, 0
  br i1 %t258, label %bb80, label %bb81
bb80:
  %t260 = load i64, ptr %l21, !tbaa !24
  %t261 = load i64, ptr %l6, !tbaa !24
  %t264 = icmp eq i64 %t260, %t261
  store i1 %t264, ptr %l177, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb82
bb82:
  %t266 = load i1, ptr %l177, !tbaa !21
  store i1 %t266, ptr %l174, !tbaa !21
  br label %bb83
bb83:
  %t267 = load i1, ptr %l174, !tbaa !21
  br i1 %t267, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l181, !tbaa !21
  br label %bb86
bb85:
  %t268 = load i64, ptr %l21, !tbaa !24
  %t269 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t272 = icmp eq i64 %t268, %t269
  store i1 %t272, ptr %l181, !tbaa !21
  br label %bb86
bb86:
  %t274 = load i1, ptr %l181, !tbaa !21
  br i1 %t274, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t276 = load i64, ptr %l19, !tbaa !24
  %t278 = add i64 %t276, 1
  store i64 %t278, ptr %l19, !tbaa !24
  br label %bb67
bb91:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr %"compiler/typed:Call", ptr %t281, i32 0, i32 0
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t287 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t280, ptr %t284)
  store i64 %t287, ptr %l191
  br label %bb92
bb92:
  %t288 = load i64, ptr %l191, !tbaa !24
  store i64 %t288, ptr %l22, !tbaa !24
  %t289 = load i64, ptr %l22, !tbaa !24
  %t291 = icmp slt i64 %t289, 0
  br i1 %t291, label %bb93, label %bb94
bb93:
  store i1 true, ptr %l194, !tbaa !21
  br label %bb96
bb94:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/scope:Scoper", ptr %t293, i32 0, i32 6
  %t296 = load i64, ptr %l22, !tbaa !24
  %t299 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t295, i64 %t296)
  store ptr %t299, ptr %l198
  br label %bb95
bb95:
  %t300 = load ptr, ptr %l198, !tbaa !29
  %t302 = getelementptr %"compiler/scope:summary", ptr %t300, i32 0, i32 14
  %t303 = load i1, ptr %t302, !tbaa !21
  %t305 = xor i1 %t303, true
  store i1 %t305, ptr %l194, !tbaa !21
  br label %bb96
bb96:
  %t307 = load i1, ptr %l194, !tbaa !21
  br i1 %t307, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l202, !tbaa !21
  br label %bb100
bb98:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/scope:Scoper", ptr %t308, i32 0, i32 6
  %t311 = load i64, ptr %l22, !tbaa !24
  %t314 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t310, i64 %t311)
  store ptr %t314, ptr %l206
  br label %bb99
bb99:
  %t315 = load ptr, ptr %l206, !tbaa !29
  %t317 = getelementptr %"compiler/scope:summary", ptr %t315, i32 0, i32 15
  %t318 = load i1, ptr %t317, !tbaa !21
  store i1 %t318, ptr %l202, !tbaa !21
  br label %bb100
bb100:
  %t320 = load i1, ptr %l202, !tbaa !21
  br i1 %t320, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb102:
  br label %bb103
bb103:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/scope:Scoper", ptr %t322, i32 0, i32 0
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t327 = getelementptr %"compiler/generic:Program", ptr %t325, i32 0, i32 2
  %t328 = load i32, ptr %l3, !tbaa !23
  %t331 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t327, i32 %t328)
  store { i64, ptr } %t331, ptr %l214
  br label %bb104
bb104:
  %t332 = load { i64, ptr }, ptr %l214, !tbaa !27
  store { i64, ptr } %t332, ptr %l23, !tbaa !27
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = getelementptr %"compiler/scope:Scoper", ptr %t333, i32 0, i32 0
  %t336 = load ptr, ptr %t335, !tbaa !29
  %t338 = getelementptr %"compiler/generic:Program", ptr %t336, i32 0, i32 2
  %t339 = load i32, ptr %l3, !tbaa !23
  %t340 = load i64, ptr %l2, !tbaa !24
  %t344 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t338, i32 %t339, i64 %t340)
  store i64 %t344, ptr %l220
  br label %bb105
bb105:
  %t345 = load i64, ptr %l220, !tbaa !24
  store i64 %t345, ptr %l24, !tbaa !24
  %t346 = load i64, ptr %l24, !tbaa !24
  %t348 = icmp sge i64 %t346, 0
  br i1 %t348, label %bb106, label %bb107
bb106:
  %t350 = load i64, ptr %l24, !tbaa !24
  store i64 %t350, ptr %l223, !tbaa !24
  br label %bb108
bb107:
  %t352 = load i64, ptr %l2, !tbaa !24
  store i64 %t352, ptr %l223, !tbaa !24
  br label %bb108
bb108:
  %t354 = load i64, ptr %l223, !tbaa !24
  store i64 %t354, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  %t355 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t355, 0
  store i64 %t357, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t359 = load i64, ptr %l27, !tbaa !24
  %t360 = load i64, ptr %l26, !tbaa !24
  %t363 = icmp sgt i64 %t359, %t360
  br i1 %t363, label %bb109, label %bb110
bb109:
  %t365 = load i64, ptr %l28, !tbaa !24
  %t367 = icmp sgt i64 %t365, 0
  br i1 %t367, label %bb111, label %bb112
bb110:
  store i64 0, ptr %l231, !tbaa !24
  br label %bb114
bb111:
  %t369 = load i64, ptr %l27, !tbaa !24
  %t370 = load i64, ptr %l26, !tbaa !24
  %t373 = sub i64 %t369, %t370
  %t374 = load i64, ptr %l28, !tbaa !24
  %t377 = add i64 %t373, %t374
  %t379 = sub i64 %t377, 1
  %t380 = load i64, ptr %l28, !tbaa !24
  %t383 = sdiv i64 %t379, %t380
  store i64 %t383, ptr %l234, !tbaa !24
  br label %bb113
bb112:
  store i64 0, ptr %l234, !tbaa !24
  br label %bb113
bb113:
  %t385 = load i64, ptr %l234, !tbaa !24
  store i64 %t385, ptr %l231, !tbaa !24
  br label %bb114
bb114:
  %t386 = load i64, ptr %l231, !tbaa !24
  store i64 %t386, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb115
bb115:
  %t387 = load i64, ptr %l30, !tbaa !24
  %t388 = load i64, ptr %l29, !tbaa !24
  %t391 = icmp slt i64 %t387, %t388
  %t393 = xor i1 %t391, true
  br i1 %t393, label %bb116, label %bb117
bb116:
  br label %bb147
bb117:
  br label %bb118
bb118:
  %t395 = load i64, ptr %l26, !tbaa !24
  %t396 = load i64, ptr %l30, !tbaa !24
  %t397 = load i64, ptr %l28, !tbaa !24
  %t400 = mul i64 %t396, %t397
  %t403 = add i64 %t395, %t400
  store i64 %t403, ptr %l31, !tbaa !24
  %t405 = load i64, ptr %l31, !tbaa !24
  %t407 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr i64, ptr %t408, i64 %t405
  %t410 = load i64, ptr %t409, !tbaa !34
  %t411 = load i64, ptr %l25, !tbaa !24
  %t414 = icmp ne i64 %t410, %t411
  br i1 %t414, label %bb119, label %bb120
bb119:
  br label %bb146
bb120:
  br label %bb121
bb121:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/scope:Scoper", ptr %t416, i32 0, i32 6
  %t419 = load i64, ptr %l22, !tbaa !24
  %t422 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t418, i64 %t419)
  store ptr %t422, ptr %l259
  br label %bb122
bb122:
  %t423 = load ptr, ptr %l259, !tbaa !29
  %t425 = getelementptr %"compiler/scope:summary", ptr %t423, i32 0, i32 0
  store ptr %t425, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb123
bb123:
  %t427 = load i64, ptr %l33, !tbaa !24
  store i64 %t427, ptr %l262, !tbaa !24
  %t428 = load ptr, ptr %l32, !tbaa !29
  %t430 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t428)
  store i64 %t430, ptr %l264
  br label %bb124
bb124:
  %t431 = load i64, ptr %l262, !tbaa !24
  %t432 = load i64, ptr %l264, !tbaa !24
  %t433 = icmp slt i64 %t431, %t432
  %t435 = xor i1 %t433, true
  br i1 %t435, label %bb125, label %bb126
bb125:
  br label %bb145
bb126:
  br label %bb127
bb127:
  %t437 = load ptr, ptr %l32, !tbaa !29
  %t438 = load i64, ptr %l33, !tbaa !24
  %t441 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t437, i64 %t438)
  store %"compiler/scope:rel" %t441, ptr %l269
  br label %bb128
bb128:
  %t442 = load %"compiler/scope:rel", ptr %l269
  store %"compiler/scope:rel" %t442, ptr %l34
  %t443 = getelementptr %"compiler/scope:rel", ptr %l34, i32 0, i32 0
  %t444 = load { i64, [2 x i64] }, ptr %t443
  %t446 = extractvalue { i64, [2 x i64] } %t444, 0
  %t447 = icmp eq i64 %t446, 2
  br i1 %t447, label %bb129, label %bb130
bb129:
  %t449 = getelementptr %"compiler/scope:rel", ptr %l34, i32 0, i32 0
  %t450 = getelementptr { i64, [2 x i64] }, ptr %t449, i32 0, i32 1
  %t451 = getelementptr { i64 }, ptr %t450, i32 0, i32 0
  %t452 = load i64, ptr %t451
  %t453 = load i64, ptr %l31, !tbaa !24
  %t456 = icmp eq i64 %t452, %t453
  store i1 %t456, ptr %l272, !tbaa !21
  br label %bb131
bb130:
  store i1 false, ptr %l272, !tbaa !21
  br label %bb131
bb131:
  %t458 = load i1, ptr %l272, !tbaa !21
  br i1 %t458, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l276, !tbaa !21
  br label %bb140
bb133:
  %t459 = getelementptr %"compiler/scope:rel", ptr %l34, i32 0, i32 2
  %t460 = load i1, ptr %t459, !tbaa !21
  br i1 %t460, label %bb134, label %bb135
bb134:
  %t462 = getelementptr %"compiler/scope:rel", ptr %l34, i32 0, i32 1
  %t463 = load { i64, [2 x i64] }, ptr %t462
  %t465 = extractvalue { i64, [2 x i64] } %t463, 0
  %t466 = icmp eq i64 %t465, 2
  br i1 %t466, label %bb136, label %bb137
bb135:
  store i1 false, ptr %l278, !tbaa !21
  br label %bb139
bb136:
  %t468 = getelementptr %"compiler/scope:rel", ptr %l34, i32 0, i32 1
  %t469 = getelementptr { i64, [2 x i64] }, ptr %t468, i32 0, i32 1
  %t470 = getelementptr { i64 }, ptr %t469, i32 0, i32 0
  %t471 = load i64, ptr %t470
  %t472 = load i64, ptr %l31, !tbaa !24
  %t475 = icmp eq i64 %t471, %t472
  store i1 %t475, ptr %l281, !tbaa !21
  br label %bb138
bb137:
  store i1 false, ptr %l281, !tbaa !21
  br label %bb138
bb138:
  %t477 = load i1, ptr %l281, !tbaa !21
  store i1 %t477, ptr %l278, !tbaa !21
  br label %bb139
bb139:
  %t478 = load i1, ptr %l278, !tbaa !21
  store i1 %t478, ptr %l276, !tbaa !21
  br label %bb140
bb140:
  %t479 = load i1, ptr %l276, !tbaa !21
  br i1 %t479, label %bb141, label %bb142
bb141:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb142:
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t481 = load i64, ptr %l33, !tbaa !24
  %t483 = add i64 %t481, 1
  store i64 %t483, ptr %l33, !tbaa !24
  br label %bb123
bb145:
  br label %bb146
bb146:
  %t485 = load i64, ptr %l30, !tbaa !24
  %t487 = add i64 %t485, 1
  store i64 %t487, ptr %l30, !tbaa !24
  br label %bb115
bb147:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/scope:Scoper", ptr %t489, i32 0, i32 6
  %t492 = load i64, ptr %l22, !tbaa !24
  %t495 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t491, i64 %t492)
  store ptr %t495, ptr %l293
  br label %bb148
bb148:
  %t496 = load ptr, ptr %l293, !tbaa !29
  %t498 = getelementptr %"compiler/scope:summary", ptr %t496, i32 0, i32 0
  store ptr %t498, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb149
bb149:
  %t500 = load i64, ptr %l36, !tbaa !24
  store i64 %t500, ptr %l296, !tbaa !24
  %t501 = load ptr, ptr %l35, !tbaa !29
  %t503 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t501)
  store i64 %t503, ptr %l298
  br label %bb150
bb150:
  %t504 = load i64, ptr %l296, !tbaa !24
  %t505 = load i64, ptr %l298, !tbaa !24
  %t506 = icmp slt i64 %t504, %t505
  %t508 = xor i1 %t506, true
  br i1 %t508, label %bb151, label %bb152
bb151:
  br label %bb167
bb152:
  br label %bb153
bb153:
  %t510 = load ptr, ptr %l35, !tbaa !29
  %t511 = load i64, ptr %l36, !tbaa !24
  %t514 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t510, i64 %t511)
  store %"compiler/scope:rel" %t514, ptr %l303
  br label %bb154
bb154:
  %t515 = load %"compiler/scope:rel", ptr %l303
  store %"compiler/scope:rel" %t515, ptr %l37
  %t516 = getelementptr %"compiler/scope:rel", ptr %l37, i32 0, i32 0
  %t517 = load { i64, [2 x i64] }, ptr %t516
  %t518 = load i64, ptr %l2, !tbaa !24
  %t521 = call i1 @compiler_2fscope_2ederivedOf({ i64, [2 x i64] } %t517, i64 %t518)
  store i1 %t521, ptr %l306
  br label %bb155
bb155:
  %t522 = load i1, ptr %l306, !tbaa !21
  br i1 %t522, label %bb156, label %bb157
bb156:
  store i1 true, ptr %l307, !tbaa !21
  br label %bb162
bb157:
  %t523 = getelementptr %"compiler/scope:rel", ptr %l37, i32 0, i32 2
  %t524 = load i1, ptr %t523, !tbaa !21
  br i1 %t524, label %bb158, label %bb159
bb158:
  %t526 = getelementptr %"compiler/scope:rel", ptr %l37, i32 0, i32 1
  %t527 = load { i64, [2 x i64] }, ptr %t526
  %t528 = load i64, ptr %l2, !tbaa !24
  %t531 = call i1 @compiler_2fscope_2ederivedOf({ i64, [2 x i64] } %t527, i64 %t528)
  store i1 %t531, ptr %l312
  br label %bb160
bb159:
  store i1 false, ptr %l309, !tbaa !21
  br label %bb161
bb160:
  %t532 = load i1, ptr %l312, !tbaa !21
  store i1 %t532, ptr %l309, !tbaa !21
  br label %bb161
bb161:
  %t533 = load i1, ptr %l309, !tbaa !21
  store i1 %t533, ptr %l307, !tbaa !21
  br label %bb162
bb162:
  %t534 = load i1, ptr %l307, !tbaa !21
  br i1 %t534, label %bb163, label %bb164
bb163:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb164:
  br label %bb165
bb165:
  br label %bb166
bb166:
  %t536 = load i64, ptr %l36, !tbaa !24
  %t538 = add i64 %t536, 1
  store i64 %t538, ptr %l36, !tbaa !24
  br label %bb149
bb167:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecaptureVar(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, [1 x i64] }
  %l11 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l46 = alloca { i64, [1 x i64] }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l15, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 6
  %t11 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %l3)
  store i64 %t14, ptr %l19
  br label %bb2
bb2:
  %t15 = load i64, ptr %l19, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l26, !tbaa !24
  store i64 %t42, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l23, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %bb27
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %l3, i64 %t62)
  store { i64, [1 x i64] } %t65, ptr %l46
  br label %bb13
bb13:
  %t66 = load { i64, [1 x i64] }, ptr %l46
  store { i64, [1 x i64] } %t66, ptr %l10
  %t67 = load { i64, [1 x i64] }, ptr %l10
  %t69 = extractvalue { i64, [1 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 4
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t72 = getelementptr { i64, [1 x i64] }, ptr %l10, i32 0, i32 1
  %t73 = getelementptr { i32 }, ptr %t72, i32 0, i32 0
  %t74 = load i32, ptr %t73
  store i32 %t74, ptr %l11, !tbaa !23
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t76 = load i32, ptr %l11, !tbaa !23
  %t80 = icmp eq i32 %t76, %a2
  br i1 %t80, label %bb17, label %bb18
bb17:
  %t82 = load i64, ptr %l9, !tbaa !24
  store i64 %t82, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_5cb72587228936ff_1a6837af5c2cdca3)
  unreachable
bb25:
  br label %bb26
bb26:
  %t84 = load i64, ptr %l8, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l8, !tbaa !24
  br label %bb9
bb27:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarries(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %s0, ptr %t3, ptr %a1, ptr %l2)
  br label %bb2
bb2:
  store ptr %l2, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l12, !tbaa !24
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t11)
  store i64 %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = load i64, ptr %l14, !tbaa !24
  %t16 = icmp slt i64 %t14, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %bb14
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t20, i64 %t21)
  store i64 %t24, ptr %l19
  br label %bb8
bb8:
  %t25 = load i64, ptr %l19, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 108
  %t32 = call i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %t28, i64 %t25)
  store i1 %t32, ptr %l23
  br label %bb9
bb9:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb3
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceDest(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, [2 x i64] }
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca ptr
  %l25 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i1
  %l38 = alloca { i64, [2 x i64] }
  %l41 = alloca i1
  %l43 = alloca i1
  %l49 = alloca { i64, [2 x i64] }
  %l51 = alloca { i64, [2 x i64] }
  %l53 = alloca i1
  %l60 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t11 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 118
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 118
  store i1 false, ptr %t8, !tbaa !21
  %t9 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t9, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store { i64, [2 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t11, i32 0, i32 0
  store i64 0, ptr %t12
  %t13 = load { i64, [2 x i64] }, ptr %t11
  store { i64, [2 x i64] } %t13, ptr %l3
  store ptr %a1, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t17 = load i64, ptr %l5, !tbaa !24
  store i64 %t17, ptr %l14, !tbaa !24
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %t18)
  store i64 %t20, ptr %l16
  br label %bb5
bb5:
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = icmp slt i64 %t21, %t22
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb39
bb7:
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1, ptr %v1, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l21
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l21, !tbaa !29
  store ptr %t32, ptr %l6, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l6, !tbaa !29
  %t38 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  store i1 %t38, ptr %l25
  br label %bb10
bb10:
  %t39 = load i1, ptr %l25, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb14
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t44 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %t40, ptr %t41)
  store i1 %t44, ptr %l29
  br label %bb13
bb13:
  %t45 = load i1, ptr %l29, !tbaa !21
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb19
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l31, !tbaa !29
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t48)
  store i32 %t50, ptr %l33
  br label %bb17
bb17:
  %t51 = load ptr, ptr %l31, !tbaa !29
  %t52 = load i32, ptr %l33, !tbaa !23
  %t53 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t53, ptr %l34
  br label %bb18
bb18:
  %t54 = load i1, ptr %l34, !tbaa !21
  %t55 = xor i1 %t54, true
  store i1 %t55, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l30, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  br label %bb38
bb21:
  br label %bb22
bb22:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l6, !tbaa !29
  %t62 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoicePeek(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  store { i64, [2 x i64] } %t62, ptr %l38
  br label %bb23
bb23:
  %t63 = load { i64, [2 x i64] }, ptr %l38
  store { i64, [2 x i64] } %t63, ptr %l7
  %t64 = load { i64, [2 x i64] }, ptr %l7
  %t66 = extractvalue { i64, [2 x i64] } %t64, 0
  %t67 = icmp eq i64 %t66, 0
  br i1 %t67, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb27
bb25:
  %t69 = load { i64, [2 x i64] }, ptr %l7
  %t71 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t69)
  store i1 %t71, ptr %l43
  br label %bb26
bb26:
  %t72 = load i1, ptr %l43, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l41, !tbaa !21
  br label %bb27
bb27:
  %t75 = load i1, ptr %l41, !tbaa !21
  br i1 %t75, label %bb28, label %bb29
bb28:
  %t76 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t76, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t78 = load { i64, [2 x i64] }, ptr %l3
  %t80 = extractvalue { i64, [2 x i64] } %t78, 0
  %t81 = icmp eq i64 %t80, 0
  br i1 %t81, label %bb31, label %bb32
bb31:
  %t83 = load { i64, [2 x i64] }, ptr %l7
  store { i64, [2 x i64] } %t83, ptr %l3
  br label %bb37
bb32:
  %t85 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t85, ptr %l49
  %t86 = load { i64, [2 x i64] }, ptr %l7
  store { i64, [2 x i64] } %t86, ptr %l51
  %t89 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l49, ptr %l51)
  store i1 %t89, ptr %l53
  br label %bb33
bb33:
  %t90 = load i1, ptr %l53, !tbaa !21
  %t91 = xor i1 %t90, true
  br i1 %t91, label %bb34, label %bb35
bb34:
  %t93 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t93, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t95 = load i64, ptr %l5, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l5, !tbaa !24
  br label %bb4
bb39:
  %t99 = load { i64, [2 x i64] }, ptr %l3
  %t101 = extractvalue { i64, [2 x i64] } %t99, 0
  %t102 = icmp eq i64 %t101, 0
  br i1 %t102, label %bb40, label %bb41
bb40:
  %t104 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t104, ptr %l60
  br label %bb42
bb41:
  %t106 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t106, ptr %l60
  br label %bb42
bb42:
  %t108 = load { i64, [2 x i64] }, ptr %l60
  store { i64, [2 x i64] } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecomponent(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i1
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l38 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l64 = alloca i64
  %l67 = alloca i64
  %l73 = alloca ptr
  %l76 = alloca i64
  %l79 = alloca i1
  %l82 = alloca i64
  %l96 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l121 = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb4
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l27, !tbaa !27
  %t9 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i64, ptr %t10, i64 0
  %t12 = load i64, ptr %t11, !tbaa !34
  %t15 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallsItself(ptr %v0, ptr %t7, i64 %t12)
  store i1 %t15, ptr %l29
  br label %bb3
bb3:
  %t16 = load i1, ptr %l29, !tbaa !21
  store i1 %t16, ptr %l25, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l25, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l5, !tbaa !24
  br label %bb7
bb6:
  br label %bb39
bb7:
  %t26 = load i64, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t34, ptr %l38, !tbaa !27
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i64, ptr %t38, i64 %t35
  %t40 = load i64, ptr %t39, !tbaa !34
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/scope:Scoper", ptr %t42, i32 0, i32 6
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t44, i64 %t40)
  store ptr %t48, ptr %l44
  br label %bb11
bb11:
  %t49 = load ptr, ptr %l44, !tbaa !29
  %t51 = getelementptr %"compiler/scope:summary", ptr %t49, i32 0, i32 15
  store i1 true, ptr %t51, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l4, !tbaa !24
  br label %bb7
bb13:
  br label %bb14
bb14:
  store i1 false, ptr %l7, !tbaa !21
  %t56 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t56, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l10, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb16, label %bb17
bb16:
  br label %bb33
bb17:
  br label %bb18
bb18:
  %t70 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t70, ptr %l55, !tbaa !27
  %t71 = load i64, ptr %l9, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i64, ptr %t74, i64 %t71
  %t76 = load i64, ptr %t75, !tbaa !34
  store i64 %t76, ptr %l11, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/scope:Scoper", ptr %t78, i32 0, i32 6
  %t81 = load i64, ptr %l11, !tbaa !24
  %t84 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t80, i64 %t81)
  store ptr %t84, ptr %l61
  br label %bb19
bb19:
  %t85 = load ptr, ptr %l61, !tbaa !29
  %t87 = getelementptr %"compiler/scope:summary", ptr %t85, i32 0, i32 0
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t87)
  store i64 %t89, ptr %l64
  br label %bb20
bb20:
  %t90 = load i64, ptr %l64, !tbaa !24
  store i64 %t90, ptr %l12, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr %l11, !tbaa !24
  %t95 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efacts(ptr %v0, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l67
  br label %bb21
bb21:
  %t96 = load i64, ptr %l67, !tbaa !24
  store i64 %t96, ptr %l13, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudge(ptr %v0, ptr %t97, i64 %t98, i1 false)
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/scope:Scoper", ptr %t101, i32 0, i32 6
  %t104 = load i64, ptr %l11, !tbaa !24
  %t107 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t103, i64 %t104)
  store ptr %t107, ptr %l73
  br label %bb23
bb23:
  %t108 = load ptr, ptr %l73, !tbaa !29
  %t110 = getelementptr %"compiler/scope:summary", ptr %t108, i32 0, i32 0
  %t112 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t110)
  store i64 %t112, ptr %l76
  br label %bb24
bb24:
  %t113 = load i64, ptr %l12, !tbaa !24
  %t114 = load i64, ptr %l76, !tbaa !24
  %t116 = icmp ne i64 %t114, %t113
  br i1 %t116, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb28
bb26:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efacts(ptr %v0, ptr %t118, i64 %t119)
  store i64 %t122, ptr %l82
  br label %bb27
bb27:
  %t123 = load i64, ptr %l13, !tbaa !24
  %t124 = load i64, ptr %l82, !tbaa !24
  %t126 = icmp ne i64 %t124, %t123
  store i1 %t126, ptr %l79, !tbaa !21
  br label %bb28
bb28:
  %t128 = load i1, ptr %l79, !tbaa !21
  br i1 %t128, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t129 = load i64, ptr %l9, !tbaa !24
  %t131 = add i64 %t129, 1
  store i64 %t131, ptr %l9, !tbaa !24
  br label %bb15
bb33:
  %t133 = load i1, ptr %l7, !tbaa !21
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb34, label %bb35
bb34:
  br label %bb38
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb14
bb38:
  br label %bb39
bb39:
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  store i64 %t141, ptr %l16, !tbaa !24
  br label %bb40
bb40:
  %t143 = load i64, ptr %l15, !tbaa !24
  %t144 = load i64, ptr %l16, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb41, label %bb42
bb41:
  br label %bb46
bb42:
  br label %bb43
bb43:
  %t151 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t151, ptr %l96, !tbaa !27
  %t152 = load i64, ptr %l15, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr i64, ptr %t155, i64 %t152
  %t157 = load i64, ptr %t156, !tbaa !34
  %t159 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudge(ptr %v0, ptr %t159, i64 %t157, i1 true)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t163 = load i64, ptr %l15, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l15, !tbaa !24
  br label %bb40
bb46:
  %t167 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t167, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  store i64 %t171, ptr %l20, !tbaa !24
  br label %bb47
bb47:
  %t173 = load i64, ptr %l19, !tbaa !24
  %t174 = load i64, ptr %l20, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb48, label %bb49
bb48:
  br label %bb54
bb49:
  br label %bb50
bb50:
  %t181 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t181, ptr %l110, !tbaa !27
  %t182 = load i64, ptr %l19, !tbaa !24
  %t184 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !27
  %t186 = getelementptr i64, ptr %t185, i64 %t182
  %t187 = load i64, ptr %t186, !tbaa !34
  store i64 %t187, ptr %l21, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/scope:Scoper", ptr %t189, i32 0, i32 6
  %t192 = load i64, ptr %l21, !tbaa !24
  %t195 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t191, i64 %t192)
  store ptr %t195, ptr %l116
  br label %bb51
bb51:
  %t196 = load ptr, ptr %l116, !tbaa !29
  %t198 = getelementptr %"compiler/scope:summary", ptr %t196, i32 0, i32 14
  store i1 true, ptr %t198, !tbaa !21
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/scope:Scoper", ptr %t199, i32 0, i32 6
  %t202 = load i64, ptr %l21, !tbaa !24
  %t205 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t201, i64 %t202)
  store ptr %t205, ptr %l121
  br label %bb52
bb52:
  %t206 = load ptr, ptr %l121, !tbaa !29
  %t208 = getelementptr %"compiler/scope:summary", ptr %t206, i32 0, i32 15
  store i1 false, ptr %t208, !tbaa !21
  br label %bb53
bb53:
  %t209 = load i64, ptr %l19, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l19, !tbaa !24
  br label %bb47
bb54:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  store i1 %t12, ptr %l3, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d29996678377eee3_d1b974339c283baf)
  unreachable
bb9:
  %t14 = load i1, ptr %l3, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l20 = alloca i64
  %rv = alloca i64
  %t34 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_f1651a5ea92fc764_7e198d85ea96f48)
  unreachable
bb2:
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/scope:Scoper", ptr %t18, i32 0, i32 25
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 3
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = sext i32 %t27 to i64
  %t30 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t31 = load i32, ptr %t30, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 3, ptr %t35
  %t37 = insertvalue { i64, i64, i64 } undef, i64 %t25, 0
  %t39 = insertvalue { i64, i64, i64 } %t37, i64 %t29, 1
  %t41 = insertvalue { i64, i64, i64 } %t39, i64 %t33, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { i64, i64, i64 } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t48 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %t45, { i64, [3 x i64] } %t43, %"compiler/msgs:Msg" %a2)
  store i64 %t48, ptr %l20
  br label %bb4
bb4:
  %t49 = load i64, ptr %l20, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eexports(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca ptr
  %l52 = alloca i64
  %l56 = alloca ptr
  %l60 = alloca i1
  %l64 = alloca ptr
  %l67 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l103 = alloca { i64, [3 x i64] }
  %l107 = alloca { i64, ptr }
  %l109 = alloca %"compiler/msgs:Msg"
  %l110 = alloca i64
  %s3 = alloca %olang.scope
  %t192 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load i64, ptr %l15, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l22, !tbaa !24
  store i64 %t33, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l19, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb42
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/scope:Scoper", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l43
  br label %bb12
bb12:
  %t60 = load ptr, ptr %l43, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 1
  %t63 = load { i64, [2 x i64] }, ptr %t62
  store { i64, [2 x i64] } %t63, ptr %l7
  %t65 = load { i64, [2 x i64] }, ptr %l7
  %t67 = extractvalue { i64, [2 x i64] } %t65, 0
  %t68 = icmp eq i64 %t67, 0
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t71 = getelementptr { i64 }, ptr %t70, i32 0, i32 0
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l8, !tbaa !24
  br label %bb15
bb14:
  br label %bb35
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/scope:Scoper", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t77, i64 %t78)
  store i64 %t81, ptr %l52
  br label %bb16
bb16:
  %t82 = load i64, ptr %l52, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l56
  br label %bb17
bb17:
  %t91 = load ptr, ptr %l56, !tbaa !29
  %t93 = getelementptr %"compiler/ast:Func", ptr %t91, i32 0, i32 7
  %t94 = load i1, ptr %t93, !tbaa !21
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb22
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/scope:Scoper", ptr %t98, i32 0, i32 6
  %t101 = load i64, ptr %l6, !tbaa !24
  %t104 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t100, i64 %t101)
  store ptr %t104, ptr %l64
  br label %bb20
bb20:
  %t105 = load ptr, ptr %l64, !tbaa !29
  %t107 = getelementptr %"compiler/scope:summary", ptr %t105, i32 0, i32 0
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t107)
  store i64 %t109, ptr %l67
  br label %bb21
bb21:
  %t110 = load i64, ptr %l67, !tbaa !24
  %t111 = icmp eq i64 %t110, 0
  store i1 %t111, ptr %l60, !tbaa !21
  br label %bb22
bb22:
  %t113 = load i1, ptr %l60, !tbaa !21
  br i1 %t113, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb24:
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t117, i64 %t118)
  store ptr %t121, ptr %l72
  br label %bb26
bb26:
  %t122 = load ptr, ptr %l72, !tbaa !29
  store ptr %t122, ptr %l10, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/load:Loader", ptr %t129, i32 0, i32 5
  store ptr %t131, ptr %l76, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/scope:Scoper", ptr %t132, i32 0, i32 0
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t136 = load i64, ptr %l9, !tbaa !24
  %t139 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t135, i64 %t136)
  store i64 %t139, ptr %l80
  br label %bb27
bb27:
  %t140 = load ptr, ptr %l76, !tbaa !29
  %t141 = load i64, ptr %l80, !tbaa !24
  %t142 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  store ptr %t142, ptr %l81
  br label %bb28
bb28:
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t145 = getelementptr %"compiler/load:Module", ptr %t143, i32 0, i32 4
  %t146 = load i64, ptr %t145, !tbaa !24
  store i64 %t146, ptr %l11, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i64, ptr %l6, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/scope:Scoper", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/load:Loader", ptr %t156, i32 0, i32 3
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t163 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v0, ptr %s3, ptr %t148, i64 %t149, ptr %t159)
  store { i64, ptr } %t163, ptr %l90
  br label %bb29
bb29:
  %t164 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t164, ptr %l12, !tbaa !27
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/scope:Scoper", ptr %t165, i32 0, i32 0
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/load:Loader", ptr %t171, i32 0, i32 4
  %t174 = load ptr, ptr %t173, !tbaa !29
  store ptr %t174, ptr %l94, !tbaa !29
  %t175 = load i64, ptr %l11, !tbaa !24
  %t176 = load ptr, ptr %l10, !tbaa !29
  %t178 = getelementptr %"compiler/ast:Func", ptr %t176, i32 0, i32 0
  %t179 = getelementptr %"compiler/source:Span", ptr %t178, i32 0, i32 0
  %t180 = load i32, ptr %t179, !tbaa !23
  %t182 = sext i32 %t180 to i64
  %t183 = load ptr, ptr %l10, !tbaa !29
  %t185 = getelementptr %"compiler/ast:Func", ptr %t183, i32 0, i32 0
  %t186 = getelementptr %"compiler/source:Span", ptr %t185, i32 0, i32 0
  %t187 = load i32, ptr %t186, !tbaa !23
  %t189 = sext i32 %t187 to i64
  %t191 = add i64 %t189, 6
  store { i64, [3 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 0
  store i64 3, ptr %t193
  %t195 = insertvalue { i64, i64, i64 } undef, i64 %t175, 0
  %t197 = insertvalue { i64, i64, i64 } %t195, i64 %t182, 1
  %t199 = insertvalue { i64, i64, i64 } %t197, i64 %t191, 2
  %t200 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  store { i64, i64, i64 } %t199, ptr %t200
  %t201 = load { i64, [3 x i64] }, ptr %t192
  store { i64, [3 x i64] } %t201, ptr %l103
  %t202 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t206 = icmp sgt i64 %t204, 0
  br i1 %t206, label %bb30, label %bb31
bb30:
  %t208 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, ptr }, ptr %t209, i64 0
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !37
  store { i64, ptr } %t211, ptr %l107, !tbaa !27
  br label %bb32
bb31:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l107, !tbaa !27
  br label %bb32
bb32:
  %t213 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t214 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportObligation(ptr %s3, ptr %s3, { i64, ptr } %t213)
  store %"compiler/msgs:Msg" %t214, ptr %l109
  br label %bb33
bb33:
  %t215 = load ptr, ptr %l94, !tbaa !29
  %t216 = load { i64, [3 x i64] }, ptr %l103
  %t217 = load %"compiler/msgs:Msg", ptr %l109
  %t218 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t215, { i64, [3 x i64] } %t216, %"compiler/msgs:Msg" %t217)
  store i64 %t218, ptr %l110
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_3d4ddf74a6173f57_410f107a77dd9b9b)
  unreachable
bb40:
  br label %bb41
bb41:
  %t219 = load i64, ptr %l5, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l5, !tbaa !24
  br label %bb8
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efacts(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 6
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/scope:summary", ptr %t9, i32 0, i32 1
  %t13 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/scope:summary", ptr %t14, i32 0, i32 2
  %t18 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l12
  br label %bb3
bb3:
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = add i64 %t19, %t20
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/scope:summary", ptr %t22, i32 0, i32 5
  %t26 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l16
  br label %bb4
bb4:
  %t27 = load i64, ptr %l13, !tbaa !24
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = add i64 %t27, %t28
  store i64 %t29, ptr %l17, !tbaa !24
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/scope:summary", ptr %t30, i32 0, i32 6
  %t34 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l20
  br label %bb5
bb5:
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = load i64, ptr %l20, !tbaa !24
  %t37 = add i64 %t35, %t36
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr %"compiler/scope:summary", ptr %t38, i32 0, i32 7
  %t42 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t40)
  store i64 %t42, ptr %l24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l21, !tbaa !24
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = add i64 %t43, %t44
  store i64 %t45, ptr %l25, !tbaa !24
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr %"compiler/scope:summary", ptr %t46, i32 0, i32 8
  %t50 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t48)
  store i64 %t50, ptr %l28
  br label %bb7
bb7:
  %t51 = load i64, ptr %l25, !tbaa !24
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = add i64 %t51, %t52
  store i64 %t53, ptr %l29, !tbaa !24
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = getelementptr %"compiler/scope:summary", ptr %t54, i32 0, i32 9
  %t58 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l32
  br label %bb8
bb8:
  %t59 = load i64, ptr %l29, !tbaa !24
  %t60 = load i64, ptr %l32, !tbaa !24
  %t61 = add i64 %t59, %t60
  store i64 %t61, ptr %l33, !tbaa !24
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/scope:summary", ptr %t62, i32 0, i32 10
  %t66 = call i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l36
  br label %bb9
bb9:
  %t67 = load i64, ptr %l33, !tbaa !24
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = add i64 %t67, %t68
  store i64 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l16 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l31 = alloca i1
  %l44 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 10
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l11
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l10
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t13, ptr %l3, !tbaa !27
  %t14 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t15 = load i32, ptr %t14, !tbaa !23
  %t17 = sext i32 %t15 to i64
  store i64 %t17, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = icmp slt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb7
bb6:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t29 = icmp sge i64 %t23, %t26
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t32 = load %"compiler/source:Span", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t32, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t34 = load i64, ptr %l4, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t42 = icmp slt i64 %t36, %t39
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t44 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t44, ptr %l28, !tbaa !27
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t45
  %t50 = load i8, ptr %t49, !tbaa !32
  %t52 = call i1 @compiler_2fscope_2eisNameChar(i8 %t50)
  store i1 %t52, ptr %l31
  br label %bb14
bb13:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb15
bb14:
  %t53 = load i1, ptr %l31, !tbaa !21
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t54 = load i1, ptr %l27, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t57 = load i64, ptr %l5, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l5, !tbaa !24
  br label %bb19
bb19:
  br label %bb11
bb20:
  %t61 = load i64, ptr %l5, !tbaa !24
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = icmp eq i64 %t61, %t62
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l5, !tbaa !24
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = trunc i64 %t71 to i32
  %t74 = load i64, ptr %l5, !tbaa !24
  %t76 = trunc i64 %t74 to i32
  %t79 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t73, i32 %t76)
  store %"compiler/source:Span" %t79, ptr %l44
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t80 = load %"compiler/source:Span", ptr %l44
  store %"compiler/source:Span" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2, i1 %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i1
  %l28 = alloca i64
  %l31 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l56 = alloca ptr
  %l60 = alloca { i64, [2 x i64] }
  %l68 = alloca i1
  %l69 = alloca { i64, [2 x i64] }
  %l71 = alloca { i64, [2 x i64] }
  %l73 = alloca i1
  %l75 = alloca i1
  %l79 = alloca i1
  %l83 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l97 = alloca i64
  %l101 = alloca i1
  %l103 = alloca i1
  %l104 = alloca { i64, [2 x i64] }
  %l106 = alloca { i64, [2 x i64] }
  %l108 = alloca i1
  %l113 = alloca i64
  %l117 = alloca i1
  %l120 = alloca i1
  %l132 = alloca i1
  %l147 = alloca i1
  %l148 = alloca { i64, [2 x i64] }
  %l150 = alloca { i64, [2 x i64] }
  %l152 = alloca i1
  %l157 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  store i1 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  %t6 = load { i64, [2 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  store i1 %t9, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l17, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 78
  store { i64, [2 x i64] } %t13, ptr %t16
  %t17 = load { i64, [2 x i64] }, ptr %l1
  %t19 = extractvalue { i64, [2 x i64] } %t17, 0
  %t20 = icmp eq i64 %t19, 5
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t23 = getelementptr { i64 }, ptr %t22, i32 0, i32 0
  %t24 = load i64, ptr %t23
  store i64 %t24, ptr %l6, !tbaa !24
  br label %bb9
bb8:
  br label %bb26
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 36
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t28, i64 %t29)
  store i64 %t32, ptr %l28
  br label %bb10
bb10:
  %t33 = load i64, ptr %l28, !tbaa !24
  store i64 %t33, ptr %l7, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %t34, i64 %t35)
  store i64 %t38, ptr %l31
  br label %bb11
bb11:
  %t39 = load i64, ptr %l31, !tbaa !24
  store i64 %t39, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = load i64, ptr %l9, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb17
bb14:
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l38, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb16
bb16:
  %t66 = load i64, ptr %l38, !tbaa !24
  store i64 %t66, ptr %l35, !tbaa !24
  br label %bb17
bb17:
  %t67 = load i64, ptr %l35, !tbaa !24
  store i64 %t67, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb18
bb18:
  %t68 = load i64, ptr %l11, !tbaa !24
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb19, label %bb20
bb19:
  br label %bb25
bb20:
  br label %bb21
bb21:
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = load i64, ptr %l11, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l56, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/scope:Scoper", ptr %t87, i32 0, i32 37
  %t93 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t89, i64 %t84)
  store { i64, [2 x i64] } %t93, ptr %l60
  br label %bb22
bb22:
  %t94 = load { i64, [2 x i64] }, ptr %l2
  %t95 = load i1, ptr %l3, !tbaa !21
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t97 = load i64, ptr %l5, !tbaa !24
  %t98 = load ptr, ptr %l56, !tbaa !29
  %t99 = load { i64, [2 x i64] }, ptr %l60
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t98, { i64, [2 x i64] } %t99, { i64, [2 x i64] } %t94, i1 %t95, ptr %t96, i64 %t97)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t104 = load i64, ptr %l11, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l11, !tbaa !24
  br label %bb18
bb25:
  br label %ret
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_47dfda24c0d910ef_d5dd1abdea0dbd2b)
  unreachable
bb31:
  %t108 = load i1, ptr %l3, !tbaa !21
  br i1 %t108, label %bb32, label %bb33
bb32:
  %t110 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t110, ptr %l69
  %t111 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t111, ptr %l71
  %t114 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l69, ptr %l71)
  store i1 %t114, ptr %l73
  br label %bb34
bb33:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb35
bb34:
  %t115 = load i1, ptr %l73, !tbaa !21
  %t116 = xor i1 %t115, true
  store i1 %t116, ptr %l68, !tbaa !21
  br label %bb35
bb35:
  %t118 = load i1, ptr %l68, !tbaa !21
  br i1 %t118, label %bb36, label %bb37
bb36:
  %t119 = load i64, ptr %l5, !tbaa !24
  %t120 = load i64, ptr @G_2ecompiler_2fscope_2eFitLocal, !tbaa !24
  %t123 = icmp eq i64 %t119, %t120
  br i1 %t123, label %bb38, label %bb39
bb37:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb41
bb38:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb40
bb39:
  %t125 = load i64, ptr %l5, !tbaa !24
  %t126 = load i64, ptr @G_2ecompiler_2fscope_2eFitValue, !tbaa !24
  %t129 = icmp eq i64 %t125, %t126
  store i1 %t129, ptr %l79, !tbaa !21
  br label %bb40
bb40:
  %t131 = load i1, ptr %l79, !tbaa !21
  store i1 %t131, ptr %l75, !tbaa !21
  br label %bb41
bb41:
  %t132 = load i1, ptr %l75, !tbaa !21
  br i1 %t132, label %bb42, label %bb43
bb42:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load { i64, [2 x i64] }, ptr %l1
  %t137 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedTerm(ptr %v0, ptr %t133, { i64, [2 x i64] } %t134)
  store i1 %t137, ptr %l86
  br label %bb44
bb43:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb49
bb44:
  %t138 = load i1, ptr %l86, !tbaa !21
  br i1 %t138, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb48
bb46:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load { i64, [2 x i64] }, ptr %l2
  %t143 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ederivedTerm(ptr %v0, ptr %t139, { i64, [2 x i64] } %t140)
  store i1 %t143, ptr %l90
  br label %bb47
bb47:
  %t144 = load i1, ptr %l90, !tbaa !21
  store i1 %t144, ptr %l87, !tbaa !21
  br label %bb48
bb48:
  %t145 = load i1, ptr %l87, !tbaa !21
  store i1 %t145, ptr %l83, !tbaa !21
  br label %bb49
bb49:
  %t146 = load i1, ptr %l83, !tbaa !21
  br i1 %t146, label %bb50, label %bb51
bb50:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l4, !tbaa !29
  %t149 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efitError(ptr %v0, ptr %v1, ptr %t147, ptr %t148, i64 %t149, i1 true)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %ret
bb53:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, [2 x i64] }, ptr %l1
  %t155 = load { i64, [2 x i64] }, ptr %l2
  %t159 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t153, { i64, [2 x i64] } %t154, { i64, [2 x i64] } %t155)
  store i64 %t159, ptr %l97
  br label %bb54
bb54:
  %t160 = load i64, ptr %l97, !tbaa !24
  store i64 %t160, ptr %l13, !tbaa !24
  %t161 = load i64, ptr %l13, !tbaa !24
  %t162 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t165 = icmp eq i64 %t161, %t162
  br i1 %t165, label %bb55, label %bb56
bb55:
  %t167 = load i1, ptr %l3, !tbaa !21
  store i1 %t167, ptr %l101, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb57
bb57:
  %t169 = load i1, ptr %l101, !tbaa !21
  br i1 %t169, label %bb58, label %bb59
bb58:
  %t170 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t170, ptr %l104
  %t171 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t171, ptr %l106
  %t174 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l104, ptr %l106)
  store i1 %t174, ptr %l108
  br label %bb60
bb59:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb61
bb60:
  %t175 = load i1, ptr %l108, !tbaa !21
  %t176 = xor i1 %t175, true
  store i1 %t176, ptr %l103, !tbaa !21
  br label %bb61
bb61:
  %t178 = load i1, ptr %l103, !tbaa !21
  br i1 %t178, label %bb62, label %bb63
bb62:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load { i64, [2 x i64] }, ptr %l2
  %t181 = load { i64, [2 x i64] }, ptr %l1
  %t185 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t179, { i64, [2 x i64] } %t180, { i64, [2 x i64] } %t181)
  store i64 %t185, ptr %l113
  br label %bb64
bb63:
  br label %bb73
bb64:
  %t186 = load i64, ptr %l113, !tbaa !24
  store i64 %t186, ptr %l13, !tbaa !24
  %t187 = load i64, ptr %l13, !tbaa !24
  %t188 = load i64, ptr @G_2ecompiler_2fscope_2eFailsBlock, !tbaa !24
  %t191 = icmp eq i64 %t187, %t188
  br i1 %t191, label %bb65, label %bb66
bb65:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, [2 x i64] }, ptr %l2
  %t197 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisBlock(ptr %v0, ptr %t193, { i64, [2 x i64] } %t194)
  store i1 %t197, ptr %l120
  br label %bb67
bb66:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb68
bb67:
  %t198 = load i1, ptr %l120, !tbaa !21
  store i1 %t198, ptr %l117, !tbaa !21
  br label %bb68
bb68:
  %t199 = load i1, ptr %l117, !tbaa !21
  br i1 %t199, label %bb69, label %bb70
bb69:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/scope:Scoper", ptr %t200, i32 0, i32 79
  store i1 true, ptr %t202, !tbaa !21
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l4, !tbaa !29
  %t205 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efitError(ptr %v0, ptr %v1, ptr %t203, ptr %t204, i64 %t205, i1 true)
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/scope:Scoper", ptr %t209, i32 0, i32 79
  store i1 false, ptr %t211, !tbaa !21
  br label %ret
bb72:
  br label %bb73
bb73:
  %t212 = load i64, ptr %l13, !tbaa !24
  %t213 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t216 = icmp eq i64 %t212, %t213
  br i1 %t216, label %bb74, label %bb75
bb74:
  br label %ret
bb75:
  br label %bb76
bb76:
  %t218 = load i64, ptr %l13, !tbaa !24
  %t219 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t222 = icmp eq i64 %t218, %t219
  br i1 %t222, label %bb77, label %bb78
bb77:
  %t224 = load i64, ptr %l5, !tbaa !24
  %t225 = load i64, ptr @G_2ecompiler_2fscope_2eFitGlobal, !tbaa !24
  %t228 = icmp eq i64 %t224, %t225
  store i1 %t228, ptr %l132, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb79
bb79:
  %t230 = load i1, ptr %l132, !tbaa !21
  br i1 %t230, label %bb80, label %bb81
bb80:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l4, !tbaa !29
  %t233 = load i64, ptr %l5, !tbaa !24
  %t234 = load i1, ptr %l3, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efitError(ptr %v0, ptr %v1, ptr %t231, ptr %t232, i64 %t233, i1 %t234)
  br label %bb82
bb81:
  br label %bb83
bb82:
  br label %ret
bb83:
  %t239 = load i64, ptr %l13, !tbaa !24
  %t240 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t243 = icmp eq i64 %t239, %t240
  br i1 %t243, label %bb84, label %bb85
bb84:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load { i64, [2 x i64] }, ptr %l1
  %t247 = load { i64, [2 x i64] }, ptr %l2
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %t245, { i64, [2 x i64] } %t246, { i64, [2 x i64] } %t247, i1 false)
  br label %bb86
bb85:
  br label %bb99
bb86:
  %t251 = load i1, ptr %l3, !tbaa !21
  br i1 %t251, label %bb87, label %bb88
bb87:
  %t253 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t253, ptr %l148
  %t254 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t254, ptr %l150
  %t257 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l148, ptr %l150)
  store i1 %t257, ptr %l152
  br label %bb89
bb88:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb90
bb89:
  %t258 = load i1, ptr %l152, !tbaa !21
  %t259 = xor i1 %t258, true
  store i1 %t259, ptr %l147, !tbaa !21
  br label %bb90
bb90:
  %t261 = load i1, ptr %l147, !tbaa !21
  br i1 %t261, label %bb91, label %bb92
bb91:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load { i64, [2 x i64] }, ptr %l2
  %t264 = load { i64, [2 x i64] }, ptr %l1
  %t268 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t262, { i64, [2 x i64] } %t263, { i64, [2 x i64] } %t264)
  store i64 %t268, ptr %l157
  br label %bb93
bb92:
  br label %bb98
bb93:
  %t269 = load i64, ptr %l157, !tbaa !24
  %t271 = load i64, ptr @G_2ecompiler_2fscope_2eObliged, !tbaa !24
  %t274 = icmp eq i64 %t269, %t271
  br i1 %t274, label %bb94, label %bb95
bb94:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load { i64, [2 x i64] }, ptr %l2
  %t278 = load { i64, [2 x i64] }, ptr %l1
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %t276, { i64, [2 x i64] } %t277, { i64, [2 x i64] } %t278, i1 false)
  br label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb97
bb97:
  br label %bb98
bb98:
  br label %ret
bb99:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load ptr, ptr %l4, !tbaa !29
  %t284 = load i64, ptr %l5, !tbaa !24
  %t285 = load i1, ptr %l3, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efitError(ptr %v0, ptr %v1, ptr %t282, ptr %t283, i64 %t284, i1 %t285)
  br label %bb100
bb100:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efitError(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l21 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l62 = alloca i1
  %l64 = alloca i1
  %l68 = alloca i1
  %l71 = alloca i1
  %l73 = alloca { i64, [2 x i64] }
  %l76 = alloca { i64, [2 x i64] }
  %l78 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l96 = alloca %"compiler/source:Span"
  %l98 = alloca i1
  %l100 = alloca %"compiler/msgs:Msg"
  %l102 = alloca %"compiler/msgs:Msg"
  %l103 = alloca %"compiler/msgs:Msg"
  %l104 = alloca i64
  %l106 = alloca i1
  %l108 = alloca i1
  %l111 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca i64
  %l116 = alloca ptr
  %l119 = alloca i64
  %l121 = alloca ptr
  %l123 = alloca ptr
  %l126 = alloca %"compiler/source:Span"
  %l131 = alloca %"compiler/source:Span"
  %l134 = alloca i64
  %l142 = alloca i1
  %l146 = alloca ptr
  %l148 = alloca ptr
  %l149 = alloca i64
  %l152 = alloca i1
  %l161 = alloca %"compiler/typed:Local"
  %l164 = alloca i1
  %l165 = alloca ptr
  %l174 = alloca %"compiler/typed:Local"
  %l176 = alloca i1
  %l178 = alloca i1
  %l186 = alloca ptr
  %l195 = alloca %"compiler/typed:Local"
  %l197 = alloca { i64, ptr }
  %l198 = alloca ptr
  %l199 = alloca i64
  %l206 = alloca i64
  %l207 = alloca ptr
  %l216 = alloca %"compiler/typed:Local"
  %l219 = alloca %"compiler/source:Span"
  %l220 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l223 = alloca { ptr, ptr }
  %l232 = alloca %"compiler/typed:Local"
  %l234 = alloca { i64, ptr }
  %l237 = alloca %"compiler/msgs:Msg"
  %l240 = alloca i1
  %l247 = alloca i64
  %l250 = alloca ptr
  %l251 = alloca i64
  %l253 = alloca ptr
  %l254 = alloca i64
  %l258 = alloca ptr
  %l267 = alloca %"compiler/typed:Local"
  %l269 = alloca { i64, ptr }
  %l273 = alloca ptr
  %l274 = alloca ptr
  %l275 = alloca ptr
  %l276 = alloca i1
  %l285 = alloca i1
  %l288 = alloca i1
  %l289 = alloca ptr
  %l290 = alloca i64
  %l297 = alloca i64
  %l301 = alloca %"compiler/source:Span"
  %l302 = alloca %"compiler/msgs:Msg"
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 27
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2fscope_2eFitReturn, !tbaa !24
  %t12 = icmp eq i64 %t8, %t9
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l22, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t15)
  store i32 %t17, ptr %l24
  br label %bb6
bb5:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb6:
  %t18 = load ptr, ptr %l22, !tbaa !29
  %t19 = load i32, ptr %l24, !tbaa !23
  %t20 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t20, ptr %l25
  br label %bb7
bb7:
  %t21 = load i1, ptr %l25, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb12
bb9:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l27, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l29
  br label %bb10
bb10:
  %t26 = load ptr, ptr %l27, !tbaa !29
  %t27 = load i32, ptr %l29, !tbaa !23
  %t28 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %t26, i32 %t27)
  store i1 %t28, ptr %l30
  br label %bb11
bb11:
  %t29 = load i1, ptr %l30, !tbaa !21
  store i1 %t29, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t30 = load i1, ptr %l26, !tbaa !21
  store i1 %t30, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t31 = load i1, ptr %l21, !tbaa !21
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t36 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapsDiffer(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  store i1 %t36, ptr %l34
  br label %bb16
bb15:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb17
bb16:
  %t37 = load i1, ptr %l34, !tbaa !21
  %t38 = xor i1 %t37, true
  store i1 %t38, ptr %l31, !tbaa !21
  br label %bb17
bb17:
  %t40 = load i1, ptr %l31, !tbaa !21
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t41 = load i64, ptr @G_2ecompiler_2fscope_2eFitOwn, !tbaa !24
  store i64 %t41, ptr %l2, !tbaa !24
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t43, i32 0, i32 80
  store i1 false, ptr %t45, !tbaa !21
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t51 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  store ptr %t51, ptr %l41
  br label %bb21
bb21:
  %t52 = load ptr, ptr %l41, !tbaa !29
  store ptr %t52, ptr %l4, !tbaa !29
  %t53 = load ptr, ptr %l4, !tbaa !29
  store ptr %t53, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t54 = load ptr, ptr %l42, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l42, !tbaa !29
  %t58 = load i64, ptr %t57
  %t60 = icmp eq i64 %t58, 2
  store i1 %t60, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l43, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l5, !tbaa !29
  br label %bb30
bb25:
  %t68 = load ptr, ptr %l4, !tbaa !29
  store ptr %t68, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t69 = load ptr, ptr %l48, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb26, label %bb27
bb26:
  %t72 = load ptr, ptr %l48, !tbaa !29
  %t73 = load i64, ptr %t72
  %t75 = icmp eq i64 %t73, 3
  store i1 %t75, ptr %l49, !tbaa !21
  br label %bb27
bb27:
  %t76 = load i1, ptr %l49, !tbaa !21
  br i1 %t76, label %bb28, label %bb29
bb28:
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t79, i32 0, i32 2
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb42
bb30:
  %t83 = load ptr, ptr %l5, !tbaa !29
  store ptr %t83, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t84 = load ptr, ptr %l54, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb31, label %bb32
bb31:
  %t87 = load ptr, ptr %l54, !tbaa !29
  %t88 = load i64, ptr %t87
  %t90 = icmp eq i64 %t88, 0
  store i1 %t90, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t91 = load i1, ptr %l55, !tbaa !21
  br i1 %t91, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/scope:Scoper", ptr %t92, i32 0, i32 80
  store i1 true, ptr %t94, !tbaa !21
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_cd338417bf9b4adb_b24d723c852a352f)
  unreachable
bb41:
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_d3b44bae2eeaabda_3c9b483dafe8946e)
  unreachable
bb47:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t96 = load i64, ptr @G_2ecompiler_2fscope_2eFitField, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  br i1 %t99, label %bb48, label %bb49
bb48:
  %t101 = load i1, ptr %l3, !tbaa !21
  store i1 %t101, ptr %l62, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb50
bb50:
  %t103 = load i1, ptr %l62, !tbaa !21
  br i1 %t103, label %bb51, label %bb52
bb51:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/scope:Scoper", ptr %t104, i32 0, i32 100
  %t107 = load i64, ptr %t106, !tbaa !24
  %t109 = icmp eq i64 %t107, 0
  store i1 %t109, ptr %l64, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb53
bb53:
  %t111 = load i1, ptr %l64, !tbaa !21
  br i1 %t111, label %bb54, label %bb55
bb54:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/scope:Scoper", ptr %t112, i32 0, i32 74
  %t115 = load i1, ptr %t114, !tbaa !21
  br i1 %t115, label %bb56, label %bb57
bb55:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb60
bb56:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/scope:Scoper", ptr %t117, i32 0, i32 78
  %t120 = load { i64, [2 x i64] }, ptr %t119
  store { i64, [2 x i64] } %t120, ptr %l73
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/scope:Scoper", ptr %t121, i32 0, i32 76
  %t124 = load { i64, [2 x i64] }, ptr %t123
  store { i64, [2 x i64] } %t124, ptr %l76
  %t127 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l73, ptr %l76)
  store i1 %t127, ptr %l78
  br label %bb58
bb57:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb59
bb58:
  %t128 = load i1, ptr %l78, !tbaa !21
  store i1 %t128, ptr %l71, !tbaa !21
  br label %bb59
bb59:
  %t129 = load i1, ptr %l71, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l68, !tbaa !21
  br label %bb60
bb60:
  %t132 = load i1, ptr %l68, !tbaa !21
  br i1 %t132, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s7
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/scope:Scoper", ptr %t133, i32 0, i32 79
  %t136 = load i1, ptr %t135, !tbaa !21
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb63, label %bb64
bb62:
  br label %bb89
bb63:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t144 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueLocalName(ptr %v0, ptr %v1, ptr %s7, ptr %t140, ptr %t141)
  store { i64, ptr } %t144, ptr %l86
  br label %bb65
bb64:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l83, !tbaa !27
  br label %bb66
bb65:
  %t145 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l83, !tbaa !27
  br label %bb66
bb66:
  %t153 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t153, ptr %l6, !tbaa !27
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l88, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/scope:Scoper", ptr %t155, i32 0, i32 81
  %t158 = load i1, ptr %t157, !tbaa !21
  br i1 %t158, label %bb67, label %bb68
bb67:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/scope:Scoper", ptr %t160, i32 0, i32 82
  %t163 = load %"compiler/source:Span", ptr %t162
  store %"compiler/source:Span" %t163, ptr %l91
  br label %bb70
bb68:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t169 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t165, ptr %t166)
  store %"compiler/source:Span" %t169, ptr %l96
  br label %bb69
bb69:
  %t170 = load %"compiler/source:Span", ptr %l96
  store %"compiler/source:Span" %t170, ptr %l91
  br label %bb70
bb70:
  %t171 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t173 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t171, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t173, ptr %l98
  br label %bb71
bb71:
  %t174 = load i1, ptr %l98, !tbaa !21
  %t175 = xor i1 %t174, true
  br i1 %t175, label %bb72, label %bb73
bb72:
  %t177 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t179 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowedLocal(ptr %s7, ptr %s7, { i64, ptr } %t177)
  store %"compiler/msgs:Msg" %t179, ptr %l102
  br label %bb74
bb73:
  %t180 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %s7)
  store %"compiler/msgs:Msg" %t180, ptr %l103
  br label %bb75
bb74:
  %t181 = load %"compiler/msgs:Msg", ptr %l102
  store %"compiler/msgs:Msg" %t181, ptr %l100
  br label %bb76
bb75:
  %t182 = load %"compiler/msgs:Msg", ptr %l103
  store %"compiler/msgs:Msg" %t182, ptr %l100
  br label %bb76
bb76:
  %t183 = load ptr, ptr %l88, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l91
  %t185 = load %"compiler/msgs:Msg", ptr %l100
  %t186 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s7, ptr %t183, %"compiler/source:Span" %t184, %"compiler/msgs:Msg" %t185)
  store i64 %t186, ptr %l104
  br label %bb77
bb77:
  %t187 = load i64, ptr %l104, !tbaa !24
  store i64 %t187, ptr %l7, !tbaa !24
  %t188 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t190 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s7, ptr %s7, { i64, ptr } %t188, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t190, ptr %l106
  br label %bb78
bb78:
  %t191 = load i1, ptr %l106, !tbaa !21
  %t192 = xor i1 %t191, true
  br i1 %t192, label %bb79, label %bb80
bb79:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/scope:Scoper", ptr %t194, i32 0, i32 57
  %t198 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t196)
  store i64 %t198, ptr %l111
  br label %bb81
bb80:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb82
bb81:
  %t199 = load i64, ptr %l111, !tbaa !24
  %t200 = icmp sgt i64 %t199, 0
  store i1 %t200, ptr %l108, !tbaa !21
  br label %bb82
bb82:
  %t202 = load i1, ptr %l108, !tbaa !21
  br i1 %t202, label %bb83, label %bb84
bb83:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l113, !tbaa !29
  %t204 = load i64, ptr %l7, !tbaa !24
  store i64 %t204, ptr %l114, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/scope:Scoper", ptr %t205, i32 0, i32 57
  store ptr %t207, ptr %l116, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/scope:Scoper", ptr %t208, i32 0, i32 57
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t210)
  store i64 %t212, ptr %l119
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t213 = load i64, ptr %l119, !tbaa !24
  %t214 = sub i64 %t213, 1
  %t215 = load ptr, ptr %l116, !tbaa !29
  %t217 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v0, ptr %t215, i64 %t214)
  store ptr %t217, ptr %l121
  br label %bb86
bb86:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t219 = load ptr, ptr %l113, !tbaa !29
  %t220 = load i64, ptr %l114, !tbaa !24
  %t221 = load ptr, ptr %l121, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteRefill(ptr %v0, ptr %v0, ptr %v1, ptr %t219, i64 %t220, ptr %t221, ptr %t218)
  br label %bb87
bb87:
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s7)
  br label %ret
bb89:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l123, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/scope:Scoper", ptr %t224, i32 0, i32 81
  %t227 = load i1, ptr %t226, !tbaa !21
  br i1 %t227, label %bb90, label %bb91
bb90:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/scope:Scoper", ptr %t229, i32 0, i32 82
  %t232 = load %"compiler/source:Span", ptr %t231
  store %"compiler/source:Span" %t232, ptr %l126
  br label %bb93
bb91:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t238 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t234, ptr %t235)
  store %"compiler/source:Span" %t238, ptr %l131
  br label %bb92
bb92:
  %t239 = load %"compiler/source:Span", ptr %l131
  store %"compiler/source:Span" %t239, ptr %l126
  br label %bb93
bb93:
  %t240 = load i64, ptr %l2, !tbaa !24
  %t241 = load i1, ptr %l3, !tbaa !21
  %t242 = load ptr, ptr %l123, !tbaa !29
  %t243 = load %"compiler/source:Span", ptr %l126
  %t246 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efitErrorAt(ptr %v0, ptr %t242, %"compiler/source:Span" %t243, i64 %t240, i1 %t241)
  store i64 %t246, ptr %l134
  br label %bb94
bb94:
  %t247 = load i64, ptr %l134, !tbaa !24
  store i64 %t247, ptr %l8, !tbaa !24
  %t248 = load i64, ptr %l8, !tbaa !24
  %t250 = icmp sge i64 %t248, 0
  br i1 %t250, label %bb95, label %bb96
bb95:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load i64, ptr %l8, !tbaa !24
  %t254 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteCondValue(ptr %v0, ptr %v1, ptr %t252, i64 %t253, ptr %t254)
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb98
bb98:
  %t258 = load i64, ptr %l8, !tbaa !24
  %t260 = icmp sge i64 %t258, 0
  br i1 %t260, label %bb99, label %bb100
bb99:
  %t262 = load i64, ptr %l2, !tbaa !24
  %t263 = load i64, ptr @G_2ecompiler_2fscope_2eFitOwn, !tbaa !24
  %t266 = icmp eq i64 %t262, %t263
  store i1 %t266, ptr %l142, !tbaa !21
  br label %bb101
bb100:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb101
bb101:
  %t268 = load i1, ptr %l142, !tbaa !21
  br i1 %t268, label %bb102, label %bb103
bb102:
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l146, !tbaa !29
  %t270 = load ptr, ptr %l1, !tbaa !29
  %t272 = call ptr @compiler_2fscope_2eunPassed(ptr %v1, ptr %t270)
  store ptr %t272, ptr %l148
  br label %bb104
bb103:
  br label %bb147
bb104:
  %t273 = load ptr, ptr %l146, !tbaa !29
  %t274 = load ptr, ptr %l148, !tbaa !29
  %t275 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLocal(ptr %v0, ptr %v1, ptr %t273, ptr %t274)
  store i64 %t275, ptr %l149
  br label %bb105
bb105:
  %t276 = load i64, ptr %l149, !tbaa !24
  store i64 %t276, ptr %l9, !tbaa !24
  %t277 = load i64, ptr %l9, !tbaa !24
  %t279 = icmp sge i64 %t277, 0
  br i1 %t279, label %bb106, label %bb107
bb106:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/scope:Scoper", ptr %t281, i32 0, i32 25
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t286 = icmp eq ptr %t284, null
  br i1 %t286, label %bb108, label %bb109
bb107:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb112
bb108:
  call void @__olang_check_failed(ptr @olang_loc_27f9f8003e66d4c2_25a72554bedf4966)
  unreachable
bb109:
  br label %bb110
bb110:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/scope:Scoper", ptr %t288, i32 0, i32 25
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Body", ptr %t291, i32 0, i32 7
  %t295 = load i64, ptr %l9, !tbaa !24
  %t298 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t294, i64 %t295)
  store %"compiler/typed:Local" %t298, ptr %l161
  br label %bb111
bb111:
  %t299 = getelementptr %"compiler/typed:Local", ptr %l161, i32 0, i32 4
  %t300 = load i32, ptr %t299
  %t302 = trunc i64 0 to i32
  %t303 = icmp eq i32 %t300, %t302
  store i1 %t303, ptr %l152, !tbaa !21
  br label %bb112
bb112:
  %t305 = load i1, ptr %l152, !tbaa !21
  br i1 %t305, label %bb113, label %bb114
bb113:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l165, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/scope:Scoper", ptr %t307, i32 0, i32 25
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t312 = icmp eq ptr %t310, null
  br i1 %t312, label %bb115, label %bb116
bb114:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb120
bb115:
  call void @__olang_check_failed(ptr @olang_loc_27f9f8003e66d4c2_25a72554bedf4966)
  unreachable
bb116:
  br label %bb117
bb117:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/scope:Scoper", ptr %t314, i32 0, i32 25
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t320 = getelementptr %"compiler/typed:Body", ptr %t317, i32 0, i32 7
  %t321 = load i64, ptr %l9, !tbaa !24
  %t324 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t320, i64 %t321)
  store %"compiler/typed:Local" %t324, ptr %l174
  br label %bb118
bb118:
  %t325 = getelementptr %"compiler/typed:Local", ptr %l174, i32 0, i32 2
  %t326 = load i32, ptr %t325, !tbaa !23
  %t327 = load ptr, ptr %l165, !tbaa !29
  %t329 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t327, i32 %t326)
  store i1 %t329, ptr %l176
  br label %bb119
bb119:
  %t330 = load i1, ptr %l176, !tbaa !21
  %t331 = xor i1 %t330, true
  store i1 %t331, ptr %l164, !tbaa !21
  br label %bb120
bb120:
  %t333 = load i1, ptr %l164, !tbaa !21
  br i1 %t333, label %bb121, label %bb122
bb121:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/scope:Scoper", ptr %t334, i32 0, i32 5
  %t337 = load { ptr, ptr }, ptr %t336
  %t339 = extractvalue { ptr, ptr } %t337, 0
  %t340 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t341 = icmp eq ptr %t339, %t340
  %t342 = extractvalue { ptr, ptr } %t337, 1
  %t343 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t344 = icmp eq ptr %t342, %t343
  %t345 = and i1 %t341, %t344
  %t347 = xor i1 %t345, true
  store i1 %t347, ptr %l178, !tbaa !21
  br label %bb123
bb122:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb123
bb123:
  %t349 = load i1, ptr %l178, !tbaa !21
  br i1 %t349, label %bb124, label %bb125
bb124:
  store %olang.scope zeroinitializer, ptr %s11
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/scope:Scoper", ptr %t350, i32 0, i32 0
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/generic:Program", ptr %t353, i32 0, i32 0
  %t356 = load ptr, ptr %t355, !tbaa !29
  %t358 = getelementptr %"compiler/load:Loader", ptr %t356, i32 0, i32 3
  %t359 = load ptr, ptr %t358, !tbaa !29
  store ptr %t359, ptr %l186, !tbaa !29
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/scope:Scoper", ptr %t360, i32 0, i32 25
  %t363 = load ptr, ptr %t362, !tbaa !29
  %t365 = icmp eq ptr %t363, null
  br i1 %t365, label %bb126, label %bb127
bb125:
  br label %bb146
bb126:
  call void @__olang_check_failed(ptr @olang_loc_5600be0283c8c0a9_e199d532ae73234d)
  unreachable
bb127:
  br label %bb128
bb128:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/scope:Scoper", ptr %t367, i32 0, i32 25
  %t370 = load ptr, ptr %t369, !tbaa !29
  %t373 = getelementptr %"compiler/typed:Body", ptr %t370, i32 0, i32 7
  %t374 = load i64, ptr %l9, !tbaa !24
  %t377 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t373, i64 %t374)
  store %"compiler/typed:Local" %t377, ptr %l195
  br label %bb129
bb129:
  %t378 = getelementptr %"compiler/typed:Local", ptr %l195, i32 0, i32 0
  %t379 = load i32, ptr %t378, !tbaa !23
  %t380 = load ptr, ptr %l186, !tbaa !29
  %t382 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t380, i32 %t379)
  store { i64, ptr } %t382, ptr %l197
  br label %bb130
bb130:
  %t383 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t383, ptr %l10, !tbaa !27
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l198, !tbaa !29
  %t385 = load i64, ptr %l8, !tbaa !24
  store i64 %t385, ptr %l199, !tbaa !24
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/scope:Scoper", ptr %t386, i32 0, i32 25
  %t389 = load ptr, ptr %t388, !tbaa !29
  %t391 = icmp eq ptr %t389, null
  br i1 %t391, label %bb131, label %bb132
bb131:
  call void @__olang_check_failed(ptr @olang_loc_7c76a5ff0a201730_60f43c735987f7c)
  unreachable
bb132:
  br label %bb133
bb133:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t395 = getelementptr %"compiler/scope:Scoper", ptr %t393, i32 0, i32 25
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Body", ptr %t396, i32 0, i32 3
  %t400 = load i64, ptr %t399, !tbaa !24
  store i64 %t400, ptr %l206, !tbaa !24
  %t401 = load ptr, ptr %l0, !tbaa !29
  store ptr %t401, ptr %l207, !tbaa !29
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/scope:Scoper", ptr %t402, i32 0, i32 25
  %t405 = load ptr, ptr %t404, !tbaa !29
  %t407 = icmp eq ptr %t405, null
  br i1 %t407, label %bb134, label %bb135
bb134:
  call void @__olang_check_failed(ptr @olang_loc_7c76a5ff0a201730_60f43c735987f7c)
  unreachable
bb135:
  br label %bb136
bb136:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/scope:Scoper", ptr %t409, i32 0, i32 25
  %t412 = load ptr, ptr %t411, !tbaa !29
  %t415 = getelementptr %"compiler/typed:Body", ptr %t412, i32 0, i32 7
  %t416 = load i64, ptr %l9, !tbaa !24
  %t419 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t415, i64 %t416)
  store %"compiler/typed:Local" %t419, ptr %l216
  br label %bb137
bb137:
  %t420 = getelementptr %"compiler/typed:Local", ptr %l216, i32 0, i32 1
  %t421 = load %"compiler/source:Span", ptr %t420
  %t422 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t423 = load ptr, ptr %l207, !tbaa !29
  %t426 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v0, ptr %t423, %"compiler/source:Span" %t421, { i64, ptr } %t422)
  store %"compiler/source:Span" %t426, ptr %l219
  br label %bb138
bb138:
  %t427 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t427, ptr %l220, !tbaa !27
  %t428 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t428, ptr %l221, !tbaa !27
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/scope:Scoper", ptr %t429, i32 0, i32 5
  %t432 = load { ptr, ptr }, ptr %t431
  store { ptr, ptr } %t432, ptr %l223
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/scope:Scoper", ptr %t433, i32 0, i32 25
  %t436 = load ptr, ptr %t435, !tbaa !29
  %t438 = icmp eq ptr %t436, null
  br i1 %t438, label %bb139, label %bb140
bb139:
  call void @__olang_check_failed(ptr @olang_loc_7c76a5ff0a201730_60f43c735987f7c)
  unreachable
bb140:
  br label %bb141
bb141:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t442 = getelementptr %"compiler/scope:Scoper", ptr %t440, i32 0, i32 25
  %t443 = load ptr, ptr %t442, !tbaa !29
  %t446 = getelementptr %"compiler/typed:Body", ptr %t443, i32 0, i32 7
  %t447 = load i64, ptr %l9, !tbaa !24
  %t450 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t446, i64 %t447)
  store %"compiler/typed:Local" %t450, ptr %l232
  br label %bb142
bb142:
  %t451 = getelementptr %"compiler/typed:Local", ptr %l232, i32 0, i32 2
  %t452 = load i32, ptr %t451, !tbaa !23
  %t453 = load { ptr, ptr }, ptr %l223
  %t454 = extractvalue { ptr, ptr } %t453, 0
  %t455 = extractvalue { ptr, ptr } %t453, 1
  %t457 = call { i64, ptr } %t454(ptr %t455, ptr %s11, i32 %t452)
  store { i64, ptr } %t457, ptr %l234
  br label %bb143
bb143:
  %t458 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t458, 1
  %t460 = extractvalue { i64, ptr } %t458, 0
  %t461 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t462 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t463 = add i64 %t460, %t462
  %t464 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 1
  %t466 = extractvalue { i64, ptr } %t464, 0
  %t467 = add i64 %t463, %t466
  %t468 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t469 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t470 = add i64 %t467, %t469
  %t471 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t470)
  call void @olang_textcopy(ptr %t471, ptr %t459, i64 %t460)
  %t472 = getelementptr i8, ptr %t471, i64 %t460
  call void @olang_textcopy(ptr %t472, ptr %t461, i64 %t462)
  %t473 = getelementptr i8, ptr %t472, i64 %t462
  call void @olang_textcopy(ptr %t473, ptr %t465, i64 %t466)
  %t474 = getelementptr i8, ptr %t473, i64 %t466
  call void @olang_textcopy(ptr %t474, ptr %t468, i64 %t469)
  %t475 = insertvalue { i64, ptr } undef, i64 %t470, 0
  %t476 = insertvalue { i64, ptr } %t475, ptr %t471, 1
  %t478 = extractvalue { i64, ptr } %t476, 0
  %t479 = extractvalue { i64, ptr } %t476, 1
  %t480 = mul i64 %t478, 1
  %t481 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t480)
  call void @llvm.memcpy.p0.p0.i64(ptr %t481, ptr %t479, i64 %t480, i1 false)
  %t482 = insertvalue { i64, ptr } undef, i64 %t478, 0
  %t483 = insertvalue { i64, ptr } %t482, ptr %t481, 1
  %t484 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t486 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteParamCopy(ptr %v0, ptr %s11, ptr %s11, { i64, ptr } %t484, { i64, ptr } %t483)
  store %"compiler/msgs:Msg" %t486, ptr %l237
  br label %bb144
bb144:
  %t487 = load ptr, ptr %l198, !tbaa !29
  %t488 = load i64, ptr %l199, !tbaa !24
  %t489 = load i64, ptr %l206, !tbaa !24
  %t490 = load %"compiler/source:Span", ptr %l219
  %t491 = load %"compiler/msgs:Msg", ptr %l237
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s11, ptr %t487, i64 %t488, i64 %t489, %"compiler/source:Span" %t490, %"compiler/msgs:Msg" %t491)
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s11)
  br label %bb146
bb146:
  br label %bb147
bb147:
  %t492 = load i64, ptr %l8, !tbaa !24
  %t494 = icmp sge i64 %t492, 0
  br i1 %t494, label %bb148, label %bb149
bb148:
  %t496 = load i64, ptr %l2, !tbaa !24
  %t497 = load i64, ptr @G_2ecompiler_2fscope_2eFitPayload, !tbaa !24
  %t500 = icmp eq i64 %t496, %t497
  store i1 %t500, ptr %l240, !tbaa !21
  br label %bb150
bb149:
  store i1 false, ptr %l240, !tbaa !21
  br label %bb150
bb150:
  %t502 = load i1, ptr %l240, !tbaa !21
  br i1 %t502, label %bb151, label %bb152
bb151:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t506 = getelementptr %"compiler/scope:Scoper", ptr %t504, i32 0, i32 78
  %t507 = load { i64, [2 x i64] }, ptr %t506
  %t510 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamOfTerm(ptr %v0, ptr %t503, { i64, [2 x i64] } %t507)
  store i64 %t510, ptr %l247
  br label %bb153
bb152:
  br label %bb163
bb153:
  %t511 = load i64, ptr %l247, !tbaa !24
  store i64 %t511, ptr %l11, !tbaa !24
  %t512 = load i64, ptr %l11, !tbaa !24
  %t514 = icmp sge i64 %t512, 0
  br i1 %t514, label %bb154, label %bb155
bb154:
  %t516 = load ptr, ptr %l0, !tbaa !29
  store ptr %t516, ptr %l250, !tbaa !29
  %t517 = load i64, ptr %l8, !tbaa !24
  store i64 %t517, ptr %l251, !tbaa !24
  %t518 = load ptr, ptr %l1, !tbaa !29
  store ptr %t518, ptr %l253, !tbaa !29
  %t520 = load i64, ptr %l11, !tbaa !24
  store i64 %t520, ptr %l254, !tbaa !24
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/scope:Scoper", ptr %t521, i32 0, i32 0
  %t524 = load ptr, ptr %t523, !tbaa !29
  %t526 = getelementptr %"compiler/generic:Program", ptr %t524, i32 0, i32 0
  %t527 = load ptr, ptr %t526, !tbaa !29
  %t529 = getelementptr %"compiler/load:Loader", ptr %t527, i32 0, i32 3
  %t530 = load ptr, ptr %t529, !tbaa !29
  store ptr %t530, ptr %l258, !tbaa !29
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t533 = getelementptr %"compiler/scope:Scoper", ptr %t531, i32 0, i32 25
  %t534 = load ptr, ptr %t533, !tbaa !29
  %t536 = icmp eq ptr %t534, null
  br i1 %t536, label %bb156, label %bb157
bb155:
  br label %bb162
bb156:
  call void @__olang_check_failed(ptr @olang_loc_3bc3e93e18d6d20f_7eae6e8d3b47aeeb)
  unreachable
bb157:
  br label %bb158
bb158:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t540 = getelementptr %"compiler/scope:Scoper", ptr %t538, i32 0, i32 25
  %t541 = load ptr, ptr %t540, !tbaa !29
  %t544 = getelementptr %"compiler/typed:Body", ptr %t541, i32 0, i32 7
  %t545 = load i64, ptr %l11, !tbaa !24
  %t548 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t544, i64 %t545)
  store %"compiler/typed:Local" %t548, ptr %l267
  br label %bb159
bb159:
  %t549 = getelementptr %"compiler/typed:Local", ptr %l267, i32 0, i32 0
  %t550 = load i32, ptr %t549, !tbaa !23
  %t551 = load ptr, ptr %l258, !tbaa !29
  %t553 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t551, i32 %t550)
  store { i64, ptr } %t553, ptr %l269
  br label %bb160
bb160:
  %t554 = load ptr, ptr %l250, !tbaa !29
  %t555 = load i64, ptr %l251, !tbaa !24
  %t556 = load ptr, ptr %l253, !tbaa !29
  %t557 = load i64, ptr %l254, !tbaa !24
  %t558 = load { i64, ptr }, ptr %l269, !tbaa !27
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v0, ptr %t554, i64 %t555, ptr %t556, i64 %t557, { i64, ptr } %t558, i64 0)
  br label %bb161
bb161:
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t560 = load ptr, ptr %l1, !tbaa !29
  %t564 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t559, ptr %t560)
  store ptr %t564, ptr %l273
  br label %bb164
bb164:
  %t565 = load ptr, ptr %l273, !tbaa !29
  %t566 = call ptr @compiler_2fscope_2eunWidened(ptr %v1, ptr %t565)
  store ptr %t566, ptr %l274
  br label %bb165
bb165:
  %t567 = load ptr, ptr %l274, !tbaa !29
  store ptr %t567, ptr %l12, !tbaa !29
  %t568 = load ptr, ptr %l12, !tbaa !29
  store ptr %t568, ptr %l275, !tbaa !29
  store i1 false, ptr %l276, !tbaa !21
  %t569 = load ptr, ptr %l275, !tbaa !29
  %t570 = icmp ne ptr %t569, null
  br i1 %t570, label %bb166, label %bb167
bb166:
  %t572 = load ptr, ptr %l275, !tbaa !29
  %t573 = load i64, ptr %t572
  %t575 = icmp eq i64 %t573, 10
  store i1 %t575, ptr %l276, !tbaa !21
  br label %bb167
bb167:
  %t576 = load i1, ptr %l276, !tbaa !21
  br i1 %t576, label %bb168, label %bb169
bb168:
  %t577 = load ptr, ptr %l12, !tbaa !29
  %t579 = getelementptr { i64, [5 x i64] }, ptr %t577, i32 0, i32 1
  %t580 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t579, i32 0, i32 0
  %t581 = load %"compiler/source:Span", ptr %t580
  store %"compiler/source:Span" %t581, ptr %l13
  %t583 = load ptr, ptr %l12, !tbaa !29
  %t585 = getelementptr { i64, [5 x i64] }, ptr %t583, i32 0, i32 1
  %t586 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t585, i32 0, i32 2
  %t587 = load ptr, ptr %t586
  store ptr %t587, ptr %l14, !tbaa !29
  br label %bb170
bb169:
  br label %bb184
bb170:
  %t589 = load i64, ptr %l8, !tbaa !24
  %t591 = icmp sge i64 %t589, 0
  br i1 %t591, label %bb171, label %bb172
bb171:
  %t593 = load ptr, ptr %l14, !tbaa !29
  %t595 = getelementptr %"compiler/typed:Slice", ptr %t593, i32 0, i32 0
  %t596 = load ptr, ptr %t595, !tbaa !29
  %t598 = call i1 @compiler_2fscope_2ethroughTemp(ptr %v1, ptr %t596)
  store i1 %t598, ptr %l288
  br label %bb173
bb172:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb174
bb173:
  %t599 = load i1, ptr %l288, !tbaa !21
  store i1 %t599, ptr %l285, !tbaa !21
  br label %bb174
bb174:
  %t600 = load i1, ptr %l285, !tbaa !21
  br i1 %t600, label %bb175, label %bb176
bb175:
  store %olang.scope zeroinitializer, ptr %s16
  %t601 = load ptr, ptr %l0, !tbaa !29
  store ptr %t601, ptr %l289, !tbaa !29
  %t602 = load i64, ptr %l8, !tbaa !24
  store i64 %t602, ptr %l290, !tbaa !24
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t605 = getelementptr %"compiler/scope:Scoper", ptr %t603, i32 0, i32 25
  %t606 = load ptr, ptr %t605, !tbaa !29
  %t608 = icmp eq ptr %t606, null
  br i1 %t608, label %bb177, label %bb178
bb176:
  br label %bb183
bb177:
  call void @__olang_check_failed(ptr @olang_loc_60c4a5415da7e8de_419e4bf7c0afcf6a)
  unreachable
bb178:
  br label %bb179
bb179:
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t612 = getelementptr %"compiler/scope:Scoper", ptr %t610, i32 0, i32 25
  %t613 = load ptr, ptr %t612, !tbaa !29
  %t616 = getelementptr %"compiler/typed:Body", ptr %t613, i32 0, i32 3
  %t617 = load i64, ptr %t616, !tbaa !24
  store i64 %t617, ptr %l297, !tbaa !24
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t619 = load %"compiler/source:Span", ptr %l13
  %t620 = load ptr, ptr %l14, !tbaa !29
  %t624 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esliceAt(ptr %v0, ptr %v1, ptr %t618, %"compiler/source:Span" %t619, ptr %t620)
  store %"compiler/source:Span" %t624, ptr %l301
  br label %bb180
bb180:
  %t625 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteSliceOfTemporary(ptr %s16)
  store %"compiler/msgs:Msg" %t625, ptr %l302
  br label %bb181
bb181:
  %t626 = load ptr, ptr %l289, !tbaa !29
  %t627 = load i64, ptr %l290, !tbaa !24
  %t628 = load i64, ptr %l297, !tbaa !24
  %t629 = load %"compiler/source:Span", ptr %l301
  %t630 = load %"compiler/msgs:Msg", ptr %l302
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s16, ptr %t626, i64 %t627, i64 %t628, %"compiler/source:Span" %t629, %"compiler/msgs:Msg" %t630)
  br label %bb182
bb182:
  call void @__olang_scope_close(ptr %s16)
  br label %bb183
bb183:
  br label %bb189
bb184:
  br i1 true, label %bb185, label %bb186
bb185:
  br label %bb187
bb186:
  br label %bb188
bb187:
  br label %bb189
bb188:
  call void @__olang_check_failed(ptr @olang_loc_b5bc1eafb7fb24bc_101d8a8a62fdaef8)
  unreachable
bb189:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efloorOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l8 = alloca i1
  %l11 = alloca i64
  %l14 = alloca i64
  %l21 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t41 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb12
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = sub i64 0, %t14
  %t18 = sub i64 %t16, 1
  store i64 %t18, ptr %l11, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 87
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb7
bb6:
  %t24 = load i64, ptr %l11, !tbaa !24
  %t25 = load i64, ptr %l14, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  store i1 %t26, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l8, !tbaa !21
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/scope:Scoper", ptr %t29, i32 0, i32 87
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = sub i64 0, %t32
  %t36 = sub i64 %t34, 1
  %t39 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t31, i64 %t36)
  store { i64, [2 x i64] } %t39, ptr %l21
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t40 = load { i64, [2 x i64] }, ptr %l21
  store { i64, [2 x i64] } %t40, ptr %rv
  br label %ret
bb11:
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7a90b7bdb9714c43_1678fcc4f66eb1af)
  unreachable
bb17:
  store { i64, [2 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [2 x i64] }, ptr %t41, i32 0, i32 0
  store i64 0, ptr %t42
  %t43 = load { i64, [2 x i64] }, ptr %t41
  store { i64, [2 x i64] } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"compiler/scope:Val"
  %l19 = alloca { i64, [2 x i64] }
  %l20 = alloca i64
  %l21 = alloca { i64, [2 x i64] }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, [2 x i64] }
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i32
  %l29 = alloca { i64, [2 x i64] }
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca i64
  %l32 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca ptr
  %l55 = alloca i64
  %l58 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/scope:fnUse"
  %l65 = alloca %"compiler/scope:Val"
  %l66 = alloca ptr
  %l67 = alloca i1
  %l79 = alloca ptr
  %l86 = alloca i64
  %l87 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l101 = alloca %"compiler/scope:fnUse"
  %l103 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l104 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l114 = alloca { i64, ptr }
  %l122 = alloca %"compiler/scope:Val"
  %l123 = alloca ptr
  %l126 = alloca i32
  %l127 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca %"compiler/scope:Val"
  %l132 = alloca { i64, [2 x i64] }
  %l133 = alloca { i64, [2 x i64] }
  %l134 = alloca ptr
  %l137 = alloca { i64, [1 x i64] }
  %l142 = alloca { i64, [2 x i64] }
  %l147 = alloca { i64, [2 x i64] }
  %l152 = alloca i64
  %l156 = alloca i1
  %l163 = alloca i1
  %l166 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca { i64, [2 x i64] }
  %l171 = alloca %"compiler/source:Span"
  %l192 = alloca ptr
  %l193 = alloca i32
  %l195 = alloca { i64, ptr }
  %l197 = alloca %"compiler/scope:Val"
  %l202 = alloca ptr
  %l203 = alloca i32
  %l205 = alloca { i64, ptr }
  %l207 = alloca { i64, [2 x i64] }
  %l208 = alloca %"compiler/scope:Val"
  %l211 = alloca i1
  %l213 = alloca i1
  %l215 = alloca i1
  %l216 = alloca { i64, [2 x i64] }
  %l219 = alloca { i64, [2 x i64] }
  %l220 = alloca ptr
  %l221 = alloca i32
  %l223 = alloca i1
  %l224 = alloca { i64, [2 x i64] }
  %l227 = alloca { i64, [2 x i64] }
  %l229 = alloca ptr
  %l230 = alloca i32
  %l232 = alloca { i64, ptr }
  %l235 = alloca i64
  %l237 = alloca i64
  %l242 = alloca { i64, [2 x i64] }
  %l243 = alloca { i64, [2 x i64] }
  %l245 = alloca { i64, [2 x i64] }
  %l247 = alloca i1
  %l249 = alloca i1
  %l253 = alloca i64
  %l259 = alloca { i64, [2 x i64] }
  %l263 = alloca %"compiler/scope:Val"
  %l264 = alloca ptr
  %l265 = alloca i1
  %l277 = alloca ptr
  %l284 = alloca i64
  %l287 = alloca %"compiler/source:Span"
  %l289 = alloca i64
  %l290 = alloca i64
  %l292 = alloca i32
  %l293 = alloca %"compiler/scope:fnUse"
  %l298 = alloca %"compiler/scope:Val"
  %l299 = alloca ptr
  %l300 = alloca %"compiler/scope:Val"
  %l302 = alloca { i64, [2 x i64] }
  %l303 = alloca { i64, [2 x i64] }
  %l306 = alloca %"compiler/source:Span"
  %l311 = alloca i64
  %l316 = alloca i1
  %l326 = alloca ptr
  %l327 = alloca i32
  %l330 = alloca { i64, [1 x i64] }
  %l331 = alloca { i64, ptr }
  %l333 = alloca { i64, [2 x i64] }
  %l334 = alloca %"compiler/scope:Val"
  %l335 = alloca ptr
  %l336 = alloca i32
  %l338 = alloca i1
  %l339 = alloca { i64, [2 x i64] }
  %l342 = alloca { i64, [2 x i64] }
  %l347 = alloca i64
  %l352 = alloca i1
  %l360 = alloca ptr
  %l361 = alloca i32
  %l364 = alloca { i64, [1 x i64] }
  %l365 = alloca { i64, ptr }
  %l367 = alloca %"compiler/scope:Val"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  %t73 = alloca { i64, [2 x i64] }, align 8
  %t163 = alloca { i64, [2 x i64] }, align 8
  %t203 = alloca { i64, [2 x i64] }, align 8
  %t558 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 71
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l4, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 68
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l5, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 71
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 68
  store i1 false, ptr %t16, !tbaa !21
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t18 = load ptr, ptr %l39, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb1, label %bb2
bb1:
  %t21 = load ptr, ptr %l39, !tbaa !29
  %t22 = load i64, ptr %t21
  %t24 = icmp eq i64 %t22, 0
  store i1 %t24, ptr %l40, !tbaa !21
  br label %bb2
bb2:
  %t25 = load i1, ptr %l40, !tbaa !21
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { i32 }, ptr %t28, i32 0, i32 0
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l6, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/scope:Scoper", ptr %t32, i32 0, i32 27
  %t35 = load i1, ptr %t34, !tbaa !21
  br i1 %t35, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 83
  store ptr %t39, ptr %l48, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/scope:Scoper", ptr %t40, i32 0, i32 25
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb8, label %bb9
bb7:
  br label %bb14
bb8:
  call void @__olang_check_failed(ptr @olang_loc_6745ec537010077c_cd78d81ca0e46128)
  unreachable
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/scope:Scoper", ptr %t47, i32 0, i32 25
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 3
  %t54 = load i64, ptr %t53, !tbaa !24
  store i64 %t54, ptr %l55, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l3
  %t59 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t55, %"compiler/source:Span" %t56)
  store %"compiler/source:Span" %t59, ptr %l58
  br label %bb11
bb11:
  %t60 = load i32, ptr %l6, !tbaa !23
  %t62 = sext i32 %t60 to i64
  %t63 = load i64, ptr @G_2ecompiler_2fscope_2eFnNamed, !tbaa !24
  %t64 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t65 = load i64, ptr %l55, !tbaa !24
  %t66 = load %"compiler/source:Span", ptr %l58
  %t70 = call %"compiler/scope:fnUse" @compiler_2fscope_3afnUse_2ector(ptr %s2, i64 %t65, %"compiler/source:Span" %t66, i64 %t62, i64 %t63, i32 %t64)
  store %"compiler/scope:fnUse" %t70, ptr %l63
  br label %bb12
bb12:
  %t71 = load ptr, ptr %l48, !tbaa !29
  %t72 = load %"compiler/scope:fnUse", ptr %l63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ePush_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %t71, %"compiler/scope:fnUse" %t72)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  store { i64, [2 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [2 x i64] }, ptr %t73, i32 0, i32 0
  store i64 3, ptr %t74
  %t75 = load { i64, [2 x i64] }, ptr %t73
  %t77 = call %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %t75)
  store %"compiler/scope:Val" %t77, ptr %l65
  br label %bb15
bb15:
  %t78 = load %"compiler/scope:Val", ptr %l65
  store %"compiler/scope:Val" %t78, ptr %rv
  br label %ret
bb16:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t80 = load ptr, ptr %l66, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb17, label %bb18
bb17:
  %t83 = load ptr, ptr %l66, !tbaa !29
  %t84 = load i64, ptr %t83
  %t86 = icmp eq i64 %t84, 1
  store i1 %t86, ptr %l67, !tbaa !21
  br label %bb18
bb18:
  %t87 = load i1, ptr %l67, !tbaa !21
  br i1 %t87, label %bb19, label %bb20
bb19:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t90, i32 0, i32 0
  %t92 = load i32, ptr %t91
  store i32 %t92, ptr %l7, !tbaa !23
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [4 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t96, i32 0, i32 1
  %t98 = load { i64, ptr }, ptr %t97
  store { i64, ptr } %t98, ptr %l8, !tbaa !27
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t102, i32 0, i32 2
  %t104 = load i32, ptr %t103
  store i32 %t104, ptr %l9, !tbaa !23
  br label %bb21
bb20:
  br label %bb131
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/scope:Scoper", ptr %t106, i32 0, i32 27
  %t109 = load i1, ptr %t108, !tbaa !21
  br i1 %t109, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/scope:Scoper", ptr %t111, i32 0, i32 83
  store ptr %t113, ptr %l79, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 25
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = icmp eq ptr %t117, null
  br i1 %t119, label %bb24, label %bb25
bb23:
  br label %bb33
bb24:
  call void @__olang_check_failed(ptr @olang_loc_dfe5171975bf36eb_aa3b662f409f8247)
  unreachable
bb25:
  br label %bb26
bb26:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/scope:Scoper", ptr %t121, i32 0, i32 25
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Body", ptr %t124, i32 0, i32 3
  %t128 = load i64, ptr %t127, !tbaa !24
  store i64 %t128, ptr %l86, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l87, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/scope:Scoper", ptr %t130, i32 0, i32 25
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = icmp eq ptr %t133, null
  br i1 %t135, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_dfe5171975bf36eb_aa3b662f409f8247)
  unreachable
bb28:
  br label %bb29
bb29:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/scope:Scoper", ptr %t137, i32 0, i32 25
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Body", ptr %t140, i32 0, i32 3
  %t144 = load i64, ptr %t143, !tbaa !24
  %t145 = load %"compiler/source:Span", ptr %l3
  %t146 = load ptr, ptr %l87, !tbaa !29
  %t149 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t146, i64 %t144, %"compiler/source:Span" %t145)
  store %"compiler/source:Span" %t149, ptr %l96
  br label %bb30
bb30:
  %t150 = load i32, ptr %l7, !tbaa !23
  %t152 = sext i32 %t150 to i64
  %t153 = load i64, ptr @G_2ecompiler_2fscope_2eFnLambda, !tbaa !24
  %t154 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t155 = load i64, ptr %l86, !tbaa !24
  %t156 = load %"compiler/source:Span", ptr %l96
  %t160 = call %"compiler/scope:fnUse" @compiler_2fscope_3afnUse_2ector(ptr %s4, i64 %t155, %"compiler/source:Span" %t156, i64 %t152, i64 %t153, i32 %t154)
  store %"compiler/scope:fnUse" %t160, ptr %l101
  br label %bb31
bb31:
  %t161 = load ptr, ptr %l79, !tbaa !29
  %t162 = load %"compiler/scope:fnUse", ptr %l101
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ePush_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %t161, %"compiler/scope:fnUse" %t162)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  store { i64, [2 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [2 x i64] }, ptr %t163, i32 0, i32 0
  store i64 0, ptr %t164
  %t165 = load { i64, [2 x i64] }, ptr %t163
  store { i64, [2 x i64] } %t165, ptr %l10
  %t167 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t167, ptr %l103
  br label %bb34
bb34:
  %t168 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l103
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t168, ptr %l11
  %t169 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t169, ptr %l104
  br label %bb35
bb35:
  %t170 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l104
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t170, ptr %l12
  %t171 = load i32, ptr %l7, !tbaa !23
  %t173 = sext i32 %t171 to i64
  store i64 %t173, ptr %l13, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t175, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 0
  store i64 %t179, ptr %l16, !tbaa !24
  br label %bb36
bb36:
  %t181 = load i64, ptr %l15, !tbaa !24
  %t182 = load i64, ptr %l16, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb37, label %bb38
bb37:
  br label %bb73
bb38:
  br label %bb39
bb39:
  %t189 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t189, ptr %l114, !tbaa !27
  %t190 = load i64, ptr %l15, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr ptr, ptr %t193, i64 %t190
  %t195 = load ptr, ptr %t194, !tbaa !39
  store ptr %t195, ptr %l17, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l17, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Capture", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t203
  %t204 = getelementptr { i64, [2 x i64] }, ptr %t203, i32 0, i32 0
  store i64 0, ptr %t204
  %t205 = load { i64, [2 x i64] }, ptr %t203
  %t209 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t197, ptr %t201, { i64, [2 x i64] } %t205)
  store %"compiler/scope:Val" %t209, ptr %l122
  br label %bb40
bb40:
  %t210 = load %"compiler/scope:Val", ptr %l122
  store %"compiler/scope:Val" %t210, ptr %l18
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l123, !tbaa !29
  %t212 = load ptr, ptr %l17, !tbaa !29
  %t214 = getelementptr %"compiler/typed:Capture", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t215)
  store i32 %t217, ptr %l126
  br label %bb41
bb41:
  %t218 = load ptr, ptr %l123, !tbaa !29
  %t219 = load i32, ptr %l126, !tbaa !23
  %t220 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t218, i32 %t219)
  store i1 %t220, ptr %l127
  br label %bb42
bb42:
  %t221 = load i1, ptr %l127, !tbaa !21
  %t222 = xor i1 %t221, true
  br i1 %t222, label %bb43, label %bb44
bb43:
  br label %bb72
bb44:
  br label %bb45
bb45:
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l129, !tbaa !29
  %t225 = load %"compiler/scope:Val", ptr %l18
  store %"compiler/scope:Val" %t225, ptr %l130
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t226)
  store { i64, [2 x i64] } %t228, ptr %l132
  br label %bb46
bb46:
  %t229 = load ptr, ptr %l129, !tbaa !29
  %t230 = load %"compiler/scope:Val", ptr %l130
  %t231 = load { i64, [2 x i64] }, ptr %l132
  %t232 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalTerm(ptr %v0, ptr %t229, %"compiler/scope:Val" %t230, { i64, [2 x i64] } %t231)
  store { i64, [2 x i64] } %t232, ptr %l133
  br label %bb47
bb47:
  %t233 = load { i64, [2 x i64] }, ptr %l133
  store { i64, [2 x i64] } %t233, ptr %l19
  store ptr %l12, ptr %l134, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load { i64, [2 x i64] }, ptr %l19
  %t238 = call { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %t234, { i64, [2 x i64] } %t235)
  store { i64, [1 x i64] } %t238, ptr %l137
  br label %bb48
bb48:
  %t239 = load ptr, ptr %l134, !tbaa !29
  %t240 = load { i64, [1 x i64] }, ptr %l137
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %s3, ptr %t239, { i64, [1 x i64] } %t240)
  br label %bb49
bb49:
  %t241 = load { i64, [2 x i64] }, ptr %l19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %s3, ptr %l11, { i64, [2 x i64] } %t241)
  br label %bb50
bb50:
  %t244 = load { i64, [2 x i64] }, ptr %l10
  %t246 = extractvalue { i64, [2 x i64] } %t244, 0
  %t247 = icmp eq i64 %t246, 0
  br i1 %t247, label %bb51, label %bb52
bb51:
  %t249 = load { i64, [2 x i64] }, ptr %l19
  store { i64, [2 x i64] } %t249, ptr %l142
  br label %bb54
bb52:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load { i64, [2 x i64] }, ptr %l10
  %t253 = load { i64, [2 x i64] }, ptr %l19
  %t257 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einner(ptr %v0, ptr %t251, { i64, [2 x i64] } %t252, { i64, [2 x i64] } %t253)
  store { i64, [2 x i64] } %t257, ptr %l147
  br label %bb53
bb53:
  %t258 = load { i64, [2 x i64] }, ptr %l147
  store { i64, [2 x i64] } %t258, ptr %l142
  br label %bb54
bb54:
  %t259 = load { i64, [2 x i64] }, ptr %l142
  store { i64, [2 x i64] } %t259, ptr %l10
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load i64, ptr %l13, !tbaa !24
  %t262 = load ptr, ptr %l17, !tbaa !29
  %t264 = getelementptr %"compiler/typed:Capture", ptr %t262, i32 0, i32 0
  %t265 = load i32, ptr %t264, !tbaa !23
  %t269 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecaptureVar(ptr %v0, ptr %t260, i64 %t261, i32 %t265)
  store i64 %t269, ptr %l152
  br label %bb55
bb55:
  %t270 = load i64, ptr %l152, !tbaa !24
  store i64 %t270, ptr %l20, !tbaa !24
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load i64, ptr %l13, !tbaa !24
  %t273 = load i64, ptr %l20, !tbaa !24
  %t277 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsSum(ptr %v0, ptr %t271, i64 %t272, i64 %t273)
  store i1 %t277, ptr %l156
  br label %bb56
bb56:
  %t278 = load i1, ptr %l156, !tbaa !21
  br i1 %t278, label %bb57, label %bb58
bb57:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load { i64, [2 x i64] }, ptr %l19
  %t281 = load %"compiler/source:Span", ptr %l3
  %t282 = load i64, ptr %l13, !tbaa !24
  %t283 = load i64, ptr %l20, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsThrough(ptr %v0, ptr %t279, { i64, [2 x i64] } %t280, %"compiler/source:Span" %t281, i64 %t282, i64 %t283)
  br label %bb59
bb58:
  %t289 = load i1, ptr %l4, !tbaa !21
  br i1 %t289, label %bb60, label %bb61
bb59:
  br label %bb71
bb60:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load { i64, [2 x i64] }, ptr %l19
  %t295 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoBuildTerm(ptr %v0, ptr %t291, { i64, [2 x i64] } %t292)
  store i1 %t295, ptr %l166
  br label %bb62
bb61:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb63
bb62:
  %t296 = load i1, ptr %l166, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l163, !tbaa !21
  br label %bb63
bb63:
  %t299 = load i1, ptr %l163, !tbaa !21
  br i1 %t299, label %bb64, label %bb65
bb64:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/scope:Scoper", ptr %t300, i32 0, i32 60
  store i1 true, ptr %t302, !tbaa !21
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l169, !tbaa !29
  %t304 = load { i64, [2 x i64] }, ptr %l19
  store { i64, [2 x i64] } %t304, ptr %l170
  %t305 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t305, ptr %l171
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/scope:Scoper", ptr %t306, i32 0, i32 25
  %t309 = load ptr, ptr %t308, !tbaa !29
  %t311 = icmp eq ptr %t309, null
  br i1 %t311, label %bb66, label %bb67
bb65:
  br label %bb70
bb66:
  call void @__olang_check_failed(ptr @olang_loc_a2d4f483fb27576a_a259ee19e61ad216)
  unreachable
bb67:
  br label %bb68
bb68:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/scope:Scoper", ptr %t313, i32 0, i32 25
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Body", ptr %t316, i32 0, i32 3
  %t320 = load i64, ptr %t319, !tbaa !24
  %t321 = load %"compiler/source:Span", ptr %l3
  %t322 = load ptr, ptr %l169, !tbaa !29
  %t323 = load { i64, [2 x i64] }, ptr %l170
  %t324 = load %"compiler/source:Span", ptr %l171
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsInto(ptr %v0, ptr %t322, { i64, [2 x i64] } %t323, %"compiler/source:Span" %t324, i64 %t320, %"compiler/source:Span" %t321)
  br label %bb69
bb69:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/scope:Scoper", ptr %t327, i32 0, i32 60
  store i1 false, ptr %t329, !tbaa !21
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t330 = load i64, ptr %l15, !tbaa !24
  %t332 = add i64 %t330, 1
  store i64 %t332, ptr %l15, !tbaa !24
  br label %bb36
bb73:
  %t334 = load { i64, [2 x i64] }, ptr %l10
  %t336 = extractvalue { i64, [2 x i64] } %t334, 0
  %t337 = icmp eq i64 %t336, 0
  br i1 %t337, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s12
  %t339 = load i1, ptr %l5, !tbaa !21
  br i1 %t339, label %bb76, label %bb77
bb75:
  br label %bb84
bb76:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonFrameAt(ptr %v0, ptr %t341, i32 %t342)
  br label %bb78
bb77:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i32, ptr %l9, !tbaa !23
  %t347 = load { i64, [2 x i64] }, ptr %l2
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuild(ptr %v0, ptr %t345, i32 %t346, { i64, [2 x i64] } %t347)
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb80
bb80:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/scope:Scoper", ptr %t351, i32 0, i32 30
  store ptr %t353, ptr %l192, !tbaa !29
  %t354 = load i32, ptr %l9, !tbaa !23
  store i32 %t354, ptr %l193, !tbaa !23
  %t356 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eToArray_3ccompiler_2ftyped_3aScope_3e(ptr %s3, ptr %s12, ptr %l12)
  store { i64, ptr } %t356, ptr %l195
  br label %bb81
bb81:
  %t357 = load ptr, ptr %l192, !tbaa !29
  %t358 = load i32, ptr %l193, !tbaa !23
  %t359 = load { i64, ptr }, ptr %l195, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %s12, ptr %t357, i32 %t358, { i64, ptr } %t359)
  br label %bb82
bb82:
  %t360 = load { i64, [2 x i64] }, ptr %l2
  %t362 = call %"compiler/scope:Val" @compiler_2fscope_2efresh({ i64, [2 x i64] } %t360)
  store %"compiler/scope:Val" %t362, ptr %l197
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s3)
  %t363 = load %"compiler/scope:Val", ptr %l197
  store %"compiler/scope:Val" %t363, ptr %rv
  br label %ret
bb84:
  %t364 = load i1, ptr %l5, !tbaa !21
  br i1 %t364, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s15
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonFrameAt(ptr %v0, ptr %t366, i32 %t367)
  br label %bb87
bb86:
  br label %bb92
bb87:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/scope:Scoper", ptr %t370, i32 0, i32 30
  store ptr %t372, ptr %l202, !tbaa !29
  %t373 = load i32, ptr %l9, !tbaa !23
  store i32 %t373, ptr %l203, !tbaa !23
  %t375 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eToArray_3ccompiler_2ftyped_3aScope_3e(ptr %s3, ptr %s15, ptr %l12)
  store { i64, ptr } %t375, ptr %l205
  br label %bb88
bb88:
  %t376 = load ptr, ptr %l202, !tbaa !29
  %t377 = load i32, ptr %l203, !tbaa !23
  %t378 = load { i64, ptr }, ptr %l205, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %s15, ptr %t376, i32 %t377, { i64, ptr } %t378)
  br label %bb89
bb89:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t379)
  store { i64, [2 x i64] } %t381, ptr %l207
  br label %bb90
bb90:
  %t382 = load { i64, [2 x i64] }, ptr %l207
  %t383 = call %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %t382)
  store %"compiler/scope:Val" %t383, ptr %l208
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s3)
  %t384 = load %"compiler/scope:Val", ptr %l208
  store %"compiler/scope:Val" %t384, ptr %rv
  br label %ret
bb92:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load { i64, [2 x i64] }, ptr %l10
  %t389 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoBuildTerm(ptr %v0, ptr %t385, { i64, [2 x i64] } %t386)
  store i1 %t389, ptr %l211
  br label %bb93
bb93:
  %t390 = load i1, ptr %l211, !tbaa !21
  br i1 %t390, label %bb94, label %bb95
bb94:
  %t391 = load i1, ptr %l4, !tbaa !21
  br i1 %t391, label %bb96, label %bb97
bb95:
  br label %bb104
bb96:
  %t393 = load { i64, [2 x i64] }, ptr %l2
  %t395 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t393)
  store i1 %t395, ptr %l215
  br label %bb98
bb97:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb99
bb98:
  %t396 = load i1, ptr %l215, !tbaa !21
  store i1 %t396, ptr %l213, !tbaa !21
  br label %bb99
bb99:
  %t397 = load i1, ptr %l213, !tbaa !21
  br i1 %t397, label %bb100, label %bb101
bb100:
  %t398 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t398, ptr %l216
  br label %bb103
bb101:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t400)
  store { i64, [2 x i64] } %t402, ptr %l219
  br label %bb102
bb102:
  %t403 = load { i64, [2 x i64] }, ptr %l219
  store { i64, [2 x i64] } %t403, ptr %l216
  br label %bb103
bb103:
  %t404 = load { i64, [2 x i64] }, ptr %l216
  store { i64, [2 x i64] } %t404, ptr %l10
  br label %bb104
bb104:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l220, !tbaa !29
  %t406 = load i32, ptr %l9, !tbaa !23
  store i32 %t406, ptr %l221, !tbaa !23
  %t407 = load { i64, [2 x i64] }, ptr %l10
  %t409 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t407)
  store i1 %t409, ptr %l223
  br label %bb105
bb105:
  %t410 = load i1, ptr %l223, !tbaa !21
  br i1 %t410, label %bb106, label %bb107
bb106:
  %t411 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t411, ptr %l224
  br label %bb109
bb107:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t413)
  store { i64, [2 x i64] } %t415, ptr %l227
  br label %bb108
bb108:
  %t416 = load { i64, [2 x i64] }, ptr %l227
  store { i64, [2 x i64] } %t416, ptr %l224
  br label %bb109
bb109:
  %t417 = load ptr, ptr %l220, !tbaa !29
  %t418 = load i32, ptr %l221, !tbaa !23
  %t419 = load { i64, [2 x i64] }, ptr %l224
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuild(ptr %v0, ptr %t417, i32 %t418, { i64, [2 x i64] } %t419)
  br label %bb110
bb110:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/scope:Scoper", ptr %t420, i32 0, i32 30
  store ptr %t422, ptr %l229, !tbaa !29
  %t423 = load i32, ptr %l9, !tbaa !23
  store i32 %t423, ptr %l230, !tbaa !23
  %t425 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eToArray_3ccompiler_2ftyped_3aScope_3e(ptr %s3, ptr %s3, ptr %l12)
  store { i64, ptr } %t425, ptr %l232
  br label %bb111
bb111:
  %t426 = load ptr, ptr %l229, !tbaa !29
  %t427 = load i32, ptr %l230, !tbaa !23
  %t428 = load { i64, ptr }, ptr %l232, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %s3, ptr %t426, i32 %t427, { i64, ptr } %t428)
  br label %bb112
bb112:
  %t429 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t429, ptr %l21
  store ptr %l11, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb113
bb113:
  %t432 = load i64, ptr %l23, !tbaa !24
  store i64 %t432, ptr %l235, !tbaa !24
  %t433 = load ptr, ptr %l22, !tbaa !29
  %t435 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %s3, ptr %t433)
  store i64 %t435, ptr %l237
  br label %bb114
bb114:
  %t436 = load i64, ptr %l235, !tbaa !24
  %t437 = load i64, ptr %l237, !tbaa !24
  %t438 = icmp slt i64 %t436, %t437
  %t440 = xor i1 %t438, true
  br i1 %t440, label %bb115, label %bb116
bb115:
  br label %bb129
bb116:
  br label %bb117
bb117:
  %t442 = load ptr, ptr %l22, !tbaa !29
  %t443 = load i64, ptr %l23, !tbaa !24
  %t446 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %s3, ptr %t442, i64 %t443)
  store { i64, [2 x i64] } %t446, ptr %l242
  br label %bb118
bb118:
  %t447 = load { i64, [2 x i64] }, ptr %l242
  store { i64, [2 x i64] } %t447, ptr %l24
  %t448 = load { i64, [2 x i64] }, ptr %l24
  store { i64, [2 x i64] } %t448, ptr %l243
  %t449 = load { i64, [2 x i64] }, ptr %l10
  store { i64, [2 x i64] } %t449, ptr %l245
  %t452 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l243, ptr %l245)
  store i1 %t452, ptr %l247
  br label %bb119
bb119:
  %t453 = load i1, ptr %l247, !tbaa !21
  %t454 = xor i1 %t453, true
  br i1 %t454, label %bb120, label %bb121
bb120:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t457 = load { i64, [2 x i64] }, ptr %l24
  %t458 = load { i64, [2 x i64] }, ptr %l10
  %t462 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t456, { i64, [2 x i64] } %t457, { i64, [2 x i64] } %t458)
  store i64 %t462, ptr %l253
  br label %bb122
bb121:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb123
bb122:
  %t463 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t464 = load i64, ptr %l253, !tbaa !24
  %t466 = icmp ne i64 %t464, %t463
  store i1 %t466, ptr %l249, !tbaa !21
  br label %bb123
bb123:
  %t468 = load i1, ptr %l249, !tbaa !21
  br i1 %t468, label %bb124, label %bb125
bb124:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load { i64, [2 x i64] }, ptr %l21
  %t471 = load { i64, [2 x i64] }, ptr %l24
  %t475 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetOf(ptr %v0, ptr %t469, { i64, [2 x i64] } %t470, { i64, [2 x i64] } %t471)
  store { i64, [2 x i64] } %t475, ptr %l259
  br label %bb126
bb125:
  br label %bb127
bb126:
  %t476 = load { i64, [2 x i64] }, ptr %l259
  store { i64, [2 x i64] } %t476, ptr %l21
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t477 = load i64, ptr %l23, !tbaa !24
  %t479 = add i64 %t477, 1
  store i64 %t479, ptr %l23, !tbaa !24
  br label %bb113
bb129:
  %t481 = load { i64, [2 x i64] }, ptr %l21
  %t483 = call %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %t481)
  store %"compiler/scope:Val" %t483, ptr %l263
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s3)
  %t484 = load %"compiler/scope:Val", ptr %l263
  store %"compiler/scope:Val" %t484, ptr %rv
  br label %ret
bb131:
  %t485 = load ptr, ptr %l1, !tbaa !29
  store ptr %t485, ptr %l264, !tbaa !29
  store i1 false, ptr %l265, !tbaa !21
  %t486 = load ptr, ptr %l264, !tbaa !29
  %t487 = icmp ne ptr %t486, null
  br i1 %t487, label %bb132, label %bb133
bb132:
  %t489 = load ptr, ptr %l264, !tbaa !29
  %t490 = load i64, ptr %t489
  %t492 = icmp eq i64 %t490, 2
  store i1 %t492, ptr %l265, !tbaa !21
  br label %bb133
bb133:
  %t493 = load i1, ptr %l265, !tbaa !21
  br i1 %t493, label %bb134, label %bb135
bb134:
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t496 = getelementptr { i64, [4 x i64] }, ptr %t494, i32 0, i32 1
  %t497 = getelementptr { i32, ptr, i32 }, ptr %t496, i32 0, i32 0
  %t498 = load i32, ptr %t497
  store i32 %t498, ptr %l25, !tbaa !23
  %t500 = load ptr, ptr %l1, !tbaa !29
  %t502 = getelementptr { i64, [4 x i64] }, ptr %t500, i32 0, i32 1
  %t503 = getelementptr { i32, ptr, i32 }, ptr %t502, i32 0, i32 1
  %t504 = load ptr, ptr %t503
  store ptr %t504, ptr %l26, !tbaa !29
  %t506 = load ptr, ptr %l1, !tbaa !29
  %t508 = getelementptr { i64, [4 x i64] }, ptr %t506, i32 0, i32 1
  %t509 = getelementptr { i32, ptr, i32 }, ptr %t508, i32 0, i32 2
  %t510 = load i32, ptr %t509
  store i32 %t510, ptr %l27, !tbaa !23
  br label %bb136
bb135:
  br label %bb180
bb136:
  store %olang.scope zeroinitializer, ptr %s21
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = getelementptr %"compiler/scope:Scoper", ptr %t512, i32 0, i32 27
  %t515 = load i1, ptr %t514, !tbaa !21
  br i1 %t515, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s22
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t519 = getelementptr %"compiler/scope:Scoper", ptr %t517, i32 0, i32 83
  store ptr %t519, ptr %l277, !tbaa !29
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t522 = getelementptr %"compiler/scope:Scoper", ptr %t520, i32 0, i32 25
  %t523 = load ptr, ptr %t522, !tbaa !29
  %t525 = icmp eq ptr %t523, null
  br i1 %t525, label %bb139, label %bb140
bb138:
  br label %bb146
bb139:
  call void @__olang_check_failed(ptr @olang_loc_cd93dd66fff9371_25f7b586ffad81fd)
  unreachable
bb140:
  br label %bb141
bb141:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr %"compiler/scope:Scoper", ptr %t527, i32 0, i32 25
  %t530 = load ptr, ptr %t529, !tbaa !29
  %t533 = getelementptr %"compiler/typed:Body", ptr %t530, i32 0, i32 3
  %t534 = load i64, ptr %t533, !tbaa !24
  store i64 %t534, ptr %l284, !tbaa !24
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load ptr, ptr %l26, !tbaa !29
  %t539 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t535, ptr %t536)
  store %"compiler/source:Span" %t539, ptr %l287
  br label %bb142
bb142:
  %t540 = load i32, ptr %l25, !tbaa !23
  %t542 = sext i32 %t540 to i64
  store i64 %t542, ptr %l289, !tbaa !24
  %t543 = load i64, ptr @G_2ecompiler_2fscope_2eFnCall, !tbaa !24
  store i64 %t543, ptr %l290, !tbaa !24
  %t544 = load ptr, ptr %l26, !tbaa !29
  %t546 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t544)
  store i32 %t546, ptr %l292
  br label %bb143
bb143:
  %t547 = load i64, ptr %l284, !tbaa !24
  %t548 = load %"compiler/source:Span", ptr %l287
  %t549 = load i64, ptr %l289, !tbaa !24
  %t550 = load i64, ptr %l290, !tbaa !24
  %t551 = load i32, ptr %l292, !tbaa !23
  %t552 = call %"compiler/scope:fnUse" @compiler_2fscope_3afnUse_2ector(ptr %s22, i64 %t547, %"compiler/source:Span" %t548, i64 %t549, i64 %t550, i32 %t551)
  store %"compiler/scope:fnUse" %t552, ptr %l293
  br label %bb144
bb144:
  %t553 = load ptr, ptr %l277, !tbaa !29
  %t554 = load %"compiler/scope:fnUse", ptr %l293
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ePush_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %t553, %"compiler/scope:fnUse" %t554)
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s22)
  br label %bb146
bb146:
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t556 = load ptr, ptr %l26, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t558
  %t559 = getelementptr { i64, [2 x i64] }, ptr %t558, i32 0, i32 0
  store i64 0, ptr %t559
  %t560 = load { i64, [2 x i64] }, ptr %t558
  %t564 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t555, ptr %t556, { i64, [2 x i64] } %t560)
  store %"compiler/scope:Val" %t564, ptr %l298
  br label %bb147
bb147:
  %t565 = load %"compiler/scope:Val", ptr %l298
  %t566 = load ptr, ptr %l0, !tbaa !29
  store ptr %t566, ptr %l299, !tbaa !29
  store %"compiler/scope:Val" %t565, ptr %l300
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t568)
  store { i64, [2 x i64] } %t570, ptr %l302
  br label %bb148
bb148:
  %t571 = load ptr, ptr %l299, !tbaa !29
  %t572 = load %"compiler/scope:Val", ptr %l300
  %t573 = load { i64, [2 x i64] }, ptr %l302
  %t574 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalTerm(ptr %v0, ptr %t571, %"compiler/scope:Val" %t572, { i64, [2 x i64] } %t573)
  store { i64, [2 x i64] } %t574, ptr %l303
  br label %bb149
bb149:
  %t575 = load { i64, [2 x i64] }, ptr %l303
  store { i64, [2 x i64] } %t575, ptr %l29
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t577 = load %"compiler/source:Span", ptr %l3
  %t580 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t576, %"compiler/source:Span" %t577)
  store %"compiler/source:Span" %t580, ptr %l306
  br label %bb150
bb150:
  %t581 = load %"compiler/source:Span", ptr %l306
  store %"compiler/source:Span" %t581, ptr %l30
  %t582 = load i1, ptr %l5, !tbaa !21
  br i1 %t582, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s23
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load i32, ptr %l25, !tbaa !23
  %t587 = sext i32 %t585 to i64
  %t590 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamVar(ptr %v0, ptr %t584, i64 %t587, i64 0)
  store i64 %t590, ptr %l311
  br label %bb153
bb152:
  br label %bb164
bb153:
  %t591 = load i64, ptr %l311, !tbaa !24
  store i64 %t591, ptr %l31, !tbaa !24
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = load i32, ptr %l25, !tbaa !23
  %t595 = sext i32 %t593 to i64
  %t596 = load i64, ptr %l31, !tbaa !24
  %t600 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsSum(ptr %v0, ptr %t592, i64 %t595, i64 %t596)
  store i1 %t600, ptr %l316
  br label %bb154
bb154:
  %t601 = load i1, ptr %l316, !tbaa !21
  br i1 %t601, label %bb155, label %bb156
bb155:
  %t602 = load ptr, ptr %l0, !tbaa !29
  %t603 = load { i64, [2 x i64] }, ptr %l29
  %t604 = load %"compiler/source:Span", ptr %l30
  %t605 = load i32, ptr %l25, !tbaa !23
  %t607 = sext i32 %t605 to i64
  %t608 = load i64, ptr %l31, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsThrough(ptr %v0, ptr %t602, { i64, [2 x i64] } %t603, %"compiler/source:Span" %t604, i64 %t607, i64 %t608)
  br label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb158
bb158:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load i32, ptr %l27, !tbaa !23
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonFrameAt(ptr %v0, ptr %t614, i32 %t615)
  br label %bb159
bb159:
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = getelementptr %"compiler/scope:Scoper", ptr %t618, i32 0, i32 30
  store ptr %t620, ptr %l326, !tbaa !29
  %t621 = load i32, ptr %l27, !tbaa !23
  store i32 %t621, ptr %l327, !tbaa !23
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t623 = load { i64, [2 x i64] }, ptr %l29
  %t626 = call { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %t622, { i64, [2 x i64] } %t623)
  store { i64, [1 x i64] } %t626, ptr %l330
  br label %bb160
bb160:
  %t627 = mul i64 1, 16
  %t628 = call ptr @__olang_scope_alloc_zeroed(ptr %s23, i64 %t627)
  %t629 = insertvalue { i64, ptr } undef, i64 1, 0
  %t630 = insertvalue { i64, ptr } %t629, ptr %t628, 1
  store { i64, ptr } %t630, ptr %l331, !tbaa !27
  %t631 = load { i64, [1 x i64] }, ptr %l330
  %t632 = getelementptr { i64, ptr }, ptr %l331, i32 0, i32 1
  %t633 = load ptr, ptr %t632, !tbaa !27
  %t634 = getelementptr { i64, [1 x i64] }, ptr %t633, i64 0
  store { i64, [1 x i64] } %t631, ptr %t634
  %t635 = load ptr, ptr %l326, !tbaa !29
  %t636 = load i32, ptr %l327, !tbaa !23
  %t637 = load { i64, ptr }, ptr %l331, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %s23, ptr %t635, i32 %t636, { i64, ptr } %t637)
  br label %bb161
bb161:
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t640 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t638)
  store { i64, [2 x i64] } %t640, ptr %l333
  br label %bb162
bb162:
  %t641 = load { i64, [2 x i64] }, ptr %l333
  %t642 = call %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %t641)
  store %"compiler/scope:Val" %t642, ptr %l334
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s21)
  %t643 = load %"compiler/scope:Val", ptr %l334
  store %"compiler/scope:Val" %t643, ptr %rv
  br label %ret
bb164:
  %t644 = load ptr, ptr %l0, !tbaa !29
  store ptr %t644, ptr %l335, !tbaa !29
  %t645 = load i32, ptr %l27, !tbaa !23
  store i32 %t645, ptr %l336, !tbaa !23
  %t646 = load { i64, [2 x i64] }, ptr %l29
  %t648 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t646)
  store i1 %t648, ptr %l338
  br label %bb165
bb165:
  %t649 = load i1, ptr %l338, !tbaa !21
  br i1 %t649, label %bb166, label %bb167
bb166:
  %t650 = load { i64, [2 x i64] }, ptr %l29
  store { i64, [2 x i64] } %t650, ptr %l339
  br label %bb169
bb167:
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t654 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t652)
  store { i64, [2 x i64] } %t654, ptr %l342
  br label %bb168
bb168:
  %t655 = load { i64, [2 x i64] }, ptr %l342
  store { i64, [2 x i64] } %t655, ptr %l339
  br label %bb169
bb169:
  %t656 = load %"compiler/source:Span", ptr %l30
  %t657 = load ptr, ptr %l335, !tbaa !29
  %t658 = load i32, ptr %l336, !tbaa !23
  %t659 = load { i64, [2 x i64] }, ptr %l339
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildSite(ptr %v0, ptr %t657, i32 %t658, { i64, [2 x i64] } %t659, %"compiler/source:Span" %t656)
  br label %bb170
bb170:
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t662 = load i32, ptr %l25, !tbaa !23
  %t664 = sext i32 %t662 to i64
  %t667 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamVar(ptr %v0, ptr %t661, i64 %t664, i64 0)
  store i64 %t667, ptr %l347
  br label %bb171
bb171:
  %t668 = load i64, ptr %l347, !tbaa !24
  store i64 %t668, ptr %l32, !tbaa !24
  %t669 = load ptr, ptr %l0, !tbaa !29
  %t670 = load i32, ptr %l25, !tbaa !23
  %t672 = sext i32 %t670 to i64
  %t673 = load i64, ptr %l32, !tbaa !24
  %t677 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsSum(ptr %v0, ptr %t669, i64 %t672, i64 %t673)
  store i1 %t677, ptr %l352
  br label %bb172
bb172:
  %t678 = load i1, ptr %l352, !tbaa !21
  br i1 %t678, label %bb173, label %bb174
bb173:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load { i64, [2 x i64] }, ptr %l29
  %t681 = load %"compiler/source:Span", ptr %l30
  %t682 = load i32, ptr %l25, !tbaa !23
  %t684 = sext i32 %t682 to i64
  %t685 = load i64, ptr %l32, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsThrough(ptr %v0, ptr %t679, { i64, [2 x i64] } %t680, %"compiler/source:Span" %t681, i64 %t684, i64 %t685)
  br label %bb175
bb174:
  br label %bb176
bb175:
  br label %bb176
bb176:
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t693 = getelementptr %"compiler/scope:Scoper", ptr %t691, i32 0, i32 30
  store ptr %t693, ptr %l360, !tbaa !29
  %t694 = load i32, ptr %l27, !tbaa !23
  store i32 %t694, ptr %l361, !tbaa !23
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t696 = load { i64, [2 x i64] }, ptr %l29
  %t699 = call { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %t695, { i64, [2 x i64] } %t696)
  store { i64, [1 x i64] } %t699, ptr %l364
  br label %bb177
bb177:
  %t700 = mul i64 1, 16
  %t701 = call ptr @__olang_scope_alloc_zeroed(ptr %s21, i64 %t700)
  %t702 = insertvalue { i64, ptr } undef, i64 1, 0
  %t703 = insertvalue { i64, ptr } %t702, ptr %t701, 1
  store { i64, ptr } %t703, ptr %l365, !tbaa !27
  %t704 = load { i64, [1 x i64] }, ptr %l364
  %t705 = getelementptr { i64, ptr }, ptr %l365, i32 0, i32 1
  %t706 = load ptr, ptr %t705, !tbaa !27
  %t707 = getelementptr { i64, [1 x i64] }, ptr %t706, i64 0
  store { i64, [1 x i64] } %t704, ptr %t707
  %t708 = load ptr, ptr %l360, !tbaa !29
  %t709 = load i32, ptr %l361, !tbaa !23
  %t710 = load { i64, ptr }, ptr %l365, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %s21, ptr %t708, i32 %t709, { i64, ptr } %t710)
  br label %bb178
bb178:
  %t711 = load { i64, [2 x i64] }, ptr %l29
  %t713 = call %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %t711)
  store %"compiler/scope:Val" %t713, ptr %l367
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s21)
  %t714 = load %"compiler/scope:Val", ptr %l367
  store %"compiler/scope:Val" %t714, ptr %rv
  br label %ret
bb180:
  call void @__olang_check_failed(ptr @olang_loc_7f2dfcb5aefb8d2f_7317cc0c9543fac3)
  unreachable
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eforWrap(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l20 = alloca %"compiler/typed:BlockInfo"
  %l24 = alloca i1
  %l36 = alloca i64
  %l39 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l62 = alloca i1
  %l73 = alloca i1
  %l83 = alloca %"compiler/typed:Local"
  %l88 = alloca ptr
  %l89 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_6b4093eaa9dab6e0_ebbf8088c45502d4)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 8
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Block", ptr %t15, i32 0, i32 0
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t23 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t14, i64 %t20)
  store %"compiler/typed:BlockInfo" %t23, ptr %l20
  br label %bb4
bb4:
  %t24 = getelementptr %"compiler/typed:BlockInfo", ptr %l20, i32 0, i32 1
  %t25 = load i32, ptr %t24
  %t27 = trunc i64 1 to i32
  %t28 = icmp eq i32 %t25, %t27
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb7
bb6:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Block", ptr %t32, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t39 = icmp slt i64 %t37, 2
  store i1 %t39, ptr %l24, !tbaa !21
  br label %bb7
bb7:
  %t41 = load i1, ptr %l24, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  store i64 0, ptr %l2, !tbaa !24
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Block", ptr %t43, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  store i64 %t48, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb11, label %bb12
bb11:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb16
bb13:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t61 = load i64, ptr %l2, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l4, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l4, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l39, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb15
bb15:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l36, !tbaa !24
  br label %bb16
bb16:
  %t77 = load i64, ptr %l36, !tbaa !24
  store i64 %t77, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb18, label %bb19
bb18:
  br label %bb52
bb19:
  br label %bb20
bb20:
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l7, !tbaa !24
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Block", ptr %t96, i32 0, i32 1
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l58, !tbaa !27
  %t100 = load i64, ptr %l7, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr ptr, ptr %t103, i64 %t100
  %t105 = load ptr, ptr %t104, !tbaa !39
  store ptr %t105, ptr %l8, !tbaa !29
  %t107 = load ptr, ptr %l8, !tbaa !29
  store ptr %t107, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t108 = load ptr, ptr %l61, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb21, label %bb22
bb21:
  %t111 = load ptr, ptr %l61, !tbaa !29
  %t112 = load i64, ptr %t111
  %t114 = icmp eq i64 %t112, 0
  store i1 %t114, ptr %l62, !tbaa !21
  br label %bb22
bb22:
  %t115 = load i1, ptr %l62, !tbaa !21
  br i1 %t115, label %bb23, label %bb24
bb23:
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t118 = getelementptr { i64, [3 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t118, i32 0, i32 1
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l9, !tbaa !23
  br label %bb25
bb24:
  br label %bb36
bb25:
  %t122 = load i64, ptr %l7, !tbaa !24
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Block", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t130 = sub i64 %t128, 1
  %t133 = icmp eq i64 %t122, %t130
  br i1 %t133, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb32
bb27:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/scope:Scoper", ptr %t135, i32 0, i32 25
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = icmp eq ptr %t138, null
  br i1 %t140, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_a83726b6934b3ff_5f714cf565db93e3)
  unreachable
bb29:
  br label %bb30
bb30:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/scope:Scoper", ptr %t142, i32 0, i32 25
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Body", ptr %t145, i32 0, i32 7
  %t149 = load i32, ptr %l9, !tbaa !23
  %t151 = sext i32 %t149 to i64
  %t154 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t148, i64 %t151)
  store %"compiler/typed:Local" %t154, ptr %l83
  br label %bb31
bb31:
  %t155 = getelementptr %"compiler/typed:Local", ptr %l83, i32 0, i32 4
  %t156 = load i32, ptr %t155
  %t158 = trunc i64 1 to i32
  %t159 = icmp eq i32 %t156, %t158
  %t161 = xor i1 %t159, true
  store i1 %t161, ptr %l73, !tbaa !21
  br label %bb32
bb32:
  %t163 = load i1, ptr %l73, !tbaa !21
  br i1 %t163, label %bb33, label %bb34
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb50
bb36:
  %t165 = load ptr, ptr %l8, !tbaa !29
  store ptr %t165, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t166 = load ptr, ptr %l88, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb37, label %bb38
bb37:
  %t169 = load ptr, ptr %l88, !tbaa !29
  %t170 = load i64, ptr %t169
  %t172 = icmp eq i64 %t170, 4
  store i1 %t172, ptr %l89, !tbaa !21
  br label %bb38
bb38:
  %t173 = load i1, ptr %l89, !tbaa !21
  br i1 %t173, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t174 = load i64, ptr %l7, !tbaa !24
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/typed:Block", ptr %t175, i32 0, i32 1
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t182 = sub i64 %t180, 1
  %t185 = icmp ne i64 %t174, %t182
  br i1 %t185, label %bb42, label %bb43
bb42:
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i1 false, ptr %rv
  br label %ret
bb49:
  call void @__olang_check_failed(ptr @olang_loc_2e96c7acbe66a05d_c52c59876e2a2911)
  unreachable
bb50:
  br label %bb51
bb51:
  %t189 = load i64, ptr %l6, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l6, !tbaa !24
  br label %bb17
bb52:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eframeHere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca i32
  %l22 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t37 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 34
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 34
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = sub i64 %t9, 1
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t11, i64 %t10)
  store i32 %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load i32, ptr %l9, !tbaa !23
  store i32 %t14, ptr %l1, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 25
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_cf803334873ab58c_86e77fabc50c4870)
  unreachable
bb4:
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/scope:Scoper", ptr %t22, i32 0, i32 25
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 1
  %t29 = load { i64, [2 x i64] }, ptr %t28
  %t33 = extractvalue { i64, [2 x i64] } %t29, 0
  %t34 = icmp eq i64 %t33, 1
  br i1 %t34, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t36 = load i32, ptr %l1, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t37
  %t38 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 0
  store i64 1, ptr %t38
  %t40 = insertvalue { i32 } undef, i32 %t36, 0
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t37, i32 0, i32 1
  store { i32 } %t40, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t37
  store { i64, [2 x i64] } %t42, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t44)
  store { i64, [2 x i64] } %t46, ptr %l22
  br label %bb13
bb13:
  %t47 = load { i64, [2 x i64] }, ptr %l22
  store { i64, [2 x i64] } %t47, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9240ff9e46a5e522_bd3125f7ca002596)
  unreachable
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca i1
  %l20 = alloca ptr
  %l29 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t38 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_eb63e604b2611290_41d83017cc1dec3c)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 15
  %t15 = load i1, ptr %t14, !tbaa !21
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 25
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_eb63e604b2611290_41d83017cc1dec3c)
  unreachable
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/scope:Scoper", ptr %t26, i32 0, i32 25
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 16
  %t33 = load i32, ptr %t32, !tbaa !23
  %t35 = icmp slt i32 %t33, 0
  store i1 %t35, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l9, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  store { i64, [2 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 0
  store i64 0, ptr %t39
  %t40 = load { i64, [2 x i64] }, ptr %t38
  store { i64, [2 x i64] } %t40, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/scope:Scoper", ptr %t42, i32 0, i32 31
  store ptr %t44, ptr %l20, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/scope:Scoper", ptr %t45, i32 0, i32 25
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  br i1 %t50, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_6c6eb04d68cfd0ef_192fcc26ed37d7ab)
  unreachable
bb14:
  br label %bb15
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/scope:Scoper", ptr %t52, i32 0, i32 25
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t55, i32 0, i32 16
  %t59 = load i32, ptr %t58, !tbaa !23
  %t61 = sext i32 %t59 to i64
  %t62 = load ptr, ptr %l20, !tbaa !29
  %t64 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t62, i64 %t61)
  store { i64, [2 x i64] } %t64, ptr %l29
  br label %bb16
bb16:
  %t65 = load { i64, [2 x i64] }, ptr %l29
  store { i64, [2 x i64] } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehandleLent(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca i32
  %l10 = alloca i32
  %l17 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca { i64, ptr }
  %l28 = alloca i1
  %l30 = alloca { i64, ptr }
  %l33 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l43 = alloca i32
  %l44 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l60 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  store ptr %t19, ptr %l17, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l4, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l22
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = load i32, ptr %l22, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t30, i32 %t31)
  store { i64, ptr } %t32, ptr %l23
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = icmp sge i64 %t34, %t37
  br i1 %t40, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb10
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i32, ptr %t47, i64 %t44
  %t49 = load i32, ptr %t48, !tbaa !33
  %t52 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t42, i32 %t49)
  store i1 %t52, ptr %l33
  br label %bb9
bb9:
  %t53 = load i1, ptr %l33, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb10
bb10:
  %t56 = load i1, ptr %l28, !tbaa !21
  br i1 %t56, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb15
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l36, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t64, ptr %l40, !tbaa !27
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i32, ptr %t68, i64 %t65
  %t70 = load i32, ptr %t69, !tbaa !33
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t63, i32 %t70)
  store i32 %t73, ptr %l43
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load i32, ptr %l43, !tbaa !23
  %t76 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t76, ptr %l44
  br label %bb14
bb14:
  %t77 = load i1, ptr %l44, !tbaa !21
  %t78 = xor i1 %t77, true
  store i1 %t78, ptr %l35, !tbaa !21
  br label %bb15
bb15:
  %t80 = load i1, ptr %l35, !tbaa !21
  br i1 %t80, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Call", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l6, !tbaa !29
  %t87 = load ptr, ptr %l6, !tbaa !29
  store ptr %t87, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t88 = load ptr, ptr %l49, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t91 = load ptr, ptr %l49, !tbaa !29
  %t92 = load i64, ptr %t91
  %t94 = icmp eq i64 %t92, 0
  store i1 %t94, ptr %l50, !tbaa !21
  br label %bb20
bb20:
  %t95 = load i1, ptr %l50, !tbaa !21
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t96 = load ptr, ptr %l6, !tbaa !29
  %t98 = getelementptr { i64, [3 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { i32 }, ptr %t98, i32 0, i32 0
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l7, !tbaa !23
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l7, !tbaa !23
  %t105 = sext i32 %t103 to i64
  %t106 = load i64, ptr %l2, !tbaa !24
  %t107 = load i64, ptr @G_2ecompiler_2fscope_2eUseThru, !tbaa !24
  %t112 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euses(ptr %v0, ptr %t102, i64 %t105, i64 %t106, i64 %t107)
  store i1 %t112, ptr %l60
  br label %bb24
bb24:
  %t113 = load i1, ptr %l60, !tbaa !21
  store i1 %t113, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_10bab568b406970b_66071842e5074daf)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisAdapter(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_a5122b0b395bd8b_9870aa37c8b5f2ef)
  unreachable
bb16:
  br label %bb29
bb17:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb18, label %bb19
bb18:
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 17
  store i1 %t33, ptr %l16, !tbaa !21
  br label %bb19
bb19:
  %t34 = load i1, ptr %l16, !tbaa !21
  br i1 %t34, label %bb20, label %bb21
bb20:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t45 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisAdapter(ptr %v0, ptr %v1, ptr %a0, ptr %t42)
  store i1 %t45, ptr %l23
  br label %bb23
bb23:
  %t46 = load i1, ptr %l23, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_51a7ef38ab67534a_42b12633f9b5762e)
  unreachable
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisLambda(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Body", ptr %a1, i32 0, i32 1
  %t4 = load { i64, [2 x i64] }, ptr %t3
  %t8 = extractvalue { i64, [2 x i64] } %t4, 0
  %t9 = icmp eq i64 %t8, 4
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_eb1882221c8ba3ab_83c8c93664e1ea07)
  unreachable
bb9:
  %t11 = load i1, ptr %l5, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca i1
  %l38 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 1
  %t4 = load { i64, [2 x i64] }, ptr %t3
  store { i64, [2 x i64] } %t4, ptr %l2
  %t6 = load { i64, [2 x i64] }, ptr %l2
  %t8 = extractvalue { i64, [2 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t12 = getelementptr { i64 }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb19
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t22, i64 %t23)
  store i64 %t26, ptr %l16
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t27, i64 %t28)
  store ptr %t29, ptr %l17
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l17, !tbaa !29
  store ptr %t30, ptr %l4, !tbaa !29
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Func", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb9
bb7:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 5
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v1, ptr %t40)
  store i64 %t42, ptr %l24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l24, !tbaa !24
  %t44 = icmp ne i64 %t43, 1
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/scope:Scoper", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/load:Loader", ptr %t54, i32 0, i32 3
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Func", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t57, i32 %t61)
  store { i64, ptr } %t64, ptr %l33
  br label %bb13
bb13:
  %t65 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t65, ptr %l5, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t66, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t68, ptr %l35
  br label %bb14
bb14:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb18
bb16:
  %t70 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t70, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t72, ptr %l38
  br label %bb17
bb17:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l36, !tbaa !21
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  %t74 = load i1, ptr %l36, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_23c81803d40008f7_62b49cfbea8bbbfb)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisText(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i32
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l21 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d12, i32 0, i32 1) }, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i32 %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load i32, ptr %l5, !tbaa !23
  store i32 %t7, ptr %l2, !tbaa !23
  %t8 = load i32, ptr %l2, !tbaa !23
  %t10 = icmp slt i32 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = icmp eq i32 %t13, %t14
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l1, !tbaa !23
  %t23 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t23, ptr %l15
  br label %bb7
bb7:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l21
  br label %bb10
bb9:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb11
bb10:
  %t35 = load i32, ptr %l2, !tbaa !23
  %t36 = load i32, ptr %l21, !tbaa !23
  %t38 = icmp eq i32 %t36, %t35
  store i1 %t38, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l16, !tbaa !21
  store i1 %t40, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i1, ptr %l12, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eitem(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l4 = alloca %"compiler/scope:Val"
  %l9 = alloca %"compiler/scope:Val"
  %l12 = alloca ptr
  %l13 = alloca { i64, [2 x i64] }
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t8 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1, ptr %t2, { i64, [2 x i64] } %t4)
  store %"compiler/scope:Val" %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load %"compiler/scope:Val", ptr %l9
  store %"compiler/scope:Val" %t9, ptr %l4
  %t10 = getelementptr %"compiler/scope:Val", ptr %l4, i32 0, i32 0
  %t11 = load i32, ptr %t10
  %t13 = trunc i64 3 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = getelementptr %"compiler/scope:Val", ptr %l4, i32 0, i32 1
  %t18 = load { i64, [2 x i64] }, ptr %t17
  store { i64, [2 x i64] } %t18, ptr %l13
  %t19 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t19, ptr %l14
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l17
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i32, ptr %l17, !tbaa !23
  %t26 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t26, ptr %l18
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = load ptr, ptr %l12, !tbaa !29
  %t30 = load { i64, [2 x i64] }, ptr %l13
  %t31 = load { i64, [2 x i64] }, ptr %l14
  %t32 = load i1, ptr %l18, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t29, { i64, [2 x i64] } %t30, { i64, [2 x i64] } %t31, i1 %t32, ptr %t27, i64 %a3)
  br label %bb6
bb6:
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudge(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:Local"
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca %"compiler/scope:rel"
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l48 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca i64
  %l61 = alloca %"compiler/typed:Local"
  %l68 = alloca i1
  %l73 = alloca i1
  %l76 = alloca i1
  %l137 = alloca i1
  %l140 = alloca i1
  %l144 = alloca ptr
  %l149 = alloca i64
  %l156 = alloca ptr
  %l158 = alloca %"compiler/typed:Plan"
  %l173 = alloca i1
  %l176 = alloca i64
  %l180 = alloca i64
  %l183 = alloca i64
  %l221 = alloca { i64, [1 x i64] }
  %l227 = alloca i64
  %l229 = alloca i1
  %l230 = alloca i32
  %l233 = alloca i32
  %l254 = alloca ptr
  %l259 = alloca i64
  %l260 = alloca i64
  %l261 = alloca ptr
  %l264 = alloca i64
  %l265 = alloca i64
  %l266 = alloca ptr
  %l267 = alloca %"compiler/source:Span"
  %l268 = alloca ptr
  %l269 = alloca %"compiler/source:Span"
  %l272 = alloca i1
  %l276 = alloca i1
  %l280 = alloca i1
  %l284 = alloca ptr
  %l286 = alloca %"compiler/source:Span"
  %l287 = alloca %"compiler/msgs:Msg"
  %l288 = alloca i64
  %l289 = alloca ptr
  %l290 = alloca i64
  %l292 = alloca i64
  %l294 = alloca %"compiler/source:Span"
  %l295 = alloca %"compiler/msgs:Msg"
  %l301 = alloca i64
  %l304 = alloca i64
  %l333 = alloca i64
  %l336 = alloca i64
  %l338 = alloca i64
  %l343 = alloca %"compiler/scope:rel"
  %l347 = alloca ptr
  %l351 = alloca i1
  %l356 = alloca ptr
  %l365 = alloca ptr
  %l374 = alloca i64
  %l376 = alloca i64
  %l381 = alloca { i64, [2 x i64] }
  %l397 = alloca i64
  %l401 = alloca i64
  %l404 = alloca i64
  %l423 = alloca ptr
  %l427 = alloca i1
  %l429 = alloca ptr
  %l433 = alloca i1
  %l435 = alloca ptr
  %l439 = alloca i64
  %l441 = alloca ptr
  %l445 = alloca %"compiler/source:Span"
  %l452 = alloca i64
  %l456 = alloca i64
  %l459 = alloca i64
  %l483 = alloca { i64, ptr }
  %l484 = alloca i64
  %l488 = alloca i1
  %l496 = alloca %"compiler/typed:Plan"
  %s0 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %t228 = alloca { i64, [2 x i64] }, align 8
  %t241 = alloca %"compiler/typed:Plan", align 8
  %t939 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l48
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l48, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 7
  store ptr %t18, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  store i64 %t20, ptr %l54, !tbaa !24
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l56
  br label %bb6
bb6:
  %t24 = load i64, ptr %l54, !tbaa !24
  %t25 = load i64, ptr %l56, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb15
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t30, i64 %t31)
  store %"compiler/typed:Local" %t34, ptr %l61
  br label %bb10
bb10:
  %t35 = load %"compiler/typed:Local", ptr %l61
  store %"compiler/typed:Local" %t35, ptr %l6
  %t36 = getelementptr %"compiler/typed:Local", ptr %l6, i32 0, i32 2
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t41 = icmp eq i32 %t37, %t38
  br i1 %t41, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t43 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l5, !tbaa !24
  br label %bb5
bb15:
  %t47 = load i1, ptr %l2, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 48
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = icmp ne i64 %t52, %t53
  store i1 %t56, ptr %l68, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l68, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i64, ptr %l1, !tbaa !24
  %t63 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehasLateLocals(ptr %v0, ptr %t59, i64 %t60)
  store i1 %t63, ptr %l76
  br label %bb21
bb20:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb22
bb21:
  %t64 = load i1, ptr %l76, !tbaa !21
  store i1 %t64, ptr %l73, !tbaa !21
  br label %bb22
bb22:
  %t65 = load i1, ptr %l73, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l1, !tbaa !24
  %t70 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 48
  store i64 %t67, ptr %t70, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/scope:Scoper", ptr %t71, i32 0, i32 50
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H075aca2c24d2905e4fa457b6b6d6570e(ptr %v0, ptr %t73)
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/scope:Scoper", ptr %t75, i32 0, i32 51
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t77)
  br label %bb26
bb26:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/scope:Scoper", ptr %t79, i32 0, i32 52
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t81)
  br label %bb27
bb27:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 49
  store i1 true, ptr %t85, !tbaa !21
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejudge(ptr %v0, ptr %t86, i64 %t87, i1 false)
  br label %bb28
bb28:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/scope:Scoper", ptr %t90, i32 0, i32 49
  store i1 false, ptr %t92, !tbaa !21
  br label %bb29
bb29:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/scope:Scoper", ptr %t93, i32 0, i32 11
  %t96 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t95, i64 %t96, i1 true)
  br label %bb30
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t104 = getelementptr %"compiler/scope:Scoper", ptr %t99, i32 0, i32 25
  store ptr %t100, ptr %t104, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i64, ptr %l1, !tbaa !24
  %t109 = getelementptr %"compiler/scope:Scoper", ptr %t105, i32 0, i32 26
  store i64 %t106, ptr %t109, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t112)
  br label %bb31
bb31:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t116)
  br label %bb32
bb32:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/scope:Scoper", ptr %t118, i32 0, i32 33
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %t120)
  br label %bb33
bb33:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/scope:Scoper", ptr %t122, i32 0, i32 34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t124)
  br label %bb34
bb34:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/scope:Scoper", ptr %t126, i32 0, i32 72
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t128)
  br label %bb35
bb35:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/scope:Scoper", ptr %t130, i32 0, i32 35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eClear_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t132)
  br label %bb36
bb36:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/scope:Scoper", ptr %t134, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t136)
  br label %bb37
bb37:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/scope:Scoper", ptr %t138, i32 0, i32 37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t140)
  br label %bb38
bb38:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/scope:Scoper", ptr %t142, i32 0, i32 40
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %t144)
  br label %bb39
bb39:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/scope:Scoper", ptr %t146, i32 0, i32 41
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %t148)
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/scope:Scoper", ptr %t150, i32 0, i32 42
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %t152)
  br label %bb41
bb41:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/scope:Scoper", ptr %t154, i32 0, i32 43
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t156)
  br label %bb42
bb42:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/scope:Scoper", ptr %t158, i32 0, i32 44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t160)
  br label %bb43
bb43:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/scope:Scoper", ptr %t162, i32 0, i32 45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t164)
  br label %bb44
bb44:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/scope:Scoper", ptr %t166, i32 0, i32 46
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t168)
  br label %bb45
bb45:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/scope:Scoper", ptr %t170, i32 0, i32 53
  store i64 -1, ptr %t172, !tbaa !24
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/scope:Scoper", ptr %t173, i32 0, i32 55
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t175)
  br label %bb46
bb46:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/scope:Scoper", ptr %t177, i32 0, i32 56
  store i1 false, ptr %t179, !tbaa !21
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/scope:Scoper", ptr %t180, i32 0, i32 57
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eClea_Hf36a88772899b36a46c039ef55a38999(ptr %v0, ptr %t182)
  br label %bb47
bb47:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/scope:Scoper", ptr %t184, i32 0, i32 39
  store i64 -1, ptr %t186, !tbaa !24
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/scope:Scoper", ptr %t187, i32 0, i32 65
  store i64 -1, ptr %t189, !tbaa !24
  %t190 = load ptr, ptr %l3, !tbaa !29
  %t192 = getelementptr %"compiler/typed:Body", ptr %t190, i32 0, i32 15
  %t193 = load i1, ptr %t192, !tbaa !21
  br i1 %t193, label %bb48, label %bb49
bb48:
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t197 = getelementptr %"compiler/typed:Body", ptr %t195, i32 0, i32 17
  %t198 = load i1, ptr %t197, !tbaa !21
  store i1 %t198, ptr %l137, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb50
bb50:
  %t200 = load i1, ptr %l137, !tbaa !21
  br i1 %t200, label %bb51, label %bb52
bb51:
  %t201 = load ptr, ptr %l3, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Body", ptr %t201, i32 0, i32 16
  %t204 = load i32, ptr %t203, !tbaa !23
  %t206 = icmp sge i32 %t204, 0
  store i1 %t206, ptr %l140, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb53
bb53:
  %t208 = load i1, ptr %l140, !tbaa !21
  br i1 %t208, label %bb54, label %bb55
bb54:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l144, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i64, ptr %l1, !tbaa !24
  %t212 = load ptr, ptr %l3, !tbaa !29
  %t214 = getelementptr %"compiler/typed:Body", ptr %t212, i32 0, i32 16
  %t215 = load i32, ptr %t214, !tbaa !23
  %t219 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecaptureVar(ptr %v0, ptr %t210, i64 %t211, i32 %t215)
  store i64 %t219, ptr %l149
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t220 = load i64, ptr %l149, !tbaa !24
  %t221 = load ptr, ptr %l144, !tbaa !29
  %t222 = getelementptr %"compiler/scope:Scoper", ptr %t221, i32 0, i32 65
  store i64 %t220, ptr %t222, !tbaa !24
  br label %bb57
bb57:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/scope:Scoper", ptr %t223, i32 0, i32 66
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %t225)
  br label %bb58
bb58:
  %t227 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t228
  %t229 = getelementptr { i64, [2 x i64] }, ptr %t228, i32 0, i32 0
  store i64 0, ptr %t229
  %t230 = load { i64, [2 x i64] }, ptr %t228
  %t233 = getelementptr %"compiler/scope:Scoper", ptr %t227, i32 0, i32 67
  store { i64, [2 x i64] } %t230, ptr %t233
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i1, ptr %l2, !tbaa !21
  %t238 = getelementptr %"compiler/scope:Scoper", ptr %t234, i32 0, i32 27
  store i1 %t235, ptr %t238, !tbaa !21
  %t239 = load ptr, ptr %l0, !tbaa !29
  store ptr %t239, ptr %l156, !tbaa !29
  %t240 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2eNewPlan(ptr %t241, ptr %v0, ptr %v0, ptr %t240)
  call void @llvm.memmove.p0.p0.i64(ptr %l158, ptr %t241, i64 152, i1 false)
  br label %bb59
bb59:
  %t243 = load ptr, ptr %l156, !tbaa !29
  %t244 = getelementptr %"compiler/scope:Scoper", ptr %t243, i32 0, i32 30
  call void @llvm.memmove.p0.p0.i64(ptr %t244, ptr %l158, i64 152, i1 false)
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/scope:Scoper", ptr %t245, i32 0, i32 58
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t247)
  br label %bb60
bb60:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/scope:Scoper", ptr %t249, i32 0, i32 59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t251)
  br label %bb61
bb61:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/scope:Scoper", ptr %t253, i32 0, i32 61
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t255)
  br label %bb62
bb62:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/scope:Scoper", ptr %t257, i32 0, i32 62
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t259)
  br label %bb63
bb63:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/scope:Scoper", ptr %t261, i32 0, i32 63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t263)
  br label %bb64
bb64:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/scope:Scoper", ptr %t265, i32 0, i32 64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t267)
  br label %bb65
bb65:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load ptr, ptr %l3, !tbaa !29
  %t273 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisStr(ptr %v0, ptr %v0, ptr %t269, ptr %t270)
  store i1 %t273, ptr %l173
  br label %bb66
bb66:
  %t274 = load i1, ptr %l173, !tbaa !21
  store i1 %t274, ptr %l7, !tbaa !21
  store i64 0, ptr %l8, !tbaa !24
  %t275 = load ptr, ptr %l3, !tbaa !29
  %t277 = getelementptr %"compiler/typed:Body", ptr %t275, i32 0, i32 6
  %t279 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t277)
  store i64 %t279, ptr %l176
  br label %bb67
bb67:
  %t280 = load i64, ptr %l176, !tbaa !24
  store i64 %t280, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t281 = load i64, ptr %l9, !tbaa !24
  %t282 = load i64, ptr %l8, !tbaa !24
  %t285 = icmp sgt i64 %t281, %t282
  br i1 %t285, label %bb68, label %bb69
bb68:
  %t287 = load i64, ptr %l10, !tbaa !24
  %t289 = icmp sgt i64 %t287, 0
  br i1 %t289, label %bb70, label %bb71
bb69:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb73
bb70:
  %t291 = load i64, ptr %l9, !tbaa !24
  %t292 = load i64, ptr %l8, !tbaa !24
  %t295 = sub i64 %t291, %t292
  %t296 = load i64, ptr %l10, !tbaa !24
  %t299 = add i64 %t295, %t296
  %t301 = sub i64 %t299, 1
  %t302 = load i64, ptr %l10, !tbaa !24
  %t305 = sdiv i64 %t301, %t302
  store i64 %t305, ptr %l183, !tbaa !24
  br label %bb72
bb71:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb72
bb72:
  %t307 = load i64, ptr %l183, !tbaa !24
  store i64 %t307, ptr %l180, !tbaa !24
  br label %bb73
bb73:
  %t308 = load i64, ptr %l180, !tbaa !24
  store i64 %t308, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb74
bb74:
  %t309 = load i64, ptr %l12, !tbaa !24
  %t310 = load i64, ptr %l11, !tbaa !24
  %t313 = icmp slt i64 %t309, %t310
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb75, label %bb76
bb75:
  br label %bb103
bb76:
  br label %bb77
bb77:
  %t317 = load i64, ptr %l8, !tbaa !24
  %t318 = load i64, ptr %l12, !tbaa !24
  %t319 = load i64, ptr %l10, !tbaa !24
  %t322 = mul i64 %t318, %t319
  %t325 = add i64 %t317, %t322
  store i64 %t325, ptr %l13, !tbaa !24
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/scope:Scoper", ptr %t327, i32 0, i32 58
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t329, i1 false)
  br label %bb78
bb78:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/scope:Scoper", ptr %t331, i32 0, i32 59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t333, i1 false)
  br label %bb79
bb79:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/scope:Scoper", ptr %t335, i32 0, i32 61
  %t338 = load ptr, ptr %l3, !tbaa !29
  %t340 = getelementptr %"compiler/typed:Body", ptr %t338, i32 0, i32 4
  %t341 = load %"compiler/source:Span", ptr %t340
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t337, %"compiler/source:Span" %t341)
  br label %bb80
bb80:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/scope:Scoper", ptr %t344, i32 0, i32 62
  %t347 = load ptr, ptr %l3, !tbaa !29
  %t349 = getelementptr %"compiler/typed:Body", ptr %t347, i32 0, i32 3
  %t350 = load i64, ptr %t349, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t346, i64 %t350)
  br label %bb81
bb81:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/scope:Scoper", ptr %t353, i32 0, i32 63
  %t356 = load ptr, ptr %l3, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Body", ptr %t356, i32 0, i32 4
  %t359 = load %"compiler/source:Span", ptr %t358
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t355, %"compiler/source:Span" %t359)
  br label %bb82
bb82:
  store i1 false, ptr %l14, !tbaa !21
  %t362 = load i1, ptr %l7, !tbaa !21
  br i1 %t362, label %bb83, label %bb84
bb83:
  %t364 = load ptr, ptr %l3, !tbaa !29
  %t366 = getelementptr %"compiler/typed:Body", ptr %t364, i32 0, i32 6
  %t367 = load i64, ptr %l13, !tbaa !24
  %t370 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t366, i64 %t367)
  store { i64, [1 x i64] } %t370, ptr %l221
  br label %bb85
bb84:
  br label %bb100
bb85:
  %t371 = load { i64, [1 x i64] }, ptr %l221
  store { i64, [1 x i64] } %t371, ptr %l15
  %t372 = load { i64, [1 x i64] }, ptr %l15
  %t374 = extractvalue { i64, [1 x i64] } %t372, 0
  %t375 = icmp eq i64 %t374, 0
  br i1 %t375, label %bb86, label %bb87
bb86:
  %t377 = getelementptr { i64, [1 x i64] }, ptr %l15, i32 0, i32 1
  %t378 = getelementptr { i32 }, ptr %t377, i32 0, i32 0
  %t379 = load i32, ptr %t378
  store i32 %t379, ptr %l16, !tbaa !23
  br label %bb88
bb87:
  br label %bb94
bb88:
  %t381 = load ptr, ptr %l3, !tbaa !29
  %t383 = getelementptr %"compiler/typed:Body", ptr %t381, i32 0, i32 5
  %t385 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t383)
  store i64 %t385, ptr %l227
  br label %bb89
bb89:
  %t386 = load i64, ptr %l227, !tbaa !24
  %t387 = icmp sgt i64 %t386, 0
  br i1 %t387, label %bb90, label %bb91
bb90:
  %t389 = load i32, ptr %l16, !tbaa !23
  store i32 %t389, ptr %l230, !tbaa !23
  %t390 = load ptr, ptr %l3, !tbaa !29
  %t392 = getelementptr %"compiler/typed:Body", ptr %t390, i32 0, i32 5
  %t394 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t392, i64 0)
  store i32 %t394, ptr %l233
  br label %bb92
bb91:
  store i1 false, ptr %l229, !tbaa !21
  br label %bb93
bb92:
  %t395 = load i32, ptr %l230, !tbaa !23
  %t396 = load i32, ptr %l233, !tbaa !23
  %t397 = icmp eq i32 %t395, %t396
  store i1 %t397, ptr %l229, !tbaa !21
  br label %bb93
bb93:
  %t399 = load i1, ptr %l229, !tbaa !21
  store i1 %t399, ptr %l14, !tbaa !21
  br label %bb99
bb94:
  br i1 true, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_75ea16a293881b53_a3e5ee6d3f4964f)
  unreachable
bb99:
  br label %bb100
bb100:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/scope:Scoper", ptr %t400, i32 0, i32 64
  %t403 = load i1, ptr %l14, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t402, i1 %t403)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t406 = load i64, ptr %l12, !tbaa !24
  %t408 = add i64 %t406, 1
  store i64 %t408, ptr %l12, !tbaa !24
  br label %bb74
bb103:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/scope:Scoper", ptr %t410, i32 0, i32 87
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t412)
  br label %bb104
bb104:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = getelementptr %"compiler/scope:Scoper", ptr %t414, i32 0, i32 88
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t416)
  br label %bb105
bb105:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/scope:Scoper", ptr %t418, i32 0, i32 89
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %t420)
  br label %bb106
bb106:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/scope:Scoper", ptr %t422, i32 0, i32 90
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %t424)
  br label %bb107
bb107:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/scope:Scoper", ptr %t426, i32 0, i32 92
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t428)
  br label %bb108
bb108:
  store i64 0, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t430 = load i1, ptr %l2, !tbaa !21
  br i1 %t430, label %bb109, label %bb110
bb109:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/scope:Scoper", ptr %t432, i32 0, i32 0
  %t435 = load ptr, ptr %t434, !tbaa !29
  %t437 = getelementptr %"compiler/generic:Program", ptr %t435, i32 0, i32 0
  %t438 = load ptr, ptr %t437, !tbaa !29
  %t440 = getelementptr %"compiler/load:Loader", ptr %t438, i32 0, i32 4
  %t441 = load ptr, ptr %t440, !tbaa !29
  store ptr %t441, ptr %l254, !tbaa !29
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/scope:Scoper", ptr %t442, i32 0, i32 0
  %t445 = load ptr, ptr %t444, !tbaa !29
  %t447 = getelementptr %"compiler/generic:Program", ptr %t445, i32 0, i32 0
  %t448 = load ptr, ptr %t447, !tbaa !29
  %t450 = getelementptr %"compiler/load:Loader", ptr %t448, i32 0, i32 4
  %t451 = load ptr, ptr %t450, !tbaa !29
  %t453 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextDepth(ptr %v0, ptr %t451)
  store i64 %t453, ptr %l259
  br label %bb111
bb110:
  br label %bb115
bb111:
  %t454 = load ptr, ptr %l254, !tbaa !29
  %t455 = load i64, ptr %l259, !tbaa !24
  %t456 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextBase(ptr %v0, ptr %t454, i64 %t455)
  store i64 %t456, ptr %l260
  br label %bb112
bb112:
  %t457 = load i64, ptr %l260, !tbaa !24
  store i64 %t457, ptr %l18, !tbaa !24
  %t458 = load ptr, ptr %l0, !tbaa !29
  store ptr %t458, ptr %l261, !tbaa !29
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load i64, ptr %l1, !tbaa !24
  %t463 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %t459, i64 %t460)
  store i64 %t463, ptr %l264
  br label %bb113
bb113:
  %t464 = load ptr, ptr %l261, !tbaa !29
  %t465 = load i64, ptr %l264, !tbaa !24
  %t466 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstContexts(ptr %v0, ptr %t464, i64 %t465)
  store i64 %t466, ptr %l265
  br label %bb114
bb114:
  %t467 = load i64, ptr %l265, !tbaa !24
  store i64 %t467, ptr %l17, !tbaa !24
  br label %bb115
bb115:
  %t468 = load ptr, ptr %l0, !tbaa !29
  store ptr %t468, ptr %l266, !tbaa !29
  %t469 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t469, ptr %l267
  br label %bb116
bb116:
  %t470 = load %"compiler/source:Span", ptr %l267
  %t471 = load ptr, ptr %l266, !tbaa !29
  %t472 = getelementptr %"compiler/scope:Scoper", ptr %t471, i32 0, i32 28
  store %"compiler/source:Span" %t470, ptr %t472
  %t473 = load ptr, ptr %l0, !tbaa !29
  store ptr %t473, ptr %l268, !tbaa !29
  %t474 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t474, ptr %l269
  br label %bb117
bb117:
  %t475 = load %"compiler/source:Span", ptr %l269
  %t476 = load ptr, ptr %l268, !tbaa !29
  %t477 = getelementptr %"compiler/scope:Scoper", ptr %t476, i32 0, i32 29
  store %"compiler/source:Span" %t475, ptr %t477
  %t478 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erun(ptr %v0, ptr %t478)
  br label %bb118
bb118:
  %t480 = load i1, ptr %l2, !tbaa !21
  br i1 %t480, label %bb119, label %bb120
bb119:
  %t482 = load i1, ptr %l7, !tbaa !21
  store i1 %t482, ptr %l272, !tbaa !21
  br label %bb121
bb120:
  store i1 false, ptr %l272, !tbaa !21
  br label %bb121
bb121:
  %t484 = load i1, ptr %l272, !tbaa !21
  br i1 %t484, label %bb122, label %bb123
bb122:
  %t485 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estrReceiver(ptr %v0, ptr %t485)
  br label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb125
bb125:
  %t487 = load i1, ptr %l2, !tbaa !21
  br i1 %t487, label %bb126, label %bb127
bb126:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/scope:Scoper", ptr %t489, i32 0, i32 28
  %t492 = getelementptr %"compiler/source:Span", ptr %t491, i32 0, i32 0
  %t493 = load i32, ptr %t492, !tbaa !23
  %t495 = icmp sge i32 %t493, 0
  store i1 %t495, ptr %l276, !tbaa !21
  br label %bb128
bb127:
  store i1 false, ptr %l276, !tbaa !21
  br label %bb128
bb128:
  %t497 = load i1, ptr %l276, !tbaa !21
  br i1 %t497, label %bb129, label %bb130
bb129:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = getelementptr %"compiler/scope:Scoper", ptr %t498, i32 0, i32 29
  %t501 = getelementptr %"compiler/source:Span", ptr %t500, i32 0, i32 0
  %t502 = load i32, ptr %t501, !tbaa !23
  %t504 = icmp sge i32 %t502, 0
  store i1 %t504, ptr %l280, !tbaa !21
  br label %bb131
bb130:
  store i1 false, ptr %l280, !tbaa !21
  br label %bb131
bb131:
  %t506 = load i1, ptr %l280, !tbaa !21
  br i1 %t506, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s16
  %t507 = load ptr, ptr %l0, !tbaa !29
  store ptr %t507, ptr %l284, !tbaa !29
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t510 = getelementptr %"compiler/scope:Scoper", ptr %t508, i32 0, i32 28
  %t511 = load %"compiler/source:Span", ptr %t510
  store %"compiler/source:Span" %t511, ptr %l286
  %t512 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeDestructor(ptr %s16, ptr %s16, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t512, ptr %l287
  br label %bb134
bb133:
  br label %bb138
bb134:
  %t513 = load ptr, ptr %l284, !tbaa !29
  %t514 = load %"compiler/source:Span", ptr %l286
  %t515 = load %"compiler/msgs:Msg", ptr %l287
  %t516 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s16, ptr %t513, %"compiler/source:Span" %t514, %"compiler/msgs:Msg" %t515)
  store i64 %t516, ptr %l288
  br label %bb135
bb135:
  %t517 = load i64, ptr %l288, !tbaa !24
  %t518 = load ptr, ptr %l0, !tbaa !29
  store ptr %t518, ptr %l289, !tbaa !29
  store i64 %t517, ptr %l290, !tbaa !24
  %t520 = load ptr, ptr %l3, !tbaa !29
  %t522 = getelementptr %"compiler/typed:Body", ptr %t520, i32 0, i32 3
  %t523 = load i64, ptr %t522, !tbaa !24
  store i64 %t523, ptr %l292, !tbaa !24
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t526 = getelementptr %"compiler/scope:Scoper", ptr %t524, i32 0, i32 29
  %t527 = load %"compiler/source:Span", ptr %t526
  store %"compiler/source:Span" %t527, ptr %l294
  %t528 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s16)
  store %"compiler/msgs:Msg" %t528, ptr %l295
  br label %bb136
bb136:
  %t529 = load ptr, ptr %l289, !tbaa !29
  %t530 = load i64, ptr %l290, !tbaa !24
  %t531 = load i64, ptr %l292, !tbaa !24
  %t532 = load %"compiler/source:Span", ptr %l294
  %t533 = load %"compiler/msgs:Msg", ptr %l295
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s16, ptr %t529, i64 %t530, i64 %t531, %"compiler/source:Span" %t532, %"compiler/msgs:Msg" %t533)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s16)
  br label %bb138
bb138:
  %t534 = load i1, ptr %l2, !tbaa !21
  br i1 %t534, label %bb139, label %bb140
bb139:
  store i64 0, ptr %l20, !tbaa !24
  %t536 = load i64, ptr %l17, !tbaa !24
  store i64 %t536, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t538 = load i64, ptr %l21, !tbaa !24
  %t539 = load i64, ptr %l20, !tbaa !24
  %t542 = icmp sgt i64 %t538, %t539
  br i1 %t542, label %bb141, label %bb142
bb140:
  br label %bb155
bb141:
  %t544 = load i64, ptr %l22, !tbaa !24
  %t546 = icmp sgt i64 %t544, 0
  br i1 %t546, label %bb143, label %bb144
bb142:
  store i64 0, ptr %l301, !tbaa !24
  br label %bb146
bb143:
  %t548 = load i64, ptr %l21, !tbaa !24
  %t549 = load i64, ptr %l20, !tbaa !24
  %t552 = sub i64 %t548, %t549
  %t553 = load i64, ptr %l22, !tbaa !24
  %t556 = add i64 %t552, %t553
  %t558 = sub i64 %t556, 1
  %t559 = load i64, ptr %l22, !tbaa !24
  %t562 = sdiv i64 %t558, %t559
  store i64 %t562, ptr %l304, !tbaa !24
  br label %bb145
bb144:
  store i64 0, ptr %l304, !tbaa !24
  br label %bb145
bb145:
  %t564 = load i64, ptr %l304, !tbaa !24
  store i64 %t564, ptr %l301, !tbaa !24
  br label %bb146
bb146:
  %t565 = load i64, ptr %l301, !tbaa !24
  store i64 %t565, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb147
bb147:
  %t566 = load i64, ptr %l24, !tbaa !24
  %t567 = load i64, ptr %l23, !tbaa !24
  %t570 = icmp slt i64 %t566, %t567
  %t572 = xor i1 %t570, true
  br i1 %t572, label %bb148, label %bb149
bb148:
  br label %bb153
bb149:
  br label %bb150
bb150:
  %t574 = load i64, ptr %l20, !tbaa !24
  %t575 = load i64, ptr %l24, !tbaa !24
  %t576 = load i64, ptr %l22, !tbaa !24
  %t579 = mul i64 %t575, %t576
  %t582 = add i64 %t574, %t579
  store i64 %t582, ptr %l25, !tbaa !24
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t586 = getelementptr %"compiler/scope:Scoper", ptr %t584, i32 0, i32 0
  %t587 = load ptr, ptr %t586, !tbaa !29
  %t589 = getelementptr %"compiler/generic:Program", ptr %t587, i32 0, i32 0
  %t590 = load ptr, ptr %t589, !tbaa !29
  %t592 = getelementptr %"compiler/load:Loader", ptr %t590, i32 0, i32 4
  %t593 = load ptr, ptr %t592, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %t593)
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t595 = load i64, ptr %l24, !tbaa !24
  %t597 = add i64 %t595, 1
  store i64 %t597, ptr %l24, !tbaa !24
  br label %bb147
bb153:
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t601 = getelementptr %"compiler/scope:Scoper", ptr %t599, i32 0, i32 0
  %t602 = load ptr, ptr %t601, !tbaa !29
  %t604 = getelementptr %"compiler/generic:Program", ptr %t602, i32 0, i32 0
  %t605 = load ptr, ptr %t604, !tbaa !29
  %t607 = getelementptr %"compiler/load:Loader", ptr %t605, i32 0, i32 4
  %t608 = load ptr, ptr %t607, !tbaa !29
  %t609 = load i64, ptr %l18, !tbaa !24
  %t612 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextBase(ptr %v0, ptr %t608, i64 %t609)
  store i64 %t612, ptr %l333
  br label %bb154
bb154:
  br label %bb155
bb155:
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t615 = getelementptr %"compiler/scope:Scoper", ptr %t613, i32 0, i32 35
  store ptr %t615, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb156
bb156:
  %t617 = load i64, ptr %l27, !tbaa !24
  store i64 %t617, ptr %l336, !tbaa !24
  %t618 = load ptr, ptr %l26, !tbaa !29
  %t620 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t618)
  store i64 %t620, ptr %l338
  br label %bb157
bb157:
  %t621 = load i64, ptr %l336, !tbaa !24
  %t622 = load i64, ptr %l338, !tbaa !24
  %t623 = icmp slt i64 %t621, %t622
  %t625 = xor i1 %t623, true
  br i1 %t625, label %bb158, label %bb159
bb158:
  br label %bb170
bb159:
  br label %bb160
bb160:
  %t627 = load ptr, ptr %l26, !tbaa !29
  %t628 = load i64, ptr %l27, !tbaa !24
  %t631 = call %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t627, i64 %t628)
  store %"compiler/scope:rel" %t631, ptr %l343
  br label %bb161
bb161:
  %t632 = load %"compiler/scope:rel", ptr %l343
  store %"compiler/scope:rel" %t632, ptr %l28
  %t633 = load ptr, ptr %l0, !tbaa !29
  %t635 = getelementptr %"compiler/scope:Scoper", ptr %t633, i32 0, i32 6
  %t636 = load i64, ptr %l1, !tbaa !24
  %t639 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t635, i64 %t636)
  store ptr %t639, ptr %l347
  br label %bb162
bb162:
  %t640 = load ptr, ptr %l347, !tbaa !29
  %t642 = getelementptr %"compiler/scope:summary", ptr %t640, i32 0, i32 0
  %t643 = load %"compiler/scope:rel", ptr %l28
  %t646 = call i1 @compiler_2fscope_2ehasRel(ptr %v0, ptr %t642, %"compiler/scope:rel" %t643)
  store i1 %t646, ptr %l351
  br label %bb163
bb163:
  %t647 = load i1, ptr %l351, !tbaa !21
  %t648 = xor i1 %t647, true
  br i1 %t648, label %bb164, label %bb165
bb164:
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t652 = getelementptr %"compiler/scope:Scoper", ptr %t650, i32 0, i32 6
  %t653 = load i64, ptr %l1, !tbaa !24
  %t656 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t652, i64 %t653)
  store ptr %t656, ptr %l356
  br label %bb166
bb165:
  br label %bb168
bb166:
  %t657 = load ptr, ptr %l356, !tbaa !29
  %t659 = getelementptr %"compiler/scope:summary", ptr %t657, i32 0, i32 0
  %t660 = load %"compiler/scope:rel", ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t659, %"compiler/scope:rel" %t660)
  br label %bb167
bb167:
  br label %bb168
bb168:
  br label %bb169
bb169:
  %t663 = load i64, ptr %l27, !tbaa !24
  %t665 = add i64 %t663, 1
  store i64 %t665, ptr %l27, !tbaa !24
  br label %bb156
bb170:
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t669 = getelementptr %"compiler/scope:Scoper", ptr %t667, i32 0, i32 6
  %t670 = load i64, ptr %l1, !tbaa !24
  %t673 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t669, i64 %t670)
  store ptr %t673, ptr %l365
  br label %bb171
bb171:
  %t674 = load ptr, ptr %l365, !tbaa !29
  store ptr %t674, ptr %l29, !tbaa !29
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t676 = load ptr, ptr %l29, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteFieldRecs(ptr %v0, ptr %v0, ptr %t675, ptr %t676)
  br label %bb172
bb172:
  %t679 = load ptr, ptr %l29, !tbaa !29
  %t681 = getelementptr %"compiler/scope:summary", ptr %t679, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t681)
  br label %bb173
bb173:
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t685 = getelementptr %"compiler/scope:Scoper", ptr %t683, i32 0, i32 56
  %t686 = load i1, ptr %t685, !tbaa !21
  br i1 %t686, label %bb174, label %bb175
bb174:
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t690 = getelementptr %"compiler/scope:Scoper", ptr %t688, i32 0, i32 55
  store ptr %t690, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb176
bb175:
  br label %bb185
bb176:
  %t692 = load i64, ptr %l31, !tbaa !24
  store i64 %t692, ptr %l374, !tbaa !24
  %t693 = load ptr, ptr %l30, !tbaa !29
  %t695 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t693)
  store i64 %t695, ptr %l376
  br label %bb177
bb177:
  %t696 = load i64, ptr %l374, !tbaa !24
  %t697 = load i64, ptr %l376, !tbaa !24
  %t698 = icmp slt i64 %t696, %t697
  %t700 = xor i1 %t698, true
  br i1 %t700, label %bb178, label %bb179
bb178:
  br label %bb184
bb179:
  br label %bb180
bb180:
  %t702 = load ptr, ptr %l30, !tbaa !29
  %t703 = load i64, ptr %l31, !tbaa !24
  %t706 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t702, i64 %t703)
  store { i64, [2 x i64] } %t706, ptr %l381
  br label %bb181
bb181:
  %t707 = load { i64, [2 x i64] }, ptr %l381
  %t708 = load ptr, ptr %l29, !tbaa !29
  %t710 = getelementptr %"compiler/scope:summary", ptr %t708, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t710, { i64, [2 x i64] } %t707)
  br label %bb182
bb182:
  br label %bb183
bb183:
  %t714 = load i64, ptr %l31, !tbaa !24
  %t716 = add i64 %t714, 1
  store i64 %t716, ptr %l31, !tbaa !24
  br label %bb176
bb184:
  br label %bb185
bb185:
  %t718 = load ptr, ptr %l29, !tbaa !29
  %t720 = getelementptr %"compiler/scope:summary", ptr %t718, i32 0, i32 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t720)
  br label %bb186
bb186:
  %t722 = load ptr, ptr %l29, !tbaa !29
  %t724 = getelementptr %"compiler/scope:summary", ptr %t722, i32 0, i32 2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t724)
  br label %bb187
bb187:
  %t726 = load ptr, ptr %l29, !tbaa !29
  %t728 = getelementptr %"compiler/scope:summary", ptr %t726, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t728)
  br label %bb188
bb188:
  %t730 = load ptr, ptr %l29, !tbaa !29
  %t732 = getelementptr %"compiler/scope:summary", ptr %t730, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t732)
  br label %bb189
bb189:
  store i64 0, ptr %l33, !tbaa !24
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t736 = getelementptr %"compiler/scope:Scoper", ptr %t734, i32 0, i32 58
  %t738 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t736)
  store i64 %t738, ptr %l397
  br label %bb190
bb190:
  %t739 = load i64, ptr %l397, !tbaa !24
  store i64 %t739, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t740 = load i64, ptr %l34, !tbaa !24
  %t741 = load i64, ptr %l33, !tbaa !24
  %t744 = icmp sgt i64 %t740, %t741
  br i1 %t744, label %bb191, label %bb192
bb191:
  %t746 = load i64, ptr %l35, !tbaa !24
  %t748 = icmp sgt i64 %t746, 0
  br i1 %t748, label %bb193, label %bb194
bb192:
  store i64 0, ptr %l401, !tbaa !24
  br label %bb196
bb193:
  %t750 = load i64, ptr %l34, !tbaa !24
  %t751 = load i64, ptr %l33, !tbaa !24
  %t754 = sub i64 %t750, %t751
  %t755 = load i64, ptr %l35, !tbaa !24
  %t758 = add i64 %t754, %t755
  %t760 = sub i64 %t758, 1
  %t761 = load i64, ptr %l35, !tbaa !24
  %t764 = sdiv i64 %t760, %t761
  store i64 %t764, ptr %l404, !tbaa !24
  br label %bb195
bb194:
  store i64 0, ptr %l404, !tbaa !24
  br label %bb195
bb195:
  %t766 = load i64, ptr %l404, !tbaa !24
  store i64 %t766, ptr %l401, !tbaa !24
  br label %bb196
bb196:
  %t767 = load i64, ptr %l401, !tbaa !24
  store i64 %t767, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb197
bb197:
  %t768 = load i64, ptr %l37, !tbaa !24
  %t769 = load i64, ptr %l36, !tbaa !24
  %t772 = icmp slt i64 %t768, %t769
  %t774 = xor i1 %t772, true
  br i1 %t774, label %bb198, label %bb199
bb198:
  br label %bb210
bb199:
  br label %bb200
bb200:
  %t776 = load i64, ptr %l33, !tbaa !24
  %t777 = load i64, ptr %l37, !tbaa !24
  %t778 = load i64, ptr %l35, !tbaa !24
  %t781 = mul i64 %t777, %t778
  %t784 = add i64 %t776, %t781
  store i64 %t784, ptr %l38, !tbaa !24
  %t786 = load ptr, ptr %l29, !tbaa !29
  %t788 = getelementptr %"compiler/scope:summary", ptr %t786, i32 0, i32 1
  store ptr %t788, ptr %l423, !tbaa !29
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t791 = getelementptr %"compiler/scope:Scoper", ptr %t789, i32 0, i32 58
  %t792 = load i64, ptr %l38, !tbaa !24
  %t795 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t791, i64 %t792)
  store i1 %t795, ptr %l427
  br label %bb201
bb201:
  %t796 = load ptr, ptr %l423, !tbaa !29
  %t797 = load i1, ptr %l427, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t796, i1 %t797)
  br label %bb202
bb202:
  %t798 = load ptr, ptr %l29, !tbaa !29
  %t800 = getelementptr %"compiler/scope:summary", ptr %t798, i32 0, i32 2
  store ptr %t800, ptr %l429, !tbaa !29
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t803 = getelementptr %"compiler/scope:Scoper", ptr %t801, i32 0, i32 59
  %t804 = load i64, ptr %l38, !tbaa !24
  %t807 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t803, i64 %t804)
  store i1 %t807, ptr %l433
  br label %bb203
bb203:
  %t808 = load ptr, ptr %l429, !tbaa !29
  %t809 = load i1, ptr %l433, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t808, i1 %t809)
  br label %bb204
bb204:
  %t810 = load ptr, ptr %l29, !tbaa !29
  %t812 = getelementptr %"compiler/scope:summary", ptr %t810, i32 0, i32 3
  store ptr %t812, ptr %l435, !tbaa !29
  %t813 = load ptr, ptr %l0, !tbaa !29
  %t815 = getelementptr %"compiler/scope:Scoper", ptr %t813, i32 0, i32 62
  %t816 = load i64, ptr %l38, !tbaa !24
  %t819 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t815, i64 %t816)
  store i64 %t819, ptr %l439
  br label %bb205
bb205:
  %t820 = load ptr, ptr %l435, !tbaa !29
  %t821 = load i64, ptr %l439, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t820, i64 %t821)
  br label %bb206
bb206:
  %t822 = load ptr, ptr %l29, !tbaa !29
  %t824 = getelementptr %"compiler/scope:summary", ptr %t822, i32 0, i32 4
  store ptr %t824, ptr %l441, !tbaa !29
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t827 = getelementptr %"compiler/scope:Scoper", ptr %t825, i32 0, i32 63
  %t828 = load i64, ptr %l38, !tbaa !24
  %t831 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t827, i64 %t828)
  store %"compiler/source:Span" %t831, ptr %l445
  br label %bb207
bb207:
  %t832 = load ptr, ptr %l441, !tbaa !29
  %t833 = load %"compiler/source:Span", ptr %l445
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t832, %"compiler/source:Span" %t833)
  br label %bb208
bb208:
  br label %bb209
bb209:
  %t834 = load i64, ptr %l37, !tbaa !24
  %t836 = add i64 %t834, 1
  store i64 %t836, ptr %l37, !tbaa !24
  br label %bb197
bb210:
  %t838 = load ptr, ptr %l0, !tbaa !29
  %t839 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecomputeKeeps(ptr %v0, ptr %v0, ptr %t838, ptr %t839)
  br label %bb211
bb211:
  store i64 0, ptr %l39, !tbaa !24
  %t842 = load ptr, ptr %l0, !tbaa !29
  %t844 = getelementptr %"compiler/scope:Scoper", ptr %t842, i32 0, i32 58
  %t846 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t844)
  store i64 %t846, ptr %l452
  br label %bb212
bb212:
  %t847 = load i64, ptr %l452, !tbaa !24
  store i64 %t847, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t848 = load i64, ptr %l40, !tbaa !24
  %t849 = load i64, ptr %l39, !tbaa !24
  %t852 = icmp sgt i64 %t848, %t849
  br i1 %t852, label %bb213, label %bb214
bb213:
  %t854 = load i64, ptr %l41, !tbaa !24
  %t856 = icmp sgt i64 %t854, 0
  br i1 %t856, label %bb215, label %bb216
bb214:
  store i64 0, ptr %l456, !tbaa !24
  br label %bb218
bb215:
  %t858 = load i64, ptr %l40, !tbaa !24
  %t859 = load i64, ptr %l39, !tbaa !24
  %t862 = sub i64 %t858, %t859
  %t863 = load i64, ptr %l41, !tbaa !24
  %t866 = add i64 %t862, %t863
  %t868 = sub i64 %t866, 1
  %t869 = load i64, ptr %l41, !tbaa !24
  %t872 = sdiv i64 %t868, %t869
  store i64 %t872, ptr %l459, !tbaa !24
  br label %bb217
bb216:
  store i64 0, ptr %l459, !tbaa !24
  br label %bb217
bb217:
  %t874 = load i64, ptr %l459, !tbaa !24
  store i64 %t874, ptr %l456, !tbaa !24
  br label %bb218
bb218:
  %t875 = load i64, ptr %l456, !tbaa !24
  store i64 %t875, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb219
bb219:
  %t876 = load i64, ptr %l43, !tbaa !24
  %t877 = load i64, ptr %l42, !tbaa !24
  %t880 = icmp slt i64 %t876, %t877
  %t882 = xor i1 %t880, true
  br i1 %t882, label %bb220, label %bb221
bb220:
  br label %bb228
bb221:
  br label %bb222
bb222:
  %t884 = load i64, ptr %l39, !tbaa !24
  %t885 = load i64, ptr %l43, !tbaa !24
  %t886 = load i64, ptr %l41, !tbaa !24
  %t889 = mul i64 %t885, %t886
  %t892 = add i64 %t884, %t889
  store i64 %t892, ptr %l44, !tbaa !24
  %t894 = load i64, ptr %l44, !tbaa !24
  %t895 = load ptr, ptr %l0, !tbaa !29
  %t897 = getelementptr %"compiler/scope:Scoper", ptr %t895, i32 0, i32 30
  %t898 = getelementptr %"compiler/typed:Plan", ptr %t897, i32 0, i32 2
  %t899 = load { i64, ptr }, ptr %t898, !tbaa !27
  %t901 = extractvalue { i64, ptr } %t899, 0
  %t904 = icmp slt i64 %t894, %t901
  br i1 %t904, label %bb223, label %bb224
bb223:
  %t906 = load ptr, ptr %l0, !tbaa !29
  %t908 = getelementptr %"compiler/scope:Scoper", ptr %t906, i32 0, i32 30
  %t909 = getelementptr %"compiler/typed:Plan", ptr %t908, i32 0, i32 2
  %t910 = load { i64, ptr }, ptr %t909, !tbaa !27
  store { i64, ptr } %t910, ptr %l483, !tbaa !27
  %t911 = load i64, ptr %l44, !tbaa !24
  store i64 %t911, ptr %l484, !tbaa !24
  %t912 = load ptr, ptr %l0, !tbaa !29
  %t914 = getelementptr %"compiler/scope:Scoper", ptr %t912, i32 0, i32 58
  %t915 = load i64, ptr %l44, !tbaa !24
  %t918 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t914, i64 %t915)
  store i1 %t918, ptr %l488
  br label %bb225
bb224:
  br label %bb226
bb225:
  %t919 = load i1, ptr %l488, !tbaa !21
  %t920 = load i64, ptr %l484, !tbaa !24
  %t921 = getelementptr { i64, ptr }, ptr %l483, i32 0, i32 1
  %t922 = load ptr, ptr %t921, !tbaa !27
  %t923 = getelementptr i1, ptr %t922, i64 %t920
  store i1 %t919, ptr %t923, !tbaa !31
  br label %bb226
bb226:
  br label %bb227
bb227:
  %t924 = load i64, ptr %l43, !tbaa !24
  %t926 = add i64 %t924, 1
  store i64 %t926, ptr %l43, !tbaa !24
  br label %bb219
bb228:
  %t928 = load i1, ptr %l2, !tbaa !21
  br i1 %t928, label %bb229, label %bb230
bb229:
  %t930 = load ptr, ptr %l0, !tbaa !29
  %t932 = getelementptr %"compiler/scope:Scoper", ptr %t930, i32 0, i32 2
  %t933 = load i64, ptr %l1, !tbaa !24
  %t934 = load ptr, ptr %l0, !tbaa !29
  %t936 = getelementptr %"compiler/scope:Scoper", ptr %t934, i32 0, i32 30
  call void @llvm.memmove.p0.p0.i64(ptr %l496, ptr %t936, i64 152, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t939, ptr %l496, i64 152, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eSetAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t932, i64 %t933, ptr %t939)
  br label %bb231
bb230:
  br label %bb232
bb231:
  br label %bb232
bb232:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l63 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb9
bb6:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l22, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l22, !tbaa !24
  store i64 %t38, ptr %l19, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l19, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb11, label %bb12
bb11:
  br label %bb35
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Block", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l41, !tbaa !27
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  store ptr %t67, ptr %l8, !tbaa !29
  %t69 = load ptr, ptr %l8, !tbaa !29
  store ptr %t69, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t70 = load ptr, ptr %l44, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l44, !tbaa !29
  %t74 = load i64, ptr %t73
  %t76 = icmp eq i64 %t74, 0
  store i1 %t76, ptr %l45, !tbaa !21
  br label %bb15
bb15:
  %t77 = load i1, ptr %l45, !tbaa !21
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t78 = load ptr, ptr %l8, !tbaa !29
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t80, i32 0, i32 1
  %t82 = load i32, ptr %t81
  store i32 %t82, ptr %l9, !tbaa !23
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l10, !tbaa !29
  br label %bb18
bb17:
  br label %bb27
bb18:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l10, !tbaa !29
  %t94 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %t90, ptr %t91)
  store i1 %t94, ptr %l54
  br label %bb19
bb19:
  %t95 = load i1, ptr %l54, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Block", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t101 = load i64, ptr %l7, !tbaa !24
  %t103 = add i64 %t101, 1
  %t104 = load i32, ptr %l9, !tbaa !23
  %t106 = sext i32 %t104 to i64
  %t111 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonlyCalled(ptr %v0, ptr %v1, ptr %t96, { i64, ptr } %t100, i64 %t103, i64 %t106)
  store i1 %t111, ptr %l63
  br label %bb22
bb21:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb23
bb22:
  %t112 = load i1, ptr %l63, !tbaa !21
  store i1 %t112, ptr %l55, !tbaa !21
  br label %bb23
bb23:
  %t113 = load i1, ptr %l55, !tbaa !21
  br i1 %t113, label %bb24, label %bb25
bb24:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %t114, i32 0, i32 117
  store i1 true, ptr %t116, !tbaa !21
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_fc6a508fadcedae3_fc22fb2e32e5f087)
  unreachable
bb32:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwStmt(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  br label %bb33
bb33:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/scope:Scoper", ptr %t122, i32 0, i32 117
  store i1 false, ptr %t124, !tbaa !21
  br label %bb34
bb34:
  %t125 = load i64, ptr %l6, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l6, !tbaa !24
  br label %bb10
bb35:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca ptr
  %l31 = alloca i32
  %l35 = alloca i64
  %l38 = alloca i1
  %l41 = alloca i1
  %l48 = alloca i64
  %l54 = alloca i64
  %l62 = alloca { i64, ptr }
  %l64 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l100 = alloca i64
  %l103 = alloca i64
  %l111 = alloca i64
  %l114 = alloca i64
  %l136 = alloca i1
  %l140 = alloca i64
  %l143 = alloca { i64, ptr }
  %l147 = alloca { i64, [2 x i64] }
  %l156 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t12 = alloca { i64, [2 x i64] }, align 8
  %t44 = alloca { i64, [2 x i64] }, align 8
  %t63 = alloca { i64, [2 x i64] }, align 8
  %t77 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l25
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l25, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [2 x i64] }, ptr %t12, i32 0, i32 0
  store i64 0, ptr %t13
  %t14 = load { i64, [2 x i64] }, ptr %t12
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t14, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i32 %t20, ptr %l31
  br label %bb5
bb5:
  %t21 = load i32, ptr %l31, !tbaa !23
  store i32 %t21, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Call", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t29 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %t22, ptr %t26)
  store i64 %t29, ptr %l35
  br label %bb6
bb6:
  %t30 = load i64, ptr %l35, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp slt i64 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb10
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %t35, i64 %t36)
  store i1 %t39, ptr %l41
  br label %bb9
bb9:
  %t40 = load i1, ptr %l41, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l38, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l38, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  store { i64, [2 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [2 x i64] }, ptr %t44, i32 0, i32 0
  store i64 0, ptr %t45
  %t46 = load { i64, [2 x i64] }, ptr %t44
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t46, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/scope:Scoper", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l3, !tbaa !23
  %t57 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t53, i32 %t54)
  store i64 %t57, ptr %l48
  br label %bb14
bb14:
  %t58 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t59 = load i64, ptr %l48, !tbaa !24
  %t61 = icmp eq i64 %t59, %t58
  br i1 %t61, label %bb15, label %bb16
bb15:
  store { i64, [2 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [2 x i64] }, ptr %t63, i32 0, i32 0
  store i64 0, ptr %t64
  %t65 = load { i64, [2 x i64] }, ptr %t63
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t65, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l54
  br label %bb18
bb18:
  %t72 = load i64, ptr %l54, !tbaa !24
  store i64 %t72, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  br i1 %t75, label %bb19, label %bb20
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [2 x i64] }, ptr %t77, i32 0, i32 0
  store i64 0, ptr %t78
  %t79 = load { i64, [2 x i64] }, ptr %t77
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t79, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t86, i32 %t87)
  store { i64, ptr } %t90, ptr %l62
  br label %bb22
bb22:
  %t91 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t91, ptr %l6, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l64, !tbaa !24
  %t95 = load i64, ptr %l64, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  br i1 %t96, label %bb23, label %bb24
bb23:
  %t98 = load i64, ptr %l64, !tbaa !24
  %t99 = icmp sle i64 %t98, 384307168202282325
  br i1 %t99, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ec2dd22d28cc6988_9d0975400b204864)
  unreachable
bb25:
  %t101 = load i64, ptr %l64, !tbaa !24
  %t102 = mul i64 %t101, 24
  %t103 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t102)
  %t104 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Call", ptr %t107, i32 0, i32 1
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  store i64 %t112, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ec2dd22d28cc6988_9d0975400b204864)
  unreachable
bb27:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb32
bb29:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load i64, ptr %l8, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l10, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l10, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l77, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb31
bb31:
  %t140 = load i64, ptr %l77, !tbaa !24
  store i64 %t140, ptr %l74, !tbaa !24
  br label %bb32
bb32:
  %t141 = load i64, ptr %l74, !tbaa !24
  store i64 %t141, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb33
bb33:
  %t142 = load i64, ptr %l12, !tbaa !24
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb34, label %bb35
bb34:
  br label %bb61
bb35:
  br label %bb36
bb36:
  %t150 = load i64, ptr %l8, !tbaa !24
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l10, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l13, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/scope:Scoper", ptr %t160, i32 0, i32 0
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/generic:Program", ptr %t163, i32 0, i32 2
  %t166 = load i32, ptr %l3, !tbaa !23
  %t167 = load i64, ptr %l13, !tbaa !24
  %t171 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t165, i32 %t166, i64 %t167)
  store i64 %t171, ptr %l100
  br label %bb37
bb37:
  %t172 = load i64, ptr %l100, !tbaa !24
  store i64 %t172, ptr %l14, !tbaa !24
  %t173 = load i64, ptr %l14, !tbaa !24
  %t175 = icmp sge i64 %t173, 0
  br i1 %t175, label %bb38, label %bb39
bb38:
  %t177 = load i64, ptr %l14, !tbaa !24
  store i64 %t177, ptr %l103, !tbaa !24
  br label %bb40
bb39:
  %t179 = load i64, ptr %l13, !tbaa !24
  store i64 %t179, ptr %l103, !tbaa !24
  br label %bb40
bb40:
  %t181 = load i64, ptr %l103, !tbaa !24
  store i64 %t181, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  store i64 %t184, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t186 = load i64, ptr %l17, !tbaa !24
  %t187 = load i64, ptr %l16, !tbaa !24
  %t190 = icmp sgt i64 %t186, %t187
  br i1 %t190, label %bb41, label %bb42
bb41:
  %t192 = load i64, ptr %l18, !tbaa !24
  %t194 = icmp sgt i64 %t192, 0
  br i1 %t194, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb46
bb43:
  %t196 = load i64, ptr %l17, !tbaa !24
  %t197 = load i64, ptr %l16, !tbaa !24
  %t200 = sub i64 %t196, %t197
  %t201 = load i64, ptr %l18, !tbaa !24
  %t204 = add i64 %t200, %t201
  %t206 = sub i64 %t204, 1
  %t207 = load i64, ptr %l18, !tbaa !24
  %t210 = sdiv i64 %t206, %t207
  store i64 %t210, ptr %l114, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb45
bb45:
  %t212 = load i64, ptr %l114, !tbaa !24
  store i64 %t212, ptr %l111, !tbaa !24
  br label %bb46
bb46:
  %t213 = load i64, ptr %l111, !tbaa !24
  store i64 %t213, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb47
bb47:
  %t214 = load i64, ptr %l20, !tbaa !24
  %t215 = load i64, ptr %l19, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb48, label %bb49
bb48:
  br label %bb59
bb49:
  br label %bb50
bb50:
  %t222 = load i64, ptr %l16, !tbaa !24
  %t223 = load i64, ptr %l20, !tbaa !24
  %t224 = load i64, ptr %l18, !tbaa !24
  %t227 = mul i64 %t223, %t224
  %t230 = add i64 %t222, %t227
  store i64 %t230, ptr %l21, !tbaa !24
  %t232 = load i64, ptr %l21, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr i64, ptr %t235, i64 %t232
  %t237 = load i64, ptr %t236, !tbaa !34
  %t238 = load i64, ptr %l15, !tbaa !24
  %t241 = icmp eq i64 %t237, %t238
  br i1 %t241, label %bb51, label %bb52
bb51:
  %t243 = load i64, ptr %l21, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr { i64, [2 x i64] }, ptr %t246, i64 %t243
  %t248 = load { i64, [2 x i64] }, ptr %t247
  %t250 = extractvalue { i64, [2 x i64] } %t248, 0
  %t251 = icmp eq i64 %t250, 0
  store i1 %t251, ptr %l136, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb53
bb53:
  %t253 = load i1, ptr %l136, !tbaa !21
  br i1 %t253, label %bb54, label %bb55
bb54:
  %t254 = load i64, ptr %l21, !tbaa !24
  store i64 %t254, ptr %l140, !tbaa !24
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load ptr, ptr %l2, !tbaa !29
  %t258 = getelementptr %"compiler/typed:Call", ptr %t256, i32 0, i32 1
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  store { i64, ptr } %t259, ptr %l143, !tbaa !27
  %t260 = load i64, ptr %l13, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr ptr, ptr %t263, i64 %t260
  %t265 = load ptr, ptr %t264, !tbaa !39
  %t269 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %t255, ptr %t265)
  store { i64, [2 x i64] } %t269, ptr %l147
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t270 = load { i64, [2 x i64] }, ptr %l147
  %t271 = load i64, ptr %l140, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr { i64, [2 x i64] }, ptr %t273, i64 %t271
  store { i64, [2 x i64] } %t270, ptr %t274
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t275 = load i64, ptr %l20, !tbaa !24
  %t277 = add i64 %t275, 1
  store i64 %t277, ptr %l20, !tbaa !24
  br label %bb47
bb59:
  br label %bb60
bb60:
  %t279 = load i64, ptr %l12, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l12, !tbaa !24
  br label %bb33
bb61:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load ptr, ptr %l2, !tbaa !29
  %t285 = load i64, ptr %l5, !tbaa !24
  %t286 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t291 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandByObligations(ptr %v0, ptr %v1, ptr %s0, ptr %t283, ptr %t284, i64 %t285, { i64, ptr } %t286)
  store { i64, [2 x i64] } %t291, ptr %l156
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  %t292 = load { i64, [2 x i64] }, ptr %l156
  store { i64, [2 x i64] } %t292, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca i1
  %l53 = alloca %"compiler/source:Span"
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 25
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d50f79fefbee4394_12c4367532f3ae80)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l18
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l17
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l7, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  store i64 %t31, ptr %l3, !tbaa !24
  %t33 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t34 = load i32, ptr %t33, !tbaa !23
  %t36 = sext i32 %t34 to i64
  store i64 %t36, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = icmp sgt i64 %t38, %t41
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t46, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l5
  br label %bb11
bb11:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  br label %bb31
bb13:
  br label %bb14
bb14:
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t58, ptr %l33, !tbaa !27
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = call i1 @compiler_2fscope_2eisNameChar(i8 %t64)
  store i1 %t66, ptr %l36
  br label %bb15
bb15:
  %t67 = load i1, ptr %l36, !tbaa !21
  br i1 %t67, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l3, !tbaa !24
  store i64 %t68, ptr %l6, !tbaa !24
  br label %bb18
bb17:
  br label %bb29
bb18:
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t76, ptr %l42, !tbaa !27
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 %t77
  %t82 = load i8, ptr %t81, !tbaa !32
  %t84 = call i1 @compiler_2fscope_2eisNameChar(i8 %t82)
  store i1 %t84, ptr %l45
  br label %bb21
bb20:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb21:
  %t85 = load i1, ptr %l45, !tbaa !21
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l41, !tbaa !21
  %t87 = xor i1 %t86, true
  br i1 %t87, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t89 = load i64, ptr %l3, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l3, !tbaa !24
  br label %bb26
bb26:
  br label %bb18
bb27:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = trunc i64 %t93 to i32
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = trunc i64 %t96 to i32
  %t101 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t95, i32 %t98)
  store %"compiler/source:Span" %t101, ptr %l53
  br label %bb28
bb28:
  %t102 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t102, ptr %l5
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb29:
  %t103 = load i64, ptr %l3, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l3, !tbaa !24
  br label %bb30
bb30:
  br label %bb11
bb31:
  %t107 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t107, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastsUntil(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l47 = alloca ptr
  %l51 = alloca { i64, [2 x i64] }
  %l53 = alloca i1
  %l64 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, [2 x i64] }, ptr %l1
  %t9 = extractvalue { i64, [2 x i64] } %t7, 0
  %t10 = icmp eq i64 %t9, 5
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t13 = getelementptr { i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb6
bb5:
  br label %bb26
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 36
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l19
  br label %bb7
bb7:
  %t23 = load i64, ptr %l19, !tbaa !24
  store i64 %t23, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t28, ptr %l22
  br label %bb8
bb8:
  %t29 = load i64, ptr %l22, !tbaa !24
  store i64 %t29, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb14
bb11:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l29, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb13
bb13:
  %t56 = load i64, ptr %l29, !tbaa !24
  store i64 %t56, ptr %l26, !tbaa !24
  br label %bb14
bb14:
  %t57 = load i64, ptr %l26, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb16, label %bb17
bb16:
  br label %bb25
bb17:
  br label %bb18
bb18:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l47, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/scope:Scoper", ptr %t77, i32 0, i32 37
  %t83 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t79, i64 %t74)
  store { i64, [2 x i64] } %t83, ptr %l51
  br label %bb19
bb19:
  %t84 = load { i64, [2 x i64] }, ptr %l2
  %t85 = load ptr, ptr %l47, !tbaa !29
  %t86 = load { i64, [2 x i64] }, ptr %l51
  %t88 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastsUntil(ptr %v0, ptr %t85, { i64, [2 x i64] } %t86, { i64, [2 x i64] } %t84)
  store i1 %t88, ptr %l53
  br label %bb20
bb20:
  %t89 = load i1, ptr %l53, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t93 = load i64, ptr %l8, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l8, !tbaa !24
  br label %bb15
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  %t98 = load { i64, [2 x i64] }, ptr %l1
  %t100 = extractvalue { i64, [2 x i64] } %t98, 0
  %t101 = icmp eq i64 %t100, 1
  br i1 %t101, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, [2 x i64] }, ptr %l1
  %t105 = load { i64, [2 x i64] }, ptr %l2
  %t109 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t103, { i64, [2 x i64] } %t104, { i64, [2 x i64] } %t105)
  store i64 %t109, ptr %l64
  br label %bb30
bb30:
  %t110 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t111 = load i64, ptr %l64, !tbaa !24
  %t113 = icmp eq i64 %t111, %t110
  store i1 %t113, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 true, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_dd2a7e97808fa897_95cc897457ffa94b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l88 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l98 = alloca i1
  %l99 = alloca i1
  %l103 = alloca i1
  %l105 = alloca { i64, ptr }
  %l108 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l119 = alloca i1
  %l120 = alloca i1
  %l124 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i1
  %l134 = alloca i1
  %l135 = alloca i1
  %l140 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca i1
  %l149 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t7 = load ptr, ptr %l18, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l18, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 6
  store i1 %t13, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l19, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l2, !tbaa !23
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb14
bb8:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i1 @compiler_2ftyped_2eScopedCall(ptr %v1, ptr %t27)
  store i1 %t29, ptr %l27
  br label %bb9
bb9:
  %t30 = load i1, ptr %l27, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb13
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l32
  br label %bb12
bb12:
  %t38 = load i1, ptr %l32, !tbaa !21
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t41 = load i1, ptr %l29, !tbaa !21
  store i1 %t41, ptr %l17, !tbaa !21
  br label %bb110
bb14:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t43 = load ptr, ptr %l34, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l34, !tbaa !29
  %t47 = load i64, ptr %t46
  %t49 = icmp eq i64 %t47, 7
  store i1 %t49, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l35, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t52 = load ptr, ptr %l38, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t55 = load ptr, ptr %l38, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 8
  store i1 %t58, ptr %l39, !tbaa !21
  br label %bb20
bb20:
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb110
bb24:
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t61 = load ptr, ptr %l42, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb25, label %bb26
bb25:
  %t64 = load ptr, ptr %l42, !tbaa !29
  %t65 = load i64, ptr %t64
  %t67 = icmp eq i64 %t65, 5
  store i1 %t67, ptr %l43, !tbaa !21
  br label %bb26
bb26:
  %t68 = load i1, ptr %l43, !tbaa !21
  br i1 %t68, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t70 = load ptr, ptr %l46, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb29, label %bb30
bb29:
  %t73 = load ptr, ptr %l46, !tbaa !29
  %t74 = load i64, ptr %t73
  %t76 = icmp eq i64 %t74, 16
  store i1 %t76, ptr %l47, !tbaa !21
  br label %bb30
bb30:
  %t77 = load i1, ptr %l47, !tbaa !21
  br i1 %t77, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb110
bb34:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t79 = load ptr, ptr %l50, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb35, label %bb36
bb35:
  %t82 = load ptr, ptr %l50, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 0
  store i1 %t85, ptr %l51, !tbaa !21
  br label %bb36
bb36:
  %t86 = load i1, ptr %l51, !tbaa !21
  br i1 %t86, label %bb37, label %bb38
bb37:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l4, !tbaa !23
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l4, !tbaa !23
  %t97 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t93, i32 %t94)
  store i1 %t97, ptr %l58
  br label %bb40
bb40:
  %t98 = load i1, ptr %l58, !tbaa !21
  store i1 %t98, ptr %l17, !tbaa !21
  br label %bb110
bb41:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t100 = load ptr, ptr %l59, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb42, label %bb43
bb42:
  %t103 = load ptr, ptr %l59, !tbaa !29
  %t104 = load i64, ptr %t103
  %t106 = icmp eq i64 %t104, 14
  store i1 %t106, ptr %l60, !tbaa !21
  br label %bb43
bb43:
  %t107 = load i1, ptr %l60, !tbaa !21
  br i1 %t107, label %bb44, label %bb45
bb44:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l5, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Try", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t121 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t114, ptr %t118)
  store i1 %t121, ptr %l68
  br label %bb47
bb47:
  %t122 = load i1, ptr %l68, !tbaa !21
  store i1 %t122, ptr %l17, !tbaa !21
  br label %bb110
bb48:
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t124 = load ptr, ptr %l69, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb49, label %bb50
bb49:
  %t127 = load ptr, ptr %l69, !tbaa !29
  %t128 = load i64, ptr %t127
  %t130 = icmp eq i64 %t128, 17
  store i1 %t130, ptr %l70, !tbaa !21
  br label %bb50
bb50:
  %t131 = load i1, ptr %l70, !tbaa !21
  br i1 %t131, label %bb51, label %bb52
bb51:
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr { i64, [5 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t134, i32 0, i32 2
  %t136 = load ptr, ptr %t135
  store ptr %t136, ptr %l6, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l6, !tbaa !29
  %t143 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t138, ptr %t139)
  store i1 %t143, ptr %l78
  br label %bb54
bb54:
  %t144 = load i1, ptr %l78, !tbaa !21
  store i1 %t144, ptr %l17, !tbaa !21
  br label %bb110
bb55:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t146 = load ptr, ptr %l79, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb56, label %bb57
bb56:
  %t149 = load ptr, ptr %l79, !tbaa !29
  %t150 = load i64, ptr %t149
  %t152 = icmp eq i64 %t150, 12
  store i1 %t152, ptr %l80, !tbaa !21
  br label %bb57
bb57:
  %t153 = load i1, ptr %l80, !tbaa !21
  br i1 %t153, label %bb58, label %bb59
bb58:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l7, !tbaa !29
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l7, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Seq", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t167 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t160, ptr %t164)
  store i1 %t167, ptr %l88
  br label %bb61
bb61:
  %t168 = load i1, ptr %l88, !tbaa !21
  store i1 %t168, ptr %l17, !tbaa !21
  br label %bb110
bb62:
  %t169 = load ptr, ptr %l1, !tbaa !29
  store ptr %t169, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t170 = load ptr, ptr %l89, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb63, label %bb64
bb63:
  %t173 = load ptr, ptr %l89, !tbaa !29
  %t174 = load i64, ptr %t173
  %t176 = icmp eq i64 %t174, 9
  store i1 %t176, ptr %l90, !tbaa !21
  br label %bb64
bb64:
  %t177 = load i1, ptr %l90, !tbaa !21
  br i1 %t177, label %bb65, label %bb66
bb65:
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr { i64, [5 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t180, i32 0, i32 2
  %t182 = load i32, ptr %t181
  store i32 %t182, ptr %l8
  %t184 = load ptr, ptr %l1, !tbaa !29
  %t186 = getelementptr { i64, [5 x i64] }, ptr %t184, i32 0, i32 1
  %t187 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t186, i32 0, i32 4
  %t188 = load { i64, ptr }, ptr %t187
  store { i64, ptr } %t188, ptr %l9, !tbaa !27
  br label %bb67
bb66:
  br label %bb76
bb67:
  %t190 = load i32, ptr %l8
  %t192 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t190)
  store i1 %t192, ptr %l98
  br label %bb68
bb68:
  %t193 = load i1, ptr %l98, !tbaa !21
  br i1 %t193, label %bb69, label %bb70
bb69:
  %t194 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t198 = icmp sgt i64 %t196, 0
  store i1 %t198, ptr %l99, !tbaa !21
  br label %bb71
bb70:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb71
bb71:
  %t200 = load i1, ptr %l99, !tbaa !21
  br i1 %t200, label %bb72, label %bb73
bb72:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t202, ptr %l105, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr ptr, ptr %t204, i64 0
  %t206 = load ptr, ptr %t205, !tbaa !39
  %t210 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t201, ptr %t206)
  store i1 %t210, ptr %l108
  br label %bb74
bb73:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb75
bb74:
  %t211 = load i1, ptr %l108, !tbaa !21
  store i1 %t211, ptr %l103, !tbaa !21
  br label %bb75
bb75:
  %t212 = load i1, ptr %l103, !tbaa !21
  store i1 %t212, ptr %l17, !tbaa !21
  br label %bb110
bb76:
  %t213 = load ptr, ptr %l1, !tbaa !29
  store ptr %t213, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t214 = load ptr, ptr %l109, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb77, label %bb78
bb77:
  %t217 = load ptr, ptr %l109, !tbaa !29
  %t218 = load i64, ptr %t217
  %t220 = icmp eq i64 %t218, 2
  store i1 %t220, ptr %l110, !tbaa !21
  br label %bb78
bb78:
  %t221 = load i1, ptr %l110, !tbaa !21
  br i1 %t221, label %bb79, label %bb80
bb79:
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t224, i32 0, i32 1
  %t226 = load i32, ptr %t225
  store i32 %t226, ptr %l10, !tbaa !23
  %t228 = load ptr, ptr %l1, !tbaa !29
  %t230 = getelementptr { i64, [5 x i64] }, ptr %t228, i32 0, i32 1
  %t231 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t230, i32 0, i32 2
  %t232 = load ptr, ptr %t231
  store ptr %t232, ptr %l11, !tbaa !29
  br label %bb81
bb80:
  br label %bb87
bb81:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l11, !tbaa !29
  %t238 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eheldPart(ptr %v0, ptr %v1, ptr %t234, ptr %t235)
  store i1 %t238, ptr %l119
  br label %bb82
bb82:
  %t239 = load i1, ptr %l119, !tbaa !21
  br i1 %t239, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb86
bb84:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l11, !tbaa !29
  %t242 = load i32, ptr %l10, !tbaa !23
  %t246 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2econstCopy(ptr %v0, ptr %v1, ptr %t240, ptr %t241, i32 %t242)
  store i1 %t246, ptr %l124
  br label %bb85
bb85:
  %t247 = load i1, ptr %l124, !tbaa !21
  store i1 %t247, ptr %l120, !tbaa !21
  br label %bb86
bb86:
  %t248 = load i1, ptr %l120, !tbaa !21
  store i1 %t248, ptr %l17, !tbaa !21
  br label %bb110
bb87:
  %t249 = load ptr, ptr %l1, !tbaa !29
  store ptr %t249, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t250 = load ptr, ptr %l125, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb88, label %bb89
bb88:
  %t253 = load ptr, ptr %l125, !tbaa !29
  %t254 = load i64, ptr %t253
  %t256 = icmp eq i64 %t254, 11
  store i1 %t256, ptr %l126, !tbaa !21
  br label %bb89
bb89:
  %t257 = load i1, ptr %l126, !tbaa !21
  br i1 %t257, label %bb90, label %bb91
bb90:
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t260 = getelementptr { i64, [5 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t260, i32 0, i32 2
  %t262 = load ptr, ptr %t261
  store ptr %t262, ptr %l12, !tbaa !29
  br label %bb92
bb91:
  br label %bb98
bb92:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l12, !tbaa !29
  %t267 = getelementptr %"compiler/typed:Cond", ptr %t265, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t271 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t264, ptr %t268)
  store i1 %t271, ptr %l134
  br label %bb93
bb93:
  %t272 = load i1, ptr %l134, !tbaa !21
  br i1 %t272, label %bb94, label %bb95
bb94:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l12, !tbaa !29
  %t276 = getelementptr %"compiler/typed:Cond", ptr %t274, i32 0, i32 2
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t281 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emadeHere(ptr %v0, ptr %v1, ptr %t273, ptr %t277)
  store i1 %t281, ptr %l140
  br label %bb96
bb95:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb97
bb96:
  %t282 = load i1, ptr %l140, !tbaa !21
  store i1 %t282, ptr %l135, !tbaa !21
  br label %bb97
bb97:
  %t283 = load i1, ptr %l135, !tbaa !21
  store i1 %t283, ptr %l17, !tbaa !21
  br label %bb110
bb98:
  %t284 = load ptr, ptr %l1, !tbaa !29
  store ptr %t284, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t285 = load ptr, ptr %l141, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb99, label %bb100
bb99:
  %t288 = load ptr, ptr %l141, !tbaa !29
  %t289 = load i64, ptr %t288
  %t291 = icmp eq i64 %t289, 13
  store i1 %t291, ptr %l142, !tbaa !21
  br label %bb100
bb100:
  %t292 = load i1, ptr %l142, !tbaa !21
  br i1 %t292, label %bb101, label %bb102
bb101:
  %t293 = load ptr, ptr %l1, !tbaa !29
  %t295 = getelementptr { i64, [5 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t295, i32 0, i32 2
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l13, !tbaa !29
  br label %bb103
bb102:
  br label %bb105
bb103:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load ptr, ptr %l13, !tbaa !29
  %t303 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ematchMadeHere(ptr %v0, ptr %v1, ptr %t299, ptr %t300)
  store i1 %t303, ptr %l149
  br label %bb104
bb104:
  %t304 = load i1, ptr %l149, !tbaa !21
  store i1 %t304, ptr %l17, !tbaa !21
  br label %bb110
bb105:
  br i1 true, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb109
bb108:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @olang_loc_717fbf6233ca6ed7_9b693e4aa4ffeed3)
  unreachable
bb110:
  %t305 = load i1, ptr %l17, !tbaa !21
  store i1 %t305, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2emarkTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca { i64, [2 x i64] }
  %l9 = alloca { i64, [2 x i64] }
  %l15 = alloca { i64, [2 x i64] }
  %l24 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t32 = alloca { i64, [2 x i64] }, align 8
  %t52 = alloca { i64, [2 x i64] }, align 8
  %t59 = alloca { i64, [2 x i64] }, align 8
  %t64 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblockTerm(ptr %v0, ptr %t6, i32 %a2)
  store { i64, [2 x i64] } %t10, ptr %l9
  br label %bb4
bb4:
  %t11 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t11, ptr %l4
  br label %bb26
bb5:
  %t12 = load { i64, [2 x i64] }, ptr %l1
  %t14 = extractvalue { i64, [2 x i64] } %t12, 0
  %t15 = icmp eq i64 %t14, 2
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t17 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %t21, i32 %t22)
  store { i64, [2 x i64] } %t25, ptr %l15
  br label %bb9
bb9:
  %t26 = load { i64, [2 x i64] }, ptr %l15
  store { i64, [2 x i64] } %t26, ptr %l4
  br label %bb26
bb10:
  %t27 = load { i64, [2 x i64] }, ptr %l1
  %t29 = extractvalue { i64, [2 x i64] } %t27, 0
  %t30 = icmp eq i64 %t29, 3
  br i1 %t30, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, [2 x i64] } zeroinitializer, ptr %t32
  %t33 = getelementptr { i64, [2 x i64] }, ptr %t32, i32 0, i32 0
  store i64 3, ptr %t33
  %t34 = load { i64, [2 x i64] }, ptr %t32
  store { i64, [2 x i64] } %t34, ptr %l4
  br label %bb26
bb14:
  %t36 = load { i64, [2 x i64] }, ptr %l1
  %t38 = extractvalue { i64, [2 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 4
  br i1 %t39, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 39
  %t44 = load i64, ptr %t43, !tbaa !24
  %t46 = icmp sge i64 %t44, 0
  br i1 %t46, label %bb18, label %bb19
bb18:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/scope:Scoper", ptr %t48, i32 0, i32 39
  %t51 = load i64, ptr %t50, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t52
  %t53 = getelementptr { i64, [2 x i64] }, ptr %t52, i32 0, i32 0
  store i64 2, ptr %t53
  %t55 = insertvalue { i64 } undef, i64 %t51, 0
  %t56 = getelementptr { i64, [2 x i64] }, ptr %t52, i32 0, i32 1
  store { i64 } %t55, ptr %t56
  %t57 = load { i64, [2 x i64] }, ptr %t52
  store { i64, [2 x i64] } %t57, ptr %l24
  br label %bb20
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t59
  %t60 = getelementptr { i64, [2 x i64] }, ptr %t59, i32 0, i32 0
  store i64 6, ptr %t60
  %t61 = load { i64, [2 x i64] }, ptr %t59
  store { i64, [2 x i64] } %t61, ptr %l24
  br label %bb20
bb20:
  %t63 = load { i64, [2 x i64] }, ptr %l24
  store { i64, [2 x i64] } %t63, ptr %l4
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store { i64, [2 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [2 x i64] }, ptr %t64, i32 0, i32 0
  store i64 0, ptr %t65
  %t66 = load { i64, [2 x i64] }, ptr %t64
  store { i64, [2 x i64] } %t66, ptr %l4
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_298102a92201c9c7_d2c28c3c337e3c3b)
  unreachable
bb26:
  %t68 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ematchFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l32 = alloca i1
  %l35 = alloca ptr
  %l42 = alloca i1
  %l49 = alloca i1
  %l59 = alloca ptr
  %l67 = alloca i1
  %l70 = alloca ptr
  %l78 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i1 false, ptr %l2, !tbaa !21
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Match", ptr %t9, i32 0, i32 1
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb26
bb6:
  br label %bb7
bb7:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t26, ptr %l19, !tbaa !27
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  store ptr %t32, ptr %l6, !tbaa !29
  %t34 = load ptr, ptr %l6, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Arm", ptr %t34, i32 0, i32 4
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb25
bb9:
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l25, !tbaa !29
  %t42 = load ptr, ptr %l6, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Arm", ptr %t42, i32 0, i32 4
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1a9ca456c0fc4f74_b6b9f556459eb628)
  unreachable
bb12:
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l6, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Arm", ptr %t49, i32 0, i32 4
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = load ptr, ptr %l25, !tbaa !29
  %t56 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t54, ptr %t52)
  store i1 %t56, ptr %l32
  br label %bb14
bb14:
  %t57 = load i1, ptr %l32, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l35, !tbaa !29
  %t62 = load ptr, ptr %l6, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Arm", ptr %t62, i32 0, i32 4
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  br i1 %t67, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_2a6344a0ea169f03_937c8368e559d747)
  unreachable
bb19:
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Arm", ptr %t69, i32 0, i32 4
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = load ptr, ptr %l35, !tbaa !29
  %t76 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t74, ptr %t72)
  store i1 %t76, ptr %l42
  br label %bb21
bb21:
  %t77 = load i1, ptr %l42, !tbaa !21
  br i1 %t77, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t78 = load i64, ptr %l4, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l4, !tbaa !24
  br label %bb4
bb26:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Match", ptr %t82, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb27, label %bb28
bb27:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Match", ptr %t91, i32 0, i32 2
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  br i1 %t96, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb32
bb29:
  call void @__olang_check_failed(ptr @olang_loc_61c41c23c6ba3b82_8b9b0b538ad52716)
  unreachable
bb30:
  br label %bb31
bb31:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Match", ptr %t98, i32 0, i32 2
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Arm", ptr %t101, i32 0, i32 4
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = icmp eq ptr %t105, null
  %t109 = xor i1 %t107, true
  store i1 %t109, ptr %l49, !tbaa !21
  br label %bb32
bb32:
  %t111 = load i1, ptr %l49, !tbaa !21
  br i1 %t111, label %bb33, label %bb34
bb33:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l59, !tbaa !29
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Match", ptr %t113, i32 0, i32 2
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = icmp eq ptr %t116, null
  br i1 %t118, label %bb35, label %bb36
bb34:
  br label %bb49
bb35:
  call void @__olang_check_failed(ptr @olang_loc_b9c5758278fbc269_f38d2c0a467d6fd)
  unreachable
bb36:
  br label %bb37
bb37:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Match", ptr %t120, i32 0, i32 2
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Arm", ptr %t123, i32 0, i32 4
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t128 = load ptr, ptr %l59, !tbaa !29
  %t130 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %t128, ptr %t127)
  store i1 %t130, ptr %l67
  br label %bb38
bb38:
  %t131 = load i1, ptr %l67, !tbaa !21
  %t132 = xor i1 %t131, true
  br i1 %t132, label %bb39, label %bb40
bb39:
  store i1 false, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l70, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Match", ptr %t136, i32 0, i32 2
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  br i1 %t141, label %bb42, label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_8672b56b87660cf0_1560bce2a415882c)
  unreachable
bb43:
  br label %bb44
bb44:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Match", ptr %t143, i32 0, i32 2
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Arm", ptr %t146, i32 0, i32 4
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t151 = load ptr, ptr %l70, !tbaa !29
  %t153 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %t151, ptr %t150)
  store i1 %t153, ptr %l78
  br label %bb45
bb45:
  %t154 = load i1, ptr %l78, !tbaa !21
  br i1 %t154, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t155 = load i1, ptr %l2, !tbaa !21
  store i1 %t155, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca i8
  %l14 = alloca i64
  %l15 = alloca i8
  %l16 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %l46 = alloca { i64, ptr }
  %l51 = alloca i1
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l76 = alloca %"compiler/source:Span"
  %l79 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l97 = alloca i1
  %l105 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/source:Span"
  %l113 = alloca i1
  %l116 = alloca i1
  %l121 = alloca %"compiler/source:Span"
  %l125 = alloca i1
  %l130 = alloca i1
  %l131 = alloca { i64, ptr }
  %l134 = alloca i1
  %l144 = alloca %"compiler/source:Span"
  %l147 = alloca i1
  %l150 = alloca i1
  %l156 = alloca i1
  %l166 = alloca i1
  %l169 = alloca i1
  %l181 = alloca i1
  %l184 = alloca i1
  %l187 = alloca i1
  %l190 = alloca %"compiler/source:Span"
  %l193 = alloca i1
  %l196 = alloca i1
  %l199 = alloca i1
  %l204 = alloca i1
  %l205 = alloca { i64, ptr }
  %l210 = alloca i1
  %l214 = alloca i1
  %l215 = alloca { i64, ptr }
  %l220 = alloca i1
  %l221 = alloca { i64, ptr }
  %l226 = alloca i1
  %l227 = alloca { i64, ptr }
  %l232 = alloca i1
  %l233 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l246 = alloca i1
  %l249 = alloca i1
  %l252 = alloca i1
  %l255 = alloca i1
  %l258 = alloca i1
  %l261 = alloca i1
  %l264 = alloca i1
  %l267 = alloca i1
  %l276 = alloca %"compiler/source:Span"
  %l282 = alloca %"compiler/source:Span"
  %l287 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l18, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 25
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_e498d93abb20b61c_9a7977ea577c2990)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l18, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l27
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l26
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t26, ptr %l16, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t28 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t29 = load i32, ptr %t28, !tbaa !23
  %t31 = sext i32 %t29 to i64
  store i64 %t31, ptr %l3, !tbaa !24
  %t33 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t34 = load i32, ptr %t33, !tbaa !23
  %t36 = sext i32 %t34 to i64
  store i64 %t36, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t44 = icmp sgt i64 %t38, %t41
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t46, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l3, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  %t50 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t50, ptr %l6
  %t52 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t52, ptr %l39
  br label %bb11
bb11:
  %t53 = load %"compiler/source:Span", ptr %l39
  store %"compiler/source:Span" %t53, ptr %l7
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t54 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t54, ptr %l40
  br label %bb12
bb12:
  %t55 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t55, ptr %l11
  %t56 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t56, ptr %l41
  br label %bb13
bb13:
  %t57 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t57, ptr %l12
  br label %bb14
bb14:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  br label %bb194
bb16:
  br label %bb17
bb17:
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t66, ptr %l46, !tbaa !27
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  store i8 %t72, ptr %l13, !tbaa !22
  %t74 = load i8, ptr %l13, !tbaa !22
  %t76 = icmp eq i8 %t74, 34
  br i1 %t76, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb20
bb19:
  %t78 = load i8, ptr %l13, !tbaa !22
  %t80 = icmp eq i8 %t78, 39
  store i1 %t80, ptr %l51, !tbaa !21
  br label %bb20
bb20:
  %t82 = load i1, ptr %l51, !tbaa !21
  br i1 %t82, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb23
bb22:
  br label %bb36
bb23:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  br i1 %t91, label %bb24, label %bb25
bb24:
  %t93 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t93, ptr %l60, !tbaa !27
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t100 = load i8, ptr %l13, !tbaa !22
  %t103 = icmp ne i8 %t99, %t100
  store i1 %t103, ptr %l59, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb26
bb26:
  %t105 = load i1, ptr %l59, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb27, label %bb28
bb27:
  br label %bb34
bb28:
  br label %bb29
bb29:
  %t108 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t108, ptr %l66, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 %t109
  %t114 = load i8, ptr %t113, !tbaa !32
  %t116 = icmp eq i8 %t114, 92
  br i1 %t116, label %bb30, label %bb31
bb30:
  %t118 = load i64, ptr %l5, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l5, !tbaa !24
  br label %bb32
bb31:
  br label %bb32
bb32:
  %t122 = load i64, ptr %l5, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l5, !tbaa !24
  br label %bb33
bb33:
  br label %bb23
bb34:
  %t126 = load i64, ptr %l5, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l5, !tbaa !24
  %t130 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 0, i32 0)
  store %"compiler/source:Span" %t130, ptr %l76
  br label %bb35
bb35:
  %t131 = load %"compiler/source:Span", ptr %l76
  store %"compiler/source:Span" %t131, ptr %l7
  call void @__olang_scope_close(ptr %s3)
  br label %bb193
bb36:
  %t132 = load i8, ptr %l13, !tbaa !22
  %t134 = icmp eq i8 %t132, 40
  br i1 %t134, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb39
bb38:
  %t136 = load i8, ptr %l13, !tbaa !22
  %t138 = icmp eq i8 %t136, 91
  store i1 %t138, ptr %l79, !tbaa !21
  br label %bb39
bb39:
  %t140 = load i1, ptr %l79, !tbaa !21
  br i1 %t140, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb42
bb41:
  %t141 = load i8, ptr %l13, !tbaa !22
  %t143 = icmp eq i8 %t141, 123
  store i1 %t143, ptr %l82, !tbaa !21
  br label %bb42
bb42:
  %t145 = load i1, ptr %l82, !tbaa !21
  br i1 %t145, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t146 = load i8, ptr %l13, !tbaa !22
  %t148 = icmp eq i8 %t146, 40
  br i1 %t148, label %bb45, label %bb46
bb44:
  br label %bb62
bb45:
  %t150 = load i64, ptr %l9, !tbaa !24
  %t152 = icmp eq i64 %t150, 0
  store i1 %t152, ptr %l87, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb47
bb47:
  %t154 = load i1, ptr %l87, !tbaa !21
  br i1 %t154, label %bb48, label %bb49
bb48:
  %t155 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t156 = load i32, ptr %t155, !tbaa !23
  %t157 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t158 = load i32, ptr %t157, !tbaa !23
  %t161 = icmp sgt i32 %t156, %t158
  store i1 %t161, ptr %l90, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb50
bb50:
  %t163 = load i1, ptr %l90, !tbaa !21
  br i1 %t163, label %bb51, label %bb52
bb51:
  %t164 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t164, ptr %l6
  store i1 true, ptr %l8, !tbaa !21
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t166 = load i8, ptr %l13, !tbaa !22
  %t168 = icmp eq i8 %t166, 91
  br i1 %t168, label %bb54, label %bb55
bb54:
  %t170 = load i64, ptr %l9, !tbaa !24
  %t172 = icmp eq i64 %t170, 0
  store i1 %t172, ptr %l97, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb56
bb56:
  %t174 = load i1, ptr %l97, !tbaa !21
  br i1 %t174, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s8
  %t175 = load i64, ptr %l5, !tbaa !24
  %t177 = trunc i64 %t175 to i32
  %t178 = load i64, ptr %l5, !tbaa !24
  %t180 = add i64 %t178, 1
  %t182 = trunc i64 %t180 to i32
  %t185 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 %t177, i32 %t182)
  store %"compiler/source:Span" %t185, ptr %l105
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t186 = load %"compiler/source:Span", ptr %l105
  store %"compiler/source:Span" %t186, ptr %l12
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb60:
  %t187 = load i64, ptr %l9, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l9, !tbaa !24
  %t191 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 0, i32 0)
  store %"compiler/source:Span" %t191, ptr %l108
  br label %bb61
bb61:
  %t192 = load %"compiler/source:Span", ptr %l108
  store %"compiler/source:Span" %t192, ptr %l7
  %t193 = load i64, ptr %l5, !tbaa !24
  %t195 = add i64 %t193, 1
  store i64 %t195, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb193
bb62:
  %t197 = load i8, ptr %l13, !tbaa !22
  %t199 = icmp eq i8 %t197, 41
  br i1 %t199, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb65
bb64:
  %t201 = load i8, ptr %l13, !tbaa !22
  %t203 = icmp eq i8 %t201, 93
  store i1 %t203, ptr %l113, !tbaa !21
  br label %bb65
bb65:
  %t205 = load i1, ptr %l113, !tbaa !21
  br i1 %t205, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb68
bb67:
  %t206 = load i8, ptr %l13, !tbaa !22
  %t208 = icmp eq i8 %t206, 125
  store i1 %t208, ptr %l116, !tbaa !21
  br label %bb68
bb68:
  %t210 = load i1, ptr %l116, !tbaa !21
  br i1 %t210, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s9
  %t211 = load i64, ptr %l9, !tbaa !24
  %t213 = sub i64 %t211, 1
  store i64 %t213, ptr %l9, !tbaa !24
  %t215 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s9, i32 0, i32 0)
  store %"compiler/source:Span" %t215, ptr %l121
  br label %bb71
bb70:
  br label %bb72
bb71:
  %t216 = load %"compiler/source:Span", ptr %l121
  store %"compiler/source:Span" %t216, ptr %l7
  %t217 = load i64, ptr %l5, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb193
bb72:
  %t221 = load i8, ptr %l13, !tbaa !22
  %t223 = call i1 @compiler_2fscope_2eisNameChar(i8 %t221)
  store i1 %t223, ptr %l125
  br label %bb73
bb73:
  %t224 = load i1, ptr %l125, !tbaa !21
  br i1 %t224, label %bb74, label %bb75
bb74:
  %t225 = load i64, ptr %l5, !tbaa !24
  store i64 %t225, ptr %l14, !tbaa !24
  br label %bb76
bb75:
  br label %bb99
bb76:
  %t227 = load i64, ptr %l5, !tbaa !24
  %t228 = load i64, ptr %l4, !tbaa !24
  %t231 = icmp slt i64 %t227, %t228
  br i1 %t231, label %bb77, label %bb78
bb77:
  %t233 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t233, ptr %l131, !tbaa !27
  %t234 = load i64, ptr %l5, !tbaa !24
  %t236 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr i8, ptr %t237, i64 %t234
  %t239 = load i8, ptr %t238, !tbaa !32
  %t241 = call i1 @compiler_2fscope_2eisNameChar(i8 %t239)
  store i1 %t241, ptr %l134
  br label %bb79
bb78:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb80
bb79:
  %t242 = load i1, ptr %l134, !tbaa !21
  store i1 %t242, ptr %l130, !tbaa !21
  br label %bb80
bb80:
  %t243 = load i1, ptr %l130, !tbaa !21
  %t244 = xor i1 %t243, true
  br i1 %t244, label %bb81, label %bb82
bb81:
  br label %bb85
bb82:
  br label %bb83
bb83:
  %t246 = load i64, ptr %l5, !tbaa !24
  %t248 = add i64 %t246, 1
  store i64 %t248, ptr %l5, !tbaa !24
  br label %bb84
bb84:
  br label %bb76
bb85:
  %t250 = load i64, ptr %l10, !tbaa !24
  %t252 = icmp eq i64 %t250, 0
  br i1 %t252, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s12
  %t254 = load i64, ptr %l14, !tbaa !24
  %t256 = trunc i64 %t254 to i32
  %t257 = load i64, ptr %l5, !tbaa !24
  %t259 = trunc i64 %t257 to i32
  %t262 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s12, i32 %t256, i32 %t259)
  store %"compiler/source:Span" %t262, ptr %l144
  br label %bb88
bb87:
  br label %bb89
bb88:
  %t263 = load %"compiler/source:Span", ptr %l144
  store %"compiler/source:Span" %t263, ptr %l7
  call void @__olang_scope_close(ptr %s12)
  br label %bb89
bb89:
  %t264 = load i1, ptr %l8, !tbaa !21
  %t266 = xor i1 %t264, true
  br i1 %t266, label %bb90, label %bb91
bb90:
  %t268 = load i64, ptr %l9, !tbaa !24
  %t270 = icmp eq i64 %t268, 0
  store i1 %t270, ptr %l147, !tbaa !21
  br label %bb92
bb91:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb92
bb92:
  %t272 = load i1, ptr %l147, !tbaa !21
  br i1 %t272, label %bb93, label %bb94
bb93:
  %t273 = load i64, ptr %l10, !tbaa !24
  %t275 = icmp eq i64 %t273, 0
  store i1 %t275, ptr %l150, !tbaa !21
  br label %bb95
bb94:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb95
bb95:
  %t277 = load i1, ptr %l150, !tbaa !21
  br i1 %t277, label %bb96, label %bb97
bb96:
  %t278 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t278, ptr %l6
  br label %bb98
bb97:
  br label %bb98
bb98:
  br label %bb193
bb99:
  %t280 = load i8, ptr %l13, !tbaa !22
  %t282 = icmp eq i8 %t280, 60
  br i1 %t282, label %bb100, label %bb101
bb100:
  %t284 = load i64, ptr %l9, !tbaa !24
  %t286 = icmp eq i64 %t284, 0
  store i1 %t286, ptr %l156, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb102
bb102:
  %t288 = load i1, ptr %l156, !tbaa !21
  br i1 %t288, label %bb103, label %bb104
bb103:
  %t289 = load i64, ptr %l10, !tbaa !24
  %t291 = add i64 %t289, 1
  store i64 %t291, ptr %l10, !tbaa !24
  %t293 = load i64, ptr %l10, !tbaa !24
  %t295 = icmp eq i64 %t293, 1
  br i1 %t295, label %bb105, label %bb106
bb104:
  %t297 = load i8, ptr %l13, !tbaa !22
  %t299 = icmp eq i8 %t297, 62
  br i1 %t299, label %bb108, label %bb109
bb105:
  %t301 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t301, ptr %l11
  br label %bb107
bb106:
  br label %bb107
bb107:
  br label %bb133
bb108:
  %t303 = load i64, ptr %l10, !tbaa !24
  %t305 = icmp sgt i64 %t303, 0
  store i1 %t305, ptr %l166, !tbaa !21
  br label %bb110
bb109:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb110
bb110:
  %t307 = load i1, ptr %l166, !tbaa !21
  br i1 %t307, label %bb111, label %bb112
bb111:
  %t308 = load i64, ptr %l9, !tbaa !24
  %t310 = icmp eq i64 %t308, 0
  store i1 %t310, ptr %l169, !tbaa !21
  br label %bb113
bb112:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb113
bb113:
  %t312 = load i1, ptr %l169, !tbaa !21
  br i1 %t312, label %bb114, label %bb115
bb114:
  %t313 = load i64, ptr %l10, !tbaa !24
  %t315 = sub i64 %t313, 1
  store i64 %t315, ptr %l10, !tbaa !24
  %t317 = load i64, ptr %l10, !tbaa !24
  %t319 = icmp eq i64 %t317, 0
  br i1 %t319, label %bb116, label %bb117
bb115:
  %t321 = load i8, ptr %l13, !tbaa !22
  %t323 = icmp ne i8 %t321, 46
  br i1 %t323, label %bb119, label %bb120
bb116:
  %t325 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t325, ptr %l7
  br label %bb118
bb117:
  br label %bb118
bb118:
  %t327 = load i64, ptr %l5, !tbaa !24
  %t329 = add i64 %t327, 1
  store i64 %t329, ptr %l5, !tbaa !24
  br label %bb193
bb119:
  %t331 = load i8, ptr %l13, !tbaa !22
  %t333 = icmp ne i8 %t331, 32
  store i1 %t333, ptr %l181, !tbaa !21
  br label %bb121
bb120:
  store i1 false, ptr %l181, !tbaa !21
  br label %bb121
bb121:
  %t335 = load i1, ptr %l181, !tbaa !21
  br i1 %t335, label %bb122, label %bb123
bb122:
  %t336 = load i8, ptr %l13, !tbaa !22
  %t338 = icmp ne i8 %t336, 44
  store i1 %t338, ptr %l184, !tbaa !21
  br label %bb124
bb123:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb124
bb124:
  %t340 = load i1, ptr %l184, !tbaa !21
  br i1 %t340, label %bb125, label %bb126
bb125:
  %t341 = load i64, ptr %l10, !tbaa !24
  %t343 = icmp eq i64 %t341, 0
  store i1 %t343, ptr %l187, !tbaa !21
  br label %bb127
bb126:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb127
bb127:
  %t345 = load i1, ptr %l187, !tbaa !21
  br i1 %t345, label %bb128, label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s20
  %t346 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s20, i32 0, i32 0)
  store %"compiler/source:Span" %t346, ptr %l190
  br label %bb130
bb129:
  br label %bb131
bb130:
  %t347 = load %"compiler/source:Span", ptr %l190
  store %"compiler/source:Span" %t347, ptr %l7
  call void @__olang_scope_close(ptr %s20)
  br label %bb131
bb131:
  br label %bb132
bb132:
  br label %bb133
bb133:
  %t348 = load i8, ptr %l13, !tbaa !22
  %t350 = icmp eq i8 %t348, 61
  br i1 %t350, label %bb134, label %bb135
bb134:
  %t352 = load i64, ptr %l9, !tbaa !24
  %t354 = icmp eq i64 %t352, 0
  store i1 %t354, ptr %l193, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb136
bb136:
  %t356 = load i1, ptr %l193, !tbaa !21
  br i1 %t356, label %bb137, label %bb138
bb137:
  %t357 = load i1, ptr %l8, !tbaa !21
  %t359 = xor i1 %t357, true
  store i1 %t359, ptr %l196, !tbaa !21
  br label %bb139
bb138:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb139
bb139:
  %t361 = load i1, ptr %l196, !tbaa !21
  br i1 %t361, label %bb140, label %bb141
bb140:
  %t362 = load i64, ptr %l5, !tbaa !24
  %t364 = add i64 %t362, 1
  %t365 = load i64, ptr %l4, !tbaa !24
  %t368 = icmp slt i64 %t364, %t365
  store i1 %t368, ptr %l199, !tbaa !21
  br label %bb142
bb141:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb142
bb142:
  %t370 = load i1, ptr %l199, !tbaa !21
  br i1 %t370, label %bb143, label %bb144
bb143:
  %t371 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t371, ptr %l205, !tbaa !27
  %t372 = load i64, ptr %l5, !tbaa !24
  %t374 = add i64 %t372, 1
  %t376 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr i8, ptr %t377, i64 %t374
  %t379 = load i8, ptr %t378, !tbaa !32
  %t381 = icmp ne i8 %t379, 61
  store i1 %t381, ptr %l204, !tbaa !21
  br label %bb145
bb144:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb145
bb145:
  %t383 = load i1, ptr %l204, !tbaa !21
  br i1 %t383, label %bb146, label %bb147
bb146:
  %t384 = load i64, ptr %l5, !tbaa !24
  %t385 = load i64, ptr %l3, !tbaa !24
  %t388 = icmp sgt i64 %t384, %t385
  store i1 %t388, ptr %l210, !tbaa !21
  br label %bb148
bb147:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb148
bb148:
  %t390 = load i1, ptr %l210, !tbaa !21
  br i1 %t390, label %bb149, label %bb150
bb149:
  %t391 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t391, ptr %l215, !tbaa !27
  %t392 = load i64, ptr %l5, !tbaa !24
  %t394 = sub i64 %t392, 1
  %t396 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = getelementptr i8, ptr %t397, i64 %t394
  %t399 = load i8, ptr %t398, !tbaa !32
  %t401 = icmp ne i8 %t399, 61
  store i1 %t401, ptr %l214, !tbaa !21
  br label %bb151
bb150:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb151
bb151:
  %t403 = load i1, ptr %l214, !tbaa !21
  br i1 %t403, label %bb152, label %bb153
bb152:
  %t404 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t404, ptr %l221, !tbaa !27
  %t405 = load i64, ptr %l5, !tbaa !24
  %t407 = sub i64 %t405, 1
  %t409 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr i8, ptr %t410, i64 %t407
  %t412 = load i8, ptr %t411, !tbaa !32
  %t414 = icmp ne i8 %t412, 33
  store i1 %t414, ptr %l220, !tbaa !21
  br label %bb154
bb153:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb154
bb154:
  %t416 = load i1, ptr %l220, !tbaa !21
  br i1 %t416, label %bb155, label %bb156
bb155:
  %t417 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t417, ptr %l227, !tbaa !27
  %t418 = load i64, ptr %l5, !tbaa !24
  %t420 = sub i64 %t418, 1
  %t422 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr i8, ptr %t423, i64 %t420
  %t425 = load i8, ptr %t424, !tbaa !32
  %t427 = icmp ne i8 %t425, 60
  store i1 %t427, ptr %l226, !tbaa !21
  br label %bb157
bb156:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb157
bb157:
  %t429 = load i1, ptr %l226, !tbaa !21
  br i1 %t429, label %bb158, label %bb159
bb158:
  %t430 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t430, ptr %l233, !tbaa !27
  %t431 = load i64, ptr %l5, !tbaa !24
  %t433 = sub i64 %t431, 1
  %t435 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr i8, ptr %t436, i64 %t433
  %t438 = load i8, ptr %t437, !tbaa !32
  %t440 = icmp ne i8 %t438, 62
  store i1 %t440, ptr %l232, !tbaa !21
  br label %bb160
bb159:
  store i1 false, ptr %l232, !tbaa !21
  br label %bb160
bb160:
  %t442 = load i1, ptr %l232, !tbaa !21
  br i1 %t442, label %bb161, label %bb162
bb161:
  store %olang.scope zeroinitializer, ptr %s21
  %t443 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t443, ptr %l238, !tbaa !27
  %t444 = load i64, ptr %l5, !tbaa !24
  %t446 = sub i64 %t444, 1
  %t448 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !27
  %t450 = getelementptr i8, ptr %t449, i64 %t446
  %t451 = load i8, ptr %t450, !tbaa !32
  store i8 %t451, ptr %l15, !tbaa !22
  %t453 = load i64, ptr %l5, !tbaa !24
  %t455 = sub i64 %t453, 1
  %t456 = load i64, ptr %l3, !tbaa !24
  %t459 = icmp sgt i64 %t455, %t456
  br i1 %t459, label %bb163, label %bb164
bb162:
  br label %bb192
bb163:
  %t461 = load i8, ptr %l15, !tbaa !22
  %t463 = icmp eq i8 %t461, 43
  br i1 %t463, label %bb165, label %bb166
bb164:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb186
bb165:
  store i1 true, ptr %l249, !tbaa !21
  br label %bb167
bb166:
  %t465 = load i8, ptr %l15, !tbaa !22
  %t467 = icmp eq i8 %t465, 45
  store i1 %t467, ptr %l249, !tbaa !21
  br label %bb167
bb167:
  %t469 = load i1, ptr %l249, !tbaa !21
  br i1 %t469, label %bb168, label %bb169
bb168:
  store i1 true, ptr %l252, !tbaa !21
  br label %bb170
bb169:
  %t470 = load i8, ptr %l15, !tbaa !22
  %t472 = icmp eq i8 %t470, 42
  store i1 %t472, ptr %l252, !tbaa !21
  br label %bb170
bb170:
  %t474 = load i1, ptr %l252, !tbaa !21
  br i1 %t474, label %bb171, label %bb172
bb171:
  store i1 true, ptr %l255, !tbaa !21
  br label %bb173
bb172:
  %t475 = load i8, ptr %l15, !tbaa !22
  %t477 = icmp eq i8 %t475, 47
  store i1 %t477, ptr %l255, !tbaa !21
  br label %bb173
bb173:
  %t479 = load i1, ptr %l255, !tbaa !21
  br i1 %t479, label %bb174, label %bb175
bb174:
  store i1 true, ptr %l258, !tbaa !21
  br label %bb176
bb175:
  %t480 = load i8, ptr %l15, !tbaa !22
  %t482 = icmp eq i8 %t480, 37
  store i1 %t482, ptr %l258, !tbaa !21
  br label %bb176
bb176:
  %t484 = load i1, ptr %l258, !tbaa !21
  br i1 %t484, label %bb177, label %bb178
bb177:
  store i1 true, ptr %l261, !tbaa !21
  br label %bb179
bb178:
  %t485 = load i8, ptr %l15, !tbaa !22
  %t487 = icmp eq i8 %t485, 38
  store i1 %t487, ptr %l261, !tbaa !21
  br label %bb179
bb179:
  %t489 = load i1, ptr %l261, !tbaa !21
  br i1 %t489, label %bb180, label %bb181
bb180:
  store i1 true, ptr %l264, !tbaa !21
  br label %bb182
bb181:
  %t490 = load i8, ptr %l15, !tbaa !22
  %t492 = icmp eq i8 %t490, 124
  store i1 %t492, ptr %l264, !tbaa !21
  br label %bb182
bb182:
  %t494 = load i1, ptr %l264, !tbaa !21
  br i1 %t494, label %bb183, label %bb184
bb183:
  store i1 true, ptr %l267, !tbaa !21
  br label %bb185
bb184:
  %t495 = load i8, ptr %l15, !tbaa !22
  %t497 = icmp eq i8 %t495, 94
  store i1 %t497, ptr %l267, !tbaa !21
  br label %bb185
bb185:
  %t499 = load i1, ptr %l267, !tbaa !21
  store i1 %t499, ptr %l246, !tbaa !21
  br label %bb186
bb186:
  %t500 = load i1, ptr %l246, !tbaa !21
  br i1 %t500, label %bb187, label %bb188
bb187:
  store %olang.scope zeroinitializer, ptr %s22
  %t501 = load i64, ptr %l5, !tbaa !24
  %t503 = sub i64 %t501, 1
  %t505 = trunc i64 %t503 to i32
  %t506 = load i64, ptr %l5, !tbaa !24
  %t508 = add i64 %t506, 1
  %t510 = trunc i64 %t508 to i32
  %t513 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s22, i32 %t505, i32 %t510)
  store %"compiler/source:Span" %t513, ptr %l276
  br label %bb189
bb188:
  br label %bb190
bb189:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t514 = load %"compiler/source:Span", ptr %l276
  store %"compiler/source:Span" %t514, ptr %rv
  br label %ret
bb190:
  %t515 = load i64, ptr %l5, !tbaa !24
  %t517 = trunc i64 %t515 to i32
  %t518 = load i64, ptr %l5, !tbaa !24
  %t520 = add i64 %t518, 1
  %t522 = trunc i64 %t520 to i32
  %t525 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s21, i32 %t517, i32 %t522)
  store %"compiler/source:Span" %t525, ptr %l282
  br label %bb191
bb191:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t526 = load %"compiler/source:Span", ptr %l282
  store %"compiler/source:Span" %t526, ptr %rv
  br label %ret
bb192:
  %t527 = load i64, ptr %l5, !tbaa !24
  %t529 = add i64 %t527, 1
  store i64 %t529, ptr %l5, !tbaa !24
  br label %bb193
bb193:
  br label %bb14
bb194:
  %t531 = load i1, ptr %l8, !tbaa !21
  %t533 = xor i1 %t531, true
  br i1 %t533, label %bb195, label %bb196
bb195:
  %t535 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 1
  %t536 = load i32, ptr %t535, !tbaa !23
  %t537 = getelementptr %"compiler/source:Span", ptr %l12, i32 0, i32 0
  %t538 = load i32, ptr %t537, !tbaa !23
  %t541 = icmp sgt i32 %t536, %t538
  store i1 %t541, ptr %l287, !tbaa !21
  br label %bb197
bb196:
  store i1 false, ptr %l287, !tbaa !21
  br label %bb197
bb197:
  %t543 = load i1, ptr %l287, !tbaa !21
  br i1 %t543, label %bb198, label %bb199
bb198:
  %t544 = load %"compiler/source:Span", ptr %l12
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t544, ptr %rv
  br label %ret
bb199:
  br label %bb200
bb200:
  %t546 = load %"compiler/source:Span", ptr %l6
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t546, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoBuildTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 64
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i64, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = icmp slt i64 %t16, %t17
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 64
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t22, i64 %t23)
  store i1 %t26, ptr %l16
  br label %bb7
bb6:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb8
bb7:
  %t27 = load i1, ptr %l16, !tbaa !21
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l12, !tbaa !21
  store i1 %t28, ptr %l3, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_a9ed640346de181b_d10bb16716ed4607)
  unreachable
bb14:
  %t29 = load i1, ptr %l3, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteFieldRecs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, [2 x i64] }
  %l36 = alloca i64
  %l38 = alloca i64
  %l43 = alloca i32
  %l44 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i32
  %l51 = alloca ptr
  %l61 = alloca %"compiler/typed:Local"
  %l63 = alloca i64
  %l66 = alloca i1
  %l69 = alloca i1
  %l72 = alloca i64
  %l75 = alloca i64
  %l80 = alloca ptr
  %l83 = alloca i64
  %l88 = alloca i64
  %l91 = alloca i64
  %l114 = alloca { i64, [2 x i64] }
  %l115 = alloca i1
  %l121 = alloca ptr
  %l123 = alloca { i64, [2 x i64] }
  %t219 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/scope:summary", ptr %t1, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v1, ptr %t3)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/scope:summary", ptr %t5, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t7)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/scope:Scoper", ptr %t9, i32 0, i32 25
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_5073d45cb29e2b2c_5271f582f3c3830)
  unreachable
bb4:
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 25
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t19, i32 0, i32 1
  %t23 = load { i64, [2 x i64] }, ptr %t22
  %t27 = extractvalue { i64, [2 x i64] } %t23, 0
  %t28 = icmp eq i64 %t27, 1
  br i1 %t28, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_e97645627b4ddb42_25acdb187fd0af56)
  unreachable
bb14:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 25
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  br i1 %t35, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1193222288ba1b5a_e9751e9a82c409de)
  unreachable
bb16:
  br label %bb17
bb17:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 25
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t40, i32 0, i32 10
  store ptr %t43, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb18
bb18:
  %t45 = load i64, ptr %l4, !tbaa !24
  store i64 %t45, ptr %l36, !tbaa !24
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t46)
  store i64 %t48, ptr %l38
  br label %bb19
bb19:
  %t49 = load i64, ptr %l36, !tbaa !24
  %t50 = load i64, ptr %l38, !tbaa !24
  %t51 = icmp slt i64 %t49, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb20, label %bb21
bb20:
  br label %bb75
bb21:
  br label %bb22
bb22:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t55, i64 %t56)
  store i32 %t59, ptr %l43
  br label %bb23
bb23:
  %t60 = load i32, ptr %l43, !tbaa !23
  store i32 %t60, ptr %l5, !tbaa !23
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/scope:Scoper", ptr %t61, i32 0, i32 43
  %t64 = load i32, ptr %l5, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t69 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t63, i64 %t66)
  %t70 = extractvalue { i32, i64 } %t69, 1
  %t71 = extractvalue { i32, i64 } %t69, 0
  store i32 %t71, ptr %l50
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb25, label %ok.73, !prof !99
ok.73:
  store i64 %t70, ptr %l49
  br label %bb24
bb24:
  %t74 = load i64, ptr %l49, !tbaa !24
  store i64 %t74, ptr %l44, !tbaa !24
  br label %bb27
bb25:
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l44, !tbaa !24
  br label %bb27
bb27:
  %t75 = load i64, ptr %l44, !tbaa !24
  store i64 %t75, ptr %l6, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l51, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/scope:Scoper", ptr %t77, i32 0, i32 25
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  br i1 %t82, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_677694645a0d3ce1_ddba560673e185)
  unreachable
bb29:
  br label %bb30
bb30:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/scope:Scoper", ptr %t84, i32 0, i32 25
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Body", ptr %t87, i32 0, i32 7
  %t91 = load i32, ptr %l5, !tbaa !23
  %t93 = sext i32 %t91 to i64
  %t96 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t90, i64 %t93)
  store %"compiler/typed:Local" %t96, ptr %l61
  br label %bb31
bb31:
  %t97 = getelementptr %"compiler/typed:Local", ptr %l61, i32 0, i32 2
  %t98 = load i32, ptr %t97, !tbaa !23
  %t99 = load ptr, ptr %l51, !tbaa !29
  %t101 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParams(ptr %v0, ptr %t99, i32 %t98)
  store i64 %t101, ptr %l63
  br label %bb32
bb32:
  %t102 = load i64, ptr %l63, !tbaa !24
  store i64 %t102, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l6, !tbaa !24
  %t105 = icmp slt i64 %t103, 0
  br i1 %t105, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb35
bb34:
  %t107 = load i64, ptr %l7, !tbaa !24
  %t109 = icmp eq i64 %t107, 0
  store i1 %t109, ptr %l66, !tbaa !21
  br label %bb35
bb35:
  %t111 = load i1, ptr %l66, !tbaa !21
  br i1 %t111, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb39
bb37:
  %t112 = load i64, ptr %l6, !tbaa !24
  %t113 = load i64, ptr %l7, !tbaa !24
  %t116 = add i64 %t112, %t113
  store i64 %t116, ptr %l72, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/scope:Scoper", ptr %t117, i32 0, i32 44
  %t121 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t119)
  store i64 %t121, ptr %l75
  br label %bb38
bb38:
  %t122 = load i64, ptr %l72, !tbaa !24
  %t123 = load i64, ptr %l75, !tbaa !24
  %t124 = icmp sgt i64 %t122, %t123
  store i1 %t124, ptr %l69, !tbaa !21
  br label %bb39
bb39:
  %t126 = load i1, ptr %l69, !tbaa !21
  br i1 %t126, label %bb40, label %bb41
bb40:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"compiler/scope:summary", ptr %t127, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t129, i64 -1)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb74
bb43:
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr %"compiler/scope:summary", ptr %t131, i32 0, i32 12
  store ptr %t133, ptr %l80, !tbaa !29
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr %"compiler/scope:summary", ptr %t134, i32 0, i32 13
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t136)
  store i64 %t138, ptr %l83
  br label %bb44
bb44:
  %t139 = load ptr, ptr %l80, !tbaa !29
  %t140 = load i64, ptr %l83, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t139, i64 %t140)
  br label %bb45
bb45:
  store i64 0, ptr %l8, !tbaa !24
  %t141 = load i64, ptr %l7, !tbaa !24
  store i64 %t141, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t143 = load i64, ptr %l9, !tbaa !24
  %t144 = load i64, ptr %l8, !tbaa !24
  %t147 = icmp sgt i64 %t143, %t144
  br i1 %t147, label %bb46, label %bb47
bb46:
  %t149 = load i64, ptr %l10, !tbaa !24
  %t151 = icmp sgt i64 %t149, 0
  br i1 %t151, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb51
bb48:
  %t153 = load i64, ptr %l9, !tbaa !24
  %t154 = load i64, ptr %l8, !tbaa !24
  %t157 = sub i64 %t153, %t154
  %t158 = load i64, ptr %l10, !tbaa !24
  %t161 = add i64 %t157, %t158
  %t163 = sub i64 %t161, 1
  %t164 = load i64, ptr %l10, !tbaa !24
  %t167 = sdiv i64 %t163, %t164
  store i64 %t167, ptr %l91, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb50
bb50:
  %t169 = load i64, ptr %l91, !tbaa !24
  store i64 %t169, ptr %l88, !tbaa !24
  br label %bb51
bb51:
  %t170 = load i64, ptr %l88, !tbaa !24
  store i64 %t170, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb52
bb52:
  %t171 = load i64, ptr %l12, !tbaa !24
  %t172 = load i64, ptr %l11, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb53, label %bb54
bb53:
  br label %bb73
bb54:
  br label %bb55
bb55:
  %t179 = load i64, ptr %l8, !tbaa !24
  %t180 = load i64, ptr %l12, !tbaa !24
  %t181 = load i64, ptr %l10, !tbaa !24
  %t184 = mul i64 %t180, %t181
  %t187 = add i64 %t179, %t184
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/scope:Scoper", ptr %t189, i32 0, i32 44
  %t192 = load i64, ptr %l6, !tbaa !24
  %t196 = add i64 %t192, %t187
  %t199 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t191, i64 %t196)
  store { i64, [2 x i64] } %t199, ptr %l114
  br label %bb56
bb56:
  %t200 = load { i64, [2 x i64] }, ptr %l114
  store { i64, [2 x i64] } %t200, ptr %l14
  %t201 = load { i64, [2 x i64] }, ptr %l14
  %t203 = extractvalue { i64, [2 x i64] } %t201, 0
  %t204 = icmp eq i64 %t203, 2
  br i1 %t204, label %bb57, label %bb58
bb57:
  br label %bb61
bb58:
  %t206 = load { i64, [2 x i64] }, ptr %l14
  %t208 = extractvalue { i64, [2 x i64] } %t206, 0
  %t209 = icmp eq i64 %t208, 3
  br i1 %t209, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb67
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_46d6c69b453c665f_cff2ba6bc4bd85db)
  unreachable
bb67:
  %t211 = load i1, ptr %l115, !tbaa !21
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr %"compiler/scope:summary", ptr %t212, i32 0, i32 13
  store ptr %t214, ptr %l121, !tbaa !29
  br i1 %t211, label %bb68, label %bb69
bb68:
  %t217 = load { i64, [2 x i64] }, ptr %l14
  store { i64, [2 x i64] } %t217, ptr %l123
  br label %bb70
bb69:
  store { i64, [2 x i64] } zeroinitializer, ptr %t219
  %t220 = getelementptr { i64, [2 x i64] }, ptr %t219, i32 0, i32 0
  store i64 6, ptr %t220
  %t221 = load { i64, [2 x i64] }, ptr %t219
  store { i64, [2 x i64] } %t221, ptr %l123
  br label %bb70
bb70:
  %t223 = load ptr, ptr %l121, !tbaa !29
  %t224 = load { i64, [2 x i64] }, ptr %l123
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v1, ptr %t223, { i64, [2 x i64] } %t224)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t225 = load i64, ptr %l12, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l12, !tbaa !24
  br label %bb52
bb73:
  br label %bb74
bb74:
  %t229 = load i64, ptr %l4, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l4, !tbaa !24
  br label %bb18
bb75:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteLoopCopy(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l16 = alloca ptr
  %l18 = alloca i64
  %l24 = alloca ptr
  %l33 = alloca %"compiler/typed:Local"
  %l35 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l45 = alloca %"compiler/typed:Local"
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i32
  %l62 = alloca ptr
  %l63 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l76 = alloca i64
  %l79 = alloca i1
  %l88 = alloca %"compiler/typed:Local"
  %l91 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca i32
  %l103 = alloca ptr
  %l105 = alloca i64
  %l108 = alloca i1
  %l117 = alloca %"compiler/typed:Local"
  %l120 = alloca i1
  %l123 = alloca i1
  %l128 = alloca ptr
  %l137 = alloca %"compiler/typed:Local"
  %l139 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l142 = alloca i64
  %l144 = alloca i64
  %l145 = alloca { i64, ptr }
  %l147 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i64
  %l157 = alloca i64
  %l158 = alloca %"compiler/source:Span"
  %l162 = alloca %"compiler/msgs:Msg"
  %l163 = alloca ptr
  %l172 = alloca %"compiler/typed:Local"
  %l174 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i64
  %l183 = alloca i64
  %l184 = alloca %"compiler/source:Span"
  %l186 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store ptr %t6, ptr %l16
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l16, !tbaa !29
  %t9 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v1, ptr %t7)
  store i64 %t9, ptr %l18
  br label %bb2
bb2:
  %t10 = load i64, ptr %l18, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/generic:Program", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 3
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l24, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 25
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb6, label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_963cba883dc4bd20_64c99da4a40e3f44)
  unreachable
bb7:
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/scope:Scoper", ptr %t32, i32 0, i32 25
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t35, i32 0, i32 7
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t38, i64 %t39)
  store %"compiler/typed:Local" %t42, ptr %l33
  br label %bb9
bb9:
  %t43 = getelementptr %"compiler/typed:Local", ptr %l33, i32 0, i32 0
  %t44 = load i32, ptr %t43, !tbaa !23
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t47 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t45, i32 %t44)
  store { i64, ptr } %t47, ptr %l35
  br label %bb10
bb10:
  %t48 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t48, ptr %l4, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l36, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/scope:Scoper", ptr %t50, i32 0, i32 25
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_91fdca4bfcfaef3f_360ec22200b0b313)
  unreachable
bb12:
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/scope:Scoper", ptr %t57, i32 0, i32 25
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 7
  %t64 = load i64, ptr %l3, !tbaa !24
  %t67 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t63, i64 %t64)
  store %"compiler/typed:Local" %t67, ptr %l45
  br label %bb14
bb14:
  %t68 = getelementptr %"compiler/typed:Local", ptr %l45, i32 0, i32 1
  %t69 = load %"compiler/source:Span", ptr %t68
  %t70 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t74 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v0, ptr %t71, %"compiler/source:Span" %t69, { i64, ptr } %t70)
  store %"compiler/source:Span" %t74, ptr %l48
  br label %bb15
bb15:
  %t75 = load %"compiler/source:Span", ptr %l48
  store %"compiler/source:Span" %t75, ptr %l5
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l49, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t76, ptr %l50, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l51, !tbaa !24
  %t79 = load i64, ptr %l51, !tbaa !24
  %t80 = mul i64 %t79, 1
  %t81 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t80)
  %t82 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  store { i64, ptr } %t83, ptr %l52, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = load i64, ptr %l51, !tbaa !24
  %t89 = mul i64 %t88, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t85, ptr %t87, i64 %t89, i1 false)
  %t90 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t90, ptr %l6, !tbaa !27
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/scope:Scoper", ptr %t91, i32 0, i32 42
  %t94 = load i64, ptr %l3, !tbaa !24
  %t97 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t93, i64 %t94)
  %t98 = extractvalue { i32, ptr } %t97, 1
  %t99 = extractvalue { i32, ptr } %t97, 0
  store i32 %t99, ptr %l58
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb17, label %ok.101, !prof !99
ok.101:
  store ptr %t98, ptr %l57
  br label %bb16
bb16:
  %t102 = load ptr, ptr %l57, !tbaa !29
  store ptr %t102, ptr %l53, !tbaa !29
  br label %bb19
bb17:
  br label %bb18
bb18:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l53, !tbaa !29
  br label %bb19
bb19:
  %t103 = load ptr, ptr %l53, !tbaa !29
  store ptr %t103, ptr %l7, !tbaa !29
  %t104 = load ptr, ptr %l7, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb20, label %bb21
bb20:
  %t110 = load ptr, ptr %l7, !tbaa !29
  store ptr %t110, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t111 = load ptr, ptr %l62, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb22, label %bb23
bb21:
  br label %bb86
bb22:
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = load i64, ptr %t114
  %t117 = icmp eq i64 %t115, 2
  store i1 %t117, ptr %l63, !tbaa !21
  br label %bb23
bb23:
  %t118 = load i1, ptr %l63, !tbaa !21
  br i1 %t118, label %bb24, label %bb25
bb24:
  %t119 = load ptr, ptr %l7, !tbaa !29
  %t121 = getelementptr { i64, [5 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t121, i32 0, i32 2
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l8, !tbaa !29
  br label %bb26
bb25:
  br label %bb80
bb26:
  %t125 = load ptr, ptr %l8, !tbaa !29
  store ptr %t125, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t126 = load ptr, ptr %l68, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb27, label %bb28
bb27:
  %t129 = load ptr, ptr %l68, !tbaa !29
  %t130 = load i64, ptr %t129
  %t132 = icmp eq i64 %t130, 4
  store i1 %t132, ptr %l69, !tbaa !21
  br label %bb28
bb28:
  %t133 = load i1, ptr %l69, !tbaa !21
  br i1 %t133, label %bb29, label %bb30
bb29:
  %t134 = load ptr, ptr %l8, !tbaa !29
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 2
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l9, !tbaa !29
  br label %bb31
bb30:
  br label %bb74
bb31:
  %t140 = load ptr, ptr %l9, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Elem", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = call i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %t143)
  store i64 %t145, ptr %l76
  br label %bb32
bb32:
  %t146 = load i64, ptr %l76, !tbaa !24
  store i64 %t146, ptr %l10, !tbaa !24
  store ptr null, ptr %l11, !tbaa !29
  %t147 = load i64, ptr %l10, !tbaa !24
  %t149 = icmp sge i64 %t147, 0
  br i1 %t149, label %bb33, label %bb34
bb33:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/scope:Scoper", ptr %t151, i32 0, i32 25
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  br i1 %t156, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb39
bb35:
  call void @__olang_check_failed(ptr @olang_loc_540f6a9ea70b2c8e_44714d47ed7a19d2)
  unreachable
bb36:
  br label %bb37
bb37:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/scope:Scoper", ptr %t158, i32 0, i32 25
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Body", ptr %t161, i32 0, i32 7
  %t165 = load i64, ptr %l10, !tbaa !24
  %t168 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t164, i64 %t165)
  store %"compiler/typed:Local" %t168, ptr %l88
  br label %bb38
bb38:
  %t169 = getelementptr %"compiler/typed:Local", ptr %l88, i32 0, i32 4
  %t170 = load i32, ptr %t169
  %t172 = trunc i64 3 to i32
  %t173 = icmp eq i32 %t170, %t172
  store i1 %t173, ptr %l79, !tbaa !21
  br label %bb39
bb39:
  %t175 = load i1, ptr %l79, !tbaa !21
  br i1 %t175, label %bb40, label %bb41
bb40:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/scope:Scoper", ptr %t176, i32 0, i32 42
  %t179 = load i64, ptr %l10, !tbaa !24
  %t182 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t178, i64 %t179)
  %t183 = extractvalue { i32, ptr } %t182, 1
  %t184 = extractvalue { i32, ptr } %t182, 0
  store i32 %t184, ptr %l96
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb43, label %ok.186, !prof !99
ok.186:
  store ptr %t183, ptr %l95
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t187 = load ptr, ptr %l95, !tbaa !29
  store ptr %t187, ptr %l91, !tbaa !29
  br label %bb45
bb43:
  br label %bb44
bb44:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l91, !tbaa !29
  br label %bb45
bb45:
  %t188 = load ptr, ptr %l91, !tbaa !29
  store ptr %t188, ptr %l11, !tbaa !29
  br label %bb46
bb46:
  store i64 -1, ptr %l12, !tbaa !24
  %t189 = load ptr, ptr %l11, !tbaa !29
  %t191 = icmp eq ptr %t189, null
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb47, label %bb48
bb47:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l11, !tbaa !29
  %t200 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v0, ptr %t195, ptr %t196)
  store ptr %t200, ptr %l103
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t201 = load ptr, ptr %l103, !tbaa !29
  %t203 = call i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %t201)
  store i64 %t203, ptr %l105
  br label %bb50
bb50:
  %t204 = load i64, ptr %l105, !tbaa !24
  store i64 %t204, ptr %l12, !tbaa !24
  br label %bb51
bb51:
  %t205 = load i64, ptr %l12, !tbaa !24
  %t207 = icmp sge i64 %t205, 0
  br i1 %t207, label %bb52, label %bb53
bb52:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/scope:Scoper", ptr %t209, i32 0, i32 25
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = icmp eq ptr %t212, null
  br i1 %t214, label %bb54, label %bb55
bb53:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb58
bb54:
  call void @__olang_check_failed(ptr @olang_loc_64a11eda2e926835_fc7221612b7da3f9)
  unreachable
bb55:
  br label %bb56
bb56:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/scope:Scoper", ptr %t216, i32 0, i32 25
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Body", ptr %t219, i32 0, i32 7
  %t223 = load i64, ptr %l12, !tbaa !24
  %t226 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t222, i64 %t223)
  store %"compiler/typed:Local" %t226, ptr %l117
  br label %bb57
bb57:
  %t227 = getelementptr %"compiler/typed:Local", ptr %l117, i32 0, i32 4
  %t228 = load i32, ptr %t227
  %t230 = trunc i64 1 to i32
  %t231 = icmp eq i32 %t228, %t230
  store i1 %t231, ptr %l108, !tbaa !21
  br label %bb58
bb58:
  %t233 = load i1, ptr %l108, !tbaa !21
  br i1 %t233, label %bb59, label %bb60
bb59:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i64, ptr %l12, !tbaa !24
  %t238 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %t234, i64 %t235)
  store i1 %t238, ptr %l123
  br label %bb61
bb60:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb62
bb61:
  %t239 = load i1, ptr %l123, !tbaa !21
  %t240 = xor i1 %t239, true
  store i1 %t240, ptr %l120, !tbaa !21
  br label %bb62
bb62:
  %t242 = load i1, ptr %l120, !tbaa !21
  br i1 %t242, label %bb63, label %bb64
bb63:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/scope:Scoper", ptr %t243, i32 0, i32 0
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t248 = getelementptr %"compiler/generic:Program", ptr %t246, i32 0, i32 0
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = getelementptr %"compiler/load:Loader", ptr %t249, i32 0, i32 3
  %t252 = load ptr, ptr %t251, !tbaa !29
  store ptr %t252, ptr %l128, !tbaa !29
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/scope:Scoper", ptr %t253, i32 0, i32 25
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = icmp eq ptr %t256, null
  br i1 %t258, label %bb65, label %bb66
bb64:
  br label %bb73
bb65:
  call void @__olang_check_failed(ptr @olang_loc_64a11eda2e926835_fc7221612b7da3f9)
  unreachable
bb66:
  br label %bb67
bb67:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/scope:Scoper", ptr %t260, i32 0, i32 25
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t266 = getelementptr %"compiler/typed:Body", ptr %t263, i32 0, i32 7
  %t267 = load i64, ptr %l12, !tbaa !24
  %t270 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t266, i64 %t267)
  store %"compiler/typed:Local" %t270, ptr %l137
  br label %bb68
bb68:
  %t271 = getelementptr %"compiler/typed:Local", ptr %l137, i32 0, i32 0
  %t272 = load i32, ptr %t271, !tbaa !23
  %t273 = load ptr, ptr %l128, !tbaa !29
  %t275 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t273, i32 %t272)
  store { i64, ptr } %t275, ptr %l139
  br label %bb69
bb69:
  %t276 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t276, ptr %l140, !tbaa !27
  %t277 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t277, 0
  %t279 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 0
  store i64 %t280, ptr %l142, !tbaa !24
  %t282 = load i64, ptr %l142, !tbaa !24
  %t283 = icmp eq i64 %t278, %t282
  br i1 %t283, label %bb70, label %bb71
bb70:
  %t285 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = load i64, ptr %l142, !tbaa !24
  %t290 = mul i64 %t289, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t286, ptr %t288, i64 %t290, i1 false)
  br label %bb72
bb71:
  %t291 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t291, 0
  store i64 %t292, ptr %l144, !tbaa !24
  %t293 = load i64, ptr %l144, !tbaa !24
  %t294 = mul i64 %t293, 1
  %t295 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t294)
  %t296 = insertvalue { i64, ptr } undef, i64 %t293, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  store { i64, ptr } %t297, ptr %l145, !tbaa !27
  %t298 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = load i64, ptr %l144, !tbaa !24
  %t303 = mul i64 %t302, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t299, ptr %t301, i64 %t303, i1 false)
  %t304 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t304, ptr %l6, !tbaa !27
  br label %bb72
bb72:
  br label %bb73
bb73:
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_f36ec553cccc6d8b_49e0ae301a30aec7)
  unreachable
bb79:
  br label %bb85
bb80:
  br i1 true, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_3ac591dbc49e034a_5e5353de6850ba66)
  unreachable
bb85:
  br label %bb86
bb86:
  %t305 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t307 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t305, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t307, ptr %l147
  br label %bb87
bb87:
  %t308 = load i1, ptr %l147, !tbaa !21
  %t309 = xor i1 %t308, true
  br i1 %t309, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s10
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l149, !tbaa !29
  %t312 = load i64, ptr %l1, !tbaa !24
  store i64 %t312, ptr %l150, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/scope:Scoper", ptr %t313, i32 0, i32 25
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t318 = icmp eq ptr %t316, null
  br i1 %t318, label %bb90, label %bb91
bb89:
  %t320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t320, ptr %l163, !tbaa !29
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/scope:Scoper", ptr %t321, i32 0, i32 25
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t326 = icmp eq ptr %t324, null
  br i1 %t326, label %bb95, label %bb96
bb90:
  call void @__olang_check_failed(ptr @olang_loc_f1a9adfa27cda772_3c6bd3db0db08dee)
  unreachable
bb91:
  br label %bb92
bb92:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/scope:Scoper", ptr %t328, i32 0, i32 25
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t334 = getelementptr %"compiler/typed:Body", ptr %t331, i32 0, i32 3
  %t335 = load i64, ptr %t334, !tbaa !24
  store i64 %t335, ptr %l157, !tbaa !24
  %t336 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t336, ptr %l158
  %t337 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t338 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t343 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLoopCopy(ptr %v0, ptr %s0, ptr %s0, ptr %s10, { i64, ptr } %t337, { i64, ptr } %t338, { i64, ptr } %t339)
  store %"compiler/msgs:Msg" %t343, ptr %l162
  br label %bb93
bb93:
  %t344 = load ptr, ptr %l149, !tbaa !29
  %t345 = load i64, ptr %l150, !tbaa !24
  %t346 = load i64, ptr %l157, !tbaa !24
  %t347 = load %"compiler/source:Span", ptr %l158
  %t348 = load %"compiler/msgs:Msg", ptr %l162
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s10, ptr %t344, i64 %t345, i64 %t346, %"compiler/source:Span" %t347, %"compiler/msgs:Msg" %t348)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s10)
  br label %bb108
bb95:
  call void @__olang_check_failed(ptr @olang_loc_52f8221627bf3e99_4756b04755d4c995)
  unreachable
bb96:
  br label %bb97
bb97:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/scope:Scoper", ptr %t349, i32 0, i32 25
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Body", ptr %t352, i32 0, i32 7
  %t356 = load i64, ptr %l3, !tbaa !24
  %t359 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t355, i64 %t356)
  store %"compiler/typed:Local" %t359, ptr %l172
  br label %bb98
bb98:
  %t360 = getelementptr %"compiler/typed:Local", ptr %l172, i32 0, i32 2
  %t361 = load i32, ptr %t360, !tbaa !23
  %t362 = load ptr, ptr %l163, !tbaa !29
  %t364 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t362, i32 %t361)
  store i1 %t364, ptr %l174
  br label %bb99
bb99:
  %t365 = load i1, ptr %l174, !tbaa !21
  br i1 %t365, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s12
  %t366 = load ptr, ptr %l0, !tbaa !29
  store ptr %t366, ptr %l175, !tbaa !29
  %t367 = load i64, ptr %l1, !tbaa !24
  store i64 %t367, ptr %l176, !tbaa !24
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = getelementptr %"compiler/scope:Scoper", ptr %t368, i32 0, i32 25
  %t371 = load ptr, ptr %t370, !tbaa !29
  %t373 = icmp eq ptr %t371, null
  br i1 %t373, label %bb102, label %bb103
bb101:
  br label %bb107
bb102:
  call void @__olang_check_failed(ptr @olang_loc_a5b27f3bb1762b98_6a8daa3c154ac73c)
  unreachable
bb103:
  br label %bb104
bb104:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/scope:Scoper", ptr %t375, i32 0, i32 25
  %t378 = load ptr, ptr %t377, !tbaa !29
  %t381 = getelementptr %"compiler/typed:Body", ptr %t378, i32 0, i32 3
  %t382 = load i64, ptr %t381, !tbaa !24
  store i64 %t382, ptr %l183, !tbaa !24
  %t383 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t383, ptr %l184
  %t384 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t386 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLoopCopyLent(ptr %v0, ptr %s12, { i64, ptr } %t384)
  store %"compiler/msgs:Msg" %t386, ptr %l186
  br label %bb105
bb105:
  %t387 = load ptr, ptr %l175, !tbaa !29
  %t388 = load i64, ptr %l176, !tbaa !24
  %t389 = load i64, ptr %l183, !tbaa !24
  %t390 = load %"compiler/source:Span", ptr %l184
  %t391 = load %"compiler/msgs:Msg", ptr %l186
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %s12, ptr %t387, i64 %t388, i64 %t389, %"compiler/source:Span" %t390, %"compiler/msgs:Msg" %t391)
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s12)
  br label %bb107
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l1 = alloca ptr
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t17 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocStmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %t10, i64 0, i64 %a2, i1 %a3)
  store i1 %t17, ptr %l12
  br label %bb4
bb4:
  %t18 = load i1, ptr %l12, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonFrameAt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l12 = alloca { i64, ptr }
  %t28 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp sge i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 30
  %t11 = getelementptr %"compiler/typed:Plan", ptr %t10, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t17 = icmp slt i64 %t7, %t14
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %t20, i32 0, i32 30
  %t23 = getelementptr %"compiler/typed:Plan", ptr %t22, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l12, !tbaa !27
  %t25 = load i32, ptr %l1, !tbaa !23
  %t27 = sext i32 %t25 to i64
  store { i64, [1 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 0
  store i64 5, ptr %t29
  %t30 = load { i64, [1 x i64] }, ptr %t28
  %t33 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i64 %t27
  store { i64, [1 x i64] } %t30, ptr %t35
  br label %bb6
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonlyCalled(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l12 = alloca %"compiler/typed:Local"
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_b076c1f6c97c7ed4_fcdcfd5688cdce70)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %t15)
  store %"compiler/typed:Local" %t18, ptr %l12
  br label %bb4
bb4:
  %t19 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 4
  %t20 = load i32, ptr %t19
  %t22 = trunc i64 6 to i32
  %t23 = icmp eq i32 %t20, %t22
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l3, !tbaa !24
  %t34 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocStmts(ptr %v0, ptr %v1, ptr %t26, { i64, ptr } %a1, i64 %a2, i64 %t29, i1 false)
  store i1 %t34, ptr %l20
  br label %bb8
bb8:
  %t35 = load i1, ptr %l20, !tbaa !21
  store i1 %t35, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca ptr
  %l28 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca ptr
  %l43 = alloca i1
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca ptr
  %l55 = alloca i1
  %l62 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca ptr
  %l74 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca ptr
  %l97 = alloca i1
  %l102 = alloca %"compiler/source:Span"
  %l103 = alloca ptr
  %l104 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca i1
  %l119 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l127 = alloca i64
  %l129 = alloca %"compiler/source:Span"
  %l130 = alloca %"compiler/source:Span"
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store ptr %t6, ptr %l16
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l16, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t9 = load ptr, ptr %l17, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l17, !tbaa !29
  %t13 = load i64, ptr %t12
  %t15 = icmp eq i64 %t13, 5
  store i1 %t15, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l18, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Promote", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t30 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  store %"compiler/source:Span" %t30, ptr %l26
  br label %bb7
bb7:
  %t31 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t31, ptr %rv
  br label %ret
bb8:
  %t32 = load ptr, ptr %l2, !tbaa !29
  store ptr %t32, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t33 = load ptr, ptr %l27, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l27, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 6
  store i1 %t39, ptr %l28, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l28, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 0
  %t45 = load %"compiler/source:Span", ptr %t44
  store %"compiler/source:Span" %t45, ptr %l4
  br label %bb17
bb12:
  %t47 = load ptr, ptr %l2, !tbaa !29
  store ptr %t47, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t48 = load ptr, ptr %l33, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load ptr, ptr %l33, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 7
  store i1 %t54, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t55 = load i1, ptr %l34, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 0
  %t60 = load %"compiler/source:Span", ptr %t59
  store %"compiler/source:Span" %t60, ptr %l4
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l4
  %t66 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enameSpan(ptr %v0, ptr %t62, %"compiler/source:Span" %t63)
  store %"compiler/source:Span" %t66, ptr %l41
  br label %bb18
bb18:
  %t67 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t67, ptr %rv
  br label %ret
bb19:
  %t68 = load ptr, ptr %l2, !tbaa !29
  store ptr %t68, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t69 = load ptr, ptr %l42, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t73 = load i64, ptr %t72
  %t75 = icmp eq i64 %t73, 10
  store i1 %t75, ptr %l43, !tbaa !21
  br label %bb21
bb21:
  %t76 = load i1, ptr %l43, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t79, i32 0, i32 0
  %t81 = load %"compiler/source:Span", ptr %t80
  store %"compiler/source:Span" %t81, ptr %l5
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l6, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l5
  %t91 = load ptr, ptr %l6, !tbaa !29
  %t95 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esliceAt(ptr %v0, ptr %v1, ptr %t89, %"compiler/source:Span" %t90, ptr %t91)
  store %"compiler/source:Span" %t95, ptr %l53
  br label %bb25
bb25:
  %t96 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t96, ptr %rv
  br label %ret
bb26:
  %t97 = load ptr, ptr %l2, !tbaa !29
  store ptr %t97, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t98 = load ptr, ptr %l54, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb27, label %bb28
bb27:
  %t101 = load ptr, ptr %l54, !tbaa !29
  %t102 = load i64, ptr %t101
  %t104 = icmp eq i64 %t102, 11
  store i1 %t104, ptr %l55, !tbaa !21
  br label %bb28
bb28:
  %t105 = load i1, ptr %l55, !tbaa !21
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  %t109 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t108, i32 0, i32 0
  %t110 = load %"compiler/source:Span", ptr %t109
  store %"compiler/source:Span" %t110, ptr %l7
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t114, i32 0, i32 2
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l8, !tbaa !29
  br label %bb31
bb30:
  br label %bb38
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l62, !tbaa !29
  %t119 = load ptr, ptr %l8, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Cond", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  br i1 %t124, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_8680c8bf7a40147c_d650a7d3d4e83170)
  unreachable
bb33:
  br label %bb34
bb34:
  %t126 = load ptr, ptr %l8, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Cond", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t129)
  store %"compiler/source:Span" %t131, ptr %l68
  br label %bb35
bb35:
  %t132 = getelementptr %"compiler/source:Span", ptr %l68, i32 0, i32 1
  %t133 = load i32, ptr %t132, !tbaa !23
  %t134 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t135 = load i32, ptr %t134, !tbaa !23
  %t138 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t133, i32 %t135)
  store %"compiler/source:Span" %t138, ptr %l71
  br label %bb36
bb36:
  %t139 = load ptr, ptr %l62, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l71
  %t141 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %s4, ptr %t139, %"compiler/source:Span" %t140, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store %"compiler/source:Span" %t141, ptr %l72
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  %t142 = load %"compiler/source:Span", ptr %l72
  store %"compiler/source:Span" %t142, ptr %rv
  br label %ret
bb38:
  %t143 = load ptr, ptr %l2, !tbaa !29
  store ptr %t143, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t144 = load ptr, ptr %l73, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb39, label %bb40
bb39:
  %t147 = load ptr, ptr %l73, !tbaa !29
  %t148 = load i64, ptr %t147
  %t150 = icmp eq i64 %t148, 2
  store i1 %t150, ptr %l74, !tbaa !21
  br label %bb40
bb40:
  %t151 = load i1, ptr %l74, !tbaa !21
  br i1 %t151, label %bb41, label %bb42
bb41:
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t154, i32 0, i32 0
  %t156 = load %"compiler/source:Span", ptr %t155
  store %"compiler/source:Span" %t156, ptr %l9
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr { i64, [5 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t160, i32 0, i32 2
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l10, !tbaa !29
  br label %bb47
bb42:
  %t164 = load ptr, ptr %l2, !tbaa !29
  store ptr %t164, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t165 = load ptr, ptr %l81, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb43, label %bb44
bb43:
  %t168 = load ptr, ptr %l81, !tbaa !29
  %t169 = load i64, ptr %t168
  %t171 = icmp eq i64 %t169, 3
  store i1 %t171, ptr %l82, !tbaa !21
  br label %bb44
bb44:
  %t172 = load i1, ptr %l82, !tbaa !21
  br i1 %t172, label %bb45, label %bb46
bb45:
  %t173 = load ptr, ptr %l2, !tbaa !29
  %t175 = getelementptr { i64, [5 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t175, i32 0, i32 0
  %t177 = load %"compiler/source:Span", ptr %t176
  store %"compiler/source:Span" %t177, ptr %l9
  %t179 = load ptr, ptr %l2, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 2
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l10, !tbaa !29
  br label %bb47
bb46:
  br label %bb86
bb47:
  %t185 = load ptr, ptr %l10, !tbaa !29
  store ptr %t185, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t186 = load ptr, ptr %l89, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb48, label %bb49
bb48:
  %t189 = load ptr, ptr %l89, !tbaa !29
  %t190 = load i64, ptr %t189
  %t192 = icmp eq i64 %t190, 3
  store i1 %t192, ptr %l90, !tbaa !21
  br label %bb49
bb49:
  %t193 = load i1, ptr %l90, !tbaa !21
  br i1 %t193, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l9
  %t198 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastName(ptr %v0, ptr %t194, %"compiler/source:Span" %t195)
  store %"compiler/source:Span" %t198, ptr %l95
  br label %bb53
bb53:
  %t199 = load %"compiler/source:Span", ptr %l95
  store %"compiler/source:Span" %t199, ptr %rv
  br label %ret
bb54:
  %t200 = load ptr, ptr %l10, !tbaa !29
  store ptr %t200, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t201 = load ptr, ptr %l96, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb55, label %bb56
bb55:
  %t204 = load ptr, ptr %l96, !tbaa !29
  %t205 = load i64, ptr %t204
  %t207 = icmp eq i64 %t205, 4
  store i1 %t207, ptr %l97, !tbaa !21
  br label %bb56
bb56:
  %t208 = load i1, ptr %l97, !tbaa !21
  br i1 %t208, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l9
  %t213 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastBracket(ptr %v0, ptr %t209, %"compiler/source:Span" %t210)
  store %"compiler/source:Span" %t213, ptr %l102
  br label %bb60
bb60:
  %t214 = load %"compiler/source:Span", ptr %l102
  store %"compiler/source:Span" %t214, ptr %rv
  br label %ret
bb61:
  %t215 = load ptr, ptr %l10, !tbaa !29
  store ptr %t215, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t216 = load ptr, ptr %l103, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb62, label %bb63
bb62:
  %t219 = load ptr, ptr %l103, !tbaa !29
  %t220 = load i64, ptr %t219
  %t222 = icmp eq i64 %t220, 2
  store i1 %t222, ptr %l104, !tbaa !21
  br label %bb63
bb63:
  %t223 = load i1, ptr %l104, !tbaa !21
  br i1 %t223, label %bb64, label %bb65
bb64:
  %t224 = load ptr, ptr %l10, !tbaa !29
  %t226 = getelementptr { i64, [4 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t226, i32 0, i32 2
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l11, !tbaa !29
  br label %bb66
bb65:
  br label %bb80
bb66:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l11, !tbaa !29
  %t235 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t230, ptr %t231)
  store ptr %t235, ptr %l112
  br label %bb67
bb67:
  %t236 = load ptr, ptr %l112, !tbaa !29
  store ptr %t236, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t238 = load ptr, ptr %l113, !tbaa !29
  %t239 = icmp ne ptr %t238, null
  br i1 %t239, label %bb68, label %bb69
bb68:
  %t241 = load ptr, ptr %l113, !tbaa !29
  %t242 = load i64, ptr %t241
  %t244 = icmp eq i64 %t242, 10
  store i1 %t244, ptr %l114, !tbaa !21
  br label %bb69
bb69:
  %t245 = load i1, ptr %l114, !tbaa !21
  br i1 %t245, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load ptr, ptr %l11, !tbaa !29
  %t250 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t246, ptr %t247)
  store %"compiler/source:Span" %t250, ptr %l119
  br label %bb73
bb73:
  %t251 = load %"compiler/source:Span", ptr %l119
  store %"compiler/source:Span" %t251, ptr %rv
  br label %ret
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_22d8393d4f188012_8c9f9e39cb427896)
  unreachable
bb79:
  br label %bb85
bb80:
  br i1 true, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_7213214fb222d0c9_1eae7674ed2401ad)
  unreachable
bb85:
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_7794e183659425f8_898d85cb25e621fc)
  unreachable
bb91:
  %t252 = load ptr, ptr %l0, !tbaa !29
  store ptr %t252, ptr %l120, !tbaa !29
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/scope:Scoper", ptr %t253, i32 0, i32 25
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = icmp eq ptr %t256, null
  br i1 %t258, label %bb92, label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_2d6fa2178670cc38_6a7a96bf0e7e73f4)
  unreachable
bb93:
  br label %bb94
bb94:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/scope:Scoper", ptr %t260, i32 0, i32 25
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t266 = getelementptr %"compiler/typed:Body", ptr %t263, i32 0, i32 3
  %t267 = load i64, ptr %t266, !tbaa !24
  store i64 %t267, ptr %l127, !tbaa !24
  %t268 = load ptr, ptr %l2, !tbaa !29
  %t270 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t268)
  store %"compiler/source:Span" %t270, ptr %l129
  br label %bb95
bb95:
  %t271 = load ptr, ptr %l120, !tbaa !29
  %t272 = load i64, ptr %l127, !tbaa !24
  %t273 = load %"compiler/source:Span", ptr %l129
  %t274 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t271, i64 %t272, %"compiler/source:Span" %t273)
  store %"compiler/source:Span" %t274, ptr %l130
  br label %bb96
bb96:
  %t275 = load %"compiler/source:Span", ptr %l130
  store %"compiler/source:Span" %t275, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoutside(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/typed:Local"
  %l11 = alloca %"compiler/typed:Local"
  %l14 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_623296b25c4a2534_fd3f86d02d068538)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 7
  %t18 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t14, i64 %a1)
  store %"compiler/typed:Local" %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = load %"compiler/typed:Local", ptr %l11
  store %"compiler/typed:Local" %t19, ptr %l2
  %t20 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t21 = load i32, ptr %t20
  %t23 = trunc i64 0 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t26 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t27 = load i32, ptr %t26
  %t29 = trunc i64 5 to i32
  %t30 = icmp eq i32 %t27, %t29
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t32 = load i1, ptr %l14, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/scope:Scoper", ptr %t34, i32 0, i32 25
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb11, label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_954f6d28b3a52ac3_ffd2f75d7c0d3157)
  unreachable
bb12:
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/scope:Scoper", ptr %t41, i32 0, i32 25
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/scope:Scoper", ptr %t45, i32 0, i32 114
  %t48 = load i32, ptr %t47, !tbaa !23
  %t49 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 3
  %t50 = load i32, ptr %t49, !tbaa !23
  %t54 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %t44, i32 %t48, i32 %t50)
  store i1 %t54, ptr %l26
  br label %bb14
bb14:
  %t55 = load i1, ptr %l26, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eownIntoResult(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l18 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_8238268b26f31dac_815f599ed0aacad8)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 1
  %t15 = load { i64, [2 x i64] }, ptr %t14
  %t19 = extractvalue { i64, [2 x i64] } %t15, 0
  %t20 = icmp eq i64 %t19, 1
  br i1 %t20, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_aa39aa4c0e664ec2_f7b48f4e1663008e)
  unreachable
bb12:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t23, i32 0, i32 39
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb13, label %bb14
bb13:
  %t30 = load { i64, [2 x i64] }, ptr %l2
  %t32 = extractvalue { i64, [2 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 2
  br i1 %t33, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb18
bb15:
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t36 = getelementptr { i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 39
  %t41 = load i64, ptr %t40, !tbaa !24
  %t44 = icmp eq i64 %t37, %t41
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb17
bb17:
  %t46 = load i1, ptr %l21, !tbaa !21
  store i1 %t46, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t47 = load i1, ptr %l18, !tbaa !21
  br i1 %t47, label %bb19, label %bb20
bb19:
  %t48 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t49 = getelementptr { i64 }, ptr %t48, i32 0, i32 0
  %t50 = load i64, ptr %t49
  store i64 %t50, ptr %l4, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisBlock(ptr %v0, ptr %t52, { i64, [2 x i64] } %a1)
  store i1 %t56, ptr %l30
  br label %bb21
bb20:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb22
bb21:
  %t57 = load i1, ptr %l30, !tbaa !21
  store i1 %t57, ptr %l26, !tbaa !21
  br label %bb22
bb22:
  %t58 = load i1, ptr %l26, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamIndex(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l48 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 25
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_f4a3544f2707870_d9666a31439b8584)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 25
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 5
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l15
  br label %bb4
bb4:
  %t17 = load i64, ptr %l15, !tbaa !24
  store i64 %t17, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb10
bb7:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l22, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l22, !tbaa !24
  store i64 %t44, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  %t45 = load i64, ptr %l19, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb12, label %bb13
bb12:
  br label %bb23
bb13:
  br label %bb14
bb14:
  %t54 = load i64, ptr %l2, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l7, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/scope:Scoper", ptr %t64, i32 0, i32 25
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_47b6b2aadca5a54f_c1e200e36f23f353)
  unreachable
bb16:
  br label %bb17
bb17:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/scope:Scoper", ptr %t71, i32 0, i32 25
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 5
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t77, i64 %t78)
  store i32 %t81, ptr %l48
  br label %bb18
bb18:
  %t82 = load i32, ptr %l48, !tbaa !23
  %t83 = sext i32 %t82 to i64
  %t87 = icmp eq i64 %t83, %a1
  br i1 %t87, label %bb19, label %bb20
bb19:
  %t89 = load i64, ptr %l7, !tbaa !24
  store i64 %t89, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l6, !tbaa !24
  br label %bb11
bb23:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartAdmits(ptr %v0, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l4 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l11 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l21 = alloca i32
  %l26 = alloca i64
  %l30 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i1, ptr %l2, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t3, i32 %t4)
  store i1 %t7, ptr %l7
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb8
bb3:
  %t8 = load i1, ptr %l7, !tbaa !21
  br i1 %t8, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb7
bb5:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l11
  br label %bb6
bb6:
  %t14 = load i1, ptr %l11, !tbaa !21
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t15 = load i1, ptr %l8, !tbaa !21
  store i1 %t15, ptr %l4, !tbaa !21
  br label %bb8
bb8:
  %t16 = load i1, ptr %l4, !tbaa !21
  br i1 %t16, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t18, i32 %t19)
  store i1 %t22, ptr %l15
  br label %bb12
bb12:
  %t23 = load i1, ptr %l15, !tbaa !21
  br i1 %t23, label %bb13, label %bb14
bb13:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l21
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l1, !tbaa !23
  %t44 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t40, i32 %t41)
  store i64 %t44, ptr %l26
  br label %bb16
bb16:
  %t45 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t46 = load i64, ptr %l26, !tbaa !24
  %t48 = and i64 %t46, %t45
  %t50 = icmp ne i64 %t48, 0
  %t51 = load ptr, ptr %l16, !tbaa !29
  %t52 = load i32, ptr %l21, !tbaa !23
  %t54 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsAt(ptr %v0, ptr %t51, i32 %t52, i1 %t50)
  store i1 %t54, ptr %l30
  br label %bb17
bb17:
  %t55 = load i1, ptr %l30, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i32, ptr %l1, !tbaa !23
  %t58 = load i1, ptr %l2, !tbaa !21
  %t62 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsAt(ptr %v0, ptr %t56, i32 %t57, i1 %t58)
  store i1 %t62, ptr %l34
  br label %bb19
bb19:
  %t63 = load i1, ptr %l34, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load { i64, [2 x i64] }, ptr %l2
  %t22 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %t16, ptr %t17, { i64, [2 x i64] } %t18)
  store i1 %t22, ptr %l19
  br label %bb6
bb6:
  %t23 = load i1, ptr %l19, !tbaa !21
  store i1 %t23, ptr %l9, !tbaa !21
  br label %bb51
bb7:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l20, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 4
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Elem", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t44 = load { i64, [2 x i64] }, ptr %l2
  %t48 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %t39, ptr %t43, { i64, [2 x i64] } %t44)
  store i1 %t48, ptr %l30
  br label %bb13
bb13:
  %t49 = load i1, ptr %l30, !tbaa !21
  store i1 %t49, ptr %l9, !tbaa !21
  br label %bb51
bb14:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t51 = load ptr, ptr %l31, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = load i64, ptr %t54
  %t57 = icmp eq i64 %t55, 5
  store i1 %t57, ptr %l32, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l32, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l5, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Payload", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load { i64, [2 x i64] }, ptr %l2
  %t74 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartOK(ptr %v0, ptr %v1, ptr %t65, ptr %t69, { i64, [2 x i64] } %t70)
  store i1 %t74, ptr %l41
  br label %bb20
bb20:
  %t75 = load i1, ptr %l41, !tbaa !21
  store i1 %t75, ptr %l9, !tbaa !21
  br label %bb51
bb21:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t77 = load ptr, ptr %l42, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb22, label %bb23
bb22:
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 2
  store i1 %t83, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t84 = load i1, ptr %l43, !tbaa !21
  br i1 %t84, label %bb24, label %bb25
bb24:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l6, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = load { i64, [2 x i64] }, ptr %l2
  %t98 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltOK(ptr %v0, ptr %v1, ptr %t91, ptr %t92, { i64, [2 x i64] } %t94)
  store i1 %t98, ptr %l52
  br label %bb27
bb27:
  %t99 = load i1, ptr %l52, !tbaa !21
  store i1 %t99, ptr %l9, !tbaa !21
  br label %bb51
bb28:
  %t100 = load ptr, ptr %l1, !tbaa !29
  store ptr %t100, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t101 = load ptr, ptr %l53, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb29, label %bb30
bb29:
  %t104 = load ptr, ptr %l53, !tbaa !29
  %t105 = load i64, ptr %t104
  %t107 = icmp eq i64 %t105, 6
  store i1 %t107, ptr %l54, !tbaa !21
  br label %bb30
bb30:
  %t108 = load i1, ptr %l54, !tbaa !21
  br i1 %t108, label %bb31, label %bb32
bb31:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t111, i32 0, i32 2
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l7, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l7, !tbaa !29
  %t118 = load { i64, [2 x i64] }, ptr %l2
  %t122 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltOK(ptr %v0, ptr %v1, ptr %t115, ptr %t116, { i64, [2 x i64] } %t118)
  store i1 %t122, ptr %l63
  br label %bb34
bb34:
  %t123 = load i1, ptr %l63, !tbaa !21
  store i1 %t123, ptr %l9, !tbaa !21
  br label %bb51
bb35:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t125 = load ptr, ptr %l64, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb36, label %bb37
bb36:
  %t128 = load ptr, ptr %l64, !tbaa !29
  %t129 = load i64, ptr %t128
  %t131 = icmp eq i64 %t129, 0
  store i1 %t131, ptr %l65, !tbaa !21
  br label %bb37
bb37:
  %t132 = load i1, ptr %l65, !tbaa !21
  br i1 %t132, label %bb38, label %bb39
bb38:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t135, i32 0, i32 2
  %t137 = load i32, ptr %t136
  store i32 %t137, ptr %l8, !tbaa !23
  br label %bb40
bb39:
  br label %bb46
bb40:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l70, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/scope:Scoper", ptr %t140, i32 0, i32 40
  %t143 = load i32, ptr %l8, !tbaa !23
  %t145 = sext i32 %t143 to i64
  %t148 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v0, ptr %t142, i64 %t145)
  %t149 = extractvalue { i32, ptr } %t148, 1
  %t150 = extractvalue { i32, ptr } %t148, 0
  store i32 %t150, ptr %l77
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb42, label %ok.152, !prof !99
ok.152:
  store ptr %t149, ptr %l76
  br label %bb41
bb41:
  %t153 = load ptr, ptr %l76, !tbaa !29
  store ptr %t153, ptr %l71, !tbaa !29
  br label %bb44
bb42:
  br label %bb43
bb43:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %l71, !tbaa !29
  br label %bb44
bb44:
  %t154 = load { i64, [2 x i64] }, ptr %l2
  %t155 = load ptr, ptr %l70, !tbaa !29
  %t156 = load ptr, ptr %l71, !tbaa !29
  %t158 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltOK(ptr %v0, ptr %v0, ptr %t155, ptr %t156, { i64, [2 x i64] } %t154)
  store i1 %t158, ptr %l79
  br label %bb45
bb45:
  %t159 = load i1, ptr %l79, !tbaa !21
  store i1 %t159, ptr %l9, !tbaa !21
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_eb55abbe133e6e93_c0f65549c24d0e87)
  unreachable
bb51:
  %t160 = load i1, ptr %l9, !tbaa !21
  store i1 %t160, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i64
  %l15 = alloca i64
  %l23 = alloca { i64, [2 x i64] }
  %l25 = alloca i1
  %l26 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t25 = alloca { i64, [2 x i64] }, align 8
  %t47 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp slt i64 %t5, 0
  store i1 %t7, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb5:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = add i64 %t10, %t11
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/scope:Scoper", ptr %t15, i32 0, i32 44
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l15, !tbaa !24
  %t22 = icmp sge i64 %t20, %t21
  store i1 %t22, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store { i64, [2 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 0
  store i64 0, ptr %t26
  %t27 = load { i64, [2 x i64] }, ptr %t25
  store { i64, [2 x i64] } %t27, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/scope:Scoper", ptr %t29, i32 0, i32 44
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t39 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t31, i64 %t36)
  store { i64, [2 x i64] } %t39, ptr %l23
  br label %bb11
bb11:
  %t40 = load { i64, [2 x i64] }, ptr %l23
  store { i64, [2 x i64] } %t40, ptr %l3
  %t41 = load { i64, [2 x i64] }, ptr %l3
  %t43 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t41)
  store i1 %t43, ptr %l25
  br label %bb12
bb12:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t45 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t45, ptr %l26
  br label %bb15
bb14:
  store { i64, [2 x i64] } zeroinitializer, ptr %t47
  %t48 = getelementptr { i64, [2 x i64] }, ptr %t47, i32 0, i32 0
  store i64 0, ptr %t48
  %t49 = load { i64, [2 x i64] }, ptr %t47
  store { i64, [2 x i64] } %t49, ptr %l26
  br label %bb15
bb15:
  %t51 = load { i64, [2 x i64] }, ptr %l26
  store { i64, [2 x i64] } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erecOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l17 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l55 = alloca %"compiler/typed:Local"
  %l59 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i32
  %l66 = alloca ptr
  %l67 = alloca i1
  %l77 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca i1
  %l91 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 43
  %t19 = load i32, ptr %l2, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t18, i64 %t21)
  %t25 = extractvalue { i32, i64 } %t24, 1
  %t26 = extractvalue { i32, i64 } %t24, 0
  store i32 %t26, ptr %l23
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb7, label %ok.28, !prof !99
ok.28:
  store i64 %t25, ptr %l22
  br label %bb6
bb6:
  %t29 = load i64, ptr %l22, !tbaa !24
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb9
bb9:
  %t30 = load i64, ptr %l17, !tbaa !24
  store i64 %t30, ptr %rv
  br label %ret
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t32 = load ptr, ptr %l24, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l24, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l25, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l25, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb55
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t51 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  store ptr %t51, ptr %l33
  br label %bb16
bb16:
  %t52 = load ptr, ptr %l33, !tbaa !29
  store ptr %t52, ptr %l4, !tbaa !29
  %t53 = load ptr, ptr %l4, !tbaa !29
  store ptr %t53, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t54 = load ptr, ptr %l34, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb17, label %bb18
bb17:
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load i64, ptr %t57
  %t60 = icmp eq i64 %t58, 2
  store i1 %t60, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t61 = load i1, ptr %l35, !tbaa !21
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l5, !tbaa !29
  br label %bb21
bb20:
  br label %bb50
bb21:
  %t68 = load ptr, ptr %l5, !tbaa !29
  store ptr %t68, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t69 = load ptr, ptr %l40, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb22, label %bb23
bb22:
  %t72 = load ptr, ptr %l40, !tbaa !29
  %t73 = load i64, ptr %t72
  %t75 = icmp eq i64 %t73, 0
  store i1 %t75, ptr %l41, !tbaa !21
  br label %bb23
bb23:
  %t76 = load i1, ptr %l41, !tbaa !21
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t79, i32 0, i32 2
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l6, !tbaa !23
  br label %bb26
bb25:
  br label %bb38
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/scope:Scoper", ptr %t83, i32 0, i32 25
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = icmp eq ptr %t86, null
  br i1 %t88, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_c7f09c07f504fc14_94662c6a2fc8d498)
  unreachable
bb28:
  br label %bb29
bb29:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/scope:Scoper", ptr %t90, i32 0, i32 25
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Body", ptr %t93, i32 0, i32 7
  %t97 = load i32, ptr %l6, !tbaa !23
  %t99 = sext i32 %t97 to i64
  %t102 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t96, i64 %t99)
  store %"compiler/typed:Local" %t102, ptr %l55
  br label %bb30
bb30:
  %t103 = getelementptr %"compiler/typed:Local", ptr %l55, i32 0, i32 4
  %t104 = load i32, ptr %t103
  %t106 = trunc i64 0 to i32
  %t107 = icmp eq i32 %t104, %t106
  br i1 %t107, label %bb31, label %bb32
bb31:
  store i64 -1, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 43
  %t113 = load i32, ptr %l6, !tbaa !23
  %t115 = sext i32 %t113 to i64
  %t118 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t112, i64 %t115)
  %t119 = extractvalue { i32, i64 } %t118, 1
  %t120 = extractvalue { i32, i64 } %t118, 0
  store i32 %t120, ptr %l65
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb35, label %ok.122, !prof !99
ok.122:
  store i64 %t119, ptr %l64
  br label %bb34
bb34:
  %t123 = load i64, ptr %l64, !tbaa !24
  store i64 %t123, ptr %l59, !tbaa !24
  br label %bb37
bb35:
  br label %bb36
bb36:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l59, !tbaa !24
  br label %bb37
bb37:
  %t124 = load i64, ptr %l59, !tbaa !24
  store i64 %t124, ptr %rv
  br label %ret
bb38:
  %t125 = load ptr, ptr %l5, !tbaa !29
  store ptr %t125, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t126 = load ptr, ptr %l66, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb39, label %bb40
bb39:
  %t129 = load ptr, ptr %l66, !tbaa !29
  %t130 = load i64, ptr %t129
  %t132 = icmp eq i64 %t130, 3
  store i1 %t132, ptr %l67, !tbaa !21
  br label %bb40
bb40:
  %t133 = load i1, ptr %l67, !tbaa !21
  br i1 %t133, label %bb41, label %bb42
bb41:
  %t134 = load ptr, ptr %l5, !tbaa !29
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t136, i32 0, i32 2
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l7, !tbaa !29
  %t140 = load ptr, ptr %l5, !tbaa !29
  %t142 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t142, i32 0, i32 3
  %t144 = load i64, ptr %t143
  store i64 %t144, ptr %l8, !tbaa !24
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l7, !tbaa !29
  %t148 = load i64, ptr %l8, !tbaa !24
  %t152 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldRec(ptr %v0, ptr %v1, ptr %t146, ptr %t147, i64 %t148)
  store i64 %t152, ptr %l77
  br label %bb44
bb44:
  %t153 = load i64, ptr %l77, !tbaa !24
  store i64 %t153, ptr %rv
  br label %ret
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i64 -1, ptr %rv
  br label %ret
bb49:
  call void @__olang_check_failed(ptr @olang_loc_e013e5ec68fcecba_db38ff2cf21abe4e)
  unreachable
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store i64 -1, ptr %rv
  br label %ret
bb54:
  call void @__olang_check_failed(ptr @olang_loc_63182fc37cc18751_f7db738c3fc11405)
  unreachable
bb55:
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t157 = load ptr, ptr %l80, !tbaa !29
  %t158 = icmp ne ptr %t157, null
  br i1 %t158, label %bb56, label %bb57
bb56:
  %t160 = load ptr, ptr %l80, !tbaa !29
  %t161 = load i64, ptr %t160
  %t163 = icmp eq i64 %t161, 3
  store i1 %t163, ptr %l81, !tbaa !21
  br label %bb57
bb57:
  %t164 = load i1, ptr %l81, !tbaa !21
  br i1 %t164, label %bb58, label %bb59
bb58:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr { i64, [4 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t167, i32 0, i32 2
  %t169 = load ptr, ptr %t168
  store ptr %t169, ptr %l9, !tbaa !29
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [4 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t173, i32 0, i32 3
  %t175 = load i64, ptr %t174
  store i64 %t175, ptr %l10, !tbaa !24
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l9, !tbaa !29
  %t179 = load i64, ptr %l10, !tbaa !24
  %t183 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldRec(ptr %v0, ptr %v1, ptr %t177, ptr %t178, i64 %t179)
  store i64 %t183, ptr %l91
  br label %bb61
bb61:
  %t184 = load i64, ptr %l91, !tbaa !24
  store i64 %t184, ptr %rv
  br label %ret
bb62:
  br i1 true, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store i64 -1, ptr %rv
  br label %ret
bb66:
  call void @__olang_check_failed(ptr @olang_loc_5d42891563591ec0_78209504ed027d54)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultTerm(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca ptr
  %l15 = alloca i32
  %l20 = alloca { i64, [2 x i64] }
  %l22 = alloca { i64, [2 x i64] }
  %l29 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca i64
  %l49 = alloca i64
  %l59 = alloca i32
  %l64 = alloca { i64, [2 x i64] }
  %l67 = alloca i1
  %l71 = alloca i1
  %l76 = alloca { i64, [2 x i64] }
  %l81 = alloca { i64, [2 x i64] }
  %l86 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t143 = alloca { i64, [2 x i64] }, align 8
  %t155 = alloca { i64, [2 x i64] }, align 8
  %t170 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/scope:Scoper", ptr %t7, i32 0, i32 25
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  br i1 %t12, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_17b5555e490eca40_3a72f19dfd1cef0c)
  unreachable
bb2:
  br label %bb3
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 25
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 2
  %t21 = load i32, ptr %t20, !tbaa !23
  %t22 = load ptr, ptr %l7, !tbaa !29
  %t24 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t22, i32 %t21)
  store i32 %t24, ptr %l15
  br label %bb4
bb4:
  %t25 = load i32, ptr %l15
  %t27 = trunc i64 21 to i32
  %t28 = icmp eq i32 %t25, %t27
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t32)
  store { i64, [2 x i64] } %t34, ptr %l20
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t35 = load { i64, [2 x i64] }, ptr %l20
  store { i64, [2 x i64] } %t35, ptr %rv
  br label %ret
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2egenElemTerm(ptr %v0, ptr %t36)
  store { i64, [2 x i64] } %t38, ptr %l22
  br label %bb9
bb9:
  %t39 = load { i64, [2 x i64] }, ptr %l22
  store { i64, [2 x i64] } %t39, ptr %l2
  %t40 = load { i64, [2 x i64] }, ptr %l2
  %t42 = extractvalue { i64, [2 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 0
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t47, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  store ptr %t54, ptr %l29, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %t55, i32 0, i32 25
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  br i1 %t60, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_7d1ba41a43de5df_b306ac45f9e7717b)
  unreachable
bb14:
  br label %bb15
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/scope:Scoper", ptr %t62, i32 0, i32 25
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Body", ptr %t65, i32 0, i32 2
  %t69 = load i32, ptr %t68, !tbaa !23
  %t71 = load ptr, ptr %l29, !tbaa !29
  %t74 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t71, i32 %t69, i64 %a1)
  store i64 %t74, ptr %l38
  br label %bb16
bb16:
  %t75 = load i64, ptr %l38, !tbaa !24
  store i64 %t75, ptr %l3, !tbaa !24
  %t76 = load i64, ptr %l3, !tbaa !24
  %t78 = icmp sge i64 %t76, 0
  br i1 %t78, label %bb17, label %bb18
bb17:
  %t80 = load i64, ptr %l3, !tbaa !24
  store i64 %t80, ptr %l41, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/scope:Scoper", ptr %t81, i32 0, i32 25
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb19, label %bb20
bb18:
  br label %bb39
bb19:
  call void @__olang_check_failed(ptr @olang_loc_deaf2ed7955484ae_e8df1e0ec0ac14ba)
  unreachable
bb20:
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/scope:Scoper", ptr %t88, i32 0, i32 25
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Body", ptr %t91, i32 0, i32 5
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t94)
  store i64 %t96, ptr %l49
  br label %bb22
bb22:
  %t97 = load i64, ptr %l41, !tbaa !24
  %t98 = load i64, ptr %l49, !tbaa !24
  %t99 = icmp slt i64 %t97, %t98
  br i1 %t99, label %bb23, label %bb24
bb23:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/scope:Scoper", ptr %t101, i32 0, i32 25
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb25, label %bb26
bb24:
  br label %bb38
bb25:
  call void @__olang_check_failed(ptr @olang_loc_79e16856d8fb6455_e8daf01bb6fb0841)
  unreachable
bb26:
  br label %bb27
bb27:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/scope:Scoper", ptr %t108, i32 0, i32 25
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Body", ptr %t111, i32 0, i32 5
  %t115 = load i64, ptr %l3, !tbaa !24
  %t118 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t114, i64 %t115)
  store i32 %t118, ptr %l59
  br label %bb28
bb28:
  %t119 = load i32, ptr %l59, !tbaa !23
  %t120 = sext i32 %t119 to i64
  store i64 %t120, ptr %l4, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/scope:Scoper", ptr %t122, i32 0, i32 31
  %t125 = load i64, ptr %l4, !tbaa !24
  %t128 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t124, i64 %t125)
  store { i64, [2 x i64] } %t128, ptr %l64
  br label %bb29
bb29:
  %t129 = load { i64, [2 x i64] }, ptr %l64
  %t131 = extractvalue { i64, [2 x i64] } %t129, 0
  %t132 = icmp eq i64 %t131, 0
  br i1 %t132, label %bb30, label %bb31
bb30:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/scope:Scoper", ptr %t134, i32 0, i32 33
  %t137 = load i64, ptr %l4, !tbaa !24
  %t140 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t136, i64 %t137)
  store i1 %t140, ptr %l71
  br label %bb32
bb31:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb33
bb32:
  %t141 = load i1, ptr %l71, !tbaa !21
  store i1 %t141, ptr %l67, !tbaa !21
  br label %bb33
bb33:
  %t142 = load i1, ptr %l67, !tbaa !21
  br i1 %t142, label %bb34, label %bb35
bb34:
  store { i64, [2 x i64] } zeroinitializer, ptr %t143
  %t144 = getelementptr { i64, [2 x i64] }, ptr %t143, i32 0, i32 0
  store i64 3, ptr %t144
  %t145 = load { i64, [2 x i64] }, ptr %t143
  store { i64, [2 x i64] } %t145, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/scope:Scoper", ptr %t147, i32 0, i32 31
  %t150 = load i64, ptr %l4, !tbaa !24
  %t153 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t149, i64 %t150)
  store { i64, [2 x i64] } %t153, ptr %l76
  br label %bb37
bb37:
  %t154 = load { i64, [2 x i64] }, ptr %l76
  store { i64, [2 x i64] } %t154, ptr %rv
  br label %ret
bb38:
  store { i64, [2 x i64] } zeroinitializer, ptr %t155
  %t156 = getelementptr { i64, [2 x i64] }, ptr %t155, i32 0, i32 0
  store i64 6, ptr %t156
  %t157 = load { i64, [2 x i64] }, ptr %t155
  store { i64, [2 x i64] } %t157, ptr %rv
  br label %ret
bb39:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/scope:Scoper", ptr %t159, i32 0, i32 39
  %t162 = load i64, ptr %t161, !tbaa !24
  %t164 = icmp sge i64 %t162, 0
  br i1 %t164, label %bb40, label %bb41
bb40:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/scope:Scoper", ptr %t166, i32 0, i32 39
  %t169 = load i64, ptr %t168, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t170
  %t171 = getelementptr { i64, [2 x i64] }, ptr %t170, i32 0, i32 0
  store i64 2, ptr %t171
  %t173 = insertvalue { i64 } undef, i64 %t169, 0
  %t174 = getelementptr { i64, [2 x i64] }, ptr %t170, i32 0, i32 1
  store { i64 } %t173, ptr %t174
  %t175 = load { i64, [2 x i64] }, ptr %t170
  store { i64, [2 x i64] } %t175, ptr %l81
  br label %bb43
bb41:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t177)
  store { i64, [2 x i64] } %t179, ptr %l86
  br label %bb42
bb42:
  %t180 = load { i64, [2 x i64] }, ptr %l86
  store { i64, [2 x i64] } %t180, ptr %l81
  br label %bb43
bb43:
  %t181 = load { i64, [2 x i64] }, ptr %l81
  store { i64, [2 x i64] } %t181, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eresultVarOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %a0, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t13, i32 %t14)
  store { i64, ptr } %t17, ptr %l17
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load i64, ptr %l5, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb10
bb7:
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l26, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l26, !tbaa !24
  store i64 %t49, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l23, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb12, label %bb13
bb12:
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = mul i64 %t60, %t61
  %t67 = add i64 %t59, %t64
  store i64 %t67, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i64, ptr %t72, i64 %t69
  %t74 = load i64, ptr %t73, !tbaa !34
  %t75 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t78 = icmp eq i64 %t74, %t75
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t80 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t80, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t82 = load i64, ptr %l7, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l7, !tbaa !24
  br label %bb11
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eret(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 107
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %t10, i32 0, i32 107
  store i1 true, ptr %t12, !tbaa !21
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eretValue(ptr %v0, ptr %v1, ptr %t13, %"compiler/source:Span" %a1, ptr %t15)
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i1, ptr %l3, !tbaa !21
  %t23 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 107
  store i1 %t20, ptr %t23, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l17 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlStmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28, i64 %a2)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlDrop(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/scope:Scoper", ptr %t6, i32 0, i32 97
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 97
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/scope:Scoper", ptr %t27, i32 0, i32 97
  %t30 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t29, i64 %t30, i64 -1)
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/scope:Scoper", ptr %t33, i32 0, i32 99
  store i1 true, ptr %t35, !tbaa !21
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esliceAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l19 = alloca %"compiler/source:Span"
  %l26 = alloca i1
  %l32 = alloca { i64, ptr }
  %l41 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 10
  store ptr %t3, ptr %l7, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %t4, i32 0, i32 25
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_e18696d73c32363c_a4e51a2c5acfe520)
  unreachable
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/scope:Scoper", ptr %t11, i32 0, i32 25
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l7, !tbaa !29
  %t21 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t19, i64 %t18)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l16
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l15
  br label %bb4
bb4:
  %t26 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t30 = getelementptr %"compiler/typed:Slice", ptr %a2, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t31)
  store %"compiler/source:Span" %t33, ptr %l19
  br label %bb8
bb8:
  %t34 = getelementptr %"compiler/source:Span", ptr %l19, i32 0, i32 1
  %t35 = load i32, ptr %t34, !tbaa !23
  %t37 = sext i32 %t35 to i64
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t54 = icmp slt i64 %t48, %t51
  store i1 %t54, ptr %l26, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l26, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l32, !tbaa !27
  %t60 = load i64, ptr %l4, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i8, ptr %t63, i64 %t60
  %t65 = load i8, ptr %t64, !tbaa !32
  %t67 = icmp eq i8 %t65, 91
  br i1 %t67, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load i64, ptr %l4, !tbaa !24
  %t71 = trunc i64 %t69 to i32
  %t72 = load i64, ptr %l4, !tbaa !24
  %t74 = add i64 %t72, 1
  %t76 = trunc i64 %t74 to i32
  %t79 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t71, i32 %t76)
  store %"compiler/source:Span" %t79, ptr %l41
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  %t80 = load %"compiler/source:Span", ptr %l41
  store %"compiler/source:Span" %t80, ptr %rv
  br label %ret
bb19:
  %t81 = load i64, ptr %l4, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l4, !tbaa !24
  br label %bb20
bb20:
  br label %bb9
bb21:
  %t85 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t85, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l122 = alloca ptr
  %l123 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l155 = alloca { i64, ptr }
  %l163 = alloca ptr
  %l164 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 113
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l23, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l23, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t12 = load ptr, ptr %l26, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l26, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l27, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l27, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [3 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t26, ptr %t27, i1 false)
  br label %bb12
bb12:
  br label %bb115
bb13:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t32 = load ptr, ptr %l35, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb14, label %bb15
bb14:
  %t35 = load ptr, ptr %l35, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 1
  store i1 %t38, ptr %l36, !tbaa !21
  br label %bb15
bb15:
  %t39 = load i1, ptr %l36, !tbaa !21
  br i1 %t39, label %bb16, label %bb17
bb16:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esolePlace(ptr %v0, ptr %v1, ptr %t52, ptr %t53, i1 false)
  br label %bb19
bb19:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t56, ptr %t57, i1 false)
  br label %bb20
bb20:
  br label %bb115
bb21:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t62 = load ptr, ptr %l48, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb22, label %bb23
bb22:
  %t65 = load ptr, ptr %l48, !tbaa !29
  %t66 = load i64, ptr %t65
  %t68 = icmp eq i64 %t66, 2
  store i1 %t68, ptr %l49, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l49, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr }, ptr %t72, i32 0, i32 1
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t76, ptr %t77, i1 false)
  br label %bb27
bb27:
  br label %bb115
bb28:
  %t81 = load ptr, ptr %l1, !tbaa !29
  store ptr %t81, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t82 = load ptr, ptr %l57, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb29, label %bb30
bb29:
  %t85 = load ptr, ptr %l57, !tbaa !29
  %t86 = load i64, ptr %t85
  %t88 = icmp eq i64 %t86, 3
  store i1 %t88, ptr %l58, !tbaa !21
  br label %bb30
bb30:
  %t89 = load i1, ptr %l58, !tbaa !21
  br i1 %t89, label %bb31, label %bb32
bb31:
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr }, ptr %t92, i32 0, i32 1
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb37
bb33:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l6, !tbaa !29
  %t99 = getelementptr %"compiler/typed:If", ptr %t97, i32 0, i32 0
  %t100 = load ptr, ptr %t99, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t96, ptr %t100, i1 false)
  br label %bb34
bb34:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t107 = getelementptr %"compiler/typed:If", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %t104, ptr %t108)
  br label %bb35
bb35:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t115 = getelementptr %"compiler/typed:If", ptr %t113, i32 0, i32 2
  %t116 = load ptr, ptr %t115, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %t112, ptr %t116)
  br label %bb36
bb36:
  br label %bb115
bb37:
  %t119 = load ptr, ptr %l1, !tbaa !29
  store ptr %t119, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t120 = load ptr, ptr %l74, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb38, label %bb39
bb38:
  %t123 = load ptr, ptr %l74, !tbaa !29
  %t124 = load i64, ptr %t123
  %t126 = icmp eq i64 %t124, 4
  store i1 %t126, ptr %l75, !tbaa !21
  br label %bb39
bb39:
  %t127 = load i1, ptr %l75, !tbaa !21
  br i1 %t127, label %bb40, label %bb41
bb40:
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t130, i32 0, i32 1
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l7, !tbaa !29
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t136, i32 0, i32 2
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l8, !tbaa !29
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %t140, ptr %t141)
  br label %bb43
bb43:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  br label %bb44
bb44:
  br label %bb115
bb45:
  %t149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t149, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t150 = load ptr, ptr %l87, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb46, label %bb47
bb46:
  %t153 = load ptr, ptr %l87, !tbaa !29
  %t154 = load i64, ptr %t153
  %t156 = icmp eq i64 %t154, 6
  store i1 %t156, ptr %l88, !tbaa !21
  br label %bb47
bb47:
  %t157 = load i1, ptr %l88, !tbaa !21
  br i1 %t157, label %bb48, label %bb49
bb48:
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l9, !tbaa !29
  br label %bb54
bb49:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t165 = load ptr, ptr %l93, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb50, label %bb51
bb50:
  %t168 = load ptr, ptr %l93, !tbaa !29
  %t169 = load i64, ptr %t168
  %t171 = icmp eq i64 %t169, 16
  store i1 %t171, ptr %l94, !tbaa !21
  br label %bb51
bb51:
  %t172 = load i1, ptr %l94, !tbaa !21
  br i1 %t172, label %bb52, label %bb53
bb52:
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l9, !tbaa !29
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t179, ptr %t180, i1 false)
  br label %bb55
bb55:
  br label %bb115
bb56:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t184 = load ptr, ptr %l101, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb57, label %bb58
bb57:
  %t187 = load ptr, ptr %l101, !tbaa !29
  %t188 = load i64, ptr %t187
  %t190 = icmp eq i64 %t188, 9
  store i1 %t190, ptr %l102, !tbaa !21
  br label %bb58
bb58:
  %t191 = load i1, ptr %l102, !tbaa !21
  br i1 %t191, label %bb59, label %bb60
bb59:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t194, i32 0, i32 2
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l10, !tbaa !29
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t198, ptr %t199, i1 false)
  br label %bb62
bb62:
  br label %bb115
bb63:
  %t202 = load ptr, ptr %l1, !tbaa !29
  store ptr %t202, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t203 = load ptr, ptr %l109, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb64, label %bb65
bb64:
  %t206 = load ptr, ptr %l109, !tbaa !29
  %t207 = load i64, ptr %t206
  %t209 = icmp eq i64 %t207, 10
  store i1 %t209, ptr %l110, !tbaa !21
  br label %bb65
bb65:
  %t210 = load i1, ptr %l110, !tbaa !21
  br i1 %t210, label %bb66, label %bb67
bb66:
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l11, !tbaa !29
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr { i64, [3 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t219, i32 0, i32 2
  %t221 = load ptr, ptr %t220
  store ptr %t221, ptr %l12, !tbaa !29
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t223, ptr %t224, i1 false)
  br label %bb69
bb69:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t228, ptr %t229, i1 false)
  br label %bb70
bb70:
  br label %bb115
bb71:
  %t232 = load ptr, ptr %l1, !tbaa !29
  store ptr %t232, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t233 = load ptr, ptr %l122, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb72, label %bb73
bb72:
  %t236 = load ptr, ptr %l122, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 11
  store i1 %t239, ptr %l123, !tbaa !21
  br label %bb73
bb73:
  %t240 = load i1, ptr %l123, !tbaa !21
  br i1 %t240, label %bb74, label %bb75
bb74:
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 1
  %t245 = load ptr, ptr %t244
  store ptr %t245, ptr %l13, !tbaa !29
  br label %bb80
bb75:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t248 = load ptr, ptr %l128, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb76, label %bb77
bb76:
  %t251 = load ptr, ptr %l128, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 12
  store i1 %t254, ptr %l129, !tbaa !21
  br label %bb77
bb77:
  %t255 = load i1, ptr %l129, !tbaa !21
  br i1 %t255, label %bb78, label %bb79
bb78:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l13, !tbaa !29
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %t262, ptr %t263)
  br label %bb81
bb81:
  br label %bb115
bb82:
  %t267 = load ptr, ptr %l1, !tbaa !29
  store ptr %t267, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t268 = load ptr, ptr %l137, !tbaa !29
  %t269 = icmp ne ptr %t268, null
  br i1 %t269, label %bb83, label %bb84
bb83:
  %t271 = load ptr, ptr %l137, !tbaa !29
  %t272 = load i64, ptr %t271
  %t274 = icmp eq i64 %t272, 13
  store i1 %t274, ptr %l138, !tbaa !21
  br label %bb84
bb84:
  %t275 = load i1, ptr %l138, !tbaa !21
  br i1 %t275, label %bb85, label %bb86
bb85:
  %t276 = load ptr, ptr %l1, !tbaa !29
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t276, i32 0, i32 1
  %t279 = getelementptr { %"compiler/source:Span", ptr }, ptr %t278, i32 0, i32 1
  %t280 = load ptr, ptr %t279
  store ptr %t280, ptr %l14, !tbaa !29
  br label %bb87
bb86:
  br label %bb96
bb87:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load ptr, ptr %l14, !tbaa !29
  %t285 = getelementptr %"compiler/typed:Join", ptr %t283, i32 0, i32 0
  %t286 = load ptr, ptr %t285, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %t282, ptr %t286)
  br label %bb88
bb88:
  %t290 = load ptr, ptr %l14, !tbaa !29
  %t292 = getelementptr %"compiler/typed:Join", ptr %t290, i32 0, i32 2
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  store { i64, ptr } %t293, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t295 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t295, 0
  store i64 %t297, ptr %l17, !tbaa !24
  br label %bb89
bb89:
  %t299 = load i64, ptr %l16, !tbaa !24
  %t300 = load i64, ptr %l17, !tbaa !24
  %t303 = icmp slt i64 %t299, %t300
  %t305 = xor i1 %t303, true
  br i1 %t305, label %bb90, label %bb91
bb90:
  br label %bb95
bb91:
  br label %bb92
bb92:
  %t307 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t307, ptr %l155, !tbaa !27
  %t308 = load i64, ptr %l16, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr ptr, ptr %t311, i64 %t308
  %t313 = load ptr, ptr %t312, !tbaa !39
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/typed:Clause", ptr %t313, i32 0, i32 3
  %t319 = load ptr, ptr %t318, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %t315, ptr %t319)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t322 = load i64, ptr %l16, !tbaa !24
  %t324 = add i64 %t322, 1
  store i64 %t324, ptr %l16, !tbaa !24
  br label %bb89
bb95:
  br label %bb115
bb96:
  %t326 = load ptr, ptr %l1, !tbaa !29
  store ptr %t326, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t327 = load ptr, ptr %l163, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb97, label %bb98
bb97:
  %t330 = load ptr, ptr %l163, !tbaa !29
  %t331 = load i64, ptr %t330
  %t333 = icmp eq i64 %t331, 14
  store i1 %t333, ptr %l164, !tbaa !21
  br label %bb98
bb98:
  %t334 = load i1, ptr %l164, !tbaa !21
  br i1 %t334, label %bb99, label %bb100
bb99:
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", ptr }, ptr %t337, i32 0, i32 1
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l19, !tbaa !29
  br label %bb101
bb100:
  br label %bb103
bb101:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load ptr, ptr %l19, !tbaa !29
  %t344 = getelementptr %"compiler/typed:Spawn", ptr %t342, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t341, ptr %t345, i1 true)
  br label %bb102
bb102:
  br label %bb115
bb103:
  %t349 = load ptr, ptr %l1, !tbaa !29
  store ptr %t349, ptr %l173, !tbaa !29
  store i1 false, ptr %l174, !tbaa !21
  %t350 = load ptr, ptr %l173, !tbaa !29
  %t351 = icmp ne ptr %t350, null
  br i1 %t351, label %bb104, label %bb105
bb104:
  %t353 = load ptr, ptr %l173, !tbaa !29
  %t354 = load i64, ptr %t353
  %t356 = icmp eq i64 %t354, 15
  store i1 %t356, ptr %l174, !tbaa !21
  br label %bb105
bb105:
  %t357 = load i1, ptr %l174, !tbaa !21
  br i1 %t357, label %bb106, label %bb107
bb106:
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr { i64, [3 x i64] }, ptr %t358, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", ptr }, ptr %t360, i32 0, i32 1
  %t362 = load ptr, ptr %t361
  store ptr %t362, ptr %l20, !tbaa !29
  br label %bb108
bb107:
  br label %bb110
bb108:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %t364, ptr %t365, i1 false)
  br label %bb109
bb109:
  br label %bb115
bb110:
  br i1 true, label %bb111, label %bb112
bb111:
  br label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_9b30aadb18eb277f_192cdcf64c29ca93)
  unreachable
bb115:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esomeHoldsDtor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb13
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  store i32 %t21, ptr %l6, !tbaa !23
  %t23 = load i32, ptr %l6, !tbaa !23
  %t25 = icmp ne i32 %t23, 0
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l6, !tbaa !23
  %t33 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholdsDtorIn(ptr %v0, ptr %v2, ptr %a0, i32 %t28, ptr %a2)
  store i1 %t33, ptr %l23
  br label %bb7
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb8
bb7:
  %t34 = load i1, ptr %l23, !tbaa !21
  store i1 %t34, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l19, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l4, !tbaa !24
  br label %bb1
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2espawn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca { { i64, [2 x i64] }, i1, i64 }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca %"compiler/scope:Val"
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca %"compiler/scope:Val"
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca { { i64, [2 x i64] }, i1, i64 }
  %l36 = alloca { i64, [2 x i64] }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca { { i64, [2 x i64] }, i1, i64 }
  %l42 = alloca { i64, [2 x i64] }
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca i1
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca i1
  %l54 = alloca i64
  %l57 = alloca ptr
  %l60 = alloca i64
  %l62 = alloca i32
  %l72 = alloca { i64, ptr }
  %l81 = alloca i1
  %l83 = alloca i64
  %l86 = alloca ptr
  %l88 = alloca i64
  %l89 = alloca ptr
  %l92 = alloca { i64, [2 x i64] }
  %l94 = alloca i1
  %l96 = alloca i1
  %l99 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l102 = alloca %"compiler/msgs:Msg"
  %l103 = alloca i64
  %l114 = alloca i64
  %l117 = alloca i64
  %l136 = alloca { i64, ptr }
  %l142 = alloca i32
  %l146 = alloca i1
  %l149 = alloca { { i64, [2 x i64] }, i1, i64 }
  %l153 = alloca i1
  %l155 = alloca i1
  %l159 = alloca i1
  %l165 = alloca i1
  %l168 = alloca { i64, [2 x i64] }
  %l170 = alloca i1
  %l175 = alloca { i64, [2 x i64] }
  %l177 = alloca { i64, [2 x i64] }
  %l179 = alloca i1
  %l182 = alloca i1
  %l184 = alloca i1
  %l188 = alloca i64
  %l202 = alloca { i64, ptr }
  %l210 = alloca %"compiler/scope:Val"
  %l214 = alloca i1
  %l218 = alloca i1
  %l220 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca ptr
  %l234 = alloca %"compiler/source:Span"
  %l235 = alloca %"compiler/msgs:Msg"
  %l236 = alloca i64
  %l239 = alloca ptr
  %l240 = alloca i1
  %l245 = alloca ptr
  %l246 = alloca i1
  %l257 = alloca i1
  %l268 = alloca %"compiler/scope:Val"
  %l274 = alloca i1
  %l277 = alloca i1
  %l281 = alloca { i64, ptr }
  %l284 = alloca ptr
  %l288 = alloca { { i64, [2 x i64] }, i1, i64 }
  %l290 = alloca ptr
  %l291 = alloca %"compiler/source:Span"
  %l297 = alloca i1
  %l302 = alloca ptr
  %l303 = alloca ptr
  %l312 = alloca %"compiler/source:Span"
  %l313 = alloca %"compiler/msgs:Msg"
  %l314 = alloca i64
  %l325 = alloca { i64, ptr }
  %l330 = alloca i1
  %l331 = alloca ptr
  %l333 = alloca i32
  %l334 = alloca i1
  %l338 = alloca { { i64, [2 x i64] }, i1, i64 }
  %l345 = alloca i1
  %l348 = alloca ptr
  %l349 = alloca ptr
  %l351 = alloca %"compiler/source:Span"
  %l352 = alloca %"compiler/source:Span"
  %l353 = alloca %"compiler/msgs:Msg"
  %l354 = alloca i64
  %l359 = alloca ptr
  %l368 = alloca %"compiler/source:Span"
  %l391 = alloca ptr
  %l393 = alloca i32
  %l395 = alloca i1
  %l396 = alloca { i64, [2 x i64] }
  %l399 = alloca { i64, [2 x i64] }
  %s6 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %t1 = alloca { i64, [2 x i64] }, align 8
  %t26 = alloca { i64, [2 x i64] }, align 8
  %t119 = alloca { i64, [2 x i64] }, align 8
  %t123 = alloca { i64, [2 x i64] }, align 8
  %t199 = alloca { i64, [2 x i64] }, align 8
  %t473 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } zeroinitializer, ptr %t1
  %t2 = getelementptr { i64, [2 x i64] }, ptr %t1, i32 0, i32 0
  store i64 0, ptr %t2
  %t3 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t3, ptr %l3
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 72
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l54
  br label %bb1
bb1:
  %t10 = load i64, ptr %l54, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/scope:Scoper", ptr %t13, i32 0, i32 72
  store ptr %t15, ptr %l57, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 72
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l60
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t21 = load i64, ptr %l60, !tbaa !24
  %t22 = sub i64 %t21, 1
  %t23 = load ptr, ptr %l57, !tbaa !29
  %t25 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t23, i64 %t22)
  store i32 %t25, ptr %l62
  br label %bb5
bb5:
  store { i64, [2 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 0
  store i64 1, ptr %t27
  %t28 = load i32, ptr %l62, !tbaa !23
  %t29 = insertvalue { i32 } undef, i32 %t28, 0
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  store { i32 } %t29, ptr %t30
  %t31 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t31, ptr %l3
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/typed:Spawn", ptr %t33, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb8, label %bb9
bb8:
  br label %bb36
bb9:
  br label %bb10
bb10:
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t50, ptr %l72, !tbaa !27
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  store ptr %t56, ptr %l7, !tbaa !29
  %t58 = load ptr, ptr %l7, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  br i1 %t60, label %bb11, label %bb12
bb11:
  br label %bb35
bb12:
  br label %bb13
bb13:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceOperands(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/scope:Scoper", ptr %t66, i32 0, i32 49
  %t69 = load i1, ptr %t68, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load ptr, ptr %l7, !tbaa !29
  %t73 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v1, ptr %t71)
  store i64 %t73, ptr %l83
  br label %bb17
bb16:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb18
bb17:
  %t74 = load i64, ptr %l83, !tbaa !24
  %t75 = icmp sge i64 %t74, 0
  store i1 %t75, ptr %l81, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l81, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/scope:Scoper", ptr %t78, i32 0, i32 51
  store ptr %t80, ptr %l86, !tbaa !29
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t83 = call i64 @compiler_2fscope_2ewholeLocal(ptr %v1, ptr %t81)
  store i64 %t83, ptr %l88
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t84 = load ptr, ptr %l86, !tbaa !29
  %t85 = load i64, ptr %l88, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t84, i64 %t85, i1 true)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l89, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l7, !tbaa !29
  %t91 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t87, ptr %t88, i1 false)
  store { i64, [2 x i64] } %t91, ptr %l92
  br label %bb24
bb24:
  %t92 = load { i64, [2 x i64] }, ptr %l3
  %t93 = load ptr, ptr %l89, !tbaa !29
  %t94 = load { i64, [2 x i64] }, ptr %l92
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastsUntil(ptr %v0, ptr %t93, { i64, [2 x i64] } %t94, { i64, [2 x i64] } %t92)
  store i1 %t96, ptr %l94
  br label %bb25
bb25:
  %t97 = load i1, ptr %l94, !tbaa !21
  %t98 = xor i1 %t97, true
  br i1 %t98, label %bb26, label %bb27
bb26:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/scope:Scoper", ptr %t100, i32 0, i32 27
  %t103 = load i1, ptr %t102, !tbaa !21
  store i1 %t103, ptr %l96, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb28
bb28:
  %t105 = load i1, ptr %l96, !tbaa !21
  br i1 %t105, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l99, !tbaa !29
  %t107 = load ptr, ptr %l7, !tbaa !29
  %t109 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t107)
  store %"compiler/source:Span" %t109, ptr %l101
  br label %bb31
bb30:
  br label %bb34
bb31:
  %t110 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultTooShort(ptr %s6)
  store %"compiler/msgs:Msg" %t110, ptr %l102
  br label %bb32
bb32:
  %t111 = load ptr, ptr %l99, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l101
  %t113 = load %"compiler/msgs:Msg", ptr %l102
  %t114 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s6, ptr %t111, %"compiler/source:Span" %t112, %"compiler/msgs:Msg" %t113)
  store i64 %t114, ptr %l103
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t115 = load i64, ptr %l5, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l5, !tbaa !24
  br label %bb7
bb36:
  store { i64, [2 x i64] } zeroinitializer, ptr %t119
  %t120 = getelementptr { i64, [2 x i64] }, ptr %t119, i32 0, i32 0
  store i64 0, ptr %t120
  %t121 = load { i64, [2 x i64] }, ptr %t119
  store { i64, [2 x i64] } %t121, ptr %l8
  store { i64, [2 x i64] } zeroinitializer, ptr %t123
  %t124 = getelementptr { i64, [2 x i64] }, ptr %t123, i32 0, i32 0
  store i64 0, ptr %t124
  %t125 = load { i64, [2 x i64] }, ptr %t123
  store { i64, [2 x i64] } %t125, ptr %l9
  store i1 true, ptr %l10, !tbaa !21
  store i64 -1, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Spawn", ptr %t127, i32 0, i32 0
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t134 = load i64, ptr %l13, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = icmp sgt i64 %t134, %t135
  br i1 %t138, label %bb37, label %bb38
bb37:
  %t140 = load i64, ptr %l14, !tbaa !24
  %t142 = icmp sgt i64 %t140, 0
  br i1 %t142, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb42
bb39:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = sub i64 %t144, %t145
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = sub i64 %t152, 1
  %t155 = load i64, ptr %l14, !tbaa !24
  %t158 = sdiv i64 %t154, %t155
  store i64 %t158, ptr %l117, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb41
bb41:
  %t160 = load i64, ptr %l117, !tbaa !24
  store i64 %t160, ptr %l114, !tbaa !24
  br label %bb42
bb42:
  %t161 = load i64, ptr %l114, !tbaa !24
  store i64 %t161, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb43
bb43:
  %t162 = load i64, ptr %l16, !tbaa !24
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb44, label %bb45
bb44:
  br label %bb91
bb45:
  br label %bb46
bb46:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l16, !tbaa !24
  %t172 = load i64, ptr %l14, !tbaa !24
  %t175 = mul i64 %t171, %t172
  %t178 = add i64 %t170, %t175
  store i64 %t178, ptr %l17, !tbaa !24
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Spawn", ptr %t180, i32 0, i32 0
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %l136, !tbaa !27
  %t184 = load i64, ptr %l17, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr ptr, ptr %t187, i64 %t184
  %t189 = load ptr, ptr %t188, !tbaa !39
  store ptr %t189, ptr %l18, !tbaa !29
  %t191 = load ptr, ptr %l18, !tbaa !29
  %t193 = icmp eq ptr %t191, null
  br i1 %t193, label %bb47, label %bb48
bb47:
  br label %bb90
bb48:
  br label %bb49
bb49:
  %t195 = load ptr, ptr %l18, !tbaa !29
  %t197 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t195)
  store i32 %t197, ptr %l142
  br label %bb50
bb50:
  %t198 = load i32, ptr %l142, !tbaa !23
  store i32 %t198, ptr %l19, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t199
  %t200 = getelementptr { i64, [2 x i64] }, ptr %t199, i32 0, i32 0
  store i64 0, ptr %t200
  %t201 = load { i64, [2 x i64] }, ptr %t199
  store { i64, [2 x i64] } %t201, ptr %l20
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l19, !tbaa !23
  %t207 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t203, i32 %t204)
  store i1 %t207, ptr %l146
  br label %bb51
bb51:
  %t208 = load i1, ptr %l146, !tbaa !21
  br i1 %t208, label %bb52, label %bb53
bb52:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %l18, !tbaa !29
  %t213 = call { { i64, [2 x i64] }, i1, i64 } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotOf(ptr %v0, ptr %v1, ptr %t209, ptr %t210)
  store { { i64, [2 x i64] }, i1, i64 } %t213, ptr %l149
  br label %bb54
bb53:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i32, ptr %l19, !tbaa !23
  %t218 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t214, i32 %t215)
  store i1 %t218, ptr %l165
  br label %bb65
bb54:
  %t219 = load { { i64, [2 x i64] }, i1, i64 }, ptr %l149
  store { { i64, [2 x i64] }, i1, i64 } %t219, ptr %l21
  %t220 = getelementptr { { i64, [2 x i64] }, i1, i64 }, ptr %l21, i32 0, i32 0
  %t221 = load { i64, [2 x i64] }, ptr %t220
  store { i64, [2 x i64] } %t221, ptr %l20
  %t225 = load { i64, [2 x i64] }, ptr %l20
  %t227 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t225)
  store i1 %t227, ptr %l153
  br label %bb55
bb55:
  %t228 = load i1, ptr %l153, !tbaa !21
  %t229 = xor i1 %t228, true
  br i1 %t229, label %bb56, label %bb57
bb56:
  %t231 = load { i64, [2 x i64] }, ptr %l20
  %t233 = extractvalue { i64, [2 x i64] } %t231, 0
  %t234 = icmp eq i64 %t233, 0
  %t236 = xor i1 %t234, true
  store i1 %t236, ptr %l155, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb58
bb58:
  %t238 = load i1, ptr %l155, !tbaa !21
  br i1 %t238, label %bb59, label %bb60
bb59:
  %t239 = load i64, ptr %l11, !tbaa !24
  %t241 = icmp slt i64 %t239, 0
  store i1 %t241, ptr %l159, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb61
bb61:
  %t243 = load i1, ptr %l159, !tbaa !21
  br i1 %t243, label %bb62, label %bb63
bb62:
  %t244 = load i64, ptr %l17, !tbaa !24
  store i64 %t244, ptr %l11, !tbaa !24
  br label %bb64
bb63:
  br label %bb64
bb64:
  br label %bb70
bb65:
  %t246 = load i1, ptr %l165, !tbaa !21
  br i1 %t246, label %bb66, label %bb67
bb66:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l18, !tbaa !29
  %t251 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t247, ptr %t248, i1 false)
  store { i64, [2 x i64] } %t251, ptr %l168
  br label %bb68
bb67:
  br label %bb69
bb68:
  %t252 = load { i64, [2 x i64] }, ptr %l168
  store { i64, [2 x i64] } %t252, ptr %l20
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t253 = load { i64, [2 x i64] }, ptr %l20
  %t255 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t253)
  store i1 %t255, ptr %l170
  br label %bb71
bb71:
  %t256 = load i1, ptr %l170, !tbaa !21
  %t257 = xor i1 %t256, true
  br i1 %t257, label %bb72, label %bb73
bb72:
  br label %bb90
bb73:
  br label %bb74
bb74:
  %t259 = load { i64, [2 x i64] }, ptr %l9
  %t261 = extractvalue { i64, [2 x i64] } %t259, 0
  %t262 = icmp eq i64 %t261, 0
  br i1 %t262, label %bb75, label %bb76
bb75:
  %t264 = load { i64, [2 x i64] }, ptr %l20
  store { i64, [2 x i64] } %t264, ptr %l9
  br label %bb81
bb76:
  %t266 = load { i64, [2 x i64] }, ptr %l20
  store { i64, [2 x i64] } %t266, ptr %l175
  %t267 = load { i64, [2 x i64] }, ptr %l9
  store { i64, [2 x i64] } %t267, ptr %l177
  %t270 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l175, ptr %l177)
  store i1 %t270, ptr %l179
  br label %bb77
bb77:
  %t271 = load i1, ptr %l179, !tbaa !21
  %t272 = xor i1 %t271, true
  br i1 %t272, label %bb78, label %bb79
bb78:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb80
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t274 = load { i64, [2 x i64] }, ptr %l8
  %t276 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t274)
  store i1 %t276, ptr %l182
  br label %bb82
bb82:
  %t277 = load i1, ptr %l182, !tbaa !21
  %t278 = xor i1 %t277, true
  br i1 %t278, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l184, !tbaa !21
  br label %bb86
bb84:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load { i64, [2 x i64] }, ptr %l20
  %t282 = load { i64, [2 x i64] }, ptr %l8
  %t286 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %t280, { i64, [2 x i64] } %t281, { i64, [2 x i64] } %t282)
  store i64 %t286, ptr %l188
  br label %bb85
bb85:
  %t287 = load i64, ptr @G_2ecompiler_2fscope_2eHolds, !tbaa !24
  %t288 = load i64, ptr %l188, !tbaa !24
  %t290 = icmp eq i64 %t288, %t287
  store i1 %t290, ptr %l184, !tbaa !21
  br label %bb86
bb86:
  %t292 = load i1, ptr %l184, !tbaa !21
  br i1 %t292, label %bb87, label %bb88
bb87:
  %t293 = load { i64, [2 x i64] }, ptr %l20
  store { i64, [2 x i64] } %t293, ptr %l8
  br label %bb89
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t295 = load i64, ptr %l16, !tbaa !24
  %t297 = add i64 %t295, 1
  store i64 %t297, ptr %l16, !tbaa !24
  br label %bb43
bb91:
  store i1 false, ptr %l23, !tbaa !21
  %t299 = load ptr, ptr %l2, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Spawn", ptr %t299, i32 0, i32 2
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  store { i64, ptr } %t302, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t304 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 0
  store i64 %t306, ptr %l26, !tbaa !24
  br label %bb92
bb92:
  %t308 = load i64, ptr %l25, !tbaa !24
  %t309 = load i64, ptr %l26, !tbaa !24
  %t312 = icmp slt i64 %t308, %t309
  %t314 = xor i1 %t312, true
  br i1 %t314, label %bb93, label %bb94
bb93:
  br label %bb140
bb94:
  br label %bb95
bb95:
  %t316 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t316, ptr %l202, !tbaa !27
  %t317 = load i64, ptr %l25, !tbaa !24
  %t319 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !27
  %t321 = getelementptr ptr, ptr %t320, i64 %t317
  %t322 = load ptr, ptr %t321, !tbaa !39
  store ptr %t322, ptr %l27, !tbaa !29
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/scope:Scoper", ptr %t324, i32 0, i32 71
  store i1 true, ptr %t326, !tbaa !21
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l27, !tbaa !29
  %t330 = getelementptr %"compiler/typed:TaskClause", ptr %t328, i32 0, i32 3
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t332 = load { i64, [2 x i64] }, ptr %l3
  %t336 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t327, ptr %t331, { i64, [2 x i64] } %t332)
  store %"compiler/scope:Val" %t336, ptr %l210
  br label %bb96
bb96:
  %t337 = load %"compiler/scope:Val", ptr %l210
  store %"compiler/scope:Val" %t337, ptr %l28
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/scope:Scoper", ptr %t338, i32 0, i32 71
  store i1 false, ptr %t340, !tbaa !21
  %t341 = getelementptr %"compiler/scope:Val", ptr %l28, i32 0, i32 0
  %t342 = load i32, ptr %t341
  %t344 = trunc i64 3 to i32
  %t345 = icmp eq i32 %t342, %t344
  br i1 %t345, label %bb97, label %bb98
bb97:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/scope:Val", ptr %l28, i32 0, i32 1
  %t349 = load { i64, [2 x i64] }, ptr %t348
  %t350 = load { i64, [2 x i64] }, ptr %l3
  %t354 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastsUntil(ptr %v0, ptr %t347, { i64, [2 x i64] } %t349, { i64, [2 x i64] } %t350)
  store i1 %t354, ptr %l218
  br label %bb99
bb98:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb100
bb99:
  %t355 = load i1, ptr %l218, !tbaa !21
  %t356 = xor i1 %t355, true
  store i1 %t356, ptr %l214, !tbaa !21
  br label %bb100
bb100:
  %t358 = load i1, ptr %l214, !tbaa !21
  br i1 %t358, label %bb101, label %bb102
bb101:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/scope:Scoper", ptr %t359, i32 0, i32 27
  %t362 = load i1, ptr %t361, !tbaa !21
  store i1 %t362, ptr %l220, !tbaa !21
  br label %bb103
bb102:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb103
bb103:
  %t364 = load i1, ptr %l220, !tbaa !21
  br i1 %t364, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s23
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l223, !tbaa !29
  %t366 = load ptr, ptr %l0, !tbaa !29
  store ptr %t366, ptr %l224, !tbaa !29
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/scope:Scoper", ptr %t367, i32 0, i32 25
  %t370 = load ptr, ptr %t369, !tbaa !29
  %t372 = icmp eq ptr %t370, null
  br i1 %t372, label %bb106, label %bb107
bb105:
  br label %bb112
bb106:
  call void @__olang_check_failed(ptr @olang_loc_e78903360621b090_3122ead72721c55c)
  unreachable
bb107:
  br label %bb108
bb108:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/scope:Scoper", ptr %t374, i32 0, i32 25
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t380 = getelementptr %"compiler/typed:Body", ptr %t377, i32 0, i32 3
  %t381 = load i64, ptr %t380, !tbaa !24
  %t382 = load ptr, ptr %l27, !tbaa !29
  %t384 = getelementptr %"compiler/typed:TaskClause", ptr %t382, i32 0, i32 0
  %t385 = load %"compiler/source:Span", ptr %t384
  %t386 = load ptr, ptr %l224, !tbaa !29
  %t389 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t386, i64 %t381, %"compiler/source:Span" %t385)
  store %"compiler/source:Span" %t389, ptr %l234
  br label %bb109
bb109:
  %t390 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnCaptureTooShort(ptr %s23)
  store %"compiler/msgs:Msg" %t390, ptr %l235
  br label %bb110
bb110:
  %t391 = load ptr, ptr %l223, !tbaa !29
  %t392 = load %"compiler/source:Span", ptr %l234
  %t393 = load %"compiler/msgs:Msg", ptr %l235
  %t394 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s23, ptr %t391, %"compiler/source:Span" %t392, %"compiler/msgs:Msg" %t393)
  store i64 %t394, ptr %l236
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s23)
  br label %bb112
bb112:
  %t395 = load ptr, ptr %l27, !tbaa !29
  %t397 = getelementptr %"compiler/typed:TaskClause", ptr %t395, i32 0, i32 3
  %t398 = load ptr, ptr %t397, !tbaa !29
  store ptr %t398, ptr %l29, !tbaa !29
  %t400 = load ptr, ptr %l29, !tbaa !29
  store ptr %t400, ptr %l239, !tbaa !29
  store i1 false, ptr %l240, !tbaa !21
  %t401 = load ptr, ptr %l239, !tbaa !29
  %t402 = icmp ne ptr %t401, null
  br i1 %t402, label %bb113, label %bb114
bb113:
  %t404 = load ptr, ptr %l239, !tbaa !29
  %t405 = load i64, ptr %t404
  %t407 = icmp eq i64 %t405, 15
  store i1 %t407, ptr %l240, !tbaa !21
  br label %bb114
bb114:
  %t408 = load i1, ptr %l240, !tbaa !21
  br i1 %t408, label %bb115, label %bb116
bb115:
  %t409 = load ptr, ptr %l29, !tbaa !29
  %t411 = getelementptr { i64, [5 x i64] }, ptr %t409, i32 0, i32 1
  %t412 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t411, i32 0, i32 2
  %t413 = load ptr, ptr %t412
  store ptr %t413, ptr %l30, !tbaa !29
  br label %bb117
bb116:
  br label %bb133
bb117:
  %t415 = load ptr, ptr %l30, !tbaa !29
  store ptr %t415, ptr %l245, !tbaa !29
  store i1 false, ptr %l246, !tbaa !21
  %t416 = load ptr, ptr %l245, !tbaa !29
  %t417 = icmp ne ptr %t416, null
  br i1 %t417, label %bb118, label %bb119
bb118:
  %t419 = load ptr, ptr %l245, !tbaa !29
  %t420 = load i64, ptr %t419
  %t422 = icmp eq i64 %t420, 1
  store i1 %t422, ptr %l246, !tbaa !21
  br label %bb119
bb119:
  %t423 = load i1, ptr %l246, !tbaa !21
  br i1 %t423, label %bb120, label %bb121
bb120:
  %t424 = load ptr, ptr %l30, !tbaa !29
  %t426 = getelementptr { i64, [4 x i64] }, ptr %t424, i32 0, i32 1
  %t427 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t426, i32 0, i32 0
  %t428 = load i32, ptr %t427
  store i32 %t428, ptr %l31, !tbaa !23
  br label %bb122
bb121:
  br label %bb127
bb122:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load i32, ptr %l31, !tbaa !23
  %t433 = sext i32 %t431 to i64
  %t434 = load { i64, [2 x i64] }, ptr %l8
  %t435 = load ptr, ptr %l27, !tbaa !29
  %t437 = getelementptr %"compiler/typed:TaskClause", ptr %t435, i32 0, i32 0
  %t438 = load %"compiler/source:Span", ptr %t437
  %t443 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclauseBuilds(ptr %v0, ptr %t430, i64 %t433, { i64, [2 x i64] } %t434, %"compiler/source:Span" %t438)
  store i1 %t443, ptr %l257
  br label %bb123
bb123:
  %t444 = load i1, ptr %l257, !tbaa !21
  br i1 %t444, label %bb124, label %bb125
bb124:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb126
bb125:
  br label %bb126
bb126:
  br label %bb132
bb127:
  br i1 true, label %bb128, label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb132
bb131:
  call void @__olang_check_failed(ptr @olang_loc_aee576b8a3d2f436_529adcde89776572)
  unreachable
bb132:
  br label %bb138
bb133:
  br i1 true, label %bb134, label %bb135
bb134:
  br label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb138
bb137:
  call void @__olang_check_failed(ptr @olang_loc_13f804c0f75facd_7560a9ac77a32da9)
  unreachable
bb138:
  br label %bb139
bb139:
  %t445 = load i64, ptr %l25, !tbaa !24
  %t447 = add i64 %t445, 1
  store i64 %t447, ptr %l25, !tbaa !24
  br label %bb92
bb140:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/scope:Scoper", ptr %t449, i32 0, i32 71
  store i1 true, ptr %t451, !tbaa !21
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t453 = load { i64, [2 x i64] }, ptr %l3
  %t456 = getelementptr %"compiler/scope:Scoper", ptr %t452, i32 0, i32 73
  store { i64, [2 x i64] } %t453, ptr %t456
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load ptr, ptr %l2, !tbaa !29
  %t460 = getelementptr %"compiler/typed:Spawn", ptr %t458, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !29
  %t463 = load { i64, [2 x i64] }, ptr %l8
  %t467 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t457, ptr %t461, { i64, [2 x i64] } %t463)
  store %"compiler/scope:Val" %t467, ptr %l268
  br label %bb141
bb141:
  %t468 = load %"compiler/scope:Val", ptr %l268
  store %"compiler/scope:Val" %t468, ptr %l32
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/scope:Scoper", ptr %t469, i32 0, i32 71
  store i1 false, ptr %t471, !tbaa !21
  %t472 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t473
  %t474 = getelementptr { i64, [2 x i64] }, ptr %t473, i32 0, i32 0
  store i64 0, ptr %t474
  %t475 = load { i64, [2 x i64] }, ptr %t473
  %t478 = getelementptr %"compiler/scope:Scoper", ptr %t472, i32 0, i32 73
  store { i64, [2 x i64] } %t475, ptr %t478
  %t479 = getelementptr %"compiler/scope:Val", ptr %l32, i32 0, i32 0
  %t480 = load i32, ptr %t479
  %t482 = trunc i64 2 to i32
  %t483 = icmp eq i32 %t480, %t482
  br i1 %t483, label %bb142, label %bb143
bb142:
  store i1 true, ptr %l274, !tbaa !21
  br label %bb144
bb143:
  %t485 = load i1, ptr %l23, !tbaa !21
  store i1 %t485, ptr %l274, !tbaa !21
  br label %bb144
bb144:
  %t487 = load i1, ptr %l274, !tbaa !21
  store i1 %t487, ptr %l33, !tbaa !21
  %t488 = load i1, ptr %l33, !tbaa !21
  br i1 %t488, label %bb145, label %bb146
bb145:
  %t490 = load i64, ptr %l11, !tbaa !24
  %t492 = icmp sge i64 %t490, 0
  store i1 %t492, ptr %l277, !tbaa !21
  br label %bb147
bb146:
  store i1 false, ptr %l277, !tbaa !21
  br label %bb147
bb147:
  %t494 = load i1, ptr %l277, !tbaa !21
  br i1 %t494, label %bb148, label %bb149
bb148:
  %t495 = load ptr, ptr %l2, !tbaa !29
  %t497 = getelementptr %"compiler/typed:Spawn", ptr %t495, i32 0, i32 0
  %t498 = load { i64, ptr }, ptr %t497, !tbaa !27
  store { i64, ptr } %t498, ptr %l281, !tbaa !27
  %t499 = load i64, ptr %l11, !tbaa !24
  %t501 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr ptr, ptr %t502, i64 %t499
  %t504 = load ptr, ptr %t503, !tbaa !39
  store ptr %t504, ptr %l34, !tbaa !29
  %t506 = load ptr, ptr %l0, !tbaa !29
  store ptr %t506, ptr %l284, !tbaa !29
  %t507 = load ptr, ptr %l34, !tbaa !29
  %t509 = icmp eq ptr %t507, null
  br i1 %t509, label %bb150, label %bb151
bb149:
  %t511 = load i1, ptr %l33, !tbaa !21
  br i1 %t511, label %bb158, label %bb159
bb150:
  call void @__olang_check_failed(ptr @olang_loc_19e7888b9ded6be5_cbea83f8bb640751)
  unreachable
bb151:
  br label %bb152
bb152:
  %t513 = load ptr, ptr %l34, !tbaa !29
  %t514 = load ptr, ptr %l284, !tbaa !29
  %t516 = call { { i64, [2 x i64] }, i1, i64 } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotOf(ptr %v0, ptr %v1, ptr %t514, ptr %t513)
  store { { i64, [2 x i64] }, i1, i64 } %t516, ptr %l288
  br label %bb153
bb153:
  %t517 = load { { i64, [2 x i64] }, i1, i64 }, ptr %l288
  store { { i64, [2 x i64] }, i1, i64 } %t517, ptr %l35
  %t518 = getelementptr { { i64, [2 x i64] }, i1, i64 }, ptr %l35, i32 0, i32 0
  %t519 = load { i64, [2 x i64] }, ptr %t518
  store { i64, [2 x i64] } %t519, ptr %l36
  %t521 = load ptr, ptr %l0, !tbaa !29
  store ptr %t521, ptr %l290, !tbaa !29
  %t522 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t522, ptr %l291
  %t523 = load ptr, ptr %l34, !tbaa !29
  %t525 = icmp eq ptr %t523, null
  br i1 %t525, label %bb154, label %bb155
bb154:
  call void @__olang_check_failed(ptr @olang_loc_e9bdb4d0fe7c1914_18007eac4987ca18)
  unreachable
bb155:
  br label %bb156
bb156:
  %t527 = load ptr, ptr %l34, !tbaa !29
  %t528 = load { i64, [2 x i64] }, ptr %l36
  %t529 = load ptr, ptr %l290, !tbaa !29
  %t530 = load %"compiler/source:Span", ptr %l291
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efreshIntoUnknown(ptr %v0, ptr %v1, ptr %t529, %"compiler/source:Span" %t530, ptr %t527, { i64, [2 x i64] } %t528)
  br label %bb157
bb157:
  br label %bb173
bb158:
  %t533 = load i1, ptr %l10, !tbaa !21
  %t535 = xor i1 %t533, true
  store i1 %t535, ptr %l297, !tbaa !21
  br label %bb160
bb159:
  store i1 false, ptr %l297, !tbaa !21
  br label %bb160
bb160:
  %t537 = load i1, ptr %l297, !tbaa !21
  br i1 %t537, label %bb161, label %bb162
bb161:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t540 = getelementptr %"compiler/scope:Scoper", ptr %t538, i32 0, i32 27
  %t541 = load i1, ptr %t540, !tbaa !21
  br i1 %t541, label %bb163, label %bb164
bb162:
  br label %bb172
bb163:
  store %olang.scope zeroinitializer, ptr %s33
  %t543 = load ptr, ptr %l0, !tbaa !29
  store ptr %t543, ptr %l302, !tbaa !29
  %t544 = load ptr, ptr %l0, !tbaa !29
  store ptr %t544, ptr %l303, !tbaa !29
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = getelementptr %"compiler/scope:Scoper", ptr %t545, i32 0, i32 25
  %t548 = load ptr, ptr %t547, !tbaa !29
  %t550 = icmp eq ptr %t548, null
  br i1 %t550, label %bb165, label %bb166
bb164:
  br label %bb171
bb165:
  call void @__olang_check_failed(ptr @olang_loc_a5b38bc8e2246423_334fa60605363c37)
  unreachable
bb166:
  br label %bb167
bb167:
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t554 = getelementptr %"compiler/scope:Scoper", ptr %t552, i32 0, i32 25
  %t555 = load ptr, ptr %t554, !tbaa !29
  %t558 = getelementptr %"compiler/typed:Body", ptr %t555, i32 0, i32 3
  %t559 = load i64, ptr %t558, !tbaa !24
  %t560 = load %"compiler/source:Span", ptr %l1
  %t561 = load ptr, ptr %l303, !tbaa !29
  %t564 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t561, i64 %t559, %"compiler/source:Span" %t560)
  store %"compiler/source:Span" %t564, ptr %l312
  br label %bb168
bb168:
  %t565 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultsDisagree(ptr %s33)
  store %"compiler/msgs:Msg" %t565, ptr %l313
  br label %bb169
bb169:
  %t566 = load ptr, ptr %l302, !tbaa !29
  %t567 = load %"compiler/source:Span", ptr %l312
  %t568 = load %"compiler/msgs:Msg", ptr %l313
  %t569 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s33, ptr %t566, %"compiler/source:Span" %t567, %"compiler/msgs:Msg" %t568)
  store i64 %t569, ptr %l314
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s33)
  br label %bb171
bb171:
  br label %bb172
bb172:
  br label %bb173
bb173:
  %t570 = getelementptr %"compiler/scope:Val", ptr %l32, i32 0, i32 0
  %t571 = load i32, ptr %t570
  %t573 = trunc i64 3 to i32
  %t574 = icmp eq i32 %t571, %t573
  br i1 %t574, label %bb174, label %bb175
bb174:
  %t576 = load ptr, ptr %l2, !tbaa !29
  %t578 = getelementptr %"compiler/typed:Spawn", ptr %t576, i32 0, i32 0
  %t579 = load { i64, ptr }, ptr %t578, !tbaa !27
  store { i64, ptr } %t579, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t581 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t583 = extractvalue { i64, ptr } %t581, 0
  store i64 %t583, ptr %l39, !tbaa !24
  br label %bb176
bb175:
  br label %bb207
bb176:
  %t585 = load i64, ptr %l38, !tbaa !24
  %t586 = load i64, ptr %l39, !tbaa !24
  %t589 = icmp slt i64 %t585, %t586
  %t591 = xor i1 %t589, true
  br i1 %t591, label %bb177, label %bb178
bb177:
  br label %bb206
bb178:
  br label %bb179
bb179:
  %t593 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t593, ptr %l325, !tbaa !27
  %t594 = load i64, ptr %l38, !tbaa !24
  %t596 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t597 = load ptr, ptr %t596, !tbaa !27
  %t598 = getelementptr ptr, ptr %t597, i64 %t594
  %t599 = load ptr, ptr %t598, !tbaa !39
  store ptr %t599, ptr %l40, !tbaa !29
  %t601 = load ptr, ptr %l40, !tbaa !29
  %t603 = icmp eq ptr %t601, null
  br i1 %t603, label %bb180, label %bb181
bb180:
  store i1 true, ptr %l330, !tbaa !21
  br label %bb184
bb181:
  %t605 = load ptr, ptr %l0, !tbaa !29
  store ptr %t605, ptr %l331, !tbaa !29
  %t606 = load ptr, ptr %l40, !tbaa !29
  %t608 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t606)
  store i32 %t608, ptr %l333
  br label %bb182
bb182:
  %t609 = load ptr, ptr %l331, !tbaa !29
  %t610 = load i32, ptr %l333, !tbaa !23
  %t611 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t609, i32 %t610)
  store i1 %t611, ptr %l334
  br label %bb183
bb183:
  %t612 = load i1, ptr %l334, !tbaa !21
  %t613 = xor i1 %t612, true
  store i1 %t613, ptr %l330, !tbaa !21
  br label %bb184
bb184:
  %t615 = load i1, ptr %l330, !tbaa !21
  br i1 %t615, label %bb185, label %bb186
bb185:
  br label %bb205
bb186:
  br label %bb187
bb187:
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t617 = load ptr, ptr %l40, !tbaa !29
  %t620 = call { { i64, [2 x i64] }, i1, i64 } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotOf(ptr %v0, ptr %v1, ptr %t616, ptr %t617)
  store { { i64, [2 x i64] }, i1, i64 } %t620, ptr %l338
  br label %bb188
bb188:
  %t621 = load { { i64, [2 x i64] }, i1, i64 }, ptr %l338
  store { { i64, [2 x i64] }, i1, i64 } %t621, ptr %l41
  %t622 = getelementptr { { i64, [2 x i64] }, i1, i64 }, ptr %l41, i32 0, i32 0
  %t623 = load { i64, [2 x i64] }, ptr %t622
  store { i64, [2 x i64] } %t623, ptr %l42
  %t625 = getelementptr { { i64, [2 x i64] }, i1, i64 }, ptr %l41, i32 0, i32 1
  %t626 = load i1, ptr %t625, !tbaa !21
  store i1 %t626, ptr %l43, !tbaa !21
  %t628 = getelementptr { { i64, [2 x i64] }, i1, i64 }, ptr %l41, i32 0, i32 2
  %t629 = load i64, ptr %t628, !tbaa !24
  store i64 %t629, ptr %l44, !tbaa !24
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t632 = load ptr, ptr %l40, !tbaa !29
  %t633 = load { i64, [2 x i64] }, ptr %l42
  %t637 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindingUnknown(ptr %v0, ptr %v1, ptr %t631, ptr %t632, { i64, [2 x i64] } %t633)
  store i1 %t637, ptr %l345
  br label %bb189
bb189:
  %t638 = load i1, ptr %l345, !tbaa !21
  br i1 %t638, label %bb190, label %bb191
bb190:
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t641 = getelementptr %"compiler/scope:Scoper", ptr %t639, i32 0, i32 27
  %t642 = load i1, ptr %t641, !tbaa !21
  br i1 %t642, label %bb192, label %bb193
bb191:
  br label %bb199
bb192:
  store %olang.scope zeroinitializer, ptr %s39
  %t644 = load ptr, ptr %l0, !tbaa !29
  store ptr %t644, ptr %l348, !tbaa !29
  %t645 = load ptr, ptr %l0, !tbaa !29
  store ptr %t645, ptr %l349, !tbaa !29
  %t646 = load ptr, ptr %l40, !tbaa !29
  %t648 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t646)
  store %"compiler/source:Span" %t648, ptr %l351
  br label %bb194
bb193:
  br label %bb198
bb194:
  %t649 = load ptr, ptr %l349, !tbaa !29
  %t650 = load %"compiler/source:Span", ptr %l351
  %t651 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eeqAfter(ptr %v0, ptr %t649, %"compiler/source:Span" %t650)
  store %"compiler/source:Span" %t651, ptr %l352
  br label %bb195
bb195:
  %t652 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldBindingUnknown(ptr %s39)
  store %"compiler/msgs:Msg" %t652, ptr %l353
  br label %bb196
bb196:
  %t653 = load ptr, ptr %l348, !tbaa !29
  %t654 = load %"compiler/source:Span", ptr %l352
  %t655 = load %"compiler/msgs:Msg", ptr %l353
  %t656 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s39, ptr %t653, %"compiler/source:Span" %t654, %"compiler/msgs:Msg" %t655)
  store i64 %t656, ptr %l354
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s39)
  br label %bb198
bb198:
  br label %bb205
bb199:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t659 = getelementptr %"compiler/scope:Scoper", ptr %t657, i32 0, i32 81
  %t660 = load i1, ptr %t659, !tbaa !21
  store i1 %t660, ptr %l45, !tbaa !21
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t664 = getelementptr %"compiler/scope:Scoper", ptr %t662, i32 0, i32 82
  %t665 = load %"compiler/source:Span", ptr %t664
  store %"compiler/source:Span" %t665, ptr %l46
  store i1 true, ptr %l47, !tbaa !21
  %t667 = load ptr, ptr %l0, !tbaa !29
  store ptr %t667, ptr %l359, !tbaa !29
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t670 = getelementptr %"compiler/scope:Scoper", ptr %t668, i32 0, i32 25
  %t671 = load ptr, ptr %t670, !tbaa !29
  %t673 = icmp eq ptr %t671, null
  br i1 %t673, label %bb200, label %bb201
bb200:
  call void @__olang_check_failed(ptr @olang_loc_e1bbe67f5ab83fa2_6597018deaf47546)
  unreachable
bb201:
  br label %bb202
bb202:
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t677 = getelementptr %"compiler/scope:Scoper", ptr %t675, i32 0, i32 25
  %t678 = load ptr, ptr %t677, !tbaa !29
  %t681 = getelementptr %"compiler/typed:Body", ptr %t678, i32 0, i32 3
  %t682 = load i64, ptr %t681, !tbaa !24
  %t683 = load %"compiler/source:Span", ptr %l1
  %t684 = load ptr, ptr %l359, !tbaa !29
  %t687 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efirstToken(ptr %v0, ptr %t684, i64 %t682, %"compiler/source:Span" %t683)
  store %"compiler/source:Span" %t687, ptr %l368
  br label %bb203
bb203:
  %t688 = load %"compiler/source:Span", ptr %l368
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t690 = load i1, ptr %l47, !tbaa !21
  %t693 = getelementptr %"compiler/scope:Scoper", ptr %t689, i32 0, i32 81
  store i1 %t690, ptr %t693, !tbaa !21
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t698 = getelementptr %"compiler/scope:Scoper", ptr %t694, i32 0, i32 82
  store %"compiler/source:Span" %t688, ptr %t698
  %t699 = load ptr, ptr %l0, !tbaa !29
  %t700 = getelementptr %"compiler/scope:Val", ptr %l32, i32 0, i32 1
  %t701 = load { i64, [2 x i64] }, ptr %t700
  %t702 = load { i64, [2 x i64] }, ptr %l42
  %t703 = load i1, ptr %l43, !tbaa !21
  %t704 = load ptr, ptr %l2, !tbaa !29
  %t706 = getelementptr %"compiler/typed:Spawn", ptr %t704, i32 0, i32 1
  %t707 = load ptr, ptr %t706, !tbaa !29
  %t708 = load i64, ptr %l44, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t699, { i64, [2 x i64] } %t701, { i64, [2 x i64] } %t702, i1 %t703, ptr %t707, i64 %t708)
  br label %bb204
bb204:
  %t715 = load i1, ptr %l45, !tbaa !21
  %t717 = load %"compiler/source:Span", ptr %l46
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t723 = getelementptr %"compiler/scope:Scoper", ptr %t719, i32 0, i32 81
  store i1 %t715, ptr %t723, !tbaa !21
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t728 = getelementptr %"compiler/scope:Scoper", ptr %t724, i32 0, i32 82
  store %"compiler/source:Span" %t717, ptr %t728
  br label %bb205
bb205:
  %t729 = load i64, ptr %l38, !tbaa !24
  %t731 = add i64 %t729, 1
  store i64 %t731, ptr %l38, !tbaa !24
  br label %bb176
bb206:
  br label %bb207
bb207:
  %t733 = load ptr, ptr %l2, !tbaa !29
  %t735 = getelementptr %"compiler/typed:Spawn", ptr %t733, i32 0, i32 3
  %t736 = load i32, ptr %t735, !tbaa !23
  %t738 = icmp sge i32 %t736, 0
  br i1 %t738, label %bb208, label %bb209
bb208:
  %t740 = load ptr, ptr %l0, !tbaa !29
  store ptr %t740, ptr %l391, !tbaa !29
  %t741 = load ptr, ptr %l2, !tbaa !29
  %t743 = getelementptr %"compiler/typed:Spawn", ptr %t741, i32 0, i32 3
  %t744 = load i32, ptr %t743, !tbaa !23
  store i32 %t744, ptr %l393, !tbaa !23
  %t745 = load { i64, [2 x i64] }, ptr %l3
  %t747 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t745)
  store i1 %t747, ptr %l395
  br label %bb210
bb209:
  br label %bb216
bb210:
  %t748 = load i1, ptr %l395, !tbaa !21
  br i1 %t748, label %bb211, label %bb212
bb211:
  %t749 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t749, ptr %l396
  br label %bb214
bb212:
  %t751 = load ptr, ptr %l0, !tbaa !29
  %t753 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t751)
  store { i64, [2 x i64] } %t753, ptr %l399
  br label %bb213
bb213:
  %t754 = load { i64, [2 x i64] }, ptr %l399
  store { i64, [2 x i64] } %t754, ptr %l396
  br label %bb214
bb214:
  %t755 = load ptr, ptr %l391, !tbaa !29
  %t756 = load i32, ptr %l393, !tbaa !23
  %t757 = load { i64, [2 x i64] }, ptr %l396
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuild(ptr %v0, ptr %t755, i32 %t756, { i64, [2 x i64] } %t757)
  br label %bb215
bb215:
  br label %bb216
bb216:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i1
  %l15 = alloca { i64, [2 x i64] }
  %l18 = alloca { i64, [2 x i64] }
  %l30 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, [2 x i64] }
  %l37 = alloca { i64, [2 x i64] }
  %l39 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t6)
  store i32 %t8, ptr %l9
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t11, ptr %l10
  br label %bb5
bb5:
  %t12 = load i1, ptr %l10, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t21 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t17, ptr %t18, i1 true)
  store { i64, [2 x i64] } %t21, ptr %l15
  br label %bb10
bb10:
  %t22 = load { i64, [2 x i64] }, ptr %l15
  store { i64, [2 x i64] } %t22, ptr %l2
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t23, ptr %t24, i1 false)
  store { i64, [2 x i64] } %t27, ptr %l18
  br label %bb11
bb11:
  %t28 = load { i64, [2 x i64] }, ptr %l18
  store { i64, [2 x i64] } %t28, ptr %l3
  %t29 = load { i64, [2 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 5
  br i1 %t32, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  %t35 = load { i64, [2 x i64] }, ptr %l2
  %t37 = extractvalue { i64, [2 x i64] } %t35, 0
  %t38 = icmp eq i64 %t37, 0
  br i1 %t38, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  %t40 = load { i64, [2 x i64] }, ptr %l2
  %t42 = extractvalue { i64, [2 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 6
  br i1 %t43, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_d14ac281d7095de3_5cf23a39181ab0c7)
  unreachable
bb26:
  %t46 = load { i64, [2 x i64] }, ptr %l3
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 0
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb27, label %bb28
bb27:
  %t53 = load { i64, [2 x i64] }, ptr %l3
  %t55 = extractvalue { i64, [2 x i64] } %t53, 0
  %t56 = icmp eq i64 %t55, 6
  %t58 = xor i1 %t56, true
  store i1 %t58, ptr %l30, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb29
bb29:
  %t60 = load i1, ptr %l30, !tbaa !21
  br i1 %t60, label %bb30, label %bb31
bb30:
  %t61 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t61, ptr %l35
  %t62 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t62, ptr %l37
  %t65 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %l35, ptr %l37)
  store i1 %t65, ptr %l39
  br label %bb32
bb31:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb33
bb32:
  %t66 = load i1, ptr %l39, !tbaa !21
  %t67 = xor i1 %t66, true
  store i1 %t67, ptr %l34, !tbaa !21
  br label %bb33
bb33:
  %t69 = load i1, ptr %l34, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estaticVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l17 = alloca i32
  %l26 = alloca { i64, ptr }
  %l38 = alloca i64
  %l41 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i64
  %l76 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i32, ptr %l17, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t19, i32 %t20)
  store { i64, ptr } %t23, ptr %l26
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t31 = icmp sge i64 %t25, %t28
  br i1 %t31, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store i1 false, ptr %l5, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Call", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i64, ptr %l8, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb14
bb11:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l41, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l41, !tbaa !24
  store i64 %t67, ptr %l38, !tbaa !24
  br label %bb14
bb14:
  %t68 = load i64, ptr %l38, !tbaa !24
  store i64 %t68, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  %t69 = load i64, ptr %l10, !tbaa !24
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb16, label %bb17
bb16:
  br label %bb39
bb17:
  br label %bb18
bb18:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t78 = load i64, ptr %l10, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l11, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/scope:Scoper", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l3, !tbaa !23
  %t94 = load i64, ptr %l11, !tbaa !24
  %t98 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t92, i32 %t93, i64 %t94)
  store i64 %t98, ptr %l64
  br label %bb19
bb19:
  %t99 = load i64, ptr %l64, !tbaa !24
  store i64 %t99, ptr %l12, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t102 = icmp sge i64 %t100, 0
  br i1 %t102, label %bb20, label %bb21
bb20:
  %t104 = load i64, ptr %l12, !tbaa !24
  store i64 %t104, ptr %l67, !tbaa !24
  br label %bb22
bb21:
  %t106 = load i64, ptr %l11, !tbaa !24
  store i64 %t106, ptr %l67, !tbaa !24
  br label %bb22
bb22:
  %t108 = load i64, ptr %l67, !tbaa !24
  %t109 = load i64, ptr %l2, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i64, ptr %t112, i64 %t109
  %t114 = load i64, ptr %t113, !tbaa !34
  %t118 = icmp ne i64 %t114, %t108
  br i1 %t118, label %bb23, label %bb24
bb23:
  br label %bb38
bb24:
  br label %bb25
bb25:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Call", ptr %t121, i32 0, i32 1
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l76, !tbaa !27
  %t125 = load i64, ptr %l11, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr ptr, ptr %t128, i64 %t125
  %t130 = load ptr, ptr %t129, !tbaa !39
  %t134 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %t120, ptr %t130)
  store ptr %t134, ptr %l80
  br label %bb26
bb26:
  %t135 = load ptr, ptr %l80, !tbaa !29
  store ptr %t135, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t137 = load ptr, ptr %l81, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb27, label %bb28
bb27:
  %t140 = load ptr, ptr %l81, !tbaa !29
  %t141 = load i64, ptr %t140
  %t143 = icmp eq i64 %t141, 1
  store i1 %t143, ptr %l82, !tbaa !21
  br label %bb28
bb28:
  %t144 = load i1, ptr %l82, !tbaa !21
  br i1 %t144, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb36:
  call void @__olang_check_failed(ptr @olang_loc_e22ca2126d036b2f_5c370e93157d3a93)
  unreachable
bb37:
  br label %bb38
bb38:
  %t146 = load i64, ptr %l10, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l10, !tbaa !24
  br label %bb15
bb39:
  %t150 = load i1, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t150, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l16 = alloca i64
  %l19 = alloca i64
  %l37 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i1
  %l68 = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l19, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l19, !tbaa !24
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l16, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb37
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t51, ptr %l37, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  store ptr %t57, ptr %l8, !tbaa !29
  %t59 = load ptr, ptr %l8, !tbaa !29
  store ptr %t59, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t60 = load ptr, ptr %l40, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t63 = load ptr, ptr %l40, !tbaa !29
  %t64 = load i64, ptr %t63
  %t66 = icmp eq i64 %t64, 0
  store i1 %t66, ptr %l41, !tbaa !21
  br label %bb12
bb12:
  %t67 = load i1, ptr %l41, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  %t68 = load ptr, ptr %l8, !tbaa !29
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l9, !tbaa !23
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l10, !tbaa !29
  br label %bb15
bb14:
  br label %bb29
bb15:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l9, !tbaa !23
  %t82 = load ptr, ptr %l10, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t84 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t84, 1
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edecide(ptr %v0, ptr %v1, ptr %v1, ptr %t80, i32 %t81, ptr %t82, { i64, ptr } %t83, i64 %t86)
  br label %bb16
bb16:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l10, !tbaa !29
  %t96 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %t92, ptr %t93)
  store i1 %t96, ptr %l56
  br label %bb17
bb17:
  %t97 = load i1, ptr %l56, !tbaa !21
  br i1 %t97, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb21
bb19:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l10, !tbaa !29
  %t102 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisAdapter(ptr %v0, ptr %v1, ptr %t98, ptr %t99)
  store i1 %t102, ptr %l60
  br label %bb20
bb20:
  %t103 = load i1, ptr %l60, !tbaa !21
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb21
bb21:
  %t104 = load i1, ptr %l57, !tbaa !21
  br i1 %t104, label %bb22, label %bb23
bb22:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = load i64, ptr %l7, !tbaa !24
  %t109 = add i64 %t107, 1
  %t110 = load i32, ptr %l9, !tbaa !23
  %t112 = sext i32 %t110 to i64
  %t117 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eonlyCalled(ptr %v0, ptr %v1, ptr %t105, { i64, ptr } %t106, i64 %t109, i64 %t112)
  store i1 %t117, ptr %l68
  br label %bb24
bb23:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb25
bb24:
  %t118 = load i1, ptr %l68, !tbaa !21
  store i1 %t118, ptr %l61, !tbaa !21
  br label %bb25
bb25:
  %t119 = load i1, ptr %l61, !tbaa !21
  br i1 %t119, label %bb26, label %bb27
bb26:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/scope:Scoper", ptr %t120, i32 0, i32 68
  store i1 true, ptr %t122, !tbaa !21
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_894def51c550c10b_edf695233d65cd0f)
  unreachable
bb34:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmt(ptr %v0, ptr %v1, ptr %t123, ptr %t124)
  br label %bb35
bb35:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/scope:Scoper", ptr %t128, i32 0, i32 68
  store i1 false, ptr %t130, !tbaa !21
  br label %bb36
bb36:
  %t131 = load i64, ptr %l6, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l6, !tbaa !24
  br label %bb7
bb37:
  br label %ret
ret:
  ret void
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i1
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l36 = alloca %"compiler/scope:Val"
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca { i64, [2 x i64] }
  %l47 = alloca ptr
  %l48 = alloca i1
  %l55 = alloca i32
  %l60 = alloca i32
  %l63 = alloca i1
  %l68 = alloca i32
  %l73 = alloca { i64, [2 x i64] }
  %l77 = alloca { i64, [2 x i64] }
  %l78 = alloca ptr
  %l79 = alloca i1
  %l87 = alloca { i64, [2 x i64] }
  %l88 = alloca ptr
  %l89 = alloca i1
  %l99 = alloca { i64, [2 x i64] }
  %l101 = alloca { i64, [2 x i64] }
  %l102 = alloca ptr
  %l103 = alloca i1
  %l108 = alloca i64
  %l110 = alloca ptr
  %l112 = alloca ptr
  %l115 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t35 = alloca { i64, [2 x i64] }, align 8
  %t57 = alloca { i64, [2 x i64] }, align 8
  %t248 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 32
  %t19 = load i32, ptr %l2, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t18, i64 %t21)
  store { i64, [2 x i64] } %t24, ptr %l20
  br label %bb6
bb6:
  %t25 = load { i64, [2 x i64] }, ptr %l20
  store { i64, [2 x i64] } %t25, ptr %rv
  br label %ret
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t27 = load ptr, ptr %l21, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 1
  store i1 %t33, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store { i64, [2 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 0
  store i64 3, ptr %t36
  %t37 = load { i64, [2 x i64] }, ptr %t35
  store { i64, [2 x i64] } %t37, ptr %rv
  br label %ret
bb13:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t40 = load ptr, ptr %l26, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t43 = load ptr, ptr %l26, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 2
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t47 = load i1, ptr %l27, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [2 x i64] }, ptr %t57, i32 0, i32 0
  store i64 0, ptr %t58
  %t59 = load { i64, [2 x i64] }, ptr %t57
  %t63 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t54, ptr %t55, { i64, [2 x i64] } %t59)
  store %"compiler/scope:Val" %t63, ptr %l36
  br label %bb19
bb19:
  %t64 = getelementptr %"compiler/scope:Val", ptr %l36, i32 0, i32 1
  %t65 = load { i64, [2 x i64] }, ptr %t64
  store { i64, [2 x i64] } %t65, ptr %rv
  br label %ret
bb20:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t68 = load ptr, ptr %l38, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = load i64, ptr %t71
  %t74 = icmp eq i64 %t72, 3
  store i1 %t74, ptr %l39, !tbaa !21
  br label %bb22
bb22:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb23, label %bb24
bb23:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l4, !tbaa !29
  %t86 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorOf(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  store { i64, [2 x i64] } %t86, ptr %l46
  br label %bb26
bb26:
  %t87 = load { i64, [2 x i64] }, ptr %l46
  store { i64, [2 x i64] } %t87, ptr %rv
  br label %ret
bb27:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t89 = load ptr, ptr %l47, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb28, label %bb29
bb28:
  %t92 = load ptr, ptr %l47, !tbaa !29
  %t93 = load i64, ptr %t92
  %t95 = icmp eq i64 %t93, 4
  store i1 %t95, ptr %l48, !tbaa !21
  br label %bb29
bb29:
  %t96 = load i1, ptr %l48, !tbaa !21
  br i1 %t96, label %bb30, label %bb31
bb30:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l5, !tbaa !29
  br label %bb32
bb31:
  br label %bb44
bb32:
  %t103 = load ptr, ptr %l5, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Elem", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t106)
  store i32 %t108, ptr %l55
  br label %bb33
bb33:
  %t109 = load i32, ptr %l55, !tbaa !23
  store i32 %t109, ptr %l6, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/scope:Scoper", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l6, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l60
  br label %bb34
bb34:
  %t120 = load i32, ptr %l60
  %t122 = trunc i64 19 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb35, label %bb36
bb35:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/scope:Scoper", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t128, i32 0, i32 2
  %t131 = load i32, ptr %l6, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t134, ptr %l68
  br label %bb37
bb36:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb38
bb37:
  %t135 = load i32, ptr %l68, !tbaa !23
  %t136 = icmp eq i32 %t135, 0
  store i1 %t136, ptr %l63, !tbaa !21
  br label %bb38
bb38:
  %t138 = load i1, ptr %l63, !tbaa !21
  br i1 %t138, label %bb39, label %bb40
bb39:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l5, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Elem", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t146 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %t139, ptr %t143)
  store { i64, [2 x i64] } %t146, ptr %l73
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t147 = load { i64, [2 x i64] }, ptr %l73
  store { i64, [2 x i64] } %t147, ptr %rv
  br label %ret
bb42:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l5, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Elem", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t155 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorOf(ptr %v0, ptr %v1, ptr %t148, ptr %t152)
  store { i64, [2 x i64] } %t155, ptr %l77
  br label %bb43
bb43:
  %t156 = load { i64, [2 x i64] }, ptr %l77
  store { i64, [2 x i64] } %t156, ptr %rv
  br label %ret
bb44:
  %t157 = load ptr, ptr %l1, !tbaa !29
  store ptr %t157, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t158 = load ptr, ptr %l78, !tbaa !29
  %t159 = icmp ne ptr %t158, null
  br i1 %t159, label %bb45, label %bb46
bb45:
  %t161 = load ptr, ptr %l78, !tbaa !29
  %t162 = load i64, ptr %t161
  %t164 = icmp eq i64 %t162, 5
  store i1 %t164, ptr %l79, !tbaa !21
  br label %bb46
bb46:
  %t165 = load i1, ptr %l79, !tbaa !21
  br i1 %t165, label %bb47, label %bb48
bb47:
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t168, i32 0, i32 2
  %t170 = load ptr, ptr %t169
  store ptr %t170, ptr %l7, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l7, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Payload", ptr %t173, i32 0, i32 0
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t179 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorOf(ptr %v0, ptr %v1, ptr %t172, ptr %t176)
  store { i64, [2 x i64] } %t179, ptr %l87
  br label %bb50
bb50:
  %t180 = load { i64, [2 x i64] }, ptr %l87
  store { i64, [2 x i64] } %t180, ptr %rv
  br label %ret
bb51:
  %t181 = load ptr, ptr %l1, !tbaa !29
  store ptr %t181, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t182 = load ptr, ptr %l88, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb52, label %bb53
bb52:
  %t185 = load ptr, ptr %l88, !tbaa !29
  %t186 = load i64, ptr %t185
  %t188 = icmp eq i64 %t186, 6
  store i1 %t188, ptr %l89, !tbaa !21
  br label %bb53
bb53:
  %t189 = load i1, ptr %l89, !tbaa !21
  br i1 %t189, label %bb54, label %bb55
bb54:
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = getelementptr { i64, [4 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t192, i32 0, i32 2
  %t194 = load ptr, ptr %t193
  store ptr %t194, ptr %l8, !tbaa !29
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t198, i32 0, i32 3
  %t200 = load i32, ptr %t199
  store i32 %t200, ptr %l9, !tbaa !23
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l8, !tbaa !29
  %t204 = load i32, ptr %l9, !tbaa !23
  %t208 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etempTerm(ptr %v0, ptr %v1, ptr %t202, ptr %t203, i32 %t204)
  store { i64, [2 x i64] } %t208, ptr %l99
  br label %bb57
bb57:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eframeHere(ptr %v0, ptr %t209)
  store { i64, [2 x i64] } %t211, ptr %l101
  br label %bb58
bb58:
  %t212 = load { i64, [2 x i64] }, ptr %l101
  store { i64, [2 x i64] } %t212, ptr %rv
  br label %ret
bb59:
  %t213 = load ptr, ptr %l1, !tbaa !29
  store ptr %t213, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t214 = load ptr, ptr %l102, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb60, label %bb61
bb60:
  %t217 = load ptr, ptr %l102, !tbaa !29
  %t218 = load i64, ptr %t217
  %t220 = icmp eq i64 %t218, 7
  store i1 %t220, ptr %l103, !tbaa !21
  br label %bb61
bb61:
  %t221 = load i1, ptr %l103, !tbaa !21
  br i1 %t221, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb72
bb64:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/scope:Scoper", ptr %t222, i32 0, i32 57
  %t226 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t224)
  store i64 %t226, ptr %l108
  br label %bb65
bb65:
  %t227 = load i64, ptr %l108, !tbaa !24
  %t228 = icmp sge i64 %t227, 2
  br i1 %t228, label %bb66, label %bb67
bb66:
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l110, !tbaa !29
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/scope:Scoper", ptr %t231, i32 0, i32 57
  store ptr %t233, ptr %l112, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/scope:Scoper", ptr %t234, i32 0, i32 57
  %t238 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t236)
  store i64 %t238, ptr %l115
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t239 = load i64, ptr %l115, !tbaa !24
  %t240 = sub i64 %t239, 2
  %t241 = load ptr, ptr %l112, !tbaa !29
  %t243 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v0, ptr %t241, i64 %t240)
  store ptr %t243, ptr %l117
  br label %bb69
bb69:
  %t244 = load ptr, ptr %l110, !tbaa !29
  %t245 = load ptr, ptr %l117, !tbaa !29
  %t246 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorOf(ptr %v0, ptr %v0, ptr %t244, ptr %t245)
  store { i64, [2 x i64] } %t246, ptr %l118
  br label %bb70
bb70:
  %t247 = load { i64, [2 x i64] }, ptr %l118
  store { i64, [2 x i64] } %t247, ptr %rv
  br label %ret
bb71:
  store { i64, [2 x i64] } zeroinitializer, ptr %t248
  %t249 = getelementptr { i64, [2 x i64] }, ptr %t248, i32 0, i32 0
  store i64 6, ptr %t249
  %t250 = load { i64, [2 x i64] }, ptr %t248
  store { i64, [2 x i64] } %t250, ptr %rv
  br label %ret
bb72:
  call void @__olang_check_failed(ptr @olang_loc_8bfac37a1f29704b_1a5bb9d5b57da78f)
  unreachable
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorageTerm(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %rv = alloca { i64, [2 x i64] }
  %t12 = alloca { i64, [2 x i64] }, align 8
  %t19 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 39
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/scope:Scoper", ptr %t8, i32 0, i32 39
  %t11 = load i64, ptr %t10, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [2 x i64] }, ptr %t12, i32 0, i32 0
  store i64 2, ptr %t13
  %t15 = insertvalue { i64 } undef, i64 %t11, 0
  %t16 = getelementptr { i64, [2 x i64] }, ptr %t12, i32 0, i32 1
  store { i64 } %t15, ptr %t16
  %t17 = load { i64, [2 x i64] }, ptr %t12
  store { i64, [2 x i64] } %t17, ptr %l4
  br label %bb3
bb2:
  store { i64, [2 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 0
  store i64 3, ptr %t20
  %t21 = load { i64, [2 x i64] }, ptr %t19
  store { i64, [2 x i64] } %t21, ptr %l4
  br label %bb3
bb3:
  %t23 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esummed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca ptr
  %l8 = alloca i1
  %l12 = alloca ptr
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"compiler/scope:summary", ptr %t8, i32 0, i32 14
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/scope:Scoper", ptr %t13, i32 0, i32 6
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t22 = getelementptr %"compiler/scope:summary", ptr %t20, i32 0, i32 15
  %t23 = load i1, ptr %t22, !tbaa !21
  store i1 %t23, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l8, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l29 = alloca i1
  %l34 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t16 = load i64, ptr %l7, !tbaa !24
  %t19 = icmp slt i64 %t15, %t16
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb5, label %bb6
bb5:
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t23, ptr %l20, !tbaa !27
  %t24 = load i64, ptr %l6, !tbaa !24
  %t26 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 %t24
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l8, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l8, !tbaa !29
  %t42 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t31, ptr %a1, ptr %t33, i64 %a3, i64 %a4)
  store i1 %t42, ptr %l29
  br label %bb8
bb8:
  %t43 = load i1, ptr %l29, !tbaa !21
  %t44 = xor i1 %t43, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/scope:Scoper", ptr %t46, i32 0, i32 96
  %t49 = getelementptr %"compiler/source:Span", ptr %t48, i32 0, i32 1
  %t50 = load i32, ptr %t49, !tbaa !23
  %t52 = icmp eq i32 %t50, 0
  br i1 %t52, label %bb11, label %bb12
bb10:
  br label %bb15
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l34, !tbaa !29
  %t55 = load ptr, ptr %l8, !tbaa !29
  %t57 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v2, ptr %t55)
  store %"compiler/source:Span" %t57, ptr %l36
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t58 = load %"compiler/source:Span", ptr %l36
  %t59 = load ptr, ptr %l34, !tbaa !29
  %t60 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 96
  store %"compiler/source:Span" %t58, ptr %t60
  br label %bb14
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb4
bb17:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunPromoted(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %a0, ptr %t2)
  store ptr %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l7, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %t12
  %t15 = icmp eq i64 %t13, 5
  store i1 %t15, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l3, !tbaa !29
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Promote", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l8, !tbaa !29
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l8, !tbaa !29
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_f9519574182490d7_42fc30f708795ccb)
  unreachable
bb12:
  %t30 = load ptr, ptr %l8, !tbaa !29
  store ptr %t30, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunknownBinding(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i1
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb12
bb3:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb11
bb5:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = sub i64 0, %t14
  %t18 = sub i64 %t16, 1
  store i64 %t18, ptr %l12, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 88
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load i64, ptr %l12, !tbaa !24
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/scope:Scoper", ptr %t28, i32 0, i32 88
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = sub i64 0, %t31
  %t35 = sub i64 %t33, 1
  %t38 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t30, i64 %t35)
  store i1 %t38, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb10
bb9:
  %t39 = load i1, ptr %l23, !tbaa !21
  store i1 %t39, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l17, !tbaa !21
  store i1 %t40, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  %t41 = load i1, ptr %l9, !tbaa !21
  store i1 %t41, ptr %l3, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_32e8be698fa34edf_ce62f399ed2770f3)
  unreachable
bb17:
  %t42 = load i1, ptr %l3, !tbaa !21
  store i1 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca %"compiler/scope:Val"
  %l13 = alloca ptr
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca { i64, [2 x i64] }
  %l50 = alloca ptr
  %l51 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca { i64, [2 x i64] }
  %l53 = alloca %"compiler/scope:Val"
  %l55 = alloca ptr
  %l56 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca %"compiler/scope:Val"
  %l60 = alloca { i64, [2 x i64] }
  %l61 = alloca %"compiler/scope:Val"
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca %"compiler/scope:Val"
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l82 = alloca %"compiler/scope:Val"
  %l84 = alloca i1
  %l85 = alloca { i64, [2 x i64] }
  %l88 = alloca { i64, [2 x i64] }
  %l89 = alloca ptr
  %l90 = alloca i1
  %l97 = alloca i1
  %l100 = alloca %"compiler/scope:Val"
  %l101 = alloca %"compiler/scope:Val"
  %l102 = alloca ptr
  %l103 = alloca i1
  %l108 = alloca %"compiler/scope:Val"
  %l109 = alloca ptr
  %l110 = alloca i1
  %l121 = alloca %"compiler/scope:Val"
  %l122 = alloca ptr
  %l123 = alloca i1
  %l134 = alloca %"compiler/scope:Val"
  %l135 = alloca ptr
  %l136 = alloca i1
  %l145 = alloca { i64, [2 x i64] }
  %l146 = alloca %"compiler/scope:Val"
  %l147 = alloca ptr
  %l148 = alloca i1
  %l156 = alloca ptr
  %l158 = alloca i32
  %l159 = alloca { i64, [2 x i64] }
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca ptr
  %l165 = alloca i1
  %l168 = alloca i1
  %l174 = alloca %"compiler/scope:Val"
  %l178 = alloca ptr
  %l182 = alloca ptr
  %l188 = alloca { i64, [2 x i64] }
  %l193 = alloca %"compiler/scope:Val"
  %l196 = alloca i1
  %l197 = alloca ptr
  %l200 = alloca i32
  %l201 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca { i64, [2 x i64] }
  %l204 = alloca { i64, [2 x i64] }
  %l205 = alloca ptr
  %l208 = alloca i32
  %l209 = alloca i1
  %l211 = alloca ptr
  %l213 = alloca i64
  %l217 = alloca %"compiler/scope:Val"
  %l218 = alloca ptr
  %l219 = alloca i1
  %l233 = alloca %"compiler/scope:Val"
  %l234 = alloca ptr
  %l235 = alloca i1
  %l244 = alloca i64
  %l249 = alloca i64
  %l262 = alloca %"compiler/scope:Val"
  %l265 = alloca i64
  %l266 = alloca %"compiler/scope:Val"
  %l268 = alloca %"compiler/scope:Val"
  %l278 = alloca i64
  %l281 = alloca i64
  %l299 = alloca i64
  %l302 = alloca { i64, ptr }
  %l307 = alloca %"compiler/scope:Val"
  %l314 = alloca i1
  %l318 = alloca i1
  %l323 = alloca i1
  %l330 = alloca i64
  %l333 = alloca i64
  %l354 = alloca i1
  %l355 = alloca ptr
  %l357 = alloca { i64, ptr }
  %l360 = alloca i32
  %l361 = alloca i1
  %l364 = alloca i1
  %l368 = alloca i1
  %l371 = alloca ptr
  %l373 = alloca { i64, [2 x i64] }
  %l374 = alloca { i64, [2 x i64] }
  %l375 = alloca ptr
  %l377 = alloca { i64, ptr }
  %l380 = alloca i32
  %l381 = alloca i1
  %l383 = alloca { i64, ptr }
  %l391 = alloca i1
  %l393 = alloca i1
  %l397 = alloca %"compiler/scope:Val"
  %l399 = alloca %"compiler/scope:Val"
  %l400 = alloca ptr
  %l401 = alloca i1
  %l414 = alloca %"compiler/scope:Val"
  %l420 = alloca %"compiler/scope:Val"
  %l421 = alloca ptr
  %l422 = alloca i1
  %l432 = alloca i1
  %l433 = alloca i1
  %l437 = alloca i1
  %l440 = alloca i1
  %l441 = alloca i1
  %l444 = alloca i1
  %l449 = alloca { i64, ptr }
  %l453 = alloca %"compiler/scope:Val"
  %l463 = alloca { i64, ptr }
  %l470 = alloca %"compiler/scope:Val"
  %l473 = alloca %"compiler/scope:Val"
  %l474 = alloca ptr
  %l475 = alloca i1
  %l489 = alloca i64
  %l496 = alloca i1
  %l497 = alloca i1
  %l500 = alloca ptr
  %l504 = alloca %"compiler/source:Span"
  %l505 = alloca %"compiler/msgs:Msg"
  %l506 = alloca i64
  %l512 = alloca %"compiler/scope:Val"
  %l518 = alloca %"compiler/scope:Val"
  %l522 = alloca { i64, [2 x i64] }
  %l528 = alloca i1
  %l530 = alloca %"compiler/scope:Val"
  %l531 = alloca ptr
  %l532 = alloca i1
  %l542 = alloca %"compiler/scope:Val"
  %l543 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l544 = alloca ptr
  %l556 = alloca { i64, [2 x i64] }
  %l561 = alloca %"compiler/scope:Val"
  %l567 = alloca %"compiler/scope:Val"
  %l572 = alloca %"compiler/scope:Val"
  %l573 = alloca ptr
  %l574 = alloca i1
  %l591 = alloca %"compiler/scope:Val"
  %l592 = alloca ptr
  %l593 = alloca i1
  %l601 = alloca %"compiler/scope:Val"
  %l602 = alloca ptr
  %l603 = alloca i1
  %l612 = alloca %"compiler/scope:Val"
  %l615 = alloca i1
  %l618 = alloca i1
  %l620 = alloca i1
  %l621 = alloca { i64, [2 x i64] }
  %l633 = alloca { i64, ptr }
  %l647 = alloca { i64, ptr }
  %l654 = alloca %"compiler/scope:Val"
  %l657 = alloca i1
  %l658 = alloca ptr
  %l660 = alloca i32
  %l661 = alloca i1
  %l662 = alloca i1
  %l666 = alloca i1
  %l668 = alloca ptr
  %l671 = alloca %"compiler/source:Span"
  %l672 = alloca %"compiler/msgs:Msg"
  %l673 = alloca i64
  %l678 = alloca %"compiler/scope:Val"
  %l684 = alloca ptr
  %l685 = alloca i1
  %l696 = alloca %"compiler/scope:Val"
  %l697 = alloca ptr
  %l698 = alloca i1
  %l715 = alloca { i64, ptr }
  %l718 = alloca ptr
  %l719 = alloca i1
  %l728 = alloca %"compiler/scope:Val"
  %l732 = alloca %"compiler/scope:Val"
  %l733 = alloca ptr
  %l734 = alloca i1
  %l743 = alloca %"compiler/scope:Val"
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %rv = alloca %"compiler/scope:Val"
  %t39 = alloca { i64, [2 x i64] }, align 8
  %t57 = alloca { i64, [2 x i64] }, align 8
  %t410 = alloca { i64, [2 x i64] }, align 8
  %t438 = alloca i64
  %t754 = alloca { i64, [2 x i64] }, align 8
  %t876 = alloca { i64, [2 x i64] }, align 8
  %t970 = alloca { i64, [2 x i64] }, align 8
  %t983 = alloca { i64, [2 x i64] }, align 8
  %t1035 = alloca { i64, [2 x i64] }, align 8
  %t1445 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/scope:Val" @compiler_2fscope_2eplain()
  store %"compiler/scope:Val" %t5, ptr %l82
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load %"compiler/scope:Val", ptr %l82
  store %"compiler/scope:Val" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load { i64, [2 x i64] }, ptr %l2
  %t9 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t7)
  store i1 %t9, ptr %l84
  br label %bb5
bb5:
  %t10 = load i1, ptr %l84, !tbaa !21
  br i1 %t10, label %bb6, label %bb7
bb6:
  %t11 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t11, ptr %l85
  br label %bb9
bb7:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %t13)
  store { i64, [2 x i64] } %t15, ptr %l88
  br label %bb8
bb8:
  %t16 = load { i64, [2 x i64] }, ptr %l88
  store { i64, [2 x i64] } %t16, ptr %l85
  br label %bb9
bb9:
  %t17 = load { i64, [2 x i64] }, ptr %l85
  store { i64, [2 x i64] } %t17, ptr %l3
  %t18 = load ptr, ptr %l1, !tbaa !29
  store ptr %t18, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t19 = load ptr, ptr %l89, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb10, label %bb11
bb10:
  %t22 = load ptr, ptr %l89, !tbaa !29
  %t23 = load i64, ptr %t22
  %t25 = icmp eq i64 %t23, 0
  store i1 %t25, ptr %l90, !tbaa !21
  br label %bb11
bb11:
  %t26 = load i1, ptr %l90, !tbaa !21
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t29, i32 0, i32 1
  %t31 = load i32, ptr %t30
  store i32 %t31, ptr %l4, !tbaa !23
  br label %bb14
bb13:
  br label %bb21
bb14:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t37 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l97
  br label %bb15
bb15:
  %t38 = load i1, ptr %l97, !tbaa !21
  br i1 %t38, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, [2 x i64] } zeroinitializer, ptr %t39
  %t40 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 0
  store i64 0, ptr %t40
  %t41 = load { i64, [2 x i64] }, ptr %t39
  %t44 = call %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %s3, i32 1, { i64, [2 x i64] } %t41)
  store %"compiler/scope:Val" %t44, ptr %l100
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  %t45 = load %"compiler/scope:Val", ptr %l100
  store %"compiler/scope:Val" %t45, ptr %rv
  br label %ret
bb19:
  %t46 = call %"compiler/scope:Val" @compiler_2fscope_2eplain()
  store %"compiler/scope:Val" %t46, ptr %l101
  br label %bb20
bb20:
  %t47 = load %"compiler/scope:Val", ptr %l101
  store %"compiler/scope:Val" %t47, ptr %rv
  br label %ret
bb21:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t49 = load ptr, ptr %l102, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb22, label %bb23
bb22:
  %t52 = load ptr, ptr %l102, !tbaa !29
  %t53 = load i64, ptr %t52
  %t55 = icmp eq i64 %t53, 1
  store i1 %t55, ptr %l103, !tbaa !21
  br label %bb23
bb23:
  %t56 = load i1, ptr %l103, !tbaa !21
  br i1 %t56, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, [2 x i64] } zeroinitializer, ptr %t57
  %t58 = getelementptr { i64, [2 x i64] }, ptr %t57, i32 0, i32 0
  store i64 3, ptr %t58
  %t59 = load { i64, [2 x i64] }, ptr %t57
  %t62 = call %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %s4, i32 4, { i64, [2 x i64] } %t59)
  store %"compiler/scope:Val" %t62, ptr %l108
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  %t63 = load %"compiler/scope:Val", ptr %l108
  store %"compiler/scope:Val" %t63, ptr %rv
  br label %ret
bb28:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t65 = load ptr, ptr %l109, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb29, label %bb30
bb29:
  %t68 = load ptr, ptr %l109, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 2
  store i1 %t71, ptr %l110, !tbaa !21
  br label %bb30
bb30:
  %t72 = load i1, ptr %l110, !tbaa !21
  br i1 %t72, label %bb31, label %bb32
bb31:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t75, i32 0, i32 1
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l5, !tbaa !23
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [5 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l6, !tbaa !29
  %t87 = load i32, ptr %l5, !tbaa !23
  %t88 = load { i64, [2 x i64] }, ptr %l2
  %t93 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eread(ptr %v0, ptr %v1, ptr %t85, ptr %t86, i32 %t87, { i64, [2 x i64] } %t88)
  store %"compiler/scope:Val" %t93, ptr %l121
  br label %bb34
bb34:
  %t94 = load %"compiler/scope:Val", ptr %l121
  store %"compiler/scope:Val" %t94, ptr %rv
  br label %ret
bb35:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t96 = load ptr, ptr %l122, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load ptr, ptr %l122, !tbaa !29
  %t100 = load i64, ptr %t99
  %t102 = icmp eq i64 %t100, 4
  store i1 %t102, ptr %l123, !tbaa !21
  br label %bb37
bb37:
  %t103 = load i1, ptr %l123, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 1
  %t108 = load i32, ptr %t107
  store i32 %t108, ptr %l7, !tbaa !23
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t112, i32 0, i32 2
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l8, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l8, !tbaa !29
  %t118 = load i32, ptr %l7, !tbaa !23
  %t119 = load { i64, [2 x i64] }, ptr %l2
  %t124 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eread(ptr %v0, ptr %v1, ptr %t116, ptr %t117, i32 %t118, { i64, [2 x i64] } %t119)
  store %"compiler/scope:Val" %t124, ptr %l134
  br label %bb41
bb41:
  %t125 = load %"compiler/scope:Val", ptr %l134
  store %"compiler/scope:Val" %t125, ptr %rv
  br label %ret
bb42:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t127 = load ptr, ptr %l135, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb43, label %bb44
bb43:
  %t130 = load ptr, ptr %l135, !tbaa !29
  %t131 = load i64, ptr %t130
  %t133 = icmp eq i64 %t131, 3
  store i1 %t133, ptr %l136, !tbaa !21
  br label %bb44
bb44:
  %t134 = load i1, ptr %l136, !tbaa !21
  br i1 %t134, label %bb45, label %bb46
bb45:
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t137, i32 0, i32 2
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l9, !tbaa !29
  br label %bb47
bb46:
  br label %bb51
bb47:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceOperands(ptr %v0, ptr %v1, ptr %t141, ptr %t142)
  br label %bb48
bb48:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l9, !tbaa !29
  %t149 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estorOf(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  store { i64, [2 x i64] } %t149, ptr %l145
  br label %bb49
bb49:
  %t150 = load { i64, [2 x i64] }, ptr %l145
  %t151 = call %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %t150)
  store %"compiler/scope:Val" %t151, ptr %l146
  br label %bb50
bb50:
  %t152 = load %"compiler/scope:Val", ptr %l146
  store %"compiler/scope:Val" %t152, ptr %rv
  br label %ret
bb51:
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t154 = load ptr, ptr %l147, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb52, label %bb53
bb52:
  %t157 = load ptr, ptr %l147, !tbaa !29
  %t158 = load i64, ptr %t157
  %t160 = icmp eq i64 %t158, 5
  store i1 %t160, ptr %l148, !tbaa !21
  br label %bb53
bb53:
  %t161 = load i1, ptr %l148, !tbaa !21
  br i1 %t161, label %bb54, label %bb55
bb54:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr { i64, [5 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t164, i32 0, i32 2
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l10, !tbaa !29
  br label %bb56
bb55:
  br label %bb91
bb56:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/scope:Scoper", ptr %t168, i32 0, i32 69
  %t171 = load i1, ptr %t170, !tbaa !21
  store i1 %t171, ptr %l11, !tbaa !21
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/scope:Scoper", ptr %t173, i32 0, i32 69
  store i1 false, ptr %t175, !tbaa !21
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l156, !tbaa !29
  %t177 = load ptr, ptr %l10, !tbaa !29
  %t179 = getelementptr %"compiler/typed:Promote", ptr %t177, i32 0, i32 1
  %t180 = load i32, ptr %t179, !tbaa !23
  store i32 %t180, ptr %l158, !tbaa !23
  %t181 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t181, ptr %l159
  %t182 = load ptr, ptr %l10, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Promote", ptr %t182, i32 0, i32 0
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t185)
  store %"compiler/source:Span" %t187, ptr %l162
  br label %bb57
bb57:
  %t188 = load ptr, ptr %l156, !tbaa !29
  %t189 = load i32, ptr %l158, !tbaa !23
  %t190 = load { i64, [2 x i64] }, ptr %l159
  %t191 = load %"compiler/source:Span", ptr %l162
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildSite(ptr %v0, ptr %t188, i32 %t189, { i64, [2 x i64] } %t190, %"compiler/source:Span" %t191)
  br label %bb58
bb58:
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l163, !tbaa !29
  %t193 = load i1, ptr %l11, !tbaa !21
  br i1 %t193, label %bb59, label %bb60
bb59:
  %t195 = load ptr, ptr %l10, !tbaa !29
  %t197 = getelementptr %"compiler/typed:Promote", ptr %t195, i32 0, i32 0
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = call i1 @compiler_2fscope_2eanyArrayBox(ptr %v1, ptr %t198)
  store i1 %t200, ptr %l168
  br label %bb61
bb60:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb62
bb61:
  %t201 = load i1, ptr %l168, !tbaa !21
  store i1 %t201, ptr %l165, !tbaa !21
  br label %bb62
bb62:
  %t202 = load i1, ptr %l165, !tbaa !21
  %t203 = load ptr, ptr %l163, !tbaa !29
  %t204 = getelementptr %"compiler/scope:Scoper", ptr %t203, i32 0, i32 70
  store i1 %t202, ptr %t204, !tbaa !21
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l10, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Promote", ptr %t206, i32 0, i32 0
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = load { i64, [2 x i64] }, ptr %l3
  %t215 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t205, ptr %t209, { i64, [2 x i64] } %t211)
  store %"compiler/scope:Val" %t215, ptr %l174
  br label %bb63
bb63:
  %t216 = load %"compiler/scope:Val", ptr %l174
  store %"compiler/scope:Val" %t216, ptr %l12
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/scope:Scoper", ptr %t217, i32 0, i32 70
  store i1 false, ptr %t219, !tbaa !21
  %t220 = load i1, ptr %l11, !tbaa !21
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb64, label %bb65
bb64:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l10, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Promote", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t231 = call ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2econvertedPlace(ptr %v0, ptr %v1, ptr %t224, ptr %t228)
  store ptr %t231, ptr %l182
  br label %bb66
bb65:
  store ptr null, ptr %l178, !tbaa !29
  br label %bb67
bb66:
  %t232 = load ptr, ptr %l182, !tbaa !29
  store ptr %t232, ptr %l178, !tbaa !29
  br label %bb67
bb67:
  %t233 = load ptr, ptr %l178, !tbaa !29
  store ptr %t233, ptr %l13, !tbaa !29
  %t234 = load ptr, ptr %l13, !tbaa !29
  %t236 = icmp eq ptr %t234, null
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb68, label %bb69
bb68:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l13, !tbaa !29
  %t244 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %t240, ptr %t241, i1 false)
  store { i64, [2 x i64] } %t244, ptr %l188
  br label %bb70
bb69:
  br label %bb75
bb70:
  %t245 = load { i64, [2 x i64] }, ptr %l188
  store { i64, [2 x i64] } %t245, ptr %l14
  %t246 = load { i64, [2 x i64] }, ptr %l14
  %t248 = extractvalue { i64, [2 x i64] } %t246, 0
  %t249 = icmp eq i64 %t248, 0
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb71, label %bb72
bb71:
  %t253 = load { i64, [2 x i64] }, ptr %l14
  %t255 = call %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %t253)
  store %"compiler/scope:Val" %t255, ptr %l193
  br label %bb73
bb72:
  br label %bb74
bb73:
  %t256 = load %"compiler/scope:Val", ptr %l193
  store %"compiler/scope:Val" %t256, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  %t257 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 0
  %t258 = load i32, ptr %t257
  %t260 = trunc i64 3 to i32
  %t261 = icmp eq i32 %t258, %t260
  br i1 %t261, label %bb76, label %bb77
bb76:
  %t263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t263, ptr %l197, !tbaa !29
  %t264 = load ptr, ptr %l10, !tbaa !29
  %t266 = getelementptr %"compiler/typed:Promote", ptr %t264, i32 0, i32 0
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t267)
  store i32 %t269, ptr %l200
  br label %bb78
bb77:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb80
bb78:
  %t270 = load ptr, ptr %l197, !tbaa !29
  %t271 = load i32, ptr %l200, !tbaa !23
  %t272 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t270, i32 %t271)
  store i1 %t272, ptr %l201
  br label %bb79
bb79:
  %t273 = load i1, ptr %l201, !tbaa !21
  store i1 %t273, ptr %l196, !tbaa !21
  br label %bb80
bb80:
  %t274 = load i1, ptr %l196, !tbaa !21
  br i1 %t274, label %bb81, label %bb82
bb81:
  %t275 = load ptr, ptr %l0, !tbaa !29
  store ptr %t275, ptr %l202, !tbaa !29
  %t276 = getelementptr %"compiler/scope:Val", ptr %l12, i32 0, i32 1
  %t277 = load { i64, [2 x i64] }, ptr %t276
  store { i64, [2 x i64] } %t277, ptr %l203
  %t278 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t278, ptr %l204
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l205, !tbaa !29
  %t280 = load ptr, ptr %l10, !tbaa !29
  %t282 = getelementptr %"compiler/typed:Promote", ptr %t280, i32 0, i32 0
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t285 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t283)
  store i32 %t285, ptr %l208
  br label %bb83
bb82:
  br label %bb89
bb83:
  %t286 = load ptr, ptr %l205, !tbaa !29
  %t287 = load i32, ptr %l208, !tbaa !23
  %t288 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t286, i32 %t287)
  store i1 %t288, ptr %l209
  br label %bb84
bb84:
  %t289 = load ptr, ptr %l10, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Promote", ptr %t289, i32 0, i32 0
  %t292 = load ptr, ptr %t291, !tbaa !29
  store ptr %t292, ptr %l211, !tbaa !29
  %t293 = load i1, ptr %l11, !tbaa !21
  br i1 %t293, label %bb85, label %bb86
bb85:
  %t295 = load i64, ptr @G_2ecompiler_2fscope_2eFitAnyCopy, !tbaa !24
  store i64 %t295, ptr %l213, !tbaa !24
  br label %bb87
bb86:
  %t297 = load i64, ptr @G_2ecompiler_2fscope_2eFitValue, !tbaa !24
  store i64 %t297, ptr %l213, !tbaa !24
  br label %bb87
bb87:
  %t299 = load ptr, ptr %l202, !tbaa !29
  %t300 = load { i64, [2 x i64] }, ptr %l203
  %t301 = load { i64, [2 x i64] }, ptr %l204
  %t302 = load i1, ptr %l209, !tbaa !21
  %t303 = load ptr, ptr %l211, !tbaa !29
  %t304 = load i64, ptr %l213, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t299, { i64, [2 x i64] } %t300, { i64, [2 x i64] } %t301, i1 %t302, ptr %t303, i64 %t304)
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t305 = load { i64, [2 x i64] }, ptr %l3
  %t307 = call %"compiler/scope:Val" @compiler_2fscope_2efresh({ i64, [2 x i64] } %t305)
  store %"compiler/scope:Val" %t307, ptr %l217
  br label %bb90
bb90:
  %t308 = load %"compiler/scope:Val", ptr %l217
  store %"compiler/scope:Val" %t308, ptr %rv
  br label %ret
bb91:
  %t309 = load ptr, ptr %l1, !tbaa !29
  store ptr %t309, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t310 = load ptr, ptr %l218, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb92, label %bb93
bb92:
  %t313 = load ptr, ptr %l218, !tbaa !29
  %t314 = load i64, ptr %t313
  %t316 = icmp eq i64 %t314, 6
  store i1 %t316, ptr %l219, !tbaa !21
  br label %bb93
bb93:
  %t317 = load i1, ptr %l219, !tbaa !21
  br i1 %t317, label %bb94, label %bb95
bb94:
  %t318 = load ptr, ptr %l1, !tbaa !29
  %t320 = getelementptr { i64, [5 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t320, i32 0, i32 0
  %t322 = load %"compiler/source:Span", ptr %t321
  store %"compiler/source:Span" %t322, ptr %l15
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = getelementptr { i64, [5 x i64] }, ptr %t324, i32 0, i32 1
  %t327 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t326, i32 0, i32 1
  %t328 = load i32, ptr %t327
  store i32 %t328, ptr %l16, !tbaa !23
  %t330 = load ptr, ptr %l1, !tbaa !29
  %t332 = getelementptr { i64, [5 x i64] }, ptr %t330, i32 0, i32 1
  %t333 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t332, i32 0, i32 2
  %t334 = load ptr, ptr %t333
  store ptr %t334, ptr %l17, !tbaa !29
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load %"compiler/source:Span", ptr %l15
  %t338 = load i32, ptr %l16, !tbaa !23
  %t339 = load ptr, ptr %l17, !tbaa !29
  %t340 = load { i64, [2 x i64] }, ptr %l2
  %t346 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecall(ptr %v0, ptr %v1, ptr %t336, %"compiler/source:Span" %t337, i32 %t338, ptr %t339, { i64, [2 x i64] } %t340)
  store %"compiler/scope:Val" %t346, ptr %l233
  br label %bb97
bb97:
  %t347 = load %"compiler/scope:Val", ptr %l233
  store %"compiler/scope:Val" %t347, ptr %rv
  br label %ret
bb98:
  %t348 = load ptr, ptr %l1, !tbaa !29
  store ptr %t348, ptr %l234, !tbaa !29
  store i1 false, ptr %l235, !tbaa !21
  %t349 = load ptr, ptr %l234, !tbaa !29
  %t350 = icmp ne ptr %t349, null
  br i1 %t350, label %bb99, label %bb100
bb99:
  %t352 = load ptr, ptr %l234, !tbaa !29
  %t353 = load i64, ptr %t352
  %t355 = icmp eq i64 %t353, 7
  store i1 %t355, ptr %l235, !tbaa !21
  br label %bb100
bb100:
  %t356 = load i1, ptr %l235, !tbaa !21
  br i1 %t356, label %bb101, label %bb102
bb101:
  %t357 = load ptr, ptr %l1, !tbaa !29
  %t359 = getelementptr { i64, [5 x i64] }, ptr %t357, i32 0, i32 1
  %t360 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t359, i32 0, i32 1
  %t361 = load i32, ptr %t360
  store i32 %t361, ptr %l18, !tbaa !23
  %t363 = load ptr, ptr %l1, !tbaa !29
  %t365 = getelementptr { i64, [5 x i64] }, ptr %t363, i32 0, i32 1
  %t366 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t365, i32 0, i32 2
  %t367 = load ptr, ptr %t366
  store ptr %t367, ptr %l19, !tbaa !29
  br label %bb103
bb102:
  br label %bb178
bb103:
  store %olang.scope zeroinitializer, ptr %s13
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/scope:Scoper", ptr %t369, i32 0, i32 70
  %t372 = load i1, ptr %t371, !tbaa !21
  br i1 %t372, label %bb104, label %bb105
bb104:
  %t374 = load i64, ptr @G_2ecompiler_2fscope_2eFitAnyCopy, !tbaa !24
  store i64 %t374, ptr %l244, !tbaa !24
  br label %bb107
bb105:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load ptr, ptr %l19, !tbaa !29
  %t379 = getelementptr %"compiler/typed:Make", ptr %t377, i32 0, i32 0
  %t380 = load i32, ptr %t379
  %t383 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eitemKind(ptr %v0, ptr %t376, i32 %t380)
  store i64 %t383, ptr %l249
  br label %bb106
bb106:
  %t384 = load i64, ptr %l249, !tbaa !24
  store i64 %t384, ptr %l244, !tbaa !24
  br label %bb107
bb107:
  %t385 = load i64, ptr %l244, !tbaa !24
  store i64 %t385, ptr %l20, !tbaa !24
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/scope:Scoper", ptr %t386, i32 0, i32 70
  store i1 false, ptr %t388, !tbaa !21
  %t389 = load ptr, ptr %l19, !tbaa !29
  %t391 = getelementptr %"compiler/typed:Make", ptr %t389, i32 0, i32 4
  %t392 = load i32, ptr %t391, !tbaa !23
  %t394 = icmp sge i32 %t392, 0
  br i1 %t394, label %bb108, label %bb109
bb108:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l19, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Make", ptr %t397, i32 0, i32 4
  %t400 = load i32, ptr %t399, !tbaa !23
  %t401 = load { i64, [2 x i64] }, ptr %l3
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuild(ptr %v0, ptr %t396, i32 %t400, { i64, [2 x i64] } %t401)
  br label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb111
bb111:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load ptr, ptr %l19, !tbaa !29
  %t408 = getelementptr %"compiler/typed:Make", ptr %t406, i32 0, i32 3
  %t409 = load ptr, ptr %t408, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t410
  %t411 = getelementptr { i64, [2 x i64] }, ptr %t410, i32 0, i32 0
  store i64 0, ptr %t411
  %t412 = load { i64, [2 x i64] }, ptr %t410
  %t416 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t405, ptr %t409, { i64, [2 x i64] } %t412)
  store %"compiler/scope:Val" %t416, ptr %l262
  br label %bb112
bb112:
  %t417 = load ptr, ptr %l19, !tbaa !29
  %t419 = getelementptr %"compiler/typed:Make", ptr %t417, i32 0, i32 2
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t420, 0
  store i64 %t422, ptr %l265, !tbaa !24
  store %"compiler/scope:Val" zeroinitializer, ptr %l266
  %t423 = load i64, ptr %l265, !tbaa !24
  %t424 = icmp sgt i64 %t423, 0
  br i1 %t424, label %bb113, label %bb114
bb113:
  %t426 = call %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %s13, i32 0, { i64, [2 x i64] } zeroinitializer)
  store %"compiler/scope:Val" %t426, ptr %l268
  br label %bb115
bb114:
  %t427 = load i64, ptr %l265, !tbaa !24
  %t428 = icmp sge i64 %t427, 0
  br i1 %t428, label %bb116, label %bb117
bb115:
  %t430 = load %"compiler/scope:Val", ptr %l268
  store %"compiler/scope:Val" %t430, ptr %l266
  br label %bb114
bb116:
  %t431 = load i64, ptr %l265, !tbaa !24
  %t432 = icmp sle i64 %t431, 288230376151711743
  br i1 %t432, label %bb118, label %bb119
bb117:
  call void @__olang_check_failed(ptr @olang_loc_c2fa93d259f2a930_39b628a0a193c8f4)
  unreachable
bb118:
  %t434 = load i64, ptr %l265, !tbaa !24
  %t435 = mul i64 %t434, 32
  %t436 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t435)
  %t437 = load %"compiler/scope:Val", ptr %l266
  store i64 0, ptr %t438
  br label %fill.439
fill.439:
  %t442 = load i64, ptr %t438
  %t443 = icmp slt i64 %t442, %t434
  br i1 %t443, label %fillb.440, label %filld.441
fillb.440:
  %t444 = getelementptr %"compiler/scope:Val", ptr %t436, i64 %t442
  store %"compiler/scope:Val" %t437, ptr %t444
  %t445 = add i64 %t442, 1
  store i64 %t445, ptr %t438
  br label %fill.439
filld.441:
  %t446 = insertvalue { i64, ptr } undef, i64 %t434, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t436, 1
  store { i64, ptr } %t447, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t449 = load ptr, ptr %l19, !tbaa !29
  %t451 = getelementptr %"compiler/typed:Make", ptr %t449, i32 0, i32 2
  %t452 = load { i64, ptr }, ptr %t451, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t452, 0
  store i64 %t454, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t456 = load i64, ptr %l23, !tbaa !24
  %t457 = load i64, ptr %l22, !tbaa !24
  %t460 = icmp sgt i64 %t456, %t457
  br i1 %t460, label %bb120, label %bb121
bb119:
  call void @__olang_check_failed(ptr @olang_loc_c2fa93d259f2a930_39b628a0a193c8f4)
  unreachable
bb120:
  %t462 = load i64, ptr %l24, !tbaa !24
  %t464 = icmp sgt i64 %t462, 0
  br i1 %t464, label %bb122, label %bb123
bb121:
  store i64 0, ptr %l278, !tbaa !24
  br label %bb125
bb122:
  %t466 = load i64, ptr %l23, !tbaa !24
  %t467 = load i64, ptr %l22, !tbaa !24
  %t470 = sub i64 %t466, %t467
  %t471 = load i64, ptr %l24, !tbaa !24
  %t474 = add i64 %t470, %t471
  %t476 = sub i64 %t474, 1
  %t477 = load i64, ptr %l24, !tbaa !24
  %t480 = sdiv i64 %t476, %t477
  store i64 %t480, ptr %l281, !tbaa !24
  br label %bb124
bb123:
  store i64 0, ptr %l281, !tbaa !24
  br label %bb124
bb124:
  %t482 = load i64, ptr %l281, !tbaa !24
  store i64 %t482, ptr %l278, !tbaa !24
  br label %bb125
bb125:
  %t483 = load i64, ptr %l278, !tbaa !24
  store i64 %t483, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb126
bb126:
  %t484 = load i64, ptr %l26, !tbaa !24
  %t485 = load i64, ptr %l25, !tbaa !24
  %t488 = icmp slt i64 %t484, %t485
  %t490 = xor i1 %t488, true
  br i1 %t490, label %bb127, label %bb128
bb127:
  br label %bb132
bb128:
  br label %bb129
bb129:
  %t492 = load i64, ptr %l22, !tbaa !24
  %t493 = load i64, ptr %l26, !tbaa !24
  %t494 = load i64, ptr %l24, !tbaa !24
  %t497 = mul i64 %t493, %t494
  %t500 = add i64 %t492, %t497
  store i64 %t500, ptr %l27, !tbaa !24
  %t502 = load i64, ptr %l27, !tbaa !24
  store i64 %t502, ptr %l299, !tbaa !24
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load ptr, ptr %l19, !tbaa !29
  %t506 = getelementptr %"compiler/typed:Make", ptr %t504, i32 0, i32 2
  %t507 = load { i64, ptr }, ptr %t506, !tbaa !27
  store { i64, ptr } %t507, ptr %l302, !tbaa !27
  %t508 = load i64, ptr %l27, !tbaa !24
  %t510 = getelementptr { i64, ptr }, ptr %l302, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !27
  %t512 = getelementptr ptr, ptr %t511, i64 %t508
  %t513 = load ptr, ptr %t512, !tbaa !39
  %t515 = load { i64, [2 x i64] }, ptr %l3
  %t519 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t503, ptr %t513, { i64, [2 x i64] } %t515)
  store %"compiler/scope:Val" %t519, ptr %l307
  br label %bb130
bb130:
  %t520 = load %"compiler/scope:Val", ptr %l307
  %t521 = load i64, ptr %l299, !tbaa !24
  %t522 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t523 = load ptr, ptr %t522, !tbaa !27
  %t524 = getelementptr %"compiler/scope:Val", ptr %t523, i64 %t521
  store %"compiler/scope:Val" %t520, ptr %t524
  br label %bb131
bb131:
  %t525 = load i64, ptr %l26, !tbaa !24
  %t527 = add i64 %t525, 1
  store i64 %t527, ptr %l26, !tbaa !24
  br label %bb126
bb132:
  %t529 = load ptr, ptr %l19, !tbaa !29
  %t531 = getelementptr %"compiler/typed:Make", ptr %t529, i32 0, i32 0
  %t532 = load i32, ptr %t531
  %t534 = trunc i64 1 to i32
  %t535 = icmp eq i32 %t532, %t534
  %t537 = xor i1 %t535, true
  br i1 %t537, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l314, !tbaa !21
  br label %bb135
bb134:
  %t539 = load ptr, ptr %l0, !tbaa !29
  %t541 = getelementptr %"compiler/scope:Scoper", ptr %t539, i32 0, i32 27
  %t542 = load i1, ptr %t541, !tbaa !21
  %t544 = xor i1 %t542, true
  store i1 %t544, ptr %l314, !tbaa !21
  br label %bb135
bb135:
  %t546 = load i1, ptr %l314, !tbaa !21
  br i1 %t546, label %bb136, label %bb137
bb136:
  store i1 true, ptr %l318, !tbaa !21
  br label %bb139
bb137:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load ptr, ptr %l19, !tbaa !29
  %t550 = getelementptr %"compiler/typed:Make", ptr %t548, i32 0, i32 2
  %t551 = load { i64, ptr }, ptr %t550, !tbaa !27
  %t552 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t556 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epayloadAgree(ptr %v0, ptr %v1, ptr %s13, ptr %t547, { i64, ptr } %t551, { i64, ptr } %t552)
  store i1 %t556, ptr %l323
  br label %bb138
bb138:
  %t557 = load i1, ptr %l323, !tbaa !21
  store i1 %t557, ptr %l318, !tbaa !21
  br label %bb139
bb139:
  %t558 = load i1, ptr %l318, !tbaa !21
  store i1 %t558, ptr %l28, !tbaa !21
  store i64 0, ptr %l29, !tbaa !24
  %t559 = load ptr, ptr %l19, !tbaa !29
  %t561 = getelementptr %"compiler/typed:Make", ptr %t559, i32 0, i32 2
  %t562 = load { i64, ptr }, ptr %t561, !tbaa !27
  %t564 = extractvalue { i64, ptr } %t562, 0
  store i64 %t564, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t566 = load i64, ptr %l30, !tbaa !24
  %t567 = load i64, ptr %l29, !tbaa !24
  %t570 = icmp sgt i64 %t566, %t567
  br i1 %t570, label %bb140, label %bb141
bb140:
  %t572 = load i64, ptr %l31, !tbaa !24
  %t574 = icmp sgt i64 %t572, 0
  br i1 %t574, label %bb142, label %bb143
bb141:
  store i64 0, ptr %l330, !tbaa !24
  br label %bb145
bb142:
  %t576 = load i64, ptr %l30, !tbaa !24
  %t577 = load i64, ptr %l29, !tbaa !24
  %t580 = sub i64 %t576, %t577
  %t581 = load i64, ptr %l31, !tbaa !24
  %t584 = add i64 %t580, %t581
  %t586 = sub i64 %t584, 1
  %t587 = load i64, ptr %l31, !tbaa !24
  %t590 = sdiv i64 %t586, %t587
  store i64 %t590, ptr %l333, !tbaa !24
  br label %bb144
bb143:
  store i64 0, ptr %l333, !tbaa !24
  br label %bb144
bb144:
  %t592 = load i64, ptr %l333, !tbaa !24
  store i64 %t592, ptr %l330, !tbaa !24
  br label %bb145
bb145:
  %t593 = load i64, ptr %l330, !tbaa !24
  store i64 %t593, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb146
bb146:
  %t594 = load i64, ptr %l33, !tbaa !24
  %t595 = load i64, ptr %l32, !tbaa !24
  %t598 = icmp slt i64 %t594, %t595
  %t600 = xor i1 %t598, true
  br i1 %t600, label %bb147, label %bb148
bb147:
  br label %bb168
bb148:
  br label %bb149
bb149:
  %t602 = load i64, ptr %l29, !tbaa !24
  %t603 = load i64, ptr %l33, !tbaa !24
  %t604 = load i64, ptr %l31, !tbaa !24
  %t607 = mul i64 %t603, %t604
  %t610 = add i64 %t602, %t607
  store i64 %t610, ptr %l34, !tbaa !24
  %t612 = load i64, ptr %l20, !tbaa !24
  %t613 = load i64, ptr @G_2ecompiler_2fscope_2eFitAnyCopy, !tbaa !24
  %t616 = icmp eq i64 %t612, %t613
  br i1 %t616, label %bb150, label %bb151
bb150:
  %t618 = load ptr, ptr %l0, !tbaa !29
  store ptr %t618, ptr %l355, !tbaa !29
  %t619 = load ptr, ptr %l19, !tbaa !29
  %t621 = getelementptr %"compiler/typed:Make", ptr %t619, i32 0, i32 2
  %t622 = load { i64, ptr }, ptr %t621, !tbaa !27
  store { i64, ptr } %t622, ptr %l357, !tbaa !27
  %t623 = load i64, ptr %l34, !tbaa !24
  %t625 = getelementptr { i64, ptr }, ptr %l357, i32 0, i32 1
  %t626 = load ptr, ptr %t625, !tbaa !27
  %t627 = getelementptr ptr, ptr %t626, i64 %t623
  %t628 = load ptr, ptr %t627, !tbaa !39
  %t630 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t628)
  store i32 %t630, ptr %l360
  br label %bb152
bb151:
  store i1 false, ptr %l354, !tbaa !21
  br label %bb154
bb152:
  %t631 = load ptr, ptr %l355, !tbaa !29
  %t632 = load i32, ptr %l360, !tbaa !23
  %t633 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t631, i32 %t632)
  store i1 %t633, ptr %l361
  br label %bb153
bb153:
  %t634 = load i1, ptr %l361, !tbaa !21
  %t635 = xor i1 %t634, true
  store i1 %t635, ptr %l354, !tbaa !21
  br label %bb154
bb154:
  %t637 = load i1, ptr %l354, !tbaa !21
  store i1 %t637, ptr %l35, !tbaa !21
  %t638 = load i1, ptr %l28, !tbaa !21
  br i1 %t638, label %bb155, label %bb156
bb155:
  %t640 = load i64, ptr %l34, !tbaa !24
  %t642 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t643 = load ptr, ptr %t642, !tbaa !27
  %t644 = getelementptr %"compiler/scope:Val", ptr %t643, i64 %t640
  %t645 = getelementptr %"compiler/scope:Val", ptr %t644, i32 0, i32 0
  %t646 = load i32, ptr %t645
  %t648 = trunc i64 3 to i32
  %t649 = icmp eq i32 %t646, %t648
  store i1 %t649, ptr %l364, !tbaa !21
  br label %bb157
bb156:
  store i1 false, ptr %l364, !tbaa !21
  br label %bb157
bb157:
  %t651 = load i1, ptr %l364, !tbaa !21
  br i1 %t651, label %bb158, label %bb159
bb158:
  %t652 = load i1, ptr %l35, !tbaa !21
  %t654 = xor i1 %t652, true
  store i1 %t654, ptr %l368, !tbaa !21
  br label %bb160
bb159:
  store i1 false, ptr %l368, !tbaa !21
  br label %bb160
bb160:
  %t656 = load i1, ptr %l368, !tbaa !21
  br i1 %t656, label %bb161, label %bb162
bb161:
  %t657 = load ptr, ptr %l0, !tbaa !29
  store ptr %t657, ptr %l371, !tbaa !29
  %t658 = load i64, ptr %l34, !tbaa !24
  %t660 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t661 = load ptr, ptr %t660, !tbaa !27
  %t662 = getelementptr %"compiler/scope:Val", ptr %t661, i64 %t658
  %t663 = getelementptr %"compiler/scope:Val", ptr %t662, i32 0, i32 1
  %t664 = load { i64, [2 x i64] }, ptr %t663
  store { i64, [2 x i64] } %t664, ptr %l373
  %t665 = load { i64, [2 x i64] }, ptr %l3
  store { i64, [2 x i64] } %t665, ptr %l374
  %t666 = load ptr, ptr %l0, !tbaa !29
  store ptr %t666, ptr %l375, !tbaa !29
  %t667 = load ptr, ptr %l19, !tbaa !29
  %t669 = getelementptr %"compiler/typed:Make", ptr %t667, i32 0, i32 2
  %t670 = load { i64, ptr }, ptr %t669, !tbaa !27
  store { i64, ptr } %t670, ptr %l377, !tbaa !27
  %t671 = load i64, ptr %l34, !tbaa !24
  %t673 = getelementptr { i64, ptr }, ptr %l377, i32 0, i32 1
  %t674 = load ptr, ptr %t673, !tbaa !27
  %t675 = getelementptr ptr, ptr %t674, i64 %t671
  %t676 = load ptr, ptr %t675, !tbaa !39
  %t678 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t676)
  store i32 %t678, ptr %l380
  br label %bb163
bb162:
  br label %bb166
bb163:
  %t679 = load ptr, ptr %l375, !tbaa !29
  %t680 = load i32, ptr %l380, !tbaa !23
  %t681 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %t679, i32 %t680)
  store i1 %t681, ptr %l381
  br label %bb164
bb164:
  %t682 = load ptr, ptr %l19, !tbaa !29
  %t684 = getelementptr %"compiler/typed:Make", ptr %t682, i32 0, i32 2
  %t685 = load { i64, ptr }, ptr %t684, !tbaa !27
  store { i64, ptr } %t685, ptr %l383, !tbaa !27
  %t686 = load i64, ptr %l34, !tbaa !24
  %t688 = getelementptr { i64, ptr }, ptr %l383, i32 0, i32 1
  %t689 = load ptr, ptr %t688, !tbaa !27
  %t690 = getelementptr ptr, ptr %t689, i64 %t686
  %t691 = load ptr, ptr %t690, !tbaa !39
  %t692 = load i64, ptr %l20, !tbaa !24
  %t693 = load ptr, ptr %l371, !tbaa !29
  %t694 = load { i64, [2 x i64] }, ptr %l373
  %t695 = load { i64, [2 x i64] }, ptr %l374
  %t696 = load i1, ptr %l381, !tbaa !21
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efit(ptr %v0, ptr %v1, ptr %t693, { i64, [2 x i64] } %t694, { i64, [2 x i64] } %t695, i1 %t696, ptr %t691, i64 %t692)
  br label %bb165
bb165:
  br label %bb166
bb166:
  br label %bb167
bb167:
  %t699 = load i64, ptr %l33, !tbaa !24
  %t701 = add i64 %t699, 1
  store i64 %t701, ptr %l33, !tbaa !24
  br label %bb146
bb168:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load i32, ptr %l18, !tbaa !23
  %t707 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t703, i32 %t704)
  store i1 %t707, ptr %l391
  br label %bb169
bb169:
  %t708 = load i1, ptr %l391, !tbaa !21
  %t709 = xor i1 %t708, true
  br i1 %t709, label %bb170, label %bb171
bb170:
  %t711 = load ptr, ptr %l19, !tbaa !29
  %t713 = getelementptr %"compiler/typed:Make", ptr %t711, i32 0, i32 4
  %t714 = load i32, ptr %t713, !tbaa !23
  %t716 = icmp slt i32 %t714, 0
  store i1 %t716, ptr %l393, !tbaa !21
  br label %bb172
bb171:
  store i1 false, ptr %l393, !tbaa !21
  br label %bb172
bb172:
  %t718 = load i1, ptr %l393, !tbaa !21
  br i1 %t718, label %bb173, label %bb174
bb173:
  %t719 = call %"compiler/scope:Val" @compiler_2fscope_2eplain()
  store %"compiler/scope:Val" %t719, ptr %l397
  br label %bb175
bb174:
  br label %bb176
bb175:
  call void @__olang_scope_close(ptr %s13)
  %t720 = load %"compiler/scope:Val", ptr %l397
  store %"compiler/scope:Val" %t720, ptr %rv
  br label %ret
bb176:
  %t721 = load { i64, [2 x i64] }, ptr %l3
  %t723 = call %"compiler/scope:Val" @compiler_2fscope_2efresh({ i64, [2 x i64] } %t721)
  store %"compiler/scope:Val" %t723, ptr %l399
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s13)
  %t724 = load %"compiler/scope:Val", ptr %l399
  store %"compiler/scope:Val" %t724, ptr %rv
  br label %ret
bb178:
  %t725 = load ptr, ptr %l1, !tbaa !29
  store ptr %t725, ptr %l400, !tbaa !29
  store i1 false, ptr %l401, !tbaa !21
  %t726 = load ptr, ptr %l400, !tbaa !29
  %t727 = icmp ne ptr %t726, null
  br i1 %t727, label %bb179, label %bb180
bb179:
  %t729 = load ptr, ptr %l400, !tbaa !29
  %t730 = load i64, ptr %t729
  %t732 = icmp eq i64 %t730, 8
  store i1 %t732, ptr %l401, !tbaa !21
  br label %bb180
bb180:
  %t733 = load i1, ptr %l401, !tbaa !21
  br i1 %t733, label %bb181, label %bb182
bb181:
  %t734 = load ptr, ptr %l1, !tbaa !29
  %t736 = getelementptr { i64, [5 x i64] }, ptr %t734, i32 0, i32 1
  %t737 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t736, i32 0, i32 2
  %t738 = load ptr, ptr %t737
  store ptr %t738, ptr %l36, !tbaa !29
  br label %bb183
bb182:
  br label %bb188
bb183:
  %t740 = load ptr, ptr %l0, !tbaa !29
  %t741 = load ptr, ptr %l36, !tbaa !29
  %t743 = getelementptr %"compiler/typed:Collect", ptr %t741, i32 0, i32 2
  %t744 = load i32, ptr %t743, !tbaa !23
  %t745 = load { i64, [2 x i64] }, ptr %l3
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuild(ptr %v0, ptr %t740, i32 %t744, { i64, [2 x i64] } %t745)
  br label %bb184
bb184:
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t750 = load ptr, ptr %l36, !tbaa !29
  %t752 = getelementptr %"compiler/typed:Collect", ptr %t750, i32 0, i32 0
  %t753 = load ptr, ptr %t752, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t754
  %t755 = getelementptr { i64, [2 x i64] }, ptr %t754, i32 0, i32 0
  store i64 0, ptr %t755
  %t756 = load { i64, [2 x i64] }, ptr %t754
  %t760 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t749, ptr %t753, { i64, [2 x i64] } %t756)
  store %"compiler/scope:Val" %t760, ptr %l414
  br label %bb185
bb185:
  %t761 = load ptr, ptr %l0, !tbaa !29
  %t762 = load ptr, ptr %l36, !tbaa !29
  %t764 = getelementptr %"compiler/typed:Collect", ptr %t762, i32 0, i32 1
  %t765 = load ptr, ptr %t764, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t761, ptr %t765)
  br label %bb186
bb186:
  %t769 = load { i64, [2 x i64] }, ptr %l3
  %t771 = call %"compiler/scope:Val" @compiler_2fscope_2efresh({ i64, [2 x i64] } %t769)
  store %"compiler/scope:Val" %t771, ptr %l420
  br label %bb187
bb187:
  %t772 = load %"compiler/scope:Val", ptr %l420
  store %"compiler/scope:Val" %t772, ptr %rv
  br label %ret
bb188:
  %t773 = load ptr, ptr %l1, !tbaa !29
  store ptr %t773, ptr %l421, !tbaa !29
  store i1 false, ptr %l422, !tbaa !21
  %t774 = load ptr, ptr %l421, !tbaa !29
  %t775 = icmp ne ptr %t774, null
  br i1 %t775, label %bb189, label %bb190
bb189:
  %t777 = load ptr, ptr %l421, !tbaa !29
  %t778 = load i64, ptr %t777
  %t780 = icmp eq i64 %t778, 9
  store i1 %t780, ptr %l422, !tbaa !21
  br label %bb190
bb190:
  %t781 = load i1, ptr %l422, !tbaa !21
  br i1 %t781, label %bb191, label %bb192
bb191:
  %t782 = load ptr, ptr %l1, !tbaa !29
  %t784 = getelementptr { i64, [5 x i64] }, ptr %t782, i32 0, i32 1
  %t785 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t784, i32 0, i32 1
  %t786 = load i32, ptr %t785
  store i32 %t786, ptr %l37, !tbaa !23
  %t788 = load ptr, ptr %l1, !tbaa !29
  %t790 = getelementptr { i64, [5 x i64] }, ptr %t788, i32 0, i32 1
  %t791 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t790, i32 0, i32 2
  %t792 = load i32, ptr %t791
  store i32 %t792, ptr %l38
  %t794 = load ptr, ptr %l1, !tbaa !29
  %t796 = getelementptr { i64, [5 x i64] }, ptr %t794, i32 0, i32 1
  %t797 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t796, i32 0, i32 4
  %t798 = load { i64, ptr }, ptr %t797
  store { i64, ptr } %t798, ptr %l39, !tbaa !27
  br label %bb193
bb192:
  br label %bb218
bb193:
  %t800 = load i32, ptr %l38
  %t802 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t800)
  store i1 %t802, ptr %l432
  br label %bb194
bb194:
  %t803 = load i1, ptr %l432, !tbaa !21
  br i1 %t803, label %bb195, label %bb196
bb195:
  %t804 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t806 = extractvalue { i64, ptr } %t804, 0
  %t808 = icmp sgt i64 %t806, 0
  store i1 %t808, ptr %l433, !tbaa !21
  br label %bb197
bb196:
  store i1 false, ptr %l433, !tbaa !21
  br label %bb197
bb197:
  %t810 = load i1, ptr %l433, !tbaa !21
  br i1 %t810, label %bb198, label %bb199
bb198:
  %t811 = load ptr, ptr %l0, !tbaa !29
  %t812 = load i32, ptr %l37, !tbaa !23
  %t815 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %t811, i32 %t812)
  store i1 %t815, ptr %l440
  br label %bb200
bb199:
  store i1 false, ptr %l437, !tbaa !21
  br label %bb205
bb200:
  %t816 = load i1, ptr %l440, !tbaa !21
  br i1 %t816, label %bb201, label %bb202
bb201:
  store i1 true, ptr %l441, !tbaa !21
  br label %bb204
bb202:
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t818 = load i32, ptr %l37, !tbaa !23
  %t821 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %t817, i32 %t818)
  store i1 %t821, ptr %l444
  br label %bb203
bb203:
  %t822 = load i1, ptr %l444, !tbaa !21
  store i1 %t822, ptr %l441, !tbaa !21
  br label %bb204
bb204:
  %t823 = load i1, ptr %l441, !tbaa !21
  store i1 %t823, ptr %l437, !tbaa !21
  br label %bb205
bb205:
  %t824 = load i1, ptr %l437, !tbaa !21
  br i1 %t824, label %bb206, label %bb207
bb206:
  %t825 = load ptr, ptr %l0, !tbaa !29
  %t826 = load i32, ptr %l38
  %t828 = trunc i64 40 to i32
  %t829 = icmp eq i32 %t826, %t828
  %t832 = getelementptr %"compiler/scope:Scoper", ptr %t825, i32 0, i32 69
  store i1 %t829, ptr %t832, !tbaa !21
  %t833 = load ptr, ptr %l0, !tbaa !29
  %t834 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t834, ptr %l449, !tbaa !27
  %t835 = getelementptr { i64, ptr }, ptr %l449, i32 0, i32 1
  %t836 = load ptr, ptr %t835, !tbaa !27
  %t837 = getelementptr ptr, ptr %t836, i64 0
  %t838 = load ptr, ptr %t837, !tbaa !39
  %t840 = load { i64, [2 x i64] }, ptr %l2
  %t844 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t833, ptr %t838, { i64, [2 x i64] } %t840)
  store %"compiler/scope:Val" %t844, ptr %l453
  br label %bb208
bb207:
  br label %bb209
bb208:
  %t845 = load %"compiler/scope:Val", ptr %l453
  %t846 = load ptr, ptr %l0, !tbaa !29
  %t848 = getelementptr %"compiler/scope:Scoper", ptr %t846, i32 0, i32 69
  store i1 false, ptr %t848, !tbaa !21
  store %"compiler/scope:Val" %t845, ptr %rv
  br label %ret
bb209:
  %t851 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t851, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t853 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t855 = extractvalue { i64, ptr } %t853, 0
  store i64 %t855, ptr %l43, !tbaa !24
  br label %bb210
bb210:
  %t857 = load i64, ptr %l42, !tbaa !24
  %t858 = load i64, ptr %l43, !tbaa !24
  %t861 = icmp slt i64 %t857, %t858
  %t863 = xor i1 %t861, true
  br i1 %t863, label %bb211, label %bb212
bb211:
  br label %bb216
bb212:
  br label %bb213
bb213:
  %t865 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t865, ptr %l463, !tbaa !27
  %t866 = load i64, ptr %l42, !tbaa !24
  %t868 = getelementptr { i64, ptr }, ptr %l463, i32 0, i32 1
  %t869 = load ptr, ptr %t868, !tbaa !27
  %t870 = getelementptr ptr, ptr %t869, i64 %t866
  %t871 = load ptr, ptr %t870, !tbaa !39
  %t873 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t876
  %t877 = getelementptr { i64, [2 x i64] }, ptr %t876, i32 0, i32 0
  store i64 0, ptr %t877
  %t878 = load { i64, [2 x i64] }, ptr %t876
  %t882 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t873, ptr %t871, { i64, [2 x i64] } %t878)
  store %"compiler/scope:Val" %t882, ptr %l470
  br label %bb214
bb214:
  br label %bb215
bb215:
  %t883 = load i64, ptr %l42, !tbaa !24
  %t885 = add i64 %t883, 1
  store i64 %t885, ptr %l42, !tbaa !24
  br label %bb210
bb216:
  %t887 = call %"compiler/scope:Val" @compiler_2fscope_2eplain()
  store %"compiler/scope:Val" %t887, ptr %l473
  br label %bb217
bb217:
  %t888 = load %"compiler/scope:Val", ptr %l473
  store %"compiler/scope:Val" %t888, ptr %rv
  br label %ret
bb218:
  %t889 = load ptr, ptr %l1, !tbaa !29
  store ptr %t889, ptr %l474, !tbaa !29
  store i1 false, ptr %l475, !tbaa !21
  %t890 = load ptr, ptr %l474, !tbaa !29
  %t891 = icmp ne ptr %t890, null
  br i1 %t891, label %bb219, label %bb220
bb219:
  %t893 = load ptr, ptr %l474, !tbaa !29
  %t894 = load i64, ptr %t893
  %t896 = icmp eq i64 %t894, 10
  store i1 %t896, ptr %l475, !tbaa !21
  br label %bb220
bb220:
  %t897 = load i1, ptr %l475, !tbaa !21
  br i1 %t897, label %bb221, label %bb222
bb221:
  %t898 = load ptr, ptr %l1, !tbaa !29
  %t900 = getelementptr { i64, [5 x i64] }, ptr %t898, i32 0, i32 1
  %t901 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t900, i32 0, i32 0
  %t902 = load %"compiler/source:Span", ptr %t901
  store %"compiler/source:Span" %t902, ptr %l45
  %t904 = load ptr, ptr %l1, !tbaa !29
  %t906 = getelementptr { i64, [5 x i64] }, ptr %t904, i32 0, i32 1
  %t907 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t906, i32 0, i32 1
  %t908 = load i32, ptr %t907
  store i32 %t908, ptr %l46, !tbaa !23
  %t910 = load ptr, ptr %l1, !tbaa !29
  %t912 = getelementptr { i64, [5 x i64] }, ptr %t910, i32 0, i32 1
  %t913 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t912, i32 0, i32 2
  %t914 = load ptr, ptr %t913
  store ptr %t914, ptr %l47, !tbaa !29
  br label %bb223
bb222:
  br label %bb244
bb223:
  %t916 = load ptr, ptr %l0, !tbaa !29
  %t917 = load ptr, ptr %l47, !tbaa !29
  %t919 = getelementptr %"compiler/typed:Slice", ptr %t917, i32 0, i32 0
  %t920 = load ptr, ptr %t919, !tbaa !29
  %t921 = load i32, ptr %l46, !tbaa !23
  %t922 = load { i64, [2 x i64] }, ptr %l2
  %t927 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartLand(ptr %v0, ptr %v1, ptr %t916, ptr %t920, i32 %t921, { i64, [2 x i64] } %t922)
  store i64 %t927, ptr %l489
  br label %bb224
bb224:
  %t928 = load i64, ptr %l489, !tbaa !24
  store i64 %t928, ptr %l48, !tbaa !24
  %t929 = load ptr, ptr %l0, !tbaa !29
  %t930 = load ptr, ptr %l47, !tbaa !29
  %t932 = getelementptr %"compiler/typed:Slice", ptr %t930, i32 0, i32 0
  %t933 = load ptr, ptr %t932, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceOperands(ptr %v0, ptr %v1, ptr %t929, ptr %t933)
  br label %bb225
bb225:
  %t936 = load ptr, ptr %l0, !tbaa !29
  %t937 = load ptr, ptr %l47, !tbaa !29
  %t939 = getelementptr %"compiler/typed:Slice", ptr %t937, i32 0, i32 0
  %t940 = load ptr, ptr %t939, !tbaa !29
  %t943 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esplitPlace(ptr %v0, ptr %v1, ptr %t936, ptr %t940)
  store i1 %t943, ptr %l496
  br label %bb226
bb226:
  %t944 = load i1, ptr %l496, !tbaa !21
  br i1 %t944, label %bb227, label %bb228
bb227:
  %t945 = load ptr, ptr %l0, !tbaa !29
  %t947 = getelementptr %"compiler/scope:Scoper", ptr %t945, i32 0, i32 27
  %t948 = load i1, ptr %t947, !tbaa !21
  store i1 %t948, ptr %l497, !tbaa !21
  br label %bb229
bb228:
  store i1 false, ptr %l497, !tbaa !21
  br label %bb229
bb229:
  %t950 = load i1, ptr %l497, !tbaa !21
  br i1 %t950, label %bb230, label %bb231
bb230:
  store %olang.scope zeroinitializer, ptr %s30
  %t951 = load ptr, ptr %l0, !tbaa !29
  store ptr %t951, ptr %l500, !tbaa !29
  %t952 = load ptr, ptr %l0, !tbaa !29
  %t953 = load %"compiler/source:Span", ptr %l45
  %t954 = load ptr, ptr %l47, !tbaa !29
  %t958 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esliceAt(ptr %v0, ptr %v1, ptr %t952, %"compiler/source:Span" %t953, ptr %t954)
  store %"compiler/source:Span" %t958, ptr %l504
  br label %bb232
bb231:
  br label %bb235
bb232:
  %t959 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSliceSplitValue(ptr %s30)
  store %"compiler/msgs:Msg" %t959, ptr %l505
  br label %bb233
bb233:
  %t960 = load ptr, ptr %l500, !tbaa !29
  %t961 = load %"compiler/source:Span", ptr %l504
  %t962 = load %"compiler/msgs:Msg", ptr %l505
  %t963 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s30, ptr %t960, %"compiler/source:Span" %t961, %"compiler/msgs:Msg" %t962)
  store i64 %t963, ptr %l506
  br label %bb234
bb234:
  call void @__olang_scope_close(ptr %s30)
  br label %bb235
bb235:
  %t964 = load ptr, ptr %l0, !tbaa !29
  %t965 = load ptr, ptr %l47, !tbaa !29
  %t967 = getelementptr %"compiler/typed:Slice", ptr %t965, i32 0, i32 1
  %t968 = load ptr, ptr %t967, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t970
  %t971 = getelementptr { i64, [2 x i64] }, ptr %t970, i32 0, i32 0
  store i64 0, ptr %t971
  %t972 = load { i64, [2 x i64] }, ptr %t970
  %t976 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t964, ptr %t968, { i64, [2 x i64] } %t972)
  store %"compiler/scope:Val" %t976, ptr %l512
  br label %bb236
bb236:
  %t977 = load ptr, ptr %l0, !tbaa !29
  %t978 = load ptr, ptr %l47, !tbaa !29
  %t980 = getelementptr %"compiler/typed:Slice", ptr %t978, i32 0, i32 2
  %t981 = load ptr, ptr %t980, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t983
  %t984 = getelementptr { i64, [2 x i64] }, ptr %t983, i32 0, i32 0
  store i64 0, ptr %t984
  %t985 = load { i64, [2 x i64] }, ptr %t983
  %t989 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t977, ptr %t981, { i64, [2 x i64] } %t985)
  store %"compiler/scope:Val" %t989, ptr %l518
  br label %bb237
bb237:
  %t990 = load ptr, ptr %l0, !tbaa !29
  %t991 = load ptr, ptr %l47, !tbaa !29
  %t993 = getelementptr %"compiler/typed:Slice", ptr %t991, i32 0, i32 0
  %t994 = load ptr, ptr %t993, !tbaa !29
  %t997 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esliceTerm(ptr %v0, ptr %v1, ptr %t990, ptr %t994)
  store { i64, [2 x i64] } %t997, ptr %l522
  br label %bb238
bb238:
  %t998 = load { i64, [2 x i64] }, ptr %l522
  store { i64, [2 x i64] } %t998, ptr %l49
  %t999 = load i64, ptr %l48, !tbaa !24
  %t1001 = icmp sge i64 %t999, 0
  br i1 %t1001, label %bb239, label %bb240
bb239:
  %t1003 = load ptr, ptr %l0, !tbaa !29
  %t1005 = getelementptr %"compiler/scope:Scoper", ptr %t1003, i32 0, i32 90
  %t1006 = load i64, ptr %l48, !tbaa !24
  %t1009 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb4ab14fd1aa8deeb21095c3402461540(ptr %v0, ptr %t1005, i64 %t1006)
  store i1 %t1009, ptr %l528
  br label %bb241
bb240:
  br label %bb242
bb241:
  br label %bb242
bb242:
  %t1010 = load { i64, [2 x i64] }, ptr %l49
  %t1012 = call %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %t1010)
  store %"compiler/scope:Val" %t1012, ptr %l530
  br label %bb243
bb243:
  %t1013 = load %"compiler/scope:Val", ptr %l530
  store %"compiler/scope:Val" %t1013, ptr %rv
  br label %ret
bb244:
  %t1014 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1014, ptr %l531, !tbaa !29
  store i1 false, ptr %l532, !tbaa !21
  %t1015 = load ptr, ptr %l531, !tbaa !29
  %t1016 = icmp ne ptr %t1015, null
  br i1 %t1016, label %bb245, label %bb246
bb245:
  %t1018 = load ptr, ptr %l531, !tbaa !29
  %t1019 = load i64, ptr %t1018
  %t1021 = icmp eq i64 %t1019, 11
  store i1 %t1021, ptr %l532, !tbaa !21
  br label %bb246
bb246:
  %t1022 = load i1, ptr %l532, !tbaa !21
  br i1 %t1022, label %bb247, label %bb248
bb247:
  %t1023 = load ptr, ptr %l1, !tbaa !29
  %t1025 = getelementptr { i64, [5 x i64] }, ptr %t1023, i32 0, i32 1
  %t1026 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1025, i32 0, i32 2
  %t1027 = load ptr, ptr %t1026
  store ptr %t1027, ptr %l50, !tbaa !29
  br label %bb249
bb248:
  br label %bb261
bb249:
  store %olang.scope zeroinitializer, ptr %s32
  %t1029 = load ptr, ptr %l0, !tbaa !29
  %t1030 = load ptr, ptr %l50, !tbaa !29
  %t1032 = getelementptr %"compiler/typed:Cond", ptr %t1030, i32 0, i32 0
  %t1033 = load ptr, ptr %t1032, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t1035
  %t1036 = getelementptr { i64, [2 x i64] }, ptr %t1035, i32 0, i32 0
  store i64 0, ptr %t1036
  %t1037 = load { i64, [2 x i64] }, ptr %t1035
  %t1041 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1029, ptr %t1033, { i64, [2 x i64] } %t1037)
  store %"compiler/scope:Val" %t1041, ptr %l542
  br label %bb250
bb250:
  %t1042 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %s32, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1042, ptr %l543
  br label %bb251
bb251:
  %t1043 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l543
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1043, ptr %l51
  store ptr %l51, ptr %l544, !tbaa !29
  %t1044 = load ptr, ptr %l50, !tbaa !29
  %t1046 = getelementptr %"compiler/typed:Cond", ptr %t1044, i32 0, i32 1
  %t1047 = load ptr, ptr %t1046, !tbaa !29
  %t1049 = icmp eq ptr %t1047, null
  br i1 %t1049, label %bb252, label %bb253
bb252:
  call void @__olang_check_failed(ptr @olang_loc_7fc6f86e6d881397_d60d455fa8d09f43)
  unreachable
bb253:
  br label %bb254
bb254:
  %t1051 = load ptr, ptr %l50, !tbaa !29
  %t1053 = getelementptr %"compiler/typed:Cond", ptr %t1051, i32 0, i32 1
  %t1054 = load ptr, ptr %t1053, !tbaa !29
  %t1055 = load ptr, ptr %l544, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s32, ptr %v1, ptr %t1055, ptr %t1054)
  br label %bb255
bb255:
  %t1057 = load ptr, ptr %l50, !tbaa !29
  %t1059 = getelementptr %"compiler/typed:Cond", ptr %t1057, i32 0, i32 2
  %t1060 = load ptr, ptr %t1059, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %s32, ptr %v1, ptr %l51, ptr %t1060)
  br label %bb256
bb256:
  %t1063 = load ptr, ptr %l0, !tbaa !29
  %t1064 = load { i64, [2 x i64] }, ptr %l2
  %t1068 = call { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoiceDest(ptr %v0, ptr %s32, ptr %t1063, ptr %l51, { i64, [2 x i64] } %t1064)
  store { i64, [2 x i64] } %t1068, ptr %l556
  br label %bb257
bb257:
  %t1069 = load { i64, [2 x i64] }, ptr %l556
  store { i64, [2 x i64] } %t1069, ptr %l52
  %t1070 = load ptr, ptr %l0, !tbaa !29
  %t1071 = load ptr, ptr %l50, !tbaa !29
  %t1073 = getelementptr %"compiler/typed:Cond", ptr %t1071, i32 0, i32 1
  %t1074 = load ptr, ptr %t1073, !tbaa !29
  %t1075 = load { i64, [2 x i64] }, ptr %l52
  %t1079 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1070, ptr %t1074, { i64, [2 x i64] } %t1075)
  store %"compiler/scope:Val" %t1079, ptr %l561
  br label %bb258
bb258:
  %t1080 = load %"compiler/scope:Val", ptr %l561
  store %"compiler/scope:Val" %t1080, ptr %l53
  %t1081 = load ptr, ptr %l0, !tbaa !29
  %t1082 = load ptr, ptr %l50, !tbaa !29
  %t1084 = getelementptr %"compiler/typed:Cond", ptr %t1082, i32 0, i32 2
  %t1085 = load ptr, ptr %t1084, !tbaa !29
  %t1087 = load { i64, [2 x i64] }, ptr %l52
  %t1091 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1081, ptr %t1085, { i64, [2 x i64] } %t1087)
  store %"compiler/scope:Val" %t1091, ptr %l567
  br label %bb259
bb259:
  %t1092 = load %"compiler/scope:Val", ptr %l567
  %t1093 = load ptr, ptr %l0, !tbaa !29
  %t1094 = load %"compiler/scope:Val", ptr %l53
  %t1096 = load { i64, [2 x i64] }, ptr %l3
  %t1101 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoin(ptr %v0, ptr %t1093, %"compiler/scope:Val" %t1094, %"compiler/scope:Val" %t1092, { i64, [2 x i64] } %t1096)
  store %"compiler/scope:Val" %t1101, ptr %l572
  br label %bb260
bb260:
  call void @__olang_scope_close(ptr %s32)
  %t1102 = load %"compiler/scope:Val", ptr %l572
  store %"compiler/scope:Val" %t1102, ptr %rv
  br label %ret
bb261:
  %t1103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1103, ptr %l573, !tbaa !29
  store i1 false, ptr %l574, !tbaa !21
  %t1104 = load ptr, ptr %l573, !tbaa !29
  %t1105 = icmp ne ptr %t1104, null
  br i1 %t1105, label %bb262, label %bb263
bb262:
  %t1107 = load ptr, ptr %l573, !tbaa !29
  %t1108 = load i64, ptr %t1107
  %t1110 = icmp eq i64 %t1108, 12
  store i1 %t1110, ptr %l574, !tbaa !21
  br label %bb263
bb263:
  %t1111 = load i1, ptr %l574, !tbaa !21
  br i1 %t1111, label %bb264, label %bb265
bb264:
  %t1112 = load ptr, ptr %l1, !tbaa !29
  %t1114 = getelementptr { i64, [5 x i64] }, ptr %t1112, i32 0, i32 1
  %t1115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1114, i32 0, i32 2
  %t1116 = load ptr, ptr %t1115
  store ptr %t1116, ptr %l55, !tbaa !29
  br label %bb266
bb265:
  br label %bb269
bb266:
  %t1118 = load ptr, ptr %l0, !tbaa !29
  %t1120 = getelementptr %"compiler/scope:Scoper", ptr %t1118, i32 0, i32 118
  %t1121 = load i1, ptr %t1120, !tbaa !21
  store i1 %t1121, ptr %l56, !tbaa !21
  %t1123 = load ptr, ptr %l0, !tbaa !29
  %t1125 = getelementptr %"compiler/scope:Scoper", ptr %t1123, i32 0, i32 118
  store i1 false, ptr %t1125, !tbaa !21
  %t1126 = load ptr, ptr %l0, !tbaa !29
  %t1127 = load ptr, ptr %l55, !tbaa !29
  %t1129 = getelementptr %"compiler/typed:Seq", ptr %t1127, i32 0, i32 0
  %t1130 = load { i64, ptr }, ptr %t1129, !tbaa !27
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmts(ptr %v0, ptr %v1, ptr %t1126, { i64, ptr } %t1130)
  br label %bb267
bb267:
  %t1133 = load ptr, ptr %l0, !tbaa !29
  %t1134 = load i1, ptr %l56, !tbaa !21
  %t1137 = getelementptr %"compiler/scope:Scoper", ptr %t1133, i32 0, i32 118
  store i1 %t1134, ptr %t1137, !tbaa !21
  %t1138 = load ptr, ptr %l0, !tbaa !29
  %t1139 = load ptr, ptr %l55, !tbaa !29
  %t1141 = getelementptr %"compiler/typed:Seq", ptr %t1139, i32 0, i32 1
  %t1142 = load ptr, ptr %t1141, !tbaa !29
  %t1143 = load { i64, [2 x i64] }, ptr %l2
  %t1147 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1138, ptr %t1142, { i64, [2 x i64] } %t1143)
  store %"compiler/scope:Val" %t1147, ptr %l591
  br label %bb268
bb268:
  %t1148 = load %"compiler/scope:Val", ptr %l591
  store %"compiler/scope:Val" %t1148, ptr %rv
  br label %ret
bb269:
  %t1149 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1149, ptr %l592, !tbaa !29
  store i1 false, ptr %l593, !tbaa !21
  %t1150 = load ptr, ptr %l592, !tbaa !29
  %t1151 = icmp ne ptr %t1150, null
  br i1 %t1151, label %bb270, label %bb271
bb270:
  %t1153 = load ptr, ptr %l592, !tbaa !29
  %t1154 = load i64, ptr %t1153
  %t1156 = icmp eq i64 %t1154, 13
  store i1 %t1156, ptr %l593, !tbaa !21
  br label %bb271
bb271:
  %t1157 = load i1, ptr %l593, !tbaa !21
  br i1 %t1157, label %bb272, label %bb273
bb272:
  %t1158 = load ptr, ptr %l1, !tbaa !29
  %t1160 = getelementptr { i64, [5 x i64] }, ptr %t1158, i32 0, i32 1
  %t1161 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1160, i32 0, i32 2
  %t1162 = load ptr, ptr %t1161
  store ptr %t1162, ptr %l57, !tbaa !29
  br label %bb274
bb273:
  br label %bb276
bb274:
  %t1164 = load ptr, ptr %l0, !tbaa !29
  %t1165 = load ptr, ptr %l57, !tbaa !29
  %t1166 = load { i64, [2 x i64] }, ptr %l2
  %t1170 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ematch(ptr %v0, ptr %v1, ptr %t1164, ptr %t1165, { i64, [2 x i64] } %t1166)
  store %"compiler/scope:Val" %t1170, ptr %l601
  br label %bb275
bb275:
  %t1171 = load %"compiler/scope:Val", ptr %l601
  store %"compiler/scope:Val" %t1171, ptr %rv
  br label %ret
bb276:
  %t1172 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1172, ptr %l602, !tbaa !29
  store i1 false, ptr %l603, !tbaa !21
  %t1173 = load ptr, ptr %l602, !tbaa !29
  %t1174 = icmp ne ptr %t1173, null
  br i1 %t1174, label %bb277, label %bb278
bb277:
  %t1176 = load ptr, ptr %l602, !tbaa !29
  %t1177 = load i64, ptr %t1176
  %t1179 = icmp eq i64 %t1177, 14
  store i1 %t1179, ptr %l603, !tbaa !21
  br label %bb278
bb278:
  %t1180 = load i1, ptr %l603, !tbaa !21
  br i1 %t1180, label %bb279, label %bb280
bb279:
  %t1181 = load ptr, ptr %l1, !tbaa !29
  %t1183 = getelementptr { i64, [5 x i64] }, ptr %t1181, i32 0, i32 1
  %t1184 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1183, i32 0, i32 2
  %t1185 = load ptr, ptr %t1184
  store ptr %t1185, ptr %l58, !tbaa !29
  br label %bb281
bb280:
  br label %bb323
bb281:
  %t1187 = load ptr, ptr %l0, !tbaa !29
  %t1188 = load ptr, ptr %l58, !tbaa !29
  %t1190 = getelementptr %"compiler/typed:Try", ptr %t1188, i32 0, i32 0
  %t1191 = load ptr, ptr %t1190, !tbaa !29
  %t1192 = load { i64, [2 x i64] }, ptr %l2
  %t1196 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1187, ptr %t1191, { i64, [2 x i64] } %t1192)
  store %"compiler/scope:Val" %t1196, ptr %l612
  br label %bb282
bb282:
  %t1197 = load %"compiler/scope:Val", ptr %l612
  store %"compiler/scope:Val" %t1197, ptr %l59
  %t1198 = getelementptr %"compiler/scope:Val", ptr %l59, i32 0, i32 0
  %t1199 = load i32, ptr %t1198
  %t1201 = trunc i64 3 to i32
  %t1202 = icmp eq i32 %t1199, %t1201
  br i1 %t1202, label %bb283, label %bb284
bb283:
  store i1 true, ptr %l615, !tbaa !21
  br label %bb285
bb284:
  %t1204 = getelementptr %"compiler/scope:Val", ptr %l59, i32 0, i32 0
  %t1205 = load i32, ptr %t1204
  %t1207 = trunc i64 2 to i32
  %t1208 = icmp eq i32 %t1205, %t1207
  store i1 %t1208, ptr %l615, !tbaa !21
  br label %bb285
bb285:
  %t1210 = load i1, ptr %l615, !tbaa !21
  br i1 %t1210, label %bb286, label %bb287
bb286:
  %t1211 = getelementptr %"compiler/scope:Val", ptr %l59, i32 0, i32 1
  %t1212 = load { i64, [2 x i64] }, ptr %t1211
  %t1214 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %t1212)
  store i1 %t1214, ptr %l620
  br label %bb288
bb287:
  store i1 false, ptr %l618, !tbaa !21
  br label %bb289
bb288:
  %t1215 = load i1, ptr %l620, !tbaa !21
  store i1 %t1215, ptr %l618, !tbaa !21
  br label %bb289
bb289:
  %t1216 = load i1, ptr %l618, !tbaa !21
  br i1 %t1216, label %bb290, label %bb291
bb290:
  %t1217 = getelementptr %"compiler/scope:Val", ptr %l59, i32 0, i32 1
  %t1218 = load { i64, [2 x i64] }, ptr %t1217
  store { i64, [2 x i64] } %t1218, ptr %l621
  br label %bb292
bb291:
  %t1220 = load { i64, [2 x i64] }, ptr %l2
  store { i64, [2 x i64] } %t1220, ptr %l621
  br label %bb292
bb292:
  %t1222 = load { i64, [2 x i64] }, ptr %l621
  store { i64, [2 x i64] } %t1222, ptr %l60
  %t1223 = load %"compiler/scope:Val", ptr %l59
  store %"compiler/scope:Val" %t1223, ptr %l61
  %t1225 = load ptr, ptr %l58, !tbaa !29
  %t1227 = getelementptr %"compiler/typed:Try", ptr %t1225, i32 0, i32 1
  %t1228 = load { i64, ptr }, ptr %t1227, !tbaa !27
  store { i64, ptr } %t1228, ptr %l62, !tbaa !27
  store i64 0, ptr %l63, !tbaa !24
  %t1230 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t1232 = extractvalue { i64, ptr } %t1230, 0
  store i64 %t1232, ptr %l64, !tbaa !24
  br label %bb293
bb293:
  %t1234 = load i64, ptr %l63, !tbaa !24
  %t1235 = load i64, ptr %l64, !tbaa !24
  %t1238 = icmp slt i64 %t1234, %t1235
  %t1240 = xor i1 %t1238, true
  br i1 %t1240, label %bb294, label %bb295
bb294:
  br label %bb322
bb295:
  br label %bb296
bb296:
  %t1242 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t1242, ptr %l633, !tbaa !27
  %t1243 = load i64, ptr %l63, !tbaa !24
  %t1245 = getelementptr { i64, ptr }, ptr %l633, i32 0, i32 1
  %t1246 = load ptr, ptr %t1245, !tbaa !27
  %t1247 = getelementptr ptr, ptr %t1246, i64 %t1243
  %t1248 = load ptr, ptr %t1247, !tbaa !39
  store ptr %t1248, ptr %l65, !tbaa !29
  %t1250 = load ptr, ptr %l0, !tbaa !29
  %t1251 = load ptr, ptr %l65, !tbaa !29
  %t1253 = getelementptr %"compiler/typed:Clause", ptr %t1251, i32 0, i32 3
  %t1254 = load ptr, ptr %t1253, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %t1250, ptr %t1254)
  br label %bb297
bb297:
  %t1257 = load ptr, ptr %l65, !tbaa !29
  %t1259 = getelementptr %"compiler/typed:Clause", ptr %t1257, i32 0, i32 4
  %t1260 = load { i64, ptr }, ptr %t1259, !tbaa !27
  store { i64, ptr } %t1260, ptr %l66, !tbaa !27
  store i64 0, ptr %l67, !tbaa !24
  %t1262 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t1264 = extractvalue { i64, ptr } %t1262, 0
  store i64 %t1264, ptr %l68, !tbaa !24
  br label %bb298
bb298:
  %t1266 = load i64, ptr %l67, !tbaa !24
  %t1267 = load i64, ptr %l68, !tbaa !24
  %t1270 = icmp slt i64 %t1266, %t1267
  %t1272 = xor i1 %t1270, true
  br i1 %t1272, label %bb299, label %bb300
bb299:
  br label %bb320
bb300:
  br label %bb301
bb301:
  %t1274 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t1274, ptr %l647, !tbaa !27
  %t1275 = load i64, ptr %l67, !tbaa !24
  %t1277 = getelementptr { i64, ptr }, ptr %l647, i32 0, i32 1
  %t1278 = load ptr, ptr %t1277, !tbaa !27
  %t1279 = getelementptr ptr, ptr %t1278, i64 %t1275
  %t1280 = load ptr, ptr %t1279, !tbaa !39
  store ptr %t1280, ptr %l69, !tbaa !29
  %t1282 = load ptr, ptr %l0, !tbaa !29
  %t1283 = load ptr, ptr %l69, !tbaa !29
  %t1285 = load { i64, [2 x i64] }, ptr %l60
  %t1289 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1282, ptr %t1283, { i64, [2 x i64] } %t1285)
  store %"compiler/scope:Val" %t1289, ptr %l654
  br label %bb302
bb302:
  %t1290 = load %"compiler/scope:Val", ptr %l654
  store %"compiler/scope:Val" %t1290, ptr %l70
  %t1291 = load ptr, ptr %l0, !tbaa !29
  %t1293 = getelementptr %"compiler/scope:Scoper", ptr %t1291, i32 0, i32 27
  %t1294 = load i1, ptr %t1293, !tbaa !21
  br i1 %t1294, label %bb303, label %bb304
bb303:
  %t1296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1296, ptr %l658, !tbaa !29
  %t1297 = load ptr, ptr %l1, !tbaa !29
  %t1299 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1297)
  store i32 %t1299, ptr %l660
  br label %bb305
bb304:
  store i1 false, ptr %l657, !tbaa !21
  br label %bb307
bb305:
  %t1300 = load ptr, ptr %l658, !tbaa !29
  %t1301 = load i32, ptr %l660, !tbaa !23
  %t1302 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t1300, i32 %t1301)
  store i1 %t1302, ptr %l661
  br label %bb306
bb306:
  %t1303 = load i1, ptr %l661, !tbaa !21
  store i1 %t1303, ptr %l657, !tbaa !21
  br label %bb307
bb307:
  %t1304 = load i1, ptr %l657, !tbaa !21
  br i1 %t1304, label %bb308, label %bb309
bb308:
  %t1305 = load ptr, ptr %l0, !tbaa !29
  %t1306 = load %"compiler/scope:Val", ptr %l61
  %t1307 = load %"compiler/scope:Val", ptr %l70
  %t1311 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edefaultFits(ptr %v0, ptr %t1305, %"compiler/scope:Val" %t1306, %"compiler/scope:Val" %t1307)
  store i1 %t1311, ptr %l666
  br label %bb310
bb309:
  store i1 false, ptr %l662, !tbaa !21
  br label %bb311
bb310:
  %t1312 = load i1, ptr %l666, !tbaa !21
  %t1313 = xor i1 %t1312, true
  store i1 %t1313, ptr %l662, !tbaa !21
  br label %bb311
bb311:
  %t1315 = load i1, ptr %l662, !tbaa !21
  br i1 %t1315, label %bb312, label %bb313
bb312:
  store %olang.scope zeroinitializer, ptr %s40
  %t1316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1316, ptr %l668, !tbaa !29
  %t1317 = load ptr, ptr %l0, !tbaa !29
  %t1318 = load ptr, ptr %l69, !tbaa !29
  %t1321 = call %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eopTok(ptr %v0, ptr %v1, ptr %t1317, ptr %t1318)
  store %"compiler/source:Span" %t1321, ptr %l671
  br label %bb314
bb313:
  br label %bb317
bb314:
  %t1322 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultScope(ptr %s40)
  store %"compiler/msgs:Msg" %t1322, ptr %l672
  br label %bb315
bb315:
  %t1323 = load ptr, ptr %l668, !tbaa !29
  %t1324 = load %"compiler/source:Span", ptr %l671
  %t1325 = load %"compiler/msgs:Msg", ptr %l672
  %t1326 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eerr(ptr %v0, ptr %s40, ptr %t1323, %"compiler/source:Span" %t1324, %"compiler/msgs:Msg" %t1325)
  store i64 %t1326, ptr %l673
  br label %bb316
bb316:
  call void @__olang_scope_close(ptr %s40)
  br label %bb317
bb317:
  %t1327 = load ptr, ptr %l0, !tbaa !29
  %t1328 = load %"compiler/scope:Val", ptr %l59
  %t1329 = load %"compiler/scope:Val", ptr %l70
  %t1330 = load { i64, [2 x i64] }, ptr %l3
  %t1335 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoin(ptr %v0, ptr %t1327, %"compiler/scope:Val" %t1328, %"compiler/scope:Val" %t1329, { i64, [2 x i64] } %t1330)
  store %"compiler/scope:Val" %t1335, ptr %l678
  br label %bb318
bb318:
  %t1336 = load %"compiler/scope:Val", ptr %l678
  store %"compiler/scope:Val" %t1336, ptr %l59
  br label %bb319
bb319:
  %t1337 = load i64, ptr %l67, !tbaa !24
  %t1339 = add i64 %t1337, 1
  store i64 %t1339, ptr %l67, !tbaa !24
  br label %bb298
bb320:
  br label %bb321
bb321:
  %t1341 = load i64, ptr %l63, !tbaa !24
  %t1343 = add i64 %t1341, 1
  store i64 %t1343, ptr %l63, !tbaa !24
  br label %bb293
bb322:
  %t1345 = load %"compiler/scope:Val", ptr %l59
  store %"compiler/scope:Val" %t1345, ptr %rv
  br label %ret
bb323:
  %t1347 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1347, ptr %l684, !tbaa !29
  store i1 false, ptr %l685, !tbaa !21
  %t1348 = load ptr, ptr %l684, !tbaa !29
  %t1349 = icmp ne ptr %t1348, null
  br i1 %t1349, label %bb324, label %bb325
bb324:
  %t1351 = load ptr, ptr %l684, !tbaa !29
  %t1352 = load i64, ptr %t1351
  %t1354 = icmp eq i64 %t1352, 15
  store i1 %t1354, ptr %l685, !tbaa !21
  br label %bb325
bb325:
  %t1355 = load i1, ptr %l685, !tbaa !21
  br i1 %t1355, label %bb326, label %bb327
bb326:
  %t1356 = load ptr, ptr %l1, !tbaa !29
  %t1358 = getelementptr { i64, [5 x i64] }, ptr %t1356, i32 0, i32 1
  %t1359 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1358, i32 0, i32 0
  %t1360 = load %"compiler/source:Span", ptr %t1359
  store %"compiler/source:Span" %t1360, ptr %l71
  %t1362 = load ptr, ptr %l1, !tbaa !29
  %t1364 = getelementptr { i64, [5 x i64] }, ptr %t1362, i32 0, i32 1
  %t1365 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1364, i32 0, i32 2
  %t1366 = load ptr, ptr %t1365
  store ptr %t1366, ptr %l72, !tbaa !29
  br label %bb328
bb327:
  br label %bb330
bb328:
  %t1368 = load ptr, ptr %l0, !tbaa !29
  %t1369 = load ptr, ptr %l72, !tbaa !29
  %t1370 = load { i64, [2 x i64] }, ptr %l3
  %t1371 = load %"compiler/source:Span", ptr %l71
  %t1376 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efnVal(ptr %v0, ptr %v1, ptr %t1368, ptr %t1369, { i64, [2 x i64] } %t1370, %"compiler/source:Span" %t1371)
  store %"compiler/scope:Val" %t1376, ptr %l696
  br label %bb329
bb329:
  %t1377 = load %"compiler/scope:Val", ptr %l696
  store %"compiler/scope:Val" %t1377, ptr %rv
  br label %ret
bb330:
  %t1378 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1378, ptr %l697, !tbaa !29
  store i1 false, ptr %l698, !tbaa !21
  %t1379 = load ptr, ptr %l697, !tbaa !29
  %t1380 = icmp ne ptr %t1379, null
  br i1 %t1380, label %bb331, label %bb332
bb331:
  %t1382 = load ptr, ptr %l697, !tbaa !29
  %t1383 = load i64, ptr %t1382
  %t1385 = icmp eq i64 %t1383, 16
  store i1 %t1385, ptr %l698, !tbaa !21
  br label %bb332
bb332:
  %t1386 = load i1, ptr %l698, !tbaa !21
  br i1 %t1386, label %bb333, label %bb334
bb333:
  %t1387 = load ptr, ptr %l1, !tbaa !29
  %t1389 = getelementptr { i64, [5 x i64] }, ptr %t1387, i32 0, i32 1
  %t1390 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1389, i32 0, i32 2
  %t1391 = load ptr, ptr %t1390
  store ptr %t1391, ptr %l73, !tbaa !29
  br label %bb335
bb334:
  br label %bb356
bb335:
  %t1393 = load ptr, ptr %l0, !tbaa !29
  %t1394 = load ptr, ptr %l73, !tbaa !29
  %t1396 = getelementptr %"compiler/typed:Text", ptr %t1394, i32 0, i32 1
  %t1397 = load i32, ptr %t1396, !tbaa !23
  %t1398 = load { i64, [2 x i64] }, ptr %l3
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuild(ptr %v0, ptr %t1393, i32 %t1397, { i64, [2 x i64] } %t1398)
  br label %bb336
bb336:
  %t1402 = load ptr, ptr %l73, !tbaa !29
  %t1404 = getelementptr %"compiler/typed:Text", ptr %t1402, i32 0, i32 0
  %t1405 = load { i64, ptr }, ptr %t1404, !tbaa !27
  store { i64, ptr } %t1405, ptr %l74, !tbaa !27
  store i64 0, ptr %l75, !tbaa !24
  %t1407 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1409 = extractvalue { i64, ptr } %t1407, 0
  store i64 %t1409, ptr %l76, !tbaa !24
  br label %bb337
bb337:
  %t1411 = load i64, ptr %l75, !tbaa !24
  %t1412 = load i64, ptr %l76, !tbaa !24
  %t1415 = icmp slt i64 %t1411, %t1412
  %t1417 = xor i1 %t1415, true
  br i1 %t1417, label %bb338, label %bb339
bb338:
  br label %bb354
bb339:
  br label %bb340
bb340:
  %t1419 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t1419, ptr %l715, !tbaa !27
  %t1420 = load i64, ptr %l75, !tbaa !24
  %t1422 = getelementptr { i64, ptr }, ptr %l715, i32 0, i32 1
  %t1423 = load ptr, ptr %t1422, !tbaa !27
  %t1424 = getelementptr ptr, ptr %t1423, i64 %t1420
  %t1425 = load ptr, ptr %t1424, !tbaa !39
  store ptr %t1425, ptr %l77, !tbaa !29
  %t1427 = load ptr, ptr %l77, !tbaa !29
  store ptr %t1427, ptr %l718, !tbaa !29
  store i1 false, ptr %l719, !tbaa !21
  %t1428 = load ptr, ptr %l718, !tbaa !29
  %t1429 = icmp ne ptr %t1428, null
  br i1 %t1429, label %bb341, label %bb342
bb341:
  %t1431 = load ptr, ptr %l718, !tbaa !29
  %t1432 = load i64, ptr %t1431
  %t1434 = icmp eq i64 %t1432, 1
  store i1 %t1434, ptr %l719, !tbaa !21
  br label %bb342
bb342:
  %t1435 = load i1, ptr %l719, !tbaa !21
  br i1 %t1435, label %bb343, label %bb344
bb343:
  %t1436 = load ptr, ptr %l77, !tbaa !29
  %t1438 = getelementptr { i64, [2 x i64] }, ptr %t1436, i32 0, i32 1
  %t1439 = getelementptr { ptr }, ptr %t1438, i32 0, i32 0
  %t1440 = load ptr, ptr %t1439
  store ptr %t1440, ptr %l78, !tbaa !29
  br label %bb345
bb344:
  br label %bb347
bb345:
  %t1442 = load ptr, ptr %l0, !tbaa !29
  %t1443 = load ptr, ptr %l78, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t1445
  %t1446 = getelementptr { i64, [2 x i64] }, ptr %t1445, i32 0, i32 0
  store i64 0, ptr %t1446
  %t1447 = load { i64, [2 x i64] }, ptr %t1445
  %t1451 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1442, ptr %t1443, { i64, [2 x i64] } %t1447)
  store %"compiler/scope:Val" %t1451, ptr %l728
  br label %bb346
bb346:
  br label %bb352
bb347:
  br i1 true, label %bb348, label %bb349
bb348:
  br label %bb350
bb349:
  br label %bb351
bb350:
  br label %bb352
bb351:
  call void @__olang_check_failed(ptr @olang_loc_1de706dca54a6565_725d55ac423312f1)
  unreachable
bb352:
  br label %bb353
bb353:
  %t1452 = load i64, ptr %l75, !tbaa !24
  %t1454 = add i64 %t1452, 1
  store i64 %t1454, ptr %l75, !tbaa !24
  br label %bb337
bb354:
  %t1456 = load { i64, [2 x i64] }, ptr %l3
  %t1458 = call %"compiler/scope:Val" @compiler_2fscope_2efresh({ i64, [2 x i64] } %t1456)
  store %"compiler/scope:Val" %t1458, ptr %l732
  br label %bb355
bb355:
  %t1459 = load %"compiler/scope:Val", ptr %l732
  store %"compiler/scope:Val" %t1459, ptr %rv
  br label %ret
bb356:
  %t1460 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1460, ptr %l733, !tbaa !29
  store i1 false, ptr %l734, !tbaa !21
  %t1461 = load ptr, ptr %l733, !tbaa !29
  %t1462 = icmp ne ptr %t1461, null
  br i1 %t1462, label %bb357, label %bb358
bb357:
  %t1464 = load ptr, ptr %l733, !tbaa !29
  %t1465 = load i64, ptr %t1464
  %t1467 = icmp eq i64 %t1465, 17
  store i1 %t1467, ptr %l734, !tbaa !21
  br label %bb358
bb358:
  %t1468 = load i1, ptr %l734, !tbaa !21
  br i1 %t1468, label %bb359, label %bb360
bb359:
  %t1469 = load ptr, ptr %l1, !tbaa !29
  %t1471 = getelementptr { i64, [5 x i64] }, ptr %t1469, i32 0, i32 1
  %t1472 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1471, i32 0, i32 2
  %t1473 = load ptr, ptr %t1472
  store ptr %t1473, ptr %l79, !tbaa !29
  br label %bb361
bb360:
  br label %bb363
bb361:
  %t1475 = load ptr, ptr %l0, !tbaa !29
  %t1476 = load ptr, ptr %l79, !tbaa !29
  %t1478 = load { i64, [2 x i64] }, ptr %l2
  %t1482 = call %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eval(ptr %v0, ptr %v1, ptr %t1475, ptr %t1476, { i64, [2 x i64] } %t1478)
  store %"compiler/scope:Val" %t1482, ptr %l743
  br label %bb362
bb362:
  %t1483 = load %"compiler/scope:Val", ptr %l743
  store %"compiler/scope:Val" %t1483, ptr %rv
  br label %ret
bb363:
  call void @__olang_check_failed(ptr @olang_loc_c8e4956a22175e34_6f39088095568ee0)
  unreachable
ret:
  %rr = load %"compiler/scope:Val", ptr %rv
  ret %"compiler/scope:Val" %rr
}

define dso_local i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l10 = alloca i1
  %l14 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l15 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l30 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca i64
  %l34 = alloca i64
  %l39 = alloca i32
  %l42 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l55 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i1, ptr %l10, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load i32, ptr %l1, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t12 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t10, i64 2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t12, ptr %l14
  br label %bb5
bb5:
  %t13 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l14
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t13, ptr %l2
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %t14, i32 0, i32 9
  %t17 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l2
  %t20 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t16, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t17)
  %t21 = extractvalue { i32, i64 } %t20, 1
  %t22 = extractvalue { i32, i64 } %t20, 0
  store i32 %t22, ptr %l20
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb7, label %ok.24, !prof !99
ok.24:
  store i64 %t21, ptr %l19
  br label %bb6
bb6:
  %t25 = load i64, ptr %l19, !tbaa !24
  store i64 %t25, ptr %l15, !tbaa !24
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l15, !tbaa !24
  br label %bb9
bb9:
  %t26 = load i64, ptr %l15, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp ne i64 %t27, 0
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = icmp eq i64 %t31, 3
  call void @__olang_scope_close(ptr %s0)
  store i1 %t33, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %t35, i32 0, i32 9
  %t38 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l2
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t37, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t38, i64 1)
  br label %bb13
bb13:
  store i1 false, ptr %l4, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %s3, ptr %t41, i32 %t42)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l30
  br label %bb14
bb14:
  %t46 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  %t47 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %t47
  store ptr %t47, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t49 = load i64, ptr %l6, !tbaa !24
  store i64 %t49, ptr %l32, !tbaa !24
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s3, ptr %t50)
  store i64 %t52, ptr %l34
  br label %bb16
bb16:
  %t53 = load i64, ptr %l32, !tbaa !24
  %t54 = load i64, ptr %l34, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb17, label %bb18
bb17:
  br label %bb34
bb18:
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s3, ptr %t59, i64 %t60)
  store i32 %t63, ptr %l39
  br label %bb20
bb20:
  %t64 = load i32, ptr %l39, !tbaa !23
  store i32 %t64, ptr %l7, !tbaa !23
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i32, ptr %l7, !tbaa !23
  %t69 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t65, i32 %t66)
  store i1 %t69, ptr %l42
  br label %bb21
bb21:
  %t70 = load i1, ptr %l42, !tbaa !21
  br i1 %t70, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l7, !tbaa !23
  %t75 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsStores(ptr %v0, ptr %t71, i32 %t72)
  store i1 %t75, ptr %l45
  br label %bb24
bb23:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l7, !tbaa !23
  %t80 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueAdmits(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t80, ptr %l48
  br label %bb28
bb24:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb32
bb28:
  %t82 = load i1, ptr %l48, !tbaa !21
  br i1 %t82, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l6, !tbaa !24
  br label %bb15
bb34:
  call void @__olang_scope_close(ptr %s3)
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/scope:Scoper", ptr %t87, i32 0, i32 9
  store ptr %t89, ptr %l52, !tbaa !29
  %t90 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l2
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t90, ptr %l53
  %t91 = load i1, ptr %l4, !tbaa !21
  br i1 %t91, label %bb35, label %bb36
bb35:
  store i64 3, ptr %l55, !tbaa !24
  br label %bb37
bb36:
  store i64 2, ptr %l55, !tbaa !24
  br label %bb37
bb37:
  %t93 = load ptr, ptr %l52, !tbaa !29
  %t94 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l53
  %t95 = load i64, ptr %l55, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t93, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t94, i64 %t95)
  br label %bb38
bb38:
  %t96 = load i1, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 %t96, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalueLocalName(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l9 = alloca ptr
  %l18 = alloca %"compiler/typed:Local"
  %l20 = alloca i1
  %l21 = alloca i1
  %l30 = alloca %"compiler/typed:Local"
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l49 = alloca %"compiler/typed:Local"
  %l51 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargLocal(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb9
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l9, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 25
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  br i1 %t17, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4a494c4484ad71e8_cc0fe42b10928cfc)
  unreachable
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %t19, i32 0, i32 25
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 7
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t25, i64 %t26)
  store %"compiler/typed:Local" %t29, ptr %l18
  br label %bb7
bb7:
  %t30 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 2
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = load ptr, ptr %l9, !tbaa !29
  %t34 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %t32, i32 %t31)
  store i1 %t34, ptr %l20
  br label %bb8
bb8:
  %t35 = load i1, ptr %l20, !tbaa !21
  store i1 %t35, ptr %l8, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l8, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb16
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/scope:Scoper", ptr %t37, i32 0, i32 25
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  br i1 %t42, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_4a494c4484ad71e8_cc0fe42b10928cfc)
  unreachable
bb13:
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 25
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t47, i32 0, i32 7
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t50, i64 %t51)
  store %"compiler/typed:Local" %t54, ptr %l30
  br label %bb15
bb15:
  %t55 = getelementptr %"compiler/typed:Local", ptr %l30, i32 0, i32 4
  %t56 = load i32, ptr %t55
  %t58 = trunc i64 3 to i32
  %t59 = icmp eq i32 %t56, %t58
  store i1 %t59, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t61 = load i1, ptr %l21, !tbaa !21
  br i1 %t61, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t62, ptr %l34, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l35, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l36, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l35, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t76, ptr %l34, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/scope:Scoper", ptr %t78, i32 0, i32 0
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/load:Loader", ptr %t84, i32 0, i32 3
  %t87 = load ptr, ptr %t86, !tbaa !29
  store ptr %t87, ptr %l40, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/scope:Scoper", ptr %t88, i32 0, i32 25
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  br i1 %t93, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_151a4fd4550fcf07_44af0ef11641bc6b)
  unreachable
bb21:
  br label %bb22
bb22:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/scope:Scoper", ptr %t95, i32 0, i32 25
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Body", ptr %t98, i32 0, i32 7
  %t102 = load i64, ptr %l2, !tbaa !24
  %t105 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t101, i64 %t102)
  store %"compiler/typed:Local" %t105, ptr %l49
  br label %bb23
bb23:
  %t106 = getelementptr %"compiler/typed:Local", ptr %l49, i32 0, i32 0
  %t107 = load i32, ptr %t106, !tbaa !23
  %t108 = load ptr, ptr %l40, !tbaa !29
  %t110 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t108, i32 %t107)
  store { i64, ptr } %t110, ptr %l51
  br label %bb24
bb24:
  %t111 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t112, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evisit(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l20 = alloca ptr
  %l32 = alloca i64
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i1
  %l69 = alloca i64
  %l72 = alloca i64
  %l77 = alloca i64
  %l84 = alloca i64
  %l88 = alloca i64
  %l91 = alloca ptr
  %l92 = alloca i64
  %l96 = alloca i64
  %l100 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i64
  %l109 = alloca i64
  %l112 = alloca ptr
  %l113 = alloca i64
  %l117 = alloca i64
  %l123 = alloca i64
  %l127 = alloca i64
  %l130 = alloca ptr
  %l133 = alloca i64
  %l134 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/scope:Scoper", ptr %t1, i32 0, i32 18
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %t5, i32 0, i32 22
  %t8 = load i64, ptr %t7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4, i64 %t8)
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/scope:Scoper", ptr %t12, i32 0, i32 19
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 22
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t14, i64 %t15, i64 %t19)
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l20, !tbaa !29
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t25 = getelementptr %"compiler/scope:Scoper", ptr %t24, i32 0, i32 22
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = add i64 %t26, 1
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = getelementptr %"compiler/scope:Scoper", ptr %t30, i32 0, i32 22
  store i64 %t28, ptr %t31, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/scope:Scoper", ptr %t32, i32 0, i32 21
  %t35 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  br label %bb3
bb3:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/scope:Scoper", ptr %t38, i32 0, i32 20
  %t41 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t40, i64 %t41, i1 true)
  br label %bb4
bb4:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %t44, i32 0, i32 12
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t46, i64 %t47)
  store i64 %t50, ptr %l32
  br label %bb5
bb5:
  %t51 = load i64, ptr %l32, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/scope:Scoper", ptr %t52, i32 0, i32 12
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = add i64 %t55, 1
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t54, i64 %t57)
  store i64 %t60, ptr %l37
  br label %bb6
bb6:
  %t61 = load i64, ptr %l37, !tbaa !24
  store i64 %t61, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t62 = load i64, ptr %l3, !tbaa !24
  %t63 = load i64, ptr %l2, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb7, label %bb8
bb7:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb12
bb9:
  %t72 = load i64, ptr %l3, !tbaa !24
  %t73 = load i64, ptr %l2, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l44, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb11
bb11:
  %t88 = load i64, ptr %l44, !tbaa !24
  store i64 %t88, ptr %l41, !tbaa !24
  br label %bb12
bb12:
  %t89 = load i64, ptr %l41, !tbaa !24
  store i64 %t89, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t90 = load i64, ptr %l6, !tbaa !24
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb14, label %bb15
bb14:
  br label %bb49
bb15:
  br label %bb16
bb16:
  %t98 = load i64, ptr %l2, !tbaa !24
  %t99 = load i64, ptr %l6, !tbaa !24
  %t100 = load i64, ptr %l4, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/scope:Scoper", ptr %t108, i32 0, i32 13
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t110, i64 %t106)
  store i64 %t114, ptr %l65
  br label %bb17
bb17:
  %t115 = load i64, ptr %l65, !tbaa !24
  store i64 %t115, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  br i1 %t118, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb21
bb19:
  %t120 = load i64, ptr %l8, !tbaa !24
  store i64 %t120, ptr %l69, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/scope:Scoper", ptr %t121, i32 0, i32 18
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t123)
  store i64 %t125, ptr %l72
  br label %bb20
bb20:
  %t126 = load i64, ptr %l69, !tbaa !24
  %t127 = load i64, ptr %l72, !tbaa !24
  %t128 = icmp sge i64 %t126, %t127
  store i1 %t128, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t130 = load i1, ptr %l68, !tbaa !21
  br i1 %t130, label %bb22, label %bb23
bb22:
  br label %bb48
bb23:
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/scope:Scoper", ptr %t131, i32 0, i32 18
  %t134 = load i64, ptr %l8, !tbaa !24
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t133, i64 %t134)
  store i64 %t137, ptr %l77
  br label %bb25
bb25:
  %t138 = load i64, ptr %l77, !tbaa !24
  %t139 = icmp slt i64 %t138, 0
  br i1 %t139, label %bb26, label %bb27
bb26:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evisit(ptr %v0, ptr %t141, i64 %t142)
  br label %bb28
bb27:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/scope:Scoper", ptr %t145, i32 0, i32 20
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t147, i64 %t148)
  store i1 %t151, ptr %l100
  br label %bb36
bb28:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/scope:Scoper", ptr %t152, i32 0, i32 19
  %t155 = load i64, ptr %l8, !tbaa !24
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t154, i64 %t155)
  store i64 %t158, ptr %l84
  br label %bb29
bb29:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/scope:Scoper", ptr %t159, i32 0, i32 19
  %t162 = load i64, ptr %l1, !tbaa !24
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t161, i64 %t162)
  store i64 %t165, ptr %l88
  br label %bb30
bb30:
  %t166 = load i64, ptr %l84, !tbaa !24
  %t167 = load i64, ptr %l88, !tbaa !24
  %t168 = icmp slt i64 %t166, %t167
  br i1 %t168, label %bb31, label %bb32
bb31:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/scope:Scoper", ptr %t170, i32 0, i32 19
  store ptr %t172, ptr %l91, !tbaa !29
  %t173 = load i64, ptr %l1, !tbaa !24
  store i64 %t173, ptr %l92, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %t174, i32 0, i32 19
  %t177 = load i64, ptr %l8, !tbaa !24
  %t180 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t176, i64 %t177)
  store i64 %t180, ptr %l96
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t181 = load ptr, ptr %l91, !tbaa !29
  %t182 = load i64, ptr %l92, !tbaa !24
  %t183 = load i64, ptr %l96, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t181, i64 %t182, i64 %t183)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb47
bb36:
  %t184 = load i1, ptr %l100, !tbaa !21
  br i1 %t184, label %bb37, label %bb38
bb37:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/scope:Scoper", ptr %t185, i32 0, i32 18
  %t188 = load i64, ptr %l8, !tbaa !24
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t187, i64 %t188)
  store i64 %t191, ptr %l105
  br label %bb39
bb38:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb41
bb39:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/scope:Scoper", ptr %t192, i32 0, i32 19
  %t195 = load i64, ptr %l1, !tbaa !24
  %t198 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t194, i64 %t195)
  store i64 %t198, ptr %l109
  br label %bb40
bb40:
  %t199 = load i64, ptr %l105, !tbaa !24
  %t200 = load i64, ptr %l109, !tbaa !24
  %t201 = icmp slt i64 %t199, %t200
  store i1 %t201, ptr %l101, !tbaa !21
  br label %bb41
bb41:
  %t203 = load i1, ptr %l101, !tbaa !21
  br i1 %t203, label %bb42, label %bb43
bb42:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/scope:Scoper", ptr %t204, i32 0, i32 19
  store ptr %t206, ptr %l112, !tbaa !29
  %t207 = load i64, ptr %l1, !tbaa !24
  store i64 %t207, ptr %l113, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/scope:Scoper", ptr %t208, i32 0, i32 18
  %t211 = load i64, ptr %l8, !tbaa !24
  %t214 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t210, i64 %t211)
  store i64 %t214, ptr %l117
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t215 = load ptr, ptr %l112, !tbaa !29
  %t216 = load i64, ptr %l113, !tbaa !24
  %t217 = load i64, ptr %l117, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t215, i64 %t216, i64 %t217)
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t218 = load i64, ptr %l6, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l6, !tbaa !24
  br label %bb13
bb49:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/scope:Scoper", ptr %t222, i32 0, i32 19
  %t225 = load i64, ptr %l1, !tbaa !24
  %t228 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t224, i64 %t225)
  store i64 %t228, ptr %l123
  br label %bb50
bb50:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/scope:Scoper", ptr %t229, i32 0, i32 18
  %t232 = load i64, ptr %l1, !tbaa !24
  %t235 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t231, i64 %t232)
  store i64 %t235, ptr %l127
  br label %bb51
bb51:
  %t236 = load i64, ptr %l123, !tbaa !24
  %t237 = load i64, ptr %l127, !tbaa !24
  %t238 = icmp eq i64 %t236, %t237
  br i1 %t238, label %bb52, label %bb53
bb52:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/scope:Scoper", ptr %t240, i32 0, i32 23
  store ptr %t242, ptr %l130, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/scope:Scoper", ptr %t243, i32 0, i32 24
  %t247 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t245)
  store i64 %t247, ptr %l133
  br label %bb54
bb53:
  br label %bb68
bb54:
  %t248 = load ptr, ptr %l130, !tbaa !29
  %t249 = load i64, ptr %l133, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t248, i64 %t249)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/scope:Scoper", ptr %t250, i32 0, i32 21
  %t254 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t252)
  %t255 = extractvalue { i32, i64 } %t254, 1
  %t256 = extractvalue { i32, i64 } %t254, 0
  store i32 %t256, ptr %l138
  %t257 = icmp ne i32 %t256, 0
  br i1 %t257, label %bb58, label %ok.258, !prof !99
ok.258:
  store i64 %t255, ptr %l137
  br label %bb57
bb57:
  %t259 = load i64, ptr %l137, !tbaa !24
  store i64 %t259, ptr %l134, !tbaa !24
  br label %bb60
bb58:
  br label %bb59
bb59:
  call void @__olang_ert_req_clear()
  br label %bb67
bb60:
  %t260 = load i64, ptr %l134, !tbaa !24
  store i64 %t260, ptr %l9, !tbaa !24
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/scope:Scoper", ptr %t261, i32 0, i32 20
  %t264 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t263, i64 %t264, i1 false)
  br label %bb61
bb61:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/scope:Scoper", ptr %t267, i32 0, i32 24
  %t270 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t269, i64 %t270)
  br label %bb62
bb62:
  %t273 = load i64, ptr %l9, !tbaa !24
  %t274 = load i64, ptr %l1, !tbaa !24
  %t277 = icmp eq i64 %t273, %t274
  br i1 %t277, label %bb63, label %bb64
bb63:
  br label %bb67
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb56
bb67:
  br label %bb68
bb68:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fscope_2eflHas(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i64, ptr %l13, !tbaa !24
  %t23 = icmp eq i64 %t18, %a1
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb32
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l16
  br label %bb12
bb12:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l4, !tbaa !21
  br label %bb32
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 4
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Elem", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %t47)
  store i1 %t49, ptr %l25
  br label %bb19
bb19:
  %t50 = load i1, ptr %l25, !tbaa !21
  store i1 %t50, ptr %l4, !tbaa !21
  br label %bb32
bb20:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb21, label %bb22
bb21:
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 5
  store i1 %t58, ptr %l27, !tbaa !21
  br label %bb22
bb22:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb23, label %bb24
bb23:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Payload", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = call i1 @compiler_2fscope_2eflThroughRef(ptr %v0, ptr %t69)
  store i1 %t71, ptr %l34
  br label %bb26
bb26:
  %t72 = load i1, ptr %l34, !tbaa !21
  store i1 %t72, ptr %l4, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_aab467fd51570cd7_b7c12dbd63ae1fe3)
  unreachable
bb32:
  %t73 = load i1, ptr %l4, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fscope_2eownField(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 3
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t41 = call i1 @compiler_2fscope_2eisParamRead(ptr %v0, ptr %t37, i64 %a1)
  store i1 %t41, ptr %l21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load i64, ptr %l3, !tbaa !24
  store i64 %t43, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_97a3337844e24daf_abbacdff6e992493)
  unreachable
bb20:
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_21f109796fa0acee_6e7b91baaed0fa92)
  unreachable
bb26:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2eregionRoot(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2fscope_2eregionLocal(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l13
  br label %bb6
bb6:
  %t19 = load i64, ptr %l13, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  br label %bb33
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t21 = load ptr, ptr %l14, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = call i64 @compiler_2fscope_2eregionRoot(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l21
  br label %bb13
bb13:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  br label %bb33
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 5
  store i1 %t46, ptr %l23, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l3, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Payload", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = call i64 @compiler_2fscope_2eregionRoot(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l30
  br label %bb20
bb20:
  %t60 = load i64, ptr %l30, !tbaa !24
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb33
bb21:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb22, label %bb23
bb22:
  %t65 = load ptr, ptr %l31, !tbaa !29
  %t66 = load i64, ptr %t65
  %t68 = icmp eq i64 %t66, 4
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb23
bb23:
  %t69 = load i1, ptr %l32, !tbaa !21
  br i1 %t69, label %bb24, label %bb25
bb24:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t72, i32 0, i32 2
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l4, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Elem", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = call i64 @compiler_2fscope_2eregionRoot(ptr %v0, ptr %t79)
  store i64 %t81, ptr %l39
  br label %bb27
bb27:
  %t82 = load i64, ptr %l39, !tbaa !24
  store i64 %t82, ptr %l5, !tbaa !24
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_b150ba266c9424e3_527b6225611e1947)
  unreachable
bb33:
  %t83 = load i64, ptr %l5, !tbaa !24
  store i64 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fscope_2erelVar({ i64, [2 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [2 x i64] }
  %l1 = alloca i64
  %l2 = alloca i64
  %rv = alloca i64
  store { i64, [2 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l0, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l1, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  br label %bb13
bb4:
  %t12 = load { i64, [2 x i64] }, ptr %l0
  %t14 = extractvalue { i64, [2 x i64] } %t12, 0
  %t15 = icmp eq i64 %t14, 3
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i64 -2, ptr %l2, !tbaa !24
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_efbd916e88210f2b_3c9d7e310fda5a0f)
  unreachable
bb13:
  %t17 = load i64, ptr %l2, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fscope_2ethroughElem(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb38
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fscope_2ethroughElem(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l16
  br label %bb12
bb12:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l4, !tbaa !21
  br label %bb38
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 5
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Payload", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = call i1 @compiler_2fscope_2ethroughElem(ptr %v0, ptr %t47)
  store i1 %t49, ptr %l25
  br label %bb19
bb19:
  %t50 = load i1, ptr %l25, !tbaa !21
  store i1 %t50, ptr %l4, !tbaa !21
  br label %bb38
bb20:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb21, label %bb22
bb21:
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load i64, ptr %t55
  %t58 = icmp eq i64 %t56, 2
  store i1 %t58, ptr %l27, !tbaa !21
  br label %bb22
bb22:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb23, label %bb24
bb23:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t69 = call i1 @compiler_2fscope_2ethroughElemExpr(ptr %v0, ptr %t66)
  store i1 %t69, ptr %l34
  br label %bb26
bb26:
  %t70 = load i1, ptr %l34, !tbaa !21
  store i1 %t70, ptr %l4, !tbaa !21
  br label %bb38
bb27:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t72 = load ptr, ptr %l35, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb28, label %bb29
bb28:
  %t75 = load ptr, ptr %l35, !tbaa !29
  %t76 = load i64, ptr %t75
  %t78 = icmp eq i64 %t76, 6
  store i1 %t78, ptr %l36, !tbaa !21
  br label %bb29
bb29:
  %t79 = load i1, ptr %l36, !tbaa !21
  br i1 %t79, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_c25c9d2f1e472363_8be32a0de7941d67)
  unreachable
bb38:
  %t80 = load i1, ptr %l4, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fscope_3aTerm(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb13
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 5, label %bb7 ]
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i64 }, ptr %t39, i32 0, i32 0
  %t41 = load i64, ptr %t40
  %t44 = icmp eq i64 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb11, label %bb1
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load i1, ptr %l2, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d12 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d14 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"an instance is built in one of them" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"if" }>, align 8
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2fscope_2eFitValue = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eFnCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eHolds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eObliged = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eUseThru = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eUseView = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fscope_2eWhyHolds = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fscope_2ecollectExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fscope_2ecollectBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparts(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7ac300513ffc0d8b_1ff73281fb7180bf = external constant [0 x i8]
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ealiasBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_75e5f2eb37e26097_1cabe39736605273 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eLen_H9daf28210c013890fd7cb07d1d61ba6e(ptr %v0, ptr %a0)
declare %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_H9c3932eb53016bf6f47a08eef06aacbe(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e_Hf018e585e117ec5a1eef851c731bcf79(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eLen_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyMethodObligations(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eunAway(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ewholeLocal(ptr %v0, ptr %a0)
@olang_loc_aa04e26a4d7578a7_d714aefedcea6ccb = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aTerm_2eRuns({ i64, [2 x i64] } %a0)
@olang_loc_5ad8ce5e83291793_3404c81b33ceede7 = external constant [0 x i8]
declare i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecalleeType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/scope:rel" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eAt_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fscope_2eWhyField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eadmitsStores(ptr %v0, ptr %a0, i32 %a1)
declare { { i64, [2 x i64] }, i1, i1 } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eagreeStep(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2, { i64, [2 x i64] } %a3, i1 %a4)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eargAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eScopeArgsDisagree(ptr %v0)
declare i32 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elift(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_2dbc08d4832115c_eb31bc54ed1b9440 = external constant [0 x i8]
@olang_loc_1fe97746d4c06972_784e8262c547b126 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehere(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2escopeOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_3e89652ff7706bd0_4686e7e94f816f94 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBuildThroughUnknownScope(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_d867a1bfd37ee6cf_dcf5a89f84b878b3 = external constant [0 x i8]
@olang_loc_8066e5da37f3a23b_ece6b8d6fabe8bf7 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsSum(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_e7f077513292cd77_7cc56e961d13405b = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebodyOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ederivedOf({ i64, [2 x i64] } %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5cb72587228936ff_1a6837af5c2cdca3 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecarried(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisNullLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholds(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2echoicePeek(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallsItself(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d29996678377eee3_d1b974339c283baf = external constant [0 x i8]
@olang_loc_f1651a5ea92fc764_7e198d85ea96f48 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportObligation(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3d4ddf74a6173f57_410f107a77dd9b9b = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecountTrue(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fscope_2eisNameChar(i8 %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetEnd(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eAt_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_47dfda24c0d910ef_d5dd1abdea0dbd2b = external constant [0 x i8]
@G_2ecompiler_2fscope_2eFitLocal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eorder(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
@G_2ecompiler_2fscope_2eFailsBlock = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisBlock(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@G_2ecompiler_2fscope_2eFitGlobal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eoblige(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2, i1 %a3)
@G_2ecompiler_2fscope_2eFitReturn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisFunc(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapsDiffer(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fscope_2eFitOwn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@olang_loc_cd338417bf9b4adb_b24d723c852a352f = external constant [0 x i8]
@olang_loc_d3b44bae2eeaabda_3c9b483dafe8946e = external constant [0 x i8]
@G_2ecompiler_2fscope_2eFitField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowedLocal(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReferenceNarrowed(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteRefill(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efitErrorAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i1 %a3)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteCondValue(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2fscope_2eunPassed(ptr %v0, ptr %a0)
@olang_loc_27f9f8003e66d4c2_25a72554bedf4966 = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5600be0283c8c0a9_e199d532ae73234d = external constant [0 x i8]
@olang_loc_7c76a5ff0a201730_60f43c735987f7c = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewordAt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteParamCopy(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/msgs:Msg" %a4)
@G_2ecompiler_2fscope_2eFitPayload = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamOfTerm(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_3bc3e93e18d6d20f_7eae6e8d3b47aeeb = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enoteMadeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5)
declare ptr @compiler_2fscope_2eunWidened(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ethroughTemp(ptr %v0, ptr %a0)
@olang_loc_60c4a5415da7e8de_419e4bf7c0afcf6a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteSliceOfTemporary(ptr %v0)
@olang_loc_b5bc1eafb7fb24bc_101d8a8a62fdaef8 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eLen_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
@olang_loc_7a90b7bdb9714c43_1678fcc4f66eb1af = external constant [0 x i8]
@olang_loc_6745ec537010077c_cd78d81ca0e46128 = external constant [0 x i8]
@G_2ecompiler_2fscope_2eFnNamed = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/scope:fnUse" @compiler_2fscope_3afnUse_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i32 %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e_2ePush_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %a0, %"compiler/scope:fnUse" %a1)
declare %"compiler/scope:Val" @compiler_2fscope_2eexisting({ i64, [2 x i64] } %a0)
@olang_loc_dfe5171975bf36eb_aa3b662f409f8247 = external constant [0 x i8]
@G_2ecompiler_2fscope_2eFnLambda = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ector(ptr %v0, i64 %a0)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2evalTerm(ptr %v0, ptr %a0, %"compiler/scope:Val" %a1, { i64, [2 x i64] } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2ePush_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2ePush_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einner(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuildsThrough(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, %"compiler/source:Span" %a2, i64 %a3, i64 %a4)
@olang_loc_a2d4f483fb27576a_a259ee19e61ad216 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuild(ptr %v0, ptr %a0, i32 %a1, { i64, [2 x i64] } %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eToArray_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePass(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare %"compiler/scope:Val" @compiler_2fscope_2efresh({ i64, [2 x i64] } %a0)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esetOf(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, { i64, [2 x i64] } %a2)
@olang_loc_cd93dd66fff9371_25f7b586ffad81fd = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_7f2dfcb5aefb8d2f_7317cc0c9543fac3 = external constant [0 x i8]
@olang_loc_6b4093eaa9dab6e0_ebbf8088c45502d4 = external constant [0 x i8]
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a83726b6934b3ff_5f714cf565db93e3 = external constant [0 x i8]
@olang_loc_2e96c7acbe66a05d_c52c59876e2a2911 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cf803334873ab58c_86e77fabc50c4870 = external constant [0 x i8]
@olang_loc_9240ff9e46a5e522_bd3125f7ca002596 = external constant [0 x i8]
@olang_loc_eb63e604b2611290_41d83017cc1dec3c = external constant [0 x i8]
@olang_loc_6c6eb04d68cfd0ef_192fcc26ed37d7ab = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eisHandle(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2euses(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
@olang_loc_10bab568b406970b_66071842e5074daf = external constant [0 x i8]
@olang_loc_a5122b0b395bd8b_9870aa37c8b5f2ef = external constant [0 x i8]
@olang_loc_51a7ef38ab67534a_42b12633f9b5762e = external constant [0 x i8]
@olang_loc_eb1882221c8ba3ab_83c8c93664e1ea07 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
@olang_loc_23c81803d40008f7_62b49cfbea8bbbfb = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estoreThrough(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ehasLateLocals(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H075aca2c24d2905e4fa457b6b6d6570e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eClear_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e_2eClear_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2eClear_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb8a8915e0c6fdfa2e5a92011b8ae7ed6(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eClea_Hf36a88772899b36a46c039ef55a38999(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2eNewPlan(ptr %out, ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_75ea16a293881b53_a3e5ee6d3f4964f = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextDepth(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextBase(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstanceOf(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2einstContexts(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erun(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estrReceiver(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeDestructor(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteHere(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ehasRel(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e_2ePush_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0, %"compiler/scope:rel" %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecomputeKeeps(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eSetAt_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecapturingLambda(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_fc6a508fadcedae3_fc22fb2e32e5f087 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ekwStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecallOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ec2dd22d28cc6988_9d0975400b204864 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elandByObligations(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_d50f79fefbee4394_12c4367532f3ae80 = external constant [0 x i8]
@olang_loc_dd2a7e97808fa897_95cc897457ffa94b = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eScopedCall(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2earenaValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eheldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2econstCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ematchMadeHere(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_717fbf6233ca6ed7_9b693e4aa4ffeed3 = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ewhereLives(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_298102a92201c9c7_d2c28c3c337e3c3b = external constant [0 x i8]
@olang_loc_1a9ca456c0fc4f74_b6b9f556459eb628 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2enewOrConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2a6344a0ea169f03_937c8368e559d747 = external constant [0 x i8]
@olang_loc_61c41c23c6ba3b82_8b9b0b538ad52716 = external constant [0 x i8]
@olang_loc_b9c5758278fbc269_f38d2c0a467d6fd = external constant [0 x i8]
@olang_loc_8672b56b87660cf0_1560bce2a415882c = external constant [0 x i8]
@olang_loc_e498d93abb20b61c_9a7977ea577c2990 = external constant [0 x i8]
@olang_loc_a9ed640346de181b_d10bb16716ed4607 = external constant [0 x i8]
@olang_loc_5073d45cb29e2b2c_5271f582f3c3830 = external constant [0 x i8]
@olang_loc_e97645627b4ddb42_25acdb187fd0af56 = external constant [0 x i8]
@olang_loc_1193222288ba1b5a_e9751e9a82c409de = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_677694645a0d3ce1_ddba560673e185 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ectorParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_46d6c69b453c665f_cff2ba6bc4bd85db = external constant [0 x i8]
declare i64 @compiler_2fscope_2eflRootExpr(ptr %v0, ptr %a0)
@olang_loc_963cba883dc4bd20_64c99da4a40e3f44 = external constant [0 x i8]
@olang_loc_91fdca4bfcfaef3f_360ec22200b0b313 = external constant [0 x i8]
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fscope_2eflRoot(ptr %v0, ptr %a0)
@olang_loc_540f6a9ea70b2c8e_44714d47ed7a19d2 = external constant [0 x i8]
@olang_loc_64a11eda2e926835_fc7221612b7da3f9 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eloopElement(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f36ec553cccc6d8b_49e0ae301a30aec7 = external constant [0 x i8]
@olang_loc_3ac591dbc49e034a_5e5353de6850ba66 = external constant [0 x i8]
@olang_loc_f1a9adfa27cda772_3c6bd3db0db08dee = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLoopCopy(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_52f8221627bf3e99_4756b04755d4c995 = external constant [0 x i8]
@olang_loc_a5b27f3bb1762b98_6a8daa3c154ac73c = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteLoopCopyLent(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eocStmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3, i1 %a4)
@olang_loc_b076c1f6c97c7ed4_fcdcfd5688cdce70 = external constant [0 x i8]
@olang_loc_8680c8bf7a40147c_d650a7d3d4e83170 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2elastBracket(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_22d8393d4f188012_8c9f9e39cb427896 = external constant [0 x i8]
@olang_loc_7213214fb222d0c9_1eae7674ed2401ad = external constant [0 x i8]
@olang_loc_7794e183659425f8_898d85cb25e621fc = external constant [0 x i8]
@olang_loc_2d6fa2178670cc38_6a7a96bf0e7e73f4 = external constant [0 x i8]
@olang_loc_623296b25c4a2534_fd3f86d02d068538 = external constant [0 x i8]
@olang_loc_954f6d28b3a52ac3_ffd2f75d7c0d3157 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_8238268b26f31dac_815f599ed0aacad8 = external constant [0 x i8]
@olang_loc_aa39aa4c0e664ec2_f7b48f4e1663008e = external constant [0 x i8]
@olang_loc_f4a3544f2707870_d9666a31439b8584 = external constant [0 x i8]
@olang_loc_47b6b2aadca5a54f_c1e200e36f23f353 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebuiltOK(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
@olang_loc_eb55abbe133e6e93_c0f65549c24d0e87 = external constant [0 x i8]
@olang_loc_c7f09c07f504fc14_94662c6a2fc8d498 = external constant [0 x i8]
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efieldRec(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_e013e5ec68fcecba_db38ff2cf21abe4e = external constant [0 x i8]
@olang_loc_63182fc37cc18751_f7db738c3fc11405 = external constant [0 x i8]
@olang_loc_5d42891563591ec0_78209504ed027d54 = external constant [0 x i8]
@olang_loc_17b5555e490eca40_3a72f19dfd1cef0c = external constant [0 x i8]
@olang_loc_7d1ba41a43de5df_b306ac45f9e7717b = external constant [0 x i8]
@olang_loc_deaf2ed7955484ae_e8df1e0ec0ac14ba = external constant [0 x i8]
@olang_loc_79e16856d8fb6455_e8daf01bb6fb0841 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eretValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2erlStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_e18696d73c32363c_a4e51a2c5acfe520 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esolePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esoleBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_9b30aadb18eb277f_192cdcf64c29ca93 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eholdsDtorIn(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eplaceOperands(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epeekPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultTooShort(ptr %v0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare { { i64, [2 x i64] }, i1, i64 } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eslotOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e78903360621b090_3122ead72721c55c = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnCaptureTooShort(ptr %v0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eclauseBuilds(ptr %v0, ptr %a0, i64 %a1, { i64, [2 x i64] } %a2, %"compiler/source:Span" %a3)
@olang_loc_aee576b8a3d2f436_529adcde89776572 = external constant [0 x i8]
@olang_loc_13f804c0f75facd_7560a9ac77a32da9 = external constant [0 x i8]
@olang_loc_19e7888b9ded6be5_cbea83f8bb640751 = external constant [0 x i8]
@olang_loc_e9bdb4d0fe7c1914_18007eac4987ca18 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2efreshIntoUnknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, [2 x i64] } %a3)
@olang_loc_a5b38bc8e2246423_334fa60605363c37 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpawnResultsDisagree(ptr %v0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ebindingUnknown(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare %"compiler/source:Span" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eeqAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFieldBindingUnknown(ptr %v0)
@olang_loc_e1bbe67f5ab83fa2_6597018deaf47546 = external constant [0 x i8]
@olang_loc_d14ac281d7095de3_5cf23a39181ab0c7 = external constant [0 x i8]
@olang_loc_e22ca2126d036b2f_5c370e93157d3a93 = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edecide(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, { i64, ptr } %a3, i64 %a4)
@olang_loc_894def51c550c10b_edf695233d65cd0f = external constant [0 x i8]
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartsTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2etempTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_8bfac37a1f29704b_1a5bb9d5b57da78f = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eueStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_f9519574182490d7_42fc30f708795ccb = external constant [0 x i8]
@olang_loc_32e8be698fa34edf_ce62f399ed2770f3 = external constant [0 x i8]
declare %"compiler/scope:Val" @compiler_2fscope_2eplain()
declare %"compiler/scope:Val" @compiler_2fscope_3aVal_2ector(ptr %v0, i32 %a0, { i64, [2 x i64] } %a1)
declare %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eread(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, { i64, [2 x i64] } %a3)
declare i1 @compiler_2fscope_2eanyArrayBox(ptr %v0, ptr %a0)
declare ptr @compiler_2fscope_2ecompiler_2fscope_3aScoper_2econvertedPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fscope_2eFitAnyCopy = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ecall(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, [2 x i64] } %a4)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eitemKind(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_c2fa93d259f2a930_39b628a0a193c8f4 = external constant [0 x i8]
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epayloadAgree(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2epartLand(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, { i64, [2 x i64] } %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSliceSplitValue(ptr %v0)
declare { i64, [2 x i64] } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2esliceTerm(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e_2e_Hb4ab14fd1aa8deeb21095c3402461540(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_7fc6f86e6d881397_d60d455fa8d09f43 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ejoin(ptr %v0, ptr %a0, %"compiler/scope:Val" %a1, %"compiler/scope:Val" %a2, { i64, [2 x i64] } %a3)
declare %"compiler/scope:Val" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [2 x i64] } %a2)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2edefaultFits(ptr %v0, ptr %a0, %"compiler/scope:Val" %a1, %"compiler/scope:Val" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultScope(ptr %v0)
@olang_loc_1de706dca54a6565_725d55ac423312f1 = external constant [0 x i8]
@olang_loc_c8e4956a22175e34_6f39088095568ee0 = external constant [0 x i8]
@olang_loc_4a494c4484ad71e8_cc0fe42b10928cfc = external constant [0 x i8]
@olang_loc_151a4fd4550fcf07_44af0ef11641bc6b = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_aab467fd51570cd7_b7c12dbd63ae1fe3 = external constant [0 x i8]
declare i1 @compiler_2fscope_2eisParamRead(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_97a3337844e24daf_abbacdff6e992493 = external constant [0 x i8]
@olang_loc_21f109796fa0acee_6e7b91baaed0fa92 = external constant [0 x i8]
declare i64 @compiler_2fscope_2eregionLocal(ptr %v0, ptr %a0)
@olang_loc_b150ba266c9424e3_527b6225611e1947 = external constant [0 x i8]
@olang_loc_efbd916e88210f2b_3c9d7e310fda5a0f = external constant [0 x i8]
declare i1 @compiler_2fscope_2ethroughElemExpr(ptr %v0, ptr %a0)
@olang_loc_c25c9d2f1e472363_8be32a0de7941d67 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
