; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_17d90761b6eeef4f_a6a3eb1441af054b = weak_odr constant [54 x i8] c"std/prelude/vec.olang:283: array length out of range\0A\00"
@olang_loc_6ddf12576f9517fa_e349023ad73ce4b6 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:284: array length out of range\0A\00"
