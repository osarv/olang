; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/free:Free" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, i1 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/free:mustW" = type { ptr, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/free:reason" = type { i64, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/free:walker" = type { ptr, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
define dso_local void @compiler_2ffree_2eAnyPlace_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eLAssign_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eLCall_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eMustNone_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eMustTop_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -2, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eOMov_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eOPl_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eOUnk_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2ffree_2eOUnk, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eRStore_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eRTask_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l23 = alloca { i64, ptr }
  %l28 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l2, !tbaa !21
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l14
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l13
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t12, ptr %l10, !tbaa !27
  br label %bb7
bb3:
  %t13 = load i32, ptr %l14, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_73a600468f127602_bc0c68a189771b8e)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb7:
  %t18 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t31, ptr %l23, !tbaa !27
  %t32 = load i64, ptr %l7, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i64, ptr %t35, i64 %t32
  %t37 = load i64, ptr %t36, !tbaa !34
  %t43 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %t37)
  store i1 %t43, ptr %l28
  br label %bb12
bb12:
  %t44 = load i1, ptr %l28, !tbaa !21
  br i1 %t44, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l7, !tbaa !24
  br label %bb8
bb17:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = add i64 %t49, %t50
  store i64 %t53, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb1
bb19:
  %t55 = load i1, ptr %l2, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2ebaseOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb23
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 4
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Elem", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l4, !tbaa !29
  br label %bb23
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load i64, ptr %t44
  %t47 = icmp eq i64 %t45, 5
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l23, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Payload", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_aa0994ef0ced0737_f892d7c71adaceeb)
  unreachable
bb23:
  %t61 = load ptr, ptr %l4, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2ecallOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i1
  %l37 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb31
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 14
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Try", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Try", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb14, label %bb15
bb13:
  store ptr null, ptr %l23, !tbaa !29
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_60a6a0a204dd2601_d155668594ed74d)
  unreachable
bb15:
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Try", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call ptr @compiler_2ffree_2ecallOf(ptr %v0, ptr %t53)
  store ptr %t55, ptr %l29
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l29, !tbaa !29
  store ptr %t56, ptr %l23, !tbaa !29
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l23, !tbaa !29
  store ptr %t57, ptr %l4, !tbaa !29
  br label %bb31
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l30, !tbaa !29
  %t63 = load i64, ptr %t62
  %t65 = icmp eq i64 %t63, 17
  store i1 %t65, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l31, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = call ptr @compiler_2ffree_2ecallOf(ptr %v0, ptr %t73)
  store ptr %t75, ptr %l37
  br label %bb25
bb25:
  %t76 = load ptr, ptr %l37, !tbaa !29
  store ptr %t76, ptr %l4, !tbaa !29
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_dcc470c1d4c9ec59_c1df879736016c25)
  unreachable
bb31:
  %t77 = load ptr, ptr %l4, !tbaa !29
  store ptr %t77, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDecide(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, [2 x i64] }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l99 = alloca i64
  %l104 = alloca i64
  %l107 = alloca i64
  %l127 = alloca i64
  %l132 = alloca ptr
  %l135 = alloca i1
  %l138 = alloca i1
  %l143 = alloca ptr
  %l146 = alloca i1
  %l148 = alloca ptr
  %l151 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l157 = alloca ptr
  %l158 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l161 = alloca ptr
  %l162 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l165 = alloca ptr
  %l166 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l169 = alloca ptr
  %l170 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l184 = alloca ptr
  %l191 = alloca ptr
  %l195 = alloca i64
  %l196 = alloca ptr
  %l203 = alloca ptr
  %l204 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l207 = alloca ptr
  %l208 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l211 = alloca ptr
  %l212 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l215 = alloca ptr
  %l216 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l219 = alloca ptr
  %l224 = alloca ptr
  %l234 = alloca i1
  %l243 = alloca i64
  %l246 = alloca i64
  %l269 = alloca ptr
  %l274 = alloca ptr
  %l278 = alloca ptr
  %l288 = alloca i1
  %l294 = alloca i64
  %l296 = alloca i64
  %l299 = alloca { i64, ptr }
  %l304 = alloca i64
  %l307 = alloca { i64, ptr }
  %l309 = alloca i64
  %l315 = alloca i64
  %l318 = alloca i64
  %l340 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l345 = alloca i64
  %l348 = alloca i64
  %l366 = alloca ptr
  %l367 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l374 = alloca i64
  %l377 = alloca i64
  %l398 = alloca { i64, ptr }
  %l406 = alloca { i64, ptr }
  %l411 = alloca i1
  %l417 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l424 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l425 = alloca i64
  %l435 = alloca { i64, ptr }
  %l442 = alloca i64
  %l444 = alloca i64
  %l449 = alloca i64
  %l461 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l463 = alloca { i64, ptr }
  %l466 = alloca { i64, ptr }
  %l467 = alloca i32
  %l476 = alloca { i64, ptr }
  %l492 = alloca i64
  %l493 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l494 = alloca i64
  %l504 = alloca { i64, ptr }
  %l511 = alloca i64
  %l513 = alloca i64
  %l518 = alloca i64
  %l531 = alloca ptr
  %l532 = alloca { i64, ptr }
  %l535 = alloca { i64, ptr }
  %l536 = alloca i32
  %l545 = alloca { i64, ptr }
  %l561 = alloca i64
  %l564 = alloca i64
  %l567 = alloca i64
  %l582 = alloca i32
  %l589 = alloca i64
  %l592 = alloca i64
  %l613 = alloca ptr
  %l614 = alloca i64
  %l616 = alloca i1
  %l620 = alloca i1
  %l623 = alloca i1
  %l627 = alloca i1
  %l630 = alloca ptr
  %l634 = alloca ptr
  %l635 = alloca i1
  %l640 = alloca { i64, ptr }
  %l644 = alloca ptr
  %l648 = alloca ptr
  %l650 = alloca i64
  %l654 = alloca ptr
  %l658 = alloca { i64, ptr }
  %l661 = alloca i32
  %l666 = alloca i64
  %l671 = alloca i64
  %l674 = alloca i64
  %l696 = alloca i64
  %l701 = alloca i64
  %l707 = alloca i64
  %l710 = alloca i64
  %l713 = alloca i64
  %l720 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s66 = alloca %olang.scope
  %s68 = alloca %olang.scope
  %t696 = alloca i64
  %t858 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 3
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %t5
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i64, ptr %l2, !tbaa !24
  %t10 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 7
  store i64 %t7, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l99
  br label %bb1
bb1:
  %t16 = load i64, ptr %l99, !tbaa !24
  store i64 %t16, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb2, label %bb3
bb2:
  %t25 = load i64, ptr %l7, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb7
bb4:
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l107, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb6
bb6:
  %t45 = load i64, ptr %l107, !tbaa !24
  store i64 %t45, ptr %l104, !tbaa !24
  br label %bb7
bb7:
  %t46 = load i64, ptr %l104, !tbaa !24
  store i64 %t46, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb10:
  br label %bb11
bb11:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store i64 %t63, ptr %l10, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l10, !tbaa !24
  %t69 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t65, i64 %t66)
  store i64 %t69, ptr %l127
  br label %bb12
bb12:
  %t70 = load i64, ptr %l127, !tbaa !24
  store i64 %t70, ptr %l11, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/free:Free", ptr %t71, i32 0, i32 16
  %t74 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t73, i64 %t74)
  br label %bb13
bb13:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:Free", ptr %t77, i32 0, i32 17
  store ptr %t79, ptr %l132, !tbaa !29
  %t80 = load i64, ptr %l2, !tbaa !24
  %t82 = icmp sge i64 %t80, 0
  br i1 %t82, label %bb14, label %bb15
bb14:
  %t84 = load i64, ptr %l11, !tbaa !24
  %t86 = icmp eq i64 %t84, -3
  br i1 %t86, label %bb16, label %bb17
bb15:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb19
bb16:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb18
bb17:
  %t88 = load i64, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l2, !tbaa !24
  %t92 = icmp eq i64 %t88, %t89
  store i1 %t92, ptr %l138, !tbaa !21
  br label %bb18
bb18:
  %t94 = load i1, ptr %l138, !tbaa !21
  store i1 %t94, ptr %l135, !tbaa !21
  br label %bb19
bb19:
  %t95 = load ptr, ptr %l132, !tbaa !29
  %t96 = load i1, ptr %l135, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t95, i1 %t96)
  br label %bb20
bb20:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/free:Free", ptr %t97, i32 0, i32 18
  store ptr %t99, ptr %l143, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownCode(ptr %v0, ptr %t100, i64 %t101)
  store i1 %t104, ptr %l146
  br label %bb21
bb21:
  %t105 = load ptr, ptr %l143, !tbaa !29
  %t106 = load i1, ptr %l146, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t105, i1 %t106)
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/free:Free", ptr %t107, i32 0, i32 19
  store ptr %t109, ptr %l148, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i64, ptr %l10, !tbaa !24
  %t114 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epreludeCode(ptr %v0, ptr %t110, i64 %t111)
  store i1 %t114, ptr %l151
  br label %bb23
bb23:
  %t115 = load ptr, ptr %l148, !tbaa !29
  %t116 = load i1, ptr %l151, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t115, i1 %t116)
  br label %bb24
bb24:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:Free", ptr %t117, i32 0, i32 20
  store ptr %t119, ptr %l153, !tbaa !29
  %t120 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t120, ptr %l154
  br label %bb25
bb25:
  %t121 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l154
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t121, ptr %t122
  %t123 = load ptr, ptr %l153, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v0, ptr %t123, ptr %t122)
  br label %bb26
bb26:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t125, i32 0, i32 21
  store ptr %t127, ptr %l157, !tbaa !29
  %t128 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t128, ptr %l158
  br label %bb27
bb27:
  %t129 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l158
  %t130 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t129, ptr %t130
  %t131 = load ptr, ptr %l157, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v0, ptr %t131, ptr %t130)
  br label %bb28
bb28:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/free:Free", ptr %t133, i32 0, i32 22
  store ptr %t135, ptr %l161, !tbaa !29
  %t136 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %l162
  br label %bb29
bb29:
  %t137 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l162
  %t138 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t137, ptr %t138
  %t139 = load ptr, ptr %l161, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v0, ptr %t139, ptr %t138)
  br label %bb30
bb30:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/free:Free", ptr %t141, i32 0, i32 23
  store ptr %t143, ptr %l165, !tbaa !29
  %t144 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %l166
  br label %bb31
bb31:
  %t145 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l166
  %t146 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t145, ptr %t146
  %t147 = load ptr, ptr %l165, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v0, ptr %t147, ptr %t146)
  br label %bb32
bb32:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/free:Free", ptr %t149, i32 0, i32 24
  store ptr %t151, ptr %l169, !tbaa !29
  %t152 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %l170
  br label %bb33
bb33:
  %t153 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l170
  %t154 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t153, ptr %t154
  %t155 = load ptr, ptr %l169, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v0, ptr %t155, ptr %t154)
  br label %bb34
bb34:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/free:Free", ptr %t157, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t159, i1 false)
  br label %bb35
bb35:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/free:Free", ptr %t161, i32 0, i32 26
  %t164 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t163, i64 %t164)
  br label %bb36
bb36:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/free:Free", ptr %t167, i32 0, i32 27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t169, i1 true)
  br label %bb37
bb37:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/free:Free", ptr %t171, i32 0, i32 28
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t173, i1 false)
  br label %bb38
bb38:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/free:Free", ptr %t175, i32 0, i32 1
  %t178 = load i64, ptr %l10, !tbaa !24
  %t181 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t177, i64 %t178)
  store ptr %t181, ptr %l184
  br label %bb39
bb39:
  %t182 = load ptr, ptr %l184, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Body", ptr %t182, i32 0, i32 1
  %t185 = load { i64, [2 x i64] }, ptr %t184
  store { i64, [2 x i64] } %t185, ptr %l12
  %t187 = load { i64, [2 x i64] }, ptr %l12
  %t189 = extractvalue { i64, [2 x i64] } %t187, 0
  %t190 = icmp eq i64 %t189, 0
  br i1 %t190, label %bb40, label %bb41
bb40:
  %t192 = getelementptr { i64, [2 x i64] }, ptr %l12, i32 0, i32 1
  %t193 = getelementptr { i64 }, ptr %t192, i32 0, i32 0
  %t194 = load i64, ptr %t193
  store i64 %t194, ptr %l13, !tbaa !24
  br label %bb42
bb41:
  br label %bb49
bb42:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/free:Free", ptr %t196, i32 0, i32 0
  %t199 = load ptr, ptr %t198, !tbaa !29
  store ptr %t199, ptr %l191, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/free:Free", ptr %t200, i32 0, i32 0
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t204 = load i64, ptr %l13, !tbaa !24
  %t207 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t203, i64 %t204)
  store i64 %t207, ptr %l195
  br label %bb43
bb43:
  %t208 = load ptr, ptr %l191, !tbaa !29
  %t209 = load i64, ptr %l195, !tbaa !24
  %t210 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t208, i64 %t209)
  store ptr %t210, ptr %l196
  br label %bb44
bb44:
  %t211 = load ptr, ptr %l196, !tbaa !29
  %t213 = getelementptr %"compiler/ast:Func", ptr %t211, i32 0, i32 7
  %t214 = load i1, ptr %t213, !tbaa !21
  br i1 %t214, label %bb45, label %bb46
bb45:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/free:Free", ptr %t216, i32 0, i32 29
  %t219 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t218, i64 %t219)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_38e68c2f90f7ff92_433845456bb6222e)
  unreachable
bb54:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/free:Free", ptr %t222, i32 0, i32 45
  store ptr %t224, ptr %l203, !tbaa !29
  %t225 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t225, ptr %l204
  br label %bb55
bb55:
  %t226 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l204
  %t227 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t226, ptr %t227
  %t228 = load ptr, ptr %l203, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v0, ptr %t228, ptr %t227)
  br label %bb56
bb56:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/free:Free", ptr %t230, i32 0, i32 46
  store ptr %t232, ptr %l207, !tbaa !29
  %t233 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t233, ptr %l208
  br label %bb57
bb57:
  %t234 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l208
  %t235 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %t235
  %t236 = load ptr, ptr %l207, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v0, ptr %t236, ptr %t235)
  br label %bb58
bb58:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/free:Free", ptr %t238, i32 0, i32 47
  store ptr %t240, ptr %l211, !tbaa !29
  %t241 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t241, ptr %l212
  br label %bb59
bb59:
  %t242 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l212
  %t243 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t242, ptr %t243
  %t244 = load ptr, ptr %l211, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H80281abdeb8e6e8df4d34cf6bb2c83d9(ptr %v0, ptr %v0, ptr %t244, ptr %t243)
  br label %bb60
bb60:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/free:Free", ptr %t246, i32 0, i32 48
  store ptr %t248, ptr %l215, !tbaa !29
  %t249 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t249, ptr %l216
  br label %bb61
bb61:
  %t250 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l216
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t250, ptr %t251
  %t252 = load ptr, ptr %l215, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v0, ptr %t252, ptr %t251)
  br label %bb62
bb62:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/free:Free", ptr %t254, i32 0, i32 49
  store ptr %t256, ptr %l219, !tbaa !29
  %t257 = icmp sge i64 0, 0
  br i1 %t257, label %bb63, label %bb64
bb63:
  %t259 = icmp sle i64 0, 1152921504606846975
  br i1 %t259, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_cfa78d5b759fffbc_7789424fbd23b3b0)
  unreachable
bb65:
  %t261 = mul i64 0, 8
  %t262 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t261)
  %t263 = insertvalue { i64, ptr } undef, i64 0, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t262, 1
  %t265 = load ptr, ptr %l219, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t265, { i64, ptr } %t264)
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_cfa78d5b759fffbc_7789424fbd23b3b0)
  unreachable
bb67:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/free:Free", ptr %t267, i32 0, i32 50
  store ptr %t269, ptr %l224, !tbaa !29
  %t270 = icmp sge i64 0, 0
  br i1 %t270, label %bb68, label %bb69
bb68:
  %t272 = icmp sle i64 0, 1152921504606846975
  br i1 %t272, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_c07c4c0bbb573d1f_6e3b998739460953)
  unreachable
bb70:
  %t274 = mul i64 0, 8
  %t275 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t274)
  %t276 = insertvalue { i64, ptr } undef, i64 0, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  %t278 = load ptr, ptr %l224, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t278, { i64, ptr } %t277)
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_c07c4c0bbb573d1f_6e3b998739460953)
  unreachable
bb72:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/free:Free", ptr %t280, i32 0, i32 61
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t282, i1 false)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb74:
  %t284 = load i64, ptr %l9, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l9, !tbaa !24
  br label %bb8
bb75:
  %t288 = load i64, ptr %l2, !tbaa !24
  %t290 = icmp slt i64 %t288, 0
  br i1 %t290, label %bb76, label %bb77
bb76:
  %t292 = load i1, ptr %l3, !tbaa !21
  %t294 = xor i1 %t292, true
  store i1 %t294, ptr %l234, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l234, !tbaa !21
  br label %bb78
bb78:
  %t296 = load i1, ptr %l234, !tbaa !21
  br i1 %t296, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb80:
  br label %bb81
bb81:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load i1, ptr %l3, !tbaa !21
  %t301 = getelementptr %"compiler/free:Free", ptr %t297, i32 0, i32 66
  store i1 %t298, ptr %t301, !tbaa !21
  store i64 0, ptr %l14, !tbaa !24
  %t302 = load i64, ptr %l4, !tbaa !24
  store i64 %t302, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t304 = load i64, ptr %l15, !tbaa !24
  %t305 = load i64, ptr %l14, !tbaa !24
  %t308 = icmp sgt i64 %t304, %t305
  br i1 %t308, label %bb82, label %bb83
bb82:
  %t310 = load i64, ptr %l16, !tbaa !24
  %t312 = icmp sgt i64 %t310, 0
  br i1 %t312, label %bb84, label %bb85
bb83:
  store i64 0, ptr %l243, !tbaa !24
  br label %bb87
bb84:
  %t314 = load i64, ptr %l15, !tbaa !24
  %t315 = load i64, ptr %l14, !tbaa !24
  %t318 = sub i64 %t314, %t315
  %t319 = load i64, ptr %l16, !tbaa !24
  %t322 = add i64 %t318, %t319
  %t324 = sub i64 %t322, 1
  %t325 = load i64, ptr %l16, !tbaa !24
  %t328 = sdiv i64 %t324, %t325
  store i64 %t328, ptr %l246, !tbaa !24
  br label %bb86
bb85:
  store i64 0, ptr %l246, !tbaa !24
  br label %bb86
bb86:
  %t330 = load i64, ptr %l246, !tbaa !24
  store i64 %t330, ptr %l243, !tbaa !24
  br label %bb87
bb87:
  %t331 = load i64, ptr %l243, !tbaa !24
  store i64 %t331, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb88
bb88:
  store %olang.scope zeroinitializer, ptr %s9
  %t332 = load i64, ptr %l18, !tbaa !24
  %t333 = load i64, ptr %l17, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s9)
  br label %bb102
bb90:
  br label %bb91
bb91:
  %t340 = load i64, ptr %l14, !tbaa !24
  %t341 = load i64, ptr %l18, !tbaa !24
  %t342 = load i64, ptr %l16, !tbaa !24
  %t345 = mul i64 %t341, %t342
  %t348 = add i64 %t340, %t345
  store i64 %t348, ptr %l19, !tbaa !24
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load i64, ptr %l19, !tbaa !24
  %t354 = getelementptr %"compiler/free:Free", ptr %t350, i32 0, i32 65
  store i64 %t351, ptr %t354, !tbaa !24
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/free:Free", ptr %t355, i32 0, i32 1
  %t358 = load i64, ptr %l19, !tbaa !24
  %t361 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t357, i64 %t358)
  store ptr %t361, ptr %l269
  br label %bb92
bb92:
  %t362 = load ptr, ptr %l269, !tbaa !29
  %t364 = getelementptr %"compiler/typed:Body", ptr %t362, i32 0, i32 11
  %t365 = load ptr, ptr %t364, !tbaa !29
  %t367 = icmp eq ptr %t365, null
  %t369 = xor i1 %t367, true
  br i1 %t369, label %bb93, label %bb94
bb93:
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l274, !tbaa !29
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/free:Free", ptr %t372, i32 0, i32 1
  %t375 = load i64, ptr %l19, !tbaa !24
  %t378 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t374, i64 %t375)
  store ptr %t378, ptr %l278
  br label %bb95
bb94:
  br label %bb100
bb95:
  %t379 = load ptr, ptr %l278, !tbaa !29
  %t381 = getelementptr %"compiler/typed:Body", ptr %t379, i32 0, i32 11
  %t382 = load ptr, ptr %t381, !tbaa !29
  store ptr %t382, ptr %l20, !tbaa !29
  %t384 = load ptr, ptr %l20, !tbaa !29
  %t386 = icmp eq ptr %t384, null
  br i1 %t386, label %bb96, label %bb97
bb96:
  call void @__olang_check_failed(ptr @olang_loc_4a2ee03059613aea_a0006d5774bd9126)
  unreachable
bb97:
  br label %bb98
bb98:
  %t388 = load ptr, ptr %l20, !tbaa !29
  %t389 = load ptr, ptr %l274, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v0, ptr %t389, ptr %t388)
  br label %bb99
bb99:
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s9)
  br label %bb101
bb101:
  %t391 = load i64, ptr %l18, !tbaa !24
  %t393 = add i64 %t391, 1
  store i64 %t393, ptr %l18, !tbaa !24
  br label %bb88
bb102:
  %t395 = load i64, ptr %l2, !tbaa !24
  %t397 = icmp slt i64 %t395, 0
  br i1 %t397, label %bb103, label %bb104
bb103:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/free:Free", ptr %t399, i32 0, i32 52
  %t402 = load i64, ptr %t401, !tbaa !24
  %t404 = icmp eq i64 %t402, 0
  store i1 %t404, ptr %l288, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb105
bb105:
  %t406 = load i1, ptr %l288, !tbaa !21
  br i1 %t406, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb107:
  br label %bb108
bb108:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = getelementptr %"compiler/free:Free", ptr %t407, i32 0, i32 8
  %t411 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t409)
  store i64 %t411, ptr %l294
  br label %bb109
bb109:
  %t412 = load i64, ptr %l294, !tbaa !24
  %t413 = icmp eq i64 %t412, 0
  br i1 %t413, label %bb110, label %bb111
bb110:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb111:
  br label %bb112
bb112:
  %t415 = call i64 @std_2ftime_2eNow()
  store i64 %t415, ptr %l296
  br label %bb113
bb113:
  %t416 = load i64, ptr %l296, !tbaa !24
  store i64 %t416, ptr %l21, !tbaa !24
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/free:Free", ptr %t417, i32 0, i32 2
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t422 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesFirst(ptr %v0, ptr %s0, ptr %t420)
  store { i64, ptr } %t422, ptr %l299
  br label %bb114
bb114:
  %t423 = load { i64, ptr }, ptr %l299, !tbaa !27
  store { i64, ptr } %t423, ptr %l22, !tbaa !27
  %t424 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t427 = load i64, ptr %l4, !tbaa !24
  %t430 = icmp ne i64 %t426, %t427
  br i1 %t430, label %bb115, label %bb116
bb115:
  %t432 = load i64, ptr %l4, !tbaa !24
  store i64 %t432, ptr %l304, !tbaa !24
  %t433 = load i64, ptr %l304, !tbaa !24
  %t434 = icmp sge i64 %t433, 0
  br i1 %t434, label %bb117, label %bb118
bb116:
  br label %bb136
bb117:
  %t436 = load i64, ptr %l304, !tbaa !24
  %t437 = icmp sle i64 %t436, 1152921504606846975
  br i1 %t437, label %bb119, label %bb120
bb118:
  call void @__olang_check_failed(ptr @olang_loc_b4402838d0fec99d_8d63b3fead7ad2c9)
  unreachable
bb119:
  %t439 = load i64, ptr %l304, !tbaa !24
  %t440 = mul i64 %t439, 8
  %t441 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t440)
  %t442 = insertvalue { i64, ptr } undef, i64 %t439, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t441, 1
  store { i64, ptr } %t443, ptr %l307, !tbaa !27
  %t444 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 0
  %t446 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t447 = extractvalue { i64, ptr } %t446, 0
  store i64 %t447, ptr %l309, !tbaa !24
  %t449 = load i64, ptr %l309, !tbaa !24
  %t450 = icmp eq i64 %t445, %t449
  br i1 %t450, label %bb121, label %bb122
bb120:
  call void @__olang_check_failed(ptr @olang_loc_b4402838d0fec99d_8d63b3fead7ad2c9)
  unreachable
bb121:
  %t452 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t453 = load ptr, ptr %t452, !tbaa !27
  %t454 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = load i64, ptr %l309, !tbaa !24
  %t457 = mul i64 %t456, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t453, ptr %t455, i64 %t457, i1 false)
  br label %bb123
bb122:
  %t458 = load { i64, ptr }, ptr %l307, !tbaa !27
  store { i64, ptr } %t458, ptr %l22, !tbaa !27
  br label %bb123
bb123:
  store i64 0, ptr %l23, !tbaa !24
  %t459 = load i64, ptr %l4, !tbaa !24
  store i64 %t459, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t461 = load i64, ptr %l24, !tbaa !24
  %t462 = load i64, ptr %l23, !tbaa !24
  %t465 = icmp sgt i64 %t461, %t462
  br i1 %t465, label %bb124, label %bb125
bb124:
  %t467 = load i64, ptr %l25, !tbaa !24
  %t469 = icmp sgt i64 %t467, 0
  br i1 %t469, label %bb126, label %bb127
bb125:
  store i64 0, ptr %l315, !tbaa !24
  br label %bb129
bb126:
  %t471 = load i64, ptr %l24, !tbaa !24
  %t472 = load i64, ptr %l23, !tbaa !24
  %t475 = sub i64 %t471, %t472
  %t476 = load i64, ptr %l25, !tbaa !24
  %t479 = add i64 %t475, %t476
  %t481 = sub i64 %t479, 1
  %t482 = load i64, ptr %l25, !tbaa !24
  %t485 = sdiv i64 %t481, %t482
  store i64 %t485, ptr %l318, !tbaa !24
  br label %bb128
bb127:
  store i64 0, ptr %l318, !tbaa !24
  br label %bb128
bb128:
  %t487 = load i64, ptr %l318, !tbaa !24
  store i64 %t487, ptr %l315, !tbaa !24
  br label %bb129
bb129:
  %t488 = load i64, ptr %l315, !tbaa !24
  store i64 %t488, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb130
bb130:
  store %olang.scope zeroinitializer, ptr %s16
  %t489 = load i64, ptr %l27, !tbaa !24
  %t490 = load i64, ptr %l26, !tbaa !24
  %t493 = icmp slt i64 %t489, %t490
  %t495 = xor i1 %t493, true
  br i1 %t495, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s16)
  br label %bb135
bb132:
  br label %bb133
bb133:
  %t497 = load i64, ptr %l23, !tbaa !24
  %t498 = load i64, ptr %l27, !tbaa !24
  %t499 = load i64, ptr %l25, !tbaa !24
  %t502 = mul i64 %t498, %t499
  %t505 = add i64 %t497, %t502
  store i64 %t505, ptr %l28, !tbaa !24
  %t507 = load i64, ptr %l28, !tbaa !24
  %t508 = load i64, ptr %l28, !tbaa !24
  %t511 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t512 = load ptr, ptr %t511, !tbaa !27
  %t513 = getelementptr i64, ptr %t512, i64 %t507
  store i64 %t508, ptr %t513, !tbaa !34
  call void @__olang_scope_close(ptr %s16)
  br label %bb134
bb134:
  %t514 = load i64, ptr %l27, !tbaa !24
  %t516 = add i64 %t514, 1
  store i64 %t516, ptr %l27, !tbaa !24
  br label %bb130
bb135:
  br label %bb136
bb136:
  %t518 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3e_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t518, ptr %l340
  br label %bb137
bb137:
  %t519 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l340
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t519, ptr %l29
  store i64 0, ptr %l30, !tbaa !24
  %t520 = load i64, ptr %l4, !tbaa !24
  store i64 %t520, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t522 = load i64, ptr %l31, !tbaa !24
  %t523 = load i64, ptr %l30, !tbaa !24
  %t526 = icmp sgt i64 %t522, %t523
  br i1 %t526, label %bb138, label %bb139
bb138:
  %t528 = load i64, ptr %l32, !tbaa !24
  %t530 = icmp sgt i64 %t528, 0
  br i1 %t530, label %bb140, label %bb141
bb139:
  store i64 0, ptr %l345, !tbaa !24
  br label %bb143
bb140:
  %t532 = load i64, ptr %l31, !tbaa !24
  %t533 = load i64, ptr %l30, !tbaa !24
  %t536 = sub i64 %t532, %t533
  %t537 = load i64, ptr %l32, !tbaa !24
  %t540 = add i64 %t536, %t537
  %t542 = sub i64 %t540, 1
  %t543 = load i64, ptr %l32, !tbaa !24
  %t546 = sdiv i64 %t542, %t543
  store i64 %t546, ptr %l348, !tbaa !24
  br label %bb142
bb141:
  store i64 0, ptr %l348, !tbaa !24
  br label %bb142
bb142:
  %t548 = load i64, ptr %l348, !tbaa !24
  store i64 %t548, ptr %l345, !tbaa !24
  br label %bb143
bb143:
  %t549 = load i64, ptr %l345, !tbaa !24
  store i64 %t549, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb144
bb144:
  store %olang.scope zeroinitializer, ptr %s19
  %t550 = load i64, ptr %l34, !tbaa !24
  %t551 = load i64, ptr %l33, !tbaa !24
  %t554 = icmp slt i64 %t550, %t551
  %t556 = xor i1 %t554, true
  br i1 %t556, label %bb145, label %bb146
bb145:
  call void @__olang_scope_close(ptr %s19)
  br label %bb151
bb146:
  br label %bb147
bb147:
  %t558 = load i64, ptr %l30, !tbaa !24
  %t559 = load i64, ptr %l34, !tbaa !24
  %t560 = load i64, ptr %l32, !tbaa !24
  %t563 = mul i64 %t559, %t560
  %t566 = add i64 %t558, %t563
  store i64 %t566, ptr %l35, !tbaa !24
  store ptr %l29, ptr %l366, !tbaa !29
  %t568 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t568, ptr %l367
  br label %bb148
bb148:
  %t569 = load ptr, ptr %l366, !tbaa !29
  %t570 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l367
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H514c3278d648f49337aafc4c9fcf3b34(ptr %s0, ptr %s0, ptr %t569, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t570)
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s19)
  br label %bb150
bb150:
  %t571 = load i64, ptr %l34, !tbaa !24
  %t573 = add i64 %t571, 1
  store i64 %t573, ptr %l34, !tbaa !24
  br label %bb144
bb151:
  store i64 0, ptr %l36, !tbaa !24
  %t575 = load i64, ptr %l4, !tbaa !24
  store i64 %t575, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t577 = load i64, ptr %l37, !tbaa !24
  %t578 = load i64, ptr %l36, !tbaa !24
  %t581 = icmp sgt i64 %t577, %t578
  br i1 %t581, label %bb152, label %bb153
bb152:
  %t583 = load i64, ptr %l38, !tbaa !24
  %t585 = icmp sgt i64 %t583, 0
  br i1 %t585, label %bb154, label %bb155
bb153:
  store i64 0, ptr %l374, !tbaa !24
  br label %bb157
bb154:
  %t587 = load i64, ptr %l37, !tbaa !24
  %t588 = load i64, ptr %l36, !tbaa !24
  %t591 = sub i64 %t587, %t588
  %t592 = load i64, ptr %l38, !tbaa !24
  %t595 = add i64 %t591, %t592
  %t597 = sub i64 %t595, 1
  %t598 = load i64, ptr %l38, !tbaa !24
  %t601 = sdiv i64 %t597, %t598
  store i64 %t601, ptr %l377, !tbaa !24
  br label %bb156
bb155:
  store i64 0, ptr %l377, !tbaa !24
  br label %bb156
bb156:
  %t603 = load i64, ptr %l377, !tbaa !24
  store i64 %t603, ptr %l374, !tbaa !24
  br label %bb157
bb157:
  %t604 = load i64, ptr %l374, !tbaa !24
  store i64 %t604, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb158
bb158:
  store %olang.scope zeroinitializer, ptr %s22
  %t605 = load i64, ptr %l40, !tbaa !24
  %t606 = load i64, ptr %l39, !tbaa !24
  %t609 = icmp slt i64 %t605, %t606
  %t611 = xor i1 %t609, true
  br i1 %t611, label %bb159, label %bb160
bb159:
  call void @__olang_scope_close(ptr %s22)
  br label %bb178
bb160:
  br label %bb161
bb161:
  %t613 = load i64, ptr %l36, !tbaa !24
  %t614 = load i64, ptr %l40, !tbaa !24
  %t615 = load i64, ptr %l38, !tbaa !24
  %t618 = mul i64 %t614, %t615
  %t621 = add i64 %t613, %t618
  store i64 %t621, ptr %l41, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s23
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t625 = getelementptr %"compiler/free:Free", ptr %t623, i32 0, i32 2
  %t626 = load ptr, ptr %t625, !tbaa !29
  %t627 = load i64, ptr %l41, !tbaa !24
  %t630 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesOf(ptr %v0, ptr %s23, ptr %t626, i64 %t627)
  store { i64, ptr } %t630, ptr %l398
  br label %bb162
bb162:
  %t631 = load { i64, ptr }, ptr %l398, !tbaa !27
  %t632 = extractvalue { i64, ptr } %t631, 0
  %t633 = extractvalue { i64, ptr } %t631, 1
  %t634 = mul i64 %t632, 8
  %t635 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t634)
  call void @llvm.memcpy.p0.p0.i64(ptr %t635, ptr %t633, i64 %t634, i1 false)
  %t636 = insertvalue { i64, ptr } undef, i64 %t632, 0
  %t637 = insertvalue { i64, ptr } %t636, ptr %t635, 1
  store { i64, ptr } %t637, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t639 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t641 = extractvalue { i64, ptr } %t639, 0
  store i64 %t641, ptr %l44, !tbaa !24
  br label %bb163
bb163:
  store %olang.scope zeroinitializer, ptr %s24
  %t643 = load i64, ptr %l43, !tbaa !24
  %t644 = load i64, ptr %l44, !tbaa !24
  %t647 = icmp slt i64 %t643, %t644
  %t649 = xor i1 %t647, true
  br i1 %t649, label %bb164, label %bb165
bb164:
  call void @__olang_scope_close(ptr %s24)
  br label %bb176
bb165:
  br label %bb166
bb166:
  %t651 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t651, ptr %l406, !tbaa !27
  %t652 = load i64, ptr %l43, !tbaa !24
  %t654 = getelementptr { i64, ptr }, ptr %l406, i32 0, i32 1
  %t655 = load ptr, ptr %t654, !tbaa !27
  %t656 = getelementptr i64, ptr %t655, i64 %t652
  %t657 = load i64, ptr %t656, !tbaa !34
  store i64 %t657, ptr %l45, !tbaa !24
  %t659 = load i64, ptr %l45, !tbaa !24
  %t661 = icmp sge i64 %t659, 0
  br i1 %t661, label %bb167, label %bb168
bb167:
  %t663 = load i64, ptr %l45, !tbaa !24
  %t664 = load i64, ptr %l4, !tbaa !24
  %t667 = icmp slt i64 %t663, %t664
  store i1 %t667, ptr %l411, !tbaa !21
  br label %bb169
bb168:
  store i1 false, ptr %l411, !tbaa !21
  br label %bb169
bb169:
  %t669 = load i1, ptr %l411, !tbaa !21
  br i1 %t669, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s25
  %t670 = load i64, ptr %l45, !tbaa !24
  %t673 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H1bfd72835118c4a69ac66e4bcdbec3db(ptr %s0, ptr %s0, ptr %l29, i64 %t670)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t673, ptr %l417
  br label %bb172
bb171:
  br label %bb174
bb172:
  %t674 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l417
  %t675 = call ptr @__olang_scope_alloc_a(ptr %s25, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t674, ptr %t675
  %t676 = load i64, ptr %l41, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t675, i64 %t676)
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s25)
  br label %bb174
bb174:
  call void @__olang_scope_close(ptr %s24)
  br label %bb175
bb175:
  %t679 = load i64, ptr %l43, !tbaa !24
  %t681 = add i64 %t679, 1
  store i64 %t681, ptr %l43, !tbaa !24
  br label %bb163
bb176:
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s22)
  br label %bb177
bb177:
  %t683 = load i64, ptr %l40, !tbaa !24
  %t685 = add i64 %t683, 1
  store i64 %t685, ptr %l40, !tbaa !24
  br label %bb158
bb178:
  store i64 0, ptr %l46, !tbaa !24
  %t687 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t687, ptr %l424
  br label %bb179
bb179:
  %t688 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l424
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t688, ptr %l47
  %t689 = load i64, ptr %l4, !tbaa !24
  store i64 %t689, ptr %l425, !tbaa !24
  %t690 = load i64, ptr %l425, !tbaa !24
  %t691 = icmp sge i64 %t690, 0
  br i1 %t691, label %bb180, label %bb181
bb180:
  %t693 = load i64, ptr %l425, !tbaa !24
  %t694 = mul i64 %t693, 1
  %t695 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t694)
  store i64 0, ptr %t696
  br label %fill.697
fill.697:
  %t700 = load i64, ptr %t696
  %t701 = icmp slt i64 %t700, %t693
  br i1 %t701, label %fillb.698, label %filld.699
fillb.698:
  %t702 = getelementptr i1, ptr %t695, i64 %t700
  store i1 true, ptr %t702
  %t703 = add i64 %t700, 1
  store i64 %t703, ptr %t696
  br label %fill.697
filld.699:
  %t704 = insertvalue { i64, ptr } undef, i64 %t693, 0
  %t705 = insertvalue { i64, ptr } %t704, ptr %t695, 1
  store { i64, ptr } %t705, ptr %l48, !tbaa !27
  %t707 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t707, ptr %l49, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  %t709 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t711 = extractvalue { i64, ptr } %t709, 0
  store i64 %t711, ptr %l51, !tbaa !24
  br label %bb182
bb181:
  call void @__olang_check_failed(ptr @olang_loc_7774858aec9876f0_864a54e21bf2c67c)
  unreachable
bb182:
  store %olang.scope zeroinitializer, ptr %s29
  %t713 = load i64, ptr %l50, !tbaa !24
  %t714 = load i64, ptr %l51, !tbaa !24
  %t717 = icmp slt i64 %t713, %t714
  %t719 = xor i1 %t717, true
  br i1 %t719, label %bb183, label %bb184
bb183:
  call void @__olang_scope_close(ptr %s29)
  br label %bb188
bb184:
  br label %bb185
bb185:
  %t721 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t721, ptr %l435, !tbaa !27
  %t722 = load i64, ptr %l50, !tbaa !24
  %t724 = getelementptr { i64, ptr }, ptr %l435, i32 0, i32 1
  %t725 = load ptr, ptr %t724, !tbaa !27
  %t726 = getelementptr i64, ptr %t725, i64 %t722
  %t727 = load i64, ptr %t726, !tbaa !34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l47, i64 %t727)
  br label %bb186
bb186:
  call void @__olang_scope_close(ptr %s29)
  br label %bb187
bb187:
  %t732 = load i64, ptr %l50, !tbaa !24
  %t734 = add i64 %t732, 1
  store i64 %t734, ptr %l50, !tbaa !24
  br label %bb182
bb188:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb189
bb189:
  store %olang.scope zeroinitializer, ptr %s32
  %t736 = load i64, ptr %l53, !tbaa !24
  store i64 %t736, ptr %l442, !tbaa !24
  %t738 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l47)
  store i64 %t738, ptr %l444
  br label %bb190
bb190:
  %t739 = load i64, ptr %l442, !tbaa !24
  %t740 = load i64, ptr %l444, !tbaa !24
  %t741 = icmp slt i64 %t739, %t740
  %t743 = xor i1 %t741, true
  br i1 %t743, label %bb191, label %bb192
bb191:
  call void @__olang_scope_close(ptr %s32)
  br label %bb220
bb192:
  br label %bb193
bb193:
  %t745 = load i64, ptr %l53, !tbaa !24
  %t748 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l47, i64 %t745)
  store i64 %t748, ptr %l449
  br label %bb194
bb194:
  %t749 = load i64, ptr %l449, !tbaa !24
  store i64 %t749, ptr %l54, !tbaa !24
  %t750 = load i64, ptr %l54, !tbaa !24
  %t752 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t753 = load ptr, ptr %t752, !tbaa !27
  %t754 = getelementptr i1, ptr %t753, i64 %t750
  store i1 false, ptr %t754, !tbaa !31
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t757 = getelementptr %"compiler/free:Free", ptr %t755, i32 0, i32 30
  store i1 false, ptr %t757, !tbaa !21
  %t758 = load i64, ptr %l46, !tbaa !24
  %t760 = add i64 %t758, 1
  store i64 %t760, ptr %l46, !tbaa !24
  %t762 = load ptr, ptr %l0, !tbaa !29
  %t763 = load i64, ptr %l54, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2emustOf(ptr %v0, ptr %t762, i64 %t763)
  br label %bb195
bb195:
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t768 = getelementptr %"compiler/free:Free", ptr %t766, i32 0, i32 30
  %t769 = load i1, ptr %t768, !tbaa !21
  %t771 = xor i1 %t769, true
  br i1 %t771, label %bb196, label %bb197
bb196:
  call void @__olang_scope_close(ptr %s32)
  br label %bb219
bb197:
  br label %bb198
bb198:
  store %olang.scope zeroinitializer, ptr %s34
  %t773 = load i64, ptr %l54, !tbaa !24
  %t776 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H1bfd72835118c4a69ac66e4bcdbec3db(ptr %s0, ptr %s0, ptr %l29, i64 %t773)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t776, ptr %l461
  br label %bb199
bb199:
  %t777 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l461
  %t778 = call ptr @__olang_scope_alloc_a(ptr %s34, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t777, ptr %t778
  store ptr %t778, ptr %l55, !tbaa !29
  store i64 0, ptr %l56, !tbaa !24
  br label %bb200
bb200:
  store %olang.scope zeroinitializer, ptr %s35
  %t780 = load ptr, ptr %l55, !tbaa !29
  %t781 = load i64, ptr %l56, !tbaa !24
  %t784 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t780, i64 %t781)
  %t785 = extractvalue { i32, { i64, ptr } } %t784, 1
  %t786 = extractvalue { i32, { i64, ptr } } %t784, 0
  store i32 %t786, ptr %l467
  %t787 = icmp ne i32 %t786, 0
  br i1 %t787, label %bb202, label %ok.788
ok.788:
  store { i64, ptr } %t785, ptr %l466
  br label %bb201
bb201:
  %t789 = load { i64, ptr }, ptr %l466, !tbaa !27
  store { i64, ptr } %t789, ptr %l463, !tbaa !27
  br label %bb206
bb202:
  %t790 = load i32, ptr %l467, !tbaa !23
  %t791 = ashr i32 %t790, 16
  %t793 = icmp eq i32 %t791, 1
  br i1 %t793, label %bb203, label %bb204
bb203:
  br label %bb205
bb204:
  call void @__olang_check_failed(ptr @olang_loc_f82c60b4f3fd4c74_8c152bea1dd531b8)
  unreachable
bb205:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s35)
  br label %bb218
bb206:
  %t795 = load { i64, ptr }, ptr %l463, !tbaa !27
  store { i64, ptr } %t795, ptr %l57, !tbaa !27
  %t796 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t798 = extractvalue { i64, ptr } %t796, 0
  store i64 %t798, ptr %l58, !tbaa !24
  store i64 0, ptr %l59, !tbaa !24
  br label %bb207
bb207:
  store %olang.scope zeroinitializer, ptr %s36
  %t800 = load i64, ptr %l59, !tbaa !24
  %t801 = load i64, ptr %l58, !tbaa !24
  %t804 = icmp slt i64 %t800, %t801
  %t806 = xor i1 %t804, true
  br i1 %t806, label %bb208, label %bb209
bb208:
  call void @__olang_scope_close(ptr %s36)
  br label %bb216
bb209:
  br label %bb210
bb210:
  %t808 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t808, ptr %l476, !tbaa !27
  %t809 = load i64, ptr %l59, !tbaa !24
  %t811 = getelementptr { i64, ptr }, ptr %l476, i32 0, i32 1
  %t812 = load ptr, ptr %t811, !tbaa !27
  %t813 = getelementptr i64, ptr %t812, i64 %t809
  %t814 = load i64, ptr %t813, !tbaa !34
  store i64 %t814, ptr %l60, !tbaa !24
  %t816 = load i64, ptr %l60, !tbaa !24
  %t818 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t819 = load ptr, ptr %t818, !tbaa !27
  %t820 = getelementptr i1, ptr %t819, i64 %t816
  %t821 = load i1, ptr %t820, !tbaa !31
  %t823 = xor i1 %t821, true
  br i1 %t823, label %bb211, label %bb212
bb211:
  %t825 = load i64, ptr %l60, !tbaa !24
  %t827 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t828 = load ptr, ptr %t827, !tbaa !27
  %t829 = getelementptr i1, ptr %t828, i64 %t825
  store i1 true, ptr %t829, !tbaa !31
  %t830 = load i64, ptr %l60, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l47, i64 %t830)
  br label %bb213
bb212:
  br label %bb214
bb213:
  br label %bb214
bb214:
  call void @__olang_scope_close(ptr %s36)
  br label %bb215
bb215:
  %t833 = load i64, ptr %l59, !tbaa !24
  %t835 = add i64 %t833, 1
  store i64 %t835, ptr %l59, !tbaa !24
  br label %bb207
bb216:
  %t837 = load i64, ptr %l56, !tbaa !24
  %t838 = load i64, ptr %l58, !tbaa !24
  %t841 = add i64 %t837, %t838
  store i64 %t841, ptr %l56, !tbaa !24
  call void @__olang_scope_close(ptr %s35)
  br label %bb217
bb217:
  br label %bb200
bb218:
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s32)
  br label %bb219
bb219:
  %t843 = load i64, ptr %l53, !tbaa !24
  %t845 = add i64 %t843, 1
  store i64 %t845, ptr %l53, !tbaa !24
  br label %bb189
bb220:
  %t847 = call i64 @std_2ftime_2eNow()
  store i64 %t847, ptr %l492
  br label %bb221
bb221:
  %t848 = load i64, ptr %l492, !tbaa !24
  store i64 %t848, ptr %l61, !tbaa !24
  store i64 0, ptr %l62, !tbaa !24
  %t849 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t849, ptr %l493
  br label %bb222
bb222:
  %t850 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l493
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t850, ptr %l63
  %t851 = load i64, ptr %l4, !tbaa !24
  store i64 %t851, ptr %l494, !tbaa !24
  %t852 = load i64, ptr %l494, !tbaa !24
  %t853 = icmp sge i64 %t852, 0
  br i1 %t853, label %bb223, label %bb224
bb223:
  %t855 = load i64, ptr %l494, !tbaa !24
  %t856 = mul i64 %t855, 1
  %t857 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t856)
  store i64 0, ptr %t858
  br label %fill.859
fill.859:
  %t862 = load i64, ptr %t858
  %t863 = icmp slt i64 %t862, %t855
  br i1 %t863, label %fillb.860, label %filld.861
fillb.860:
  %t864 = getelementptr i1, ptr %t857, i64 %t862
  store i1 true, ptr %t864
  %t865 = add i64 %t862, 1
  store i64 %t865, ptr %t858
  br label %fill.859
filld.861:
  %t866 = insertvalue { i64, ptr } undef, i64 %t855, 0
  %t867 = insertvalue { i64, ptr } %t866, ptr %t857, 1
  store { i64, ptr } %t867, ptr %l64, !tbaa !27
  %t869 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t869, ptr %l65, !tbaa !27
  store i64 0, ptr %l66, !tbaa !24
  %t871 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t873 = extractvalue { i64, ptr } %t871, 0
  store i64 %t873, ptr %l67, !tbaa !24
  br label %bb225
bb224:
  call void @__olang_check_failed(ptr @olang_loc_1d52b8c7af03b45e_7ee7d49b67a560a)
  unreachable
bb225:
  store %olang.scope zeroinitializer, ptr %s41
  %t875 = load i64, ptr %l66, !tbaa !24
  %t876 = load i64, ptr %l67, !tbaa !24
  %t879 = icmp slt i64 %t875, %t876
  %t881 = xor i1 %t879, true
  br i1 %t881, label %bb226, label %bb227
bb226:
  call void @__olang_scope_close(ptr %s41)
  br label %bb231
bb227:
  br label %bb228
bb228:
  %t883 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t883, ptr %l504, !tbaa !27
  %t884 = load i64, ptr %l66, !tbaa !24
  %t886 = getelementptr { i64, ptr }, ptr %l504, i32 0, i32 1
  %t887 = load ptr, ptr %t886, !tbaa !27
  %t888 = getelementptr i64, ptr %t887, i64 %t884
  %t889 = load i64, ptr %t888, !tbaa !34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l63, i64 %t889)
  br label %bb229
bb229:
  call void @__olang_scope_close(ptr %s41)
  br label %bb230
bb230:
  %t894 = load i64, ptr %l66, !tbaa !24
  %t896 = add i64 %t894, 1
  store i64 %t896, ptr %l66, !tbaa !24
  br label %bb225
bb231:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb232
bb232:
  store %olang.scope zeroinitializer, ptr %s44
  %t898 = load i64, ptr %l69, !tbaa !24
  store i64 %t898, ptr %l511, !tbaa !24
  %t900 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l63)
  store i64 %t900, ptr %l513
  br label %bb233
bb233:
  %t901 = load i64, ptr %l511, !tbaa !24
  %t902 = load i64, ptr %l513, !tbaa !24
  %t903 = icmp slt i64 %t901, %t902
  %t905 = xor i1 %t903, true
  br i1 %t905, label %bb234, label %bb235
bb234:
  call void @__olang_scope_close(ptr %s44)
  br label %bb263
bb235:
  br label %bb236
bb236:
  %t907 = load i64, ptr %l69, !tbaa !24
  %t910 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l63, i64 %t907)
  store i64 %t910, ptr %l518
  br label %bb237
bb237:
  %t911 = load i64, ptr %l518, !tbaa !24
  store i64 %t911, ptr %l70, !tbaa !24
  %t912 = load i64, ptr %l70, !tbaa !24
  %t914 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t915 = load ptr, ptr %t914, !tbaa !27
  %t916 = getelementptr i1, ptr %t915, i64 %t912
  store i1 false, ptr %t916, !tbaa !31
  %t917 = load ptr, ptr %l0, !tbaa !29
  %t919 = getelementptr %"compiler/free:Free", ptr %t917, i32 0, i32 30
  store i1 false, ptr %t919, !tbaa !21
  %t920 = load i64, ptr %l62, !tbaa !24
  %t922 = add i64 %t920, 1
  store i64 %t922, ptr %l62, !tbaa !24
  %t924 = load ptr, ptr %l0, !tbaa !29
  %t925 = load i64, ptr %l70, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewalk(ptr %v0, ptr %t924, i64 %t925, i1 false)
  br label %bb238
bb238:
  %t928 = load ptr, ptr %l0, !tbaa !29
  %t930 = getelementptr %"compiler/free:Free", ptr %t928, i32 0, i32 30
  %t931 = load i1, ptr %t930, !tbaa !21
  %t933 = xor i1 %t931, true
  br i1 %t933, label %bb239, label %bb240
bb239:
  call void @__olang_scope_close(ptr %s44)
  br label %bb262
bb240:
  br label %bb241
bb241:
  %t935 = load ptr, ptr %l0, !tbaa !29
  %t937 = getelementptr %"compiler/free:Free", ptr %t935, i32 0, i32 48
  %t938 = load i64, ptr %l70, !tbaa !24
  %t941 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t937, i64 %t938)
  store ptr %t941, ptr %l531
  br label %bb242
bb242:
  %t942 = load ptr, ptr %l531, !tbaa !29
  store ptr %t942, ptr %l71, !tbaa !29
  store i64 0, ptr %l72, !tbaa !24
  br label %bb243
bb243:
  store %olang.scope zeroinitializer, ptr %s47
  %t943 = load ptr, ptr %l71, !tbaa !29
  %t944 = load i64, ptr %l72, !tbaa !24
  %t947 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t943, i64 %t944)
  %t948 = extractvalue { i32, { i64, ptr } } %t947, 1
  %t949 = extractvalue { i32, { i64, ptr } } %t947, 0
  store i32 %t949, ptr %l536
  %t950 = icmp ne i32 %t949, 0
  br i1 %t950, label %bb245, label %ok.951
ok.951:
  store { i64, ptr } %t948, ptr %l535
  br label %bb244
bb244:
  %t952 = load { i64, ptr }, ptr %l535, !tbaa !27
  store { i64, ptr } %t952, ptr %l532, !tbaa !27
  br label %bb249
bb245:
  %t953 = load i32, ptr %l536, !tbaa !23
  %t954 = ashr i32 %t953, 16
  %t956 = icmp eq i32 %t954, 1
  br i1 %t956, label %bb246, label %bb247
bb246:
  br label %bb248
bb247:
  call void @__olang_check_failed(ptr @olang_loc_b00b407721719b6a_38625d6521f1b366)
  unreachable
bb248:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s47)
  br label %bb261
bb249:
  %t958 = load { i64, ptr }, ptr %l532, !tbaa !27
  store { i64, ptr } %t958, ptr %l73, !tbaa !27
  %t959 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t961 = extractvalue { i64, ptr } %t959, 0
  store i64 %t961, ptr %l74, !tbaa !24
  store i64 0, ptr %l75, !tbaa !24
  br label %bb250
bb250:
  store %olang.scope zeroinitializer, ptr %s48
  %t963 = load i64, ptr %l75, !tbaa !24
  %t964 = load i64, ptr %l74, !tbaa !24
  %t967 = icmp slt i64 %t963, %t964
  %t969 = xor i1 %t967, true
  br i1 %t969, label %bb251, label %bb252
bb251:
  call void @__olang_scope_close(ptr %s48)
  br label %bb259
bb252:
  br label %bb253
bb253:
  %t971 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t971, ptr %l545, !tbaa !27
  %t972 = load i64, ptr %l75, !tbaa !24
  %t974 = getelementptr { i64, ptr }, ptr %l545, i32 0, i32 1
  %t975 = load ptr, ptr %t974, !tbaa !27
  %t976 = getelementptr i64, ptr %t975, i64 %t972
  %t977 = load i64, ptr %t976, !tbaa !34
  store i64 %t977, ptr %l76, !tbaa !24
  %t979 = load i64, ptr %l76, !tbaa !24
  %t981 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t982 = load ptr, ptr %t981, !tbaa !27
  %t983 = getelementptr i1, ptr %t982, i64 %t979
  %t984 = load i1, ptr %t983, !tbaa !31
  %t986 = xor i1 %t984, true
  br i1 %t986, label %bb254, label %bb255
bb254:
  %t988 = load i64, ptr %l76, !tbaa !24
  %t990 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t991 = load ptr, ptr %t990, !tbaa !27
  %t992 = getelementptr i1, ptr %t991, i64 %t988
  store i1 true, ptr %t992, !tbaa !31
  %t993 = load i64, ptr %l76, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l63, i64 %t993)
  br label %bb256
bb255:
  br label %bb257
bb256:
  br label %bb257
bb257:
  call void @__olang_scope_close(ptr %s48)
  br label %bb258
bb258:
  %t996 = load i64, ptr %l75, !tbaa !24
  %t998 = add i64 %t996, 1
  store i64 %t998, ptr %l75, !tbaa !24
  br label %bb250
bb259:
  %t1000 = load i64, ptr %l72, !tbaa !24
  %t1001 = load i64, ptr %l74, !tbaa !24
  %t1004 = add i64 %t1000, %t1001
  store i64 %t1004, ptr %l72, !tbaa !24
  call void @__olang_scope_close(ptr %s47)
  br label %bb260
bb260:
  br label %bb243
bb261:
  call void @__olang_scope_close(ptr %s44)
  br label %bb262
bb262:
  %t1006 = load i64, ptr %l69, !tbaa !24
  %t1008 = add i64 %t1006, 1
  store i64 %t1008, ptr %l69, !tbaa !24
  br label %bb232
bb263:
  %t1010 = call i64 @std_2ftime_2eNow()
  store i64 %t1010, ptr %l561
  br label %bb264
bb264:
  %t1011 = load i64, ptr %l561, !tbaa !24
  store i64 %t1011, ptr %l77, !tbaa !24
  %t1012 = load ptr, ptr %l0, !tbaa !29
  %t1014 = getelementptr %"compiler/free:Free", ptr %t1012, i32 0, i32 68
  %t1015 = load i1, ptr %t1014, !tbaa !21
  br i1 %t1015, label %bb265, label %bb266
bb265:
  store %olang.scope zeroinitializer, ptr %s52
  %t1017 = load i64, ptr %l4, !tbaa !24
  store i64 %t1017, ptr %l564, !tbaa !24
  %t1018 = load ptr, ptr %l0, !tbaa !29
  %t1020 = getelementptr %"compiler/free:Free", ptr %t1018, i32 0, i32 8
  %t1022 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t1020)
  store i64 %t1022, ptr %l567
  br label %bb267
bb266:
  br label %bb274
bb267:
  %t1023 = load i64, ptr %l46, !tbaa !24
  %t1024 = load i64, ptr %l61, !tbaa !24
  %t1025 = load i64, ptr %l21, !tbaa !24
  %t1028 = sub i64 %t1024, %t1025
  %t1030 = sdiv i64 %t1028, 1000000
  %t1031 = load i64, ptr %l62, !tbaa !24
  %t1032 = load ptr, ptr %l0, !tbaa !29
  %t1034 = getelementptr %"compiler/free:Free", ptr %t1032, i32 0, i32 4
  %t1035 = load i64, ptr %t1034, !tbaa !24
  %t1036 = load i64, ptr %l77, !tbaa !24
  %t1037 = load i64, ptr %l61, !tbaa !24
  %t1040 = sub i64 %t1036, %t1037
  %t1042 = sdiv i64 %t1040, 1000000
  %t1043 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t1044 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t1045 = load i64, ptr %l564, !tbaa !24
  %t1046 = call i64 @__olang_fmt_i64(ptr null, i64 %t1045)
  %t1047 = add i64 %t1044, %t1046
  %t1048 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t1049 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t1050 = add i64 %t1047, %t1049
  %t1051 = load i64, ptr %l567, !tbaa !24
  %t1052 = call i64 @__olang_fmt_i64(ptr null, i64 %t1051)
  %t1053 = add i64 %t1050, %t1052
  %t1054 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t1055 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t1056 = add i64 %t1053, %t1055
  %t1058 = call i64 @__olang_fmt_i64(ptr null, i64 %t1023)
  %t1059 = add i64 %t1056, %t1058
  %t1060 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t1061 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t1062 = add i64 %t1059, %t1061
  %t1064 = call i64 @__olang_fmt_i64(ptr null, i64 %t1030)
  %t1065 = add i64 %t1062, %t1064
  %t1066 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t1067 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t1068 = add i64 %t1065, %t1067
  %t1070 = call i64 @__olang_fmt_i64(ptr null, i64 %t1031)
  %t1071 = add i64 %t1068, %t1070
  %t1072 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t1073 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t1074 = add i64 %t1071, %t1073
  %t1076 = call i64 @__olang_fmt_i64(ptr null, i64 %t1035)
  %t1077 = add i64 %t1074, %t1076
  %t1078 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t1079 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t1080 = add i64 %t1077, %t1079
  %t1082 = call i64 @__olang_fmt_i64(ptr null, i64 %t1042)
  %t1083 = add i64 %t1080, %t1082
  %t1084 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t1085 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t1086 = add i64 %t1083, %t1085
  %t1087 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1086)
  call void @olang_textcopy(ptr %t1087, ptr %t1043, i64 %t1044)
  %t1088 = getelementptr i8, ptr %t1087, i64 %t1044
  %t1089 = call i64 @__olang_fmt_i64(ptr %t1088, i64 %t1045)
  %t1090 = getelementptr i8, ptr %t1088, i64 %t1046
  call void @olang_textcopy(ptr %t1090, ptr %t1048, i64 %t1049)
  %t1091 = getelementptr i8, ptr %t1090, i64 %t1049
  %t1092 = call i64 @__olang_fmt_i64(ptr %t1091, i64 %t1051)
  %t1093 = getelementptr i8, ptr %t1091, i64 %t1052
  call void @olang_textcopy(ptr %t1093, ptr %t1054, i64 %t1055)
  %t1094 = getelementptr i8, ptr %t1093, i64 %t1055
  %t1095 = call i64 @__olang_fmt_i64(ptr %t1094, i64 %t1023)
  %t1096 = getelementptr i8, ptr %t1094, i64 %t1058
  call void @olang_textcopy(ptr %t1096, ptr %t1060, i64 %t1061)
  %t1097 = getelementptr i8, ptr %t1096, i64 %t1061
  %t1098 = call i64 @__olang_fmt_i64(ptr %t1097, i64 %t1030)
  %t1099 = getelementptr i8, ptr %t1097, i64 %t1064
  call void @olang_textcopy(ptr %t1099, ptr %t1066, i64 %t1067)
  %t1100 = getelementptr i8, ptr %t1099, i64 %t1067
  %t1101 = call i64 @__olang_fmt_i64(ptr %t1100, i64 %t1031)
  %t1102 = getelementptr i8, ptr %t1100, i64 %t1070
  call void @olang_textcopy(ptr %t1102, ptr %t1072, i64 %t1073)
  %t1103 = getelementptr i8, ptr %t1102, i64 %t1073
  %t1104 = call i64 @__olang_fmt_i64(ptr %t1103, i64 %t1035)
  %t1105 = getelementptr i8, ptr %t1103, i64 %t1076
  call void @olang_textcopy(ptr %t1105, ptr %t1078, i64 %t1079)
  %t1106 = getelementptr i8, ptr %t1105, i64 %t1079
  %t1107 = call i64 @__olang_fmt_i64(ptr %t1106, i64 %t1042)
  %t1108 = getelementptr i8, ptr %t1106, i64 %t1082
  call void @olang_textcopy(ptr %t1108, ptr %t1084, i64 %t1085)
  %t1109 = insertvalue { i64, ptr } undef, i64 %t1086, 0
  %t1110 = insertvalue { i64, ptr } %t1109, ptr %t1087, 1
  %t1112 = extractvalue { i64, ptr } %t1110, 0
  %t1113 = extractvalue { i64, ptr } %t1110, 1
  %t1114 = mul i64 %t1112, 1
  %t1115 = call ptr @__olang_scope_alloc(ptr %s52, i64 %t1114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1115, ptr %t1113, i64 %t1114, i1 false)
  %t1116 = insertvalue { i64, ptr } undef, i64 %t1112, 0
  %t1117 = insertvalue { i64, ptr } %t1116, ptr %t1115, 1
  %t1119 = call i32 @std_2fio_2ePrintErr(ptr %s52, { i64, ptr } %t1117)
  store i32 %t1119, ptr %l582
  %t1120 = icmp ne i32 %t1119, 0
  br i1 %t1120, label %bb269, label %ok.1121
ok.1121:
  br label %bb268
bb268:
  br label %bb273
bb269:
  %t1122 = load i32, ptr %l582, !tbaa !23
  %t1123 = ashr i32 %t1122, 16
  %t1125 = icmp eq i32 %t1123, 1
  br i1 %t1125, label %bb270, label %bb271
bb270:
  br label %bb272
bb271:
  call void @__olang_check_failed(ptr @olang_loc_58b1755dfcbf182b_23efb7b6d3d1a7c7)
  unreachable
bb272:
  call void @__olang_ert_req_clear()
  br label %bb273
bb273:
  call void @__olang_scope_close(ptr %s52)
  br label %bb274
bb274:
  store i64 0, ptr %l78, !tbaa !24
  %t1127 = load i64, ptr %l4, !tbaa !24
  store i64 %t1127, ptr %l79, !tbaa !24
  store i64 1, ptr %l80, !tbaa !24
  %t1129 = load i64, ptr %l79, !tbaa !24
  %t1130 = load i64, ptr %l78, !tbaa !24
  %t1133 = icmp sgt i64 %t1129, %t1130
  br i1 %t1133, label %bb275, label %bb276
bb275:
  %t1135 = load i64, ptr %l80, !tbaa !24
  %t1137 = icmp sgt i64 %t1135, 0
  br i1 %t1137, label %bb277, label %bb278
bb276:
  store i64 0, ptr %l589, !tbaa !24
  br label %bb280
bb277:
  %t1139 = load i64, ptr %l79, !tbaa !24
  %t1140 = load i64, ptr %l78, !tbaa !24
  %t1143 = sub i64 %t1139, %t1140
  %t1144 = load i64, ptr %l80, !tbaa !24
  %t1147 = add i64 %t1143, %t1144
  %t1149 = sub i64 %t1147, 1
  %t1150 = load i64, ptr %l80, !tbaa !24
  %t1153 = sdiv i64 %t1149, %t1150
  store i64 %t1153, ptr %l592, !tbaa !24
  br label %bb279
bb278:
  store i64 0, ptr %l592, !tbaa !24
  br label %bb279
bb279:
  %t1155 = load i64, ptr %l592, !tbaa !24
  store i64 %t1155, ptr %l589, !tbaa !24
  br label %bb280
bb280:
  %t1156 = load i64, ptr %l589, !tbaa !24
  store i64 %t1156, ptr %l81, !tbaa !24
  store i64 0, ptr %l82, !tbaa !24
  br label %bb281
bb281:
  store %olang.scope zeroinitializer, ptr %s56
  %t1157 = load i64, ptr %l82, !tbaa !24
  %t1158 = load i64, ptr %l81, !tbaa !24
  %t1161 = icmp slt i64 %t1157, %t1158
  %t1163 = xor i1 %t1161, true
  br i1 %t1163, label %bb282, label %bb283
bb282:
  call void @__olang_scope_close(ptr %s56)
  br label %bb318
bb283:
  br label %bb284
bb284:
  %t1165 = load i64, ptr %l78, !tbaa !24
  %t1166 = load i64, ptr %l82, !tbaa !24
  %t1167 = load i64, ptr %l80, !tbaa !24
  %t1170 = mul i64 %t1166, %t1167
  %t1173 = add i64 %t1165, %t1170
  store i64 %t1173, ptr %l83, !tbaa !24
  %t1175 = load ptr, ptr %l0, !tbaa !29
  %t1177 = getelementptr %"compiler/free:Free", ptr %t1175, i32 0, i32 24
  %t1178 = load i64, ptr %l83, !tbaa !24
  %t1181 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t1177, i64 %t1178)
  store ptr %t1181, ptr %l613
  br label %bb285
bb285:
  %t1182 = load ptr, ptr %l613, !tbaa !29
  %t1183 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t1182)
  store i64 %t1183, ptr %l614
  br label %bb286
bb286:
  %t1184 = load i64, ptr %l614, !tbaa !24
  %t1185 = icmp sgt i64 %t1184, 0
  br i1 %t1185, label %bb287, label %bb288
bb287:
  store i1 true, ptr %l616, !tbaa !21
  br label %bb290
bb288:
  %t1187 = load ptr, ptr %l0, !tbaa !29
  %t1189 = getelementptr %"compiler/free:Free", ptr %t1187, i32 0, i32 25
  %t1190 = load i64, ptr %l83, !tbaa !24
  %t1193 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1189, i64 %t1190)
  store i1 %t1193, ptr %l620
  br label %bb289
bb289:
  %t1194 = load i1, ptr %l620, !tbaa !21
  store i1 %t1194, ptr %l616, !tbaa !21
  br label %bb290
bb290:
  %t1195 = load i1, ptr %l616, !tbaa !21
  br i1 %t1195, label %bb291, label %bb292
bb291:
  %t1196 = load ptr, ptr %l0, !tbaa !29
  %t1197 = load i64, ptr %l83, !tbaa !24
  %t1200 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eimplicit(ptr %v0, ptr %t1196, i64 %t1197)
  store i1 %t1200, ptr %l623
  br label %bb293
bb292:
  br label %bb316
bb293:
  %t1201 = load i1, ptr %l623, !tbaa !21
  br i1 %t1201, label %bb294, label %bb295
bb294:
  %t1202 = load ptr, ptr %l0, !tbaa !29
  %t1204 = getelementptr %"compiler/free:Free", ptr %t1202, i32 0, i32 25
  %t1205 = load i64, ptr %l83, !tbaa !24
  %t1208 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1204, i64 %t1205)
  store i1 %t1208, ptr %l627
  br label %bb296
bb295:
  br label %bb315
bb296:
  %t1209 = load i1, ptr %l627, !tbaa !21
  br i1 %t1209, label %bb297, label %bb298
bb297:
  %t1210 = load ptr, ptr %l0, !tbaa !29
  %t1212 = getelementptr %"compiler/free:Free", ptr %t1210, i32 0, i32 32
  store i1 true, ptr %t1212, !tbaa !21
  br label %bb301
bb298:
  %t1213 = load ptr, ptr %l0, !tbaa !29
  %t1215 = getelementptr %"compiler/free:Free", ptr %t1213, i32 0, i32 33
  store ptr %t1215, ptr %l630, !tbaa !29
  %t1216 = load ptr, ptr %l0, !tbaa !29
  %t1218 = getelementptr %"compiler/free:Free", ptr %t1216, i32 0, i32 24
  %t1219 = load i64, ptr %l83, !tbaa !24
  %t1222 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t1218, i64 %t1219)
  store ptr %t1222, ptr %l634
  br label %bb299
bb299:
  %t1223 = load ptr, ptr %l630, !tbaa !29
  %t1224 = load ptr, ptr %l634, !tbaa !29
  %t1225 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v0, ptr %t1223, ptr %t1224)
  store i1 %t1225, ptr %l635
  br label %bb300
bb300:
  br label %bb301
bb301:
  %t1226 = load ptr, ptr %l0, !tbaa !29
  %t1228 = getelementptr %"compiler/free:Free", ptr %t1226, i32 0, i32 68
  %t1229 = load i1, ptr %t1228, !tbaa !21
  br i1 %t1229, label %bb302, label %bb303
bb302:
  store %olang.scope zeroinitializer, ptr %s61
  %t1231 = load ptr, ptr %l0, !tbaa !29
  %t1232 = load i64, ptr %l83, !tbaa !24
  %t1235 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s61, ptr %t1231, i64 %t1232)
  store { i64, ptr } %t1235, ptr %l640
  br label %bb304
bb303:
  br label %bb314
bb304:
  %t1236 = load ptr, ptr %l0, !tbaa !29
  %t1238 = getelementptr %"compiler/free:Free", ptr %t1236, i32 0, i32 0
  %t1239 = load ptr, ptr %t1238, !tbaa !29
  %t1241 = getelementptr %"compiler/generic:Program", ptr %t1239, i32 0, i32 0
  %t1242 = load ptr, ptr %t1241, !tbaa !29
  %t1244 = getelementptr %"compiler/load:Loader", ptr %t1242, i32 0, i32 4
  %t1245 = load ptr, ptr %t1244, !tbaa !29
  store ptr %t1245, ptr %l644, !tbaa !29
  %t1246 = load ptr, ptr %l0, !tbaa !29
  %t1248 = getelementptr %"compiler/free:Free", ptr %t1246, i32 0, i32 1
  %t1249 = load i64, ptr %l83, !tbaa !24
  %t1252 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t1248, i64 %t1249)
  store ptr %t1252, ptr %l648
  br label %bb305
bb305:
  %t1253 = load ptr, ptr %l648, !tbaa !29
  %t1255 = getelementptr %"compiler/typed:Body", ptr %t1253, i32 0, i32 3
  %t1256 = load i64, ptr %t1255, !tbaa !24
  store i64 %t1256, ptr %l650, !tbaa !24
  %t1257 = load ptr, ptr %l0, !tbaa !29
  %t1259 = getelementptr %"compiler/free:Free", ptr %t1257, i32 0, i32 1
  %t1260 = load i64, ptr %l83, !tbaa !24
  %t1263 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t1259, i64 %t1260)
  store ptr %t1263, ptr %l654
  br label %bb306
bb306:
  %t1264 = load ptr, ptr %l654, !tbaa !29
  %t1266 = getelementptr %"compiler/typed:Body", ptr %t1264, i32 0, i32 4
  %t1267 = getelementptr %"compiler/source:Span", ptr %t1266, i32 0, i32 0
  %t1268 = load i32, ptr %t1267, !tbaa !23
  %t1270 = sext i32 %t1268 to i64
  %t1271 = load ptr, ptr %l644, !tbaa !29
  %t1272 = load i64, ptr %l650, !tbaa !24
  %t1274 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s61, ptr %t1271, i64 %t1272, i64 %t1270)
  store { i64, ptr } %t1274, ptr %l658
  br label %bb307
bb307:
  %t1275 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t1276 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t1277 = load { i64, ptr }, ptr %l640, !tbaa !27
  %t1278 = extractvalue { i64, ptr } %t1277, 1
  %t1279 = extractvalue { i64, ptr } %t1277, 0
  %t1280 = add i64 %t1276, %t1279
  %t1281 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t1282 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t1283 = add i64 %t1280, %t1282
  %t1284 = load { i64, ptr }, ptr %l658, !tbaa !27
  %t1285 = extractvalue { i64, ptr } %t1284, 1
  %t1286 = extractvalue { i64, ptr } %t1284, 0
  %t1287 = add i64 %t1283, %t1286
  %t1288 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t1289 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t1290 = add i64 %t1287, %t1289
  %t1291 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1290)
  call void @olang_textcopy(ptr %t1291, ptr %t1275, i64 %t1276)
  %t1292 = getelementptr i8, ptr %t1291, i64 %t1276
  call void @olang_textcopy(ptr %t1292, ptr %t1278, i64 %t1279)
  %t1293 = getelementptr i8, ptr %t1292, i64 %t1279
  call void @olang_textcopy(ptr %t1293, ptr %t1281, i64 %t1282)
  %t1294 = getelementptr i8, ptr %t1293, i64 %t1282
  call void @olang_textcopy(ptr %t1294, ptr %t1285, i64 %t1286)
  %t1295 = getelementptr i8, ptr %t1294, i64 %t1286
  call void @olang_textcopy(ptr %t1295, ptr %t1288, i64 %t1289)
  %t1296 = insertvalue { i64, ptr } undef, i64 %t1290, 0
  %t1297 = insertvalue { i64, ptr } %t1296, ptr %t1291, 1
  %t1299 = extractvalue { i64, ptr } %t1297, 0
  %t1300 = extractvalue { i64, ptr } %t1297, 1
  %t1301 = mul i64 %t1299, 1
  %t1302 = call ptr @__olang_scope_alloc(ptr %s61, i64 %t1301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1302, ptr %t1300, i64 %t1301, i1 false)
  %t1303 = insertvalue { i64, ptr } undef, i64 %t1299, 0
  %t1304 = insertvalue { i64, ptr } %t1303, ptr %t1302, 1
  %t1306 = call i32 @std_2fio_2ePrintErr(ptr %s61, { i64, ptr } %t1304)
  store i32 %t1306, ptr %l661
  %t1307 = icmp ne i32 %t1306, 0
  br i1 %t1307, label %bb309, label %ok.1308
ok.1308:
  br label %bb308
bb308:
  br label %bb313
bb309:
  %t1309 = load i32, ptr %l661, !tbaa !23
  %t1310 = ashr i32 %t1309, 16
  %t1312 = icmp eq i32 %t1310, 1
  br i1 %t1312, label %bb310, label %bb311
bb310:
  br label %bb312
bb311:
  call void @__olang_check_failed(ptr @olang_loc_ad17e1d275f06ba1_d55ab4a9088c1b55)
  unreachable
bb312:
  call void @__olang_ert_req_clear()
  br label %bb313
bb313:
  call void @__olang_scope_close(ptr %s61)
  br label %bb314
bb314:
  br label %bb315
bb315:
  br label %bb316
bb316:
  call void @__olang_scope_close(ptr %s56)
  br label %bb317
bb317:
  %t1314 = load i64, ptr %l82, !tbaa !24
  %t1316 = add i64 %t1314, 1
  store i64 %t1316, ptr %l82, !tbaa !24
  br label %bb281
bb318:
  %t1318 = call i64 @std_2ftime_2eNow()
  store i64 %t1318, ptr %l666
  br label %bb319
bb319:
  %t1319 = load i64, ptr %l666, !tbaa !24
  store i64 %t1319, ptr %l84, !tbaa !24
  store i64 0, ptr %l85, !tbaa !24
  %t1320 = load i64, ptr %l4, !tbaa !24
  store i64 %t1320, ptr %l86, !tbaa !24
  store i64 1, ptr %l87, !tbaa !24
  %t1322 = load i64, ptr %l86, !tbaa !24
  %t1323 = load i64, ptr %l85, !tbaa !24
  %t1326 = icmp sgt i64 %t1322, %t1323
  br i1 %t1326, label %bb320, label %bb321
bb320:
  %t1328 = load i64, ptr %l87, !tbaa !24
  %t1330 = icmp sgt i64 %t1328, 0
  br i1 %t1330, label %bb322, label %bb323
bb321:
  store i64 0, ptr %l671, !tbaa !24
  br label %bb325
bb322:
  %t1332 = load i64, ptr %l86, !tbaa !24
  %t1333 = load i64, ptr %l85, !tbaa !24
  %t1336 = sub i64 %t1332, %t1333
  %t1337 = load i64, ptr %l87, !tbaa !24
  %t1340 = add i64 %t1336, %t1337
  %t1342 = sub i64 %t1340, 1
  %t1343 = load i64, ptr %l87, !tbaa !24
  %t1346 = sdiv i64 %t1342, %t1343
  store i64 %t1346, ptr %l674, !tbaa !24
  br label %bb324
bb323:
  store i64 0, ptr %l674, !tbaa !24
  br label %bb324
bb324:
  %t1348 = load i64, ptr %l674, !tbaa !24
  store i64 %t1348, ptr %l671, !tbaa !24
  br label %bb325
bb325:
  %t1349 = load i64, ptr %l671, !tbaa !24
  store i64 %t1349, ptr %l88, !tbaa !24
  store i64 0, ptr %l89, !tbaa !24
  br label %bb326
bb326:
  store %olang.scope zeroinitializer, ptr %s66
  %t1350 = load i64, ptr %l89, !tbaa !24
  %t1351 = load i64, ptr %l88, !tbaa !24
  %t1354 = icmp slt i64 %t1350, %t1351
  %t1356 = xor i1 %t1354, true
  br i1 %t1356, label %bb327, label %bb328
bb327:
  call void @__olang_scope_close(ptr %s66)
  br label %bb332
bb328:
  br label %bb329
bb329:
  %t1358 = load i64, ptr %l85, !tbaa !24
  %t1359 = load i64, ptr %l89, !tbaa !24
  %t1360 = load i64, ptr %l87, !tbaa !24
  %t1363 = mul i64 %t1359, %t1360
  %t1366 = add i64 %t1358, %t1363
  %t1368 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewalk(ptr %v0, ptr %t1368, i64 %t1366, i1 true)
  br label %bb330
bb330:
  call void @__olang_scope_close(ptr %s66)
  br label %bb331
bb331:
  %t1372 = load i64, ptr %l89, !tbaa !24
  %t1374 = add i64 %t1372, 1
  store i64 %t1374, ptr %l89, !tbaa !24
  br label %bb326
bb332:
  %t1376 = call i64 @std_2ftime_2eNow()
  store i64 %t1376, ptr %l696
  br label %bb333
bb333:
  %t1377 = load i64, ptr %l696, !tbaa !24
  store i64 %t1377, ptr %l91, !tbaa !24
  %t1378 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edecide(ptr %v0, ptr %t1378)
  br label %bb334
bb334:
  %t1380 = load ptr, ptr %l0, !tbaa !29
  %t1382 = getelementptr %"compiler/free:Free", ptr %t1380, i32 0, i32 67
  store i1 true, ptr %t1382, !tbaa !21
  %t1383 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewritePlans(ptr %v0, ptr %t1383)
  br label %bb335
bb335:
  %t1385 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestroyErrors(ptr %v0, ptr %t1385)
  br label %bb336
bb336:
  %t1387 = call i64 @std_2ftime_2eNow()
  store i64 %t1387, ptr %l701
  br label %bb337
bb337:
  %t1388 = load i64, ptr %l701, !tbaa !24
  store i64 %t1388, ptr %l92, !tbaa !24
  %t1389 = load ptr, ptr %l0, !tbaa !29
  %t1391 = getelementptr %"compiler/free:Free", ptr %t1389, i32 0, i32 68
  %t1392 = load i1, ptr %t1391, !tbaa !21
  br i1 %t1392, label %bb338, label %bb339
bb338:
  store %olang.scope zeroinitializer, ptr %s68
  %t1394 = load i64, ptr %l91, !tbaa !24
  %t1395 = load i64, ptr %l84, !tbaa !24
  %t1398 = sub i64 %t1394, %t1395
  %t1400 = sdiv i64 %t1398, 1000000
  store i64 %t1400, ptr %l707, !tbaa !24
  %t1401 = load ptr, ptr %l0, !tbaa !29
  %t1403 = getelementptr %"compiler/free:Free", ptr %t1401, i32 0, i32 35
  %t1405 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t1403)
  store i64 %t1405, ptr %l710
  br label %bb340
bb339:
  br label %bb348
bb340:
  %t1406 = load ptr, ptr %l0, !tbaa !29
  %t1408 = getelementptr %"compiler/free:Free", ptr %t1406, i32 0, i32 34
  %t1410 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t1408)
  store i64 %t1410, ptr %l713
  br label %bb341
bb341:
  %t1411 = load i64, ptr %l92, !tbaa !24
  %t1412 = load i64, ptr %l91, !tbaa !24
  %t1415 = sub i64 %t1411, %t1412
  %t1417 = sdiv i64 %t1415, 1000000
  %t1418 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t1419 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t1420 = load i64, ptr %l707, !tbaa !24
  %t1421 = call i64 @__olang_fmt_i64(ptr null, i64 %t1420)
  %t1422 = add i64 %t1419, %t1421
  %t1423 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t1424 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t1425 = add i64 %t1422, %t1424
  %t1426 = load i64, ptr %l710, !tbaa !24
  %t1427 = call i64 @__olang_fmt_i64(ptr null, i64 %t1426)
  %t1428 = add i64 %t1425, %t1427
  %t1429 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t1430 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t1431 = add i64 %t1428, %t1430
  %t1432 = load i64, ptr %l713, !tbaa !24
  %t1433 = call i64 @__olang_fmt_i64(ptr null, i64 %t1432)
  %t1434 = add i64 %t1431, %t1433
  %t1435 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t1436 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t1437 = add i64 %t1434, %t1436
  %t1439 = call i64 @__olang_fmt_i64(ptr null, i64 %t1417)
  %t1440 = add i64 %t1437, %t1439
  %t1441 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t1442 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t1443 = add i64 %t1440, %t1442
  %t1444 = call ptr @__olang_scope_alloc(ptr %s68, i64 %t1443)
  call void @olang_textcopy(ptr %t1444, ptr %t1418, i64 %t1419)
  %t1445 = getelementptr i8, ptr %t1444, i64 %t1419
  %t1446 = call i64 @__olang_fmt_i64(ptr %t1445, i64 %t1420)
  %t1447 = getelementptr i8, ptr %t1445, i64 %t1421
  call void @olang_textcopy(ptr %t1447, ptr %t1423, i64 %t1424)
  %t1448 = getelementptr i8, ptr %t1447, i64 %t1424
  %t1449 = call i64 @__olang_fmt_i64(ptr %t1448, i64 %t1426)
  %t1450 = getelementptr i8, ptr %t1448, i64 %t1427
  call void @olang_textcopy(ptr %t1450, ptr %t1429, i64 %t1430)
  %t1451 = getelementptr i8, ptr %t1450, i64 %t1430
  %t1452 = call i64 @__olang_fmt_i64(ptr %t1451, i64 %t1432)
  %t1453 = getelementptr i8, ptr %t1451, i64 %t1433
  call void @olang_textcopy(ptr %t1453, ptr %t1435, i64 %t1436)
  %t1454 = getelementptr i8, ptr %t1453, i64 %t1436
  %t1455 = call i64 @__olang_fmt_i64(ptr %t1454, i64 %t1417)
  %t1456 = getelementptr i8, ptr %t1454, i64 %t1439
  call void @olang_textcopy(ptr %t1456, ptr %t1441, i64 %t1442)
  %t1457 = insertvalue { i64, ptr } undef, i64 %t1443, 0
  %t1458 = insertvalue { i64, ptr } %t1457, ptr %t1444, 1
  %t1460 = extractvalue { i64, ptr } %t1458, 0
  %t1461 = extractvalue { i64, ptr } %t1458, 1
  %t1462 = mul i64 %t1460, 1
  %t1463 = call ptr @__olang_scope_alloc(ptr %s68, i64 %t1462)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1463, ptr %t1461, i64 %t1462, i1 false)
  %t1464 = insertvalue { i64, ptr } undef, i64 %t1460, 0
  %t1465 = insertvalue { i64, ptr } %t1464, ptr %t1463, 1
  %t1467 = call i32 @std_2fio_2ePrintErr(ptr %s68, { i64, ptr } %t1465)
  store i32 %t1467, ptr %l720
  %t1468 = icmp ne i32 %t1467, 0
  br i1 %t1468, label %bb343, label %ok.1469
ok.1469:
  br label %bb342
bb342:
  br label %bb347
bb343:
  %t1470 = load i32, ptr %l720, !tbaa !23
  %t1471 = ashr i32 %t1470, 16
  %t1473 = icmp eq i32 %t1471, 1
  br i1 %t1473, label %bb344, label %bb345
bb344:
  br label %bb346
bb345:
  call void @__olang_check_failed(ptr @olang_loc_6198ef54548c7110_909a06f0dca20164)
  unreachable
bb346:
  call void @__olang_ert_req_clear()
  br label %bb347
bb347:
  call void @__olang_scope_close(ptr %s68)
  br label %bb348
bb348:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFrees(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 67
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sge i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 17
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l11
  br label %bb6
bb5:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 17
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t24, i64 %t25)
  store i1 %t28, ptr %l17
  br label %bb10
bb9:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb11
bb10:
  %t29 = load i1, ptr %l17, !tbaa !21
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l13, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsHandle(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 10
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 10
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t18, i64 %t19)
  store i1 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l10, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l3, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l6, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 -1, ptr %l6, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_44f49f80b055cb88_68fe70e2113a02d4)
  unreachable
bb11:
  %t25 = load i64, ptr %l6, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %a0, ptr %t24)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l63 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t2 = load ptr, ptr %l14, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l14, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l15, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l15, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  br label %bb7
bb7:
  br label %bb89
bb8:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t31 = load ptr, ptr %l26, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l26, !tbaa !29
  %t35 = load i64, ptr %t34
  %t37 = icmp eq i64 %t35, 0
  store i1 %t37, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l27, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  br label %bb14
bb14:
  br label %bb89
bb15:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l34, !tbaa !29
  %t54 = load i64, ptr %t53
  %t56 = icmp eq i64 %t54, 2
  store i1 %t56, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l35, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr }, ptr %t60, i32 0, i32 0
  %t62 = load %"compiler/source:Span", ptr %t61
  store %"compiler/source:Span" %t62, ptr %l5
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr }, ptr %t66, i32 0, i32 1
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l6, !tbaa !29
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t70, ptr %t71)
  br label %bb21
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l5
  %t76 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindDestroy(ptr %v0, ptr %v1, ptr %t74, %"compiler/source:Span" %t75, ptr %t76)
  br label %bb22
bb22:
  br label %bb89
bb23:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t85 = load i64, ptr %t84
  %t87 = icmp eq i64 %t85, 3
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l48, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  br label %bb38
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l7, !tbaa !29
  %t98 = getelementptr %"compiler/typed:If", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t95, ptr %t99)
  br label %bb29
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l7, !tbaa !29
  %t105 = getelementptr %"compiler/typed:If", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t102, ptr %t106)
  br label %bb30
bb30:
  %t109 = load ptr, ptr %l7, !tbaa !29
  %t111 = getelementptr %"compiler/typed:If", ptr %t109, i32 0, i32 2
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = icmp eq ptr %t112, null
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb31, label %bb32
bb31:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l63, !tbaa !29
  %t119 = load ptr, ptr %l7, !tbaa !29
  %t121 = getelementptr %"compiler/typed:If", ptr %t119, i32 0, i32 2
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  br i1 %t124, label %bb33, label %bb34
bb32:
  br label %bb37
bb33:
  call void @__olang_check_failed(ptr @olang_loc_f0ef9f3a8cd9f24a_5f2afb921a19c616)
  unreachable
bb34:
  br label %bb35
bb35:
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t128 = getelementptr %"compiler/typed:If", ptr %t126, i32 0, i32 2
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load ptr, ptr %l63, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t130, ptr %t129)
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb89
bb38:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t133 = load ptr, ptr %l69, !tbaa !29
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %bb39, label %bb40
bb39:
  %t136 = load ptr, ptr %l69, !tbaa !29
  %t137 = load i64, ptr %t136
  %t139 = icmp eq i64 %t137, 4
  store i1 %t139, ptr %l70, !tbaa !21
  br label %bb40
bb40:
  %t140 = load i1, ptr %l70, !tbaa !21
  br i1 %t140, label %bb41, label %bb42
bb41:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [3 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t143, i32 0, i32 1
  %t145 = load ptr, ptr %t144
  store ptr %t145, ptr %l8, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t149, i32 0, i32 2
  %t151 = load ptr, ptr %t150
  store ptr %t151, ptr %l9, !tbaa !29
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t153, ptr %t154)
  br label %bb44
bb44:
  %t157 = load ptr, ptr %l9, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb45, label %bb46
bb45:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb89
bb49:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t168 = load ptr, ptr %l84, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb50, label %bb51
bb50:
  %t171 = load ptr, ptr %l84, !tbaa !29
  %t172 = load i64, ptr %t171
  %t174 = icmp eq i64 %t172, 6
  store i1 %t174, ptr %l85, !tbaa !21
  br label %bb51
bb51:
  %t175 = load i1, ptr %l85, !tbaa !21
  br i1 %t175, label %bb52, label %bb53
bb52:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l10, !tbaa !29
  br label %bb58
bb53:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t183 = load ptr, ptr %l90, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb54, label %bb55
bb54:
  %t186 = load ptr, ptr %l90, !tbaa !29
  %t187 = load i64, ptr %t186
  %t189 = icmp eq i64 %t187, 16
  store i1 %t189, ptr %l91, !tbaa !21
  br label %bb55
bb55:
  %t190 = load i1, ptr %l91, !tbaa !21
  br i1 %t190, label %bb56, label %bb57
bb56:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", ptr }, ptr %t193, i32 0, i32 1
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l10, !tbaa !29
  br label %bb58
bb57:
  br label %bb63
bb58:
  %t197 = load ptr, ptr %l10, !tbaa !29
  %t199 = icmp eq ptr %t197, null
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb59, label %bb60
bb59:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t203, ptr %t204)
  br label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb62
bb62:
  br label %bb89
bb63:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t208 = load ptr, ptr %l101, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb64, label %bb65
bb64:
  %t211 = load ptr, ptr %l101, !tbaa !29
  %t212 = load i64, ptr %t211
  %t214 = icmp eq i64 %t212, 11
  store i1 %t214, ptr %l102, !tbaa !21
  br label %bb65
bb65:
  %t215 = load i1, ptr %l102, !tbaa !21
  br i1 %t215, label %bb66, label %bb67
bb66:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [3 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr }, ptr %t218, i32 0, i32 1
  %t220 = load ptr, ptr %t219
  store ptr %t220, ptr %l11, !tbaa !29
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t222, ptr %t223)
  br label %bb69
bb69:
  br label %bb89
bb70:
  %t226 = load ptr, ptr %l1, !tbaa !29
  store ptr %t226, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t227 = load ptr, ptr %l109, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb71, label %bb72
bb71:
  %t230 = load ptr, ptr %l109, !tbaa !29
  %t231 = load i64, ptr %t230
  %t233 = icmp eq i64 %t231, 12
  store i1 %t233, ptr %l110, !tbaa !21
  br label %bb72
bb72:
  %t234 = load i1, ptr %l110, !tbaa !21
  br i1 %t234, label %bb73, label %bb74
bb73:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 1
  %t238 = getelementptr { %"compiler/source:Span", ptr }, ptr %t237, i32 0, i32 1
  %t239 = load ptr, ptr %t238
  store ptr %t239, ptr %l12, !tbaa !29
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t241, ptr %t242)
  br label %bb76
bb76:
  br label %bb89
bb77:
  %t245 = load ptr, ptr %l1, !tbaa !29
  store ptr %t245, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t246 = load ptr, ptr %l117, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb78, label %bb79
bb78:
  %t249 = load ptr, ptr %l117, !tbaa !29
  %t250 = load i64, ptr %t249
  %t252 = icmp eq i64 %t250, 13
  store i1 %t252, ptr %l118, !tbaa !21
  br label %bb79
bb79:
  %t253 = load i1, ptr %l118, !tbaa !21
  br i1 %t253, label %bb80, label %bb81
bb80:
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [3 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", ptr }, ptr %t256, i32 0, i32 1
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l13, !tbaa !29
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l13, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Join", ptr %t261, i32 0, i32 0
  %t264 = load ptr, ptr %t263, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t260, ptr %t264)
  br label %bb83
bb83:
  br label %bb89
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_1befe4f0760966d8_ea99a8b72a88b024)
  unreachable
bb89:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisContents(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/free:letGo"
  %l11 = alloca i1
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %l28 = alloca { i64, ptr }
  %l34 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 37
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l11
  br label %bb1
bb1:
  %t8 = load i1, ptr %l11, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/free:Free", ptr %t10, i32 0, i32 35
  store ptr %t12, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eRunFrom_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t14, i64 %t15)
  %t19 = extractvalue { i32, { i64, ptr } } %t18, 1
  %t20 = extractvalue { i32, { i64, ptr } } %t18, 0
  store i32 %t20, ptr %l19
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb7, label %ok.22
ok.22:
  store { i64, ptr } %t19, ptr %l18
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  br label %bb11
bb7:
  %t24 = load i32, ptr %l19, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_382d5ddd4082031c_8c872e693a10d18)
  unreachable
bb10:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb11:
  %t29 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t29, ptr %l4, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb14:
  br label %bb15
bb15:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t42, ptr %l28, !tbaa !27
  %t43 = load i64, ptr %l6, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr %"compiler/free:letGo", ptr %t46, i64 %t43
  %t48 = load %"compiler/free:letGo", ptr %t47
  store %"compiler/free:letGo" %t48, ptr %l7
  %t50 = getelementptr %"compiler/free:letGo", ptr %l7, i32 0, i32 0
  %t51 = load i64, ptr %t50, !tbaa !24
  %t52 = load i64, ptr %l1, !tbaa !24
  %t55 = icmp eq i64 %t51, %t52
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t57 = getelementptr %"compiler/free:letGo", ptr %l7, i32 0, i32 5
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = load i64, ptr @G_2ecompiler_2ffree_2eLVacate, !tbaa !24
  %t62 = icmp eq i64 %t58, %t59
  store i1 %t62, ptr %l34, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t64 = load i1, ptr %l34, !tbaa !21
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 18
  %t68 = getelementptr %"compiler/free:letGo", ptr %l7, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  %t72 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t67, i64 %t69)
  store i1 %t72, ptr %l42
  br label %bb21
bb20:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb22
bb21:
  %t73 = load i1, ptr %l42, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l38, !tbaa !21
  br label %bb22
bb22:
  %t76 = load i1, ptr %l38, !tbaa !21
  br i1 %t76, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb12
bb27:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = add i64 %t82, %t83
  store i64 %t86, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  br label %bb5
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 9
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 9
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp eq i64 %t23, -2
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l10, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca i1
  %l75 = alloca i1
  %l79 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l94 = alloca { i64, ptr }
  %l99 = alloca i1
  %l107 = alloca i1
  %l108 = alloca ptr
  %l114 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l129 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l133 = alloca i1
  %l140 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca i1
  %l163 = alloca i1
  %l165 = alloca i1
  %l169 = alloca ptr
  %l173 = alloca i1
  %l177 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca i1
  %l196 = alloca { i64, ptr }
  %l201 = alloca i1
  %l206 = alloca ptr
  %l207 = alloca i1
  %l219 = alloca { i64, ptr }
  %l224 = alloca i1
  %l229 = alloca ptr
  %l230 = alloca i1
  %l237 = alloca i1
  %l238 = alloca ptr
  %l239 = alloca i1
  %l247 = alloca i1
  %l248 = alloca i1
  %l253 = alloca i1
  %l254 = alloca ptr
  %l260 = alloca i1
  %l261 = alloca i1
  %l265 = alloca i1
  %l266 = alloca ptr
  %l267 = alloca i1
  %l276 = alloca i1
  %l277 = alloca ptr
  %l283 = alloca i1
  %l293 = alloca { i64, ptr }
  %l309 = alloca { i64, ptr }
  %l314 = alloca i1
  %l321 = alloca ptr
  %l322 = alloca i1
  %l327 = alloca i1
  %l328 = alloca ptr
  %l329 = alloca i1
  %l332 = alloca ptr
  %l333 = alloca i1
  %l344 = alloca i1
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t2 = load ptr, ptr %l42, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l42, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l43, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l43, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t11 = load ptr, ptr %l46, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l46, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l47, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l47, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t20 = load ptr, ptr %l50, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l50, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 2
  store i1 %t26, ptr %l51, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l51, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t29 = load ptr, ptr %l54, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load ptr, ptr %l54, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 3
  store i1 %t35, ptr %l55, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l55, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t39 = load ptr, ptr %l59, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb19, label %bb20
bb19:
  %t42 = load ptr, ptr %l59, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 4
  store i1 %t45, ptr %l60, !tbaa !21
  br label %bb20
bb20:
  %t46 = load i1, ptr %l60, !tbaa !21
  br i1 %t46, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %rv
  br label %ret
bb24:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t49 = load ptr, ptr %l64, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb25, label %bb26
bb25:
  %t52 = load ptr, ptr %l64, !tbaa !29
  %t53 = load i64, ptr %t52
  %t55 = icmp eq i64 %t53, 5
  store i1 %t55, ptr %l65, !tbaa !21
  br label %bb26
bb26:
  %t56 = load i1, ptr %l65, !tbaa !21
  br i1 %t56, label %bb27, label %bb28
bb27:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l2, !tbaa !23
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l3, !tbaa !29
  br label %bb29
bb28:
  br label %bb35
bb29:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t73, ptr %l74
  br label %bb30
bb30:
  %t74 = load i1, ptr %l74, !tbaa !21
  br i1 %t74, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb34
bb32:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Promote", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t82 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t75, ptr %t79)
  store i1 %t82, ptr %l79
  br label %bb33
bb33:
  %t83 = load i1, ptr %l79, !tbaa !21
  store i1 %t83, ptr %l75, !tbaa !21
  br label %bb34
bb34:
  %t84 = load i1, ptr %l75, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb35:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t86 = load ptr, ptr %l80, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb36, label %bb37
bb36:
  %t89 = load ptr, ptr %l80, !tbaa !29
  %t90 = load i64, ptr %t89
  %t92 = icmp eq i64 %t90, 7
  store i1 %t92, ptr %l81, !tbaa !21
  br label %bb37
bb37:
  %t93 = load i1, ptr %l81, !tbaa !21
  br i1 %t93, label %bb38, label %bb39
bb38:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb58
bb40:
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Make", ptr %t100, i32 0, i32 2
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %l7, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t109 = load i64, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb43:
  br label %bb44
bb44:
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t117, ptr %l94, !tbaa !27
  %t118 = load i64, ptr %l6, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr ptr, ptr %t121, i64 %t118
  %t123 = load ptr, ptr %t122, !tbaa !39
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t129 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t125, ptr %t123)
  store i1 %t129, ptr %l99
  br label %bb45
bb45:
  %t130 = load i1, ptr %l99, !tbaa !21
  br i1 %t130, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s6)
  store i1 true, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  %t132 = load i64, ptr %l6, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l6, !tbaa !24
  br label %bb41
bb50:
  %t136 = load ptr, ptr %l4, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Make", ptr %t136, i32 0, i32 3
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb51, label %bb52
bb51:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l108, !tbaa !29
  %t146 = load ptr, ptr %l4, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Make", ptr %t146, i32 0, i32 3
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  br i1 %t151, label %bb53, label %bb54
bb52:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb57
bb53:
  call void @__olang_check_failed(ptr @olang_loc_ec4c329f8a2f93df_8cb0fdf9b7b252db)
  unreachable
bb54:
  br label %bb55
bb55:
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Make", ptr %t153, i32 0, i32 3
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t157 = load ptr, ptr %l108, !tbaa !29
  %t159 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t157, ptr %t156)
  store i1 %t159, ptr %l114
  br label %bb56
bb56:
  %t160 = load i1, ptr %l114, !tbaa !21
  store i1 %t160, ptr %l107, !tbaa !21
  br label %bb57
bb57:
  %t161 = load i1, ptr %l107, !tbaa !21
  store i1 %t161, ptr %rv
  br label %ret
bb58:
  %t162 = load ptr, ptr %l1, !tbaa !29
  store ptr %t162, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t163 = load ptr, ptr %l115, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb59, label %bb60
bb59:
  %t166 = load ptr, ptr %l115, !tbaa !29
  %t167 = load i64, ptr %t166
  %t169 = icmp eq i64 %t167, 16
  store i1 %t169, ptr %l116, !tbaa !21
  br label %bb60
bb60:
  %t170 = load i1, ptr %l116, !tbaa !21
  br i1 %t170, label %bb61, label %bb62
bb61:
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t173, i32 0, i32 2
  %t175 = load ptr, ptr %t174
  store ptr %t175, ptr %l9, !tbaa !29
  br label %bb63
bb62:
  br label %bb85
bb63:
  %t177 = load ptr, ptr %l9, !tbaa !29
  %t179 = getelementptr %"compiler/typed:Text", ptr %t177, i32 0, i32 0
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  store { i64, ptr } %t180, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  store i64 %t184, ptr %l12, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s11
  %t186 = load i64, ptr %l11, !tbaa !24
  %t187 = load i64, ptr %l12, !tbaa !24
  %t190 = icmp slt i64 %t186, %t187
  %t192 = xor i1 %t190, true
  br i1 %t192, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s11)
  br label %bb84
bb66:
  br label %bb67
bb67:
  %t194 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t194, ptr %l129, !tbaa !27
  %t195 = load i64, ptr %l11, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr ptr, ptr %t198, i64 %t195
  %t200 = load ptr, ptr %t199, !tbaa !39
  store ptr %t200, ptr %l13, !tbaa !29
  %t202 = load ptr, ptr %l13, !tbaa !29
  store ptr %t202, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t203 = load ptr, ptr %l132, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb68, label %bb69
bb68:
  %t206 = load ptr, ptr %l132, !tbaa !29
  %t207 = load i64, ptr %t206
  %t209 = icmp eq i64 %t207, 1
  store i1 %t209, ptr %l133, !tbaa !21
  br label %bb69
bb69:
  %t210 = load i1, ptr %l133, !tbaa !21
  br i1 %t210, label %bb70, label %bb71
bb70:
  %t211 = load ptr, ptr %l13, !tbaa !29
  %t213 = getelementptr { i64, [2 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { ptr }, ptr %t213, i32 0, i32 0
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l14, !tbaa !29
  br label %bb72
bb71:
  br label %bb77
bb72:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l14, !tbaa !29
  %t221 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t217, ptr %t218)
  store i1 %t221, ptr %l140
  br label %bb73
bb73:
  %t222 = load i1, ptr %l140, !tbaa !21
  br i1 %t222, label %bb74, label %bb75
bb74:
  call void @__olang_scope_close(ptr %s11)
  store i1 true, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  br label %bb82
bb77:
  br i1 true, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_285dc0af82d31c87_50e1bc6ae6554e83)
  unreachable
bb82:
  call void @__olang_scope_close(ptr %s11)
  br label %bb83
bb83:
  %t224 = load i64, ptr %l11, !tbaa !24
  %t226 = add i64 %t224, 1
  store i64 %t226, ptr %l11, !tbaa !24
  br label %bb64
bb84:
  store i1 false, ptr %rv
  br label %ret
bb85:
  %t229 = load ptr, ptr %l1, !tbaa !29
  store ptr %t229, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t230 = load ptr, ptr %l145, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb86, label %bb87
bb86:
  %t233 = load ptr, ptr %l145, !tbaa !29
  %t234 = load i64, ptr %t233
  %t236 = icmp eq i64 %t234, 6
  store i1 %t236, ptr %l146, !tbaa !21
  br label %bb87
bb87:
  %t237 = load i1, ptr %l146, !tbaa !21
  br i1 %t237, label %bb88, label %bb89
bb88:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t240, i32 0, i32 2
  %t242 = load ptr, ptr %t241
  store ptr %t242, ptr %l15, !tbaa !29
  br label %bb90
bb89:
  br label %bb134
bb90:
  %t244 = load ptr, ptr %l15, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Call", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  store ptr %t247, ptr %l16, !tbaa !29
  %t249 = load ptr, ptr %l16, !tbaa !29
  store ptr %t249, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t250 = load ptr, ptr %l153, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb91, label %bb92
bb91:
  %t253 = load ptr, ptr %l153, !tbaa !29
  %t254 = load i64, ptr %t253
  %t256 = icmp eq i64 %t254, 0
  store i1 %t256, ptr %l154, !tbaa !21
  br label %bb92
bb92:
  %t257 = load i1, ptr %l154, !tbaa !21
  br i1 %t257, label %bb93, label %bb94
bb93:
  %t258 = load ptr, ptr %l16, !tbaa !29
  %t260 = getelementptr { i64, [3 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { i32 }, ptr %t260, i32 0, i32 0
  %t262 = load i32, ptr %t261
  store i32 %t262, ptr %l17, !tbaa !23
  br label %bb95
bb94:
  br label %bb108
bb95:
  %t264 = load i32, ptr %l17, !tbaa !23
  %t266 = sext i32 %t264 to i64
  store i64 %t266, ptr %l18, !tbaa !24
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load i64, ptr %l18, !tbaa !24
  %t272 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %t268, i64 %t269)
  store i1 %t272, ptr %l163
  br label %bb96
bb96:
  %t273 = load i1, ptr %l163, !tbaa !21
  %t274 = xor i1 %t273, true
  br i1 %t274, label %bb97, label %bb98
bb97:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/free:Free", ptr %t276, i32 0, i32 1
  %t279 = load i64, ptr %l18, !tbaa !24
  %t282 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t278, i64 %t279)
  store ptr %t282, ptr %l169
  br label %bb99
bb98:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb104
bb99:
  %t283 = load ptr, ptr %l169, !tbaa !29
  %t285 = getelementptr %"compiler/typed:Body", ptr %t283, i32 0, i32 11
  %t286 = load ptr, ptr %t285, !tbaa !29
  %t288 = icmp eq ptr %t286, null
  br i1 %t288, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb103
bb101:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/free:Free", ptr %t290, i32 0, i32 28
  %t293 = load i64, ptr %l18, !tbaa !24
  %t296 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t292, i64 %t293)
  store i1 %t296, ptr %l177
  br label %bb102
bb102:
  %t297 = load i1, ptr %l177, !tbaa !21
  store i1 %t297, ptr %l173, !tbaa !21
  br label %bb103
bb103:
  %t298 = load i1, ptr %l173, !tbaa !21
  store i1 %t298, ptr %l165, !tbaa !21
  br label %bb104
bb104:
  %t299 = load i1, ptr %l165, !tbaa !21
  br i1 %t299, label %bb105, label %bb106
bb105:
  store i1 true, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  br label %bb123
bb108:
  %t301 = load ptr, ptr %l16, !tbaa !29
  store ptr %t301, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t302 = load ptr, ptr %l179, !tbaa !29
  %t303 = icmp ne ptr %t302, null
  br i1 %t303, label %bb109, label %bb110
bb109:
  %t305 = load ptr, ptr %l179, !tbaa !29
  %t306 = load i64, ptr %t305
  %t308 = icmp eq i64 %t306, 4
  store i1 %t308, ptr %l180, !tbaa !21
  br label %bb110
bb110:
  %t309 = load i1, ptr %l180, !tbaa !21
  br i1 %t309, label %bb111, label %bb112
bb111:
  br label %bb117
bb112:
  %t310 = load ptr, ptr %l16, !tbaa !29
  store ptr %t310, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t311 = load ptr, ptr %l183, !tbaa !29
  %t312 = icmp ne ptr %t311, null
  br i1 %t312, label %bb113, label %bb114
bb113:
  %t314 = load ptr, ptr %l183, !tbaa !29
  %t315 = load i64, ptr %t314
  %t317 = icmp eq i64 %t315, 1
  store i1 %t317, ptr %l184, !tbaa !21
  br label %bb114
bb114:
  %t318 = load i1, ptr %l184, !tbaa !21
  br i1 %t318, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb123
bb118:
  br i1 true, label %bb119, label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb122
bb121:
  store i1 true, ptr %rv
  br label %ret
bb122:
  call void @__olang_check_failed(ptr @olang_loc_f9703b3e8b4d3f8c_114f0f1572d2eea8)
  unreachable
bb123:
  %t320 = load ptr, ptr %l15, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Call", ptr %t320, i32 0, i32 1
  %t323 = load { i64, ptr }, ptr %t322, !tbaa !27
  store { i64, ptr } %t323, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t325 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t325, 0
  store i64 %t327, ptr %l21, !tbaa !24
  br label %bb124
bb124:
  store %olang.scope zeroinitializer, ptr %s22
  %t329 = load i64, ptr %l20, !tbaa !24
  %t330 = load i64, ptr %l21, !tbaa !24
  %t333 = icmp slt i64 %t329, %t330
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb125, label %bb126
bb125:
  call void @__olang_scope_close(ptr %s22)
  br label %bb133
bb126:
  br label %bb127
bb127:
  %t337 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t337, ptr %l196, !tbaa !27
  %t338 = load i64, ptr %l20, !tbaa !24
  %t340 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr ptr, ptr %t341, i64 %t338
  %t343 = load ptr, ptr %t342, !tbaa !39
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t349 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t345, ptr %t343)
  store i1 %t349, ptr %l201
  br label %bb128
bb128:
  %t350 = load i1, ptr %l201, !tbaa !21
  br i1 %t350, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s22)
  store i1 true, ptr %rv
  br label %ret
bb130:
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s22)
  br label %bb132
bb132:
  %t352 = load i64, ptr %l20, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l20, !tbaa !24
  br label %bb124
bb133:
  store i1 false, ptr %rv
  br label %ret
bb134:
  %t357 = load ptr, ptr %l1, !tbaa !29
  store ptr %t357, ptr %l206, !tbaa !29
  store i1 false, ptr %l207, !tbaa !21
  %t358 = load ptr, ptr %l206, !tbaa !29
  %t359 = icmp ne ptr %t358, null
  br i1 %t359, label %bb135, label %bb136
bb135:
  %t361 = load ptr, ptr %l206, !tbaa !29
  %t362 = load i64, ptr %t361
  %t364 = icmp eq i64 %t362, 9
  store i1 %t364, ptr %l207, !tbaa !21
  br label %bb136
bb136:
  %t365 = load i1, ptr %l207, !tbaa !21
  br i1 %t365, label %bb137, label %bb138
bb137:
  %t366 = load ptr, ptr %l1, !tbaa !29
  %t368 = getelementptr { i64, [5 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t368, i32 0, i32 4
  %t370 = load { i64, ptr }, ptr %t369
  store { i64, ptr } %t370, ptr %l23, !tbaa !27
  br label %bb139
bb138:
  br label %bb150
bb139:
  %t372 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t372, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t374 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t374, 0
  store i64 %t376, ptr %l26, !tbaa !24
  br label %bb140
bb140:
  store %olang.scope zeroinitializer, ptr %s27
  %t378 = load i64, ptr %l25, !tbaa !24
  %t379 = load i64, ptr %l26, !tbaa !24
  %t382 = icmp slt i64 %t378, %t379
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb141, label %bb142
bb141:
  call void @__olang_scope_close(ptr %s27)
  br label %bb149
bb142:
  br label %bb143
bb143:
  %t386 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t386, ptr %l219, !tbaa !27
  %t387 = load i64, ptr %l25, !tbaa !24
  %t389 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr ptr, ptr %t390, i64 %t387
  %t392 = load ptr, ptr %t391, !tbaa !39
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t398 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t394, ptr %t392)
  store i1 %t398, ptr %l224
  br label %bb144
bb144:
  %t399 = load i1, ptr %l224, !tbaa !21
  br i1 %t399, label %bb145, label %bb146
bb145:
  call void @__olang_scope_close(ptr %s27)
  store i1 true, ptr %rv
  br label %ret
bb146:
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s27)
  br label %bb148
bb148:
  %t401 = load i64, ptr %l25, !tbaa !24
  %t403 = add i64 %t401, 1
  store i64 %t403, ptr %l25, !tbaa !24
  br label %bb140
bb149:
  store i1 false, ptr %rv
  br label %ret
bb150:
  %t406 = load ptr, ptr %l1, !tbaa !29
  store ptr %t406, ptr %l229, !tbaa !29
  store i1 false, ptr %l230, !tbaa !21
  %t407 = load ptr, ptr %l229, !tbaa !29
  %t408 = icmp ne ptr %t407, null
  br i1 %t408, label %bb151, label %bb152
bb151:
  %t410 = load ptr, ptr %l229, !tbaa !29
  %t411 = load i64, ptr %t410
  %t413 = icmp eq i64 %t411, 17
  store i1 %t413, ptr %l230, !tbaa !21
  br label %bb152
bb152:
  %t414 = load i1, ptr %l230, !tbaa !21
  br i1 %t414, label %bb153, label %bb154
bb153:
  %t415 = load ptr, ptr %l1, !tbaa !29
  %t417 = getelementptr { i64, [5 x i64] }, ptr %t415, i32 0, i32 1
  %t418 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t417, i32 0, i32 2
  %t419 = load ptr, ptr %t418
  store ptr %t419, ptr %l28, !tbaa !29
  br label %bb155
bb154:
  br label %bb157
bb155:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load ptr, ptr %l28, !tbaa !29
  %t425 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t421, ptr %t422)
  store i1 %t425, ptr %l237
  br label %bb156
bb156:
  %t426 = load i1, ptr %l237, !tbaa !21
  store i1 %t426, ptr %rv
  br label %ret
bb157:
  %t427 = load ptr, ptr %l1, !tbaa !29
  store ptr %t427, ptr %l238, !tbaa !29
  store i1 false, ptr %l239, !tbaa !21
  %t428 = load ptr, ptr %l238, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb158, label %bb159
bb158:
  %t431 = load ptr, ptr %l238, !tbaa !29
  %t432 = load i64, ptr %t431
  %t434 = icmp eq i64 %t432, 11
  store i1 %t434, ptr %l239, !tbaa !21
  br label %bb159
bb159:
  %t435 = load i1, ptr %l239, !tbaa !21
  br i1 %t435, label %bb160, label %bb161
bb160:
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t438 = getelementptr { i64, [5 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t438, i32 0, i32 2
  %t440 = load ptr, ptr %t439
  store ptr %t440, ptr %l29, !tbaa !29
  br label %bb162
bb161:
  br label %bb178
bb162:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load ptr, ptr %l29, !tbaa !29
  %t445 = getelementptr %"compiler/typed:Cond", ptr %t443, i32 0, i32 0
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t449 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t442, ptr %t446)
  store i1 %t449, ptr %l247
  br label %bb163
bb163:
  %t450 = load i1, ptr %l247, !tbaa !21
  br i1 %t450, label %bb164, label %bb165
bb164:
  store i1 true, ptr %l248, !tbaa !21
  br label %bb173
bb165:
  %t451 = load ptr, ptr %l29, !tbaa !29
  %t453 = getelementptr %"compiler/typed:Cond", ptr %t451, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !29
  %t456 = icmp eq ptr %t454, null
  %t458 = xor i1 %t456, true
  br i1 %t458, label %bb166, label %bb167
bb166:
  %t460 = load ptr, ptr %l0, !tbaa !29
  store ptr %t460, ptr %l254, !tbaa !29
  %t461 = load ptr, ptr %l29, !tbaa !29
  %t463 = getelementptr %"compiler/typed:Cond", ptr %t461, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !29
  %t466 = icmp eq ptr %t464, null
  br i1 %t466, label %bb168, label %bb169
bb167:
  store i1 false, ptr %l253, !tbaa !21
  br label %bb172
bb168:
  call void @__olang_check_failed(ptr @olang_loc_c329a7357b4632ae_1972f4ce8b92321a)
  unreachable
bb169:
  br label %bb170
bb170:
  %t468 = load ptr, ptr %l29, !tbaa !29
  %t470 = getelementptr %"compiler/typed:Cond", ptr %t468, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !29
  %t472 = load ptr, ptr %l254, !tbaa !29
  %t474 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t472, ptr %t471)
  store i1 %t474, ptr %l260
  br label %bb171
bb171:
  %t475 = load i1, ptr %l260, !tbaa !21
  store i1 %t475, ptr %l253, !tbaa !21
  br label %bb172
bb172:
  %t476 = load i1, ptr %l253, !tbaa !21
  store i1 %t476, ptr %l248, !tbaa !21
  br label %bb173
bb173:
  %t477 = load i1, ptr %l248, !tbaa !21
  br i1 %t477, label %bb174, label %bb175
bb174:
  store i1 true, ptr %l261, !tbaa !21
  br label %bb177
bb175:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load ptr, ptr %l29, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Cond", ptr %t479, i32 0, i32 2
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t485 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t478, ptr %t482)
  store i1 %t485, ptr %l265
  br label %bb176
bb176:
  %t486 = load i1, ptr %l265, !tbaa !21
  store i1 %t486, ptr %l261, !tbaa !21
  br label %bb177
bb177:
  %t487 = load i1, ptr %l261, !tbaa !21
  store i1 %t487, ptr %rv
  br label %ret
bb178:
  %t488 = load ptr, ptr %l1, !tbaa !29
  store ptr %t488, ptr %l266, !tbaa !29
  store i1 false, ptr %l267, !tbaa !21
  %t489 = load ptr, ptr %l266, !tbaa !29
  %t490 = icmp ne ptr %t489, null
  br i1 %t490, label %bb179, label %bb180
bb179:
  %t492 = load ptr, ptr %l266, !tbaa !29
  %t493 = load i64, ptr %t492
  %t495 = icmp eq i64 %t493, 14
  store i1 %t495, ptr %l267, !tbaa !21
  br label %bb180
bb180:
  %t496 = load i1, ptr %l267, !tbaa !21
  br i1 %t496, label %bb181, label %bb182
bb181:
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t499 = getelementptr { i64, [5 x i64] }, ptr %t497, i32 0, i32 1
  %t500 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t499, i32 0, i32 2
  %t501 = load ptr, ptr %t500
  store ptr %t501, ptr %l30, !tbaa !29
  br label %bb183
bb182:
  br label %bb213
bb183:
  %t503 = load ptr, ptr %l30, !tbaa !29
  %t505 = getelementptr %"compiler/typed:Try", ptr %t503, i32 0, i32 0
  %t506 = load ptr, ptr %t505, !tbaa !29
  %t508 = icmp eq ptr %t506, null
  %t510 = xor i1 %t508, true
  br i1 %t510, label %bb184, label %bb185
bb184:
  %t512 = load ptr, ptr %l0, !tbaa !29
  store ptr %t512, ptr %l277, !tbaa !29
  %t513 = load ptr, ptr %l30, !tbaa !29
  %t515 = getelementptr %"compiler/typed:Try", ptr %t513, i32 0, i32 0
  %t516 = load ptr, ptr %t515, !tbaa !29
  %t518 = icmp eq ptr %t516, null
  br i1 %t518, label %bb186, label %bb187
bb185:
  store i1 false, ptr %l276, !tbaa !21
  br label %bb190
bb186:
  call void @__olang_check_failed(ptr @olang_loc_ce4a56608212b1d3_28564c72fb26107)
  unreachable
bb187:
  br label %bb188
bb188:
  %t520 = load ptr, ptr %l30, !tbaa !29
  %t522 = getelementptr %"compiler/typed:Try", ptr %t520, i32 0, i32 0
  %t523 = load ptr, ptr %t522, !tbaa !29
  %t524 = load ptr, ptr %l277, !tbaa !29
  %t526 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t524, ptr %t523)
  store i1 %t526, ptr %l283
  br label %bb189
bb189:
  %t527 = load i1, ptr %l283, !tbaa !21
  store i1 %t527, ptr %l276, !tbaa !21
  br label %bb190
bb190:
  %t528 = load i1, ptr %l276, !tbaa !21
  br i1 %t528, label %bb191, label %bb192
bb191:
  store i1 true, ptr %rv
  br label %ret
bb192:
  br label %bb193
bb193:
  %t530 = load ptr, ptr %l30, !tbaa !29
  %t532 = getelementptr %"compiler/typed:Try", ptr %t530, i32 0, i32 1
  %t533 = load { i64, ptr }, ptr %t532, !tbaa !27
  store { i64, ptr } %t533, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t535 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t537 = extractvalue { i64, ptr } %t535, 0
  store i64 %t537, ptr %l33, !tbaa !24
  br label %bb194
bb194:
  store %olang.scope zeroinitializer, ptr %s35
  %t539 = load i64, ptr %l32, !tbaa !24
  %t540 = load i64, ptr %l33, !tbaa !24
  %t543 = icmp slt i64 %t539, %t540
  %t545 = xor i1 %t543, true
  br i1 %t545, label %bb195, label %bb196
bb195:
  call void @__olang_scope_close(ptr %s35)
  br label %bb212
bb196:
  br label %bb197
bb197:
  %t547 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t547, ptr %l293, !tbaa !27
  %t548 = load i64, ptr %l32, !tbaa !24
  %t550 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t551 = load ptr, ptr %t550, !tbaa !27
  %t552 = getelementptr ptr, ptr %t551, i64 %t548
  %t553 = load ptr, ptr %t552, !tbaa !39
  store ptr %t553, ptr %l34, !tbaa !29
  %t555 = load ptr, ptr %l34, !tbaa !29
  %t557 = getelementptr %"compiler/typed:Clause", ptr %t555, i32 0, i32 3
  %t558 = load ptr, ptr %t557, !tbaa !29
  %t560 = icmp eq ptr %t558, null
  %t562 = xor i1 %t560, true
  br i1 %t562, label %bb198, label %bb199
bb198:
  call void @__olang_scope_close(ptr %s35)
  store i1 true, ptr %rv
  br label %ret
bb199:
  br label %bb200
bb200:
  %t565 = load ptr, ptr %l34, !tbaa !29
  %t567 = getelementptr %"compiler/typed:Clause", ptr %t565, i32 0, i32 4
  %t568 = load { i64, ptr }, ptr %t567, !tbaa !27
  store { i64, ptr } %t568, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t570 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t572 = extractvalue { i64, ptr } %t570, 0
  store i64 %t572, ptr %l37, !tbaa !24
  br label %bb201
bb201:
  store %olang.scope zeroinitializer, ptr %s38
  %t574 = load i64, ptr %l36, !tbaa !24
  %t575 = load i64, ptr %l37, !tbaa !24
  %t578 = icmp slt i64 %t574, %t575
  %t580 = xor i1 %t578, true
  br i1 %t580, label %bb202, label %bb203
bb202:
  call void @__olang_scope_close(ptr %s38)
  br label %bb210
bb203:
  br label %bb204
bb204:
  %t582 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t582, ptr %l309, !tbaa !27
  %t583 = load i64, ptr %l36, !tbaa !24
  %t585 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t586 = load ptr, ptr %t585, !tbaa !27
  %t587 = getelementptr ptr, ptr %t586, i64 %t583
  %t588 = load ptr, ptr %t587, !tbaa !39
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t594 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t590, ptr %t588)
  store i1 %t594, ptr %l314
  br label %bb205
bb205:
  %t595 = load i1, ptr %l314, !tbaa !21
  br i1 %t595, label %bb206, label %bb207
bb206:
  call void @__olang_scope_close(ptr %s38)
  call void @__olang_scope_close(ptr %s35)
  store i1 true, ptr %rv
  br label %ret
bb207:
  br label %bb208
bb208:
  call void @__olang_scope_close(ptr %s38)
  br label %bb209
bb209:
  %t597 = load i64, ptr %l36, !tbaa !24
  %t599 = add i64 %t597, 1
  store i64 %t599, ptr %l36, !tbaa !24
  br label %bb201
bb210:
  call void @__olang_scope_close(ptr %s35)
  br label %bb211
bb211:
  %t601 = load i64, ptr %l32, !tbaa !24
  %t603 = add i64 %t601, 1
  store i64 %t603, ptr %l32, !tbaa !24
  br label %bb194
bb212:
  store i1 false, ptr %rv
  br label %ret
bb213:
  %t606 = load ptr, ptr %l1, !tbaa !29
  store ptr %t606, ptr %l321, !tbaa !29
  store i1 false, ptr %l322, !tbaa !21
  %t607 = load ptr, ptr %l321, !tbaa !29
  %t608 = icmp ne ptr %t607, null
  br i1 %t608, label %bb214, label %bb215
bb214:
  %t610 = load ptr, ptr %l321, !tbaa !29
  %t611 = load i64, ptr %t610
  %t613 = icmp eq i64 %t611, 15
  store i1 %t613, ptr %l322, !tbaa !21
  br label %bb215
bb215:
  %t614 = load i1, ptr %l322, !tbaa !21
  br i1 %t614, label %bb216, label %bb217
bb216:
  %t615 = load ptr, ptr %l1, !tbaa !29
  %t617 = getelementptr { i64, [5 x i64] }, ptr %t615, i32 0, i32 1
  %t618 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t617, i32 0, i32 2
  %t619 = load ptr, ptr %t618
  store ptr %t619, ptr %l39, !tbaa !29
  br label %bb218
bb217:
  br label %bb237
bb218:
  %t621 = load ptr, ptr %l39, !tbaa !29
  store ptr %t621, ptr %l328, !tbaa !29
  store i1 false, ptr %l329, !tbaa !21
  %t622 = load ptr, ptr %l328, !tbaa !29
  %t623 = icmp ne ptr %t622, null
  br i1 %t623, label %bb219, label %bb220
bb219:
  %t625 = load ptr, ptr %l328, !tbaa !29
  %t626 = load i64, ptr %t625
  %t628 = icmp eq i64 %t626, 0
  store i1 %t628, ptr %l329, !tbaa !21
  br label %bb220
bb220:
  %t629 = load i1, ptr %l329, !tbaa !21
  br i1 %t629, label %bb221, label %bb222
bb221:
  br label %bb223
bb222:
  br label %bb224
bb223:
  store i1 false, ptr %l327, !tbaa !21
  br label %bb236
bb224:
  %t630 = load ptr, ptr %l39, !tbaa !29
  store ptr %t630, ptr %l332, !tbaa !29
  store i1 false, ptr %l333, !tbaa !21
  %t631 = load ptr, ptr %l332, !tbaa !29
  %t632 = icmp ne ptr %t631, null
  br i1 %t632, label %bb225, label %bb226
bb225:
  %t634 = load ptr, ptr %l332, !tbaa !29
  %t635 = load i64, ptr %t634
  %t637 = icmp eq i64 %t635, 1
  store i1 %t637, ptr %l333, !tbaa !21
  br label %bb226
bb226:
  %t638 = load i1, ptr %l333, !tbaa !21
  br i1 %t638, label %bb227, label %bb228
bb227:
  %t639 = load ptr, ptr %l39, !tbaa !29
  %t641 = getelementptr { i64, [4 x i64] }, ptr %t639, i32 0, i32 1
  %t642 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t641, i32 0, i32 0
  %t643 = load i32, ptr %t642
  store i32 %t643, ptr %l40, !tbaa !23
  %t645 = load ptr, ptr %l39, !tbaa !29
  %t647 = getelementptr { i64, [4 x i64] }, ptr %t645, i32 0, i32 1
  %t648 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t647, i32 0, i32 1
  %t649 = load { i64, ptr }, ptr %t648
  store { i64, ptr } %t649, ptr %l41, !tbaa !27
  br label %bb229
bb228:
  br label %bb231
bb229:
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = getelementptr %"compiler/free:Free", ptr %t651, i32 0, i32 28
  %t654 = load i32, ptr %l40, !tbaa !23
  %t656 = sext i32 %t654 to i64
  %t659 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t653, i64 %t656)
  store i1 %t659, ptr %l344
  br label %bb230
bb230:
  %t660 = load i1, ptr %l344, !tbaa !21
  store i1 %t660, ptr %l327, !tbaa !21
  br label %bb236
bb231:
  br i1 true, label %bb232, label %bb233
bb232:
  br label %bb234
bb233:
  br label %bb235
bb234:
  store i1 true, ptr %l327, !tbaa !21
  br label %bb236
bb235:
  call void @__olang_check_failed(ptr @olang_loc_8c3ff88e405c7c2b_15d3403d537d031f)
  unreachable
bb236:
  %t661 = load i1, ptr %l327, !tbaa !21
  store i1 %t661, ptr %rv
  br label %ret
bb237:
  br i1 true, label %bb238, label %bb239
bb238:
  br label %bb240
bb239:
  br label %bb241
bb240:
  store i1 true, ptr %rv
  br label %ret
bb241:
  call void @__olang_check_failed(ptr @olang_loc_2b6adc3dc0c287f0_370d6d4a959e10e4)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2emustOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l58 = alloca ptr
  %l64 = alloca %"compiler/free:mustW"
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l103 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i64
  %l129 = alloca ptr
  %l133 = alloca i32
  %l137 = alloca ptr
  %l141 = alloca i32
  %l146 = alloca ptr
  %l154 = alloca i64
  %l158 = alloca i64
  %l161 = alloca i64
  %l182 = alloca i64
  %l185 = alloca i1
  %l188 = alloca i1
  %l192 = alloca i64
  %l193 = alloca ptr
  %l197 = alloca ptr
  %l198 = alloca i64
  %l199 = alloca i64
  %l200 = alloca i64
  %l204 = alloca i64
  %l213 = alloca i64
  %l215 = alloca ptr
  %l217 = alloca ptr
  %l221 = alloca ptr
  %l222 = alloca i64
  %l223 = alloca i64
  %l224 = alloca i64
  %l228 = alloca i64
  %l241 = alloca ptr
  %l245 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l249 = alloca i32
  %l258 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l275 = alloca i32
  %l284 = alloca { i64, ptr }
  %l287 = alloca i64
  %l290 = alloca i64
  %l291 = alloca i64
  %l294 = alloca i1
  %l301 = alloca i64
  %l305 = alloca i64
  %l312 = alloca i1
  %l316 = alloca i1
  %l318 = alloca i1
  %l322 = alloca i1
  %l330 = alloca ptr
  %l334 = alloca { i64, ptr }
  %l337 = alloca { i64, ptr }
  %l338 = alloca i32
  %l347 = alloca { i64, ptr }
  %l360 = alloca ptr
  %l364 = alloca i64
  %l368 = alloca i64
  %l371 = alloca i64
  %l389 = alloca ptr
  %l392 = alloca i1
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l58
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l58, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call %"compiler/free:mustW" @compiler_2ffree_3amustW_2ector(ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  store %"compiler/free:mustW" %t20, ptr %l64
  br label %bb5
bb5:
  %t21 = load %"compiler/free:mustW", ptr %l64
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/free:mustW" %t21, ptr %t22
  store ptr %t22, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 7
  %t28 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l68
  br label %bb6
bb6:
  %t29 = load i64, ptr %l68, !tbaa !24
  store i64 %t29, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb12
bb9:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l75, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb11
bb11:
  %t56 = load i64, ptr %l75, !tbaa !24
  store i64 %t56, ptr %l72, !tbaa !24
  br label %bb12
bb12:
  %t57 = load i64, ptr %l72, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb15:
  br label %bb16
bb16:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l9, !tbaa !24
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/free:mustW", ptr %t76, i32 0, i32 2
  %t79 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t78, i64 %t79)
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr %"compiler/free:mustW", ptr %t82, i32 0, i32 3
  %t85 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t84, i64 %t85)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t88 = load i64, ptr %l8, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l8, !tbaa !24
  br label %bb13
bb20:
  store i64 0, ptr %l10, !tbaa !24
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Body", ptr %t92, i32 0, i32 5
  %t96 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t94)
  store i64 %t96, ptr %l103
  br label %bb21
bb21:
  %t97 = load i64, ptr %l103, !tbaa !24
  store i64 %t97, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = icmp sgt i64 %t98, %t99
  br i1 %t102, label %bb22, label %bb23
bb22:
  %t104 = load i64, ptr %l12, !tbaa !24
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb27
bb24:
  %t108 = load i64, ptr %l11, !tbaa !24
  %t109 = load i64, ptr %l10, !tbaa !24
  %t112 = sub i64 %t108, %t109
  %t113 = load i64, ptr %l12, !tbaa !24
  %t116 = add i64 %t112, %t113
  %t118 = sub i64 %t116, 1
  %t119 = load i64, ptr %l12, !tbaa !24
  %t122 = sdiv i64 %t118, %t119
  store i64 %t122, ptr %l110, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb26
bb26:
  %t124 = load i64, ptr %l110, !tbaa !24
  store i64 %t124, ptr %l107, !tbaa !24
  br label %bb27
bb27:
  %t125 = load i64, ptr %l107, !tbaa !24
  store i64 %t125, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t126 = load i64, ptr %l14, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  %t130 = icmp slt i64 %t126, %t127
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb30:
  br label %bb31
bb31:
  %t134 = load i64, ptr %l10, !tbaa !24
  %t135 = load i64, ptr %l14, !tbaa !24
  %t136 = load i64, ptr %l12, !tbaa !24
  %t139 = mul i64 %t135, %t136
  %t142 = add i64 %t134, %t139
  store i64 %t142, ptr %l15, !tbaa !24
  %t144 = load ptr, ptr %l3, !tbaa !29
  %t146 = getelementptr %"compiler/free:mustW", ptr %t144, i32 0, i32 2
  store ptr %t146, ptr %l129, !tbaa !29
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Body", ptr %t147, i32 0, i32 5
  %t150 = load i64, ptr %l15, !tbaa !24
  %t153 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t149, i64 %t150)
  store i32 %t153, ptr %l133
  br label %bb32
bb32:
  %t154 = load i32, ptr %l133, !tbaa !23
  %t155 = sext i32 %t154 to i64
  %t156 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  %t157 = load ptr, ptr %l129, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t157, i64 %t155, i64 %t156)
  br label %bb33
bb33:
  %t160 = load ptr, ptr %l3, !tbaa !29
  %t162 = getelementptr %"compiler/free:mustW", ptr %t160, i32 0, i32 3
  store ptr %t162, ptr %l137, !tbaa !29
  %t163 = load ptr, ptr %l2, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Body", ptr %t163, i32 0, i32 5
  %t166 = load i64, ptr %l15, !tbaa !24
  %t169 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t165, i64 %t166)
  store i32 %t169, ptr %l141
  br label %bb34
bb34:
  %t170 = load i32, ptr %l141, !tbaa !23
  %t171 = sext i32 %t170 to i64
  %t172 = load i64, ptr %l15, !tbaa !24
  %t173 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t173, i64 %t171, i64 %t172)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  %t176 = load i64, ptr %l14, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l14, !tbaa !24
  br label %bb28
bb37:
  %t180 = load ptr, ptr %l3, !tbaa !29
  store ptr %t180, ptr %l146, !tbaa !29
  %t181 = load ptr, ptr %l2, !tbaa !29
  %t183 = getelementptr %"compiler/typed:Body", ptr %t181, i32 0, i32 11
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t186 = icmp eq ptr %t184, null
  br i1 %t186, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_1d9a56a827ed845f_5cc839dbc781b743)
  unreachable
bb39:
  br label %bb40
bb40:
  %t188 = load ptr, ptr %l2, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Body", ptr %t188, i32 0, i32 11
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t192 = load ptr, ptr %l146, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v0, ptr %t192, ptr %t191)
  br label %bb41
bb41:
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  store i1 false, ptr %l16, !tbaa !21
  store i64 0, ptr %l17, !tbaa !24
  %t194 = load ptr, ptr %l3, !tbaa !29
  %t196 = getelementptr %"compiler/free:mustW", ptr %t194, i32 0, i32 4
  %t198 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t196)
  store i64 %t198, ptr %l154
  br label %bb43
bb43:
  %t199 = load i64, ptr %l154, !tbaa !24
  store i64 %t199, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t200 = load i64, ptr %l18, !tbaa !24
  %t201 = load i64, ptr %l17, !tbaa !24
  %t204 = icmp sgt i64 %t200, %t201
  br i1 %t204, label %bb44, label %bb45
bb44:
  %t206 = load i64, ptr %l19, !tbaa !24
  %t208 = icmp sgt i64 %t206, 0
  br i1 %t208, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l158, !tbaa !24
  br label %bb49
bb46:
  %t210 = load i64, ptr %l18, !tbaa !24
  %t211 = load i64, ptr %l17, !tbaa !24
  %t214 = sub i64 %t210, %t211
  %t215 = load i64, ptr %l19, !tbaa !24
  %t218 = add i64 %t214, %t215
  %t220 = sub i64 %t218, 1
  %t221 = load i64, ptr %l19, !tbaa !24
  %t224 = sdiv i64 %t220, %t221
  store i64 %t224, ptr %l161, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb48
bb48:
  %t226 = load i64, ptr %l161, !tbaa !24
  store i64 %t226, ptr %l158, !tbaa !24
  br label %bb49
bb49:
  %t227 = load i64, ptr %l158, !tbaa !24
  store i64 %t227, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s10
  %t228 = load i64, ptr %l21, !tbaa !24
  %t229 = load i64, ptr %l20, !tbaa !24
  %t232 = icmp slt i64 %t228, %t229
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s10)
  br label %bb81
bb52:
  br label %bb53
bb53:
  %t236 = load i64, ptr %l17, !tbaa !24
  %t237 = load i64, ptr %l21, !tbaa !24
  %t238 = load i64, ptr %l19, !tbaa !24
  %t241 = mul i64 %t237, %t238
  %t244 = add i64 %t236, %t241
  store i64 %t244, ptr %l22, !tbaa !24
  %t246 = load ptr, ptr %l3, !tbaa !29
  %t248 = getelementptr %"compiler/free:mustW", ptr %t246, i32 0, i32 4
  %t249 = load i64, ptr %l22, !tbaa !24
  %t252 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t248, i64 %t249)
  store i64 %t252, ptr %l182
  br label %bb54
bb54:
  %t253 = load i64, ptr %l182, !tbaa !24
  store i64 %t253, ptr %l23, !tbaa !24
  %t254 = load i64, ptr %l23, !tbaa !24
  %t256 = icmp slt i64 %t254, 0
  br i1 %t256, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l185, !tbaa !21
  br label %bb58
bb56:
  %t258 = load ptr, ptr %l3, !tbaa !29
  %t259 = load i64, ptr %l23, !tbaa !24
  %t262 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %t258, i64 %t259)
  store i1 %t262, ptr %l188
  br label %bb57
bb57:
  %t263 = load i1, ptr %l188, !tbaa !21
  store i1 %t263, ptr %l185, !tbaa !21
  br label %bb58
bb58:
  %t264 = load i1, ptr %l185, !tbaa !21
  br i1 %t264, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb80
bb60:
  br label %bb61
bb61:
  %t265 = load ptr, ptr %l3, !tbaa !29
  %t267 = getelementptr %"compiler/free:mustW", ptr %t265, i32 0, i32 2
  %t268 = load i64, ptr %l23, !tbaa !24
  %t271 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t267, i64 %t268)
  store i64 %t271, ptr %l192
  br label %bb62
bb62:
  %t272 = load ptr, ptr %l3, !tbaa !29
  store ptr %t272, ptr %l193, !tbaa !29
  %t273 = load ptr, ptr %l3, !tbaa !29
  %t275 = getelementptr %"compiler/free:mustW", ptr %t273, i32 0, i32 5
  %t276 = load i64, ptr %l22, !tbaa !24
  %t279 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t275, i64 %t276)
  store ptr %t279, ptr %l197
  br label %bb63
bb63:
  %t280 = load ptr, ptr %l193, !tbaa !29
  %t281 = load ptr, ptr %l197, !tbaa !29
  %t282 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v0, ptr %t280, ptr %t281)
  store i64 %t282, ptr %l198
  br label %bb64
bb64:
  %t283 = load i64, ptr %l192, !tbaa !24
  %t284 = load i64, ptr %l198, !tbaa !24
  %t285 = call i64 @compiler_2ffree_2emeet(i64 %t283, i64 %t284)
  store i64 %t285, ptr %l199
  br label %bb65
bb65:
  %t286 = load i64, ptr %l199, !tbaa !24
  store i64 %t286, ptr %l24, !tbaa !24
  %t287 = load i64, ptr %l24, !tbaa !24
  store i64 %t287, ptr %l200, !tbaa !24
  %t288 = load ptr, ptr %l3, !tbaa !29
  %t290 = getelementptr %"compiler/free:mustW", ptr %t288, i32 0, i32 2
  %t291 = load i64, ptr %l23, !tbaa !24
  %t294 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t290, i64 %t291)
  store i64 %t294, ptr %l204
  br label %bb66
bb66:
  %t295 = load i64, ptr %l200, !tbaa !24
  %t296 = load i64, ptr %l204, !tbaa !24
  %t297 = icmp ne i64 %t295, %t296
  br i1 %t297, label %bb67, label %bb68
bb67:
  %t299 = load ptr, ptr %l3, !tbaa !29
  %t301 = getelementptr %"compiler/free:mustW", ptr %t299, i32 0, i32 2
  %t302 = load i64, ptr %l23, !tbaa !24
  %t303 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t301, i64 %t302, i64 %t303)
  br label %bb69
bb68:
  br label %bb70
bb69:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb70
bb70:
  %t307 = load ptr, ptr %l3, !tbaa !29
  %t309 = getelementptr %"compiler/free:mustW", ptr %t307, i32 0, i32 3
  %t310 = load i64, ptr %l23, !tbaa !24
  %t313 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t309, i64 %t310)
  store i64 %t313, ptr %l213
  br label %bb71
bb71:
  %t314 = load ptr, ptr %l3, !tbaa !29
  %t316 = getelementptr %"compiler/free:mustW", ptr %t314, i32 0, i32 0
  %t317 = load ptr, ptr %t316, !tbaa !29
  store ptr %t317, ptr %l215, !tbaa !29
  %t318 = load ptr, ptr %l3, !tbaa !29
  %t320 = getelementptr %"compiler/free:mustW", ptr %t318, i32 0, i32 3
  store ptr %t320, ptr %l217, !tbaa !29
  %t321 = load ptr, ptr %l3, !tbaa !29
  %t323 = getelementptr %"compiler/free:mustW", ptr %t321, i32 0, i32 5
  %t324 = load i64, ptr %l22, !tbaa !24
  %t327 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t323, i64 %t324)
  store ptr %t327, ptr %l221
  br label %bb72
bb72:
  %t328 = load ptr, ptr %l215, !tbaa !29
  %t329 = load ptr, ptr %l217, !tbaa !29
  %t330 = load ptr, ptr %l221, !tbaa !29
  %t331 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v0, ptr %v0, ptr %t328, ptr %t329, ptr %t330)
  store i64 %t331, ptr %l222
  br label %bb73
bb73:
  %t332 = load i64, ptr %l213, !tbaa !24
  %t333 = load i64, ptr %l222, !tbaa !24
  %t334 = call i64 @compiler_2ffree_2emeet(i64 %t332, i64 %t333)
  store i64 %t334, ptr %l223
  br label %bb74
bb74:
  %t335 = load i64, ptr %l223, !tbaa !24
  store i64 %t335, ptr %l25, !tbaa !24
  %t336 = load i64, ptr %l25, !tbaa !24
  store i64 %t336, ptr %l224, !tbaa !24
  %t337 = load ptr, ptr %l3, !tbaa !29
  %t339 = getelementptr %"compiler/free:mustW", ptr %t337, i32 0, i32 3
  %t340 = load i64, ptr %l23, !tbaa !24
  %t343 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t339, i64 %t340)
  store i64 %t343, ptr %l228
  br label %bb75
bb75:
  %t344 = load i64, ptr %l224, !tbaa !24
  %t345 = load i64, ptr %l228, !tbaa !24
  %t346 = icmp ne i64 %t344, %t345
  br i1 %t346, label %bb76, label %bb77
bb76:
  %t348 = load ptr, ptr %l3, !tbaa !29
  %t350 = getelementptr %"compiler/free:mustW", ptr %t348, i32 0, i32 3
  %t351 = load i64, ptr %l23, !tbaa !24
  %t352 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t350, i64 %t351, i64 %t352)
  br label %bb78
bb77:
  br label %bb79
bb78:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s10)
  br label %bb80
bb80:
  %t356 = load i64, ptr %l21, !tbaa !24
  %t358 = add i64 %t356, 1
  store i64 %t358, ptr %l21, !tbaa !24
  br label %bb50
bb81:
  %t360 = load i1, ptr %l16, !tbaa !21
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s8)
  br label %bb86
bb83:
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s8)
  br label %bb85
bb85:
  br label %bb42
bb86:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/free:Free", ptr %t364, i32 0, i32 46
  %t367 = load i64, ptr %l1, !tbaa !24
  %t370 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t366, i64 %t367)
  store ptr %t370, ptr %l241
  br label %bb87
bb87:
  %t371 = load ptr, ptr %l241, !tbaa !29
  store ptr %t371, ptr %l26, !tbaa !29
  %t372 = load ptr, ptr %l26, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t372)
  br label %bb88
bb88:
  %t374 = load ptr, ptr %l3, !tbaa !29
  %t376 = getelementptr %"compiler/free:mustW", ptr %t374, i32 0, i32 3
  store ptr %t376, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s17
  %t378 = load ptr, ptr %l27, !tbaa !29
  %t379 = load i64, ptr %l28, !tbaa !24
  %t382 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t378, i64 %t379)
  %t383 = extractvalue { i32, { i64, ptr } } %t382, 1
  %t384 = extractvalue { i32, { i64, ptr } } %t382, 0
  store i32 %t384, ptr %l249
  %t385 = icmp ne i32 %t384, 0
  br i1 %t385, label %bb91, label %ok.386
ok.386:
  store { i64, ptr } %t383, ptr %l248
  br label %bb90
bb90:
  %t387 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t387, ptr %l245, !tbaa !27
  br label %bb95
bb91:
  %t388 = load i32, ptr %l249, !tbaa !23
  %t389 = ashr i32 %t388, 16
  %t391 = icmp eq i32 %t389, 1
  br i1 %t391, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_b0b9e719fd18da07_d4692a85838c2bdb)
  unreachable
bb94:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s17)
  br label %bb104
bb95:
  %t393 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t393, ptr %l29, !tbaa !27
  %t394 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t394, 0
  store i64 %t396, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s18
  %t398 = load i64, ptr %l31, !tbaa !24
  %t399 = load i64, ptr %l30, !tbaa !24
  %t402 = icmp slt i64 %t398, %t399
  %t404 = xor i1 %t402, true
  br i1 %t404, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s18)
  br label %bb102
bb98:
  br label %bb99
bb99:
  %t406 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t406, ptr %l258, !tbaa !27
  %t407 = load i64, ptr %l31, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l258, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr i64, ptr %t410, i64 %t407
  %t412 = load i64, ptr %t411, !tbaa !34
  %t414 = load ptr, ptr %l26, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t414, i64 %t412)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s18)
  br label %bb101
bb101:
  %t418 = load i64, ptr %l31, !tbaa !24
  %t420 = add i64 %t418, 1
  store i64 %t420, ptr %l31, !tbaa !24
  br label %bb96
bb102:
  %t422 = load i64, ptr %l28, !tbaa !24
  %t423 = load i64, ptr %l30, !tbaa !24
  %t426 = add i64 %t422, %t423
  store i64 %t426, ptr %l28, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb103
bb103:
  br label %bb89
bb104:
  %t428 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  store i64 %t428, ptr %l33, !tbaa !24
  store i1 true, ptr %l34, !tbaa !21
  %t430 = load ptr, ptr %l3, !tbaa !29
  %t432 = getelementptr %"compiler/free:mustW", ptr %t430, i32 0, i32 6
  store ptr %t432, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb105
bb105:
  store %olang.scope zeroinitializer, ptr %s21
  %t434 = load ptr, ptr %l35, !tbaa !29
  %t435 = load i64, ptr %l36, !tbaa !24
  %t438 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eRun_H53a7d26114b960961c1fb4b8403d34c1(ptr %v0, ptr %t434, i64 %t435)
  %t439 = extractvalue { i32, { i64, ptr } } %t438, 1
  %t440 = extractvalue { i32, { i64, ptr } } %t438, 0
  store i32 %t440, ptr %l275
  %t441 = icmp ne i32 %t440, 0
  br i1 %t441, label %bb107, label %ok.442
ok.442:
  store { i64, ptr } %t439, ptr %l274
  br label %bb106
bb106:
  %t443 = load { i64, ptr }, ptr %l274, !tbaa !27
  store { i64, ptr } %t443, ptr %l271, !tbaa !27
  br label %bb111
bb107:
  %t444 = load i32, ptr %l275, !tbaa !23
  %t445 = ashr i32 %t444, 16
  %t447 = icmp eq i32 %t445, 1
  br i1 %t447, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @olang_loc_81cc61a90592fd0c_27b8446ae48616e0)
  unreachable
bb110:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s21)
  br label %bb125
bb111:
  %t449 = load { i64, ptr }, ptr %l271, !tbaa !27
  store { i64, ptr } %t449, ptr %l37, !tbaa !27
  %t450 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t450, 0
  store i64 %t452, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s22
  %t454 = load i64, ptr %l39, !tbaa !24
  %t455 = load i64, ptr %l38, !tbaa !24
  %t458 = icmp slt i64 %t454, %t455
  %t460 = xor i1 %t458, true
  br i1 %t460, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s22)
  br label %bb123
bb114:
  br label %bb115
bb115:
  %t462 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t462, ptr %l284, !tbaa !27
  %t463 = load i64, ptr %l39, !tbaa !24
  %t465 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !27
  %t467 = getelementptr ptr, ptr %t466, i64 %t463
  %t468 = load ptr, ptr %t467, !tbaa !39
  store ptr %t468, ptr %l40, !tbaa !29
  %t470 = load i64, ptr %l33, !tbaa !24
  store i64 %t470, ptr %l287, !tbaa !24
  %t471 = load ptr, ptr %l3, !tbaa !29
  %t472 = load ptr, ptr %l40, !tbaa !29
  %t475 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v0, ptr %t471, ptr %t472)
  store i64 %t475, ptr %l290
  br label %bb116
bb116:
  %t476 = load i64, ptr %l287, !tbaa !24
  %t477 = load i64, ptr %l290, !tbaa !24
  %t478 = call i64 @compiler_2ffree_2emeet(i64 %t476, i64 %t477)
  store i64 %t478, ptr %l291
  br label %bb117
bb117:
  %t479 = load i64, ptr %l291, !tbaa !24
  store i64 %t479, ptr %l33, !tbaa !24
  %t480 = load ptr, ptr %l3, !tbaa !29
  %t481 = load ptr, ptr %l40, !tbaa !29
  %t484 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v0, ptr %t480, ptr %t481, i64 0)
  store i1 %t484, ptr %l294
  br label %bb118
bb118:
  %t485 = load i1, ptr %l294, !tbaa !21
  %t486 = xor i1 %t485, true
  br i1 %t486, label %bb119, label %bb120
bb119:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb121
bb120:
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s22)
  br label %bb122
bb122:
  %t488 = load i64, ptr %l39, !tbaa !24
  %t490 = add i64 %t488, 1
  store i64 %t490, ptr %l39, !tbaa !24
  br label %bb112
bb123:
  %t492 = load i64, ptr %l36, !tbaa !24
  %t493 = load i64, ptr %l38, !tbaa !24
  %t496 = add i64 %t492, %t493
  store i64 %t496, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s21)
  br label %bb124
bb124:
  br label %bb105
bb125:
  %t498 = load i64, ptr %l33, !tbaa !24
  store i64 %t498, ptr %l301, !tbaa !24
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t501 = getelementptr %"compiler/free:Free", ptr %t499, i32 0, i32 26
  %t502 = load i64, ptr %l1, !tbaa !24
  %t505 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t501, i64 %t502)
  store i64 %t505, ptr %l305
  br label %bb126
bb126:
  %t506 = load i64, ptr %l301, !tbaa !24
  %t507 = load i64, ptr %l305, !tbaa !24
  %t508 = icmp ne i64 %t506, %t507
  br i1 %t508, label %bb127, label %bb128
bb127:
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t512 = getelementptr %"compiler/free:Free", ptr %t510, i32 0, i32 26
  %t513 = load i64, ptr %l1, !tbaa !24
  %t514 = load i64, ptr %l33, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t512, i64 %t513, i64 %t514)
  br label %bb129
bb128:
  br label %bb130
bb129:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t520 = getelementptr %"compiler/free:Free", ptr %t518, i32 0, i32 30
  store i1 true, ptr %t520, !tbaa !21
  br label %bb130
bb130:
  %t521 = load i1, ptr %l34, !tbaa !21
  store i1 %t521, ptr %l312, !tbaa !21
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t524 = getelementptr %"compiler/free:Free", ptr %t522, i32 0, i32 27
  %t525 = load i64, ptr %l1, !tbaa !24
  %t528 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t524, i64 %t525)
  store i1 %t528, ptr %l316
  br label %bb131
bb131:
  %t529 = load i1, ptr %l312, !tbaa !21
  %t530 = load i1, ptr %l316, !tbaa !21
  %t531 = icmp ne i1 %t529, %t530
  br i1 %t531, label %bb132, label %bb133
bb132:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t535 = getelementptr %"compiler/free:Free", ptr %t533, i32 0, i32 27
  %t536 = load i64, ptr %l1, !tbaa !24
  %t539 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t535, i64 %t536)
  store i1 %t539, ptr %l322
  br label %bb134
bb133:
  store i1 false, ptr %l318, !tbaa !21
  br label %bb135
bb134:
  %t540 = load i1, ptr %l322, !tbaa !21
  store i1 %t540, ptr %l318, !tbaa !21
  br label %bb135
bb135:
  %t541 = load i1, ptr %l318, !tbaa !21
  br i1 %t541, label %bb136, label %bb137
bb136:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t544 = getelementptr %"compiler/free:Free", ptr %t542, i32 0, i32 27
  %t545 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t544, i64 %t545, i1 false)
  br label %bb138
bb137:
  br label %bb139
bb138:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t550 = getelementptr %"compiler/free:Free", ptr %t548, i32 0, i32 30
  store i1 true, ptr %t550, !tbaa !21
  br label %bb139
bb139:
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t553 = getelementptr %"compiler/free:Free", ptr %t551, i32 0, i32 45
  %t554 = load i64, ptr %l1, !tbaa !24
  %t557 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t553, i64 %t554)
  store ptr %t557, ptr %l330
  br label %bb140
bb140:
  %t558 = load ptr, ptr %l330, !tbaa !29
  store ptr %t558, ptr %l41, !tbaa !29
  %t559 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t559)
  br label %bb141
bb141:
  %t561 = load ptr, ptr %l3, !tbaa !29
  %t563 = getelementptr %"compiler/free:mustW", ptr %t561, i32 0, i32 2
  store ptr %t563, ptr %l42, !tbaa !29
  store i64 0, ptr %l43, !tbaa !24
  br label %bb142
bb142:
  store %olang.scope zeroinitializer, ptr %s28
  %t565 = load ptr, ptr %l42, !tbaa !29
  %t566 = load i64, ptr %l43, !tbaa !24
  %t569 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t565, i64 %t566)
  %t570 = extractvalue { i32, { i64, ptr } } %t569, 1
  %t571 = extractvalue { i32, { i64, ptr } } %t569, 0
  store i32 %t571, ptr %l338
  %t572 = icmp ne i32 %t571, 0
  br i1 %t572, label %bb144, label %ok.573
ok.573:
  store { i64, ptr } %t570, ptr %l337
  br label %bb143
bb143:
  %t574 = load { i64, ptr }, ptr %l337, !tbaa !27
  store { i64, ptr } %t574, ptr %l334, !tbaa !27
  br label %bb148
bb144:
  %t575 = load i32, ptr %l338, !tbaa !23
  %t576 = ashr i32 %t575, 16
  %t578 = icmp eq i32 %t576, 1
  br i1 %t578, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  call void @__olang_check_failed(ptr @olang_loc_377f9dc3f8b5b43d_2adc919691629af1)
  unreachable
bb147:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s28)
  br label %bb157
bb148:
  %t580 = load { i64, ptr }, ptr %l334, !tbaa !27
  store { i64, ptr } %t580, ptr %l44, !tbaa !27
  %t581 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t583 = extractvalue { i64, ptr } %t581, 0
  store i64 %t583, ptr %l45, !tbaa !24
  store i64 0, ptr %l46, !tbaa !24
  br label %bb149
bb149:
  store %olang.scope zeroinitializer, ptr %s29
  %t585 = load i64, ptr %l46, !tbaa !24
  %t586 = load i64, ptr %l45, !tbaa !24
  %t589 = icmp slt i64 %t585, %t586
  %t591 = xor i1 %t589, true
  br i1 %t591, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s29)
  br label %bb155
bb151:
  br label %bb152
bb152:
  %t593 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t593, ptr %l347, !tbaa !27
  %t594 = load i64, ptr %l46, !tbaa !24
  %t596 = getelementptr { i64, ptr }, ptr %l347, i32 0, i32 1
  %t597 = load ptr, ptr %t596, !tbaa !27
  %t598 = getelementptr i64, ptr %t597, i64 %t594
  %t599 = load i64, ptr %t598, !tbaa !34
  %t601 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t601, i64 %t599)
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s29)
  br label %bb154
bb154:
  %t605 = load i64, ptr %l46, !tbaa !24
  %t607 = add i64 %t605, 1
  store i64 %t607, ptr %l46, !tbaa !24
  br label %bb149
bb155:
  %t609 = load i64, ptr %l43, !tbaa !24
  %t610 = load i64, ptr %l45, !tbaa !24
  %t613 = add i64 %t609, %t610
  store i64 %t613, ptr %l43, !tbaa !24
  call void @__olang_scope_close(ptr %s28)
  br label %bb156
bb156:
  br label %bb142
bb157:
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t617 = getelementptr %"compiler/free:Free", ptr %t615, i32 0, i32 47
  %t618 = load i64, ptr %l1, !tbaa !24
  %t621 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H96e9eb9990b7b2982627078c49255e88(ptr %v0, ptr %v0, ptr %t617, i64 %t618)
  store ptr %t621, ptr %l360
  br label %bb158
bb158:
  %t622 = load ptr, ptr %l360, !tbaa !29
  store ptr %t622, ptr %l48, !tbaa !29
  %t623 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t623)
  br label %bb159
bb159:
  store i64 0, ptr %l49, !tbaa !24
  %t625 = load ptr, ptr %l2, !tbaa !29
  %t627 = getelementptr %"compiler/typed:Body", ptr %t625, i32 0, i32 7
  %t629 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t627)
  store i64 %t629, ptr %l364
  br label %bb160
bb160:
  %t630 = load i64, ptr %l364, !tbaa !24
  store i64 %t630, ptr %l50, !tbaa !24
  store i64 1, ptr %l51, !tbaa !24
  %t631 = load i64, ptr %l50, !tbaa !24
  %t632 = load i64, ptr %l49, !tbaa !24
  %t635 = icmp sgt i64 %t631, %t632
  br i1 %t635, label %bb161, label %bb162
bb161:
  %t637 = load i64, ptr %l51, !tbaa !24
  %t639 = icmp sgt i64 %t637, 0
  br i1 %t639, label %bb163, label %bb164
bb162:
  store i64 0, ptr %l368, !tbaa !24
  br label %bb166
bb163:
  %t641 = load i64, ptr %l50, !tbaa !24
  %t642 = load i64, ptr %l49, !tbaa !24
  %t645 = sub i64 %t641, %t642
  %t646 = load i64, ptr %l51, !tbaa !24
  %t649 = add i64 %t645, %t646
  %t651 = sub i64 %t649, 1
  %t652 = load i64, ptr %l51, !tbaa !24
  %t655 = sdiv i64 %t651, %t652
  store i64 %t655, ptr %l371, !tbaa !24
  br label %bb165
bb164:
  store i64 0, ptr %l371, !tbaa !24
  br label %bb165
bb165:
  %t657 = load i64, ptr %l371, !tbaa !24
  store i64 %t657, ptr %l368, !tbaa !24
  br label %bb166
bb166:
  %t658 = load i64, ptr %l368, !tbaa !24
  store i64 %t658, ptr %l52, !tbaa !24
  store i64 0, ptr %l53, !tbaa !24
  br label %bb167
bb167:
  store %olang.scope zeroinitializer, ptr %s32
  %t659 = load i64, ptr %l53, !tbaa !24
  %t660 = load i64, ptr %l52, !tbaa !24
  %t663 = icmp slt i64 %t659, %t660
  %t665 = xor i1 %t663, true
  br i1 %t665, label %bb168, label %bb169
bb168:
  call void @__olang_scope_close(ptr %s32)
  br label %bb174
bb169:
  br label %bb170
bb170:
  %t667 = load i64, ptr %l49, !tbaa !24
  %t668 = load i64, ptr %l53, !tbaa !24
  %t669 = load i64, ptr %l51, !tbaa !24
  %t672 = mul i64 %t668, %t669
  %t675 = add i64 %t667, %t672
  %t677 = load ptr, ptr %l48, !tbaa !29
  store ptr %t677, ptr %l389, !tbaa !29
  %t678 = load ptr, ptr %l3, !tbaa !29
  %t682 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efreshLocal(ptr %v0, ptr %t678, i64 %t675)
  store i1 %t682, ptr %l392
  br label %bb171
bb171:
  %t683 = load ptr, ptr %l389, !tbaa !29
  %t684 = load i1, ptr %l392, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t683, i1 %t684)
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s32)
  br label %bb173
bb173:
  %t685 = load i64, ptr %l53, !tbaa !24
  %t687 = add i64 %t685, 1
  store i64 %t687, ptr %l53, !tbaa !24
  br label %bb167
bb174:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3, i32 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/free:reason"
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 8
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t9, i32 %a1)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t15, i64 %a2)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/free:Free", ptr %t19, i32 0, i32 10
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t21, i1 %a3)
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/free:Free", ptr %t25, i32 0, i32 11
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t27, i32 %a4)
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 36
  %t34 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t33, i64 %t34)
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:Free", ptr %t37, i32 0, i32 37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t39, i1 false)
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/free:Free", ptr %t41, i32 0, i32 38
  store ptr %t43, ptr %l28, !tbaa !29
  %t44 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  store i64 %t44, ptr %l29, !tbaa !24
  %t45 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t45, ptr %l30
  br label %bb8
bb8:
  %t46 = load i64, ptr %l29, !tbaa !24
  %t47 = load %"compiler/source:Span", ptr %l30
  %t48 = call %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v0, i64 %t46, i64 -1, %"compiler/source:Span" %t47, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store %"compiler/free:reason" %t48, ptr %l31
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l28, !tbaa !29
  %t50 = load %"compiler/free:reason", ptr %l31
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2ePush_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t49, %"compiler/free:reason" %t50)
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/free:Free", ptr %t51, i32 0, i32 62
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t53, i1 %a5)
  br label %bb11
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:Free", ptr %t57, i32 0, i32 63
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t59, i1 false)
  br label %bb12
bb12:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/free:Free", ptr %t61, i32 0, i32 64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t63, i1 false)
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 54
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t67, i64 -1)
  br label %bb14
bb14:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:Free", ptr %t69, i32 0, i32 55
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t71, i64 -1)
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 56
  store ptr %t75, ptr %l44, !tbaa !29
  %t76 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t76, ptr %l45
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l44, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l45
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t77, %"compiler/source:Span" %t78)
  br label %bb17
bb17:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/free:Free", ptr %t79, i32 0, i32 57
  store ptr %t81, ptr %l47, !tbaa !29
  %t82 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t82, ptr %l48
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l47, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l48
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t83, %"compiler/source:Span" %t84)
  br label %bb19
bb19:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:Free", ptr %t85, i32 0, i32 58
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t87, i1 false)
  br label %bb20
bb20:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/free:Free", ptr %t89, i32 0, i32 59
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t91, i1 false)
  br label %bb21
bb21:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/free:Free", ptr %t93, i32 0, i32 60
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t95, i1 false)
  br label %bb22
bb22:
  %t97 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i64
  %l49 = alloca i64
  %l57 = alloca ptr
  %l60 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t7, -3
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb26
bb4:
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l3
  %t23 = load { i64, [2 x i64] }, ptr %l3
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l25
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t44, i64 %t45)
  store i64 %t46, ptr %l26
  br label %bb9
bb9:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb25
bb10:
  %t48 = load { i64, [2 x i64] }, ptr %l3
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t54 = getelementptr { i32, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t57)
  store ptr %t59, ptr %l31
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t60)
  store ptr %t62, ptr %l33
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t63)
  store ptr %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i32, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t67, i32 %t66)
  store i32 %t69, ptr %l37
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l38
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l31, !tbaa !29
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t75, ptr %l39
  br label %bb19
bb19:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_997f49c366488af5_93d2651ee5683809)
  unreachable
bb25:
  br label %bb26
bb26:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t80 = icmp slt i64 %t78, 0
  br i1 %t80, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb30
bb28:
  %t82 = load i64, ptr %l2, !tbaa !24
  store i64 %t82, ptr %l44, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:Free", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/load:Loader", ptr %t89, i32 0, i32 5
  %t93 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l49
  br label %bb29
bb29:
  %t94 = load i64, ptr %l44, !tbaa !24
  %t95 = load i64, ptr %l49, !tbaa !24
  %t96 = icmp sge i64 %t94, %t95
  store i1 %t96, ptr %l43, !tbaa !21
  br label %bb30
bb30:
  %t98 = load i1, ptr %l43, !tbaa !21
  br i1 %t98, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/free:Free", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/load:Loader", ptr %t106, i32 0, i32 5
  %t109 = load i64, ptr %l2, !tbaa !24
  %t112 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t108, i64 %t109)
  store ptr %t112, ptr %l57
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l57, !tbaa !29
  %t115 = getelementptr %"compiler/load:Module", ptr %t113, i32 0, i32 2
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t116, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t118, ptr %l60
  br label %bb35
bb35:
  %t119 = load i1, ptr %l60, !tbaa !21
  %t120 = xor i1 %t119, true
  call void @__olang_scope_close(ptr %s0)
  store i1 %t120, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l23 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l24 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i32
  %l35 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i32
  %l46 = alloca i32
  %l51 = alloca i32
  %l54 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i32
  %l66 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i32
  %l78 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l92 = alloca i1
  %l95 = alloca i1
  %l98 = alloca i1
  %l101 = alloca i1
  %l104 = alloca i1
  %l117 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l14, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  store ptr %t5, ptr %l15, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l18
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l15, !tbaa !29
  %t12 = load i32, ptr %l18, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l19
  br label %bb3
bb3:
  %t14 = load i32, ptr %l19, !tbaa !23
  store i32 %t14, ptr %l4, !tbaa !23
  %t15 = load i32, ptr %l4, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t17, i64 %t18)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t21, ptr %l23
  br label %bb4
bb4:
  %t22 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l23
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t22, ptr %l5
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:Free", ptr %t23, i32 0, i32 13
  %t26 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t29 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t25, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t26)
  %t30 = extractvalue { i32, i64 } %t29, 1
  %t31 = extractvalue { i32, i64 } %t29, 0
  store i32 %t31, ptr %l29
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb6, label %ok.33
ok.33:
  store i64 %t30, ptr %l28
  br label %bb5
bb5:
  %t34 = load i64, ptr %l28, !tbaa !24
  store i64 %t34, ptr %l24, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp eq i64 %t36, 1
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp eq i64 %t41, 2
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/free:Free", ptr %t45, i32 0, i32 12
  %t48 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t51 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t47, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t48)
  %t52 = extractvalue { i32, i64 } %t51, 1
  %t53 = extractvalue { i32, i64 } %t51, 0
  store i32 %t53, ptr %l40
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb15, label %ok.55
ok.55:
  store i64 %t52, ptr %l39
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t56 = load i64, ptr %l39, !tbaa !24
  store i64 %t56, ptr %l35, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i64, ptr %l35, !tbaa !24
  store i64 %t57, ptr %rv
  br label %ret
bb18:
  store i1 false, ptr %l7, !tbaa !21
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t58, ptr %l8, !tbaa !23
  store i1 false, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = icmp slt i64 %t60, 0
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t65 = load i32, ptr %l4, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l46
  br label %bb21
bb20:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t70 = load i32, ptr %l4, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l63
  br label %bb34
bb21:
  %t74 = load i32, ptr %l46
  %t76 = trunc i64 19 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t80 = load i32, ptr %l4, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l51
  br label %bb24
bb23:
  br label %bb33
bb24:
  %t84 = load i32, ptr %l51, !tbaa !23
  store i32 %t84, ptr %l8, !tbaa !23
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l8, !tbaa !23
  %t89 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %t85, i32 %t86)
  store i1 %t89, ptr %l54
  br label %bb25
bb25:
  %t90 = load i1, ptr %l54, !tbaa !21
  store i1 %t90, ptr %l7, !tbaa !21
  %t91 = load i1, ptr %l7, !tbaa !21
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb26, label %bb27
bb26:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l8, !tbaa !23
  %t99 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edtorCand(ptr %v0, ptr %t95, i32 %t96)
  store i1 %t99, ptr %l60
  br label %bb28
bb27:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb29
bb28:
  %t100 = load i1, ptr %l60, !tbaa !21
  store i1 %t100, ptr %l57, !tbaa !21
  br label %bb29
bb29:
  %t101 = load i1, ptr %l57, !tbaa !21
  br i1 %t101, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l7, !tbaa !21
  store i1 true, ptr %l10, !tbaa !21
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb67
bb34:
  %t102 = load i32, ptr %l63
  %t104 = trunc i64 18 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb35, label %bb36
bb35:
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t108 = load i32, ptr %l4, !tbaa !23
  %t111 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l69
  br label %bb37
bb36:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb38
bb37:
  %t112 = load i1, ptr %l69, !tbaa !21
  store i1 %t112, ptr %l66, !tbaa !21
  br label %bb38
bb38:
  %t113 = load i1, ptr %l66, !tbaa !21
  br i1 %t113, label %bb39, label %bb40
bb39:
  %t114 = load ptr, ptr %l3, !tbaa !29
  store ptr %t114, ptr %l71, !tbaa !29
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t116 = load i32, ptr %l4, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l74
  br label %bb41
bb40:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb43
bb41:
  %t120 = load ptr, ptr %l71, !tbaa !29
  %t121 = load i32, ptr %l74, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t122, ptr %l75
  br label %bb42
bb42:
  %t123 = load i32, ptr %l75
  %t125 = trunc i64 0 to i32
  %t126 = icmp eq i32 %t123, %t125
  store i1 %t126, ptr %l70, !tbaa !21
  br label %bb43
bb43:
  %t128 = load i1, ptr %l70, !tbaa !21
  br i1 %t128, label %bb44, label %bb45
bb44:
  %t129 = load ptr, ptr %l3, !tbaa !29
  store ptr %t129, ptr %l78, !tbaa !29
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t131 = load i32, ptr %l4, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t134, ptr %l81
  br label %bb46
bb45:
  br label %bb66
bb46:
  %t135 = load ptr, ptr %l78, !tbaa !29
  %t136 = load i32, ptr %l81, !tbaa !23
  %t137 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t135, i32 %t136)
  store { i64, ptr } %t137, ptr %l82
  br label %bb47
bb47:
  %t138 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t138, ptr %l11, !tbaa !27
  %t139 = load i64, ptr %l2, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t145 = icmp slt i64 %t139, %t142
  br i1 %t145, label %bb48, label %bb49
bb48:
  %t147 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t147, ptr %l87, !tbaa !27
  %t148 = load i64, ptr %l2, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 %t148
  %t153 = load i32, ptr %t152, !tbaa !33
  store i32 %t153, ptr %l8, !tbaa !23
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l8, !tbaa !23
  %t159 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %t155, i32 %t156)
  store i1 %t159, ptr %l92
  br label %bb50
bb49:
  br label %bb65
bb50:
  %t160 = load i1, ptr %l92, !tbaa !21
  store i1 %t160, ptr %l7, !tbaa !21
  %t161 = load i1, ptr %l7, !tbaa !21
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb51, label %bb52
bb51:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i32, ptr %l8, !tbaa !23
  %t169 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandleCand(ptr %v0, ptr %t165, i32 %t166)
  store i1 %t169, ptr %l98
  br label %bb53
bb52:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb54
bb53:
  %t170 = load i1, ptr %l98, !tbaa !21
  store i1 %t170, ptr %l95, !tbaa !21
  br label %bb54
bb54:
  %t171 = load i1, ptr %l95, !tbaa !21
  br i1 %t171, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l7, !tbaa !21
  store i1 true, ptr %l9, !tbaa !21
  br label %bb57
bb56:
  br label %bb57
bb57:
  %t172 = load i1, ptr %l7, !tbaa !21
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb58, label %bb59
bb58:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l8, !tbaa !23
  %t180 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edtorCand(ptr %v0, ptr %t176, i32 %t177)
  store i1 %t180, ptr %l104
  br label %bb60
bb59:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb61
bb60:
  %t181 = load i1, ptr %l104, !tbaa !21
  store i1 %t181, ptr %l101, !tbaa !21
  br label %bb61
bb61:
  %t182 = load i1, ptr %l101, !tbaa !21
  br i1 %t182, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l7, !tbaa !21
  store i1 true, ptr %l10, !tbaa !21
  br label %bb64
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t183 = load i1, ptr %l7, !tbaa !21
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb68, label %bb69
bb68:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/free:Free", ptr %t187, i32 0, i32 13
  %t190 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t189, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t190, i64 1)
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb71:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l4, !tbaa !23
  %t196 = load i64, ptr %l2, !tbaa !24
  %t197 = load i1, ptr %l9, !tbaa !21
  %t198 = load i32, ptr %l8, !tbaa !23
  %t199 = load i1, ptr %l10, !tbaa !21
  %t206 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %t194, i32 %t195, i64 %t196, i1 %t197, i32 %t198, i1 %t199)
  store i64 %t206, ptr %l117
  br label %bb72
bb72:
  %t207 = load i64, ptr %l117, !tbaa !24
  store i64 %t207, ptr %l12, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/free:Free", ptr %t208, i32 0, i32 12
  %t211 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t212 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t210, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t211, i64 %t212)
  br label %bb73
bb73:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/free:Free", ptr %t216, i32 0, i32 13
  %t219 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t218, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t219, i64 2)
  br label %bb74
bb74:
  %t222 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t222, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i1 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca %"compiler/typed:Plan"
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l39 = alloca %"compiler/typed:Plan"
  %l44 = alloca ptr
  %l45 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, [1 x i64] }
  %l58 = alloca { i64, [1 x i64] }
  %l60 = alloca i1
  %l61 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca i1
  %l81 = alloca i1
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l88 = alloca { i64, [1 x i64] }
  %l90 = alloca { i64, [1 x i64] }
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l117 = alloca i1
  %l123 = alloca i1
  %l124 = alloca { i64, ptr }
  %l128 = alloca { i64, [1 x i64] }
  %l130 = alloca { i64, [1 x i64] }
  %l132 = alloca i1
  %l133 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l139 = alloca i1
  %l145 = alloca i1
  %l146 = alloca { i64, ptr }
  %l150 = alloca { i64, [1 x i64] }
  %l152 = alloca { i64, [1 x i64] }
  %l154 = alloca i1
  %l155 = alloca { i64, ptr }
  %l160 = alloca ptr
  %l161 = alloca i1
  %l168 = alloca i64
  %l171 = alloca i1
  %l175 = alloca i1
  %l179 = alloca ptr
  %l185 = alloca i64
  %l187 = alloca ptr
  %l191 = alloca ptr
  %l194 = alloca i64
  %l199 = alloca i1
  %l202 = alloca i1
  %l207 = alloca i1
  %l212 = alloca { i64, [1 x i64] }
  %l214 = alloca { i64, [1 x i64] }
  %l216 = alloca i1
  %l224 = alloca i64
  %l230 = alloca i64
  %l233 = alloca i64
  %l252 = alloca i64
  %l269 = alloca i64
  %l272 = alloca i64
  %l293 = alloca i64
  %l296 = alloca i1
  %l299 = alloca i1
  %l301 = alloca i64
  %l308 = alloca { i64, ptr }
  %l315 = alloca ptr
  %l316 = alloca i1
  %s6 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %t5 = alloca %"compiler/typed:Plan", align 8
  %t12 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  store i1 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t5, ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  call void @llvm.memmove.p0.p0.i64(ptr %l39, ptr %t5, i64 152, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l39, i64 152, i1 false)
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = trunc i64 %t8 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t12
  %t13 = getelementptr { i64, [1 x i64] }, ptr %t12, i32 0, i32 0
  store i64 4, ptr %t13
  %t15 = insertvalue { i32 } undef, i32 %t10, 0
  %t16 = getelementptr { i64, [1 x i64] }, ptr %t12, i32 0, i32 1
  store { i32 } %t15, ptr %t16
  %t17 = load { i64, [1 x i64] }, ptr %t12
  store { i64, [1 x i64] } %t17, ptr %l8
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t20 = load ptr, ptr %l44, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load ptr, ptr %l44, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 5
  store i1 %t26, ptr %l45, !tbaa !21
  br label %bb3
bb3:
  %t27 = load i1, ptr %l45, !tbaa !21
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l9, !tbaa !29
  br label %bb6
bb5:
  br label %bb15
bb6:
  %t34 = load i1, ptr %l5, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb10
bb8:
  %t36 = getelementptr %"compiler/typed:Plan", ptr %l7, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l52, !tbaa !27
  %t38 = load ptr, ptr %l9, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Promote", ptr %t38, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t45 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, [1 x i64] }, ptr %t46, i64 %t43
  %t48 = load { i64, [1 x i64] }, ptr %t47
  store { i64, [1 x i64] } %t48, ptr %l56
  %t49 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t49, ptr %l58
  %t52 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l56, ptr %l58)
  store i1 %t52, ptr %l60
  br label %bb9
bb9:
  %t53 = load i1, ptr %l60, !tbaa !21
  store i1 %t53, ptr %l51, !tbaa !21
  br label %bb10
bb10:
  %t54 = load i1, ptr %l51, !tbaa !21
  br i1 %t54, label %bb11, label %bb12
bb11:
  %t55 = getelementptr %"compiler/typed:Plan", ptr %l7, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l61, !tbaa !27
  %t57 = load ptr, ptr %l9, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Promote", ptr %t57, i32 0, i32 1
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = sext i32 %t60 to i64
  %t63 = load { i64, [1 x i64] }, ptr %l8
  %t66 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, [1 x i64] }, ptr %t67, i64 %t62
  store { i64, [1 x i64] } %t63, ptr %t68
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l1, !tbaa !24
  %t71 = load ptr, ptr %l9, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Promote", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i64, ptr %l3, !tbaa !24
  %t76 = load { i64, [1 x i64] }, ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t69, i64 %t70, ptr %t74, i64 %t75, { i64, [1 x i64] } %t76, i1 false, i1 true)
  br label %bb14
bb14:
  br label %bb157
bb15:
  %t82 = load ptr, ptr %l2, !tbaa !29
  store ptr %t82, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t83 = load ptr, ptr %l72, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb16, label %bb17
bb16:
  %t86 = load ptr, ptr %l72, !tbaa !29
  %t87 = load i64, ptr %t86
  %t89 = icmp eq i64 %t87, 7
  store i1 %t89, ptr %l73, !tbaa !21
  br label %bb17
bb17:
  %t90 = load i1, ptr %l73, !tbaa !21
  br i1 %t90, label %bb18, label %bb19
bb18:
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr { i64, [5 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t93, i32 0, i32 2
  %t95 = load ptr, ptr %t94
  store ptr %t95, ptr %l10, !tbaa !29
  br label %bb20
bb19:
  br label %bb38
bb20:
  %t97 = load ptr, ptr %l10, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Make", ptr %t97, i32 0, i32 4
  %t100 = load i32, ptr %t99, !tbaa !23
  %t102 = icmp sge i32 %t100, 0
  br i1 %t102, label %bb21, label %bb22
bb21:
  %t104 = load i1, ptr %l5, !tbaa !21
  br i1 %t104, label %bb23, label %bb24
bb22:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb27
bb23:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb26
bb24:
  %t106 = getelementptr %"compiler/typed:Plan", ptr %l7, i32 0, i32 0
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  store { i64, ptr } %t107, ptr %l84, !tbaa !27
  %t108 = load ptr, ptr %l10, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Make", ptr %t108, i32 0, i32 4
  %t111 = load i32, ptr %t110, !tbaa !23
  %t113 = sext i32 %t111 to i64
  %t115 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, [1 x i64] }, ptr %t116, i64 %t113
  %t118 = load { i64, [1 x i64] }, ptr %t117
  store { i64, [1 x i64] } %t118, ptr %l88
  %t119 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t119, ptr %l90
  %t122 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l88, ptr %l90)
  store i1 %t122, ptr %l92
  br label %bb25
bb25:
  %t123 = load i1, ptr %l92, !tbaa !21
  store i1 %t123, ptr %l83, !tbaa !21
  br label %bb26
bb26:
  %t124 = load i1, ptr %l83, !tbaa !21
  store i1 %t124, ptr %l81, !tbaa !21
  br label %bb27
bb27:
  %t125 = load i1, ptr %l81, !tbaa !21
  br i1 %t125, label %bb28, label %bb29
bb28:
  %t126 = getelementptr %"compiler/typed:Plan", ptr %l7, i32 0, i32 0
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l93, !tbaa !27
  %t128 = load ptr, ptr %l10, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Make", ptr %t128, i32 0, i32 4
  %t131 = load i32, ptr %t130, !tbaa !23
  %t133 = sext i32 %t131 to i64
  %t134 = load { i64, [1 x i64] }, ptr %l8
  %t137 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr { i64, [1 x i64] }, ptr %t138, i64 %t133
  store { i64, [1 x i64] } %t134, ptr %t139
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t140 = load ptr, ptr %l10, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Make", ptr %t140, i32 0, i32 2
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t145 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  store i64 %t147, ptr %l13, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t149 = load i64, ptr %l12, !tbaa !24
  %t150 = load i64, ptr %l13, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t157 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t157, ptr %l106, !tbaa !27
  %t158 = load i64, ptr %l12, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr ptr, ptr %t161, i64 %t158
  %t163 = load ptr, ptr %t162, !tbaa !39
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i64, ptr %l1, !tbaa !24
  %t168 = load i64, ptr %l3, !tbaa !24
  %t169 = load { i64, [1 x i64] }, ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t165, i64 %t166, ptr %t163, i64 %t168, { i64, [1 x i64] } %t169, i1 false, i1 false)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  %t175 = load i64, ptr %l12, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l12, !tbaa !24
  br label %bb31
bb37:
  br label %bb157
bb38:
  %t179 = load ptr, ptr %l2, !tbaa !29
  store ptr %t179, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t180 = load ptr, ptr %l116, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb39, label %bb40
bb39:
  %t183 = load ptr, ptr %l116, !tbaa !29
  %t184 = load i64, ptr %t183
  %t186 = icmp eq i64 %t184, 16
  store i1 %t186, ptr %l117, !tbaa !21
  br label %bb40
bb40:
  %t187 = load i1, ptr %l117, !tbaa !21
  br i1 %t187, label %bb41, label %bb42
bb41:
  %t188 = load ptr, ptr %l2, !tbaa !29
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t190, i32 0, i32 2
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l15, !tbaa !29
  br label %bb43
bb42:
  br label %bb51
bb43:
  %t194 = load i1, ptr %l5, !tbaa !21
  br i1 %t194, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb47
bb45:
  %t196 = getelementptr %"compiler/typed:Plan", ptr %l7, i32 0, i32 0
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l124, !tbaa !27
  %t198 = load ptr, ptr %l15, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Text", ptr %t198, i32 0, i32 1
  %t201 = load i32, ptr %t200, !tbaa !23
  %t203 = sext i32 %t201 to i64
  %t205 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr { i64, [1 x i64] }, ptr %t206, i64 %t203
  %t208 = load { i64, [1 x i64] }, ptr %t207
  store { i64, [1 x i64] } %t208, ptr %l128
  %t209 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t209, ptr %l130
  %t212 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l128, ptr %l130)
  store i1 %t212, ptr %l132
  br label %bb46
bb46:
  %t213 = load i1, ptr %l132, !tbaa !21
  store i1 %t213, ptr %l123, !tbaa !21
  br label %bb47
bb47:
  %t214 = load i1, ptr %l123, !tbaa !21
  br i1 %t214, label %bb48, label %bb49
bb48:
  %t215 = getelementptr %"compiler/typed:Plan", ptr %l7, i32 0, i32 0
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  store { i64, ptr } %t216, ptr %l133, !tbaa !27
  %t217 = load ptr, ptr %l15, !tbaa !29
  %t219 = getelementptr %"compiler/typed:Text", ptr %t217, i32 0, i32 1
  %t220 = load i32, ptr %t219, !tbaa !23
  %t222 = sext i32 %t220 to i64
  %t223 = load { i64, [1 x i64] }, ptr %l8
  %t226 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr { i64, [1 x i64] }, ptr %t227, i64 %t222
  store { i64, [1 x i64] } %t223, ptr %t228
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb157
bb51:
  %t229 = load ptr, ptr %l2, !tbaa !29
  store ptr %t229, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t230 = load ptr, ptr %l138, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb52, label %bb53
bb52:
  %t233 = load ptr, ptr %l138, !tbaa !29
  %t234 = load i64, ptr %t233
  %t236 = icmp eq i64 %t234, 8
  store i1 %t236, ptr %l139, !tbaa !21
  br label %bb53
bb53:
  %t237 = load i1, ptr %l139, !tbaa !21
  br i1 %t237, label %bb54, label %bb55
bb54:
  %t238 = load ptr, ptr %l2, !tbaa !29
  %t240 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t240, i32 0, i32 2
  %t242 = load ptr, ptr %t241
  store ptr %t242, ptr %l16, !tbaa !29
  br label %bb56
bb55:
  br label %bb64
bb56:
  %t244 = load i1, ptr %l5, !tbaa !21
  br i1 %t244, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb60
bb58:
  %t246 = getelementptr %"compiler/typed:Plan", ptr %l7, i32 0, i32 0
  %t247 = load { i64, ptr }, ptr %t246, !tbaa !27
  store { i64, ptr } %t247, ptr %l146, !tbaa !27
  %t248 = load ptr, ptr %l16, !tbaa !29
  %t250 = getelementptr %"compiler/typed:Collect", ptr %t248, i32 0, i32 2
  %t251 = load i32, ptr %t250, !tbaa !23
  %t253 = sext i32 %t251 to i64
  %t255 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr { i64, [1 x i64] }, ptr %t256, i64 %t253
  %t258 = load { i64, [1 x i64] }, ptr %t257
  store { i64, [1 x i64] } %t258, ptr %l150
  %t259 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t259, ptr %l152
  %t262 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l150, ptr %l152)
  store i1 %t262, ptr %l154
  br label %bb59
bb59:
  %t263 = load i1, ptr %l154, !tbaa !21
  store i1 %t263, ptr %l145, !tbaa !21
  br label %bb60
bb60:
  %t264 = load i1, ptr %l145, !tbaa !21
  br i1 %t264, label %bb61, label %bb62
bb61:
  %t265 = getelementptr %"compiler/typed:Plan", ptr %l7, i32 0, i32 0
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  store { i64, ptr } %t266, ptr %l155, !tbaa !27
  %t267 = load ptr, ptr %l16, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Collect", ptr %t267, i32 0, i32 2
  %t270 = load i32, ptr %t269, !tbaa !23
  %t272 = sext i32 %t270 to i64
  %t273 = load { i64, [1 x i64] }, ptr %l8
  %t276 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, [1 x i64] }, ptr %t277, i64 %t272
  store { i64, [1 x i64] } %t273, ptr %t278
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb157
bb64:
  %t279 = load ptr, ptr %l2, !tbaa !29
  store ptr %t279, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t280 = load ptr, ptr %l160, !tbaa !29
  %t281 = icmp ne ptr %t280, null
  br i1 %t281, label %bb65, label %bb66
bb65:
  %t283 = load ptr, ptr %l160, !tbaa !29
  %t284 = load i64, ptr %t283
  %t286 = icmp eq i64 %t284, 6
  store i1 %t286, ptr %l161, !tbaa !21
  br label %bb66
bb66:
  %t287 = load i1, ptr %l161, !tbaa !21
  br i1 %t287, label %bb67, label %bb68
bb67:
  %t288 = load ptr, ptr %l2, !tbaa !29
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t288, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t290, i32 0, i32 2
  %t292 = load ptr, ptr %t291
  store ptr %t292, ptr %l17, !tbaa !29
  br label %bb69
bb68:
  br label %bb145
bb69:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load ptr, ptr %l17, !tbaa !29
  %t298 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t294, ptr %t295)
  store i64 %t298, ptr %l168
  br label %bb70
bb70:
  %t299 = load i64, ptr %l168, !tbaa !24
  store i64 %t299, ptr %l18, !tbaa !24
  %t300 = load i64, ptr %l18, !tbaa !24
  %t302 = icmp slt i64 %t300, 0
  br i1 %t302, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l171, !tbaa !21
  br label %bb73
bb72:
  %t304 = load ptr, ptr %l17, !tbaa !29
  %t306 = getelementptr %"compiler/typed:Call", ptr %t304, i32 0, i32 3
  %t307 = load i32, ptr %t306, !tbaa !23
  %t309 = icmp slt i32 %t307, 0
  store i1 %t309, ptr %l171, !tbaa !21
  br label %bb73
bb73:
  %t311 = load i1, ptr %l171, !tbaa !21
  br i1 %t311, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l175, !tbaa !21
  br label %bb77
bb75:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/free:Free", ptr %t312, i32 0, i32 1
  %t315 = load i64, ptr %l18, !tbaa !24
  %t318 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t314, i64 %t315)
  store ptr %t318, ptr %l179
  br label %bb76
bb76:
  %t319 = load ptr, ptr %l179, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Body", ptr %t319, i32 0, i32 11
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = icmp eq ptr %t322, null
  store i1 %t324, ptr %l175, !tbaa !21
  br label %bb77
bb77:
  %t326 = load i1, ptr %l175, !tbaa !21
  br i1 %t326, label %bb78, label %bb79
bb78:
  br label %ret
bb79:
  br label %bb80
bb80:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i64, ptr %l18, !tbaa !24
  %t331 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %t327, i64 %t328)
  store i64 %t331, ptr %l185
  br label %bb81
bb81:
  %t332 = load i64, ptr %l185, !tbaa !24
  store i64 %t332, ptr %l19, !tbaa !24
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t333)
  store ptr %t335, ptr %l187
  br label %bb82
bb82:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/free:Free", ptr %t336, i32 0, i32 1
  %t339 = load i64, ptr %l18, !tbaa !24
  %t342 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t338, i64 %t339)
  store ptr %t342, ptr %l191
  br label %bb83
bb83:
  %t343 = load ptr, ptr %l191, !tbaa !29
  %t345 = getelementptr %"compiler/typed:Body", ptr %t343, i32 0, i32 2
  %t346 = load i32, ptr %t345, !tbaa !23
  %t347 = load ptr, ptr %l187, !tbaa !29
  %t349 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t347, i32 %t346)
  store i64 %t349, ptr %l194
  br label %bb84
bb84:
  %t350 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t351 = load i64, ptr %l194, !tbaa !24
  %t353 = icmp eq i64 %t351, %t350
  store i1 %t353, ptr %l20, !tbaa !21
  %t355 = load i1, ptr %l5, !tbaa !21
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb85, label %bb86
bb85:
  %t359 = load i1, ptr %l20, !tbaa !21
  %t361 = xor i1 %t359, true
  store i1 %t361, ptr %l199, !tbaa !21
  br label %bb87
bb86:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb87
bb87:
  %t363 = load i1, ptr %l199, !tbaa !21
  br i1 %t363, label %bb88, label %bb89
bb88:
  %t364 = load i1, ptr %l6, !tbaa !21
  %t366 = xor i1 %t364, true
  store i1 %t366, ptr %l202, !tbaa !21
  br label %bb90
bb89:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb90
bb90:
  %t368 = load i1, ptr %l202, !tbaa !21
  br i1 %t368, label %bb91, label %bb92
bb91:
  br label %ret
bb92:
  br label %bb93
bb93:
  %t369 = load i1, ptr %l5, !tbaa !21
  %t371 = xor i1 %t369, true
  br i1 %t371, label %bb94, label %bb95
bb94:
  %t373 = load ptr, ptr %l17, !tbaa !29
  %t375 = getelementptr %"compiler/typed:Call", ptr %t373, i32 0, i32 3
  %t376 = load i32, ptr %t375, !tbaa !23
  %t377 = load i64, ptr %l19, !tbaa !24
  %t381 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %l7, i32 %t376, i64 %t377)
  store { i64, [1 x i64] } %t381, ptr %l212
  br label %bb96
bb95:
  store i1 false, ptr %l207, !tbaa !21
  br label %bb98
bb96:
  %t382 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t382, ptr %l214
  %t385 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l212, ptr %l214)
  store i1 %t385, ptr %l216
  br label %bb97
bb97:
  %t386 = load i1, ptr %l216, !tbaa !21
  %t387 = xor i1 %t386, true
  store i1 %t387, ptr %l207, !tbaa !21
  br label %bb98
bb98:
  %t389 = load i1, ptr %l207, !tbaa !21
  br i1 %t389, label %bb99, label %bb100
bb99:
  br label %ret
bb100:
  br label %bb101
bb101:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i64, ptr %l1, !tbaa !24
  %t392 = load ptr, ptr %l17, !tbaa !29
  %t393 = load i64, ptr %l18, !tbaa !24
  %t394 = load { i64, [1 x i64] }, ptr %l4
  %t395 = load i64, ptr %l19, !tbaa !24
  %t402 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %t390, i64 %t391, ptr %t392, i64 %t393, { i64, [1 x i64] } %t394, i64 %t395)
  store i64 %t402, ptr %l224
  br label %bb102
bb102:
  %t403 = load i64, ptr %l224, !tbaa !24
  store i64 %t403, ptr %l21, !tbaa !24
  %t404 = load i64, ptr %l21, !tbaa !24
  %t406 = icmp slt i64 %t404, 0
  br i1 %t406, label %bb103, label %bb104
bb103:
  br label %ret
bb104:
  br label %bb105
bb105:
  store i64 0, ptr %l22, !tbaa !24
  store i64 63, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t408 = load i64, ptr %l23, !tbaa !24
  %t409 = load i64, ptr %l22, !tbaa !24
  %t412 = icmp sgt i64 %t408, %t409
  br i1 %t412, label %bb106, label %bb107
bb106:
  %t414 = load i64, ptr %l24, !tbaa !24
  %t416 = icmp sgt i64 %t414, 0
  br i1 %t416, label %bb108, label %bb109
bb107:
  store i64 0, ptr %l230, !tbaa !24
  br label %bb111
bb108:
  %t418 = load i64, ptr %l23, !tbaa !24
  %t419 = load i64, ptr %l22, !tbaa !24
  %t422 = sub i64 %t418, %t419
  %t423 = load i64, ptr %l24, !tbaa !24
  %t426 = add i64 %t422, %t423
  %t428 = sub i64 %t426, 1
  %t429 = load i64, ptr %l24, !tbaa !24
  %t432 = sdiv i64 %t428, %t429
  store i64 %t432, ptr %l233, !tbaa !24
  br label %bb110
bb109:
  store i64 0, ptr %l233, !tbaa !24
  br label %bb110
bb110:
  %t434 = load i64, ptr %l233, !tbaa !24
  store i64 %t434, ptr %l230, !tbaa !24
  br label %bb111
bb111:
  %t435 = load i64, ptr %l230, !tbaa !24
  store i64 %t435, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s18
  %t436 = load i64, ptr %l26, !tbaa !24
  %t437 = load i64, ptr %l25, !tbaa !24
  %t440 = icmp slt i64 %t436, %t437
  %t442 = xor i1 %t440, true
  br i1 %t442, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s18)
  br label %bb121
bb114:
  br label %bb115
bb115:
  %t444 = load i64, ptr %l22, !tbaa !24
  %t445 = load i64, ptr %l26, !tbaa !24
  %t446 = load i64, ptr %l24, !tbaa !24
  %t449 = mul i64 %t445, %t446
  %t452 = add i64 %t444, %t449
  store i64 %t452, ptr %l27, !tbaa !24
  %t454 = load i64, ptr %l21, !tbaa !24
  %t455 = load i64, ptr %l27, !tbaa !24
  store i64 %t455, ptr %l252, !tbaa !24
  %t456 = load i64, ptr %l252, !tbaa !24
  %t457 = load i64, ptr %l252, !tbaa !24
  %t458 = shl i64 1, %t457
  %t461 = and i64 %t454, %t458
  %t463 = icmp ne i64 %t461, 0
  br i1 %t463, label %bb116, label %bb117
bb116:
  %t465 = load ptr, ptr %l17, !tbaa !29
  %t467 = getelementptr %"compiler/typed:Call", ptr %t465, i32 0, i32 3
  %t468 = load i32, ptr %t467, !tbaa !23
  %t469 = load i64, ptr %l27, !tbaa !24
  %t470 = load { i64, [1 x i64] }, ptr %l8
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %l7, i32 %t468, i64 %t469, { i64, [1 x i64] } %t470)
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s18)
  br label %bb120
bb120:
  %t475 = load i64, ptr %l26, !tbaa !24
  %t477 = add i64 %t475, 1
  store i64 %t477, ptr %l26, !tbaa !24
  br label %bb112
bb121:
  store i64 0, ptr %l28, !tbaa !24
  %t479 = load ptr, ptr %l17, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Call", ptr %t479, i32 0, i32 1
  %t482 = load { i64, ptr }, ptr %t481, !tbaa !27
  %t484 = extractvalue { i64, ptr } %t482, 0
  store i64 %t484, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t486 = load i64, ptr %l29, !tbaa !24
  %t487 = load i64, ptr %l28, !tbaa !24
  %t490 = icmp sgt i64 %t486, %t487
  br i1 %t490, label %bb122, label %bb123
bb122:
  %t492 = load i64, ptr %l30, !tbaa !24
  %t494 = icmp sgt i64 %t492, 0
  br i1 %t494, label %bb124, label %bb125
bb123:
  store i64 0, ptr %l269, !tbaa !24
  br label %bb127
bb124:
  %t496 = load i64, ptr %l29, !tbaa !24
  %t497 = load i64, ptr %l28, !tbaa !24
  %t500 = sub i64 %t496, %t497
  %t501 = load i64, ptr %l30, !tbaa !24
  %t504 = add i64 %t500, %t501
  %t506 = sub i64 %t504, 1
  %t507 = load i64, ptr %l30, !tbaa !24
  %t510 = sdiv i64 %t506, %t507
  store i64 %t510, ptr %l272, !tbaa !24
  br label %bb126
bb125:
  store i64 0, ptr %l272, !tbaa !24
  br label %bb126
bb126:
  %t512 = load i64, ptr %l272, !tbaa !24
  store i64 %t512, ptr %l269, !tbaa !24
  br label %bb127
bb127:
  %t513 = load i64, ptr %l269, !tbaa !24
  store i64 %t513, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb128
bb128:
  store %olang.scope zeroinitializer, ptr %s22
  %t514 = load i64, ptr %l32, !tbaa !24
  %t515 = load i64, ptr %l31, !tbaa !24
  %t518 = icmp slt i64 %t514, %t515
  %t520 = xor i1 %t518, true
  br i1 %t520, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s22)
  br label %bb144
bb130:
  br label %bb131
bb131:
  %t522 = load i64, ptr %l28, !tbaa !24
  %t523 = load i64, ptr %l32, !tbaa !24
  %t524 = load i64, ptr %l30, !tbaa !24
  %t527 = mul i64 %t523, %t524
  %t530 = add i64 %t522, %t527
  store i64 %t530, ptr %l33, !tbaa !24
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load i64, ptr %l18, !tbaa !24
  %t534 = load i64, ptr %l33, !tbaa !24
  %t538 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t532, i64 %t533, i64 %t534)
  store i64 %t538, ptr %l293
  br label %bb132
bb132:
  %t539 = load i64, ptr %l293, !tbaa !24
  store i64 %t539, ptr %l34, !tbaa !24
  %t540 = load i64, ptr %l34, !tbaa !24
  %t542 = icmp sge i64 %t540, 0
  br i1 %t542, label %bb133, label %bb134
bb133:
  %t544 = load i64, ptr %l34, !tbaa !24
  %t546 = icmp slt i64 %t544, 63
  store i1 %t546, ptr %l296, !tbaa !21
  br label %bb135
bb134:
  store i1 false, ptr %l296, !tbaa !21
  br label %bb135
bb135:
  %t548 = load i1, ptr %l296, !tbaa !21
  br i1 %t548, label %bb136, label %bb137
bb136:
  %t549 = load i64, ptr %l21, !tbaa !24
  %t550 = load i64, ptr %l34, !tbaa !24
  store i64 %t550, ptr %l301, !tbaa !24
  %t551 = load i64, ptr %l301, !tbaa !24
  %t552 = load i64, ptr %l301, !tbaa !24
  %t553 = shl i64 1, %t552
  %t556 = and i64 %t549, %t553
  %t558 = icmp ne i64 %t556, 0
  store i1 %t558, ptr %l299, !tbaa !21
  br label %bb138
bb137:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb138
bb138:
  %t560 = load i1, ptr %l299, !tbaa !21
  br i1 %t560, label %bb139, label %bb140
bb139:
  %t561 = load ptr, ptr %l0, !tbaa !29
  %t562 = load i64, ptr %l1, !tbaa !24
  %t563 = load ptr, ptr %l17, !tbaa !29
  %t565 = getelementptr %"compiler/typed:Call", ptr %t563, i32 0, i32 1
  %t566 = load { i64, ptr }, ptr %t565, !tbaa !27
  store { i64, ptr } %t566, ptr %l308, !tbaa !27
  %t567 = load i64, ptr %l33, !tbaa !24
  %t569 = getelementptr { i64, ptr }, ptr %l308, i32 0, i32 1
  %t570 = load ptr, ptr %t569, !tbaa !27
  %t571 = getelementptr ptr, ptr %t570, i64 %t567
  %t572 = load ptr, ptr %t571, !tbaa !39
  %t573 = load i64, ptr %l3, !tbaa !24
  %t574 = load { i64, [1 x i64] }, ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t561, i64 %t562, ptr %t572, i64 %t573, { i64, [1 x i64] } %t574, i1 false, i1 false)
  br label %bb141
bb140:
  br label %bb142
bb141:
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s22)
  br label %bb143
bb143:
  %t580 = load i64, ptr %l32, !tbaa !24
  %t582 = add i64 %t580, 1
  store i64 %t582, ptr %l32, !tbaa !24
  br label %bb128
bb144:
  br label %bb157
bb145:
  %t584 = load ptr, ptr %l2, !tbaa !29
  store ptr %t584, ptr %l315, !tbaa !29
  store i1 false, ptr %l316, !tbaa !21
  %t585 = load ptr, ptr %l315, !tbaa !29
  %t586 = icmp ne ptr %t585, null
  br i1 %t586, label %bb146, label %bb147
bb146:
  %t588 = load ptr, ptr %l315, !tbaa !29
  %t589 = load i64, ptr %t588
  %t591 = icmp eq i64 %t589, 17
  store i1 %t591, ptr %l316, !tbaa !21
  br label %bb147
bb147:
  %t592 = load i1, ptr %l316, !tbaa !21
  br i1 %t592, label %bb148, label %bb149
bb148:
  %t593 = load ptr, ptr %l2, !tbaa !29
  %t595 = getelementptr { i64, [5 x i64] }, ptr %t593, i32 0, i32 1
  %t596 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t595, i32 0, i32 2
  %t597 = load ptr, ptr %t596
  store ptr %t597, ptr %l35, !tbaa !29
  br label %bb150
bb149:
  br label %bb152
bb150:
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t600 = load i64, ptr %l1, !tbaa !24
  %t601 = load ptr, ptr %l35, !tbaa !29
  %t602 = load i64, ptr %l3, !tbaa !24
  %t603 = load { i64, [1 x i64] }, ptr %l4
  %t604 = load i1, ptr %l5, !tbaa !21
  %t605 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t599, i64 %t600, ptr %t601, i64 %t602, { i64, [1 x i64] } %t603, i1 %t604, i1 %t605)
  br label %bb151
bb151:
  br label %bb157
bb152:
  br i1 true, label %bb153, label %bb154
bb153:
  br label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb157
bb156:
  call void @__olang_check_failed(ptr @olang_loc_40e6d44f68e64eba_dc25501b912aa106)
  unreachable
bb157:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i32
  %l33 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l51 = alloca i1
  %l58 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb4:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l15
  br label %bb5
bb5:
  %t18 = load i1, ptr %l15, !tbaa !21
  store i1 %t18, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l19
  br label %bb9
bb9:
  %t25 = load i1, ptr %l19, !tbaa !21
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l24
  br label %bb14
bb14:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l24, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l25
  br label %bb15
bb15:
  %t37 = load i32, ptr %l25, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l28
  br label %bb16
bb16:
  %t43 = load i32, ptr %l28
  store i32 %t43, ptr %l4
  %t44 = load i32, ptr %l4
  %t46 = trunc i64 19 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l33
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t54 = load i1, ptr %l33, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
bb20:
  %t55 = load i32, ptr %l4
  %t57 = trunc i64 18 to i32
  %t58 = icmp eq i32 %t55, %t57
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb24
bb22:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l40
  br label %bb23
bb23:
  %t67 = load i1, ptr %l40, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t70 = load i1, ptr %l37, !tbaa !21
  br i1 %t70, label %bb25, label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t72 = load ptr, ptr %l2, !tbaa !29
  store ptr %t72, ptr %l43, !tbaa !29
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t74 = load i32, ptr %l3, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l46
  br label %bb28
bb28:
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t79 = load i32, ptr %l46, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t80, ptr %l47
  br label %bb29
bb29:
  %t81 = load i32, ptr %l47
  store i32 %t81, ptr %l5
  %t82 = load i32, ptr %l5
  %t84 = trunc i64 0 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb30, label %bb31
bb30:
  %t89 = load i32, ptr %l5
  %t91 = trunc i64 1 to i32
  %t92 = icmp eq i32 %t89, %t91
  %t94 = xor i1 %t92, true
  store i1 %t94, ptr %l51, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t96 = load i1, ptr %l51, !tbaa !21
  br i1 %t96, label %bb33, label %bb34
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t98, i32 %t99)
  store i1 %t102, ptr %l58
  br label %bb36
bb36:
  %t103 = load i1, ptr %l58, !tbaa !21
  store i1 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l28 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i64
  %l39 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i64
  %l49 = alloca i1
  %l55 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = add i64 %t1, 2
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb3:
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t13, ptr %l15, !tbaa !27
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i64, ptr %t17, i64 %t14
  %t19 = load i64, ptr %t18, !tbaa !34
  store i64 %t19, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i64, ptr %t27, i64 %t24
  %t29 = load i64, ptr %t28, !tbaa !34
  store i64 %t29, ptr %l5, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t32, 2
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i64, ptr %t37, i64 %t34
  %t39 = load i64, ptr %t38, !tbaa !34
  store i64 %t39, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = icmp sge i64 %t41, 0
  br i1 %t43, label %bb5, label %bb6
bb5:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp slt i64 %t45, 63
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t49 = load i1, ptr %l28, !tbaa !21
  br i1 %t49, label %bb8, label %bb9
bb8:
  %t50 = load i64, ptr %l2, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  store i64 %t51, ptr %l33, !tbaa !24
  %t52 = load i64, ptr %l33, !tbaa !24
  %t53 = load i64, ptr %l33, !tbaa !24
  %t54 = shl i64 1, %t53
  %t57 = and i64 %t50, %t54
  %t59 = icmp ne i64 %t57, 0
  store i1 %t59, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t61 = load i1, ptr %l31, !tbaa !21
  store i1 %t61, ptr %l7, !tbaa !21
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = icmp sge i64 %t62, 0
  br i1 %t64, label %bb11, label %bb12
bb11:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = icmp slt i64 %t66, 63
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t70 = load i1, ptr %l39, !tbaa !21
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load i64, ptr %l5, !tbaa !24
  store i64 %t72, ptr %l44, !tbaa !24
  %t73 = load i64, ptr %l44, !tbaa !24
  %t74 = load i64, ptr %l44, !tbaa !24
  %t75 = shl i64 1, %t74
  %t78 = and i64 %t71, %t75
  %t80 = icmp ne i64 %t78, 0
  store i1 %t80, ptr %l42, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t82 = load i1, ptr %l42, !tbaa !21
  store i1 %t82, ptr %l8, !tbaa !21
  %t83 = load i1, ptr %l7, !tbaa !21
  br i1 %t83, label %bb17, label %bb18
bb17:
  %t85 = load i1, ptr %l8, !tbaa !21
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l49, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb19
bb19:
  %t89 = load i1, ptr %l49, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = icmp eq i64 %t91, 1
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = load i1, ptr %l7, !tbaa !21
  %t96 = load i1, ptr %l8, !tbaa !21
  %t99 = icmp ne i1 %t95, %t96
  store i1 %t99, ptr %l55, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb25
bb25:
  %t101 = load i1, ptr %l55, !tbaa !21
  br i1 %t101, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t103 = load i64, ptr %l3, !tbaa !24
  %t105 = add i64 %t103, 3
  store i64 %t105, ptr %l3, !tbaa !24
  br label %bb1
bb30:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erowBefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1, %"compiler/free:letGo" %a2) #0 {
entry:
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca %"compiler/free:letGo"
  %l16 = alloca i1
  %rv = alloca i1
  store %"compiler/free:letGo" %a1, ptr %l1
  store %"compiler/free:letGo" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 5
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t6 = icmp eq i64 %t2, %t3
  %t7 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 5
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t12 = icmp eq i64 %t8, %t9
  %t15 = icmp ne i1 %t6, %t12
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 5
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t22 = icmp eq i64 %t18, %t19
  store i1 %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t25 = load %"compiler/free:letGo", ptr %l1
  %t26 = load %"compiler/free:letGo", ptr %l2
  %t30 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %t25, %"compiler/free:letGo" %t26)
  store i1 %t30, ptr %l16
  br label %bb4
bb4:
  %t31 = load i1, ptr %l16, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esave(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l44 = alloca { i64, ptr }
  %l47 = alloca i64
  %l49 = alloca i64
  %l57 = alloca i64
  %l61 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l90 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca i32
  %l110 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 3
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_He8628b0a6160e3784b3615fe3f392582(ptr %v1, ptr %t3)
  store i64 %t5, ptr %l28
  br label %bb1
bb1:
  %t6 = load i64, ptr %l28, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 3
  store ptr %t9, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = load i64, ptr %l6, !tbaa !24
  %t15 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hd2f0d304a9aa6fbe6d847d83ccff30fa(ptr %v1, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l35
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb4, label %ok.19
ok.19:
  store { i64, ptr } %t16, ptr %l34
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t20, ptr %l31, !tbaa !27
  br label %bb8
bb4:
  %t21 = load i32, ptr %l35, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a2405124df419505_d09a35ea35067921)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb8:
  %t26 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l9, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t39 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t39, ptr %l44, !tbaa !27
  %t40 = load i64, ptr %l9, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 %t40
  %t45 = load ptr, ptr %t44, !tbaa !39
  %t47 = load i64, ptr %l4, !tbaa !24
  store i64 %t47, ptr %l47, !tbaa !24
  %t50 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t45)
  store i64 %t50, ptr %l49
  br label %bb13
bb13:
  %t51 = load i64, ptr %l47, !tbaa !24
  %t52 = load i64, ptr %l49, !tbaa !24
  %t53 = add i64 %t51, %t52
  store i64 %t53, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t55 = load i64, ptr %l9, !tbaa !24
  %t57 = add i64 %t55, 1
  store i64 %t57, ptr %l9, !tbaa !24
  br label %bb9
bb15:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = add i64 %t59, %t60
  store i64 %t63, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %bb2
bb17:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l57, !tbaa !24
  %t68 = load i64, ptr %l57, !tbaa !24
  %t69 = icmp sge i64 %t68, 0
  br i1 %t69, label %bb18, label %bb19
bb18:
  %t71 = load i64, ptr %l57, !tbaa !24
  %t72 = icmp sle i64 %t71, 1152921504606846975
  br i1 %t72, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_a35b07018a31f4f3_69e61a5b7415d1c7)
  unreachable
bb20:
  %t74 = load i64, ptr %l57, !tbaa !24
  %t75 = mul i64 %t74, 8
  %t76 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l11, !tbaa !27
  %t80 = load i64, ptr %l4, !tbaa !24
  store i64 %t80, ptr %l61, !tbaa !24
  %t81 = load i64, ptr %l61, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  br i1 %t82, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a35b07018a31f4f3_69e61a5b7415d1c7)
  unreachable
bb22:
  %t84 = load i64, ptr %l61, !tbaa !24
  %t85 = icmp sle i64 %t84, 1152921504606846975
  br i1 %t85, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_f643d9b6ae0bdcd0_4526d46ebc766864)
  unreachable
bb24:
  %t87 = load i64, ptr %l61, !tbaa !24
  %t88 = mul i64 %t87, 8
  %t89 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  %t93 = load i64, ptr %l3, !tbaa !24
  store i64 %t93, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t95 = load i64, ptr %l15, !tbaa !24
  %t96 = load i64, ptr %l14, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  br i1 %t99, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_f643d9b6ae0bdcd0_4526d46ebc766864)
  unreachable
bb26:
  %t101 = load i64, ptr %l16, !tbaa !24
  %t103 = icmp sgt i64 %t101, 0
  br i1 %t103, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb31
bb28:
  %t105 = load i64, ptr %l15, !tbaa !24
  %t106 = load i64, ptr %l14, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t110 = load i64, ptr %l16, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = sub i64 %t113, 1
  %t116 = load i64, ptr %l16, !tbaa !24
  %t119 = sdiv i64 %t115, %t116
  store i64 %t119, ptr %l72, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb30
bb30:
  %t121 = load i64, ptr %l72, !tbaa !24
  store i64 %t121, ptr %l69, !tbaa !24
  br label %bb31
bb31:
  %t122 = load i64, ptr %l69, !tbaa !24
  store i64 %t122, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t123 = load i64, ptr %l18, !tbaa !24
  %t124 = load i64, ptr %l17, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb53
bb34:
  br label %bb35
bb35:
  %t131 = load i64, ptr %l14, !tbaa !24
  %t132 = load i64, ptr %l18, !tbaa !24
  %t133 = load i64, ptr %l16, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  store i64 %t139, ptr %l19, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t141, ptr %l90, !tbaa !27
  %t142 = load i64, ptr %l19, !tbaa !24
  %t143 = load i64, ptr %l13, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i64, ptr %t147, i64 %t142
  store i64 %t143, ptr %t148, !tbaa !34
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr %"compiler/free:walker", ptr %t149, i32 0, i32 3
  %t152 = load i64, ptr %l19, !tbaa !24
  %t155 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v1, ptr %v1, ptr %t151, i64 %t152)
  store ptr %t155, ptr %l96
  br label %bb36
bb36:
  %t156 = load ptr, ptr %l96, !tbaa !29
  store ptr %t156, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t157 = load ptr, ptr %l20, !tbaa !29
  %t158 = load i64, ptr %l21, !tbaa !24
  %t161 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t157, i64 %t158)
  %t162 = extractvalue { i32, { i64, ptr } } %t161, 1
  %t163 = extractvalue { i32, { i64, ptr } } %t161, 0
  store i32 %t163, ptr %l101
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb39, label %ok.165
ok.165:
  store { i64, ptr } %t162, ptr %l100
  br label %bb38
bb38:
  %t166 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t166, ptr %l97, !tbaa !27
  br label %bb43
bb39:
  %t167 = load i32, ptr %l101, !tbaa !23
  %t168 = ashr i32 %t167, 16
  %t170 = icmp eq i32 %t168, 1
  br i1 %t170, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_859ddcc5919b3f4e_ba7432349dfb5d8a)
  unreachable
bb42:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s8)
  br label %bb51
bb43:
  %t172 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t172, ptr %l22, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t177 = load i64, ptr %l24, !tbaa !24
  %t178 = load i64, ptr %l23, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb49
bb46:
  br label %bb47
bb47:
  %t185 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t185, ptr %l110, !tbaa !27
  %t186 = load i64, ptr %l24, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i64, ptr %t189, i64 %t186
  %t191 = load i64, ptr %t190, !tbaa !34
  %t193 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t193, ptr %l113, !tbaa !27
  %t194 = load i64, ptr %l13, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr i64, ptr %t199, i64 %t194
  store i64 %t191, ptr %t200, !tbaa !34
  %t201 = load i64, ptr %l13, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb48
bb48:
  %t205 = load i64, ptr %l24, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l24, !tbaa !24
  br label %bb44
bb49:
  %t209 = load i64, ptr %l21, !tbaa !24
  %t210 = load i64, ptr %l23, !tbaa !24
  %t213 = add i64 %t209, %t210
  store i64 %t213, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb50:
  br label %bb37
bb51:
  call void @__olang_scope_close(ptr %s6)
  br label %bb52
bb52:
  %t215 = load i64, ptr %l18, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l18, !tbaa !24
  br label %bb32
bb53:
  %t219 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t219, ptr %l125, !tbaa !27
  %t220 = load i64, ptr %l3, !tbaa !24
  %t221 = load i64, ptr %l13, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i64, ptr %t225, i64 %t220
  store i64 %t221, ptr %t226, !tbaa !34
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/free:Free", ptr %t227, i32 0, i32 49
  %t230 = load i64, ptr %l2, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t229, i64 %t230, { i64, ptr } %t231)
  br label %bb54
bb54:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/free:Free", ptr %t235, i32 0, i32 50
  %t238 = load i64, ptr %l2, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t237, i64 %t238, { i64, ptr } %t239)
  br label %bb55
bb55:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estoredMore(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l27 = alloca { i64, ptr }
  %l43 = alloca i1
  %l47 = alloca ptr
  %l49 = alloca i1
  %l50 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i1
  %l63 = alloca ptr
  %l65 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 21
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l13, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t9, i64 %t10)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l18
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb4, label %ok.17
ok.17:
  store { i64, ptr } %t14, ptr %l17
  br label %bb3
bb3:
  %t18 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  br label %bb8
bb4:
  %t19 = load i32, ptr %l18, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a764b585ac706330_d4408aac5d1924a4)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb8:
  %t24 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t24, ptr %l6, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load i64, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb11:
  br label %bb12
bb12:
  %t37 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t38 = load i64, ptr %l8, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i64, ptr %t41, i64 %t38
  %t43 = load i64, ptr %t42, !tbaa !34
  %t47 = ashr i64 %t43, 32
  %t48 = load i64, ptr %l2, !tbaa !24
  %t51 = icmp eq i64 %t47, %t48
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l3, !tbaa !24
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l8, !tbaa !24
  br label %bb9
bb17:
  %t61 = load i64, ptr %l5, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = add i64 %t61, %t62
  store i64 %t65, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb2
bb19:
  %t67 = load i64, ptr %l3, !tbaa !24
  %t69 = icmp sgt i64 %t67, 1
  br i1 %t69, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb24
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/free:Free", ptr %t71, i32 0, i32 22
  %t74 = load i64, ptr %l1, !tbaa !24
  %t77 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  store ptr %t77, ptr %l47
  br label %bb22
bb22:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t79 = load ptr, ptr %l47, !tbaa !29
  %t81 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t79, i64 %t78)
  store i1 %t81, ptr %l49
  br label %bb23
bb23:
  %t82 = load i1, ptr %l49, !tbaa !21
  store i1 %t82, ptr %l43, !tbaa !21
  br label %bb24
bb24:
  %t83 = load i1, ptr %l43, !tbaa !21
  br i1 %t83, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb30
bb26:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:Free", ptr %t84, i32 0, i32 20
  %t87 = load i64, ptr %l1, !tbaa !24
  %t90 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t86, i64 %t87)
  store ptr %t90, ptr %l54
  br label %bb27
bb27:
  %t91 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t92 = load i64, ptr %l2, !tbaa !24
  %t95 = call i64 @compiler_2ffree_2eorig(i64 %t91, i64 %t92)
  store i64 %t95, ptr %l57
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l54, !tbaa !29
  %t97 = load i64, ptr %l57, !tbaa !24
  %t98 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t96, i64 %t97)
  store i1 %t98, ptr %l58
  br label %bb29
bb29:
  %t99 = load i1, ptr %l58, !tbaa !21
  store i1 %t99, ptr %l50, !tbaa !21
  br label %bb30
bb30:
  %t100 = load i1, ptr %l50, !tbaa !21
  br i1 %t100, label %bb31, label %bb32
bb31:
  store i1 true, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/free:Free", ptr %t102, i32 0, i32 23
  %t105 = load i64, ptr %l1, !tbaa !24
  %t108 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t104, i64 %t105)
  store ptr %t108, ptr %l63
  br label %bb34
bb34:
  %t109 = load i64, ptr %l2, !tbaa !24
  %t110 = load ptr, ptr %l63, !tbaa !29
  %t112 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t110, i64 %t109)
  store i1 %t112, ptr %l65
  br label %bb35
bb35:
  %t113 = load i1, ptr %l65, !tbaa !21
  store i1 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l62 = alloca i64
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 1
  %t19 = load i32, ptr %t18, !tbaa !23
  %t21 = sext i32 %t19 to i64
  store i64 %t21, ptr %l8, !tbaa !24
  br label %bb42
bb6:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t24 = load ptr, ptr %l18, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l18, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 7
  store i1 %t30, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Make", ptr %t38, i32 0, i32 4
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  store i64 %t43, ptr %l8, !tbaa !24
  br label %bb42
bb12:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t46 = load ptr, ptr %l27, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = load i64, ptr %t49
  %t52 = icmp eq i64 %t50, 16
  store i1 %t52, ptr %l28, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Text", ptr %t60, i32 0, i32 1
  %t63 = load i32, ptr %t62, !tbaa !23
  %t65 = sext i32 %t63 to i64
  store i64 %t65, ptr %l8, !tbaa !24
  br label %bb42
bb18:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = load i64, ptr %t71
  %t74 = icmp eq i64 %t72, 8
  store i1 %t74, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l37, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [5 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Collect", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = sext i32 %t85 to i64
  store i64 %t87, ptr %l8, !tbaa !24
  br label %bb42
bb24:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t90 = load ptr, ptr %l45, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb25, label %bb26
bb25:
  %t93 = load ptr, ptr %l45, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 6
  store i1 %t96, ptr %l46, !tbaa !21
  br label %bb26
bb26:
  %t97 = load i1, ptr %l46, !tbaa !21
  br i1 %t97, label %bb27, label %bb28
bb27:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [5 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Call", ptr %t104, i32 0, i32 3
  %t107 = load i32, ptr %t106, !tbaa !23
  %t109 = sext i32 %t107 to i64
  store i64 %t109, ptr %l8, !tbaa !24
  br label %bb42
bb30:
  %t111 = load ptr, ptr %l1, !tbaa !29
  store ptr %t111, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t112 = load ptr, ptr %l54, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb31, label %bb32
bb31:
  %t115 = load ptr, ptr %l54, !tbaa !29
  %t116 = load i64, ptr %t115
  %t118 = icmp eq i64 %t116, 17
  store i1 %t118, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t119 = load i1, ptr %l55, !tbaa !21
  br i1 %t119, label %bb33, label %bb34
bb33:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t122, i32 0, i32 2
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l7, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t130 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %a0, ptr %t127)
  store i64 %t130, ptr %l62
  br label %bb36
bb36:
  %t131 = load i64, ptr %l62, !tbaa !24
  store i64 %t131, ptr %l8, !tbaa !24
  br label %bb42
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_a0b39b8bb083daea_3953b4ce55bab6be)
  unreachable
bb42:
  %t132 = load i64, ptr %l8, !tbaa !24
  store i64 %t132, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewalk(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca i1
  %l26 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l35 = alloca i32
  %l38 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l61 = alloca ptr
  %l64 = alloca ptr
  %l67 = alloca ptr
  %l83 = alloca ptr
  %l93 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t16)
  store ptr %t18, ptr %l15
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l15, !tbaa !29
  store ptr %t19, ptr %l4, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %t23, !tbaa !23
  %t27 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t20, i32 %t24)
  store i64 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t29 = load i64, ptr %l19, !tbaa !24
  %t31 = icmp eq i64 %t29, %t28
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Body", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %t36, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t33, i32 %t37)
  store { i64, ptr } %t40, ptr %l26
  br label %bb9
bb8:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb10
bb9:
  %t41 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t44 = icmp eq i64 %t42, 1
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l22, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load ptr, ptr %l4, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Body", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t48, i32 %t52)
  store { i64, ptr } %t55, ptr %l33
  br label %bb13
bb12:
  br label %bb34
bb13:
  %t56 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i32, ptr %t57, i64 0
  %t59 = load i32, ptr %t58, !tbaa !33
  %t60 = load ptr, ptr %l29, !tbaa !29
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t60, i32 %t59)
  store i32 %t62, ptr %l35
  br label %bb14
bb14:
  %t63 = load i32, ptr %l35, !tbaa !23
  store i32 %t63, ptr %l5, !tbaa !23
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t65 = load i32, ptr %l5, !tbaa !23
  %t68 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t68, ptr %l38
  br label %bb15
bb15:
  %t69 = load i1, ptr %l38, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t70 = load ptr, ptr %l4, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t72 = load i32, ptr %l5, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l42
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t77 = load i32, ptr %l42, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t78, ptr %l43
  br label %bb19
bb19:
  %t79 = load i32, ptr %l43, !tbaa !23
  store i32 %t79, ptr %l5, !tbaa !23
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t81 = load i32, ptr %l5, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l46
  br label %bb21
bb21:
  %t85 = load i32, ptr %l46
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t91 = load i32, ptr %l5, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l52
  br label %bb24
bb23:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb25
bb24:
  %t95 = load i1, ptr %l52, !tbaa !21
  store i1 %t95, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t96 = load i1, ptr %l49, !tbaa !21
  br i1 %t96, label %bb26, label %bb27
bb26:
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t98 = load i32, ptr %l5, !tbaa !23
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l56
  br label %bb28
bb27:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb29
bb28:
  %t102 = load i1, ptr %l56, !tbaa !21
  store i1 %t102, ptr %l53, !tbaa !21
  br label %bb29
bb29:
  %t103 = load i1, ptr %l53, !tbaa !21
  br i1 %t103, label %bb30, label %bb31
bb30:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t104, i64 %t105)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l1, !tbaa !24
  %t112 = call ptr @compiler_2ffree_2enewWalker(ptr %v0, ptr %t108, i64 %t109, i1 false)
  store ptr %t112, ptr %l61
  br label %bb35
bb35:
  %t113 = load ptr, ptr %l61, !tbaa !29
  store ptr %t113, ptr %l6, !tbaa !29
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s5
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = getelementptr %"compiler/free:walker", ptr %t114, i32 0, i32 5
  store i1 false, ptr %t116, !tbaa !21
  %t117 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %t117)
  br label %bb37
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l64, !tbaa !29
  %t120 = load ptr, ptr %l64, !tbaa !29
  %t121 = getelementptr %"compiler/free:Free", ptr %t120, i32 0, i32 4
  %t122 = load i64, ptr %t121, !tbaa !24
  %t124 = add i64 %t122, 1
  %t126 = load ptr, ptr %l64, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t126, i32 0, i32 4
  store i64 %t124, ptr %t127, !tbaa !24
  %t128 = load ptr, ptr %l6, !tbaa !29
  store ptr %t128, ptr %l67, !tbaa !29
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Body", ptr %t129, i32 0, i32 11
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_30cfd3b464a887aa_ca3830b5343a05a6)
  unreachable
bb39:
  br label %bb40
bb40:
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Body", ptr %t136, i32 0, i32 11
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t140 = load ptr, ptr %l67, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v0, ptr %t140, ptr %t139)
  br label %bb41
bb41:
  %t142 = load ptr, ptr %l6, !tbaa !29
  %t144 = getelementptr %"compiler/free:walker", ptr %t142, i32 0, i32 5
  %t145 = load i1, ptr %t144, !tbaa !21
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb46
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb45:
  br label %bb36
bb46:
  %t149 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamPaths(ptr %v0, ptr %t149)
  br label %bb47
bb47:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l6, !tbaa !29
  %t153 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esave(ptr %v0, ptr %v0, ptr %t151, ptr %t152, i64 %t153)
  br label %bb48
bb48:
  br i1 %a2, label %bb49, label %bb50
bb49:
  %t159 = load ptr, ptr %l6, !tbaa !29
  %t161 = getelementptr %"compiler/free:walker", ptr %t159, i32 0, i32 2
  store i1 true, ptr %t161, !tbaa !21
  %t162 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %t162)
  br label %bb51
bb50:
  br label %bb62
bb51:
  %t164 = load ptr, ptr %l6, !tbaa !29
  store ptr %t164, ptr %l83, !tbaa !29
  %t165 = load ptr, ptr %l3, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Body", ptr %t165, i32 0, i32 11
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = icmp eq ptr %t168, null
  br i1 %t170, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_3a3557a9366273b1_8eafb121351cf8d)
  unreachable
bb53:
  br label %bb54
bb54:
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Body", ptr %t172, i32 0, i32 11
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t176 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v0, ptr %t176, ptr %t175)
  br label %bb55
bb55:
  %t178 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviews(ptr %v0, ptr %t178)
  br label %bb56
bb56:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/free:Free", ptr %t180, i32 0, i32 61
  %t183 = load i64, ptr %l1, !tbaa !24
  %t186 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t182, i64 %t183)
  store i1 %t186, ptr %l93
  br label %bb57
bb57:
  %t187 = load i1, ptr %l93, !tbaa !21
  br i1 %t187, label %bb58, label %bb59
bb58:
  %t188 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroys(ptr %v0, ptr %t188)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca i64
  %l55 = alloca i1
  %l59 = alloca ptr
  %l63 = alloca i1
  %l64 = alloca ptr
  %l68 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l79 = alloca ptr
  %l82 = alloca i64
  %l85 = alloca i1
  %l95 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca ptr
  %l100 = alloca i1
  %l117 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l134 = alloca i64
  %l135 = alloca ptr
  %l136 = alloca i1
  %l144 = alloca i64
  %l145 = alloca ptr
  %l146 = alloca i1
  %l155 = alloca i1
  %l156 = alloca i64
  %l159 = alloca { i64, ptr }
  %l161 = alloca i64
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l18, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t6 = load ptr, ptr %l19, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l19, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l20, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t14 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
bb7:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t17 = load ptr, ptr %l24, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb8, label %bb9
bb8:
  %t20 = load ptr, ptr %l24, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l25, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t37 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t31, ptr %t32, ptr %t33)
  store i64 %t37, ptr %l33
  br label %bb13
bb13:
  %t38 = load i64, ptr %l33, !tbaa !24
  store i64 %t38, ptr %rv
  br label %ret
bb14:
  %t39 = load ptr, ptr %l2, !tbaa !29
  store ptr %t39, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t40 = load ptr, ptr %l34, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l34, !tbaa !29
  %t44 = load i64, ptr %t43
  %t46 = icmp eq i64 %t44, 3
  store i1 %t46, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l35, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l5, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t60 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t54, ptr %t55, ptr %t56)
  store i64 %t60, ptr %l43
  br label %bb20
bb20:
  %t61 = load i64, ptr %l43, !tbaa !24
  store i64 %t61, ptr %rv
  br label %ret
bb21:
  %t62 = load ptr, ptr %l2, !tbaa !29
  store ptr %t62, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t63 = load ptr, ptr %l44, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb22, label %bb23
bb22:
  %t66 = load ptr, ptr %l44, !tbaa !29
  %t67 = load i64, ptr %t66
  %t69 = icmp eq i64 %t67, 6
  store i1 %t69, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t70 = load i1, ptr %l45, !tbaa !21
  br i1 %t70, label %bb24, label %bb25
bb24:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l6, !tbaa !29
  br label %bb26
bb25:
  br label %bb49
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l6, !tbaa !29
  %t81 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v2, ptr %t77, ptr %t78)
  store i64 %t81, ptr %l52
  br label %bb27
bb27:
  %t82 = load i64, ptr %l52, !tbaa !24
  store i64 %t82, ptr %l7, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t85 = icmp slt i64 %t83, 0
  br i1 %t85, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb31
bb29:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 1
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t89, i64 %t90)
  store ptr %t93, ptr %l59
  br label %bb30
bb30:
  %t94 = load ptr, ptr %l59, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Body", ptr %t94, i32 0, i32 11
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = icmp eq ptr %t97, null
  store i1 %t99, ptr %l55, !tbaa !21
  br label %bb31
bb31:
  %t101 = load i1, ptr %l55, !tbaa !21
  br i1 %t101, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb36
bb33:
  %t102 = load ptr, ptr %l3, !tbaa !29
  store ptr %t102, ptr %l64, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/free:Free", ptr %t103, i32 0, i32 1
  %t106 = load i64, ptr %l7, !tbaa !24
  %t109 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t105, i64 %t106)
  store ptr %t109, ptr %l68
  br label %bb34
bb34:
  %t110 = load ptr, ptr %l68, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Body", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %t112, !tbaa !23
  %t114 = load ptr, ptr %l64, !tbaa !29
  %t116 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s4, ptr %t114, i32 %t113)
  store { i64, ptr } %t116, ptr %l71
  br label %bb35
bb35:
  %t117 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  %t120 = icmp ne i64 %t118, 1
  store i1 %t120, ptr %l63, !tbaa !21
  br label %bb36
bb36:
  %t122 = load i1, ptr %l63, !tbaa !21
  br i1 %t122, label %bb37, label %bb38
bb37:
  %t123 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  store i64 %t123, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t125 = load ptr, ptr %l3, !tbaa !29
  store ptr %t125, ptr %l75, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/free:Free", ptr %t126, i32 0, i32 1
  %t129 = load i64, ptr %l7, !tbaa !24
  %t132 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t128, i64 %t129)
  store ptr %t132, ptr %l79
  br label %bb40
bb40:
  %t133 = load ptr, ptr %l79, !tbaa !29
  %t135 = getelementptr %"compiler/typed:Body", ptr %t133, i32 0, i32 2
  %t136 = load i32, ptr %t135, !tbaa !23
  %t137 = load ptr, ptr %l75, !tbaa !29
  %t139 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t137, i32 %t136, i64 0)
  store i64 %t139, ptr %l82
  br label %bb41
bb41:
  %t140 = load i64, ptr %l82, !tbaa !24
  store i64 %t140, ptr %l8, !tbaa !24
  %t141 = load i64, ptr %l8, !tbaa !24
  %t143 = icmp slt i64 %t141, 0
  br i1 %t143, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb44
bb43:
  %t145 = load i64, ptr %l8, !tbaa !24
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Call", ptr %t146, i32 0, i32 1
  %t149 = load { i64, ptr }, ptr %t148, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t154 = icmp sge i64 %t145, %t151
  store i1 %t154, ptr %l85, !tbaa !21
  br label %bb44
bb44:
  %t156 = load i1, ptr %l85, !tbaa !21
  br i1 %t156, label %bb45, label %bb46
bb45:
  %t157 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  store i64 %t157, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t161 = load ptr, ptr %l6, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Call", ptr %t161, i32 0, i32 1
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  store { i64, ptr } %t164, ptr %l95, !tbaa !27
  %t165 = load i64, ptr %l8, !tbaa !24
  %t167 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr ptr, ptr %t168, i64 %t165
  %t170 = load ptr, ptr %t169, !tbaa !39
  %t174 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t159, ptr %t160, ptr %t170)
  store i64 %t174, ptr %l98
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s4)
  %t175 = load i64, ptr %l98, !tbaa !24
  store i64 %t175, ptr %rv
  br label %ret
bb49:
  %t176 = load ptr, ptr %l2, !tbaa !29
  store ptr %t176, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t177 = load ptr, ptr %l99, !tbaa !29
  %t178 = icmp ne ptr %t177, null
  br i1 %t178, label %bb50, label %bb51
bb50:
  %t180 = load ptr, ptr %l99, !tbaa !29
  %t181 = load i64, ptr %t180
  %t183 = icmp eq i64 %t181, 14
  store i1 %t183, ptr %l100, !tbaa !21
  br label %bb51
bb51:
  %t184 = load i1, ptr %l100, !tbaa !21
  br i1 %t184, label %bb52, label %bb53
bb52:
  %t185 = load ptr, ptr %l2, !tbaa !29
  %t187 = getelementptr { i64, [5 x i64] }, ptr %t185, i32 0, i32 1
  %t188 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t187, i32 0, i32 2
  %t189 = load ptr, ptr %t188
  store ptr %t189, ptr %l9, !tbaa !29
  br label %bb54
bb53:
  br label %bb71
bb54:
  %t191 = load ptr, ptr %l9, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Try", ptr %t191, i32 0, i32 0
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = icmp eq ptr %t194, null
  br i1 %t196, label %bb55, label %bb56
bb55:
  %t198 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t198, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t200 = load ptr, ptr %l9, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Try", ptr %t200, i32 0, i32 1
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  store { i64, ptr } %t203, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  store i64 %t207, ptr %l12, !tbaa !24
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s10
  %t209 = load i64, ptr %l11, !tbaa !24
  %t210 = load i64, ptr %l12, !tbaa !24
  %t213 = icmp slt i64 %t209, %t210
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb66
bb60:
  br label %bb61
bb61:
  %t217 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t217, ptr %l117, !tbaa !27
  %t218 = load i64, ptr %l11, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr ptr, ptr %t221, i64 %t218
  %t223 = load ptr, ptr %t222, !tbaa !39
  %t227 = getelementptr %"compiler/typed:Clause", ptr %t223, i32 0, i32 4
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t232 = icmp sgt i64 %t230, 0
  br i1 %t232, label %bb62, label %bb63
bb62:
  %t234 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  store i64 %t234, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s10)
  br label %bb65
bb65:
  %t236 = load i64, ptr %l11, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l11, !tbaa !24
  br label %bb58
bb66:
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l127, !tbaa !29
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l128, !tbaa !29
  %t242 = load ptr, ptr %l9, !tbaa !29
  %t244 = getelementptr %"compiler/typed:Try", ptr %t242, i32 0, i32 0
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = icmp eq ptr %t245, null
  br i1 %t247, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_4acb4c8921e8c407_808d59af97a4073)
  unreachable
bb68:
  br label %bb69
bb69:
  %t249 = load ptr, ptr %l9, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Try", ptr %t249, i32 0, i32 0
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t253 = load ptr, ptr %l127, !tbaa !29
  %t254 = load ptr, ptr %l128, !tbaa !29
  %t256 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t253, ptr %t254, ptr %t252)
  store i64 %t256, ptr %l134
  br label %bb70
bb70:
  %t257 = load i64, ptr %l134, !tbaa !24
  store i64 %t257, ptr %rv
  br label %ret
bb71:
  %t258 = load ptr, ptr %l2, !tbaa !29
  store ptr %t258, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t259 = load ptr, ptr %l135, !tbaa !29
  %t260 = icmp ne ptr %t259, null
  br i1 %t260, label %bb72, label %bb73
bb72:
  %t262 = load ptr, ptr %l135, !tbaa !29
  %t263 = load i64, ptr %t262
  %t265 = icmp eq i64 %t263, 17
  store i1 %t265, ptr %l136, !tbaa !21
  br label %bb73
bb73:
  %t266 = load i1, ptr %l136, !tbaa !21
  br i1 %t266, label %bb74, label %bb75
bb74:
  %t267 = load ptr, ptr %l2, !tbaa !29
  %t269 = getelementptr { i64, [5 x i64] }, ptr %t267, i32 0, i32 1
  %t270 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t269, i32 0, i32 2
  %t271 = load ptr, ptr %t270
  store ptr %t271, ptr %l14, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t275 = load ptr, ptr %l14, !tbaa !29
  %t279 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t273, ptr %t274, ptr %t275)
  store i64 %t279, ptr %l144
  br label %bb77
bb77:
  %t280 = load i64, ptr %l144, !tbaa !24
  store i64 %t280, ptr %rv
  br label %ret
bb78:
  %t281 = load ptr, ptr %l2, !tbaa !29
  store ptr %t281, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t282 = load ptr, ptr %l145, !tbaa !29
  %t283 = icmp ne ptr %t282, null
  br i1 %t283, label %bb79, label %bb80
bb79:
  %t285 = load ptr, ptr %l145, !tbaa !29
  %t286 = load i64, ptr %t285
  %t288 = icmp eq i64 %t286, 9
  store i1 %t288, ptr %l146, !tbaa !21
  br label %bb80
bb80:
  %t289 = load i1, ptr %l146, !tbaa !21
  br i1 %t289, label %bb81, label %bb82
bb81:
  %t290 = load ptr, ptr %l2, !tbaa !29
  %t292 = getelementptr { i64, [5 x i64] }, ptr %t290, i32 0, i32 1
  %t293 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t292, i32 0, i32 2
  %t294 = load i32, ptr %t293
  store i32 %t294, ptr %l15
  %t296 = load ptr, ptr %l2, !tbaa !29
  %t298 = getelementptr { i64, [5 x i64] }, ptr %t296, i32 0, i32 1
  %t299 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t298, i32 0, i32 4
  %t300 = load { i64, ptr }, ptr %t299
  store { i64, ptr } %t300, ptr %l16, !tbaa !27
  br label %bb83
bb82:
  br label %bb89
bb83:
  %t302 = load i32, ptr %l15
  %t303 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t306 = call i1 @compiler_2ffree_2eisConversion(ptr %v2, i32 %t302, { i64, ptr } %t303)
  store i1 %t306, ptr %l155
  br label %bb84
bb84:
  %t307 = load i1, ptr %l155, !tbaa !21
  br i1 %t307, label %bb85, label %bb86
bb85:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l1, !tbaa !29
  %t310 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t310, ptr %l159, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr ptr, ptr %t312, i64 0
  %t314 = load ptr, ptr %t313, !tbaa !39
  %t318 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t308, ptr %t309, ptr %t314)
  store i64 %t318, ptr %l161
  br label %bb87
bb86:
  %t319 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t319, ptr %l156, !tbaa !24
  br label %bb88
bb87:
  %t321 = load i64, ptr %l161, !tbaa !24
  store i64 %t321, ptr %l156, !tbaa !24
  br label %bb88
bb88:
  %t322 = load i64, ptr %l156, !tbaa !24
  store i64 %t322, ptr %rv
  br label %ret
bb89:
  br i1 true, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  %t323 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t323, ptr %rv
  br label %ret
bb93:
  call void @__olang_check_failed(ptr @olang_loc_d1dd1febe39b41f_df28cb247c1abe4b)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPlace(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/free:Free", ptr %t2, i32 0, i32 46
  %t8 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t4, i64 %a1)
  store ptr %t8, ptr %l7
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v0, ptr %v1, ptr %t10, ptr %t11, ptr %a2)
  store i64 %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load i64, ptr %l9, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l29 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:mustW", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l13
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l13, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 5
  store ptr %t16, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %t18, i64 %t19)
  %t23 = extractvalue { i32, { i64, ptr } } %t22, 1
  %t24 = extractvalue { i32, { i64, ptr } } %t22, 0
  store i32 %t24, ptr %l20
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb4, label %ok.26
ok.26:
  store { i64, ptr } %t23, ptr %l19
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  br label %bb8
bb4:
  %t28 = load i32, ptr %l20, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  br i1 %t31, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9f79222042d933c1_46b0afd99b60162d)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb8:
  %t33 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb11:
  br label %bb12
bb12:
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l29, !tbaa !27
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 %t47
  %t52 = load i32, ptr %t51, !tbaa !33
  %t56 = sext i32 %t52 to i64
  %t60 = icmp eq i64 %t56, %a1
  br i1 %t60, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t63 = load i64, ptr %l6, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l6, !tbaa !24
  br label %bb9
bb17:
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l5, !tbaa !24
  %t71 = add i64 %t67, %t68
  store i64 %t71, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb2
bb19:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l79 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:mustW", ptr %t22, i32 0, i32 4
  %t25 = load i32, ptr %l2, !tbaa !23
  %t27 = sext i32 %t25 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t24, i64 %t27)
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/free:mustW", ptr %t30, i32 0, i32 5
  %t33 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t36, ptr %t37)
  br label %bb8
bb8:
  br label %bb103
bb9:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t41 = load ptr, ptr %l32, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l32, !tbaa !29
  %t45 = load i64, ptr %t44
  %t47 = icmp eq i64 %t45, 1
  store i1 %t47, ptr %l33, !tbaa !21
  br label %bb11
bb11:
  %t48 = load i1, ptr %l33, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [3 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t51, i32 0, i32 1
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l4, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l5, !tbaa !29
  br label %bb14
bb13:
  br label %bb29
bb14:
  %t61 = load ptr, ptr %l4, !tbaa !29
  store ptr %t61, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t62 = load ptr, ptr %l40, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l40, !tbaa !29
  %t66 = load i64, ptr %t65
  %t68 = icmp eq i64 %t66, 0
  store i1 %t68, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t69 = load i1, ptr %l41, !tbaa !21
  br i1 %t69, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t72, i32 0, i32 2
  %t74 = load i32, ptr %t73
  store i32 %t74, ptr %l6, !tbaa !23
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/free:mustW", ptr %t76, i32 0, i32 4
  %t79 = load i32, ptr %l6, !tbaa !23
  %t81 = sext i32 %t79 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t78, i64 %t81)
  br label %bb20
bb20:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:mustW", ptr %t84, i32 0, i32 5
  %t87 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_18fbdab9dd354c58_c2b73ff02acf68dc)
  unreachable
bb27:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t90, ptr %t91)
  br label %bb28
bb28:
  br label %bb103
bb29:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t95 = load ptr, ptr %l55, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb30, label %bb31
bb30:
  %t98 = load ptr, ptr %l55, !tbaa !29
  %t99 = load i64, ptr %t98
  %t101 = icmp eq i64 %t99, 2
  store i1 %t101, ptr %l56, !tbaa !21
  br label %bb31
bb31:
  %t102 = load i1, ptr %l56, !tbaa !21
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [3 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", ptr }, ptr %t105, i32 0, i32 1
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l7, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t109, ptr %t110)
  br label %bb35
bb35:
  br label %bb103
bb36:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t114 = load ptr, ptr %l63, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb37, label %bb38
bb37:
  %t117 = load ptr, ptr %l63, !tbaa !29
  %t118 = load i64, ptr %t117
  %t120 = icmp eq i64 %t118, 3
  store i1 %t120, ptr %l64, !tbaa !21
  br label %bb38
bb38:
  %t121 = load i1, ptr %l64, !tbaa !21
  br i1 %t121, label %bb39, label %bb40
bb39:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [3 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", ptr }, ptr %t124, i32 0, i32 1
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l8, !tbaa !29
  br label %bb41
bb40:
  br label %bb51
bb41:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l8, !tbaa !29
  %t131 = getelementptr %"compiler/typed:If", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t128, ptr %t132)
  br label %bb42
bb42:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l8, !tbaa !29
  %t138 = getelementptr %"compiler/typed:If", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t135, ptr %t139)
  br label %bb43
bb43:
  %t142 = load ptr, ptr %l8, !tbaa !29
  %t144 = getelementptr %"compiler/typed:If", ptr %t142, i32 0, i32 2
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = icmp eq ptr %t145, null
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb44, label %bb45
bb44:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l79, !tbaa !29
  %t152 = load ptr, ptr %l8, !tbaa !29
  %t154 = getelementptr %"compiler/typed:If", ptr %t152, i32 0, i32 2
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = icmp eq ptr %t155, null
  br i1 %t157, label %bb46, label %bb47
bb45:
  br label %bb50
bb46:
  call void @__olang_check_failed(ptr @olang_loc_6e5f625591edaca_eb58e2cd01ac77e)
  unreachable
bb47:
  br label %bb48
bb48:
  %t159 = load ptr, ptr %l8, !tbaa !29
  %t161 = getelementptr %"compiler/typed:If", ptr %t159, i32 0, i32 2
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t163 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t163, ptr %t162)
  br label %bb49
bb49:
  br label %bb50
bb50:
  br label %bb103
bb51:
  %t165 = load ptr, ptr %l1, !tbaa !29
  store ptr %t165, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t166 = load ptr, ptr %l85, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb52, label %bb53
bb52:
  %t169 = load ptr, ptr %l85, !tbaa !29
  %t170 = load i64, ptr %t169
  %t172 = icmp eq i64 %t170, 4
  store i1 %t172, ptr %l86, !tbaa !21
  br label %bb53
bb53:
  %t173 = load i1, ptr %l86, !tbaa !21
  br i1 %t173, label %bb54, label %bb55
bb54:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [3 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t176, i32 0, i32 1
  %t178 = load ptr, ptr %t177
  store ptr %t178, ptr %l9, !tbaa !29
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr { i64, [3 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t182, i32 0, i32 2
  %t184 = load ptr, ptr %t183
  store ptr %t184, ptr %l10, !tbaa !29
  br label %bb56
bb55:
  br label %bb62
bb56:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t186, ptr %t187)
  br label %bb57
bb57:
  %t190 = load ptr, ptr %l10, !tbaa !29
  %t192 = icmp eq ptr %t190, null
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb58, label %bb59
bb58:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t196, ptr %t197)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb103
bb62:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t201 = load ptr, ptr %l100, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb63, label %bb64
bb63:
  %t204 = load ptr, ptr %l100, !tbaa !29
  %t205 = load i64, ptr %t204
  %t207 = icmp eq i64 %t205, 6
  store i1 %t207, ptr %l101, !tbaa !21
  br label %bb64
bb64:
  %t208 = load i1, ptr %l101, !tbaa !21
  br i1 %t208, label %bb65, label %bb66
bb65:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [3 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", ptr }, ptr %t211, i32 0, i32 1
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l11, !tbaa !29
  br label %bb71
bb66:
  %t215 = load ptr, ptr %l1, !tbaa !29
  store ptr %t215, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t216 = load ptr, ptr %l106, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb67, label %bb68
bb67:
  %t219 = load ptr, ptr %l106, !tbaa !29
  %t220 = load i64, ptr %t219
  %t222 = icmp eq i64 %t220, 16
  store i1 %t222, ptr %l107, !tbaa !21
  br label %bb68
bb68:
  %t223 = load i1, ptr %l107, !tbaa !21
  br i1 %t223, label %bb69, label %bb70
bb69:
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [3 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", ptr }, ptr %t226, i32 0, i32 1
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l11, !tbaa !29
  br label %bb71
bb70:
  br label %bb77
bb71:
  %t230 = load ptr, ptr %l11, !tbaa !29
  %t232 = icmp eq ptr %t230, null
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb72, label %bb73
bb72:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/free:mustW", ptr %t236, i32 0, i32 6
  %t239 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %t238, ptr %t239)
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t242, ptr %t243)
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb103
bb77:
  %t246 = load ptr, ptr %l1, !tbaa !29
  store ptr %t246, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t247 = load ptr, ptr %l120, !tbaa !29
  %t248 = icmp ne ptr %t247, null
  br i1 %t248, label %bb78, label %bb79
bb78:
  %t250 = load ptr, ptr %l120, !tbaa !29
  %t251 = load i64, ptr %t250
  %t253 = icmp eq i64 %t251, 11
  store i1 %t253, ptr %l121, !tbaa !21
  br label %bb79
bb79:
  %t254 = load i1, ptr %l121, !tbaa !21
  br i1 %t254, label %bb80, label %bb81
bb80:
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t257 = getelementptr { i64, [3 x i64] }, ptr %t255, i32 0, i32 1
  %t258 = getelementptr { %"compiler/source:Span", ptr }, ptr %t257, i32 0, i32 1
  %t259 = load ptr, ptr %t258
  store ptr %t259, ptr %l12, !tbaa !29
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t261, ptr %t262)
  br label %bb83
bb83:
  br label %bb103
bb84:
  %t265 = load ptr, ptr %l1, !tbaa !29
  store ptr %t265, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t266 = load ptr, ptr %l128, !tbaa !29
  %t267 = icmp ne ptr %t266, null
  br i1 %t267, label %bb85, label %bb86
bb85:
  %t269 = load ptr, ptr %l128, !tbaa !29
  %t270 = load i64, ptr %t269
  %t272 = icmp eq i64 %t270, 12
  store i1 %t272, ptr %l129, !tbaa !21
  br label %bb86
bb86:
  %t273 = load i1, ptr %l129, !tbaa !21
  br i1 %t273, label %bb87, label %bb88
bb87:
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t276 = getelementptr { i64, [3 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { %"compiler/source:Span", ptr }, ptr %t276, i32 0, i32 1
  %t278 = load ptr, ptr %t277
  store ptr %t278, ptr %l13, !tbaa !29
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t280, ptr %t281)
  br label %bb90
bb90:
  br label %bb103
bb91:
  %t284 = load ptr, ptr %l1, !tbaa !29
  store ptr %t284, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t285 = load ptr, ptr %l136, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb92, label %bb93
bb92:
  %t288 = load ptr, ptr %l136, !tbaa !29
  %t289 = load i64, ptr %t288
  %t291 = icmp eq i64 %t289, 13
  store i1 %t291, ptr %l137, !tbaa !21
  br label %bb93
bb93:
  %t292 = load i1, ptr %l137, !tbaa !21
  br i1 %t292, label %bb94, label %bb95
bb94:
  %t293 = load ptr, ptr %l1, !tbaa !29
  %t295 = getelementptr { i64, [3 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", ptr }, ptr %t295, i32 0, i32 1
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l14, !tbaa !29
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load ptr, ptr %l14, !tbaa !29
  %t302 = getelementptr %"compiler/typed:Join", ptr %t300, i32 0, i32 0
  %t303 = load ptr, ptr %t302, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t299, ptr %t303)
  br label %bb97
bb97:
  br label %bb103
bb98:
  br i1 true, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_6578a1c50e6256f2_162d732cc51ca876)
  unreachable
bb103:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/free:leaf"
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca ptr
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca i1
  %l41 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i32
  %l62 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca i64
  %l72 = alloca ptr
  %l75 = alloca i64
  %l76 = alloca ptr
  %l80 = alloca i1
  %l81 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i64
  %l101 = alloca ptr
  %l102 = alloca ptr
  %l103 = alloca %"compiler/source:Span"
  %l104 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l107 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l114 = alloca i64
  %l115 = alloca i64
  %l117 = alloca %"compiler/source:Span"
  %l118 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l122 = alloca i32
  %l123 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l125 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca i32
  %l138 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l142 = alloca i64
  %l143 = alloca i64
  %l145 = alloca %"compiler/source:Span"
  %l146 = alloca %"compiler/source:Span"
  %l153 = alloca i64
  %l155 = alloca ptr
  %l156 = alloca ptr
  %l158 = alloca i32
  %l163 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l164 = alloca ptr
  %l165 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i64
  %l172 = alloca ptr
  %l173 = alloca ptr
  %l174 = alloca %"compiler/source:Span"
  %l175 = alloca ptr
  %l177 = alloca %"compiler/source:Span"
  %l178 = alloca { i64, ptr }
  %l185 = alloca ptr
  %l187 = alloca i32
  %l188 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l190 = alloca i64
  %l192 = alloca ptr
  %l193 = alloca ptr
  %l195 = alloca i32
  %l200 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l203 = alloca ptr
  %l204 = alloca ptr
  %l205 = alloca %"compiler/source:Span"
  %l206 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l213 = alloca i64
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l19, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 9
  %t8 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePu_H51141c7f79c906b1679ae982392c7956(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %s0, ptr %t11, ptr %t12)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l25
  br label %bb3
bb3:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l5
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 9
  %t21 = call { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePo_H0db9b8972766e5b481cadc211ca24c07(ptr %v0, ptr %s0, ptr %t19)
  %t22 = extractvalue { i32, ptr } %t21, 1
  %t23 = extractvalue { i32, ptr } %t21, 0
  store i32 %t23, ptr %l30
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25
ok.25:
  store ptr %t22, ptr %l29
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l29, !tbaa !29
  store ptr %t26, ptr %l26, !tbaa !29
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t28 = load ptr, ptr %l31, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l31, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l32, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t38, i32 0, i32 2
  %t40 = load i32, ptr %t39
  store i32 %t40, ptr %l6, !tbaa !23
  br label %bb12
bb11:
  br label %bb23
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t45 = sext i32 %t43 to i64
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s0, ptr %t42, i64 %t45, ptr %l5)
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/free:walker", ptr %t49, i32 0, i32 7
  %t52 = load i32, ptr %l6, !tbaa !23
  %t54 = sext i32 %t52 to i64
  %t57 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t51, i64 %t54)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l47
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb15, label %ok.61
ok.61:
  store i64 %t58, ptr %l46
  br label %bb14
bb14:
  %t62 = load i64, ptr %l46, !tbaa !24
  store i64 %t62, ptr %l41, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l41, !tbaa !24
  br label %bb17
bb17:
  %t63 = load i64, ptr %l41, !tbaa !24
  store i64 %t63, ptr %l7, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t66 = icmp sge i64 %t64, 0
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v2, ptr %s0, ptr %t68, i64 %t69, ptr %t70, ptr %l5, %"compiler/source:Span" %t71)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l6, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t82 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyStore(ptr %v0, ptr %v2, ptr %t77, i64 %t80, ptr %t81, %"compiler/source:Span" %t82)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_620cc86993d1ee05_2ed463b6a2f232e1)
  unreachable
bb28:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t91 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %s0, ptr %t87, ptr %t88)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %l62
  br label %bb29
bb29:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:walker", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t99 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t95, ptr %t96)
  store i64 %t99, ptr %l66
  br label %bb30
bb30:
  %t100 = load i64, ptr %l66, !tbaa !24
  store i64 %t100, ptr %l8, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/free:walker", ptr %t101, i32 0, i32 2
  %t104 = load i1, ptr %t103, !tbaa !21
  br i1 %t104, label %bb31, label %bb32
bb31:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t108 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorStoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %t106, ptr %t107, ptr %t108)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l72, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t117 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %t113, ptr %t114)
  store i64 %t117, ptr %l75
  br label %bb35
bb35:
  %t118 = load i64, ptr %l75, !tbaa !24
  %t119 = load ptr, ptr %l72, !tbaa !29
  %t120 = getelementptr %"compiler/free:walker", ptr %t119, i32 0, i32 30
  store i64 %t118, ptr %t120, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l76, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l3, !tbaa !29
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t128 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esameValue(ptr %v0, ptr %v2, ptr %v1, ptr %t122, ptr %t123, ptr %t124)
  store i1 %t128, ptr %l80
  br label %bb36
bb36:
  %t129 = load i1, ptr %l80, !tbaa !21
  br i1 %t129, label %bb37, label %bb38
bb37:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t134 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einsidePlace(ptr %v0, ptr %v1, ptr %t130, ptr %t131)
  store i64 %t134, ptr %l84
  br label %bb39
bb38:
  store i64 -1, ptr %l81, !tbaa !24
  br label %bb40
bb39:
  %t135 = load i64, ptr %l84, !tbaa !24
  store i64 %t135, ptr %l81, !tbaa !24
  br label %bb40
bb40:
  %t136 = load i64, ptr %l81, !tbaa !24
  %t137 = load ptr, ptr %l76, !tbaa !29
  %t138 = getelementptr %"compiler/free:walker", ptr %t137, i32 0, i32 31
  store i64 %t136, ptr %t138, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t143 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t139, ptr %t140)
  store i64 %t143, ptr %l87
  br label %bb41
bb41:
  %t144 = load i64, ptr %l87, !tbaa !24
  store i64 %t144, ptr %l9, !tbaa !24
  %t145 = load i64, ptr %l9, !tbaa !24
  %t147 = icmp sge i64 %t145, 0
  br i1 %t147, label %bb42, label %bb43
bb42:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s0, ptr %t149, i64 %t150, ptr %l5)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  %t154 = load ptr, ptr %l2, !tbaa !29
  store ptr %t154, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t155 = load ptr, ptr %l93, !tbaa !29
  %t156 = icmp ne ptr %t155, null
  br i1 %t156, label %bb46, label %bb47
bb46:
  %t158 = load ptr, ptr %l93, !tbaa !29
  %t159 = load i64, ptr %t158
  %t161 = icmp eq i64 %t159, 3
  store i1 %t161, ptr %l94, !tbaa !21
  br label %bb47
bb47:
  %t162 = load i1, ptr %l94, !tbaa !21
  br i1 %t162, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb86
bb50:
  %t163 = load i64, ptr %l8, !tbaa !24
  %t165 = icmp sge i64 %t163, 0
  br i1 %t165, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l99, !tbaa !29
  %t168 = load i64, ptr %l8, !tbaa !24
  store i64 %t168, ptr %l100, !tbaa !24
  %t169 = load ptr, ptr %l3, !tbaa !29
  store ptr %t169, ptr %l101, !tbaa !29
  store ptr %l5, ptr %l102, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t170, ptr %l103
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l104, !tbaa !29
  %t172 = load ptr, ptr %l2, !tbaa !29
  %t174 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t172)
  store %"compiler/source:Span" %t174, ptr %l106
  br label %bb53
bb52:
  br label %bb59
bb53:
  %t175 = load ptr, ptr %l104, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l106
  %t177 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s8, ptr %t175, %"compiler/source:Span" %t176)
  store { i64, ptr } %t177, ptr %l107
  br label %bb54
bb54:
  %t178 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load i64, ptr %l9, !tbaa !24
  %t187 = icmp sge i64 %t185, 0
  %t188 = load ptr, ptr %l99, !tbaa !29
  %t189 = load i64, ptr %l100, !tbaa !24
  %t190 = load ptr, ptr %l101, !tbaa !29
  %t191 = load ptr, ptr %l102, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l103
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v2, ptr %s0, ptr %s8, ptr %t188, i64 %t189, ptr %t190, ptr %t191, %"compiler/source:Span" %t192, { i64, ptr } %t184, i1 %t187)
  br label %bb55
bb55:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/free:walker", ptr %t195, i32 0, i32 30
  store i64 -1, ptr %t197, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/free:walker", ptr %t198, i32 0, i32 31
  store i64 -1, ptr %t200, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l113, !tbaa !29
  %t202 = load i64, ptr %l8, !tbaa !24
  store i64 %t202, ptr %l114, !tbaa !24
  %t203 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  store i64 %t203, ptr %l115, !tbaa !24
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t206 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t204)
  store %"compiler/source:Span" %t206, ptr %l117
  br label %bb56
bb56:
  %t207 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 0, i32 0)
  store %"compiler/source:Span" %t207, ptr %l118
  br label %bb57
bb57:
  %t208 = load ptr, ptr %l113, !tbaa !29
  %t209 = load i64, ptr %l114, !tbaa !24
  %t210 = load i64, ptr %l115, !tbaa !24
  %t211 = load %"compiler/source:Span", ptr %l117
  %t212 = load %"compiler/source:Span", ptr %l118
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t208, i64 %t209, i64 %t210, %"compiler/source:Span" %t211, %"compiler/source:Span" %t212, i64 -1)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb59:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/free:walker", ptr %t213, i32 0, i32 0
  %t216 = load ptr, ptr %t215, !tbaa !29
  store ptr %t216, ptr %l120, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t219 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t217)
  store i32 %t219, ptr %l122
  br label %bb60
bb60:
  %t220 = load ptr, ptr %l120, !tbaa !29
  %t221 = load i32, ptr %l122, !tbaa !23
  %t222 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t220, i32 %t221)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t222, ptr %l123
  br label %bb61
bb61:
  %t223 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l123
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t223, ptr %l10
  store ptr %l10, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  %t225 = load ptr, ptr %l11, !tbaa !29
  %t226 = load i64, ptr %l12, !tbaa !24
  %t229 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eRunFrom_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %t225, i64 %t226)
  %t230 = extractvalue { i32, { i64, ptr } } %t229, 1
  %t231 = extractvalue { i32, { i64, ptr } } %t229, 0
  store i32 %t231, ptr %l129
  %t232 = icmp ne i32 %t231, 0
  br i1 %t232, label %bb64, label %ok.233
ok.233:
  store { i64, ptr } %t230, ptr %l128
  br label %bb63
bb63:
  %t234 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t234, ptr %l125, !tbaa !27
  br label %bb68
bb64:
  %t235 = load i32, ptr %l129, !tbaa !23
  %t236 = ashr i32 %t235, 16
  %t238 = icmp eq i32 %t236, 1
  br i1 %t238, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_e251e9e241135754_793c210c71879d50)
  unreachable
bb67:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s10)
  br label %bb79
bb68:
  %t240 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t240, ptr %l13, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t241, 0
  store i64 %t243, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s11
  %t245 = load i64, ptr %l15, !tbaa !24
  %t246 = load i64, ptr %l14, !tbaa !24
  %t249 = icmp slt i64 %t245, %t246
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s11)
  br label %bb77
bb71:
  br label %bb72
bb72:
  %t253 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t253, ptr %l138, !tbaa !27
  %t254 = load i64, ptr %l15, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr %"compiler/free:leaf", ptr %t257, i64 %t254
  %t259 = load %"compiler/free:leaf", ptr %t258
  store %"compiler/free:leaf" %t259, ptr %l16
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l141, !tbaa !29
  %t262 = getelementptr %"compiler/free:leaf", ptr %l16, i32 0, i32 1
  %t263 = load i64, ptr %t262, !tbaa !24
  store i64 %t263, ptr %l142, !tbaa !24
  %t264 = load i64, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  store i64 %t264, ptr %l143, !tbaa !24
  %t265 = load ptr, ptr %l2, !tbaa !29
  %t267 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t265)
  store %"compiler/source:Span" %t267, ptr %l145
  br label %bb73
bb73:
  %t268 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 0, i32 0)
  store %"compiler/source:Span" %t268, ptr %l146
  br label %bb74
bb74:
  %t269 = load ptr, ptr %l141, !tbaa !29
  %t270 = load i64, ptr %l142, !tbaa !24
  %t271 = load i64, ptr %l143, !tbaa !24
  %t272 = load %"compiler/source:Span", ptr %l145
  %t273 = load %"compiler/source:Span", ptr %l146
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t269, i64 %t270, i64 %t271, %"compiler/source:Span" %t272, %"compiler/source:Span" %t273, i64 -1)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s11)
  br label %bb76
bb76:
  %t274 = load i64, ptr %l15, !tbaa !24
  %t276 = add i64 %t274, 1
  store i64 %t276, ptr %l15, !tbaa !24
  br label %bb69
bb77:
  %t278 = load i64, ptr %l12, !tbaa !24
  %t279 = load i64, ptr %l14, !tbaa !24
  %t282 = add i64 %t278, %t279
  store i64 %t282, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb78
bb78:
  br label %bb62
bb79:
  %t285 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %l10)
  store i64 %t285, ptr %l153
  br label %bb80
bb80:
  %t286 = load i64, ptr %l153, !tbaa !24
  %t287 = icmp sgt i64 %t286, 0
  br i1 %t287, label %bb81, label %bb82
bb81:
  %t289 = load ptr, ptr %l0, !tbaa !29
  store ptr %t289, ptr %l155, !tbaa !29
  store ptr %l10, ptr %l156, !tbaa !29
  %t290 = load ptr, ptr %l2, !tbaa !29
  %t292 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t290)
  store i32 %t292, ptr %l158
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t293 = load ptr, ptr %l3, !tbaa !29
  %t294 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t296 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t294, ptr %t296
  %t297 = load %"compiler/source:Span", ptr %l1
  %t298 = load ptr, ptr %l155, !tbaa !29
  %t299 = load ptr, ptr %l156, !tbaa !29
  %t300 = load i32, ptr %l158, !tbaa !23
  %t304 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %v0, ptr %v2, ptr %s0, ptr %s0, ptr %t298, ptr %t299, i32 %t300, ptr %t293, ptr %t296, %"compiler/source:Span" %t297)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t304, ptr %l163
  br label %bb84
bb84:
  %t305 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l163
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t305, ptr %l5
  br label %bb85
bb85:
  br label %bb111
bb86:
  %t306 = load ptr, ptr %l2, !tbaa !29
  store ptr %t306, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t307 = load ptr, ptr %l164, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb87, label %bb88
bb87:
  %t310 = load ptr, ptr %l164, !tbaa !29
  %t311 = load i64, ptr %t310
  %t313 = icmp eq i64 %t311, 4
  store i1 %t313, ptr %l165, !tbaa !21
  br label %bb88
bb88:
  %t314 = load i1, ptr %l165, !tbaa !21
  br i1 %t314, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb106
bb91:
  %t315 = load i64, ptr %l8, !tbaa !24
  %t317 = icmp sge i64 %t315, 0
  br i1 %t317, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s15
  %t319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t319, ptr %l170, !tbaa !29
  %t320 = load i64, ptr %l8, !tbaa !24
  store i64 %t320, ptr %l171, !tbaa !24
  %t321 = load ptr, ptr %l3, !tbaa !29
  store ptr %t321, ptr %l172, !tbaa !29
  store ptr %l5, ptr %l173, !tbaa !29
  %t322 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t322, ptr %l174
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l175, !tbaa !29
  %t324 = load ptr, ptr %l2, !tbaa !29
  %t326 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t324)
  store %"compiler/source:Span" %t326, ptr %l177
  br label %bb94
bb93:
  br label %bb97
bb94:
  %t327 = load ptr, ptr %l175, !tbaa !29
  %t328 = load %"compiler/source:Span", ptr %l177
  %t329 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s15, ptr %t327, %"compiler/source:Span" %t328)
  store { i64, ptr } %t329, ptr %l178
  br label %bb95
bb95:
  %t330 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 0
  %t332 = extractvalue { i64, ptr } %t330, 1
  %t333 = mul i64 %t331, 1
  %t334 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t333)
  call void @llvm.memcpy.p0.p0.i64(ptr %t334, ptr %t332, i64 %t333, i1 false)
  %t335 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t334, 1
  %t337 = load i64, ptr %l9, !tbaa !24
  %t339 = icmp sge i64 %t337, 0
  %t340 = load ptr, ptr %l170, !tbaa !29
  %t341 = load i64, ptr %l171, !tbaa !24
  %t342 = load ptr, ptr %l172, !tbaa !29
  %t343 = load ptr, ptr %l173, !tbaa !29
  %t344 = load %"compiler/source:Span", ptr %l174
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v2, ptr %s0, ptr %s15, ptr %t340, i64 %t341, ptr %t342, ptr %t343, %"compiler/source:Span" %t344, { i64, ptr } %t336, i1 %t339)
  br label %bb96
bb96:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"compiler/free:walker", ptr %t347, i32 0, i32 30
  store i64 -1, ptr %t349, !tbaa !24
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/free:walker", ptr %t350, i32 0, i32 31
  store i64 -1, ptr %t352, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb97:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/free:walker", ptr %t353, i32 0, i32 0
  %t356 = load ptr, ptr %t355, !tbaa !29
  store ptr %t356, ptr %l185, !tbaa !29
  %t357 = load ptr, ptr %l2, !tbaa !29
  %t359 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t357)
  store i32 %t359, ptr %l187
  br label %bb98
bb98:
  %t360 = load ptr, ptr %l185, !tbaa !29
  %t361 = load i32, ptr %l187, !tbaa !23
  %t362 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t360, i32 %t361)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t362, ptr %l188
  br label %bb99
bb99:
  %t363 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l188
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t363, ptr %l17
  %t365 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %l17)
  store i64 %t365, ptr %l190
  br label %bb100
bb100:
  %t366 = load i64, ptr %l190, !tbaa !24
  %t367 = icmp sgt i64 %t366, 0
  br i1 %t367, label %bb101, label %bb102
bb101:
  %t369 = load ptr, ptr %l0, !tbaa !29
  store ptr %t369, ptr %l192, !tbaa !29
  store ptr %l17, ptr %l193, !tbaa !29
  %t370 = load ptr, ptr %l2, !tbaa !29
  %t372 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t370)
  store i32 %t372, ptr %l195
  br label %bb103
bb102:
  br label %bb105
bb103:
  %t373 = load ptr, ptr %l3, !tbaa !29
  %t374 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t376 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t374, ptr %t376
  %t377 = load %"compiler/source:Span", ptr %l1
  %t378 = load ptr, ptr %l192, !tbaa !29
  %t379 = load ptr, ptr %l193, !tbaa !29
  %t380 = load i32, ptr %l195, !tbaa !23
  %t384 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %v0, ptr %v2, ptr %s0, ptr %s0, ptr %t378, ptr %t379, i32 %t380, ptr %t373, ptr %t376, %"compiler/source:Span" %t377)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t384, ptr %l200
  br label %bb104
bb104:
  %t385 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l200
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t385, ptr %l5
  br label %bb105
bb105:
  br label %bb111
bb106:
  br i1 true, label %bb107, label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb111
bb110:
  call void @__olang_check_failed(ptr @olang_loc_7d1db60ec5fa7c8f_44fdf29e388dfc8b)
  unreachable
bb111:
  %t386 = load i64, ptr %l9, !tbaa !24
  %t388 = icmp slt i64 %t386, 0
  br i1 %t388, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s18
  %t390 = load ptr, ptr %l0, !tbaa !29
  store ptr %t390, ptr %l203, !tbaa !29
  store ptr %l5, ptr %l204, !tbaa !29
  %t391 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t391, ptr %l205
  %t392 = load ptr, ptr %l0, !tbaa !29
  store ptr %t392, ptr %l206, !tbaa !29
  %t393 = load ptr, ptr %l2, !tbaa !29
  %t395 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t393)
  store %"compiler/source:Span" %t395, ptr %l208
  br label %bb114
bb113:
  br label %bb118
bb114:
  %t396 = load ptr, ptr %l206, !tbaa !29
  %t397 = load %"compiler/source:Span", ptr %l208
  %t398 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s18, ptr %t396, %"compiler/source:Span" %t397)
  store { i64, ptr } %t398, ptr %l209
  br label %bb115
bb115:
  %t399 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t400 = extractvalue { i64, ptr } %t399, 0
  %t401 = extractvalue { i64, ptr } %t399, 1
  %t402 = mul i64 %t400, 1
  %t403 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t402)
  call void @llvm.memcpy.p0.p0.i64(ptr %t403, ptr %t401, i64 %t402, i1 false)
  %t404 = insertvalue { i64, ptr } undef, i64 %t400, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  store { i64, ptr } %t405, ptr %l210, !tbaa !27
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load ptr, ptr %l2, !tbaa !29
  %t410 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %t406, ptr %t407)
  store i64 %t410, ptr %l213
  br label %bb116
bb116:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/free:walker", ptr %t411, i32 0, i32 31
  %t414 = load i64, ptr %t413, !tbaa !24
  %t415 = load ptr, ptr %l203, !tbaa !29
  %t416 = load ptr, ptr %l204, !tbaa !29
  %t417 = load %"compiler/source:Span", ptr %l205
  %t418 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t419 = load i64, ptr %l213, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s0, ptr %s18, ptr %t415, ptr %t416, %"compiler/source:Span" %t417, { i64, ptr } %t418, i1 true, i64 %t419, i64 %t414)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s18)
  br label %bb118
bb118:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/free:walker", ptr %t421, i32 0, i32 30
  store i64 -1, ptr %t423, !tbaa !24
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/free:walker", ptr %t424, i32 0, i32 31
  store i64 -1, ptr %t426, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l6
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l6, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroys(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l78 = alloca i64
  %l82 = alloca i64
  %l86 = alloca i64
  %l90 = alloca i64
  %l93 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i64
  %l100 = alloca i64
  %l102 = alloca i64
  %l106 = alloca %"compiler/source:Span"
  %l113 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i64
  %l116 = alloca i64
  %l118 = alloca i64
  %l122 = alloca %"compiler/source:Span"
  %l126 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l129 = alloca i64
  %l133 = alloca i64
  %l136 = alloca i64
  %l157 = alloca i64
  %l169 = alloca i64
  %l172 = alloca i1
  %l176 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i64
  %l187 = alloca %"compiler/source:Span"
  %l189 = alloca ptr
  %l190 = alloca i64
  %l194 = alloca i64
  %l197 = alloca i64
  %l203 = alloca i64
  %l207 = alloca i64
  %l210 = alloca i64
  %l231 = alloca i1
  %l235 = alloca i1
  %l236 = alloca i1
  %l240 = alloca ptr
  %l243 = alloca i64
  %l244 = alloca i1
  %l246 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l249 = alloca i64
  %l253 = alloca i64
  %l256 = alloca i64
  %l277 = alloca i64
  %l289 = alloca i64
  %l295 = alloca ptr
  %l297 = alloca i64
  %l301 = alloca %"compiler/typed:Local"
  %l304 = alloca i64
  %l305 = alloca ptr
  %l306 = alloca i64
  %l307 = alloca i64
  %l309 = alloca i64
  %l313 = alloca %"compiler/source:Span"
  %l316 = alloca { i64, ptr }
  %l325 = alloca i1
  %l329 = alloca i1
  %l331 = alloca i64
  %l335 = alloca i64
  %l336 = alloca i32
  %l341 = alloca i64
  %l345 = alloca i64
  %l348 = alloca i64
  %l369 = alloca i64
  %l372 = alloca i1
  %l376 = alloca i64
  %l379 = alloca i1
  %l383 = alloca i64
  %l386 = alloca ptr
  %l387 = alloca i64
  %l388 = alloca i64
  %l390 = alloca i64
  %l394 = alloca %"compiler/source:Span"
  %l398 = alloca ptr
  %l400 = alloca i64
  %l401 = alloca ptr
  %l405 = alloca i64
  %l406 = alloca %"compiler/source:Span"
  %l409 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l47
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l47, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/free:walker", ptr %t10, i32 0, i32 46
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l50
  br label %bb2
bb2:
  %t15 = load i64, ptr %l50, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l57, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l57, !tbaa !24
  store i64 %t42, ptr %l54, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l54, !tbaa !24
  store i64 %t43, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb161
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l8, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/free:walker", ptr %t62, i32 0, i32 46
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t64, i64 %t65)
  store i64 %t68, ptr %l78
  br label %bb13
bb13:
  %t69 = load i64, ptr %l78, !tbaa !24
  store i64 %t69, ptr %l9, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:walker", ptr %t70, i32 0, i32 47
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t72, i64 %t73)
  store i64 %t76, ptr %l82
  br label %bb14
bb14:
  %t77 = load i64, ptr %l82, !tbaa !24
  store i64 %t77, ptr %l10, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/free:walker", ptr %t78, i32 0, i32 48
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t80, i64 %t81)
  store i64 %t84, ptr %l86
  br label %bb15
bb15:
  %t85 = load i64, ptr %l86, !tbaa !24
  store i64 %t85, ptr %l11, !tbaa !24
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/free:Free", ptr %t86, i32 0, i32 55
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t88, i64 %t89)
  store i64 %t92, ptr %l90
  br label %bb16
bb16:
  %t93 = load i64, ptr %l90, !tbaa !24
  store i64 %t93, ptr %l12, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l12, !tbaa !24
  %t98 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %s2, ptr %t94, i64 %t95)
  store { i64, ptr } %t98, ptr %l93
  br label %bb17
bb17:
  %t99 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t99, ptr %l13, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/free:walker", ptr %t100, i32 0, i32 6
  %t103 = load i64, ptr %l12, !tbaa !24
  %t106 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t102, i64 %t103)
  store i1 %t106, ptr %l97
  br label %bb18
bb18:
  %t107 = load i1, ptr %l97, !tbaa !21
  br i1 %t107, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l98, !tbaa !29
  %t109 = load i64, ptr %l9, !tbaa !24
  store i64 %t109, ptr %l99, !tbaa !24
  %t110 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t110, ptr %l100, !tbaa !24
  %t111 = load ptr, ptr %l2, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Body", ptr %t111, i32 0, i32 3
  %t114 = load i64, ptr %t113, !tbaa !24
  store i64 %t114, ptr %l102, !tbaa !24
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/free:Free", ptr %t115, i32 0, i32 56
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t117, i64 %t118)
  store %"compiler/source:Span" %t121, ptr %l106
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t122 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t126 = extractvalue { i64, ptr } %t122, 1
  %t127 = extractvalue { i64, ptr } %t122, 0
  %t128 = add i64 %t124, %t127
  %t129 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t131 = add i64 %t128, %t130
  %t132 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t131)
  call void @olang_textcopy(ptr %t132, ptr %t123, i64 %t124)
  %t133 = getelementptr i8, ptr %t132, i64 %t124
  call void @olang_textcopy(ptr %t133, ptr %t126, i64 %t127)
  %t134 = getelementptr i8, ptr %t133, i64 %t127
  call void @olang_textcopy(ptr %t134, ptr %t129, i64 %t130)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t132, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } %t136, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load ptr, ptr %l98, !tbaa !29
  %t145 = load i64, ptr %l99, !tbaa !24
  %t146 = load i64, ptr %l100, !tbaa !24
  %t147 = load i64, ptr %l102, !tbaa !24
  %t148 = load %"compiler/source:Span", ptr %l106
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s3, ptr %t144, i64 %t145, i64 %t146, i64 %t147, %"compiler/source:Span" %t148, { i64, ptr } %t143)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/free:walker", ptr %t150, i32 0, i32 7
  %t153 = load i64, ptr %l12, !tbaa !24
  %t156 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t152, i64 %t153)
  store i1 %t156, ptr %l113
  br label %bb24
bb24:
  %t157 = load i1, ptr %l113, !tbaa !21
  br i1 %t157, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l114, !tbaa !29
  %t159 = load i64, ptr %l9, !tbaa !24
  store i64 %t159, ptr %l115, !tbaa !24
  %t160 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t160, ptr %l116, !tbaa !24
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Body", ptr %t161, i32 0, i32 3
  %t164 = load i64, ptr %t163, !tbaa !24
  store i64 %t164, ptr %l118, !tbaa !24
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/free:Free", ptr %t165, i32 0, i32 56
  %t168 = load i64, ptr %l9, !tbaa !24
  %t171 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t167, i64 %t168)
  store %"compiler/source:Span" %t171, ptr %l122
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t172 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t176 = extractvalue { i64, ptr } %t172, 1
  %t177 = extractvalue { i64, ptr } %t172, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t173, i64 %t174)
  %t183 = getelementptr i8, ptr %t182, i64 %t174
  call void @olang_textcopy(ptr %t183, ptr %t176, i64 %t177)
  %t184 = getelementptr i8, ptr %t183, i64 %t177
  call void @olang_textcopy(ptr %t184, ptr %t179, i64 %t180)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t182, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = extractvalue { i64, ptr } %t186, 1
  %t190 = mul i64 %t188, 1
  %t191 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t190)
  call void @llvm.memcpy.p0.p0.i64(ptr %t191, ptr %t189, i64 %t190, i1 false)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  %t194 = load ptr, ptr %l114, !tbaa !29
  %t195 = load i64, ptr %l115, !tbaa !24
  %t196 = load i64, ptr %l116, !tbaa !24
  %t197 = load i64, ptr %l118, !tbaa !24
  %t198 = load %"compiler/source:Span", ptr %l122
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s5, ptr %t194, i64 %t195, i64 %t196, i64 %t197, %"compiler/source:Span" %t198, { i64, ptr } %t193)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t200 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t200, ptr %l126
  br label %bb30
bb30:
  %t201 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l126
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t201, ptr %l14
  store i64 0, ptr %l15, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/free:walker", ptr %t202, i32 0, i32 24
  %t206 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t204)
  store i64 %t206, ptr %l129
  br label %bb31
bb31:
  %t207 = load i64, ptr %l129, !tbaa !24
  store i64 %t207, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t208 = load i64, ptr %l16, !tbaa !24
  %t209 = load i64, ptr %l15, !tbaa !24
  %t212 = icmp sgt i64 %t208, %t209
  br i1 %t212, label %bb32, label %bb33
bb32:
  %t214 = load i64, ptr %l17, !tbaa !24
  %t216 = icmp sgt i64 %t214, 0
  br i1 %t216, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb37
bb34:
  %t218 = load i64, ptr %l16, !tbaa !24
  %t219 = load i64, ptr %l15, !tbaa !24
  %t222 = sub i64 %t218, %t219
  %t223 = load i64, ptr %l17, !tbaa !24
  %t226 = add i64 %t222, %t223
  %t228 = sub i64 %t226, 1
  %t229 = load i64, ptr %l17, !tbaa !24
  %t232 = sdiv i64 %t228, %t229
  store i64 %t232, ptr %l136, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb36
bb36:
  %t234 = load i64, ptr %l136, !tbaa !24
  store i64 %t234, ptr %l133, !tbaa !24
  br label %bb37
bb37:
  %t235 = load i64, ptr %l133, !tbaa !24
  store i64 %t235, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t236 = load i64, ptr %l19, !tbaa !24
  %t237 = load i64, ptr %l18, !tbaa !24
  %t240 = icmp slt i64 %t236, %t237
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb40:
  br label %bb41
bb41:
  %t244 = load i64, ptr %l15, !tbaa !24
  %t245 = load i64, ptr %l19, !tbaa !24
  %t246 = load i64, ptr %l17, !tbaa !24
  %t249 = mul i64 %t245, %t246
  %t252 = add i64 %t244, %t249
  store i64 %t252, ptr %l20, !tbaa !24
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/free:walker", ptr %t254, i32 0, i32 24
  %t257 = load i64, ptr %l20, !tbaa !24
  %t260 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t256, i64 %t257)
  store i64 %t260, ptr %l157
  br label %bb42
bb42:
  %t261 = load i64, ptr %l12, !tbaa !24
  %t262 = load i64, ptr %l157, !tbaa !24
  %t264 = icmp eq i64 %t262, %t261
  br i1 %t264, label %bb43, label %bb44
bb43:
  %t266 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s2, ptr %l14, i64 %t266)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s8)
  br label %bb47
bb47:
  %t269 = load i64, ptr %l19, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l19, !tbaa !24
  br label %bb38
bb48:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i64, ptr %l12, !tbaa !24
  %t275 = load i64, ptr %l10, !tbaa !24
  %t276 = load i64, ptr %l11, !tbaa !24
  %t282 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyAfter(ptr %v0, ptr %s2, ptr %t273, i64 %t274, i64 %t275, i64 %t276, ptr %l14)
  store i64 %t282, ptr %l169
  br label %bb49
bb49:
  %t283 = load i64, ptr %l169, !tbaa !24
  store i64 %t283, ptr %l21, !tbaa !24
  %t284 = load i64, ptr %l21, !tbaa !24
  %t286 = icmp sge i64 %t284, 0
  br i1 %t286, label %bb50, label %bb51
bb50:
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = getelementptr %"compiler/free:Free", ptr %t288, i32 0, i32 58
  %t291 = load i64, ptr %l9, !tbaa !24
  %t294 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t290, i64 %t291)
  store i1 %t294, ptr %l176
  br label %bb52
bb51:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb53
bb52:
  %t295 = load i1, ptr %l176, !tbaa !21
  %t296 = xor i1 %t295, true
  store i1 %t296, ptr %l172, !tbaa !21
  br label %bb53
bb53:
  %t298 = load i1, ptr %l172, !tbaa !21
  br i1 %t298, label %bb54, label %bb55
bb54:
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t301 = getelementptr %"compiler/free:Free", ptr %t299, i32 0, i32 58
  %t302 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t301, i64 %t302, i1 true)
  br label %bb56
bb55:
  br label %bb64
bb56:
  %t305 = load ptr, ptr %l1, !tbaa !29
  %t307 = getelementptr %"compiler/free:Free", ptr %t305, i32 0, i32 57
  store ptr %t307, ptr %l182, !tbaa !29
  %t308 = load i64, ptr %l9, !tbaa !24
  store i64 %t308, ptr %l183, !tbaa !24
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/free:walker", ptr %t309, i32 0, i32 26
  %t312 = load i64, ptr %l21, !tbaa !24
  %t315 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t311, i64 %t312)
  store %"compiler/source:Span" %t315, ptr %l187
  br label %bb57
bb57:
  %t316 = load ptr, ptr %l182, !tbaa !29
  %t317 = load i64, ptr %l183, !tbaa !24
  %t318 = load %"compiler/source:Span", ptr %l187
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t316, i64 %t317, %"compiler/source:Span" %t318)
  br label %bb58
bb58:
  %t319 = load ptr, ptr %l1, !tbaa !29
  %t321 = getelementptr %"compiler/free:Free", ptr %t319, i32 0, i32 59
  store ptr %t321, ptr %l189, !tbaa !29
  %t322 = load i64, ptr %l9, !tbaa !24
  store i64 %t322, ptr %l190, !tbaa !24
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/free:walker", ptr %t323, i32 0, i32 25
  %t326 = load i64, ptr %l21, !tbaa !24
  %t329 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t325, i64 %t326)
  store i64 %t329, ptr %l194
  br label %bb59
bb59:
  %t330 = load i64, ptr %l11, !tbaa !24
  %t332 = icmp sge i64 %t330, 0
  br i1 %t332, label %bb60, label %bb61
bb60:
  %t334 = load i64, ptr %l11, !tbaa !24
  store i64 %t334, ptr %l197, !tbaa !24
  br label %bb62
bb61:
  %t336 = load i64, ptr %l10, !tbaa !24
  store i64 %t336, ptr %l197, !tbaa !24
  br label %bb62
bb62:
  %t338 = load i64, ptr %l194, !tbaa !24
  %t339 = load i64, ptr %l197, !tbaa !24
  %t340 = icmp sle i64 %t338, %t339
  %t341 = load ptr, ptr %l189, !tbaa !29
  %t342 = load i64, ptr %l190, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t341, i64 %t342, i1 %t340)
  br label %bb63
bb63:
  br label %bb64
bb64:
  store i64 0, ptr %l22, !tbaa !24
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/free:walker", ptr %t344, i32 0, i32 3
  %t348 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_He8628b0a6160e3784b3615fe3f392582(ptr %v0, ptr %t346)
  store i64 %t348, ptr %l203
  br label %bb65
bb65:
  %t349 = load i64, ptr %l203, !tbaa !24
  store i64 %t349, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t350 = load i64, ptr %l23, !tbaa !24
  %t351 = load i64, ptr %l22, !tbaa !24
  %t354 = icmp sgt i64 %t350, %t351
  br i1 %t354, label %bb66, label %bb67
bb66:
  %t356 = load i64, ptr %l24, !tbaa !24
  %t358 = icmp sgt i64 %t356, 0
  br i1 %t358, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb71
bb68:
  %t360 = load i64, ptr %l23, !tbaa !24
  %t361 = load i64, ptr %l22, !tbaa !24
  %t364 = sub i64 %t360, %t361
  %t365 = load i64, ptr %l24, !tbaa !24
  %t368 = add i64 %t364, %t365
  %t370 = sub i64 %t368, 1
  %t371 = load i64, ptr %l24, !tbaa !24
  %t374 = sdiv i64 %t370, %t371
  store i64 %t374, ptr %l210, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l210, !tbaa !24
  br label %bb70
bb70:
  %t376 = load i64, ptr %l210, !tbaa !24
  store i64 %t376, ptr %l207, !tbaa !24
  br label %bb71
bb71:
  %t377 = load i64, ptr %l207, !tbaa !24
  store i64 %t377, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s13
  %t378 = load i64, ptr %l26, !tbaa !24
  %t379 = load i64, ptr %l25, !tbaa !24
  %t382 = icmp slt i64 %t378, %t379
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s13)
  br label %bb118
bb74:
  br label %bb75
bb75:
  %t386 = load i64, ptr %l22, !tbaa !24
  %t387 = load i64, ptr %l26, !tbaa !24
  %t388 = load i64, ptr %l24, !tbaa !24
  %t391 = mul i64 %t387, %t388
  %t394 = add i64 %t386, %t391
  store i64 %t394, ptr %l27, !tbaa !24
  %t396 = load i64, ptr %l27, !tbaa !24
  %t397 = load i64, ptr %l12, !tbaa !24
  %t400 = icmp eq i64 %t396, %t397
  br i1 %t400, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l231, !tbaa !21
  br label %bb79
bb77:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/free:walker", ptr %t402, i32 0, i32 6
  %t405 = load i64, ptr %l27, !tbaa !24
  %t408 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t404, i64 %t405)
  store i1 %t408, ptr %l235
  br label %bb78
bb78:
  %t409 = load i1, ptr %l235, !tbaa !21
  store i1 %t409, ptr %l231, !tbaa !21
  br label %bb79
bb79:
  %t410 = load i1, ptr %l231, !tbaa !21
  br i1 %t410, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l236, !tbaa !21
  br label %bb85
bb81:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/free:walker", ptr %t411, i32 0, i32 3
  %t414 = load i64, ptr %l27, !tbaa !24
  %t417 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t413, i64 %t414)
  store ptr %t417, ptr %l240
  br label %bb82
bb82:
  %t418 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t419 = load i64, ptr %l9, !tbaa !24
  %t422 = call i64 @compiler_2ffree_2eorig(i64 %t418, i64 %t419)
  store i64 %t422, ptr %l243
  br label %bb83
bb83:
  %t423 = load ptr, ptr %l240, !tbaa !29
  %t424 = load i64, ptr %l243, !tbaa !24
  %t425 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t423, i64 %t424)
  store i1 %t425, ptr %l244
  br label %bb84
bb84:
  %t426 = load i1, ptr %l244, !tbaa !21
  %t427 = xor i1 %t426, true
  store i1 %t427, ptr %l236, !tbaa !21
  br label %bb85
bb85:
  %t429 = load i1, ptr %l236, !tbaa !21
  br i1 %t429, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s13)
  br label %bb117
bb87:
  br label %bb88
bb88:
  %t430 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s13)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t430, ptr %l246
  br label %bb89
bb89:
  %t431 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l246
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t431, ptr %l28
  store i64 0, ptr %l29, !tbaa !24
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/free:walker", ptr %t432, i32 0, i32 24
  %t436 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t434)
  store i64 %t436, ptr %l249
  br label %bb90
bb90:
  %t437 = load i64, ptr %l249, !tbaa !24
  store i64 %t437, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t438 = load i64, ptr %l30, !tbaa !24
  %t439 = load i64, ptr %l29, !tbaa !24
  %t442 = icmp sgt i64 %t438, %t439
  br i1 %t442, label %bb91, label %bb92
bb91:
  %t444 = load i64, ptr %l31, !tbaa !24
  %t446 = icmp sgt i64 %t444, 0
  br i1 %t446, label %bb93, label %bb94
bb92:
  store i64 0, ptr %l253, !tbaa !24
  br label %bb96
bb93:
  %t448 = load i64, ptr %l30, !tbaa !24
  %t449 = load i64, ptr %l29, !tbaa !24
  %t452 = sub i64 %t448, %t449
  %t453 = load i64, ptr %l31, !tbaa !24
  %t456 = add i64 %t452, %t453
  %t458 = sub i64 %t456, 1
  %t459 = load i64, ptr %l31, !tbaa !24
  %t462 = sdiv i64 %t458, %t459
  store i64 %t462, ptr %l256, !tbaa !24
  br label %bb95
bb94:
  store i64 0, ptr %l256, !tbaa !24
  br label %bb95
bb95:
  %t464 = load i64, ptr %l256, !tbaa !24
  store i64 %t464, ptr %l253, !tbaa !24
  br label %bb96
bb96:
  %t465 = load i64, ptr %l253, !tbaa !24
  store i64 %t465, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb97
bb97:
  store %olang.scope zeroinitializer, ptr %s16
  %t466 = load i64, ptr %l33, !tbaa !24
  %t467 = load i64, ptr %l32, !tbaa !24
  %t470 = icmp slt i64 %t466, %t467
  %t472 = xor i1 %t470, true
  br i1 %t472, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s16)
  br label %bb107
bb99:
  br label %bb100
bb100:
  %t474 = load i64, ptr %l29, !tbaa !24
  %t475 = load i64, ptr %l33, !tbaa !24
  %t476 = load i64, ptr %l31, !tbaa !24
  %t479 = mul i64 %t475, %t476
  %t482 = add i64 %t474, %t479
  store i64 %t482, ptr %l34, !tbaa !24
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t486 = getelementptr %"compiler/free:walker", ptr %t484, i32 0, i32 24
  %t487 = load i64, ptr %l34, !tbaa !24
  %t490 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t486, i64 %t487)
  store i64 %t490, ptr %l277
  br label %bb101
bb101:
  %t491 = load i64, ptr %l27, !tbaa !24
  %t492 = load i64, ptr %l277, !tbaa !24
  %t494 = icmp eq i64 %t492, %t491
  br i1 %t494, label %bb102, label %bb103
bb102:
  %t496 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s13, ptr %l28, i64 %t496)
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s16)
  br label %bb106
bb106:
  %t499 = load i64, ptr %l33, !tbaa !24
  %t501 = add i64 %t499, 1
  store i64 %t501, ptr %l33, !tbaa !24
  br label %bb97
bb107:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load i64, ptr %l27, !tbaa !24
  %t505 = load i64, ptr %l10, !tbaa !24
  %t506 = load i64, ptr %l11, !tbaa !24
  %t512 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyAfter(ptr %v0, ptr %s13, ptr %t503, i64 %t504, i64 %t505, i64 %t506, ptr %l28)
  store i64 %t512, ptr %l289
  br label %bb108
bb108:
  %t513 = load i64, ptr %l289, !tbaa !24
  store i64 %t513, ptr %l35, !tbaa !24
  %t514 = load i64, ptr %l35, !tbaa !24
  %t516 = icmp slt i64 %t514, 0
  br i1 %t516, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s13)
  br label %bb117
bb110:
  br label %bb111
bb111:
  %t518 = load ptr, ptr %l1, !tbaa !29
  %t520 = getelementptr %"compiler/free:Free", ptr %t518, i32 0, i32 0
  %t521 = load ptr, ptr %t520, !tbaa !29
  %t523 = getelementptr %"compiler/generic:Program", ptr %t521, i32 0, i32 0
  %t524 = load ptr, ptr %t523, !tbaa !29
  %t526 = getelementptr %"compiler/load:Loader", ptr %t524, i32 0, i32 4
  %t527 = load ptr, ptr %t526, !tbaa !29
  store ptr %t527, ptr %l295, !tbaa !29
  %t528 = load ptr, ptr %l2, !tbaa !29
  %t530 = getelementptr %"compiler/typed:Body", ptr %t528, i32 0, i32 3
  %t531 = load i64, ptr %t530, !tbaa !24
  store i64 %t531, ptr %l297, !tbaa !24
  %t532 = load ptr, ptr %l2, !tbaa !29
  %t534 = getelementptr %"compiler/typed:Body", ptr %t532, i32 0, i32 7
  %t535 = load i64, ptr %l27, !tbaa !24
  %t538 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t534, i64 %t535)
  store %"compiler/typed:Local" %t538, ptr %l301
  br label %bb112
bb112:
  %t539 = getelementptr %"compiler/typed:Local", ptr %l301, i32 0, i32 1
  %t540 = getelementptr %"compiler/source:Span", ptr %t539, i32 0, i32 0
  %t541 = load i32, ptr %t540, !tbaa !23
  %t543 = sext i32 %t541 to i64
  %t544 = load ptr, ptr %l295, !tbaa !29
  %t545 = load i64, ptr %l297, !tbaa !24
  %t547 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t544, i64 %t545, i64 %t543)
  store i64 %t547, ptr %l304
  br label %bb113
bb113:
  %t548 = load i64, ptr %l304, !tbaa !24
  store i64 %t548, ptr %l36, !tbaa !24
  %t549 = load ptr, ptr %l1, !tbaa !29
  store ptr %t549, ptr %l305, !tbaa !29
  %t550 = load i64, ptr %l9, !tbaa !24
  store i64 %t550, ptr %l306, !tbaa !24
  %t551 = load i64, ptr @G_2ecompiler_2ffree_2eRView, !tbaa !24
  store i64 %t551, ptr %l307, !tbaa !24
  %t552 = load ptr, ptr %l2, !tbaa !29
  %t554 = getelementptr %"compiler/typed:Body", ptr %t552, i32 0, i32 3
  %t555 = load i64, ptr %t554, !tbaa !24
  store i64 %t555, ptr %l309, !tbaa !24
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/free:walker", ptr %t556, i32 0, i32 26
  %t559 = load i64, ptr %l35, !tbaa !24
  %t562 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t558, i64 %t559)
  store %"compiler/source:Span" %t562, ptr %l313
  br label %bb114
bb114:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load i64, ptr %l27, !tbaa !24
  %t567 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %s13, ptr %t563, i64 %t564)
  store { i64, ptr } %t567, ptr %l316
  br label %bb115
bb115:
  %t568 = load i64, ptr %l36, !tbaa !24
  %t569 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t570 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t571 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t572 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t573 = extractvalue { i64, ptr } %t572, 1
  %t574 = extractvalue { i64, ptr } %t572, 0
  %t575 = add i64 %t571, %t574
  %t576 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t577 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t578 = add i64 %t575, %t577
  %t580 = call i64 @__olang_fmt_i64(ptr null, i64 %t568)
  %t581 = add i64 %t578, %t580
  %t582 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t583 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t584 = add i64 %t581, %t583
  %t586 = extractvalue { i64, ptr } %t569, 1
  %t587 = extractvalue { i64, ptr } %t569, 0
  %t588 = add i64 %t584, %t587
  %t589 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t590 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t591 = add i64 %t588, %t590
  %t592 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t591)
  call void @olang_textcopy(ptr %t592, ptr %t570, i64 %t571)
  %t593 = getelementptr i8, ptr %t592, i64 %t571
  call void @olang_textcopy(ptr %t593, ptr %t573, i64 %t574)
  %t594 = getelementptr i8, ptr %t593, i64 %t574
  call void @olang_textcopy(ptr %t594, ptr %t576, i64 %t577)
  %t595 = getelementptr i8, ptr %t594, i64 %t577
  %t596 = call i64 @__olang_fmt_i64(ptr %t595, i64 %t568)
  %t597 = getelementptr i8, ptr %t595, i64 %t580
  call void @olang_textcopy(ptr %t597, ptr %t582, i64 %t583)
  %t598 = getelementptr i8, ptr %t597, i64 %t583
  call void @olang_textcopy(ptr %t598, ptr %t586, i64 %t587)
  %t599 = getelementptr i8, ptr %t598, i64 %t587
  call void @olang_textcopy(ptr %t599, ptr %t589, i64 %t590)
  %t600 = insertvalue { i64, ptr } undef, i64 %t591, 0
  %t601 = insertvalue { i64, ptr } %t600, ptr %t592, 1
  %t603 = extractvalue { i64, ptr } %t601, 0
  %t604 = extractvalue { i64, ptr } %t601, 1
  %t605 = mul i64 %t603, 1
  %t606 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t605)
  call void @llvm.memcpy.p0.p0.i64(ptr %t606, ptr %t604, i64 %t605, i1 false)
  %t607 = insertvalue { i64, ptr } undef, i64 %t603, 0
  %t608 = insertvalue { i64, ptr } %t607, ptr %t606, 1
  %t609 = load ptr, ptr %l305, !tbaa !29
  %t610 = load i64, ptr %l306, !tbaa !24
  %t611 = load i64, ptr %l307, !tbaa !24
  %t612 = load i64, ptr %l309, !tbaa !24
  %t613 = load %"compiler/source:Span", ptr %l313
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s13, ptr %t609, i64 %t610, i64 %t611, i64 %t612, %"compiler/source:Span" %t613, { i64, ptr } %t608)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s13)
  br label %bb117
bb117:
  %t615 = load i64, ptr %l26, !tbaa !24
  %t617 = add i64 %t615, 1
  store i64 %t617, ptr %l26, !tbaa !24
  br label %bb72
bb118:
  %t619 = load i64, ptr %l11, !tbaa !24
  %t621 = icmp sge i64 %t619, 0
  br i1 %t621, label %bb119, label %bb120
bb119:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t625 = getelementptr %"compiler/free:walker", ptr %t623, i32 0, i32 57
  %t626 = load i64, ptr %l11, !tbaa !24
  %t629 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t625, i64 %t626)
  store i1 %t629, ptr %l329
  br label %bb121
bb120:
  store i1 false, ptr %l325, !tbaa !21
  br label %bb122
bb121:
  %t630 = load i1, ptr %l329, !tbaa !21
  %t631 = xor i1 %t630, true
  store i1 %t631, ptr %l325, !tbaa !21
  br label %bb122
bb122:
  %t633 = load i1, ptr %l325, !tbaa !21
  br i1 %t633, label %bb123, label %bb124
bb123:
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t636 = getelementptr %"compiler/free:walker", ptr %t634, i32 0, i32 53
  %t637 = load i64, ptr %l11, !tbaa !24
  %t640 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t636, i64 %t637)
  %t641 = extractvalue { i32, i64 } %t640, 1
  %t642 = extractvalue { i32, i64 } %t640, 0
  store i32 %t642, ptr %l336
  %t643 = icmp ne i32 %t642, 0
  br i1 %t643, label %bb126, label %ok.644
ok.644:
  store i64 %t641, ptr %l335
  br label %bb125
bb124:
  br label %bb159
bb125:
  %t645 = load i64, ptr %l335, !tbaa !24
  store i64 %t645, ptr %l331, !tbaa !24
  br label %bb128
bb126:
  br label %bb127
bb127:
  call void @__olang_ert_req_clear()
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t648 = getelementptr %"compiler/free:walker", ptr %t646, i32 0, i32 11
  %t649 = load i64, ptr %t648, !tbaa !24
  store i64 %t649, ptr %l331, !tbaa !24
  br label %bb128
bb128:
  %t651 = load i64, ptr %l331, !tbaa !24
  store i64 %t651, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t654 = getelementptr %"compiler/free:walker", ptr %t652, i32 0, i32 49
  %t656 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t654)
  store i64 %t656, ptr %l341
  br label %bb129
bb129:
  %t657 = load i64, ptr %l341, !tbaa !24
  store i64 %t657, ptr %l39, !tbaa !24
  store i64 1, ptr %l40, !tbaa !24
  %t658 = load i64, ptr %l39, !tbaa !24
  %t659 = load i64, ptr %l38, !tbaa !24
  %t662 = icmp sgt i64 %t658, %t659
  br i1 %t662, label %bb130, label %bb131
bb130:
  %t664 = load i64, ptr %l40, !tbaa !24
  %t666 = icmp sgt i64 %t664, 0
  br i1 %t666, label %bb132, label %bb133
bb131:
  store i64 0, ptr %l345, !tbaa !24
  br label %bb135
bb132:
  %t668 = load i64, ptr %l39, !tbaa !24
  %t669 = load i64, ptr %l38, !tbaa !24
  %t672 = sub i64 %t668, %t669
  %t673 = load i64, ptr %l40, !tbaa !24
  %t676 = add i64 %t672, %t673
  %t678 = sub i64 %t676, 1
  %t679 = load i64, ptr %l40, !tbaa !24
  %t682 = sdiv i64 %t678, %t679
  store i64 %t682, ptr %l348, !tbaa !24
  br label %bb134
bb133:
  store i64 0, ptr %l348, !tbaa !24
  br label %bb134
bb134:
  %t684 = load i64, ptr %l348, !tbaa !24
  store i64 %t684, ptr %l345, !tbaa !24
  br label %bb135
bb135:
  %t685 = load i64, ptr %l345, !tbaa !24
  store i64 %t685, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  br label %bb136
bb136:
  store %olang.scope zeroinitializer, ptr %s24
  %t686 = load i64, ptr %l42, !tbaa !24
  %t687 = load i64, ptr %l41, !tbaa !24
  %t690 = icmp slt i64 %t686, %t687
  %t692 = xor i1 %t690, true
  br i1 %t692, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s24)
  br label %bb158
bb138:
  br label %bb139
bb139:
  %t694 = load i64, ptr %l38, !tbaa !24
  %t695 = load i64, ptr %l42, !tbaa !24
  %t696 = load i64, ptr %l40, !tbaa !24
  %t699 = mul i64 %t695, %t696
  %t702 = add i64 %t694, %t699
  store i64 %t702, ptr %l43, !tbaa !24
  %t704 = load ptr, ptr %l0, !tbaa !29
  %t706 = getelementptr %"compiler/free:walker", ptr %t704, i32 0, i32 49
  %t707 = load i64, ptr %l43, !tbaa !24
  %t710 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t706, i64 %t707)
  store i64 %t710, ptr %l369
  br label %bb140
bb140:
  %t711 = load i64, ptr %l9, !tbaa !24
  %t712 = load i64, ptr %l369, !tbaa !24
  %t714 = icmp eq i64 %t712, %t711
  br i1 %t714, label %bb141, label %bb142
bb141:
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t718 = getelementptr %"compiler/free:walker", ptr %t716, i32 0, i32 50
  %t719 = load i64, ptr %l43, !tbaa !24
  %t722 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t718, i64 %t719)
  store i64 %t722, ptr %l376
  br label %bb143
bb142:
  store i1 false, ptr %l372, !tbaa !21
  br label %bb144
bb143:
  %t723 = load i64, ptr %l11, !tbaa !24
  %t724 = load i64, ptr %l376, !tbaa !24
  %t726 = icmp sgt i64 %t724, %t723
  store i1 %t726, ptr %l372, !tbaa !21
  br label %bb144
bb144:
  %t728 = load i1, ptr %l372, !tbaa !21
  br i1 %t728, label %bb145, label %bb146
bb145:
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t731 = getelementptr %"compiler/free:walker", ptr %t729, i32 0, i32 50
  %t732 = load i64, ptr %l43, !tbaa !24
  %t735 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t731, i64 %t732)
  store i64 %t735, ptr %l383
  br label %bb147
bb146:
  store i1 false, ptr %l379, !tbaa !21
  br label %bb148
bb147:
  %t736 = load i64, ptr %l37, !tbaa !24
  %t737 = load i64, ptr %l383, !tbaa !24
  %t739 = icmp sle i64 %t737, %t736
  store i1 %t739, ptr %l379, !tbaa !21
  br label %bb148
bb148:
  %t741 = load i1, ptr %l379, !tbaa !21
  br i1 %t741, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s25
  %t742 = load ptr, ptr %l1, !tbaa !29
  store ptr %t742, ptr %l386, !tbaa !29
  %t743 = load i64, ptr %l9, !tbaa !24
  store i64 %t743, ptr %l387, !tbaa !24
  %t744 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t744, ptr %l388, !tbaa !24
  %t745 = load ptr, ptr %l2, !tbaa !29
  %t747 = getelementptr %"compiler/typed:Body", ptr %t745, i32 0, i32 3
  %t748 = load i64, ptr %t747, !tbaa !24
  store i64 %t748, ptr %l390, !tbaa !24
  %t749 = load ptr, ptr %l1, !tbaa !29
  %t751 = getelementptr %"compiler/free:Free", ptr %t749, i32 0, i32 56
  %t752 = load i64, ptr %l9, !tbaa !24
  %t755 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t751, i64 %t752)
  store %"compiler/source:Span" %t755, ptr %l394
  br label %bb151
bb150:
  br label %bb156
bb151:
  %t756 = load ptr, ptr %l1, !tbaa !29
  %t758 = getelementptr %"compiler/free:Free", ptr %t756, i32 0, i32 0
  %t759 = load ptr, ptr %t758, !tbaa !29
  %t761 = getelementptr %"compiler/generic:Program", ptr %t759, i32 0, i32 0
  %t762 = load ptr, ptr %t761, !tbaa !29
  %t764 = getelementptr %"compiler/load:Loader", ptr %t762, i32 0, i32 4
  %t765 = load ptr, ptr %t764, !tbaa !29
  store ptr %t765, ptr %l398, !tbaa !29
  %t766 = load ptr, ptr %l2, !tbaa !29
  %t768 = getelementptr %"compiler/typed:Body", ptr %t766, i32 0, i32 3
  %t769 = load i64, ptr %t768, !tbaa !24
  store i64 %t769, ptr %l400, !tbaa !24
  %t770 = load ptr, ptr %l0, !tbaa !29
  store ptr %t770, ptr %l401, !tbaa !29
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t773 = getelementptr %"compiler/free:walker", ptr %t771, i32 0, i32 50
  %t774 = load i64, ptr %l43, !tbaa !24
  %t777 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t773, i64 %t774)
  store i64 %t777, ptr %l405
  br label %bb152
bb152:
  %t778 = load ptr, ptr %l401, !tbaa !29
  %t779 = load i64, ptr %l405, !tbaa !24
  %t780 = call %"compiler/source:Span" @compiler_2ffree_2ecompiler_2ffree_3awalker_2euseSpAt(ptr %v0, ptr %t778, i64 %t779)
  store %"compiler/source:Span" %t780, ptr %l406
  br label %bb153
bb153:
  %t781 = getelementptr %"compiler/source:Span", ptr %l406, i32 0, i32 0
  %t782 = load i32, ptr %t781, !tbaa !23
  %t784 = sext i32 %t782 to i64
  %t785 = load ptr, ptr %l398, !tbaa !29
  %t786 = load i64, ptr %l400, !tbaa !24
  %t788 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t785, i64 %t786, i64 %t784)
  store i64 %t788, ptr %l409
  br label %bb154
bb154:
  %t789 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t790 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t791 = load i64, ptr %l409, !tbaa !24
  %t792 = call i64 @__olang_fmt_i64(ptr null, i64 %t791)
  %t793 = add i64 %t790, %t792
  %t794 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t795 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t796 = add i64 %t793, %t795
  %t797 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t796)
  call void @olang_textcopy(ptr %t797, ptr %t789, i64 %t790)
  %t798 = getelementptr i8, ptr %t797, i64 %t790
  %t799 = call i64 @__olang_fmt_i64(ptr %t798, i64 %t791)
  %t800 = getelementptr i8, ptr %t798, i64 %t792
  call void @olang_textcopy(ptr %t800, ptr %t794, i64 %t795)
  %t801 = insertvalue { i64, ptr } undef, i64 %t796, 0
  %t802 = insertvalue { i64, ptr } %t801, ptr %t797, 1
  %t804 = extractvalue { i64, ptr } %t802, 0
  %t805 = extractvalue { i64, ptr } %t802, 1
  %t806 = mul i64 %t804, 1
  %t807 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t806)
  call void @llvm.memcpy.p0.p0.i64(ptr %t807, ptr %t805, i64 %t806, i1 false)
  %t808 = insertvalue { i64, ptr } undef, i64 %t804, 0
  %t809 = insertvalue { i64, ptr } %t808, ptr %t807, 1
  %t810 = load ptr, ptr %l386, !tbaa !29
  %t811 = load i64, ptr %l387, !tbaa !24
  %t812 = load i64, ptr %l388, !tbaa !24
  %t813 = load i64, ptr %l390, !tbaa !24
  %t814 = load %"compiler/source:Span", ptr %l394
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s25, ptr %t810, i64 %t811, i64 %t812, i64 %t813, %"compiler/source:Span" %t814, { i64, ptr } %t809)
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s25)
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s24)
  br label %bb157
bb157:
  %t816 = load i64, ptr %l42, !tbaa !24
  %t818 = add i64 %t816, 1
  store i64 %t818, ptr %l42, !tbaa !24
  br label %bb136
bb158:
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s2)
  br label %bb160
bb160:
  %t820 = load i64, ptr %l7, !tbaa !24
  %t822 = add i64 %t820, 1
  store i64 %t822, ptr %l7, !tbaa !24
  br label %bb9
bb161:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %l13 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %t9, ptr %a2)
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:walker", ptr %t13, i32 0, i32 4
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t15, i64 %t16)
  store i1 %t19, ptr %l13
  br label %bb5
bb4:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i1, ptr %l13, !tbaa !21
  store i1 %t20, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:walker", ptr %t22, i32 0, i32 5
  store i1 true, ptr %t24, !tbaa !21
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ehandedToTask(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i1
  %l38 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l44 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l57 = alloca ptr
  %l60 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l68 = alloca i1
  %l69 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i32
  %l86 = alloca { i64, ptr }
  %l90 = alloca i64
  %l93 = alloca i1
  %l94 = alloca ptr
  %l96 = alloca i64
  %l97 = alloca i1
  %l98 = alloca ptr
  %l100 = alloca i64
  %l101 = alloca i64
  %l103 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l20
  br label %bb1
bb1:
  %t7 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l4
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l21, !tbaa !29
  %t9 = load ptr, ptr %l21, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t9, i32 0, i32 29
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = add i64 %t11, 1
  %t15 = load ptr, ptr %l21, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t15, i32 0, i32 29
  store i64 %t13, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t18 = load ptr, ptr %l24, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load ptr, ptr %l24, !tbaa !29
  %t22 = load i64, ptr %t21
  %t24 = icmp eq i64 %t22, 6
  store i1 %t24, ptr %l25, !tbaa !21
  br label %bb3
bb3:
  %t25 = load i1, ptr %l25, !tbaa !21
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t28, i32 0, i32 2
  %t30 = load ptr, ptr %t29
  store ptr %t30, ptr %l5, !tbaa !29
  br label %bb6
bb5:
  br label %bb28
bb6:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Call", ptr %t32, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t49 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t49, ptr %l38, !tbaa !27
  %t50 = load i64, ptr %l7, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr ptr, ptr %t53, i64 %t50
  %t55 = load ptr, ptr %t54, !tbaa !39
  store ptr %l4, ptr %l41, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t61 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s3, ptr %t57, ptr %t55)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l44
  br label %bb11
bb11:
  %t62 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  %t63 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %t63
  %t64 = load ptr, ptr %l41, !tbaa !29
  %t66 = call i1 @compiler_2ffree_2eaddAllTo(ptr %s0, ptr %s3, ptr %t64, ptr %t63)
  store i1 %t66, ptr %l46
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l7, !tbaa !24
  br label %bb7
bb14:
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Call", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  store ptr %t74, ptr %l10, !tbaa !29
  %t76 = load ptr, ptr %l10, !tbaa !29
  store ptr %t76, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t77 = load ptr, ptr %l51, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb15, label %bb16
bb15:
  %t80 = load ptr, ptr %l51, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 2
  store i1 %t83, ptr %l52, !tbaa !21
  br label %bb16
bb16:
  %t84 = load i1, ptr %l52, !tbaa !21
  br i1 %t84, label %bb17, label %bb18
bb17:
  %t85 = load ptr, ptr %l10, !tbaa !29
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { ptr }, ptr %t87, i32 0, i32 0
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l11, !tbaa !29
  br label %bb19
bb18:
  br label %bb22
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  store ptr %l4, ptr %l57, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l11, !tbaa !29
  %t95 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t91, ptr %t92)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t95, ptr %l60
  br label %bb20
bb20:
  %t96 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  %t97 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %t97
  %t98 = load ptr, ptr %l57, !tbaa !29
  %t100 = call i1 @compiler_2ffree_2eaddAllTo(ptr %s0, ptr %s5, ptr %t98, ptr %t97)
  store i1 %t100, ptr %l62
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_2985f8fc2e318fe2_ff9fdbe5a7c1e586)
  unreachable
bb27:
  br label %bb35
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb34
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l4, ptr %l63, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t105 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s7, ptr %t101, ptr %t102)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l66
  br label %bb32
bb32:
  %t106 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  %t107 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %t107
  %t108 = load ptr, ptr %l63, !tbaa !29
  %t110 = call i1 @compiler_2ffree_2eaddAllTo(ptr %s0, ptr %s7, ptr %t108, ptr %t107)
  store i1 %t110, ptr %l68
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_c5aa1cd767c26de3_b3f529891401f067)
  unreachable
bb35:
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l69, !tbaa !29
  %t112 = load ptr, ptr %l69, !tbaa !29
  %t113 = getelementptr %"compiler/free:walker", ptr %t112, i32 0, i32 29
  %t114 = load i64, ptr %t113, !tbaa !24
  %t116 = sub i64 %t114, 1
  %t118 = load ptr, ptr %l69, !tbaa !29
  %t119 = getelementptr %"compiler/free:walker", ptr %t118, i32 0, i32 29
  store i64 %t116, ptr %t119, !tbaa !24
  store ptr %l4, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s9
  %t121 = load ptr, ptr %l12, !tbaa !29
  %t122 = load i64, ptr %l13, !tbaa !24
  %t125 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t121, i64 %t122)
  %t126 = extractvalue { i32, { i64, ptr } } %t125, 1
  %t127 = extractvalue { i32, { i64, ptr } } %t125, 0
  store i32 %t127, ptr %l77
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb38, label %ok.129
ok.129:
  store { i64, ptr } %t126, ptr %l76
  br label %bb37
bb37:
  %t130 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t130, ptr %l73, !tbaa !27
  br label %bb42
bb38:
  %t131 = load i32, ptr %l77, !tbaa !23
  %t132 = ashr i32 %t131, 16
  %t134 = icmp eq i32 %t132, 1
  br i1 %t134, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_f742f29424112a08_e1bb9df773dbe5ec)
  unreachable
bb41:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb62
bb42:
  %t136 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t136, ptr %l14, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s10
  %t141 = load i64, ptr %l16, !tbaa !24
  %t142 = load i64, ptr %l15, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb45:
  br label %bb46
bb46:
  %t149 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t149, ptr %l86, !tbaa !27
  %t150 = load i64, ptr %l16, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i64, ptr %t153, i64 %t150
  %t155 = load i64, ptr %t154, !tbaa !34
  store i64 %t155, ptr %l17, !tbaa !24
  %t157 = load i64, ptr %l17, !tbaa !24
  %t159 = call i64 @compiler_2ffree_2eokind(i64 %t157)
  store i64 %t159, ptr %l90
  br label %bb47
bb47:
  %t160 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t161 = load i64, ptr %l90, !tbaa !24
  %t163 = icmp eq i64 %t161, %t160
  br i1 %t163, label %bb48, label %bb49
bb48:
  %t165 = load ptr, ptr %l3, !tbaa !29
  store ptr %t165, ptr %l94, !tbaa !29
  %t166 = load i64, ptr %l17, !tbaa !24
  %t168 = call i64 @compiler_2ffree_2eoval(i64 %t166)
  store i64 %t168, ptr %l96
  br label %bb50
bb49:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb52
bb50:
  %t169 = load ptr, ptr %l94, !tbaa !29
  %t170 = load i64, ptr %l96, !tbaa !24
  %t171 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t169, i64 %t170)
  store i1 %t171, ptr %l97
  br label %bb51
bb51:
  %t172 = load i1, ptr %l97, !tbaa !21
  store i1 %t172, ptr %l93, !tbaa !21
  br label %bb52
bb52:
  %t173 = load i1, ptr %l93, !tbaa !21
  br i1 %t173, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s11
  %t174 = load ptr, ptr %l3, !tbaa !29
  store ptr %t174, ptr %l98, !tbaa !29
  %t175 = load i64, ptr %l17, !tbaa !24
  %t177 = call i64 @compiler_2ffree_2eoval(i64 %t175)
  store i64 %t177, ptr %l100
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t178 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t178, ptr %l101, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t179)
  store ptr %t181, ptr %l103
  br label %bb56
bb56:
  %t182 = load ptr, ptr %l103, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Body", ptr %t182, i32 0, i32 3
  %t185 = load i64, ptr %t184, !tbaa !24
  %t187 = load ptr, ptr %l98, !tbaa !29
  %t188 = load i64, ptr %l100, !tbaa !24
  %t189 = load i64, ptr %l101, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s11, ptr %t187, i64 %t188, i64 %t189, i64 %t185, %"compiler/source:Span" %a1, { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb59:
  %t192 = load i64, ptr %l16, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l16, !tbaa !24
  br label %bb43
bb60:
  %t196 = load i64, ptr %l13, !tbaa !24
  %t197 = load i64, ptr %l15, !tbaa !24
  %t200 = add i64 %t196, %t197
  store i64 %t200, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb61
bb61:
  br label %bb36
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einsidePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l10 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ederefRoot(ptr %v1, ptr %a1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %t11)
  store i64 %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load i64, ptr %l10, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeStores(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i64
  %l39 = alloca i1
  %l48 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Make", ptr %t6, i32 0, i32 0
  %t9 = load i32, ptr %t8
  %t11 = trunc i64 2 to i32
  %t12 = icmp eq i32 %t9, %t11
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18
  %t21 = trunc i64 3 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l20, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l4, !tbaa !29
  store ptr %t27, ptr %l25, !tbaa !29
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t32 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t28, i32 %a2)
  store i32 %t32, ptr %l28
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l25, !tbaa !29
  %t34 = load i32, ptr %l28, !tbaa !23
  %t35 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t33, i32 %t34, i64 -1)
  store i64 %t35, ptr %l29
  br label %bb8
bb8:
  %t36 = load i64, ptr %l29, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t37, 0
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Make", ptr %t41, i32 0, i32 0
  %t44 = load i32, ptr %t43
  %t46 = trunc i64 3 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 19
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  %t58 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t51, i64 %t55)
  store i1 %t58, ptr %l39
  br label %bb14
bb13:
  br label %bb25
bb14:
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Make", ptr %t60, i32 0, i32 2
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s6)
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t77 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t77, ptr %l48, !tbaa !27
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 %t78
  %t83 = load ptr, ptr %t82, !tbaa !39
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %t85, i64 %t86, ptr %t83, %"compiler/source:Span" %t88, i1 true)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb23
bb23:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb18
bb24:
  br label %ret
bb25:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Make", ptr %t97, i32 0, i32 2
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  store { i64, ptr } %t100, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  store i64 %t104, ptr %l12, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s9
  %t106 = load i64, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t114 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t114, ptr %l65, !tbaa !27
  %t115 = load i64, ptr %l11, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr ptr, ptr %t118, i64 %t115
  %t120 = load ptr, ptr %t119, !tbaa !39
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l5, !tbaa !24
  %t125 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %t122, i64 %t123, ptr %t120, %"compiler/source:Span" %t125, i1 false)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s9)
  br label %bb31
bb31:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l11, !tbaa !24
  br label %bb26
bb32:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:walker", ptr %t31, i32 0, i32 6
  %t34 = load i32, ptr %l3, !tbaa !23
  %t36 = sext i32 %t34 to i64
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t33, i64 %t36)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l25
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb12, label %ok.43
ok.43:
  store i64 %t40, ptr %l24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l24, !tbaa !24
  store i64 %t44, ptr %l19, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l19, !tbaa !24
  br label %bb14
bb14:
  %t45 = load i64, ptr %l19, !tbaa !24
  store i64 %t45, ptr %l12, !tbaa !24
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f81460935a0747e6_f4792861f5ca2502)
  unreachable
bb20:
  %t46 = load i64, ptr %l12, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  br label %bb33
bb21:
  %t47 = load ptr, ptr %l1, !tbaa !29
  store ptr %t47, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t48 = load ptr, ptr %l26, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb22, label %bb23
bb22:
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 17
  store i1 %t54, ptr %l27, !tbaa !21
  br label %bb23
bb23:
  %t55 = load i1, ptr %l27, !tbaa !21
  br i1 %t55, label %bb24, label %bb25
bb24:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t66 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store i64 %t66, ptr %l34
  br label %bb27
bb27:
  %t67 = load i64, ptr %l34, !tbaa !24
  store i64 %t67, ptr %l5, !tbaa !24
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e3a1bae50be73c47_b8cb15515377d683)
  unreachable
bb33:
  %t68 = load i64, ptr %l5, !tbaa !24
  store i64 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/free:leaf"
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca i64
  %l22 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i1
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l44 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca i1
  %l59 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t6, ptr %t7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t11, ptr %lp4
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t13 = load ptr, ptr %lp4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %t13
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  store i64 %t18, ptr %l19
  br label %bb2
bb2:
  %t19 = load i64, ptr %l19, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load ptr, ptr %lp4
  store ptr %t24, ptr %l22, !tbaa !29
  %t25 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = call i64 @compiler_2ffree_2eorig(i64 %t25, i64 %t26)
  store i64 %t29, ptr %l25
  br label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t31 = load i32, ptr %l2, !tbaa !23
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t30, i32 %t31)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l29
  br label %bb7
bb5:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %l25, !tbaa !24
  %t37 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t35, i64 %t36)
  store i1 %t37, ptr %l26
  br label %bb6
bb6:
  br label %bb25
bb7:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  %t39 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %t39
  store ptr %t39, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eRunFrom_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %t41, i64 %t42)
  %t46 = extractvalue { i32, { i64, ptr } } %t45, 1
  %t47 = extractvalue { i32, { i64, ptr } } %t45, 0
  store i32 %t47, ptr %l35
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb10, label %ok.49
ok.49:
  store { i64, ptr } %t46, ptr %l34
  br label %bb9
bb9:
  %t50 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t50, ptr %l31, !tbaa !27
  br label %bb14
bb10:
  %t51 = load i32, ptr %l35, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  br i1 %t54, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_378e310462eb235_e1d32e68ec76ebf1)
  unreachable
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb14:
  %t56 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t56, ptr %l8, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb17:
  br label %bb18
bb18:
  %t69 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t69, ptr %l44, !tbaa !27
  %t70 = load i64, ptr %l10, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr %"compiler/free:leaf", ptr %t73, i64 %t70
  %t75 = load %"compiler/free:leaf", ptr %t74
  store %"compiler/free:leaf" %t75, ptr %l11
  %t77 = load ptr, ptr %lp4
  store ptr %t77, ptr %l47, !tbaa !29
  %t78 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t79 = getelementptr %"compiler/free:leaf", ptr %l11, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t83 = call i64 @compiler_2ffree_2eorig(i64 %t78, i64 %t80)
  store i64 %t83, ptr %l50
  br label %bb19
bb19:
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t85 = load i64, ptr %l50, !tbaa !24
  %t86 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t84, i64 %t85)
  store i1 %t86, ptr %l51
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb21:
  %t87 = load i64, ptr %l10, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l10, !tbaa !24
  br label %bb15
bb22:
  %t91 = load i64, ptr %l7, !tbaa !24
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = add i64 %t91, %t92
  store i64 %t95, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  br label %bb8
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l2, !tbaa !23
  %t101 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l59
  br label %bb26
bb26:
  %t102 = load i1, ptr %l59, !tbaa !21
  br i1 %t102, label %bb27, label %bb28
bb27:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %lp4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v2, ptr %t103, ptr %t104)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t107 = load ptr, ptr %lp4
  %t108 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t107
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2eremoves(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l48 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i1
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l64 = alloca %"compiler/source:Span"
  %l67 = alloca i1
  %l70 = alloca i1
  %l75 = alloca i1
  %l77 = alloca ptr
  %l79 = alloca ptr
  %l81 = alloca i64
  %l85 = alloca %"compiler/source:Span"
  %l86 = alloca { i64, ptr }
  %l92 = alloca i1
  %l95 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i1
  %l108 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t5, ptr %l15, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l16, !tbaa !24
  %t8 = load i64, ptr %l16, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l17, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l16, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:walker", ptr %t21, i32 0, i32 36
  %t25 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l20
  br label %bb4
bb4:
  %t26 = load i64, ptr %l20, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb10
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l27, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l27, !tbaa !24
  store i64 %t53, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l24, !tbaa !24
  store i64 %t54, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load i64, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb62
bb13:
  br label %bb14
bb14:
  %t63 = load i64, ptr %l2, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l4, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l7, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 41
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  store i64 %t79, ptr %l48
  br label %bb15
bb15:
  %t80 = load i64, ptr %l48, !tbaa !24
  store i64 %t80, ptr %l8, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:walker", ptr %t81, i32 0, i32 36
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l52
  br label %bb16
bb16:
  %t88 = load i64, ptr %l1, !tbaa !24
  %t89 = load i64, ptr %l52, !tbaa !24
  %t91 = icmp ne i64 %t89, %t88
  br i1 %t91, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb21
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/free:walker", ptr %t93, i32 0, i32 40
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t95, i64 %t96)
  store %"compiler/source:Span" %t99, ptr %l59
  br label %bb19
bb19:
  %t100 = getelementptr %"compiler/source:Span", ptr %l59, i32 0, i32 0
  %t101 = load i32, ptr %t100, !tbaa !23
  store i32 %t101, ptr %l60, !tbaa !23
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/free:walker", ptr %t102, i32 0, i32 40
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t104, i64 %t105)
  store %"compiler/source:Span" %t108, ptr %l64
  br label %bb20
bb20:
  %t109 = getelementptr %"compiler/source:Span", ptr %l64, i32 0, i32 1
  %t110 = load i32, ptr %t109, !tbaa !23
  %t111 = load i32, ptr %l60, !tbaa !23
  %t113 = icmp sge i32 %t111, %t110
  store i1 %t113, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t115 = load i1, ptr %l55, !tbaa !21
  br i1 %t115, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb24
bb23:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  store i1 %t118, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t120 = load i1, ptr %l67, !tbaa !21
  br i1 %t120, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb28
bb26:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/free:walker", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/free:Free", ptr %t124, i32 0, i32 18
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t126, i64 %t127)
  store i1 %t130, ptr %l75
  br label %bb27
bb27:
  %t131 = load i1, ptr %l75, !tbaa !21
  store i1 %t131, ptr %l70, !tbaa !21
  br label %bb28
bb28:
  %t132 = load i1, ptr %l70, !tbaa !21
  br i1 %t132, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb30:
  br label %bb31
bb31:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/free:walker", ptr %t133, i32 0, i32 0
  %t136 = load ptr, ptr %t135, !tbaa !29
  store ptr %t136, ptr %l77, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t137)
  store ptr %t139, ptr %l79
  br label %bb32
bb32:
  %t140 = load ptr, ptr %l79, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Body", ptr %t140, i32 0, i32 3
  %t143 = load i64, ptr %t142, !tbaa !24
  store i64 %t143, ptr %l81, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/free:walker", ptr %t144, i32 0, i32 40
  %t147 = load i64, ptr %l7, !tbaa !24
  %t150 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t146, i64 %t147)
  store %"compiler/source:Span" %t150, ptr %l85
  br label %bb33
bb33:
  %t151 = load ptr, ptr %l77, !tbaa !29
  %t152 = load i64, ptr %l81, !tbaa !24
  %t153 = load %"compiler/source:Span", ptr %l85
  %t154 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s3, ptr %t151, i64 %t152, %"compiler/source:Span" %t153)
  store { i64, ptr } %t154, ptr %l86
  br label %bb34
bb34:
  %t155 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t155, ptr %l9, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t160 = sub i64 %t158, 1
  store i64 %t160, ptr %l10, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t162 = load i64, ptr %l10, !tbaa !24
  %t164 = icmp sge i64 %t162, 0
  br i1 %t164, label %bb36, label %bb37
bb36:
  %t166 = load i64, ptr %l10, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i8, ptr %t169, i64 %t166
  %t171 = load i8, ptr %t170, !tbaa !32
  %t173 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t171)
  store i1 %t173, ptr %l95
  br label %bb38
bb37:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb46
bb38:
  %t174 = load i1, ptr %l95, !tbaa !21
  br i1 %t174, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb42
bb40:
  %t175 = load i64, ptr %l10, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i8, ptr %t178, i64 %t175
  %t180 = load i8, ptr %t179, !tbaa !32
  %t182 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t180)
  store i1 %t182, ptr %l99
  br label %bb41
bb41:
  %t183 = load i1, ptr %l99, !tbaa !21
  store i1 %t183, ptr %l96, !tbaa !21
  br label %bb42
bb42:
  %t184 = load i1, ptr %l96, !tbaa !21
  br i1 %t184, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb45
bb44:
  %t185 = load i64, ptr %l10, !tbaa !24
  %t187 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i8, ptr %t188, i64 %t185
  %t190 = load i8, ptr %t189, !tbaa !32
  %t192 = icmp eq i8 %t190, 95
  store i1 %t192, ptr %l100, !tbaa !21
  br label %bb45
bb45:
  %t194 = load i1, ptr %l100, !tbaa !21
  store i1 %t194, ptr %l92, !tbaa !21
  br label %bb46
bb46:
  %t195 = load i1, ptr %l92, !tbaa !21
  %t196 = xor i1 %t195, true
  br i1 %t196, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb48:
  br label %bb49
bb49:
  %t198 = load i64, ptr %l10, !tbaa !24
  %t200 = sub i64 %t198, 1
  store i64 %t200, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb50
bb50:
  br label %bb35
bb51:
  %t202 = load i64, ptr %l10, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l108, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  store i64 %t207, ptr %l110, !tbaa !24
  %t208 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  store i64 %t209, ptr %l111, !tbaa !24
  %t210 = load i64, ptr %l108, !tbaa !24
  %t211 = icmp sge i64 %t210, 0
  br i1 %t211, label %bb52, label %bb53
bb52:
  %t213 = load i64, ptr %l108, !tbaa !24
  %t214 = load i64, ptr %l110, !tbaa !24
  %t215 = icmp sle i64 %t213, %t214
  br i1 %t215, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_3f338d8afa9da51a_e8058e9e002c9166)
  unreachable
bb54:
  %t217 = load i64, ptr %l110, !tbaa !24
  %t218 = load i64, ptr %l111, !tbaa !24
  %t219 = icmp sle i64 %t217, %t218
  br i1 %t219, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_3f338d8afa9da51a_e8058e9e002c9166)
  unreachable
bb56:
  %t221 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = load i64, ptr %l108, !tbaa !24
  %t224 = load i64, ptr %l110, !tbaa !24
  %t225 = getelementptr i8, ptr %t222, i64 %t223
  %t226 = sub i64 %t224, %t223
  %t227 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t225, 1
  store { i64, ptr } %t228, ptr %l11, !tbaa !27
  %t230 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t234 = icmp sgt i64 %t232, 0
  br i1 %t234, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_3f338d8afa9da51a_e8058e9e002c9166)
  unreachable
bb58:
  %t236 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t237 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t240 = extractvalue { i64, ptr } %t236, 1
  %t241 = extractvalue { i64, ptr } %t236, 0
  %t242 = add i64 %t238, %t241
  %t243 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t242)
  call void @olang_textcopy(ptr %t243, ptr %t237, i64 %t238)
  %t244 = getelementptr i8, ptr %t243, i64 %t238
  call void @olang_textcopy(ptr %t244, ptr %t240, i64 %t241)
  %t245 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t243, 1
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t246, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb61:
  %t248 = load i64, ptr %l6, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l6, !tbaa !24
  br label %bb11
bb62:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l123, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t252, ptr %l124, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  store i64 %t254, ptr %l125, !tbaa !24
  %t255 = load i64, ptr %l125, !tbaa !24
  %t256 = mul i64 %t255, 1
  %t257 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t256)
  %t258 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  store { i64, ptr } %t259, ptr %l126, !tbaa !27
  %t260 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = load i64, ptr %l125, !tbaa !24
  %t265 = mul i64 %t264, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t261, ptr %t263, i64 %t265, i1 false)
  %t266 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t266, ptr %l124, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t267, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t5)
  store ptr %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t16 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %t13, i64 %t11, %"compiler/source:Span" %a1)
  store { i64, ptr } %t16, ptr %l9
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i1
  %l70 = alloca ptr
  %l73 = alloca ptr
  %l76 = alloca ptr
  %l80 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l99 = alloca ptr
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca i1
  %l120 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l21
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l21, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  br label %bb81
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t23 = load ptr, ptr %l22, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l22, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l23, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [3 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb19
bb12:
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t44 = load i64, ptr %l1, !tbaa !24
  %t47 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t43, i64 %t44)
  store ptr %t47, ptr %l32
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l32, !tbaa !29
  %t49 = icmp eq ptr %t48, null
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t54 = load i64, ptr %l1, !tbaa !24
  %t57 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t53, i64 %t54)
  store ptr %t57, ptr %l38
  br label %bb16
bb15:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t62 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %t58, i64 %t59)
  store ptr %t62, ptr %l41
  br label %bb17
bb16:
  %t63 = load ptr, ptr %l38, !tbaa !29
  store ptr %t63, ptr %l35, !tbaa !29
  br label %bb18
bb17:
  %t64 = load ptr, ptr %l41, !tbaa !29
  store ptr %t64, ptr %l35, !tbaa !29
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l35, !tbaa !29
  store ptr %t65, ptr %l12, !tbaa !29
  br label %bb81
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t67 = load ptr, ptr %l42, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = load ptr, ptr %l42, !tbaa !29
  %t71 = load i64, ptr %t70
  %t73 = icmp eq i64 %t71, 2
  store i1 %t73, ptr %l43, !tbaa !21
  br label %bb21
bb21:
  %t74 = load i1, ptr %l43, !tbaa !21
  br i1 %t74, label %bb22, label %bb23
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr { i64, [3 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", ptr }, ptr %t77, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l5, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  %t85 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t81, i64 %t82)
  store ptr %t85, ptr %l50
  br label %bb25
bb25:
  %t86 = load ptr, ptr %l50, !tbaa !29
  store ptr %t86, ptr %l12, !tbaa !29
  br label %bb81
bb26:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t88 = load ptr, ptr %l51, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb27, label %bb28
bb27:
  %t91 = load ptr, ptr %l51, !tbaa !29
  %t92 = load i64, ptr %t91
  %t94 = icmp eq i64 %t92, 3
  store i1 %t94, ptr %l52, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l52, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr { i64, [3 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l6, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t103 = load i64, ptr %l1, !tbaa !24
  %t106 = call ptr @compiler_2ffree_2efindIf(ptr %v0, ptr %t102, i64 %t103)
  store ptr %t106, ptr %l59
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l59, !tbaa !29
  store ptr %t107, ptr %l12, !tbaa !29
  br label %bb81
bb33:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t109 = load ptr, ptr %l60, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t112 = load ptr, ptr %l60, !tbaa !29
  %t113 = load i64, ptr %t112
  %t115 = icmp eq i64 %t113, 4
  store i1 %t115, ptr %l61, !tbaa !21
  br label %bb35
bb35:
  %t116 = load i1, ptr %l61, !tbaa !21
  br i1 %t116, label %bb36, label %bb37
bb36:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l7, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr { i64, [3 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t125, i32 0, i32 2
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l8, !tbaa !29
  br label %bb38
bb37:
  br label %bb48
bb38:
  %t129 = load ptr, ptr %l7, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  %t133 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %t129, i64 %t130)
  store ptr %t133, ptr %l70
  br label %bb39
bb39:
  %t134 = load ptr, ptr %l70, !tbaa !29
  %t135 = icmp eq ptr %t134, null
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb40, label %bb41
bb40:
  %t139 = load ptr, ptr %l7, !tbaa !29
  %t140 = load i64, ptr %l1, !tbaa !24
  %t143 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %t139, i64 %t140)
  store ptr %t143, ptr %l76
  br label %bb42
bb41:
  %t144 = load ptr, ptr %l8, !tbaa !29
  %t146 = icmp eq ptr %t144, null
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb43, label %bb44
bb42:
  %t150 = load ptr, ptr %l76, !tbaa !29
  store ptr %t150, ptr %l73, !tbaa !29
  br label %bb47
bb43:
  %t151 = load ptr, ptr %l8, !tbaa !29
  %t152 = load i64, ptr %l1, !tbaa !24
  %t155 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %t151, i64 %t152)
  store ptr %t155, ptr %l83
  br label %bb45
bb44:
  store ptr null, ptr %l80, !tbaa !29
  br label %bb46
bb45:
  %t156 = load ptr, ptr %l83, !tbaa !29
  store ptr %t156, ptr %l80, !tbaa !29
  br label %bb46
bb46:
  %t157 = load ptr, ptr %l80, !tbaa !29
  store ptr %t157, ptr %l73, !tbaa !29
  br label %bb47
bb47:
  %t158 = load ptr, ptr %l73, !tbaa !29
  store ptr %t158, ptr %l12, !tbaa !29
  br label %bb81
bb48:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t160 = load ptr, ptr %l84, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb49, label %bb50
bb49:
  %t163 = load ptr, ptr %l84, !tbaa !29
  %t164 = load i64, ptr %t163
  %t166 = icmp eq i64 %t164, 6
  store i1 %t166, ptr %l85, !tbaa !21
  br label %bb50
bb50:
  %t167 = load i1, ptr %l85, !tbaa !21
  br i1 %t167, label %bb51, label %bb52
bb51:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr }, ptr %t170, i32 0, i32 1
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l9, !tbaa !29
  br label %bb57
bb52:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t175 = load ptr, ptr %l90, !tbaa !29
  %t176 = icmp ne ptr %t175, null
  br i1 %t176, label %bb53, label %bb54
bb53:
  %t178 = load ptr, ptr %l90, !tbaa !29
  %t179 = load i64, ptr %t178
  %t181 = icmp eq i64 %t179, 16
  store i1 %t181, ptr %l91, !tbaa !21
  br label %bb54
bb54:
  %t182 = load i1, ptr %l91, !tbaa !21
  br i1 %t182, label %bb55, label %bb56
bb55:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr { i64, [3 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", ptr }, ptr %t185, i32 0, i32 1
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l9, !tbaa !29
  br label %bb57
bb56:
  br label %bb62
bb57:
  %t189 = load ptr, ptr %l9, !tbaa !29
  %t191 = icmp eq ptr %t189, null
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb58, label %bb59
bb58:
  %t195 = load ptr, ptr %l9, !tbaa !29
  %t196 = load i64, ptr %l1, !tbaa !24
  %t199 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t195, i64 %t196)
  store ptr %t199, ptr %l102
  br label %bb60
bb59:
  store ptr null, ptr %l99, !tbaa !29
  br label %bb61
bb60:
  %t200 = load ptr, ptr %l102, !tbaa !29
  store ptr %t200, ptr %l99, !tbaa !29
  br label %bb61
bb61:
  %t201 = load ptr, ptr %l99, !tbaa !29
  store ptr %t201, ptr %l12, !tbaa !29
  br label %bb81
bb62:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t203 = load ptr, ptr %l103, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb63, label %bb64
bb63:
  %t206 = load ptr, ptr %l103, !tbaa !29
  %t207 = load i64, ptr %t206
  %t209 = icmp eq i64 %t207, 11
  store i1 %t209, ptr %l104, !tbaa !21
  br label %bb64
bb64:
  %t210 = load i1, ptr %l104, !tbaa !21
  br i1 %t210, label %bb65, label %bb66
bb65:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l10, !tbaa !29
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t217 = load ptr, ptr %l10, !tbaa !29
  %t218 = load i64, ptr %l1, !tbaa !24
  %t221 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %t217, i64 %t218)
  store ptr %t221, ptr %l111
  br label %bb68
bb68:
  %t222 = load ptr, ptr %l111, !tbaa !29
  store ptr %t222, ptr %l12, !tbaa !29
  br label %bb81
bb69:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t224 = load ptr, ptr %l112, !tbaa !29
  %t225 = icmp ne ptr %t224, null
  br i1 %t225, label %bb70, label %bb71
bb70:
  %t227 = load ptr, ptr %l112, !tbaa !29
  %t228 = load i64, ptr %t227
  %t230 = icmp eq i64 %t228, 12
  store i1 %t230, ptr %l113, !tbaa !21
  br label %bb71
bb71:
  %t231 = load i1, ptr %l113, !tbaa !21
  br i1 %t231, label %bb72, label %bb73
bb72:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr { i64, [3 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", ptr }, ptr %t234, i32 0, i32 1
  %t236 = load ptr, ptr %t235
  store ptr %t236, ptr %l11, !tbaa !29
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t238 = load ptr, ptr %l11, !tbaa !29
  %t239 = load i64, ptr %l1, !tbaa !24
  %t242 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %t238, i64 %t239)
  store ptr %t242, ptr %l120
  br label %bb75
bb75:
  %t243 = load ptr, ptr %l120, !tbaa !29
  store ptr %t243, ptr %l12, !tbaa !29
  br label %bb81
bb76:
  br i1 true, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  store ptr null, ptr %l12, !tbaa !29
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_649fc3f56aacc7bc_4edb8d32620c5088)
  unreachable
bb81:
  %t244 = load ptr, ptr %l12, !tbaa !29
  store ptr %t244, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2efindIf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l15 = alloca ptr
  %l31 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:If", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %t22, i64 %t23)
  store ptr %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l15, !tbaa !29
  store ptr %t27, ptr %l2, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/typed:If", ptr %t37, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/typed:If", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb11, label %bb12
bb10:
  br label %bb15
bb11:
  call void @__olang_check_failed(ptr @olang_loc_2779327e577b2afc_81ce12c77e8d0b58)
  unreachable
bb12:
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:If", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i64, ptr %l1, !tbaa !24
  %t60 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %t56, i64 %t57)
  store ptr %t60, ptr %l31
  br label %bb14
bb14:
  %t61 = load ptr, ptr %l31, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
bb15:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ffree_2eisConversion(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 20 to i32
  %t4 = icmp eq i32 %a0, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t8 = extractvalue { i64, ptr } %a1, 0
  %t10 = icmp eq i64 %t8, 1
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l4, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2eisVar({ i64, [1 x i64] } %a0) #0 {
entry:
  %l1 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [1 x i64] } %a0, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3f15d8a4ec391f6e_384039254c446aaa)
  unreachable
bb9:
  %t6 = load i1, ptr %l1, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2eleaves(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_6ad9637bd46aa97_a10a430e5eff5d73)
  unreachable
bb15:
  %t19 = load i1, ptr %l1, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ereadLocalOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %l10, !tbaa !24
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d0a35c72e1689727_18f1e8c23ad8e373)
  unreachable
bb16:
  %t35 = load i64, ptr %l10, !tbaa !24
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9d733ba55f12146_b889888c2106eef2)
  unreachable
bb22:
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2esamePure(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l3, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t35 = call i1 @compiler_2ffree_2esamePurePlace(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t35, ptr %l20
  br label %bb11
bb11:
  %t36 = load i1, ptr %l20, !tbaa !21
  store i1 %t36, ptr %l11, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a76c2f62bbf8a003_89a44c6922f8d22f)
  unreachable
bb17:
  %t37 = load i1, ptr %l11, !tbaa !21
  store i1 %t37, ptr %l4, !tbaa !21
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_e31a42735e4aee82_13f2226a4db7316e)
  unreachable
bb23:
  %t38 = load i1, ptr %l4, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/free:letGo" @compiler_2ffree_3aletGo_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5, %"compiler/source:Span" %a6, i64 %a7, i1 %a8) #0 {
entry:
  %rv = alloca %"compiler/free:letGo"
  br label %start
start:
  br label %bb0
bb0:
  %t20 = insertvalue %"compiler/free:letGo" undef, i64 %a0, 0
  %t22 = insertvalue %"compiler/free:letGo" %t20, i64 %a1, 1
  %t24 = insertvalue %"compiler/free:letGo" %t22, i64 %a2, 2
  %t26 = insertvalue %"compiler/free:letGo" %t24, %"compiler/source:Span" %a3, 3
  %t28 = insertvalue %"compiler/free:letGo" %t26, %"compiler/source:Span" %a4, 4
  %t30 = insertvalue %"compiler/free:letGo" %t28, i64 %a5, 5
  %t32 = insertvalue %"compiler/free:letGo" %t30, %"compiler/source:Span" %a6, 6
  %t34 = insertvalue %"compiler/free:letGo" %t32, i64 %a7, 7
  %t36 = insertvalue %"compiler/free:letGo" %t34, i1 %a8, 8
  store %"compiler/free:letGo" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:letGo", ptr %rv
  ret %"compiler/free:letGo" %rr
}

define dso_local %"compiler/free:mustW" @compiler_2ffree_3amustW_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/free:mustW"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 %a1, ptr %l3, !tbaa !24
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l4
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l5
  %t9 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l13
  br label %bb3
bb3:
  %t10 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l6
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l14
  br label %bb4
bb4:
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l7
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l15
  br label %bb5
bb5:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = insertvalue %"compiler/free:mustW" undef, ptr %t15, 0
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = insertvalue %"compiler/free:mustW" %t16, i64 %t17, 1
  %t19 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t20 = insertvalue %"compiler/free:mustW" %t18, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, 2
  %t21 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t22 = insertvalue %"compiler/free:mustW" %t20, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, 3
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t24 = insertvalue %"compiler/free:mustW" %t22, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, 4
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t26 = insertvalue %"compiler/free:mustW" %t24, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, 5
  %t28 = insertvalue %"compiler/free:mustW" %t26, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, 6
  store %"compiler/free:mustW" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:mustW", ptr %rv
  ret %"compiler/free:mustW" %rr
}

define dso_local %"compiler/free:orCall" @compiler_2ffree_3aorCall_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, ptr %a5, ptr %a6) #0 {
entry:
  %rv = alloca %"compiler/free:orCall"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/free:orCall" undef, i64 %a0, 0
  %t18 = insertvalue %"compiler/free:orCall" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/free:orCall" %t18, i64 %a2, 2
  %t22 = insertvalue %"compiler/free:orCall" %t20, i64 %a3, 3
  %t24 = insertvalue %"compiler/free:orCall" %t22, i64 %a4, 4
  %t26 = insertvalue %"compiler/free:orCall" %t24, ptr %a5, 5
  %t28 = insertvalue %"compiler/free:orCall" %t26, ptr %a6, 6
  store %"compiler/free:orCall" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:orCall", ptr %rv
  ret %"compiler/free:orCall" %rr
}

declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d0 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"free: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d1 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" bodies, " }>, align 8
@.d2 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" places; must " }>, align 8
@.d3 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" bodies " }>, align 8
@.d4 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" ms; may " }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" walks " }>, align 8
@.d6 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" passes " }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d8 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"free: hidden let-go in " }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d11 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"free: final " }>, align 8
@.d12 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" ms, " }>, align 8
@.d13 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" let-goes, " }>, align 8
@.d14 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" stores; decide " }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb9, label %bb1
bb7:
  br label %bb3
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t46 = load i1, ptr %l2, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d19 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"' is a parameter: its caller holds the instance too" }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d21 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"' is a field of the instance being built, which holds it too" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d23 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"' (line " }>, align 8
@.d24 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c") reaches it too, and is used here, after '" }>, align 8
@.d25 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c".Destroy()'" }>, align 8
@.d26 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"it is returned (line " }>, align 8
@.d27 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"), and its Destroy() is deferred: it runs as the function leaves" }>, align 8
@.d28 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"it is handed to a task here, which may use it after the Destroy()" }>, align 8
@.d29 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"may let go of anything" }>, align 8
@.d30 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"removes " }>, align 8
@.d31 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"lets go of it" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2ffree_2eAnyPlace = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eLAssign = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eMustNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eMustTop = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eOMov = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOPl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOUnk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRStore = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRTask = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_73a600468f127602_bc0c68a189771b8e = external constant [0 x i8]
declare i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_aa0994ef0ced0737_f892d7c71adaceeb = external constant [0 x i8]
@olang_loc_60a6a0a204dd2601_d155668594ed74d = external constant [0 x i8]
@olang_loc_dcc470c1d4c9ec59_c1df879736016c25 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epreludeCode(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_38e68c2f90f7ff92_433845456bb6222e = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H80281abdeb8e6e8df4d34cf6bb2c83d9(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_cfa78d5b759fffbc_7789424fbd23b3b0 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_c07c4c0bbb573d1f_6e3b998739460953 = external constant [0 x i8]
@olang_loc_4a2ee03059613aea_a0006d5774bd9126 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i64 @std_2ftime_2eNow()
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesFirst(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_b4402838d0fec99d_8d63b3fead7ad2c9 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H514c3278d648f49337aafc4c9fcf3b34(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H1bfd72835118c4a69ac66e4bcdbec3db(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7774858aec9876f0_864a54e21bf2c67c = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f82c60b4f3fd4c74_8c152bea1dd531b8 = external constant [0 x i8]
@olang_loc_1d52b8c7af03b45e_7ee7d49b67a560a = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_b00b407721719b6a_38625d6521f1b366 = external constant [0 x i8]
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
@olang_loc_58b1755dfcbf182b_23efb7b6d3d1a7c7 = external constant [0 x i8]
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eimplicit(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_ad17e1d275f06ba1_d55ab4a9088c1b55 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edecide(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewritePlans(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestroyErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0)
@olang_loc_6198ef54548c7110_909a06f0dca20164 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_44f49f80b055cb88_68fe70e2113a02d4 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindDestroy(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_f0ef9f3a8cd9f24a_5f2afb921a19c616 = external constant [0 x i8]
@olang_loc_1befe4f0760966d8_ea99a8b72a88b024 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eRunFrom_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_382d5ddd4082031c_8c872e693a10d18 = external constant [0 x i8]
@G_2ecompiler_2ffree_2eLVacate = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ec4c329f8a2f93df_8cb0fdf9b7b252db = external constant [0 x i8]
@olang_loc_285dc0af82d31c87_50e1bc6ae6554e83 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f9703b3e8b4d3f8c_114f0f1572d2eea8 = external constant [0 x i8]
@olang_loc_c329a7357b4632ae_1972f4ce8b92321a = external constant [0 x i8]
@olang_loc_ce4a56608212b1d3_28564c72fb26107 = external constant [0 x i8]
@olang_loc_8c3ff88e405c7c2b_15d3403d537d031f = external constant [0 x i8]
@olang_loc_2b6adc3dc0c287f0_370d6d4a959e10e4 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_1d9a56a827ed845f_5cc839dbc781b743 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2emeet(i64 %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_b0b9e719fd18da07_d4692a85838c2bdb = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eRun_H53a7d26114b960961c1fb4b8403d34c1(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_81cc61a90592fd0c_27b8446ae48616e0 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_377f9dc3f8b5b43d_2adc919691629af1 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H96e9eb9990b7b2982627078c49255e88(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efreshLocal(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eRNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2ePush_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:reason" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_997f49c366488af5_93d2651ee5683809 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edtorCand(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandleCand(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i64 %a5)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2, { i64, [1 x i64] } %a3)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_40e6d44f68e64eba_dc25501b912aa106 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1, %"compiler/free:letGo" %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_He8628b0a6160e3784b3615fe3f392582(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hd2f0d304a9aa6fbe6d847d83ccff30fa(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a2405124df419505_d09a35ea35067921 = external constant [0 x i8]
@olang_loc_a35b07018a31f4f3_69e61a5b7415d1c7 = external constant [0 x i8]
@olang_loc_f643d9b6ae0bdcd0_4526d46ebc766864 = external constant [0 x i8]
@olang_loc_859ddcc5919b3f4e_ba7432349dfb5d8a = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_a764b585ac706330_d4408aac5d1924a4 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ehas(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eOPar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eorig(i64 %a0, i64 %a1)
@olang_loc_a0b39b8bb083daea_3953b4ce55bab6be = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2enewWalker(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %a0)
@olang_loc_30cfd3b464a887aa_ca3830b5343a05a6 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamPaths(ptr %v0, ptr %a0)
@olang_loc_3a3557a9366273b1_8eafb121351cf8d = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviews(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_4acb4c8921e8c407_808d59af97a4073 = external constant [0 x i8]
@olang_loc_d1dd1febe39b41f_df28cb247c1abe4b = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9f79222042d933c1_46b0afd99b60162d = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_18fbdab9dd354c58_c2b73ff02acf68dc = external constant [0 x i8]
@olang_loc_6e5f625591edaca_eb58e2cd01ac77e = external constant [0 x i8]
@olang_loc_6578a1c50e6256f2_162d732cc51ca876 = external constant [0 x i8]
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePu_H51141c7f79c906b1679ae982392c7956(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ePo_H0db9b8972766e5b481cadc211ca24c07(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyStore(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3)
@olang_loc_620cc86993d1ee05_2ed463b6a2f232e1 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorStoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esameValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eRunFrom_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e251e9e241135754_793c210c71879d50 = external constant [0 x i8]
@G_2ecompiler_2ffree_2eLLeaf = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5)
@olang_loc_7d1db60ec5fa7c8f_44fdf29e388dfc8b = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i1 %a4, i64 %a5, i64 %a6)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRMade = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyAfter(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, ptr %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2ffree_2eRView = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2ffree_2ecompiler_2ffree_3awalker_2euseSpAt(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2985f8fc2e318fe2_ff9fdbe5a7c1e586 = external constant [0 x i8]
@olang_loc_c5aa1cd767c26de3_b3f529891401f067 = external constant [0 x i8]
@olang_loc_f742f29424112a08_e1bb9df773dbe5ec = external constant [0 x i8]
declare i64 @compiler_2ffree_2eokind(i64 %a0)
declare i64 @compiler_2ffree_2eoval(i64 %a0)
declare ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4)
@olang_loc_f81460935a0747e6_f4792861f5ca2502 = external constant [0 x i8]
@olang_loc_e3a1bae50be73c47_b8cb15515377d683 = external constant [0 x i8]
@olang_loc_378e310462eb235_e1d32e68ec76ebf1 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_3f338d8afa9da51a_e8058e9e002c9166 = external constant [0 x i8]
declare ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_649fc3f56aacc7bc_4edb8d32620c5088 = external constant [0 x i8]
@olang_loc_2779327e577b2afc_81ce12c77e8d0b58 = external constant [0 x i8]
@olang_loc_3f15d8a4ec391f6e_384039254c446aaa = external constant [0 x i8]
@olang_loc_6ad9637bd46aa97_a10a430e5eff5d73 = external constant [0 x i8]
@olang_loc_d0a35c72e1689727_18f1e8c23ad8e373 = external constant [0 x i8]
@olang_loc_9d733ba55f12146_b889888c2106eef2 = external constant [0 x i8]
declare i1 @compiler_2ffree_2esamePurePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_a76c2f62bbf8a003_89a44c6922f8d22f = external constant [0 x i8]
@olang_loc_e31a42735e4aee82_13f2226a4db7316e = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
