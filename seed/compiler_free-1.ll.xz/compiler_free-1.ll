; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/free:mustW" = type { ptr, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/free:reason" = type { i64, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/free:walker" = type { ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
define dso_local i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load i64, ptr %l14, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l15, !tbaa !24
  %t24 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %t18)
  store i64 %t24, ptr %l18
  br label %bb7
bb7:
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = add i64 %t25, %t26
  store i64 %t27, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t29, 1
  store i64 %t31, ptr %l4, !tbaa !24
  br label %bb1
bb9:
  %t33 = load i64, ptr %l2, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2ffree_2ebaseOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb23
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 4
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Elem", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l4, !tbaa !29
  br label %bb23
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 8}
  %t47 = icmp eq i64 %t45, 5
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l23, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Payload", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_aa0994ef0ced0737_f892d7c71adaceeb)
  unreachable
bb23:
  %t61 = load ptr, ptr %l4, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDecide(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l94 = alloca i64
  %l99 = alloca i64
  %l102 = alloca i64
  %l122 = alloca i64
  %l127 = alloca ptr
  %l130 = alloca i1
  %l133 = alloca i1
  %l138 = alloca ptr
  %l141 = alloca i1
  %l143 = alloca ptr
  %l146 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l152 = alloca ptr
  %l153 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l156 = alloca ptr
  %l157 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l160 = alloca ptr
  %l161 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l164 = alloca ptr
  %l165 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l168 = alloca ptr
  %l169 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l172 = alloca ptr
  %l173 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l187 = alloca ptr
  %l194 = alloca ptr
  %l198 = alloca i64
  %l199 = alloca ptr
  %l202 = alloca i1
  %l205 = alloca i1
  %l210 = alloca ptr
  %l211 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l214 = alloca ptr
  %l215 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l218 = alloca ptr
  %l219 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l222 = alloca ptr
  %l223 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l230 = alloca ptr
  %l235 = alloca ptr
  %l251 = alloca i64
  %l254 = alloca i64
  %l277 = alloca ptr
  %l282 = alloca ptr
  %l286 = alloca ptr
  %l296 = alloca i64
  %l298 = alloca i64
  %l301 = alloca { i64, ptr }
  %l306 = alloca i64
  %l309 = alloca { i64, ptr }
  %l311 = alloca i64
  %l317 = alloca i64
  %l320 = alloca i64
  %l342 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l347 = alloca i64
  %l350 = alloca i64
  %l368 = alloca ptr
  %l369 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l376 = alloca i64
  %l379 = alloca i64
  %l400 = alloca { i64, ptr }
  %l408 = alloca { i64, ptr }
  %l413 = alloca i1
  %l419 = alloca ptr
  %l425 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l426 = alloca i64
  %l436 = alloca { i64, ptr }
  %l443 = alloca i64
  %l445 = alloca i64
  %l450 = alloca i64
  %l462 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l464 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l466 = alloca i64
  %l468 = alloca i64
  %l473 = alloca i64
  %l484 = alloca i64
  %l485 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l486 = alloca i64
  %l496 = alloca { i64, ptr }
  %l503 = alloca i64
  %l505 = alloca i64
  %l510 = alloca i64
  %l523 = alloca ptr
  %l524 = alloca i64
  %l526 = alloca i64
  %l531 = alloca i64
  %l542 = alloca i64
  %l545 = alloca i64
  %l548 = alloca i64
  %l563 = alloca i32
  %l565 = alloca i1
  %l572 = alloca i64
  %l575 = alloca i64
  %l596 = alloca ptr
  %l597 = alloca i64
  %l599 = alloca i1
  %l603 = alloca i1
  %l606 = alloca i1
  %l607 = alloca i1
  %l610 = alloca i1
  %l615 = alloca i1
  %l618 = alloca ptr
  %l622 = alloca ptr
  %l623 = alloca i64
  %l628 = alloca { i64, ptr }
  %l632 = alloca ptr
  %l636 = alloca ptr
  %l638 = alloca i64
  %l642 = alloca ptr
  %l646 = alloca { i64, ptr }
  %l649 = alloca i32
  %l651 = alloca i1
  %l656 = alloca i64
  %l661 = alloca i64
  %l664 = alloca i64
  %l686 = alloca i64
  %l687 = alloca ptr
  %l689 = alloca i1
  %l693 = alloca i64
  %l699 = alloca i64
  %l702 = alloca i64
  %l705 = alloca i64
  %l712 = alloca i32
  %l714 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s58 = alloca %olang.scope
  %s65 = alloca %olang.scope
  %t707 = alloca i64
  %t845 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l86, !tbaa !29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l87
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %l87)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l89
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89
  %t6 = load ptr, ptr %l86, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t7
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 7
  store i64 %t9, ptr %t12, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 1
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l94
  br label %bb2
bb2:
  %t18 = load i64, ptr %l94, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb8
bb5:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l102, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb7
bb7:
  %t47 = load i64, ptr %l102, !tbaa !24
  store i64 %t47, ptr %l99, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l99, !tbaa !24
  store i64 %t48, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb10, label %bb11
bb10:
  br label %bb87
bb11:
  br label %bb12
bb12:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l9, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t67, i64 %t68)
  store i64 %t71, ptr %l122
  br label %bb13
bb13:
  %t72 = load i64, ptr %l122, !tbaa !24
  store i64 %t72, ptr %l10, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 20
  %t76 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  br label %bb14
bb14:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/free:Free", ptr %t79, i32 0, i32 21
  store ptr %t81, ptr %l127, !tbaa !29
  %t82 = load i64, ptr %l2, !tbaa !24
  %t84 = icmp sge i64 %t82, 0
  br i1 %t84, label %bb15, label %bb16
bb15:
  %t86 = load i64, ptr %l10, !tbaa !24
  %t88 = icmp eq i64 %t86, -3
  br i1 %t88, label %bb17, label %bb18
bb16:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb20
bb17:
  store i1 true, ptr %l133, !tbaa !21
  br label %bb19
bb18:
  %t90 = load i64, ptr %l10, !tbaa !24
  %t91 = load i64, ptr %l2, !tbaa !24
  %t94 = icmp eq i64 %t90, %t91
  store i1 %t94, ptr %l133, !tbaa !21
  br label %bb19
bb19:
  %t96 = load i1, ptr %l133, !tbaa !21
  store i1 %t96, ptr %l130, !tbaa !21
  br label %bb20
bb20:
  %t97 = load ptr, ptr %l127, !tbaa !29
  %t98 = load i1, ptr %l130, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t97, i1 %t98)
  br label %bb21
bb21:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/free:Free", ptr %t99, i32 0, i32 22
  store ptr %t101, ptr %l138, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownCode(ptr %v0, ptr %t102, i64 %t103)
  store i1 %t106, ptr %l141
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l138, !tbaa !29
  %t108 = load i1, ptr %l141, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t107, i1 %t108)
  br label %bb23
bb23:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/free:Free", ptr %t109, i32 0, i32 23
  store ptr %t111, ptr %l143, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l9, !tbaa !24
  %t116 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epreludeCode(ptr %v0, ptr %t112, i64 %t113)
  store i1 %t116, ptr %l146
  br label %bb24
bb24:
  %t117 = load ptr, ptr %l143, !tbaa !29
  %t118 = load i1, ptr %l146, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t117, i1 %t118)
  br label %bb25
bb25:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/free:Free", ptr %t119, i32 0, i32 24
  store ptr %t121, ptr %l148, !tbaa !29
  %t122 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t122, ptr %l149
  br label %bb26
bb26:
  %t123 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149
  %t124 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t123, ptr %t124
  %t125 = load ptr, ptr %l148, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t125, ptr %t124)
  br label %bb27
bb27:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/free:Free", ptr %t127, i32 0, i32 25
  store ptr %t129, ptr %l152, !tbaa !29
  %t130 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l153
  br label %bb28
bb28:
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l153
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %t132
  %t133 = load ptr, ptr %l152, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t133, ptr %t132)
  br label %bb29
bb29:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/free:Free", ptr %t135, i32 0, i32 26
  store ptr %t137, ptr %l156, !tbaa !29
  %t138 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %l157
  br label %bb30
bb30:
  %t139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l157
  %t140 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %t140
  %t141 = load ptr, ptr %l156, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t141, ptr %t140)
  br label %bb31
bb31:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/free:Free", ptr %t143, i32 0, i32 27
  store ptr %t145, ptr %l160, !tbaa !29
  %t146 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t146, ptr %l161
  br label %bb32
bb32:
  %t147 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l161
  %t148 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t147, ptr %t148
  %t149 = load ptr, ptr %l160, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t149, ptr %t148)
  br label %bb33
bb33:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/free:Free", ptr %t151, i32 0, i32 28
  store ptr %t153, ptr %l164, !tbaa !29
  %t154 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %l165
  br label %bb34
bb34:
  %t155 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l165
  %t156 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %t156
  %t157 = load ptr, ptr %l164, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t157, ptr %t156)
  br label %bb35
bb35:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/free:Free", ptr %t159, i32 0, i32 29
  store ptr %t161, ptr %l168, !tbaa !29
  %t162 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %l169
  br label %bb36
bb36:
  %t163 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l169
  %t164 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %t164
  %t165 = load ptr, ptr %l168, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t165, ptr %t164)
  br label %bb37
bb37:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/free:Free", ptr %t167, i32 0, i32 30
  store ptr %t169, ptr %l172, !tbaa !29
  %t170 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %l173
  br label %bb38
bb38:
  %t171 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l173
  %t172 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t171, ptr %t172
  %t173 = load ptr, ptr %l172, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t173, ptr %t172)
  br label %bb39
bb39:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/free:Free", ptr %t175, i32 0, i32 31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t177, i1 false)
  br label %bb40
bb40:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/free:Free", ptr %t179, i32 0, i32 32
  %t182 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t181, i64 %t182)
  br label %bb41
bb41:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/free:Free", ptr %t185, i32 0, i32 33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t187, i1 true)
  br label %bb42
bb42:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/free:Free", ptr %t189, i32 0, i32 34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t191, i1 false)
  br label %bb43
bb43:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/free:Free", ptr %t193, i32 0, i32 1
  %t196 = load i64, ptr %l9, !tbaa !24
  %t199 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t195, i64 %t196)
  store ptr %t199, ptr %l187
  br label %bb44
bb44:
  %t200 = load ptr, ptr %l187, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Body", ptr %t200, i32 0, i32 1
  %t203 = load { i64, [2 x i64] }, ptr %t202
  store { i64, [2 x i64] } %t203, ptr %l11
  %t205 = load { i64, [2 x i64] }, ptr %l11
  %t207 = extractvalue { i64, [2 x i64] } %t205, 0
  %t208 = icmp eq i64 %t207, 0
  br i1 %t208, label %bb45, label %bb46
bb45:
  %t210 = getelementptr { i64, [2 x i64] }, ptr %l11, i32 0, i32 1
  %t211 = getelementptr { i64 }, ptr %t210, i32 0, i32 0
  %t212 = load i64, ptr %t211
  store i64 %t212, ptr %l12, !tbaa !24
  br label %bb47
bb46:
  br label %bb58
bb47:
  store %olang.scope zeroinitializer, ptr %s3
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/free:Free", ptr %t214, i32 0, i32 0
  %t217 = load ptr, ptr %t216, !tbaa !29
  store ptr %t217, ptr %l194, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/free:Free", ptr %t218, i32 0, i32 0
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t222 = load i64, ptr %l12, !tbaa !24
  %t225 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t221, i64 %t222)
  store i64 %t225, ptr %l198
  br label %bb48
bb48:
  %t226 = load ptr, ptr %l194, !tbaa !29
  %t227 = load i64, ptr %l198, !tbaa !24
  %t228 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s3, ptr %t226, i64 %t227)
  store ptr %t228, ptr %l199
  br label %bb49
bb49:
  %t229 = load ptr, ptr %l199, !tbaa !29
  %t231 = getelementptr %"compiler/ast:Func", ptr %t229, i32 0, i32 7
  %t232 = load i1, ptr %t231, !tbaa !21
  br i1 %t232, label %bb50, label %bb51
bb50:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i64, ptr %l12, !tbaa !24
  %t238 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandedToC(ptr %v0, ptr %t234, i64 %t235)
  store i1 %t238, ptr %l205
  br label %bb52
bb51:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb53
bb52:
  %t239 = load i1, ptr %l205, !tbaa !21
  store i1 %t239, ptr %l202, !tbaa !21
  br label %bb53
bb53:
  %t240 = load i1, ptr %l202, !tbaa !21
  br i1 %t240, label %bb54, label %bb55
bb54:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/free:Free", ptr %t241, i32 0, i32 35
  %t244 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t243, i64 %t244)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s3)
  br label %bb63
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_38e68c2f90f7ff92_433845456bb6222e)
  unreachable
bb63:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/free:Free", ptr %t247, i32 0, i32 53
  store ptr %t249, ptr %l210, !tbaa !29
  %t250 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t250, ptr %l211
  br label %bb64
bb64:
  %t251 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l211
  %t252 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t251, ptr %t252
  %t253 = load ptr, ptr %l210, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t253, ptr %t252)
  br label %bb65
bb65:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/free:Free", ptr %t255, i32 0, i32 54
  store ptr %t257, ptr %l214, !tbaa !29
  %t258 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t258, ptr %l215
  br label %bb66
bb66:
  %t259 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l215
  %t260 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t259, ptr %t260
  %t261 = load ptr, ptr %l214, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t261, ptr %t260)
  br label %bb67
bb67:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/free:Free", ptr %t263, i32 0, i32 55
  store ptr %t265, ptr %l218, !tbaa !29
  %t266 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %l219
  br label %bb68
bb68:
  %t267 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l219
  %t268 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t267, ptr %t268
  %t269 = load ptr, ptr %l218, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_H788cd74f9c006611bc4bb459b5b22001(ptr %v0, ptr %v0, ptr %t269, ptr %t268)
  br label %bb69
bb69:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/free:Free", ptr %t271, i32 0, i32 56
  store ptr %t273, ptr %l222, !tbaa !29
  %t274 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t274, ptr %l223
  br label %bb70
bb70:
  %t275 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l223
  %t276 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t275, ptr %t276
  %t277 = load ptr, ptr %l222, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t277, ptr %t276)
  br label %bb71
bb71:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/free:Free", ptr %t279, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t281, i1 false)
  br label %bb72
bb72:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/free:Free", ptr %t283, i32 0, i32 39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t285, i1 false)
  br label %bb73
bb73:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/free:Free", ptr %t287, i32 0, i32 57
  store ptr %t289, ptr %l230, !tbaa !29
  %t290 = icmp sge i64 0, 0
  br i1 %t290, label %bb74, label %bb75
bb74:
  %t292 = icmp sle i64 0, 1152921504606846975
  br i1 %t292, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_cfa78d5b759fffbc_7789424fbd23b3b0)
  unreachable
bb76:
  %t294 = mul i64 0, 8
  %t295 = insertvalue { i64, ptr } undef, i64 0, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t297 = load ptr, ptr %l230, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t297, { i64, ptr } %t296)
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_cfa78d5b759fffbc_7789424fbd23b3b0)
  unreachable
bb78:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/free:Free", ptr %t299, i32 0, i32 58
  store ptr %t301, ptr %l235, !tbaa !29
  %t302 = icmp sge i64 0, 0
  br i1 %t302, label %bb79, label %bb80
bb79:
  %t304 = icmp sle i64 0, 1152921504606846975
  br i1 %t304, label %bb81, label %bb82
bb80:
  call void @__olang_check_failed(ptr @olang_loc_c07c4c0bbb573d1f_6e3b998739460953)
  unreachable
bb81:
  %t306 = mul i64 0, 8
  %t307 = insertvalue { i64, ptr } undef, i64 0, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t309 = load ptr, ptr %l235, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t309, { i64, ptr } %t308)
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_c07c4c0bbb573d1f_6e3b998739460953)
  unreachable
bb83:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/free:Free", ptr %t311, i32 0, i32 61
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t313, i1 false)
  br label %bb84
bb84:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2enoteDtor(ptr %v0, ptr %t315, i64 %t316)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t319 = load i64, ptr %l8, !tbaa !24
  %t321 = add i64 %t319, 1
  store i64 %t321, ptr %l8, !tbaa !24
  br label %bb9
bb87:
  %t323 = load i64, ptr %l2, !tbaa !24
  %t325 = icmp slt i64 %t323, 0
  br i1 %t325, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb89:
  br label %bb90
bb90:
  store i64 0, ptr %l13, !tbaa !24
  %t327 = load i64, ptr %l3, !tbaa !24
  store i64 %t327, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t329 = load i64, ptr %l14, !tbaa !24
  %t330 = load i64, ptr %l13, !tbaa !24
  %t333 = icmp sgt i64 %t329, %t330
  br i1 %t333, label %bb91, label %bb92
bb91:
  %t335 = load i64, ptr %l15, !tbaa !24
  %t337 = icmp sgt i64 %t335, 0
  br i1 %t337, label %bb93, label %bb94
bb92:
  store i64 0, ptr %l251, !tbaa !24
  br label %bb96
bb93:
  %t339 = load i64, ptr %l14, !tbaa !24
  %t340 = load i64, ptr %l13, !tbaa !24
  %t343 = sub i64 %t339, %t340
  %t344 = load i64, ptr %l15, !tbaa !24
  %t347 = add i64 %t343, %t344
  %t349 = sub i64 %t347, 1
  %t350 = load i64, ptr %l15, !tbaa !24
  %t353 = sdiv i64 %t349, %t350
  store i64 %t353, ptr %l254, !tbaa !24
  br label %bb95
bb94:
  store i64 0, ptr %l254, !tbaa !24
  br label %bb95
bb95:
  %t355 = load i64, ptr %l254, !tbaa !24
  store i64 %t355, ptr %l251, !tbaa !24
  br label %bb96
bb96:
  %t356 = load i64, ptr %l251, !tbaa !24
  store i64 %t356, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb97
bb97:
  %t357 = load i64, ptr %l17, !tbaa !24
  %t358 = load i64, ptr %l16, !tbaa !24
  %t361 = icmp slt i64 %t357, %t358
  %t363 = xor i1 %t361, true
  br i1 %t363, label %bb98, label %bb99
bb98:
  br label %bb111
bb99:
  br label %bb100
bb100:
  %t365 = load i64, ptr %l13, !tbaa !24
  %t366 = load i64, ptr %l17, !tbaa !24
  %t367 = load i64, ptr %l15, !tbaa !24
  %t370 = mul i64 %t366, %t367
  %t373 = add i64 %t365, %t370
  store i64 %t373, ptr %l18, !tbaa !24
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load i64, ptr %l18, !tbaa !24
  %t379 = getelementptr %"compiler/free:Free", ptr %t375, i32 0, i32 64
  store i64 %t376, ptr %t379, !tbaa !24
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/free:Free", ptr %t380, i32 0, i32 1
  %t383 = load i64, ptr %l18, !tbaa !24
  %t386 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t382, i64 %t383)
  store ptr %t386, ptr %l277
  br label %bb101
bb101:
  %t387 = load ptr, ptr %l277, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Body", ptr %t387, i32 0, i32 11
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t392 = icmp eq ptr %t390, null
  %t394 = xor i1 %t392, true
  br i1 %t394, label %bb102, label %bb103
bb102:
  %t396 = load ptr, ptr %l0, !tbaa !29
  store ptr %t396, ptr %l282, !tbaa !29
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/free:Free", ptr %t397, i32 0, i32 1
  %t400 = load i64, ptr %l18, !tbaa !24
  %t403 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t399, i64 %t400)
  store ptr %t403, ptr %l286
  br label %bb104
bb103:
  br label %bb109
bb104:
  %t404 = load ptr, ptr %l286, !tbaa !29
  %t406 = getelementptr %"compiler/typed:Body", ptr %t404, i32 0, i32 11
  %t407 = load ptr, ptr %t406, !tbaa !29
  store ptr %t407, ptr %l19, !tbaa !29
  %t409 = load ptr, ptr %l19, !tbaa !29
  %t411 = icmp eq ptr %t409, null
  br i1 %t411, label %bb105, label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_4a2ee03059613aea_a0006d5774bd9126)
  unreachable
bb106:
  br label %bb107
bb107:
  %t413 = load ptr, ptr %l19, !tbaa !29
  %t414 = load ptr, ptr %l282, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v0, ptr %t414, ptr %t413)
  br label %bb108
bb108:
  br label %bb109
bb109:
  br label %bb110
bb110:
  %t416 = load i64, ptr %l17, !tbaa !24
  %t418 = add i64 %t416, 1
  store i64 %t418, ptr %l17, !tbaa !24
  br label %bb97
bb111:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/free:Free", ptr %t420, i32 0, i32 8
  %t424 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t422)
  store i64 %t424, ptr %l296
  br label %bb112
bb112:
  %t425 = load i64, ptr %l296, !tbaa !24
  %t426 = icmp eq i64 %t425, 0
  br i1 %t426, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb114:
  br label %bb115
bb115:
  %t428 = call i64 @std_2ftime_2eNow()
  store i64 %t428, ptr %l298
  br label %bb116
bb116:
  %t429 = load i64, ptr %l298, !tbaa !24
  store i64 %t429, ptr %l20, !tbaa !24
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/free:Free", ptr %t430, i32 0, i32 2
  %t433 = load ptr, ptr %t432, !tbaa !29
  %t435 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesFirst(ptr %v0, ptr %s0, ptr %t433)
  store { i64, ptr } %t435, ptr %l301
  br label %bb117
bb117:
  %t436 = load { i64, ptr }, ptr %l301, !tbaa !27
  store { i64, ptr } %t436, ptr %l21, !tbaa !27
  %t437 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t439 = extractvalue { i64, ptr } %t437, 0
  %t440 = load i64, ptr %l3, !tbaa !24
  %t443 = icmp ne i64 %t439, %t440
  br i1 %t443, label %bb118, label %bb119
bb118:
  %t445 = load i64, ptr %l3, !tbaa !24
  store i64 %t445, ptr %l306, !tbaa !24
  %t446 = load i64, ptr %l306, !tbaa !24
  %t447 = icmp sge i64 %t446, 0
  br i1 %t447, label %bb120, label %bb121
bb119:
  br label %bb139
bb120:
  %t449 = load i64, ptr %l306, !tbaa !24
  %t450 = icmp sle i64 %t449, 1152921504606846975
  br i1 %t450, label %bb122, label %bb123
bb121:
  call void @__olang_check_failed(ptr @olang_loc_b4402838d0fec99d_8d63b3fead7ad2c9)
  unreachable
bb122:
  %t452 = load i64, ptr %l306, !tbaa !24
  %t453 = mul i64 %t452, 8
  %t454 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t453)
  %t455 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t456 = insertvalue { i64, ptr } %t455, ptr %t454, 1
  store { i64, ptr } %t456, ptr %l309, !tbaa !27
  %t457 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t457, 0
  %t459 = load { i64, ptr }, ptr %l309, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t459, 0
  store i64 %t460, ptr %l311, !tbaa !24
  %t462 = load i64, ptr %l311, !tbaa !24
  %t463 = icmp eq i64 %t458, %t462
  br i1 %t463, label %bb124, label %bb125
bb123:
  call void @__olang_check_failed(ptr @olang_loc_b4402838d0fec99d_8d63b3fead7ad2c9)
  unreachable
bb124:
  %t465 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !27
  %t467 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = load i64, ptr %l311, !tbaa !24
  %t470 = mul i64 %t469, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t466, ptr %t468, i64 %t470, i1 false)
  br label %bb126
bb125:
  %t471 = load { i64, ptr }, ptr %l309, !tbaa !27
  store { i64, ptr } %t471, ptr %l21, !tbaa !27
  br label %bb126
bb126:
  store i64 0, ptr %l22, !tbaa !24
  %t472 = load i64, ptr %l3, !tbaa !24
  store i64 %t472, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t474 = load i64, ptr %l23, !tbaa !24
  %t475 = load i64, ptr %l22, !tbaa !24
  %t478 = icmp sgt i64 %t474, %t475
  br i1 %t478, label %bb127, label %bb128
bb127:
  %t480 = load i64, ptr %l24, !tbaa !24
  %t482 = icmp sgt i64 %t480, 0
  br i1 %t482, label %bb129, label %bb130
bb128:
  store i64 0, ptr %l317, !tbaa !24
  br label %bb132
bb129:
  %t484 = load i64, ptr %l23, !tbaa !24
  %t485 = load i64, ptr %l22, !tbaa !24
  %t488 = sub i64 %t484, %t485
  %t489 = load i64, ptr %l24, !tbaa !24
  %t492 = add i64 %t488, %t489
  %t494 = sub i64 %t492, 1
  %t495 = load i64, ptr %l24, !tbaa !24
  %t498 = sdiv i64 %t494, %t495
  store i64 %t498, ptr %l320, !tbaa !24
  br label %bb131
bb130:
  store i64 0, ptr %l320, !tbaa !24
  br label %bb131
bb131:
  %t500 = load i64, ptr %l320, !tbaa !24
  store i64 %t500, ptr %l317, !tbaa !24
  br label %bb132
bb132:
  %t501 = load i64, ptr %l317, !tbaa !24
  store i64 %t501, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb133
bb133:
  %t502 = load i64, ptr %l26, !tbaa !24
  %t503 = load i64, ptr %l25, !tbaa !24
  %t506 = icmp slt i64 %t502, %t503
  %t508 = xor i1 %t506, true
  br i1 %t508, label %bb134, label %bb135
bb134:
  br label %bb138
bb135:
  br label %bb136
bb136:
  %t510 = load i64, ptr %l22, !tbaa !24
  %t511 = load i64, ptr %l26, !tbaa !24
  %t512 = load i64, ptr %l24, !tbaa !24
  %t515 = mul i64 %t511, %t512
  %t518 = add i64 %t510, %t515
  store i64 %t518, ptr %l27, !tbaa !24
  %t520 = load i64, ptr %l27, !tbaa !24
  %t521 = load i64, ptr %l27, !tbaa !24
  %t524 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t525 = load ptr, ptr %t524, !tbaa !27
  %t526 = getelementptr i64, ptr %t525, i64 %t520
  store i64 %t521, ptr %t526, !tbaa !34
  br label %bb137
bb137:
  %t527 = load i64, ptr %l26, !tbaa !24
  %t529 = add i64 %t527, 1
  store i64 %t529, ptr %l26, !tbaa !24
  br label %bb133
bb138:
  br label %bb139
bb139:
  %t531 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t531, ptr %l342
  br label %bb140
bb140:
  %t532 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l342
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t532, ptr %l28
  store i64 0, ptr %l29, !tbaa !24
  %t533 = load i64, ptr %l3, !tbaa !24
  store i64 %t533, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t535 = load i64, ptr %l30, !tbaa !24
  %t536 = load i64, ptr %l29, !tbaa !24
  %t539 = icmp sgt i64 %t535, %t536
  br i1 %t539, label %bb141, label %bb142
bb141:
  %t541 = load i64, ptr %l31, !tbaa !24
  %t543 = icmp sgt i64 %t541, 0
  br i1 %t543, label %bb143, label %bb144
bb142:
  store i64 0, ptr %l347, !tbaa !24
  br label %bb146
bb143:
  %t545 = load i64, ptr %l30, !tbaa !24
  %t546 = load i64, ptr %l29, !tbaa !24
  %t549 = sub i64 %t545, %t546
  %t550 = load i64, ptr %l31, !tbaa !24
  %t553 = add i64 %t549, %t550
  %t555 = sub i64 %t553, 1
  %t556 = load i64, ptr %l31, !tbaa !24
  %t559 = sdiv i64 %t555, %t556
  store i64 %t559, ptr %l350, !tbaa !24
  br label %bb145
bb144:
  store i64 0, ptr %l350, !tbaa !24
  br label %bb145
bb145:
  %t561 = load i64, ptr %l350, !tbaa !24
  store i64 %t561, ptr %l347, !tbaa !24
  br label %bb146
bb146:
  %t562 = load i64, ptr %l347, !tbaa !24
  store i64 %t562, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb147
bb147:
  store %olang.scope zeroinitializer, ptr %s18
  %t563 = load i64, ptr %l33, !tbaa !24
  %t564 = load i64, ptr %l32, !tbaa !24
  %t567 = icmp slt i64 %t563, %t564
  %t569 = xor i1 %t567, true
  br i1 %t569, label %bb148, label %bb149
bb148:
  call void @__olang_scope_close(ptr %s18)
  br label %bb154
bb149:
  br label %bb150
bb150:
  %t571 = load i64, ptr %l29, !tbaa !24
  %t572 = load i64, ptr %l33, !tbaa !24
  %t573 = load i64, ptr %l31, !tbaa !24
  %t576 = mul i64 %t572, %t573
  %t579 = add i64 %t571, %t576
  store i64 %t579, ptr %l34, !tbaa !24
  store ptr %l28, ptr %l368, !tbaa !29
  %t581 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s18, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t581, ptr %l369
  br label %bb151
bb151:
  %t582 = load ptr, ptr %l368, !tbaa !29
  %t583 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l369
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %s0, ptr %s18, ptr %t582, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t583)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s18)
  br label %bb153
bb153:
  %t584 = load i64, ptr %l33, !tbaa !24
  %t586 = add i64 %t584, 1
  store i64 %t586, ptr %l33, !tbaa !24
  br label %bb147
bb154:
  store i64 0, ptr %l35, !tbaa !24
  %t588 = load i64, ptr %l3, !tbaa !24
  store i64 %t588, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t590 = load i64, ptr %l36, !tbaa !24
  %t591 = load i64, ptr %l35, !tbaa !24
  %t594 = icmp sgt i64 %t590, %t591
  br i1 %t594, label %bb155, label %bb156
bb155:
  %t596 = load i64, ptr %l37, !tbaa !24
  %t598 = icmp sgt i64 %t596, 0
  br i1 %t598, label %bb157, label %bb158
bb156:
  store i64 0, ptr %l376, !tbaa !24
  br label %bb160
bb157:
  %t600 = load i64, ptr %l36, !tbaa !24
  %t601 = load i64, ptr %l35, !tbaa !24
  %t604 = sub i64 %t600, %t601
  %t605 = load i64, ptr %l37, !tbaa !24
  %t608 = add i64 %t604, %t605
  %t610 = sub i64 %t608, 1
  %t611 = load i64, ptr %l37, !tbaa !24
  %t614 = sdiv i64 %t610, %t611
  store i64 %t614, ptr %l379, !tbaa !24
  br label %bb159
bb158:
  store i64 0, ptr %l379, !tbaa !24
  br label %bb159
bb159:
  %t616 = load i64, ptr %l379, !tbaa !24
  store i64 %t616, ptr %l376, !tbaa !24
  br label %bb160
bb160:
  %t617 = load i64, ptr %l376, !tbaa !24
  store i64 %t617, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb161
bb161:
  %t618 = load i64, ptr %l39, !tbaa !24
  %t619 = load i64, ptr %l38, !tbaa !24
  %t622 = icmp slt i64 %t618, %t619
  %t624 = xor i1 %t622, true
  br i1 %t624, label %bb162, label %bb163
bb162:
  br label %bb181
bb163:
  br label %bb164
bb164:
  %t626 = load i64, ptr %l35, !tbaa !24
  %t627 = load i64, ptr %l39, !tbaa !24
  %t628 = load i64, ptr %l37, !tbaa !24
  %t631 = mul i64 %t627, %t628
  %t634 = add i64 %t626, %t631
  store i64 %t634, ptr %l40, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s22
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t638 = getelementptr %"compiler/free:Free", ptr %t636, i32 0, i32 2
  %t639 = load ptr, ptr %t638, !tbaa !29
  %t640 = load i64, ptr %l40, !tbaa !24
  %t643 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesOf(ptr %v0, ptr %s22, ptr %t639, i64 %t640)
  store { i64, ptr } %t643, ptr %l400
  br label %bb165
bb165:
  %t644 = load { i64, ptr }, ptr %l400, !tbaa !27
  %t645 = extractvalue { i64, ptr } %t644, 0
  %t646 = extractvalue { i64, ptr } %t644, 1
  %t647 = mul i64 %t645, 8
  %t648 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t647)
  call void @llvm.memcpy.p0.p0.i64(ptr %t648, ptr %t646, i64 %t647, i1 false)
  %t649 = insertvalue { i64, ptr } undef, i64 %t645, 0
  %t650 = insertvalue { i64, ptr } %t649, ptr %t648, 1
  store { i64, ptr } %t650, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t652 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t654 = extractvalue { i64, ptr } %t652, 0
  store i64 %t654, ptr %l43, !tbaa !24
  br label %bb166
bb166:
  %t656 = load i64, ptr %l42, !tbaa !24
  %t657 = load i64, ptr %l43, !tbaa !24
  %t660 = icmp slt i64 %t656, %t657
  %t662 = xor i1 %t660, true
  br i1 %t662, label %bb167, label %bb168
bb167:
  br label %bb179
bb168:
  br label %bb169
bb169:
  %t664 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t664, ptr %l408, !tbaa !27
  %t665 = load i64, ptr %l42, !tbaa !24
  %t667 = getelementptr { i64, ptr }, ptr %l408, i32 0, i32 1
  %t668 = load ptr, ptr %t667, !tbaa !27
  %t669 = getelementptr i64, ptr %t668, i64 %t665
  %t670 = load i64, ptr %t669, !tbaa !34
  store i64 %t670, ptr %l44, !tbaa !24
  %t672 = load i64, ptr %l44, !tbaa !24
  %t674 = icmp sge i64 %t672, 0
  br i1 %t674, label %bb170, label %bb171
bb170:
  %t676 = load i64, ptr %l44, !tbaa !24
  %t677 = load i64, ptr %l3, !tbaa !24
  %t680 = icmp slt i64 %t676, %t677
  store i1 %t680, ptr %l413, !tbaa !21
  br label %bb172
bb171:
  store i1 false, ptr %l413, !tbaa !21
  br label %bb172
bb172:
  %t682 = load i1, ptr %l413, !tbaa !21
  br i1 %t682, label %bb173, label %bb174
bb173:
  %t683 = load i64, ptr %l44, !tbaa !24
  %t686 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %s0, ptr %s0, ptr %l28, i64 %t683)
  store ptr %t686, ptr %l419
  br label %bb175
bb174:
  br label %bb177
bb175:
  %t687 = load i64, ptr %l40, !tbaa !24
  %t688 = load ptr, ptr %l419, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t688, i64 %t687)
  br label %bb176
bb176:
  br label %bb177
bb177:
  br label %bb178
bb178:
  %t690 = load i64, ptr %l42, !tbaa !24
  %t692 = add i64 %t690, 1
  store i64 %t692, ptr %l42, !tbaa !24
  br label %bb166
bb179:
  call void @__olang_scope_close(ptr %s22)
  br label %bb180
bb180:
  %t694 = load i64, ptr %l39, !tbaa !24
  %t696 = add i64 %t694, 1
  store i64 %t696, ptr %l39, !tbaa !24
  br label %bb161
bb181:
  store i64 0, ptr %l45, !tbaa !24
  %t698 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t698, ptr %l425
  br label %bb182
bb182:
  %t699 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l425
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t699, ptr %l46
  %t700 = load i64, ptr %l3, !tbaa !24
  store i64 %t700, ptr %l426, !tbaa !24
  %t701 = load i64, ptr %l426, !tbaa !24
  %t702 = icmp sge i64 %t701, 0
  br i1 %t702, label %bb183, label %bb184
bb183:
  %t704 = load i64, ptr %l426, !tbaa !24
  %t705 = mul i64 %t704, 1
  %t706 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t705)
  store i64 0, ptr %t707
  br label %fill.708
fill.708:
  %t711 = load i64, ptr %t707
  %t712 = icmp slt i64 %t711, %t704
  br i1 %t712, label %fillb.709, label %filld.710
fillb.709:
  %t713 = getelementptr i1, ptr %t706, i64 %t711
  store i1 true, ptr %t713
  %t714 = add i64 %t711, 1
  store i64 %t714, ptr %t707
  br label %fill.708
filld.710:
  %t715 = insertvalue { i64, ptr } undef, i64 %t704, 0
  %t716 = insertvalue { i64, ptr } %t715, ptr %t706, 1
  store { i64, ptr } %t716, ptr %l47, !tbaa !27
  %t718 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t718, ptr %l48, !tbaa !27
  store i64 0, ptr %l49, !tbaa !24
  %t720 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t722 = extractvalue { i64, ptr } %t720, 0
  store i64 %t722, ptr %l50, !tbaa !24
  br label %bb185
bb184:
  call void @__olang_check_failed(ptr @olang_loc_7774858aec9876f0_864a54e21bf2c67c)
  unreachable
bb185:
  %t724 = load i64, ptr %l49, !tbaa !24
  %t725 = load i64, ptr %l50, !tbaa !24
  %t728 = icmp slt i64 %t724, %t725
  %t730 = xor i1 %t728, true
  br i1 %t730, label %bb186, label %bb187
bb186:
  br label %bb191
bb187:
  br label %bb188
bb188:
  %t732 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t732, ptr %l436, !tbaa !27
  %t733 = load i64, ptr %l49, !tbaa !24
  %t735 = getelementptr { i64, ptr }, ptr %l436, i32 0, i32 1
  %t736 = load ptr, ptr %t735, !tbaa !27
  %t737 = getelementptr i64, ptr %t736, i64 %t733
  %t738 = load i64, ptr %t737, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l46, i64 %t738)
  br label %bb189
bb189:
  br label %bb190
bb190:
  %t743 = load i64, ptr %l49, !tbaa !24
  %t745 = add i64 %t743, 1
  store i64 %t745, ptr %l49, !tbaa !24
  br label %bb185
bb191:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb192
bb192:
  %t747 = load i64, ptr %l52, !tbaa !24
  store i64 %t747, ptr %l443, !tbaa !24
  %t749 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l46)
  store i64 %t749, ptr %l445
  br label %bb193
bb193:
  %t750 = load i64, ptr %l443, !tbaa !24
  %t751 = load i64, ptr %l445, !tbaa !24
  %t752 = icmp slt i64 %t750, %t751
  %t754 = xor i1 %t752, true
  br i1 %t754, label %bb194, label %bb195
bb194:
  br label %bb217
bb195:
  br label %bb196
bb196:
  %t756 = load i64, ptr %l52, !tbaa !24
  %t759 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l46, i64 %t756)
  store i64 %t759, ptr %l450
  br label %bb197
bb197:
  %t760 = load i64, ptr %l450, !tbaa !24
  store i64 %t760, ptr %l53, !tbaa !24
  %t761 = load i64, ptr %l53, !tbaa !24
  %t763 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t764 = load ptr, ptr %t763, !tbaa !27
  %t765 = getelementptr i1, ptr %t764, i64 %t761
  store i1 false, ptr %t765, !tbaa !31
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t768 = getelementptr %"compiler/free:Free", ptr %t766, i32 0, i32 36
  store i1 false, ptr %t768, !tbaa !21
  %t769 = load i64, ptr %l45, !tbaa !24
  %t771 = add i64 %t769, 1
  store i64 %t771, ptr %l45, !tbaa !24
  %t773 = load ptr, ptr %l0, !tbaa !29
  %t774 = load i64, ptr %l53, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2emustOf(ptr %v0, ptr %t773, i64 %t774)
  br label %bb198
bb198:
  %t777 = load ptr, ptr %l0, !tbaa !29
  %t779 = getelementptr %"compiler/free:Free", ptr %t777, i32 0, i32 36
  %t780 = load i1, ptr %t779, !tbaa !21
  %t782 = xor i1 %t780, true
  br i1 %t782, label %bb199, label %bb200
bb199:
  br label %bb216
bb200:
  br label %bb201
bb201:
  store %olang.scope zeroinitializer, ptr %s33
  %t784 = load i64, ptr %l53, !tbaa !24
  %t787 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s33, ptr %l28, i64 %t784)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t787, ptr %l462
  br label %bb202
bb202:
  %t789 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s33, ptr %l462)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t789, ptr %l464
  br label %bb203
bb203:
  %t790 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l464
  %t791 = call ptr @__olang_scope_alloc_a(ptr %s33, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t790, ptr %t791
  store ptr %t791, ptr %l54, !tbaa !29
  store i64 0, ptr %l55, !tbaa !24
  br label %bb204
bb204:
  %t793 = load i64, ptr %l55, !tbaa !24
  store i64 %t793, ptr %l466, !tbaa !24
  %t794 = load ptr, ptr %l54, !tbaa !29
  %t796 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s33, ptr %t794)
  store i64 %t796, ptr %l468
  br label %bb205
bb205:
  %t797 = load i64, ptr %l466, !tbaa !24
  %t798 = load i64, ptr %l468, !tbaa !24
  %t799 = icmp slt i64 %t797, %t798
  %t801 = xor i1 %t799, true
  br i1 %t801, label %bb206, label %bb207
bb206:
  br label %bb215
bb207:
  br label %bb208
bb208:
  %t803 = load ptr, ptr %l54, !tbaa !29
  %t804 = load i64, ptr %l55, !tbaa !24
  %t807 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s33, ptr %t803, i64 %t804)
  store i64 %t807, ptr %l473
  br label %bb209
bb209:
  %t808 = load i64, ptr %l473, !tbaa !24
  store i64 %t808, ptr %l56, !tbaa !24
  %t809 = load i64, ptr %l56, !tbaa !24
  %t811 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t812 = load ptr, ptr %t811, !tbaa !27
  %t813 = getelementptr i1, ptr %t812, i64 %t809
  %t814 = load i1, ptr %t813, !tbaa !31
  %t816 = xor i1 %t814, true
  br i1 %t816, label %bb210, label %bb211
bb210:
  %t818 = load i64, ptr %l56, !tbaa !24
  %t820 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t821 = load ptr, ptr %t820, !tbaa !27
  %t822 = getelementptr i1, ptr %t821, i64 %t818
  store i1 true, ptr %t822, !tbaa !31
  %t823 = load i64, ptr %l56, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l46, i64 %t823)
  br label %bb212
bb211:
  br label %bb213
bb212:
  br label %bb213
bb213:
  br label %bb214
bb214:
  %t826 = load i64, ptr %l55, !tbaa !24
  %t828 = add i64 %t826, 1
  store i64 %t828, ptr %l55, !tbaa !24
  br label %bb204
bb215:
  call void @__olang_scope_close(ptr %s33)
  br label %bb216
bb216:
  %t830 = load i64, ptr %l52, !tbaa !24
  %t832 = add i64 %t830, 1
  store i64 %t832, ptr %l52, !tbaa !24
  br label %bb192
bb217:
  %t834 = call i64 @std_2ftime_2eNow()
  store i64 %t834, ptr %l484
  br label %bb218
bb218:
  %t835 = load i64, ptr %l484, !tbaa !24
  store i64 %t835, ptr %l57, !tbaa !24
  store i64 0, ptr %l58, !tbaa !24
  %t836 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t836, ptr %l485
  br label %bb219
bb219:
  %t837 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l485
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t837, ptr %l59
  %t838 = load i64, ptr %l3, !tbaa !24
  store i64 %t838, ptr %l486, !tbaa !24
  %t839 = load i64, ptr %l486, !tbaa !24
  %t840 = icmp sge i64 %t839, 0
  br i1 %t840, label %bb220, label %bb221
bb220:
  %t842 = load i64, ptr %l486, !tbaa !24
  %t843 = mul i64 %t842, 1
  %t844 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t843)
  store i64 0, ptr %t845
  br label %fill.846
fill.846:
  %t849 = load i64, ptr %t845
  %t850 = icmp slt i64 %t849, %t842
  br i1 %t850, label %fillb.847, label %filld.848
fillb.847:
  %t851 = getelementptr i1, ptr %t844, i64 %t849
  store i1 true, ptr %t851
  %t852 = add i64 %t849, 1
  store i64 %t852, ptr %t845
  br label %fill.846
filld.848:
  %t853 = insertvalue { i64, ptr } undef, i64 %t842, 0
  %t854 = insertvalue { i64, ptr } %t853, ptr %t844, 1
  store { i64, ptr } %t854, ptr %l60, !tbaa !27
  %t856 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t856, ptr %l61, !tbaa !27
  store i64 0, ptr %l62, !tbaa !24
  %t858 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t860 = extractvalue { i64, ptr } %t858, 0
  store i64 %t860, ptr %l63, !tbaa !24
  br label %bb222
bb221:
  call void @__olang_check_failed(ptr @olang_loc_a3e4b8257e528993_6ac514faf6c963df)
  unreachable
bb222:
  %t862 = load i64, ptr %l62, !tbaa !24
  %t863 = load i64, ptr %l63, !tbaa !24
  %t866 = icmp slt i64 %t862, %t863
  %t868 = xor i1 %t866, true
  br i1 %t868, label %bb223, label %bb224
bb223:
  br label %bb228
bb224:
  br label %bb225
bb225:
  %t870 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t870, ptr %l496, !tbaa !27
  %t871 = load i64, ptr %l62, !tbaa !24
  %t873 = getelementptr { i64, ptr }, ptr %l496, i32 0, i32 1
  %t874 = load ptr, ptr %t873, !tbaa !27
  %t875 = getelementptr i64, ptr %t874, i64 %t871
  %t876 = load i64, ptr %t875, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l59, i64 %t876)
  br label %bb226
bb226:
  br label %bb227
bb227:
  %t881 = load i64, ptr %l62, !tbaa !24
  %t883 = add i64 %t881, 1
  store i64 %t883, ptr %l62, !tbaa !24
  br label %bb222
bb228:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb229
bb229:
  %t885 = load i64, ptr %l65, !tbaa !24
  store i64 %t885, ptr %l503, !tbaa !24
  %t887 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l59)
  store i64 %t887, ptr %l505
  br label %bb230
bb230:
  %t888 = load i64, ptr %l503, !tbaa !24
  %t889 = load i64, ptr %l505, !tbaa !24
  %t890 = icmp slt i64 %t888, %t889
  %t892 = xor i1 %t890, true
  br i1 %t892, label %bb231, label %bb232
bb231:
  br label %bb253
bb232:
  br label %bb233
bb233:
  %t894 = load i64, ptr %l65, !tbaa !24
  %t897 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l59, i64 %t894)
  store i64 %t897, ptr %l510
  br label %bb234
bb234:
  %t898 = load i64, ptr %l510, !tbaa !24
  store i64 %t898, ptr %l66, !tbaa !24
  %t899 = load i64, ptr %l66, !tbaa !24
  %t901 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t902 = load ptr, ptr %t901, !tbaa !27
  %t903 = getelementptr i1, ptr %t902, i64 %t899
  store i1 false, ptr %t903, !tbaa !31
  %t904 = load ptr, ptr %l0, !tbaa !29
  %t906 = getelementptr %"compiler/free:Free", ptr %t904, i32 0, i32 36
  store i1 false, ptr %t906, !tbaa !21
  %t907 = load i64, ptr %l58, !tbaa !24
  %t909 = add i64 %t907, 1
  store i64 %t909, ptr %l58, !tbaa !24
  %t911 = load ptr, ptr %l0, !tbaa !29
  %t912 = load i64, ptr %l66, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewalk(ptr %v0, ptr %t911, i64 %t912, i1 false)
  br label %bb235
bb235:
  %t915 = load ptr, ptr %l0, !tbaa !29
  %t917 = getelementptr %"compiler/free:Free", ptr %t915, i32 0, i32 36
  %t918 = load i1, ptr %t917, !tbaa !21
  %t920 = xor i1 %t918, true
  br i1 %t920, label %bb236, label %bb237
bb236:
  br label %bb252
bb237:
  br label %bb238
bb238:
  %t922 = load ptr, ptr %l0, !tbaa !29
  %t924 = getelementptr %"compiler/free:Free", ptr %t922, i32 0, i32 56
  %t925 = load i64, ptr %l66, !tbaa !24
  %t928 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t924, i64 %t925)
  store ptr %t928, ptr %l523
  br label %bb239
bb239:
  %t929 = load ptr, ptr %l523, !tbaa !29
  store ptr %t929, ptr %l67, !tbaa !29
  store i64 0, ptr %l68, !tbaa !24
  br label %bb240
bb240:
  %t930 = load i64, ptr %l68, !tbaa !24
  store i64 %t930, ptr %l524, !tbaa !24
  %t931 = load ptr, ptr %l67, !tbaa !29
  %t933 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t931)
  store i64 %t933, ptr %l526
  br label %bb241
bb241:
  %t934 = load i64, ptr %l524, !tbaa !24
  %t935 = load i64, ptr %l526, !tbaa !24
  %t936 = icmp slt i64 %t934, %t935
  %t938 = xor i1 %t936, true
  br i1 %t938, label %bb242, label %bb243
bb242:
  br label %bb251
bb243:
  br label %bb244
bb244:
  %t940 = load ptr, ptr %l67, !tbaa !29
  %t941 = load i64, ptr %l68, !tbaa !24
  %t944 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t940, i64 %t941)
  store i64 %t944, ptr %l531
  br label %bb245
bb245:
  %t945 = load i64, ptr %l531, !tbaa !24
  store i64 %t945, ptr %l69, !tbaa !24
  %t946 = load i64, ptr %l69, !tbaa !24
  %t948 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t949 = load ptr, ptr %t948, !tbaa !27
  %t950 = getelementptr i1, ptr %t949, i64 %t946
  %t951 = load i1, ptr %t950, !tbaa !31
  %t953 = xor i1 %t951, true
  br i1 %t953, label %bb246, label %bb247
bb246:
  %t955 = load i64, ptr %l69, !tbaa !24
  %t957 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t958 = load ptr, ptr %t957, !tbaa !27
  %t959 = getelementptr i1, ptr %t958, i64 %t955
  store i1 true, ptr %t959, !tbaa !31
  %t960 = load i64, ptr %l69, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l59, i64 %t960)
  br label %bb248
bb247:
  br label %bb249
bb248:
  br label %bb249
bb249:
  br label %bb250
bb250:
  %t963 = load i64, ptr %l68, !tbaa !24
  %t965 = add i64 %t963, 1
  store i64 %t965, ptr %l68, !tbaa !24
  br label %bb240
bb251:
  br label %bb252
bb252:
  %t967 = load i64, ptr %l65, !tbaa !24
  %t969 = add i64 %t967, 1
  store i64 %t969, ptr %l65, !tbaa !24
  br label %bb229
bb253:
  %t971 = call i64 @std_2ftime_2eNow()
  store i64 %t971, ptr %l542
  br label %bb254
bb254:
  %t972 = load i64, ptr %l542, !tbaa !24
  store i64 %t972, ptr %l70, !tbaa !24
  %t973 = load ptr, ptr %l0, !tbaa !29
  %t975 = getelementptr %"compiler/free:Free", ptr %t973, i32 0, i32 66
  %t976 = load i1, ptr %t975, !tbaa !21
  br i1 %t976, label %bb255, label %bb256
bb255:
  store %olang.scope zeroinitializer, ptr %s49
  %t978 = load i64, ptr %l3, !tbaa !24
  store i64 %t978, ptr %l545, !tbaa !24
  %t979 = load ptr, ptr %l0, !tbaa !29
  %t981 = getelementptr %"compiler/free:Free", ptr %t979, i32 0, i32 8
  %t983 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t981)
  store i64 %t983, ptr %l548
  br label %bb257
bb256:
  br label %bb264
bb257:
  %t984 = load i64, ptr %l45, !tbaa !24
  %t985 = load i64, ptr %l57, !tbaa !24
  %t986 = load i64, ptr %l20, !tbaa !24
  %t989 = sub i64 %t985, %t986
  %t991 = sdiv i64 %t989, 1000000
  %t992 = load i64, ptr %l58, !tbaa !24
  %t993 = load ptr, ptr %l0, !tbaa !29
  %t995 = getelementptr %"compiler/free:Free", ptr %t993, i32 0, i32 4
  %t996 = load i64, ptr %t995, !tbaa !24
  %t997 = load i64, ptr %l70, !tbaa !24
  %t998 = load i64, ptr %l57, !tbaa !24
  %t1001 = sub i64 %t997, %t998
  %t1003 = sdiv i64 %t1001, 1000000
  %t1004 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t1005 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t1006 = load i64, ptr %l545, !tbaa !24
  %t1007 = call i64 @__olang_fmt_i64(ptr null, i64 %t1006)
  %t1008 = add i64 %t1005, %t1007
  %t1009 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t1010 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t1011 = add i64 %t1008, %t1010
  %t1012 = load i64, ptr %l548, !tbaa !24
  %t1013 = call i64 @__olang_fmt_i64(ptr null, i64 %t1012)
  %t1014 = add i64 %t1011, %t1013
  %t1015 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t1016 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t1017 = add i64 %t1014, %t1016
  %t1019 = call i64 @__olang_fmt_i64(ptr null, i64 %t984)
  %t1020 = add i64 %t1017, %t1019
  %t1021 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t1022 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t1023 = add i64 %t1020, %t1022
  %t1025 = call i64 @__olang_fmt_i64(ptr null, i64 %t991)
  %t1026 = add i64 %t1023, %t1025
  %t1027 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t1028 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t1029 = add i64 %t1026, %t1028
  %t1031 = call i64 @__olang_fmt_i64(ptr null, i64 %t992)
  %t1032 = add i64 %t1029, %t1031
  %t1033 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t1034 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t1035 = add i64 %t1032, %t1034
  %t1037 = call i64 @__olang_fmt_i64(ptr null, i64 %t996)
  %t1038 = add i64 %t1035, %t1037
  %t1039 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t1040 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t1041 = add i64 %t1038, %t1040
  %t1043 = call i64 @__olang_fmt_i64(ptr null, i64 %t1003)
  %t1044 = add i64 %t1041, %t1043
  %t1045 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t1046 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t1047 = add i64 %t1044, %t1046
  %t1048 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1047)
  call void @olang_textcopy(ptr %t1048, ptr %t1004, i64 %t1005)
  %t1049 = getelementptr i8, ptr %t1048, i64 %t1005
  %t1050 = call i64 @__olang_fmt_i64(ptr %t1049, i64 %t1006)
  %t1051 = getelementptr i8, ptr %t1049, i64 %t1007
  call void @olang_textcopy(ptr %t1051, ptr %t1009, i64 %t1010)
  %t1052 = getelementptr i8, ptr %t1051, i64 %t1010
  %t1053 = call i64 @__olang_fmt_i64(ptr %t1052, i64 %t1012)
  %t1054 = getelementptr i8, ptr %t1052, i64 %t1013
  call void @olang_textcopy(ptr %t1054, ptr %t1015, i64 %t1016)
  %t1055 = getelementptr i8, ptr %t1054, i64 %t1016
  %t1056 = call i64 @__olang_fmt_i64(ptr %t1055, i64 %t984)
  %t1057 = getelementptr i8, ptr %t1055, i64 %t1019
  call void @olang_textcopy(ptr %t1057, ptr %t1021, i64 %t1022)
  %t1058 = getelementptr i8, ptr %t1057, i64 %t1022
  %t1059 = call i64 @__olang_fmt_i64(ptr %t1058, i64 %t991)
  %t1060 = getelementptr i8, ptr %t1058, i64 %t1025
  call void @olang_textcopy(ptr %t1060, ptr %t1027, i64 %t1028)
  %t1061 = getelementptr i8, ptr %t1060, i64 %t1028
  %t1062 = call i64 @__olang_fmt_i64(ptr %t1061, i64 %t992)
  %t1063 = getelementptr i8, ptr %t1061, i64 %t1031
  call void @olang_textcopy(ptr %t1063, ptr %t1033, i64 %t1034)
  %t1064 = getelementptr i8, ptr %t1063, i64 %t1034
  %t1065 = call i64 @__olang_fmt_i64(ptr %t1064, i64 %t996)
  %t1066 = getelementptr i8, ptr %t1064, i64 %t1037
  call void @olang_textcopy(ptr %t1066, ptr %t1039, i64 %t1040)
  %t1067 = getelementptr i8, ptr %t1066, i64 %t1040
  %t1068 = call i64 @__olang_fmt_i64(ptr %t1067, i64 %t1003)
  %t1069 = getelementptr i8, ptr %t1067, i64 %t1043
  call void @olang_textcopy(ptr %t1069, ptr %t1045, i64 %t1046)
  %t1070 = insertvalue { i64, ptr } undef, i64 %t1047, 0
  %t1071 = insertvalue { i64, ptr } %t1070, ptr %t1048, 1
  %t1073 = extractvalue { i64, ptr } %t1071, 0
  %t1074 = extractvalue { i64, ptr } %t1071, 1
  %t1075 = mul i64 %t1073, 1
  %t1076 = call ptr @__olang_scope_alloc(ptr %s49, i64 %t1075)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1076, ptr %t1074, i64 %t1075, i1 false)
  %t1077 = insertvalue { i64, ptr } undef, i64 %t1073, 0
  %t1078 = insertvalue { i64, ptr } %t1077, ptr %t1076, 1
  %t1080 = call i32 @std_2fio_2ePrintErr(ptr %s49, { i64, ptr } %t1078)
  store i32 %t1080, ptr %l563
  %t1081 = icmp ne i32 %t1080, 0
  br i1 %t1081, label %bb259, label %ok.1082, !prof !99
ok.1082:
  br label %bb258
bb258:
  br label %bb263
bb259:
  %t1083 = load i32, ptr %l563, !tbaa !23
  %t1084 = ashr i32 %t1083, 16
  %t1086 = icmp eq i32 %t1084, 1
  store i1 %t1086, ptr %l565, !tbaa !21
  %t1087 = load i32, ptr %l563, !tbaa !23
  %t1088 = ashr i32 %t1087, 16
  %t1090 = icmp eq i32 %t1088, 1
  br i1 %t1090, label %bb260, label %bb261
bb260:
  call void @__olang_errpay_pop()
  br label %bb261
bb261:
  br label %bb262
bb262:
  br label %bb263
bb263:
  call void @__olang_scope_close(ptr %s49)
  br label %bb264
bb264:
  store i64 0, ptr %l71, !tbaa !24
  %t1092 = load i64, ptr %l3, !tbaa !24
  store i64 %t1092, ptr %l72, !tbaa !24
  store i64 1, ptr %l73, !tbaa !24
  %t1094 = load i64, ptr %l72, !tbaa !24
  %t1095 = load i64, ptr %l71, !tbaa !24
  %t1098 = icmp sgt i64 %t1094, %t1095
  br i1 %t1098, label %bb265, label %bb266
bb265:
  %t1100 = load i64, ptr %l73, !tbaa !24
  %t1102 = icmp sgt i64 %t1100, 0
  br i1 %t1102, label %bb267, label %bb268
bb266:
  store i64 0, ptr %l572, !tbaa !24
  br label %bb270
bb267:
  %t1104 = load i64, ptr %l72, !tbaa !24
  %t1105 = load i64, ptr %l71, !tbaa !24
  %t1108 = sub i64 %t1104, %t1105
  %t1109 = load i64, ptr %l73, !tbaa !24
  %t1112 = add i64 %t1108, %t1109
  %t1114 = sub i64 %t1112, 1
  %t1115 = load i64, ptr %l73, !tbaa !24
  %t1118 = sdiv i64 %t1114, %t1115
  store i64 %t1118, ptr %l575, !tbaa !24
  br label %bb269
bb268:
  store i64 0, ptr %l575, !tbaa !24
  br label %bb269
bb269:
  %t1120 = load i64, ptr %l575, !tbaa !24
  store i64 %t1120, ptr %l572, !tbaa !24
  br label %bb270
bb270:
  %t1121 = load i64, ptr %l572, !tbaa !24
  store i64 %t1121, ptr %l74, !tbaa !24
  store i64 0, ptr %l75, !tbaa !24
  br label %bb271
bb271:
  %t1122 = load i64, ptr %l75, !tbaa !24
  %t1123 = load i64, ptr %l74, !tbaa !24
  %t1126 = icmp slt i64 %t1122, %t1123
  %t1128 = xor i1 %t1126, true
  br i1 %t1128, label %bb272, label %bb273
bb272:
  br label %bb312
bb273:
  br label %bb274
bb274:
  %t1130 = load i64, ptr %l71, !tbaa !24
  %t1131 = load i64, ptr %l75, !tbaa !24
  %t1132 = load i64, ptr %l73, !tbaa !24
  %t1135 = mul i64 %t1131, %t1132
  %t1138 = add i64 %t1130, %t1135
  store i64 %t1138, ptr %l76, !tbaa !24
  %t1140 = load ptr, ptr %l0, !tbaa !29
  %t1142 = getelementptr %"compiler/free:Free", ptr %t1140, i32 0, i32 30
  %t1143 = load i64, ptr %l76, !tbaa !24
  %t1146 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t1142, i64 %t1143)
  store ptr %t1146, ptr %l596
  br label %bb275
bb275:
  %t1147 = load ptr, ptr %l596, !tbaa !29
  %t1148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t1147)
  store i64 %t1148, ptr %l597
  br label %bb276
bb276:
  %t1149 = load i64, ptr %l597, !tbaa !24
  %t1150 = icmp sgt i64 %t1149, 0
  br i1 %t1150, label %bb277, label %bb278
bb277:
  store i1 true, ptr %l599, !tbaa !21
  br label %bb280
bb278:
  %t1152 = load ptr, ptr %l0, !tbaa !29
  %t1154 = getelementptr %"compiler/free:Free", ptr %t1152, i32 0, i32 31
  %t1155 = load i64, ptr %l76, !tbaa !24
  %t1158 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1154, i64 %t1155)
  store i1 %t1158, ptr %l603
  br label %bb279
bb279:
  %t1159 = load i1, ptr %l603, !tbaa !21
  store i1 %t1159, ptr %l599, !tbaa !21
  br label %bb280
bb280:
  %t1160 = load i1, ptr %l599, !tbaa !21
  br i1 %t1160, label %bb281, label %bb282
bb281:
  %t1161 = load ptr, ptr %l0, !tbaa !29
  %t1162 = load i64, ptr %l76, !tbaa !24
  %t1165 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eimplicit(ptr %v0, ptr %t1161, i64 %t1162)
  store i1 %t1165, ptr %l606
  br label %bb283
bb282:
  br label %bb310
bb283:
  %t1166 = load i1, ptr %l606, !tbaa !21
  br i1 %t1166, label %bb284, label %bb285
bb284:
  %t1167 = load ptr, ptr %l0, !tbaa !29
  %t1168 = load i64, ptr %l76, !tbaa !24
  %t1171 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emodelled(ptr %v0, ptr %t1167, i64 %t1168)
  store i1 %t1171, ptr %l610
  br label %bb286
bb285:
  store i1 false, ptr %l607, !tbaa !21
  br label %bb287
bb286:
  %t1172 = load i1, ptr %l610, !tbaa !21
  %t1173 = xor i1 %t1172, true
  store i1 %t1173, ptr %l607, !tbaa !21
  br label %bb287
bb287:
  %t1175 = load i1, ptr %l607, !tbaa !21
  br i1 %t1175, label %bb288, label %bb289
bb288:
  %t1176 = load ptr, ptr %l0, !tbaa !29
  %t1178 = getelementptr %"compiler/free:Free", ptr %t1176, i32 0, i32 31
  %t1179 = load i64, ptr %l76, !tbaa !24
  %t1182 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1178, i64 %t1179)
  store i1 %t1182, ptr %l615
  br label %bb290
bb289:
  br label %bb309
bb290:
  %t1183 = load i1, ptr %l615, !tbaa !21
  br i1 %t1183, label %bb291, label %bb292
bb291:
  %t1184 = load ptr, ptr %l0, !tbaa !29
  %t1186 = getelementptr %"compiler/free:Free", ptr %t1184, i32 0, i32 40
  store i1 true, ptr %t1186, !tbaa !21
  br label %bb295
bb292:
  %t1187 = load ptr, ptr %l0, !tbaa !29
  %t1189 = getelementptr %"compiler/free:Free", ptr %t1187, i32 0, i32 41
  store ptr %t1189, ptr %l618, !tbaa !29
  %t1190 = load ptr, ptr %l0, !tbaa !29
  %t1192 = getelementptr %"compiler/free:Free", ptr %t1190, i32 0, i32 30
  %t1193 = load i64, ptr %l76, !tbaa !24
  %t1196 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t1192, i64 %t1193)
  store ptr %t1196, ptr %l622
  br label %bb293
bb293:
  %t1197 = load ptr, ptr %l618, !tbaa !29
  %t1198 = load ptr, ptr %l622, !tbaa !29
  %t1199 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v0, ptr %t1197, ptr %t1198)
  store i64 %t1199, ptr %l623
  br label %bb294
bb294:
  br label %bb295
bb295:
  %t1200 = load ptr, ptr %l0, !tbaa !29
  %t1202 = getelementptr %"compiler/free:Free", ptr %t1200, i32 0, i32 66
  %t1203 = load i1, ptr %t1202, !tbaa !21
  br i1 %t1203, label %bb296, label %bb297
bb296:
  store %olang.scope zeroinitializer, ptr %s58
  %t1205 = load ptr, ptr %l0, !tbaa !29
  %t1206 = load i64, ptr %l76, !tbaa !24
  %t1209 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s58, ptr %t1205, i64 %t1206)
  store { i64, ptr } %t1209, ptr %l628
  br label %bb298
bb297:
  br label %bb308
bb298:
  %t1210 = load ptr, ptr %l0, !tbaa !29
  %t1212 = getelementptr %"compiler/free:Free", ptr %t1210, i32 0, i32 0
  %t1213 = load ptr, ptr %t1212, !tbaa !29
  %t1215 = getelementptr %"compiler/generic:Program", ptr %t1213, i32 0, i32 0
  %t1216 = load ptr, ptr %t1215, !tbaa !29
  %t1218 = getelementptr %"compiler/load:Loader", ptr %t1216, i32 0, i32 4
  %t1219 = load ptr, ptr %t1218, !tbaa !29
  store ptr %t1219, ptr %l632, !tbaa !29
  %t1220 = load ptr, ptr %l0, !tbaa !29
  %t1222 = getelementptr %"compiler/free:Free", ptr %t1220, i32 0, i32 1
  %t1223 = load i64, ptr %l76, !tbaa !24
  %t1226 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t1222, i64 %t1223)
  store ptr %t1226, ptr %l636
  br label %bb299
bb299:
  %t1227 = load ptr, ptr %l636, !tbaa !29
  %t1229 = getelementptr %"compiler/typed:Body", ptr %t1227, i32 0, i32 3
  %t1230 = load i64, ptr %t1229, !tbaa !24
  store i64 %t1230, ptr %l638, !tbaa !24
  %t1231 = load ptr, ptr %l0, !tbaa !29
  %t1233 = getelementptr %"compiler/free:Free", ptr %t1231, i32 0, i32 1
  %t1234 = load i64, ptr %l76, !tbaa !24
  %t1237 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t1233, i64 %t1234)
  store ptr %t1237, ptr %l642
  br label %bb300
bb300:
  %t1238 = load ptr, ptr %l642, !tbaa !29
  %t1240 = getelementptr %"compiler/typed:Body", ptr %t1238, i32 0, i32 4
  %t1241 = getelementptr %"compiler/source:Span", ptr %t1240, i32 0, i32 0
  %t1242 = load i32, ptr %t1241, !tbaa !23
  %t1244 = sext i32 %t1242 to i64
  %t1245 = load ptr, ptr %l632, !tbaa !29
  %t1246 = load i64, ptr %l638, !tbaa !24
  %t1248 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s58, ptr %t1245, i64 %t1246, i64 %t1244)
  store { i64, ptr } %t1248, ptr %l646
  br label %bb301
bb301:
  %t1249 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t1250 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t1251 = load { i64, ptr }, ptr %l628, !tbaa !27
  %t1252 = extractvalue { i64, ptr } %t1251, 1
  %t1253 = extractvalue { i64, ptr } %t1251, 0
  %t1254 = add i64 %t1250, %t1253
  %t1255 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t1256 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t1257 = add i64 %t1254, %t1256
  %t1258 = load { i64, ptr }, ptr %l646, !tbaa !27
  %t1259 = extractvalue { i64, ptr } %t1258, 1
  %t1260 = extractvalue { i64, ptr } %t1258, 0
  %t1261 = add i64 %t1257, %t1260
  %t1262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t1263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t1264 = add i64 %t1261, %t1263
  %t1265 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t1264)
  call void @olang_textcopy(ptr %t1265, ptr %t1249, i64 %t1250)
  %t1266 = getelementptr i8, ptr %t1265, i64 %t1250
  call void @olang_textcopy(ptr %t1266, ptr %t1252, i64 %t1253)
  %t1267 = getelementptr i8, ptr %t1266, i64 %t1253
  call void @olang_textcopy(ptr %t1267, ptr %t1255, i64 %t1256)
  %t1268 = getelementptr i8, ptr %t1267, i64 %t1256
  call void @olang_textcopy(ptr %t1268, ptr %t1259, i64 %t1260)
  %t1269 = getelementptr i8, ptr %t1268, i64 %t1260
  call void @olang_textcopy(ptr %t1269, ptr %t1262, i64 %t1263)
  %t1270 = insertvalue { i64, ptr } undef, i64 %t1264, 0
  %t1271 = insertvalue { i64, ptr } %t1270, ptr %t1265, 1
  %t1273 = extractvalue { i64, ptr } %t1271, 0
  %t1274 = extractvalue { i64, ptr } %t1271, 1
  %t1275 = mul i64 %t1273, 1
  %t1276 = call ptr @__olang_scope_alloc(ptr %s58, i64 %t1275)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1276, ptr %t1274, i64 %t1275, i1 false)
  %t1277 = insertvalue { i64, ptr } undef, i64 %t1273, 0
  %t1278 = insertvalue { i64, ptr } %t1277, ptr %t1276, 1
  %t1280 = call i32 @std_2fio_2ePrintErr(ptr %s58, { i64, ptr } %t1278)
  store i32 %t1280, ptr %l649
  %t1281 = icmp ne i32 %t1280, 0
  br i1 %t1281, label %bb303, label %ok.1282, !prof !99
ok.1282:
  br label %bb302
bb302:
  br label %bb307
bb303:
  %t1283 = load i32, ptr %l649, !tbaa !23
  %t1284 = ashr i32 %t1283, 16
  %t1286 = icmp eq i32 %t1284, 1
  store i1 %t1286, ptr %l651, !tbaa !21
  %t1287 = load i32, ptr %l649, !tbaa !23
  %t1288 = ashr i32 %t1287, 16
  %t1290 = icmp eq i32 %t1288, 1
  br i1 %t1290, label %bb304, label %bb305
bb304:
  call void @__olang_errpay_pop()
  br label %bb305
bb305:
  br label %bb306
bb306:
  br label %bb307
bb307:
  call void @__olang_scope_close(ptr %s58)
  br label %bb308
bb308:
  br label %bb309
bb309:
  br label %bb310
bb310:
  br label %bb311
bb311:
  %t1292 = load i64, ptr %l75, !tbaa !24
  %t1294 = add i64 %t1292, 1
  store i64 %t1294, ptr %l75, !tbaa !24
  br label %bb271
bb312:
  %t1296 = call i64 @std_2ftime_2eNow()
  store i64 %t1296, ptr %l656
  br label %bb313
bb313:
  %t1297 = load i64, ptr %l656, !tbaa !24
  store i64 %t1297, ptr %l77, !tbaa !24
  store i64 0, ptr %l78, !tbaa !24
  %t1298 = load i64, ptr %l3, !tbaa !24
  store i64 %t1298, ptr %l79, !tbaa !24
  store i64 1, ptr %l80, !tbaa !24
  %t1300 = load i64, ptr %l79, !tbaa !24
  %t1301 = load i64, ptr %l78, !tbaa !24
  %t1304 = icmp sgt i64 %t1300, %t1301
  br i1 %t1304, label %bb314, label %bb315
bb314:
  %t1306 = load i64, ptr %l80, !tbaa !24
  %t1308 = icmp sgt i64 %t1306, 0
  br i1 %t1308, label %bb316, label %bb317
bb315:
  store i64 0, ptr %l661, !tbaa !24
  br label %bb319
bb316:
  %t1310 = load i64, ptr %l79, !tbaa !24
  %t1311 = load i64, ptr %l78, !tbaa !24
  %t1314 = sub i64 %t1310, %t1311
  %t1315 = load i64, ptr %l80, !tbaa !24
  %t1318 = add i64 %t1314, %t1315
  %t1320 = sub i64 %t1318, 1
  %t1321 = load i64, ptr %l80, !tbaa !24
  %t1324 = sdiv i64 %t1320, %t1321
  store i64 %t1324, ptr %l664, !tbaa !24
  br label %bb318
bb317:
  store i64 0, ptr %l664, !tbaa !24
  br label %bb318
bb318:
  %t1326 = load i64, ptr %l664, !tbaa !24
  store i64 %t1326, ptr %l661, !tbaa !24
  br label %bb319
bb319:
  %t1327 = load i64, ptr %l661, !tbaa !24
  store i64 %t1327, ptr %l81, !tbaa !24
  store i64 0, ptr %l82, !tbaa !24
  br label %bb320
bb320:
  %t1328 = load i64, ptr %l82, !tbaa !24
  %t1329 = load i64, ptr %l81, !tbaa !24
  %t1332 = icmp slt i64 %t1328, %t1329
  %t1334 = xor i1 %t1332, true
  br i1 %t1334, label %bb321, label %bb322
bb321:
  br label %bb326
bb322:
  br label %bb323
bb323:
  %t1336 = load i64, ptr %l78, !tbaa !24
  %t1337 = load i64, ptr %l82, !tbaa !24
  %t1338 = load i64, ptr %l80, !tbaa !24
  %t1341 = mul i64 %t1337, %t1338
  %t1344 = add i64 %t1336, %t1341
  %t1346 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewalk(ptr %v0, ptr %t1346, i64 %t1344, i1 true)
  br label %bb324
bb324:
  br label %bb325
bb325:
  %t1350 = load i64, ptr %l82, !tbaa !24
  %t1352 = add i64 %t1350, 1
  store i64 %t1352, ptr %l82, !tbaa !24
  br label %bb320
bb326:
  %t1354 = call i64 @std_2ftime_2eNow()
  store i64 %t1354, ptr %l686
  br label %bb327
bb327:
  %t1355 = load i64, ptr %l686, !tbaa !24
  store i64 %t1355, ptr %l84, !tbaa !24
  %t1356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1356, ptr %l687, !tbaa !29
  %t1357 = load ptr, ptr %l0, !tbaa !29
  %t1359 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachedTasks(ptr %v0, ptr %t1357)
  store i1 %t1359, ptr %l689
  br label %bb328
bb328:
  %t1360 = load i1, ptr %l689, !tbaa !21
  %t1361 = load ptr, ptr %l687, !tbaa !29
  %t1362 = getelementptr %"compiler/free:Free", ptr %t1361, i32 0, i32 37
  store i1 %t1360, ptr %t1362, !tbaa !21
  %t1363 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edecide(ptr %v0, ptr %t1363)
  br label %bb329
bb329:
  %t1365 = load ptr, ptr %l0, !tbaa !29
  %t1367 = getelementptr %"compiler/free:Free", ptr %t1365, i32 0, i32 65
  store i1 true, ptr %t1367, !tbaa !21
  %t1368 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewritePlans(ptr %v0, ptr %t1368)
  br label %bb330
bb330:
  %t1370 = call i64 @std_2ftime_2eNow()
  store i64 %t1370, ptr %l693
  br label %bb331
bb331:
  %t1371 = load i64, ptr %l693, !tbaa !24
  store i64 %t1371, ptr %l85, !tbaa !24
  %t1372 = load ptr, ptr %l0, !tbaa !29
  %t1374 = getelementptr %"compiler/free:Free", ptr %t1372, i32 0, i32 66
  %t1375 = load i1, ptr %t1374, !tbaa !21
  br i1 %t1375, label %bb332, label %bb333
bb332:
  store %olang.scope zeroinitializer, ptr %s65
  %t1377 = load i64, ptr %l84, !tbaa !24
  %t1378 = load i64, ptr %l77, !tbaa !24
  %t1381 = sub i64 %t1377, %t1378
  %t1383 = sdiv i64 %t1381, 1000000
  store i64 %t1383, ptr %l699, !tbaa !24
  %t1384 = load ptr, ptr %l0, !tbaa !29
  %t1386 = getelementptr %"compiler/free:Free", ptr %t1384, i32 0, i32 43
  %t1388 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t1386)
  store i64 %t1388, ptr %l702
  br label %bb334
bb333:
  br label %bb342
bb334:
  %t1389 = load ptr, ptr %l0, !tbaa !29
  %t1391 = getelementptr %"compiler/free:Free", ptr %t1389, i32 0, i32 42
  %t1393 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t1391)
  store i64 %t1393, ptr %l705
  br label %bb335
bb335:
  %t1394 = load i64, ptr %l85, !tbaa !24
  %t1395 = load i64, ptr %l84, !tbaa !24
  %t1398 = sub i64 %t1394, %t1395
  %t1400 = sdiv i64 %t1398, 1000000
  %t1401 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t1402 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t1403 = load i64, ptr %l699, !tbaa !24
  %t1404 = call i64 @__olang_fmt_i64(ptr null, i64 %t1403)
  %t1405 = add i64 %t1402, %t1404
  %t1406 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t1407 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t1408 = add i64 %t1405, %t1407
  %t1409 = load i64, ptr %l702, !tbaa !24
  %t1410 = call i64 @__olang_fmt_i64(ptr null, i64 %t1409)
  %t1411 = add i64 %t1408, %t1410
  %t1412 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t1413 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t1414 = add i64 %t1411, %t1413
  %t1415 = load i64, ptr %l705, !tbaa !24
  %t1416 = call i64 @__olang_fmt_i64(ptr null, i64 %t1415)
  %t1417 = add i64 %t1414, %t1416
  %t1418 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t1419 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t1420 = add i64 %t1417, %t1419
  %t1422 = call i64 @__olang_fmt_i64(ptr null, i64 %t1400)
  %t1423 = add i64 %t1420, %t1422
  %t1424 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t1425 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t1426 = add i64 %t1423, %t1425
  %t1427 = call ptr @__olang_scope_alloc(ptr %s65, i64 %t1426)
  call void @olang_textcopy(ptr %t1427, ptr %t1401, i64 %t1402)
  %t1428 = getelementptr i8, ptr %t1427, i64 %t1402
  %t1429 = call i64 @__olang_fmt_i64(ptr %t1428, i64 %t1403)
  %t1430 = getelementptr i8, ptr %t1428, i64 %t1404
  call void @olang_textcopy(ptr %t1430, ptr %t1406, i64 %t1407)
  %t1431 = getelementptr i8, ptr %t1430, i64 %t1407
  %t1432 = call i64 @__olang_fmt_i64(ptr %t1431, i64 %t1409)
  %t1433 = getelementptr i8, ptr %t1431, i64 %t1410
  call void @olang_textcopy(ptr %t1433, ptr %t1412, i64 %t1413)
  %t1434 = getelementptr i8, ptr %t1433, i64 %t1413
  %t1435 = call i64 @__olang_fmt_i64(ptr %t1434, i64 %t1415)
  %t1436 = getelementptr i8, ptr %t1434, i64 %t1416
  call void @olang_textcopy(ptr %t1436, ptr %t1418, i64 %t1419)
  %t1437 = getelementptr i8, ptr %t1436, i64 %t1419
  %t1438 = call i64 @__olang_fmt_i64(ptr %t1437, i64 %t1400)
  %t1439 = getelementptr i8, ptr %t1437, i64 %t1422
  call void @olang_textcopy(ptr %t1439, ptr %t1424, i64 %t1425)
  %t1440 = insertvalue { i64, ptr } undef, i64 %t1426, 0
  %t1441 = insertvalue { i64, ptr } %t1440, ptr %t1427, 1
  %t1443 = extractvalue { i64, ptr } %t1441, 0
  %t1444 = extractvalue { i64, ptr } %t1441, 1
  %t1445 = mul i64 %t1443, 1
  %t1446 = call ptr @__olang_scope_alloc(ptr %s65, i64 %t1445)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1446, ptr %t1444, i64 %t1445, i1 false)
  %t1447 = insertvalue { i64, ptr } undef, i64 %t1443, 0
  %t1448 = insertvalue { i64, ptr } %t1447, ptr %t1446, 1
  %t1450 = call i32 @std_2fio_2ePrintErr(ptr %s65, { i64, ptr } %t1448)
  store i32 %t1450, ptr %l712
  %t1451 = icmp ne i32 %t1450, 0
  br i1 %t1451, label %bb337, label %ok.1452, !prof !99
ok.1452:
  br label %bb336
bb336:
  br label %bb341
bb337:
  %t1453 = load i32, ptr %l712, !tbaa !23
  %t1454 = ashr i32 %t1453, 16
  %t1456 = icmp eq i32 %t1454, 1
  store i1 %t1456, ptr %l714, !tbaa !21
  %t1457 = load i32, ptr %l712, !tbaa !23
  %t1458 = ashr i32 %t1457, 16
  %t1460 = icmp eq i32 %t1458, 1
  br i1 %t1460, label %bb338, label %bb339
bb338:
  call void @__olang_errpay_pop()
  br label %bb339
bb339:
  br label %bb340
bb340:
  br label %bb341
bb341:
  call void @__olang_scope_close(ptr %s65)
  br label %bb342
bb342:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFrees(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 65
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sge i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 21
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l11
  br label %bb6
bb5:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 21
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t24, i64 %t25)
  store i1 %t28, ptr %l17
  br label %bb10
bb9:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb11
bb10:
  %t29 = load i1, ptr %l17, !tbaa !21
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l13, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsHandle(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 10
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 10
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t18, i64 %t19)
  store i1 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l10, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSoleLocal(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l29 = alloca i64
  %l30 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 65
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, 0
  store i1 %t10, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l7, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb7
bb5:
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:Free", ptr %t14, i32 0, i32 61
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l14
  br label %bb6
bb6:
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = icmp sge i64 %t19, %t20
  store i1 %t21, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l10, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb11
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/free:Free", ptr %t24, i32 0, i32 61
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t26, i64 %t27)
  store i1 %t30, ptr %l20
  br label %bb10
bb10:
  %t31 = load i1, ptr %l20, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t34 = load i1, ptr %l16, !tbaa !21
  br i1 %t34, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 60
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t43 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t39, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t43, ptr %l28
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l28
  %t46 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t44, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t45)
  %t47 = extractvalue { i32, i64 } %t46, 1
  %t48 = extractvalue { i32, i64 } %t46, 0
  store i32 %t48, ptr %l30
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb17, label %ok.50, !prof !99
ok.50:
  store i64 %t47, ptr %l29
  br label %bb16
bb16:
  %t51 = load i64, ptr %l29, !tbaa !24
  store i64 %t51, ptr %l23, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  store i64 -1, ptr %l23, !tbaa !24
  br label %bb19
bb19:
  %t52 = load i64, ptr %l23, !tbaa !24
  store i64 %t52, ptr %l3, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l3, !tbaa !24
  %t57 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t53, i64 %t54)
  store i1 %t57, ptr %l33
  br label %bb20
bb20:
  %t58 = load i1, ptr %l33, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l34, !tbaa !24
  br label %bb23
bb22:
  store i64 -1, ptr %l34, !tbaa !24
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i64, ptr %l34, !tbaa !24
  store i64 %t61, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eentry(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i64
  %l19 = alloca i1
  %l23 = alloca i1
  %l26 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca ptr
  %l36 = alloca i1
  %l39 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l12, !tbaa !24
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1c505c1b55d06586_a0a7e4d6315dd1d2)
  unreachable
bb10:
  %t24 = load i64, ptr %l12, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb14
bb12:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 39
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t31, i64 %t32)
  store i1 %t35, ptr %l23
  br label %bb13
bb13:
  %t36 = load i1, ptr %l23, !tbaa !21
  store i1 %t36, ptr %l19, !tbaa !21
  br label %bb14
bb14:
  %t37 = load i1, ptr %l19, !tbaa !21
  br i1 %t37, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:Free", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l26, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/free:Free", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t46, i64 %t47)
  store i64 %t50, ptr %l30
  br label %bb18
bb18:
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t53, ptr %l31
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l31, !tbaa !29
  store ptr %t54, ptr %l5, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Func", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb22
bb21:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Func", ptr %t64, i32 0, i32 7
  %t67 = load i1, ptr %t66, !tbaa !21
  store i1 %t67, ptr %l36, !tbaa !21
  br label %bb22
bb22:
  %t69 = load i1, ptr %l36, !tbaa !21
  br i1 %t69, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb27
bb24:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:Free", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/load:Loader", ptr %t76, i32 0, i32 3
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t79, i32 %t83)
  store { i64, ptr } %t86, ptr %l46
  br label %bb25
bb25:
  %t87 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t87, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t88, ptr %l47
  br label %bb26
bb26:
  %t89 = load i1, ptr %l47, !tbaa !21
  store i1 %t89, ptr %l39, !tbaa !21
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t90 = load i1, ptr %l39, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %a0, ptr %t24)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l59 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownLocalCand(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  br label %bb8
bb8:
  br label %bb89
bb9:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t35 = load ptr, ptr %l27, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l27, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 17}
  %t41 = icmp eq i64 %t39, 0
  store i1 %t41, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l28, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  br label %bb15
bb15:
  br label %bb89
bb16:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb17, label %bb18
bb17:
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 17}
  %t60 = icmp eq i64 %t58, 2
  store i1 %t60, ptr %l36, !tbaa !21
  br label %bb18
bb18:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l5, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb22
bb22:
  br label %bb89
bb23:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t73 = load ptr, ptr %l43, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l43, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 17}
  %t79 = icmp eq i64 %t77, 3
  store i1 %t79, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t80 = load i1, ptr %l44, !tbaa !21
  br i1 %t80, label %bb26, label %bb27
bb26:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [3 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", ptr }, ptr %t83, i32 0, i32 1
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l6, !tbaa !29
  br label %bb28
bb27:
  br label %bb38
bb28:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = getelementptr %"compiler/typed:If", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t87, ptr %t91)
  br label %bb29
bb29:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t97 = getelementptr %"compiler/typed:If", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t94, ptr %t98)
  br label %bb30
bb30:
  %t101 = load ptr, ptr %l6, !tbaa !29
  %t103 = getelementptr %"compiler/typed:If", ptr %t101, i32 0, i32 2
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb31, label %bb32
bb31:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l59, !tbaa !29
  %t111 = load ptr, ptr %l6, !tbaa !29
  %t113 = getelementptr %"compiler/typed:If", ptr %t111, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  br i1 %t116, label %bb33, label %bb34
bb32:
  br label %bb37
bb33:
  call void @__olang_check_failed(ptr @olang_loc_f0ef9f3a8cd9f24a_5f2afb921a19c616)
  unreachable
bb34:
  br label %bb35
bb35:
  %t118 = load ptr, ptr %l6, !tbaa !29
  %t120 = getelementptr %"compiler/typed:If", ptr %t118, i32 0, i32 2
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load ptr, ptr %l59, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t122, ptr %t121)
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb89
bb38:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t125 = load ptr, ptr %l65, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb39, label %bb40
bb39:
  %t128 = load ptr, ptr %l65, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 17}
  %t131 = icmp eq i64 %t129, 4
  store i1 %t131, ptr %l66, !tbaa !21
  br label %bb40
bb40:
  %t132 = load i1, ptr %l66, !tbaa !21
  br i1 %t132, label %bb41, label %bb42
bb41:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t135, i32 0, i32 1
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l7, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [3 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l8, !tbaa !29
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  br label %bb44
bb44:
  %t149 = load ptr, ptr %l8, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb45, label %bb46
bb45:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t155, ptr %t156)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb89
bb49:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t160 = load ptr, ptr %l80, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb50, label %bb51
bb50:
  %t163 = load ptr, ptr %l80, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 17}
  %t166 = icmp eq i64 %t164, 6
  store i1 %t166, ptr %l81, !tbaa !21
  br label %bb51
bb51:
  %t167 = load i1, ptr %l81, !tbaa !21
  br i1 %t167, label %bb52, label %bb53
bb52:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr }, ptr %t170, i32 0, i32 1
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l9, !tbaa !29
  br label %bb58
bb53:
  %t174 = load ptr, ptr %l1, !tbaa !29
  store ptr %t174, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t175 = load ptr, ptr %l86, !tbaa !29
  %t176 = icmp ne ptr %t175, null
  br i1 %t176, label %bb54, label %bb55
bb54:
  %t178 = load ptr, ptr %l86, !tbaa !29
  %t179 = load i64, ptr %t178, !range !{i64 0, i64 17}
  %t181 = icmp eq i64 %t179, 16
  store i1 %t181, ptr %l87, !tbaa !21
  br label %bb55
bb55:
  %t182 = load i1, ptr %l87, !tbaa !21
  br i1 %t182, label %bb56, label %bb57
bb56:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr { i64, [3 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", ptr }, ptr %t185, i32 0, i32 1
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l9, !tbaa !29
  br label %bb58
bb57:
  br label %bb63
bb58:
  %t189 = load ptr, ptr %l9, !tbaa !29
  %t191 = icmp eq ptr %t189, null
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb59, label %bb60
bb59:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t195, ptr %t196)
  br label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb62
bb62:
  br label %bb89
bb63:
  %t199 = load ptr, ptr %l1, !tbaa !29
  store ptr %t199, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t200 = load ptr, ptr %l97, !tbaa !29
  %t201 = icmp ne ptr %t200, null
  br i1 %t201, label %bb64, label %bb65
bb64:
  %t203 = load ptr, ptr %l97, !tbaa !29
  %t204 = load i64, ptr %t203, !range !{i64 0, i64 17}
  %t206 = icmp eq i64 %t204, 11
  store i1 %t206, ptr %l98, !tbaa !21
  br label %bb65
bb65:
  %t207 = load i1, ptr %l98, !tbaa !21
  br i1 %t207, label %bb66, label %bb67
bb66:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr { i64, [3 x i64] }, ptr %t208, i32 0, i32 1
  %t211 = getelementptr { %"compiler/source:Span", ptr }, ptr %t210, i32 0, i32 1
  %t212 = load ptr, ptr %t211
  store ptr %t212, ptr %l10, !tbaa !29
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t214, ptr %t215)
  br label %bb69
bb69:
  br label %bb89
bb70:
  %t218 = load ptr, ptr %l1, !tbaa !29
  store ptr %t218, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t219 = load ptr, ptr %l105, !tbaa !29
  %t220 = icmp ne ptr %t219, null
  br i1 %t220, label %bb71, label %bb72
bb71:
  %t222 = load ptr, ptr %l105, !tbaa !29
  %t223 = load i64, ptr %t222, !range !{i64 0, i64 17}
  %t225 = icmp eq i64 %t223, 12
  store i1 %t225, ptr %l106, !tbaa !21
  br label %bb72
bb72:
  %t226 = load i1, ptr %l106, !tbaa !21
  br i1 %t226, label %bb73, label %bb74
bb73:
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr { i64, [3 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", ptr }, ptr %t229, i32 0, i32 1
  %t231 = load ptr, ptr %t230
  store ptr %t231, ptr %l11, !tbaa !29
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t233, ptr %t234)
  br label %bb76
bb76:
  br label %bb89
bb77:
  %t237 = load ptr, ptr %l1, !tbaa !29
  store ptr %t237, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t238 = load ptr, ptr %l113, !tbaa !29
  %t239 = icmp ne ptr %t238, null
  br i1 %t239, label %bb78, label %bb79
bb78:
  %t241 = load ptr, ptr %l113, !tbaa !29
  %t242 = load i64, ptr %t241, !range !{i64 0, i64 17}
  %t244 = icmp eq i64 %t242, 13
  store i1 %t244, ptr %l114, !tbaa !21
  br label %bb79
bb79:
  %t245 = load i1, ptr %l114, !tbaa !21
  br i1 %t245, label %bb80, label %bb81
bb80:
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr { i64, [3 x i64] }, ptr %t246, i32 0, i32 1
  %t249 = getelementptr { %"compiler/source:Span", ptr }, ptr %t248, i32 0, i32 1
  %t250 = load ptr, ptr %t249
  store ptr %t250, ptr %l12, !tbaa !29
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load ptr, ptr %l12, !tbaa !29
  %t255 = getelementptr %"compiler/typed:Join", ptr %t253, i32 0, i32 0
  %t256 = load ptr, ptr %t255, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t252, ptr %t256)
  br label %bb83
bb83:
  br label %bb89
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_1befe4f0760966d8_ea99a8b72a88b024)
  unreachable
bb89:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %lp4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l33 = alloca i1
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca i32
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i32
  %l55 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i32
  %l75 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca { i64, ptr }
  %l85 = alloca i64
  %l88 = alloca i64
  %l109 = alloca i64
  %l112 = alloca i1
  %l116 = alloca i1
  %l117 = alloca i1
  %l121 = alloca i1
  %l124 = alloca i64
  %l126 = alloca { i64, ptr }
  %l129 = alloca i1
  %l131 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l136 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l138 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l140 = alloca i64
  %l145 = alloca ptr
  %l148 = alloca i32
  %l149 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l161 = alloca i1
  %l163 = alloca ptr
  %l166 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l168 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l170 = alloca i64
  %l175 = alloca i1
  %l178 = alloca ptr
  %l181 = alloca i32
  %l182 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l194 = alloca i1
  %l196 = alloca ptr
  %l199 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l201 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l203 = alloca i64
  %l207 = alloca ptr
  %l208 = alloca i32
  %l209 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l211 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l24
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l24, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l25, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l28
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l25, !tbaa !29
  %t12 = load i32, ptr %l28, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l29
  br label %bb3
bb3:
  %t14 = load i32, ptr %l29, !tbaa !23
  store i32 %t14, ptr %l3, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/free:Free", ptr %t15, i32 0, i32 19
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H0fa35282e56bd0cd9b08251ba99b9868(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l33
  br label %bb4
bb4:
  %t22 = load i1, ptr %l33, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:Free", ptr %t23, i32 0, i32 19
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H08f3244764437e29647226f03a29c83b(ptr %v0, ptr %v1, ptr %t25, i32 %t26)
  %t30 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t29, 1
  %t31 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t29, 0
  store i32 %t31, ptr %l39
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb8, label %ok.33, !prof !99
ok.33:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l38
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v1, ptr %l38)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l41
  br label %bb10
bb8:
  br label %bb9
bb9:
  %t36 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l42
  br label %bb11
bb10:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l34
  br label %bb12
bb11:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l34
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %rv
  br label %ret
bb13:
  %t40 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l43
  br label %bb14
bb14:
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t41, ptr %lp4
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  %t43 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %t43
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/free:Free", ptr %t44, i32 0, i32 19
  store ptr %t46, ptr %l45, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  store i32 %t47, ptr %l46, !tbaa !23
  %t48 = load ptr, ptr %lp4
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l47
  %t51 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l49
  br label %bb15
bb15:
  %t52 = load ptr, ptr %l45, !tbaa !29
  %t53 = load i32, ptr %l46, !tbaa !23
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H127fb385441fbfd25cd8404c6b268b5d(ptr %v0, ptr %s0, ptr %t52, i32 %t53, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54)
  br label %bb16
bb16:
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t56 = load i32, ptr %l3, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l52
  br label %bb17
bb17:
  %t60 = load i32, ptr %l52, !range !{i32 0, i32 33}
  store i32 %t60, ptr %l5
  %t61 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t63 = trunc i64 19 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb18, label %bb19
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l55, !tbaa !29
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l58
  br label %bb20
bb19:
  %t72 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t74 = trunc i64 18 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb23, label %bb24
bb20:
  %t77 = load ptr, ptr %l55, !tbaa !29
  %t78 = load i32, ptr %l58, !tbaa !23
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v1, ptr %t77, i32 %t78)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l59
  br label %bb21
bb21:
  %t81 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v1, ptr %l59)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81, ptr %l61
  br label %bb22
bb22:
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61
  %t83 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %t83
  br label %bb108
bb23:
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t85 = load i32, ptr %l3, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l67
  br label %bb25
bb24:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb26
bb25:
  %t89 = load i1, ptr %l67, !tbaa !21
  store i1 %t89, ptr %l64, !tbaa !21
  br label %bb26
bb26:
  %t90 = load i1, ptr %l64, !tbaa !21
  br i1 %t90, label %bb27, label %bb28
bb27:
  %t91 = load ptr, ptr %l2, !tbaa !29
  store ptr %t91, ptr %l68, !tbaa !29
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l71
  br label %bb29
bb28:
  %t97 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t99 = trunc i64 23 to i32
  %t100 = icmp eq i32 %t97, %t99
  br i1 %t100, label %bb86, label %bb87
bb29:
  %t102 = load ptr, ptr %l68, !tbaa !29
  %t103 = load i32, ptr %l71, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t104, ptr %l72
  br label %bb30
bb30:
  %t105 = load i32, ptr %l72, !range !{i32 0, i32 6}
  store i32 %t105, ptr %l6
  %t106 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t108 = trunc i64 0 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb31, label %bb32
bb31:
  %t111 = load ptr, ptr %l2, !tbaa !29
  store ptr %t111, ptr %l75, !tbaa !29
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t113 = load i32, ptr %l3, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l78
  br label %bb33
bb32:
  %t117 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t119 = trunc i64 1 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb67, label %bb68
bb33:
  %t122 = load ptr, ptr %l75, !tbaa !29
  %t123 = load i32, ptr %l78, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t122, i32 %t123)
  store { i64, ptr } %t124, ptr %l79
  br label %bb34
bb34:
  %t125 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t125, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t130 = load i64, ptr %l9, !tbaa !24
  %t131 = load i64, ptr %l8, !tbaa !24
  %t134 = icmp sgt i64 %t130, %t131
  br i1 %t134, label %bb35, label %bb36
bb35:
  %t136 = load i64, ptr %l10, !tbaa !24
  %t138 = icmp sgt i64 %t136, 0
  br i1 %t138, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb40
bb37:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t141 = load i64, ptr %l8, !tbaa !24
  %t144 = sub i64 %t140, %t141
  %t145 = load i64, ptr %l10, !tbaa !24
  %t148 = add i64 %t144, %t145
  %t150 = sub i64 %t148, 1
  %t151 = load i64, ptr %l10, !tbaa !24
  %t154 = sdiv i64 %t150, %t151
  store i64 %t154, ptr %l88, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb39
bb39:
  %t156 = load i64, ptr %l88, !tbaa !24
  store i64 %t156, ptr %l85, !tbaa !24
  br label %bb40
bb40:
  %t157 = load i64, ptr %l85, !tbaa !24
  store i64 %t157, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb41
bb41:
  %t158 = load i64, ptr %l12, !tbaa !24
  %t159 = load i64, ptr %l11, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb42, label %bb43
bb42:
  br label %bb66
bb43:
  br label %bb44
bb44:
  %t166 = load i64, ptr %l8, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t168 = load i64, ptr %l10, !tbaa !24
  %t171 = mul i64 %t167, %t168
  %t174 = add i64 %t166, %t171
  store i64 %t174, ptr %l13, !tbaa !24
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l3, !tbaa !23
  %t178 = load i64, ptr %l13, !tbaa !24
  %t182 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t176, i32 %t177, i64 %t178)
  store i64 %t182, ptr %l109
  br label %bb45
bb45:
  %t183 = load i64, ptr %l109, !tbaa !24
  store i64 %t183, ptr %l14, !tbaa !24
  %t184 = load i64, ptr %l14, !tbaa !24
  %t186 = icmp sge i64 %t184, 0
  br i1 %t186, label %bb46, label %bb47
bb46:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/free:Free", ptr %t188, i32 0, i32 11
  %t191 = load i64, ptr %l14, !tbaa !24
  %t194 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t190, i64 %t191)
  store i1 %t194, ptr %l116
  br label %bb48
bb47:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb53
bb48:
  %t195 = load i1, ptr %l116, !tbaa !21
  br i1 %t195, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb52
bb50:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/free:Free", ptr %t196, i32 0, i32 12
  %t199 = load i64, ptr %l14, !tbaa !24
  %t202 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t198, i64 %t199)
  store i1 %t202, ptr %l121
  br label %bb51
bb51:
  %t203 = load i1, ptr %l121, !tbaa !21
  store i1 %t203, ptr %l117, !tbaa !21
  br label %bb52
bb52:
  %t204 = load i1, ptr %l117, !tbaa !21
  store i1 %t204, ptr %l112, !tbaa !21
  br label %bb53
bb53:
  %t205 = load i1, ptr %l112, !tbaa !21
  br i1 %t205, label %bb54, label %bb55
bb54:
  %t206 = load ptr, ptr %lp4
  %t207 = load i64, ptr %l14, !tbaa !24
  %t210 = call i64 @compiler_2ffree_2eaddTo(ptr %v1, ptr %t206, i64 %t207)
  store i64 %t210, ptr %l124
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  %t211 = load ptr, ptr %l2, !tbaa !29
  %t212 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t212, ptr %l126, !tbaa !27
  %t213 = load i64, ptr %l13, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr i32, ptr %t216, i64 %t213
  %t218 = load i32, ptr %t217, !tbaa !33
  %t221 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t211, i32 %t218)
  store i1 %t221, ptr %l129
  br label %bb58
bb58:
  %t222 = load i1, ptr %l129, !tbaa !21
  %t223 = xor i1 %t222, true
  br i1 %t223, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s9
  %t225 = load ptr, ptr %lp4
  store ptr %t225, ptr %l131, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t227, ptr %l133, !tbaa !27
  %t228 = load i64, ptr %l13, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i32, ptr %t231, i64 %t228
  %t233 = load i32, ptr %t232, !tbaa !33
  %t236 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v0, ptr %t226, i32 %t233)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t236, ptr %l136
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t238 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %l136)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t238, ptr %l138
  br label %bb62
bb62:
  %t239 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l138
  %t240 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %t240
  %t241 = load ptr, ptr %l131, !tbaa !29
  %t243 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v1, ptr %v0, ptr %t241, ptr %t240)
  store i64 %t243, ptr %l140
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t244 = load i64, ptr %l12, !tbaa !24
  %t246 = add i64 %t244, 1
  store i64 %t246, ptr %l12, !tbaa !24
  br label %bb41
bb66:
  br label %bb85
bb67:
  %t248 = load ptr, ptr %l2, !tbaa !29
  store ptr %t248, ptr %l145, !tbaa !29
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t250 = load i32, ptr %l3, !tbaa !23
  %t253 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t249, i32 %t250)
  store i32 %t253, ptr %l148
  br label %bb69
bb68:
  br label %bb84
bb69:
  %t254 = load ptr, ptr %l145, !tbaa !29
  %t255 = load i32, ptr %l148, !tbaa !23
  %t256 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t254, i32 %t255)
  store { i64, ptr } %t256, ptr %l149
  br label %bb70
bb70:
  %t257 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t257, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t258 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 0
  store i64 %t260, ptr %l17, !tbaa !24
  br label %bb71
bb71:
  %t262 = load i64, ptr %l16, !tbaa !24
  %t263 = load i64, ptr %l17, !tbaa !24
  %t266 = icmp slt i64 %t262, %t263
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb72, label %bb73
bb72:
  br label %bb83
bb73:
  br label %bb74
bb74:
  %t270 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t270, ptr %l156, !tbaa !27
  %t271 = load i64, ptr %l16, !tbaa !24
  %t273 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = getelementptr i32, ptr %t274, i64 %t271
  %t276 = load i32, ptr %t275, !tbaa !33
  store i32 %t276, ptr %l18, !tbaa !23
  %t278 = load ptr, ptr %l2, !tbaa !29
  %t279 = load i32, ptr %l18, !tbaa !23
  %t282 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t278, i32 %t279)
  store i1 %t282, ptr %l161
  br label %bb75
bb75:
  %t283 = load i1, ptr %l161, !tbaa !21
  %t284 = xor i1 %t283, true
  br i1 %t284, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s15
  %t286 = load ptr, ptr %lp4
  store ptr %t286, ptr %l163, !tbaa !29
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load i32, ptr %l18, !tbaa !23
  %t291 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v0, ptr %t287, i32 %t288)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t291, ptr %l166
  br label %bb78
bb77:
  br label %bb81
bb78:
  %t293 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %l166)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t293, ptr %l168
  br label %bb79
bb79:
  %t294 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l168
  %t295 = call ptr @__olang_scope_alloc_a(ptr %s15, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t294, ptr %t295
  %t296 = load ptr, ptr %l163, !tbaa !29
  %t298 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v1, ptr %v0, ptr %t296, ptr %t295)
  store i64 %t298, ptr %l170
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s15)
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t299 = load i64, ptr %l16, !tbaa !24
  %t301 = add i64 %t299, 1
  store i64 %t301, ptr %l16, !tbaa !24
  br label %bb71
bb83:
  br label %bb84
bb84:
  br label %bb85
bb85:
  br label %bb107
bb86:
  store i1 true, ptr %l175, !tbaa !21
  br label %bb88
bb87:
  %t303 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t305 = trunc i64 22 to i32
  %t306 = icmp eq i32 %t303, %t305
  store i1 %t306, ptr %l175, !tbaa !21
  br label %bb88
bb88:
  %t308 = load i1, ptr %l175, !tbaa !21
  br i1 %t308, label %bb89, label %bb90
bb89:
  %t309 = load ptr, ptr %l2, !tbaa !29
  store ptr %t309, ptr %l178, !tbaa !29
  %t310 = load ptr, ptr %l2, !tbaa !29
  %t311 = load i32, ptr %l3, !tbaa !23
  %t314 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t310, i32 %t311)
  store i32 %t314, ptr %l181
  br label %bb91
bb90:
  br label %bb106
bb91:
  %t315 = load ptr, ptr %l178, !tbaa !29
  %t316 = load i32, ptr %l181, !tbaa !23
  %t317 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t315, i32 %t316)
  store { i64, ptr } %t317, ptr %l182
  br label %bb92
bb92:
  %t318 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } %t318, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t319 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t319, 0
  store i64 %t321, ptr %l21, !tbaa !24
  br label %bb93
bb93:
  %t323 = load i64, ptr %l20, !tbaa !24
  %t324 = load i64, ptr %l21, !tbaa !24
  %t327 = icmp slt i64 %t323, %t324
  %t329 = xor i1 %t327, true
  br i1 %t329, label %bb94, label %bb95
bb94:
  br label %bb105
bb95:
  br label %bb96
bb96:
  %t331 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t331, ptr %l189, !tbaa !27
  %t332 = load i64, ptr %l20, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr i32, ptr %t335, i64 %t332
  %t337 = load i32, ptr %t336, !tbaa !33
  store i32 %t337, ptr %l22, !tbaa !23
  %t339 = load ptr, ptr %l2, !tbaa !29
  %t340 = load i32, ptr %l22, !tbaa !23
  %t343 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t339, i32 %t340)
  store i1 %t343, ptr %l194
  br label %bb97
bb97:
  %t344 = load i1, ptr %l194, !tbaa !21
  %t345 = xor i1 %t344, true
  br i1 %t345, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s21
  %t347 = load ptr, ptr %lp4
  store ptr %t347, ptr %l196, !tbaa !29
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i32, ptr %l22, !tbaa !23
  %t352 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v0, ptr %t348, i32 %t349)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t352, ptr %l199
  br label %bb100
bb99:
  br label %bb103
bb100:
  %t354 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %l199)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t354, ptr %l201
  br label %bb101
bb101:
  %t355 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l201
  %t356 = call ptr @__olang_scope_alloc_a(ptr %s21, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t355, ptr %t356
  %t357 = load ptr, ptr %l196, !tbaa !29
  %t359 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v1, ptr %v0, ptr %t357, ptr %t356)
  store i64 %t359, ptr %l203
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s21)
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t360 = load i64, ptr %l20, !tbaa !24
  %t362 = add i64 %t360, 1
  store i64 %t362, ptr %l20, !tbaa !24
  br label %bb93
bb105:
  br label %bb106
bb106:
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/free:Free", ptr %t364, i32 0, i32 19
  store ptr %t366, ptr %l207, !tbaa !29
  %t367 = load i32, ptr %l3, !tbaa !23
  store i32 %t367, ptr %l208, !tbaa !23
  %t368 = load ptr, ptr %lp4
  %t369 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t368
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t369, ptr %l209
  %t371 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l209)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t371, ptr %l211
  br label %bb109
bb109:
  %t372 = load ptr, ptr %l207, !tbaa !29
  %t373 = load i32, ptr %l208, !tbaa !23
  %t374 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l211
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H127fb385441fbfd25cd8404c6b268b5d(ptr %v0, ptr %s0, ptr %t372, i32 %t373, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t374)
  br label %bb110
bb110:
  %t375 = load ptr, ptr %lp4
  %t376 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t375
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t376, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisContents(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/free:letGo"
  %l8 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i64
  %l19 = alloca %"compiler/free:letGo"
  %l23 = alloca i1
  %l27 = alloca i1
  %l31 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 45
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load i1, ptr %l8, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/free:Free", ptr %t10, i32 0, i32 43
  store ptr %t12, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t14 = load i64, ptr %l3, !tbaa !24
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = icmp slt i64 %t18, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %bb22
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t24, i64 %t25)
  store %"compiler/free:letGo" %t28, ptr %l19
  br label %bb10
bb10:
  %t29 = load %"compiler/free:letGo", ptr %l19
  store %"compiler/free:letGo" %t29, ptr %l4
  %t30 = getelementptr %"compiler/free:letGo", ptr %l4, i32 0, i32 0
  %t31 = load i64, ptr %t30, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp eq i64 %t31, %t32
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t37 = getelementptr %"compiler/free:letGo", ptr %l4, i32 0, i32 5
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load i64, ptr @G_2ecompiler_2ffree_2eLVacate, !tbaa !24
  %t42 = icmp eq i64 %t38, %t39
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/free:Free", ptr %t45, i32 0, i32 22
  %t48 = getelementptr %"compiler/free:letGo", ptr %l4, i32 0, i32 1
  %t49 = load i64, ptr %t48, !tbaa !24
  %t52 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t47, i64 %t49)
  store i1 %t52, ptr %l31
  br label %bb16
bb15:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb17
bb16:
  %t53 = load i1, ptr %l31, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t56 = load i1, ptr %l27, !tbaa !21
  br i1 %t56, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l3, !tbaa !24
  br label %bb5
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l75 = alloca i1
  %l76 = alloca i1
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l95 = alloca { i64, ptr }
  %l100 = alloca i1
  %l108 = alloca i1
  %l109 = alloca ptr
  %l115 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i1
  %l130 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l134 = alloca i1
  %l141 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i1
  %l164 = alloca i1
  %l166 = alloca i1
  %l170 = alloca ptr
  %l174 = alloca i1
  %l178 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i1
  %l184 = alloca ptr
  %l185 = alloca i1
  %l197 = alloca { i64, ptr }
  %l202 = alloca i1
  %l207 = alloca ptr
  %l208 = alloca i1
  %l220 = alloca { i64, ptr }
  %l225 = alloca i1
  %l230 = alloca ptr
  %l231 = alloca i1
  %l238 = alloca i1
  %l239 = alloca ptr
  %l240 = alloca i1
  %l248 = alloca i1
  %l249 = alloca i1
  %l254 = alloca i1
  %l255 = alloca ptr
  %l261 = alloca i1
  %l262 = alloca i1
  %l266 = alloca i1
  %l267 = alloca ptr
  %l268 = alloca i1
  %l277 = alloca i1
  %l278 = alloca ptr
  %l284 = alloca i1
  %l294 = alloca { i64, ptr }
  %l310 = alloca { i64, ptr }
  %l315 = alloca i1
  %l322 = alloca ptr
  %l323 = alloca i1
  %l328 = alloca i1
  %l329 = alloca ptr
  %l330 = alloca i1
  %l333 = alloca ptr
  %l334 = alloca i1
  %l343 = alloca i1
  %l344 = alloca ptr
  %l345 = alloca i1
  %l353 = alloca i1
  %l359 = alloca i1
  %l360 = alloca ptr
  %l366 = alloca i1
  %l367 = alloca ptr
  %l368 = alloca i1
  %l377 = alloca i1
  %l378 = alloca ptr
  %l384 = alloca i1
  %l390 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t2 = load ptr, ptr %l43, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l43, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l44, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l44, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t11 = load ptr, ptr %l47, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l47, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l48, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l48, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t20 = load ptr, ptr %l51, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l51, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 2
  store i1 %t26, ptr %l52, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l52, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t29 = load ptr, ptr %l55, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load ptr, ptr %l55, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 3
  store i1 %t35, ptr %l56, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l56, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t39 = load ptr, ptr %l60, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb19, label %bb20
bb19:
  %t42 = load ptr, ptr %l60, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 4
  store i1 %t45, ptr %l61, !tbaa !21
  br label %bb20
bb20:
  %t46 = load i1, ptr %l61, !tbaa !21
  br i1 %t46, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %rv
  br label %ret
bb24:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t49 = load ptr, ptr %l65, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb25, label %bb26
bb25:
  %t52 = load ptr, ptr %l65, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 5
  store i1 %t55, ptr %l66, !tbaa !21
  br label %bb26
bb26:
  %t56 = load i1, ptr %l66, !tbaa !21
  br i1 %t56, label %bb27, label %bb28
bb27:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l2, !tbaa !23
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l3, !tbaa !29
  br label %bb29
bb28:
  br label %bb35
bb29:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t73, ptr %l75
  br label %bb30
bb30:
  %t74 = load i1, ptr %l75, !tbaa !21
  br i1 %t74, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb34
bb32:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Promote", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t82 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t75, ptr %t79)
  store i1 %t82, ptr %l80
  br label %bb33
bb33:
  %t83 = load i1, ptr %l80, !tbaa !21
  store i1 %t83, ptr %l76, !tbaa !21
  br label %bb34
bb34:
  %t84 = load i1, ptr %l76, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb35:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t86 = load ptr, ptr %l81, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb36, label %bb37
bb36:
  %t89 = load ptr, ptr %l81, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 7
  store i1 %t92, ptr %l82, !tbaa !21
  br label %bb37
bb37:
  %t93 = load i1, ptr %l82, !tbaa !21
  br i1 %t93, label %bb38, label %bb39
bb38:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb58
bb40:
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Make", ptr %t100, i32 0, i32 2
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %l7, !tbaa !24
  br label %bb41
bb41:
  %t109 = load i64, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb42, label %bb43
bb42:
  br label %bb50
bb43:
  br label %bb44
bb44:
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t117, ptr %l95, !tbaa !27
  %t118 = load i64, ptr %l6, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr ptr, ptr %t121, i64 %t118
  %t123 = load ptr, ptr %t122, !tbaa !39
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t129 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t125, ptr %t123)
  store i1 %t129, ptr %l100
  br label %bb45
bb45:
  %t130 = load i1, ptr %l100, !tbaa !21
  br i1 %t130, label %bb46, label %bb47
bb46:
  store i1 true, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t132 = load i64, ptr %l6, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l6, !tbaa !24
  br label %bb41
bb50:
  %t136 = load ptr, ptr %l4, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Make", ptr %t136, i32 0, i32 3
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb51, label %bb52
bb51:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l109, !tbaa !29
  %t146 = load ptr, ptr %l4, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Make", ptr %t146, i32 0, i32 3
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  br i1 %t151, label %bb53, label %bb54
bb52:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb57
bb53:
  call void @__olang_check_failed(ptr @olang_loc_ec4c329f8a2f93df_8cb0fdf9b7b252db)
  unreachable
bb54:
  br label %bb55
bb55:
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Make", ptr %t153, i32 0, i32 3
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t157 = load ptr, ptr %l109, !tbaa !29
  %t159 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t157, ptr %t156)
  store i1 %t159, ptr %l115
  br label %bb56
bb56:
  %t160 = load i1, ptr %l115, !tbaa !21
  store i1 %t160, ptr %l108, !tbaa !21
  br label %bb57
bb57:
  %t161 = load i1, ptr %l108, !tbaa !21
  store i1 %t161, ptr %rv
  br label %ret
bb58:
  %t162 = load ptr, ptr %l1, !tbaa !29
  store ptr %t162, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t163 = load ptr, ptr %l116, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb59, label %bb60
bb59:
  %t166 = load ptr, ptr %l116, !tbaa !29
  %t167 = load i64, ptr %t166, !range !{i64 0, i64 18}
  %t169 = icmp eq i64 %t167, 16
  store i1 %t169, ptr %l117, !tbaa !21
  br label %bb60
bb60:
  %t170 = load i1, ptr %l117, !tbaa !21
  br i1 %t170, label %bb61, label %bb62
bb61:
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t173, i32 0, i32 2
  %t175 = load ptr, ptr %t174
  store ptr %t175, ptr %l9, !tbaa !29
  br label %bb63
bb62:
  br label %bb85
bb63:
  %t177 = load ptr, ptr %l9, !tbaa !29
  %t179 = getelementptr %"compiler/typed:Text", ptr %t177, i32 0, i32 0
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  store { i64, ptr } %t180, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t182, 0
  store i64 %t184, ptr %l12, !tbaa !24
  br label %bb64
bb64:
  %t186 = load i64, ptr %l11, !tbaa !24
  %t187 = load i64, ptr %l12, !tbaa !24
  %t190 = icmp slt i64 %t186, %t187
  %t192 = xor i1 %t190, true
  br i1 %t192, label %bb65, label %bb66
bb65:
  br label %bb84
bb66:
  br label %bb67
bb67:
  %t194 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t194, ptr %l130, !tbaa !27
  %t195 = load i64, ptr %l11, !tbaa !24
  %t197 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr ptr, ptr %t198, i64 %t195
  %t200 = load ptr, ptr %t199, !tbaa !39
  store ptr %t200, ptr %l13, !tbaa !29
  %t202 = load ptr, ptr %l13, !tbaa !29
  store ptr %t202, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t203 = load ptr, ptr %l133, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb68, label %bb69
bb68:
  %t206 = load ptr, ptr %l133, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 2}
  %t209 = icmp eq i64 %t207, 1
  store i1 %t209, ptr %l134, !tbaa !21
  br label %bb69
bb69:
  %t210 = load i1, ptr %l134, !tbaa !21
  br i1 %t210, label %bb70, label %bb71
bb70:
  %t211 = load ptr, ptr %l13, !tbaa !29
  %t213 = getelementptr { i64, [2 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { ptr }, ptr %t213, i32 0, i32 0
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l14, !tbaa !29
  br label %bb72
bb71:
  br label %bb77
bb72:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load ptr, ptr %l14, !tbaa !29
  %t221 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t217, ptr %t218)
  store i1 %t221, ptr %l141
  br label %bb73
bb73:
  %t222 = load i1, ptr %l141, !tbaa !21
  br i1 %t222, label %bb74, label %bb75
bb74:
  store i1 true, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  br label %bb82
bb77:
  br i1 true, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_285dc0af82d31c87_50e1bc6ae6554e83)
  unreachable
bb82:
  br label %bb83
bb83:
  %t224 = load i64, ptr %l11, !tbaa !24
  %t226 = add i64 %t224, 1
  store i64 %t226, ptr %l11, !tbaa !24
  br label %bb64
bb84:
  store i1 false, ptr %rv
  br label %ret
bb85:
  %t229 = load ptr, ptr %l1, !tbaa !29
  store ptr %t229, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t230 = load ptr, ptr %l146, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb86, label %bb87
bb86:
  %t233 = load ptr, ptr %l146, !tbaa !29
  %t234 = load i64, ptr %t233, !range !{i64 0, i64 18}
  %t236 = icmp eq i64 %t234, 6
  store i1 %t236, ptr %l147, !tbaa !21
  br label %bb87
bb87:
  %t237 = load i1, ptr %l147, !tbaa !21
  br i1 %t237, label %bb88, label %bb89
bb88:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t240, i32 0, i32 2
  %t242 = load ptr, ptr %t241
  store ptr %t242, ptr %l15, !tbaa !29
  br label %bb90
bb89:
  br label %bb134
bb90:
  %t244 = load ptr, ptr %l15, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Call", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  store ptr %t247, ptr %l16, !tbaa !29
  %t249 = load ptr, ptr %l16, !tbaa !29
  store ptr %t249, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t250 = load ptr, ptr %l154, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb91, label %bb92
bb91:
  %t253 = load ptr, ptr %l154, !tbaa !29
  %t254 = load i64, ptr %t253, !range !{i64 0, i64 5}
  %t256 = icmp eq i64 %t254, 0
  store i1 %t256, ptr %l155, !tbaa !21
  br label %bb92
bb92:
  %t257 = load i1, ptr %l155, !tbaa !21
  br i1 %t257, label %bb93, label %bb94
bb93:
  %t258 = load ptr, ptr %l16, !tbaa !29
  %t260 = getelementptr { i64, [3 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { i32 }, ptr %t260, i32 0, i32 0
  %t262 = load i32, ptr %t261
  store i32 %t262, ptr %l17, !tbaa !23
  br label %bb95
bb94:
  br label %bb108
bb95:
  %t264 = load i32, ptr %l17, !tbaa !23
  %t266 = sext i32 %t264 to i64
  store i64 %t266, ptr %l18, !tbaa !24
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load i64, ptr %l18, !tbaa !24
  %t272 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %t268, i64 %t269)
  store i1 %t272, ptr %l164
  br label %bb96
bb96:
  %t273 = load i1, ptr %l164, !tbaa !21
  %t274 = xor i1 %t273, true
  br i1 %t274, label %bb97, label %bb98
bb97:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/free:Free", ptr %t276, i32 0, i32 1
  %t279 = load i64, ptr %l18, !tbaa !24
  %t282 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t278, i64 %t279)
  store ptr %t282, ptr %l170
  br label %bb99
bb98:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb104
bb99:
  %t283 = load ptr, ptr %l170, !tbaa !29
  %t285 = getelementptr %"compiler/typed:Body", ptr %t283, i32 0, i32 11
  %t286 = load ptr, ptr %t285, !tbaa !29
  %t288 = icmp eq ptr %t286, null
  br i1 %t288, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l174, !tbaa !21
  br label %bb103
bb101:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/free:Free", ptr %t290, i32 0, i32 34
  %t293 = load i64, ptr %l18, !tbaa !24
  %t296 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t292, i64 %t293)
  store i1 %t296, ptr %l178
  br label %bb102
bb102:
  %t297 = load i1, ptr %l178, !tbaa !21
  store i1 %t297, ptr %l174, !tbaa !21
  br label %bb103
bb103:
  %t298 = load i1, ptr %l174, !tbaa !21
  store i1 %t298, ptr %l166, !tbaa !21
  br label %bb104
bb104:
  %t299 = load i1, ptr %l166, !tbaa !21
  br i1 %t299, label %bb105, label %bb106
bb105:
  store i1 true, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  br label %bb123
bb108:
  %t301 = load ptr, ptr %l16, !tbaa !29
  store ptr %t301, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t302 = load ptr, ptr %l180, !tbaa !29
  %t303 = icmp ne ptr %t302, null
  br i1 %t303, label %bb109, label %bb110
bb109:
  %t305 = load ptr, ptr %l180, !tbaa !29
  %t306 = load i64, ptr %t305, !range !{i64 0, i64 5}
  %t308 = icmp eq i64 %t306, 4
  store i1 %t308, ptr %l181, !tbaa !21
  br label %bb110
bb110:
  %t309 = load i1, ptr %l181, !tbaa !21
  br i1 %t309, label %bb111, label %bb112
bb111:
  br label %bb117
bb112:
  %t310 = load ptr, ptr %l16, !tbaa !29
  store ptr %t310, ptr %l184, !tbaa !29
  store i1 false, ptr %l185, !tbaa !21
  %t311 = load ptr, ptr %l184, !tbaa !29
  %t312 = icmp ne ptr %t311, null
  br i1 %t312, label %bb113, label %bb114
bb113:
  %t314 = load ptr, ptr %l184, !tbaa !29
  %t315 = load i64, ptr %t314, !range !{i64 0, i64 5}
  %t317 = icmp eq i64 %t315, 1
  store i1 %t317, ptr %l185, !tbaa !21
  br label %bb114
bb114:
  %t318 = load i1, ptr %l185, !tbaa !21
  br i1 %t318, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb123
bb118:
  br i1 true, label %bb119, label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb122
bb121:
  store i1 true, ptr %rv
  br label %ret
bb122:
  call void @__olang_check_failed(ptr @olang_loc_f9703b3e8b4d3f8c_114f0f1572d2eea8)
  unreachable
bb123:
  %t320 = load ptr, ptr %l15, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Call", ptr %t320, i32 0, i32 1
  %t323 = load { i64, ptr }, ptr %t322, !tbaa !27
  store { i64, ptr } %t323, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t325 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t325, 0
  store i64 %t327, ptr %l21, !tbaa !24
  br label %bb124
bb124:
  %t329 = load i64, ptr %l20, !tbaa !24
  %t330 = load i64, ptr %l21, !tbaa !24
  %t333 = icmp slt i64 %t329, %t330
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb125, label %bb126
bb125:
  br label %bb133
bb126:
  br label %bb127
bb127:
  %t337 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t337, ptr %l197, !tbaa !27
  %t338 = load i64, ptr %l20, !tbaa !24
  %t340 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr ptr, ptr %t341, i64 %t338
  %t343 = load ptr, ptr %t342, !tbaa !39
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t349 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t345, ptr %t343)
  store i1 %t349, ptr %l202
  br label %bb128
bb128:
  %t350 = load i1, ptr %l202, !tbaa !21
  br i1 %t350, label %bb129, label %bb130
bb129:
  store i1 true, ptr %rv
  br label %ret
bb130:
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t352 = load i64, ptr %l20, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l20, !tbaa !24
  br label %bb124
bb133:
  store i1 false, ptr %rv
  br label %ret
bb134:
  %t357 = load ptr, ptr %l1, !tbaa !29
  store ptr %t357, ptr %l207, !tbaa !29
  store i1 false, ptr %l208, !tbaa !21
  %t358 = load ptr, ptr %l207, !tbaa !29
  %t359 = icmp ne ptr %t358, null
  br i1 %t359, label %bb135, label %bb136
bb135:
  %t361 = load ptr, ptr %l207, !tbaa !29
  %t362 = load i64, ptr %t361, !range !{i64 0, i64 18}
  %t364 = icmp eq i64 %t362, 9
  store i1 %t364, ptr %l208, !tbaa !21
  br label %bb136
bb136:
  %t365 = load i1, ptr %l208, !tbaa !21
  br i1 %t365, label %bb137, label %bb138
bb137:
  %t366 = load ptr, ptr %l1, !tbaa !29
  %t368 = getelementptr { i64, [5 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t368, i32 0, i32 4
  %t370 = load { i64, ptr }, ptr %t369
  store { i64, ptr } %t370, ptr %l23, !tbaa !27
  br label %bb139
bb138:
  br label %bb150
bb139:
  %t372 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t372, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t374 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t374, 0
  store i64 %t376, ptr %l26, !tbaa !24
  br label %bb140
bb140:
  %t378 = load i64, ptr %l25, !tbaa !24
  %t379 = load i64, ptr %l26, !tbaa !24
  %t382 = icmp slt i64 %t378, %t379
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb141, label %bb142
bb141:
  br label %bb149
bb142:
  br label %bb143
bb143:
  %t386 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t386, ptr %l220, !tbaa !27
  %t387 = load i64, ptr %l25, !tbaa !24
  %t389 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr ptr, ptr %t390, i64 %t387
  %t392 = load ptr, ptr %t391, !tbaa !39
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t398 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t394, ptr %t392)
  store i1 %t398, ptr %l225
  br label %bb144
bb144:
  %t399 = load i1, ptr %l225, !tbaa !21
  br i1 %t399, label %bb145, label %bb146
bb145:
  store i1 true, ptr %rv
  br label %ret
bb146:
  br label %bb147
bb147:
  br label %bb148
bb148:
  %t401 = load i64, ptr %l25, !tbaa !24
  %t403 = add i64 %t401, 1
  store i64 %t403, ptr %l25, !tbaa !24
  br label %bb140
bb149:
  store i1 false, ptr %rv
  br label %ret
bb150:
  %t406 = load ptr, ptr %l1, !tbaa !29
  store ptr %t406, ptr %l230, !tbaa !29
  store i1 false, ptr %l231, !tbaa !21
  %t407 = load ptr, ptr %l230, !tbaa !29
  %t408 = icmp ne ptr %t407, null
  br i1 %t408, label %bb151, label %bb152
bb151:
  %t410 = load ptr, ptr %l230, !tbaa !29
  %t411 = load i64, ptr %t410, !range !{i64 0, i64 18}
  %t413 = icmp eq i64 %t411, 17
  store i1 %t413, ptr %l231, !tbaa !21
  br label %bb152
bb152:
  %t414 = load i1, ptr %l231, !tbaa !21
  br i1 %t414, label %bb153, label %bb154
bb153:
  %t415 = load ptr, ptr %l1, !tbaa !29
  %t417 = getelementptr { i64, [5 x i64] }, ptr %t415, i32 0, i32 1
  %t418 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t417, i32 0, i32 2
  %t419 = load ptr, ptr %t418
  store ptr %t419, ptr %l28, !tbaa !29
  br label %bb155
bb154:
  br label %bb157
bb155:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load ptr, ptr %l28, !tbaa !29
  %t425 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t421, ptr %t422)
  store i1 %t425, ptr %l238
  br label %bb156
bb156:
  %t426 = load i1, ptr %l238, !tbaa !21
  store i1 %t426, ptr %rv
  br label %ret
bb157:
  %t427 = load ptr, ptr %l1, !tbaa !29
  store ptr %t427, ptr %l239, !tbaa !29
  store i1 false, ptr %l240, !tbaa !21
  %t428 = load ptr, ptr %l239, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb158, label %bb159
bb158:
  %t431 = load ptr, ptr %l239, !tbaa !29
  %t432 = load i64, ptr %t431, !range !{i64 0, i64 18}
  %t434 = icmp eq i64 %t432, 11
  store i1 %t434, ptr %l240, !tbaa !21
  br label %bb159
bb159:
  %t435 = load i1, ptr %l240, !tbaa !21
  br i1 %t435, label %bb160, label %bb161
bb160:
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t438 = getelementptr { i64, [5 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t438, i32 0, i32 2
  %t440 = load ptr, ptr %t439
  store ptr %t440, ptr %l29, !tbaa !29
  br label %bb162
bb161:
  br label %bb178
bb162:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load ptr, ptr %l29, !tbaa !29
  %t445 = getelementptr %"compiler/typed:Cond", ptr %t443, i32 0, i32 0
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t449 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t442, ptr %t446)
  store i1 %t449, ptr %l248
  br label %bb163
bb163:
  %t450 = load i1, ptr %l248, !tbaa !21
  br i1 %t450, label %bb164, label %bb165
bb164:
  store i1 true, ptr %l249, !tbaa !21
  br label %bb173
bb165:
  %t451 = load ptr, ptr %l29, !tbaa !29
  %t453 = getelementptr %"compiler/typed:Cond", ptr %t451, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !29
  %t456 = icmp eq ptr %t454, null
  %t458 = xor i1 %t456, true
  br i1 %t458, label %bb166, label %bb167
bb166:
  %t460 = load ptr, ptr %l0, !tbaa !29
  store ptr %t460, ptr %l255, !tbaa !29
  %t461 = load ptr, ptr %l29, !tbaa !29
  %t463 = getelementptr %"compiler/typed:Cond", ptr %t461, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !29
  %t466 = icmp eq ptr %t464, null
  br i1 %t466, label %bb168, label %bb169
bb167:
  store i1 false, ptr %l254, !tbaa !21
  br label %bb172
bb168:
  call void @__olang_check_failed(ptr @olang_loc_c329a7357b4632ae_1972f4ce8b92321a)
  unreachable
bb169:
  br label %bb170
bb170:
  %t468 = load ptr, ptr %l29, !tbaa !29
  %t470 = getelementptr %"compiler/typed:Cond", ptr %t468, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !29
  %t472 = load ptr, ptr %l255, !tbaa !29
  %t474 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t472, ptr %t471)
  store i1 %t474, ptr %l261
  br label %bb171
bb171:
  %t475 = load i1, ptr %l261, !tbaa !21
  store i1 %t475, ptr %l254, !tbaa !21
  br label %bb172
bb172:
  %t476 = load i1, ptr %l254, !tbaa !21
  store i1 %t476, ptr %l249, !tbaa !21
  br label %bb173
bb173:
  %t477 = load i1, ptr %l249, !tbaa !21
  br i1 %t477, label %bb174, label %bb175
bb174:
  store i1 true, ptr %l262, !tbaa !21
  br label %bb177
bb175:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load ptr, ptr %l29, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Cond", ptr %t479, i32 0, i32 2
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t485 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t478, ptr %t482)
  store i1 %t485, ptr %l266
  br label %bb176
bb176:
  %t486 = load i1, ptr %l266, !tbaa !21
  store i1 %t486, ptr %l262, !tbaa !21
  br label %bb177
bb177:
  %t487 = load i1, ptr %l262, !tbaa !21
  store i1 %t487, ptr %rv
  br label %ret
bb178:
  %t488 = load ptr, ptr %l1, !tbaa !29
  store ptr %t488, ptr %l267, !tbaa !29
  store i1 false, ptr %l268, !tbaa !21
  %t489 = load ptr, ptr %l267, !tbaa !29
  %t490 = icmp ne ptr %t489, null
  br i1 %t490, label %bb179, label %bb180
bb179:
  %t492 = load ptr, ptr %l267, !tbaa !29
  %t493 = load i64, ptr %t492, !range !{i64 0, i64 18}
  %t495 = icmp eq i64 %t493, 14
  store i1 %t495, ptr %l268, !tbaa !21
  br label %bb180
bb180:
  %t496 = load i1, ptr %l268, !tbaa !21
  br i1 %t496, label %bb181, label %bb182
bb181:
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t499 = getelementptr { i64, [5 x i64] }, ptr %t497, i32 0, i32 1
  %t500 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t499, i32 0, i32 2
  %t501 = load ptr, ptr %t500
  store ptr %t501, ptr %l30, !tbaa !29
  br label %bb183
bb182:
  br label %bb213
bb183:
  %t503 = load ptr, ptr %l30, !tbaa !29
  %t505 = getelementptr %"compiler/typed:Try", ptr %t503, i32 0, i32 0
  %t506 = load ptr, ptr %t505, !tbaa !29
  %t508 = icmp eq ptr %t506, null
  %t510 = xor i1 %t508, true
  br i1 %t510, label %bb184, label %bb185
bb184:
  %t512 = load ptr, ptr %l0, !tbaa !29
  store ptr %t512, ptr %l278, !tbaa !29
  %t513 = load ptr, ptr %l30, !tbaa !29
  %t515 = getelementptr %"compiler/typed:Try", ptr %t513, i32 0, i32 0
  %t516 = load ptr, ptr %t515, !tbaa !29
  %t518 = icmp eq ptr %t516, null
  br i1 %t518, label %bb186, label %bb187
bb185:
  store i1 false, ptr %l277, !tbaa !21
  br label %bb190
bb186:
  call void @__olang_check_failed(ptr @olang_loc_ce4a56608212b1d3_28564c72fb26107)
  unreachable
bb187:
  br label %bb188
bb188:
  %t520 = load ptr, ptr %l30, !tbaa !29
  %t522 = getelementptr %"compiler/typed:Try", ptr %t520, i32 0, i32 0
  %t523 = load ptr, ptr %t522, !tbaa !29
  %t524 = load ptr, ptr %l278, !tbaa !29
  %t526 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t524, ptr %t523)
  store i1 %t526, ptr %l284
  br label %bb189
bb189:
  %t527 = load i1, ptr %l284, !tbaa !21
  store i1 %t527, ptr %l277, !tbaa !21
  br label %bb190
bb190:
  %t528 = load i1, ptr %l277, !tbaa !21
  br i1 %t528, label %bb191, label %bb192
bb191:
  store i1 true, ptr %rv
  br label %ret
bb192:
  br label %bb193
bb193:
  %t530 = load ptr, ptr %l30, !tbaa !29
  %t532 = getelementptr %"compiler/typed:Try", ptr %t530, i32 0, i32 1
  %t533 = load { i64, ptr }, ptr %t532, !tbaa !27
  store { i64, ptr } %t533, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t535 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t537 = extractvalue { i64, ptr } %t535, 0
  store i64 %t537, ptr %l33, !tbaa !24
  br label %bb194
bb194:
  %t539 = load i64, ptr %l32, !tbaa !24
  %t540 = load i64, ptr %l33, !tbaa !24
  %t543 = icmp slt i64 %t539, %t540
  %t545 = xor i1 %t543, true
  br i1 %t545, label %bb195, label %bb196
bb195:
  br label %bb212
bb196:
  br label %bb197
bb197:
  %t547 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t547, ptr %l294, !tbaa !27
  %t548 = load i64, ptr %l32, !tbaa !24
  %t550 = getelementptr { i64, ptr }, ptr %l294, i32 0, i32 1
  %t551 = load ptr, ptr %t550, !tbaa !27
  %t552 = getelementptr ptr, ptr %t551, i64 %t548
  %t553 = load ptr, ptr %t552, !tbaa !39
  store ptr %t553, ptr %l34, !tbaa !29
  %t555 = load ptr, ptr %l34, !tbaa !29
  %t557 = getelementptr %"compiler/typed:Clause", ptr %t555, i32 0, i32 3
  %t558 = load ptr, ptr %t557, !tbaa !29
  %t560 = icmp eq ptr %t558, null
  %t562 = xor i1 %t560, true
  br i1 %t562, label %bb198, label %bb199
bb198:
  store i1 true, ptr %rv
  br label %ret
bb199:
  br label %bb200
bb200:
  %t565 = load ptr, ptr %l34, !tbaa !29
  %t567 = getelementptr %"compiler/typed:Clause", ptr %t565, i32 0, i32 4
  %t568 = load { i64, ptr }, ptr %t567, !tbaa !27
  store { i64, ptr } %t568, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t570 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t572 = extractvalue { i64, ptr } %t570, 0
  store i64 %t572, ptr %l37, !tbaa !24
  br label %bb201
bb201:
  %t574 = load i64, ptr %l36, !tbaa !24
  %t575 = load i64, ptr %l37, !tbaa !24
  %t578 = icmp slt i64 %t574, %t575
  %t580 = xor i1 %t578, true
  br i1 %t580, label %bb202, label %bb203
bb202:
  br label %bb210
bb203:
  br label %bb204
bb204:
  %t582 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t582, ptr %l310, !tbaa !27
  %t583 = load i64, ptr %l36, !tbaa !24
  %t585 = getelementptr { i64, ptr }, ptr %l310, i32 0, i32 1
  %t586 = load ptr, ptr %t585, !tbaa !27
  %t587 = getelementptr ptr, ptr %t586, i64 %t583
  %t588 = load ptr, ptr %t587, !tbaa !39
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t594 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t590, ptr %t588)
  store i1 %t594, ptr %l315
  br label %bb205
bb205:
  %t595 = load i1, ptr %l315, !tbaa !21
  br i1 %t595, label %bb206, label %bb207
bb206:
  store i1 true, ptr %rv
  br label %ret
bb207:
  br label %bb208
bb208:
  br label %bb209
bb209:
  %t597 = load i64, ptr %l36, !tbaa !24
  %t599 = add i64 %t597, 1
  store i64 %t599, ptr %l36, !tbaa !24
  br label %bb201
bb210:
  br label %bb211
bb211:
  %t601 = load i64, ptr %l32, !tbaa !24
  %t603 = add i64 %t601, 1
  store i64 %t603, ptr %l32, !tbaa !24
  br label %bb194
bb212:
  store i1 false, ptr %rv
  br label %ret
bb213:
  %t606 = load ptr, ptr %l1, !tbaa !29
  store ptr %t606, ptr %l322, !tbaa !29
  store i1 false, ptr %l323, !tbaa !21
  %t607 = load ptr, ptr %l322, !tbaa !29
  %t608 = icmp ne ptr %t607, null
  br i1 %t608, label %bb214, label %bb215
bb214:
  %t610 = load ptr, ptr %l322, !tbaa !29
  %t611 = load i64, ptr %t610, !range !{i64 0, i64 18}
  %t613 = icmp eq i64 %t611, 15
  store i1 %t613, ptr %l323, !tbaa !21
  br label %bb215
bb215:
  %t614 = load i1, ptr %l323, !tbaa !21
  br i1 %t614, label %bb216, label %bb217
bb216:
  %t615 = load ptr, ptr %l1, !tbaa !29
  %t617 = getelementptr { i64, [5 x i64] }, ptr %t615, i32 0, i32 1
  %t618 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t617, i32 0, i32 2
  %t619 = load ptr, ptr %t618
  store ptr %t619, ptr %l39, !tbaa !29
  br label %bb218
bb217:
  br label %bb237
bb218:
  %t621 = load ptr, ptr %l39, !tbaa !29
  store ptr %t621, ptr %l329, !tbaa !29
  store i1 false, ptr %l330, !tbaa !21
  %t622 = load ptr, ptr %l329, !tbaa !29
  %t623 = icmp ne ptr %t622, null
  br i1 %t623, label %bb219, label %bb220
bb219:
  %t625 = load ptr, ptr %l329, !tbaa !29
  %t626 = load i64, ptr %t625, !range !{i64 0, i64 3}
  %t628 = icmp eq i64 %t626, 0
  store i1 %t628, ptr %l330, !tbaa !21
  br label %bb220
bb220:
  %t629 = load i1, ptr %l330, !tbaa !21
  br i1 %t629, label %bb221, label %bb222
bb221:
  br label %bb223
bb222:
  br label %bb224
bb223:
  store i1 false, ptr %l328, !tbaa !21
  br label %bb236
bb224:
  %t630 = load ptr, ptr %l39, !tbaa !29
  store ptr %t630, ptr %l333, !tbaa !29
  store i1 false, ptr %l334, !tbaa !21
  %t631 = load ptr, ptr %l333, !tbaa !29
  %t632 = icmp ne ptr %t631, null
  br i1 %t632, label %bb225, label %bb226
bb225:
  %t634 = load ptr, ptr %l333, !tbaa !29
  %t635 = load i64, ptr %t634, !range !{i64 0, i64 3}
  %t637 = icmp eq i64 %t635, 1
  store i1 %t637, ptr %l334, !tbaa !21
  br label %bb226
bb226:
  %t638 = load i1, ptr %l334, !tbaa !21
  br i1 %t638, label %bb227, label %bb228
bb227:
  %t639 = load ptr, ptr %l39, !tbaa !29
  %t641 = getelementptr { i64, [4 x i64] }, ptr %t639, i32 0, i32 1
  %t642 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t641, i32 0, i32 0
  %t643 = load i32, ptr %t642
  store i32 %t643, ptr %l40, !tbaa !23
  br label %bb229
bb228:
  br label %bb231
bb229:
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t647 = getelementptr %"compiler/free:Free", ptr %t645, i32 0, i32 34
  %t648 = load i32, ptr %l40, !tbaa !23
  %t650 = sext i32 %t648 to i64
  %t653 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t647, i64 %t650)
  store i1 %t653, ptr %l343
  br label %bb230
bb230:
  %t654 = load i1, ptr %l343, !tbaa !21
  store i1 %t654, ptr %l328, !tbaa !21
  br label %bb236
bb231:
  br i1 true, label %bb232, label %bb233
bb232:
  br label %bb234
bb233:
  br label %bb235
bb234:
  store i1 true, ptr %l328, !tbaa !21
  br label %bb236
bb235:
  call void @__olang_check_failed(ptr @olang_loc_8c3ff88e405c7c2b_15d3403d537d031f)
  unreachable
bb236:
  %t655 = load i1, ptr %l328, !tbaa !21
  store i1 %t655, ptr %rv
  br label %ret
bb237:
  %t656 = load ptr, ptr %l1, !tbaa !29
  store ptr %t656, ptr %l344, !tbaa !29
  store i1 false, ptr %l345, !tbaa !21
  %t657 = load ptr, ptr %l344, !tbaa !29
  %t658 = icmp ne ptr %t657, null
  br i1 %t658, label %bb238, label %bb239
bb238:
  %t660 = load ptr, ptr %l344, !tbaa !29
  %t661 = load i64, ptr %t660, !range !{i64 0, i64 18}
  %t663 = icmp eq i64 %t661, 12
  store i1 %t663, ptr %l345, !tbaa !21
  br label %bb239
bb239:
  %t664 = load i1, ptr %l345, !tbaa !21
  br i1 %t664, label %bb240, label %bb241
bb240:
  %t665 = load ptr, ptr %l1, !tbaa !29
  %t667 = getelementptr { i64, [5 x i64] }, ptr %t665, i32 0, i32 1
  %t668 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t667, i32 0, i32 2
  %t669 = load ptr, ptr %t668
  store ptr %t669, ptr %l41, !tbaa !29
  br label %bb242
bb241:
  br label %bb254
bb242:
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t672 = load ptr, ptr %l41, !tbaa !29
  %t674 = getelementptr %"compiler/typed:Seq", ptr %t672, i32 0, i32 0
  %t675 = load { i64, ptr }, ptr %t674, !tbaa !27
  %t678 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t671, { i64, ptr } %t675)
  store i1 %t678, ptr %l353
  br label %bb243
bb243:
  %t679 = load i1, ptr %l353, !tbaa !21
  br i1 %t679, label %bb244, label %bb245
bb244:
  store i1 true, ptr %rv
  br label %ret
bb245:
  br label %bb246
bb246:
  %t681 = load ptr, ptr %l41, !tbaa !29
  %t683 = getelementptr %"compiler/typed:Seq", ptr %t681, i32 0, i32 1
  %t684 = load ptr, ptr %t683, !tbaa !29
  %t686 = icmp eq ptr %t684, null
  %t688 = xor i1 %t686, true
  br i1 %t688, label %bb247, label %bb248
bb247:
  %t690 = load ptr, ptr %l0, !tbaa !29
  store ptr %t690, ptr %l360, !tbaa !29
  %t691 = load ptr, ptr %l41, !tbaa !29
  %t693 = getelementptr %"compiler/typed:Seq", ptr %t691, i32 0, i32 1
  %t694 = load ptr, ptr %t693, !tbaa !29
  %t696 = icmp eq ptr %t694, null
  br i1 %t696, label %bb249, label %bb250
bb248:
  store i1 false, ptr %l359, !tbaa !21
  br label %bb253
bb249:
  call void @__olang_check_failed(ptr @olang_loc_637aed21ecd584b9_ebc4f5a84b828bd)
  unreachable
bb250:
  br label %bb251
bb251:
  %t698 = load ptr, ptr %l41, !tbaa !29
  %t700 = getelementptr %"compiler/typed:Seq", ptr %t698, i32 0, i32 1
  %t701 = load ptr, ptr %t700, !tbaa !29
  %t702 = load ptr, ptr %l360, !tbaa !29
  %t704 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t702, ptr %t701)
  store i1 %t704, ptr %l366
  br label %bb252
bb252:
  %t705 = load i1, ptr %l366, !tbaa !21
  store i1 %t705, ptr %l359, !tbaa !21
  br label %bb253
bb253:
  %t706 = load i1, ptr %l359, !tbaa !21
  store i1 %t706, ptr %rv
  br label %ret
bb254:
  %t707 = load ptr, ptr %l1, !tbaa !29
  store ptr %t707, ptr %l367, !tbaa !29
  store i1 false, ptr %l368, !tbaa !21
  %t708 = load ptr, ptr %l367, !tbaa !29
  %t709 = icmp ne ptr %t708, null
  br i1 %t709, label %bb255, label %bb256
bb255:
  %t711 = load ptr, ptr %l367, !tbaa !29
  %t712 = load i64, ptr %t711, !range !{i64 0, i64 18}
  %t714 = icmp eq i64 %t712, 8
  store i1 %t714, ptr %l368, !tbaa !21
  br label %bb256
bb256:
  %t715 = load i1, ptr %l368, !tbaa !21
  br i1 %t715, label %bb257, label %bb258
bb257:
  %t716 = load ptr, ptr %l1, !tbaa !29
  %t718 = getelementptr { i64, [5 x i64] }, ptr %t716, i32 0, i32 1
  %t719 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t718, i32 0, i32 2
  %t720 = load ptr, ptr %t719
  store ptr %t720, ptr %l42, !tbaa !29
  br label %bb259
bb258:
  br label %bb271
bb259:
  %t722 = load ptr, ptr %l42, !tbaa !29
  %t724 = getelementptr %"compiler/typed:Collect", ptr %t722, i32 0, i32 0
  %t725 = load ptr, ptr %t724, !tbaa !29
  %t727 = icmp eq ptr %t725, null
  %t729 = xor i1 %t727, true
  br i1 %t729, label %bb260, label %bb261
bb260:
  %t731 = load ptr, ptr %l0, !tbaa !29
  store ptr %t731, ptr %l378, !tbaa !29
  %t732 = load ptr, ptr %l42, !tbaa !29
  %t734 = getelementptr %"compiler/typed:Collect", ptr %t732, i32 0, i32 0
  %t735 = load ptr, ptr %t734, !tbaa !29
  %t737 = icmp eq ptr %t735, null
  br i1 %t737, label %bb262, label %bb263
bb261:
  store i1 false, ptr %l377, !tbaa !21
  br label %bb266
bb262:
  call void @__olang_check_failed(ptr @olang_loc_683418f7a5c8092_d6a8437e0252bcd6)
  unreachable
bb263:
  br label %bb264
bb264:
  %t739 = load ptr, ptr %l42, !tbaa !29
  %t741 = getelementptr %"compiler/typed:Collect", ptr %t739, i32 0, i32 0
  %t742 = load ptr, ptr %t741, !tbaa !29
  %t743 = load ptr, ptr %l378, !tbaa !29
  %t745 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t743, ptr %t742)
  store i1 %t745, ptr %l384
  br label %bb265
bb265:
  %t746 = load i1, ptr %l384, !tbaa !21
  store i1 %t746, ptr %l377, !tbaa !21
  br label %bb266
bb266:
  %t747 = load i1, ptr %l377, !tbaa !21
  br i1 %t747, label %bb267, label %bb268
bb267:
  store i1 true, ptr %rv
  br label %ret
bb268:
  br label %bb269
bb269:
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t750 = load ptr, ptr %l42, !tbaa !29
  %t752 = getelementptr %"compiler/typed:Collect", ptr %t750, i32 0, i32 1
  %t753 = load ptr, ptr %t752, !tbaa !29
  %t755 = getelementptr %"compiler/typed:Block", ptr %t753, i32 0, i32 1
  %t756 = load { i64, ptr }, ptr %t755, !tbaa !27
  %t759 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t749, { i64, ptr } %t756)
  store i1 %t759, ptr %l390
  br label %bb270
bb270:
  %t760 = load i1, ptr %l390, !tbaa !21
  store i1 %t760, ptr %rv
  br label %ret
bb271:
  br i1 true, label %bb272, label %bb273
bb272:
  br label %bb274
bb273:
  br label %bb275
bb274:
  store i1 true, ptr %rv
  br label %ret
bb275:
  call void @__olang_check_failed(ptr @olang_loc_edaf755937fbeeee_2c55fc89855df6da)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2emustOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l49 = alloca ptr
  %l55 = alloca %"compiler/free:mustW"
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l94 = alloca i64
  %l98 = alloca i64
  %l101 = alloca i64
  %l120 = alloca ptr
  %l124 = alloca i32
  %l128 = alloca ptr
  %l132 = alloca i32
  %l137 = alloca ptr
  %l145 = alloca i64
  %l149 = alloca i64
  %l152 = alloca i64
  %l173 = alloca i64
  %l176 = alloca i1
  %l179 = alloca i1
  %l183 = alloca i64
  %l184 = alloca ptr
  %l188 = alloca ptr
  %l189 = alloca i64
  %l190 = alloca i64
  %l191 = alloca i64
  %l195 = alloca i64
  %l204 = alloca i64
  %l206 = alloca ptr
  %l208 = alloca ptr
  %l212 = alloca ptr
  %l213 = alloca i64
  %l214 = alloca i64
  %l215 = alloca i64
  %l219 = alloca i64
  %l232 = alloca ptr
  %l236 = alloca i64
  %l238 = alloca i64
  %l243 = alloca i64
  %l251 = alloca i64
  %l253 = alloca i64
  %l258 = alloca ptr
  %l259 = alloca i64
  %l262 = alloca i64
  %l263 = alloca i64
  %l266 = alloca i1
  %l270 = alloca i64
  %l274 = alloca i64
  %l281 = alloca i1
  %l285 = alloca i1
  %l287 = alloca i1
  %l291 = alloca i1
  %l299 = alloca ptr
  %l303 = alloca i64
  %l305 = alloca i64
  %l310 = alloca i64
  %l318 = alloca ptr
  %l322 = alloca i64
  %l326 = alloca i64
  %l329 = alloca i64
  %l347 = alloca ptr
  %l350 = alloca i1
  %t18 = alloca %"compiler/free:mustW", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l49
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l49, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_3amustW_2ector(ptr %t18, ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  call void @llvm.memmove.p0.p0.i64(ptr %l55, ptr %t18, i64 176, i1 false)
  br label %bb5
bb5:
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 176, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %l55, i64 176, i1 false)
  store ptr %t21, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Body", ptr %t23, i32 0, i32 7
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l59
  br label %bb6
bb6:
  %t28 = load i64, ptr %l59, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb12
bb9:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l66, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l66, !tbaa !24
  store i64 %t55, ptr %l63, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l63, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  br label %bb20
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l9, !tbaa !24
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/free:mustW", ptr %t75, i32 0, i32 2
  %t78 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t77, i64 %t78)
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t83 = getelementptr %"compiler/free:mustW", ptr %t81, i32 0, i32 3
  %t84 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t83, i64 %t84)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t87 = load i64, ptr %l8, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l8, !tbaa !24
  br label %bb13
bb20:
  store i64 0, ptr %l10, !tbaa !24
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Body", ptr %t91, i32 0, i32 5
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l94
  br label %bb21
bb21:
  %t96 = load i64, ptr %l94, !tbaa !24
  store i64 %t96, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t97 = load i64, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb22, label %bb23
bb22:
  %t103 = load i64, ptr %l12, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb27
bb24:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l12, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l101, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb26
bb26:
  %t123 = load i64, ptr %l101, !tbaa !24
  store i64 %t123, ptr %l98, !tbaa !24
  br label %bb27
bb27:
  %t124 = load i64, ptr %l98, !tbaa !24
  store i64 %t124, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb28
bb28:
  %t125 = load i64, ptr %l14, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb29, label %bb30
bb29:
  br label %bb37
bb30:
  br label %bb31
bb31:
  %t133 = load i64, ptr %l10, !tbaa !24
  %t134 = load i64, ptr %l14, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l15, !tbaa !24
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t145 = getelementptr %"compiler/free:mustW", ptr %t143, i32 0, i32 2
  store ptr %t145, ptr %l120, !tbaa !29
  %t146 = load ptr, ptr %l2, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Body", ptr %t146, i32 0, i32 5
  %t149 = load i64, ptr %l15, !tbaa !24
  %t152 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t148, i64 %t149)
  store i32 %t152, ptr %l124
  br label %bb32
bb32:
  %t153 = load i32, ptr %l124, !tbaa !23
  %t154 = sext i32 %t153 to i64
  %t155 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  %t156 = load ptr, ptr %l120, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t156, i64 %t154, i64 %t155)
  br label %bb33
bb33:
  %t159 = load ptr, ptr %l3, !tbaa !29
  %t161 = getelementptr %"compiler/free:mustW", ptr %t159, i32 0, i32 3
  store ptr %t161, ptr %l128, !tbaa !29
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Body", ptr %t162, i32 0, i32 5
  %t165 = load i64, ptr %l15, !tbaa !24
  %t168 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t164, i64 %t165)
  store i32 %t168, ptr %l132
  br label %bb34
bb34:
  %t169 = load i32, ptr %l132, !tbaa !23
  %t170 = sext i32 %t169 to i64
  %t171 = load i64, ptr %l15, !tbaa !24
  %t172 = load ptr, ptr %l128, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t172, i64 %t170, i64 %t171)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t175 = load i64, ptr %l14, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l14, !tbaa !24
  br label %bb28
bb37:
  %t179 = load ptr, ptr %l3, !tbaa !29
  store ptr %t179, ptr %l137, !tbaa !29
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Body", ptr %t180, i32 0, i32 11
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_1d9a56a827ed845f_5cc839dbc781b743)
  unreachable
bb39:
  br label %bb40
bb40:
  %t187 = load ptr, ptr %l2, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Body", ptr %t187, i32 0, i32 11
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t191 = load ptr, ptr %l137, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v0, ptr %t191, ptr %t190)
  br label %bb41
bb41:
  br label %bb42
bb42:
  store i1 false, ptr %l16, !tbaa !21
  store i64 0, ptr %l17, !tbaa !24
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t195 = getelementptr %"compiler/free:mustW", ptr %t193, i32 0, i32 4
  %t197 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t195)
  store i64 %t197, ptr %l145
  br label %bb43
bb43:
  %t198 = load i64, ptr %l145, !tbaa !24
  store i64 %t198, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t199 = load i64, ptr %l18, !tbaa !24
  %t200 = load i64, ptr %l17, !tbaa !24
  %t203 = icmp sgt i64 %t199, %t200
  br i1 %t203, label %bb44, label %bb45
bb44:
  %t205 = load i64, ptr %l19, !tbaa !24
  %t207 = icmp sgt i64 %t205, 0
  br i1 %t207, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb49
bb46:
  %t209 = load i64, ptr %l18, !tbaa !24
  %t210 = load i64, ptr %l17, !tbaa !24
  %t213 = sub i64 %t209, %t210
  %t214 = load i64, ptr %l19, !tbaa !24
  %t217 = add i64 %t213, %t214
  %t219 = sub i64 %t217, 1
  %t220 = load i64, ptr %l19, !tbaa !24
  %t223 = sdiv i64 %t219, %t220
  store i64 %t223, ptr %l152, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb48
bb48:
  %t225 = load i64, ptr %l152, !tbaa !24
  store i64 %t225, ptr %l149, !tbaa !24
  br label %bb49
bb49:
  %t226 = load i64, ptr %l149, !tbaa !24
  store i64 %t226, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb50
bb50:
  %t227 = load i64, ptr %l21, !tbaa !24
  %t228 = load i64, ptr %l20, !tbaa !24
  %t231 = icmp slt i64 %t227, %t228
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb51, label %bb52
bb51:
  br label %bb81
bb52:
  br label %bb53
bb53:
  %t235 = load i64, ptr %l17, !tbaa !24
  %t236 = load i64, ptr %l21, !tbaa !24
  %t237 = load i64, ptr %l19, !tbaa !24
  %t240 = mul i64 %t236, %t237
  %t243 = add i64 %t235, %t240
  store i64 %t243, ptr %l22, !tbaa !24
  %t245 = load ptr, ptr %l3, !tbaa !29
  %t247 = getelementptr %"compiler/free:mustW", ptr %t245, i32 0, i32 4
  %t248 = load i64, ptr %l22, !tbaa !24
  %t251 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t247, i64 %t248)
  store i64 %t251, ptr %l173
  br label %bb54
bb54:
  %t252 = load i64, ptr %l173, !tbaa !24
  store i64 %t252, ptr %l23, !tbaa !24
  %t253 = load i64, ptr %l23, !tbaa !24
  %t255 = icmp slt i64 %t253, 0
  br i1 %t255, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l176, !tbaa !21
  br label %bb58
bb56:
  %t257 = load ptr, ptr %l3, !tbaa !29
  %t258 = load i64, ptr %l23, !tbaa !24
  %t261 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %t257, i64 %t258)
  store i1 %t261, ptr %l179
  br label %bb57
bb57:
  %t262 = load i1, ptr %l179, !tbaa !21
  store i1 %t262, ptr %l176, !tbaa !21
  br label %bb58
bb58:
  %t263 = load i1, ptr %l176, !tbaa !21
  br i1 %t263, label %bb59, label %bb60
bb59:
  br label %bb80
bb60:
  br label %bb61
bb61:
  %t264 = load ptr, ptr %l3, !tbaa !29
  %t266 = getelementptr %"compiler/free:mustW", ptr %t264, i32 0, i32 2
  %t267 = load i64, ptr %l23, !tbaa !24
  %t270 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t266, i64 %t267)
  store i64 %t270, ptr %l183
  br label %bb62
bb62:
  %t271 = load ptr, ptr %l3, !tbaa !29
  store ptr %t271, ptr %l184, !tbaa !29
  %t272 = load ptr, ptr %l3, !tbaa !29
  %t274 = getelementptr %"compiler/free:mustW", ptr %t272, i32 0, i32 5
  %t275 = load i64, ptr %l22, !tbaa !24
  %t278 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t274, i64 %t275)
  store ptr %t278, ptr %l188
  br label %bb63
bb63:
  %t279 = load ptr, ptr %l184, !tbaa !29
  %t280 = load ptr, ptr %l188, !tbaa !29
  %t281 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v0, ptr %t279, ptr %t280)
  store i64 %t281, ptr %l189
  br label %bb64
bb64:
  %t282 = load i64, ptr %l183, !tbaa !24
  %t283 = load i64, ptr %l189, !tbaa !24
  %t284 = call i64 @compiler_2ffree_2emeet(i64 %t282, i64 %t283)
  store i64 %t284, ptr %l190
  br label %bb65
bb65:
  %t285 = load i64, ptr %l190, !tbaa !24
  store i64 %t285, ptr %l24, !tbaa !24
  %t286 = load i64, ptr %l24, !tbaa !24
  store i64 %t286, ptr %l191, !tbaa !24
  %t287 = load ptr, ptr %l3, !tbaa !29
  %t289 = getelementptr %"compiler/free:mustW", ptr %t287, i32 0, i32 2
  %t290 = load i64, ptr %l23, !tbaa !24
  %t293 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t289, i64 %t290)
  store i64 %t293, ptr %l195
  br label %bb66
bb66:
  %t294 = load i64, ptr %l191, !tbaa !24
  %t295 = load i64, ptr %l195, !tbaa !24
  %t296 = icmp ne i64 %t294, %t295
  br i1 %t296, label %bb67, label %bb68
bb67:
  %t298 = load ptr, ptr %l3, !tbaa !29
  %t300 = getelementptr %"compiler/free:mustW", ptr %t298, i32 0, i32 2
  %t301 = load i64, ptr %l23, !tbaa !24
  %t302 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t300, i64 %t301, i64 %t302)
  br label %bb69
bb68:
  br label %bb70
bb69:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb70
bb70:
  %t306 = load ptr, ptr %l3, !tbaa !29
  %t308 = getelementptr %"compiler/free:mustW", ptr %t306, i32 0, i32 3
  %t309 = load i64, ptr %l23, !tbaa !24
  %t312 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t308, i64 %t309)
  store i64 %t312, ptr %l204
  br label %bb71
bb71:
  %t313 = load ptr, ptr %l3, !tbaa !29
  %t315 = getelementptr %"compiler/free:mustW", ptr %t313, i32 0, i32 0
  %t316 = load ptr, ptr %t315, !tbaa !29
  store ptr %t316, ptr %l206, !tbaa !29
  %t317 = load ptr, ptr %l3, !tbaa !29
  %t319 = getelementptr %"compiler/free:mustW", ptr %t317, i32 0, i32 3
  store ptr %t319, ptr %l208, !tbaa !29
  %t320 = load ptr, ptr %l3, !tbaa !29
  %t322 = getelementptr %"compiler/free:mustW", ptr %t320, i32 0, i32 5
  %t323 = load i64, ptr %l22, !tbaa !24
  %t326 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t322, i64 %t323)
  store ptr %t326, ptr %l212
  br label %bb72
bb72:
  %t327 = load ptr, ptr %l206, !tbaa !29
  %t328 = load ptr, ptr %l208, !tbaa !29
  %t329 = load ptr, ptr %l212, !tbaa !29
  %t330 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v0, ptr %v0, ptr %t327, ptr %t328, ptr %t329)
  store i64 %t330, ptr %l213
  br label %bb73
bb73:
  %t331 = load i64, ptr %l204, !tbaa !24
  %t332 = load i64, ptr %l213, !tbaa !24
  %t333 = call i64 @compiler_2ffree_2emeet(i64 %t331, i64 %t332)
  store i64 %t333, ptr %l214
  br label %bb74
bb74:
  %t334 = load i64, ptr %l214, !tbaa !24
  store i64 %t334, ptr %l25, !tbaa !24
  %t335 = load i64, ptr %l25, !tbaa !24
  store i64 %t335, ptr %l215, !tbaa !24
  %t336 = load ptr, ptr %l3, !tbaa !29
  %t338 = getelementptr %"compiler/free:mustW", ptr %t336, i32 0, i32 3
  %t339 = load i64, ptr %l23, !tbaa !24
  %t342 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t338, i64 %t339)
  store i64 %t342, ptr %l219
  br label %bb75
bb75:
  %t343 = load i64, ptr %l215, !tbaa !24
  %t344 = load i64, ptr %l219, !tbaa !24
  %t345 = icmp ne i64 %t343, %t344
  br i1 %t345, label %bb76, label %bb77
bb76:
  %t347 = load ptr, ptr %l3, !tbaa !29
  %t349 = getelementptr %"compiler/free:mustW", ptr %t347, i32 0, i32 3
  %t350 = load i64, ptr %l23, !tbaa !24
  %t351 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t349, i64 %t350, i64 %t351)
  br label %bb78
bb77:
  br label %bb79
bb78:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t355 = load i64, ptr %l21, !tbaa !24
  %t357 = add i64 %t355, 1
  store i64 %t357, ptr %l21, !tbaa !24
  br label %bb50
bb81:
  %t359 = load i1, ptr %l16, !tbaa !21
  %t361 = xor i1 %t359, true
  br i1 %t361, label %bb82, label %bb83
bb82:
  br label %bb86
bb83:
  br label %bb84
bb84:
  br label %bb85
bb85:
  br label %bb42
bb86:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/free:Free", ptr %t363, i32 0, i32 54
  %t366 = load i64, ptr %l1, !tbaa !24
  %t369 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t365, i64 %t366)
  store ptr %t369, ptr %l232
  br label %bb87
bb87:
  %t370 = load ptr, ptr %l232, !tbaa !29
  store ptr %t370, ptr %l26, !tbaa !29
  %t371 = load ptr, ptr %l26, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t371)
  br label %bb88
bb88:
  %t373 = load ptr, ptr %l3, !tbaa !29
  %t375 = getelementptr %"compiler/free:mustW", ptr %t373, i32 0, i32 3
  store ptr %t375, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb89
bb89:
  %t377 = load i64, ptr %l28, !tbaa !24
  store i64 %t377, ptr %l236, !tbaa !24
  %t378 = load ptr, ptr %l27, !tbaa !29
  %t380 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t378)
  store i64 %t380, ptr %l238
  br label %bb90
bb90:
  %t381 = load i64, ptr %l236, !tbaa !24
  %t382 = load i64, ptr %l238, !tbaa !24
  %t383 = icmp slt i64 %t381, %t382
  %t385 = xor i1 %t383, true
  br i1 %t385, label %bb91, label %bb92
bb91:
  br label %bb97
bb92:
  br label %bb93
bb93:
  %t387 = load ptr, ptr %l27, !tbaa !29
  %t388 = load i64, ptr %l28, !tbaa !24
  %t391 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t387, i64 %t388)
  store i64 %t391, ptr %l243
  br label %bb94
bb94:
  %t392 = load i64, ptr %l243, !tbaa !24
  %t393 = load ptr, ptr %l26, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t393, i64 %t392)
  br label %bb95
bb95:
  br label %bb96
bb96:
  %t397 = load i64, ptr %l28, !tbaa !24
  %t399 = add i64 %t397, 1
  store i64 %t399, ptr %l28, !tbaa !24
  br label %bb89
bb97:
  %t401 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  store i64 %t401, ptr %l30, !tbaa !24
  store i1 true, ptr %l31, !tbaa !21
  %t403 = load ptr, ptr %l3, !tbaa !29
  %t405 = getelementptr %"compiler/free:mustW", ptr %t403, i32 0, i32 6
  store ptr %t405, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb98
bb98:
  %t407 = load i64, ptr %l33, !tbaa !24
  store i64 %t407, ptr %l251, !tbaa !24
  %t408 = load ptr, ptr %l32, !tbaa !29
  %t410 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t408)
  store i64 %t410, ptr %l253
  br label %bb99
bb99:
  %t411 = load i64, ptr %l251, !tbaa !24
  %t412 = load i64, ptr %l253, !tbaa !24
  %t413 = icmp slt i64 %t411, %t412
  %t415 = xor i1 %t413, true
  br i1 %t415, label %bb100, label %bb101
bb100:
  br label %bb111
bb101:
  br label %bb102
bb102:
  %t417 = load ptr, ptr %l32, !tbaa !29
  %t418 = load i64, ptr %l33, !tbaa !24
  %t421 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t417, i64 %t418)
  store ptr %t421, ptr %l258
  br label %bb103
bb103:
  %t422 = load ptr, ptr %l258, !tbaa !29
  store ptr %t422, ptr %l34, !tbaa !29
  %t423 = load i64, ptr %l30, !tbaa !24
  store i64 %t423, ptr %l259, !tbaa !24
  %t424 = load ptr, ptr %l3, !tbaa !29
  %t425 = load ptr, ptr %l34, !tbaa !29
  %t428 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v0, ptr %t424, ptr %t425)
  store i64 %t428, ptr %l262
  br label %bb104
bb104:
  %t429 = load i64, ptr %l259, !tbaa !24
  %t430 = load i64, ptr %l262, !tbaa !24
  %t431 = call i64 @compiler_2ffree_2emeet(i64 %t429, i64 %t430)
  store i64 %t431, ptr %l263
  br label %bb105
bb105:
  %t432 = load i64, ptr %l263, !tbaa !24
  store i64 %t432, ptr %l30, !tbaa !24
  %t433 = load ptr, ptr %l3, !tbaa !29
  %t434 = load ptr, ptr %l34, !tbaa !29
  %t437 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v0, ptr %t433, ptr %t434, i64 0)
  store i1 %t437, ptr %l266
  br label %bb106
bb106:
  %t438 = load i1, ptr %l266, !tbaa !21
  %t439 = xor i1 %t438, true
  br i1 %t439, label %bb107, label %bb108
bb107:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb109
bb108:
  br label %bb109
bb109:
  br label %bb110
bb110:
  %t441 = load i64, ptr %l33, !tbaa !24
  %t443 = add i64 %t441, 1
  store i64 %t443, ptr %l33, !tbaa !24
  br label %bb98
bb111:
  %t445 = load i64, ptr %l30, !tbaa !24
  store i64 %t445, ptr %l270, !tbaa !24
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/free:Free", ptr %t446, i32 0, i32 32
  %t449 = load i64, ptr %l1, !tbaa !24
  %t452 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t448, i64 %t449)
  store i64 %t452, ptr %l274
  br label %bb112
bb112:
  %t453 = load i64, ptr %l270, !tbaa !24
  %t454 = load i64, ptr %l274, !tbaa !24
  %t455 = icmp ne i64 %t453, %t454
  br i1 %t455, label %bb113, label %bb114
bb113:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr %"compiler/free:Free", ptr %t457, i32 0, i32 32
  %t460 = load i64, ptr %l1, !tbaa !24
  %t461 = load i64, ptr %l30, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t459, i64 %t460, i64 %t461)
  br label %bb115
bb114:
  br label %bb116
bb115:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/free:Free", ptr %t465, i32 0, i32 36
  store i1 true, ptr %t467, !tbaa !21
  br label %bb116
bb116:
  %t468 = load i1, ptr %l31, !tbaa !21
  store i1 %t468, ptr %l281, !tbaa !21
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/free:Free", ptr %t469, i32 0, i32 33
  %t472 = load i64, ptr %l1, !tbaa !24
  %t475 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t471, i64 %t472)
  store i1 %t475, ptr %l285
  br label %bb117
bb117:
  %t476 = load i1, ptr %l281, !tbaa !21
  %t477 = load i1, ptr %l285, !tbaa !21
  %t478 = icmp ne i1 %t476, %t477
  br i1 %t478, label %bb118, label %bb119
bb118:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = getelementptr %"compiler/free:Free", ptr %t480, i32 0, i32 33
  %t483 = load i64, ptr %l1, !tbaa !24
  %t486 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t482, i64 %t483)
  store i1 %t486, ptr %l291
  br label %bb120
bb119:
  store i1 false, ptr %l287, !tbaa !21
  br label %bb121
bb120:
  %t487 = load i1, ptr %l291, !tbaa !21
  store i1 %t487, ptr %l287, !tbaa !21
  br label %bb121
bb121:
  %t488 = load i1, ptr %l287, !tbaa !21
  br i1 %t488, label %bb122, label %bb123
bb122:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/free:Free", ptr %t489, i32 0, i32 33
  %t492 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t491, i64 %t492, i1 false)
  br label %bb124
bb123:
  br label %bb125
bb124:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/free:Free", ptr %t495, i32 0, i32 36
  store i1 true, ptr %t497, !tbaa !21
  br label %bb125
bb125:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = getelementptr %"compiler/free:Free", ptr %t498, i32 0, i32 53
  %t501 = load i64, ptr %l1, !tbaa !24
  %t504 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t500, i64 %t501)
  store ptr %t504, ptr %l299
  br label %bb126
bb126:
  %t505 = load ptr, ptr %l299, !tbaa !29
  store ptr %t505, ptr %l35, !tbaa !29
  %t506 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t506)
  br label %bb127
bb127:
  %t508 = load ptr, ptr %l3, !tbaa !29
  %t510 = getelementptr %"compiler/free:mustW", ptr %t508, i32 0, i32 2
  store ptr %t510, ptr %l36, !tbaa !29
  store i64 0, ptr %l37, !tbaa !24
  br label %bb128
bb128:
  %t512 = load i64, ptr %l37, !tbaa !24
  store i64 %t512, ptr %l303, !tbaa !24
  %t513 = load ptr, ptr %l36, !tbaa !29
  %t515 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t513)
  store i64 %t515, ptr %l305
  br label %bb129
bb129:
  %t516 = load i64, ptr %l303, !tbaa !24
  %t517 = load i64, ptr %l305, !tbaa !24
  %t518 = icmp slt i64 %t516, %t517
  %t520 = xor i1 %t518, true
  br i1 %t520, label %bb130, label %bb131
bb130:
  br label %bb136
bb131:
  br label %bb132
bb132:
  %t522 = load ptr, ptr %l36, !tbaa !29
  %t523 = load i64, ptr %l37, !tbaa !24
  %t526 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t522, i64 %t523)
  store i64 %t526, ptr %l310
  br label %bb133
bb133:
  %t527 = load i64, ptr %l310, !tbaa !24
  %t528 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t528, i64 %t527)
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t532 = load i64, ptr %l37, !tbaa !24
  %t534 = add i64 %t532, 1
  store i64 %t534, ptr %l37, !tbaa !24
  br label %bb128
bb136:
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t538 = getelementptr %"compiler/free:Free", ptr %t536, i32 0, i32 55
  %t539 = load i64, ptr %l1, !tbaa !24
  %t542 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_Ha64a825bb0b4fc6c7596ac96329c2853(ptr %v0, ptr %v0, ptr %t538, i64 %t539)
  store ptr %t542, ptr %l318
  br label %bb137
bb137:
  %t543 = load ptr, ptr %l318, !tbaa !29
  store ptr %t543, ptr %l39, !tbaa !29
  %t544 = load ptr, ptr %l39, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t544)
  br label %bb138
bb138:
  store i64 0, ptr %l40, !tbaa !24
  %t546 = load ptr, ptr %l2, !tbaa !29
  %t548 = getelementptr %"compiler/typed:Body", ptr %t546, i32 0, i32 7
  %t550 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t548)
  store i64 %t550, ptr %l322
  br label %bb139
bb139:
  %t551 = load i64, ptr %l322, !tbaa !24
  store i64 %t551, ptr %l41, !tbaa !24
  store i64 1, ptr %l42, !tbaa !24
  %t552 = load i64, ptr %l41, !tbaa !24
  %t553 = load i64, ptr %l40, !tbaa !24
  %t556 = icmp sgt i64 %t552, %t553
  br i1 %t556, label %bb140, label %bb141
bb140:
  %t558 = load i64, ptr %l42, !tbaa !24
  %t560 = icmp sgt i64 %t558, 0
  br i1 %t560, label %bb142, label %bb143
bb141:
  store i64 0, ptr %l326, !tbaa !24
  br label %bb145
bb142:
  %t562 = load i64, ptr %l41, !tbaa !24
  %t563 = load i64, ptr %l40, !tbaa !24
  %t566 = sub i64 %t562, %t563
  %t567 = load i64, ptr %l42, !tbaa !24
  %t570 = add i64 %t566, %t567
  %t572 = sub i64 %t570, 1
  %t573 = load i64, ptr %l42, !tbaa !24
  %t576 = sdiv i64 %t572, %t573
  store i64 %t576, ptr %l329, !tbaa !24
  br label %bb144
bb143:
  store i64 0, ptr %l329, !tbaa !24
  br label %bb144
bb144:
  %t578 = load i64, ptr %l329, !tbaa !24
  store i64 %t578, ptr %l326, !tbaa !24
  br label %bb145
bb145:
  %t579 = load i64, ptr %l326, !tbaa !24
  store i64 %t579, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb146
bb146:
  %t580 = load i64, ptr %l44, !tbaa !24
  %t581 = load i64, ptr %l43, !tbaa !24
  %t584 = icmp slt i64 %t580, %t581
  %t586 = xor i1 %t584, true
  br i1 %t586, label %bb147, label %bb148
bb147:
  br label %bb153
bb148:
  br label %bb149
bb149:
  %t588 = load i64, ptr %l40, !tbaa !24
  %t589 = load i64, ptr %l44, !tbaa !24
  %t590 = load i64, ptr %l42, !tbaa !24
  %t593 = mul i64 %t589, %t590
  %t596 = add i64 %t588, %t593
  %t598 = load ptr, ptr %l39, !tbaa !29
  store ptr %t598, ptr %l347, !tbaa !29
  %t599 = load ptr, ptr %l3, !tbaa !29
  %t603 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efreshLocal(ptr %v0, ptr %t599, i64 %t596)
  store i1 %t603, ptr %l350
  br label %bb150
bb150:
  %t604 = load ptr, ptr %l347, !tbaa !29
  %t605 = load i1, ptr %l350, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t604, i1 %t605)
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t606 = load i64, ptr %l44, !tbaa !24
  %t608 = add i64 %t606, 1
  store i64 %t608, ptr %l44, !tbaa !24
  br label %bb146
bb153:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3, i32 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/free:reason"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t9, i32 %a1)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t15, i64 %a2)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/free:Free", ptr %t19, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t21, i1 %a3)
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/free:Free", ptr %t25, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t27, i1 false)
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 12
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t31, i1 false)
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:Free", ptr %t33, i32 0, i32 14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t35, i32 %a4)
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:Free", ptr %t39, i32 0, i32 44
  %t42 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/free:Free", ptr %t45, i32 0, i32 45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t47, i1 false)
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 46
  store ptr %t51, ptr %l32, !tbaa !29
  %t52 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  store i64 %t52, ptr %l33, !tbaa !24
  %t53 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t53, ptr %l34
  br label %bb10
bb10:
  %t54 = load i64, ptr %l33, !tbaa !24
  %t55 = load %"compiler/source:Span", ptr %l34
  %t56 = call %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v0, i64 %t54, i64 -1, %"compiler/source:Span" %t55, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store %"compiler/free:reason" %t56, ptr %l35
  br label %bb11
bb11:
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = load %"compiler/free:reason", ptr %l35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2ePush_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t57, %"compiler/free:reason" %t58)
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:Free", ptr %t59, i32 0, i32 63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t61, i1 %a5)
  br label %bb13
bb13:
  %t65 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i64
  %l49 = alloca i64
  %l57 = alloca ptr
  %l60 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t7, -3
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb26
bb4:
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l3
  %t23 = load { i64, [2 x i64] }, ptr %l3
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l25
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t44, i64 %t45)
  store i64 %t46, ptr %l26
  br label %bb9
bb9:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb25
bb10:
  %t48 = load { i64, [2 x i64] }, ptr %l3
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t54 = getelementptr { i32, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t57)
  store ptr %t59, ptr %l31
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t60)
  store ptr %t62, ptr %l33
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i32, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t67, i32 %t66)
  store i32 %t69, ptr %l37
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l38
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l31, !tbaa !29
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t75, ptr %l39
  br label %bb19
bb19:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_997f49c366488af5_93d2651ee5683809)
  unreachable
bb25:
  br label %bb26
bb26:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t80 = icmp slt i64 %t78, 0
  br i1 %t80, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb30
bb28:
  %t82 = load i64, ptr %l2, !tbaa !24
  store i64 %t82, ptr %l44, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:Free", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/load:Loader", ptr %t89, i32 0, i32 10
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l49
  br label %bb29
bb29:
  %t94 = load i64, ptr %l44, !tbaa !24
  %t95 = load i64, ptr %l49, !tbaa !24
  %t96 = icmp sge i64 %t94, %t95
  store i1 %t96, ptr %l43, !tbaa !21
  br label %bb30
bb30:
  %t98 = load i1, ptr %l43, !tbaa !21
  br i1 %t98, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/free:Free", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/load:Loader", ptr %t106, i32 0, i32 10
  %t109 = load i64, ptr %l2, !tbaa !24
  %t112 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t108, i64 %t109)
  store ptr %t112, ptr %l57
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l57, !tbaa !29
  %t115 = getelementptr %"compiler/load:Module", ptr %t113, i32 0, i32 2
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t116, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t118, ptr %l60
  br label %bb35
bb35:
  %t119 = load i1, ptr %l60, !tbaa !21
  %t120 = xor i1 %t119, true
  call void @__olang_scope_close(ptr %s0)
  store i1 %t120, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownLocalCand(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca %"compiler/typed:Local"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l19 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l24 = alloca ptr
  %l29 = alloca %"compiler/typed:Local"
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %l47 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb27
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 64
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s1, i64 %t25, i64 %t28)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, ptr %l19
  br label %bb6
bb6:
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l19
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32, ptr %l4
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:Free", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 64
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t35, i64 %t39)
  store ptr %t42, ptr %l24
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 7
  %t46 = load i32, ptr %l3, !tbaa !23
  %t48 = sext i32 %t46 to i64
  %t51 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t45, i64 %t48)
  store %"compiler/typed:Local" %t51, ptr %l29
  br label %bb8
bb8:
  %t52 = load %"compiler/typed:Local", ptr %l29
  store %"compiler/typed:Local" %t52, ptr %l5
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:Free", ptr %t53, i32 0, i32 60
  %t56 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t59 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %t55, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t56)
  store i1 %t59, ptr %l33
  br label %bb9
bb9:
  %t60 = load i1, ptr %l33, !tbaa !21
  br i1 %t60, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb12
bb11:
  %t61 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t62 = load i32, ptr %t61, !range !{i32 0, i32 7}
  %t64 = trunc i64 1 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %l34, !tbaa !21
  br label %bb12
bb12:
  %t69 = load i1, ptr %l34, !tbaa !21
  br i1 %t69, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb15
bb14:
  %t70 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 6
  %t71 = load i1, ptr %t70, !tbaa !21
  store i1 %t71, ptr %l38, !tbaa !21
  br label %bb15
bb15:
  %t73 = load i1, ptr %l38, !tbaa !21
  br i1 %t73, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb17:
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownerCand(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t78, ptr %l42
  br label %bb19
bb19:
  %t79 = load i1, ptr %l42, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb21:
  br label %bb22
bb22:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l2, !tbaa !23
  %t84 = load i32, ptr %l2, !tbaa !23
  %t88 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %t82, i32 %t83, i64 -3, i1 false, i32 %t84, i1 false)
  store i64 %t88, ptr %l47
  br label %bb23
bb23:
  %t89 = load i64, ptr %l47, !tbaa !24
  store i64 %t89, ptr %l6, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:Free", ptr %t90, i32 0, i32 11
  %t93 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t92, i64 %t93, i1 true)
  br label %bb24
bb24:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 60
  %t99 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t100 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t98, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t99, i64 %t100)
  br label %bb25
bb25:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/free:Free", ptr %t104, i32 0, i32 61
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/free:Free", ptr %t107, i32 0, i32 64
  %t110 = load i64, ptr %t109, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t106, i64 %t110, i1 true)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s1)
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_3f4c383e8983fca5_b7613254c9da681)
  unreachable
bb32:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i32
  %l25 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l26 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i32
  %l37 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i32
  %l48 = alloca i32
  %l53 = alloca i32
  %l56 = alloca i1
  %l59 = alloca i1
  %l62 = alloca i1
  %l65 = alloca i32
  %l68 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca i32
  %l80 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l94 = alloca i1
  %l97 = alloca i1
  %l100 = alloca i1
  %l103 = alloca i1
  %l106 = alloca i1
  %l109 = alloca i1
  %l112 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l131 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l16, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  store ptr %t5, ptr %l17, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l20
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l17, !tbaa !29
  %t12 = load i32, ptr %l20, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l21
  br label %bb3
bb3:
  %t14 = load i32, ptr %l21, !tbaa !23
  store i32 %t14, ptr %l4, !tbaa !23
  %t15 = load i32, ptr %l4, !tbaa !23
  %t17 = sext i32 %t15 to i64
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t17, i64 %t18)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t21, ptr %l25
  br label %bb4
bb4:
  %t22 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l25
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t22, ptr %l5
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:Free", ptr %t23, i32 0, i32 16
  %t26 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t29 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t25, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t26)
  %t30 = extractvalue { i32, i64 } %t29, 1
  %t31 = extractvalue { i32, i64 } %t29, 0
  store i32 %t31, ptr %l31
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb6, label %ok.33, !prof !99
ok.33:
  store i64 %t30, ptr %l30
  br label %bb5
bb5:
  %t34 = load i64, ptr %l30, !tbaa !24
  store i64 %t34, ptr %l26, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l26, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp eq i64 %t36, 1
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp eq i64 %t41, 2
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/free:Free", ptr %t45, i32 0, i32 15
  %t48 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t51 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t47, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t48)
  %t52 = extractvalue { i32, i64 } %t51, 1
  %t53 = extractvalue { i32, i64 } %t51, 0
  store i32 %t53, ptr %l42
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb15, label %ok.55, !prof !99
ok.55:
  store i64 %t52, ptr %l41
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t56 = load i64, ptr %l41, !tbaa !24
  store i64 %t56, ptr %l37, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  store i64 -1, ptr %l37, !tbaa !24
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i64, ptr %l37, !tbaa !24
  store i64 %t57, ptr %rv
  br label %ret
bb18:
  store i1 false, ptr %l7, !tbaa !21
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t58, ptr %l8, !tbaa !23
  store i1 false, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  store i1 false, ptr %l11, !tbaa !21
  store i1 false, ptr %l12, !tbaa !21
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = icmp slt i64 %t60, 0
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t65 = load i32, ptr %l4, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l48
  br label %bb21
bb20:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t70 = load i32, ptr %l4, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l65
  br label %bb34
bb21:
  %t74 = load i32, ptr %l48, !range !{i32 0, i32 33}
  %t76 = trunc i64 19 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t80 = load i32, ptr %l4, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l53
  br label %bb24
bb23:
  br label %bb33
bb24:
  %t84 = load i32, ptr %l53, !tbaa !23
  store i32 %t84, ptr %l8, !tbaa !23
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l8, !tbaa !23
  %t89 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %t85, i32 %t86)
  store i1 %t89, ptr %l56
  br label %bb25
bb25:
  %t90 = load i1, ptr %l56, !tbaa !21
  store i1 %t90, ptr %l7, !tbaa !21
  %t91 = load i1, ptr %l7, !tbaa !21
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb26, label %bb27
bb26:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l8, !tbaa !23
  %t99 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edtorCand(ptr %v0, ptr %t95, i32 %t96)
  store i1 %t99, ptr %l62
  br label %bb28
bb27:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb29
bb28:
  %t100 = load i1, ptr %l62, !tbaa !21
  store i1 %t100, ptr %l59, !tbaa !21
  br label %bb29
bb29:
  %t101 = load i1, ptr %l59, !tbaa !21
  br i1 %t101, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l7, !tbaa !21
  store i1 true, ptr %l12, !tbaa !21
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb81
bb34:
  %t102 = load i32, ptr %l65, !range !{i32 0, i32 33}
  %t104 = trunc i64 18 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb35, label %bb36
bb35:
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t108 = load i32, ptr %l4, !tbaa !23
  %t111 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l71
  br label %bb37
bb36:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb38
bb37:
  %t112 = load i1, ptr %l71, !tbaa !21
  store i1 %t112, ptr %l68, !tbaa !21
  br label %bb38
bb38:
  %t113 = load i1, ptr %l68, !tbaa !21
  br i1 %t113, label %bb39, label %bb40
bb39:
  %t114 = load ptr, ptr %l3, !tbaa !29
  store ptr %t114, ptr %l73, !tbaa !29
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t116 = load i32, ptr %l4, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l76
  br label %bb41
bb40:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb43
bb41:
  %t120 = load ptr, ptr %l73, !tbaa !29
  %t121 = load i32, ptr %l76, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t122, ptr %l77
  br label %bb42
bb42:
  %t123 = load i32, ptr %l77, !range !{i32 0, i32 6}
  %t125 = trunc i64 0 to i32
  %t126 = icmp eq i32 %t123, %t125
  store i1 %t126, ptr %l72, !tbaa !21
  br label %bb43
bb43:
  %t128 = load i1, ptr %l72, !tbaa !21
  br i1 %t128, label %bb44, label %bb45
bb44:
  %t129 = load ptr, ptr %l3, !tbaa !29
  store ptr %t129, ptr %l80, !tbaa !29
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t131 = load i32, ptr %l4, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t134, ptr %l83
  br label %bb46
bb45:
  br label %bb80
bb46:
  %t135 = load ptr, ptr %l80, !tbaa !29
  %t136 = load i32, ptr %l83, !tbaa !23
  %t137 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t135, i32 %t136)
  store { i64, ptr } %t137, ptr %l84
  br label %bb47
bb47:
  %t138 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t138, ptr %l13, !tbaa !27
  %t139 = load i64, ptr %l2, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t145 = icmp slt i64 %t139, %t142
  br i1 %t145, label %bb48, label %bb49
bb48:
  %t147 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t147, ptr %l89, !tbaa !27
  %t148 = load i64, ptr %l2, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 %t148
  %t153 = load i32, ptr %t152, !tbaa !33
  store i32 %t153, ptr %l8, !tbaa !23
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l8, !tbaa !23
  %t159 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %t155, i32 %t156)
  store i1 %t159, ptr %l94
  br label %bb50
bb49:
  br label %bb79
bb50:
  %t160 = load i1, ptr %l94, !tbaa !21
  store i1 %t160, ptr %l7, !tbaa !21
  %t161 = load i1, ptr %l7, !tbaa !21
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb51, label %bb52
bb51:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i32, ptr %l8, !tbaa !23
  %t169 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandleCand(ptr %v0, ptr %t165, i32 %t166)
  store i1 %t169, ptr %l100
  br label %bb53
bb52:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb54
bb53:
  %t170 = load i1, ptr %l100, !tbaa !21
  store i1 %t170, ptr %l97, !tbaa !21
  br label %bb54
bb54:
  %t171 = load i1, ptr %l97, !tbaa !21
  br i1 %t171, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l7, !tbaa !21
  store i1 true, ptr %l9, !tbaa !21
  br label %bb57
bb56:
  br label %bb57
bb57:
  %t172 = load i1, ptr %l7, !tbaa !21
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb58, label %bb59
bb58:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l8, !tbaa !23
  %t180 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownerCand(ptr %v0, ptr %t176, i32 %t177)
  store i1 %t180, ptr %l106
  br label %bb60
bb59:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb61
bb60:
  %t181 = load i1, ptr %l106, !tbaa !21
  store i1 %t181, ptr %l103, !tbaa !21
  br label %bb61
bb61:
  %t182 = load i1, ptr %l103, !tbaa !21
  br i1 %t182, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l7, !tbaa !21
  store i1 true, ptr %l10, !tbaa !21
  br label %bb64
bb63:
  br label %bb64
bb64:
  %t183 = load i1, ptr %l7, !tbaa !21
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb65, label %bb66
bb65:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i32, ptr %l8, !tbaa !23
  %t191 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayCand(ptr %v0, ptr %t187, i32 %t188)
  store i1 %t191, ptr %l112
  br label %bb67
bb66:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb68
bb67:
  %t192 = load i1, ptr %l112, !tbaa !21
  store i1 %t192, ptr %l109, !tbaa !21
  br label %bb68
bb68:
  %t193 = load i1, ptr %l109, !tbaa !21
  br i1 %t193, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l7, !tbaa !21
  store i1 true, ptr %l11, !tbaa !21
  br label %bb71
bb70:
  br label %bb71
bb71:
  %t194 = load i1, ptr %l7, !tbaa !21
  %t196 = xor i1 %t194, true
  br i1 %t196, label %bb72, label %bb73
bb72:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i32, ptr %l8, !tbaa !23
  %t202 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edtorCand(ptr %v0, ptr %t198, i32 %t199)
  store i1 %t202, ptr %l118
  br label %bb74
bb73:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb75
bb74:
  %t203 = load i1, ptr %l118, !tbaa !21
  store i1 %t203, ptr %l115, !tbaa !21
  br label %bb75
bb75:
  %t204 = load i1, ptr %l115, !tbaa !21
  br i1 %t204, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l7, !tbaa !21
  store i1 true, ptr %l12, !tbaa !21
  br label %bb78
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t205 = load i1, ptr %l7, !tbaa !21
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb82, label %bb83
bb82:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/free:Free", ptr %t209, i32 0, i32 16
  %t212 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t211, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t212, i64 1)
  br label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb85:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load i32, ptr %l4, !tbaa !23
  %t218 = load i64, ptr %l2, !tbaa !24
  %t219 = load i1, ptr %l9, !tbaa !21
  %t220 = load i32, ptr %l8, !tbaa !23
  %t221 = load i1, ptr %l12, !tbaa !21
  %t228 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %t216, i32 %t217, i64 %t218, i1 %t219, i32 %t220, i1 %t221)
  store i64 %t228, ptr %l131
  br label %bb86
bb86:
  %t229 = load i64, ptr %l131, !tbaa !24
  store i64 %t229, ptr %l14, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/free:Free", ptr %t230, i32 0, i32 11
  %t233 = load i64, ptr %l14, !tbaa !24
  %t234 = load i1, ptr %l10, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t232, i64 %t233, i1 %t234)
  br label %bb87
bb87:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/free:Free", ptr %t238, i32 0, i32 12
  %t241 = load i64, ptr %l14, !tbaa !24
  %t242 = load i1, ptr %l11, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t240, i64 %t241, i1 %t242)
  br label %bb88
bb88:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/free:Free", ptr %t246, i32 0, i32 15
  %t249 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t250 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t248, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t249, i64 %t250)
  br label %bb89
bb89:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/free:Free", ptr %t254, i32 0, i32 16
  %t257 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t256, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t257, i64 2)
  br label %bb90
bb90:
  %t260 = load i64, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t260, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplainElems(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 14
  %t13 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t9, i64 %a1)
  store i32 %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i32, ptr %l11, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t16, ptr %l12
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t18 = load i32, ptr %l12, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l13
  br label %bb4
bb4:
  %t20 = load i32, ptr %l13, !tbaa !23
  store i32 %t20, ptr %l3, !tbaa !23
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l16
  br label %bb5
bb5:
  %t26 = load i1, ptr %l16, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  %t34 = load i1, ptr %l21, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l18, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachedTasks(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca i64
  %l49 = alloca i64
  %l69 = alloca i1
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca i64
  %l84 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca i64
  %l113 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca i64
  %l137 = alloca i64
  %l142 = alloca i64
  %l145 = alloca i1
  %l151 = alloca ptr
  %l157 = alloca i64
  %l159 = alloca i64
  %l164 = alloca i64
  %l168 = alloca i1
  %l173 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l186 = alloca i1
  %l190 = alloca i1
  %l200 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l202 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l204 = alloca i64
  %l206 = alloca i64
  %l211 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l37
  br label %bb1
bb1:
  %t6 = load i64, ptr %l37, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l38, !tbaa !24
  %t8 = load i64, ptr %l38, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l38, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l2, !tbaa !27
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l41
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_98179ed2ec661f5d_533fcebe8f905861)
  unreachable
bb4:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb10
bb7:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l49, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l49, !tbaa !24
  store i64 %t47, ptr %l46, !tbaa !24
  br label %bb10
bb10:
  %t48 = load i64, ptr %l46, !tbaa !24
  store i64 %t48, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l9, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eentry(ptr %v0, ptr %t67, i64 %t68)
  store i1 %t71, ptr %l69
  br label %bb15
bb15:
  %t72 = load i1, ptr %l69, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t75 = load i64, ptr %l9, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i1, ptr %t78, i64 %t75
  store i1 true, ptr %t79, !tbaa !31
  %t80 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t80)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t83 = load i64, ptr %l8, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb11
bb21:
  %t87 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l76
  br label %bb22
bb22:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l76
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l1, !tbaa !24
  store i64 %t89, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t91 = load i64, ptr %l12, !tbaa !24
  %t92 = load i64, ptr %l11, !tbaa !24
  %t95 = icmp sgt i64 %t91, %t92
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t97 = load i64, ptr %l13, !tbaa !24
  %t99 = icmp sgt i64 %t97, 0
  br i1 %t99, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb28
bb25:
  %t101 = load i64, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = sub i64 %t101, %t102
  %t106 = load i64, ptr %l13, !tbaa !24
  %t109 = add i64 %t105, %t106
  %t111 = sub i64 %t109, 1
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = sdiv i64 %t111, %t112
  store i64 %t115, ptr %l84, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb27
bb27:
  %t117 = load i64, ptr %l84, !tbaa !24
  store i64 %t117, ptr %l81, !tbaa !24
  br label %bb28
bb28:
  %t118 = load i64, ptr %l81, !tbaa !24
  store i64 %t118, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t119 = load i64, ptr %l15, !tbaa !24
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb31:
  br label %bb32
bb32:
  %t127 = load i64, ptr %l11, !tbaa !24
  %t128 = load i64, ptr %l15, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t132 = mul i64 %t128, %t129
  %t135 = add i64 %t127, %t132
  store i64 %t135, ptr %l16, !tbaa !24
  store ptr %l10, ptr %l102, !tbaa !29
  %t137 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s6, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %l103
  br label %bb33
bb33:
  %t138 = load ptr, ptr %l102, !tbaa !29
  %t139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %s0, ptr %s6, ptr %t138, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  %t140 = load i64, ptr %l15, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l15, !tbaa !24
  br label %bb29
bb36:
  store i64 0, ptr %l17, !tbaa !24
  %t144 = load i64, ptr %l1, !tbaa !24
  store i64 %t144, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t146 = load i64, ptr %l18, !tbaa !24
  %t147 = load i64, ptr %l17, !tbaa !24
  %t150 = icmp sgt i64 %t146, %t147
  br i1 %t150, label %bb37, label %bb38
bb37:
  %t152 = load i64, ptr %l19, !tbaa !24
  %t154 = icmp sgt i64 %t152, 0
  br i1 %t154, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb42
bb39:
  %t156 = load i64, ptr %l18, !tbaa !24
  %t157 = load i64, ptr %l17, !tbaa !24
  %t160 = sub i64 %t156, %t157
  %t161 = load i64, ptr %l19, !tbaa !24
  %t164 = add i64 %t160, %t161
  %t166 = sub i64 %t164, 1
  %t167 = load i64, ptr %l19, !tbaa !24
  %t170 = sdiv i64 %t166, %t167
  store i64 %t170, ptr %l113, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb41
bb41:
  %t172 = load i64, ptr %l113, !tbaa !24
  store i64 %t172, ptr %l110, !tbaa !24
  br label %bb42
bb42:
  %t173 = load i64, ptr %l110, !tbaa !24
  store i64 %t173, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb43
bb43:
  %t174 = load i64, ptr %l21, !tbaa !24
  %t175 = load i64, ptr %l20, !tbaa !24
  %t178 = icmp slt i64 %t174, %t175
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb44, label %bb45
bb44:
  br label %bb65
bb45:
  br label %bb46
bb46:
  %t182 = load i64, ptr %l17, !tbaa !24
  %t183 = load i64, ptr %l21, !tbaa !24
  %t184 = load i64, ptr %l19, !tbaa !24
  %t187 = mul i64 %t183, %t184
  %t190 = add i64 %t182, %t187
  store i64 %t190, ptr %l22, !tbaa !24
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/free:Free", ptr %t192, i32 0, i32 56
  %t195 = load i64, ptr %l22, !tbaa !24
  %t198 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t194, i64 %t195)
  store ptr %t198, ptr %l134
  br label %bb47
bb47:
  %t199 = load ptr, ptr %l134, !tbaa !29
  store ptr %t199, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb48
bb48:
  %t200 = load i64, ptr %l24, !tbaa !24
  store i64 %t200, ptr %l135, !tbaa !24
  %t201 = load ptr, ptr %l23, !tbaa !29
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t201)
  store i64 %t203, ptr %l137
  br label %bb49
bb49:
  %t204 = load i64, ptr %l135, !tbaa !24
  %t205 = load i64, ptr %l137, !tbaa !24
  %t206 = icmp slt i64 %t204, %t205
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb50, label %bb51
bb50:
  br label %bb63
bb51:
  br label %bb52
bb52:
  %t210 = load ptr, ptr %l23, !tbaa !29
  %t211 = load i64, ptr %l24, !tbaa !24
  %t214 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t210, i64 %t211)
  store i64 %t214, ptr %l142
  br label %bb53
bb53:
  %t215 = load i64, ptr %l142, !tbaa !24
  store i64 %t215, ptr %l25, !tbaa !24
  %t216 = load i64, ptr %l25, !tbaa !24
  %t218 = icmp sge i64 %t216, 0
  br i1 %t218, label %bb54, label %bb55
bb54:
  %t220 = load i64, ptr %l25, !tbaa !24
  %t221 = load i64, ptr %l1, !tbaa !24
  %t224 = icmp slt i64 %t220, %t221
  store i1 %t224, ptr %l145, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb56
bb56:
  %t226 = load i1, ptr %l145, !tbaa !21
  br i1 %t226, label %bb57, label %bb58
bb57:
  %t227 = load i64, ptr %l25, !tbaa !24
  %t230 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %s0, ptr %s0, ptr %l10, i64 %t227)
  store ptr %t230, ptr %l151
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t231 = load i64, ptr %l22, !tbaa !24
  %t232 = load ptr, ptr %l151, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t232, i64 %t231)
  br label %bb60
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t234 = load i64, ptr %l24, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l24, !tbaa !24
  br label %bb48
bb63:
  br label %bb64
bb64:
  %t238 = load i64, ptr %l21, !tbaa !24
  %t240 = add i64 %t238, 1
  store i64 %t240, ptr %l21, !tbaa !24
  br label %bb43
bb65:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb66
bb66:
  %t242 = load i64, ptr %l26, !tbaa !24
  store i64 %t242, ptr %l157, !tbaa !24
  %t244 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t244, ptr %l159
  br label %bb67
bb67:
  %t245 = load i64, ptr %l157, !tbaa !24
  %t246 = load i64, ptr %l159, !tbaa !24
  %t247 = icmp slt i64 %t245, %t246
  %t249 = xor i1 %t247, true
  br i1 %t249, label %bb68, label %bb69
bb68:
  br label %bb108
bb69:
  br label %bb70
bb70:
  %t251 = load i64, ptr %l26, !tbaa !24
  %t254 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t251)
  store i64 %t254, ptr %l164
  br label %bb71
bb71:
  %t255 = load i64, ptr %l164, !tbaa !24
  store i64 %t255, ptr %l27, !tbaa !24
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/free:Free", ptr %t256, i32 0, i32 38
  %t259 = load i64, ptr %l27, !tbaa !24
  %t262 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t258, i64 %t259)
  store i1 %t262, ptr %l168
  br label %bb72
bb72:
  %t263 = load i1, ptr %l168, !tbaa !21
  br i1 %t263, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s18
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/free:Free", ptr %t265, i32 0, i32 2
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t269 = load i64, ptr %l27, !tbaa !24
  %t272 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesOf(ptr %v0, ptr %s18, ptr %t268, i64 %t269)
  store { i64, ptr } %t272, ptr %l173
  br label %bb76
bb76:
  %t273 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 0
  %t275 = extractvalue { i64, ptr } %t273, 1
  %t276 = mul i64 %t274, 8
  %t277 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t276)
  call void @llvm.memcpy.p0.p0.i64(ptr %t277, ptr %t275, i64 %t276, i1 false)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  store { i64, ptr } %t279, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t281 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t281, 0
  store i64 %t283, ptr %l30, !tbaa !24
  br label %bb77
bb77:
  %t285 = load i64, ptr %l29, !tbaa !24
  %t286 = load i64, ptr %l30, !tbaa !24
  %t289 = icmp slt i64 %t285, %t286
  %t291 = xor i1 %t289, true
  br i1 %t291, label %bb78, label %bb79
bb78:
  br label %bb92
bb79:
  br label %bb80
bb80:
  %t293 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t293, ptr %l181, !tbaa !27
  %t294 = load i64, ptr %l29, !tbaa !24
  %t296 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr i64, ptr %t297, i64 %t294
  %t299 = load i64, ptr %t298, !tbaa !34
  store i64 %t299, ptr %l31, !tbaa !24
  %t301 = load i64, ptr %l31, !tbaa !24
  %t303 = icmp slt i64 %t301, 0
  br i1 %t303, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb83
bb82:
  %t305 = load i64, ptr %l31, !tbaa !24
  %t306 = load i64, ptr %l1, !tbaa !24
  %t309 = icmp sge i64 %t305, %t306
  store i1 %t309, ptr %l186, !tbaa !21
  br label %bb83
bb83:
  %t311 = load i1, ptr %l186, !tbaa !21
  br i1 %t311, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb86
bb85:
  %t312 = load i64, ptr %l31, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr i1, ptr %t315, i64 %t312
  %t317 = load i1, ptr %t316, !tbaa !31
  store i1 %t317, ptr %l190, !tbaa !21
  br label %bb86
bb86:
  %t319 = load i1, ptr %l190, !tbaa !21
  br i1 %t319, label %bb87, label %bb88
bb87:
  br label %bb91
bb88:
  br label %bb89
bb89:
  %t320 = load i64, ptr %l31, !tbaa !24
  %t322 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr i1, ptr %t323, i64 %t320
  store i1 true, ptr %t324, !tbaa !31
  %t325 = load i64, ptr %l31, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t325)
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t328 = load i64, ptr %l29, !tbaa !24
  %t330 = add i64 %t328, 1
  store i64 %t330, ptr %l29, !tbaa !24
  br label %bb77
bb92:
  call void @__olang_scope_close(ptr %s18)
  store %olang.scope zeroinitializer, ptr %s22
  %t332 = load i64, ptr %l27, !tbaa !24
  %t335 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s22, ptr %l10, i64 %t332)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t335, ptr %l200
  br label %bb93
bb93:
  %t337 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s22, ptr %l200)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t337, ptr %l202
  br label %bb94
bb94:
  %t338 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l202
  %t339 = call ptr @__olang_scope_alloc_a(ptr %s22, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t338, ptr %t339
  store ptr %t339, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb95
bb95:
  %t341 = load i64, ptr %l33, !tbaa !24
  store i64 %t341, ptr %l204, !tbaa !24
  %t342 = load ptr, ptr %l32, !tbaa !29
  %t344 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s22, ptr %t342)
  store i64 %t344, ptr %l206
  br label %bb96
bb96:
  %t345 = load i64, ptr %l204, !tbaa !24
  %t346 = load i64, ptr %l206, !tbaa !24
  %t347 = icmp slt i64 %t345, %t346
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb97, label %bb98
bb97:
  br label %bb106
bb98:
  br label %bb99
bb99:
  %t351 = load ptr, ptr %l32, !tbaa !29
  %t352 = load i64, ptr %l33, !tbaa !24
  %t355 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s22, ptr %t351, i64 %t352)
  store i64 %t355, ptr %l211
  br label %bb100
bb100:
  %t356 = load i64, ptr %l211, !tbaa !24
  store i64 %t356, ptr %l34, !tbaa !24
  %t357 = load i64, ptr %l34, !tbaa !24
  %t359 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !27
  %t361 = getelementptr i1, ptr %t360, i64 %t357
  %t362 = load i1, ptr %t361, !tbaa !31
  br i1 %t362, label %bb101, label %bb102
bb101:
  br label %bb105
bb102:
  br label %bb103
bb103:
  %t364 = load i64, ptr %l34, !tbaa !24
  %t366 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !27
  %t368 = getelementptr i1, ptr %t367, i64 %t364
  store i1 true, ptr %t368, !tbaa !31
  %t369 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t369)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t372 = load i64, ptr %l33, !tbaa !24
  %t374 = add i64 %t372, 1
  store i64 %t374, ptr %l33, !tbaa !24
  br label %bb95
bb106:
  call void @__olang_scope_close(ptr %s22)
  br label %bb107
bb107:
  %t376 = load i64, ptr %l26, !tbaa !24
  %t378 = add i64 %t376, 1
  store i64 %t378, ptr %l26, !tbaa !24
  br label %bb66
bb108:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i1 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l40 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i1
  %l52 = alloca i1
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, [1 x i64] }
  %l60 = alloca { i64, [1 x i64] }
  %l62 = alloca i1
  %l64 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i1
  %l84 = alloca i1
  %l86 = alloca i1
  %l88 = alloca { i64, ptr }
  %l92 = alloca { i64, [1 x i64] }
  %l94 = alloca { i64, [1 x i64] }
  %l96 = alloca i1
  %l98 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l122 = alloca i1
  %l128 = alloca i1
  %l130 = alloca { i64, ptr }
  %l134 = alloca { i64, [1 x i64] }
  %l136 = alloca { i64, [1 x i64] }
  %l138 = alloca i1
  %l140 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l146 = alloca i1
  %l152 = alloca i1
  %l154 = alloca { i64, ptr }
  %l158 = alloca { i64, [1 x i64] }
  %l160 = alloca { i64, [1 x i64] }
  %l162 = alloca i1
  %l164 = alloca { i64, ptr }
  %l169 = alloca ptr
  %l170 = alloca i1
  %l176 = alloca i64
  %l179 = alloca i1
  %l183 = alloca i1
  %l187 = alloca ptr
  %l193 = alloca i64
  %l195 = alloca ptr
  %l199 = alloca ptr
  %l202 = alloca i64
  %l207 = alloca i1
  %l210 = alloca i1
  %l215 = alloca i1
  %l220 = alloca { i64, [1 x i64] }
  %l222 = alloca { i64, [1 x i64] }
  %l224 = alloca i1
  %l232 = alloca i64
  %l238 = alloca i64
  %l241 = alloca i64
  %l260 = alloca i64
  %l277 = alloca i64
  %l280 = alloca i64
  %l301 = alloca i64
  %l304 = alloca i1
  %l307 = alloca i1
  %l309 = alloca i64
  %l316 = alloca { i64, ptr }
  %l323 = alloca ptr
  %l324 = alloca i1
  %l336 = alloca ptr
  %l337 = alloca i1
  %l346 = alloca ptr
  %l347 = alloca i64
  %t13 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  store i1 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l40
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l40, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = trunc i64 %t9 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [1 x i64] }, ptr %t13, i32 0, i32 0
  store i64 4, ptr %t14
  %t16 = insertvalue { i32 } undef, i32 %t11, 0
  %t17 = getelementptr { i64, [1 x i64] }, ptr %t13, i32 0, i32 1
  store { i32 } %t16, ptr %t17
  %t18 = load { i64, [1 x i64] }, ptr %t13
  store { i64, [1 x i64] } %t18, ptr %l8
  %t20 = load ptr, ptr %l2, !tbaa !29
  store ptr %t20, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t21 = load ptr, ptr %l45, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load ptr, ptr %l45, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 5
  store i1 %t27, ptr %l46, !tbaa !21
  br label %bb3
bb3:
  %t28 = load i1, ptr %l46, !tbaa !21
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l9, !tbaa !29
  br label %bb6
bb5:
  br label %bb15
bb6:
  %t35 = load i1, ptr %l5, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb10
bb8:
  %t37 = load ptr, ptr %l7, !tbaa !29
  %t39 = getelementptr %"compiler/typed:Plan", ptr %t37, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l54, !tbaa !27
  %t41 = load ptr, ptr %l9, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Promote", ptr %t41, i32 0, i32 1
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t48 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, [1 x i64] }, ptr %t49, i64 %t46
  %t51 = load { i64, [1 x i64] }, ptr %t50
  store { i64, [1 x i64] } %t51, ptr %l58
  %t52 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t52, ptr %l60
  %t55 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l58, ptr %l60)
  store i1 %t55, ptr %l62
  br label %bb9
bb9:
  %t56 = load i1, ptr %l62, !tbaa !21
  store i1 %t56, ptr %l52, !tbaa !21
  br label %bb10
bb10:
  %t57 = load i1, ptr %l52, !tbaa !21
  br i1 %t57, label %bb11, label %bb12
bb11:
  %t58 = load ptr, ptr %l7, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Plan", ptr %t58, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l64, !tbaa !27
  %t62 = load ptr, ptr %l9, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Promote", ptr %t62, i32 0, i32 1
  %t65 = load i32, ptr %t64, !tbaa !23
  %t67 = sext i32 %t65 to i64
  %t68 = load { i64, [1 x i64] }, ptr %l8
  %t71 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr { i64, [1 x i64] }, ptr %t72, i64 %t67
  store { i64, [1 x i64] } %t68, ptr %t73
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l1, !tbaa !24
  %t76 = load ptr, ptr %l9, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Promote", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load { i64, [1 x i64] }, ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t74, i64 %t75, ptr %t79, i64 %t80, { i64, [1 x i64] } %t81, i1 false, i1 true)
  br label %bb14
bb14:
  br label %bb170
bb15:
  %t87 = load ptr, ptr %l2, !tbaa !29
  store ptr %t87, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t88 = load ptr, ptr %l75, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb16, label %bb17
bb16:
  %t91 = load ptr, ptr %l75, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 18}
  %t94 = icmp eq i64 %t92, 7
  store i1 %t94, ptr %l76, !tbaa !21
  br label %bb17
bb17:
  %t95 = load i1, ptr %l76, !tbaa !21
  br i1 %t95, label %bb18, label %bb19
bb18:
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t98, i32 0, i32 2
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l10, !tbaa !29
  br label %bb20
bb19:
  br label %bb38
bb20:
  %t102 = load ptr, ptr %l10, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Make", ptr %t102, i32 0, i32 4
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = icmp sge i32 %t105, 0
  br i1 %t107, label %bb21, label %bb22
bb21:
  %t109 = load i1, ptr %l5, !tbaa !21
  br i1 %t109, label %bb23, label %bb24
bb22:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb27
bb23:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb26
bb24:
  %t111 = load ptr, ptr %l7, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Plan", ptr %t111, i32 0, i32 0
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l88, !tbaa !27
  %t115 = load ptr, ptr %l10, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Make", ptr %t115, i32 0, i32 4
  %t118 = load i32, ptr %t117, !tbaa !23
  %t120 = sext i32 %t118 to i64
  %t122 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, [1 x i64] }, ptr %t123, i64 %t120
  %t125 = load { i64, [1 x i64] }, ptr %t124
  store { i64, [1 x i64] } %t125, ptr %l92
  %t126 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t126, ptr %l94
  %t129 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l92, ptr %l94)
  store i1 %t129, ptr %l96
  br label %bb25
bb25:
  %t130 = load i1, ptr %l96, !tbaa !21
  store i1 %t130, ptr %l86, !tbaa !21
  br label %bb26
bb26:
  %t131 = load i1, ptr %l86, !tbaa !21
  store i1 %t131, ptr %l84, !tbaa !21
  br label %bb27
bb27:
  %t132 = load i1, ptr %l84, !tbaa !21
  br i1 %t132, label %bb28, label %bb29
bb28:
  %t133 = load ptr, ptr %l7, !tbaa !29
  %t135 = getelementptr %"compiler/typed:Plan", ptr %t133, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l98, !tbaa !27
  %t137 = load ptr, ptr %l10, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Make", ptr %t137, i32 0, i32 4
  %t140 = load i32, ptr %t139, !tbaa !23
  %t142 = sext i32 %t140 to i64
  %t143 = load { i64, [1 x i64] }, ptr %l8
  %t146 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr { i64, [1 x i64] }, ptr %t147, i64 %t142
  store { i64, [1 x i64] } %t143, ptr %t148
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t149 = load ptr, ptr %l10, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Make", ptr %t149, i32 0, i32 2
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  store { i64, ptr } %t152, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  store i64 %t156, ptr %l13, !tbaa !24
  br label %bb31
bb31:
  %t158 = load i64, ptr %l12, !tbaa !24
  %t159 = load i64, ptr %l13, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t166 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t166, ptr %l111, !tbaa !27
  %t167 = load i64, ptr %l12, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr ptr, ptr %t170, i64 %t167
  %t172 = load ptr, ptr %t171, !tbaa !39
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i64, ptr %l1, !tbaa !24
  %t177 = load i64, ptr %l3, !tbaa !24
  %t178 = load { i64, [1 x i64] }, ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t174, i64 %t175, ptr %t172, i64 %t177, { i64, [1 x i64] } %t178, i1 false, i1 false)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t184 = load i64, ptr %l12, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l12, !tbaa !24
  br label %bb31
bb37:
  br label %bb170
bb38:
  %t188 = load ptr, ptr %l2, !tbaa !29
  store ptr %t188, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t189 = load ptr, ptr %l121, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb39, label %bb40
bb39:
  %t192 = load ptr, ptr %l121, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 18}
  %t195 = icmp eq i64 %t193, 16
  store i1 %t195, ptr %l122, !tbaa !21
  br label %bb40
bb40:
  %t196 = load i1, ptr %l122, !tbaa !21
  br i1 %t196, label %bb41, label %bb42
bb41:
  %t197 = load ptr, ptr %l2, !tbaa !29
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t199, i32 0, i32 2
  %t201 = load ptr, ptr %t200
  store ptr %t201, ptr %l15, !tbaa !29
  br label %bb43
bb42:
  br label %bb51
bb43:
  %t203 = load i1, ptr %l5, !tbaa !21
  br i1 %t203, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l128, !tbaa !21
  br label %bb47
bb45:
  %t205 = load ptr, ptr %l7, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Plan", ptr %t205, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l130, !tbaa !27
  %t209 = load ptr, ptr %l15, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Text", ptr %t209, i32 0, i32 1
  %t212 = load i32, ptr %t211, !tbaa !23
  %t214 = sext i32 %t212 to i64
  %t216 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr { i64, [1 x i64] }, ptr %t217, i64 %t214
  %t219 = load { i64, [1 x i64] }, ptr %t218
  store { i64, [1 x i64] } %t219, ptr %l134
  %t220 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t220, ptr %l136
  %t223 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l134, ptr %l136)
  store i1 %t223, ptr %l138
  br label %bb46
bb46:
  %t224 = load i1, ptr %l138, !tbaa !21
  store i1 %t224, ptr %l128, !tbaa !21
  br label %bb47
bb47:
  %t225 = load i1, ptr %l128, !tbaa !21
  br i1 %t225, label %bb48, label %bb49
bb48:
  %t226 = load ptr, ptr %l7, !tbaa !29
  %t228 = getelementptr %"compiler/typed:Plan", ptr %t226, i32 0, i32 0
  %t229 = load { i64, ptr }, ptr %t228, !tbaa !27
  store { i64, ptr } %t229, ptr %l140, !tbaa !27
  %t230 = load ptr, ptr %l15, !tbaa !29
  %t232 = getelementptr %"compiler/typed:Text", ptr %t230, i32 0, i32 1
  %t233 = load i32, ptr %t232, !tbaa !23
  %t235 = sext i32 %t233 to i64
  %t236 = load { i64, [1 x i64] }, ptr %l8
  %t239 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr { i64, [1 x i64] }, ptr %t240, i64 %t235
  store { i64, [1 x i64] } %t236, ptr %t241
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb170
bb51:
  %t242 = load ptr, ptr %l2, !tbaa !29
  store ptr %t242, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t243 = load ptr, ptr %l145, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb52, label %bb53
bb52:
  %t246 = load ptr, ptr %l145, !tbaa !29
  %t247 = load i64, ptr %t246, !range !{i64 0, i64 18}
  %t249 = icmp eq i64 %t247, 8
  store i1 %t249, ptr %l146, !tbaa !21
  br label %bb53
bb53:
  %t250 = load i1, ptr %l146, !tbaa !21
  br i1 %t250, label %bb54, label %bb55
bb54:
  %t251 = load ptr, ptr %l2, !tbaa !29
  %t253 = getelementptr { i64, [5 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t253, i32 0, i32 2
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l16, !tbaa !29
  br label %bb56
bb55:
  br label %bb64
bb56:
  %t257 = load i1, ptr %l5, !tbaa !21
  br i1 %t257, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l152, !tbaa !21
  br label %bb60
bb58:
  %t259 = load ptr, ptr %l7, !tbaa !29
  %t261 = getelementptr %"compiler/typed:Plan", ptr %t259, i32 0, i32 0
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  store { i64, ptr } %t262, ptr %l154, !tbaa !27
  %t263 = load ptr, ptr %l16, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Collect", ptr %t263, i32 0, i32 2
  %t266 = load i32, ptr %t265, !tbaa !23
  %t268 = sext i32 %t266 to i64
  %t270 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr { i64, [1 x i64] }, ptr %t271, i64 %t268
  %t273 = load { i64, [1 x i64] }, ptr %t272
  store { i64, [1 x i64] } %t273, ptr %l158
  %t274 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t274, ptr %l160
  %t277 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l158, ptr %l160)
  store i1 %t277, ptr %l162
  br label %bb59
bb59:
  %t278 = load i1, ptr %l162, !tbaa !21
  store i1 %t278, ptr %l152, !tbaa !21
  br label %bb60
bb60:
  %t279 = load i1, ptr %l152, !tbaa !21
  br i1 %t279, label %bb61, label %bb62
bb61:
  %t280 = load ptr, ptr %l7, !tbaa !29
  %t282 = getelementptr %"compiler/typed:Plan", ptr %t280, i32 0, i32 0
  %t283 = load { i64, ptr }, ptr %t282, !tbaa !27
  store { i64, ptr } %t283, ptr %l164, !tbaa !27
  %t284 = load ptr, ptr %l16, !tbaa !29
  %t286 = getelementptr %"compiler/typed:Collect", ptr %t284, i32 0, i32 2
  %t287 = load i32, ptr %t286, !tbaa !23
  %t289 = sext i32 %t287 to i64
  %t290 = load { i64, [1 x i64] }, ptr %l8
  %t293 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr { i64, [1 x i64] }, ptr %t294, i64 %t289
  store { i64, [1 x i64] } %t290, ptr %t295
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb170
bb64:
  %t296 = load ptr, ptr %l2, !tbaa !29
  store ptr %t296, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t297 = load ptr, ptr %l169, !tbaa !29
  %t298 = icmp ne ptr %t297, null
  br i1 %t298, label %bb65, label %bb66
bb65:
  %t300 = load ptr, ptr %l169, !tbaa !29
  %t301 = load i64, ptr %t300, !range !{i64 0, i64 18}
  %t303 = icmp eq i64 %t301, 6
  store i1 %t303, ptr %l170, !tbaa !21
  br label %bb66
bb66:
  %t304 = load i1, ptr %l170, !tbaa !21
  br i1 %t304, label %bb67, label %bb68
bb67:
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t307 = getelementptr { i64, [5 x i64] }, ptr %t305, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t307, i32 0, i32 2
  %t309 = load ptr, ptr %t308
  store ptr %t309, ptr %l17, !tbaa !29
  br label %bb69
bb68:
  br label %bb145
bb69:
  %t311 = load ptr, ptr %l17, !tbaa !29
  %t313 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t311)
  store i64 %t313, ptr %l176
  br label %bb70
bb70:
  %t314 = load i64, ptr %l176, !tbaa !24
  store i64 %t314, ptr %l18, !tbaa !24
  %t315 = load i64, ptr %l18, !tbaa !24
  %t317 = icmp slt i64 %t315, 0
  br i1 %t317, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l179, !tbaa !21
  br label %bb73
bb72:
  %t319 = load ptr, ptr %l17, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Call", ptr %t319, i32 0, i32 2
  %t322 = load i32, ptr %t321, !tbaa !23
  %t324 = icmp slt i32 %t322, 0
  store i1 %t324, ptr %l179, !tbaa !21
  br label %bb73
bb73:
  %t326 = load i1, ptr %l179, !tbaa !21
  br i1 %t326, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb77
bb75:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/free:Free", ptr %t327, i32 0, i32 1
  %t330 = load i64, ptr %l18, !tbaa !24
  %t333 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t329, i64 %t330)
  store ptr %t333, ptr %l187
  br label %bb76
bb76:
  %t334 = load ptr, ptr %l187, !tbaa !29
  %t336 = getelementptr %"compiler/typed:Body", ptr %t334, i32 0, i32 11
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t339 = icmp eq ptr %t337, null
  store i1 %t339, ptr %l183, !tbaa !21
  br label %bb77
bb77:
  %t341 = load i1, ptr %l183, !tbaa !21
  br i1 %t341, label %bb78, label %bb79
bb78:
  br label %ret
bb79:
  br label %bb80
bb80:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load i64, ptr %l18, !tbaa !24
  %t346 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %t342, i64 %t343)
  store i64 %t346, ptr %l193
  br label %bb81
bb81:
  %t347 = load i64, ptr %l193, !tbaa !24
  store i64 %t347, ptr %l19, !tbaa !24
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t348)
  store ptr %t350, ptr %l195
  br label %bb82
bb82:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/free:Free", ptr %t351, i32 0, i32 1
  %t354 = load i64, ptr %l18, !tbaa !24
  %t357 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t353, i64 %t354)
  store ptr %t357, ptr %l199
  br label %bb83
bb83:
  %t358 = load ptr, ptr %l199, !tbaa !29
  %t360 = getelementptr %"compiler/typed:Body", ptr %t358, i32 0, i32 2
  %t361 = load i32, ptr %t360, !tbaa !23
  %t362 = load ptr, ptr %l195, !tbaa !29
  %t364 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t362, i32 %t361)
  store i64 %t364, ptr %l202
  br label %bb84
bb84:
  %t365 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t366 = load i64, ptr %l202, !tbaa !24
  %t368 = icmp eq i64 %t366, %t365
  store i1 %t368, ptr %l20, !tbaa !21
  %t370 = load i1, ptr %l5, !tbaa !21
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb85, label %bb86
bb85:
  %t374 = load i1, ptr %l20, !tbaa !21
  %t376 = xor i1 %t374, true
  store i1 %t376, ptr %l207, !tbaa !21
  br label %bb87
bb86:
  store i1 false, ptr %l207, !tbaa !21
  br label %bb87
bb87:
  %t378 = load i1, ptr %l207, !tbaa !21
  br i1 %t378, label %bb88, label %bb89
bb88:
  %t379 = load i1, ptr %l6, !tbaa !21
  %t381 = xor i1 %t379, true
  store i1 %t381, ptr %l210, !tbaa !21
  br label %bb90
bb89:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb90
bb90:
  %t383 = load i1, ptr %l210, !tbaa !21
  br i1 %t383, label %bb91, label %bb92
bb91:
  br label %ret
bb92:
  br label %bb93
bb93:
  %t384 = load i1, ptr %l5, !tbaa !21
  %t386 = xor i1 %t384, true
  br i1 %t386, label %bb94, label %bb95
bb94:
  %t388 = load ptr, ptr %l7, !tbaa !29
  %t389 = load ptr, ptr %l17, !tbaa !29
  %t391 = getelementptr %"compiler/typed:Call", ptr %t389, i32 0, i32 2
  %t392 = load i32, ptr %t391, !tbaa !23
  %t393 = load i64, ptr %l19, !tbaa !24
  %t397 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t388, i32 %t392, i64 %t393)
  store { i64, [1 x i64] } %t397, ptr %l220
  br label %bb96
bb95:
  store i1 false, ptr %l215, !tbaa !21
  br label %bb98
bb96:
  %t398 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t398, ptr %l222
  %t401 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l220, ptr %l222)
  store i1 %t401, ptr %l224
  br label %bb97
bb97:
  %t402 = load i1, ptr %l224, !tbaa !21
  %t403 = xor i1 %t402, true
  store i1 %t403, ptr %l215, !tbaa !21
  br label %bb98
bb98:
  %t405 = load i1, ptr %l215, !tbaa !21
  br i1 %t405, label %bb99, label %bb100
bb99:
  br label %ret
bb100:
  br label %bb101
bb101:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load i64, ptr %l1, !tbaa !24
  %t408 = load ptr, ptr %l17, !tbaa !29
  %t409 = load i64, ptr %l18, !tbaa !24
  %t410 = load { i64, [1 x i64] }, ptr %l4
  %t411 = load i64, ptr %l19, !tbaa !24
  %t418 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %t406, i64 %t407, ptr %t408, i64 %t409, { i64, [1 x i64] } %t410, i64 %t411)
  store i64 %t418, ptr %l232
  br label %bb102
bb102:
  %t419 = load i64, ptr %l232, !tbaa !24
  store i64 %t419, ptr %l21, !tbaa !24
  %t420 = load i64, ptr %l21, !tbaa !24
  %t422 = icmp slt i64 %t420, 0
  br i1 %t422, label %bb103, label %bb104
bb103:
  br label %ret
bb104:
  br label %bb105
bb105:
  store i64 0, ptr %l22, !tbaa !24
  store i64 63, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t424 = load i64, ptr %l23, !tbaa !24
  %t425 = load i64, ptr %l22, !tbaa !24
  %t428 = icmp sgt i64 %t424, %t425
  br i1 %t428, label %bb106, label %bb107
bb106:
  %t430 = load i64, ptr %l24, !tbaa !24
  %t432 = icmp sgt i64 %t430, 0
  br i1 %t432, label %bb108, label %bb109
bb107:
  store i64 0, ptr %l238, !tbaa !24
  br label %bb111
bb108:
  %t434 = load i64, ptr %l23, !tbaa !24
  %t435 = load i64, ptr %l22, !tbaa !24
  %t438 = sub i64 %t434, %t435
  %t439 = load i64, ptr %l24, !tbaa !24
  %t442 = add i64 %t438, %t439
  %t444 = sub i64 %t442, 1
  %t445 = load i64, ptr %l24, !tbaa !24
  %t448 = sdiv i64 %t444, %t445
  store i64 %t448, ptr %l241, !tbaa !24
  br label %bb110
bb109:
  store i64 0, ptr %l241, !tbaa !24
  br label %bb110
bb110:
  %t450 = load i64, ptr %l241, !tbaa !24
  store i64 %t450, ptr %l238, !tbaa !24
  br label %bb111
bb111:
  %t451 = load i64, ptr %l238, !tbaa !24
  store i64 %t451, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb112
bb112:
  %t452 = load i64, ptr %l26, !tbaa !24
  %t453 = load i64, ptr %l25, !tbaa !24
  %t456 = icmp slt i64 %t452, %t453
  %t458 = xor i1 %t456, true
  br i1 %t458, label %bb113, label %bb114
bb113:
  br label %bb121
bb114:
  br label %bb115
bb115:
  %t460 = load i64, ptr %l22, !tbaa !24
  %t461 = load i64, ptr %l26, !tbaa !24
  %t462 = load i64, ptr %l24, !tbaa !24
  %t465 = mul i64 %t461, %t462
  %t468 = add i64 %t460, %t465
  store i64 %t468, ptr %l27, !tbaa !24
  %t470 = load i64, ptr %l21, !tbaa !24
  %t471 = load i64, ptr %l27, !tbaa !24
  store i64 %t471, ptr %l260, !tbaa !24
  %t472 = load i64, ptr %l260, !tbaa !24
  %t473 = load i64, ptr %l260, !tbaa !24
  %t474 = shl i64 1, %t473
  %t477 = and i64 %t470, %t474
  %t479 = icmp ne i64 %t477, 0
  br i1 %t479, label %bb116, label %bb117
bb116:
  %t481 = load ptr, ptr %l7, !tbaa !29
  %t482 = load ptr, ptr %l17, !tbaa !29
  %t484 = getelementptr %"compiler/typed:Call", ptr %t482, i32 0, i32 2
  %t485 = load i32, ptr %t484, !tbaa !23
  %t486 = load i64, ptr %l27, !tbaa !24
  %t487 = load { i64, [1 x i64] }, ptr %l8
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %t481, i32 %t485, i64 %t486, { i64, [1 x i64] } %t487)
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t492 = load i64, ptr %l26, !tbaa !24
  %t494 = add i64 %t492, 1
  store i64 %t494, ptr %l26, !tbaa !24
  br label %bb112
bb121:
  store i64 0, ptr %l28, !tbaa !24
  %t496 = load ptr, ptr %l17, !tbaa !29
  %t498 = getelementptr %"compiler/typed:Call", ptr %t496, i32 0, i32 1
  %t499 = load { i64, ptr }, ptr %t498, !tbaa !27
  %t501 = extractvalue { i64, ptr } %t499, 0
  store i64 %t501, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t503 = load i64, ptr %l29, !tbaa !24
  %t504 = load i64, ptr %l28, !tbaa !24
  %t507 = icmp sgt i64 %t503, %t504
  br i1 %t507, label %bb122, label %bb123
bb122:
  %t509 = load i64, ptr %l30, !tbaa !24
  %t511 = icmp sgt i64 %t509, 0
  br i1 %t511, label %bb124, label %bb125
bb123:
  store i64 0, ptr %l277, !tbaa !24
  br label %bb127
bb124:
  %t513 = load i64, ptr %l29, !tbaa !24
  %t514 = load i64, ptr %l28, !tbaa !24
  %t517 = sub i64 %t513, %t514
  %t518 = load i64, ptr %l30, !tbaa !24
  %t521 = add i64 %t517, %t518
  %t523 = sub i64 %t521, 1
  %t524 = load i64, ptr %l30, !tbaa !24
  %t527 = sdiv i64 %t523, %t524
  store i64 %t527, ptr %l280, !tbaa !24
  br label %bb126
bb125:
  store i64 0, ptr %l280, !tbaa !24
  br label %bb126
bb126:
  %t529 = load i64, ptr %l280, !tbaa !24
  store i64 %t529, ptr %l277, !tbaa !24
  br label %bb127
bb127:
  %t530 = load i64, ptr %l277, !tbaa !24
  store i64 %t530, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb128
bb128:
  %t531 = load i64, ptr %l32, !tbaa !24
  %t532 = load i64, ptr %l31, !tbaa !24
  %t535 = icmp slt i64 %t531, %t532
  %t537 = xor i1 %t535, true
  br i1 %t537, label %bb129, label %bb130
bb129:
  br label %bb144
bb130:
  br label %bb131
bb131:
  %t539 = load i64, ptr %l28, !tbaa !24
  %t540 = load i64, ptr %l32, !tbaa !24
  %t541 = load i64, ptr %l30, !tbaa !24
  %t544 = mul i64 %t540, %t541
  %t547 = add i64 %t539, %t544
  store i64 %t547, ptr %l33, !tbaa !24
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t550 = load i64, ptr %l18, !tbaa !24
  %t551 = load i64, ptr %l33, !tbaa !24
  %t555 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t549, i64 %t550, i64 %t551)
  store i64 %t555, ptr %l301
  br label %bb132
bb132:
  %t556 = load i64, ptr %l301, !tbaa !24
  store i64 %t556, ptr %l34, !tbaa !24
  %t557 = load i64, ptr %l34, !tbaa !24
  %t559 = icmp sge i64 %t557, 0
  br i1 %t559, label %bb133, label %bb134
bb133:
  %t561 = load i64, ptr %l34, !tbaa !24
  %t563 = icmp slt i64 %t561, 63
  store i1 %t563, ptr %l304, !tbaa !21
  br label %bb135
bb134:
  store i1 false, ptr %l304, !tbaa !21
  br label %bb135
bb135:
  %t565 = load i1, ptr %l304, !tbaa !21
  br i1 %t565, label %bb136, label %bb137
bb136:
  %t566 = load i64, ptr %l21, !tbaa !24
  %t567 = load i64, ptr %l34, !tbaa !24
  store i64 %t567, ptr %l309, !tbaa !24
  %t568 = load i64, ptr %l309, !tbaa !24
  %t569 = load i64, ptr %l309, !tbaa !24
  %t570 = shl i64 1, %t569
  %t573 = and i64 %t566, %t570
  %t575 = icmp ne i64 %t573, 0
  store i1 %t575, ptr %l307, !tbaa !21
  br label %bb138
bb137:
  store i1 false, ptr %l307, !tbaa !21
  br label %bb138
bb138:
  %t577 = load i1, ptr %l307, !tbaa !21
  br i1 %t577, label %bb139, label %bb140
bb139:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load i64, ptr %l1, !tbaa !24
  %t580 = load ptr, ptr %l17, !tbaa !29
  %t582 = getelementptr %"compiler/typed:Call", ptr %t580, i32 0, i32 1
  %t583 = load { i64, ptr }, ptr %t582, !tbaa !27
  store { i64, ptr } %t583, ptr %l316, !tbaa !27
  %t584 = load i64, ptr %l33, !tbaa !24
  %t586 = getelementptr { i64, ptr }, ptr %l316, i32 0, i32 1
  %t587 = load ptr, ptr %t586, !tbaa !27
  %t588 = getelementptr ptr, ptr %t587, i64 %t584
  %t589 = load ptr, ptr %t588, !tbaa !39
  %t590 = load i64, ptr %l3, !tbaa !24
  %t591 = load { i64, [1 x i64] }, ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t578, i64 %t579, ptr %t589, i64 %t590, { i64, [1 x i64] } %t591, i1 false, i1 false)
  br label %bb141
bb140:
  br label %bb142
bb141:
  br label %bb142
bb142:
  br label %bb143
bb143:
  %t597 = load i64, ptr %l32, !tbaa !24
  %t599 = add i64 %t597, 1
  store i64 %t599, ptr %l32, !tbaa !24
  br label %bb128
bb144:
  br label %bb170
bb145:
  %t601 = load ptr, ptr %l2, !tbaa !29
  store ptr %t601, ptr %l323, !tbaa !29
  store i1 false, ptr %l324, !tbaa !21
  %t602 = load ptr, ptr %l323, !tbaa !29
  %t603 = icmp ne ptr %t602, null
  br i1 %t603, label %bb146, label %bb147
bb146:
  %t605 = load ptr, ptr %l323, !tbaa !29
  %t606 = load i64, ptr %t605, !range !{i64 0, i64 18}
  %t608 = icmp eq i64 %t606, 17
  store i1 %t608, ptr %l324, !tbaa !21
  br label %bb147
bb147:
  %t609 = load i1, ptr %l324, !tbaa !21
  br i1 %t609, label %bb148, label %bb149
bb148:
  %t610 = load ptr, ptr %l2, !tbaa !29
  %t612 = getelementptr { i64, [5 x i64] }, ptr %t610, i32 0, i32 1
  %t613 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t612, i32 0, i32 2
  %t614 = load ptr, ptr %t613
  store ptr %t614, ptr %l35, !tbaa !29
  br label %bb150
bb149:
  br label %bb152
bb150:
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t617 = load i64, ptr %l1, !tbaa !24
  %t618 = load ptr, ptr %l35, !tbaa !29
  %t619 = load i64, ptr %l3, !tbaa !24
  %t620 = load { i64, [1 x i64] }, ptr %l4
  %t621 = load i1, ptr %l5, !tbaa !21
  %t622 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t616, i64 %t617, ptr %t618, i64 %t619, { i64, [1 x i64] } %t620, i1 %t621, i1 %t622)
  br label %bb151
bb151:
  br label %bb170
bb152:
  %t630 = load ptr, ptr %l2, !tbaa !29
  store ptr %t630, ptr %l336, !tbaa !29
  store i1 false, ptr %l337, !tbaa !21
  %t631 = load ptr, ptr %l336, !tbaa !29
  %t632 = icmp ne ptr %t631, null
  br i1 %t632, label %bb153, label %bb154
bb153:
  %t634 = load ptr, ptr %l336, !tbaa !29
  %t635 = load i64, ptr %t634, !range !{i64 0, i64 18}
  %t637 = icmp eq i64 %t635, 12
  store i1 %t637, ptr %l337, !tbaa !21
  br label %bb154
bb154:
  %t638 = load i1, ptr %l337, !tbaa !21
  br i1 %t638, label %bb155, label %bb156
bb155:
  %t639 = load ptr, ptr %l2, !tbaa !29
  %t641 = getelementptr { i64, [5 x i64] }, ptr %t639, i32 0, i32 1
  %t642 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t641, i32 0, i32 2
  %t643 = load ptr, ptr %t642
  store ptr %t643, ptr %l36, !tbaa !29
  br label %bb157
bb156:
  br label %bb165
bb157:
  %t645 = load ptr, ptr %l36, !tbaa !29
  %t647 = getelementptr %"compiler/typed:Seq", ptr %t645, i32 0, i32 1
  %t648 = load ptr, ptr %t647, !tbaa !29
  %t650 = icmp eq ptr %t648, null
  %t652 = xor i1 %t650, true
  br i1 %t652, label %bb158, label %bb159
bb158:
  %t654 = load ptr, ptr %l0, !tbaa !29
  store ptr %t654, ptr %l346, !tbaa !29
  %t655 = load i64, ptr %l1, !tbaa !24
  store i64 %t655, ptr %l347, !tbaa !24
  %t656 = load ptr, ptr %l36, !tbaa !29
  %t658 = getelementptr %"compiler/typed:Seq", ptr %t656, i32 0, i32 1
  %t659 = load ptr, ptr %t658, !tbaa !29
  %t661 = icmp eq ptr %t659, null
  br i1 %t661, label %bb160, label %bb161
bb159:
  br label %bb164
bb160:
  call void @__olang_check_failed(ptr @olang_loc_21335a5a6f6a0d23_1fb4d5f27249eebf)
  unreachable
bb161:
  br label %bb162
bb162:
  %t663 = load ptr, ptr %l36, !tbaa !29
  %t665 = getelementptr %"compiler/typed:Seq", ptr %t663, i32 0, i32 1
  %t666 = load ptr, ptr %t665, !tbaa !29
  %t667 = load i64, ptr %l3, !tbaa !24
  %t668 = load { i64, [1 x i64] }, ptr %l4
  %t669 = load i1, ptr %l5, !tbaa !21
  %t670 = load i1, ptr %l6, !tbaa !21
  %t671 = load ptr, ptr %l346, !tbaa !29
  %t672 = load i64, ptr %l347, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t671, i64 %t672, ptr %t666, i64 %t667, { i64, [1 x i64] } %t668, i1 %t669, i1 %t670)
  br label %bb163
bb163:
  br label %bb164
bb164:
  br label %bb170
bb165:
  br i1 true, label %bb166, label %bb167
bb166:
  br label %bb168
bb167:
  br label %bb169
bb168:
  br label %bb170
bb169:
  call void @__olang_check_failed(ptr @olang_loc_80551b5782bfdb3b_907a9dbefd6aabe7)
  unreachable
bb170:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i32
  %l33 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l51 = alloca i1
  %l58 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb4:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l15
  br label %bb5
bb5:
  %t18 = load i1, ptr %l15, !tbaa !21
  store i1 %t18, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l19
  br label %bb9
bb9:
  %t25 = load i1, ptr %l19, !tbaa !21
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l24
  br label %bb14
bb14:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l24, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l25
  br label %bb15
bb15:
  %t37 = load i32, ptr %l25, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l28
  br label %bb16
bb16:
  %t43 = load i32, ptr %l28, !range !{i32 0, i32 33}
  store i32 %t43, ptr %l4
  %t44 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t46 = trunc i64 19 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l33
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t54 = load i1, ptr %l33, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
bb20:
  %t55 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t57 = trunc i64 18 to i32
  %t58 = icmp eq i32 %t55, %t57
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb24
bb22:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l40
  br label %bb23
bb23:
  %t67 = load i1, ptr %l40, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t70 = load i1, ptr %l37, !tbaa !21
  br i1 %t70, label %bb25, label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t72 = load ptr, ptr %l2, !tbaa !29
  store ptr %t72, ptr %l43, !tbaa !29
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t74 = load i32, ptr %l3, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l46
  br label %bb28
bb28:
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t79 = load i32, ptr %l46, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t80, ptr %l47
  br label %bb29
bb29:
  %t81 = load i32, ptr %l47, !range !{i32 0, i32 6}
  store i32 %t81, ptr %l5
  %t82 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t84 = trunc i64 0 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb30, label %bb31
bb30:
  %t89 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t91 = trunc i64 1 to i32
  %t92 = icmp eq i32 %t89, %t91
  %t94 = xor i1 %t92, true
  store i1 %t94, ptr %l51, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t96 = load i1, ptr %l51, !tbaa !21
  br i1 %t96, label %bb33, label %bb34
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t98, i32 %t99)
  store i1 %t102, ptr %l58
  br label %bb36
bb36:
  %t103 = load i1, ptr %l58, !tbaa !21
  store i1 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l28 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i64
  %l39 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i64
  %l49 = alloca i1
  %l55 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = add i64 %t1, 2
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb30
bb3:
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t13, ptr %l15, !tbaa !27
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i64, ptr %t17, i64 %t14
  %t19 = load i64, ptr %t18, !tbaa !34
  store i64 %t19, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i64, ptr %t27, i64 %t24
  %t29 = load i64, ptr %t28, !tbaa !34
  store i64 %t29, ptr %l5, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t32, 2
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i64, ptr %t37, i64 %t34
  %t39 = load i64, ptr %t38, !tbaa !34
  store i64 %t39, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = icmp sge i64 %t41, 0
  br i1 %t43, label %bb5, label %bb6
bb5:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp slt i64 %t45, 63
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t49 = load i1, ptr %l28, !tbaa !21
  br i1 %t49, label %bb8, label %bb9
bb8:
  %t50 = load i64, ptr %l2, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  store i64 %t51, ptr %l33, !tbaa !24
  %t52 = load i64, ptr %l33, !tbaa !24
  %t53 = load i64, ptr %l33, !tbaa !24
  %t54 = shl i64 1, %t53
  %t57 = and i64 %t50, %t54
  %t59 = icmp ne i64 %t57, 0
  store i1 %t59, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t61 = load i1, ptr %l31, !tbaa !21
  store i1 %t61, ptr %l7, !tbaa !21
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = icmp sge i64 %t62, 0
  br i1 %t64, label %bb11, label %bb12
bb11:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = icmp slt i64 %t66, 63
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t70 = load i1, ptr %l39, !tbaa !21
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load i64, ptr %l5, !tbaa !24
  store i64 %t72, ptr %l44, !tbaa !24
  %t73 = load i64, ptr %l44, !tbaa !24
  %t74 = load i64, ptr %l44, !tbaa !24
  %t75 = shl i64 1, %t74
  %t78 = and i64 %t71, %t75
  %t80 = icmp ne i64 %t78, 0
  store i1 %t80, ptr %l42, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t82 = load i1, ptr %l42, !tbaa !21
  store i1 %t82, ptr %l8, !tbaa !21
  %t83 = load i1, ptr %l7, !tbaa !21
  br i1 %t83, label %bb17, label %bb18
bb17:
  %t85 = load i1, ptr %l8, !tbaa !21
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l49, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb19
bb19:
  %t89 = load i1, ptr %l49, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = icmp eq i64 %t91, 1
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = load i1, ptr %l7, !tbaa !21
  %t96 = load i1, ptr %l8, !tbaa !21
  %t99 = icmp ne i1 %t95, %t96
  store i1 %t99, ptr %l55, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb25
bb25:
  %t101 = load i1, ptr %l55, !tbaa !21
  br i1 %t101, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t103 = load i64, ptr %l3, !tbaa !24
  %t105 = add i64 %t103, 3
  store i64 %t105, ptr %l3, !tbaa !24
  br label %bb1
bb30:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erowBefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1, %"compiler/free:letGo" %a2) #0 {
entry:
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca %"compiler/free:letGo"
  %l16 = alloca i1
  %rv = alloca i1
  store %"compiler/free:letGo" %a1, ptr %l1
  store %"compiler/free:letGo" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 5
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t6 = icmp eq i64 %t2, %t3
  %t7 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 5
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t12 = icmp eq i64 %t8, %t9
  %t15 = icmp ne i1 %t6, %t12
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 5
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t22 = icmp eq i64 %t18, %t19
  store i1 %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t25 = load %"compiler/free:letGo", ptr %l1
  %t26 = load %"compiler/free:letGo", ptr %l2
  %t30 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %t25, %"compiler/free:letGo" %t26)
  store i1 %t30, ptr %l16
  br label %bb4
bb4:
  %t31 = load i1, ptr %l16, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esave(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l35 = alloca i64
  %l40 = alloca i64
  %l44 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l73 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca i64
  %l82 = alloca i64
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 3
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v1, ptr %t3)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 3
  store ptr %t9, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l6, !tbaa !24
  store i64 %t11, ptr %l25, !tbaa !24
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l27
  br label %bb3
bb3:
  %t15 = load i64, ptr %l25, !tbaa !24
  %t16 = load i64, ptr %l27, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v1, ptr %v1, ptr %t21, i64 %t22)
  store ptr %t25, ptr %l32
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l32, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  store i64 %t27, ptr %l33, !tbaa !24
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t26)
  store i64 %t30, ptr %l35
  br label %bb8
bb8:
  %t31 = load i64, ptr %l33, !tbaa !24
  %t32 = load i64, ptr %l35, !tbaa !24
  %t33 = add i64 %t31, %t32
  store i64 %t33, ptr %l4, !tbaa !24
  br label %bb9
bb9:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l6, !tbaa !24
  br label %bb2
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l40, !tbaa !24
  %t42 = load i64, ptr %l40, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = load i64, ptr %l40, !tbaa !24
  %t46 = icmp sle i64 %t45, 1152921504606846975
  br i1 %t46, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_cba1607a5f8c25be_1da50212bb736ed2)
  unreachable
bb13:
  %t48 = load i64, ptr %l40, !tbaa !24
  %t49 = mul i64 %t48, 8
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l8, !tbaa !27
  %t54 = load i64, ptr %l4, !tbaa !24
  store i64 %t54, ptr %l44, !tbaa !24
  %t55 = load i64, ptr %l44, !tbaa !24
  %t56 = icmp sge i64 %t55, 0
  br i1 %t56, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_cba1607a5f8c25be_1da50212bb736ed2)
  unreachable
bb15:
  %t58 = load i64, ptr %l44, !tbaa !24
  %t59 = icmp sle i64 %t58, 1152921504606846975
  br i1 %t59, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a35b07018a31f4f3_69e61a5b7415d1c7)
  unreachable
bb17:
  %t61 = load i64, ptr %l44, !tbaa !24
  %t62 = mul i64 %t61, 8
  %t63 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t67 = load i64, ptr %l3, !tbaa !24
  store i64 %t67, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t69 = load i64, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_a35b07018a31f4f3_69e61a5b7415d1c7)
  unreachable
bb19:
  %t75 = load i64, ptr %l13, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb24
bb21:
  %t79 = load i64, ptr %l12, !tbaa !24
  %t80 = load i64, ptr %l11, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l13, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l13, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l55, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb23
bb23:
  %t95 = load i64, ptr %l55, !tbaa !24
  store i64 %t95, ptr %l52, !tbaa !24
  br label %bb24
bb24:
  %t96 = load i64, ptr %l52, !tbaa !24
  store i64 %t96, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb25
bb25:
  %t97 = load i64, ptr %l15, !tbaa !24
  %t98 = load i64, ptr %l14, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb26, label %bb27
bb26:
  br label %bb39
bb27:
  br label %bb28
bb28:
  %t105 = load i64, ptr %l11, !tbaa !24
  %t106 = load i64, ptr %l15, !tbaa !24
  %t107 = load i64, ptr %l13, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l16, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t115, ptr %l73, !tbaa !27
  %t116 = load i64, ptr %l16, !tbaa !24
  %t117 = load i64, ptr %l10, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i64, ptr %t121, i64 %t116
  store i64 %t117, ptr %t122, !tbaa !34
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/free:walker", ptr %t123, i32 0, i32 3
  %t126 = load i64, ptr %l16, !tbaa !24
  %t129 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v1, ptr %v1, ptr %t125, i64 %t126)
  store ptr %t129, ptr %l79
  br label %bb29
bb29:
  %t130 = load ptr, ptr %l79, !tbaa !29
  store ptr %t130, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb30
bb30:
  %t131 = load i64, ptr %l18, !tbaa !24
  store i64 %t131, ptr %l80, !tbaa !24
  %t132 = load ptr, ptr %l17, !tbaa !29
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t132)
  store i64 %t134, ptr %l82
  br label %bb31
bb31:
  %t135 = load i64, ptr %l80, !tbaa !24
  %t136 = load i64, ptr %l82, !tbaa !24
  %t137 = icmp slt i64 %t135, %t136
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t141 = load ptr, ptr %l17, !tbaa !29
  %t142 = load i64, ptr %l18, !tbaa !24
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t141, i64 %t142)
  store i64 %t145, ptr %l87
  br label %bb35
bb35:
  %t146 = load i64, ptr %l87, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t147, ptr %l88, !tbaa !27
  %t148 = load i64, ptr %l10, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i64, ptr %t153, i64 %t148
  store i64 %t146, ptr %t154, !tbaa !34
  %t155 = load i64, ptr %l10, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l10, !tbaa !24
  br label %bb36
bb36:
  %t159 = load i64, ptr %l18, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l18, !tbaa !24
  br label %bb30
bb37:
  br label %bb38
bb38:
  %t163 = load i64, ptr %l15, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l15, !tbaa !24
  br label %bb25
bb39:
  %t167 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t167, ptr %l97, !tbaa !27
  %t168 = load i64, ptr %l3, !tbaa !24
  %t169 = load i64, ptr %l10, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i64, ptr %t173, i64 %t168
  store i64 %t169, ptr %t174, !tbaa !34
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/free:Free", ptr %t175, i32 0, i32 57
  %t178 = load i64, ptr %l2, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t177, i64 %t178, { i64, ptr } %t179)
  br label %bb40
bb40:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/free:Free", ptr %t183, i32 0, i32 58
  %t186 = load i64, ptr %l2, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t185, i64 %t186, { i64, ptr } %t187)
  br label %bb41
bb41:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estoredMore(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i64
  %l29 = alloca i1
  %l33 = alloca ptr
  %l35 = alloca i1
  %l36 = alloca i1
  %l40 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l49 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i1
  %l58 = alloca ptr
  %l60 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 25
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l5, !tbaa !24
  store i64 %t9, ptr %l11, !tbaa !24
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l13
  br label %bb3
bb3:
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l13, !tbaa !24
  %t15 = icmp slt i64 %t13, %t14
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb12
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t19, i64 %t20)
  store i64 %t23, ptr %l18
  br label %bb7
bb7:
  %t24 = load i64, ptr %l18, !tbaa !24
  %t27 = ashr i64 %t24, 32
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp eq i64 %t27, %t28
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l5, !tbaa !24
  br label %bb2
bb12:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = icmp sgt i64 %t41, 1
  br i1 %t43, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb17
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/free:Free", ptr %t45, i32 0, i32 26
  %t48 = load i64, ptr %l1, !tbaa !24
  %t51 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t47, i64 %t48)
  store ptr %t51, ptr %l33
  br label %bb15
bb15:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t53 = load ptr, ptr %l33, !tbaa !29
  %t55 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t53, i64 %t52)
  store i1 %t55, ptr %l35
  br label %bb16
bb16:
  %t56 = load i1, ptr %l35, !tbaa !21
  store i1 %t56, ptr %l29, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l29, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb23
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/free:Free", ptr %t58, i32 0, i32 24
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store ptr %t64, ptr %l40
  br label %bb20
bb20:
  %t65 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t66 = load i64, ptr %l2, !tbaa !24
  %t69 = call i64 @compiler_2ffree_2eorig(i64 %t65, i64 %t66)
  store i64 %t69, ptr %l43
  br label %bb21
bb21:
  %t70 = load ptr, ptr %l40, !tbaa !29
  %t71 = load i64, ptr %l43, !tbaa !24
  %t72 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t70, i64 %t71)
  store i1 %t72, ptr %l44
  br label %bb22
bb22:
  %t73 = load i1, ptr %l44, !tbaa !21
  store i1 %t73, ptr %l36, !tbaa !21
  br label %bb23
bb23:
  %t74 = load i1, ptr %l36, !tbaa !21
  br i1 %t74, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb29
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/free:Free", ptr %t75, i32 0, i32 24
  %t78 = load i64, ptr %l1, !tbaa !24
  %t81 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t77, i64 %t78)
  store ptr %t81, ptr %l49
  br label %bb26
bb26:
  %t82 = load i64, ptr @G_2ecompiler_2ffree_2eOParC, !tbaa !24
  %t83 = load i64, ptr %l2, !tbaa !24
  %t86 = call i64 @compiler_2ffree_2eorig(i64 %t82, i64 %t83)
  store i64 %t86, ptr %l52
  br label %bb27
bb27:
  %t87 = load ptr, ptr %l49, !tbaa !29
  %t88 = load i64, ptr %l52, !tbaa !24
  %t89 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t87, i64 %t88)
  store i1 %t89, ptr %l53
  br label %bb28
bb28:
  %t90 = load i1, ptr %l53, !tbaa !21
  store i1 %t90, ptr %l45, !tbaa !21
  br label %bb29
bb29:
  %t91 = load i1, ptr %l45, !tbaa !21
  br i1 %t91, label %bb30, label %bb31
bb30:
  store i1 true, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/free:Free", ptr %t93, i32 0, i32 28
  %t96 = load i64, ptr %l1, !tbaa !24
  %t99 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t95, i64 %t96)
  store ptr %t99, ptr %l58
  br label %bb33
bb33:
  %t100 = load i64, ptr %l2, !tbaa !24
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t103 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t101, i64 %t100)
  store i1 %t103, ptr %l60
  br label %bb34
bb34:
  %t104 = load i1, ptr %l60, !tbaa !21
  store i1 %t104, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i1
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l28 = alloca ptr
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca ptr
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %s0 = alloca %olang.scope
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = call i64 @compiler_2ffree_2eokind(i64 %t1)
  store i64 %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load i64, ptr %l7, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @compiler_2ffree_2eoval(i64 %t5)
  store i64 %t7, ptr %l9
  br label %bb2
bb2:
  %t8 = load i64, ptr %l9, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t13 = icmp ne i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr @G_2ecompiler_2ffree_2eOParC, !tbaa !24
  %t19 = icmp ne i64 %t15, %t16
  store i1 %t19, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l13, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t22, i64 %t23)
  store i64 %t26, ptr %l19
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t27 = load i64, ptr %l5, !tbaa !24
  store i64 %t27, ptr %l20, !tbaa !24
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v1, ptr %t28)
  store i64 %t30, ptr %l22
  br label %bb10
bb10:
  %t31 = load i64, ptr %l20, !tbaa !24
  %t32 = load i64, ptr %l22, !tbaa !24
  %t33 = icmp sge i64 %t31, %t32
  br i1 %t33, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t35 = load ptr, ptr %l3, !tbaa !29
  store ptr %t35, ptr %l24, !tbaa !29
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t40 = icmp eq i64 %t36, %t37
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v1, ptr %s0, ptr %t42, i64 %t43)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l31
  br label %bb16
bb15:
  store ptr %a0, ptr %l35, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v1, ptr %v1, ptr %t48, i64 %t49)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l38
  br label %bb18
bb16:
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l31)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l33
  br label %bb17
bb17:
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t56 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %t56
  store ptr %t56, ptr %l28, !tbaa !29
  br label %bb21
bb18:
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v1, ptr %l38)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l40
  br label %bb19
bb19:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  %t61 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t61
  %t62 = load ptr, ptr %l35, !tbaa !29
  %t64 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %v1, ptr %s0, ptr %t62, ptr %t61)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l42
  br label %bb20
bb20:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  %t66 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %t66
  store ptr %t66, ptr %l28, !tbaa !29
  br label %bb21
bb21:
  %t68 = load ptr, ptr %l24, !tbaa !29
  %t69 = load ptr, ptr %l28, !tbaa !29
  %t70 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s0, ptr %t68, ptr %t69)
  store i64 %t70, ptr %l44
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca i64
  %l75 = alloca ptr
  %l81 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 1
  %t19 = load i32, ptr %t18, !tbaa !23
  %t21 = sext i32 %t19 to i64
  store i64 %t21, ptr %l9, !tbaa !24
  br label %bb55
bb6:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 7
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Make", ptr %t38, i32 0, i32 4
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  store i64 %t43, ptr %l9, !tbaa !24
  br label %bb55
bb12:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l28, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 18}
  %t52 = icmp eq i64 %t50, 16
  store i1 %t52, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l29, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Text", ptr %t60, i32 0, i32 1
  %t63 = load i32, ptr %t62, !tbaa !23
  %t65 = sext i32 %t63 to i64
  store i64 %t65, ptr %l9, !tbaa !24
  br label %bb55
bb18:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 18}
  %t74 = icmp eq i64 %t72, 8
  store i1 %t74, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l38, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [5 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Collect", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = sext i32 %t85 to i64
  store i64 %t87, ptr %l9, !tbaa !24
  br label %bb55
bb24:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb25, label %bb26
bb25:
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 18}
  %t96 = icmp eq i64 %t94, 6
  store i1 %t96, ptr %l47, !tbaa !21
  br label %bb26
bb26:
  %t97 = load i1, ptr %l47, !tbaa !21
  br i1 %t97, label %bb27, label %bb28
bb27:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [5 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Call", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %t106, !tbaa !23
  %t109 = sext i32 %t107 to i64
  store i64 %t109, ptr %l9, !tbaa !24
  br label %bb55
bb30:
  %t111 = load ptr, ptr %l1, !tbaa !29
  store ptr %t111, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t112 = load ptr, ptr %l55, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb31, label %bb32
bb31:
  %t115 = load ptr, ptr %l55, !tbaa !29
  %t116 = load i64, ptr %t115, !range !{i64 0, i64 18}
  %t118 = icmp eq i64 %t116, 17
  store i1 %t118, ptr %l56, !tbaa !21
  br label %bb32
bb32:
  %t119 = load i1, ptr %l56, !tbaa !21
  br i1 %t119, label %bb33, label %bb34
bb33:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t122, i32 0, i32 2
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l7, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t130 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t126, ptr %t127)
  store i64 %t130, ptr %l63
  br label %bb36
bb36:
  %t131 = load i64, ptr %l63, !tbaa !24
  store i64 %t131, ptr %l9, !tbaa !24
  br label %bb55
bb37:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t133 = load ptr, ptr %l64, !tbaa !29
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %bb38, label %bb39
bb38:
  %t136 = load ptr, ptr %l64, !tbaa !29
  %t137 = load i64, ptr %t136, !range !{i64 0, i64 18}
  %t139 = icmp eq i64 %t137, 12
  store i1 %t139, ptr %l65, !tbaa !21
  br label %bb39
bb39:
  %t140 = load i1, ptr %l65, !tbaa !21
  br i1 %t140, label %bb40, label %bb41
bb40:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t143, i32 0, i32 2
  %t145 = load ptr, ptr %t144
  store ptr %t145, ptr %l8, !tbaa !29
  br label %bb42
bb41:
  br label %bb50
bb42:
  %t147 = load ptr, ptr %l8, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Seq", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb43, label %bb44
bb43:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l75, !tbaa !29
  %t157 = load ptr, ptr %l8, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Seq", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  br i1 %t162, label %bb45, label %bb46
bb44:
  store i64 -1, ptr %l74, !tbaa !24
  br label %bb49
bb45:
  call void @__olang_check_failed(ptr @olang_loc_2a5f6fd698855c53_bf46ca1a958c9ea7)
  unreachable
bb46:
  br label %bb47
bb47:
  %t164 = load ptr, ptr %l8, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Seq", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t168 = load ptr, ptr %l75, !tbaa !29
  %t170 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t168, ptr %t167)
  store i64 %t170, ptr %l81
  br label %bb48
bb48:
  %t171 = load i64, ptr %l81, !tbaa !24
  store i64 %t171, ptr %l74, !tbaa !24
  br label %bb49
bb49:
  %t172 = load i64, ptr %l74, !tbaa !24
  store i64 %t172, ptr %l9, !tbaa !24
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_4959d0728bd157ab_d85fd94b6e31a9bf)
  unreachable
bb55:
  %t173 = load i64, ptr %l9, !tbaa !24
  store i64 %t173, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l39 = alloca i64
  %l40 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 1
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l18
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l18, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t27, ptr %l2
  %t29 = load { i64, [2 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t35 = getelementptr { i64 }, ptr %t34, i32 0, i32 0
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/free:Free", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 6
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t46, i64 %t47)
  %t51 = extractvalue { i32, i64 } %t50, 1
  %t52 = extractvalue { i32, i64 } %t50, 0
  store i32 %t52, ptr %l32
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb13, label %ok.54, !prof !99
ok.54:
  store i64 %t51, ptr %l31
  br label %bb12
bb12:
  %t55 = load i64, ptr %l31, !tbaa !24
  store i64 %t55, ptr %l25, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb15
bb15:
  %t56 = load i64, ptr %l25, !tbaa !24
  store i64 %t56, ptr %l21, !tbaa !24
  br label %bb32
bb16:
  %t57 = load { i64, [2 x i64] }, ptr %l2
  %t59 = extractvalue { i64, [2 x i64] } %t57, 0
  %t60 = icmp eq i64 %t59, 1
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t62 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t63 = getelementptr { i32, i32 }, ptr %t62, i32 0, i32 0
  %t64 = load i32, ptr %t63
  store i32 %t64, ptr %l4, !tbaa !23
  %t66 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t67 = getelementptr { i32, i32 }, ptr %t66, i32 0, i32 1
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l5, !tbaa !23
  br label %bb19
bb18:
  br label %bb27
bb19:
  %t70 = load i32, ptr %l5, !tbaa !23
  %t72 = icmp eq i32 %t70, 0
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/load:Loader", ptr %t80, i32 0, i32 7
  %t83 = load i32, ptr %l4, !tbaa !23
  %t85 = sext i32 %t83 to i64
  %t88 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t82, i64 %t85)
  %t89 = extractvalue { i32, i64 } %t88, 1
  %t90 = extractvalue { i32, i64 } %t88, 0
  store i32 %t90, ptr %l48
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb23, label %ok.92, !prof !99
ok.92:
  store i64 %t89, ptr %l47
  br label %bb22
bb21:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb26
bb22:
  %t93 = load i64, ptr %l47, !tbaa !24
  store i64 %t93, ptr %l40, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb25
bb25:
  %t94 = load i64, ptr %l40, !tbaa !24
  store i64 %t94, ptr %l39, !tbaa !24
  br label %bb26
bb26:
  %t95 = load i64, ptr %l39, !tbaa !24
  store i64 %t95, ptr %l21, !tbaa !24
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_12d027853a0706eb_617ec39b0606fdd7)
  unreachable
bb32:
  %t96 = load i64, ptr %l21, !tbaa !24
  store i64 %t96, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewalk(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca i1
  %l26 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l35 = alloca i32
  %l38 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l61 = alloca ptr
  %l64 = alloca ptr
  %l67 = alloca ptr
  %l83 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l15
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l15, !tbaa !29
  store ptr %t19, ptr %l4, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %t23, !tbaa !23
  %t27 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t20, i32 %t24)
  store i64 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t29 = load i64, ptr %l19, !tbaa !24
  %t31 = icmp eq i64 %t29, %t28
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Body", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %t36, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t33, i32 %t37)
  store { i64, ptr } %t40, ptr %l26
  br label %bb9
bb8:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb10
bb9:
  %t41 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t44 = icmp eq i64 %t42, 1
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l22, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load ptr, ptr %l4, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Body", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t48, i32 %t52)
  store { i64, ptr } %t55, ptr %l33
  br label %bb13
bb12:
  br label %bb34
bb13:
  %t56 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i32, ptr %t57, i64 0
  %t59 = load i32, ptr %t58, !tbaa !33
  %t60 = load ptr, ptr %l29, !tbaa !29
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t60, i32 %t59)
  store i32 %t62, ptr %l35
  br label %bb14
bb14:
  %t63 = load i32, ptr %l35, !tbaa !23
  store i32 %t63, ptr %l5, !tbaa !23
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t65 = load i32, ptr %l5, !tbaa !23
  %t68 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t68, ptr %l38
  br label %bb15
bb15:
  %t69 = load i1, ptr %l38, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t70 = load ptr, ptr %l4, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t72 = load i32, ptr %l5, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l42
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t77 = load i32, ptr %l42, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t78, ptr %l43
  br label %bb19
bb19:
  %t79 = load i32, ptr %l43, !tbaa !23
  store i32 %t79, ptr %l5, !tbaa !23
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t81 = load i32, ptr %l5, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l46
  br label %bb21
bb21:
  %t85 = load i32, ptr %l46, !range !{i32 0, i32 33}
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t91 = load i32, ptr %l5, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l52
  br label %bb24
bb23:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb25
bb24:
  %t95 = load i1, ptr %l52, !tbaa !21
  store i1 %t95, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t96 = load i1, ptr %l49, !tbaa !21
  br i1 %t96, label %bb26, label %bb27
bb26:
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t98 = load i32, ptr %l5, !tbaa !23
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l56
  br label %bb28
bb27:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb29
bb28:
  %t102 = load i1, ptr %l56, !tbaa !21
  store i1 %t102, ptr %l53, !tbaa !21
  br label %bb29
bb29:
  %t103 = load i1, ptr %l53, !tbaa !21
  br i1 %t103, label %bb30, label %bb31
bb30:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t104, i64 %t105)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l1, !tbaa !24
  %t112 = call ptr @compiler_2ffree_2ewalker_2enewWalker(ptr %v0, ptr %v0, ptr %t108, i64 %t109, i1 false)
  store ptr %t112, ptr %l61
  br label %bb35
bb35:
  %t113 = load ptr, ptr %l61, !tbaa !29
  store ptr %t113, ptr %l6, !tbaa !29
  br label %bb36
bb36:
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = getelementptr %"compiler/free:walker", ptr %t114, i32 0, i32 5
  store i1 false, ptr %t116, !tbaa !21
  %t117 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %t117)
  br label %bb37
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l64, !tbaa !29
  %t120 = load ptr, ptr %l64, !tbaa !29
  %t121 = getelementptr %"compiler/free:Free", ptr %t120, i32 0, i32 4
  %t122 = load i64, ptr %t121, !tbaa !24
  %t124 = add i64 %t122, 1
  %t126 = load ptr, ptr %l64, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t126, i32 0, i32 4
  store i64 %t124, ptr %t127, !tbaa !24
  %t128 = load ptr, ptr %l6, !tbaa !29
  store ptr %t128, ptr %l67, !tbaa !29
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Body", ptr %t129, i32 0, i32 11
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_30cfd3b464a887aa_ca3830b5343a05a6)
  unreachable
bb39:
  br label %bb40
bb40:
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Body", ptr %t136, i32 0, i32 11
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t140 = load ptr, ptr %l67, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v0, ptr %t140, ptr %t139)
  br label %bb41
bb41:
  %t142 = load ptr, ptr %l6, !tbaa !29
  %t144 = getelementptr %"compiler/free:walker", ptr %t142, i32 0, i32 5
  %t145 = load i1, ptr %t144, !tbaa !21
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb36
bb46:
  %t149 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamPaths(ptr %v0, ptr %t149)
  br label %bb47
bb47:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l6, !tbaa !29
  %t153 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esave(ptr %v0, ptr %v0, ptr %t151, ptr %t152, i64 %t153)
  br label %bb48
bb48:
  br i1 %a2, label %bb49, label %bb50
bb49:
  %t159 = load ptr, ptr %l6, !tbaa !29
  %t161 = getelementptr %"compiler/free:walker", ptr %t159, i32 0, i32 2
  store i1 true, ptr %t161, !tbaa !21
  %t162 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %t162)
  br label %bb51
bb50:
  br label %bb57
bb51:
  %t164 = load ptr, ptr %l6, !tbaa !29
  store ptr %t164, ptr %l83, !tbaa !29
  %t165 = load ptr, ptr %l3, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Body", ptr %t165, i32 0, i32 11
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = icmp eq ptr %t168, null
  br i1 %t170, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_3a3557a9366273b1_8eafb121351cf8d)
  unreachable
bb53:
  br label %bb54
bb54:
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Body", ptr %t172, i32 0, i32 11
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t176 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v0, ptr %t176, ptr %t175)
  br label %bb55
bb55:
  %t178 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviews(ptr %v0, ptr %t178)
  br label %bb56
bb56:
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l51 = alloca i64
  %l54 = alloca i1
  %l58 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca ptr
  %l67 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l78 = alloca ptr
  %l81 = alloca i64
  %l84 = alloca i1
  %l94 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca i1
  %l116 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l133 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca i1
  %l143 = alloca i64
  %l144 = alloca ptr
  %l145 = alloca i1
  %l154 = alloca i1
  %l155 = alloca i64
  %l158 = alloca { i64, ptr }
  %l160 = alloca i64
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l18, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t6 = load ptr, ptr %l19, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l19, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l20, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t14 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
bb7:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t17 = load ptr, ptr %l24, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb8, label %bb9
bb8:
  %t20 = load ptr, ptr %l24, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l25, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t37 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t31, ptr %t32, ptr %t33)
  store i64 %t37, ptr %l33
  br label %bb13
bb13:
  %t38 = load i64, ptr %l33, !tbaa !24
  store i64 %t38, ptr %rv
  br label %ret
bb14:
  %t39 = load ptr, ptr %l2, !tbaa !29
  store ptr %t39, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t40 = load ptr, ptr %l34, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l34, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 18}
  %t46 = icmp eq i64 %t44, 3
  store i1 %t46, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l35, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l5, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t60 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t54, ptr %t55, ptr %t56)
  store i64 %t60, ptr %l43
  br label %bb20
bb20:
  %t61 = load i64, ptr %l43, !tbaa !24
  store i64 %t61, ptr %rv
  br label %ret
bb21:
  %t62 = load ptr, ptr %l2, !tbaa !29
  store ptr %t62, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t63 = load ptr, ptr %l44, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb22, label %bb23
bb22:
  %t66 = load ptr, ptr %l44, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 18}
  %t69 = icmp eq i64 %t67, 6
  store i1 %t69, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t70 = load i1, ptr %l45, !tbaa !21
  br i1 %t70, label %bb24, label %bb25
bb24:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l6, !tbaa !29
  br label %bb26
bb25:
  br label %bb49
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t79 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v2, ptr %t77)
  store i64 %t79, ptr %l51
  br label %bb27
bb27:
  %t80 = load i64, ptr %l51, !tbaa !24
  store i64 %t80, ptr %l7, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = icmp slt i64 %t81, 0
  br i1 %t83, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb31
bb29:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:Free", ptr %t85, i32 0, i32 1
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t87, i64 %t88)
  store ptr %t91, ptr %l58
  br label %bb30
bb30:
  %t92 = load ptr, ptr %l58, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Body", ptr %t92, i32 0, i32 11
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = icmp eq ptr %t95, null
  store i1 %t97, ptr %l54, !tbaa !21
  br label %bb31
bb31:
  %t99 = load i1, ptr %l54, !tbaa !21
  br i1 %t99, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb36
bb33:
  %t100 = load ptr, ptr %l3, !tbaa !29
  store ptr %t100, ptr %l63, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/free:Free", ptr %t101, i32 0, i32 1
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t103, i64 %t104)
  store ptr %t107, ptr %l67
  br label %bb34
bb34:
  %t108 = load ptr, ptr %l67, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Body", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %t110, !tbaa !23
  %t112 = load ptr, ptr %l63, !tbaa !29
  %t114 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s4, ptr %t112, i32 %t111)
  store { i64, ptr } %t114, ptr %l70
  br label %bb35
bb35:
  %t115 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  %t118 = icmp ne i64 %t116, 1
  store i1 %t118, ptr %l62, !tbaa !21
  br label %bb36
bb36:
  %t120 = load i1, ptr %l62, !tbaa !21
  br i1 %t120, label %bb37, label %bb38
bb37:
  %t121 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  store i64 %t121, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t123 = load ptr, ptr %l3, !tbaa !29
  store ptr %t123, ptr %l74, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/free:Free", ptr %t124, i32 0, i32 1
  %t127 = load i64, ptr %l7, !tbaa !24
  %t130 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t126, i64 %t127)
  store ptr %t130, ptr %l78
  br label %bb40
bb40:
  %t131 = load ptr, ptr %l78, !tbaa !29
  %t133 = getelementptr %"compiler/typed:Body", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %t133, !tbaa !23
  %t135 = load ptr, ptr %l74, !tbaa !29
  %t137 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t135, i32 %t134, i64 0)
  store i64 %t137, ptr %l81
  br label %bb41
bb41:
  %t138 = load i64, ptr %l81, !tbaa !24
  store i64 %t138, ptr %l8, !tbaa !24
  %t139 = load i64, ptr %l8, !tbaa !24
  %t141 = icmp slt i64 %t139, 0
  br i1 %t141, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb44
bb43:
  %t143 = load i64, ptr %l8, !tbaa !24
  %t144 = load ptr, ptr %l6, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Call", ptr %t144, i32 0, i32 1
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t152 = icmp sge i64 %t143, %t149
  store i1 %t152, ptr %l84, !tbaa !21
  br label %bb44
bb44:
  %t154 = load i1, ptr %l84, !tbaa !21
  br i1 %t154, label %bb45, label %bb46
bb45:
  %t155 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  store i64 %t155, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t159 = load ptr, ptr %l6, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Call", ptr %t159, i32 0, i32 1
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l94, !tbaa !27
  %t163 = load i64, ptr %l8, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr ptr, ptr %t166, i64 %t163
  %t168 = load ptr, ptr %t167, !tbaa !39
  %t172 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t157, ptr %t158, ptr %t168)
  store i64 %t172, ptr %l97
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s4)
  %t173 = load i64, ptr %l97, !tbaa !24
  store i64 %t173, ptr %rv
  br label %ret
bb49:
  %t174 = load ptr, ptr %l2, !tbaa !29
  store ptr %t174, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t175 = load ptr, ptr %l98, !tbaa !29
  %t176 = icmp ne ptr %t175, null
  br i1 %t176, label %bb50, label %bb51
bb50:
  %t178 = load ptr, ptr %l98, !tbaa !29
  %t179 = load i64, ptr %t178, !range !{i64 0, i64 18}
  %t181 = icmp eq i64 %t179, 14
  store i1 %t181, ptr %l99, !tbaa !21
  br label %bb51
bb51:
  %t182 = load i1, ptr %l99, !tbaa !21
  br i1 %t182, label %bb52, label %bb53
bb52:
  %t183 = load ptr, ptr %l2, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t185, i32 0, i32 2
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l9, !tbaa !29
  br label %bb54
bb53:
  br label %bb71
bb54:
  %t189 = load ptr, ptr %l9, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Try", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = icmp eq ptr %t192, null
  br i1 %t194, label %bb55, label %bb56
bb55:
  %t196 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t196, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t198 = load ptr, ptr %l9, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Try", ptr %t198, i32 0, i32 1
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  store i64 %t205, ptr %l12, !tbaa !24
  br label %bb58
bb58:
  %t207 = load i64, ptr %l11, !tbaa !24
  %t208 = load i64, ptr %l12, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb59, label %bb60
bb59:
  br label %bb66
bb60:
  br label %bb61
bb61:
  %t215 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t215, ptr %l116, !tbaa !27
  %t216 = load i64, ptr %l11, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr ptr, ptr %t219, i64 %t216
  %t221 = load ptr, ptr %t220, !tbaa !39
  %t225 = getelementptr %"compiler/typed:Clause", ptr %t221, i32 0, i32 4
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t230 = icmp sgt i64 %t228, 0
  br i1 %t230, label %bb62, label %bb63
bb62:
  %t232 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t232, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t234 = load i64, ptr %l11, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l11, !tbaa !24
  br label %bb58
bb66:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l126, !tbaa !29
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l127, !tbaa !29
  %t240 = load ptr, ptr %l9, !tbaa !29
  %t242 = getelementptr %"compiler/typed:Try", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = icmp eq ptr %t243, null
  br i1 %t245, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_4acb4c8921e8c407_808d59af97a4073)
  unreachable
bb68:
  br label %bb69
bb69:
  %t247 = load ptr, ptr %l9, !tbaa !29
  %t249 = getelementptr %"compiler/typed:Try", ptr %t247, i32 0, i32 0
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t251 = load ptr, ptr %l126, !tbaa !29
  %t252 = load ptr, ptr %l127, !tbaa !29
  %t254 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t251, ptr %t252, ptr %t250)
  store i64 %t254, ptr %l133
  br label %bb70
bb70:
  %t255 = load i64, ptr %l133, !tbaa !24
  store i64 %t255, ptr %rv
  br label %ret
bb71:
  %t256 = load ptr, ptr %l2, !tbaa !29
  store ptr %t256, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t257 = load ptr, ptr %l134, !tbaa !29
  %t258 = icmp ne ptr %t257, null
  br i1 %t258, label %bb72, label %bb73
bb72:
  %t260 = load ptr, ptr %l134, !tbaa !29
  %t261 = load i64, ptr %t260, !range !{i64 0, i64 18}
  %t263 = icmp eq i64 %t261, 17
  store i1 %t263, ptr %l135, !tbaa !21
  br label %bb73
bb73:
  %t264 = load i1, ptr %l135, !tbaa !21
  br i1 %t264, label %bb74, label %bb75
bb74:
  %t265 = load ptr, ptr %l2, !tbaa !29
  %t267 = getelementptr { i64, [5 x i64] }, ptr %t265, i32 0, i32 1
  %t268 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t267, i32 0, i32 2
  %t269 = load ptr, ptr %t268
  store ptr %t269, ptr %l14, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load ptr, ptr %l1, !tbaa !29
  %t273 = load ptr, ptr %l14, !tbaa !29
  %t277 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t271, ptr %t272, ptr %t273)
  store i64 %t277, ptr %l143
  br label %bb77
bb77:
  %t278 = load i64, ptr %l143, !tbaa !24
  store i64 %t278, ptr %rv
  br label %ret
bb78:
  %t279 = load ptr, ptr %l2, !tbaa !29
  store ptr %t279, ptr %l144, !tbaa !29
  store i1 false, ptr %l145, !tbaa !21
  %t280 = load ptr, ptr %l144, !tbaa !29
  %t281 = icmp ne ptr %t280, null
  br i1 %t281, label %bb79, label %bb80
bb79:
  %t283 = load ptr, ptr %l144, !tbaa !29
  %t284 = load i64, ptr %t283, !range !{i64 0, i64 18}
  %t286 = icmp eq i64 %t284, 9
  store i1 %t286, ptr %l145, !tbaa !21
  br label %bb80
bb80:
  %t287 = load i1, ptr %l145, !tbaa !21
  br i1 %t287, label %bb81, label %bb82
bb81:
  %t288 = load ptr, ptr %l2, !tbaa !29
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t288, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t290, i32 0, i32 2
  %t292 = load i32, ptr %t291, !range !{i32 0, i32 52}
  store i32 %t292, ptr %l15
  %t294 = load ptr, ptr %l2, !tbaa !29
  %t296 = getelementptr { i64, [5 x i64] }, ptr %t294, i32 0, i32 1
  %t297 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t296, i32 0, i32 4
  %t298 = load { i64, ptr }, ptr %t297
  store { i64, ptr } %t298, ptr %l16, !tbaa !27
  br label %bb83
bb82:
  br label %bb89
bb83:
  %t300 = load i32, ptr %l15, !range !{i32 0, i32 52}
  %t301 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t304 = call i1 @compiler_2ffree_2eisConversion(ptr %v2, i32 %t300, { i64, ptr } %t301)
  store i1 %t304, ptr %l154
  br label %bb84
bb84:
  %t305 = load i1, ptr %l154, !tbaa !21
  br i1 %t305, label %bb85, label %bb86
bb85:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l1, !tbaa !29
  %t308 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t308, ptr %l158, !tbaa !27
  %t309 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr ptr, ptr %t310, i64 0
  %t312 = load ptr, ptr %t311, !tbaa !39
  %t316 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t306, ptr %t307, ptr %t312)
  store i64 %t316, ptr %l160
  br label %bb87
bb86:
  %t317 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t317, ptr %l155, !tbaa !24
  br label %bb88
bb87:
  %t319 = load i64, ptr %l160, !tbaa !24
  store i64 %t319, ptr %l155, !tbaa !24
  br label %bb88
bb88:
  %t320 = load i64, ptr %l155, !tbaa !24
  store i64 %t320, ptr %rv
  br label %ret
bb89:
  br i1 true, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  %t321 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t321, ptr %rv
  br label %ret
bb93:
  call void @__olang_check_failed(ptr @olang_loc_d1dd1febe39b41f_df28cb247c1abe4b)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPlace(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/free:Free", ptr %t2, i32 0, i32 54
  %t8 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t4, i64 %a1)
  store ptr %t8, ptr %l7
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v0, ptr %v1, ptr %t10, ptr %t11, ptr %a2)
  store i64 %t13, ptr %l9
  br label %bb2
bb2:
  %t14 = load i64, ptr %l9, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eassignedFresh(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i1
  %l43 = alloca ptr
  %l47 = alloca ptr
  %l50 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 4
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:mustW", ptr %t53, i32 0, i32 4
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l39
  br label %bb12
bb12:
  %t61 = load i64, ptr %l39, !tbaa !24
  %t63 = icmp eq i64 %t61, %a1
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l43, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:mustW", ptr %t66, i32 0, i32 5
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t68, i64 %t69)
  store ptr %t72, ptr %l47
  br label %bb15
bb14:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb17
bb15:
  %t75 = add i64 %a2, 1
  %t76 = load ptr, ptr %l43, !tbaa !29
  %t77 = load ptr, ptr %l47, !tbaa !29
  %t79 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v0, ptr %t76, ptr %t77, i64 %t75)
  store i1 %t79, ptr %l50
  br label %bb16
bb16:
  %t80 = load i1, ptr %l50, !tbaa !21
  %t81 = xor i1 %t80, true
  store i1 %t81, ptr %l42, !tbaa !21
  br label %bb17
bb17:
  %t83 = load i1, ptr %l42, !tbaa !21
  br i1 %t83, label %bb18, label %bb19
bb18:
  store i1 false, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb8
bb22:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:mustW", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 5
  store ptr %t16, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l13, !tbaa !24
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l15
  br label %bb3
bb3:
  %t22 = load i64, ptr %l13, !tbaa !24
  %t23 = load i64, ptr %l15, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  br label %bb12
bb5:
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l20
  br label %bb7
bb7:
  %t33 = load i32, ptr %l20, !tbaa !23
  %t36 = sext i32 %t33 to i64
  %t40 = icmp eq i64 %t36, %a1
  br i1 %t40, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb2
bb12:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l79 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:mustW", ptr %t22, i32 0, i32 4
  %t25 = load i32, ptr %l2, !tbaa !23
  %t27 = sext i32 %t25 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t24, i64 %t27)
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/free:mustW", ptr %t30, i32 0, i32 5
  %t33 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t36, ptr %t37)
  br label %bb8
bb8:
  br label %bb103
bb9:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t41 = load ptr, ptr %l32, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l32, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 17}
  %t47 = icmp eq i64 %t45, 1
  store i1 %t47, ptr %l33, !tbaa !21
  br label %bb11
bb11:
  %t48 = load i1, ptr %l33, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [3 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t51, i32 0, i32 1
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l4, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l5, !tbaa !29
  br label %bb14
bb13:
  br label %bb29
bb14:
  %t61 = load ptr, ptr %l4, !tbaa !29
  store ptr %t61, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t62 = load ptr, ptr %l40, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l40, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 8}
  %t68 = icmp eq i64 %t66, 0
  store i1 %t68, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t69 = load i1, ptr %l41, !tbaa !21
  br i1 %t69, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t72, i32 0, i32 2
  %t74 = load i32, ptr %t73
  store i32 %t74, ptr %l6, !tbaa !23
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/free:mustW", ptr %t76, i32 0, i32 4
  %t79 = load i32, ptr %l6, !tbaa !23
  %t81 = sext i32 %t79 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t78, i64 %t81)
  br label %bb20
bb20:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:mustW", ptr %t84, i32 0, i32 5
  %t87 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  br label %bb21
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_18fbdab9dd354c58_c2b73ff02acf68dc)
  unreachable
bb27:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t90, ptr %t91)
  br label %bb28
bb28:
  br label %bb103
bb29:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t95 = load ptr, ptr %l55, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb30, label %bb31
bb30:
  %t98 = load ptr, ptr %l55, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 17}
  %t101 = icmp eq i64 %t99, 2
  store i1 %t101, ptr %l56, !tbaa !21
  br label %bb31
bb31:
  %t102 = load i1, ptr %l56, !tbaa !21
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [3 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", ptr }, ptr %t105, i32 0, i32 1
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l7, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t109, ptr %t110)
  br label %bb35
bb35:
  br label %bb103
bb36:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t114 = load ptr, ptr %l63, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb37, label %bb38
bb37:
  %t117 = load ptr, ptr %l63, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 17}
  %t120 = icmp eq i64 %t118, 3
  store i1 %t120, ptr %l64, !tbaa !21
  br label %bb38
bb38:
  %t121 = load i1, ptr %l64, !tbaa !21
  br i1 %t121, label %bb39, label %bb40
bb39:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [3 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", ptr }, ptr %t124, i32 0, i32 1
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l8, !tbaa !29
  br label %bb41
bb40:
  br label %bb51
bb41:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l8, !tbaa !29
  %t131 = getelementptr %"compiler/typed:If", ptr %t129, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t128, ptr %t132)
  br label %bb42
bb42:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l8, !tbaa !29
  %t138 = getelementptr %"compiler/typed:If", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t135, ptr %t139)
  br label %bb43
bb43:
  %t142 = load ptr, ptr %l8, !tbaa !29
  %t144 = getelementptr %"compiler/typed:If", ptr %t142, i32 0, i32 2
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = icmp eq ptr %t145, null
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb44, label %bb45
bb44:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l79, !tbaa !29
  %t152 = load ptr, ptr %l8, !tbaa !29
  %t154 = getelementptr %"compiler/typed:If", ptr %t152, i32 0, i32 2
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = icmp eq ptr %t155, null
  br i1 %t157, label %bb46, label %bb47
bb45:
  br label %bb50
bb46:
  call void @__olang_check_failed(ptr @olang_loc_6e5f625591edaca_eb58e2cd01ac77e)
  unreachable
bb47:
  br label %bb48
bb48:
  %t159 = load ptr, ptr %l8, !tbaa !29
  %t161 = getelementptr %"compiler/typed:If", ptr %t159, i32 0, i32 2
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t163 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t163, ptr %t162)
  br label %bb49
bb49:
  br label %bb50
bb50:
  br label %bb103
bb51:
  %t165 = load ptr, ptr %l1, !tbaa !29
  store ptr %t165, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t166 = load ptr, ptr %l85, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb52, label %bb53
bb52:
  %t169 = load ptr, ptr %l85, !tbaa !29
  %t170 = load i64, ptr %t169, !range !{i64 0, i64 17}
  %t172 = icmp eq i64 %t170, 4
  store i1 %t172, ptr %l86, !tbaa !21
  br label %bb53
bb53:
  %t173 = load i1, ptr %l86, !tbaa !21
  br i1 %t173, label %bb54, label %bb55
bb54:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [3 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t176, i32 0, i32 1
  %t178 = load ptr, ptr %t177
  store ptr %t178, ptr %l9, !tbaa !29
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr { i64, [3 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t182, i32 0, i32 2
  %t184 = load ptr, ptr %t183
  store ptr %t184, ptr %l10, !tbaa !29
  br label %bb56
bb55:
  br label %bb62
bb56:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t186, ptr %t187)
  br label %bb57
bb57:
  %t190 = load ptr, ptr %l10, !tbaa !29
  %t192 = icmp eq ptr %t190, null
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb58, label %bb59
bb58:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t196, ptr %t197)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb103
bb62:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t201 = load ptr, ptr %l100, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb63, label %bb64
bb63:
  %t204 = load ptr, ptr %l100, !tbaa !29
  %t205 = load i64, ptr %t204, !range !{i64 0, i64 17}
  %t207 = icmp eq i64 %t205, 6
  store i1 %t207, ptr %l101, !tbaa !21
  br label %bb64
bb64:
  %t208 = load i1, ptr %l101, !tbaa !21
  br i1 %t208, label %bb65, label %bb66
bb65:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [3 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", ptr }, ptr %t211, i32 0, i32 1
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l11, !tbaa !29
  br label %bb71
bb66:
  %t215 = load ptr, ptr %l1, !tbaa !29
  store ptr %t215, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t216 = load ptr, ptr %l106, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb67, label %bb68
bb67:
  %t219 = load ptr, ptr %l106, !tbaa !29
  %t220 = load i64, ptr %t219, !range !{i64 0, i64 17}
  %t222 = icmp eq i64 %t220, 16
  store i1 %t222, ptr %l107, !tbaa !21
  br label %bb68
bb68:
  %t223 = load i1, ptr %l107, !tbaa !21
  br i1 %t223, label %bb69, label %bb70
bb69:
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [3 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", ptr }, ptr %t226, i32 0, i32 1
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l11, !tbaa !29
  br label %bb71
bb70:
  br label %bb77
bb71:
  %t230 = load ptr, ptr %l11, !tbaa !29
  %t232 = icmp eq ptr %t230, null
  %t234 = xor i1 %t232, true
  br i1 %t234, label %bb72, label %bb73
bb72:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/free:mustW", ptr %t236, i32 0, i32 6
  %t239 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t238, ptr %t239)
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t242, ptr %t243)
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb103
bb77:
  %t246 = load ptr, ptr %l1, !tbaa !29
  store ptr %t246, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t247 = load ptr, ptr %l120, !tbaa !29
  %t248 = icmp ne ptr %t247, null
  br i1 %t248, label %bb78, label %bb79
bb78:
  %t250 = load ptr, ptr %l120, !tbaa !29
  %t251 = load i64, ptr %t250, !range !{i64 0, i64 17}
  %t253 = icmp eq i64 %t251, 11
  store i1 %t253, ptr %l121, !tbaa !21
  br label %bb79
bb79:
  %t254 = load i1, ptr %l121, !tbaa !21
  br i1 %t254, label %bb80, label %bb81
bb80:
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t257 = getelementptr { i64, [3 x i64] }, ptr %t255, i32 0, i32 1
  %t258 = getelementptr { %"compiler/source:Span", ptr }, ptr %t257, i32 0, i32 1
  %t259 = load ptr, ptr %t258
  store ptr %t259, ptr %l12, !tbaa !29
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t261, ptr %t262)
  br label %bb83
bb83:
  br label %bb103
bb84:
  %t265 = load ptr, ptr %l1, !tbaa !29
  store ptr %t265, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t266 = load ptr, ptr %l128, !tbaa !29
  %t267 = icmp ne ptr %t266, null
  br i1 %t267, label %bb85, label %bb86
bb85:
  %t269 = load ptr, ptr %l128, !tbaa !29
  %t270 = load i64, ptr %t269, !range !{i64 0, i64 17}
  %t272 = icmp eq i64 %t270, 12
  store i1 %t272, ptr %l129, !tbaa !21
  br label %bb86
bb86:
  %t273 = load i1, ptr %l129, !tbaa !21
  br i1 %t273, label %bb87, label %bb88
bb87:
  %t274 = load ptr, ptr %l1, !tbaa !29
  %t276 = getelementptr { i64, [3 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { %"compiler/source:Span", ptr }, ptr %t276, i32 0, i32 1
  %t278 = load ptr, ptr %t277
  store ptr %t278, ptr %l13, !tbaa !29
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t280, ptr %t281)
  br label %bb90
bb90:
  br label %bb103
bb91:
  %t284 = load ptr, ptr %l1, !tbaa !29
  store ptr %t284, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t285 = load ptr, ptr %l136, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb92, label %bb93
bb92:
  %t288 = load ptr, ptr %l136, !tbaa !29
  %t289 = load i64, ptr %t288, !range !{i64 0, i64 17}
  %t291 = icmp eq i64 %t289, 13
  store i1 %t291, ptr %l137, !tbaa !21
  br label %bb93
bb93:
  %t292 = load i1, ptr %l137, !tbaa !21
  br i1 %t292, label %bb94, label %bb95
bb94:
  %t293 = load ptr, ptr %l1, !tbaa !29
  %t295 = getelementptr { i64, [3 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", ptr }, ptr %t295, i32 0, i32 1
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l14, !tbaa !29
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load ptr, ptr %l14, !tbaa !29
  %t302 = getelementptr %"compiler/typed:Join", ptr %t300, i32 0, i32 0
  %t303 = load ptr, ptr %t302, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t299, ptr %t303)
  br label %bb97
bb97:
  br label %bb103
bb98:
  br i1 true, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_6578a1c50e6256f2_162d732cc51ca876)
  unreachable
bb103:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/free:leaf"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l40 = alloca i64
  %l47 = alloca ptr
  %l55 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca ptr
  %l60 = alloca i64
  %l63 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca ptr
  %l86 = alloca i1
  %l90 = alloca i1
  %l92 = alloca ptr
  %l94 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca i32
  %l98 = alloca i32
  %l101 = alloca i1
  %l103 = alloca i1
  %l104 = alloca ptr
  %l106 = alloca i32
  %l108 = alloca ptr
  %l109 = alloca i1
  %l118 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i32
  %l140 = alloca i64
  %l143 = alloca ptr
  %l144 = alloca i64
  %l145 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l151 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l154 = alloca i64
  %l155 = alloca i64
  %l157 = alloca %"compiler/source:Span"
  %l158 = alloca %"compiler/source:Span"
  %l162 = alloca i64
  %l163 = alloca ptr
  %l166 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l175 = alloca ptr
  %l178 = alloca i64
  %l179 = alloca ptr
  %l183 = alloca i1
  %l184 = alloca i64
  %l187 = alloca i64
  %l190 = alloca i64
  %l196 = alloca ptr
  %l197 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i64
  %l204 = alloca ptr
  %l205 = alloca ptr
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca ptr
  %l209 = alloca %"compiler/source:Span"
  %l210 = alloca { i64, ptr }
  %l216 = alloca ptr
  %l217 = alloca i64
  %l218 = alloca i64
  %l220 = alloca %"compiler/source:Span"
  %l221 = alloca %"compiler/source:Span"
  %l223 = alloca ptr
  %l225 = alloca i32
  %l226 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l228 = alloca i64
  %l230 = alloca i64
  %l235 = alloca %"compiler/free:leaf"
  %l237 = alloca %"compiler/free:leaf"
  %l238 = alloca ptr
  %l239 = alloca i64
  %l240 = alloca i64
  %l242 = alloca %"compiler/source:Span"
  %l243 = alloca %"compiler/source:Span"
  %l247 = alloca i64
  %l249 = alloca i1
  %l253 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca ptr
  %l258 = alloca i32
  %l264 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l266 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l267 = alloca ptr
  %l268 = alloca i1
  %l273 = alloca ptr
  %l274 = alloca i64
  %l275 = alloca ptr
  %l276 = alloca ptr
  %l277 = alloca %"compiler/source:Span"
  %l278 = alloca ptr
  %l280 = alloca %"compiler/source:Span"
  %l281 = alloca { i64, ptr }
  %l288 = alloca ptr
  %l290 = alloca i32
  %l291 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l293 = alloca i64
  %l295 = alloca i1
  %l299 = alloca i1
  %l301 = alloca ptr
  %l302 = alloca ptr
  %l304 = alloca i32
  %l310 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l312 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l315 = alloca ptr
  %l316 = alloca ptr
  %l317 = alloca %"compiler/source:Span"
  %l318 = alloca ptr
  %l320 = alloca %"compiler/source:Span"
  %l321 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l325 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 9
  %t4 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %t3, ptr %t4)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t10 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v2, ptr %v2, ptr %t7)
  store ptr %t10, ptr %l27
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l27, !tbaa !29
  store ptr %t11, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:walker", ptr %t12, i32 0, i32 32
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l30, !tbaa !29
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t25 = load ptr, ptr %l35, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l35, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 8}
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l36, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l36, !tbaa !21
  %t33 = xor i1 %t32, true
  store i1 %t33, ptr %l34, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l34, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Call", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %t38, !tbaa !23
  %t41 = sext i32 %t39 to i64
  store i64 %t41, ptr %l40, !tbaa !24
  br label %bb10
bb9:
  store i64 -1, ptr %l40, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l40, !tbaa !24
  %t44 = load ptr, ptr %l30, !tbaa !29
  %t45 = getelementptr %"compiler/free:walker", ptr %t44, i32 0, i32 32
  store i64 %t43, ptr %t45, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t52 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyStored(ptr %v0, ptr %v1, ptr %v2, ptr %v0, ptr %t46, ptr %t47, ptr %t48)
  store ptr %t52, ptr %l47
  br label %bb11
bb11:
  %t53 = load ptr, ptr %l47, !tbaa !29
  store ptr %t53, ptr %l6, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/free:walker", ptr %t54, i32 0, i32 34
  %t57 = load i64, ptr %t56, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:walker", ptr %t59, i32 0, i32 35
  %t62 = load i64, ptr %t61, !tbaa !24
  store i64 %t62, ptr %l8, !tbaa !24
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t66 = icmp eq ptr %t64, null
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l55, !tbaa !29
  %t71 = load ptr, ptr %l6, !tbaa !29
  %t73 = call i64 @compiler_2ffree_2eownCopySite(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l57
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t74 = load i64, ptr %l57, !tbaa !24
  %t75 = load ptr, ptr %l55, !tbaa !29
  %t76 = getelementptr %"compiler/free:walker", ptr %t75, i32 0, i32 34
  store i64 %t74, ptr %t76, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l58, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t80 = call i64 @compiler_2ffree_2ereadLocalOf(ptr %v2, ptr %t78)
  store i64 %t80, ptr %l60
  br label %bb15
bb15:
  %t81 = load i64, ptr %l60, !tbaa !24
  %t82 = load ptr, ptr %l58, !tbaa !29
  %t83 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 35
  store i64 %t81, ptr %t83, !tbaa !24
  br label %bb16
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t88 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %s0, ptr %t84, ptr %t85)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l63
  br label %bb17
bb17:
  %t89 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l63
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l9
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t92 = icmp eq ptr %t90, null
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb18, label %bb19
bb18:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:walker", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t102 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %t102
  %t105 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %s0, ptr %s0, ptr %t99, ptr %t102)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l71
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t106 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %l9
  br label %bb21
bb21:
  %t107 = load i64, ptr %l7, !tbaa !24
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/free:walker", ptr %t111, i32 0, i32 34
  store i64 %t107, ptr %t115, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/free:walker", ptr %t116, i32 0, i32 35
  store i64 %t109, ptr %t120, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i64, ptr %l5, !tbaa !24
  %t125 = getelementptr %"compiler/free:walker", ptr %t121, i32 0, i32 32
  store i64 %t122, ptr %t125, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/free:walker", ptr %t126, i32 0, i32 9
  %t130 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePop__He26954e073d6f40019e862398a9b5f5c(ptr %v0, ptr %s0, ptr %t128)
  %t131 = extractvalue { i32, ptr } %t130, 1
  %t132 = extractvalue { i32, ptr } %t130, 0
  store i32 %t132, ptr %l84
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb23, label %ok.134, !prof !99
ok.134:
  store ptr %t131, ptr %l83
  br label %bb22
bb22:
  %t135 = load ptr, ptr %l83, !tbaa !29
  store ptr %t135, ptr %l80, !tbaa !29
  br label %bb25
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t136 = load ptr, ptr %l2, !tbaa !29
  store ptr %t136, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t137 = load ptr, ptr %l85, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb26, label %bb27
bb26:
  %t140 = load ptr, ptr %l85, !tbaa !29
  %t141 = load i64, ptr %t140, !range !{i64 0, i64 8}
  %t143 = icmp eq i64 %t141, 0
  store i1 %t143, ptr %l86, !tbaa !21
  br label %bb27
bb27:
  %t144 = load i1, ptr %l86, !tbaa !21
  %t145 = xor i1 %t144, true
  br i1 %t145, label %bb28, label %bb29
bb28:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t147)
  store ptr %t149, ptr %l92
  br label %bb30
bb29:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb35
bb30:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t150)
  store ptr %t152, ptr %l94
  br label %bb31
bb31:
  %t153 = load ptr, ptr %l2, !tbaa !29
  %t155 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t153)
  store i32 %t155, ptr %l96
  br label %bb32
bb32:
  %t156 = load ptr, ptr %l94, !tbaa !29
  %t157 = load i32, ptr %l96, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t158, ptr %l97
  br label %bb33
bb33:
  %t159 = load ptr, ptr %l92, !tbaa !29
  %t160 = load i32, ptr %l97, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t159, i32 %t160)
  store i32 %t161, ptr %l98
  br label %bb34
bb34:
  %t162 = load i32, ptr %l98, !range !{i32 0, i32 33}
  %t164 = trunc i64 19 to i32
  %t165 = icmp eq i32 %t162, %t164
  store i1 %t165, ptr %l90, !tbaa !21
  br label %bb35
bb35:
  %t167 = load i1, ptr %l90, !tbaa !21
  br i1 %t167, label %bb36, label %bb37
bb36:
  %t168 = load ptr, ptr %l3, !tbaa !29
  %t170 = call i1 @compiler_2ffree_2ecopiedStore(ptr %v2, ptr %t168)
  store i1 %t170, ptr %l103
  br label %bb38
bb37:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb39
bb38:
  %t171 = load i1, ptr %l103, !tbaa !21
  store i1 %t171, ptr %l101, !tbaa !21
  br label %bb39
bb39:
  %t172 = load i1, ptr %l101, !tbaa !21
  br i1 %t172, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l104, !tbaa !29
  %t174 = load ptr, ptr %l2, !tbaa !29
  %t176 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t174)
  store i32 %t176, ptr %l106
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t177 = load %"compiler/source:Span", ptr %l1
  %t178 = load ptr, ptr %l104, !tbaa !29
  %t179 = load i32, ptr %l106, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %s4, ptr %t178, i32 %t179, %"compiler/source:Span" %t177, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d19, i32 0, i32 1) })
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb44:
  %t181 = load ptr, ptr %l2, !tbaa !29
  store ptr %t181, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t182 = load ptr, ptr %l108, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb45, label %bb46
bb45:
  %t185 = load ptr, ptr %l108, !tbaa !29
  %t186 = load i64, ptr %t185, !range !{i64 0, i64 8}
  %t188 = icmp eq i64 %t186, 0
  store i1 %t188, ptr %l109, !tbaa !21
  br label %bb46
bb46:
  %t189 = load i1, ptr %l109, !tbaa !21
  br i1 %t189, label %bb47, label %bb48
bb47:
  %t190 = load ptr, ptr %l2, !tbaa !29
  %t192 = getelementptr { i64, [4 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t192, i32 0, i32 2
  %t194 = load i32, ptr %t193
  store i32 %t194, ptr %l12, !tbaa !23
  br label %bb49
bb48:
  br label %bb72
bb49:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i32, ptr %l12, !tbaa !23
  %t199 = sext i32 %t197 to i64
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s0, ptr %t196, i64 %t199, ptr %l9)
  br label %bb50
bb50:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/free:walker", ptr %t203, i32 0, i32 7
  %t206 = load i32, ptr %l12, !tbaa !23
  %t208 = sext i32 %t206 to i64
  %t211 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t205, i64 %t208)
  %t212 = extractvalue { i32, i64 } %t211, 1
  %t213 = extractvalue { i32, i64 } %t211, 0
  store i32 %t213, ptr %l124
  %t214 = icmp ne i32 %t213, 0
  br i1 %t214, label %bb52, label %ok.215, !prof !99
ok.215:
  store i64 %t212, ptr %l123
  br label %bb51
bb51:
  %t216 = load i64, ptr %l123, !tbaa !24
  store i64 %t216, ptr %l118, !tbaa !24
  br label %bb54
bb52:
  br label %bb53
bb53:
  store i64 -1, ptr %l118, !tbaa !24
  br label %bb54
bb54:
  %t217 = load i64, ptr %l118, !tbaa !24
  store i64 %t217, ptr %l13, !tbaa !24
  %t218 = load i64, ptr %l13, !tbaa !24
  %t220 = icmp sge i64 %t218, 0
  br i1 %t220, label %bb55, label %bb56
bb55:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i64, ptr %l13, !tbaa !24
  %t224 = load ptr, ptr %l3, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v2, ptr %s0, ptr %t222, i64 %t223, ptr %t224, ptr %l9, %"compiler/source:Span" %t225)
  br label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb58
bb58:
  %t231 = load i64, ptr %l13, !tbaa !24
  %t233 = icmp sge i64 %t231, 0
  br i1 %t233, label %bb59, label %bb60
bb59:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i64, ptr %l13, !tbaa !24
  %t237 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeField(ptr %v0, ptr %v2, ptr %t235, i64 %t236, ptr %t237)
  br label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb62
bb62:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i32, ptr %l12, !tbaa !23
  %t244 = sext i32 %t242 to i64
  %t247 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %t241, i64 %t244)
  store i64 %t247, ptr %l140
  br label %bb63
bb63:
  %t248 = load i64, ptr %l140, !tbaa !24
  store i64 %t248, ptr %l14, !tbaa !24
  %t249 = load i64, ptr %l14, !tbaa !24
  %t251 = icmp sge i64 %t249, 0
  br i1 %t251, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s8
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l143, !tbaa !29
  %t254 = load i64, ptr %l14, !tbaa !24
  store i64 %t254, ptr %l144, !tbaa !24
  %t255 = load ptr, ptr %l3, !tbaa !29
  store ptr %t255, ptr %l145, !tbaa !29
  store ptr %l9, ptr %l146, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t256, ptr %l147
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l12, !tbaa !23
  %t260 = sext i32 %t258 to i64
  %t263 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %s8, ptr %t257, i64 %t260)
  store { i64, ptr } %t263, ptr %l151
  br label %bb66
bb65:
  br label %bb71
bb66:
  %t264 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  %t266 = extractvalue { i64, ptr } %t264, 1
  %t267 = mul i64 %t265, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t268, ptr %t266, i64 %t267, i1 false)
  %t269 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  %t271 = load ptr, ptr %l143, !tbaa !29
  %t272 = load i64, ptr %l144, !tbaa !24
  %t273 = load ptr, ptr %l145, !tbaa !29
  %t274 = load ptr, ptr %l146, !tbaa !29
  %t275 = load %"compiler/source:Span", ptr %l147
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v2, ptr %s0, ptr %s8, ptr %t271, i64 %t272, ptr %t273, ptr %t274, %"compiler/source:Span" %t275, { i64, ptr } %t270, i1 false)
  br label %bb67
bb67:
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l153, !tbaa !29
  %t278 = load i64, ptr %l14, !tbaa !24
  store i64 %t278, ptr %l154, !tbaa !24
  %t279 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  store i64 %t279, ptr %l155, !tbaa !24
  %t280 = load ptr, ptr %l2, !tbaa !29
  %t282 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t280)
  store %"compiler/source:Span" %t282, ptr %l157
  br label %bb68
bb68:
  %t283 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 0, i32 0)
  store %"compiler/source:Span" %t283, ptr %l158
  br label %bb69
bb69:
  %t284 = load ptr, ptr %l153, !tbaa !29
  %t285 = load i64, ptr %l154, !tbaa !24
  %t286 = load i64, ptr %l155, !tbaa !24
  %t287 = load %"compiler/source:Span", ptr %l157
  %t288 = load %"compiler/source:Span", ptr %l158
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t284, i64 %t285, i64 %t286, %"compiler/source:Span" %t287, %"compiler/source:Span" %t288, i64 -1)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s8)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_620cc86993d1ee05_2ed463b6a2f232e1)
  unreachable
bb77:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/free:walker", ptr %t289, i32 0, i32 0
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t293 = load ptr, ptr %l2, !tbaa !29
  %t296 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t292, ptr %t293)
  store i64 %t296, ptr %l162
  br label %bb78
bb78:
  %t297 = load i64, ptr %l162, !tbaa !24
  store i64 %t297, ptr %l15, !tbaa !24
  %t298 = load ptr, ptr %l0, !tbaa !29
  store ptr %t298, ptr %l163, !tbaa !29
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load ptr, ptr %l2, !tbaa !29
  %t303 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %s0, ptr %t299, ptr %t300)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t303, ptr %l166
  br label %bb79
bb79:
  %t304 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l166
  %t305 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t304, ptr %t305
  %t306 = load i64, ptr %l15, !tbaa !24
  %t307 = load %"compiler/source:Span", ptr %l1
  %t308 = load ptr, ptr %l163, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2einOwner(ptr %v0, ptr %s0, ptr %s0, ptr %t308, ptr %t305, i64 %t306, %"compiler/source:Span" %t307, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb80
bb80:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/free:walker", ptr %t312, i32 0, i32 2
  %t315 = load i1, ptr %t314, !tbaa !21
  br i1 %t315, label %bb81, label %bb82
bb81:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load ptr, ptr %l2, !tbaa !29
  %t319 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorStoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %t317, ptr %t318, ptr %t319)
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb84
bb84:
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l175, !tbaa !29
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load ptr, ptr %l2, !tbaa !29
  %t328 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %t324, ptr %t325)
  store i64 %t328, ptr %l178
  br label %bb85
bb85:
  %t329 = load i64, ptr %l178, !tbaa !24
  %t330 = load ptr, ptr %l175, !tbaa !29
  %t331 = getelementptr %"compiler/free:walker", ptr %t330, i32 0, i32 30
  store i64 %t329, ptr %t331, !tbaa !24
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l179, !tbaa !29
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load ptr, ptr %l3, !tbaa !29
  %t335 = load ptr, ptr %l2, !tbaa !29
  %t339 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esameValue(ptr %v0, ptr %v2, ptr %v1, ptr %t333, ptr %t334, ptr %t335)
  store i1 %t339, ptr %l183
  br label %bb86
bb86:
  %t340 = load i1, ptr %l183, !tbaa !21
  br i1 %t340, label %bb87, label %bb88
bb87:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load ptr, ptr %l2, !tbaa !29
  %t345 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einsidePlace(ptr %v0, ptr %v1, ptr %t341, ptr %t342)
  store i64 %t345, ptr %l187
  br label %bb89
bb88:
  store i64 -1, ptr %l184, !tbaa !24
  br label %bb90
bb89:
  %t346 = load i64, ptr %l187, !tbaa !24
  store i64 %t346, ptr %l184, !tbaa !24
  br label %bb90
bb90:
  %t347 = load i64, ptr %l184, !tbaa !24
  %t348 = load ptr, ptr %l179, !tbaa !29
  %t349 = getelementptr %"compiler/free:walker", ptr %t348, i32 0, i32 31
  store i64 %t347, ptr %t349, !tbaa !24
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load ptr, ptr %l2, !tbaa !29
  %t354 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t350, ptr %t351)
  store i64 %t354, ptr %l190
  br label %bb91
bb91:
  %t355 = load i64, ptr %l190, !tbaa !24
  store i64 %t355, ptr %l16, !tbaa !24
  %t356 = load i64, ptr %l16, !tbaa !24
  %t358 = icmp sge i64 %t356, 0
  br i1 %t358, label %bb92, label %bb93
bb92:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load i64, ptr %l16, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s0, ptr %t360, i64 %t361, ptr %l9)
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb95
bb95:
  %t365 = load ptr, ptr %l2, !tbaa !29
  store ptr %t365, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t366 = load ptr, ptr %l196, !tbaa !29
  %t367 = icmp ne ptr %t366, null
  br i1 %t367, label %bb96, label %bb97
bb96:
  %t369 = load ptr, ptr %l196, !tbaa !29
  %t370 = load i64, ptr %t369, !range !{i64 0, i64 8}
  %t372 = icmp eq i64 %t370, 3
  store i1 %t372, ptr %l197, !tbaa !21
  br label %bb97
bb97:
  %t373 = load i1, ptr %l197, !tbaa !21
  br i1 %t373, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb135
bb100:
  store %olang.scope zeroinitializer, ptr %s12
  %t374 = load i64, ptr %l15, !tbaa !24
  %t376 = icmp sge i64 %t374, 0
  br i1 %t376, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s13
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l202, !tbaa !29
  %t379 = load i64, ptr %l15, !tbaa !24
  store i64 %t379, ptr %l203, !tbaa !24
  %t380 = load ptr, ptr %l3, !tbaa !29
  store ptr %t380, ptr %l204, !tbaa !29
  store ptr %l9, ptr %l205, !tbaa !29
  %t381 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t381, ptr %l206
  %t382 = load ptr, ptr %l0, !tbaa !29
  store ptr %t382, ptr %l207, !tbaa !29
  %t383 = load ptr, ptr %l2, !tbaa !29
  %t385 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t383)
  store %"compiler/source:Span" %t385, ptr %l209
  br label %bb103
bb102:
  br label %bb109
bb103:
  %t386 = load ptr, ptr %l207, !tbaa !29
  %t387 = load %"compiler/source:Span", ptr %l209
  %t388 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s13, ptr %t386, %"compiler/source:Span" %t387)
  store { i64, ptr } %t388, ptr %l210
  br label %bb104
bb104:
  %t389 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 0
  %t391 = extractvalue { i64, ptr } %t389, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t396 = load i64, ptr %l16, !tbaa !24
  %t398 = icmp sge i64 %t396, 0
  %t399 = load ptr, ptr %l202, !tbaa !29
  %t400 = load i64, ptr %l203, !tbaa !24
  %t401 = load ptr, ptr %l204, !tbaa !29
  %t402 = load ptr, ptr %l205, !tbaa !29
  %t403 = load %"compiler/source:Span", ptr %l206
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v2, ptr %s0, ptr %s13, ptr %t399, i64 %t400, ptr %t401, ptr %t402, %"compiler/source:Span" %t403, { i64, ptr } %t395, i1 %t398)
  br label %bb105
bb105:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/free:walker", ptr %t406, i32 0, i32 30
  store i64 -1, ptr %t408, !tbaa !24
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/free:walker", ptr %t409, i32 0, i32 31
  store i64 -1, ptr %t411, !tbaa !24
  %t412 = load ptr, ptr %l0, !tbaa !29
  store ptr %t412, ptr %l216, !tbaa !29
  %t413 = load i64, ptr %l15, !tbaa !24
  store i64 %t413, ptr %l217, !tbaa !24
  %t414 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  store i64 %t414, ptr %l218, !tbaa !24
  %t415 = load ptr, ptr %l2, !tbaa !29
  %t417 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t415)
  store %"compiler/source:Span" %t417, ptr %l220
  br label %bb106
bb106:
  %t418 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s13, i32 0, i32 0)
  store %"compiler/source:Span" %t418, ptr %l221
  br label %bb107
bb107:
  %t419 = load ptr, ptr %l216, !tbaa !29
  %t420 = load i64, ptr %l217, !tbaa !24
  %t421 = load i64, ptr %l218, !tbaa !24
  %t422 = load %"compiler/source:Span", ptr %l220
  %t423 = load %"compiler/source:Span", ptr %l221
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t419, i64 %t420, i64 %t421, %"compiler/source:Span" %t422, %"compiler/source:Span" %t423, i64 -1)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb109:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/free:walker", ptr %t424, i32 0, i32 0
  %t427 = load ptr, ptr %t426, !tbaa !29
  store ptr %t427, ptr %l223, !tbaa !29
  %t428 = load ptr, ptr %l2, !tbaa !29
  %t430 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t428)
  store i32 %t430, ptr %l225
  br label %bb110
bb110:
  %t431 = load ptr, ptr %l223, !tbaa !29
  %t432 = load i32, ptr %l225, !tbaa !23
  %t433 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t431, i32 %t432)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t433, ptr %l226
  br label %bb111
bb111:
  %t434 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l226
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t434, ptr %l17
  store ptr %l17, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s15
  %t436 = load i64, ptr %l19, !tbaa !24
  store i64 %t436, ptr %l228, !tbaa !24
  %t437 = load ptr, ptr %l18, !tbaa !29
  %t439 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s12, ptr %t437)
  store i64 %t439, ptr %l230
  br label %bb113
bb113:
  %t440 = load i64, ptr %l228, !tbaa !24
  %t441 = load i64, ptr %l230, !tbaa !24
  %t442 = icmp slt i64 %t440, %t441
  %t444 = xor i1 %t442, true
  br i1 %t444, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s15)
  br label %bb123
bb115:
  br label %bb116
bb116:
  %t446 = load ptr, ptr %l18, !tbaa !29
  %t447 = load i64, ptr %l19, !tbaa !24
  %t450 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s12, ptr %s12, ptr %t446, i64 %t447)
  store %"compiler/free:leaf" %t450, ptr %l235
  br label %bb117
bb117:
  %t452 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s15, ptr %l235)
  store %"compiler/free:leaf" %t452, ptr %l237
  br label %bb118
bb118:
  %t453 = load %"compiler/free:leaf", ptr %l237
  store %"compiler/free:leaf" %t453, ptr %l20
  %t454 = load ptr, ptr %l0, !tbaa !29
  store ptr %t454, ptr %l238, !tbaa !29
  %t455 = getelementptr %"compiler/free:leaf", ptr %l20, i32 0, i32 1
  %t456 = load i64, ptr %t455, !tbaa !24
  store i64 %t456, ptr %l239, !tbaa !24
  %t457 = load i64, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  store i64 %t457, ptr %l240, !tbaa !24
  %t458 = load ptr, ptr %l2, !tbaa !29
  %t460 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t458)
  store %"compiler/source:Span" %t460, ptr %l242
  br label %bb119
bb119:
  %t461 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s15, i32 0, i32 0)
  store %"compiler/source:Span" %t461, ptr %l243
  br label %bb120
bb120:
  %t462 = load ptr, ptr %l238, !tbaa !29
  %t463 = load i64, ptr %l239, !tbaa !24
  %t464 = load i64, ptr %l240, !tbaa !24
  %t465 = load %"compiler/source:Span", ptr %l242
  %t466 = load %"compiler/source:Span", ptr %l243
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t462, i64 %t463, i64 %t464, %"compiler/source:Span" %t465, %"compiler/source:Span" %t466, i64 -1)
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s15)
  br label %bb122
bb122:
  %t467 = load i64, ptr %l19, !tbaa !24
  %t469 = add i64 %t467, 1
  store i64 %t469, ptr %l19, !tbaa !24
  br label %bb112
bb123:
  %t472 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s12, ptr %l17)
  store i64 %t472, ptr %l247
  br label %bb124
bb124:
  %t473 = load i64, ptr %l247, !tbaa !24
  %t474 = icmp sgt i64 %t473, 0
  br i1 %t474, label %bb125, label %bb126
bb125:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load ptr, ptr %l3, !tbaa !29
  %t478 = load ptr, ptr %l6, !tbaa !29
  %t482 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoredWhole(ptr %v0, ptr %v2, ptr %v0, ptr %t476, ptr %t477, ptr %t478)
  store i1 %t482, ptr %l253
  br label %bb127
bb126:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb128
bb127:
  %t483 = load i1, ptr %l253, !tbaa !21
  %t484 = xor i1 %t483, true
  store i1 %t484, ptr %l249, !tbaa !21
  br label %bb128
bb128:
  %t486 = load i1, ptr %l249, !tbaa !21
  br i1 %t486, label %bb129, label %bb130
bb129:
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l255, !tbaa !29
  store ptr %l17, ptr %l256, !tbaa !29
  %t488 = load ptr, ptr %l2, !tbaa !29
  %t490 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t488)
  store i32 %t490, ptr %l258
  br label %bb131
bb130:
  br label %bb134
bb131:
  %t491 = load ptr, ptr %l3, !tbaa !29
  %t492 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t494 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t492, ptr %t494
  %t495 = load %"compiler/source:Span", ptr %l1
  %t496 = load ptr, ptr %l6, !tbaa !29
  %t497 = load ptr, ptr %l255, !tbaa !29
  %t498 = load ptr, ptr %l256, !tbaa !29
  %t499 = load i32, ptr %l258, !tbaa !23
  %t504 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %s12, ptr %v2, ptr %s0, ptr %v0, ptr %s0, ptr %t497, ptr %t498, i32 %t499, ptr %t491, ptr %t494, %"compiler/source:Span" %t495, ptr %t496)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t504, ptr %l264
  br label %bb132
bb132:
  %t506 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l264)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t506, ptr %l266
  br label %bb133
bb133:
  %t507 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l266
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t507, ptr %l9
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s12)
  br label %bb165
bb135:
  %t508 = load ptr, ptr %l2, !tbaa !29
  store ptr %t508, ptr %l267, !tbaa !29
  store i1 false, ptr %l268, !tbaa !21
  %t509 = load ptr, ptr %l267, !tbaa !29
  %t510 = icmp ne ptr %t509, null
  br i1 %t510, label %bb136, label %bb137
bb136:
  %t512 = load ptr, ptr %l267, !tbaa !29
  %t513 = load i64, ptr %t512, !range !{i64 0, i64 8}
  %t515 = icmp eq i64 %t513, 4
  store i1 %t515, ptr %l268, !tbaa !21
  br label %bb137
bb137:
  %t516 = load i1, ptr %l268, !tbaa !21
  br i1 %t516, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb160
bb140:
  store %olang.scope zeroinitializer, ptr %s18
  %t517 = load i64, ptr %l15, !tbaa !24
  %t519 = icmp sge i64 %t517, 0
  br i1 %t519, label %bb141, label %bb142
bb141:
  store %olang.scope zeroinitializer, ptr %s19
  %t521 = load ptr, ptr %l0, !tbaa !29
  store ptr %t521, ptr %l273, !tbaa !29
  %t522 = load i64, ptr %l15, !tbaa !24
  store i64 %t522, ptr %l274, !tbaa !24
  %t523 = load ptr, ptr %l3, !tbaa !29
  store ptr %t523, ptr %l275, !tbaa !29
  store ptr %l9, ptr %l276, !tbaa !29
  %t524 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t524, ptr %l277
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l278, !tbaa !29
  %t526 = load ptr, ptr %l2, !tbaa !29
  %t528 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t526)
  store %"compiler/source:Span" %t528, ptr %l280
  br label %bb143
bb142:
  br label %bb146
bb143:
  %t529 = load ptr, ptr %l278, !tbaa !29
  %t530 = load %"compiler/source:Span", ptr %l280
  %t531 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s19, ptr %t529, %"compiler/source:Span" %t530)
  store { i64, ptr } %t531, ptr %l281
  br label %bb144
bb144:
  %t532 = load { i64, ptr }, ptr %l281, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t532, 0
  %t534 = extractvalue { i64, ptr } %t532, 1
  %t535 = mul i64 %t533, 1
  %t536 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t535)
  call void @llvm.memcpy.p0.p0.i64(ptr %t536, ptr %t534, i64 %t535, i1 false)
  %t537 = insertvalue { i64, ptr } undef, i64 %t533, 0
  %t538 = insertvalue { i64, ptr } %t537, ptr %t536, 1
  %t539 = load i64, ptr %l16, !tbaa !24
  %t541 = icmp sge i64 %t539, 0
  %t542 = load ptr, ptr %l273, !tbaa !29
  %t543 = load i64, ptr %l274, !tbaa !24
  %t544 = load ptr, ptr %l275, !tbaa !29
  %t545 = load ptr, ptr %l276, !tbaa !29
  %t546 = load %"compiler/source:Span", ptr %l277
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v2, ptr %s0, ptr %s19, ptr %t542, i64 %t543, ptr %t544, ptr %t545, %"compiler/source:Span" %t546, { i64, ptr } %t538, i1 %t541)
  br label %bb145
bb145:
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/free:walker", ptr %t549, i32 0, i32 30
  store i64 -1, ptr %t551, !tbaa !24
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t554 = getelementptr %"compiler/free:walker", ptr %t552, i32 0, i32 31
  store i64 -1, ptr %t554, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb146:
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t557 = getelementptr %"compiler/free:walker", ptr %t555, i32 0, i32 0
  %t558 = load ptr, ptr %t557, !tbaa !29
  store ptr %t558, ptr %l288, !tbaa !29
  %t559 = load ptr, ptr %l2, !tbaa !29
  %t561 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t559)
  store i32 %t561, ptr %l290
  br label %bb147
bb147:
  %t562 = load ptr, ptr %l288, !tbaa !29
  %t563 = load i32, ptr %l290, !tbaa !23
  %t564 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t562, i32 %t563)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t564, ptr %l291
  br label %bb148
bb148:
  %t565 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l291
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t565, ptr %l21
  %t567 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s18, ptr %l21)
  store i64 %t567, ptr %l293
  br label %bb149
bb149:
  %t568 = load i64, ptr %l293, !tbaa !24
  %t569 = icmp sgt i64 %t568, 0
  br i1 %t569, label %bb150, label %bb151
bb150:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = load ptr, ptr %l3, !tbaa !29
  %t573 = load ptr, ptr %l6, !tbaa !29
  %t577 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoredWhole(ptr %v0, ptr %v2, ptr %v0, ptr %t571, ptr %t572, ptr %t573)
  store i1 %t577, ptr %l299
  br label %bb152
bb151:
  store i1 false, ptr %l295, !tbaa !21
  br label %bb153
bb152:
  %t578 = load i1, ptr %l299, !tbaa !21
  %t579 = xor i1 %t578, true
  store i1 %t579, ptr %l295, !tbaa !21
  br label %bb153
bb153:
  %t581 = load i1, ptr %l295, !tbaa !21
  br i1 %t581, label %bb154, label %bb155
bb154:
  %t582 = load ptr, ptr %l0, !tbaa !29
  store ptr %t582, ptr %l301, !tbaa !29
  store ptr %l21, ptr %l302, !tbaa !29
  %t583 = load ptr, ptr %l2, !tbaa !29
  %t585 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t583)
  store i32 %t585, ptr %l304
  br label %bb156
bb155:
  br label %bb159
bb156:
  %t586 = load ptr, ptr %l3, !tbaa !29
  %t587 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t589 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t587, ptr %t589
  %t590 = load %"compiler/source:Span", ptr %l1
  %t591 = load ptr, ptr %l6, !tbaa !29
  %t592 = load ptr, ptr %l301, !tbaa !29
  %t593 = load ptr, ptr %l302, !tbaa !29
  %t594 = load i32, ptr %l304, !tbaa !23
  %t599 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %s18, ptr %v2, ptr %s0, ptr %v0, ptr %s0, ptr %t592, ptr %t593, i32 %t594, ptr %t586, ptr %t589, %"compiler/source:Span" %t590, ptr %t591)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t599, ptr %l310
  br label %bb157
bb157:
  %t601 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l310)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t601, ptr %l312
  br label %bb158
bb158:
  %t602 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l312
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t602, ptr %l9
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s18)
  br label %bb165
bb160:
  br i1 true, label %bb161, label %bb162
bb161:
  br label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  call void @__olang_check_failed(ptr @olang_loc_e251e9e241135754_793c210c71879d50)
  unreachable
bb165:
  %t603 = load i64, ptr %l16, !tbaa !24
  %t605 = icmp slt i64 %t603, 0
  br i1 %t605, label %bb166, label %bb167
bb166:
  store %olang.scope zeroinitializer, ptr %s22
  %t607 = load ptr, ptr %l0, !tbaa !29
  store ptr %t607, ptr %l315, !tbaa !29
  store ptr %l9, ptr %l316, !tbaa !29
  %t608 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t608, ptr %l317
  %t609 = load ptr, ptr %l0, !tbaa !29
  store ptr %t609, ptr %l318, !tbaa !29
  %t610 = load ptr, ptr %l2, !tbaa !29
  %t612 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t610)
  store %"compiler/source:Span" %t612, ptr %l320
  br label %bb168
bb167:
  br label %bb172
bb168:
  %t613 = load ptr, ptr %l318, !tbaa !29
  %t614 = load %"compiler/source:Span", ptr %l320
  %t615 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s22, ptr %t613, %"compiler/source:Span" %t614)
  store { i64, ptr } %t615, ptr %l321
  br label %bb169
bb169:
  %t616 = load { i64, ptr }, ptr %l321, !tbaa !27
  %t617 = extractvalue { i64, ptr } %t616, 0
  %t618 = extractvalue { i64, ptr } %t616, 1
  %t619 = mul i64 %t617, 1
  %t620 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t619)
  call void @llvm.memcpy.p0.p0.i64(ptr %t620, ptr %t618, i64 %t619, i1 false)
  %t621 = insertvalue { i64, ptr } undef, i64 %t617, 0
  %t622 = insertvalue { i64, ptr } %t621, ptr %t620, 1
  store { i64, ptr } %t622, ptr %l322, !tbaa !27
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load ptr, ptr %l2, !tbaa !29
  %t627 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %t623, ptr %t624)
  store i64 %t627, ptr %l325
  br label %bb170
bb170:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr %"compiler/free:walker", ptr %t628, i32 0, i32 31
  %t631 = load i64, ptr %t630, !tbaa !24
  %t632 = load ptr, ptr %l315, !tbaa !29
  %t633 = load ptr, ptr %l316, !tbaa !29
  %t634 = load %"compiler/source:Span", ptr %l317
  %t635 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t636 = load i64, ptr %l325, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s0, ptr %s22, ptr %t632, ptr %t633, %"compiler/source:Span" %t634, { i64, ptr } %t635, i1 true, i64 %t636, i64 %t631)
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s22)
  br label %bb172
bb172:
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t640 = getelementptr %"compiler/free:walker", ptr %t638, i32 0, i32 30
  store i64 -1, ptr %t640, !tbaa !24
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t643 = getelementptr %"compiler/free:walker", ptr %t641, i32 0, i32 31
  store i64 -1, ptr %t643, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l6
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l6, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecloseAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i32
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i1
  %l27 = alloca ptr
  %l38 = alloca ptr
  %l44 = alloca %"compiler/typed:BlockInfo"
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 37
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Block", ptr %t4, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t12 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H1c6ff733ce949281236b08418b935189(ptr %v0, ptr %v0, ptr %t3, i64 %t9)
  %t13 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t12, 1
  %t14 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t12, 0
  store i32 %t14, ptr %l16
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb2, label %ok.16, !prof !99
ok.16:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l15
  br label %bb1
bb1:
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l18
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb5
bb5:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l2
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:walker", ptr %t21, i32 0, i32 37
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Block", ptr %t24, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = sext i32 %t27 to i64
  %t32 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H48be4d072aa67a39865369f0fe94a62c(ptr %v0, ptr %t23, i64 %t29)
  store i1 %t32, ptr %l24
  br label %bb6
bb6:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:walker", ptr %t33, i32 0, i32 11
  %t36 = load i64, ptr %t35, !tbaa !24
  store i64 %t36, ptr %l3, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l27, !tbaa !29
  %t39 = load ptr, ptr %l27, !tbaa !29
  %t40 = getelementptr %"compiler/free:walker", ptr %t39, i32 0, i32 11
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = add i64 %t41, 1
  %t45 = load ptr, ptr %l27, !tbaa !29
  %t46 = getelementptr %"compiler/free:walker", ptr %t45, i32 0, i32 11
  store i64 %t43, ptr %t46, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/free:walker", ptr %t47, i32 0, i32 13
  %t50 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t49, i64 %t50)
  br label %bb7
bb7:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 12
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l4, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = getelementptr %"compiler/free:walker", ptr %t58, i32 0, i32 12
  store i64 %t59, ptr %t62, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l38
  br label %bb8
bb8:
  %t66 = load ptr, ptr %l38, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Body", ptr %t66, i32 0, i32 8
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Block", ptr %t69, i32 0, i32 0
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = sext i32 %t72 to i64
  %t77 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t68, i64 %t74)
  store %"compiler/typed:BlockInfo" %t77, ptr %l44
  br label %bb9
bb9:
  %t78 = getelementptr %"compiler/typed:BlockInfo", ptr %l44, i32 0, i32 2
  %t79 = load %"compiler/source:Span", ptr %t78
  store %"compiler/source:Span" %t79, ptr %l5
  store ptr %l2, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t82 = load i64, ptr %l7, !tbaa !24
  store i64 %t82, ptr %l47, !tbaa !24
  %t83 = load ptr, ptr %l6, !tbaa !29
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t83)
  store i64 %t85, ptr %l49
  br label %bb11
bb11:
  %t86 = load i64, ptr %l47, !tbaa !24
  %t87 = load i64, ptr %l49, !tbaa !24
  %t88 = icmp slt i64 %t86, %t87
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t93 = load i64, ptr %l7, !tbaa !24
  %t96 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t92, i64 %t93)
  store i32 %t96, ptr %l54
  br label %bb15
bb15:
  %t97 = load i32, ptr %l54, !tbaa !23
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCallsOf(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, i32 %t97)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l7, !tbaa !24
  br label %bb10
bb18:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:walker", ptr %t108, i32 0, i32 13
  %t111 = load i64, ptr %l3, !tbaa !24
  %t112 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t110, i64 %t111, i64 %t112)
  br label %bb19
bb19:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i64, ptr %l4, !tbaa !24
  %t120 = getelementptr %"compiler/free:walker", ptr %t116, i32 0, i32 12
  store i64 %t117, ptr %t120, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eelemRead(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i1
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i64
  %l60 = alloca i64
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2ffree_2einElement(ptr %v1, ptr %a1)
  store i1 %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load i1, ptr %l12, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = getelementptr %"compiler/free:walker", ptr %a0, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t12)
  store i64 %t14, ptr %l17
  br label %bb5
bb5:
  %t15 = load i64, ptr %l17, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load i64, ptr %l7, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb11
bb8:
  %t26 = load i64, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l24, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t42 = load i64, ptr %l24, !tbaa !24
  store i64 %t42, ptr %l21, !tbaa !24
  br label %bb11
bb11:
  %t43 = load i64, ptr %l21, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t44 = load i64, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb13, label %bb14
bb13:
  br label %bb30
bb14:
  br label %bb15
bb15:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l10, !tbaa !24
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load i64, ptr %l10, !tbaa !24
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t62, i64 %t63)
  store i64 %t66, ptr %l44
  br label %bb16
bb16:
  %t67 = load i64, ptr %l44, !tbaa !24
  %t68 = call i64 @compiler_2ffree_2eokind(i64 %t67)
  store i64 %t68, ptr %l45
  br label %bb17
bb17:
  %t69 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t70 = load i64, ptr %l45, !tbaa !24
  %t72 = icmp eq i64 %t70, %t69
  br i1 %t72, label %bb18, label %bb19
bb18:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 12
  store ptr %t76, ptr %l50, !tbaa !29
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i64, ptr %l10, !tbaa !24
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t77, i64 %t78)
  store i64 %t81, ptr %l53
  br label %bb20
bb19:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb23
bb20:
  %t82 = load i64, ptr %l53, !tbaa !24
  %t83 = call i64 @compiler_2ffree_2eoval(i64 %t82)
  store i64 %t83, ptr %l54
  br label %bb21
bb21:
  %t84 = load ptr, ptr %l50, !tbaa !29
  %t85 = load i64, ptr %l54, !tbaa !24
  %t86 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t84, i64 %t85)
  store i1 %t86, ptr %l55
  br label %bb22
bb22:
  %t87 = load i1, ptr %l55, !tbaa !21
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb23
bb23:
  %t88 = load i1, ptr %l48, !tbaa !21
  br i1 %t88, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t89 = load ptr, ptr %l2, !tbaa !29
  store ptr %t89, ptr %l56, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l57, !tbaa !24
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t92 = load i64, ptr %l10, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l60
  br label %bb27
bb27:
  %t96 = load ptr, ptr %l56, !tbaa !29
  %t97 = load i64, ptr %l57, !tbaa !24
  %t98 = load i64, ptr %l60, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v2, ptr %t96, i64 %t97, i64 %t98)
  br label %bb28
bb28:
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l4, !tbaa !24
  br label %bb29
bb29:
  %t103 = load i64, ptr %l9, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l9, !tbaa !24
  br label %bb12
bb30:
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t108 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v2, ptr %t107, i64 %t108)
  br label %bb31
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %t9, ptr %a2)
  store i64 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp sgt i64 %t12, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/free:walker", ptr %t15, i32 0, i32 4
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t17, i64 %t18)
  store i1 %t21, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t22 = load i1, ptr %l14, !tbaa !21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l10, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/free:walker", ptr %t24, i32 0, i32 5
  store i1 true, ptr %t26, !tbaa !21
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eheldDrop(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l14 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i64
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 30 to i32
  %t4 = icmp eq i32 %a1, %t3
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp ne i64 %t10, 1
  store i1 %t12, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb5:
  %t17 = getelementptr %"compiler/free:walker", ptr %a0, i32 0, i32 54
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l21
  br label %bb6
bb6:
  %t20 = load i64, ptr %l21, !tbaa !24
  %t21 = icmp eq i64 %t20, 0
  store i1 %t21, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l18, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  store i64 -1, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 0
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l3, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  store ptr %t31, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t32 = load ptr, ptr %l26, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l26, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 18}
  %t38 = icmp eq i64 %t36, 3
  store i1 %t38, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l27, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb13, label %bb14
bb13:
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t45, i32 0, i32 0
  %t47 = load %"compiler/source:Span", ptr %t46
  store %"compiler/source:Span" %t47, ptr %l4
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 1
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l5, !tbaa !23
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l7, !tbaa !29
  %t63 = load ptr, ptr %l7, !tbaa !29
  store ptr %t63, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t64 = load ptr, ptr %l39, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb16, label %bb17
bb16:
  %t67 = load ptr, ptr %l39, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 8}
  %t70 = icmp eq i64 %t68, 0
  store i1 %t70, ptr %l40, !tbaa !21
  br label %bb17
bb17:
  %t71 = load i1, ptr %l40, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb18, label %bb19
bb18:
  store i64 -1, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t75 = load ptr, ptr %l7, !tbaa !29
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t77, i32 0, i32 0
  %t79 = load %"compiler/source:Span", ptr %t78
  store %"compiler/source:Span" %t79, ptr %l8
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l9, !tbaa !23
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t89, i32 0, i32 2
  %t91 = load i32, ptr %t90
  %t95 = sext i32 %t91 to i64
  store i64 %t95, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2einOwner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i1
  %l17 = alloca i64
  %l19 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i1
  %l33 = alloca i64
  %l36 = alloca i1
  %l40 = alloca i1
  %l44 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca i64
  %l50 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 29
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  store ptr %a1, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t18 = load i64, ptr %l6, !tbaa !24
  store i64 %t18, ptr %l17, !tbaa !24
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l19
  br label %bb8
bb8:
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = load i64, ptr %l19, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %bb33
bb10:
  br label %bb11
bb11:
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t28, i64 %t29)
  store i64 %t32, ptr %l24
  br label %bb12
bb12:
  %t33 = load i64, ptr %l24, !tbaa !24
  store i64 %t33, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = call i64 @compiler_2ffree_2eoval(i64 %t34)
  store i64 %t36, ptr %l26
  br label %bb13
bb13:
  %t37 = load i64, ptr %l26, !tbaa !24
  store i64 %t37, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t40 = call i64 @compiler_2ffree_2eokind(i64 %t38)
  store i64 %t40, ptr %l28
  br label %bb14
bb14:
  %t41 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  %t44 = icmp eq i64 %t42, %t41
  br i1 %t44, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb18
bb16:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = call i64 @compiler_2ffree_2eokind(i64 %t46)
  store i64 %t48, ptr %l33
  br label %bb17
bb17:
  %t49 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t50 = load i64, ptr %l33, !tbaa !24
  %t52 = icmp eq i64 %t50, %t49
  store i1 %t52, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t54 = load i1, ptr %l31, !tbaa !21
  br i1 %t54, label %bb19, label %bb20
bb19:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp ne i64 %t55, %a2
  store i1 %t59, ptr %l36, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/free:walker", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %t65, i64 %t66)
  store i1 %t69, ptr %l44
  br label %bb24
bb23:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb25
bb24:
  %t70 = load i1, ptr %l44, !tbaa !21
  store i1 %t70, ptr %l40, !tbaa !21
  br label %bb25
bb25:
  %t71 = load i1, ptr %l40, !tbaa !21
  br i1 %t71, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/free:walker", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  store ptr %t75, ptr %l46, !tbaa !29
  %t76 = load i64, ptr %l8, !tbaa !24
  store i64 %t76, ptr %l47, !tbaa !24
  %t77 = load i64, ptr @G_2ecompiler_2ffree_2eRInPlace, !tbaa !24
  store i64 %t77, ptr %l48, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t78)
  store ptr %t80, ptr %l50
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t81 = load ptr, ptr %l50, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Body", ptr %t81, i32 0, i32 3
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 %t84, ptr %l52, !tbaa !24
  %t85 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t85, ptr %l53
  store { i64, ptr } %a4, ptr %l54, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l3
  %t91 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s4, ptr %t87, %"compiler/source:Span" %t88)
  store { i64, ptr } %t91, ptr %l57
  br label %bb29
bb29:
  %t92 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t94 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = add i64 %t93, %t96
  %t98 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t101 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = add i64 %t100, %t103
  %t105 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t107 = add i64 %t104, %t106
  %t108 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t107)
  call void @olang_textcopy(ptr %t108, ptr %t92, i64 %t93)
  %t109 = getelementptr i8, ptr %t108, i64 %t93
  call void @olang_textcopy(ptr %t109, ptr %t95, i64 %t96)
  %t110 = getelementptr i8, ptr %t109, i64 %t96
  call void @olang_textcopy(ptr %t110, ptr %t98, i64 %t99)
  %t111 = getelementptr i8, ptr %t110, i64 %t99
  call void @olang_textcopy(ptr %t111, ptr %t102, i64 %t103)
  %t112 = getelementptr i8, ptr %t111, i64 %t103
  call void @olang_textcopy(ptr %t112, ptr %t105, i64 %t106)
  %t113 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t108, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = extractvalue { i64, ptr } %t114, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  %t122 = load ptr, ptr %l46, !tbaa !29
  %t123 = load i64, ptr %l47, !tbaa !24
  %t124 = load i64, ptr %l48, !tbaa !24
  %t125 = load i64, ptr %l52, !tbaa !24
  %t126 = load %"compiler/source:Span", ptr %l53
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s4, ptr %t122, i64 %t123, i64 %t124, i64 %t125, %"compiler/source:Span" %t126, { i64, ptr } %t121)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t128 = load i64, ptr %l6, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l6, !tbaa !24
  br label %bb7
bb33:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einsidePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l10 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ederefRoot(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %t11)
  store i64 %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load i64, ptr %l10, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2elambdaMade(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i64
  %l16 = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 56
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t6, i64 %t9)
  store ptr %t12, ptr %l7
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:walker", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t19 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t17, i64 %t16)
  store i64 %t19, ptr %l10
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/free:walker", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/free:Free", ptr %t23, i32 0, i32 34
  %t26 = load i32, ptr %l1, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t25, i64 %t28)
  store i1 %t31, ptr %l16
  br label %bb3
bb3:
  %t32 = load i1, ptr %l16, !tbaa !21
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:walker", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:walker", ptr %t37, i32 0, i32 1
  %t40 = load i64, ptr %t39, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t36, i64 %t40)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeStores(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i64
  %l39 = alloca i1
  %l48 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Make", ptr %t6, i32 0, i32 0
  %t9 = load i32, ptr %t8, !range !{i32 0, i32 5}
  %t11 = trunc i64 2 to i32
  %t12 = icmp eq i32 %t9, %t11
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 3 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l20, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l4, !tbaa !29
  store ptr %t27, ptr %l25, !tbaa !29
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t32 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t28, i32 %a2)
  store i32 %t32, ptr %l28
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l25, !tbaa !29
  %t34 = load i32, ptr %l28, !tbaa !23
  %t35 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t33, i32 %t34, i64 -1)
  store i64 %t35, ptr %l29
  br label %bb8
bb8:
  %t36 = load i64, ptr %l29, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t37, 0
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Make", ptr %t41, i32 0, i32 0
  %t44 = load i32, ptr %t43, !range !{i32 0, i32 5}
  %t46 = trunc i64 3 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 23
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  %t58 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t51, i64 %t55)
  store i1 %t58, ptr %l39
  br label %bb14
bb13:
  br label %bb25
bb14:
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Make", ptr %t60, i32 0, i32 2
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb19, label %bb20
bb19:
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t77 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t77, ptr %l48, !tbaa !27
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 %t78
  %t83 = load ptr, ptr %t82, !tbaa !39
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %t85, i64 %t86, ptr %t83, %"compiler/source:Span" %t88, i1 true)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb18
bb24:
  br label %ret
bb25:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Make", ptr %t97, i32 0, i32 2
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  store { i64, ptr } %t100, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  store i64 %t104, ptr %l12, !tbaa !24
  br label %bb26
bb26:
  %t106 = load i64, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t114 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t114, ptr %l65, !tbaa !27
  %t115 = load i64, ptr %l11, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr ptr, ptr %t118, i64 %t115
  %t120 = load ptr, ptr %t119, !tbaa !39
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l5, !tbaa !24
  %t125 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %t122, i64 %t123, ptr %t120, %"compiler/source:Span" %t125, i1 false)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l11, !tbaa !24
  br label %bb26
bb32:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l16 = alloca ptr
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i64
  %l22 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 61
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:walker", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t10, i64 %t14)
  store i1 %t17, ptr %l10
  br label %bb3
bb3:
  %t18 = load i1, ptr %l10, !tbaa !21
  %t19 = xor i1 %t18, true
  store i1 %t19, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l4, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 60
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t32, i64 %t33)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36, ptr %l20
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t37, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t38)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l22
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb10, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l21
  br label %bb9
bb9:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l13, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load i64, ptr %l13, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca i64
  %l40 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:walker", ptr %t31, i32 0, i32 6
  %t34 = load i32, ptr %l3, !tbaa !23
  %t36 = sext i32 %t34 to i64
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t33, i64 %t36)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l25
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb12, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l24, !tbaa !24
  store i64 %t44, ptr %l19, !tbaa !24
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t49 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store i64 %t49, ptr %l28
  br label %bb14
bb14:
  %t50 = load i64, ptr %l28, !tbaa !24
  store i64 %t50, ptr %l19, !tbaa !24
  br label %bb15
bb15:
  %t51 = load i64, ptr %l19, !tbaa !24
  store i64 %t51, ptr %l12, !tbaa !24
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_f81460935a0747e6_f4792861f5ca2502)
  unreachable
bb21:
  %t52 = load i64, ptr %l12, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb35
bb22:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb23, label %bb24
bb23:
  %t57 = load ptr, ptr %l29, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 17
  store i1 %t60, ptr %l30, !tbaa !21
  br label %bb24
bb24:
  %t61 = load i1, ptr %l30, !tbaa !21
  br i1 %t61, label %bb25, label %bb26
bb25:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l4, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t72 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store i64 %t72, ptr %l37
  br label %bb28
bb28:
  %t73 = load i64, ptr %l37, !tbaa !24
  store i64 %t73, ptr %l5, !tbaa !24
  br label %bb35
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t78 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  store i64 %t78, ptr %l40
  br label %bb33
bb33:
  %t79 = load i64, ptr %l40, !tbaa !24
  store i64 %t79, ptr %l5, !tbaa !24
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_e3a1bae50be73c47_b8cb15515377d683)
  unreachable
bb35:
  %t80 = load i64, ptr %l5, !tbaa !24
  store i64 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca i32
  %lp13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/free:leaf"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca i1
  %l36 = alloca i1
  %l47 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i32
  %l57 = alloca %"compiler/source:Span"
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca i64
  %l69 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca i64
  %l77 = alloca i1
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l85 = alloca i64
  %l90 = alloca %"compiler/free:leaf"
  %l91 = alloca ptr
  %l94 = alloca i64
  %l95 = alloca i64
  %l100 = alloca i1
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l4
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l5, !tbaa !23
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [4 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t29, i32 0, i32 2
  %t31 = load i32, ptr %t30
  %t35 = sext i32 %t31 to i64
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:walker", ptr %t36, i32 0, i32 35
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = icmp ne i64 %t35, %t39
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t44 = load i1, ptr %l24, !tbaa !21
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t47, i32 0, i32 0
  %t49 = load %"compiler/source:Span", ptr %t48
  store %"compiler/source:Span" %t49, ptr %l7
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t53, i32 0, i32 1
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l8, !tbaa !23
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t59, i32 0, i32 2
  %t61 = load i32, ptr %t60
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t63, i32 0, i32 33
  %t68 = sext i32 %t61 to i64
  %t71 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc57530578add1ad359c6d87470cc4752(ptr %v0, ptr %t65, i64 %t68)
  store i1 %t71, ptr %l47
  br label %bb8
bb7:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb9
bb8:
  %t72 = load i1, ptr %l47, !tbaa !21
  store i1 %t72, ptr %l36, !tbaa !21
  br label %bb9
bb9:
  %t73 = load i1, ptr %l36, !tbaa !21
  br i1 %t73, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t76, i32 0, i32 0
  %t78 = load %"compiler/source:Span", ptr %t77
  store %"compiler/source:Span" %t78, ptr %l10
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t82, i32 0, i32 1
  %t84 = load i32, ptr %t83
  store i32 %t84, ptr %l11, !tbaa !23
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t88, i32 0, i32 2
  %t90 = load i32, ptr %t89
  store i32 %t90, ptr %l12, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l54, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  store i32 %t93, ptr %l55, !tbaa !23
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t94)
  store %"compiler/source:Span" %t96, ptr %l57
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t97 = load ptr, ptr %l54, !tbaa !29
  %t98 = load i32, ptr %l55, !tbaa !23
  %t99 = load %"compiler/source:Span", ptr %l57
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %s1, ptr %t97, i32 %t98, %"compiler/source:Span" %t99, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d24, i32 0, i32 1) })
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t104 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t100, ptr %t101)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l60
  br label %bb15
bb15:
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t105, ptr %lp13
  %t106 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  %t107 = load ptr, ptr %lp13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %t107
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t110 = load ptr, ptr %lp13
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eelemRead(ptr %v0, ptr %v1, ptr %v2, ptr %t108, ptr %t109, ptr %t110)
  br label %bb16
bb16:
  %t114 = load ptr, ptr %l3, !tbaa !29
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t118 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t114, ptr %t115)
  store i64 %t118, ptr %l66
  br label %bb17
bb17:
  %t119 = load i64, ptr %l66, !tbaa !24
  store i64 %t119, ptr %l14, !tbaa !24
  %t120 = load i64, ptr %l14, !tbaa !24
  %t122 = icmp sge i64 %t120, 0
  br i1 %t122, label %bb18, label %bb19
bb18:
  %t124 = load ptr, ptr %lp13
  store ptr %t124, ptr %l69, !tbaa !29
  %t125 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = call i64 @compiler_2ffree_2eorig(i64 %t125, i64 %t126)
  store i64 %t129, ptr %l72
  br label %bb20
bb19:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t132 = load i32, ptr %l2, !tbaa !23
  %t136 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedRead(ptr %v0, ptr %v1, ptr %t130, ptr %t131, i32 %t132)
  store i1 %t136, ptr %l77
  br label %bb22
bb20:
  %t137 = load ptr, ptr %l69, !tbaa !29
  %t138 = load i64, ptr %l72, !tbaa !24
  %t139 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t137, i64 %t138)
  store i64 %t139, ptr %l73
  br label %bb21
bb21:
  br label %bb37
bb22:
  %t140 = load i1, ptr %l77, !tbaa !21
  %t141 = xor i1 %t140, true
  br i1 %t141, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t144 = load i32, ptr %l2, !tbaa !23
  %t147 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s5, ptr %t143, i32 %t144)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t147, ptr %l81
  br label %bb25
bb24:
  br label %bb36
bb25:
  %t148 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81
  %t149 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t148, ptr %t149
  store ptr %t149, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb26
bb26:
  %t151 = load i64, ptr %l16, !tbaa !24
  store i64 %t151, ptr %l83, !tbaa !24
  %t152 = load ptr, ptr %l15, !tbaa !29
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s5, ptr %t152)
  store i64 %t154, ptr %l85
  br label %bb27
bb27:
  %t155 = load i64, ptr %l83, !tbaa !24
  %t156 = load i64, ptr %l85, !tbaa !24
  %t157 = icmp slt i64 %t155, %t156
  %t159 = xor i1 %t157, true
  br i1 %t159, label %bb28, label %bb29
bb28:
  br label %bb35
bb29:
  br label %bb30
bb30:
  %t161 = load ptr, ptr %l15, !tbaa !29
  %t162 = load i64, ptr %l16, !tbaa !24
  %t165 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s5, ptr %s5, ptr %t161, i64 %t162)
  store %"compiler/free:leaf" %t165, ptr %l90
  br label %bb31
bb31:
  %t166 = load %"compiler/free:leaf", ptr %l90
  store %"compiler/free:leaf" %t166, ptr %l17
  %t167 = load ptr, ptr %lp13
  store ptr %t167, ptr %l91, !tbaa !29
  %t168 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t169 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 1
  %t170 = load i64, ptr %t169, !tbaa !24
  %t173 = call i64 @compiler_2ffree_2eorig(i64 %t168, i64 %t170)
  store i64 %t173, ptr %l94
  br label %bb32
bb32:
  %t174 = load ptr, ptr %l91, !tbaa !29
  %t175 = load i64, ptr %l94, !tbaa !24
  %t176 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t174, i64 %t175)
  store i64 %t176, ptr %l95
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t177 = load i64, ptr %l16, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l16, !tbaa !24
  br label %bb26
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l2, !tbaa !23
  %t185 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %t181, i32 %t182)
  store i1 %t185, ptr %l100
  br label %bb38
bb38:
  %t186 = load i1, ptr %l100, !tbaa !21
  br i1 %t186, label %bb39, label %bb40
bb39:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %lp13
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v2, ptr %t187, ptr %t188)
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  %t191 = load ptr, ptr %lp13
  %t192 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t191
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t192, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eregisteredAt(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, [1 x i64] }
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i64
  %l27 = alloca %"compiler/typed:Plan"
  %l29 = alloca %"compiler/typed:Plan"
  %l37 = alloca %"compiler/typed:Plan"
  %l39 = alloca %"compiler/typed:Plan"
  %l40 = alloca { i64, ptr }
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca i32
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca i1
  %s0 = alloca %olang.scope
  %t6 = alloca { i64, [1 x i64] }, align 8
  %t38 = alloca %"compiler/typed:Plan", align 8
  %t41 = alloca %"compiler/typed:Plan", align 8
  %t59 = alloca %"compiler/typed:Plan", align 8
  %t62 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [1 x i64] }, ptr %t6, i32 0, i32 0
  store i64 0, ptr %t7
  %t8 = load { i64, [1 x i64] }, ptr %t6
  store { i64, [1 x i64] } %t8, ptr %l4
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/free:walker", ptr %t10, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l12, !tbaa !24
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = getelementptr %"compiler/free:Free", ptr %t14, i32 0, i32 3
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l15
  br label %bb1
bb1:
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = load i64, ptr %l15, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = icmp sge i32 %t23, 0
  store i1 %t25, ptr %l17, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb4
bb4:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l1, !tbaa !23
  %t30 = sext i32 %t28 to i64
  store i64 %t30, ptr %l22, !tbaa !24
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 3
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:walker", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %t36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t38, ptr %v0, ptr %v0, ptr %t33, i64 %t37)
  call void @llvm.memmove.p0.p0.i64(ptr %l27, ptr %t38, i64 224, i1 false)
  br label %bb7
bb6:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb7:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t41, ptr %v0, ptr %l27)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t41, i64 224, i1 false)
  br label %bb8
bb8:
  %t43 = getelementptr %"compiler/typed:Plan", ptr %l29, i32 0, i32 0
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = load i64, ptr %l22, !tbaa !24
  %t49 = icmp slt i64 %t47, %t46
  store i1 %t49, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t51 = load i1, ptr %l20, !tbaa !21
  br i1 %t51, label %bb10, label %bb11
bb10:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = getelementptr %"compiler/free:Free", ptr %t52, i32 0, i32 3
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/free:walker", ptr %t55, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t59, ptr %v0, ptr %v0, ptr %t54, i64 %t58)
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %t59, i64 224, i1 false)
  br label %bb12
bb11:
  br label %bb14
bb12:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t62, ptr %v0, ptr %l37)
  call void @llvm.memmove.p0.p0.i64(ptr %l39, ptr %t62, i64 224, i1 false)
  br label %bb13
bb13:
  %t64 = getelementptr %"compiler/typed:Plan", ptr %l39, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l40, !tbaa !27
  %t66 = load i32, ptr %l1, !tbaa !23
  %t68 = sext i32 %t66 to i64
  %t70 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, [1 x i64] }, ptr %t71, i64 %t68
  %t73 = load { i64, [1 x i64] }, ptr %t72
  store { i64, [1 x i64] } %t73, ptr %l4
  br label %bb14
bb14:
  %t75 = load { i64, [1 x i64] }, ptr %l4
  %t77 = extractvalue { i64, [1 x i64] } %t75, 0
  %t78 = icmp eq i64 %t77, 1
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t83 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eregister(ptr %v0, ptr %t82, i32 %t83)
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  %t86 = getelementptr { i64, [1 x i64] }, ptr %l4, i32 0, i32 1
  %t87 = getelementptr { i32 }, ptr %t86, i32 0, i32 0
  %t88 = load i32, ptr %t87
  %t92 = sext i32 %t88 to i64
  store i64 %t92, ptr %l6, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/free:walker", ptr %t94, i32 0, i32 37
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H1c6ff733ce949281236b08418b935189(ptr %v0, ptr %v0, ptr %t96, i64 %t97)
  %t101 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t100, 1
  %t102 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t100, 0
  store i32 %t102, ptr %l57
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb20, label %ok.104, !prof !99
ok.104:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t101, ptr %l56
  br label %bb19
bb19:
  %t106 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l56)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %l59
  br label %bb22
bb20:
  br label %bb21
bb21:
  %t107 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l60
  br label %bb23
bb22:
  %t108 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l52
  br label %bb24
bb23:
  %t109 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l52
  br label %bb24
bb24:
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %l7
  %t111 = load i32, ptr %l2, !tbaa !23
  %t114 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i32 %t111)
  store i1 %t114, ptr %l63
  br label %bb25
bb25:
  %t115 = load i1, ptr %l63, !tbaa !21
  %t116 = xor i1 %t115, true
  br i1 %t116, label %bb26, label %bb27
bb26:
  %t118 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i32 %t118)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/free:walker", ptr %t121, i32 0, i32 37
  %t124 = load i64, ptr %l6, !tbaa !24
  %t125 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4057097bf127937e673a7f89a723e29a(ptr %v0, ptr %s0, ptr %t123, i64 %t124, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t125)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2eremoves(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l48 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i1
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l64 = alloca %"compiler/source:Span"
  %l67 = alloca i1
  %l70 = alloca i1
  %l75 = alloca i1
  %l77 = alloca ptr
  %l79 = alloca ptr
  %l81 = alloca i64
  %l85 = alloca %"compiler/source:Span"
  %l86 = alloca { i64, ptr }
  %l92 = alloca i1
  %l95 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i1
  %l108 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t5, ptr %l15, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l16, !tbaa !24
  %t8 = load i64, ptr %l16, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l17, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l16, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:walker", ptr %t21, i32 0, i32 44
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l20
  br label %bb4
bb4:
  %t26 = load i64, ptr %l20, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb10
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l27, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l27, !tbaa !24
  store i64 %t53, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l24, !tbaa !24
  store i64 %t54, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load i64, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb62
bb13:
  br label %bb14
bb14:
  %t63 = load i64, ptr %l2, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l4, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l7, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 49
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  store i64 %t79, ptr %l48
  br label %bb15
bb15:
  %t80 = load i64, ptr %l48, !tbaa !24
  store i64 %t80, ptr %l8, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:walker", ptr %t81, i32 0, i32 44
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l52
  br label %bb16
bb16:
  %t88 = load i64, ptr %l1, !tbaa !24
  %t89 = load i64, ptr %l52, !tbaa !24
  %t91 = icmp ne i64 %t89, %t88
  br i1 %t91, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb21
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/free:walker", ptr %t93, i32 0, i32 48
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t95, i64 %t96)
  store %"compiler/source:Span" %t99, ptr %l59
  br label %bb19
bb19:
  %t100 = getelementptr %"compiler/source:Span", ptr %l59, i32 0, i32 0
  %t101 = load i32, ptr %t100, !tbaa !23
  store i32 %t101, ptr %l60, !tbaa !23
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/free:walker", ptr %t102, i32 0, i32 48
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t104, i64 %t105)
  store %"compiler/source:Span" %t108, ptr %l64
  br label %bb20
bb20:
  %t109 = getelementptr %"compiler/source:Span", ptr %l64, i32 0, i32 1
  %t110 = load i32, ptr %t109, !tbaa !23
  %t111 = load i32, ptr %l60, !tbaa !23
  %t113 = icmp sge i32 %t111, %t110
  store i1 %t113, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t115 = load i1, ptr %l55, !tbaa !21
  br i1 %t115, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb24
bb23:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  store i1 %t118, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t120 = load i1, ptr %l67, !tbaa !21
  br i1 %t120, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb28
bb26:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/free:walker", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/free:Free", ptr %t124, i32 0, i32 22
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t126, i64 %t127)
  store i1 %t130, ptr %l75
  br label %bb27
bb27:
  %t131 = load i1, ptr %l75, !tbaa !21
  store i1 %t131, ptr %l70, !tbaa !21
  br label %bb28
bb28:
  %t132 = load i1, ptr %l70, !tbaa !21
  br i1 %t132, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb30:
  br label %bb31
bb31:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/free:walker", ptr %t133, i32 0, i32 0
  %t136 = load ptr, ptr %t135, !tbaa !29
  store ptr %t136, ptr %l77, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t137)
  store ptr %t139, ptr %l79
  br label %bb32
bb32:
  %t140 = load ptr, ptr %l79, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Body", ptr %t140, i32 0, i32 3
  %t143 = load i64, ptr %t142, !tbaa !24
  store i64 %t143, ptr %l81, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/free:walker", ptr %t144, i32 0, i32 48
  %t147 = load i64, ptr %l7, !tbaa !24
  %t150 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t146, i64 %t147)
  store %"compiler/source:Span" %t150, ptr %l85
  br label %bb33
bb33:
  %t151 = load ptr, ptr %l77, !tbaa !29
  %t152 = load i64, ptr %l81, !tbaa !24
  %t153 = load %"compiler/source:Span", ptr %l85
  %t154 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s3, ptr %t151, i64 %t152, %"compiler/source:Span" %t153)
  store { i64, ptr } %t154, ptr %l86
  br label %bb34
bb34:
  %t155 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t155, ptr %l9, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t160 = sub i64 %t158, 1
  store i64 %t160, ptr %l10, !tbaa !24
  br label %bb35
bb35:
  %t162 = load i64, ptr %l10, !tbaa !24
  %t164 = icmp sge i64 %t162, 0
  br i1 %t164, label %bb36, label %bb37
bb36:
  %t166 = load i64, ptr %l10, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i8, ptr %t169, i64 %t166
  %t171 = load i8, ptr %t170, !tbaa !32
  %t173 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t171)
  store i1 %t173, ptr %l95
  br label %bb38
bb37:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb46
bb38:
  %t174 = load i1, ptr %l95, !tbaa !21
  br i1 %t174, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb42
bb40:
  %t175 = load i64, ptr %l10, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i8, ptr %t178, i64 %t175
  %t180 = load i8, ptr %t179, !tbaa !32
  %t182 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t180)
  store i1 %t182, ptr %l99
  br label %bb41
bb41:
  %t183 = load i1, ptr %l99, !tbaa !21
  store i1 %t183, ptr %l96, !tbaa !21
  br label %bb42
bb42:
  %t184 = load i1, ptr %l96, !tbaa !21
  br i1 %t184, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb45
bb44:
  %t185 = load i64, ptr %l10, !tbaa !24
  %t187 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i8, ptr %t188, i64 %t185
  %t190 = load i8, ptr %t189, !tbaa !32
  %t192 = icmp eq i8 %t190, 95
  store i1 %t192, ptr %l100, !tbaa !21
  br label %bb45
bb45:
  %t194 = load i1, ptr %l100, !tbaa !21
  store i1 %t194, ptr %l92, !tbaa !21
  br label %bb46
bb46:
  %t195 = load i1, ptr %l92, !tbaa !21
  %t196 = xor i1 %t195, true
  br i1 %t196, label %bb47, label %bb48
bb47:
  br label %bb51
bb48:
  br label %bb49
bb49:
  %t198 = load i64, ptr %l10, !tbaa !24
  %t200 = sub i64 %t198, 1
  store i64 %t200, ptr %l10, !tbaa !24
  br label %bb50
bb50:
  br label %bb35
bb51:
  %t202 = load i64, ptr %l10, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l108, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  store i64 %t207, ptr %l110, !tbaa !24
  %t208 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  store i64 %t209, ptr %l111, !tbaa !24
  %t210 = load i64, ptr %l108, !tbaa !24
  %t211 = icmp sge i64 %t210, 0
  br i1 %t211, label %bb52, label %bb53
bb52:
  %t213 = load i64, ptr %l108, !tbaa !24
  %t214 = load i64, ptr %l110, !tbaa !24
  %t215 = icmp sle i64 %t213, %t214
  br i1 %t215, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_3f338d8afa9da51a_e8058e9e002c9166)
  unreachable
bb54:
  %t217 = load i64, ptr %l110, !tbaa !24
  %t218 = load i64, ptr %l111, !tbaa !24
  %t219 = icmp sle i64 %t217, %t218
  br i1 %t219, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_3f338d8afa9da51a_e8058e9e002c9166)
  unreachable
bb56:
  %t221 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = load i64, ptr %l108, !tbaa !24
  %t224 = load i64, ptr %l110, !tbaa !24
  %t225 = getelementptr i8, ptr %t222, i64 %t223
  %t226 = sub i64 %t224, %t223
  %t227 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t225, 1
  store { i64, ptr } %t228, ptr %l11, !tbaa !27
  %t230 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t234 = icmp sgt i64 %t232, 0
  br i1 %t234, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_3f338d8afa9da51a_e8058e9e002c9166)
  unreachable
bb58:
  %t236 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t237 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t240 = extractvalue { i64, ptr } %t236, 1
  %t241 = extractvalue { i64, ptr } %t236, 0
  %t242 = add i64 %t238, %t241
  %t243 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t242)
  call void @olang_textcopy(ptr %t243, ptr %t237, i64 %t238)
  %t244 = getelementptr i8, ptr %t243, i64 %t238
  call void @olang_textcopy(ptr %t244, ptr %t240, i64 %t241)
  %t245 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t243, 1
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t246, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb61:
  %t248 = load i64, ptr %l6, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l6, !tbaa !24
  br label %bb11
bb62:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l123, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t252, ptr %l124, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  store i64 %t254, ptr %l125, !tbaa !24
  %t255 = load i64, ptr %l125, !tbaa !24
  %t256 = mul i64 %t255, 1
  %t257 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t256)
  %t258 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  store { i64, ptr } %t259, ptr %l126, !tbaa !27
  %t260 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = load i64, ptr %l125, !tbaa !24
  %t265 = mul i64 %t264, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t261, ptr %t263, i64 %t265, i1 false)
  %t266 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t266, ptr %l124, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t267, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereturnedOwnLocals(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load i64, ptr %l14, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = call i64 @compiler_2ffree_2eokind(i64 %t19)
  store i64 %t21, ptr %l16
  br label %bb7
bb7:
  %t22 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t23 = load i64, ptr %l16, !tbaa !24
  %t25 = icmp eq i64 %t23, %t22
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:walker", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = call i64 @compiler_2ffree_2eoval(i64 %t31)
  store i64 %t33, ptr %l23
  br label %bb10
bb9:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb12
bb10:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisOwnLocal(ptr %v0, ptr %t34, i64 %t35)
  store i1 %t36, ptr %l24
  br label %bb11
bb11:
  %t37 = load i1, ptr %l24, !tbaa !21
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:walker", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l26, !tbaa !29
  %t43 = load i64, ptr %l5, !tbaa !24
  %t45 = call i64 @compiler_2ffree_2eoval(i64 %t43)
  store i64 %t45, ptr %l28
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t46 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t46, ptr %l29, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t47)
  store ptr %t49, ptr %l31
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l31, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 3
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load i64, ptr %l28, !tbaa !24
  %t57 = load i64, ptr %l29, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s3, ptr %t55, i64 %t56, i64 %t57, i64 %t53, %"compiler/source:Span" %a2, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l4, !tbaa !24
  br label %bb1
bb20:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoredWhole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l10 = alloca i64
  %l17 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = icmp eq ptr %a2, null
  %t5 = xor i1 %t3, true
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %t8, ptr %a1)
  store i64 %t12, ptr %l10
  br label %bb4
bb4:
  %t13 = load i64, ptr %l10, !tbaa !24
  store i64 %t13, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp slt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/free:walker", ptr %t19, i32 0, i32 2
  %t22 = load i1, ptr %t21, !tbaa !21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:walker", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t38 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t31, i64 %t35)
  store ptr %t38, ptr %l23
  br label %bb10
bb9:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb12
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l23, !tbaa !29
  %t42 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t40, i64 %t39)
  store i64 %t42, ptr %l25
  br label %bb11
bb11:
  %t43 = load i64, ptr %l25, !tbaa !24
  %t44 = icmp sgt i64 %t43, 0
  store i1 %t44, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l17, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/free:walker", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/free:Free", ptr %t50, i32 0, i32 36
  store i1 true, ptr %t52, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t5)
  store ptr %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t16 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %t13, i64 %t11, %"compiler/source:Span" %a1)
  store { i64, ptr } %t16, ptr %l9
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca i64
  %l32 = alloca i64
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l47 = alloca i32
  %l49 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i64
  %l57 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 29
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l10, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %s2, ptr %t19, i32 %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l17
  br label %bb7
bb7:
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s2, ptr %l17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l19
  br label %bb8
bb8:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t27 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t27
  store ptr %t27, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load i64, ptr %l5, !tbaa !24
  store i64 %t29, ptr %l21, !tbaa !24
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t30)
  store i64 %t32, ptr %l23
  br label %bb10
bb10:
  %t33 = load i64, ptr %l21, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = icmp slt i64 %t33, %t34
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb12:
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l4, !tbaa !29
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l28
  br label %bb14
bb14:
  %t44 = load i64, ptr %l28, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/free:walker", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/free:Free", ptr %t48, i32 0, i32 66
  %t51 = load i1, ptr %t50, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t53 = load i64, ptr %l6, !tbaa !24
  store i64 %t53, ptr %l32, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/free:walker", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/free:Free", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/load:Loader", ptr %t63, i32 0, i32 4
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l37, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t67)
  store ptr %t69, ptr %l39
  br label %bb17
bb16:
  br label %bb25
bb17:
  %t70 = load ptr, ptr %l39, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 3
  %t73 = load i64, ptr %t72, !tbaa !24
  %t74 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t75 = load i32, ptr %t74, !tbaa !23
  %t77 = sext i32 %t75 to i64
  %t78 = load ptr, ptr %l37, !tbaa !29
  %t81 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s4, ptr %t78, i64 %t73, i64 %t77)
  store { i64, ptr } %t81, ptr %l44
  br label %bb18
bb18:
  %t82 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t84 = load i64, ptr %l32, !tbaa !24
  %t85 = call i64 @__olang_fmt_i64(ptr null, i64 %t84)
  %t86 = add i64 %t83, %t85
  %t87 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t90 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = add i64 %t89, %t92
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t82, i64 %t83)
  %t98 = getelementptr i8, ptr %t97, i64 %t83
  %t99 = call i64 @__olang_fmt_i64(ptr %t98, i64 %t84)
  %t100 = getelementptr i8, ptr %t98, i64 %t85
  call void @olang_textcopy(ptr %t100, ptr %t87, i64 %t88)
  %t101 = getelementptr i8, ptr %t100, i64 %t88
  call void @olang_textcopy(ptr %t101, ptr %t91, i64 %t92)
  %t102 = getelementptr i8, ptr %t101, i64 %t92
  call void @olang_textcopy(ptr %t102, ptr %t94, i64 %t95)
  %t103 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t97, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t113 = call i32 @std_2fio_2ePrintErr(ptr %s4, { i64, ptr } %t111)
  store i32 %t113, ptr %l47
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb20, label %ok.115, !prof !99
ok.115:
  br label %bb19
bb19:
  br label %bb24
bb20:
  %t116 = load i32, ptr %l47, !tbaa !23
  %t117 = ashr i32 %t116, 16
  %t119 = icmp eq i32 %t117, 1
  store i1 %t119, ptr %l49, !tbaa !21
  %t120 = load i32, ptr %l47, !tbaa !23
  %t121 = ashr i32 %t120, 16
  %t123 = icmp eq i32 %t121, 1
  br i1 %t123, label %bb21, label %bb22
bb21:
  call void @__olang_errpay_pop()
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:walker", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  store ptr %t128, ptr %l53, !tbaa !29
  %t129 = load i64, ptr %l6, !tbaa !24
  store i64 %t129, ptr %l54, !tbaa !24
  %t130 = load i64, ptr @G_2ecompiler_2ffree_2eRCopied, !tbaa !24
  store i64 %t130, ptr %l55, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t131)
  store ptr %t133, ptr %l57
  br label %bb26
bb26:
  %t134 = load ptr, ptr %l57, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Body", ptr %t134, i32 0, i32 3
  %t137 = load i64, ptr %t136, !tbaa !24
  store i64 %t137, ptr %l59, !tbaa !24
  %t138 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t138, ptr %l60
  store { i64, ptr } %a3, ptr %l61, !tbaa !27
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l2
  %t144 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s3, ptr %t140, %"compiler/source:Span" %t141)
  store { i64, ptr } %t144, ptr %l64
  br label %bb27
bb27:
  %t145 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t147 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = add i64 %t146, %t149
  %t151 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t153 = add i64 %t150, %t152
  %t154 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = add i64 %t153, %t156
  %t158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t160 = add i64 %t157, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t145, i64 %t146)
  %t162 = getelementptr i8, ptr %t161, i64 %t146
  call void @olang_textcopy(ptr %t162, ptr %t148, i64 %t149)
  %t163 = getelementptr i8, ptr %t162, i64 %t149
  call void @olang_textcopy(ptr %t163, ptr %t151, i64 %t152)
  %t164 = getelementptr i8, ptr %t163, i64 %t152
  call void @olang_textcopy(ptr %t164, ptr %t155, i64 %t156)
  %t165 = getelementptr i8, ptr %t164, i64 %t156
  call void @olang_textcopy(ptr %t165, ptr %t158, i64 %t159)
  %t166 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t161, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = extractvalue { i64, ptr } %t167, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t175 = load ptr, ptr %l53, !tbaa !29
  %t176 = load i64, ptr %l54, !tbaa !24
  %t177 = load i64, ptr %l55, !tbaa !24
  %t178 = load i64, ptr %l59, !tbaa !24
  %t179 = load %"compiler/source:Span", ptr %l60
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s3, ptr %t175, i64 %t176, i64 %t177, i64 %t178, %"compiler/source:Span" %t179, { i64, ptr } %t174)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  %t181 = load i64, ptr %l5, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l5, !tbaa !24
  br label %bb9
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l19 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca i64
  %l29 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l37 = alloca i64
  %l39 = alloca ptr
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l49 = alloca i32
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  store i64 %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load i64, ptr %l13, !tbaa !24
  store i64 %t11, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 2
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb3:
  br label %bb12
bb4:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = getelementptr %"compiler/free:Free", ptr %t23, i32 0, i32 29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:walker", ptr %t26, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t25, i64 %t29)
  store ptr %t32, ptr %l24
  br label %bb6
bb5:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb8
bb6:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l24, !tbaa !29
  %t36 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t34, i64 %t33)
  store i64 %t36, ptr %l26
  br label %bb7
bb7:
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = icmp sgt i64 %t37, 0
  store i1 %t38, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l19, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t41 = load ptr, ptr %l4, !tbaa !29
  %t43 = getelementptr %"compiler/free:Free", ptr %t41, i32 0, i32 36
  store i1 true, ptr %t43, !tbaa !21
  br label %bb11
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t44 = load ptr, ptr %l4, !tbaa !29
  store ptr %t44, ptr %l29, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t45)
  store i32 %t47, ptr %l31
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l29, !tbaa !29
  %t49 = load i32, ptr %l31, !tbaa !23
  %t50 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t48, i32 %t49)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l32
  br label %bb14
bb14:
  %t51 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l6
  %t53 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s0, ptr %l6)
  store i64 %t53, ptr %l34
  br label %bb15
bb15:
  %t54 = load i64, ptr %l34, !tbaa !24
  %t55 = icmp eq i64 %t54, 0
  br i1 %t55, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = call i64 @compiler_2ffree_2eownCopySite(ptr %v1, ptr %t57)
  store i64 %t59, ptr %l37
  br label %bb19
bb19:
  %t60 = load i64, ptr %l37, !tbaa !24
  %t61 = icmp sge i64 %t60, 0
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l39, !tbaa !29
  br label %bb22
bb21:
  store ptr null, ptr %l39, !tbaa !29
  br label %bb22
bb22:
  %t66 = load ptr, ptr %l39, !tbaa !29
  store ptr %t66, ptr %l7, !tbaa !29
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l43
  %t71 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l43)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %l45
  br label %bb23
bb23:
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l8
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l46, !tbaa !29
  store ptr %l6, ptr %l47, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t74)
  store i32 %t76, ptr %l49
  br label %bb24
bb24:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t80 = load ptr, ptr %l46, !tbaa !29
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = load i32, ptr %l49, !tbaa !23
  %t87 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %s0, ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t80, ptr %t81, i32 %t82, ptr %t77, ptr %l8, %"compiler/source:Span" %a3, ptr %t79)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l54
  br label %bb25
bb25:
  %t89 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l54)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l56
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewritable(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i1
  %l17 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t18 = trunc i64 20 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t25, ptr %l17
  br label %bb6
bb5:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t26 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t27 = load i64, ptr %l17, !tbaa !24
  %t29 = and i64 %t27, %t26
  %t31 = icmp ne i64 %t29, 0
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l14, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i1
  %l70 = alloca ptr
  %l73 = alloca ptr
  %l76 = alloca ptr
  %l80 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l99 = alloca ptr
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca i1
  %l120 = alloca ptr
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l21
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l21, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  br label %bb81
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t23 = load ptr, ptr %l22, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l22, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 17}
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l23, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [3 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb19
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t44 = load i64, ptr %l1, !tbaa !24
  %t47 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %s2, ptr %t43, i64 %t44)
  store ptr %t47, ptr %l32
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l32, !tbaa !29
  %t49 = icmp eq ptr %t48, null
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t54 = load i64, ptr %l1, !tbaa !24
  %t57 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t53, i64 %t54)
  store ptr %t57, ptr %l38
  br label %bb16
bb15:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t62 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %t58, i64 %t59)
  store ptr %t62, ptr %l41
  br label %bb17
bb16:
  %t63 = load ptr, ptr %l38, !tbaa !29
  store ptr %t63, ptr %l35, !tbaa !29
  br label %bb18
bb17:
  %t64 = load ptr, ptr %l41, !tbaa !29
  store ptr %t64, ptr %l35, !tbaa !29
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l35, !tbaa !29
  store ptr %t65, ptr %l12, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  br label %bb81
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t67 = load ptr, ptr %l42, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = load ptr, ptr %l42, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 17}
  %t73 = icmp eq i64 %t71, 2
  store i1 %t73, ptr %l43, !tbaa !21
  br label %bb21
bb21:
  %t74 = load i1, ptr %l43, !tbaa !21
  br i1 %t74, label %bb22, label %bb23
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr { i64, [3 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", ptr }, ptr %t77, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l5, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  %t85 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t81, i64 %t82)
  store ptr %t85, ptr %l50
  br label %bb25
bb25:
  %t86 = load ptr, ptr %l50, !tbaa !29
  store ptr %t86, ptr %l12, !tbaa !29
  br label %bb81
bb26:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t88 = load ptr, ptr %l51, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb27, label %bb28
bb27:
  %t91 = load ptr, ptr %l51, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 17}
  %t94 = icmp eq i64 %t92, 3
  store i1 %t94, ptr %l52, !tbaa !21
  br label %bb28
bb28:
  %t95 = load i1, ptr %l52, !tbaa !21
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr { i64, [3 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l6, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t103 = load i64, ptr %l1, !tbaa !24
  %t106 = call ptr @compiler_2ffree_2efindIf(ptr %v0, ptr %v1, ptr %t102, i64 %t103)
  store ptr %t106, ptr %l59
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l59, !tbaa !29
  store ptr %t107, ptr %l12, !tbaa !29
  br label %bb81
bb33:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t109 = load ptr, ptr %l60, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t112 = load ptr, ptr %l60, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 17}
  %t115 = icmp eq i64 %t113, 4
  store i1 %t115, ptr %l61, !tbaa !21
  br label %bb35
bb35:
  %t116 = load i1, ptr %l61, !tbaa !21
  br i1 %t116, label %bb36, label %bb37
bb36:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l7, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr { i64, [3 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t125, i32 0, i32 2
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l8, !tbaa !29
  br label %bb38
bb37:
  br label %bb48
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t129 = load ptr, ptr %l7, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  %t133 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %s5, ptr %t129, i64 %t130)
  store ptr %t133, ptr %l70
  br label %bb39
bb39:
  %t134 = load ptr, ptr %l70, !tbaa !29
  %t135 = icmp eq ptr %t134, null
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb40, label %bb41
bb40:
  %t139 = load ptr, ptr %l7, !tbaa !29
  %t140 = load i64, ptr %l1, !tbaa !24
  %t143 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %v1, ptr %t139, i64 %t140)
  store ptr %t143, ptr %l76
  br label %bb42
bb41:
  %t144 = load ptr, ptr %l8, !tbaa !29
  %t146 = icmp eq ptr %t144, null
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb43, label %bb44
bb42:
  %t150 = load ptr, ptr %l76, !tbaa !29
  store ptr %t150, ptr %l73, !tbaa !29
  br label %bb47
bb43:
  %t151 = load ptr, ptr %l8, !tbaa !29
  %t152 = load i64, ptr %l1, !tbaa !24
  %t155 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %v1, ptr %t151, i64 %t152)
  store ptr %t155, ptr %l83
  br label %bb45
bb44:
  store ptr null, ptr %l80, !tbaa !29
  br label %bb46
bb45:
  %t156 = load ptr, ptr %l83, !tbaa !29
  store ptr %t156, ptr %l80, !tbaa !29
  br label %bb46
bb46:
  %t157 = load ptr, ptr %l80, !tbaa !29
  store ptr %t157, ptr %l73, !tbaa !29
  br label %bb47
bb47:
  %t158 = load ptr, ptr %l73, !tbaa !29
  store ptr %t158, ptr %l12, !tbaa !29
  call void @__olang_scope_close(ptr %s5)
  br label %bb81
bb48:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t160 = load ptr, ptr %l84, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb49, label %bb50
bb49:
  %t163 = load ptr, ptr %l84, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 17}
  %t166 = icmp eq i64 %t164, 6
  store i1 %t166, ptr %l85, !tbaa !21
  br label %bb50
bb50:
  %t167 = load i1, ptr %l85, !tbaa !21
  br i1 %t167, label %bb51, label %bb52
bb51:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr }, ptr %t170, i32 0, i32 1
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l9, !tbaa !29
  br label %bb57
bb52:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t175 = load ptr, ptr %l90, !tbaa !29
  %t176 = icmp ne ptr %t175, null
  br i1 %t176, label %bb53, label %bb54
bb53:
  %t178 = load ptr, ptr %l90, !tbaa !29
  %t179 = load i64, ptr %t178, !range !{i64 0, i64 17}
  %t181 = icmp eq i64 %t179, 16
  store i1 %t181, ptr %l91, !tbaa !21
  br label %bb54
bb54:
  %t182 = load i1, ptr %l91, !tbaa !21
  br i1 %t182, label %bb55, label %bb56
bb55:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr { i64, [3 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", ptr }, ptr %t185, i32 0, i32 1
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l9, !tbaa !29
  br label %bb57
bb56:
  br label %bb62
bb57:
  %t189 = load ptr, ptr %l9, !tbaa !29
  %t191 = icmp eq ptr %t189, null
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb58, label %bb59
bb58:
  %t195 = load ptr, ptr %l9, !tbaa !29
  %t196 = load i64, ptr %l1, !tbaa !24
  %t199 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t195, i64 %t196)
  store ptr %t199, ptr %l102
  br label %bb60
bb59:
  store ptr null, ptr %l99, !tbaa !29
  br label %bb61
bb60:
  %t200 = load ptr, ptr %l102, !tbaa !29
  store ptr %t200, ptr %l99, !tbaa !29
  br label %bb61
bb61:
  %t201 = load ptr, ptr %l99, !tbaa !29
  store ptr %t201, ptr %l12, !tbaa !29
  br label %bb81
bb62:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t203 = load ptr, ptr %l103, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb63, label %bb64
bb63:
  %t206 = load ptr, ptr %l103, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 11
  store i1 %t209, ptr %l104, !tbaa !21
  br label %bb64
bb64:
  %t210 = load i1, ptr %l104, !tbaa !21
  br i1 %t210, label %bb65, label %bb66
bb65:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l10, !tbaa !29
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t217 = load ptr, ptr %l10, !tbaa !29
  %t218 = load i64, ptr %l1, !tbaa !24
  %t221 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %v1, ptr %t217, i64 %t218)
  store ptr %t221, ptr %l111
  br label %bb68
bb68:
  %t222 = load ptr, ptr %l111, !tbaa !29
  store ptr %t222, ptr %l12, !tbaa !29
  br label %bb81
bb69:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t224 = load ptr, ptr %l112, !tbaa !29
  %t225 = icmp ne ptr %t224, null
  br i1 %t225, label %bb70, label %bb71
bb70:
  %t227 = load ptr, ptr %l112, !tbaa !29
  %t228 = load i64, ptr %t227, !range !{i64 0, i64 17}
  %t230 = icmp eq i64 %t228, 12
  store i1 %t230, ptr %l113, !tbaa !21
  br label %bb71
bb71:
  %t231 = load i1, ptr %l113, !tbaa !21
  br i1 %t231, label %bb72, label %bb73
bb72:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr { i64, [3 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", ptr }, ptr %t234, i32 0, i32 1
  %t236 = load ptr, ptr %t235
  store ptr %t236, ptr %l11, !tbaa !29
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t238 = load ptr, ptr %l11, !tbaa !29
  %t239 = load i64, ptr %l1, !tbaa !24
  %t242 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %v1, ptr %t238, i64 %t239)
  store ptr %t242, ptr %l120
  br label %bb75
bb75:
  %t243 = load ptr, ptr %l120, !tbaa !29
  store ptr %t243, ptr %l12, !tbaa !29
  br label %bb81
bb76:
  br i1 true, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  store ptr null, ptr %l12, !tbaa !29
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_649fc3f56aacc7bc_4edb8d32620c5088)
  unreachable
bb81:
  %t244 = load ptr, ptr %l12, !tbaa !29
  store ptr %t244, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2efindIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l15 = alloca ptr
  %l31 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:If", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %v1, ptr %t22, i64 %t23)
  store ptr %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l15, !tbaa !29
  store ptr %t27, ptr %l2, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/typed:If", ptr %t37, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/typed:If", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb11, label %bb12
bb10:
  br label %bb15
bb11:
  call void @__olang_check_failed(ptr @olang_loc_2779327e577b2afc_81ce12c77e8d0b58)
  unreachable
bb12:
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:If", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i64, ptr %l1, !tbaa !24
  %t60 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %v1, ptr %t56, i64 %t57)
  store ptr %t60, ptr %l31
  br label %bb14
bb14:
  %t61 = load ptr, ptr %l31, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
bb15:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ffree_2eisConversion(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 20 to i32
  %t4 = icmp eq i32 %a0, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t8 = extractvalue { i64, ptr } %a1, 0
  %t10 = icmp eq i64 %t8, 1
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l4, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2eisVar({ i64, [1 x i64] } %a0) #0 {
entry:
  %l1 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [1 x i64] } %a0, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3f15d8a4ec391f6e_384039254c446aaa)
  unreachable
bb9:
  %t6 = load i1, ptr %l1, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2eleaves(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 17}
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_6ad9637bd46aa97_a10a430e5eff5d73)
  unreachable
bb15:
  %t19 = load i1, ptr %l1, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2emovesOnly(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l24 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 8
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Collect", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = call i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %t19)
  store i1 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  store i1 %t22, ptr %l4, !tbaa !21
  br label %bb32
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 12
  store i1 %t30, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb20
bb12:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Seq", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Seq", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = icmp eq ptr %t50, null
  br i1 %t52, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_66111a817c7bb1ea_259ee9d6b37f7fd6)
  unreachable
bb16:
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Seq", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = call i1 @compiler_2ffree_2emovesOnly(ptr %v0, ptr %t57)
  store i1 %t59, ptr %l30
  br label %bb18
bb18:
  %t60 = load i1, ptr %l30, !tbaa !21
  store i1 %t60, ptr %l24, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l24, !tbaa !21
  store i1 %t61, ptr %l4, !tbaa !21
  br label %bb32
bb20:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t63 = load ptr, ptr %l31, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 18}
  %t69 = icmp eq i64 %t67, 17
  store i1 %t69, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t70 = load i1, ptr %l32, !tbaa !21
  br i1 %t70, label %bb23, label %bb24
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = call i1 @compiler_2ffree_2emovesOnly(ptr %v0, ptr %t77)
  store i1 %t79, ptr %l38
  br label %bb26
bb26:
  %t80 = load i1, ptr %l38, !tbaa !21
  store i1 %t80, ptr %l4, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_7a6e1b2179b57278_bd7dcc1897dee1e4)
  unreachable
bb32:
  %t81 = load i1, ptr %l4, !tbaa !21
  store i1 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2eownCopySite(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i1
  %l12 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 4 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Make", ptr %t24, i32 0, i32 4
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = sext i32 %t27 to i64
  store i64 %t29, ptr %l12, !tbaa !24
  br label %bb8
bb7:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t31 = load i64, ptr %l12, !tbaa !24
  store i64 %t31, ptr %l2, !tbaa !24
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_3413d17bc44a57e3_7c445ad346a50247)
  unreachable
bb14:
  %t32 = load i64, ptr %l2, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ereadLocalOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %l10, !tbaa !24
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d0a35c72e1689727_18f1e8c23ad8e373)
  unreachable
bb16:
  %t35 = load i64, ptr %l10, !tbaa !24
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9d733ba55f12146_b889888c2106eef2)
  unreachable
bb22:
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2esamePure(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l3, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t35 = call i1 @compiler_2ffree_2esamePurePlace(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t35, ptr %l20
  br label %bb11
bb11:
  %t36 = load i1, ptr %l20, !tbaa !21
  store i1 %t36, ptr %l11, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a76c2f62bbf8a003_89a44c6922f8d22f)
  unreachable
bb17:
  %t37 = load i1, ptr %l11, !tbaa !21
  store i1 %t37, ptr %l4, !tbaa !21
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_e31a42735e4aee82_13f2226a4db7316e)
  unreachable
bb23:
  %t38 = load i1, ptr %l4, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/free:letGo" @compiler_2ffree_3aletGo_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5, %"compiler/source:Span" %a6, i64 %a7, i1 %a8) #0 {
entry:
  %rv = alloca %"compiler/free:letGo"
  br label %start
start:
  br label %bb0
bb0:
  %t20 = insertvalue %"compiler/free:letGo" undef, i64 %a0, 0
  %t22 = insertvalue %"compiler/free:letGo" %t20, i64 %a1, 1
  %t24 = insertvalue %"compiler/free:letGo" %t22, i64 %a2, 2
  %t26 = insertvalue %"compiler/free:letGo" %t24, %"compiler/source:Span" %a3, 3
  %t28 = insertvalue %"compiler/free:letGo" %t26, %"compiler/source:Span" %a4, 4
  %t30 = insertvalue %"compiler/free:letGo" %t28, i64 %a5, 5
  %t32 = insertvalue %"compiler/free:letGo" %t30, %"compiler/source:Span" %a6, 6
  %t34 = insertvalue %"compiler/free:letGo" %t32, i64 %a7, 7
  %t36 = insertvalue %"compiler/free:letGo" %t34, i1 %a8, 8
  store %"compiler/free:letGo" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:letGo", ptr %rv
  ret %"compiler/free:letGo" %rr
}

define dso_local void @compiler_2ffree_3amustW_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"compiler/free:mustW"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 %a1, ptr %l3, !tbaa !24
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l4
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l13
  br label %bb3
bb3:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l6
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l14
  br label %bb4
bb4:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l7
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l15
  br label %bb5
bb5:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t15 = getelementptr %"compiler/free:mustW", ptr %l16, i32 0, i32 0
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %t15, !tbaa !29
  %t17 = getelementptr %"compiler/free:mustW", ptr %l16, i32 0, i32 1
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %t17, !tbaa !24
  %t19 = getelementptr %"compiler/free:mustW", ptr %l16, i32 0, i32 2
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t19
  %t21 = getelementptr %"compiler/free:mustW", ptr %l16, i32 0, i32 3
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %t21
  %t23 = getelementptr %"compiler/free:mustW", ptr %l16, i32 0, i32 4
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %t23
  %t25 = getelementptr %"compiler/free:mustW", ptr %l16, i32 0, i32 5
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t25
  %t27 = getelementptr %"compiler/free:mustW", ptr %l16, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %t27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l16, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/free:orCall" @compiler_2ffree_3aorCall_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, ptr %a5, ptr %a6) #0 {
entry:
  %rv = alloca %"compiler/free:orCall"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/free:orCall" undef, i64 %a0, 0
  %t18 = insertvalue %"compiler/free:orCall" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/free:orCall" %t18, i64 %a2, 2
  %t22 = insertvalue %"compiler/free:orCall" %t20, i64 %a3, 3
  %t24 = insertvalue %"compiler/free:orCall" %t22, i64 %a4, 4
  %t26 = insertvalue %"compiler/free:orCall" %t24, ptr %a5, 5
  %t28 = insertvalue %"compiler/free:orCall" %t26, ptr %a6, 6
  store %"compiler/free:orCall" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:orCall", ptr %rv
  ret %"compiler/free:orCall" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@__olang_empty_array = external constant [16 x i64]
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d0 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"free: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d1 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" bodies, " }>, align 8
@.d2 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" places; must " }>, align 8
@.d3 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" bodies " }>, align 8
@.d4 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" ms; may " }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" walks " }>, align 8
@.d6 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" passes " }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_errpay_pop()
@.d8 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"free: hidden let-go in " }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d11 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"free: final " }>, align 8
@.d12 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" ms, " }>, align 8
@.d13 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" let-goes, " }>, align 8
@.d14 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" stores; decide " }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 8}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 8}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb12
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 7, label %bb7 ]
bb3:
  br label %bb12
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [1 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [1 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb11, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  br label %bb3
bb11:
  br label %bb3
bb12:
  %t58 = load i1, ptr %l2, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d19 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"a whole array of them stored" }>, align 8
@.d20 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a store into it" }>, align 8
define linkonce_odr %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:leaf"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:leaf", ptr %a0
  store %"compiler/free:leaf" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/free:leaf", ptr %l1
  store %"compiler/free:leaf" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d21 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"its value is changed in place, by " }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c": '" }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d24 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"a copy of a value holding it" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 224, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 8
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 11
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

@.d25 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"may let go of anything" }>, align 8
@.d26 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"removes " }>, align 8
@.d27 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"lets go of it" }>, align 8
@.d28 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"its value is handed back here" }>, align 8
@.d29 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"untracked " }>, align 8
@.d30 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d32 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"a value holding it is made with no store into it, by " }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c": '" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/typed:Plan"
  %rv = alloca { i64, ptr }
  %t16 = alloca %"compiler/typed:Plan", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 224
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/typed:Plan", ptr %t14, i64 %t12
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t16, ptr %v0, ptr %t15)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t16, i64 224, i1 false)
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr %"compiler/typed:Plan", ptr %t21, i64 %t19
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %l6, i64 224, i1 false)
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t23, 1
  store i64 %t24, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_aa0994ef0ced0737_f892d7c71adaceeb = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epreludeCode(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ffree_2eMustTop = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandedToC(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_38e68c2f90f7ff92_433845456bb6222e = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_H788cd74f9c006611bc4bb459b5b22001(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_cfa78d5b759fffbc_7789424fbd23b3b0 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_c07c4c0bbb573d1f_6e3b998739460953 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2enoteDtor(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4a2ee03059613aea_a0006d5774bd9126 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i64 @std_2ftime_2eNow()
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesFirst(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_b4402838d0fec99d_8d63b3fead7ad2c9 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7774858aec9876f0_864a54e21bf2c67c = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_a3e4b8257e528993_6ac514faf6c963df = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eimplicit(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emodelled(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edecide(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewritePlans(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1c505c1b55d06586_a0a7e4d6315dd1d2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f0ef9f3a8cd9f24a_5f2afb921a19c616 = external constant [0 x i8]
@olang_loc_1befe4f0760966d8_ea99a8b72a88b024 = external constant [0 x i8]
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H0fa35282e56bd0cd9b08251ba99b9868(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H08f3244764437e29647226f03a29c83b(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H127fb385441fbfd25cd8404c6b268b5d(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eLVacate = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ec4c329f8a2f93df_8cb0fdf9b7b252db = external constant [0 x i8]
@olang_loc_285dc0af82d31c87_50e1bc6ae6554e83 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f9703b3e8b4d3f8c_114f0f1572d2eea8 = external constant [0 x i8]
@olang_loc_c329a7357b4632ae_1972f4ce8b92321a = external constant [0 x i8]
@olang_loc_ce4a56608212b1d3_28564c72fb26107 = external constant [0 x i8]
@olang_loc_8c3ff88e405c7c2b_15d3403d537d031f = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_637aed21ecd584b9_ebc4f5a84b828bd = external constant [0 x i8]
@olang_loc_683418f7a5c8092_d6a8437e0252bcd6 = external constant [0 x i8]
@olang_loc_edaf755937fbeeee_2c55fc89855df6da = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eMustNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_1d9a56a827ed845f_5cc839dbc781b743 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2emeet(i64 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_Ha64a825bb0b4fc6c7596ac96329c2853(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efreshLocal(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eRNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2ePush_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:reason" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_997f49c366488af5_93d2651ee5683809 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownerCand(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
@olang_loc_3f4c383e8983fca5_b7613254c9da681 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edtorCand(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandleCand(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayCand(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98179ed2ec661f5d_533fcebe8f905861 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i64 %a5)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2, { i64, [1 x i64] } %a3)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_21335a5a6f6a0d23_1fb4d5f27249eebf = external constant [0 x i8]
@olang_loc_80551b5782bfdb3b_907a9dbefd6aabe7 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eLCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1, %"compiler/free:letGo" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %a0)
@olang_loc_cba1607a5f8c25be_1da50212bb736ed2 = external constant [0 x i8]
@olang_loc_a35b07018a31f4f3_69e61a5b7415d1c7 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i1 @compiler_2ffree_2ehas(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eOPar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eorig(i64 %a0, i64 %a1)
@G_2ecompiler_2ffree_2eOParC = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eokind(i64 %a0)
declare i64 @compiler_2ffree_2eoval(i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_2a5f6fd698855c53_bf46ca1a958c9ea7 = external constant [0 x i8]
@olang_loc_4959d0728bd157ab_d85fd94b6e31a9bf = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_12d027853a0706eb_617ec39b0606fdd7 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2ewalker_2enewWalker(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %a0)
@olang_loc_30cfd3b464a887aa_ca3830b5343a05a6 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamPaths(ptr %v0, ptr %a0)
@olang_loc_3a3557a9366273b1_8eafb121351cf8d = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviews(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_4acb4c8921e8c407_808d59af97a4073 = external constant [0 x i8]
@olang_loc_d1dd1febe39b41f_df28cb247c1abe4b = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_18fbdab9dd354c58_c2b73ff02acf68dc = external constant [0 x i8]
@olang_loc_6e5f625591edaca_eb58e2cd01ac77e = external constant [0 x i8]
@olang_loc_6578a1c50e6256f2_162d732cc51ca876 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePush_H521773322b2b1b179ce4cc03a1674857(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2ftyped_2eCall_2eOf(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyStored(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ePop__He26954e073d6f40019e862398a9b5f5c(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecopiedStore(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeField(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6)
@G_2ecompiler_2ffree_2eLAssign = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5)
@olang_loc_620cc86993d1ee05_2ed463b6a2f232e1 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorStoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esameValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0)
declare %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eLLeaf = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5, ptr %a6)
@olang_loc_e251e9e241135754_793c210c71879d50 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i1 %a4, i64 %a5, i64 %a6)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H1c6ff733ce949281236b08418b935189(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H48be4d072aa67a39865369f0fe94a62c(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCallsOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i1 @compiler_2ffree_2einElement(ptr %v0, ptr %a0)
@G_2ecompiler_2ffree_2eOPl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eOMov = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRInPlace = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f81460935a0747e6_f4792861f5ca2502 = external constant [0 x i8]
@olang_loc_e3a1bae50be73c47_b8cb15515377d683 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc57530578add1ad359c6d87470cc4752(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eregister(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4057097bf127937e673a7f89a723e29a(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_3f338d8afa9da51a_e8058e9e002c9166 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisOwnLocal(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRStore = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRCopied = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_649fc3f56aacc7bc_4edb8d32620c5088 = external constant [0 x i8]
@olang_loc_2779327e577b2afc_81ce12c77e8d0b58 = external constant [0 x i8]
@olang_loc_3f15d8a4ec391f6e_384039254c446aaa = external constant [0 x i8]
@olang_loc_6ad9637bd46aa97_a10a430e5eff5d73 = external constant [0 x i8]
declare i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %a0)
@olang_loc_66111a817c7bb1ea_259ee9d6b37f7fd6 = external constant [0 x i8]
@olang_loc_7a6e1b2179b57278_bd7dcc1897dee1e4 = external constant [0 x i8]
@olang_loc_3413d17bc44a57e3_7c445ad346a50247 = external constant [0 x i8]
@olang_loc_d0a35c72e1689727_18f1e8c23ad8e373 = external constant [0 x i8]
@olang_loc_9d733ba55f12146_b889888c2106eef2 = external constant [0 x i8]
declare i1 @compiler_2ffree_2esamePurePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_a76c2f62bbf8a003_89a44c6922f8d22f = external constant [0 x i8]
@olang_loc_e31a42735e4aee82_13f2226a4db7316e = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
