; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"compiler/free:reason" = type { i64, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/free:store" = type { i64, i64, i64, %"compiler/source:Span", i64, i64, i64, ptr, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/free:walker" = type { ptr, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/free:orStore" = type { i64, i64, ptr, ptr }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/free:mustW" = type { ptr, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
define dso_local void @compiler_2ffree_2eLCall_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eLDestroy_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 6, ptr @G_2ecompiler_2ffree_2eLDestroy, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eLLeaf_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eLVacate_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ffree_2eLVacate, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eMustTop_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -2, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eOPar_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eRNone_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eRemovalNames_2einit() #0 {
entry:
  %l0 = alloca [9 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %t9, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2ffree_2eRemovalNames, ptr %l0, i64 144, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eSMove_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i64, ptr %l13, !tbaa !24
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp eq i64 %t18, %t20
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t30, i64 %t31)
  br label %bb12
bb12:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2ebaseOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb23
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 4
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Elem", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l4, !tbaa !29
  br label %bb23
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load i64, ptr %t44
  %t47 = icmp eq i64 %t45, 5
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l23, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Payload", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_aa0994ef0ced0737_f892d7c71adaceeb)
  unreachable
bb23:
  %t61 = load ptr, ptr %l4, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDroppedMove(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i1
  %l17 = alloca ptr
  %l25 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 67
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t9, ptr %a1)
  store i64 %t13, ptr %l10
  br label %bb4
bb4:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb8
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/free:Free", ptr %t19, i32 0, i32 1
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t21, i64 %t22)
  store ptr %t25, ptr %l17
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Body", ptr %t26, i32 0, i32 11
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  store i1 %t31, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l13, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:Free", ptr %t35, i32 0, i32 26
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t37, i64 %t38)
  store i64 %t41, ptr %l25
  br label %bb12
bb12:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  br i1 %t47, label %bb13, label %bb14
bb13:
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t58 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t50, i64 %t55)
  store i1 %t58, ptr %l34
  br label %bb16
bb16:
  %t59 = load i1, ptr %l34, !tbaa !21
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t61 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t64 = sub i64 %t60, %t61
  store i64 %t64, ptr %l35, !tbaa !24
  br label %bb19
bb18:
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb19
bb19:
  %t66 = load i64, ptr %l35, !tbaa !24
  store i64 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFrees(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 67
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sge i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 17
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l11
  br label %bb6
bb5:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 17
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t24, i64 %t25)
  store i1 %t28, ptr %l17
  br label %bb10
bb9:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb11
bb10:
  %t29 = load i1, ptr %l17, !tbaa !21
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l13, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 67
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sge i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 41
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l11
  br label %bb6
bb5:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 41
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t24, i64 %t25)
  store i1 %t28, ptr %l17
  br label %bb10
bb9:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb11
bb10:
  %t29 = load i1, ptr %l17, !tbaa !21
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l13, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSoleLeaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/free:leaf"
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca %"compiler/free:leaf"
  %l25 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 67
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %lp2
  %t13 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t15, i32 %a1)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l13
  br label %bb5
bb5:
  %t20 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t21 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %t21
  store ptr %t21, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  %t23 = load i64, ptr %l4, !tbaa !24
  store i64 %t23, ptr %l15, !tbaa !24
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l17
  br label %bb7
bb7:
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = load i64, ptr %l17, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb8, label %bb9
bb8:
  br label %bb18
bb9:
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v0, ptr %t33, i64 %t34)
  store %"compiler/free:leaf" %t37, ptr %l22
  br label %bb11
bb11:
  %t38 = load %"compiler/free:leaf", ptr %l22
  store %"compiler/free:leaf" %t38, ptr %l5
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/free:leaf", ptr %l5, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t44 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t39, i64 %t41)
  store i1 %t44, ptr %l25
  br label %bb12
bb12:
  %t45 = load i1, ptr %l25, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %lp2
  %t47 = load %"compiler/free:leaf", ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v0, ptr %t46, %"compiler/free:leaf" %t47)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l4, !tbaa !24
  br label %bb6
bb18:
  call void @__olang_scope_close(ptr %s2)
  %t54 = load ptr, ptr %lp2
  %t55 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t54
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1, %"compiler/free:letGo" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca %"compiler/free:letGo"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  store %"compiler/free:letGo" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = icmp ne i64 %t2, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = icmp slt i64 %t10, %t12
  store i1 %t15, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t17 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 3
  %t18 = getelementptr %"compiler/source:Span", ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18, !tbaa !23
  %t20 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 3
  %t21 = getelementptr %"compiler/source:Span", ptr %t20, i32 0, i32 0
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = icmp slt i32 %t19, %t22
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %lp3 = alloca ptr
  %l7 = alloca ptr
  %l18 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t8, ptr %lp3
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %lp3
  store ptr %t9, ptr %t10, !tbaa !29
  %t11 = load ptr, ptr %lp3
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 11
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  br i1 %t17, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %lp3
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 11
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = icmp eq ptr %t24, null
  br i1 %t26, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3a516a19293feeda_7f77204653e04cce)
  unreachable
bb6:
  br label %bb7
bb7:
  %t28 = load ptr, ptr %lp3
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 11
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t36 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %t32, i64 %a2)
  store ptr %t36, ptr %l18
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l18, !tbaa !29
  store ptr %t37, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i64, ptr %l11, !tbaa !24
  %t22 = icmp slt i64 %t21, 0
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  %t28 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l15
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4cef24e7d17769b7_e2744f91577a9953)
  unreachable
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestroyErrors(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, [3 x i64] }
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca i64
  %l16 = alloca %"compiler/free:reason"
  %l24 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l54 = alloca i1
  %l56 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l80 = alloca i1
  %l81 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l97 = alloca ptr
  %l101 = alloca i64
  %l102 = alloca %"compiler/typed:Local"
  %l104 = alloca { i64, ptr }
  %l107 = alloca i64
  %l111 = alloca %"compiler/source:Span"
  %l113 = alloca i64
  %l117 = alloca %"compiler/source:Span"
  %l124 = alloca i1
  %l125 = alloca i1
  %l129 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca { i64, [3 x i64] }
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca i64
  %l138 = alloca i1
  %l142 = alloca %"compiler/source:Span"
  %l143 = alloca ptr
  %l150 = alloca { i64, [3 x i64] }
  %l151 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l154 = alloca i64
  %l158 = alloca %"compiler/source:Span"
  %l161 = alloca i64
  %l162 = alloca %"compiler/msgs:Msg"
  %l163 = alloca i64
  %l164 = alloca ptr
  %l165 = alloca i64
  %l166 = alloca { i64, [3 x i64] }
  %l168 = alloca %"compiler/msgs:Msg"
  %l169 = alloca ptr
  %l170 = alloca { i64, [3 x i64] }
  %l172 = alloca %"compiler/msgs:Msg"
  %l173 = alloca i64
  %l177 = alloca %"compiler/free:reason"
  %l180 = alloca ptr
  %l181 = alloca i64
  %l187 = alloca { i64, [3 x i64] }
  %l189 = alloca %"compiler/msgs:Msg"
  %l190 = alloca ptr
  %l191 = alloca i64
  %l192 = alloca { i64, [3 x i64] }
  %l194 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t213 = alloca { i64, [3 x i64] }, align 8
  %t279 = alloca { i64, [3 x i64] }, align 8
  %t365 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 66
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l1, !tbaa !29
  %t19 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l24
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:Free", ptr %t21, i32 0, i32 8
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l27
  br label %bb5
bb5:
  %t26 = load i64, ptr %l27, !tbaa !24
  store i64 %t26, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb11
bb8:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l34, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb10
bb10:
  %t53 = load i64, ptr %l34, !tbaa !24
  store i64 %t53, ptr %l31, !tbaa !24
  br label %bb11
bb11:
  %t54 = load i64, ptr %l31, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb70
bb14:
  br label %bb15
bb15:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l8, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l8, !tbaa !24
  %t77 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t73, i64 %t74)
  store i1 %t77, ptr %l54
  br label %bb16
bb16:
  %t78 = load i1, ptr %l54, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb20
bb18:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:Free", ptr %t81, i32 0, i32 60
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t83, i64 %t84)
  store i1 %t87, ptr %l60
  br label %bb19
bb19:
  %t88 = load i1, ptr %l60, !tbaa !21
  store i1 %t88, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t89 = load i1, ptr %l56, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb22:
  br label %bb23
bb23:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:Free", ptr %t90, i32 0, i32 54
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t92, i64 %t93)
  store i64 %t96, ptr %l64
  br label %bb24
bb24:
  %t97 = load i64, ptr %l64, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/free:Free", ptr %t98, i32 0, i32 1
  %t104 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t100, i64 %t97)
  store ptr %t104, ptr %l68
  br label %bb25
bb25:
  %t105 = load ptr, ptr %l68, !tbaa !29
  store ptr %t105, ptr %l10, !tbaa !29
  store ptr %l2, ptr %l69, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/free:Free", ptr %t106, i32 0, i32 56
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t108, i64 %t109)
  store %"compiler/source:Span" %t112, ptr %l73
  br label %bb26
bb26:
  %t113 = getelementptr %"compiler/source:Span", ptr %l73, i32 0, i32 0
  %t114 = load i32, ptr %t113, !tbaa !23
  %t116 = sext i32 %t114 to i64
  %t118 = mul i64 %t116, 4096
  %t119 = load ptr, ptr %l10, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Body", ptr %t119, i32 0, i32 3
  %t122 = load i64, ptr %t121, !tbaa !24
  %t125 = add i64 %t118, %t122
  %t126 = load ptr, ptr %l69, !tbaa !29
  %t128 = call i1 @compiler_2ffree_2ehas(ptr %s0, ptr %t126, i64 %t125)
  store i1 %t128, ptr %l80
  br label %bb27
bb27:
  %t129 = load i1, ptr %l80, !tbaa !21
  br i1 %t129, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb29:
  br label %bb30
bb30:
  store ptr %l2, ptr %l81, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/free:Free", ptr %t130, i32 0, i32 56
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t132, i64 %t133)
  store %"compiler/source:Span" %t136, ptr %l85
  br label %bb31
bb31:
  %t137 = getelementptr %"compiler/source:Span", ptr %l85, i32 0, i32 0
  %t138 = load i32, ptr %t137, !tbaa !23
  %t140 = sext i32 %t138 to i64
  %t142 = mul i64 %t140, 4096
  %t143 = load ptr, ptr %l10, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Body", ptr %t143, i32 0, i32 3
  %t146 = load i64, ptr %t145, !tbaa !24
  %t149 = add i64 %t142, %t146
  %t150 = load ptr, ptr %l81, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t150, i64 %t149)
  br label %bb32
bb32:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/free:Free", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/load:Loader", ptr %t158, i32 0, i32 3
  %t161 = load ptr, ptr %t160, !tbaa !29
  store ptr %t161, ptr %l95, !tbaa !29
  %t162 = load ptr, ptr %l10, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Body", ptr %t162, i32 0, i32 7
  store ptr %t164, ptr %l97, !tbaa !29
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/free:Free", ptr %t165, i32 0, i32 55
  %t168 = load i64, ptr %l8, !tbaa !24
  %t171 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t167, i64 %t168)
  store i64 %t171, ptr %l101
  br label %bb33
bb33:
  %t172 = load ptr, ptr %l97, !tbaa !29
  %t173 = load i64, ptr %l101, !tbaa !24
  %t174 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t172, i64 %t173)
  store %"compiler/typed:Local" %t174, ptr %l102
  br label %bb34
bb34:
  %t175 = getelementptr %"compiler/typed:Local", ptr %l102, i32 0, i32 0
  %t176 = load i32, ptr %t175, !tbaa !23
  %t177 = load ptr, ptr %l95, !tbaa !29
  %t179 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t177, i32 %t176)
  store { i64, ptr } %t179, ptr %l104
  br label %bb35
bb35:
  %t180 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t181, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l11, !tbaa !27
  %t187 = load ptr, ptr %l10, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Body", ptr %t187, i32 0, i32 3
  %t190 = load i64, ptr %t189, !tbaa !24
  store i64 %t190, ptr %l107, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/free:Free", ptr %t191, i32 0, i32 56
  %t194 = load i64, ptr %l8, !tbaa !24
  %t197 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t193, i64 %t194)
  store %"compiler/source:Span" %t197, ptr %l111
  br label %bb36
bb36:
  %t198 = getelementptr %"compiler/source:Span", ptr %l111, i32 0, i32 0
  %t199 = load i32, ptr %t198, !tbaa !23
  %t201 = sext i32 %t199 to i64
  store i64 %t201, ptr %l113, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/free:Free", ptr %t202, i32 0, i32 56
  %t205 = load i64, ptr %l8, !tbaa !24
  %t208 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t204, i64 %t205)
  store %"compiler/source:Span" %t208, ptr %l117
  br label %bb37
bb37:
  %t209 = getelementptr %"compiler/source:Span", ptr %l117, i32 0, i32 1
  %t210 = load i32, ptr %t209, !tbaa !23
  %t212 = sext i32 %t210 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 0
  store i64 3, ptr %t214
  %t215 = load i64, ptr %l107, !tbaa !24
  %t216 = insertvalue { i64, i64, i64 } undef, i64 %t215, 0
  %t217 = load i64, ptr %l113, !tbaa !24
  %t218 = insertvalue { i64, i64, i64 } %t216, i64 %t217, 1
  %t220 = insertvalue { i64, i64, i64 } %t218, i64 %t212, 2
  %t221 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 1
  store { i64, i64, i64 } %t220, ptr %t221
  %t222 = load { i64, [3 x i64] }, ptr %t213
  store { i64, [3 x i64] } %t222, ptr %l12
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/free:Free", ptr %t224, i32 0, i32 58
  %t227 = load i64, ptr %l8, !tbaa !24
  %t230 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t226, i64 %t227)
  store i1 %t230, ptr %l124
  br label %bb38
bb38:
  %t231 = load i1, ptr %l124, !tbaa !21
  br i1 %t231, label %bb39, label %bb40
bb39:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/free:Free", ptr %t232, i32 0, i32 59
  %t235 = load i64, ptr %l8, !tbaa !24
  %t238 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t234, i64 %t235)
  store i1 %t238, ptr %l129
  br label %bb41
bb40:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb42
bb41:
  %t239 = load i1, ptr %l129, !tbaa !21
  store i1 %t239, ptr %l125, !tbaa !21
  br label %bb42
bb42:
  %t240 = load i1, ptr %l125, !tbaa !21
  br i1 %t240, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l130, !tbaa !29
  %t242 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t242, ptr %l131
  %t243 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t245 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyInLoop(ptr %s3, ptr %s7, { i64, ptr } %t243)
  store %"compiler/msgs:Msg" %t245, ptr %l133
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t246 = load ptr, ptr %l130, !tbaa !29
  %t247 = load { i64, [3 x i64] }, ptr %l131
  %t248 = load %"compiler/msgs:Msg", ptr %l133
  %t249 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t246, { i64, [3 x i64] } %t247, %"compiler/msgs:Msg" %t248)
  store i64 %t249, ptr %l134
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb47:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/free:Free", ptr %t250, i32 0, i32 58
  %t253 = load i64, ptr %l8, !tbaa !24
  %t256 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t252, i64 %t253)
  store i1 %t256, ptr %l138
  br label %bb48
bb48:
  %t257 = load i1, ptr %l138, !tbaa !21
  br i1 %t257, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/free:Free", ptr %t258, i32 0, i32 57
  %t261 = load i64, ptr %l8, !tbaa !24
  %t264 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t260, i64 %t261)
  store %"compiler/source:Span" %t264, ptr %l142
  br label %bb51
bb50:
  br label %bb58
bb51:
  %t265 = load %"compiler/source:Span", ptr %l142
  store %"compiler/source:Span" %t265, ptr %l13
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l143, !tbaa !29
  %t267 = load ptr, ptr %l10, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Body", ptr %t267, i32 0, i32 3
  %t270 = load i64, ptr %t269, !tbaa !24
  %t271 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t272 = load i32, ptr %t271, !tbaa !23
  %t274 = sext i32 %t272 to i64
  %t275 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t276 = load i32, ptr %t275, !tbaa !23
  %t278 = sext i32 %t276 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 0
  store i64 3, ptr %t280
  %t282 = insertvalue { i64, i64, i64 } undef, i64 %t270, 0
  %t284 = insertvalue { i64, i64, i64 } %t282, i64 %t274, 1
  %t286 = insertvalue { i64, i64, i64 } %t284, i64 %t278, 2
  %t287 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 1
  store { i64, i64, i64 } %t286, ptr %t287
  %t288 = load { i64, [3 x i64] }, ptr %t279
  store { i64, [3 x i64] } %t288, ptr %l150
  %t289 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t289, ptr %l151, !tbaa !27
  %t290 = load ptr, ptr %l1, !tbaa !29
  store ptr %t290, ptr %l152, !tbaa !29
  %t291 = load ptr, ptr %l10, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Body", ptr %t291, i32 0, i32 3
  %t294 = load i64, ptr %t293, !tbaa !24
  store i64 %t294, ptr %l154, !tbaa !24
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/free:Free", ptr %t295, i32 0, i32 56
  %t298 = load i64, ptr %l8, !tbaa !24
  %t301 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t297, i64 %t298)
  store %"compiler/source:Span" %t301, ptr %l158
  br label %bb52
bb52:
  %t302 = getelementptr %"compiler/source:Span", ptr %l158, i32 0, i32 0
  %t303 = load i32, ptr %t302, !tbaa !23
  %t305 = sext i32 %t303 to i64
  %t306 = load ptr, ptr %l152, !tbaa !29
  %t307 = load i64, ptr %l154, !tbaa !24
  %t309 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t306, i64 %t307, i64 %t305)
  store i64 %t309, ptr %l161
  br label %bb53
bb53:
  %t310 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t311 = load i64, ptr %l161, !tbaa !24
  %t312 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyUsedAfter(ptr %s3, ptr %s8, { i64, ptr } %t310, i64 %t311)
  store %"compiler/msgs:Msg" %t312, ptr %l162
  br label %bb54
bb54:
  %t313 = load ptr, ptr %l143, !tbaa !29
  %t314 = load { i64, [3 x i64] }, ptr %l150
  %t315 = load %"compiler/msgs:Msg", ptr %l162
  %t316 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t313, { i64, [3 x i64] } %t314, %"compiler/msgs:Msg" %t315)
  store i64 %t316, ptr %l163
  br label %bb55
bb55:
  %t317 = load i64, ptr %l163, !tbaa !24
  %t318 = load ptr, ptr %l1, !tbaa !29
  store ptr %t318, ptr %l164, !tbaa !29
  store i64 %t317, ptr %l165, !tbaa !24
  %t320 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t320, ptr %l166
  %t321 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t323 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyHere(ptr %s3, ptr %s8, { i64, ptr } %t321)
  store %"compiler/msgs:Msg" %t323, ptr %l168
  br label %bb56
bb56:
  %t324 = load ptr, ptr %l164, !tbaa !29
  %t325 = load i64, ptr %l165, !tbaa !24
  %t326 = load { i64, [3 x i64] }, ptr %l166
  %t327 = load %"compiler/msgs:Msg", ptr %l168
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s8, ptr %t324, i64 %t325, { i64, [3 x i64] } %t326, %"compiler/msgs:Msg" %t327)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb58:
  %t328 = load ptr, ptr %l1, !tbaa !29
  store ptr %t328, ptr %l169, !tbaa !29
  %t329 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t329, ptr %l170
  %t330 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t332 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNotSole(ptr %s3, ptr %s3, { i64, ptr } %t330)
  store %"compiler/msgs:Msg" %t332, ptr %l172
  br label %bb59
bb59:
  %t333 = load ptr, ptr %l169, !tbaa !29
  %t334 = load { i64, [3 x i64] }, ptr %l170
  %t335 = load %"compiler/msgs:Msg", ptr %l172
  %t336 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t333, { i64, [3 x i64] } %t334, %"compiler/msgs:Msg" %t335)
  store i64 %t336, ptr %l173
  br label %bb60
bb60:
  %t337 = load i64, ptr %l173, !tbaa !24
  store i64 %t337, ptr %l15, !tbaa !24
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/free:Free", ptr %t338, i32 0, i32 38
  %t341 = load i64, ptr %l8, !tbaa !24
  %t344 = call %"compiler/free:reason" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t340, i64 %t341)
  store %"compiler/free:reason" %t344, ptr %l177
  br label %bb61
bb61:
  %t345 = load %"compiler/free:reason", ptr %l177
  store %"compiler/free:reason" %t345, ptr %l16
  %t346 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 1
  %t347 = load i64, ptr %t346, !tbaa !24
  %t349 = icmp sge i64 %t347, 0
  br i1 %t349, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s9
  %t351 = load ptr, ptr %l1, !tbaa !29
  store ptr %t351, ptr %l180, !tbaa !29
  %t352 = load i64, ptr %l15, !tbaa !24
  store i64 %t352, ptr %l181, !tbaa !24
  %t353 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 1
  %t354 = load i64, ptr %t353, !tbaa !24
  %t355 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 2
  %t356 = getelementptr %"compiler/source:Span", ptr %t355, i32 0, i32 0
  %t357 = load i32, ptr %t356, !tbaa !23
  %t359 = sext i32 %t357 to i64
  %t360 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 2
  %t361 = getelementptr %"compiler/source:Span", ptr %t360, i32 0, i32 1
  %t362 = load i32, ptr %t361, !tbaa !23
  %t364 = sext i32 %t362 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t365
  %t366 = getelementptr { i64, [3 x i64] }, ptr %t365, i32 0, i32 0
  store i64 3, ptr %t366
  %t368 = insertvalue { i64, i64, i64 } undef, i64 %t354, 0
  %t370 = insertvalue { i64, i64, i64 } %t368, i64 %t359, 1
  %t372 = insertvalue { i64, i64, i64 } %t370, i64 %t364, 2
  %t373 = getelementptr { i64, [3 x i64] }, ptr %t365, i32 0, i32 1
  store { i64, i64, i64 } %t372, ptr %t373
  %t374 = load { i64, [3 x i64] }, ptr %t365
  store { i64, [3 x i64] } %t374, ptr %l187
  %t375 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 3
  %t376 = load { i64, ptr }, ptr %t375, !tbaa !27
  %t378 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyWhy(ptr %v0, ptr %s9, { i64, ptr } %t376)
  store %"compiler/msgs:Msg" %t378, ptr %l189
  br label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s10
  %t379 = load ptr, ptr %l1, !tbaa !29
  store ptr %t379, ptr %l190, !tbaa !29
  %t380 = load i64, ptr %l15, !tbaa !24
  store i64 %t380, ptr %l191, !tbaa !24
  %t381 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t381, ptr %l192
  %t382 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 3
  %t383 = load { i64, ptr }, ptr %t382, !tbaa !27
  %t385 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyWhy(ptr %v0, ptr %s10, { i64, ptr } %t383)
  store %"compiler/msgs:Msg" %t385, ptr %l194
  br label %bb66
bb64:
  %t386 = load ptr, ptr %l180, !tbaa !29
  %t387 = load i64, ptr %l181, !tbaa !24
  %t388 = load { i64, [3 x i64] }, ptr %l187
  %t389 = load %"compiler/msgs:Msg", ptr %l189
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s9, ptr %t386, i64 %t387, { i64, [3 x i64] } %t388, %"compiler/msgs:Msg" %t389)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb68
bb66:
  %t390 = load ptr, ptr %l190, !tbaa !29
  %t391 = load i64, ptr %l191, !tbaa !24
  %t392 = load { i64, [3 x i64] }, ptr %l192
  %t393 = load %"compiler/msgs:Msg", ptr %l194
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s10, ptr %t390, i64 %t391, { i64, [3 x i64] } %t392, %"compiler/msgs:Msg" %t393)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb69:
  %t394 = load i64, ptr %l7, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l7, !tbaa !24
  br label %bb12
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = load i32, ptr %l16, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb9
bb9:
  %t32 = load i32, ptr %l19
  %t34 = trunc i64 18 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t41 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l25
  br label %bb12
bb11:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb13
bb12:
  %t42 = load i1, ptr %l25, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l29
  br label %bb16
bb15:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb17
bb16:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l26, !tbaa !21
  br label %bb17
bb17:
  %t50 = load i1, ptr %l26, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edtorCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i32
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l51 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l70 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l12
  br label %bb2
bb2:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb6
bb4:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l17
  br label %bb5
bb5:
  %t18 = load i1, ptr %l17, !tbaa !21
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l21
  br label %bb9
bb9:
  %t25 = load i1, ptr %l21, !tbaa !21
  store i1 %t25, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l23, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l26
  br label %bb14
bb14:
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t35 = load i32, ptr %l26, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l27
  br label %bb15
bb15:
  %t37 = load i32, ptr %l27, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l30
  br label %bb16
bb16:
  %t43 = load i32, ptr %l30
  %t45 = trunc i64 18 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb20
bb18:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l37
  br label %bb19
bb19:
  %t55 = load i1, ptr %l37, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l34, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l34, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb25
bb22:
  %t59 = load ptr, ptr %l2, !tbaa !29
  store ptr %t59, ptr %l40, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l43
  br label %bb23
bb23:
  %t65 = load ptr, ptr %l40, !tbaa !29
  %t66 = load i32, ptr %l43, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t67, ptr %l44
  br label %bb24
bb24:
  %t68 = load i32, ptr %l44
  %t70 = trunc i64 0 to i32
  %t71 = icmp eq i32 %t68, %t70
  %t73 = xor i1 %t71, true
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb25
bb25:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t81 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t77, i32 %t78)
  store i1 %t81, ptr %l51
  br label %bb29
bb29:
  %t82 = load i1, ptr %l51, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb30, label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l54, !tbaa !29
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t88 = load i32, ptr %l3, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l57
  br label %bb33
bb33:
  %t92 = load ptr, ptr %l54, !tbaa !29
  %t93 = load i32, ptr %l57, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t92, i32 %t93)
  store { i64, ptr } %t94, ptr %l58
  br label %bb34
bb34:
  %t95 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t95, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l6, !tbaa !24
  br label %bb35
bb35:
  %t100 = load i64, ptr %l5, !tbaa !24
  %t101 = load i64, ptr %l6, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb36, label %bb37
bb36:
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t108, ptr %l65, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i32, ptr %t112, i64 %t109
  %t114 = load i32, ptr %t113, !tbaa !33
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t120 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t116, i32 %t114)
  store i1 %t120, ptr %l70
  br label %bb39
bb39:
  %t121 = load i1, ptr %l70, !tbaa !21
  %t122 = xor i1 %t121, true
  br i1 %t122, label %bb40, label %bb41
bb40:
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t125 = load i64, ptr %l5, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l5, !tbaa !24
  br label %bb35
bb44:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindDestroy(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l22 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l50 = alloca i1
  %l54 = alloca i64
  %l77 = alloca ptr
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 4
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb45
bb5:
  %t22 = load i32, ptr %l3
  %t24 = trunc i64 30 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t33 = icmp ne i64 %t31, 1
  store i1 %t33, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t36, ptr %l26, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 0
  %t40 = load ptr, ptr %t39, !tbaa !39
  store ptr %t40, ptr %l5, !tbaa !29
  %t42 = load ptr, ptr %l5, !tbaa !29
  store ptr %t42, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i64, ptr %t46
  %t49 = icmp eq i64 %t47, 2
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t53, i32 0, i32 1
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l6, !tbaa !23
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l7, !tbaa !29
  br label %bb16
bb15:
  br label %bb39
bb16:
  %t63 = load ptr, ptr %l7, !tbaa !29
  store ptr %t63, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l36, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 0
  store i1 %t70, ptr %l37, !tbaa !21
  br label %bb18
bb18:
  %t71 = load i1, ptr %l37, !tbaa !21
  br i1 %t71, label %bb19, label %bb20
bb19:
  %t72 = load ptr, ptr %l7, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t74, i32 0, i32 2
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l8, !tbaa !23
  br label %bb21
bb20:
  br label %bb33
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/free:Free", ptr %t78, i32 0, i32 65
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load i32, ptr %l8, !tbaa !23
  %t84 = sext i32 %t82 to i64
  %t87 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t81, i64 %t84)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t87, ptr %l46
  br label %bb22
bb22:
  %t88 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l46
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t88, ptr %l9
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/free:Free", ptr %t89, i32 0, i32 53
  %t92 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l9
  %t95 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %t91, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t92)
  store i1 %t95, ptr %l50
  br label %bb23
bb23:
  %t96 = load i1, ptr %l50, !tbaa !21
  br i1 %t96, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb25:
  br label %bb26
bb26:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l6, !tbaa !23
  %t99 = load i32, ptr %l6, !tbaa !23
  %t103 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %t97, i32 %t98, i64 -2, i1 false, i32 %t99, i1 false)
  store i64 %t103, ptr %l54
  br label %bb27
bb27:
  %t104 = load i64, ptr %l54, !tbaa !24
  store i64 %t104, ptr %l10, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:Free", ptr %t105, i32 0, i32 53
  %t108 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l9
  %t109 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t107, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t108, i64 %t109)
  br label %bb28
bb28:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/free:Free", ptr %t113, i32 0, i32 54
  %t116 = load i64, ptr %l10, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:Free", ptr %t117, i32 0, i32 65
  %t120 = load i64, ptr %t119, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t115, i64 %t116, i64 %t120)
  br label %bb29
bb29:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/free:Free", ptr %t124, i32 0, i32 55
  %t127 = load i64, ptr %l10, !tbaa !24
  %t128 = load i32, ptr %l8, !tbaa !23
  %t130 = sext i32 %t128 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t126, i64 %t127, i64 %t130)
  br label %bb30
bb30:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:Free", ptr %t134, i32 0, i32 56
  %t137 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t136, i64 %t137, %"compiler/source:Span" %a1)
  br label %bb31
bb31:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/free:Free", ptr %t142, i32 0, i32 61
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/free:Free", ptr %t145, i32 0, i32 65
  %t148 = load i64, ptr %t147, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t144, i64 %t148, i1 true)
  br label %bb32
bb32:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l77, !tbaa !29
  %t152 = load ptr, ptr %l77, !tbaa !29
  %t153 = getelementptr %"compiler/free:Free", ptr %t152, i32 0, i32 52
  %t154 = load i64, ptr %t153, !tbaa !24
  %t156 = add i64 %t154, 1
  %t158 = load ptr, ptr %l77, !tbaa !29
  %t159 = getelementptr %"compiler/free:Free", ptr %t158, i32 0, i32 52
  store i64 %t156, ptr %t159, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_abb447fb014369ff_ca54bae4e013147b)
  unreachable
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_b390d81e3df133fe_1bb65207cb7ceffa)
  unreachable
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_f1cf9d8b5dd1d1b5_4d41c45ca418d191)
  unreachable
bb50:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l63 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t2 = load ptr, ptr %l14, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l14, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l15, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l15, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  br label %bb7
bb7:
  br label %bb89
bb8:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t31 = load ptr, ptr %l26, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l26, !tbaa !29
  %t35 = load i64, ptr %t34
  %t37 = icmp eq i64 %t35, 0
  store i1 %t37, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l27, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  br label %bb14
bb14:
  br label %bb89
bb15:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l34, !tbaa !29
  %t54 = load i64, ptr %t53
  %t56 = icmp eq i64 %t54, 2
  store i1 %t56, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l35, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr }, ptr %t60, i32 0, i32 0
  %t62 = load %"compiler/source:Span", ptr %t61
  store %"compiler/source:Span" %t62, ptr %l5
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr }, ptr %t66, i32 0, i32 1
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l6, !tbaa !29
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t70, ptr %t71)
  br label %bb21
bb21:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l5
  %t76 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindDestroy(ptr %v0, ptr %v1, ptr %t74, %"compiler/source:Span" %t75, ptr %t76)
  br label %bb22
bb22:
  br label %bb89
bb23:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t85 = load i64, ptr %t84
  %t87 = icmp eq i64 %t85, 3
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l48, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l7, !tbaa !29
  br label %bb28
bb27:
  br label %bb38
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l7, !tbaa !29
  %t98 = getelementptr %"compiler/typed:If", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t95, ptr %t99)
  br label %bb29
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l7, !tbaa !29
  %t105 = getelementptr %"compiler/typed:If", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t102, ptr %t106)
  br label %bb30
bb30:
  %t109 = load ptr, ptr %l7, !tbaa !29
  %t111 = getelementptr %"compiler/typed:If", ptr %t109, i32 0, i32 2
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = icmp eq ptr %t112, null
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb31, label %bb32
bb31:
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l63, !tbaa !29
  %t119 = load ptr, ptr %l7, !tbaa !29
  %t121 = getelementptr %"compiler/typed:If", ptr %t119, i32 0, i32 2
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  br i1 %t124, label %bb33, label %bb34
bb32:
  br label %bb37
bb33:
  call void @__olang_check_failed(ptr @olang_loc_f0ef9f3a8cd9f24a_5f2afb921a19c616)
  unreachable
bb34:
  br label %bb35
bb35:
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t128 = getelementptr %"compiler/typed:If", ptr %t126, i32 0, i32 2
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t130 = load ptr, ptr %l63, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t130, ptr %t129)
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb89
bb38:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t133 = load ptr, ptr %l69, !tbaa !29
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %bb39, label %bb40
bb39:
  %t136 = load ptr, ptr %l69, !tbaa !29
  %t137 = load i64, ptr %t136
  %t139 = icmp eq i64 %t137, 4
  store i1 %t139, ptr %l70, !tbaa !21
  br label %bb40
bb40:
  %t140 = load i1, ptr %l70, !tbaa !21
  br i1 %t140, label %bb41, label %bb42
bb41:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [3 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t143, i32 0, i32 1
  %t145 = load ptr, ptr %t144
  store ptr %t145, ptr %l8, !tbaa !29
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [3 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t149, i32 0, i32 2
  %t151 = load ptr, ptr %t150
  store ptr %t151, ptr %l9, !tbaa !29
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t153, ptr %t154)
  br label %bb44
bb44:
  %t157 = load ptr, ptr %l9, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb45, label %bb46
bb45:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  br label %bb89
bb49:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t168 = load ptr, ptr %l84, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb50, label %bb51
bb50:
  %t171 = load ptr, ptr %l84, !tbaa !29
  %t172 = load i64, ptr %t171
  %t174 = icmp eq i64 %t172, 6
  store i1 %t174, ptr %l85, !tbaa !21
  br label %bb51
bb51:
  %t175 = load i1, ptr %l85, !tbaa !21
  br i1 %t175, label %bb52, label %bb53
bb52:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l10, !tbaa !29
  br label %bb58
bb53:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t183 = load ptr, ptr %l90, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb54, label %bb55
bb54:
  %t186 = load ptr, ptr %l90, !tbaa !29
  %t187 = load i64, ptr %t186
  %t189 = icmp eq i64 %t187, 16
  store i1 %t189, ptr %l91, !tbaa !21
  br label %bb55
bb55:
  %t190 = load i1, ptr %l91, !tbaa !21
  br i1 %t190, label %bb56, label %bb57
bb56:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", ptr }, ptr %t193, i32 0, i32 1
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l10, !tbaa !29
  br label %bb58
bb57:
  br label %bb63
bb58:
  %t197 = load ptr, ptr %l10, !tbaa !29
  %t199 = icmp eq ptr %t197, null
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb59, label %bb60
bb59:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t203, ptr %t204)
  br label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb62
bb62:
  br label %bb89
bb63:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t208 = load ptr, ptr %l101, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb64, label %bb65
bb64:
  %t211 = load ptr, ptr %l101, !tbaa !29
  %t212 = load i64, ptr %t211
  %t214 = icmp eq i64 %t212, 11
  store i1 %t214, ptr %l102, !tbaa !21
  br label %bb65
bb65:
  %t215 = load i1, ptr %l102, !tbaa !21
  br i1 %t215, label %bb66, label %bb67
bb66:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr { i64, [3 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr }, ptr %t218, i32 0, i32 1
  %t220 = load ptr, ptr %t219
  store ptr %t220, ptr %l11, !tbaa !29
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t222, ptr %t223)
  br label %bb69
bb69:
  br label %bb89
bb70:
  %t226 = load ptr, ptr %l1, !tbaa !29
  store ptr %t226, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t227 = load ptr, ptr %l109, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb71, label %bb72
bb71:
  %t230 = load ptr, ptr %l109, !tbaa !29
  %t231 = load i64, ptr %t230
  %t233 = icmp eq i64 %t231, 12
  store i1 %t233, ptr %l110, !tbaa !21
  br label %bb72
bb72:
  %t234 = load i1, ptr %l110, !tbaa !21
  br i1 %t234, label %bb73, label %bb74
bb73:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 1
  %t238 = getelementptr { %"compiler/source:Span", ptr }, ptr %t237, i32 0, i32 1
  %t239 = load ptr, ptr %t238
  store ptr %t239, ptr %l12, !tbaa !29
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t241, ptr %t242)
  br label %bb76
bb76:
  br label %bb89
bb77:
  %t245 = load ptr, ptr %l1, !tbaa !29
  store ptr %t245, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t246 = load ptr, ptr %l117, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb78, label %bb79
bb78:
  %t249 = load ptr, ptr %l117, !tbaa !29
  %t250 = load i64, ptr %t249
  %t252 = icmp eq i64 %t250, 13
  store i1 %t252, ptr %l118, !tbaa !21
  br label %bb79
bb79:
  %t253 = load i1, ptr %l118, !tbaa !21
  br i1 %t253, label %bb80, label %bb81
bb80:
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [3 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", ptr }, ptr %t256, i32 0, i32 1
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l13, !tbaa !29
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l13, !tbaa !29
  %t263 = getelementptr %"compiler/typed:Join", ptr %t261, i32 0, i32 0
  %t264 = load ptr, ptr %t263, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t260, ptr %t264)
  br label %bb83
bb83:
  br label %bb89
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_1befe4f0760966d8_ea99a8b72a88b024)
  unreachable
bb89:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l23
  br label %bb5
bb5:
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t44, i64 %t45)
  store ptr %t46, ptr %l24
  br label %bb6
bb6:
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Func", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %t49, !tbaa !23
  %t51 = load ptr, ptr %l17, !tbaa !29
  %t53 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t51, i32 %t50)
  store { i64, ptr } %t53, ptr %l27
  br label %bb7
bb7:
  %t54 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l10, !tbaa !27
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t61, ptr %l10, !tbaa !27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_947cc6b8bd079717_9e266d1a8b9c5cdb)
  unreachable
bb13:
  %t63 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l31, !tbaa !24
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l32, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l31, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t76, ptr %l10, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eimplicit(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 3
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %rv
  br label %ret
bb5:
  %t19 = load { i64, [2 x i64] }, ptr %l2
  %t21 = extractvalue { i64, [2 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t25 = getelementptr { i64 }, ptr %t24, i32 0, i32 0
  %t26 = load i64, ptr %t25
  store i64 %t26, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb33
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/free:Free", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t35, i64 %t36)
  store i64 %t39, ptr %l23
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load i64, ptr %l23, !tbaa !24
  %t42 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t40, i64 %t41)
  store ptr %t42, ptr %l24
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/free:Free", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Func", ptr %t43, i32 0, i32 2
  %t57 = load i32, ptr %t56, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t53, i32 %t57)
  store { i64, ptr } %t60, ptr %l31
  br label %bb11
bb11:
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %l5, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t62, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t64, ptr %l33
  br label %bb12
bb12:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb16
bb14:
  %t66 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t66, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t68, ptr %l36
  br label %bb15
bb15:
  %t69 = load i1, ptr %l36, !tbaa !21
  store i1 %t69, ptr %l34, !tbaa !21
  br label %bb16
bb16:
  %t70 = load i1, ptr %l34, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb20
bb18:
  %t71 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t71, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t73, ptr %l39
  br label %bb19
bb19:
  %t74 = load i1, ptr %l39, !tbaa !21
  store i1 %t74, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l37, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb24
bb22:
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t76, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t78, ptr %l42
  br label %bb23
bb23:
  %t79 = load i1, ptr %l42, !tbaa !21
  store i1 %t79, ptr %l40, !tbaa !21
  br label %bb24
bb24:
  %t80 = load i1, ptr %l40, !tbaa !21
  br i1 %t80, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb28
bb26:
  %t81 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t81, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t83, ptr %l45
  br label %bb27
bb27:
  %t84 = load i1, ptr %l45, !tbaa !21
  store i1 %t84, ptr %l43, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l43, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb32
bb30:
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t86, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t88, ptr %l48
  br label %bb31
bb31:
  %t89 = load i1, ptr %l48, !tbaa !21
  store i1 %t89, ptr %l46, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  %t90 = load i1, ptr %l46, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i1 false, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_708b3215abbdbba7_3cea2bd689d53e8b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l18 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l34 = alloca %"compiler/free:reason"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 36
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb8
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 36
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l18
  br label %bb7
bb7:
  %t23 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t24 = load i64, ptr %l18, !tbaa !24
  %t26 = icmp ne i64 %t24, %t23
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 36
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t31, i64 %t32, i64 %t33)
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:Free", ptr %t37, i32 0, i32 38
  store ptr %t39, ptr %l26, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  store i64 %t40, ptr %l27, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t46 = extractvalue { i64, ptr } %a5, 1
  %t47 = extractvalue { i64, ptr } %a5, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t62 = call %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v0, i64 %t41, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %t57)
  store %"compiler/free:reason" %t62, ptr %l34
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l26, !tbaa !29
  %t64 = load i64, ptr %l27, !tbaa !24
  %t65 = load %"compiler/free:reason", ptr %l34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eSetAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t63, i64 %t64, %"compiler/free:reason" %t65)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3, i32 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/free:reason"
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t9, i32 %a1)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t15, i64 %a2)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/free:Free", ptr %t19, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t21, i1 %a3)
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/free:Free", ptr %t25, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t27, i32 %a4)
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 36
  %t34 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t33, i64 %t34)
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:Free", ptr %t37, i32 0, i32 37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t39, i1 false)
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/free:Free", ptr %t41, i32 0, i32 38
  store ptr %t43, ptr %l28, !tbaa !29
  %t44 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  store i64 %t44, ptr %l29, !tbaa !24
  %t45 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t45, ptr %l30
  br label %bb8
bb8:
  %t46 = load i64, ptr %l29, !tbaa !24
  %t47 = load %"compiler/source:Span", ptr %l30
  %t48 = call %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v0, i64 %t46, i64 -1, %"compiler/source:Span" %t47, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store %"compiler/free:reason" %t48, ptr %l31
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l28, !tbaa !29
  %t50 = load %"compiler/free:reason", ptr %l31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2ePush_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t49, %"compiler/free:reason" %t50)
  br label %bb10
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/free:Free", ptr %t51, i32 0, i32 62
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t53, i1 %a5)
  br label %bb11
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:Free", ptr %t57, i32 0, i32 63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t59, i1 false)
  br label %bb12
bb12:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/free:Free", ptr %t61, i32 0, i32 64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t63, i1 false)
  br label %bb13
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 54
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t67, i64 -1)
  br label %bb14
bb14:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:Free", ptr %t69, i32 0, i32 55
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t71, i64 -1)
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 56
  store ptr %t75, ptr %l44, !tbaa !29
  %t76 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t76, ptr %l45
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l44, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t77, %"compiler/source:Span" %t78)
  br label %bb17
bb17:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/free:Free", ptr %t79, i32 0, i32 57
  store ptr %t81, ptr %l47, !tbaa !29
  %t82 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t82, ptr %l48
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l47, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l48
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t83, %"compiler/source:Span" %t84)
  br label %bb19
bb19:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:Free", ptr %t85, i32 0, i32 58
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t87, i1 false)
  br label %bb20
bb20:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/free:Free", ptr %t89, i32 0, i32 59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t91, i1 false)
  br label %bb21
bb21:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/free:Free", ptr %t93, i32 0, i32 60
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t95, i1 false)
  br label %bb22
bb22:
  %t97 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t97, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:Plan"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i1
  %l25 = alloca %"compiler/typed:Plan"
  %l26 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i1
  %l64 = alloca i1
  %l72 = alloca { i64, [1 x i64] }
  %l74 = alloca { i64, [1 x i64] }
  %l76 = alloca i1
  %l77 = alloca i1
  %l80 = alloca { i64, ptr }
  %l83 = alloca i64
  %l85 = alloca i1
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, [1 x i64] }
  %l94 = alloca { i64, [1 x i64] }
  %l96 = alloca i1
  %l98 = alloca i64
  %l106 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t15 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp sge i64 %t5, 63
  store i1 %t7, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 3
  %t14 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t15, ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t15, i64 152, i1 false)
  br label %bb7
bb7:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l25, i64 152, i1 false)
  %t18 = load i64, ptr %l5, !tbaa !24
  store i64 %t18, ptr %l26, !tbaa !24
  %t19 = load i64, ptr %l26, !tbaa !24
  %t20 = load i64, ptr %l26, !tbaa !24
  %t21 = shl i64 1, %t20
  store i64 %t21, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Call", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t30 = load i64, ptr %l9, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load i64, ptr %l10, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb13
bb10:
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l10, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l10, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l37, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l37, !tbaa !24
  store i64 %t56, ptr %l34, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb14
bb14:
  %t58 = load i64, ptr %l12, !tbaa !24
  %t59 = load i64, ptr %l11, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  br label %bb43
bb16:
  br label %bb17
bb17:
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l12, !tbaa !24
  %t68 = load i64, ptr %l10, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l13, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l13, !tbaa !24
  %t82 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t76, i64 %t77, i64 %t78)
  store i64 %t82, ptr %l58
  br label %bb18
bb18:
  %t83 = load i64, ptr %l58, !tbaa !24
  store i64 %t83, ptr %l14, !tbaa !24
  %t84 = load i64, ptr %l14, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb21
bb20:
  %t88 = load i64, ptr %l14, !tbaa !24
  %t90 = icmp sge i64 %t88, 63
  store i1 %t90, ptr %l61, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l61, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb24
bb23:
  %t93 = load i64, ptr %l14, !tbaa !24
  %t94 = load i64, ptr %l5, !tbaa !24
  %t97 = icmp eq i64 %t93, %t94
  store i1 %t97, ptr %l64, !tbaa !21
  br label %bb24
bb24:
  %t99 = load i1, ptr %l64, !tbaa !21
  br i1 %t99, label %bb25, label %bb26
bb25:
  br label %bb42
bb26:
  br label %bb27
bb27:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Call", ptr %t100, i32 0, i32 3
  %t103 = load i32, ptr %t102, !tbaa !23
  %t104 = load i64, ptr %l14, !tbaa !24
  %t108 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %l6, i32 %t103, i64 %t104)
  store { i64, [1 x i64] } %t108, ptr %l72
  br label %bb28
bb28:
  %t109 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t109, ptr %l74
  %t112 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l72, ptr %l74)
  store i1 %t112, ptr %l76
  br label %bb29
bb29:
  %t113 = load i1, ptr %l76, !tbaa !21
  br i1 %t113, label %bb30, label %bb31
bb30:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Call", ptr %t115, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l80, !tbaa !27
  %t119 = load i64, ptr %l13, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 %t119
  %t124 = load ptr, ptr %t123, !tbaa !39
  %t127 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t114, ptr %t124)
  store i64 %t127, ptr %l83
  br label %bb32
bb31:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb33
bb32:
  %t128 = load i64, ptr %l83, !tbaa !24
  %t129 = icmp sge i64 %t128, 0
  store i1 %t129, ptr %l77, !tbaa !21
  br label %bb33
bb33:
  %t131 = load i1, ptr %l77, !tbaa !21
  br i1 %t131, label %bb34, label %bb35
bb34:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l1, !tbaa !24
  %t134 = load ptr, ptr %l2, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Call", ptr %t134, i32 0, i32 1
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l89, !tbaa !27
  %t138 = load i64, ptr %l13, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr ptr, ptr %t141, i64 %t138
  %t143 = load ptr, ptr %t142, !tbaa !39
  %t147 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t132, i64 %t133, ptr %t143)
  store { i64, [1 x i64] } %t147, ptr %l92
  br label %bb36
bb35:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb38
bb36:
  %t148 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t148, ptr %l94
  %t151 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l92, ptr %l94)
  store i1 %t151, ptr %l96
  br label %bb37
bb37:
  %t152 = load i1, ptr %l96, !tbaa !21
  store i1 %t152, ptr %l85, !tbaa !21
  br label %bb38
bb38:
  %t153 = load i1, ptr %l85, !tbaa !21
  br i1 %t153, label %bb39, label %bb40
bb39:
  %t154 = load i64, ptr %l7, !tbaa !24
  %t155 = load i64, ptr %l14, !tbaa !24
  store i64 %t155, ptr %l98, !tbaa !24
  %t156 = load i64, ptr %l98, !tbaa !24
  %t157 = load i64, ptr %l98, !tbaa !24
  %t158 = shl i64 1, %t157
  %t161 = or i64 %t154, %t158
  store i64 %t161, ptr %l7, !tbaa !24
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t163 = load i64, ptr %l12, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l12, !tbaa !24
  br label %bb14
bb43:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/free:Free", ptr %t167, i32 0, i32 2
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t171 = load i64, ptr %l3, !tbaa !24
  %t174 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %s0, ptr %t170, i64 %t171)
  store { i64, ptr } %t174, ptr %l106
  br label %bb44
bb44:
  %t175 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l7, !tbaa !24
  %t182 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %s0, ptr %t176, { i64, ptr } %t175, i64 %t178)
  store i1 %t182, ptr %l110
  br label %bb45
bb45:
  %t183 = load i1, ptr %l110, !tbaa !21
  br i1 %t183, label %bb46, label %bb47
bb46:
  %t184 = load i64, ptr %l7, !tbaa !24
  store i64 %t184, ptr %l111, !tbaa !24
  br label %bb48
bb47:
  store i64 -1, ptr %l111, !tbaa !24
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t186 = load i64, ptr %l111, !tbaa !24
  store i64 %t186, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i64
  %l49 = alloca i64
  %l57 = alloca ptr
  %l60 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t7, -3
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb26
bb4:
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l3
  %t23 = load { i64, [2 x i64] }, ptr %l3
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l25
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t44, i64 %t45)
  store i64 %t46, ptr %l26
  br label %bb9
bb9:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb25
bb10:
  %t48 = load { i64, [2 x i64] }, ptr %l3
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t54 = getelementptr { i32, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t57)
  store ptr %t59, ptr %l31
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t60)
  store ptr %t62, ptr %l33
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t63)
  store ptr %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i32, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t67, i32 %t66)
  store i32 %t69, ptr %l37
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l38
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l31, !tbaa !29
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t75, ptr %l39
  br label %bb19
bb19:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_997f49c366488af5_93d2651ee5683809)
  unreachable
bb25:
  br label %bb26
bb26:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t80 = icmp slt i64 %t78, 0
  br i1 %t80, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb30
bb28:
  %t82 = load i64, ptr %l2, !tbaa !24
  store i64 %t82, ptr %l44, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:Free", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/load:Loader", ptr %t89, i32 0, i32 5
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l49
  br label %bb29
bb29:
  %t94 = load i64, ptr %l44, !tbaa !24
  %t95 = load i64, ptr %l49, !tbaa !24
  %t96 = icmp sge i64 %t94, %t95
  store i1 %t96, ptr %l43, !tbaa !21
  br label %bb30
bb30:
  %t98 = load i1, ptr %l43, !tbaa !21
  br i1 %t98, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/free:Free", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/load:Loader", ptr %t106, i32 0, i32 5
  %t109 = load i64, ptr %l2, !tbaa !24
  %t112 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t108, i64 %t109)
  store ptr %t112, ptr %l57
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l57, !tbaa !29
  %t115 = getelementptr %"compiler/load:Module", ptr %t113, i32 0, i32 2
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t116, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t118, ptr %l60
  br label %bb35
bb35:
  %t119 = load i1, ptr %l60, !tbaa !21
  %t120 = xor i1 %t119, true
  call void @__olang_scope_close(ptr %s0)
  store i1 %t120, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 3
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l16
  br label %bb6
bb6:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i32, ptr %l16, !tbaa !23
  %t30 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t27, i32 %t28, i64 %t26)
  store i64 %t30, ptr %l18
  br label %bb7
bb7:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  br label %bb22
bb8:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 4
  store i1 %t39, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l20, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l25, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l26, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Elem", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t52)
  store i32 %t54, ptr %l29
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load i32, ptr %l29, !tbaa !23
  %t57 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t57, ptr %l30
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l25, !tbaa !29
  %t59 = load i32, ptr %l30, !tbaa !23
  %t60 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t58, i32 %t59, i64 -1)
  store i64 %t60, ptr %l31
  br label %bb16
bb16:
  %t61 = load i64, ptr %l31, !tbaa !24
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5c44d6b41b035ab1_55f561a861d07b6d)
  unreachable
bb22:
  %t62 = load i64, ptr %l5, !tbaa !24
  store i64 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:store"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca ptr
  %l44 = alloca %"compiler/free:store"
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l56 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i64
  %l67 = alloca { i64, [1 x i64] }
  %l70 = alloca i64
  %l71 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:store" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 7
  %t2 = load ptr, ptr %t1, !tbaa !29
  %t4 = icmp eq ptr %t2, null
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_3bfd4abaed3d7178_ecedd42d9535955c)
  unreachable
bb2:
  br label %bb3
bb3:
  %t6 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 7
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t16 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t9, i64 %t11, ptr %t12)
  store { i64, [1 x i64] } %t16, ptr %l13
  br label %bb4
bb4:
  %t17 = load { i64, [1 x i64] }, ptr %l13
  %t18 = call i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %t17)
  store i1 %t18, ptr %l14
  br label %bb5
bb5:
  %t19 = load i1, ptr %l14, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = call ptr @compiler_2ffree_2ecallOf(ptr %v1, ptr %t23)
  store ptr %t25, ptr %l18
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l18, !tbaa !29
  store ptr %t26, ptr %l3, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 5
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Promote", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call ptr @compiler_2ffree_2ectorCall(ptr %v1, ptr %t45)
  store ptr %t47, ptr %l27
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l27, !tbaa !29
  store ptr %t48, ptr %l3, !tbaa !29
  br label %bb35
bb16:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t50 = load ptr, ptr %l28, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t53 = load ptr, ptr %l28, !tbaa !29
  %t54 = load i64, ptr %t53
  %t56 = icmp eq i64 %t54, 17
  store i1 %t56, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t57 = load i1, ptr %l29, !tbaa !21
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  br label %bb21
bb20:
  br label %bb24
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l34, !tbaa !29
  %t65 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 0
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 2
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 3
  %t72 = load %"compiler/source:Span", ptr %t71
  %t73 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 4
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 5
  %t76 = load i64, ptr %t75, !tbaa !24
  %t77 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 6
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t89 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v1, ptr %s3, ptr %s3, i64 %t66, i64 %t68, i64 %t70, %"compiler/source:Span" %t72, i64 %t74, i64 %t76, i64 %t78, ptr %t79, ptr null)
  store %"compiler/free:store" %t89, ptr %l44
  br label %bb22
bb22:
  %t90 = load ptr, ptr %l34, !tbaa !29
  %t91 = load %"compiler/free:store", ptr %l44
  %t92 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %s3, ptr %t90, %"compiler/free:store" %t91)
  store i1 %t92, ptr %l45
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  %t93 = load i1, ptr %l45, !tbaa !21
  store i1 %t93, ptr %rv
  br label %ret
bb24:
  %t94 = load ptr, ptr %l2, !tbaa !29
  store ptr %t94, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t95 = load ptr, ptr %l46, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t98 = load ptr, ptr %l46, !tbaa !29
  %t99 = load i64, ptr %t98
  %t101 = icmp eq i64 %t99, 6
  store i1 %t101, ptr %l47, !tbaa !21
  br label %bb26
bb26:
  %t102 = load i1, ptr %l47, !tbaa !21
  br i1 %t102, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 true, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_18f4ed1d8e27b1ae_93487f3f650a5572)
  unreachable
bb35:
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb36, label %bb37
bb36:
  store i1 true, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t113 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t109, ptr %t110)
  store i64 %t113, ptr %l56
  br label %bb39
bb39:
  %t114 = load i64, ptr %l56, !tbaa !24
  store i64 %t114, ptr %l6, !tbaa !24
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = icmp slt i64 %t115, 0
  br i1 %t117, label %bb40, label %bb41
bb40:
  store i1 true, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l60, !tbaa !29
  %t121 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t122 = load i64, ptr %t121, !tbaa !24
  store i64 %t122, ptr %l61, !tbaa !24
  %t123 = load ptr, ptr %l3, !tbaa !29
  store ptr %t123, ptr %l62, !tbaa !29
  %t124 = load i64, ptr %l6, !tbaa !24
  store i64 %t124, ptr %l63, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t127 = load i64, ptr %t126, !tbaa !24
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t132 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t125, i64 %t127, ptr %t128)
  store { i64, [1 x i64] } %t132, ptr %l67
  br label %bb43
bb43:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i64, ptr %l6, !tbaa !24
  %t137 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %t133, i64 %t134)
  store i64 %t137, ptr %l70
  br label %bb44
bb44:
  %t138 = load ptr, ptr %l60, !tbaa !29
  %t139 = load i64, ptr %l61, !tbaa !24
  %t140 = load ptr, ptr %l62, !tbaa !29
  %t141 = load i64, ptr %l63, !tbaa !24
  %t142 = load { i64, [1 x i64] }, ptr %l67
  %t143 = load i64, ptr %l70, !tbaa !24
  %t144 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %t138, i64 %t139, ptr %t140, i64 %t141, { i64, [1 x i64] } %t142, i64 %t143)
  store i64 %t144, ptr %l71
  br label %bb45
bb45:
  %t145 = load i64, ptr %l71, !tbaa !24
  %t146 = icmp sge i64 %t145, 0
  store i1 %t146, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:letGo"
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 6
  %t5 = load %"compiler/source:Span", ptr %t4
  %t9 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %t3, %"compiler/source:Span" %t5)
  store { i64, ptr } %t9, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i32
  %l33 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l51 = alloca i1
  %l58 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb4:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l15
  br label %bb5
bb5:
  %t18 = load i1, ptr %l15, !tbaa !21
  store i1 %t18, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l19
  br label %bb9
bb9:
  %t25 = load i1, ptr %l19, !tbaa !21
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l24
  br label %bb14
bb14:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l24, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l25
  br label %bb15
bb15:
  %t37 = load i32, ptr %l25, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l28
  br label %bb16
bb16:
  %t43 = load i32, ptr %l28
  store i32 %t43, ptr %l4
  %t44 = load i32, ptr %l4
  %t46 = trunc i64 19 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l33
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t54 = load i1, ptr %l33, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
bb20:
  %t55 = load i32, ptr %l4
  %t57 = trunc i64 18 to i32
  %t58 = icmp eq i32 %t55, %t57
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb24
bb22:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l40
  br label %bb23
bb23:
  %t67 = load i1, ptr %l40, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t70 = load i1, ptr %l37, !tbaa !21
  br i1 %t70, label %bb25, label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t72 = load ptr, ptr %l2, !tbaa !29
  store ptr %t72, ptr %l43, !tbaa !29
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t74 = load i32, ptr %l3, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l46
  br label %bb28
bb28:
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t79 = load i32, ptr %l46, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t80, ptr %l47
  br label %bb29
bb29:
  %t81 = load i32, ptr %l47
  store i32 %t81, ptr %l5
  %t82 = load i32, ptr %l5
  %t84 = trunc i64 0 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb30, label %bb31
bb30:
  %t89 = load i32, ptr %l5
  %t91 = trunc i64 1 to i32
  %t92 = icmp eq i32 %t89, %t91
  %t94 = xor i1 %t92, true
  store i1 %t94, ptr %l51, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t96 = load i1, ptr %l51, !tbaa !21
  br i1 %t96, label %bb33, label %bb34
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t98, i32 %t99)
  store i1 %t102, ptr %l58
  br label %bb36
bb36:
  %t103 = load i1, ptr %l58, !tbaa !21
  store i1 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l28 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i64
  %l39 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i64
  %l49 = alloca i1
  %l55 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = add i64 %t1, 2
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb30
bb3:
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t13, ptr %l15, !tbaa !27
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i64, ptr %t17, i64 %t14
  %t19 = load i64, ptr %t18, !tbaa !34
  store i64 %t19, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i64, ptr %t27, i64 %t24
  %t29 = load i64, ptr %t28, !tbaa !34
  store i64 %t29, ptr %l5, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t32, 2
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i64, ptr %t37, i64 %t34
  %t39 = load i64, ptr %t38, !tbaa !34
  store i64 %t39, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = icmp sge i64 %t41, 0
  br i1 %t43, label %bb5, label %bb6
bb5:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp slt i64 %t45, 63
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t49 = load i1, ptr %l28, !tbaa !21
  br i1 %t49, label %bb8, label %bb9
bb8:
  %t50 = load i64, ptr %l2, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  store i64 %t51, ptr %l33, !tbaa !24
  %t52 = load i64, ptr %l33, !tbaa !24
  %t53 = load i64, ptr %l33, !tbaa !24
  %t54 = shl i64 1, %t53
  %t57 = and i64 %t50, %t54
  %t59 = icmp ne i64 %t57, 0
  store i1 %t59, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t61 = load i1, ptr %l31, !tbaa !21
  store i1 %t61, ptr %l7, !tbaa !21
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = icmp sge i64 %t62, 0
  br i1 %t64, label %bb11, label %bb12
bb11:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = icmp slt i64 %t66, 63
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t70 = load i1, ptr %l39, !tbaa !21
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load i64, ptr %l5, !tbaa !24
  store i64 %t72, ptr %l44, !tbaa !24
  %t73 = load i64, ptr %l44, !tbaa !24
  %t74 = load i64, ptr %l44, !tbaa !24
  %t75 = shl i64 1, %t74
  %t78 = and i64 %t71, %t75
  %t80 = icmp ne i64 %t78, 0
  store i1 %t80, ptr %l42, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t82 = load i1, ptr %l42, !tbaa !21
  store i1 %t82, ptr %l8, !tbaa !21
  %t83 = load i1, ptr %l7, !tbaa !21
  br i1 %t83, label %bb17, label %bb18
bb17:
  %t85 = load i1, ptr %l8, !tbaa !21
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l49, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb19
bb19:
  %t89 = load i1, ptr %l49, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = icmp eq i64 %t91, 1
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = load i1, ptr %l7, !tbaa !21
  %t96 = load i1, ptr %l8, !tbaa !21
  %t99 = icmp ne i1 %t95, %t96
  store i1 %t99, ptr %l55, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb25
bb25:
  %t101 = load i1, ptr %l55, !tbaa !21
  br i1 %t101, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t103 = load i64, ptr %l3, !tbaa !24
  %t105 = add i64 %t103, 3
  store i64 %t105, ptr %l3, !tbaa !24
  br label %bb1
bb30:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereported(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/free:store"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l11 = alloca i1
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca %"compiler/free:store"
  %l26 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l49 = alloca i1
  %l54 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca i32
  %l67 = alloca i32
  %l72 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca i64
  %l79 = alloca i1
  %l80 = alloca i64
  %l85 = alloca i64
  %l87 = alloca i1
  %l93 = alloca ptr
  %l96 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i1 false, ptr %l2, !tbaa !21
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 34
  store ptr %t10, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t12 = load i64, ptr %l4, !tbaa !24
  store i64 %t12, ptr %l15, !tbaa !24
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l17
  br label %bb6
bb6:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = load i64, ptr %l17, !tbaa !24
  %t18 = icmp slt i64 %t16, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb7, label %bb8
bb7:
  br label %bb28
bb8:
  br label %bb9
bb9:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t22, i64 %t23)
  store %"compiler/free:store" %t26, ptr %l22
  br label %bb10
bb10:
  %t27 = load %"compiler/free:store", ptr %l22
  store %"compiler/free:store" %t27, ptr %l5
  %t28 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:Free", ptr %t35, i32 0, i32 17
  %t38 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 1
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t37, i64 %t39)
  store i1 %t42, ptr %l30
  br label %bb13
bb12:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb14
bb13:
  %t43 = load i1, ptr %l30, !tbaa !21
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t45 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 6
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = icmp sge i64 %t46, 0
  br i1 %t48, label %bb17, label %bb18
bb16:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb23
bb17:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb19
bb18:
  %t50 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 4
  %t51 = load i64, ptr %t50, !tbaa !24
  %t52 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t55 = icmp eq i64 %t51, %t52
  store i1 %t55, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l34, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb22
bb21:
  %t58 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 4
  %t59 = load i64, ptr %t58, !tbaa !24
  %t60 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t63 = icmp eq i64 %t59, %t60
  store i1 %t63, ptr %l38, !tbaa !21
  br label %bb22
bb22:
  %t65 = load i1, ptr %l38, !tbaa !21
  store i1 %t65, ptr %l31, !tbaa !21
  br label %bb23
bb23:
  %t66 = load i1, ptr %l31, !tbaa !21
  br i1 %t66, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l4, !tbaa !24
  br label %bb5
bb28:
  %t71 = load i1, ptr %l2, !tbaa !21
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l1, !tbaa !24
  %t80 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisContents(ptr %v0, ptr %t76, i64 %t77)
  store i1 %t80, ptr %l49
  br label %bb32
bb32:
  %t81 = load i1, ptr %l49, !tbaa !21
  br i1 %t81, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:Free", ptr %t83, i32 0, i32 9
  %t86 = load i64, ptr %l1, !tbaa !24
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t85, i64 %t86)
  store i64 %t89, ptr %l54
  br label %bb36
bb36:
  %t90 = load i64, ptr %l54, !tbaa !24
  %t91 = icmp slt i64 %t90, 0
  br i1 %t91, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t94)
  store ptr %t96, ptr %l58
  br label %bb40
bb40:
  %t97 = load ptr, ptr %l58, !tbaa !29
  store ptr %t97, ptr %l6, !tbaa !29
  %t98 = load ptr, ptr %l6, !tbaa !29
  store ptr %t98, ptr %l59, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/free:Free", ptr %t99, i32 0, i32 8
  %t102 = load i64, ptr %l1, !tbaa !24
  %t105 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t101, i64 %t102)
  store i32 %t105, ptr %l63
  br label %bb41
bb41:
  %t106 = load ptr, ptr %l59, !tbaa !29
  %t107 = load i32, ptr %l63, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t108, ptr %l64
  br label %bb42
bb42:
  %t109 = load i32, ptr %l64, !tbaa !23
  store i32 %t109, ptr %l7, !tbaa !23
  %t110 = load ptr, ptr %l6, !tbaa !29
  %t111 = load i32, ptr %l7, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t114, ptr %l67
  br label %bb43
bb43:
  %t115 = load i32, ptr %l67
  %t117 = trunc i64 18 to i32
  %t118 = icmp eq i32 %t115, %t117
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t123 = load ptr, ptr %l6, !tbaa !29
  store ptr %t123, ptr %l72, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t125 = load i32, ptr %l7, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l75
  br label %bb47
bb47:
  %t129 = load ptr, ptr %l72, !tbaa !29
  %t130 = load i32, ptr %l75, !tbaa !23
  %t131 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t129, i32 %t130)
  store i64 %t131, ptr %l76
  br label %bb48
bb48:
  %t132 = load i64, ptr %l76, !tbaa !24
  store i64 %t132, ptr %l8, !tbaa !24
  %t133 = load i64, ptr %l8, !tbaa !24
  %t135 = icmp sge i64 %t133, 0
  br i1 %t135, label %bb49, label %bb50
bb49:
  %t137 = load i64, ptr %l8, !tbaa !24
  store i64 %t137, ptr %l80, !tbaa !24
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/free:Free", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/load:Loader", ptr %t144, i32 0, i32 5
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l85
  br label %bb51
bb50:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb52
bb51:
  %t149 = load i64, ptr %l80, !tbaa !24
  %t150 = load i64, ptr %l85, !tbaa !24
  %t151 = icmp slt i64 %t149, %t150
  store i1 %t151, ptr %l79, !tbaa !21
  br label %bb52
bb52:
  %t153 = load i1, ptr %l79, !tbaa !21
  br i1 %t153, label %bb53, label %bb54
bb53:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/free:Free", ptr %t154, i32 0, i32 0
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 0
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/load:Loader", ptr %t160, i32 0, i32 5
  %t163 = load i64, ptr %l8, !tbaa !24
  %t166 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t162, i64 %t163)
  store ptr %t166, ptr %l93
  br label %bb55
bb54:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb57
bb55:
  %t167 = load ptr, ptr %l93, !tbaa !29
  %t169 = getelementptr %"compiler/load:Module", ptr %t167, i32 0, i32 2
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  %t172 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t170, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t172, ptr %l96
  br label %bb56
bb56:
  %t173 = load i1, ptr %l96, !tbaa !21
  %t174 = xor i1 %t173, true
  store i1 %t174, ptr %l87, !tbaa !21
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t176 = load i1, ptr %l87, !tbaa !21
  store i1 %t176, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erowBefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1, %"compiler/free:letGo" %a2) #0 {
entry:
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca %"compiler/free:letGo"
  %l16 = alloca i1
  %rv = alloca i1
  store %"compiler/free:letGo" %a1, ptr %l1
  store %"compiler/free:letGo" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 5
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t6 = icmp eq i64 %t2, %t3
  %t7 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 5
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t12 = icmp eq i64 %t8, %t9
  %t15 = icmp ne i1 %t6, %t12
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 5
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t22 = icmp eq i64 %t18, %t19
  store i1 %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t25 = load %"compiler/free:letGo", ptr %l1
  %t26 = load %"compiler/free:letGo", ptr %l2
  %t30 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %t25, %"compiler/free:letGo" %t26)
  store i1 %t30, ptr %l16
  br label %bb4
bb4:
  %t31 = load i1, ptr %l16, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l48 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i1
  %l57 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l91 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l107 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i32
  %l130 = alloca i1
  %l140 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca i32
  %l149 = alloca i1
  %l150 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l165 = alloca i1
  %l168 = alloca i1
  %l174 = alloca ptr
  %l177 = alloca i32
  %l178 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l189 = alloca i1
  %l192 = alloca i1
  %l200 = alloca ptr
  %l201 = alloca i32
  %l203 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l25
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l25, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l28
  br label %bb2
bb2:
  %t10 = load i32, ptr %l28, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l31
  br label %bb3
bb3:
  %t16 = load i32, ptr %l31
  store i32 %t16, ptr %l4
  %t17 = load i32, ptr %l4
  %t19 = trunc i64 21 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb6
bb5:
  %t22 = load i32, ptr %l4
  %t24 = trunc i64 25 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l34, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l34, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb9
bb8:
  %t28 = load i32, ptr %l4
  %t30 = trunc i64 29 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l37, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l37, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb12
bb11:
  %t34 = load i32, ptr %l4
  %t36 = trunc i64 0 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l40, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l40, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t41 = load i32, ptr %l4
  %t43 = trunc i64 20 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb16, label %bb17
bb16:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l48
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t51 = load i1, ptr %l48, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l50, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l53
  br label %bb22
bb22:
  %t59 = load ptr, ptr %l50, !tbaa !29
  %t60 = load i32, ptr %l53, !tbaa !23
  %t61 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t61, ptr %l54
  br label %bb23
bb23:
  %t62 = load i1, ptr %l54, !tbaa !21
  store i1 %t62, ptr %rv
  br label %ret
bb24:
  %t63 = load i32, ptr %l4
  %t65 = trunc i64 19 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb25, label %bb26
bb25:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l57, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t70 = load i32, ptr %l3, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l60
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t74 = load ptr, ptr %l57, !tbaa !29
  %t75 = load i32, ptr %l60, !tbaa !23
  %t76 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t76, ptr %l61
  br label %bb28
bb28:
  %t77 = load i1, ptr %l61, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
bb29:
  %t78 = load i32, ptr %l4
  %t80 = trunc i64 22 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb32
bb31:
  %t83 = load i32, ptr %l4
  %t85 = trunc i64 23 to i32
  %t86 = icmp eq i32 %t83, %t85
  store i1 %t86, ptr %l64, !tbaa !21
  br label %bb32
bb32:
  %t88 = load i1, ptr %l64, !tbaa !21
  br i1 %t88, label %bb33, label %bb34
bb33:
  %t89 = load ptr, ptr %l2, !tbaa !29
  store ptr %t89, ptr %l67, !tbaa !29
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l70
  br label %bb35
bb34:
  br label %bb47
bb35:
  %t95 = load ptr, ptr %l67, !tbaa !29
  %t96 = load i32, ptr %l70, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t95, i32 %t96)
  store { i64, ptr } %t97, ptr %l71
  br label %bb36
bb36:
  %t98 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t98, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  store i64 %t101, ptr %l7, !tbaa !24
  br label %bb37
bb37:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb38, label %bb39
bb38:
  br label %bb46
bb39:
  br label %bb40
bb40:
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t111, ptr %l78, !tbaa !27
  %t112 = load i64, ptr %l6, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 %t112
  %t117 = load i32, ptr %t116, !tbaa !33
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t123 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t119, i32 %t117)
  store i1 %t123, ptr %l83
  br label %bb41
bb41:
  %t124 = load i1, ptr %l83, !tbaa !21
  %t125 = xor i1 %t124, true
  br i1 %t125, label %bb42, label %bb43
bb42:
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t128 = load i64, ptr %l6, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l6, !tbaa !24
  br label %bb37
bb46:
  store i1 true, ptr %rv
  br label %ret
bb47:
  %t133 = load i32, ptr %l4
  %t135 = trunc i64 24 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb48, label %bb49
bb48:
  %t138 = load ptr, ptr %l2, !tbaa !29
  store ptr %t138, ptr %l91, !tbaa !29
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t140 = load i32, ptr %l3, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l94
  br label %bb50
bb49:
  br label %bb62
bb50:
  %t144 = load ptr, ptr %l91, !tbaa !29
  %t145 = load i32, ptr %l94, !tbaa !23
  %t146 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t144, i32 %t145)
  store { i64, ptr } %t146, ptr %l95
  br label %bb51
bb51:
  %t147 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t147, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  store i64 %t150, ptr %l11, !tbaa !24
  br label %bb52
bb52:
  %t152 = load i64, ptr %l10, !tbaa !24
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = icmp slt i64 %t152, %t153
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb53, label %bb54
bb53:
  br label %bb61
bb54:
  br label %bb55
bb55:
  %t160 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t160, ptr %l102, !tbaa !27
  %t161 = load i64, ptr %l10, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i32, ptr %t164, i64 %t161
  %t166 = load i32, ptr %t165, !tbaa !33
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t172 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t168, i32 %t166)
  store i1 %t172, ptr %l107
  br label %bb56
bb56:
  %t173 = load i1, ptr %l107, !tbaa !21
  %t174 = xor i1 %t173, true
  br i1 %t174, label %bb57, label %bb58
bb57:
  store i1 false, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t177 = load i64, ptr %l10, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l10, !tbaa !24
  br label %bb52
bb61:
  store i1 true, ptr %rv
  br label %ret
bb62:
  %t182 = load i32, ptr %l4
  %t184 = trunc i64 18 to i32
  %t185 = icmp eq i32 %t182, %t184
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb63, label %bb64
bb63:
  store i1 true, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  %t190 = load ptr, ptr %l2, !tbaa !29
  %t191 = load i32, ptr %l3, !tbaa !23
  %t194 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t190, i32 %t191)
  store i1 %t194, ptr %l119
  br label %bb66
bb66:
  %t195 = load i1, ptr %l119, !tbaa !21
  %t196 = xor i1 %t195, true
  br i1 %t196, label %bb67, label %bb68
bb67:
  store i1 false, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/free:Free", ptr %t199, i32 0, i32 14
  %t202 = load i32, ptr %l3, !tbaa !23
  %t205 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t201, i32 %t202)
  %t206 = extractvalue { i32, i64 } %t205, 1
  %t207 = extractvalue { i32, i64 } %t205, 0
  store i32 %t207, ptr %l127
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb71, label %ok.209
ok.209:
  store i64 %t206, ptr %l126
  br label %bb70
bb70:
  %t210 = load i64, ptr %l126, !tbaa !24
  store i64 %t210, ptr %l122, !tbaa !24
  br label %bb73
bb71:
  br label %bb72
bb72:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l122, !tbaa !24
  br label %bb73
bb73:
  %t211 = load i64, ptr %l122, !tbaa !24
  store i64 %t211, ptr %l13, !tbaa !24
  %t212 = load i64, ptr %l13, !tbaa !24
  %t214 = icmp eq i64 %t212, 1
  br i1 %t214, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb76
bb75:
  %t216 = load i64, ptr %l13, !tbaa !24
  %t218 = icmp eq i64 %t216, 3
  store i1 %t218, ptr %l130, !tbaa !21
  br label %bb76
bb76:
  %t220 = load i1, ptr %l130, !tbaa !21
  br i1 %t220, label %bb77, label %bb78
bb77:
  store i1 true, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t224 = icmp eq i64 %t222, 2
  br i1 %t224, label %bb80, label %bb81
bb80:
  store i1 false, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/free:Free", ptr %t227, i32 0, i32 14
  %t230 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t229, i32 %t230, i64 1)
  br label %bb83
bb83:
  store i1 true, ptr %l14, !tbaa !21
  %t233 = load ptr, ptr %l2, !tbaa !29
  store ptr %t233, ptr %l140, !tbaa !29
  %t234 = load ptr, ptr %l2, !tbaa !29
  %t235 = load i32, ptr %l3, !tbaa !23
  %t238 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t234, i32 %t235)
  store i32 %t238, ptr %l143
  br label %bb84
bb84:
  %t239 = load ptr, ptr %l140, !tbaa !29
  %t240 = load i32, ptr %l143, !tbaa !23
  %t241 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t239, i32 %t240)
  store i32 %t241, ptr %l144
  br label %bb85
bb85:
  %t242 = load i32, ptr %l144
  store i32 %t242, ptr %l15
  %t243 = load i32, ptr %l15
  %t245 = trunc i64 0 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb86, label %bb87
bb86:
  %t248 = load ptr, ptr %l2, !tbaa !29
  %t249 = load i32, ptr %l3, !tbaa !23
  %t252 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t248, i32 %t249)
  store i1 %t252, ptr %l149
  br label %bb88
bb87:
  %t253 = load i32, ptr %l15
  %t255 = trunc i64 1 to i32
  %t256 = icmp eq i32 %t253, %t255
  br i1 %t256, label %bb107, label %bb108
bb88:
  %t258 = load i1, ptr %l149, !tbaa !21
  br i1 %t258, label %bb89, label %bb90
bb89:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb91
bb90:
  br label %bb91
bb91:
  %t259 = load ptr, ptr %l2, !tbaa !29
  store ptr %t259, ptr %l150, !tbaa !29
  %t260 = load ptr, ptr %l2, !tbaa !29
  %t261 = load i32, ptr %l3, !tbaa !23
  %t264 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t264, ptr %l153
  br label %bb92
bb92:
  %t265 = load ptr, ptr %l150, !tbaa !29
  %t266 = load i32, ptr %l153, !tbaa !23
  %t267 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t265, i32 %t266)
  store { i64, ptr } %t267, ptr %l154
  br label %bb93
bb93:
  %t268 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t268, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t269 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 0
  store i64 %t271, ptr %l18, !tbaa !24
  br label %bb94
bb94:
  %t273 = load i64, ptr %l17, !tbaa !24
  %t274 = load i64, ptr %l18, !tbaa !24
  %t277 = icmp slt i64 %t273, %t274
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb95, label %bb96
bb95:
  br label %bb106
bb96:
  br label %bb97
bb97:
  %t281 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t281, ptr %l161, !tbaa !27
  %t282 = load i64, ptr %l17, !tbaa !24
  %t284 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = getelementptr i32, ptr %t285, i64 %t282
  %t287 = load i32, ptr %t286, !tbaa !33
  store i32 %t287, ptr %l19, !tbaa !23
  %t289 = load i1, ptr %l14, !tbaa !21
  br i1 %t289, label %bb98, label %bb99
bb98:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l19, !tbaa !23
  %t295 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t291, i32 %t292)
  store i1 %t295, ptr %l168
  br label %bb100
bb99:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb101
bb100:
  %t296 = load i1, ptr %l168, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l165, !tbaa !21
  br label %bb101
bb101:
  %t299 = load i1, ptr %l165, !tbaa !21
  br i1 %t299, label %bb102, label %bb103
bb102:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb104
bb103:
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t300 = load i64, ptr %l17, !tbaa !24
  %t302 = add i64 %t300, 1
  store i64 %t302, ptr %l17, !tbaa !24
  br label %bb94
bb106:
  br label %bb128
bb107:
  %t304 = load ptr, ptr %l2, !tbaa !29
  store ptr %t304, ptr %l174, !tbaa !29
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t306 = load i32, ptr %l3, !tbaa !23
  %t309 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t305, i32 %t306)
  store i32 %t309, ptr %l177
  br label %bb109
bb108:
  %t310 = load i32, ptr %l15
  %t312 = trunc i64 4 to i32
  %t313 = icmp eq i32 %t310, %t312
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb124, label %bb125
bb109:
  %t317 = load ptr, ptr %l174, !tbaa !29
  %t318 = load i32, ptr %l177, !tbaa !23
  %t319 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t317, i32 %t318)
  store { i64, ptr } %t319, ptr %l178
  br label %bb110
bb110:
  %t320 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t320, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t321 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  store i64 %t323, ptr %l22, !tbaa !24
  br label %bb111
bb111:
  %t325 = load i64, ptr %l21, !tbaa !24
  %t326 = load i64, ptr %l22, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb112, label %bb113
bb112:
  br label %bb123
bb113:
  br label %bb114
bb114:
  %t333 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t333, ptr %l185, !tbaa !27
  %t334 = load i64, ptr %l21, !tbaa !24
  %t336 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr i32, ptr %t337, i64 %t334
  %t339 = load i32, ptr %t338, !tbaa !33
  store i32 %t339, ptr %l23, !tbaa !23
  %t341 = load i1, ptr %l14, !tbaa !21
  br i1 %t341, label %bb115, label %bb116
bb115:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i32, ptr %l23, !tbaa !23
  %t347 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t343, i32 %t344)
  store i1 %t347, ptr %l192
  br label %bb117
bb116:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb118
bb117:
  %t348 = load i1, ptr %l192, !tbaa !21
  %t349 = xor i1 %t348, true
  store i1 %t349, ptr %l189, !tbaa !21
  br label %bb118
bb118:
  %t351 = load i1, ptr %l189, !tbaa !21
  br i1 %t351, label %bb119, label %bb120
bb119:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb121
bb120:
  br label %bb121
bb121:
  br label %bb122
bb122:
  %t352 = load i64, ptr %l21, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l21, !tbaa !24
  br label %bb111
bb123:
  br label %bb127
bb124:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb126
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/free:Free", ptr %t356, i32 0, i32 14
  store ptr %t358, ptr %l200, !tbaa !29
  %t359 = load i32, ptr %l3, !tbaa !23
  store i32 %t359, ptr %l201, !tbaa !23
  %t360 = load i1, ptr %l14, !tbaa !21
  br i1 %t360, label %bb129, label %bb130
bb129:
  store i64 3, ptr %l203, !tbaa !24
  br label %bb131
bb130:
  store i64 2, ptr %l203, !tbaa !24
  br label %bb131
bb131:
  %t362 = load ptr, ptr %l200, !tbaa !29
  %t363 = load i32, ptr %l201, !tbaa !23
  %t364 = load i64, ptr %l203, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t362, i32 %t363, i64 %t364)
  br label %bb132
bb132:
  %t365 = load i1, ptr %l14, !tbaa !21
  store i1 %t365, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esave(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l35 = alloca i64
  %l40 = alloca i64
  %l44 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l73 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca i64
  %l82 = alloca i64
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 3
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v1, ptr %t3)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 3
  store ptr %t9, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l6, !tbaa !24
  store i64 %t11, ptr %l25, !tbaa !24
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l27
  br label %bb3
bb3:
  %t15 = load i64, ptr %l25, !tbaa !24
  %t16 = load i64, ptr %l27, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v1, ptr %v1, ptr %t21, i64 %t22)
  store ptr %t25, ptr %l32
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l32, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  store i64 %t27, ptr %l33, !tbaa !24
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t26)
  store i64 %t30, ptr %l35
  br label %bb8
bb8:
  %t31 = load i64, ptr %l33, !tbaa !24
  %t32 = load i64, ptr %l35, !tbaa !24
  %t33 = add i64 %t31, %t32
  store i64 %t33, ptr %l4, !tbaa !24
  br label %bb9
bb9:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l6, !tbaa !24
  br label %bb2
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l40, !tbaa !24
  %t42 = load i64, ptr %l40, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = load i64, ptr %l40, !tbaa !24
  %t46 = icmp sle i64 %t45, 1152921504606846975
  br i1 %t46, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_cba1607a5f8c25be_1da50212bb736ed2)
  unreachable
bb13:
  %t48 = load i64, ptr %l40, !tbaa !24
  %t49 = mul i64 %t48, 8
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l8, !tbaa !27
  %t54 = load i64, ptr %l4, !tbaa !24
  store i64 %t54, ptr %l44, !tbaa !24
  %t55 = load i64, ptr %l44, !tbaa !24
  %t56 = icmp sge i64 %t55, 0
  br i1 %t56, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_cba1607a5f8c25be_1da50212bb736ed2)
  unreachable
bb15:
  %t58 = load i64, ptr %l44, !tbaa !24
  %t59 = icmp sle i64 %t58, 1152921504606846975
  br i1 %t59, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a35b07018a31f4f3_69e61a5b7415d1c7)
  unreachable
bb17:
  %t61 = load i64, ptr %l44, !tbaa !24
  %t62 = mul i64 %t61, 8
  %t63 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t67 = load i64, ptr %l3, !tbaa !24
  store i64 %t67, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t69 = load i64, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l11, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_a35b07018a31f4f3_69e61a5b7415d1c7)
  unreachable
bb19:
  %t75 = load i64, ptr %l13, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb24
bb21:
  %t79 = load i64, ptr %l12, !tbaa !24
  %t80 = load i64, ptr %l11, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l13, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l13, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l55, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb23
bb23:
  %t95 = load i64, ptr %l55, !tbaa !24
  store i64 %t95, ptr %l52, !tbaa !24
  br label %bb24
bb24:
  %t96 = load i64, ptr %l52, !tbaa !24
  store i64 %t96, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb25
bb25:
  %t97 = load i64, ptr %l15, !tbaa !24
  %t98 = load i64, ptr %l14, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb26, label %bb27
bb26:
  br label %bb39
bb27:
  br label %bb28
bb28:
  %t105 = load i64, ptr %l11, !tbaa !24
  %t106 = load i64, ptr %l15, !tbaa !24
  %t107 = load i64, ptr %l13, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l16, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t115, ptr %l73, !tbaa !27
  %t116 = load i64, ptr %l16, !tbaa !24
  %t117 = load i64, ptr %l10, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i64, ptr %t121, i64 %t116
  store i64 %t117, ptr %t122, !tbaa !34
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/free:walker", ptr %t123, i32 0, i32 3
  %t126 = load i64, ptr %l16, !tbaa !24
  %t129 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v1, ptr %v1, ptr %t125, i64 %t126)
  store ptr %t129, ptr %l79
  br label %bb29
bb29:
  %t130 = load ptr, ptr %l79, !tbaa !29
  store ptr %t130, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb30
bb30:
  %t131 = load i64, ptr %l18, !tbaa !24
  store i64 %t131, ptr %l80, !tbaa !24
  %t132 = load ptr, ptr %l17, !tbaa !29
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t132)
  store i64 %t134, ptr %l82
  br label %bb31
bb31:
  %t135 = load i64, ptr %l80, !tbaa !24
  %t136 = load i64, ptr %l82, !tbaa !24
  %t137 = icmp slt i64 %t135, %t136
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t141 = load ptr, ptr %l17, !tbaa !29
  %t142 = load i64, ptr %l18, !tbaa !24
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t141, i64 %t142)
  store i64 %t145, ptr %l87
  br label %bb35
bb35:
  %t146 = load i64, ptr %l87, !tbaa !24
  %t147 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t147, ptr %l88, !tbaa !27
  %t148 = load i64, ptr %l10, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i64, ptr %t153, i64 %t148
  store i64 %t146, ptr %t154, !tbaa !34
  %t155 = load i64, ptr %l10, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l10, !tbaa !24
  br label %bb36
bb36:
  %t159 = load i64, ptr %l18, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l18, !tbaa !24
  br label %bb30
bb37:
  br label %bb38
bb38:
  %t163 = load i64, ptr %l15, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l15, !tbaa !24
  br label %bb25
bb39:
  %t167 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t167, ptr %l97, !tbaa !27
  %t168 = load i64, ptr %l3, !tbaa !24
  %t169 = load i64, ptr %l10, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i64, ptr %t173, i64 %t168
  store i64 %t169, ptr %t174, !tbaa !34
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/free:Free", ptr %t175, i32 0, i32 49
  %t178 = load i64, ptr %l2, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t177, i64 %t178, { i64, ptr } %t179)
  br label %bb40
bb40:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/free:Free", ptr %t183, i32 0, i32 50
  %t186 = load i64, ptr %l2, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t185, i64 %t186, { i64, ptr } %t187)
  br label %bb41
bb41:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2escopeName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/free:letGo"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca i32
  %l26 = alloca { i64, ptr }
  %l30 = alloca i64
  %l32 = alloca i1
  %l34 = alloca i1
  %l36 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca i64
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca %"compiler/free:letGo"
  %l59 = alloca i1
  %l65 = alloca { i64, ptr }
  %l67 = alloca i1
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l81 = alloca i1
  %l84 = alloca i1
  %l85 = alloca i1
  %l88 = alloca i1
  %l89 = alloca i1
  %l96 = alloca i64
  %l97 = alloca i64
  %l105 = alloca ptr
  %l107 = alloca ptr
  %l110 = alloca i64
  %l114 = alloca i64
  %l117 = alloca i64
  %l138 = alloca ptr
  %l142 = alloca %"compiler/typed:Local"
  %l144 = alloca { i64, ptr }
  %l146 = alloca i1
  %l150 = alloca i64
  %l152 = alloca i64
  %l157 = alloca i32
  %l165 = alloca ptr
  %l169 = alloca %"compiler/typed:Local"
  %l171 = alloca i32
  %l174 = alloca i1
  %l175 = alloca ptr
  %l178 = alloca i32
  %l179 = alloca i32
  %l182 = alloca i32
  %l188 = alloca ptr
  %l189 = alloca ptr
  %l192 = alloca i32
  %l193 = alloca i32
  %l194 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l204 = alloca i64
  %l205 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/free:letGo", ptr %l1
  %t5 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %s0, ptr %t1, %"compiler/free:letGo" %t2)
  store { i64, ptr } %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 9
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t9, i64 %t10)
  store i64 %t13, ptr %l30
  br label %bb2
bb2:
  %t14 = load i64, ptr %l30, !tbaa !24
  %t15 = icmp slt i64 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t19, ptr %l34
  br label %bb5
bb4:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i1, ptr %l34, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l32, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l32, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l36, !tbaa !27
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/free:letGo", ptr %l1
  %t30 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %s0, ptr %t26, %"compiler/free:letGo" %t27)
  store { i64, ptr } %t30, ptr %l40
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t31, ptr %l36, !tbaa !27
  br label %bb10
bb10:
  %t32 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t32, ptr %l4, !tbaa !27
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:Free", ptr %t33, i32 0, i32 9
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t35, i64 %t36)
  store i64 %t39, ptr %l44
  br label %bb11
bb11:
  %t40 = load i64, ptr %l44, !tbaa !24
  %t41 = icmp slt i64 %t40, 0
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/free:Free", ptr %t43, i32 0, i32 35
  store ptr %t45, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb13:
  br label %bb36
bb14:
  %t47 = load i64, ptr %l6, !tbaa !24
  store i64 %t47, ptr %l48, !tbaa !24
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t50 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t48)
  store i64 %t50, ptr %l50
  br label %bb15
bb15:
  %t51 = load i64, ptr %l48, !tbaa !24
  %t52 = load i64, ptr %l50, !tbaa !24
  %t53 = icmp slt i64 %t51, %t52
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb16, label %bb17
bb16:
  br label %bb35
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t57, i64 %t58)
  store %"compiler/free:letGo" %t61, ptr %l55
  br label %bb19
bb19:
  %t62 = load %"compiler/free:letGo", ptr %l55
  store %"compiler/free:letGo" %t62, ptr %l7
  %t63 = getelementptr %"compiler/free:letGo", ptr %l7, i32 0, i32 0
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = load i64, ptr %l2, !tbaa !24
  %t68 = icmp eq i64 %t64, %t65
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = getelementptr %"compiler/free:letGo", ptr %l7, i32 0, i32 1
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t73 = load i64, ptr %t72, !tbaa !24
  %t76 = icmp eq i64 %t71, %t73
  store i1 %t76, ptr %l59, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb22
bb22:
  %t78 = load i1, ptr %l59, !tbaa !21
  br i1 %t78, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load %"compiler/free:letGo", ptr %l7
  %t83 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %s4, ptr %t79, %"compiler/free:letGo" %t80)
  store { i64, ptr } %t83, ptr %l65
  br label %bb25
bb24:
  br label %bb33
bb25:
  %t84 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t84, ptr %l8, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t85, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t87, ptr %l67
  br label %bb26
bb26:
  %t88 = load i1, ptr %l67, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb27, label %bb28
bb27:
  %t91 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t91, ptr %l69, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  %t94 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l71, !tbaa !24
  %t97 = load i64, ptr %l71, !tbaa !24
  %t98 = icmp eq i64 %t93, %t97
  br i1 %t98, label %bb29, label %bb30
bb28:
  br label %bb32
bb29:
  %t100 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = load i64, ptr %l71, !tbaa !24
  %t105 = mul i64 %t104, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t101, ptr %t103, i64 %t105, i1 false)
  br label %bb31
bb30:
  %t106 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l73, !tbaa !24
  %t108 = load i64, ptr %l73, !tbaa !24
  %t109 = mul i64 %t108, 1
  %t110 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l74, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l73, !tbaa !24
  %t118 = mul i64 %t117, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t114, ptr %t116, i64 %t118, i1 false)
  %t119 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t119, ptr %l4, !tbaa !27
  br label %bb31
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t120 = load i64, ptr %l6, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l6, !tbaa !24
  br label %bb14
bb35:
  br label %bb36
bb36:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  %t124 = load i64, ptr %l9, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t130 = icmp slt i64 %t124, %t127
  br i1 %t130, label %bb38, label %bb39
bb38:
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i8, ptr %t135, i64 %t132
  %t137 = load i8, ptr %t136, !tbaa !32
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t137)
  store i1 %t139, ptr %l84
  br label %bb40
bb39:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb48
bb40:
  %t140 = load i1, ptr %l84, !tbaa !21
  br i1 %t140, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb44
bb42:
  %t141 = load i64, ptr %l9, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i8, ptr %t144, i64 %t141
  %t146 = load i8, ptr %t145, !tbaa !32
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t146)
  store i1 %t148, ptr %l88
  br label %bb43
bb43:
  %t149 = load i1, ptr %l88, !tbaa !21
  store i1 %t149, ptr %l85, !tbaa !21
  br label %bb44
bb44:
  %t150 = load i1, ptr %l85, !tbaa !21
  br i1 %t150, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb47
bb46:
  %t151 = load i64, ptr %l9, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i8, ptr %t154, i64 %t151
  %t156 = load i8, ptr %t155, !tbaa !32
  %t158 = icmp eq i8 %t156, 95
  store i1 %t158, ptr %l89, !tbaa !21
  br label %bb47
bb47:
  %t160 = load i1, ptr %l89, !tbaa !21
  store i1 %t160, ptr %l81, !tbaa !21
  br label %bb48
bb48:
  %t161 = load i1, ptr %l81, !tbaa !21
  %t162 = xor i1 %t161, true
  br i1 %t162, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  br label %bb51
bb51:
  %t164 = load i64, ptr %l9, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l9, !tbaa !24
  br label %bb52
bb52:
  br label %bb37
bb53:
  %t168 = load i64, ptr %l9, !tbaa !24
  store i64 %t168, ptr %l96, !tbaa !24
  %t169 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 0
  store i64 %t170, ptr %l97, !tbaa !24
  %t171 = icmp sge i64 0, 0
  br i1 %t171, label %bb54, label %bb55
bb54:
  %t173 = load i64, ptr %l96, !tbaa !24
  %t174 = icmp sle i64 0, %t173
  br i1 %t174, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c)
  unreachable
bb56:
  %t176 = load i64, ptr %l96, !tbaa !24
  %t177 = load i64, ptr %l97, !tbaa !24
  %t178 = icmp sle i64 %t176, %t177
  br i1 %t178, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c)
  unreachable
bb58:
  %t180 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = load i64, ptr %l96, !tbaa !24
  %t183 = getelementptr i8, ptr %t181, i64 0
  %t184 = sub i64 %t182, 0
  %t185 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t183, 1
  store { i64, ptr } %t186, ptr %l10, !tbaa !27
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/free:Free", ptr %t188, i32 0, i32 1
  %t191 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t192 = load i64, ptr %t191, !tbaa !24
  %t195 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t190, i64 %t192)
  store ptr %t195, ptr %l105
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c)
  unreachable
bb60:
  %t196 = load ptr, ptr %l105, !tbaa !29
  store ptr %t196, ptr %l11, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t197)
  store ptr %t199, ptr %l107
  br label %bb61
bb61:
  %t200 = load ptr, ptr %l107, !tbaa !29
  store ptr %t200, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t201 = load ptr, ptr %l11, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Body", ptr %t201, i32 0, i32 7
  %t205 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t203)
  store i64 %t205, ptr %l110
  br label %bb62
bb62:
  %t206 = load i64, ptr %l110, !tbaa !24
  store i64 %t206, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t207 = load i64, ptr %l14, !tbaa !24
  %t208 = load i64, ptr %l13, !tbaa !24
  %t211 = icmp sgt i64 %t207, %t208
  br i1 %t211, label %bb63, label %bb64
bb63:
  %t213 = load i64, ptr %l15, !tbaa !24
  %t215 = icmp sgt i64 %t213, 0
  br i1 %t215, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb68
bb65:
  %t217 = load i64, ptr %l14, !tbaa !24
  %t218 = load i64, ptr %l13, !tbaa !24
  %t221 = sub i64 %t217, %t218
  %t222 = load i64, ptr %l15, !tbaa !24
  %t225 = add i64 %t221, %t222
  %t227 = sub i64 %t225, 1
  %t228 = load i64, ptr %l15, !tbaa !24
  %t231 = sdiv i64 %t227, %t228
  store i64 %t231, ptr %l117, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb67
bb67:
  %t233 = load i64, ptr %l117, !tbaa !24
  store i64 %t233, ptr %l114, !tbaa !24
  br label %bb68
bb68:
  %t234 = load i64, ptr %l114, !tbaa !24
  store i64 %t234, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s9
  %t235 = load i64, ptr %l17, !tbaa !24
  %t236 = load i64, ptr %l16, !tbaa !24
  %t239 = icmp slt i64 %t235, %t236
  %t241 = xor i1 %t239, true
  br i1 %t241, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s9)
  br label %bb110
bb71:
  br label %bb72
bb72:
  %t243 = load i64, ptr %l13, !tbaa !24
  %t244 = load i64, ptr %l17, !tbaa !24
  %t245 = load i64, ptr %l15, !tbaa !24
  %t248 = mul i64 %t244, %t245
  %t251 = add i64 %t243, %t248
  store i64 %t251, ptr %l18, !tbaa !24
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/free:Free", ptr %t253, i32 0, i32 0
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = getelementptr %"compiler/generic:Program", ptr %t256, i32 0, i32 0
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/load:Loader", ptr %t259, i32 0, i32 3
  %t262 = load ptr, ptr %t261, !tbaa !29
  store ptr %t262, ptr %l138, !tbaa !29
  %t263 = load ptr, ptr %l11, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Body", ptr %t263, i32 0, i32 7
  %t266 = load i64, ptr %l18, !tbaa !24
  %t269 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t265, i64 %t266)
  store %"compiler/typed:Local" %t269, ptr %l142
  br label %bb73
bb73:
  %t270 = getelementptr %"compiler/typed:Local", ptr %l142, i32 0, i32 0
  %t271 = load i32, ptr %t270, !tbaa !23
  %t272 = load ptr, ptr %l138, !tbaa !29
  %t274 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t272, i32 %t271)
  store { i64, ptr } %t274, ptr %l144
  br label %bb74
bb74:
  %t275 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t276 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t278 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t276, { i64, ptr } %t275)
  store i1 %t278, ptr %l146
  br label %bb75
bb75:
  %t279 = load i1, ptr %l146, !tbaa !21
  %t280 = xor i1 %t279, true
  br i1 %t280, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s9)
  br label %bb109
bb77:
  br label %bb78
bb78:
  store i1 false, ptr %l19, !tbaa !21
  %t282 = load ptr, ptr %l11, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Body", ptr %t282, i32 0, i32 5
  store ptr %t284, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb79
bb79:
  %t286 = load i64, ptr %l21, !tbaa !24
  store i64 %t286, ptr %l150, !tbaa !24
  %t287 = load ptr, ptr %l20, !tbaa !29
  %t289 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t287)
  store i64 %t289, ptr %l152
  br label %bb80
bb80:
  %t290 = load i64, ptr %l150, !tbaa !24
  %t291 = load i64, ptr %l152, !tbaa !24
  %t292 = icmp slt i64 %t290, %t291
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb81, label %bb82
bb81:
  br label %bb89
bb82:
  br label %bb83
bb83:
  %t296 = load ptr, ptr %l20, !tbaa !29
  %t297 = load i64, ptr %l21, !tbaa !24
  %t300 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t296, i64 %t297)
  store i32 %t300, ptr %l157
  br label %bb84
bb84:
  %t301 = load i32, ptr %l157, !tbaa !23
  %t304 = sext i32 %t301 to i64
  %t305 = load i64, ptr %l18, !tbaa !24
  %t308 = icmp eq i64 %t304, %t305
  br i1 %t308, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb87
bb86:
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t310 = load i64, ptr %l21, !tbaa !24
  %t312 = add i64 %t310, 1
  store i64 %t312, ptr %l21, !tbaa !24
  br label %bb79
bb89:
  %t314 = load i1, ptr %l19, !tbaa !21
  br i1 %t314, label %bb90, label %bb91
bb90:
  %t316 = load ptr, ptr %l12, !tbaa !29
  store ptr %t316, ptr %l165, !tbaa !29
  %t317 = load ptr, ptr %l11, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Body", ptr %t317, i32 0, i32 7
  %t320 = load i64, ptr %l18, !tbaa !24
  %t323 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t319, i64 %t320)
  store %"compiler/typed:Local" %t323, ptr %l169
  br label %bb92
bb91:
  br label %bb107
bb92:
  %t324 = getelementptr %"compiler/typed:Local", ptr %l169, i32 0, i32 2
  %t325 = load i32, ptr %t324, !tbaa !23
  %t326 = load ptr, ptr %l165, !tbaa !29
  %t328 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t326, i32 %t325)
  store i32 %t328, ptr %l171
  br label %bb93
bb93:
  %t329 = load i32, ptr %l171, !tbaa !23
  store i32 %t329, ptr %l23, !tbaa !23
  %t330 = load ptr, ptr %l12, !tbaa !29
  %t331 = load i32, ptr %l23, !tbaa !23
  %t334 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t330, i32 %t331)
  store i1 %t334, ptr %l174
  br label %bb94
bb94:
  %t335 = load i1, ptr %l174, !tbaa !21
  br i1 %t335, label %bb95, label %bb96
bb95:
  %t336 = load ptr, ptr %l12, !tbaa !29
  store ptr %t336, ptr %l175, !tbaa !29
  %t337 = load ptr, ptr %l12, !tbaa !29
  %t338 = load i32, ptr %l23, !tbaa !23
  %t341 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t337, i32 %t338)
  store i32 %t341, ptr %l178
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t342 = load ptr, ptr %l175, !tbaa !29
  %t343 = load i32, ptr %l178, !tbaa !23
  %t344 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t342, i32 %t343)
  store i32 %t344, ptr %l179
  br label %bb98
bb98:
  %t345 = load i32, ptr %l179, !tbaa !23
  store i32 %t345, ptr %l23, !tbaa !23
  br label %bb99
bb99:
  %t346 = load ptr, ptr %l12, !tbaa !29
  %t347 = load i32, ptr %l23, !tbaa !23
  %t350 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t346, i32 %t347)
  store i32 %t350, ptr %l182
  br label %bb100
bb100:
  %t351 = load i32, ptr %l182
  %t353 = trunc i64 18 to i32
  %t354 = icmp eq i32 %t351, %t353
  br i1 %t354, label %bb101, label %bb102
bb101:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/free:Free", ptr %t356, i32 0, i32 0
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t361 = getelementptr %"compiler/generic:Program", ptr %t359, i32 0, i32 0
  %t362 = load ptr, ptr %t361, !tbaa !29
  %t364 = getelementptr %"compiler/load:Loader", ptr %t362, i32 0, i32 3
  %t365 = load ptr, ptr %t364, !tbaa !29
  store ptr %t365, ptr %l188, !tbaa !29
  %t366 = load ptr, ptr %l12, !tbaa !29
  store ptr %t366, ptr %l189, !tbaa !29
  %t367 = load ptr, ptr %l12, !tbaa !29
  %t368 = load i32, ptr %l23, !tbaa !23
  %t371 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t367, i32 %t368)
  store i32 %t371, ptr %l192
  br label %bb103
bb102:
  br label %bb106
bb103:
  %t372 = load ptr, ptr %l189, !tbaa !29
  %t373 = load i32, ptr %l192, !tbaa !23
  %t374 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t372, i32 %t373)
  store i32 %t374, ptr %l193
  br label %bb104
bb104:
  %t375 = load ptr, ptr %l188, !tbaa !29
  %t376 = load i32, ptr %l193, !tbaa !23
  %t377 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t375, i32 %t376)
  store { i64, ptr } %t377, ptr %l194
  br label %bb105
bb105:
  %t378 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t379 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t380 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t380, 1
  %t382 = extractvalue { i64, ptr } %t380, 0
  %t383 = add i64 %t379, %t382
  %t384 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t385 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t386 = add i64 %t383, %t385
  %t387 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t386)
  call void @olang_textcopy(ptr %t387, ptr %t378, i64 %t379)
  %t388 = getelementptr i8, ptr %t387, i64 %t379
  call void @olang_textcopy(ptr %t388, ptr %t381, i64 %t382)
  %t389 = getelementptr i8, ptr %t388, i64 %t382
  call void @olang_textcopy(ptr %t389, ptr %t384, i64 %t385)
  %t390 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t387, 1
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t391, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t395 = load i64, ptr %t394, !tbaa !24
  %t398 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s9, ptr %t393, i64 %t395)
  store { i64, ptr } %t398, ptr %l198
  br label %bb108
bb108:
  %t399 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t400 = extractvalue { i64, ptr } %t399, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t403 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t404 = add i64 %t401, %t403
  %t405 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t404)
  call void @olang_textcopy(ptr %t405, ptr %t400, i64 %t401)
  %t406 = getelementptr i8, ptr %t405, i64 %t401
  call void @olang_textcopy(ptr %t406, ptr %t402, i64 %t403)
  %t407 = insertvalue { i64, ptr } undef, i64 %t404, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t405, 1
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t408, ptr %rv
  br label %ret
bb109:
  %t410 = load i64, ptr %l17, !tbaa !24
  %t412 = add i64 %t410, 1
  store i64 %t412, ptr %l17, !tbaa !24
  br label %bb69
bb110:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l202, !tbaa !27
  %t414 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t414, ptr %l203, !tbaa !27
  %t415 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t416 = extractvalue { i64, ptr } %t415, 0
  store i64 %t416, ptr %l204, !tbaa !24
  %t417 = load i64, ptr %l204, !tbaa !24
  %t418 = mul i64 %t417, 1
  %t419 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t418)
  %t420 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t421 = insertvalue { i64, ptr } %t420, ptr %t419, 1
  store { i64, ptr } %t421, ptr %l205, !tbaa !27
  %t422 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = load i64, ptr %l204, !tbaa !24
  %t427 = mul i64 %t426, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t423, ptr %t425, i64 %t427, i1 false)
  %t428 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t428, ptr %l203, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t429 = load { i64, ptr }, ptr %l203, !tbaa !27
  store { i64, ptr } %t429, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eshown(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i1
  %l23 = alloca i1
  %l27 = alloca { i64, ptr }
  %l40 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 18
  %t4 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t5)
  store i1 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i1, ptr %l10, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 5
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t18 = icmp ne i64 %t14, %t15
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 7
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:Free", ptr %t27, i32 0, i32 18
  %t30 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 7
  %t31 = load i64, ptr %t30, !tbaa !24
  %t34 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t29, i64 %t31)
  store i1 %t34, ptr %l23
  br label %bb11
bb11:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 7
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s0, ptr %t37, i64 %t39)
  store { i64, ptr } %t42, ptr %l27
  br label %bb15
bb15:
  %t43 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  store ptr @G_2ecompiler_2ffree_2eRemovalNames, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t45 = load ptr, ptr %l3
  store i64 9, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t56 = load ptr, ptr %l3
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = getelementptr [9 x { i64, ptr }], ptr %t56, i64 0, i64 %t57
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !37
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = load ptr, ptr @__olang_prog_scope
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t65, ptr %s0, { i64, ptr } %t61, { i64, ptr } %t64)
  store i1 %t68, ptr %l40
  br label %bb20
bb20:
  %t69 = load i1, ptr %l40, !tbaa !21
  br i1 %t69, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb16
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"compiler/typed:Plan"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca %"compiler/typed:Plan"
  %l14 = alloca { i64, [1 x i64] }
  %l15 = alloca ptr
  %l16 = alloca i1
  %l21 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca { i64, [1 x i64] }
  %l36 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l48 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca i1
  %l59 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca i1
  %l73 = alloca { i64, [1 x i64] }
  %l74 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca { i64, [1 x i64] }
  %l84 = alloca ptr
  %l85 = alloca i1
  %l93 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t5 = alloca %"compiler/typed:Plan", align 8
  %t73 = alloca { i64, [1 x i64] }, align 8
  %t168 = alloca { i64, [1 x i64] }, align 8
  %t204 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t5, ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t5, i64 152, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l13, i64 152, i1 false)
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t9 = load ptr, ptr %l15, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l15, !tbaa !29
  %t13 = load i64, ptr %t12
  %t15 = icmp eq i64 %t13, 5
  store i1 %t15, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l16, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t23 = getelementptr %"compiler/typed:Plan", ptr %l3, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l21, !tbaa !27
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Promote", ptr %t25, i32 0, i32 1
  %t28 = load i32, ptr %t27, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t32 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, [1 x i64] }, ptr %t33, i64 %t30
  %t35 = load { i64, [1 x i64] }, ptr %t34
  store { i64, [1 x i64] } %t35, ptr %l14
  br label %bb52
bb7:
  %t37 = load ptr, ptr %l2, !tbaa !29
  store ptr %t37, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 7
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Make", ptr %t52, i32 0, i32 4
  %t55 = load i32, ptr %t54, !tbaa !23
  %t57 = icmp sge i32 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = getelementptr %"compiler/typed:Plan", ptr %l3, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l36, !tbaa !27
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Make", ptr %t61, i32 0, i32 4
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t68 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, [1 x i64] }, ptr %t69, i64 %t66
  %t71 = load { i64, [1 x i64] }, ptr %t70
  store { i64, [1 x i64] } %t71, ptr %l35
  br label %bb15
bb14:
  store { i64, [1 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [1 x i64] }, ptr %t73, i32 0, i32 0
  store i64 0, ptr %t74
  %t75 = load { i64, [1 x i64] }, ptr %t73
  store { i64, [1 x i64] } %t75, ptr %l35
  br label %bb15
bb15:
  %t77 = load { i64, [1 x i64] }, ptr %l35
  store { i64, [1 x i64] } %t77, ptr %l14
  br label %bb52
bb16:
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t79 = load ptr, ptr %l42, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb17, label %bb18
bb17:
  %t82 = load ptr, ptr %l42, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 16
  store i1 %t85, ptr %l43, !tbaa !21
  br label %bb18
bb18:
  %t86 = load i1, ptr %l43, !tbaa !21
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l6, !tbaa !29
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t93 = getelementptr %"compiler/typed:Plan", ptr %l3, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l48, !tbaa !27
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Text", ptr %t95, i32 0, i32 1
  %t98 = load i32, ptr %t97, !tbaa !23
  %t100 = sext i32 %t98 to i64
  %t102 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr { i64, [1 x i64] }, ptr %t103, i64 %t100
  %t105 = load { i64, [1 x i64] }, ptr %t104
  store { i64, [1 x i64] } %t105, ptr %l14
  br label %bb52
bb22:
  %t107 = load ptr, ptr %l2, !tbaa !29
  store ptr %t107, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t108 = load ptr, ptr %l53, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb23, label %bb24
bb23:
  %t111 = load ptr, ptr %l53, !tbaa !29
  %t112 = load i64, ptr %t111
  %t114 = icmp eq i64 %t112, 8
  store i1 %t114, ptr %l54, !tbaa !21
  br label %bb24
bb24:
  %t115 = load i1, ptr %l54, !tbaa !21
  br i1 %t115, label %bb25, label %bb26
bb25:
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr { i64, [5 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t118, i32 0, i32 2
  %t120 = load ptr, ptr %t119
  store ptr %t120, ptr %l7, !tbaa !29
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t122 = getelementptr %"compiler/typed:Plan", ptr %l3, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l59, !tbaa !27
  %t124 = load ptr, ptr %l7, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Collect", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %t126, !tbaa !23
  %t129 = sext i32 %t127 to i64
  %t131 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, [1 x i64] }, ptr %t132, i64 %t129
  %t134 = load { i64, [1 x i64] }, ptr %t133
  store { i64, [1 x i64] } %t134, ptr %l14
  br label %bb52
bb28:
  %t136 = load ptr, ptr %l2, !tbaa !29
  store ptr %t136, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t137 = load ptr, ptr %l64, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb29, label %bb30
bb29:
  %t140 = load ptr, ptr %l64, !tbaa !29
  %t141 = load i64, ptr %t140
  %t143 = icmp eq i64 %t141, 6
  store i1 %t143, ptr %l65, !tbaa !21
  br label %bb30
bb30:
  %t144 = load i1, ptr %l65, !tbaa !21
  br i1 %t144, label %bb31, label %bb32
bb31:
  %t145 = load ptr, ptr %l2, !tbaa !29
  %t147 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t147, i32 0, i32 2
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l8, !tbaa !29
  br label %bb33
bb32:
  br label %bb40
bb33:
  %t151 = load ptr, ptr %l8, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Call", ptr %t151, i32 0, i32 3
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = icmp sge i32 %t154, 0
  br i1 %t156, label %bb34, label %bb35
bb34:
  store ptr %l3, ptr %l74, !tbaa !29
  %t158 = load ptr, ptr %l8, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Call", ptr %t158, i32 0, i32 3
  %t161 = load i32, ptr %t160, !tbaa !23
  store i32 %t161, ptr %l76, !tbaa !23
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l77, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l8, !tbaa !29
  %t167 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  store i64 %t167, ptr %l80
  br label %bb36
bb35:
  store { i64, [1 x i64] } zeroinitializer, ptr %t168
  %t169 = getelementptr { i64, [1 x i64] }, ptr %t168, i32 0, i32 0
  store i64 0, ptr %t169
  %t170 = load { i64, [1 x i64] }, ptr %t168
  store { i64, [1 x i64] } %t170, ptr %l73
  br label %bb39
bb36:
  %t172 = load ptr, ptr %l77, !tbaa !29
  %t173 = load i64, ptr %l80, !tbaa !24
  %t174 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %t172, i64 %t173)
  store i64 %t174, ptr %l81
  br label %bb37
bb37:
  %t175 = load ptr, ptr %l74, !tbaa !29
  %t176 = load i32, ptr %l76, !tbaa !23
  %t177 = load i64, ptr %l81, !tbaa !24
  %t178 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t175, i32 %t176, i64 %t177)
  store { i64, [1 x i64] } %t178, ptr %l82
  br label %bb38
bb38:
  %t179 = load { i64, [1 x i64] }, ptr %l82
  store { i64, [1 x i64] } %t179, ptr %l73
  br label %bb39
bb39:
  %t180 = load { i64, [1 x i64] }, ptr %l73
  store { i64, [1 x i64] } %t180, ptr %l14
  br label %bb52
bb40:
  %t181 = load ptr, ptr %l2, !tbaa !29
  store ptr %t181, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t182 = load ptr, ptr %l84, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb41, label %bb42
bb41:
  %t185 = load ptr, ptr %l84, !tbaa !29
  %t186 = load i64, ptr %t185
  %t188 = icmp eq i64 %t186, 17
  store i1 %t188, ptr %l85, !tbaa !21
  br label %bb42
bb42:
  %t189 = load i1, ptr %l85, !tbaa !21
  br i1 %t189, label %bb43, label %bb44
bb43:
  %t190 = load ptr, ptr %l2, !tbaa !29
  %t192 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t192, i32 0, i32 2
  %t194 = load ptr, ptr %t193
  store ptr %t194, ptr %l9, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i64, ptr %l1, !tbaa !24
  %t198 = load ptr, ptr %l9, !tbaa !29
  %t202 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t196, i64 %t197, ptr %t198)
  store { i64, [1 x i64] } %t202, ptr %l93
  br label %bb46
bb46:
  %t203 = load { i64, [1 x i64] }, ptr %l93
  store { i64, [1 x i64] } %t203, ptr %l14
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  store { i64, [1 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [1 x i64] }, ptr %t204, i32 0, i32 0
  store i64 0, ptr %t205
  %t206 = load { i64, [1 x i64] }, ptr %t204
  store { i64, [1 x i64] } %t206, ptr %l14
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_78dfe086e9f9163d_4fecfa12a5383061)
  unreachable
bb52:
  %t208 = load { i64, [1 x i64] }, ptr %l14
  store { i64, [1 x i64] } %t208, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esourceModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t7, -3
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb26
bb4:
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l3
  %t23 = load { i64, [2 x i64] }, ptr %l3
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l25
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t44, i64 %t45)
  store i64 %t46, ptr %l26
  br label %bb9
bb9:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb25
bb10:
  %t48 = load { i64, [2 x i64] }, ptr %l3
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t54 = getelementptr { i32, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t57)
  store ptr %t59, ptr %l31
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t60)
  store ptr %t62, ptr %l33
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t63)
  store ptr %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i32, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t67, i32 %t66)
  store i32 %t69, ptr %l37
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l38
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l31, !tbaa !29
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t75, ptr %l39
  br label %bb19
bb19:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b4c0d703fa684531_272a8f4f39064c15)
  unreachable
bb25:
  br label %bb26
bb26:
  %t77 = load i64, ptr %l2, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:Plan"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l25 = alloca %"compiler/typed:Plan"
  %l26 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i1
  %l68 = alloca { i64, [1 x i64] }
  %l70 = alloca { i64, [1 x i64] }
  %l72 = alloca i1
  %l73 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, [1 x i64] }
  %l82 = alloca { i64, [1 x i64] }
  %l84 = alloca i1
  %l86 = alloca i64
  %l94 = alloca { i64, ptr }
  %l98 = alloca i1
  %l100 = alloca i64
  %l105 = alloca i1
  %l106 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t15 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp sge i64 %t5, 63
  store i1 %t7, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 3
  %t14 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t15, ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t15, i64 152, i1 false)
  br label %bb7
bb7:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l25, i64 152, i1 false)
  %t18 = load i64, ptr %l5, !tbaa !24
  store i64 %t18, ptr %l26, !tbaa !24
  %t19 = load i64, ptr %l26, !tbaa !24
  %t20 = load i64, ptr %l26, !tbaa !24
  %t21 = shl i64 1, %t20
  store i64 %t21, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Call", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t30 = load i64, ptr %l9, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load i64, ptr %l10, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb13
bb10:
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l10, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l10, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l37, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l37, !tbaa !24
  store i64 %t56, ptr %l34, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb14
bb14:
  %t58 = load i64, ptr %l12, !tbaa !24
  %t59 = load i64, ptr %l11, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  br label %bb36
bb16:
  br label %bb17
bb17:
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l12, !tbaa !24
  %t68 = load i64, ptr %l10, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l13, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l13, !tbaa !24
  %t82 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t76, i64 %t77, i64 %t78)
  store i64 %t82, ptr %l58
  br label %bb18
bb18:
  %t83 = load i64, ptr %l58, !tbaa !24
  store i64 %t83, ptr %l14, !tbaa !24
  %t84 = load i64, ptr %l14, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb21
bb20:
  %t88 = load i64, ptr %l14, !tbaa !24
  %t90 = icmp sge i64 %t88, 63
  store i1 %t90, ptr %l61, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l61, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  br label %bb35
bb23:
  br label %bb24
bb24:
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Call", ptr %t93, i32 0, i32 3
  %t96 = load i32, ptr %t95, !tbaa !23
  %t97 = load i64, ptr %l14, !tbaa !24
  %t101 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %l6, i32 %t96, i64 %t97)
  store { i64, [1 x i64] } %t101, ptr %l68
  br label %bb25
bb25:
  %t102 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t102, ptr %l70
  %t105 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l68, ptr %l70)
  store i1 %t105, ptr %l72
  br label %bb26
bb26:
  %t106 = load i1, ptr %l72, !tbaa !21
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i64, ptr %l1, !tbaa !24
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Call", ptr %t109, i32 0, i32 1
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  store { i64, ptr } %t112, ptr %l77, !tbaa !27
  %t113 = load i64, ptr %l13, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr ptr, ptr %t116, i64 %t113
  %t118 = load ptr, ptr %t117, !tbaa !39
  %t122 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t107, i64 %t108, ptr %t118)
  store { i64, [1 x i64] } %t122, ptr %l80
  br label %bb29
bb28:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb31
bb29:
  %t123 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t123, ptr %l82
  %t126 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l80, ptr %l82)
  store i1 %t126, ptr %l84
  br label %bb30
bb30:
  %t127 = load i1, ptr %l84, !tbaa !21
  store i1 %t127, ptr %l73, !tbaa !21
  br label %bb31
bb31:
  %t128 = load i1, ptr %l73, !tbaa !21
  br i1 %t128, label %bb32, label %bb33
bb32:
  %t129 = load i64, ptr %l7, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  store i64 %t130, ptr %l86, !tbaa !24
  %t131 = load i64, ptr %l86, !tbaa !24
  %t132 = load i64, ptr %l86, !tbaa !24
  %t133 = shl i64 1, %t132
  %t136 = or i64 %t129, %t133
  store i64 %t136, ptr %l7, !tbaa !24
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t138 = load i64, ptr %l12, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l12, !tbaa !24
  br label %bb14
bb36:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/free:Free", ptr %t142, i32 0, i32 2
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t146 = load i64, ptr %l3, !tbaa !24
  %t149 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %s0, ptr %t145, i64 %t146)
  store { i64, ptr } %t149, ptr %l94
  br label %bb37
bb37:
  %t150 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t150, ptr %l15, !tbaa !27
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t153 = load i64, ptr %l7, !tbaa !24
  %t157 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %s0, ptr %t151, { i64, ptr } %t152, i64 %t153)
  store i1 %t157, ptr %l98
  br label %bb38
bb38:
  %t158 = load i1, ptr %l98, !tbaa !21
  br i1 %t158, label %bb39, label %bb40
bb39:
  %t159 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t159, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t161 = load i64, ptr %l5, !tbaa !24
  store i64 %t161, ptr %l100, !tbaa !24
  %t162 = load i64, ptr %l100, !tbaa !24
  %t163 = load i64, ptr %l100, !tbaa !24
  %t164 = shl i64 1, %t163
  store i64 %t164, ptr %l7, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t168 = load i64, ptr %l7, !tbaa !24
  %t172 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %s0, ptr %t166, { i64, ptr } %t167, i64 %t168)
  store i1 %t172, ptr %l105
  br label %bb42
bb42:
  %t173 = load i1, ptr %l105, !tbaa !21
  br i1 %t173, label %bb43, label %bb44
bb43:
  %t174 = load i64, ptr %l7, !tbaa !24
  store i64 %t174, ptr %l106, !tbaa !24
  br label %bb45
bb44:
  store i64 -1, ptr %l106, !tbaa !24
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t176 = load i64, ptr %l106, !tbaa !24
  store i64 %t176, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewalk(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca i1
  %l26 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l35 = alloca i32
  %l38 = alloca i1
  %l39 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l61 = alloca ptr
  %l64 = alloca ptr
  %l67 = alloca ptr
  %l83 = alloca ptr
  %l93 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t16)
  store ptr %t18, ptr %l15
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l15, !tbaa !29
  store ptr %t19, ptr %l4, !tbaa !29
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %t23, !tbaa !23
  %t27 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t20, i32 %t24)
  store i64 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t29 = load i64, ptr %l19, !tbaa !24
  %t31 = icmp eq i64 %t29, %t28
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Body", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %t36, !tbaa !23
  %t40 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t33, i32 %t37)
  store { i64, ptr } %t40, ptr %l26
  br label %bb9
bb8:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb10
bb9:
  %t41 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t44 = icmp eq i64 %t42, 1
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l22, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load ptr, ptr %l4, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Body", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t48, i32 %t52)
  store { i64, ptr } %t55, ptr %l33
  br label %bb13
bb12:
  br label %bb34
bb13:
  %t56 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i32, ptr %t57, i64 0
  %t59 = load i32, ptr %t58, !tbaa !33
  %t60 = load ptr, ptr %l29, !tbaa !29
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t60, i32 %t59)
  store i32 %t62, ptr %l35
  br label %bb14
bb14:
  %t63 = load i32, ptr %l35, !tbaa !23
  store i32 %t63, ptr %l5, !tbaa !23
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t65 = load i32, ptr %l5, !tbaa !23
  %t68 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t68, ptr %l38
  br label %bb15
bb15:
  %t69 = load i1, ptr %l38, !tbaa !21
  br i1 %t69, label %bb16, label %bb17
bb16:
  %t70 = load ptr, ptr %l4, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t72 = load i32, ptr %l5, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l42
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t77 = load i32, ptr %l42, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t78, ptr %l43
  br label %bb19
bb19:
  %t79 = load i32, ptr %l43, !tbaa !23
  store i32 %t79, ptr %l5, !tbaa !23
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t81 = load i32, ptr %l5, !tbaa !23
  %t84 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t80, i32 %t81)
  store i32 %t84, ptr %l46
  br label %bb21
bb21:
  %t85 = load i32, ptr %l46
  %t87 = trunc i64 18 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t91 = load i32, ptr %l5, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l52
  br label %bb24
bb23:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb25
bb24:
  %t95 = load i1, ptr %l52, !tbaa !21
  store i1 %t95, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t96 = load i1, ptr %l49, !tbaa !21
  br i1 %t96, label %bb26, label %bb27
bb26:
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t98 = load i32, ptr %l5, !tbaa !23
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l56
  br label %bb28
bb27:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb29
bb28:
  %t102 = load i1, ptr %l56, !tbaa !21
  store i1 %t102, ptr %l53, !tbaa !21
  br label %bb29
bb29:
  %t103 = load i1, ptr %l53, !tbaa !21
  br i1 %t103, label %bb30, label %bb31
bb30:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t104, i64 %t105)
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l1, !tbaa !24
  %t112 = call ptr @compiler_2ffree_2enewWalker(ptr %v0, ptr %t108, i64 %t109, i1 false)
  store ptr %t112, ptr %l61
  br label %bb35
bb35:
  %t113 = load ptr, ptr %l61, !tbaa !29
  store ptr %t113, ptr %l6, !tbaa !29
  br label %bb36
bb36:
  %t114 = load ptr, ptr %l6, !tbaa !29
  %t116 = getelementptr %"compiler/free:walker", ptr %t114, i32 0, i32 5
  store i1 false, ptr %t116, !tbaa !21
  %t117 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %t117)
  br label %bb37
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l64, !tbaa !29
  %t120 = load ptr, ptr %l64, !tbaa !29
  %t121 = getelementptr %"compiler/free:Free", ptr %t120, i32 0, i32 4
  %t122 = load i64, ptr %t121, !tbaa !24
  %t124 = add i64 %t122, 1
  %t126 = load ptr, ptr %l64, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t126, i32 0, i32 4
  store i64 %t124, ptr %t127, !tbaa !24
  %t128 = load ptr, ptr %l6, !tbaa !29
  store ptr %t128, ptr %l67, !tbaa !29
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Body", ptr %t129, i32 0, i32 11
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_30cfd3b464a887aa_ca3830b5343a05a6)
  unreachable
bb39:
  br label %bb40
bb40:
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Body", ptr %t136, i32 0, i32 11
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t140 = load ptr, ptr %l67, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v0, ptr %t140, ptr %t139)
  br label %bb41
bb41:
  %t142 = load ptr, ptr %l6, !tbaa !29
  %t144 = getelementptr %"compiler/free:walker", ptr %t142, i32 0, i32 5
  %t145 = load i1, ptr %t144, !tbaa !21
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb36
bb46:
  %t149 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamPaths(ptr %v0, ptr %t149)
  br label %bb47
bb47:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l6, !tbaa !29
  %t153 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esave(ptr %v0, ptr %v0, ptr %t151, ptr %t152, i64 %t153)
  br label %bb48
bb48:
  br i1 %a2, label %bb49, label %bb50
bb49:
  %t159 = load ptr, ptr %l6, !tbaa !29
  %t161 = getelementptr %"compiler/free:walker", ptr %t159, i32 0, i32 2
  store i1 true, ptr %t161, !tbaa !21
  %t162 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %t162)
  br label %bb51
bb50:
  br label %bb62
bb51:
  %t164 = load ptr, ptr %l6, !tbaa !29
  store ptr %t164, ptr %l83, !tbaa !29
  %t165 = load ptr, ptr %l3, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Body", ptr %t165, i32 0, i32 11
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = icmp eq ptr %t168, null
  br i1 %t170, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_3a3557a9366273b1_8eafb121351cf8d)
  unreachable
bb53:
  br label %bb54
bb54:
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Body", ptr %t172, i32 0, i32 11
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t176 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v0, ptr %t176, ptr %t175)
  br label %bb55
bb55:
  %t178 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviews(ptr %v0, ptr %t178)
  br label %bb56
bb56:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/free:Free", ptr %t180, i32 0, i32 61
  %t183 = load i64, ptr %l1, !tbaa !24
  %t186 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t182, i64 %t183)
  store i1 %t186, ptr %l93
  br label %bb57
bb57:
  %t187 = load i1, ptr %l93, !tbaa !21
  br i1 %t187, label %bb58, label %bb59
bb58:
  %t188 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroys(ptr %v0, ptr %t188)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i1
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i1
  %l67 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l18
  br label %bb6
bb6:
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = load i64, ptr %l18, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = load i32, ptr %l3, !tbaa !23
  %t29 = sext i32 %t27 to i64
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t26, i64 %t29)
  store i64 %t32, ptr %l24
  br label %bb9
bb8:
  %t33 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t33, ptr %l20, !tbaa !24
  br label %bb10
bb9:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  br label %bb10
bb10:
  %t36 = load i64, ptr %l20, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  br label %bb44
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  store ptr %t37, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 3
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t58 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t52, ptr %t53, ptr %t54)
  store i64 %t58, ptr %l35
  br label %bb17
bb17:
  %t59 = load i64, ptr %l35, !tbaa !24
  store i64 %t59, ptr %l8, !tbaa !24
  br label %bb44
bb18:
  %t60 = load ptr, ptr %l2, !tbaa !29
  store ptr %t60, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = load i64, ptr %t64
  %t67 = icmp eq i64 %t65, 4
  store i1 %t67, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Elem", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t84 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t75, ptr %t76, ptr %t80)
  store i64 %t84, ptr %l46
  br label %bb24
bb24:
  %t85 = load i64, ptr %l46, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb44
bb25:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t87 = load ptr, ptr %l47, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l47, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 5
  store i1 %t93, ptr %l48, !tbaa !21
  br label %bb27
bb27:
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Payload", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t110 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, ptr %t106)
  store i64 %t110, ptr %l57
  br label %bb31
bb31:
  %t111 = load i64, ptr %l57, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb44
bb32:
  %t112 = load ptr, ptr %l2, !tbaa !29
  store ptr %t112, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t113 = load ptr, ptr %l58, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb33, label %bb34
bb33:
  %t116 = load ptr, ptr %l58, !tbaa !29
  %t117 = load i64, ptr %t116
  %t119 = icmp eq i64 %t117, 2
  store i1 %t119, ptr %l59, !tbaa !21
  br label %bb34
bb34:
  %t120 = load i1, ptr %l59, !tbaa !21
  br i1 %t120, label %bb35, label %bb36
bb35:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t123, i32 0, i32 2
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load ptr, ptr %l7, !tbaa !29
  %t133 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t127, ptr %t128, ptr %t129)
  store i64 %t133, ptr %l67
  br label %bb38
bb38:
  %t134 = load i64, ptr %l67, !tbaa !24
  store i64 %t134, ptr %l8, !tbaa !24
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t135 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t135, ptr %l8, !tbaa !24
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_6cb79447255537d7_e828faabaec907d3)
  unreachable
bb44:
  %t137 = load i64, ptr %l8, !tbaa !24
  store i64 %t137, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewritePlans(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/free:store"
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/typed:Plan"
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/free:store"
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/free:orStore"
  %l16 = alloca i64
  %l17 = alloca %"compiler/typed:Plan"
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca %"compiler/free:orCall"
  %l22 = alloca %"compiler/typed:Plan"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca { i64, [1 x i64] }
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l46 = alloca i64
  %l48 = alloca i64
  %l53 = alloca %"compiler/free:store"
  %l61 = alloca i1
  %l62 = alloca i1
  %l66 = alloca i1
  %l67 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i1
  %l76 = alloca i1
  %l78 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i1
  %l86 = alloca i1
  %l93 = alloca i64
  %l99 = alloca %"compiler/typed:Plan"
  %l100 = alloca { i64, ptr }
  %l107 = alloca { i64, [1 x i64] }
  %l108 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l122 = alloca i64
  %l124 = alloca i64
  %l129 = alloca %"compiler/free:store"
  %l133 = alloca i1
  %l136 = alloca i1
  %l138 = alloca i1
  %l142 = alloca i1
  %l144 = alloca ptr
  %l148 = alloca i64
  %l151 = alloca i1
  %l155 = alloca %"compiler/typed:Plan"
  %l156 = alloca { i64, ptr }
  %l172 = alloca i64
  %l174 = alloca i64
  %l179 = alloca %"compiler/free:orStore"
  %l183 = alloca i1
  %l187 = alloca i64
  %l193 = alloca %"compiler/typed:Plan"
  %l197 = alloca { i64, [1 x i64] }
  %l199 = alloca i1
  %l201 = alloca i1
  %l202 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l218 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l240 = alloca i64
  %l242 = alloca i64
  %l247 = alloca %"compiler/free:orCall"
  %l251 = alloca i1
  %l256 = alloca %"compiler/typed:Plan"
  %l257 = alloca { i64, ptr }
  %l262 = alloca ptr
  %l266 = alloca i64
  %l275 = alloca { i64, [1 x i64] }
  %l277 = alloca i1
  %l282 = alloca ptr
  %l291 = alloca i64
  %l294 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l299 = alloca { i64, ptr }
  %l306 = alloca i64
  %l309 = alloca i64
  %l328 = alloca i64
  %l345 = alloca i64
  %l348 = alloca i64
  %l369 = alloca i64
  %l372 = alloca i1
  %l375 = alloca i1
  %l377 = alloca i64
  %l381 = alloca i1
  %l386 = alloca { i64, ptr }
  %l391 = alloca i64
  %l394 = alloca i1
  %l395 = alloca { i64, ptr }
  %l399 = alloca { i64, ptr }
  %s11 = alloca %olang.scope
  %t110 = alloca %"compiler/typed:Plan", align 8
  %t234 = alloca %"compiler/typed:Plan", align 8
  %t320 = alloca %"compiler/typed:Plan", align 8
  %t474 = alloca %"compiler/typed:Plan", align 8
  %t651 = alloca { i64, [1 x i64] }, align 8
  %t793 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 34
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l46, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l48
  br label %bb2
bb2:
  %t9 = load i64, ptr %l46, !tbaa !24
  %t10 = load i64, ptr %l48, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb48
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/free:store" %t19, ptr %l53
  br label %bb6
bb6:
  %t20 = load %"compiler/free:store", ptr %l53
  store %"compiler/free:store" %t20, ptr %l3
  %t21 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 4
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t26 = icmp ne i64 %t22, %t23
  br i1 %t26, label %bb7, label %bb8
bb7:
  br label %bb47
bb8:
  br label %bb9
bb9:
  %t28 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  store i64 %t29, ptr %l4, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 41
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t33, i64 %t34)
  store i1 %t37, ptr %l61
  br label %bb10
bb10:
  %t38 = load i1, ptr %l61, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb18
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:Free", ptr %t39, i32 0, i32 62
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t41, i64 %t42)
  store i1 %t45, ptr %l66
  br label %bb13
bb13:
  %t46 = load i1, ptr %l66, !tbaa !21
  br i1 %t46, label %bb14, label %bb15
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/free:Free", ptr %t47, i32 0, i32 64
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t49, i64 %t50)
  store i1 %t53, ptr %l71
  br label %bb16
bb15:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb17
bb16:
  %t54 = load i1, ptr %l71, !tbaa !21
  store i1 %t54, ptr %l67, !tbaa !21
  br label %bb17
bb17:
  %t55 = load i1, ptr %l67, !tbaa !21
  store i1 %t55, ptr %l62, !tbaa !21
  br label %bb18
bb18:
  %t56 = load i1, ptr %l62, !tbaa !21
  br i1 %t56, label %bb19, label %bb20
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:Free", ptr %t57, i32 0, i32 17
  %t60 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 1
  %t61 = load i64, ptr %t60, !tbaa !24
  %t64 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t59, i64 %t61)
  store i1 %t64, ptr %l76
  br label %bb21
bb20:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb22
bb21:
  %t65 = load i1, ptr %l76, !tbaa !21
  store i1 %t65, ptr %l72, !tbaa !21
  br label %bb22
bb22:
  %t66 = load i1, ptr %l72, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l4, !tbaa !24
  %t73 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t69, i64 %t70)
  store i1 %t73, ptr %l81
  br label %bb25
bb24:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb30
bb25:
  %t74 = load i1, ptr %l81, !tbaa !21
  br i1 %t74, label %bb26, label %bb27
bb26:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/free:Free", ptr %t75, i32 0, i32 60
  %t78 = load i64, ptr %l4, !tbaa !24
  %t81 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t77, i64 %t78)
  store i1 %t81, ptr %l86
  br label %bb28
bb27:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb29
bb28:
  %t82 = load i1, ptr %l86, !tbaa !21
  store i1 %t82, ptr %l82, !tbaa !21
  br label %bb29
bb29:
  %t83 = load i1, ptr %l82, !tbaa !21
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l78, !tbaa !21
  br label %bb30
bb30:
  %t86 = load i1, ptr %l78, !tbaa !21
  br i1 %t86, label %bb31, label %bb32
bb31:
  br label %bb47
bb32:
  br label %bb33
bb33:
  %t87 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 7
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = icmp eq ptr %t88, null
  br i1 %t90, label %bb34, label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_b0d58e2b07420cd2_669637d27520b416)
  unreachable
bb35:
  br label %bb36
bb36:
  %t92 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 7
  %t93 = load ptr, ptr %t92, !tbaa !29
  store ptr %t93, ptr %l5, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l5, !tbaa !29
  %t99 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t95, ptr %t96)
  store i64 %t99, ptr %l93
  br label %bb37
bb37:
  %t100 = load i64, ptr %l93, !tbaa !24
  store i64 %t100, ptr %l6, !tbaa !24
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = icmp slt i64 %t101, 0
  br i1 %t103, label %bb38, label %bb39
bb38:
  br label %bb47
bb39:
  br label %bb40
bb40:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:Free", ptr %t105, i32 0, i32 3
  %t108 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t110, ptr %v0, ptr %v0, ptr %t107, i64 %t109)
  call void @llvm.memmove.p0.p0.i64(ptr %l99, ptr %t110, i64 152, i1 false)
  br label %bb41
bb41:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l99, i64 152, i1 false)
  %t113 = getelementptr %"compiler/typed:Plan", ptr %l7, i32 0, i32 4
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l100, !tbaa !27
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr i64, ptr %t118, i64 %t115
  %t120 = load i64, ptr %t119, !tbaa !34
  %t122 = icmp ne i64 %t120, 0
  br i1 %t122, label %bb42, label %bb43
bb42:
  br label %bb47
bb43:
  br label %bb44
bb44:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 1
  %t126 = load i64, ptr %t125, !tbaa !24
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t131 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v0, ptr %t124, i64 %t126, ptr %t127)
  store { i64, [1 x i64] } %t131, ptr %l107
  br label %bb45
bb45:
  %t132 = load { i64, [1 x i64] }, ptr %l107
  store { i64, [1 x i64] } %t132, ptr %l8
  %t133 = getelementptr %"compiler/typed:Plan", ptr %l7, i32 0, i32 4
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l108, !tbaa !27
  %t135 = load i64, ptr %l6, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i64, ptr %t138, i64 %t135
  store i64 1, ptr %t139, !tbaa !34
  %t140 = getelementptr %"compiler/typed:Plan", ptr %l7, i32 0, i32 5
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l110, !tbaa !27
  %t142 = load i64, ptr %l6, !tbaa !24
  %t143 = load { i64, [1 x i64] }, ptr %l8
  %t146 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr { i64, [1 x i64] }, ptr %t147, i64 %t142
  store { i64, [1 x i64] } %t143, ptr %t148
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 1
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = load ptr, ptr %l5, !tbaa !29
  %t153 = load i64, ptr %l6, !tbaa !24
  %t154 = load { i64, [1 x i64] }, ptr %l8
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t149, i64 %t151, ptr %t152, i64 %t153, { i64, [1 x i64] } %t154, i1 true, i1 false)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t160 = load i64, ptr %l2, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l2, !tbaa !24
  br label %bb1
bb48:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/free:Free", ptr %t164, i32 0, i32 34
  store ptr %t166, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb49
bb49:
  %t168 = load i64, ptr %l10, !tbaa !24
  store i64 %t168, ptr %l122, !tbaa !24
  %t169 = load ptr, ptr %l9, !tbaa !29
  %t171 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t169)
  store i64 %t171, ptr %l124
  br label %bb50
bb50:
  %t172 = load i64, ptr %l122, !tbaa !24
  %t173 = load i64, ptr %l124, !tbaa !24
  %t174 = icmp slt i64 %t172, %t173
  %t176 = xor i1 %t174, true
  br i1 %t176, label %bb51, label %bb52
bb51:
  br label %bb80
bb52:
  br label %bb53
bb53:
  %t178 = load ptr, ptr %l9, !tbaa !29
  %t179 = load i64, ptr %l10, !tbaa !24
  %t182 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t178, i64 %t179)
  store %"compiler/free:store" %t182, ptr %l129
  br label %bb54
bb54:
  %t183 = load %"compiler/free:store", ptr %l129
  store %"compiler/free:store" %t183, ptr %l11
  %t184 = getelementptr %"compiler/free:store", ptr %l11, i32 0, i32 4
  %t185 = load i64, ptr %t184, !tbaa !24
  %t186 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t189 = icmp ne i64 %t185, %t186
  br i1 %t189, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l133, !tbaa !21
  br label %bb58
bb56:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/free:store", ptr %l11, i32 0, i32 0
  %t193 = load i64, ptr %t192, !tbaa !24
  %t196 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t191, i64 %t193)
  store i1 %t196, ptr %l136
  br label %bb57
bb57:
  %t197 = load i1, ptr %l136, !tbaa !21
  %t198 = xor i1 %t197, true
  store i1 %t198, ptr %l133, !tbaa !21
  br label %bb58
bb58:
  %t200 = load i1, ptr %l133, !tbaa !21
  br i1 %t200, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb62
bb60:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/free:Free", ptr %t201, i32 0, i32 60
  %t204 = getelementptr %"compiler/free:store", ptr %l11, i32 0, i32 0
  %t205 = load i64, ptr %t204, !tbaa !24
  %t208 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t203, i64 %t205)
  store i1 %t208, ptr %l142
  br label %bb61
bb61:
  %t209 = load i1, ptr %l142, !tbaa !21
  %t210 = xor i1 %t209, true
  store i1 %t210, ptr %l138, !tbaa !21
  br label %bb62
bb62:
  %t212 = load i1, ptr %l138, !tbaa !21
  br i1 %t212, label %bb63, label %bb64
bb63:
  br label %bb79
bb64:
  br label %bb65
bb65:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l144, !tbaa !29
  %t214 = getelementptr %"compiler/free:store", ptr %l11, i32 0, i32 7
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = icmp eq ptr %t215, null
  br i1 %t217, label %bb66, label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_68d66244454596f9_ea33ff3f8eb363fd)
  unreachable
bb67:
  br label %bb68
bb68:
  %t219 = getelementptr %"compiler/free:store", ptr %l11, i32 0, i32 7
  %t220 = load ptr, ptr %t219, !tbaa !29
  %t221 = load ptr, ptr %l144, !tbaa !29
  %t223 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t221, ptr %t220)
  store i64 %t223, ptr %l148
  br label %bb69
bb69:
  %t224 = load i64, ptr %l148, !tbaa !24
  store i64 %t224, ptr %l12, !tbaa !24
  %t225 = load i64, ptr %l12, !tbaa !24
  %t227 = icmp slt i64 %t225, 0
  br i1 %t227, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l151, !tbaa !21
  br label %bb73
bb71:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/free:Free", ptr %t229, i32 0, i32 3
  %t232 = getelementptr %"compiler/free:store", ptr %l11, i32 0, i32 1
  %t233 = load i64, ptr %t232, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t234, ptr %v0, ptr %v0, ptr %t231, i64 %t233)
  call void @llvm.memmove.p0.p0.i64(ptr %l155, ptr %t234, i64 152, i1 false)
  br label %bb72
bb72:
  %t237 = getelementptr %"compiler/typed:Plan", ptr %l155, i32 0, i32 4
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  store { i64, ptr } %t238, ptr %l156, !tbaa !27
  %t239 = load i64, ptr %l12, !tbaa !24
  %t241 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr i64, ptr %t242, i64 %t239
  %t244 = load i64, ptr %t243, !tbaa !34
  %t246 = icmp ne i64 %t244, 1
  store i1 %t246, ptr %l151, !tbaa !21
  br label %bb73
bb73:
  %t248 = load i1, ptr %l151, !tbaa !21
  br i1 %t248, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s11
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/free:Free", ptr %t249, i32 0, i32 60
  %t252 = getelementptr %"compiler/free:store", ptr %l11, i32 0, i32 0
  %t253 = load i64, ptr %t252, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t251, i64 %t253, i1 false)
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/free:store", ptr %l11, i32 0, i32 0
  %t258 = load i64, ptr %t257, !tbaa !24
  %t259 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t260 = getelementptr %"compiler/free:store", ptr %l11, i32 0, i32 2
  %t261 = load i64, ptr %t260, !tbaa !24
  %t262 = getelementptr %"compiler/free:store", ptr %l11, i32 0, i32 3
  %t263 = load %"compiler/source:Span", ptr %t262
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s11, ptr %t256, i64 %t258, i64 %t259, i64 %t261, %"compiler/source:Span" %t263, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d25, i32 0, i32 1) })
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s11)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t269 = load i64, ptr %l10, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l10, !tbaa !24
  br label %bb49
bb80:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/free:Free", ptr %t273, i32 0, i32 40
  store ptr %t275, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb81
bb81:
  %t277 = load i64, ptr %l14, !tbaa !24
  store i64 %t277, ptr %l172, !tbaa !24
  %t278 = load ptr, ptr %l13, !tbaa !29
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %t278)
  store i64 %t280, ptr %l174
  br label %bb82
bb82:
  %t281 = load i64, ptr %l172, !tbaa !24
  %t282 = load i64, ptr %l174, !tbaa !24
  %t283 = icmp slt i64 %t281, %t282
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb83, label %bb84
bb83:
  br label %bb115
bb84:
  br label %bb85
bb85:
  %t287 = load ptr, ptr %l13, !tbaa !29
  %t288 = load i64, ptr %l14, !tbaa !24
  %t291 = call %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v0, ptr %t287, i64 %t288)
  store %"compiler/free:orStore" %t291, ptr %l179
  br label %bb86
bb86:
  %t292 = load %"compiler/free:orStore", ptr %l179
  store %"compiler/free:orStore" %t292, ptr %l15
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/free:Free", ptr %t293, i32 0, i32 41
  %t296 = getelementptr %"compiler/free:orStore", ptr %l15, i32 0, i32 1
  %t297 = load i64, ptr %t296, !tbaa !24
  %t300 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t295, i64 %t297)
  store i1 %t300, ptr %l183
  br label %bb87
bb87:
  %t301 = load i1, ptr %l183, !tbaa !21
  %t302 = xor i1 %t301, true
  br i1 %t302, label %bb88, label %bb89
bb88:
  br label %bb114
bb89:
  br label %bb90
bb90:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/free:orStore", ptr %l15, i32 0, i32 2
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t309 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t304, ptr %t306)
  store i64 %t309, ptr %l187
  br label %bb91
bb91:
  %t310 = load i64, ptr %l187, !tbaa !24
  store i64 %t310, ptr %l16, !tbaa !24
  %t311 = load i64, ptr %l16, !tbaa !24
  %t313 = icmp slt i64 %t311, 0
  br i1 %t313, label %bb92, label %bb93
bb92:
  br label %bb114
bb93:
  br label %bb94
bb94:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/free:Free", ptr %t315, i32 0, i32 3
  %t318 = getelementptr %"compiler/free:orStore", ptr %l15, i32 0, i32 0
  %t319 = load i64, ptr %t318, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t320, ptr %v0, ptr %v0, ptr %t317, i64 %t319)
  call void @llvm.memmove.p0.p0.i64(ptr %l193, ptr %t320, i64 152, i1 false)
  br label %bb95
bb95:
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %l193, i64 152, i1 false)
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/free:orStore", ptr %l15, i32 0, i32 0
  %t325 = load i64, ptr %t324, !tbaa !24
  %t326 = getelementptr %"compiler/free:orStore", ptr %l15, i32 0, i32 2
  %t327 = load ptr, ptr %t326, !tbaa !29
  %t331 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v0, ptr %t323, i64 %t325, ptr %t327)
  store { i64, [1 x i64] } %t331, ptr %l197
  br label %bb96
bb96:
  %t332 = load { i64, [1 x i64] }, ptr %l197
  store { i64, [1 x i64] } %t332, ptr %l18
  %t333 = load { i64, [1 x i64] }, ptr %l18
  %t335 = call i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %t333)
  store i1 %t335, ptr %l199
  br label %bb97
bb97:
  %t336 = load i1, ptr %l199, !tbaa !21
  %t337 = xor i1 %t336, true
  br i1 %t337, label %bb98, label %bb99
bb98:
  %t339 = getelementptr %"compiler/typed:Plan", ptr %l17, i32 0, i32 4
  %t340 = load { i64, ptr }, ptr %t339, !tbaa !27
  store { i64, ptr } %t340, ptr %l202, !tbaa !27
  %t341 = load i64, ptr %l16, !tbaa !24
  %t343 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr i64, ptr %t344, i64 %t341
  %t346 = load i64, ptr %t345, !tbaa !34
  %t348 = icmp eq i64 %t346, 0
  store i1 %t348, ptr %l201, !tbaa !21
  br label %bb100
bb99:
  store i1 false, ptr %l201, !tbaa !21
  br label %bb100
bb100:
  %t350 = load i1, ptr %l201, !tbaa !21
  br i1 %t350, label %bb101, label %bb102
bb101:
  br label %bb114
bb102:
  br label %bb103
bb103:
  %t351 = getelementptr %"compiler/typed:Plan", ptr %l17, i32 0, i32 4
  %t352 = load { i64, ptr }, ptr %t351, !tbaa !27
  store { i64, ptr } %t352, ptr %l206, !tbaa !27
  %t353 = load i64, ptr %l16, !tbaa !24
  %t355 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !27
  %t357 = getelementptr i64, ptr %t356, i64 %t353
  %t358 = load i64, ptr %t357, !tbaa !34
  %t360 = icmp eq i64 %t358, 1
  br i1 %t360, label %bb104, label %bb105
bb104:
  %t362 = getelementptr %"compiler/typed:Plan", ptr %l17, i32 0, i32 6
  %t363 = load { i64, ptr }, ptr %t362, !tbaa !27
  store { i64, ptr } %t363, ptr %l210, !tbaa !27
  %t364 = load i64, ptr %l16, !tbaa !24
  %t366 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !27
  %t368 = getelementptr ptr, ptr %t367, i64 %t364
  %t369 = load ptr, ptr %t368, !tbaa !39
  %t371 = icmp eq ptr %t369, null
  br i1 %t371, label %bb106, label %bb107
bb105:
  br label %bb109
bb106:
  %t373 = getelementptr %"compiler/typed:Plan", ptr %l17, i32 0, i32 6
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !27
  store { i64, ptr } %t374, ptr %l214, !tbaa !27
  %t375 = load i64, ptr %l16, !tbaa !24
  %t376 = getelementptr %"compiler/free:orStore", ptr %l15, i32 0, i32 3
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t381 = getelementptr { i64, ptr }, ptr %l214, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !27
  %t383 = getelementptr ptr, ptr %t382, i64 %t375
  store ptr %t377, ptr %t383, !tbaa !39
  br label %bb108
bb107:
  br label %bb108
bb108:
  br label %bb114
bb109:
  %t384 = getelementptr %"compiler/typed:Plan", ptr %l17, i32 0, i32 4
  %t385 = load { i64, ptr }, ptr %t384, !tbaa !27
  store { i64, ptr } %t385, ptr %l218, !tbaa !27
  %t386 = load i64, ptr %l16, !tbaa !24
  %t388 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !27
  %t390 = getelementptr i64, ptr %t389, i64 %t386
  %t391 = load i64, ptr %t390, !tbaa !34
  %t393 = icmp ne i64 %t391, 0
  br i1 %t393, label %bb110, label %bb111
bb110:
  br label %bb114
bb111:
  br label %bb112
bb112:
  %t395 = getelementptr %"compiler/typed:Plan", ptr %l17, i32 0, i32 4
  %t396 = load { i64, ptr }, ptr %t395, !tbaa !27
  store { i64, ptr } %t396, ptr %l222, !tbaa !27
  %t397 = load i64, ptr %l16, !tbaa !24
  %t399 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !27
  %t401 = getelementptr i64, ptr %t400, i64 %t397
  store i64 2, ptr %t401, !tbaa !34
  %t402 = getelementptr %"compiler/typed:Plan", ptr %l17, i32 0, i32 5
  %t403 = load { i64, ptr }, ptr %t402, !tbaa !27
  store { i64, ptr } %t403, ptr %l224, !tbaa !27
  %t404 = load i64, ptr %l16, !tbaa !24
  %t405 = load { i64, [1 x i64] }, ptr %l18
  %t408 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !27
  %t410 = getelementptr { i64, [1 x i64] }, ptr %t409, i64 %t404
  store { i64, [1 x i64] } %t405, ptr %t410
  %t411 = getelementptr %"compiler/typed:Plan", ptr %l17, i32 0, i32 6
  %t412 = load { i64, ptr }, ptr %t411, !tbaa !27
  store { i64, ptr } %t412, ptr %l227, !tbaa !27
  %t413 = load i64, ptr %l16, !tbaa !24
  %t414 = getelementptr %"compiler/free:orStore", ptr %l15, i32 0, i32 3
  %t415 = load ptr, ptr %t414, !tbaa !29
  %t419 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t420 = load ptr, ptr %t419, !tbaa !27
  %t421 = getelementptr ptr, ptr %t420, i64 %t413
  store ptr %t415, ptr %t421, !tbaa !39
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/free:orStore", ptr %l15, i32 0, i32 0
  %t424 = load i64, ptr %t423, !tbaa !24
  %t425 = getelementptr %"compiler/free:orStore", ptr %l15, i32 0, i32 2
  %t426 = load ptr, ptr %t425, !tbaa !29
  %t427 = load i64, ptr %l16, !tbaa !24
  %t428 = load { i64, [1 x i64] }, ptr %l18
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t422, i64 %t424, ptr %t426, i64 %t427, { i64, [1 x i64] } %t428, i1 true, i1 false)
  br label %bb113
bb113:
  br label %bb114
bb114:
  %t434 = load i64, ptr %l14, !tbaa !24
  %t436 = add i64 %t434, 1
  store i64 %t436, ptr %l14, !tbaa !24
  br label %bb81
bb115:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/free:Free", ptr %t438, i32 0, i32 39
  store ptr %t440, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb116
bb116:
  %t442 = load i64, ptr %l20, !tbaa !24
  store i64 %t442, ptr %l240, !tbaa !24
  %t443 = load ptr, ptr %l19, !tbaa !29
  %t445 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %t443)
  store i64 %t445, ptr %l242
  br label %bb117
bb117:
  %t446 = load i64, ptr %l240, !tbaa !24
  %t447 = load i64, ptr %l242, !tbaa !24
  %t448 = icmp slt i64 %t446, %t447
  %t450 = xor i1 %t448, true
  br i1 %t450, label %bb118, label %bb119
bb118:
  br label %bb198
bb119:
  br label %bb120
bb120:
  %t452 = load ptr, ptr %l19, !tbaa !29
  %t453 = load i64, ptr %l20, !tbaa !24
  %t456 = call %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v0, ptr %t452, i64 %t453)
  store %"compiler/free:orCall" %t456, ptr %l247
  br label %bb121
bb121:
  %t457 = load %"compiler/free:orCall", ptr %l247
  store %"compiler/free:orCall" %t457, ptr %l21
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/free:Free", ptr %t458, i32 0, i32 41
  %t461 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 4
  %t462 = load i64, ptr %t461, !tbaa !24
  %t465 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t460, i64 %t462)
  store i1 %t465, ptr %l251
  br label %bb122
bb122:
  %t466 = load i1, ptr %l251, !tbaa !21
  %t467 = xor i1 %t466, true
  br i1 %t467, label %bb123, label %bb124
bb123:
  br label %bb197
bb124:
  br label %bb125
bb125:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/free:Free", ptr %t469, i32 0, i32 3
  %t472 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 0
  %t473 = load i64, ptr %t472, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t474, ptr %v0, ptr %v0, ptr %t471, i64 %t473)
  call void @llvm.memmove.p0.p0.i64(ptr %l256, ptr %t474, i64 152, i1 false)
  br label %bb126
bb126:
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %l256, i64 152, i1 false)
  %t477 = getelementptr %"compiler/typed:Plan", ptr %l22, i32 0, i32 4
  %t478 = load { i64, ptr }, ptr %t477, !tbaa !27
  store { i64, ptr } %t478, ptr %l257, !tbaa !27
  %t479 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 1
  %t480 = load i64, ptr %t479, !tbaa !24
  %t482 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr i64, ptr %t483, i64 %t480
  %t485 = load i64, ptr %t484, !tbaa !34
  %t487 = icmp ne i64 %t485, 0
  br i1 %t487, label %bb127, label %bb128
bb127:
  br label %bb197
bb128:
  br label %bb129
bb129:
  %t489 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 6
  %t490 = load ptr, ptr %t489, !tbaa !29
  %t492 = call ptr @compiler_2ffree_2ecallOf(ptr %v0, ptr %t490)
  store ptr %t492, ptr %l262
  br label %bb130
bb130:
  %t493 = load ptr, ptr %l262, !tbaa !29
  store ptr %t493, ptr %l23, !tbaa !29
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 2
  %t496 = load i64, ptr %t495, !tbaa !24
  %t497 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 3
  %t498 = load i64, ptr %t497, !tbaa !24
  %t502 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t494, i64 %t496, i64 %t498)
  store i64 %t502, ptr %l266
  br label %bb131
bb131:
  %t503 = load i64, ptr %l266, !tbaa !24
  store i64 %t503, ptr %l24, !tbaa !24
  %t504 = load i64, ptr %l24, !tbaa !24
  %t506 = icmp slt i64 %t504, 0
  br i1 %t506, label %bb132, label %bb133
bb132:
  br label %bb197
bb133:
  br label %bb134
bb134:
  %t508 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 1
  %t509 = load i64, ptr %t508, !tbaa !24
  %t511 = trunc i64 %t509 to i32
  store i32 %t511, ptr %l25, !tbaa !23
  %t514 = load i32, ptr %l25, !tbaa !23
  %t515 = load i64, ptr %l24, !tbaa !24
  %t519 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %l22, i32 %t514, i64 %t515)
  store { i64, [1 x i64] } %t519, ptr %l275
  br label %bb135
bb135:
  %t520 = load { i64, [1 x i64] }, ptr %l275
  store { i64, [1 x i64] } %t520, ptr %l26
  %t521 = load { i64, [1 x i64] }, ptr %l26
  %t523 = call i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %t521)
  store i1 %t523, ptr %l277
  br label %bb136
bb136:
  %t524 = load i1, ptr %l277, !tbaa !21
  %t525 = xor i1 %t524, true
  br i1 %t525, label %bb137, label %bb138
bb137:
  br label %bb197
bb138:
  br label %bb139
bb139:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 0
  %t529 = load i64, ptr %t528, !tbaa !24
  %t530 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 1
  %t531 = load i64, ptr %t530, !tbaa !24
  %t535 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %t527, i64 %t529, i64 %t531)
  store ptr %t535, ptr %l282
  br label %bb140
bb140:
  %t536 = load ptr, ptr %l282, !tbaa !29
  store ptr %t536, ptr %l27, !tbaa !29
  %t537 = load ptr, ptr %l27, !tbaa !29
  %t539 = icmp eq ptr %t537, null
  br i1 %t539, label %bb141, label %bb142
bb141:
  br label %bb197
bb142:
  br label %bb143
bb143:
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 0
  %t543 = load i64, ptr %t542, !tbaa !24
  %t544 = load ptr, ptr %l27, !tbaa !29
  %t545 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 2
  %t546 = load i64, ptr %t545, !tbaa !24
  %t547 = load { i64, [1 x i64] }, ptr %l26
  %t548 = load i64, ptr %l24, !tbaa !24
  %t555 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v0, ptr %t541, i64 %t543, ptr %t544, i64 %t546, { i64, [1 x i64] } %t547, i64 %t548)
  store i64 %t555, ptr %l291
  br label %bb144
bb144:
  %t556 = load i64, ptr %l291, !tbaa !24
  store i64 %t556, ptr %l28, !tbaa !24
  %t557 = load i64, ptr %l28, !tbaa !24
  %t559 = icmp slt i64 %t557, 0
  br i1 %t559, label %bb145, label %bb146
bb145:
  br label %bb197
bb146:
  br label %bb147
bb147:
  %t561 = getelementptr %"compiler/typed:Plan", ptr %l22, i32 0, i32 4
  %t562 = load { i64, ptr }, ptr %t561, !tbaa !27
  store { i64, ptr } %t562, ptr %l294, !tbaa !27
  %t563 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 1
  %t564 = load i64, ptr %t563, !tbaa !24
  %t566 = getelementptr { i64, ptr }, ptr %l294, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !27
  %t568 = getelementptr i64, ptr %t567, i64 %t564
  store i64 2, ptr %t568, !tbaa !34
  %t569 = getelementptr %"compiler/typed:Plan", ptr %l22, i32 0, i32 5
  %t570 = load { i64, ptr }, ptr %t569, !tbaa !27
  store { i64, ptr } %t570, ptr %l296, !tbaa !27
  %t571 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 1
  %t572 = load i64, ptr %t571, !tbaa !24
  %t573 = load { i64, [1 x i64] }, ptr %l26
  %t576 = getelementptr { i64, ptr }, ptr %l296, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr { i64, [1 x i64] }, ptr %t577, i64 %t572
  store { i64, [1 x i64] } %t573, ptr %t578
  %t579 = getelementptr %"compiler/typed:Plan", ptr %l22, i32 0, i32 6
  %t580 = load { i64, ptr }, ptr %t579, !tbaa !27
  store { i64, ptr } %t580, ptr %l299, !tbaa !27
  %t581 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 1
  %t582 = load i64, ptr %t581, !tbaa !24
  %t583 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 5
  %t584 = load ptr, ptr %t583, !tbaa !29
  %t588 = getelementptr { i64, ptr }, ptr %l299, i32 0, i32 1
  %t589 = load ptr, ptr %t588, !tbaa !27
  %t590 = getelementptr ptr, ptr %t589, i64 %t582
  store ptr %t584, ptr %t590, !tbaa !39
  store i64 0, ptr %l29, !tbaa !24
  store i64 63, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t591 = load i64, ptr %l30, !tbaa !24
  %t592 = load i64, ptr %l29, !tbaa !24
  %t595 = icmp sgt i64 %t591, %t592
  br i1 %t595, label %bb148, label %bb149
bb148:
  %t597 = load i64, ptr %l31, !tbaa !24
  %t599 = icmp sgt i64 %t597, 0
  br i1 %t599, label %bb150, label %bb151
bb149:
  store i64 0, ptr %l306, !tbaa !24
  br label %bb153
bb150:
  %t601 = load i64, ptr %l30, !tbaa !24
  %t602 = load i64, ptr %l29, !tbaa !24
  %t605 = sub i64 %t601, %t602
  %t606 = load i64, ptr %l31, !tbaa !24
  %t609 = add i64 %t605, %t606
  %t611 = sub i64 %t609, 1
  %t612 = load i64, ptr %l31, !tbaa !24
  %t615 = sdiv i64 %t611, %t612
  store i64 %t615, ptr %l309, !tbaa !24
  br label %bb152
bb151:
  store i64 0, ptr %l309, !tbaa !24
  br label %bb152
bb152:
  %t617 = load i64, ptr %l309, !tbaa !24
  store i64 %t617, ptr %l306, !tbaa !24
  br label %bb153
bb153:
  %t618 = load i64, ptr %l306, !tbaa !24
  store i64 %t618, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb154
bb154:
  %t619 = load i64, ptr %l33, !tbaa !24
  %t620 = load i64, ptr %l32, !tbaa !24
  %t623 = icmp slt i64 %t619, %t620
  %t625 = xor i1 %t623, true
  br i1 %t625, label %bb155, label %bb156
bb155:
  br label %bb163
bb156:
  br label %bb157
bb157:
  %t627 = load i64, ptr %l29, !tbaa !24
  %t628 = load i64, ptr %l33, !tbaa !24
  %t629 = load i64, ptr %l31, !tbaa !24
  %t632 = mul i64 %t628, %t629
  %t635 = add i64 %t627, %t632
  store i64 %t635, ptr %l34, !tbaa !24
  %t637 = load i64, ptr %l28, !tbaa !24
  %t638 = load i64, ptr %l34, !tbaa !24
  store i64 %t638, ptr %l328, !tbaa !24
  %t639 = load i64, ptr %l328, !tbaa !24
  %t640 = load i64, ptr %l328, !tbaa !24
  %t641 = shl i64 1, %t640
  %t644 = and i64 %t637, %t641
  %t646 = icmp ne i64 %t644, 0
  br i1 %t646, label %bb158, label %bb159
bb158:
  %t648 = load i32, ptr %l25, !tbaa !23
  %t649 = load i64, ptr %l34, !tbaa !24
  %t650 = load i32, ptr %l25, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t651
  %t652 = getelementptr { i64, [1 x i64] }, ptr %t651, i32 0, i32 0
  store i64 4, ptr %t652
  %t654 = insertvalue { i32 } undef, i32 %t650, 0
  %t655 = getelementptr { i64, [1 x i64] }, ptr %t651, i32 0, i32 1
  store { i32 } %t654, ptr %t655
  %t656 = load { i64, [1 x i64] }, ptr %t651
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %l22, i32 %t648, i64 %t649, { i64, [1 x i64] } %t656)
  br label %bb160
bb159:
  br label %bb161
bb160:
  br label %bb161
bb161:
  br label %bb162
bb162:
  %t661 = load i64, ptr %l33, !tbaa !24
  %t663 = add i64 %t661, 1
  store i64 %t663, ptr %l33, !tbaa !24
  br label %bb154
bb163:
  store i64 0, ptr %l35, !tbaa !24
  %t665 = load ptr, ptr %l27, !tbaa !29
  %t667 = getelementptr %"compiler/typed:Call", ptr %t665, i32 0, i32 1
  %t668 = load { i64, ptr }, ptr %t667, !tbaa !27
  %t670 = extractvalue { i64, ptr } %t668, 0
  store i64 %t670, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t672 = load i64, ptr %l36, !tbaa !24
  %t673 = load i64, ptr %l35, !tbaa !24
  %t676 = icmp sgt i64 %t672, %t673
  br i1 %t676, label %bb164, label %bb165
bb164:
  %t678 = load i64, ptr %l37, !tbaa !24
  %t680 = icmp sgt i64 %t678, 0
  br i1 %t680, label %bb166, label %bb167
bb165:
  store i64 0, ptr %l345, !tbaa !24
  br label %bb169
bb166:
  %t682 = load i64, ptr %l36, !tbaa !24
  %t683 = load i64, ptr %l35, !tbaa !24
  %t686 = sub i64 %t682, %t683
  %t687 = load i64, ptr %l37, !tbaa !24
  %t690 = add i64 %t686, %t687
  %t692 = sub i64 %t690, 1
  %t693 = load i64, ptr %l37, !tbaa !24
  %t696 = sdiv i64 %t692, %t693
  store i64 %t696, ptr %l348, !tbaa !24
  br label %bb168
bb167:
  store i64 0, ptr %l348, !tbaa !24
  br label %bb168
bb168:
  %t698 = load i64, ptr %l348, !tbaa !24
  store i64 %t698, ptr %l345, !tbaa !24
  br label %bb169
bb169:
  %t699 = load i64, ptr %l345, !tbaa !24
  store i64 %t699, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb170
bb170:
  %t700 = load i64, ptr %l39, !tbaa !24
  %t701 = load i64, ptr %l38, !tbaa !24
  %t704 = icmp slt i64 %t700, %t701
  %t706 = xor i1 %t704, true
  br i1 %t706, label %bb171, label %bb172
bb171:
  br label %bb196
bb172:
  br label %bb173
bb173:
  %t708 = load i64, ptr %l35, !tbaa !24
  %t709 = load i64, ptr %l39, !tbaa !24
  %t710 = load i64, ptr %l37, !tbaa !24
  %t713 = mul i64 %t709, %t710
  %t716 = add i64 %t708, %t713
  store i64 %t716, ptr %l40, !tbaa !24
  %t718 = load ptr, ptr %l0, !tbaa !29
  %t719 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 2
  %t720 = load i64, ptr %t719, !tbaa !24
  %t721 = load i64, ptr %l40, !tbaa !24
  %t725 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t718, i64 %t720, i64 %t721)
  store i64 %t725, ptr %l369
  br label %bb174
bb174:
  %t726 = load i64, ptr %l369, !tbaa !24
  store i64 %t726, ptr %l41, !tbaa !24
  %t727 = load i64, ptr %l41, !tbaa !24
  %t729 = icmp slt i64 %t727, 0
  br i1 %t729, label %bb175, label %bb176
bb175:
  store i1 true, ptr %l372, !tbaa !21
  br label %bb177
bb176:
  %t731 = load i64, ptr %l41, !tbaa !24
  %t733 = icmp sge i64 %t731, 63
  store i1 %t733, ptr %l372, !tbaa !21
  br label %bb177
bb177:
  %t735 = load i1, ptr %l372, !tbaa !21
  br i1 %t735, label %bb178, label %bb179
bb178:
  store i1 true, ptr %l375, !tbaa !21
  br label %bb180
bb179:
  %t736 = load i64, ptr %l28, !tbaa !24
  %t737 = load i64, ptr %l41, !tbaa !24
  store i64 %t737, ptr %l377, !tbaa !24
  %t738 = load i64, ptr %l377, !tbaa !24
  %t739 = load i64, ptr %l377, !tbaa !24
  %t740 = shl i64 1, %t739
  %t743 = and i64 %t736, %t740
  %t745 = icmp eq i64 %t743, 0
  store i1 %t745, ptr %l375, !tbaa !21
  br label %bb180
bb180:
  %t747 = load i1, ptr %l375, !tbaa !21
  br i1 %t747, label %bb181, label %bb182
bb181:
  store i1 true, ptr %l381, !tbaa !21
  br label %bb183
bb182:
  %t748 = load i64, ptr %l40, !tbaa !24
  %t749 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 3
  %t750 = load i64, ptr %t749, !tbaa !24
  %t753 = icmp eq i64 %t748, %t750
  store i1 %t753, ptr %l381, !tbaa !21
  br label %bb183
bb183:
  %t755 = load i1, ptr %l381, !tbaa !21
  br i1 %t755, label %bb184, label %bb185
bb184:
  br label %bb195
bb185:
  br label %bb186
bb186:
  %t756 = load ptr, ptr %l27, !tbaa !29
  %t758 = getelementptr %"compiler/typed:Call", ptr %t756, i32 0, i32 1
  %t759 = load { i64, ptr }, ptr %t758, !tbaa !27
  store { i64, ptr } %t759, ptr %l386, !tbaa !27
  %t760 = load i64, ptr %l40, !tbaa !24
  %t762 = getelementptr { i64, ptr }, ptr %l386, i32 0, i32 1
  %t763 = load ptr, ptr %t762, !tbaa !27
  %t764 = getelementptr ptr, ptr %t763, i64 %t760
  %t765 = load ptr, ptr %t764, !tbaa !39
  store ptr %t765, ptr %l42, !tbaa !29
  %t767 = load ptr, ptr %l0, !tbaa !29
  %t768 = load ptr, ptr %l42, !tbaa !29
  %t771 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t767, ptr %t768)
  store i64 %t771, ptr %l391
  br label %bb187
bb187:
  %t772 = load i64, ptr %l391, !tbaa !24
  store i64 %t772, ptr %l43, !tbaa !24
  %t773 = load i64, ptr %l43, !tbaa !24
  %t775 = icmp sge i64 %t773, 0
  br i1 %t775, label %bb188, label %bb189
bb188:
  %t777 = getelementptr %"compiler/typed:Plan", ptr %l22, i32 0, i32 4
  %t778 = load { i64, ptr }, ptr %t777, !tbaa !27
  store { i64, ptr } %t778, ptr %l395, !tbaa !27
  %t779 = load i64, ptr %l43, !tbaa !24
  %t781 = getelementptr { i64, ptr }, ptr %l395, i32 0, i32 1
  %t782 = load ptr, ptr %t781, !tbaa !27
  %t783 = getelementptr i64, ptr %t782, i64 %t779
  %t784 = load i64, ptr %t783, !tbaa !34
  %t786 = icmp eq i64 %t784, 1
  store i1 %t786, ptr %l394, !tbaa !21
  br label %bb190
bb189:
  store i1 false, ptr %l394, !tbaa !21
  br label %bb190
bb190:
  %t788 = load i1, ptr %l394, !tbaa !21
  br i1 %t788, label %bb191, label %bb192
bb191:
  %t789 = getelementptr %"compiler/typed:Plan", ptr %l22, i32 0, i32 5
  %t790 = load { i64, ptr }, ptr %t789, !tbaa !27
  store { i64, ptr } %t790, ptr %l399, !tbaa !27
  %t791 = load i64, ptr %l43, !tbaa !24
  %t792 = load i32, ptr %l25, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t793
  %t794 = getelementptr { i64, [1 x i64] }, ptr %t793, i32 0, i32 0
  store i64 4, ptr %t794
  %t796 = insertvalue { i32 } undef, i32 %t792, 0
  %t797 = getelementptr { i64, [1 x i64] }, ptr %t793, i32 0, i32 1
  store { i32 } %t796, ptr %t797
  %t798 = load { i64, [1 x i64] }, ptr %t793
  %t801 = getelementptr { i64, ptr }, ptr %l399, i32 0, i32 1
  %t802 = load ptr, ptr %t801, !tbaa !27
  %t803 = getelementptr { i64, [1 x i64] }, ptr %t802, i64 %t791
  store { i64, [1 x i64] } %t798, ptr %t803
  br label %bb194
bb192:
  %t804 = load ptr, ptr %l0, !tbaa !29
  %t805 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 0
  %t806 = load i64, ptr %t805, !tbaa !24
  %t807 = load ptr, ptr %l42, !tbaa !29
  %t808 = getelementptr %"compiler/free:orCall", ptr %l21, i32 0, i32 1
  %t809 = load i64, ptr %t808, !tbaa !24
  %t810 = load { i64, [1 x i64] }, ptr %l26
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t804, i64 %t806, ptr %t807, i64 %t809, { i64, [1 x i64] } %t810, i1 false, i1 false)
  br label %bb193
bb193:
  br label %bb194
bb194:
  br label %bb195
bb195:
  %t816 = load i64, ptr %l39, !tbaa !24
  %t818 = add i64 %t816, 1
  store i64 %t818, ptr %l39, !tbaa !24
  br label %bb170
bb196:
  br label %bb197
bb197:
  %t820 = load i64, ptr %l20, !tbaa !24
  %t822 = add i64 %t820, 1
  store i64 %t822, ptr %l20, !tbaa !24
  br label %bb116
bb198:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t24)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2ecallMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i1
  %l14 = alloca ptr
  %l23 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t4, ptr %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:mustW", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 1
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l14
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 11
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  store i1 %t29, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t31 = load i1, ptr %l9, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t32 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:mustW", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/free:Free", ptr %t37, i32 0, i32 26
  %t40 = load i64, ptr %l2, !tbaa !24
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l23
  br label %bb9
bb9:
  %t44 = load i64, ptr %l23, !tbaa !24
  store i64 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l50 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i1
  %l81 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l148 = alloca ptr
  %l169 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca i1
  %l190 = alloca ptr
  %l204 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca i1
  %l233 = alloca { i64, ptr }
  %l240 = alloca ptr
  %l241 = alloca i1
  %l250 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t2 = load ptr, ptr %l36, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l36, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l37, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l37, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Seq", ptr %t16, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l50, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %t41, ptr %t39)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb6
bb12:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Seq", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l61, !tbaa !29
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Seq", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb15, label %bb16
bb14:
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_14962ab25e47b4fc_3749941476b1d040)
  unreachable
bb16:
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Seq", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t70, ptr %t69)
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb141
bb20:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t73 = load ptr, ptr %l67, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = load ptr, ptr %l67, !tbaa !29
  %t77 = load i64, ptr %t76
  %t79 = icmp eq i64 %t77, 13
  store i1 %t79, ptr %l68, !tbaa !21
  br label %bb22
bb22:
  %t80 = load i1, ptr %l68, !tbaa !21
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l7, !tbaa !29
  br label %bb25
bb24:
  br label %bb83
bb25:
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Match", ptr %t87, i32 0, i32 0
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  store { i64, ptr } %t90, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l10, !tbaa !24
  br label %bb26
bb26:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t100 = icmp slt i64 %t96, %t97
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t104 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t104, ptr %l81, !tbaa !27
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr ptr, ptr %t108, i64 %t105
  %t110 = load ptr, ptr %t109, !tbaa !39
  %t112 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %t112, ptr %t110)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t116 = load i64, ptr %l9, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l9, !tbaa !24
  br label %bb26
bb32:
  %t120 = load ptr, ptr %l7, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Match", ptr %t120, i32 0, i32 1
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  store i64 %t127, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb34, label %bb35
bb34:
  br label %bb66
bb35:
  br label %bb36
bb36:
  %t137 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t137, ptr %l96, !tbaa !27
  %t138 = load i64, ptr %l13, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr ptr, ptr %t141, i64 %t138
  %t143 = load ptr, ptr %t142, !tbaa !39
  store ptr %t143, ptr %l15, !tbaa !29
  %t145 = load ptr, ptr %l15, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Arm", ptr %t145, i32 0, i32 1
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  store i64 %t152, ptr %l18, !tbaa !24
  br label %bb37
bb37:
  %t154 = load i64, ptr %l17, !tbaa !24
  %t155 = load i64, ptr %l18, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb38, label %bb39
bb38:
  br label %bb50
bb39:
  br label %bb40
bb40:
  %t162 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t162, ptr %l107, !tbaa !27
  %t163 = load i64, ptr %l17, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr ptr, ptr %t166, i64 %t163
  %t168 = load ptr, ptr %t167, !tbaa !39
  %t172 = getelementptr %"compiler/typed:Alt", ptr %t168, i32 0, i32 1
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l22, !tbaa !24
  br label %bb41
bb41:
  %t179 = load i64, ptr %l21, !tbaa !24
  %t180 = load i64, ptr %l22, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb42, label %bb43
bb42:
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t187 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t187, ptr %l118, !tbaa !27
  %t188 = load i64, ptr %l21, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr ptr, ptr %t191, i64 %t188
  %t193 = load ptr, ptr %t192, !tbaa !39
  store ptr %t193, ptr %l23, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/free:mustW", ptr %t195, i32 0, i32 4
  %t198 = load ptr, ptr %l23, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Bind", ptr %t198, i32 0, i32 0
  %t201 = load i32, ptr %t200, !tbaa !23
  %t203 = sext i32 %t201 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t197, i64 %t203)
  br label %bb45
bb45:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/free:mustW", ptr %t206, i32 0, i32 5
  %t209 = load ptr, ptr %l23, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Bind", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t208, ptr %t212)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t215 = load i64, ptr %l21, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l21, !tbaa !24
  br label %bb41
bb48:
  br label %bb49
bb49:
  %t219 = load i64, ptr %l17, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l17, !tbaa !24
  br label %bb37
bb50:
  %t223 = load ptr, ptr %l15, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Arm", ptr %t223, i32 0, i32 3
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = icmp eq ptr %t226, null
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb51, label %bb52
bb51:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l138, !tbaa !29
  %t233 = load ptr, ptr %l15, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Arm", ptr %t233, i32 0, i32 3
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = icmp eq ptr %t236, null
  br i1 %t238, label %bb53, label %bb54
bb52:
  br label %bb57
bb53:
  call void @__olang_check_failed(ptr @olang_loc_8d35557863f6e46b_2765f8f7d1e0ebdf)
  unreachable
bb54:
  br label %bb55
bb55:
  %t240 = load ptr, ptr %l15, !tbaa !29
  %t242 = getelementptr %"compiler/typed:Arm", ptr %t240, i32 0, i32 3
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t244 = load ptr, ptr %l138, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t244, ptr %t243)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t246 = load ptr, ptr %l15, !tbaa !29
  %t248 = getelementptr %"compiler/typed:Arm", ptr %t246, i32 0, i32 4
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = icmp eq ptr %t249, null
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb58, label %bb59
bb58:
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l148, !tbaa !29
  %t256 = load ptr, ptr %l15, !tbaa !29
  %t258 = getelementptr %"compiler/typed:Arm", ptr %t256, i32 0, i32 4
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = icmp eq ptr %t259, null
  br i1 %t261, label %bb60, label %bb61
bb59:
  br label %bb64
bb60:
  call void @__olang_check_failed(ptr @olang_loc_502532e2e95f04ea_fe436d8dc2f78aae)
  unreachable
bb61:
  br label %bb62
bb62:
  %t263 = load ptr, ptr %l15, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Arm", ptr %t263, i32 0, i32 4
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t267 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t267, ptr %t266)
  br label %bb63
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t269 = load i64, ptr %l13, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l13, !tbaa !24
  br label %bb33
bb66:
  %t273 = load ptr, ptr %l7, !tbaa !29
  %t275 = getelementptr %"compiler/typed:Match", ptr %t273, i32 0, i32 2
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = icmp eq ptr %t276, null
  %t280 = xor i1 %t278, true
  br i1 %t280, label %bb67, label %bb68
bb67:
  %t282 = load ptr, ptr %l7, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Match", ptr %t282, i32 0, i32 2
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = icmp eq ptr %t285, null
  br i1 %t287, label %bb69, label %bb70
bb68:
  br label %bb82
bb69:
  call void @__olang_check_failed(ptr @olang_loc_ba297c355e3740f1_9975a70d069e6a55)
  unreachable
bb70:
  br label %bb71
bb71:
  %t289 = load ptr, ptr %l7, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Match", ptr %t289, i32 0, i32 2
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t295 = getelementptr %"compiler/typed:Arm", ptr %t292, i32 0, i32 3
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = icmp eq ptr %t296, null
  %t300 = xor i1 %t298, true
  br i1 %t300, label %bb72, label %bb73
bb72:
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l169, !tbaa !29
  %t303 = load ptr, ptr %l7, !tbaa !29
  %t305 = getelementptr %"compiler/typed:Match", ptr %t303, i32 0, i32 2
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = icmp eq ptr %t306, null
  br i1 %t308, label %bb74, label %bb75
bb73:
  br label %bb81
bb74:
  call void @__olang_check_failed(ptr @olang_loc_ba297c355e3740f1_9975a70d069e6a55)
  unreachable
bb75:
  br label %bb76
bb76:
  %t310 = load ptr, ptr %l7, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Match", ptr %t310, i32 0, i32 2
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t316 = getelementptr %"compiler/typed:Arm", ptr %t313, i32 0, i32 3
  %t317 = load ptr, ptr %t316, !tbaa !29
  store ptr %t317, ptr %l24, !tbaa !29
  %t319 = load ptr, ptr %l24, !tbaa !29
  %t321 = icmp eq ptr %t319, null
  br i1 %t321, label %bb77, label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_ba297c355e3740f1_9975a70d069e6a55)
  unreachable
bb78:
  br label %bb79
bb79:
  %t323 = load ptr, ptr %l24, !tbaa !29
  %t324 = load ptr, ptr %l169, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t324, ptr %t323)
  br label %bb80
bb80:
  br label %bb81
bb81:
  br label %bb82
bb82:
  br label %bb141
bb83:
  %t326 = load ptr, ptr %l1, !tbaa !29
  store ptr %t326, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t327 = load ptr, ptr %l180, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb84, label %bb85
bb84:
  %t330 = load ptr, ptr %l180, !tbaa !29
  %t331 = load i64, ptr %t330
  %t333 = icmp eq i64 %t331, 14
  store i1 %t333, ptr %l181, !tbaa !21
  br label %bb85
bb85:
  %t334 = load i1, ptr %l181, !tbaa !21
  br i1 %t334, label %bb86, label %bb87
bb86:
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr { i64, [5 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t337, i32 0, i32 2
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l25, !tbaa !29
  br label %bb88
bb87:
  br label %bb109
bb88:
  %t341 = load ptr, ptr %l25, !tbaa !29
  %t343 = getelementptr %"compiler/typed:Try", ptr %t341, i32 0, i32 0
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = icmp eq ptr %t344, null
  %t348 = xor i1 %t346, true
  br i1 %t348, label %bb89, label %bb90
bb89:
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l190, !tbaa !29
  %t351 = load ptr, ptr %l25, !tbaa !29
  %t353 = getelementptr %"compiler/typed:Try", ptr %t351, i32 0, i32 0
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t356 = icmp eq ptr %t354, null
  br i1 %t356, label %bb91, label %bb92
bb90:
  br label %bb95
bb91:
  call void @__olang_check_failed(ptr @olang_loc_bb85040a6a786cb8_20e886069e3b9c04)
  unreachable
bb92:
  br label %bb93
bb93:
  %t358 = load ptr, ptr %l25, !tbaa !29
  %t360 = getelementptr %"compiler/typed:Try", ptr %t358, i32 0, i32 0
  %t361 = load ptr, ptr %t360, !tbaa !29
  %t362 = load ptr, ptr %l190, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t362, ptr %t361)
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t364 = load ptr, ptr %l25, !tbaa !29
  %t366 = getelementptr %"compiler/typed:Try", ptr %t364, i32 0, i32 1
  %t367 = load { i64, ptr }, ptr %t366, !tbaa !27
  store { i64, ptr } %t367, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t369 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t369, 0
  store i64 %t371, ptr %l28, !tbaa !24
  br label %bb96
bb96:
  %t373 = load i64, ptr %l27, !tbaa !24
  %t374 = load i64, ptr %l28, !tbaa !24
  %t377 = icmp slt i64 %t373, %t374
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb97, label %bb98
bb97:
  br label %bb108
bb98:
  br label %bb99
bb99:
  %t381 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t381, ptr %l204, !tbaa !27
  %t382 = load i64, ptr %l27, !tbaa !24
  %t384 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = getelementptr ptr, ptr %t385, i64 %t382
  %t387 = load ptr, ptr %t386, !tbaa !39
  store ptr %t387, ptr %l29, !tbaa !29
  %t389 = load ptr, ptr %l29, !tbaa !29
  %t391 = getelementptr %"compiler/typed:Clause", ptr %t389, i32 0, i32 3
  %t392 = load ptr, ptr %t391, !tbaa !29
  %t394 = icmp eq ptr %t392, null
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb100, label %bb101
bb100:
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l211, !tbaa !29
  %t399 = load ptr, ptr %l29, !tbaa !29
  %t401 = getelementptr %"compiler/typed:Clause", ptr %t399, i32 0, i32 3
  %t402 = load ptr, ptr %t401, !tbaa !29
  %t404 = icmp eq ptr %t402, null
  br i1 %t404, label %bb102, label %bb103
bb101:
  br label %bb106
bb102:
  call void @__olang_check_failed(ptr @olang_loc_be187497b97f18d7_9641cb8c9c409d3)
  unreachable
bb103:
  br label %bb104
bb104:
  %t406 = load ptr, ptr %l29, !tbaa !29
  %t408 = getelementptr %"compiler/typed:Clause", ptr %t406, i32 0, i32 3
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t410 = load ptr, ptr %l211, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t410, ptr %t409)
  br label %bb105
bb105:
  br label %bb106
bb106:
  br label %bb107
bb107:
  %t412 = load i64, ptr %l27, !tbaa !24
  %t414 = add i64 %t412, 1
  store i64 %t414, ptr %l27, !tbaa !24
  br label %bb96
bb108:
  br label %bb141
bb109:
  %t416 = load ptr, ptr %l1, !tbaa !29
  store ptr %t416, ptr %l219, !tbaa !29
  store i1 false, ptr %l220, !tbaa !21
  %t417 = load ptr, ptr %l219, !tbaa !29
  %t418 = icmp ne ptr %t417, null
  br i1 %t418, label %bb110, label %bb111
bb110:
  %t420 = load ptr, ptr %l219, !tbaa !29
  %t421 = load i64, ptr %t420
  %t423 = icmp eq i64 %t421, 6
  store i1 %t423, ptr %l220, !tbaa !21
  br label %bb111
bb111:
  %t424 = load i1, ptr %l220, !tbaa !21
  br i1 %t424, label %bb112, label %bb113
bb112:
  %t425 = load ptr, ptr %l1, !tbaa !29
  %t427 = getelementptr { i64, [5 x i64] }, ptr %t425, i32 0, i32 1
  %t428 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t427, i32 0, i32 2
  %t429 = load ptr, ptr %t428
  store ptr %t429, ptr %l30, !tbaa !29
  br label %bb114
bb113:
  br label %bb122
bb114:
  %t431 = load ptr, ptr %l30, !tbaa !29
  %t433 = getelementptr %"compiler/typed:Call", ptr %t431, i32 0, i32 1
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  store { i64, ptr } %t434, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t436 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t436, 0
  store i64 %t438, ptr %l33, !tbaa !24
  br label %bb115
bb115:
  %t440 = load i64, ptr %l32, !tbaa !24
  %t441 = load i64, ptr %l33, !tbaa !24
  %t444 = icmp slt i64 %t440, %t441
  %t446 = xor i1 %t444, true
  br i1 %t446, label %bb116, label %bb117
bb116:
  br label %bb121
bb117:
  br label %bb118
bb118:
  %t448 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t448, ptr %l233, !tbaa !27
  %t449 = load i64, ptr %l32, !tbaa !24
  %t451 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr ptr, ptr %t452, i64 %t449
  %t454 = load ptr, ptr %t453, !tbaa !39
  %t456 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t456, ptr %t454)
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t460 = load i64, ptr %l32, !tbaa !24
  %t462 = add i64 %t460, 1
  store i64 %t462, ptr %l32, !tbaa !24
  br label %bb115
bb121:
  br label %bb141
bb122:
  %t464 = load ptr, ptr %l1, !tbaa !29
  store ptr %t464, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t465 = load ptr, ptr %l240, !tbaa !29
  %t466 = icmp ne ptr %t465, null
  br i1 %t466, label %bb123, label %bb124
bb123:
  %t468 = load ptr, ptr %l240, !tbaa !29
  %t469 = load i64, ptr %t468
  %t471 = icmp eq i64 %t469, 11
  store i1 %t471, ptr %l241, !tbaa !21
  br label %bb124
bb124:
  %t472 = load i1, ptr %l241, !tbaa !21
  br i1 %t472, label %bb125, label %bb126
bb125:
  %t473 = load ptr, ptr %l1, !tbaa !29
  %t475 = getelementptr { i64, [5 x i64] }, ptr %t473, i32 0, i32 1
  %t476 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t475, i32 0, i32 2
  %t477 = load ptr, ptr %t476
  store ptr %t477, ptr %l35, !tbaa !29
  br label %bb127
bb126:
  br label %bb136
bb127:
  %t479 = load ptr, ptr %l35, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Cond", ptr %t479, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t484 = icmp eq ptr %t482, null
  %t486 = xor i1 %t484, true
  br i1 %t486, label %bb128, label %bb129
bb128:
  %t488 = load ptr, ptr %l0, !tbaa !29
  store ptr %t488, ptr %l250, !tbaa !29
  %t489 = load ptr, ptr %l35, !tbaa !29
  %t491 = getelementptr %"compiler/typed:Cond", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = icmp eq ptr %t492, null
  br i1 %t494, label %bb130, label %bb131
bb129:
  br label %bb134
bb130:
  call void @__olang_check_failed(ptr @olang_loc_342e0c3fe78e7ee6_419d07e7c20dd892)
  unreachable
bb131:
  br label %bb132
bb132:
  %t496 = load ptr, ptr %l35, !tbaa !29
  %t498 = getelementptr %"compiler/typed:Cond", ptr %t496, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !29
  %t500 = load ptr, ptr %l250, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t500, ptr %t499)
  br label %bb133
bb133:
  br label %bb134
bb134:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load ptr, ptr %l35, !tbaa !29
  %t505 = getelementptr %"compiler/typed:Cond", ptr %t503, i32 0, i32 2
  %t506 = load ptr, ptr %t505, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t502, ptr %t506)
  br label %bb135
bb135:
  br label %bb141
bb136:
  br i1 true, label %bb137, label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb141
bb140:
  call void @__olang_check_failed(ptr @olang_loc_d5478abcfcd1a74_537f989617a8cff0)
  unreachable
bb141:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efreshLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i1
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i1 false, ptr %l2, !tbaa !21
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:mustW", ptr %t8, i32 0, i32 4
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l15
  br label %bb5
bb5:
  %t13 = load i64, ptr %l15, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb11
bb8:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l22, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb10
bb10:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb11
bb11:
  %t41 = load i64, ptr %l19, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb13, label %bb14
bb13:
  br label %bb26
bb14:
  br label %bb15
bb15:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:mustW", ptr %t60, i32 0, i32 4
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t62, i64 %t63)
  store i64 %t66, ptr %l43
  br label %bb16
bb16:
  %t67 = load i64, ptr %l1, !tbaa !24
  %t68 = load i64, ptr %l43, !tbaa !24
  %t70 = icmp ne i64 %t68, %t67
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l46, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:mustW", ptr %t73, i32 0, i32 5
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t75, i64 %t76)
  store ptr %t79, ptr %l50
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l46, !tbaa !29
  %t81 = load ptr, ptr %l50, !tbaa !29
  %t82 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v0, ptr %t80, ptr %t81, i64 1)
  store i1 %t82, ptr %l51
  br label %bb21
bb21:
  %t83 = load i1, ptr %l51, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb22, label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb25
bb25:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb12
bb26:
  %t91 = load i1, ptr %l2, !tbaa !21
  store i1 %t91, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca i64
  %l20 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:mustW", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 5
  store ptr %t16, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l13, !tbaa !24
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l15
  br label %bb3
bb3:
  %t22 = load i64, ptr %l13, !tbaa !24
  %t23 = load i64, ptr %l15, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  br label %bb12
bb5:
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l20
  br label %bb7
bb7:
  %t33 = load i32, ptr %l20, !tbaa !23
  %t36 = sext i32 %t33 to i64
  %t40 = icmp eq i64 %t36, %a1
  br i1 %t40, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb2
bb12:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/free:leaf"
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l22 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i1
  %l38 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l59 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca i64
  %l69 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca ptr
  %l77 = alloca i1
  %l78 = alloca i64
  %l81 = alloca i64
  %l84 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca ptr
  %l103 = alloca %"compiler/source:Span"
  %l104 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l111 = alloca i64
  %l112 = alloca i64
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca %"compiler/source:Span"
  %l117 = alloca ptr
  %l119 = alloca i32
  %l120 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l122 = alloca i64
  %l124 = alloca i64
  %l129 = alloca %"compiler/free:leaf"
  %l130 = alloca ptr
  %l131 = alloca i64
  %l132 = alloca i64
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca %"compiler/source:Span"
  %l139 = alloca i64
  %l141 = alloca ptr
  %l142 = alloca ptr
  %l144 = alloca i32
  %l149 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l150 = alloca ptr
  %l151 = alloca i1
  %l156 = alloca ptr
  %l157 = alloca i64
  %l158 = alloca ptr
  %l159 = alloca ptr
  %l160 = alloca %"compiler/source:Span"
  %l161 = alloca ptr
  %l163 = alloca %"compiler/source:Span"
  %l164 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l173 = alloca i32
  %l174 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l176 = alloca i64
  %l178 = alloca ptr
  %l179 = alloca ptr
  %l181 = alloca i32
  %l186 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l189 = alloca ptr
  %l190 = alloca ptr
  %l191 = alloca %"compiler/source:Span"
  %l192 = alloca ptr
  %l194 = alloca %"compiler/source:Span"
  %l195 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l199 = alloca i64
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l16, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 9
  %t8 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2ePush_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t15 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %s0, ptr %t11, ptr %t12)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l22
  br label %bb3
bb3:
  %t16 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l5
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 9
  %t21 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2ePop_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %s0, ptr %t19)
  %t22 = extractvalue { i32, ptr } %t21, 1
  %t23 = extractvalue { i32, ptr } %t21, 0
  store i32 %t23, ptr %l27
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb5, label %ok.25
ok.25:
  store ptr %t22, ptr %l26
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l26, !tbaa !29
  store ptr %t26, ptr %l23, !tbaa !29
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t28 = load ptr, ptr %l28, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l28, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l29, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t38, i32 0, i32 2
  %t40 = load i32, ptr %t39
  store i32 %t40, ptr %l6, !tbaa !23
  br label %bb12
bb11:
  br label %bb23
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t45 = sext i32 %t43 to i64
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s0, ptr %t42, i64 %t45, ptr %l5)
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/free:walker", ptr %t49, i32 0, i32 7
  %t52 = load i32, ptr %l6, !tbaa !23
  %t54 = sext i32 %t52 to i64
  %t57 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t51, i64 %t54)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l44
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb15, label %ok.61
ok.61:
  store i64 %t58, ptr %l43
  br label %bb14
bb14:
  %t62 = load i64, ptr %l43, !tbaa !24
  store i64 %t62, ptr %l38, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t63 = load i64, ptr %l38, !tbaa !24
  store i64 %t63, ptr %l7, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t66 = icmp sge i64 %t64, 0
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v2, ptr %s0, ptr %t68, i64 %t69, ptr %t70, ptr %l5, %"compiler/source:Span" %t71)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l6, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t82 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyStore(ptr %v0, ptr %v2, ptr %t77, i64 %t80, ptr %t81, %"compiler/source:Span" %t82)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_620cc86993d1ee05_2ed463b6a2f232e1)
  unreachable
bb28:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t91 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %s0, ptr %t87, ptr %t88)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %l59
  br label %bb29
bb29:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:walker", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t99 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t95, ptr %t96)
  store i64 %t99, ptr %l63
  br label %bb30
bb30:
  %t100 = load i64, ptr %l63, !tbaa !24
  store i64 %t100, ptr %l8, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/free:walker", ptr %t101, i32 0, i32 2
  %t104 = load i1, ptr %t103, !tbaa !21
  br i1 %t104, label %bb31, label %bb32
bb31:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t108 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorStoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %t106, ptr %t107, ptr %t108)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l69, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t117 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %t113, ptr %t114)
  store i64 %t117, ptr %l72
  br label %bb35
bb35:
  %t118 = load i64, ptr %l72, !tbaa !24
  %t119 = load ptr, ptr %l69, !tbaa !29
  %t120 = getelementptr %"compiler/free:walker", ptr %t119, i32 0, i32 30
  store i64 %t118, ptr %t120, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l73, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l3, !tbaa !29
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t128 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esameValue(ptr %v0, ptr %v2, ptr %v1, ptr %t122, ptr %t123, ptr %t124)
  store i1 %t128, ptr %l77
  br label %bb36
bb36:
  %t129 = load i1, ptr %l77, !tbaa !21
  br i1 %t129, label %bb37, label %bb38
bb37:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t134 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einsidePlace(ptr %v0, ptr %v1, ptr %t130, ptr %t131)
  store i64 %t134, ptr %l81
  br label %bb39
bb38:
  store i64 -1, ptr %l78, !tbaa !24
  br label %bb40
bb39:
  %t135 = load i64, ptr %l81, !tbaa !24
  store i64 %t135, ptr %l78, !tbaa !24
  br label %bb40
bb40:
  %t136 = load i64, ptr %l78, !tbaa !24
  %t137 = load ptr, ptr %l73, !tbaa !29
  %t138 = getelementptr %"compiler/free:walker", ptr %t137, i32 0, i32 31
  store i64 %t136, ptr %t138, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t143 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t139, ptr %t140)
  store i64 %t143, ptr %l84
  br label %bb41
bb41:
  %t144 = load i64, ptr %l84, !tbaa !24
  store i64 %t144, ptr %l9, !tbaa !24
  %t145 = load i64, ptr %l9, !tbaa !24
  %t147 = icmp sge i64 %t145, 0
  br i1 %t147, label %bb42, label %bb43
bb42:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s0, ptr %t149, i64 %t150, ptr %l5)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  %t154 = load ptr, ptr %l2, !tbaa !29
  store ptr %t154, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t155 = load ptr, ptr %l90, !tbaa !29
  %t156 = icmp ne ptr %t155, null
  br i1 %t156, label %bb46, label %bb47
bb46:
  %t158 = load ptr, ptr %l90, !tbaa !29
  %t159 = load i64, ptr %t158
  %t161 = icmp eq i64 %t159, 3
  store i1 %t161, ptr %l91, !tbaa !21
  br label %bb47
bb47:
  %t162 = load i1, ptr %l91, !tbaa !21
  br i1 %t162, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb79
bb50:
  %t163 = load i64, ptr %l8, !tbaa !24
  %t165 = icmp sge i64 %t163, 0
  br i1 %t165, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l96, !tbaa !29
  %t168 = load i64, ptr %l8, !tbaa !24
  store i64 %t168, ptr %l97, !tbaa !24
  %t169 = load ptr, ptr %l3, !tbaa !29
  store ptr %t169, ptr %l98, !tbaa !29
  store ptr %l5, ptr %l99, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t170, ptr %l100
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l101, !tbaa !29
  %t172 = load ptr, ptr %l2, !tbaa !29
  %t174 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t172)
  store %"compiler/source:Span" %t174, ptr %l103
  br label %bb53
bb52:
  br label %bb59
bb53:
  %t175 = load ptr, ptr %l101, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l103
  %t177 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s8, ptr %t175, %"compiler/source:Span" %t176)
  store { i64, ptr } %t177, ptr %l104
  br label %bb54
bb54:
  %t178 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load i64, ptr %l9, !tbaa !24
  %t187 = icmp sge i64 %t185, 0
  %t188 = load ptr, ptr %l96, !tbaa !29
  %t189 = load i64, ptr %l97, !tbaa !24
  %t190 = load ptr, ptr %l98, !tbaa !29
  %t191 = load ptr, ptr %l99, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l100
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v2, ptr %s0, ptr %s8, ptr %t188, i64 %t189, ptr %t190, ptr %t191, %"compiler/source:Span" %t192, { i64, ptr } %t184, i1 %t187)
  br label %bb55
bb55:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/free:walker", ptr %t195, i32 0, i32 30
  store i64 -1, ptr %t197, !tbaa !24
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/free:walker", ptr %t198, i32 0, i32 31
  store i64 -1, ptr %t200, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l110, !tbaa !29
  %t202 = load i64, ptr %l8, !tbaa !24
  store i64 %t202, ptr %l111, !tbaa !24
  %t203 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  store i64 %t203, ptr %l112, !tbaa !24
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t206 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t204)
  store %"compiler/source:Span" %t206, ptr %l114
  br label %bb56
bb56:
  %t207 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 0, i32 0)
  store %"compiler/source:Span" %t207, ptr %l115
  br label %bb57
bb57:
  %t208 = load ptr, ptr %l110, !tbaa !29
  %t209 = load i64, ptr %l111, !tbaa !24
  %t210 = load i64, ptr %l112, !tbaa !24
  %t211 = load %"compiler/source:Span", ptr %l114
  %t212 = load %"compiler/source:Span", ptr %l115
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t208, i64 %t209, i64 %t210, %"compiler/source:Span" %t211, %"compiler/source:Span" %t212, i64 -1)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb59:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/free:walker", ptr %t213, i32 0, i32 0
  %t216 = load ptr, ptr %t215, !tbaa !29
  store ptr %t216, ptr %l117, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t219 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t217)
  store i32 %t219, ptr %l119
  br label %bb60
bb60:
  %t220 = load ptr, ptr %l117, !tbaa !29
  %t221 = load i32, ptr %l119, !tbaa !23
  %t222 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t220, i32 %t221)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t222, ptr %l120
  br label %bb61
bb61:
  %t223 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l120
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t223, ptr %l10
  store ptr %l10, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  %t225 = load i64, ptr %l12, !tbaa !24
  store i64 %t225, ptr %l122, !tbaa !24
  %t226 = load ptr, ptr %l11, !tbaa !29
  %t228 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %t226)
  store i64 %t228, ptr %l124
  br label %bb63
bb63:
  %t229 = load i64, ptr %l122, !tbaa !24
  %t230 = load i64, ptr %l124, !tbaa !24
  %t231 = icmp slt i64 %t229, %t230
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s10)
  br label %bb72
bb65:
  br label %bb66
bb66:
  %t235 = load ptr, ptr %l11, !tbaa !29
  %t236 = load i64, ptr %l12, !tbaa !24
  %t239 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v0, ptr %t235, i64 %t236)
  store %"compiler/free:leaf" %t239, ptr %l129
  br label %bb67
bb67:
  %t240 = load %"compiler/free:leaf", ptr %l129
  store %"compiler/free:leaf" %t240, ptr %l13
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l130, !tbaa !29
  %t242 = getelementptr %"compiler/free:leaf", ptr %l13, i32 0, i32 1
  %t243 = load i64, ptr %t242, !tbaa !24
  store i64 %t243, ptr %l131, !tbaa !24
  %t244 = load i64, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  store i64 %t244, ptr %l132, !tbaa !24
  %t245 = load ptr, ptr %l2, !tbaa !29
  %t247 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t245)
  store %"compiler/source:Span" %t247, ptr %l134
  br label %bb68
bb68:
  %t248 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s10, i32 0, i32 0)
  store %"compiler/source:Span" %t248, ptr %l135
  br label %bb69
bb69:
  %t249 = load ptr, ptr %l130, !tbaa !29
  %t250 = load i64, ptr %l131, !tbaa !24
  %t251 = load i64, ptr %l132, !tbaa !24
  %t252 = load %"compiler/source:Span", ptr %l134
  %t253 = load %"compiler/source:Span", ptr %l135
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t249, i64 %t250, i64 %t251, %"compiler/source:Span" %t252, %"compiler/source:Span" %t253, i64 -1)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s10)
  br label %bb71
bb71:
  %t254 = load i64, ptr %l12, !tbaa !24
  %t256 = add i64 %t254, 1
  store i64 %t256, ptr %l12, !tbaa !24
  br label %bb62
bb72:
  %t259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %l10)
  store i64 %t259, ptr %l139
  br label %bb73
bb73:
  %t260 = load i64, ptr %l139, !tbaa !24
  %t261 = icmp sgt i64 %t260, 0
  br i1 %t261, label %bb74, label %bb75
bb74:
  %t263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t263, ptr %l141, !tbaa !29
  store ptr %l10, ptr %l142, !tbaa !29
  %t264 = load ptr, ptr %l2, !tbaa !29
  %t266 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t264)
  store i32 %t266, ptr %l144
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t267 = load ptr, ptr %l3, !tbaa !29
  %t268 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t270 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t268, ptr %t270
  %t271 = load %"compiler/source:Span", ptr %l1
  %t272 = load ptr, ptr %l141, !tbaa !29
  %t273 = load ptr, ptr %l142, !tbaa !29
  %t274 = load i32, ptr %l144, !tbaa !23
  %t278 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %v0, ptr %v2, ptr %s0, ptr %s0, ptr %t272, ptr %t273, i32 %t274, ptr %t267, ptr %t270, %"compiler/source:Span" %t271)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t278, ptr %l149
  br label %bb77
bb77:
  %t279 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l149
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t279, ptr %l5
  br label %bb78
bb78:
  br label %bb104
bb79:
  %t280 = load ptr, ptr %l2, !tbaa !29
  store ptr %t280, ptr %l150, !tbaa !29
  store i1 false, ptr %l151, !tbaa !21
  %t281 = load ptr, ptr %l150, !tbaa !29
  %t282 = icmp ne ptr %t281, null
  br i1 %t282, label %bb80, label %bb81
bb80:
  %t284 = load ptr, ptr %l150, !tbaa !29
  %t285 = load i64, ptr %t284
  %t287 = icmp eq i64 %t285, 4
  store i1 %t287, ptr %l151, !tbaa !21
  br label %bb81
bb81:
  %t288 = load i1, ptr %l151, !tbaa !21
  br i1 %t288, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb99
bb84:
  %t289 = load i64, ptr %l8, !tbaa !24
  %t291 = icmp sge i64 %t289, 0
  br i1 %t291, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s14
  %t293 = load ptr, ptr %l0, !tbaa !29
  store ptr %t293, ptr %l156, !tbaa !29
  %t294 = load i64, ptr %l8, !tbaa !24
  store i64 %t294, ptr %l157, !tbaa !24
  %t295 = load ptr, ptr %l3, !tbaa !29
  store ptr %t295, ptr %l158, !tbaa !29
  store ptr %l5, ptr %l159, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t296, ptr %l160
  %t297 = load ptr, ptr %l0, !tbaa !29
  store ptr %t297, ptr %l161, !tbaa !29
  %t298 = load ptr, ptr %l2, !tbaa !29
  %t300 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t298)
  store %"compiler/source:Span" %t300, ptr %l163
  br label %bb87
bb86:
  br label %bb90
bb87:
  %t301 = load ptr, ptr %l161, !tbaa !29
  %t302 = load %"compiler/source:Span", ptr %l163
  %t303 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s14, ptr %t301, %"compiler/source:Span" %t302)
  store { i64, ptr } %t303, ptr %l164
  br label %bb88
bb88:
  %t304 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 0
  %t306 = extractvalue { i64, ptr } %t304, 1
  %t307 = mul i64 %t305, 1
  %t308 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t307)
  call void @llvm.memcpy.p0.p0.i64(ptr %t308, ptr %t306, i64 %t307, i1 false)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  %t311 = load i64, ptr %l9, !tbaa !24
  %t313 = icmp sge i64 %t311, 0
  %t314 = load ptr, ptr %l156, !tbaa !29
  %t315 = load i64, ptr %l157, !tbaa !24
  %t316 = load ptr, ptr %l158, !tbaa !29
  %t317 = load ptr, ptr %l159, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l160
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v2, ptr %s0, ptr %s14, ptr %t314, i64 %t315, ptr %t316, ptr %t317, %"compiler/source:Span" %t318, { i64, ptr } %t310, i1 %t313)
  br label %bb89
bb89:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/free:walker", ptr %t321, i32 0, i32 30
  store i64 -1, ptr %t323, !tbaa !24
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/free:walker", ptr %t324, i32 0, i32 31
  store i64 -1, ptr %t326, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb90:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/free:walker", ptr %t327, i32 0, i32 0
  %t330 = load ptr, ptr %t329, !tbaa !29
  store ptr %t330, ptr %l171, !tbaa !29
  %t331 = load ptr, ptr %l2, !tbaa !29
  %t333 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t331)
  store i32 %t333, ptr %l173
  br label %bb91
bb91:
  %t334 = load ptr, ptr %l171, !tbaa !29
  %t335 = load i32, ptr %l173, !tbaa !23
  %t336 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t334, i32 %t335)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t336, ptr %l174
  br label %bb92
bb92:
  %t337 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l174
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t337, ptr %l14
  %t339 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %l14)
  store i64 %t339, ptr %l176
  br label %bb93
bb93:
  %t340 = load i64, ptr %l176, !tbaa !24
  %t341 = icmp sgt i64 %t340, 0
  br i1 %t341, label %bb94, label %bb95
bb94:
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l178, !tbaa !29
  store ptr %l14, ptr %l179, !tbaa !29
  %t344 = load ptr, ptr %l2, !tbaa !29
  %t346 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t344)
  store i32 %t346, ptr %l181
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t347 = load ptr, ptr %l3, !tbaa !29
  %t348 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t350 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t348, ptr %t350
  %t351 = load %"compiler/source:Span", ptr %l1
  %t352 = load ptr, ptr %l178, !tbaa !29
  %t353 = load ptr, ptr %l179, !tbaa !29
  %t354 = load i32, ptr %l181, !tbaa !23
  %t358 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %v0, ptr %v2, ptr %s0, ptr %s0, ptr %t352, ptr %t353, i32 %t354, ptr %t347, ptr %t350, %"compiler/source:Span" %t351)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t358, ptr %l186
  br label %bb97
bb97:
  %t359 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l186
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t359, ptr %l5
  br label %bb98
bb98:
  br label %bb104
bb99:
  br i1 true, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_e251e9e241135754_793c210c71879d50)
  unreachable
bb104:
  %t360 = load i64, ptr %l9, !tbaa !24
  %t362 = icmp slt i64 %t360, 0
  br i1 %t362, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s17
  %t364 = load ptr, ptr %l0, !tbaa !29
  store ptr %t364, ptr %l189, !tbaa !29
  store ptr %l5, ptr %l190, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t365, ptr %l191
  %t366 = load ptr, ptr %l0, !tbaa !29
  store ptr %t366, ptr %l192, !tbaa !29
  %t367 = load ptr, ptr %l2, !tbaa !29
  %t369 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t367)
  store %"compiler/source:Span" %t369, ptr %l194
  br label %bb107
bb106:
  br label %bb111
bb107:
  %t370 = load ptr, ptr %l192, !tbaa !29
  %t371 = load %"compiler/source:Span", ptr %l194
  %t372 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s17, ptr %t370, %"compiler/source:Span" %t371)
  store { i64, ptr } %t372, ptr %l195
  br label %bb108
bb108:
  %t373 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t373, 0
  %t375 = extractvalue { i64, ptr } %t373, 1
  %t376 = mul i64 %t374, 1
  %t377 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t376)
  call void @llvm.memcpy.p0.p0.i64(ptr %t377, ptr %t375, i64 %t376, i1 false)
  %t378 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t377, 1
  store { i64, ptr } %t379, ptr %l196, !tbaa !27
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load ptr, ptr %l2, !tbaa !29
  %t384 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %t380, ptr %t381)
  store i64 %t384, ptr %l199
  br label %bb109
bb109:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t387 = getelementptr %"compiler/free:walker", ptr %t385, i32 0, i32 31
  %t388 = load i64, ptr %t387, !tbaa !24
  %t389 = load ptr, ptr %l189, !tbaa !29
  %t390 = load ptr, ptr %l190, !tbaa !29
  %t391 = load %"compiler/source:Span", ptr %l191
  %t392 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t393 = load i64, ptr %l199, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s0, ptr %s17, ptr %t389, ptr %t390, %"compiler/source:Span" %t391, { i64, ptr } %t392, i1 true, i64 %t393, i64 %t388)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s17)
  br label %bb111
bb111:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/free:walker", ptr %t395, i32 0, i32 30
  store i64 -1, ptr %t397, !tbaa !24
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/free:walker", ptr %t398, i32 0, i32 31
  store i64 -1, ptr %t400, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i32
  %l20 = alloca i1
  %l26 = alloca i1
  %l27 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca i64
  %l37 = alloca i64
  %l61 = alloca i1
  %l63 = alloca { i64, ptr }
  %l67 = alloca i1
  %l78 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l104 = alloca ptr
  %l107 = alloca i64
  %l112 = alloca ptr
  %l115 = alloca i64
  %l120 = alloca ptr
  %l123 = alloca i64
  %l126 = alloca ptr
  %l129 = alloca i64
  %l132 = alloca { i64, ptr }
  %l135 = alloca i1
  %l138 = alloca i64
  %l140 = alloca { i64, ptr }
  %l143 = alloca ptr
  %l144 = alloca i1
  %l151 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/free:Free", ptr %t9, i32 0, i32 61
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:walker", ptr %t12, i32 0, i32 1
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t11, i64 %t15)
  store i1 %t18, ptr %l26
  br label %bb3
bb2:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb4
bb3:
  %t19 = load i1, ptr %l26, !tbaa !21
  store i1 %t19, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l20, !tbaa !21
  store i1 %t20, ptr %l2, !tbaa !21
  %t21 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l27
  br label %bb5
bb5:
  %t22 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Block", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb11
bb8:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l37, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb10
bb10:
  %t56 = load i64, ptr %l37, !tbaa !24
  store i64 %t56, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb13, label %bb14
bb13:
  br label %bb30
bb14:
  br label %bb15
bb15:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t78 = add i64 %t76, 1
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Block", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t87 = icmp slt i64 %t78, %t84
  br i1 %t87, label %bb16, label %bb17
bb16:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Block", ptr %t89, i32 0, i32 1
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %l63, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = add i64 %t93, 1
  %t97 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr ptr, ptr %t98, i64 %t95
  %t100 = load ptr, ptr %t99, !tbaa !39
  %t102 = call i1 @compiler_2ffree_2eleaves(ptr %v1, ptr %t100)
  store i1 %t102, ptr %l67
  br label %bb18
bb17:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb19
bb18:
  %t103 = load i1, ptr %l67, !tbaa !21
  store i1 %t103, ptr %l61, !tbaa !21
  br label %bb19
bb19:
  %t104 = load i1, ptr %l61, !tbaa !21
  br i1 %t104, label %bb20, label %bb21
bb20:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:walker", ptr %t105, i32 0, i32 22
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:walker", ptr %t108, i32 0, i32 11
  %t111 = load i64, ptr %t110, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t107, i64 %t111)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t114 = load i1, ptr %l2, !tbaa !21
  br i1 %t114, label %bb24, label %bb25
bb24:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/free:walker", ptr %t116, i32 0, i32 11
  %t119 = load i64, ptr %t118, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t119)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Block", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l78, !tbaa !27
  %t127 = load i64, ptr %l9, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 %t127
  %t132 = load ptr, ptr %t131, !tbaa !39
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %t122, ptr %t132)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l8, !tbaa !24
  br label %bb12
bb30:
  %t139 = load i1, ptr %l2, !tbaa !21
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  br label %bb33
bb33:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/free:walker", ptr %t143, i32 0, i32 11
  %t146 = load i64, ptr %t145, !tbaa !24
  %t148 = sub i64 %t146, 1
  store i64 %t148, ptr %l10, !tbaa !24
  store i64 -1, ptr %l11, !tbaa !24
  store i64 -1, ptr %l12, !tbaa !24
  store i64 -1, ptr %l13, !tbaa !24
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Block", ptr %t150, i32 0, i32 1
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t157 = sub i64 %t155, 1
  store i64 %t157, ptr %l14, !tbaa !24
  br label %bb34
bb34:
  %t159 = load i64, ptr %l14, !tbaa !24
  %t161 = icmp sge i64 %t159, 0
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb35, label %bb36
bb35:
  br label %bb81
bb36:
  br label %bb37
bb37:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Block", ptr %t165, i32 0, i32 1
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  store { i64, ptr } %t168, ptr %l96, !tbaa !27
  %t169 = load i64, ptr %l14, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr ptr, ptr %t172, i64 %t169
  %t174 = load ptr, ptr %t173, !tbaa !39
  store ptr %t174, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t177 = load ptr, ptr %l99, !tbaa !29
  %t178 = icmp ne ptr %t177, null
  br i1 %t178, label %bb38, label %bb39
bb38:
  %t180 = load ptr, ptr %l99, !tbaa !29
  %t181 = load i64, ptr %t180
  %t183 = icmp eq i64 %t181, 12
  store i1 %t183, ptr %l100, !tbaa !21
  br label %bb39
bb39:
  %t184 = load i1, ptr %l100, !tbaa !21
  br i1 %t184, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/free:walker", ptr %t185, i32 0, i32 53
  store ptr %t187, ptr %l104, !tbaa !29
  %t188 = load i64, ptr %l14, !tbaa !24
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t188)
  store i64 %t191, ptr %l107
  br label %bb43
bb43:
  %t192 = load i64, ptr %l10, !tbaa !24
  %t193 = load ptr, ptr %l104, !tbaa !29
  %t194 = load i64, ptr %l107, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t193, i64 %t194, i64 %t192)
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_2fa77e012092fd19_7ffe9e1eddadbc5d)
  unreachable
bb50:
  %t196 = load i64, ptr %l11, !tbaa !24
  %t198 = icmp sge i64 %t196, 0
  br i1 %t198, label %bb51, label %bb52
bb51:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/free:walker", ptr %t200, i32 0, i32 54
  store ptr %t202, ptr %l112, !tbaa !29
  %t203 = load i64, ptr %l14, !tbaa !24
  %t206 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t203)
  store i64 %t206, ptr %l115
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t207 = load i64, ptr %l11, !tbaa !24
  %t208 = load ptr, ptr %l112, !tbaa !29
  %t209 = load i64, ptr %l115, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t208, i64 %t209, i64 %t207)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t211 = load i64, ptr %l12, !tbaa !24
  %t213 = icmp sge i64 %t211, 0
  br i1 %t213, label %bb56, label %bb57
bb56:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/free:walker", ptr %t215, i32 0, i32 55
  store ptr %t217, ptr %l120, !tbaa !29
  %t218 = load i64, ptr %l14, !tbaa !24
  %t221 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t218)
  store i64 %t221, ptr %l123
  br label %bb58
bb57:
  br label %bb62
bb58:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t223 = load ptr, ptr %l120, !tbaa !29
  %t224 = load i64, ptr %l123, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t223, i64 %t224, i64 %t222)
  br label %bb59
bb59:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/free:walker", ptr %t226, i32 0, i32 56
  store ptr %t228, ptr %l126, !tbaa !29
  %t229 = load i64, ptr %l14, !tbaa !24
  %t232 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t229)
  store i64 %t232, ptr %l129
  br label %bb60
bb60:
  %t233 = load i64, ptr %l12, !tbaa !24
  %t234 = load ptr, ptr %l126, !tbaa !29
  %t235 = load i64, ptr %l129, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t234, i64 %t235, i64 %t233)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr %"compiler/typed:Block", ptr %t237, i32 0, i32 1
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  store { i64, ptr } %t240, ptr %l132, !tbaa !27
  %t241 = load i64, ptr %l14, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr ptr, ptr %t244, i64 %t241
  %t246 = load ptr, ptr %t245, !tbaa !39
  %t248 = call i1 @compiler_2ffree_2eleavesFunction(ptr %v1, ptr %t246)
  store i1 %t248, ptr %l135
  br label %bb63
bb63:
  %t249 = load i1, ptr %l135, !tbaa !21
  br i1 %t249, label %bb64, label %bb65
bb64:
  %t250 = load i64, ptr %l14, !tbaa !24
  %t253 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t250)
  store i64 %t253, ptr %l138
  br label %bb66
bb65:
  br label %bb67
bb66:
  %t254 = load i64, ptr %l138, !tbaa !24
  store i64 %t254, ptr %l11, !tbaa !24
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb67
bb67:
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t257 = getelementptr %"compiler/typed:Block", ptr %t255, i32 0, i32 1
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  store { i64, ptr } %t258, ptr %l140, !tbaa !27
  %t259 = load i64, ptr %l14, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr ptr, ptr %t262, i64 %t259
  %t264 = load ptr, ptr %t263, !tbaa !39
  store ptr %t264, ptr %l16, !tbaa !29
  %t266 = load ptr, ptr %l16, !tbaa !29
  store ptr %t266, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t267 = load ptr, ptr %l143, !tbaa !29
  %t268 = icmp ne ptr %t267, null
  br i1 %t268, label %bb68, label %bb69
bb68:
  %t270 = load ptr, ptr %l143, !tbaa !29
  %t271 = load i64, ptr %t270
  %t273 = icmp eq i64 %t271, 5
  store i1 %t273, ptr %l144, !tbaa !21
  br label %bb69
bb69:
  %t274 = load i1, ptr %l144, !tbaa !21
  br i1 %t274, label %bb70, label %bb71
bb70:
  %t275 = load ptr, ptr %l16, !tbaa !29
  %t277 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t277, i32 0, i32 2
  %t279 = load i32, ptr %t278
  store i32 %t279, ptr %l17, !tbaa !23
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t281 = load i64, ptr %l14, !tbaa !24
  %t284 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t281)
  store i64 %t284, ptr %l151
  br label %bb73
bb73:
  %t285 = load i64, ptr %l151, !tbaa !24
  store i64 %t285, ptr %l12, !tbaa !24
  %t286 = load i32, ptr %l17, !tbaa !23
  %t288 = sext i32 %t286 to i64
  store i64 %t288, ptr %l13, !tbaa !24
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_59a6b24cdfdba848_73366ee735d239ac)
  unreachable
bb79:
  br label %bb80
bb80:
  %t290 = load i64, ptr %l14, !tbaa !24
  %t292 = sub i64 %t290, 1
  store i64 %t292, ptr %l14, !tbaa !24
  br label %bb34
bb81:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/free:leaf"
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i1
  %l37 = alloca ptr
  %l42 = alloca i1
  %l43 = alloca ptr
  %l47 = alloca ptr
  %l50 = alloca i64
  %l53 = alloca i1
  %l54 = alloca ptr
  %l58 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l76 = alloca i32
  %l79 = alloca i32
  %l80 = alloca i1
  %l81 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l82 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca i64
  %l91 = alloca i64
  %l96 = alloca i64
  %l98 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l111 = alloca ptr
  %l112 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l120 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l122 = alloca i1
  %l125 = alloca i1
  %l128 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l141 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l144 = alloca i1
  %l149 = alloca i64
  %l151 = alloca i64
  %l156 = alloca %"compiler/free:leaf"
  %l158 = alloca ptr
  %l159 = alloca i64
  %l161 = alloca i64
  %l163 = alloca ptr
  %l170 = alloca %"compiler/free:store"
  %l171 = alloca ptr
  %l172 = alloca i64
  %l173 = alloca i64
  %l175 = alloca ptr
  %l177 = alloca i64
  %l178 = alloca %"compiler/source:Span"
  %l179 = alloca ptr
  %l181 = alloca %"compiler/source:Span"
  %l182 = alloca { i64, ptr }
  %l188 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l21
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l21, !tbaa !29
  store ptr %t9, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = call ptr @compiler_2ffree_2ecallOf(ptr %v2, ptr %t10)
  store ptr %t12, ptr %l23
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l23, !tbaa !29
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load ptr, ptr %l6, !tbaa !29
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t24 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v2, ptr %t20, ptr %t21)
  store i64 %t24, ptr %l30
  br label %bb5
bb4:
  store i64 -1, ptr %l27, !tbaa !24
  br label %bb6
bb5:
  %t25 = load i64, ptr %l30, !tbaa !24
  store i64 %t25, ptr %l27, !tbaa !24
  br label %bb6
bb6:
  %t26 = load i64, ptr %l27, !tbaa !24
  store i64 %t26, ptr %l9, !tbaa !24
  %t27 = load i64, ptr %l9, !tbaa !24
  %t29 = icmp sge i64 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 1
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t33, i64 %t34)
  store ptr %t37, ptr %l37
  br label %bb9
bb8:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb10
bb9:
  %t38 = load ptr, ptr %l37, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 11
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  store i1 %t45, ptr %l33, !tbaa !21
  br label %bb10
bb10:
  %t47 = load i1, ptr %l33, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l7, !tbaa !29
  store ptr %t48, ptr %l43, !tbaa !29
  %t49 = load ptr, ptr %l6, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 1
  %t52 = load i64, ptr %l9, !tbaa !24
  %t55 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l47
  br label %bb13
bb12:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb15
bb13:
  %t56 = load ptr, ptr %l47, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %t58, !tbaa !23
  %t60 = load ptr, ptr %l43, !tbaa !29
  %t62 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t60, i32 %t59)
  store i64 %t62, ptr %l50
  br label %bb14
bb14:
  %t63 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t64 = load i64, ptr %l50, !tbaa !24
  %t66 = icmp eq i64 %t64, %t63
  store i1 %t66, ptr %l42, !tbaa !21
  br label %bb15
bb15:
  %t68 = load i1, ptr %l42, !tbaa !21
  br i1 %t68, label %bb16, label %bb17
bb16:
  %t69 = load ptr, ptr %l7, !tbaa !29
  store ptr %t69, ptr %l54, !tbaa !29
  %t70 = load ptr, ptr %l6, !tbaa !29
  %t72 = getelementptr %"compiler/free:Free", ptr %t70, i32 0, i32 1
  %t73 = load i64, ptr %l9, !tbaa !24
  %t76 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t72, i64 %t73)
  store ptr %t76, ptr %l58
  br label %bb18
bb17:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb20
bb18:
  %t77 = load ptr, ptr %l58, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Body", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t81 = load ptr, ptr %l54, !tbaa !29
  %t83 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t81, i32 %t80)
  store { i64, ptr } %t83, ptr %l61
  br label %bb19
bb19:
  %t84 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t87 = icmp eq i64 %t85, 1
  store i1 %t87, ptr %l53, !tbaa !21
  br label %bb20
bb20:
  %t89 = load i1, ptr %l53, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t90 = load ptr, ptr %l7, !tbaa !29
  store ptr %t90, ptr %l65, !tbaa !29
  %t91 = load ptr, ptr %l7, !tbaa !29
  store ptr %t91, ptr %l66, !tbaa !29
  %t92 = load ptr, ptr %l7, !tbaa !29
  store ptr %t92, ptr %l67, !tbaa !29
  %t93 = load ptr, ptr %l6, !tbaa !29
  %t95 = getelementptr %"compiler/free:Free", ptr %t93, i32 0, i32 1
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t95, i64 %t96)
  store ptr %t99, ptr %l71
  br label %bb23
bb22:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb28
bb23:
  %t100 = load ptr, ptr %l71, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Body", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %t102, !tbaa !23
  %t104 = load ptr, ptr %l67, !tbaa !29
  %t106 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t104, i32 %t103)
  store { i64, ptr } %t106, ptr %l74
  br label %bb24
bb24:
  %t107 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i32, ptr %t108, i64 0
  %t110 = load i32, ptr %t109, !tbaa !33
  %t111 = load ptr, ptr %l66, !tbaa !29
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t111, i32 %t110)
  store i32 %t113, ptr %l76
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l7, !tbaa !29
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t114, i32 %a2)
  store i32 %t118, ptr %l79
  br label %bb26
bb26:
  %t119 = load ptr, ptr %l65, !tbaa !29
  %t120 = load i32, ptr %l76, !tbaa !23
  %t121 = load i32, ptr %l79, !tbaa !23
  %t122 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t119, i32 %t120, i32 %t121)
  store i1 %t122, ptr %l80
  br label %bb27
bb27:
  %t123 = load i1, ptr %l80, !tbaa !21
  store i1 %t123, ptr %l64, !tbaa !21
  br label %bb28
bb28:
  %t124 = load i1, ptr %l64, !tbaa !21
  br i1 %t124, label %bb29, label %bb30
bb29:
  %t125 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t125, ptr %l81
  br label %bb31
bb30:
  br label %bb58
bb31:
  %t126 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 8, i64 8)
  store ptr %t126, ptr %lp10
  %t127 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  %t128 = load ptr, ptr %lp10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t127, ptr %t128
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l82, !tbaa !29
  %t130 = load ptr, ptr %l82, !tbaa !29
  %t131 = getelementptr %"compiler/free:walker", ptr %t130, i32 0, i32 29
  %t132 = load i64, ptr %t131, !tbaa !24
  %t134 = add i64 %t132, 1
  %t136 = load ptr, ptr %l82, !tbaa !29
  %t137 = getelementptr %"compiler/free:walker", ptr %t136, i32 0, i32 29
  store i64 %t134, ptr %t137, !tbaa !24
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t140 = getelementptr %"compiler/free:Free", ptr %t138, i32 0, i32 20
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  store ptr %t144, ptr %l88
  br label %bb32
bb32:
  %t145 = load ptr, ptr %l88, !tbaa !29
  store ptr %t145, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb33
bb33:
  %t146 = load i64, ptr %l12, !tbaa !24
  store i64 %t146, ptr %l89, !tbaa !24
  %t147 = load ptr, ptr %l11, !tbaa !29
  %t149 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t147)
  store i64 %t149, ptr %l91
  br label %bb34
bb34:
  %t150 = load i64, ptr %l89, !tbaa !24
  %t151 = load i64, ptr %l91, !tbaa !24
  %t152 = icmp slt i64 %t150, %t151
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb35, label %bb36
bb35:
  br label %bb57
bb36:
  br label %bb37
bb37:
  %t156 = load ptr, ptr %l11, !tbaa !29
  %t157 = load i64, ptr %l12, !tbaa !24
  %t160 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t156, i64 %t157)
  store i64 %t160, ptr %l96
  br label %bb38
bb38:
  %t161 = load i64, ptr %l96, !tbaa !24
  store i64 %t161, ptr %l13, !tbaa !24
  %t162 = load i64, ptr %l13, !tbaa !24
  %t164 = call i64 @compiler_2ffree_2eokind(i64 %t162)
  store i64 %t164, ptr %l98
  br label %bb39
bb39:
  %t165 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t166 = load i64, ptr %l98, !tbaa !24
  %t168 = icmp eq i64 %t166, %t165
  br i1 %t168, label %bb40, label %bb41
bb40:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t172 = call i64 @compiler_2ffree_2eoval(i64 %t170)
  store i64 %t172, ptr %l102
  br label %bb42
bb41:
  %t173 = load ptr, ptr %lp10
  %t174 = load i64, ptr %l13, !tbaa !24
  %t177 = call i1 @compiler_2ffree_2eaddTo(ptr %v4, ptr %t173, i64 %t174)
  store i1 %t177, ptr %l125
  br label %bb54
bb42:
  %t178 = load i64, ptr %l102, !tbaa !24
  store i64 %t178, ptr %l14, !tbaa !24
  %t179 = load i64, ptr %l14, !tbaa !24
  store i64 %t179, ptr %l103, !tbaa !24
  %t180 = load ptr, ptr %l8, !tbaa !29
  %t182 = icmp eq ptr %t180, null
  br i1 %t182, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_3ed6c54977104fdc_6fa493e2929cd018)
  unreachable
bb44:
  br label %bb45
bb45:
  %t184 = load ptr, ptr %l8, !tbaa !29
  %t187 = getelementptr %"compiler/typed:Call", ptr %t184, i32 0, i32 1
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t191 = load i64, ptr %l103, !tbaa !24
  %t193 = icmp slt i64 %t191, %t190
  br i1 %t193, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s5
  %t195 = load ptr, ptr %lp10
  store ptr %t195, ptr %l111, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l112, !tbaa !29
  %t197 = load ptr, ptr %l8, !tbaa !29
  %t199 = icmp eq ptr %t197, null
  br i1 %t199, label %bb48, label %bb49
bb47:
  br label %bb53
bb48:
  call void @__olang_check_failed(ptr @olang_loc_3ed6c54977104fdc_6fa493e2929cd018)
  unreachable
bb49:
  br label %bb50
bb50:
  %t201 = load ptr, ptr %l8, !tbaa !29
  %t204 = getelementptr %"compiler/typed:Call", ptr %t201, i32 0, i32 1
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  store { i64, ptr } %t205, ptr %l117, !tbaa !27
  %t206 = load i64, ptr %l14, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr ptr, ptr %t209, i64 %t206
  %t211 = load ptr, ptr %t210, !tbaa !39
  %t212 = load ptr, ptr %l112, !tbaa !29
  %t214 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %s5, ptr %t212, ptr %t211)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t214, ptr %l120
  br label %bb51
bb51:
  %t215 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l120
  %t216 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t215, ptr %t216
  %t217 = load ptr, ptr %l111, !tbaa !29
  %t219 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v4, ptr %s5, ptr %t217, ptr %t216)
  store i1 %t219, ptr %l122
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t220 = load i64, ptr %l12, !tbaa !24
  %t222 = add i64 %t220, 1
  store i64 %t222, ptr %l12, !tbaa !24
  br label %bb33
bb57:
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l128, !tbaa !29
  %t225 = load ptr, ptr %l128, !tbaa !29
  %t226 = getelementptr %"compiler/free:walker", ptr %t225, i32 0, i32 29
  %t227 = load i64, ptr %t226, !tbaa !24
  %t229 = sub i64 %t227, 1
  %t231 = load ptr, ptr %l128, !tbaa !29
  %t232 = getelementptr %"compiler/free:walker", ptr %t231, i32 0, i32 29
  store i64 %t229, ptr %t232, !tbaa !24
  %t233 = load ptr, ptr %lp10
  %t234 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t233
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %rv
  br label %ret
bb58:
  %t236 = load ptr, ptr %l3, !tbaa !29
  store ptr %t236, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t237 = load ptr, ptr %l132, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb59, label %bb60
bb59:
  %t240 = load ptr, ptr %l132, !tbaa !29
  %t241 = load i64, ptr %t240
  %t243 = icmp eq i64 %t241, 0
  store i1 %t243, ptr %l133, !tbaa !21
  br label %bb60
bb60:
  %t244 = load i1, ptr %l133, !tbaa !21
  br i1 %t244, label %bb61, label %bb62
bb61:
  br label %bb67
bb62:
  %t245 = load ptr, ptr %l3, !tbaa !29
  store ptr %t245, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t246 = load ptr, ptr %l136, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb63, label %bb64
bb63:
  %t249 = load ptr, ptr %l136, !tbaa !29
  %t250 = load i64, ptr %t249
  %t252 = icmp eq i64 %t250, 1
  store i1 %t252, ptr %l137, !tbaa !21
  br label %bb64
bb64:
  %t253 = load i1, ptr %l137, !tbaa !21
  br i1 %t253, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t254 = load ptr, ptr %l4, !tbaa !29
  %t256 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClone_3cI64_3e(ptr %v3, ptr %v4, ptr %t254)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t256, ptr %l141
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t257 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l141
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t257, ptr %rv
  br label %ret
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_5c4d06a93fa4e0f2_2916de872c41e4ce)
  unreachable
bb74:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/free:walker", ptr %t258, i32 0, i32 2
  %t261 = load i1, ptr %t260, !tbaa !21
  br i1 %t261, label %bb75, label %bb76
bb75:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"compiler/free:walker", ptr %t263, i32 0, i32 29
  %t266 = load i64, ptr %t265, !tbaa !24
  %t268 = icmp eq i64 %t266, 0
  store i1 %t268, ptr %l144, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb77
bb77:
  %t270 = load i1, ptr %l144, !tbaa !21
  br i1 %t270, label %bb78, label %bb79
bb78:
  store ptr %a1, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb80
bb79:
  br label %bb95
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t273 = load i64, ptr %l16, !tbaa !24
  store i64 %t273, ptr %l149, !tbaa !24
  %t274 = load ptr, ptr %l15, !tbaa !29
  %t276 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t274)
  store i64 %t276, ptr %l151
  br label %bb81
bb81:
  %t277 = load i64, ptr %l149, !tbaa !24
  %t278 = load i64, ptr %l151, !tbaa !24
  %t279 = icmp slt i64 %t277, %t278
  %t281 = xor i1 %t279, true
  br i1 %t281, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s12)
  br label %bb94
bb83:
  br label %bb84
bb84:
  %t283 = load ptr, ptr %l15, !tbaa !29
  %t284 = load i64, ptr %l16, !tbaa !24
  %t287 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t283, i64 %t284)
  store %"compiler/free:leaf" %t287, ptr %l156
  br label %bb85
bb85:
  %t288 = load %"compiler/free:leaf", ptr %l156
  store %"compiler/free:leaf" %t288, ptr %l17
  %t289 = load ptr, ptr %l6, !tbaa !29
  %t291 = getelementptr %"compiler/free:Free", ptr %t289, i32 0, i32 34
  store ptr %t291, ptr %l158, !tbaa !29
  %t292 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 1
  %t293 = load i64, ptr %t292, !tbaa !24
  store i64 %t293, ptr %l159, !tbaa !24
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/free:walker", ptr %t294, i32 0, i32 1
  %t297 = load i64, ptr %t296, !tbaa !24
  store i64 %t297, ptr %l161, !tbaa !24
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t298)
  store ptr %t300, ptr %l163
  br label %bb86
bb86:
  %t301 = load ptr, ptr %l163, !tbaa !29
  %t303 = getelementptr %"compiler/typed:Body", ptr %t301, i32 0, i32 3
  %t304 = load i64, ptr %t303, !tbaa !24
  %t305 = load %"compiler/source:Span", ptr %l5
  %t306 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t307 = load ptr, ptr %l3, !tbaa !29
  %t309 = load i64, ptr %l159, !tbaa !24
  %t310 = load i64, ptr %l161, !tbaa !24
  %t315 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v2, ptr %v0, ptr %v0, i64 %t309, i64 %t310, i64 %t304, %"compiler/source:Span" %t305, i64 %t306, i64 -1, i64 -1, ptr %t307, ptr null)
  store %"compiler/free:store" %t315, ptr %l170
  br label %bb87
bb87:
  %t316 = load ptr, ptr %l158, !tbaa !29
  %t317 = load %"compiler/free:store", ptr %l170
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t316, %"compiler/free:store" %t317)
  br label %bb88
bb88:
  %t318 = load ptr, ptr %l6, !tbaa !29
  store ptr %t318, ptr %l171, !tbaa !29
  %t319 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  store i64 %t320, ptr %l172, !tbaa !24
  %t321 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t321, ptr %l173, !tbaa !24
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t322)
  store ptr %t324, ptr %l175
  br label %bb89
bb89:
  %t325 = load ptr, ptr %l175, !tbaa !29
  %t327 = getelementptr %"compiler/typed:Body", ptr %t325, i32 0, i32 3
  %t328 = load i64, ptr %t327, !tbaa !24
  store i64 %t328, ptr %l177, !tbaa !24
  %t329 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t329, ptr %l178
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l179, !tbaa !29
  %t331 = load ptr, ptr %l3, !tbaa !29
  %t333 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t331)
  store %"compiler/source:Span" %t333, ptr %l181
  br label %bb90
bb90:
  %t334 = load ptr, ptr %l179, !tbaa !29
  %t335 = load %"compiler/source:Span", ptr %l181
  %t336 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s12, ptr %t334, %"compiler/source:Span" %t335)
  store { i64, ptr } %t336, ptr %l182
  br label %bb91
bb91:
  %t337 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t338 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t339 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 1
  %t341 = extractvalue { i64, ptr } %t339, 0
  %t342 = add i64 %t338, %t341
  %t343 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t344 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t345 = add i64 %t342, %t344
  %t346 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t345)
  call void @olang_textcopy(ptr %t346, ptr %t337, i64 %t338)
  %t347 = getelementptr i8, ptr %t346, i64 %t338
  call void @olang_textcopy(ptr %t347, ptr %t340, i64 %t341)
  %t348 = getelementptr i8, ptr %t347, i64 %t341
  call void @olang_textcopy(ptr %t348, ptr %t343, i64 %t344)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t346, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = extractvalue { i64, ptr } %t350, 1
  %t354 = mul i64 %t352, 1
  %t355 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t355, ptr %t353, i64 %t354, i1 false)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  %t358 = load ptr, ptr %l171, !tbaa !29
  %t359 = load i64, ptr %l172, !tbaa !24
  %t360 = load i64, ptr %l173, !tbaa !24
  %t361 = load i64, ptr %l177, !tbaa !24
  %t362 = load %"compiler/source:Span", ptr %l178
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s12, ptr %t358, i64 %t359, i64 %t360, i64 %t361, %"compiler/source:Span" %t362, { i64, ptr } %t357)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s12)
  br label %bb93
bb93:
  %t364 = load i64, ptr %l16, !tbaa !24
  %t366 = add i64 %t364, 1
  store i64 %t366, ptr %l16, !tbaa !24
  br label %bb80
bb94:
  br label %bb95
bb95:
  %t368 = load ptr, ptr %l4, !tbaa !29
  %t370 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClone_3cI64_3e(ptr %v3, ptr %v4, ptr %t368)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t370, ptr %l188
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s0)
  %t371 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l188
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t371, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, i64, i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyMade(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, { i64, ptr } }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i1
  %l22 = alloca { i64, i64, i64, { i64, ptr } }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, i64, i64, { i64, ptr } }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca i64
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, i64, i64, { i64, ptr } }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, { i64, ptr } }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca { i64, i64, i64, { i64, ptr } }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l80 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i1
  %l90 = alloca ptr
  %l95 = alloca i1
  %l99 = alloca i64
  %l102 = alloca i64
  %l106 = alloca i64
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, i64, i64, { i64, ptr } }
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca { i64, ptr }
  %l116 = alloca i1
  %l120 = alloca { i64, i64, i64, { i64, ptr } }
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca ptr
  %l127 = alloca %"compiler/source:Span"
  %l128 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, i64, i64, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t7 = load ptr, ptr %l14, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l14, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 17
  store i1 %t13, ptr %l15, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t25 = call { i64, i64, i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyMade(ptr %v0, ptr %v1, ptr %v2, ptr %t21, ptr %t22)
  store { i64, i64, i64, { i64, ptr } } %t25, ptr %l22
  br label %bb6
bb6:
  %t26 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l22, i32 0, i32 3
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l24, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l25, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l24, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t42 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l22, i32 0, i32 3
  store { i64, ptr } %t41, ptr %t42, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t43 = load { i64, i64, i64, { i64, ptr } }, ptr %l22
  store { i64, i64, i64, { i64, ptr } } %t43, ptr %rv
  br label %ret
bb7:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t48 = load ptr, ptr %l26, !tbaa !29
  %t49 = load i64, ptr %t48
  %t51 = icmp eq i64 %t49, 14
  store i1 %t51, ptr %l27, !tbaa !21
  br label %bb9
bb9:
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t59 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t62 = insertvalue { i64, i64, i64, { i64, ptr } } undef, i64 %t59, 0
  %t63 = insertvalue { i64, i64, i64, { i64, ptr } } %t62, i64 -1, 1
  %t64 = insertvalue { i64, i64, i64, { i64, ptr } } %t63, i64 -1, 2
  %t66 = insertvalue { i64, i64, i64, { i64, ptr } } %t64, { i64, ptr } %t60, 3
  store { i64, i64, i64, { i64, ptr } } %t66, ptr %l35
  %t67 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l35, i32 0, i32 3
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l36, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l37, !tbaa !24
  %t71 = load i64, ptr %l37, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l38, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l37, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t83 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l35, i32 0, i32 3
  store { i64, ptr } %t82, ptr %t83, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { i64, i64, i64, { i64, ptr } }, ptr %l35
  store { i64, i64, i64, { i64, ptr } } %t84, ptr %rv
  br label %ret
bb13:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t86 = load ptr, ptr %l39, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb14, label %bb15
bb14:
  %t89 = load ptr, ptr %l39, !tbaa !29
  %t90 = load i64, ptr %t89
  %t92 = icmp eq i64 %t90, 4
  store i1 %t92, ptr %l40, !tbaa !21
  br label %bb15
bb15:
  %t93 = load i1, ptr %l40, !tbaa !21
  br i1 %t93, label %bb16, label %bb17
bb16:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l5, !tbaa !29
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t104 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t100, ptr %t101)
  store i64 %t104, ptr %l47
  br label %bb19
bb19:
  %t105 = load i64, ptr %l47, !tbaa !24
  store i64 %t105, ptr %l6, !tbaa !24
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = icmp sge i64 %t106, 0
  br i1 %t108, label %bb20, label %bb21
bb20:
  %t110 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t111 = load i64, ptr %l6, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t114 = insertvalue { i64, i64, i64, { i64, ptr } } undef, i64 %t110, 0
  %t116 = insertvalue { i64, i64, i64, { i64, ptr } } %t114, i64 %t111, 1
  %t117 = insertvalue { i64, i64, i64, { i64, ptr } } %t116, i64 -1, 2
  %t119 = insertvalue { i64, i64, i64, { i64, ptr } } %t117, { i64, ptr } %t112, 3
  store { i64, i64, i64, { i64, ptr } } %t119, ptr %l54
  %t120 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l54, i32 0, i32 3
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l55, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l56, !tbaa !24
  %t124 = load i64, ptr %l56, !tbaa !24
  %t125 = mul i64 %t124, 1
  %t126 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l57, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = load i64, ptr %l56, !tbaa !24
  %t134 = mul i64 %t133, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t130, ptr %t132, i64 %t134, i1 false)
  %t135 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t136 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l54, i32 0, i32 3
  store { i64, ptr } %t135, ptr %t136, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t137 = load { i64, i64, i64, { i64, ptr } }, ptr %l54
  store { i64, i64, i64, { i64, ptr } } %t137, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_ecfdd571afc7fb57_85e5c41b21451123)
  unreachable
bb28:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t142 = call { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %s0, ptr %t138, ptr %t139)
  store { i64, { i64, ptr } } %t142, ptr %l60
  br label %bb29
bb29:
  %t143 = load { i64, { i64, ptr } }, ptr %l60
  store { i64, { i64, ptr } } %t143, ptr %l7
  %t144 = getelementptr { i64, { i64, ptr } }, ptr %l7, i32 0, i32 0
  %t145 = load i64, ptr %t144, !tbaa !24
  store i64 %t145, ptr %l8, !tbaa !24
  %t147 = getelementptr { i64, { i64, ptr } }, ptr %l7, i32 0, i32 1
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l62, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 0
  store i64 %t150, ptr %l63, !tbaa !24
  %t151 = load i64, ptr %l63, !tbaa !24
  %t152 = mul i64 %t151, 1
  %t153 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t152)
  %t154 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l64, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = load i64, ptr %l63, !tbaa !24
  %t161 = mul i64 %t160, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t157, ptr %t159, i64 %t161, i1 false)
  %t162 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t162, ptr %l9, !tbaa !27
  %t163 = load i64, ptr %l8, !tbaa !24
  %t165 = icmp sge i64 %t163, 0
  br i1 %t165, label %bb30, label %bb31
bb30:
  %t167 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t168 = load i64, ptr %l8, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l69, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t171 = insertvalue { i64, i64, i64, { i64, ptr } } undef, i64 %t167, 0
  %t172 = insertvalue { i64, i64, i64, { i64, ptr } } %t171, i64 -1, 1
  %t174 = insertvalue { i64, i64, i64, { i64, ptr } } %t172, i64 %t168, 2
  %t176 = insertvalue { i64, i64, i64, { i64, ptr } } %t174, { i64, ptr } %t169, 3
  store { i64, i64, i64, { i64, ptr } } %t176, ptr %l71
  %t177 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l71, i32 0, i32 3
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l72, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l73, !tbaa !24
  %t181 = load i64, ptr %l73, !tbaa !24
  %t182 = mul i64 %t181, 1
  %t183 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l74, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = load i64, ptr %l73, !tbaa !24
  %t191 = mul i64 %t190, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t187, ptr %t189, i64 %t191, i1 false)
  %t192 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t193 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l71, i32 0, i32 3
  store { i64, ptr } %t192, ptr %t193, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t194 = load { i64, i64, i64, { i64, ptr } }, ptr %l71
  store { i64, i64, i64, { i64, ptr } } %t194, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = call ptr @compiler_2ffree_2ecallOf(ptr %v1, ptr %t195)
  store ptr %t197, ptr %l76
  br label %bb33
bb33:
  %t198 = load ptr, ptr %l76, !tbaa !29
  store ptr %t198, ptr %l10, !tbaa !29
  %t199 = load ptr, ptr %l10, !tbaa !29
  %t201 = icmp eq ptr %t199, null
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb34, label %bb35
bb34:
  %t205 = load ptr, ptr %l2, !tbaa !29
  %t206 = load ptr, ptr %l10, !tbaa !29
  %t209 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t205, ptr %t206)
  store i64 %t209, ptr %l83
  br label %bb36
bb35:
  store i64 -1, ptr %l80, !tbaa !24
  br label %bb37
bb36:
  %t210 = load i64, ptr %l83, !tbaa !24
  store i64 %t210, ptr %l80, !tbaa !24
  br label %bb37
bb37:
  %t211 = load i64, ptr %l80, !tbaa !24
  store i64 %t211, ptr %l11, !tbaa !24
  %t212 = load i64, ptr %l11, !tbaa !24
  %t214 = icmp sge i64 %t212, 0
  br i1 %t214, label %bb38, label %bb39
bb38:
  %t216 = load ptr, ptr %l2, !tbaa !29
  %t218 = getelementptr %"compiler/free:Free", ptr %t216, i32 0, i32 1
  %t219 = load i64, ptr %l11, !tbaa !24
  %t222 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t218, i64 %t219)
  store ptr %t222, ptr %l90
  br label %bb40
bb39:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb41
bb40:
  %t223 = load ptr, ptr %l90, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Body", ptr %t223, i32 0, i32 11
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = icmp eq ptr %t226, null
  %t230 = xor i1 %t228, true
  store i1 %t230, ptr %l86, !tbaa !21
  br label %bb41
bb41:
  %t232 = load i1, ptr %l86, !tbaa !21
  br i1 %t232, label %bb42, label %bb43
bb42:
  %t233 = load ptr, ptr %l2, !tbaa !29
  %t235 = getelementptr %"compiler/free:Free", ptr %t233, i32 0, i32 26
  %t236 = load i64, ptr %l11, !tbaa !24
  %t239 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t235, i64 %t236)
  store i64 %t239, ptr %l99
  br label %bb44
bb43:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb45
bb44:
  %t240 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t241 = load i64, ptr %l99, !tbaa !24
  %t243 = icmp sge i64 %t241, %t240
  store i1 %t243, ptr %l95, !tbaa !21
  br label %bb45
bb45:
  %t245 = load i1, ptr %l95, !tbaa !21
  br i1 %t245, label %bb46, label %bb47
bb46:
  %t246 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  store i64 %t246, ptr %l102, !tbaa !24
  %t247 = load ptr, ptr %l2, !tbaa !29
  %t249 = getelementptr %"compiler/free:Free", ptr %t247, i32 0, i32 26
  %t250 = load i64, ptr %l11, !tbaa !24
  %t253 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t249, i64 %t250)
  store i64 %t253, ptr %l106
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t254 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t255 = load i64, ptr %l106, !tbaa !24
  %t257 = sub i64 %t255, %t254
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l109, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t259 = load i64, ptr %l102, !tbaa !24
  %t260 = insertvalue { i64, i64, i64, { i64, ptr } } undef, i64 %t259, 0
  %t262 = insertvalue { i64, i64, i64, { i64, ptr } } %t260, i64 %t257, 1
  %t263 = insertvalue { i64, i64, i64, { i64, ptr } } %t262, i64 -1, 2
  %t265 = insertvalue { i64, i64, i64, { i64, ptr } } %t263, { i64, ptr } %t258, 3
  store { i64, i64, i64, { i64, ptr } } %t265, ptr %l111
  %t266 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l111, i32 0, i32 3
  %t267 = load { i64, ptr }, ptr %t266, !tbaa !27
  store { i64, ptr } %t267, ptr %l112, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 0
  store i64 %t269, ptr %l113, !tbaa !24
  %t270 = load i64, ptr %l113, !tbaa !24
  %t271 = mul i64 %t270, 1
  %t272 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t271)
  %t273 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  store { i64, ptr } %t274, ptr %l114, !tbaa !27
  %t275 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = load i64, ptr %l113, !tbaa !24
  %t280 = mul i64 %t279, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t276, ptr %t278, i64 %t280, i1 false)
  %t281 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t282 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l111, i32 0, i32 3
  store { i64, ptr } %t281, ptr %t282, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t283 = load { i64, i64, i64, { i64, ptr } }, ptr %l111
  store { i64, i64, i64, { i64, ptr } } %t283, ptr %rv
  br label %ret
bb49:
  %t284 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t286 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t284, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t286, ptr %l116
  br label %bb50
bb50:
  %t287 = load i1, ptr %l116, !tbaa !21
  %t288 = xor i1 %t287, true
  br i1 %t288, label %bb51, label %bb52
bb51:
  %t290 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t291 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t293 = insertvalue { i64, i64, i64, { i64, ptr } } undef, i64 %t290, 0
  %t294 = insertvalue { i64, i64, i64, { i64, ptr } } %t293, i64 -1, 1
  %t295 = insertvalue { i64, i64, i64, { i64, ptr } } %t294, i64 -1, 2
  %t297 = insertvalue { i64, i64, i64, { i64, ptr } } %t295, { i64, ptr } %t291, 3
  store { i64, i64, i64, { i64, ptr } } %t297, ptr %l120
  %t298 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l120, i32 0, i32 3
  %t299 = load { i64, ptr }, ptr %t298, !tbaa !27
  store { i64, ptr } %t299, ptr %l121, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t300, 0
  store i64 %t301, ptr %l122, !tbaa !24
  %t302 = load i64, ptr %l122, !tbaa !24
  %t303 = mul i64 %t302, 1
  %t304 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t303)
  %t305 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t304, 1
  store { i64, ptr } %t306, ptr %l123, !tbaa !27
  %t307 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = load i64, ptr %l122, !tbaa !24
  %t312 = mul i64 %t311, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t308, ptr %t310, i64 %t312, i1 false)
  %t313 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t314 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l120, i32 0, i32 3
  store { i64, ptr } %t313, ptr %t314, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t315 = load { i64, i64, i64, { i64, ptr } }, ptr %l120
  store { i64, i64, i64, { i64, ptr } } %t315, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t316 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t316, ptr %l124, !tbaa !24
  %t317 = load ptr, ptr %l0, !tbaa !29
  store ptr %t317, ptr %l125, !tbaa !29
  %t318 = load ptr, ptr %l1, !tbaa !29
  %t320 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t318)
  store %"compiler/source:Span" %t320, ptr %l127
  br label %bb54
bb54:
  %t321 = load ptr, ptr %l125, !tbaa !29
  %t322 = load %"compiler/source:Span", ptr %l127
  %t323 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s0, ptr %t321, %"compiler/source:Span" %t322)
  store { i64, ptr } %t323, ptr %l128
  br label %bb55
bb55:
  %t324 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t326 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = add i64 %t325, %t328
  %t330 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t331 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t332 = add i64 %t329, %t331
  %t333 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t332)
  call void @olang_textcopy(ptr %t333, ptr %t324, i64 %t325)
  %t334 = getelementptr i8, ptr %t333, i64 %t325
  call void @olang_textcopy(ptr %t334, ptr %t327, i64 %t328)
  %t335 = getelementptr i8, ptr %t334, i64 %t328
  call void @olang_textcopy(ptr %t335, ptr %t330, i64 %t331)
  %t336 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t333, 1
  %t338 = load i64, ptr %l124, !tbaa !24
  %t339 = insertvalue { i64, i64, i64, { i64, ptr } } undef, i64 %t338, 0
  %t340 = insertvalue { i64, i64, i64, { i64, ptr } } %t339, i64 -1, 1
  %t341 = insertvalue { i64, i64, i64, { i64, ptr } } %t340, i64 -1, 2
  %t343 = insertvalue { i64, i64, i64, { i64, ptr } } %t341, { i64, ptr } %t337, 3
  call void @__olang_scope_close(ptr %s0)
  store { i64, i64, i64, { i64, ptr } } %t343, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64, i64, { i64, ptr } }, ptr %rv
  ret { i64, i64, i64, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l16 = alloca ptr
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i64
  %l22 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 61
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:walker", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t10, i64 %t14)
  store i1 %t17, ptr %l10
  br label %bb3
bb3:
  %t18 = load i1, ptr %l10, !tbaa !21
  %t19 = xor i1 %t18, true
  store i1 %t19, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l4, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 53
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t32, i64 %t33)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36, ptr %l20
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t37, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t38)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l22
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb10, label %ok.43
ok.43:
  store i64 %t40, ptr %l21
  br label %bb9
bb9:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l13, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load i64, ptr %l13, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyStore(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, i64, i64, { i64, ptr } }
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca ptr
  %l23 = alloca i64
  %l30 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca { i64, i64, i64, { i64, ptr } }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l63 = alloca %"compiler/free:store"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyOf(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i64, ptr %l16, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l19
  br label %bb5
bb5:
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l5
  store ptr %l5, ptr %l20, !tbaa !29
  %t13 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i64 @compiler_2ffree_2eorig(i64 %t13, i64 %t14)
  store i64 %t17, ptr %l23
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l20, !tbaa !29
  %t19 = load i64, ptr %l23, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t18, i64 %t19)
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s0, ptr %t20, i64 %t21, ptr %l5)
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/free:walker", ptr %t25, i32 0, i32 2
  %t28 = load i1, ptr %t27, !tbaa !21
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 29
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  store i1 %t37, ptr %l30, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l30, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l6, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t45)
  store ptr %t47, ptr %l37
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l37, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t48, i32 0, i32 3
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  %t55 = call ptr @compiler_2ffree_2eunwrapped(ptr %v1, ptr %a2)
  store ptr %t55, ptr %l41
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l41, !tbaa !29
  store ptr %t56, ptr %l8, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l8, !tbaa !29
  %t61 = call { i64, i64, i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyMade(ptr %v0, ptr %v1, ptr %s0, ptr %t57, ptr %t58)
  store { i64, i64, i64, { i64, ptr } } %t61, ptr %l44
  br label %bb17
bb17:
  %t62 = load { i64, i64, i64, { i64, ptr } }, ptr %l44
  store { i64, i64, i64, { i64, ptr } } %t62, ptr %l9
  %t63 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l9, i32 0, i32 0
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l10, !tbaa !24
  %t66 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l9, i32 0, i32 1
  %t67 = load i64, ptr %t66, !tbaa !24
  %t69 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l9, i32 0, i32 2
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l9, i32 0, i32 3
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l48, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l49, !tbaa !24
  %t76 = load i64, ptr %l49, !tbaa !24
  %t77 = mul i64 %t76, 1
  %t78 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  store { i64, ptr } %t80, ptr %l50, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = load i64, ptr %l49, !tbaa !24
  %t86 = mul i64 %t85, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t82, ptr %t84, i64 %t86, i1 false)
  %t87 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t87, ptr %l13, !tbaa !27
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = getelementptr %"compiler/free:Free", ptr %t88, i32 0, i32 34
  store ptr %t90, ptr %l52, !tbaa !29
  %t91 = load i64, ptr %l4, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:walker", ptr %t92, i32 0, i32 1
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load %"compiler/source:Span", ptr %l3
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = load ptr, ptr %l8, !tbaa !29
  %t111 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v1, ptr %v0, ptr %v0, i64 %t91, i64 %t95, i64 %t96, %"compiler/source:Span" %t97, i64 %t98, i64 %t67, i64 %t70, ptr %t101, ptr null)
  store %"compiler/free:store" %t111, ptr %l63
  br label %bb18
bb18:
  %t112 = load ptr, ptr %l52, !tbaa !29
  %t113 = load %"compiler/free:store", ptr %l63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t112, %"compiler/free:store" %t113)
  br label %bb19
bb19:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t118 = icmp eq i64 %t114, %t115
  br i1 %t118, label %bb20, label %bb21
bb20:
  %t120 = load ptr, ptr %l6, !tbaa !29
  %t121 = load i64, ptr %l4, !tbaa !24
  %t122 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t123 = load i64, ptr %l7, !tbaa !24
  %t124 = load %"compiler/source:Span", ptr %l3
  %t125 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s0, ptr %t120, i64 %t121, i64 %t122, i64 %t123, %"compiler/source:Span" %t124, { i64, ptr } %t125)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroys(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l47 = alloca ptr
  %l50 = alloca i64
  %l54 = alloca i64
  %l57 = alloca i64
  %l78 = alloca i64
  %l82 = alloca i64
  %l86 = alloca i64
  %l90 = alloca i64
  %l93 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i64
  %l100 = alloca i64
  %l102 = alloca i64
  %l106 = alloca %"compiler/source:Span"
  %l113 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i64
  %l116 = alloca i64
  %l118 = alloca i64
  %l122 = alloca %"compiler/source:Span"
  %l126 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l129 = alloca i64
  %l133 = alloca i64
  %l136 = alloca i64
  %l157 = alloca i64
  %l169 = alloca i64
  %l172 = alloca i1
  %l176 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i64
  %l187 = alloca %"compiler/source:Span"
  %l189 = alloca ptr
  %l190 = alloca i64
  %l194 = alloca i64
  %l197 = alloca i64
  %l203 = alloca i64
  %l207 = alloca i64
  %l210 = alloca i64
  %l231 = alloca i1
  %l235 = alloca i1
  %l236 = alloca i1
  %l240 = alloca ptr
  %l243 = alloca i64
  %l244 = alloca i1
  %l246 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l249 = alloca i64
  %l253 = alloca i64
  %l256 = alloca i64
  %l277 = alloca i64
  %l289 = alloca i64
  %l295 = alloca ptr
  %l297 = alloca i64
  %l301 = alloca %"compiler/typed:Local"
  %l304 = alloca i64
  %l305 = alloca ptr
  %l306 = alloca i64
  %l307 = alloca i64
  %l309 = alloca i64
  %l313 = alloca %"compiler/source:Span"
  %l316 = alloca { i64, ptr }
  %l325 = alloca i1
  %l329 = alloca i1
  %l331 = alloca i64
  %l335 = alloca i64
  %l336 = alloca i32
  %l341 = alloca i64
  %l345 = alloca i64
  %l348 = alloca i64
  %l369 = alloca i64
  %l372 = alloca i1
  %l376 = alloca i64
  %l379 = alloca i1
  %l383 = alloca i64
  %l386 = alloca ptr
  %l387 = alloca i64
  %l388 = alloca i64
  %l390 = alloca i64
  %l394 = alloca %"compiler/source:Span"
  %l398 = alloca ptr
  %l400 = alloca i64
  %l401 = alloca ptr
  %l405 = alloca i64
  %l406 = alloca %"compiler/source:Span"
  %l409 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s25 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l47
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l47, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/free:walker", ptr %t10, i32 0, i32 46
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l50
  br label %bb2
bb2:
  %t15 = load i64, ptr %l50, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l57, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l57, !tbaa !24
  store i64 %t42, ptr %l54, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l54, !tbaa !24
  store i64 %t43, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb161
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l8, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/free:walker", ptr %t62, i32 0, i32 46
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t64, i64 %t65)
  store i64 %t68, ptr %l78
  br label %bb13
bb13:
  %t69 = load i64, ptr %l78, !tbaa !24
  store i64 %t69, ptr %l9, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:walker", ptr %t70, i32 0, i32 47
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t72, i64 %t73)
  store i64 %t76, ptr %l82
  br label %bb14
bb14:
  %t77 = load i64, ptr %l82, !tbaa !24
  store i64 %t77, ptr %l10, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/free:walker", ptr %t78, i32 0, i32 48
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t80, i64 %t81)
  store i64 %t84, ptr %l86
  br label %bb15
bb15:
  %t85 = load i64, ptr %l86, !tbaa !24
  store i64 %t85, ptr %l11, !tbaa !24
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr %"compiler/free:Free", ptr %t86, i32 0, i32 55
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t88, i64 %t89)
  store i64 %t92, ptr %l90
  br label %bb16
bb16:
  %t93 = load i64, ptr %l90, !tbaa !24
  store i64 %t93, ptr %l12, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l12, !tbaa !24
  %t98 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %s2, ptr %t94, i64 %t95)
  store { i64, ptr } %t98, ptr %l93
  br label %bb17
bb17:
  %t99 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t99, ptr %l13, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/free:walker", ptr %t100, i32 0, i32 6
  %t103 = load i64, ptr %l12, !tbaa !24
  %t106 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t102, i64 %t103)
  store i1 %t106, ptr %l97
  br label %bb18
bb18:
  %t107 = load i1, ptr %l97, !tbaa !21
  br i1 %t107, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l98, !tbaa !29
  %t109 = load i64, ptr %l9, !tbaa !24
  store i64 %t109, ptr %l99, !tbaa !24
  %t110 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t110, ptr %l100, !tbaa !24
  %t111 = load ptr, ptr %l2, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Body", ptr %t111, i32 0, i32 3
  %t114 = load i64, ptr %t113, !tbaa !24
  store i64 %t114, ptr %l102, !tbaa !24
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/free:Free", ptr %t115, i32 0, i32 56
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t117, i64 %t118)
  store %"compiler/source:Span" %t121, ptr %l106
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t122 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t123 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t124 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t126 = extractvalue { i64, ptr } %t122, 1
  %t127 = extractvalue { i64, ptr } %t122, 0
  %t128 = add i64 %t124, %t127
  %t129 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t131 = add i64 %t128, %t130
  %t132 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t131)
  call void @olang_textcopy(ptr %t132, ptr %t123, i64 %t124)
  %t133 = getelementptr i8, ptr %t132, i64 %t124
  call void @olang_textcopy(ptr %t133, ptr %t126, i64 %t127)
  %t134 = getelementptr i8, ptr %t133, i64 %t127
  call void @olang_textcopy(ptr %t134, ptr %t129, i64 %t130)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t132, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } %t136, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load ptr, ptr %l98, !tbaa !29
  %t145 = load i64, ptr %l99, !tbaa !24
  %t146 = load i64, ptr %l100, !tbaa !24
  %t147 = load i64, ptr %l102, !tbaa !24
  %t148 = load %"compiler/source:Span", ptr %l106
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s3, ptr %t144, i64 %t145, i64 %t146, i64 %t147, %"compiler/source:Span" %t148, { i64, ptr } %t143)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/free:walker", ptr %t150, i32 0, i32 7
  %t153 = load i64, ptr %l12, !tbaa !24
  %t156 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t152, i64 %t153)
  store i1 %t156, ptr %l113
  br label %bb24
bb24:
  %t157 = load i1, ptr %l113, !tbaa !21
  br i1 %t157, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l114, !tbaa !29
  %t159 = load i64, ptr %l9, !tbaa !24
  store i64 %t159, ptr %l115, !tbaa !24
  %t160 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t160, ptr %l116, !tbaa !24
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Body", ptr %t161, i32 0, i32 3
  %t164 = load i64, ptr %t163, !tbaa !24
  store i64 %t164, ptr %l118, !tbaa !24
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/free:Free", ptr %t165, i32 0, i32 56
  %t168 = load i64, ptr %l9, !tbaa !24
  %t171 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t167, i64 %t168)
  store %"compiler/source:Span" %t171, ptr %l122
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t172 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t176 = extractvalue { i64, ptr } %t172, 1
  %t177 = extractvalue { i64, ptr } %t172, 0
  %t178 = add i64 %t174, %t177
  %t179 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t181)
  call void @olang_textcopy(ptr %t182, ptr %t173, i64 %t174)
  %t183 = getelementptr i8, ptr %t182, i64 %t174
  call void @olang_textcopy(ptr %t183, ptr %t176, i64 %t177)
  %t184 = getelementptr i8, ptr %t183, i64 %t177
  call void @olang_textcopy(ptr %t184, ptr %t179, i64 %t180)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t182, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = extractvalue { i64, ptr } %t186, 1
  %t190 = mul i64 %t188, 1
  %t191 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t190)
  call void @llvm.memcpy.p0.p0.i64(ptr %t191, ptr %t189, i64 %t190, i1 false)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  %t194 = load ptr, ptr %l114, !tbaa !29
  %t195 = load i64, ptr %l115, !tbaa !24
  %t196 = load i64, ptr %l116, !tbaa !24
  %t197 = load i64, ptr %l118, !tbaa !24
  %t198 = load %"compiler/source:Span", ptr %l122
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s5, ptr %t194, i64 %t195, i64 %t196, i64 %t197, %"compiler/source:Span" %t198, { i64, ptr } %t193)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t200 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t200, ptr %l126
  br label %bb30
bb30:
  %t201 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l126
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t201, ptr %l14
  store i64 0, ptr %l15, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/free:walker", ptr %t202, i32 0, i32 24
  %t206 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t204)
  store i64 %t206, ptr %l129
  br label %bb31
bb31:
  %t207 = load i64, ptr %l129, !tbaa !24
  store i64 %t207, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t208 = load i64, ptr %l16, !tbaa !24
  %t209 = load i64, ptr %l15, !tbaa !24
  %t212 = icmp sgt i64 %t208, %t209
  br i1 %t212, label %bb32, label %bb33
bb32:
  %t214 = load i64, ptr %l17, !tbaa !24
  %t216 = icmp sgt i64 %t214, 0
  br i1 %t216, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb37
bb34:
  %t218 = load i64, ptr %l16, !tbaa !24
  %t219 = load i64, ptr %l15, !tbaa !24
  %t222 = sub i64 %t218, %t219
  %t223 = load i64, ptr %l17, !tbaa !24
  %t226 = add i64 %t222, %t223
  %t228 = sub i64 %t226, 1
  %t229 = load i64, ptr %l17, !tbaa !24
  %t232 = sdiv i64 %t228, %t229
  store i64 %t232, ptr %l136, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb36
bb36:
  %t234 = load i64, ptr %l136, !tbaa !24
  store i64 %t234, ptr %l133, !tbaa !24
  br label %bb37
bb37:
  %t235 = load i64, ptr %l133, !tbaa !24
  store i64 %t235, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb38
bb38:
  %t236 = load i64, ptr %l19, !tbaa !24
  %t237 = load i64, ptr %l18, !tbaa !24
  %t240 = icmp slt i64 %t236, %t237
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb39, label %bb40
bb39:
  br label %bb48
bb40:
  br label %bb41
bb41:
  %t244 = load i64, ptr %l15, !tbaa !24
  %t245 = load i64, ptr %l19, !tbaa !24
  %t246 = load i64, ptr %l17, !tbaa !24
  %t249 = mul i64 %t245, %t246
  %t252 = add i64 %t244, %t249
  store i64 %t252, ptr %l20, !tbaa !24
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/free:walker", ptr %t254, i32 0, i32 24
  %t257 = load i64, ptr %l20, !tbaa !24
  %t260 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t256, i64 %t257)
  store i64 %t260, ptr %l157
  br label %bb42
bb42:
  %t261 = load i64, ptr %l12, !tbaa !24
  %t262 = load i64, ptr %l157, !tbaa !24
  %t264 = icmp eq i64 %t262, %t261
  br i1 %t264, label %bb43, label %bb44
bb43:
  %t266 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s2, ptr %l14, i64 %t266)
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t269 = load i64, ptr %l19, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l19, !tbaa !24
  br label %bb38
bb48:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i64, ptr %l12, !tbaa !24
  %t275 = load i64, ptr %l10, !tbaa !24
  %t276 = load i64, ptr %l11, !tbaa !24
  %t282 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyAfter(ptr %v0, ptr %s2, ptr %t273, i64 %t274, i64 %t275, i64 %t276, ptr %l14)
  store i64 %t282, ptr %l169
  br label %bb49
bb49:
  %t283 = load i64, ptr %l169, !tbaa !24
  store i64 %t283, ptr %l21, !tbaa !24
  %t284 = load i64, ptr %l21, !tbaa !24
  %t286 = icmp sge i64 %t284, 0
  br i1 %t286, label %bb50, label %bb51
bb50:
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = getelementptr %"compiler/free:Free", ptr %t288, i32 0, i32 58
  %t291 = load i64, ptr %l9, !tbaa !24
  %t294 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t290, i64 %t291)
  store i1 %t294, ptr %l176
  br label %bb52
bb51:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb53
bb52:
  %t295 = load i1, ptr %l176, !tbaa !21
  %t296 = xor i1 %t295, true
  store i1 %t296, ptr %l172, !tbaa !21
  br label %bb53
bb53:
  %t298 = load i1, ptr %l172, !tbaa !21
  br i1 %t298, label %bb54, label %bb55
bb54:
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t301 = getelementptr %"compiler/free:Free", ptr %t299, i32 0, i32 58
  %t302 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t301, i64 %t302, i1 true)
  br label %bb56
bb55:
  br label %bb64
bb56:
  %t305 = load ptr, ptr %l1, !tbaa !29
  %t307 = getelementptr %"compiler/free:Free", ptr %t305, i32 0, i32 57
  store ptr %t307, ptr %l182, !tbaa !29
  %t308 = load i64, ptr %l9, !tbaa !24
  store i64 %t308, ptr %l183, !tbaa !24
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/free:walker", ptr %t309, i32 0, i32 26
  %t312 = load i64, ptr %l21, !tbaa !24
  %t315 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t311, i64 %t312)
  store %"compiler/source:Span" %t315, ptr %l187
  br label %bb57
bb57:
  %t316 = load ptr, ptr %l182, !tbaa !29
  %t317 = load i64, ptr %l183, !tbaa !24
  %t318 = load %"compiler/source:Span", ptr %l187
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t316, i64 %t317, %"compiler/source:Span" %t318)
  br label %bb58
bb58:
  %t319 = load ptr, ptr %l1, !tbaa !29
  %t321 = getelementptr %"compiler/free:Free", ptr %t319, i32 0, i32 59
  store ptr %t321, ptr %l189, !tbaa !29
  %t322 = load i64, ptr %l9, !tbaa !24
  store i64 %t322, ptr %l190, !tbaa !24
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/free:walker", ptr %t323, i32 0, i32 25
  %t326 = load i64, ptr %l21, !tbaa !24
  %t329 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t325, i64 %t326)
  store i64 %t329, ptr %l194
  br label %bb59
bb59:
  %t330 = load i64, ptr %l11, !tbaa !24
  %t332 = icmp sge i64 %t330, 0
  br i1 %t332, label %bb60, label %bb61
bb60:
  %t334 = load i64, ptr %l11, !tbaa !24
  store i64 %t334, ptr %l197, !tbaa !24
  br label %bb62
bb61:
  %t336 = load i64, ptr %l10, !tbaa !24
  store i64 %t336, ptr %l197, !tbaa !24
  br label %bb62
bb62:
  %t338 = load i64, ptr %l194, !tbaa !24
  %t339 = load i64, ptr %l197, !tbaa !24
  %t340 = icmp sle i64 %t338, %t339
  %t341 = load ptr, ptr %l189, !tbaa !29
  %t342 = load i64, ptr %l190, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t341, i64 %t342, i1 %t340)
  br label %bb63
bb63:
  br label %bb64
bb64:
  store i64 0, ptr %l22, !tbaa !24
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/free:walker", ptr %t344, i32 0, i32 3
  %t348 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %t346)
  store i64 %t348, ptr %l203
  br label %bb65
bb65:
  %t349 = load i64, ptr %l203, !tbaa !24
  store i64 %t349, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t350 = load i64, ptr %l23, !tbaa !24
  %t351 = load i64, ptr %l22, !tbaa !24
  %t354 = icmp sgt i64 %t350, %t351
  br i1 %t354, label %bb66, label %bb67
bb66:
  %t356 = load i64, ptr %l24, !tbaa !24
  %t358 = icmp sgt i64 %t356, 0
  br i1 %t358, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb71
bb68:
  %t360 = load i64, ptr %l23, !tbaa !24
  %t361 = load i64, ptr %l22, !tbaa !24
  %t364 = sub i64 %t360, %t361
  %t365 = load i64, ptr %l24, !tbaa !24
  %t368 = add i64 %t364, %t365
  %t370 = sub i64 %t368, 1
  %t371 = load i64, ptr %l24, !tbaa !24
  %t374 = sdiv i64 %t370, %t371
  store i64 %t374, ptr %l210, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l210, !tbaa !24
  br label %bb70
bb70:
  %t376 = load i64, ptr %l210, !tbaa !24
  store i64 %t376, ptr %l207, !tbaa !24
  br label %bb71
bb71:
  %t377 = load i64, ptr %l207, !tbaa !24
  store i64 %t377, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s13
  %t378 = load i64, ptr %l26, !tbaa !24
  %t379 = load i64, ptr %l25, !tbaa !24
  %t382 = icmp slt i64 %t378, %t379
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s13)
  br label %bb118
bb74:
  br label %bb75
bb75:
  %t386 = load i64, ptr %l22, !tbaa !24
  %t387 = load i64, ptr %l26, !tbaa !24
  %t388 = load i64, ptr %l24, !tbaa !24
  %t391 = mul i64 %t387, %t388
  %t394 = add i64 %t386, %t391
  store i64 %t394, ptr %l27, !tbaa !24
  %t396 = load i64, ptr %l27, !tbaa !24
  %t397 = load i64, ptr %l12, !tbaa !24
  %t400 = icmp eq i64 %t396, %t397
  br i1 %t400, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l231, !tbaa !21
  br label %bb79
bb77:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/free:walker", ptr %t402, i32 0, i32 6
  %t405 = load i64, ptr %l27, !tbaa !24
  %t408 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t404, i64 %t405)
  store i1 %t408, ptr %l235
  br label %bb78
bb78:
  %t409 = load i1, ptr %l235, !tbaa !21
  store i1 %t409, ptr %l231, !tbaa !21
  br label %bb79
bb79:
  %t410 = load i1, ptr %l231, !tbaa !21
  br i1 %t410, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l236, !tbaa !21
  br label %bb85
bb81:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/free:walker", ptr %t411, i32 0, i32 3
  %t414 = load i64, ptr %l27, !tbaa !24
  %t417 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t413, i64 %t414)
  store ptr %t417, ptr %l240
  br label %bb82
bb82:
  %t418 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t419 = load i64, ptr %l9, !tbaa !24
  %t422 = call i64 @compiler_2ffree_2eorig(i64 %t418, i64 %t419)
  store i64 %t422, ptr %l243
  br label %bb83
bb83:
  %t423 = load ptr, ptr %l240, !tbaa !29
  %t424 = load i64, ptr %l243, !tbaa !24
  %t425 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t423, i64 %t424)
  store i1 %t425, ptr %l244
  br label %bb84
bb84:
  %t426 = load i1, ptr %l244, !tbaa !21
  %t427 = xor i1 %t426, true
  store i1 %t427, ptr %l236, !tbaa !21
  br label %bb85
bb85:
  %t429 = load i1, ptr %l236, !tbaa !21
  br i1 %t429, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s13)
  br label %bb117
bb87:
  br label %bb88
bb88:
  %t430 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s13, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t430, ptr %l246
  br label %bb89
bb89:
  %t431 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l246
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t431, ptr %l28
  store i64 0, ptr %l29, !tbaa !24
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/free:walker", ptr %t432, i32 0, i32 24
  %t436 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t434)
  store i64 %t436, ptr %l249
  br label %bb90
bb90:
  %t437 = load i64, ptr %l249, !tbaa !24
  store i64 %t437, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t438 = load i64, ptr %l30, !tbaa !24
  %t439 = load i64, ptr %l29, !tbaa !24
  %t442 = icmp sgt i64 %t438, %t439
  br i1 %t442, label %bb91, label %bb92
bb91:
  %t444 = load i64, ptr %l31, !tbaa !24
  %t446 = icmp sgt i64 %t444, 0
  br i1 %t446, label %bb93, label %bb94
bb92:
  store i64 0, ptr %l253, !tbaa !24
  br label %bb96
bb93:
  %t448 = load i64, ptr %l30, !tbaa !24
  %t449 = load i64, ptr %l29, !tbaa !24
  %t452 = sub i64 %t448, %t449
  %t453 = load i64, ptr %l31, !tbaa !24
  %t456 = add i64 %t452, %t453
  %t458 = sub i64 %t456, 1
  %t459 = load i64, ptr %l31, !tbaa !24
  %t462 = sdiv i64 %t458, %t459
  store i64 %t462, ptr %l256, !tbaa !24
  br label %bb95
bb94:
  store i64 0, ptr %l256, !tbaa !24
  br label %bb95
bb95:
  %t464 = load i64, ptr %l256, !tbaa !24
  store i64 %t464, ptr %l253, !tbaa !24
  br label %bb96
bb96:
  %t465 = load i64, ptr %l253, !tbaa !24
  store i64 %t465, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb97
bb97:
  %t466 = load i64, ptr %l33, !tbaa !24
  %t467 = load i64, ptr %l32, !tbaa !24
  %t470 = icmp slt i64 %t466, %t467
  %t472 = xor i1 %t470, true
  br i1 %t472, label %bb98, label %bb99
bb98:
  br label %bb107
bb99:
  br label %bb100
bb100:
  %t474 = load i64, ptr %l29, !tbaa !24
  %t475 = load i64, ptr %l33, !tbaa !24
  %t476 = load i64, ptr %l31, !tbaa !24
  %t479 = mul i64 %t475, %t476
  %t482 = add i64 %t474, %t479
  store i64 %t482, ptr %l34, !tbaa !24
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t486 = getelementptr %"compiler/free:walker", ptr %t484, i32 0, i32 24
  %t487 = load i64, ptr %l34, !tbaa !24
  %t490 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t486, i64 %t487)
  store i64 %t490, ptr %l277
  br label %bb101
bb101:
  %t491 = load i64, ptr %l27, !tbaa !24
  %t492 = load i64, ptr %l277, !tbaa !24
  %t494 = icmp eq i64 %t492, %t491
  br i1 %t494, label %bb102, label %bb103
bb102:
  %t496 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s13, ptr %l28, i64 %t496)
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t499 = load i64, ptr %l33, !tbaa !24
  %t501 = add i64 %t499, 1
  store i64 %t501, ptr %l33, !tbaa !24
  br label %bb97
bb107:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load i64, ptr %l27, !tbaa !24
  %t505 = load i64, ptr %l10, !tbaa !24
  %t506 = load i64, ptr %l11, !tbaa !24
  %t512 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyAfter(ptr %v0, ptr %s13, ptr %t503, i64 %t504, i64 %t505, i64 %t506, ptr %l28)
  store i64 %t512, ptr %l289
  br label %bb108
bb108:
  %t513 = load i64, ptr %l289, !tbaa !24
  store i64 %t513, ptr %l35, !tbaa !24
  %t514 = load i64, ptr %l35, !tbaa !24
  %t516 = icmp slt i64 %t514, 0
  br i1 %t516, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s13)
  br label %bb117
bb110:
  br label %bb111
bb111:
  %t518 = load ptr, ptr %l1, !tbaa !29
  %t520 = getelementptr %"compiler/free:Free", ptr %t518, i32 0, i32 0
  %t521 = load ptr, ptr %t520, !tbaa !29
  %t523 = getelementptr %"compiler/generic:Program", ptr %t521, i32 0, i32 0
  %t524 = load ptr, ptr %t523, !tbaa !29
  %t526 = getelementptr %"compiler/load:Loader", ptr %t524, i32 0, i32 4
  %t527 = load ptr, ptr %t526, !tbaa !29
  store ptr %t527, ptr %l295, !tbaa !29
  %t528 = load ptr, ptr %l2, !tbaa !29
  %t530 = getelementptr %"compiler/typed:Body", ptr %t528, i32 0, i32 3
  %t531 = load i64, ptr %t530, !tbaa !24
  store i64 %t531, ptr %l297, !tbaa !24
  %t532 = load ptr, ptr %l2, !tbaa !29
  %t534 = getelementptr %"compiler/typed:Body", ptr %t532, i32 0, i32 7
  %t535 = load i64, ptr %l27, !tbaa !24
  %t538 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t534, i64 %t535)
  store %"compiler/typed:Local" %t538, ptr %l301
  br label %bb112
bb112:
  %t539 = getelementptr %"compiler/typed:Local", ptr %l301, i32 0, i32 1
  %t540 = getelementptr %"compiler/source:Span", ptr %t539, i32 0, i32 0
  %t541 = load i32, ptr %t540, !tbaa !23
  %t543 = sext i32 %t541 to i64
  %t544 = load ptr, ptr %l295, !tbaa !29
  %t545 = load i64, ptr %l297, !tbaa !24
  %t547 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t544, i64 %t545, i64 %t543)
  store i64 %t547, ptr %l304
  br label %bb113
bb113:
  %t548 = load i64, ptr %l304, !tbaa !24
  store i64 %t548, ptr %l36, !tbaa !24
  %t549 = load ptr, ptr %l1, !tbaa !29
  store ptr %t549, ptr %l305, !tbaa !29
  %t550 = load i64, ptr %l9, !tbaa !24
  store i64 %t550, ptr %l306, !tbaa !24
  %t551 = load i64, ptr @G_2ecompiler_2ffree_2eRView, !tbaa !24
  store i64 %t551, ptr %l307, !tbaa !24
  %t552 = load ptr, ptr %l2, !tbaa !29
  %t554 = getelementptr %"compiler/typed:Body", ptr %t552, i32 0, i32 3
  %t555 = load i64, ptr %t554, !tbaa !24
  store i64 %t555, ptr %l309, !tbaa !24
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/free:walker", ptr %t556, i32 0, i32 26
  %t559 = load i64, ptr %l35, !tbaa !24
  %t562 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t558, i64 %t559)
  store %"compiler/source:Span" %t562, ptr %l313
  br label %bb114
bb114:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load i64, ptr %l27, !tbaa !24
  %t567 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %s13, ptr %t563, i64 %t564)
  store { i64, ptr } %t567, ptr %l316
  br label %bb115
bb115:
  %t568 = load i64, ptr %l36, !tbaa !24
  %t569 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t570 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t571 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t572 = load { i64, ptr }, ptr %l316, !tbaa !27
  %t573 = extractvalue { i64, ptr } %t572, 1
  %t574 = extractvalue { i64, ptr } %t572, 0
  %t575 = add i64 %t571, %t574
  %t576 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t577 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t578 = add i64 %t575, %t577
  %t580 = call i64 @__olang_fmt_i64(ptr null, i64 %t568)
  %t581 = add i64 %t578, %t580
  %t582 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t583 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t584 = add i64 %t581, %t583
  %t586 = extractvalue { i64, ptr } %t569, 1
  %t587 = extractvalue { i64, ptr } %t569, 0
  %t588 = add i64 %t584, %t587
  %t589 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t590 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t591 = add i64 %t588, %t590
  %t592 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t591)
  call void @olang_textcopy(ptr %t592, ptr %t570, i64 %t571)
  %t593 = getelementptr i8, ptr %t592, i64 %t571
  call void @olang_textcopy(ptr %t593, ptr %t573, i64 %t574)
  %t594 = getelementptr i8, ptr %t593, i64 %t574
  call void @olang_textcopy(ptr %t594, ptr %t576, i64 %t577)
  %t595 = getelementptr i8, ptr %t594, i64 %t577
  %t596 = call i64 @__olang_fmt_i64(ptr %t595, i64 %t568)
  %t597 = getelementptr i8, ptr %t595, i64 %t580
  call void @olang_textcopy(ptr %t597, ptr %t582, i64 %t583)
  %t598 = getelementptr i8, ptr %t597, i64 %t583
  call void @olang_textcopy(ptr %t598, ptr %t586, i64 %t587)
  %t599 = getelementptr i8, ptr %t598, i64 %t587
  call void @olang_textcopy(ptr %t599, ptr %t589, i64 %t590)
  %t600 = insertvalue { i64, ptr } undef, i64 %t591, 0
  %t601 = insertvalue { i64, ptr } %t600, ptr %t592, 1
  %t603 = extractvalue { i64, ptr } %t601, 0
  %t604 = extractvalue { i64, ptr } %t601, 1
  %t605 = mul i64 %t603, 1
  %t606 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t605)
  call void @llvm.memcpy.p0.p0.i64(ptr %t606, ptr %t604, i64 %t605, i1 false)
  %t607 = insertvalue { i64, ptr } undef, i64 %t603, 0
  %t608 = insertvalue { i64, ptr } %t607, ptr %t606, 1
  %t609 = load ptr, ptr %l305, !tbaa !29
  %t610 = load i64, ptr %l306, !tbaa !24
  %t611 = load i64, ptr %l307, !tbaa !24
  %t612 = load i64, ptr %l309, !tbaa !24
  %t613 = load %"compiler/source:Span", ptr %l313
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s13, ptr %t609, i64 %t610, i64 %t611, i64 %t612, %"compiler/source:Span" %t613, { i64, ptr } %t608)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s13)
  br label %bb117
bb117:
  %t615 = load i64, ptr %l26, !tbaa !24
  %t617 = add i64 %t615, 1
  store i64 %t617, ptr %l26, !tbaa !24
  br label %bb72
bb118:
  %t619 = load i64, ptr %l11, !tbaa !24
  %t621 = icmp sge i64 %t619, 0
  br i1 %t621, label %bb119, label %bb120
bb119:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t625 = getelementptr %"compiler/free:walker", ptr %t623, i32 0, i32 57
  %t626 = load i64, ptr %l11, !tbaa !24
  %t629 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t625, i64 %t626)
  store i1 %t629, ptr %l329
  br label %bb121
bb120:
  store i1 false, ptr %l325, !tbaa !21
  br label %bb122
bb121:
  %t630 = load i1, ptr %l329, !tbaa !21
  %t631 = xor i1 %t630, true
  store i1 %t631, ptr %l325, !tbaa !21
  br label %bb122
bb122:
  %t633 = load i1, ptr %l325, !tbaa !21
  br i1 %t633, label %bb123, label %bb124
bb123:
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t636 = getelementptr %"compiler/free:walker", ptr %t634, i32 0, i32 53
  %t637 = load i64, ptr %l11, !tbaa !24
  %t640 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t636, i64 %t637)
  %t641 = extractvalue { i32, i64 } %t640, 1
  %t642 = extractvalue { i32, i64 } %t640, 0
  store i32 %t642, ptr %l336
  %t643 = icmp ne i32 %t642, 0
  br i1 %t643, label %bb126, label %ok.644
ok.644:
  store i64 %t641, ptr %l335
  br label %bb125
bb124:
  br label %bb159
bb125:
  %t645 = load i64, ptr %l335, !tbaa !24
  store i64 %t645, ptr %l331, !tbaa !24
  br label %bb128
bb126:
  br label %bb127
bb127:
  call void @__olang_ert_req_clear()
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t648 = getelementptr %"compiler/free:walker", ptr %t646, i32 0, i32 11
  %t649 = load i64, ptr %t648, !tbaa !24
  store i64 %t649, ptr %l331, !tbaa !24
  br label %bb128
bb128:
  %t651 = load i64, ptr %l331, !tbaa !24
  store i64 %t651, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t654 = getelementptr %"compiler/free:walker", ptr %t652, i32 0, i32 49
  %t656 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t654)
  store i64 %t656, ptr %l341
  br label %bb129
bb129:
  %t657 = load i64, ptr %l341, !tbaa !24
  store i64 %t657, ptr %l39, !tbaa !24
  store i64 1, ptr %l40, !tbaa !24
  %t658 = load i64, ptr %l39, !tbaa !24
  %t659 = load i64, ptr %l38, !tbaa !24
  %t662 = icmp sgt i64 %t658, %t659
  br i1 %t662, label %bb130, label %bb131
bb130:
  %t664 = load i64, ptr %l40, !tbaa !24
  %t666 = icmp sgt i64 %t664, 0
  br i1 %t666, label %bb132, label %bb133
bb131:
  store i64 0, ptr %l345, !tbaa !24
  br label %bb135
bb132:
  %t668 = load i64, ptr %l39, !tbaa !24
  %t669 = load i64, ptr %l38, !tbaa !24
  %t672 = sub i64 %t668, %t669
  %t673 = load i64, ptr %l40, !tbaa !24
  %t676 = add i64 %t672, %t673
  %t678 = sub i64 %t676, 1
  %t679 = load i64, ptr %l40, !tbaa !24
  %t682 = sdiv i64 %t678, %t679
  store i64 %t682, ptr %l348, !tbaa !24
  br label %bb134
bb133:
  store i64 0, ptr %l348, !tbaa !24
  br label %bb134
bb134:
  %t684 = load i64, ptr %l348, !tbaa !24
  store i64 %t684, ptr %l345, !tbaa !24
  br label %bb135
bb135:
  %t685 = load i64, ptr %l345, !tbaa !24
  store i64 %t685, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  br label %bb136
bb136:
  %t686 = load i64, ptr %l42, !tbaa !24
  %t687 = load i64, ptr %l41, !tbaa !24
  %t690 = icmp slt i64 %t686, %t687
  %t692 = xor i1 %t690, true
  br i1 %t692, label %bb137, label %bb138
bb137:
  br label %bb158
bb138:
  br label %bb139
bb139:
  %t694 = load i64, ptr %l38, !tbaa !24
  %t695 = load i64, ptr %l42, !tbaa !24
  %t696 = load i64, ptr %l40, !tbaa !24
  %t699 = mul i64 %t695, %t696
  %t702 = add i64 %t694, %t699
  store i64 %t702, ptr %l43, !tbaa !24
  %t704 = load ptr, ptr %l0, !tbaa !29
  %t706 = getelementptr %"compiler/free:walker", ptr %t704, i32 0, i32 49
  %t707 = load i64, ptr %l43, !tbaa !24
  %t710 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t706, i64 %t707)
  store i64 %t710, ptr %l369
  br label %bb140
bb140:
  %t711 = load i64, ptr %l9, !tbaa !24
  %t712 = load i64, ptr %l369, !tbaa !24
  %t714 = icmp eq i64 %t712, %t711
  br i1 %t714, label %bb141, label %bb142
bb141:
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t718 = getelementptr %"compiler/free:walker", ptr %t716, i32 0, i32 50
  %t719 = load i64, ptr %l43, !tbaa !24
  %t722 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t718, i64 %t719)
  store i64 %t722, ptr %l376
  br label %bb143
bb142:
  store i1 false, ptr %l372, !tbaa !21
  br label %bb144
bb143:
  %t723 = load i64, ptr %l11, !tbaa !24
  %t724 = load i64, ptr %l376, !tbaa !24
  %t726 = icmp sgt i64 %t724, %t723
  store i1 %t726, ptr %l372, !tbaa !21
  br label %bb144
bb144:
  %t728 = load i1, ptr %l372, !tbaa !21
  br i1 %t728, label %bb145, label %bb146
bb145:
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t731 = getelementptr %"compiler/free:walker", ptr %t729, i32 0, i32 50
  %t732 = load i64, ptr %l43, !tbaa !24
  %t735 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t731, i64 %t732)
  store i64 %t735, ptr %l383
  br label %bb147
bb146:
  store i1 false, ptr %l379, !tbaa !21
  br label %bb148
bb147:
  %t736 = load i64, ptr %l37, !tbaa !24
  %t737 = load i64, ptr %l383, !tbaa !24
  %t739 = icmp sle i64 %t737, %t736
  store i1 %t739, ptr %l379, !tbaa !21
  br label %bb148
bb148:
  %t741 = load i1, ptr %l379, !tbaa !21
  br i1 %t741, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s25
  %t742 = load ptr, ptr %l1, !tbaa !29
  store ptr %t742, ptr %l386, !tbaa !29
  %t743 = load i64, ptr %l9, !tbaa !24
  store i64 %t743, ptr %l387, !tbaa !24
  %t744 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t744, ptr %l388, !tbaa !24
  %t745 = load ptr, ptr %l2, !tbaa !29
  %t747 = getelementptr %"compiler/typed:Body", ptr %t745, i32 0, i32 3
  %t748 = load i64, ptr %t747, !tbaa !24
  store i64 %t748, ptr %l390, !tbaa !24
  %t749 = load ptr, ptr %l1, !tbaa !29
  %t751 = getelementptr %"compiler/free:Free", ptr %t749, i32 0, i32 56
  %t752 = load i64, ptr %l9, !tbaa !24
  %t755 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t751, i64 %t752)
  store %"compiler/source:Span" %t755, ptr %l394
  br label %bb151
bb150:
  br label %bb156
bb151:
  %t756 = load ptr, ptr %l1, !tbaa !29
  %t758 = getelementptr %"compiler/free:Free", ptr %t756, i32 0, i32 0
  %t759 = load ptr, ptr %t758, !tbaa !29
  %t761 = getelementptr %"compiler/generic:Program", ptr %t759, i32 0, i32 0
  %t762 = load ptr, ptr %t761, !tbaa !29
  %t764 = getelementptr %"compiler/load:Loader", ptr %t762, i32 0, i32 4
  %t765 = load ptr, ptr %t764, !tbaa !29
  store ptr %t765, ptr %l398, !tbaa !29
  %t766 = load ptr, ptr %l2, !tbaa !29
  %t768 = getelementptr %"compiler/typed:Body", ptr %t766, i32 0, i32 3
  %t769 = load i64, ptr %t768, !tbaa !24
  store i64 %t769, ptr %l400, !tbaa !24
  %t770 = load ptr, ptr %l0, !tbaa !29
  store ptr %t770, ptr %l401, !tbaa !29
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t773 = getelementptr %"compiler/free:walker", ptr %t771, i32 0, i32 50
  %t774 = load i64, ptr %l43, !tbaa !24
  %t777 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t773, i64 %t774)
  store i64 %t777, ptr %l405
  br label %bb152
bb152:
  %t778 = load ptr, ptr %l401, !tbaa !29
  %t779 = load i64, ptr %l405, !tbaa !24
  %t780 = call %"compiler/source:Span" @compiler_2ffree_2ecompiler_2ffree_3awalker_2euseSpAt(ptr %v0, ptr %t778, i64 %t779)
  store %"compiler/source:Span" %t780, ptr %l406
  br label %bb153
bb153:
  %t781 = getelementptr %"compiler/source:Span", ptr %l406, i32 0, i32 0
  %t782 = load i32, ptr %t781, !tbaa !23
  %t784 = sext i32 %t782 to i64
  %t785 = load ptr, ptr %l398, !tbaa !29
  %t786 = load i64, ptr %l400, !tbaa !24
  %t788 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t785, i64 %t786, i64 %t784)
  store i64 %t788, ptr %l409
  br label %bb154
bb154:
  %t789 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t790 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t791 = load i64, ptr %l409, !tbaa !24
  %t792 = call i64 @__olang_fmt_i64(ptr null, i64 %t791)
  %t793 = add i64 %t790, %t792
  %t794 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t795 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t796 = add i64 %t793, %t795
  %t797 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t796)
  call void @olang_textcopy(ptr %t797, ptr %t789, i64 %t790)
  %t798 = getelementptr i8, ptr %t797, i64 %t790
  %t799 = call i64 @__olang_fmt_i64(ptr %t798, i64 %t791)
  %t800 = getelementptr i8, ptr %t798, i64 %t792
  call void @olang_textcopy(ptr %t800, ptr %t794, i64 %t795)
  %t801 = insertvalue { i64, ptr } undef, i64 %t796, 0
  %t802 = insertvalue { i64, ptr } %t801, ptr %t797, 1
  %t804 = extractvalue { i64, ptr } %t802, 0
  %t805 = extractvalue { i64, ptr } %t802, 1
  %t806 = mul i64 %t804, 1
  %t807 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t806)
  call void @llvm.memcpy.p0.p0.i64(ptr %t807, ptr %t805, i64 %t806, i1 false)
  %t808 = insertvalue { i64, ptr } undef, i64 %t804, 0
  %t809 = insertvalue { i64, ptr } %t808, ptr %t807, 1
  %t810 = load ptr, ptr %l386, !tbaa !29
  %t811 = load i64, ptr %l387, !tbaa !24
  %t812 = load i64, ptr %l388, !tbaa !24
  %t813 = load i64, ptr %l390, !tbaa !24
  %t814 = load %"compiler/source:Span", ptr %l394
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s25, ptr %t810, i64 %t811, i64 %t812, i64 %t813, %"compiler/source:Span" %t814, { i64, ptr } %t809)
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s25)
  br label %bb156
bb156:
  br label %bb157
bb157:
  %t816 = load i64, ptr %l42, !tbaa !24
  %t818 = add i64 %t816, 1
  store i64 %t818, ptr %l42, !tbaa !24
  br label %bb136
bb158:
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s2)
  br label %bb160
bb160:
  %t820 = load i64, ptr %l7, !tbaa !24
  %t822 = add i64 %t820, 1
  store i64 %t822, ptr %l7, !tbaa !24
  br label %bb9
bb161:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i1 %a4, i64 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i64
  %l28 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i64
  %l41 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i1
  %l51 = alloca { i64, ptr }
  %l53 = alloca i64
  %l57 = alloca ptr
  %l59 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l68 = alloca i32
  %l74 = alloca i1
  %l77 = alloca i1
  %l79 = alloca i64
  %l82 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca i1
  %l86 = alloca ptr
  %l88 = alloca i64
  %l89 = alloca i64
  %l91 = alloca ptr
  %l93 = alloca i64
  %l94 = alloca %"compiler/source:Span"
  %l96 = alloca i1
  %l98 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l104 = alloca i64
  %l105 = alloca i64
  %l107 = alloca ptr
  %l109 = alloca i64
  %l110 = alloca %"compiler/source:Span"
  %l112 = alloca i1
  %l114 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  store ptr %a1, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l9, !tbaa !24
  store i64 %t8, ptr %l15, !tbaa !24
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l17
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  %t13 = load i64, ptr %l17, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb67
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l8, !tbaa !29
  %t19 = load i64, ptr %l9, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l22
  br label %bb6
bb6:
  %t23 = load i64, ptr %l22, !tbaa !24
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l10, !tbaa !24
  %t26 = call i64 @compiler_2ffree_2eokind(i64 %t24)
  store i64 %t26, ptr %l24
  br label %bb7
bb7:
  %t27 = load i64, ptr %l24, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  %t28 = load i64, ptr %l11, !tbaa !24
  %t29 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t32 = icmp eq i64 %t28, %t29
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:walker", ptr %t34, i32 0, i32 2
  %t37 = load i1, ptr %t36, !tbaa !21
  %t39 = xor i1 %t37, true
  store i1 %t39, ptr %l28, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb10
bb10:
  %t41 = load i1, ptr %l28, !tbaa !21
  br i1 %t41, label %bb11, label %bb12
bb11:
  %t42 = load i64, ptr %l10, !tbaa !24
  %t44 = call i64 @compiler_2ffree_2eoval(i64 %t42)
  store i64 %t44, ptr %l34
  br label %bb13
bb12:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb14
bb13:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l34, !tbaa !24
  %t48 = icmp ne i64 %t46, %t45
  store i1 %t48, ptr %l32, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l32, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t53 = getelementptr %"compiler/free:Free", ptr %t51, i32 0, i32 22
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/free:walker", ptr %t54, i32 0, i32 1
  %t57 = load i64, ptr %t56, !tbaa !24
  %t60 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t53, i64 %t57)
  store ptr %t60, ptr %l41
  br label %bb17
bb16:
  br label %bb36
bb17:
  %t61 = load i64, ptr %l10, !tbaa !24
  %t63 = call i64 @compiler_2ffree_2eoval(i64 %t61)
  store i64 %t63, ptr %l43
  br label %bb18
bb18:
  %t64 = load ptr, ptr %l41, !tbaa !29
  %t65 = load i64, ptr %l43, !tbaa !24
  %t66 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t64, i64 %t65)
  store i1 %t66, ptr %l44
  br label %bb19
bb19:
  %t67 = load i1, ptr %l44, !tbaa !21
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l7, !tbaa !29
  %t70 = getelementptr %"compiler/free:Free", ptr %t68, i32 0, i32 30
  store i1 true, ptr %t70, !tbaa !21
  %t71 = load ptr, ptr %l7, !tbaa !29
  %t73 = getelementptr %"compiler/free:Free", ptr %t71, i32 0, i32 68
  %t74 = load i1, ptr %t73, !tbaa !21
  br i1 %t74, label %bb22, label %bb23
bb21:
  br label %bb35
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:walker", ptr %t77, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t83 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s5, ptr %t76, i64 %t80)
  store { i64, ptr } %t83, ptr %l51
  br label %bb24
bb23:
  br label %bb34
bb24:
  %t84 = load i64, ptr %l10, !tbaa !24
  %t86 = call i64 @compiler_2ffree_2eoval(i64 %t84)
  store i64 %t86, ptr %l53
  br label %bb25
bb25:
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t89 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/load:Loader", ptr %t93, i32 0, i32 4
  %t96 = load ptr, ptr %t95, !tbaa !29
  store ptr %t96, ptr %l57, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t97)
  store ptr %t99, ptr %l59
  br label %bb26
bb26:
  %t100 = load ptr, ptr %l59, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Body", ptr %t100, i32 0, i32 3
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = sext i32 %t105 to i64
  %t108 = load ptr, ptr %l57, !tbaa !29
  %t111 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s5, ptr %t108, i64 %t103, i64 %t107)
  store { i64, ptr } %t111, ptr %l64
  br label %bb27
bb27:
  %t112 = load i64, ptr %l5, !tbaa !24
  %t113 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t115 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = add i64 %t114, %t117
  %t119 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t121 = add i64 %t118, %t120
  %t122 = load i64, ptr %l53, !tbaa !24
  %t123 = call i64 @__olang_fmt_i64(ptr null, i64 %t122)
  %t124 = add i64 %t121, %t123
  %t125 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t126 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t127 = add i64 %t124, %t126
  %t128 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = add i64 %t127, %t130
  %t132 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t134 = add i64 %t131, %t133
  %t136 = call i64 @__olang_fmt_i64(ptr null, i64 %t112)
  %t137 = add i64 %t134, %t136
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t113, i64 %t114)
  %t142 = getelementptr i8, ptr %t141, i64 %t114
  call void @olang_textcopy(ptr %t142, ptr %t116, i64 %t117)
  %t143 = getelementptr i8, ptr %t142, i64 %t117
  call void @olang_textcopy(ptr %t143, ptr %t119, i64 %t120)
  %t144 = getelementptr i8, ptr %t143, i64 %t120
  %t145 = call i64 @__olang_fmt_i64(ptr %t144, i64 %t122)
  %t146 = getelementptr i8, ptr %t144, i64 %t123
  call void @olang_textcopy(ptr %t146, ptr %t125, i64 %t126)
  %t147 = getelementptr i8, ptr %t146, i64 %t126
  call void @olang_textcopy(ptr %t147, ptr %t129, i64 %t130)
  %t148 = getelementptr i8, ptr %t147, i64 %t130
  call void @olang_textcopy(ptr %t148, ptr %t132, i64 %t133)
  %t149 = getelementptr i8, ptr %t148, i64 %t133
  %t150 = call i64 @__olang_fmt_i64(ptr %t149, i64 %t112)
  %t151 = getelementptr i8, ptr %t149, i64 %t136
  call void @olang_textcopy(ptr %t151, ptr %t138, i64 %t139)
  %t152 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t141, 1
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t156 = extractvalue { i64, ptr } %t153, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t162 = call i32 @std_2fio_2ePrintErr(ptr %s5, { i64, ptr } %t160)
  store i32 %t162, ptr %l68
  %t163 = icmp ne i32 %t162, 0
  br i1 %t163, label %bb29, label %ok.164
ok.164:
  br label %bb28
bb28:
  br label %bb33
bb29:
  %t165 = load i32, ptr %l68, !tbaa !23
  %t166 = ashr i32 %t165, 16
  %t168 = icmp eq i32 %t166, 1
  br i1 %t168, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_5ca0c94719aba3bb_f8486f1b87c86b37)
  unreachable
bb32:
  call void @__olang_ert_req_clear()
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t170 = load i64, ptr %l11, !tbaa !24
  %t171 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t174 = icmp eq i64 %t170, %t171
  br i1 %t174, label %bb37, label %bb38
bb37:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/free:walker", ptr %t176, i32 0, i32 2
  %t179 = load i1, ptr %t178, !tbaa !21
  store i1 %t179, ptr %l74, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb39
bb39:
  %t181 = load i1, ptr %l74, !tbaa !21
  br i1 %t181, label %bb40, label %bb41
bb40:
  %t182 = load i64, ptr %l10, !tbaa !24
  %t184 = call i64 @compiler_2ffree_2eoval(i64 %t182)
  store i64 %t184, ptr %l79
  br label %bb42
bb41:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb43
bb42:
  %t186 = load i64, ptr %l79, !tbaa !24
  %t188 = icmp ne i64 %t186, %a6
  store i1 %t188, ptr %l77, !tbaa !21
  br label %bb43
bb43:
  %t190 = load i1, ptr %l77, !tbaa !21
  br i1 %t190, label %bb44, label %bb45
bb44:
  %t191 = load ptr, ptr %l7, !tbaa !29
  store ptr %t191, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %l10, !tbaa !24
  %t194 = call i64 @compiler_2ffree_2eoval(i64 %t192)
  store i64 %t194, ptr %l84
  br label %bb46
bb45:
  br label %bb65
bb46:
  %t195 = load ptr, ptr %l82, !tbaa !29
  %t196 = load i64, ptr %l84, !tbaa !24
  %t197 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t195, i64 %t196)
  store i1 %t197, ptr %l85
  br label %bb47
bb47:
  %t198 = load i1, ptr %l85, !tbaa !21
  br i1 %t198, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t199 = load ptr, ptr %l7, !tbaa !29
  store ptr %t199, ptr %l86, !tbaa !29
  %t200 = load i64, ptr %l10, !tbaa !24
  %t202 = call i64 @compiler_2ffree_2eoval(i64 %t200)
  store i64 %t202, ptr %l88
  br label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t203 = load ptr, ptr %l7, !tbaa !29
  store ptr %t203, ptr %l102, !tbaa !29
  %t204 = load i64, ptr %l10, !tbaa !24
  %t206 = call i64 @compiler_2ffree_2eoval(i64 %t204)
  store i64 %t206, ptr %l104
  br label %bb57
bb50:
  %t207 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t207, ptr %l89, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t208)
  store ptr %t210, ptr %l91
  br label %bb51
bb51:
  %t211 = load ptr, ptr %l91, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Body", ptr %t211, i32 0, i32 3
  %t214 = load i64, ptr %t213, !tbaa !24
  store i64 %t214, ptr %l93, !tbaa !24
  %t215 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t215, ptr %l94
  %t216 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t218 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s9, { i64, ptr } %t216, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t218, ptr %l96
  br label %bb52
bb52:
  %t219 = load i1, ptr %l96, !tbaa !21
  %t220 = xor i1 %t219, true
  br i1 %t220, label %bb53, label %bb54
bb53:
  %t222 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t223 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t226 = extractvalue { i64, ptr } %t222, 1
  %t227 = extractvalue { i64, ptr } %t222, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t231 = add i64 %t228, %t230
  %t232 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t231)
  call void @olang_textcopy(ptr %t232, ptr %t223, i64 %t224)
  %t233 = getelementptr i8, ptr %t232, i64 %t224
  call void @olang_textcopy(ptr %t233, ptr %t226, i64 %t227)
  %t234 = getelementptr i8, ptr %t233, i64 %t227
  call void @olang_textcopy(ptr %t234, ptr %t229, i64 %t230)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t232, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = extractvalue { i64, ptr } %t236, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l98, !tbaa !27
  br label %bb55
bb54:
  store { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l98, !tbaa !27
  br label %bb55
bb55:
  %t245 = load ptr, ptr %l86, !tbaa !29
  %t246 = load i64, ptr %l88, !tbaa !24
  %t247 = load i64, ptr %l89, !tbaa !24
  %t248 = load i64, ptr %l93, !tbaa !24
  %t249 = load %"compiler/source:Span", ptr %l94
  %t250 = load { i64, ptr }, ptr %l98, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s9, ptr %t245, i64 %t246, i64 %t247, i64 %t248, %"compiler/source:Span" %t249, { i64, ptr } %t250)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb64
bb57:
  %t251 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t251, ptr %l105, !tbaa !24
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t252)
  store ptr %t254, ptr %l107
  br label %bb58
bb58:
  %t255 = load ptr, ptr %l107, !tbaa !29
  %t257 = getelementptr %"compiler/typed:Body", ptr %t255, i32 0, i32 3
  %t258 = load i64, ptr %t257, !tbaa !24
  store i64 %t258, ptr %l109, !tbaa !24
  %t259 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t259, ptr %l110
  %t260 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t262 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s11, { i64, ptr } %t260, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t262, ptr %l112
  br label %bb59
bb59:
  %t263 = load i1, ptr %l112, !tbaa !21
  %t264 = xor i1 %t263, true
  br i1 %t264, label %bb60, label %bb61
bb60:
  %t266 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t267 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t270 = extractvalue { i64, ptr } %t266, 1
  %t271 = extractvalue { i64, ptr } %t266, 0
  %t272 = add i64 %t268, %t271
  %t273 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t274 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t275 = add i64 %t272, %t274
  %t276 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t275)
  call void @olang_textcopy(ptr %t276, ptr %t267, i64 %t268)
  %t277 = getelementptr i8, ptr %t276, i64 %t268
  call void @olang_textcopy(ptr %t277, ptr %t270, i64 %t271)
  %t278 = getelementptr i8, ptr %t277, i64 %t271
  call void @olang_textcopy(ptr %t278, ptr %t273, i64 %t274)
  %t279 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t276, 1
  %t282 = extractvalue { i64, ptr } %t280, 0
  %t283 = extractvalue { i64, ptr } %t280, 1
  %t284 = mul i64 %t282, 1
  %t285 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t284)
  call void @llvm.memcpy.p0.p0.i64(ptr %t285, ptr %t283, i64 %t284, i1 false)
  %t286 = insertvalue { i64, ptr } undef, i64 %t282, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  store { i64, ptr } %t287, ptr %l114, !tbaa !27
  br label %bb62
bb61:
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l114, !tbaa !27
  br label %bb62
bb62:
  %t289 = load ptr, ptr %l102, !tbaa !29
  %t290 = load i64, ptr %l104, !tbaa !24
  %t291 = load i64, ptr %l105, !tbaa !24
  %t292 = load i64, ptr %l109, !tbaa !24
  %t293 = load %"compiler/source:Span", ptr %l110
  %t294 = load { i64, ptr }, ptr %l114, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s11, ptr %t289, i64 %t290, i64 %t291, i64 %t292, %"compiler/source:Span" %t293, { i64, ptr } %t294)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb64
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t295 = load i64, ptr %l9, !tbaa !24
  %t297 = add i64 %t295, 1
  store i64 %t297, ptr %l9, !tbaa !24
  br label %bb1
bb67:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca { i64, ptr }
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i64
  %l65 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca ptr
  %l78 = alloca i1
  %l88 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca ptr
  %l90 = alloca i1
  %l97 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca ptr
  %l99 = alloca i1
  %l109 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l110 = alloca ptr
  %l111 = alloca i1
  %l121 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l122 = alloca ptr
  %l127 = alloca i64
  %l128 = alloca i1
  %l132 = alloca i1
  %l136 = alloca i1
  %l137 = alloca i1
  %l143 = alloca %"compiler/typed:Plan"
  %l144 = alloca { i64, ptr }
  %l149 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i1
  %l168 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l169 = alloca ptr
  %l170 = alloca i1
  %l182 = alloca i1
  %l188 = alloca i1
  %l197 = alloca { i64, ptr }
  %l202 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l207 = alloca i1
  %l214 = alloca ptr
  %l220 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l224 = alloca ptr
  %l229 = alloca i64
  %l230 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca i1
  %l249 = alloca ptr
  %l255 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l257 = alloca ptr
  %l259 = alloca ptr
  %l263 = alloca i32
  %l264 = alloca i64
  %l266 = alloca ptr
  %l267 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l272 = alloca i64
  %l275 = alloca i64
  %l276 = alloca i32
  %l277 = alloca ptr
  %l280 = alloca ptr
  %l281 = alloca i32
  %l282 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l286 = alloca i1
  %l287 = alloca ptr
  %l292 = alloca i64
  %l293 = alloca i1
  %l294 = alloca ptr
  %l295 = alloca i1
  %l307 = alloca { i64, ptr }
  %l310 = alloca ptr
  %l313 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l315 = alloca i1
  %l318 = alloca ptr
  %l319 = alloca i1
  %l324 = alloca ptr
  %l326 = alloca ptr
  %l329 = alloca i32
  %l330 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l334 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l338 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l339 = alloca ptr
  %l340 = alloca i1
  %l348 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l353 = alloca ptr
  %l354 = alloca ptr
  %l360 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l362 = alloca i1
  %l363 = alloca ptr
  %l367 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l369 = alloca i1
  %l370 = alloca ptr
  %l371 = alloca i1
  %l384 = alloca { i64, ptr }
  %l395 = alloca ptr
  %l401 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l402 = alloca ptr
  %l403 = alloca i1
  %l416 = alloca { i64, ptr }
  %l431 = alloca { i64, ptr }
  %l434 = alloca ptr
  %l437 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l439 = alloca i1
  %l446 = alloca ptr
  %l447 = alloca ptr
  %l453 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l455 = alloca i1
  %l456 = alloca ptr
  %l457 = alloca i1
  %l466 = alloca ptr
  %l472 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l481 = alloca { i64, ptr }
  %l488 = alloca ptr
  %l502 = alloca { i64, ptr }
  %l505 = alloca ptr
  %l508 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l510 = alloca i1
  %l515 = alloca ptr
  %l516 = alloca i1
  %l523 = alloca ptr
  %l524 = alloca i1
  %l541 = alloca ptr
  %l544 = alloca i1
  %l550 = alloca i1
  %l562 = alloca { i64, ptr }
  %l568 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l574 = alloca i1
  %l577 = alloca ptr
  %l581 = alloca i64
  %l582 = alloca i1
  %l583 = alloca ptr
  %l584 = alloca i1
  %l600 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l606 = alloca i1
  %l607 = alloca ptr
  %l611 = alloca i64
  %l612 = alloca i1
  %l613 = alloca ptr
  %l614 = alloca i1
  %l627 = alloca { i64, ptr }
  %l630 = alloca ptr
  %l631 = alloca i1
  %l638 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l641 = alloca ptr
  %l646 = alloca i64
  %l647 = alloca i1
  %l648 = alloca ptr
  %l649 = alloca i1
  %l656 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l657 = alloca ptr
  %l659 = alloca i32
  %l660 = alloca i1
  %l662 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s59 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %t159 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l76
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t6 = load ptr, ptr %l77, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l77, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l78, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l78, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t32 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %t26, ptr %t27, i32 %t28)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l88
  br label %bb7
bb7:
  %t33 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  %t34 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t34
  br label %bb331
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t36 = load ptr, ptr %l89, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l89, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 3
  store i1 %t42, ptr %l90, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l90, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l5, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t54 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eborrowOf(ptr %v0, ptr %v1, ptr %v2, ptr %t50, ptr %t51)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %l97
  br label %bb14
bb14:
  %t55 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l97
  %t56 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %t56
  br label %bb331
bb15:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t58 = load ptr, ptr %l98, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t61 = load ptr, ptr %l98, !tbaa !29
  %t62 = load i64, ptr %t61
  %t64 = icmp eq i64 %t62, 4
  store i1 %t64, ptr %l99, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l99, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t68, i32 0, i32 1
  %t70 = load i32, ptr %t69
  store i32 %t70, ptr %l6, !tbaa !23
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l7, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t80 = load i32, ptr %l6, !tbaa !23
  %t84 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etakeOf(ptr %v0, ptr %v1, ptr %v2, ptr %t78, ptr %t79, i32 %t80)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %l109
  br label %bb21
bb21:
  %t85 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  %t86 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %t86
  br label %bb331
bb22:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t88 = load ptr, ptr %l110, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l110, !tbaa !29
  %t92 = load i64, ptr %t91
  %t94 = icmp eq i64 %t92, 5
  store i1 %t94, ptr %l111, !tbaa !21
  br label %bb24
bb24:
  %t95 = load i1, ptr %l111, !tbaa !21
  br i1 %t95, label %bb25, label %bb26
bb25:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t98, i32 0, i32 1
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l8, !tbaa !23
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 2
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l9, !tbaa !29
  br label %bb27
bb26:
  br label %bb44
bb27:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l9, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Promote", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t115 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t108, ptr %t112)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %l121
  br label %bb28
bb28:
  %t116 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l121
  %t117 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %t117
  %t118 = load ptr, ptr %lp2
  store ptr %t118, ptr %l122, !tbaa !29
  %t119 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t120 = load ptr, ptr %l9, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Promote", ptr %t120, i32 0, i32 1
  %t123 = load i32, ptr %t122, !tbaa !23
  %t125 = sext i32 %t123 to i64
  %t128 = call i64 @compiler_2ffree_2eorig(i64 %t119, i64 %t125)
  store i64 %t128, ptr %l127
  br label %bb29
bb29:
  %t129 = load ptr, ptr %l122, !tbaa !29
  %t130 = load i64, ptr %l127, !tbaa !24
  %t131 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t129, i64 %t130)
  store i1 %t131, ptr %l128
  br label %bb30
bb30:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/free:walker", ptr %t132, i32 0, i32 2
  %t135 = load i1, ptr %t134, !tbaa !21
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb31, label %bb32
bb31:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/free:walker", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t143 = load i32, ptr %l8, !tbaa !23
  %t146 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %t142, i32 %t143)
  store i1 %t146, ptr %l136
  br label %bb33
bb32:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb34
bb33:
  %t147 = load i1, ptr %l136, !tbaa !21
  store i1 %t147, ptr %l132, !tbaa !21
  br label %bb34
bb34:
  %t148 = load i1, ptr %l132, !tbaa !21
  br i1 %t148, label %bb35, label %bb36
bb35:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/free:walker", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/free:Free", ptr %t152, i32 0, i32 3
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/free:walker", ptr %t155, i32 0, i32 1
  %t158 = load i64, ptr %t157, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t159, ptr %v0, ptr %v0, ptr %t154, i64 %t158)
  call void @llvm.memmove.p0.p0.i64(ptr %l143, ptr %t159, i64 152, i1 false)
  br label %bb37
bb36:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb39
bb37:
  %t162 = getelementptr %"compiler/typed:Plan", ptr %l143, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l144, !tbaa !27
  %t164 = load ptr, ptr %l9, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Promote", ptr %t164, i32 0, i32 1
  %t167 = load i32, ptr %t166, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t171 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr { i64, [1 x i64] }, ptr %t172, i64 %t169
  %t174 = load { i64, [1 x i64] }, ptr %t173
  %t176 = call i1 @compiler_2ffree_2eisVar({ i64, [1 x i64] } %t174)
  store i1 %t176, ptr %l149
  br label %bb38
bb38:
  %t177 = load i1, ptr %l149, !tbaa !21
  store i1 %t177, ptr %l137, !tbaa !21
  br label %bb39
bb39:
  %t178 = load i1, ptr %l137, !tbaa !21
  br i1 %t178, label %bb40, label %bb41
bb40:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/free:walker", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/free:walker", ptr %t183, i32 0, i32 1
  %t186 = load i64, ptr %t185, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t182, i64 %t186)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb331
bb44:
  %t189 = load ptr, ptr %l1, !tbaa !29
  store ptr %t189, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t190 = load ptr, ptr %l154, !tbaa !29
  %t191 = icmp ne ptr %t190, null
  br i1 %t191, label %bb45, label %bb46
bb45:
  %t193 = load ptr, ptr %l154, !tbaa !29
  %t194 = load i64, ptr %t193
  %t196 = icmp eq i64 %t194, 6
  store i1 %t196, ptr %l155, !tbaa !21
  br label %bb46
bb46:
  %t197 = load i1, ptr %l155, !tbaa !21
  br i1 %t197, label %bb47, label %bb48
bb47:
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr { i64, [5 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t200, i32 0, i32 0
  %t202 = load %"compiler/source:Span", ptr %t201
  store %"compiler/source:Span" %t202, ptr %l10
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr { i64, [5 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t206, i32 0, i32 1
  %t208 = load i32, ptr %t207
  store i32 %t208, ptr %l11, !tbaa !23
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [5 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t212, i32 0, i32 2
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l12, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l12, !tbaa !29
  %t218 = load i32, ptr %l11, !tbaa !23
  %t219 = load %"compiler/source:Span", ptr %l10
  %t224 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %t216, ptr %t217, i32 %t218, %"compiler/source:Span" %t219)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t224, ptr %l168
  br label %bb50
bb50:
  %t225 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l168
  %t226 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t225, ptr %t226
  br label %bb331
bb51:
  %t227 = load ptr, ptr %l1, !tbaa !29
  store ptr %t227, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t228 = load ptr, ptr %l169, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb52, label %bb53
bb52:
  %t231 = load ptr, ptr %l169, !tbaa !29
  %t232 = load i64, ptr %t231
  %t234 = icmp eq i64 %t232, 7
  store i1 %t234, ptr %l170, !tbaa !21
  br label %bb53
bb53:
  %t235 = load i1, ptr %l170, !tbaa !21
  br i1 %t235, label %bb54, label %bb55
bb54:
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t238, i32 0, i32 0
  %t240 = load %"compiler/source:Span", ptr %t239
  store %"compiler/source:Span" %t240, ptr %l13
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = getelementptr { i64, [5 x i64] }, ptr %t242, i32 0, i32 1
  %t245 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t244, i32 0, i32 1
  %t246 = load i32, ptr %t245
  store i32 %t246, ptr %l14, !tbaa !23
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t250, i32 0, i32 2
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l15, !tbaa !29
  br label %bb56
bb55:
  br label %bb85
bb56:
  %t254 = load ptr, ptr %l15, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Make", ptr %t254, i32 0, i32 0
  %t257 = load i32, ptr %t256
  %t259 = trunc i64 3 to i32
  %t260 = icmp eq i32 %t257, %t259
  br i1 %t260, label %bb57, label %bb58
bb57:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/free:walker", ptr %t262, i32 0, i32 0
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = getelementptr %"compiler/free:Free", ptr %t265, i32 0, i32 19
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/free:walker", ptr %t268, i32 0, i32 1
  %t271 = load i64, ptr %t270, !tbaa !24
  %t274 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t267, i64 %t271)
  store i1 %t274, ptr %l188
  br label %bb59
bb58:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb60
bb59:
  %t275 = load i1, ptr %l188, !tbaa !21
  store i1 %t275, ptr %l182, !tbaa !21
  br label %bb60
bb60:
  %t276 = load i1, ptr %l182, !tbaa !21
  store i1 %t276, ptr %l16, !tbaa !21
  %t277 = load ptr, ptr %l15, !tbaa !29
  %t279 = getelementptr %"compiler/typed:Make", ptr %t277, i32 0, i32 2
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t282 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t282, 0
  store i64 %t284, ptr %l19, !tbaa !24
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s9
  %t286 = load i64, ptr %l18, !tbaa !24
  %t287 = load i64, ptr %l19, !tbaa !24
  %t290 = icmp slt i64 %t286, %t287
  %t292 = xor i1 %t290, true
  br i1 %t292, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s9)
  br label %bb71
bb63:
  br label %bb64
bb64:
  %t294 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t294, ptr %l197, !tbaa !27
  %t295 = load i64, ptr %l18, !tbaa !24
  %t297 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = getelementptr ptr, ptr %t298, i64 %t295
  %t300 = load ptr, ptr %t299, !tbaa !39
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t306 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %t302, ptr %t300)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t306, ptr %l202
  br label %bb65
bb65:
  %t307 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l202
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t307, ptr %l21
  %t308 = load i1, ptr %l16, !tbaa !21
  %t310 = xor i1 %t308, true
  br i1 %t310, label %bb66, label %bb67
bb66:
  %t312 = load ptr, ptr %lp2
  %t315 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s9, ptr %t312, ptr %l21)
  store i1 %t315, ptr %l207
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s9)
  br label %bb70
bb70:
  %t316 = load i64, ptr %l18, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l18, !tbaa !24
  br label %bb61
bb71:
  %t320 = load ptr, ptr %l15, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Make", ptr %t320, i32 0, i32 3
  %t323 = load ptr, ptr %t322, !tbaa !29
  %t325 = icmp eq ptr %t323, null
  %t327 = xor i1 %t325, true
  br i1 %t327, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s12
  %t329 = load ptr, ptr %l0, !tbaa !29
  store ptr %t329, ptr %l214, !tbaa !29
  %t330 = load ptr, ptr %l15, !tbaa !29
  %t332 = getelementptr %"compiler/typed:Make", ptr %t330, i32 0, i32 3
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t335 = icmp eq ptr %t333, null
  br i1 %t335, label %bb74, label %bb75
bb73:
  br label %bb78
bb74:
  call void @__olang_check_failed(ptr @olang_loc_dc7e16ca98e3c304_3c9b7555f95fce88)
  unreachable
bb75:
  br label %bb76
bb76:
  %t337 = load ptr, ptr %l15, !tbaa !29
  %t339 = getelementptr %"compiler/typed:Make", ptr %t337, i32 0, i32 3
  %t340 = load ptr, ptr %t339, !tbaa !29
  %t341 = load ptr, ptr %l214, !tbaa !29
  %t343 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s12, ptr %t341, ptr %t340)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t343, ptr %l220
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s12)
  br label %bb78
bb78:
  %t344 = load ptr, ptr %l15, !tbaa !29
  %t346 = getelementptr %"compiler/typed:Make", ptr %t344, i32 0, i32 4
  %t347 = load i32, ptr %t346, !tbaa !23
  %t349 = icmp sge i32 %t347, 0
  br i1 %t349, label %bb79, label %bb80
bb79:
  %t351 = load ptr, ptr %lp2
  store ptr %t351, ptr %l224, !tbaa !29
  %t352 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t353 = load ptr, ptr %l15, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Make", ptr %t353, i32 0, i32 4
  %t356 = load i32, ptr %t355, !tbaa !23
  %t358 = sext i32 %t356 to i64
  %t361 = call i64 @compiler_2ffree_2eorig(i64 %t352, i64 %t358)
  store i64 %t361, ptr %l229
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t362 = load ptr, ptr %l224, !tbaa !29
  %t363 = load i64, ptr %l229, !tbaa !24
  %t364 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t362, i64 %t363)
  store i1 %t364, ptr %l230
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load ptr, ptr %l15, !tbaa !29
  %t367 = load i32, ptr %l14, !tbaa !23
  %t368 = load %"compiler/source:Span", ptr %l13
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeStores(ptr %v0, ptr %v1, ptr %t365, ptr %t366, i32 %t367, %"compiler/source:Span" %t368)
  br label %bb84
bb84:
  br label %bb331
bb85:
  %t373 = load ptr, ptr %l1, !tbaa !29
  store ptr %t373, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t374 = load ptr, ptr %l235, !tbaa !29
  %t375 = icmp ne ptr %t374, null
  br i1 %t375, label %bb86, label %bb87
bb86:
  %t377 = load ptr, ptr %l235, !tbaa !29
  %t378 = load i64, ptr %t377
  %t380 = icmp eq i64 %t378, 8
  store i1 %t380, ptr %l236, !tbaa !21
  br label %bb87
bb87:
  %t381 = load i1, ptr %l236, !tbaa !21
  br i1 %t381, label %bb88, label %bb89
bb88:
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t384 = getelementptr { i64, [5 x i64] }, ptr %t382, i32 0, i32 1
  %t385 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t384, i32 0, i32 0
  %t386 = load %"compiler/source:Span", ptr %t385
  store %"compiler/source:Span" %t386, ptr %l22
  %t388 = load ptr, ptr %l1, !tbaa !29
  %t390 = getelementptr { i64, [5 x i64] }, ptr %t388, i32 0, i32 1
  %t391 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t390, i32 0, i32 1
  %t392 = load i32, ptr %t391
  store i32 %t392, ptr %l23, !tbaa !23
  %t394 = load ptr, ptr %l1, !tbaa !29
  %t396 = getelementptr { i64, [5 x i64] }, ptr %t394, i32 0, i32 1
  %t397 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t396, i32 0, i32 2
  %t398 = load ptr, ptr %t397
  store ptr %t398, ptr %l24, !tbaa !29
  br label %bb90
bb89:
  br label %bb116
bb90:
  %t400 = load ptr, ptr %l24, !tbaa !29
  %t402 = getelementptr %"compiler/typed:Collect", ptr %t400, i32 0, i32 0
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = icmp eq ptr %t403, null
  %t407 = xor i1 %t405, true
  br i1 %t407, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s15
  %t409 = load ptr, ptr %l0, !tbaa !29
  store ptr %t409, ptr %l249, !tbaa !29
  %t410 = load ptr, ptr %l24, !tbaa !29
  %t412 = getelementptr %"compiler/typed:Collect", ptr %t410, i32 0, i32 0
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  br i1 %t415, label %bb93, label %bb94
bb92:
  br label %bb97
bb93:
  call void @__olang_check_failed(ptr @olang_loc_c4f9ad7cc46c30d3_40011a8198a2fca7)
  unreachable
bb94:
  br label %bb95
bb95:
  %t417 = load ptr, ptr %l24, !tbaa !29
  %t419 = getelementptr %"compiler/typed:Collect", ptr %t417, i32 0, i32 0
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t421 = load ptr, ptr %l249, !tbaa !29
  %t423 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s15, ptr %t421, ptr %t420)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t423, ptr %l255
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s15)
  br label %bb97
bb97:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/free:walker", ptr %t424, i32 0, i32 10
  store ptr %t426, ptr %l257, !tbaa !29
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/free:walker", ptr %t427, i32 0, i32 0
  %t430 = load ptr, ptr %t429, !tbaa !29
  store ptr %t430, ptr %l259, !tbaa !29
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/free:walker", ptr %t431, i32 0, i32 0
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t435 = load i32, ptr %l23, !tbaa !23
  %t438 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t434, i32 %t435)
  store i32 %t438, ptr %l263
  br label %bb98
bb98:
  %t439 = load ptr, ptr %l259, !tbaa !29
  %t440 = load i32, ptr %l263, !tbaa !23
  %t441 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t439, i32 %t440, i64 -1)
  store i64 %t441, ptr %l264
  br label %bb99
bb99:
  %t442 = load ptr, ptr %l257, !tbaa !29
  %t443 = load i64, ptr %l264, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t442, i64 %t443)
  br label %bb100
bb100:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/free:walker", ptr %t444, i32 0, i32 32
  store ptr %t446, ptr %l266, !tbaa !29
  %t447 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t447, ptr %l267
  br label %bb101
bb101:
  %t448 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l267
  %t449 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t448, ptr %t449
  %t450 = load ptr, ptr %l266, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t450, ptr %t449)
  br label %bb102
bb102:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t453 = load ptr, ptr %l24, !tbaa !29
  %t455 = getelementptr %"compiler/typed:Collect", ptr %t453, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t452, ptr %t456)
  br label %bb103
bb103:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/free:walker", ptr %t459, i32 0, i32 10
  %t463 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t461)
  %t464 = extractvalue { i32, i64 } %t463, 1
  %t465 = extractvalue { i32, i64 } %t463, 0
  store i32 %t465, ptr %l276
  %t466 = icmp ne i32 %t465, 0
  br i1 %t466, label %bb105, label %ok.467
ok.467:
  store i64 %t464, ptr %l275
  br label %bb104
bb104:
  %t468 = load i64, ptr %l275, !tbaa !24
  store i64 %t468, ptr %l272, !tbaa !24
  br label %bb107
bb105:
  br label %bb106
bb106:
  call void @__olang_ert_req_clear()
  br label %bb107
bb107:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/free:walker", ptr %t469, i32 0, i32 32
  %t473 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H5927ce9e0c48ffa4d9cf1c64f8f12c1b(ptr %v0, ptr %v0, ptr %t471)
  %t474 = extractvalue { i32, ptr } %t473, 1
  %t475 = extractvalue { i32, ptr } %t473, 0
  store i32 %t475, ptr %l281
  %t476 = icmp ne i32 %t475, 0
  br i1 %t476, label %bb109, label %ok.477
ok.477:
  store ptr %t474, ptr %l280
  br label %bb108
bb108:
  %t478 = load ptr, ptr %l280, !tbaa !29
  store ptr %t478, ptr %l277, !tbaa !29
  br label %bb112
bb109:
  br label %bb110
bb110:
  call void @__olang_ert_req_clear()
  %t479 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t479, ptr %l282
  br label %bb111
bb111:
  %t480 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l282
  %t481 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t480, ptr %t481
  store ptr %t481, ptr %l277, !tbaa !29
  br label %bb112
bb112:
  %t483 = load ptr, ptr %l277, !tbaa !29
  %t484 = load ptr, ptr %lp2
  %t488 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %v0, ptr %t484, ptr %t483)
  store i1 %t488, ptr %l286
  br label %bb113
bb113:
  %t489 = load ptr, ptr %lp2
  store ptr %t489, ptr %l287, !tbaa !29
  %t490 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t491 = load ptr, ptr %l24, !tbaa !29
  %t493 = getelementptr %"compiler/typed:Collect", ptr %t491, i32 0, i32 2
  %t494 = load i32, ptr %t493, !tbaa !23
  %t496 = sext i32 %t494 to i64
  %t499 = call i64 @compiler_2ffree_2eorig(i64 %t490, i64 %t496)
  store i64 %t499, ptr %l292
  br label %bb114
bb114:
  %t500 = load ptr, ptr %l287, !tbaa !29
  %t501 = load i64, ptr %l292, !tbaa !24
  %t502 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t500, i64 %t501)
  store i1 %t502, ptr %l293
  br label %bb115
bb115:
  br label %bb331
bb116:
  %t503 = load ptr, ptr %l1, !tbaa !29
  store ptr %t503, ptr %l294, !tbaa !29
  store i1 false, ptr %l295, !tbaa !21
  %t504 = load ptr, ptr %l294, !tbaa !29
  %t505 = icmp ne ptr %t504, null
  br i1 %t505, label %bb117, label %bb118
bb117:
  %t507 = load ptr, ptr %l294, !tbaa !29
  %t508 = load i64, ptr %t507
  %t510 = icmp eq i64 %t508, 9
  store i1 %t510, ptr %l295, !tbaa !21
  br label %bb118
bb118:
  %t511 = load i1, ptr %l295, !tbaa !21
  br i1 %t511, label %bb119, label %bb120
bb119:
  %t512 = load ptr, ptr %l1, !tbaa !29
  %t514 = getelementptr { i64, [5 x i64] }, ptr %t512, i32 0, i32 1
  %t515 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t514, i32 0, i32 4
  %t516 = load { i64, ptr }, ptr %t515
  store { i64, ptr } %t516, ptr %l26, !tbaa !27
  br label %bb121
bb120:
  br label %bb130
bb121:
  %t518 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t518, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t520 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t522 = extractvalue { i64, ptr } %t520, 0
  store i64 %t522, ptr %l29, !tbaa !24
  br label %bb122
bb122:
  store %olang.scope zeroinitializer, ptr %s19
  %t524 = load i64, ptr %l28, !tbaa !24
  %t525 = load i64, ptr %l29, !tbaa !24
  %t528 = icmp slt i64 %t524, %t525
  %t530 = xor i1 %t528, true
  br i1 %t530, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s19)
  br label %bb129
bb124:
  br label %bb125
bb125:
  %t532 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t532, ptr %l307, !tbaa !27
  %t533 = load i64, ptr %l28, !tbaa !24
  %t535 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t536 = load ptr, ptr %t535, !tbaa !27
  %t537 = getelementptr ptr, ptr %t536, i64 %t533
  %t538 = load ptr, ptr %t537, !tbaa !39
  %t540 = load ptr, ptr %lp2
  store ptr %t540, ptr %l310, !tbaa !29
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t545 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s19, ptr %t541, ptr %t538)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t545, ptr %l313
  br label %bb126
bb126:
  %t546 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l313
  %t547 = call ptr @__olang_scope_alloc_a(ptr %s19, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t546, ptr %t547
  %t548 = load ptr, ptr %l310, !tbaa !29
  %t550 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s19, ptr %t548, ptr %t547)
  store i1 %t550, ptr %l315
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s19)
  br label %bb128
bb128:
  %t551 = load i64, ptr %l28, !tbaa !24
  %t553 = add i64 %t551, 1
  store i64 %t553, ptr %l28, !tbaa !24
  br label %bb122
bb129:
  br label %bb331
bb130:
  %t555 = load ptr, ptr %l1, !tbaa !29
  store ptr %t555, ptr %l318, !tbaa !29
  store i1 false, ptr %l319, !tbaa !21
  %t556 = load ptr, ptr %l318, !tbaa !29
  %t557 = icmp ne ptr %t556, null
  br i1 %t557, label %bb131, label %bb132
bb131:
  %t559 = load ptr, ptr %l318, !tbaa !29
  %t560 = load i64, ptr %t559
  %t562 = icmp eq i64 %t560, 10
  store i1 %t562, ptr %l319, !tbaa !21
  br label %bb132
bb132:
  %t563 = load i1, ptr %l319, !tbaa !21
  br i1 %t563, label %bb133, label %bb134
bb133:
  %t564 = load ptr, ptr %l1, !tbaa !29
  %t566 = getelementptr { i64, [5 x i64] }, ptr %t564, i32 0, i32 1
  %t567 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t566, i32 0, i32 2
  %t568 = load ptr, ptr %t567
  store ptr %t568, ptr %l31, !tbaa !29
  br label %bb135
bb134:
  br label %bb140
bb135:
  store %olang.scope zeroinitializer, ptr %s21
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l324, !tbaa !29
  %t571 = load ptr, ptr %l31, !tbaa !29
  %t573 = getelementptr %"compiler/typed:Slice", ptr %t571, i32 0, i32 0
  %t574 = load ptr, ptr %t573, !tbaa !29
  store ptr %t574, ptr %l326, !tbaa !29
  %t575 = load ptr, ptr %l31, !tbaa !29
  %t577 = getelementptr %"compiler/typed:Slice", ptr %t575, i32 0, i32 0
  %t578 = load ptr, ptr %t577, !tbaa !29
  %t580 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t578)
  store i32 %t580, ptr %l329
  br label %bb136
bb136:
  %t581 = load ptr, ptr %l324, !tbaa !29
  %t582 = load ptr, ptr %l326, !tbaa !29
  %t583 = load i32, ptr %l329, !tbaa !23
  %t584 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %t581, ptr %t582, i32 %t583)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t584, ptr %l330
  br label %bb137
bb137:
  %t585 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l330
  %t586 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t585, ptr %t586
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load ptr, ptr %l31, !tbaa !29
  %t590 = getelementptr %"compiler/typed:Slice", ptr %t588, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !29
  %t594 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s21, ptr %t587, ptr %t591)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t594, ptr %l334
  br label %bb138
bb138:
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load ptr, ptr %l31, !tbaa !29
  %t598 = getelementptr %"compiler/typed:Slice", ptr %t596, i32 0, i32 2
  %t599 = load ptr, ptr %t598, !tbaa !29
  %t602 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s21, ptr %t595, ptr %t599)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t602, ptr %l338
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s21)
  br label %bb331
bb140:
  %t603 = load ptr, ptr %l1, !tbaa !29
  store ptr %t603, ptr %l339, !tbaa !29
  store i1 false, ptr %l340, !tbaa !21
  %t604 = load ptr, ptr %l339, !tbaa !29
  %t605 = icmp ne ptr %t604, null
  br i1 %t605, label %bb141, label %bb142
bb141:
  %t607 = load ptr, ptr %l339, !tbaa !29
  %t608 = load i64, ptr %t607
  %t610 = icmp eq i64 %t608, 11
  store i1 %t610, ptr %l340, !tbaa !21
  br label %bb142
bb142:
  %t611 = load i1, ptr %l340, !tbaa !21
  br i1 %t611, label %bb143, label %bb144
bb143:
  %t612 = load ptr, ptr %l1, !tbaa !29
  %t614 = getelementptr { i64, [5 x i64] }, ptr %t612, i32 0, i32 1
  %t615 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t614, i32 0, i32 2
  %t616 = load ptr, ptr %t615
  store ptr %t616, ptr %l32, !tbaa !29
  br label %bb145
bb144:
  br label %bb157
bb145:
  store %olang.scope zeroinitializer, ptr %s22
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t619 = load ptr, ptr %l32, !tbaa !29
  %t621 = getelementptr %"compiler/typed:Cond", ptr %t619, i32 0, i32 0
  %t622 = load ptr, ptr %t621, !tbaa !29
  %t625 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s22, ptr %t618, ptr %t622)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t625, ptr %l348
  br label %bb146
bb146:
  %t626 = load ptr, ptr %l32, !tbaa !29
  %t628 = getelementptr %"compiler/typed:Cond", ptr %t626, i32 0, i32 1
  %t629 = load ptr, ptr %t628, !tbaa !29
  %t631 = icmp eq ptr %t629, null
  %t633 = xor i1 %t631, true
  br i1 %t633, label %bb147, label %bb148
bb147:
  store %olang.scope zeroinitializer, ptr %s23
  %t635 = load ptr, ptr %lp2
  store ptr %t635, ptr %l353, !tbaa !29
  %t636 = load ptr, ptr %l0, !tbaa !29
  store ptr %t636, ptr %l354, !tbaa !29
  %t637 = load ptr, ptr %l32, !tbaa !29
  %t639 = getelementptr %"compiler/typed:Cond", ptr %t637, i32 0, i32 1
  %t640 = load ptr, ptr %t639, !tbaa !29
  %t642 = icmp eq ptr %t640, null
  br i1 %t642, label %bb149, label %bb150
bb148:
  br label %bb154
bb149:
  call void @__olang_check_failed(ptr @olang_loc_fd3298abbcb5ff92_1a857839cb7bbff6)
  unreachable
bb150:
  br label %bb151
bb151:
  %t644 = load ptr, ptr %l32, !tbaa !29
  %t646 = getelementptr %"compiler/typed:Cond", ptr %t644, i32 0, i32 1
  %t647 = load ptr, ptr %t646, !tbaa !29
  %t648 = load ptr, ptr %l354, !tbaa !29
  %t650 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s23, ptr %t648, ptr %t647)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t650, ptr %l360
  br label %bb152
bb152:
  %t651 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l360
  %t652 = call ptr @__olang_scope_alloc_a(ptr %s23, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t651, ptr %t652
  %t653 = load ptr, ptr %l353, !tbaa !29
  %t655 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s23, ptr %t653, ptr %t652)
  store i1 %t655, ptr %l362
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s23)
  br label %bb154
bb154:
  %t656 = load ptr, ptr %lp2
  store ptr %t656, ptr %l363, !tbaa !29
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load ptr, ptr %l32, !tbaa !29
  %t660 = getelementptr %"compiler/typed:Cond", ptr %t658, i32 0, i32 2
  %t661 = load ptr, ptr %t660, !tbaa !29
  %t664 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s22, ptr %t657, ptr %t661)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t664, ptr %l367
  br label %bb155
bb155:
  %t665 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l367
  %t666 = call ptr @__olang_scope_alloc_a(ptr %s22, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t665, ptr %t666
  %t667 = load ptr, ptr %l363, !tbaa !29
  %t669 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s22, ptr %t667, ptr %t666)
  store i1 %t669, ptr %l369
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s22)
  br label %bb331
bb157:
  %t670 = load ptr, ptr %l1, !tbaa !29
  store ptr %t670, ptr %l370, !tbaa !29
  store i1 false, ptr %l371, !tbaa !21
  %t671 = load ptr, ptr %l370, !tbaa !29
  %t672 = icmp ne ptr %t671, null
  br i1 %t672, label %bb158, label %bb159
bb158:
  %t674 = load ptr, ptr %l370, !tbaa !29
  %t675 = load i64, ptr %t674
  %t677 = icmp eq i64 %t675, 12
  store i1 %t677, ptr %l371, !tbaa !21
  br label %bb159
bb159:
  %t678 = load i1, ptr %l371, !tbaa !21
  br i1 %t678, label %bb160, label %bb161
bb160:
  %t679 = load ptr, ptr %l1, !tbaa !29
  %t681 = getelementptr { i64, [5 x i64] }, ptr %t679, i32 0, i32 1
  %t682 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t681, i32 0, i32 2
  %t683 = load ptr, ptr %t682
  store ptr %t683, ptr %l33, !tbaa !29
  br label %bb162
bb161:
  br label %bb177
bb162:
  %t685 = load ptr, ptr %l33, !tbaa !29
  %t687 = getelementptr %"compiler/typed:Seq", ptr %t685, i32 0, i32 0
  %t688 = load { i64, ptr }, ptr %t687, !tbaa !27
  store { i64, ptr } %t688, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t690 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t692 = extractvalue { i64, ptr } %t690, 0
  store i64 %t692, ptr %l36, !tbaa !24
  br label %bb163
bb163:
  %t694 = load i64, ptr %l35, !tbaa !24
  %t695 = load i64, ptr %l36, !tbaa !24
  %t698 = icmp slt i64 %t694, %t695
  %t700 = xor i1 %t698, true
  br i1 %t700, label %bb164, label %bb165
bb164:
  br label %bb169
bb165:
  br label %bb166
bb166:
  %t702 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t702, ptr %l384, !tbaa !27
  %t703 = load i64, ptr %l35, !tbaa !24
  %t705 = getelementptr { i64, ptr }, ptr %l384, i32 0, i32 1
  %t706 = load ptr, ptr %t705, !tbaa !27
  %t707 = getelementptr ptr, ptr %t706, i64 %t703
  %t708 = load ptr, ptr %t707, !tbaa !39
  %t710 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %t710, ptr %t708)
  br label %bb167
bb167:
  br label %bb168
bb168:
  %t714 = load i64, ptr %l35, !tbaa !24
  %t716 = add i64 %t714, 1
  store i64 %t716, ptr %l35, !tbaa !24
  br label %bb163
bb169:
  %t718 = load ptr, ptr %l33, !tbaa !29
  %t720 = getelementptr %"compiler/typed:Seq", ptr %t718, i32 0, i32 1
  %t721 = load ptr, ptr %t720, !tbaa !29
  %t723 = icmp eq ptr %t721, null
  %t725 = xor i1 %t723, true
  br i1 %t725, label %bb170, label %bb171
bb170:
  %t727 = load ptr, ptr %l0, !tbaa !29
  store ptr %t727, ptr %l395, !tbaa !29
  %t728 = load ptr, ptr %l33, !tbaa !29
  %t730 = getelementptr %"compiler/typed:Seq", ptr %t728, i32 0, i32 1
  %t731 = load ptr, ptr %t730, !tbaa !29
  %t733 = icmp eq ptr %t731, null
  br i1 %t733, label %bb172, label %bb173
bb171:
  br label %bb176
bb172:
  call void @__olang_check_failed(ptr @olang_loc_5a2a443e2f2f03b9_3064adab7524445d)
  unreachable
bb173:
  br label %bb174
bb174:
  %t735 = load ptr, ptr %l33, !tbaa !29
  %t737 = getelementptr %"compiler/typed:Seq", ptr %t735, i32 0, i32 1
  %t738 = load ptr, ptr %t737, !tbaa !29
  %t739 = load ptr, ptr %l395, !tbaa !29
  %t741 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t739, ptr %t738)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t741, ptr %l401
  br label %bb175
bb175:
  %t742 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l401
  %t743 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t742, ptr %t743
  br label %bb176
bb176:
  br label %bb331
bb177:
  %t744 = load ptr, ptr %l1, !tbaa !29
  store ptr %t744, ptr %l402, !tbaa !29
  store i1 false, ptr %l403, !tbaa !21
  %t745 = load ptr, ptr %l402, !tbaa !29
  %t746 = icmp ne ptr %t745, null
  br i1 %t746, label %bb178, label %bb179
bb178:
  %t748 = load ptr, ptr %l402, !tbaa !29
  %t749 = load i64, ptr %t748
  %t751 = icmp eq i64 %t749, 13
  store i1 %t751, ptr %l403, !tbaa !21
  br label %bb179
bb179:
  %t752 = load i1, ptr %l403, !tbaa !21
  br i1 %t752, label %bb180, label %bb181
bb180:
  %t753 = load ptr, ptr %l1, !tbaa !29
  %t755 = getelementptr { i64, [5 x i64] }, ptr %t753, i32 0, i32 1
  %t756 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t755, i32 0, i32 2
  %t757 = load ptr, ptr %t756
  store ptr %t757, ptr %l38, !tbaa !29
  br label %bb182
bb181:
  br label %bb206
bb182:
  %t759 = load ptr, ptr %l38, !tbaa !29
  %t761 = getelementptr %"compiler/typed:Match", ptr %t759, i32 0, i32 0
  %t762 = load { i64, ptr }, ptr %t761, !tbaa !27
  store { i64, ptr } %t762, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t764 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t766 = extractvalue { i64, ptr } %t764, 0
  store i64 %t766, ptr %l41, !tbaa !24
  br label %bb183
bb183:
  %t768 = load i64, ptr %l40, !tbaa !24
  %t769 = load i64, ptr %l41, !tbaa !24
  %t772 = icmp slt i64 %t768, %t769
  %t774 = xor i1 %t772, true
  br i1 %t774, label %bb184, label %bb185
bb184:
  br label %bb189
bb185:
  br label %bb186
bb186:
  %t776 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t776, ptr %l416, !tbaa !27
  %t777 = load i64, ptr %l40, !tbaa !24
  %t779 = getelementptr { i64, ptr }, ptr %l416, i32 0, i32 1
  %t780 = load ptr, ptr %t779, !tbaa !27
  %t781 = getelementptr ptr, ptr %t780, i64 %t777
  %t782 = load ptr, ptr %t781, !tbaa !39
  %t784 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %t784, ptr %t782)
  br label %bb187
bb187:
  br label %bb188
bb188:
  %t788 = load i64, ptr %l40, !tbaa !24
  %t790 = add i64 %t788, 1
  store i64 %t790, ptr %l40, !tbaa !24
  br label %bb183
bb189:
  %t792 = load ptr, ptr %l38, !tbaa !29
  %t794 = getelementptr %"compiler/typed:Match", ptr %t792, i32 0, i32 1
  %t795 = load { i64, ptr }, ptr %t794, !tbaa !27
  store { i64, ptr } %t795, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t797 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t799 = extractvalue { i64, ptr } %t797, 0
  store i64 %t799, ptr %l45, !tbaa !24
  br label %bb190
bb190:
  store %olang.scope zeroinitializer, ptr %s34
  %t801 = load i64, ptr %l44, !tbaa !24
  %t802 = load i64, ptr %l45, !tbaa !24
  %t805 = icmp slt i64 %t801, %t802
  %t807 = xor i1 %t805, true
  br i1 %t807, label %bb191, label %bb192
bb191:
  call void @__olang_scope_close(ptr %s34)
  br label %bb197
bb192:
  br label %bb193
bb193:
  %t809 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t809, ptr %l431, !tbaa !27
  %t810 = load i64, ptr %l44, !tbaa !24
  %t812 = getelementptr { i64, ptr }, ptr %l431, i32 0, i32 1
  %t813 = load ptr, ptr %t812, !tbaa !27
  %t814 = getelementptr ptr, ptr %t813, i64 %t810
  %t815 = load ptr, ptr %t814, !tbaa !39
  %t817 = load ptr, ptr %lp2
  store ptr %t817, ptr %l434, !tbaa !29
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t822 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %s34, ptr %t818, ptr %t815)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t822, ptr %l437
  br label %bb194
bb194:
  %t823 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l437
  %t824 = call ptr @__olang_scope_alloc_a(ptr %s34, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t823, ptr %t824
  %t825 = load ptr, ptr %l434, !tbaa !29
  %t827 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s34, ptr %t825, ptr %t824)
  store i1 %t827, ptr %l439
  br label %bb195
bb195:
  call void @__olang_scope_close(ptr %s34)
  br label %bb196
bb196:
  %t828 = load i64, ptr %l44, !tbaa !24
  %t830 = add i64 %t828, 1
  store i64 %t830, ptr %l44, !tbaa !24
  br label %bb190
bb197:
  %t832 = load ptr, ptr %l38, !tbaa !29
  %t834 = getelementptr %"compiler/typed:Match", ptr %t832, i32 0, i32 2
  %t835 = load ptr, ptr %t834, !tbaa !29
  %t837 = icmp eq ptr %t835, null
  %t839 = xor i1 %t837, true
  br i1 %t839, label %bb198, label %bb199
bb198:
  store %olang.scope zeroinitializer, ptr %s36
  %t841 = load ptr, ptr %lp2
  store ptr %t841, ptr %l446, !tbaa !29
  %t842 = load ptr, ptr %l0, !tbaa !29
  store ptr %t842, ptr %l447, !tbaa !29
  %t843 = load ptr, ptr %l38, !tbaa !29
  %t845 = getelementptr %"compiler/typed:Match", ptr %t843, i32 0, i32 2
  %t846 = load ptr, ptr %t845, !tbaa !29
  %t848 = icmp eq ptr %t846, null
  br i1 %t848, label %bb200, label %bb201
bb199:
  br label %bb205
bb200:
  call void @__olang_check_failed(ptr @olang_loc_f2df24d87159f740_3aba0f93d819cd0c)
  unreachable
bb201:
  br label %bb202
bb202:
  %t850 = load ptr, ptr %l38, !tbaa !29
  %t852 = getelementptr %"compiler/typed:Match", ptr %t850, i32 0, i32 2
  %t853 = load ptr, ptr %t852, !tbaa !29
  %t854 = load ptr, ptr %l447, !tbaa !29
  %t856 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %s36, ptr %t854, ptr %t853)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t856, ptr %l453
  br label %bb203
bb203:
  %t857 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l453
  %t858 = call ptr @__olang_scope_alloc_a(ptr %s36, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t857, ptr %t858
  %t859 = load ptr, ptr %l446, !tbaa !29
  %t861 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s36, ptr %t859, ptr %t858)
  store i1 %t861, ptr %l455
  br label %bb204
bb204:
  call void @__olang_scope_close(ptr %s36)
  br label %bb205
bb205:
  br label %bb331
bb206:
  %t862 = load ptr, ptr %l1, !tbaa !29
  store ptr %t862, ptr %l456, !tbaa !29
  store i1 false, ptr %l457, !tbaa !21
  %t863 = load ptr, ptr %l456, !tbaa !29
  %t864 = icmp ne ptr %t863, null
  br i1 %t864, label %bb207, label %bb208
bb207:
  %t866 = load ptr, ptr %l456, !tbaa !29
  %t867 = load i64, ptr %t866
  %t869 = icmp eq i64 %t867, 14
  store i1 %t869, ptr %l457, !tbaa !21
  br label %bb208
bb208:
  %t870 = load i1, ptr %l457, !tbaa !21
  br i1 %t870, label %bb209, label %bb210
bb209:
  %t871 = load ptr, ptr %l1, !tbaa !29
  %t873 = getelementptr { i64, [5 x i64] }, ptr %t871, i32 0, i32 1
  %t874 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t873, i32 0, i32 2
  %t875 = load ptr, ptr %t874
  store ptr %t875, ptr %l47, !tbaa !29
  br label %bb211
bb210:
  br label %bb240
bb211:
  %t877 = load ptr, ptr %l47, !tbaa !29
  %t879 = getelementptr %"compiler/typed:Try", ptr %t877, i32 0, i32 0
  %t880 = load ptr, ptr %t879, !tbaa !29
  %t882 = icmp eq ptr %t880, null
  %t884 = xor i1 %t882, true
  br i1 %t884, label %bb212, label %bb213
bb212:
  %t886 = load ptr, ptr %l0, !tbaa !29
  store ptr %t886, ptr %l466, !tbaa !29
  %t887 = load ptr, ptr %l47, !tbaa !29
  %t889 = getelementptr %"compiler/typed:Try", ptr %t887, i32 0, i32 0
  %t890 = load ptr, ptr %t889, !tbaa !29
  %t892 = icmp eq ptr %t890, null
  br i1 %t892, label %bb214, label %bb215
bb213:
  br label %bb218
bb214:
  call void @__olang_check_failed(ptr @olang_loc_e2fb89bbcc8912df_b34dca3bd4e44f7b)
  unreachable
bb215:
  br label %bb216
bb216:
  %t894 = load ptr, ptr %l47, !tbaa !29
  %t896 = getelementptr %"compiler/typed:Try", ptr %t894, i32 0, i32 0
  %t897 = load ptr, ptr %t896, !tbaa !29
  %t898 = load ptr, ptr %l466, !tbaa !29
  %t900 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t898, ptr %t897)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t900, ptr %l472
  br label %bb217
bb217:
  %t901 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l472
  %t902 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t901, ptr %t902
  br label %bb218
bb218:
  %t903 = load ptr, ptr %l47, !tbaa !29
  %t905 = getelementptr %"compiler/typed:Try", ptr %t903, i32 0, i32 1
  %t906 = load { i64, ptr }, ptr %t905, !tbaa !27
  store { i64, ptr } %t906, ptr %l48, !tbaa !27
  store i64 0, ptr %l49, !tbaa !24
  %t908 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t910 = extractvalue { i64, ptr } %t908, 0
  store i64 %t910, ptr %l50, !tbaa !24
  br label %bb219
bb219:
  %t912 = load i64, ptr %l49, !tbaa !24
  %t913 = load i64, ptr %l50, !tbaa !24
  %t916 = icmp slt i64 %t912, %t913
  %t918 = xor i1 %t916, true
  br i1 %t918, label %bb220, label %bb221
bb220:
  br label %bb239
bb221:
  br label %bb222
bb222:
  %t920 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t920, ptr %l481, !tbaa !27
  %t921 = load i64, ptr %l49, !tbaa !24
  %t923 = getelementptr { i64, ptr }, ptr %l481, i32 0, i32 1
  %t924 = load ptr, ptr %t923, !tbaa !27
  %t925 = getelementptr ptr, ptr %t924, i64 %t921
  %t926 = load ptr, ptr %t925, !tbaa !39
  store ptr %t926, ptr %l51, !tbaa !29
  %t928 = load ptr, ptr %l51, !tbaa !29
  %t930 = getelementptr %"compiler/typed:Clause", ptr %t928, i32 0, i32 3
  %t931 = load ptr, ptr %t930, !tbaa !29
  %t933 = icmp eq ptr %t931, null
  %t935 = xor i1 %t933, true
  br i1 %t935, label %bb223, label %bb224
bb223:
  %t937 = load ptr, ptr %l0, !tbaa !29
  store ptr %t937, ptr %l488, !tbaa !29
  %t938 = load ptr, ptr %l51, !tbaa !29
  %t940 = getelementptr %"compiler/typed:Clause", ptr %t938, i32 0, i32 3
  %t941 = load ptr, ptr %t940, !tbaa !29
  %t943 = icmp eq ptr %t941, null
  br i1 %t943, label %bb225, label %bb226
bb224:
  br label %bb229
bb225:
  call void @__olang_check_failed(ptr @olang_loc_b9d8fe51bd9fb1ae_e9263c049ba8f2ba)
  unreachable
bb226:
  br label %bb227
bb227:
  %t945 = load ptr, ptr %l51, !tbaa !29
  %t947 = getelementptr %"compiler/typed:Clause", ptr %t945, i32 0, i32 3
  %t948 = load ptr, ptr %t947, !tbaa !29
  %t949 = load ptr, ptr %l488, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t949, ptr %t948)
  br label %bb228
bb228:
  br label %bb229
bb229:
  %t951 = load ptr, ptr %l51, !tbaa !29
  %t953 = getelementptr %"compiler/typed:Clause", ptr %t951, i32 0, i32 4
  %t954 = load { i64, ptr }, ptr %t953, !tbaa !27
  store { i64, ptr } %t954, ptr %l52, !tbaa !27
  store i64 0, ptr %l53, !tbaa !24
  %t956 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t958 = extractvalue { i64, ptr } %t956, 0
  store i64 %t958, ptr %l54, !tbaa !24
  br label %bb230
bb230:
  store %olang.scope zeroinitializer, ptr %s43
  %t960 = load i64, ptr %l53, !tbaa !24
  %t961 = load i64, ptr %l54, !tbaa !24
  %t964 = icmp slt i64 %t960, %t961
  %t966 = xor i1 %t964, true
  br i1 %t966, label %bb231, label %bb232
bb231:
  call void @__olang_scope_close(ptr %s43)
  br label %bb237
bb232:
  br label %bb233
bb233:
  %t968 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t968, ptr %l502, !tbaa !27
  %t969 = load i64, ptr %l53, !tbaa !24
  %t971 = getelementptr { i64, ptr }, ptr %l502, i32 0, i32 1
  %t972 = load ptr, ptr %t971, !tbaa !27
  %t973 = getelementptr ptr, ptr %t972, i64 %t969
  %t974 = load ptr, ptr %t973, !tbaa !39
  %t976 = load ptr, ptr %lp2
  store ptr %t976, ptr %l505, !tbaa !29
  %t977 = load ptr, ptr %l0, !tbaa !29
  %t981 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s43, ptr %t977, ptr %t974)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t981, ptr %l508
  br label %bb234
bb234:
  %t982 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l508
  %t983 = call ptr @__olang_scope_alloc_a(ptr %s43, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t982, ptr %t983
  %t984 = load ptr, ptr %l505, !tbaa !29
  %t986 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s43, ptr %t984, ptr %t983)
  store i1 %t986, ptr %l510
  br label %bb235
bb235:
  call void @__olang_scope_close(ptr %s43)
  br label %bb236
bb236:
  %t987 = load i64, ptr %l53, !tbaa !24
  %t989 = add i64 %t987, 1
  store i64 %t989, ptr %l53, !tbaa !24
  br label %bb230
bb237:
  br label %bb238
bb238:
  %t991 = load i64, ptr %l49, !tbaa !24
  %t993 = add i64 %t991, 1
  store i64 %t993, ptr %l49, !tbaa !24
  br label %bb219
bb239:
  br label %bb331
bb240:
  %t995 = load ptr, ptr %l1, !tbaa !29
  store ptr %t995, ptr %l515, !tbaa !29
  store i1 false, ptr %l516, !tbaa !21
  %t996 = load ptr, ptr %l515, !tbaa !29
  %t997 = icmp ne ptr %t996, null
  br i1 %t997, label %bb241, label %bb242
bb241:
  %t999 = load ptr, ptr %l515, !tbaa !29
  %t1000 = load i64, ptr %t999
  %t1002 = icmp eq i64 %t1000, 15
  store i1 %t1002, ptr %l516, !tbaa !21
  br label %bb242
bb242:
  %t1003 = load i1, ptr %l516, !tbaa !21
  br i1 %t1003, label %bb243, label %bb244
bb243:
  %t1004 = load ptr, ptr %l1, !tbaa !29
  %t1006 = getelementptr { i64, [5 x i64] }, ptr %t1004, i32 0, i32 1
  %t1007 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1006, i32 0, i32 0
  %t1008 = load %"compiler/source:Span", ptr %t1007
  store %"compiler/source:Span" %t1008, ptr %l56
  %t1010 = load ptr, ptr %l1, !tbaa !29
  %t1012 = getelementptr { i64, [5 x i64] }, ptr %t1010, i32 0, i32 1
  %t1013 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1012, i32 0, i32 2
  %t1014 = load ptr, ptr %t1013
  store ptr %t1014, ptr %l57, !tbaa !29
  br label %bb245
bb244:
  br label %bb293
bb245:
  %t1016 = load ptr, ptr %l57, !tbaa !29
  store ptr %t1016, ptr %l523, !tbaa !29
  store i1 false, ptr %l524, !tbaa !21
  %t1017 = load ptr, ptr %l523, !tbaa !29
  %t1018 = icmp ne ptr %t1017, null
  br i1 %t1018, label %bb246, label %bb247
bb246:
  %t1020 = load ptr, ptr %l523, !tbaa !29
  %t1021 = load i64, ptr %t1020
  %t1023 = icmp eq i64 %t1021, 1
  store i1 %t1023, ptr %l524, !tbaa !21
  br label %bb247
bb247:
  %t1024 = load i1, ptr %l524, !tbaa !21
  br i1 %t1024, label %bb248, label %bb249
bb248:
  %t1025 = load ptr, ptr %l57, !tbaa !29
  %t1027 = getelementptr { i64, [4 x i64] }, ptr %t1025, i32 0, i32 1
  %t1028 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t1027, i32 0, i32 0
  %t1029 = load i32, ptr %t1028
  store i32 %t1029, ptr %l58, !tbaa !23
  %t1031 = load ptr, ptr %l57, !tbaa !29
  %t1033 = getelementptr { i64, [4 x i64] }, ptr %t1031, i32 0, i32 1
  %t1034 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t1033, i32 0, i32 1
  %t1035 = load { i64, ptr }, ptr %t1034
  store { i64, ptr } %t1035, ptr %l59, !tbaa !27
  %t1037 = load ptr, ptr %l57, !tbaa !29
  %t1039 = getelementptr { i64, [4 x i64] }, ptr %t1037, i32 0, i32 1
  %t1040 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t1039, i32 0, i32 2
  %t1041 = load i32, ptr %t1040
  store i32 %t1041, ptr %l60, !tbaa !23
  br label %bb250
bb249:
  br label %bb272
bb250:
  %t1043 = load ptr, ptr %l0, !tbaa !29
  %t1045 = getelementptr %"compiler/free:walker", ptr %t1043, i32 0, i32 2
  %t1046 = load i1, ptr %t1045, !tbaa !21
  %t1048 = xor i1 %t1046, true
  br i1 %t1048, label %bb251, label %bb252
bb251:
  %t1050 = load ptr, ptr %l0, !tbaa !29
  %t1052 = getelementptr %"compiler/free:walker", ptr %t1050, i32 0, i32 0
  %t1053 = load ptr, ptr %t1052, !tbaa !29
  %t1055 = getelementptr %"compiler/free:Free", ptr %t1053, i32 0, i32 48
  %t1056 = load i32, ptr %l58, !tbaa !23
  %t1058 = sext i32 %t1056 to i64
  %t1061 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t1055, i64 %t1058)
  store ptr %t1061, ptr %l541
  br label %bb253
bb252:
  br label %bb260
bb253:
  %t1062 = load ptr, ptr %l0, !tbaa !29
  %t1064 = getelementptr %"compiler/free:walker", ptr %t1062, i32 0, i32 1
  %t1065 = load i64, ptr %t1064, !tbaa !24
  %t1066 = load ptr, ptr %l541, !tbaa !29
  %t1068 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t1066, i64 %t1065)
  store i1 %t1068, ptr %l544
  br label %bb254
bb254:
  %t1069 = load ptr, ptr %l0, !tbaa !29
  %t1071 = getelementptr %"compiler/free:walker", ptr %t1069, i32 0, i32 0
  %t1072 = load ptr, ptr %t1071, !tbaa !29
  %t1074 = getelementptr %"compiler/free:Free", ptr %t1072, i32 0, i32 28
  %t1075 = load i32, ptr %l58, !tbaa !23
  %t1077 = sext i32 %t1075 to i64
  %t1080 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1074, i64 %t1077)
  store i1 %t1080, ptr %l550
  br label %bb255
bb255:
  %t1081 = load i1, ptr %l550, !tbaa !21
  br i1 %t1081, label %bb256, label %bb257
bb256:
  %t1082 = load ptr, ptr %l0, !tbaa !29
  %t1084 = getelementptr %"compiler/free:walker", ptr %t1082, i32 0, i32 0
  %t1085 = load ptr, ptr %t1084, !tbaa !29
  %t1086 = load ptr, ptr %l0, !tbaa !29
  %t1088 = getelementptr %"compiler/free:walker", ptr %t1086, i32 0, i32 1
  %t1089 = load i64, ptr %t1088, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t1085, i64 %t1089)
  br label %bb258
bb257:
  br label %bb259
bb258:
  br label %bb259
bb259:
  br label %bb260
bb260:
  %t1092 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t1092, ptr %l61, !tbaa !27
  store i64 0, ptr %l62, !tbaa !24
  %t1094 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t1096 = extractvalue { i64, ptr } %t1094, 0
  store i64 %t1096, ptr %l63, !tbaa !24
  br label %bb261
bb261:
  store %olang.scope zeroinitializer, ptr %s51
  %t1098 = load i64, ptr %l62, !tbaa !24
  %t1099 = load i64, ptr %l63, !tbaa !24
  %t1102 = icmp slt i64 %t1098, %t1099
  %t1104 = xor i1 %t1102, true
  br i1 %t1104, label %bb262, label %bb263
bb262:
  call void @__olang_scope_close(ptr %s51)
  br label %bb269
bb263:
  br label %bb264
bb264:
  %t1106 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1106, ptr %l562, !tbaa !27
  %t1107 = load i64, ptr %l62, !tbaa !24
  %t1109 = getelementptr { i64, ptr }, ptr %l562, i32 0, i32 1
  %t1110 = load ptr, ptr %t1109, !tbaa !27
  %t1111 = getelementptr ptr, ptr %t1110, i64 %t1107
  %t1112 = load ptr, ptr %t1111, !tbaa !39
  %t1114 = load ptr, ptr %l0, !tbaa !29
  %t1117 = getelementptr %"compiler/typed:Capture", ptr %t1112, i32 0, i32 1
  %t1118 = load ptr, ptr %t1117, !tbaa !29
  %t1121 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s51, ptr %t1114, ptr %t1118)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1121, ptr %l568
  br label %bb265
bb265:
  %t1122 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l568
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1122, ptr %l65
  %t1123 = load ptr, ptr %l0, !tbaa !29
  %t1124 = load %"compiler/source:Span", ptr %l56
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s51, ptr %s51, ptr %t1123, ptr %l65, %"compiler/source:Span" %t1124, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb266
bb266:
  %t1128 = load ptr, ptr %lp2
  %t1131 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s51, ptr %t1128, ptr %l65)
  store i1 %t1131, ptr %l574
  br label %bb267
bb267:
  call void @__olang_scope_close(ptr %s51)
  br label %bb268
bb268:
  %t1132 = load i64, ptr %l62, !tbaa !24
  %t1134 = add i64 %t1132, 1
  store i64 %t1134, ptr %l62, !tbaa !24
  br label %bb261
bb269:
  %t1136 = load ptr, ptr %lp2
  store ptr %t1136, ptr %l577, !tbaa !29
  %t1137 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t1138 = load i32, ptr %l60, !tbaa !23
  %t1140 = sext i32 %t1138 to i64
  %t1143 = call i64 @compiler_2ffree_2eorig(i64 %t1137, i64 %t1140)
  store i64 %t1143, ptr %l581
  br label %bb270
bb270:
  %t1144 = load ptr, ptr %l577, !tbaa !29
  %t1145 = load i64, ptr %l581, !tbaa !24
  %t1146 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t1144, i64 %t1145)
  store i1 %t1146, ptr %l582
  br label %bb271
bb271:
  br label %bb292
bb272:
  %t1147 = load ptr, ptr %l57, !tbaa !29
  store ptr %t1147, ptr %l583, !tbaa !29
  store i1 false, ptr %l584, !tbaa !21
  %t1148 = load ptr, ptr %l583, !tbaa !29
  %t1149 = icmp ne ptr %t1148, null
  br i1 %t1149, label %bb273, label %bb274
bb273:
  %t1151 = load ptr, ptr %l583, !tbaa !29
  %t1152 = load i64, ptr %t1151
  %t1154 = icmp eq i64 %t1152, 2
  store i1 %t1154, ptr %l584, !tbaa !21
  br label %bb274
bb274:
  %t1155 = load i1, ptr %l584, !tbaa !21
  br i1 %t1155, label %bb275, label %bb276
bb275:
  %t1156 = load ptr, ptr %l57, !tbaa !29
  %t1158 = getelementptr { i64, [4 x i64] }, ptr %t1156, i32 0, i32 1
  %t1159 = getelementptr { i32, ptr, i32 }, ptr %t1158, i32 0, i32 1
  %t1160 = load ptr, ptr %t1159
  store ptr %t1160, ptr %l66, !tbaa !29
  %t1162 = load ptr, ptr %l57, !tbaa !29
  %t1164 = getelementptr { i64, [4 x i64] }, ptr %t1162, i32 0, i32 1
  %t1165 = getelementptr { i32, ptr, i32 }, ptr %t1164, i32 0, i32 2
  %t1166 = load i32, ptr %t1165
  store i32 %t1166, ptr %l67, !tbaa !23
  br label %bb277
bb276:
  br label %bb287
bb277:
  store %olang.scope zeroinitializer, ptr %s53
  %t1168 = load ptr, ptr %l0, !tbaa !29
  %t1170 = getelementptr %"compiler/free:walker", ptr %t1168, i32 0, i32 2
  %t1171 = load i1, ptr %t1170, !tbaa !21
  %t1173 = xor i1 %t1171, true
  br i1 %t1173, label %bb278, label %bb279
bb278:
  %t1175 = load ptr, ptr %l0, !tbaa !29
  %t1177 = getelementptr %"compiler/free:walker", ptr %t1175, i32 0, i32 0
  %t1178 = load ptr, ptr %t1177, !tbaa !29
  %t1179 = load ptr, ptr %l0, !tbaa !29
  %t1181 = getelementptr %"compiler/free:walker", ptr %t1179, i32 0, i32 1
  %t1182 = load i64, ptr %t1181, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t1178, i64 %t1182)
  br label %bb280
bb279:
  br label %bb281
bb280:
  br label %bb281
bb281:
  %t1185 = load ptr, ptr %l0, !tbaa !29
  %t1186 = load ptr, ptr %l66, !tbaa !29
  %t1189 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s53, ptr %t1185, ptr %t1186)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1189, ptr %l600
  br label %bb282
bb282:
  %t1190 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l600
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1190, ptr %l68
  %t1191 = load ptr, ptr %l0, !tbaa !29
  %t1192 = load %"compiler/source:Span", ptr %l56
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s53, ptr %s53, ptr %t1191, ptr %l68, %"compiler/source:Span" %t1192, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb283
bb283:
  %t1196 = load ptr, ptr %lp2
  %t1199 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s53, ptr %t1196, ptr %l68)
  store i1 %t1199, ptr %l606
  br label %bb284
bb284:
  %t1200 = load ptr, ptr %lp2
  store ptr %t1200, ptr %l607, !tbaa !29
  %t1201 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t1202 = load i32, ptr %l67, !tbaa !23
  %t1204 = sext i32 %t1202 to i64
  %t1207 = call i64 @compiler_2ffree_2eorig(i64 %t1201, i64 %t1204)
  store i64 %t1207, ptr %l611
  br label %bb285
bb285:
  %t1208 = load ptr, ptr %l607, !tbaa !29
  %t1209 = load i64, ptr %l611, !tbaa !24
  %t1210 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t1208, i64 %t1209)
  store i1 %t1210, ptr %l612
  br label %bb286
bb286:
  call void @__olang_scope_close(ptr %s53)
  br label %bb292
bb287:
  br i1 true, label %bb288, label %bb289
bb288:
  br label %bb290
bb289:
  br label %bb291
bb290:
  br label %bb292
bb291:
  call void @__olang_check_failed(ptr @olang_loc_67165cb650ae48c_1f30efdb88316bc8)
  unreachable
bb292:
  br label %bb331
bb293:
  %t1211 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1211, ptr %l613, !tbaa !29
  store i1 false, ptr %l614, !tbaa !21
  %t1212 = load ptr, ptr %l613, !tbaa !29
  %t1213 = icmp ne ptr %t1212, null
  br i1 %t1213, label %bb294, label %bb295
bb294:
  %t1215 = load ptr, ptr %l613, !tbaa !29
  %t1216 = load i64, ptr %t1215
  %t1218 = icmp eq i64 %t1216, 16
  store i1 %t1218, ptr %l614, !tbaa !21
  br label %bb295
bb295:
  %t1219 = load i1, ptr %l614, !tbaa !21
  br i1 %t1219, label %bb296, label %bb297
bb296:
  %t1220 = load ptr, ptr %l1, !tbaa !29
  %t1222 = getelementptr { i64, [5 x i64] }, ptr %t1220, i32 0, i32 1
  %t1223 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1222, i32 0, i32 2
  %t1224 = load ptr, ptr %t1223
  store ptr %t1224, ptr %l69, !tbaa !29
  br label %bb298
bb297:
  br label %bb319
bb298:
  %t1226 = load ptr, ptr %l69, !tbaa !29
  %t1228 = getelementptr %"compiler/typed:Text", ptr %t1226, i32 0, i32 0
  %t1229 = load { i64, ptr }, ptr %t1228, !tbaa !27
  store { i64, ptr } %t1229, ptr %l70, !tbaa !27
  store i64 0, ptr %l71, !tbaa !24
  %t1231 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t1233 = extractvalue { i64, ptr } %t1231, 0
  store i64 %t1233, ptr %l72, !tbaa !24
  br label %bb299
bb299:
  %t1235 = load i64, ptr %l71, !tbaa !24
  %t1236 = load i64, ptr %l72, !tbaa !24
  %t1239 = icmp slt i64 %t1235, %t1236
  %t1241 = xor i1 %t1239, true
  br i1 %t1241, label %bb300, label %bb301
bb300:
  br label %bb316
bb301:
  br label %bb302
bb302:
  %t1243 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t1243, ptr %l627, !tbaa !27
  %t1244 = load i64, ptr %l71, !tbaa !24
  %t1246 = getelementptr { i64, ptr }, ptr %l627, i32 0, i32 1
  %t1247 = load ptr, ptr %t1246, !tbaa !27
  %t1248 = getelementptr ptr, ptr %t1247, i64 %t1244
  %t1249 = load ptr, ptr %t1248, !tbaa !39
  store ptr %t1249, ptr %l73, !tbaa !29
  %t1251 = load ptr, ptr %l73, !tbaa !29
  store ptr %t1251, ptr %l630, !tbaa !29
  store i1 false, ptr %l631, !tbaa !21
  %t1252 = load ptr, ptr %l630, !tbaa !29
  %t1253 = icmp ne ptr %t1252, null
  br i1 %t1253, label %bb303, label %bb304
bb303:
  %t1255 = load ptr, ptr %l630, !tbaa !29
  %t1256 = load i64, ptr %t1255
  %t1258 = icmp eq i64 %t1256, 1
  store i1 %t1258, ptr %l631, !tbaa !21
  br label %bb304
bb304:
  %t1259 = load i1, ptr %l631, !tbaa !21
  br i1 %t1259, label %bb305, label %bb306
bb305:
  %t1260 = load ptr, ptr %l73, !tbaa !29
  %t1262 = getelementptr { i64, [2 x i64] }, ptr %t1260, i32 0, i32 1
  %t1263 = getelementptr { ptr }, ptr %t1262, i32 0, i32 0
  %t1264 = load ptr, ptr %t1263
  store ptr %t1264, ptr %l74, !tbaa !29
  br label %bb307
bb306:
  br label %bb309
bb307:
  store %olang.scope zeroinitializer, ptr %s59
  %t1266 = load ptr, ptr %l0, !tbaa !29
  %t1267 = load ptr, ptr %l74, !tbaa !29
  %t1270 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s59, ptr %t1266, ptr %t1267)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1270, ptr %l638
  br label %bb308
bb308:
  call void @__olang_scope_close(ptr %s59)
  br label %bb314
bb309:
  br i1 true, label %bb310, label %bb311
bb310:
  br label %bb312
bb311:
  br label %bb313
bb312:
  br label %bb314
bb313:
  call void @__olang_check_failed(ptr @olang_loc_b6b576316e1b3293_3c9a5af727622297)
  unreachable
bb314:
  br label %bb315
bb315:
  %t1271 = load i64, ptr %l71, !tbaa !24
  %t1273 = add i64 %t1271, 1
  store i64 %t1273, ptr %l71, !tbaa !24
  br label %bb299
bb316:
  %t1275 = load ptr, ptr %lp2
  store ptr %t1275, ptr %l641, !tbaa !29
  %t1276 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t1277 = load ptr, ptr %l69, !tbaa !29
  %t1279 = getelementptr %"compiler/typed:Text", ptr %t1277, i32 0, i32 1
  %t1280 = load i32, ptr %t1279, !tbaa !23
  %t1282 = sext i32 %t1280 to i64
  %t1285 = call i64 @compiler_2ffree_2eorig(i64 %t1276, i64 %t1282)
  store i64 %t1285, ptr %l646
  br label %bb317
bb317:
  %t1286 = load ptr, ptr %l641, !tbaa !29
  %t1287 = load i64, ptr %l646, !tbaa !24
  %t1288 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t1286, i64 %t1287)
  store i1 %t1288, ptr %l647
  br label %bb318
bb318:
  br label %bb331
bb319:
  %t1289 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1289, ptr %l648, !tbaa !29
  store i1 false, ptr %l649, !tbaa !21
  %t1290 = load ptr, ptr %l648, !tbaa !29
  %t1291 = icmp ne ptr %t1290, null
  br i1 %t1291, label %bb320, label %bb321
bb320:
  %t1293 = load ptr, ptr %l648, !tbaa !29
  %t1294 = load i64, ptr %t1293
  %t1296 = icmp eq i64 %t1294, 17
  store i1 %t1296, ptr %l649, !tbaa !21
  br label %bb321
bb321:
  %t1297 = load i1, ptr %l649, !tbaa !21
  br i1 %t1297, label %bb322, label %bb323
bb322:
  %t1298 = load ptr, ptr %l1, !tbaa !29
  %t1300 = getelementptr { i64, [5 x i64] }, ptr %t1298, i32 0, i32 1
  %t1301 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1300, i32 0, i32 2
  %t1302 = load ptr, ptr %t1301
  store ptr %t1302, ptr %l75, !tbaa !29
  br label %bb324
bb323:
  br label %bb326
bb324:
  %t1304 = load ptr, ptr %l0, !tbaa !29
  %t1305 = load ptr, ptr %l75, !tbaa !29
  %t1308 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t1304, ptr %t1305)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1308, ptr %l656
  br label %bb325
bb325:
  %t1309 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l656
  %t1310 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1309, ptr %t1310
  br label %bb331
bb326:
  br i1 true, label %bb327, label %bb328
bb327:
  br label %bb329
bb328:
  br label %bb330
bb329:
  br label %bb331
bb330:
  call void @__olang_check_failed(ptr @olang_loc_797639ecae530892_5422fc7df8fd29f6)
  unreachable
bb331:
  %t1311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1311, ptr %l657, !tbaa !29
  %t1312 = load ptr, ptr %l1, !tbaa !29
  %t1314 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1312)
  store i32 %t1314, ptr %l659
  br label %bb332
bb332:
  %t1315 = load ptr, ptr %l657, !tbaa !29
  %t1316 = load i32, ptr %l659, !tbaa !23
  %t1317 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %t1315, i32 %t1316)
  store i1 %t1317, ptr %l660
  br label %bb333
bb333:
  %t1318 = load i1, ptr %l660, !tbaa !21
  %t1319 = xor i1 %t1318, true
  br i1 %t1319, label %bb334, label %bb335
bb334:
  %t1321 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1321, ptr %l662
  br label %bb336
bb335:
  br label %bb337
bb336:
  %t1322 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l662
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1322, ptr %rv
  br label %ret
bb337:
  %t1323 = load ptr, ptr %lp2
  %t1324 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1323
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1324, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, { i64, ptr } }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, { i64, ptr } }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca { i64, ptr }
  %l58 = alloca { i64, { i64, ptr } }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, { i64, ptr } }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca i64
  %l88 = alloca i1
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, { i64, ptr } }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l107 = alloca { i64, { i64, ptr } }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l114 = alloca i64
  %l120 = alloca { i64, ptr }
  %l122 = alloca { i64, { i64, ptr } }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l134 = alloca { i64, { i64, ptr } }
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca { i64, ptr }
  %l141 = alloca i64
  %l144 = alloca i1
  %l150 = alloca i1
  %l151 = alloca i64
  %l154 = alloca i64
  %l159 = alloca ptr
  %l161 = alloca ptr
  %l165 = alloca i32
  %l167 = alloca %"compiler/typed:Local"
  %l169 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l180 = alloca %"compiler/source:Span"
  %l183 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l196 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l203 = alloca { i64, { i64, ptr } }
  %l204 = alloca { i64, ptr }
  %l205 = alloca i64
  %l206 = alloca { i64, ptr }
  %l210 = alloca i1
  %l214 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l222 = alloca { i64, { i64, ptr } }
  %l223 = alloca { i64, ptr }
  %l224 = alloca i64
  %l225 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l228 = alloca { i64, { i64, ptr } }
  %l229 = alloca { i64, ptr }
  %l230 = alloca i64
  %l231 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l16
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l16, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t11 = load ptr, ptr %l17, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l17, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 5
  store i1 %t17, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l18, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Promote", ptr %t25, i32 0, i32 1
  %t28 = load i32, ptr %t27, !tbaa !23
  %t30 = sext i32 %t28 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t33 = insertvalue { i64, { i64, ptr } } undef, i64 %t30, 0
  %t35 = insertvalue { i64, { i64, ptr } } %t33, { i64, ptr } %t31, 1
  store { i64, { i64, ptr } } %t35, ptr %l28
  %t36 = getelementptr { i64, { i64, ptr } }, ptr %l28, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l29, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l30, !tbaa !24
  %t40 = load i64, ptr %l30, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l30, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t52 = getelementptr { i64, { i64, ptr } }, ptr %l28, i32 0, i32 1
  store { i64, ptr } %t51, ptr %t52, !tbaa !27
  %t53 = load { i64, { i64, ptr } }, ptr %l28
  store { i64, { i64, ptr } } %t53, ptr %rv
  br label %ret
bb7:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb8, label %bb9
bb8:
  %t58 = load ptr, ptr %l32, !tbaa !29
  %t59 = load i64, ptr %t58
  %t61 = icmp eq i64 %t59, 7
  store i1 %t61, ptr %l33, !tbaa !21
  br label %bb9
bb9:
  %t62 = load i1, ptr %l33, !tbaa !21
  br i1 %t62, label %bb10, label %bb11
bb10:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Make", ptr %t69, i32 0, i32 4
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = sext i32 %t72 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = insertvalue { i64, { i64, ptr } } undef, i64 %t74, 0
  %t79 = insertvalue { i64, { i64, ptr } } %t77, { i64, ptr } %t75, 1
  store { i64, { i64, ptr } } %t79, ptr %l43
  %t80 = getelementptr { i64, { i64, ptr } }, ptr %l43, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l44, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l45, !tbaa !24
  %t84 = load i64, ptr %l45, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l46, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l45, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t96 = getelementptr { i64, { i64, ptr } }, ptr %l43, i32 0, i32 1
  store { i64, ptr } %t95, ptr %t96, !tbaa !27
  %t97 = load { i64, { i64, ptr } }, ptr %l43
  store { i64, { i64, ptr } } %t97, ptr %rv
  br label %ret
bb13:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t99 = load ptr, ptr %l47, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb14, label %bb15
bb14:
  %t102 = load ptr, ptr %l47, !tbaa !29
  %t103 = load i64, ptr %t102
  %t105 = icmp eq i64 %t103, 16
  store i1 %t105, ptr %l48, !tbaa !21
  br label %bb15
bb15:
  %t106 = load i1, ptr %l48, !tbaa !21
  br i1 %t106, label %bb16, label %bb17
bb16:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l6, !tbaa !29
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Text", ptr %t113, i32 0, i32 1
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = sext i32 %t116 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l56, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t121 = insertvalue { i64, { i64, ptr } } undef, i64 %t118, 0
  %t123 = insertvalue { i64, { i64, ptr } } %t121, { i64, ptr } %t119, 1
  store { i64, { i64, ptr } } %t123, ptr %l58
  %t124 = getelementptr { i64, { i64, ptr } }, ptr %l58, i32 0, i32 1
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l59, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l60, !tbaa !24
  %t128 = load i64, ptr %l60, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l61, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l60, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t140 = getelementptr { i64, { i64, ptr } }, ptr %l58, i32 0, i32 1
  store { i64, ptr } %t139, ptr %t140, !tbaa !27
  %t141 = load { i64, { i64, ptr } }, ptr %l58
  store { i64, { i64, ptr } } %t141, ptr %rv
  br label %ret
bb19:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t143 = load ptr, ptr %l62, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb20, label %bb21
bb20:
  %t146 = load ptr, ptr %l62, !tbaa !29
  %t147 = load i64, ptr %t146
  %t149 = icmp eq i64 %t147, 8
  store i1 %t149, ptr %l63, !tbaa !21
  br label %bb21
bb21:
  %t150 = load i1, ptr %l63, !tbaa !21
  br i1 %t150, label %bb22, label %bb23
bb22:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l7, !tbaa !29
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Collect", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %t159, !tbaa !23
  %t162 = sext i32 %t160 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l71, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t165 = insertvalue { i64, { i64, ptr } } undef, i64 %t162, 0
  %t167 = insertvalue { i64, { i64, ptr } } %t165, { i64, ptr } %t163, 1
  store { i64, { i64, ptr } } %t167, ptr %l73
  %t168 = getelementptr { i64, { i64, ptr } }, ptr %l73, i32 0, i32 1
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l74, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l75, !tbaa !24
  %t172 = load i64, ptr %l75, !tbaa !24
  %t173 = mul i64 %t172, 1
  %t174 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t173)
  %t175 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l76, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l75, !tbaa !24
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  %t183 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t184 = getelementptr { i64, { i64, ptr } }, ptr %l73, i32 0, i32 1
  store { i64, ptr } %t183, ptr %t184, !tbaa !27
  %t185 = load { i64, { i64, ptr } }, ptr %l73
  store { i64, { i64, ptr } } %t185, ptr %rv
  br label %ret
bb25:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t187 = load ptr, ptr %l77, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb26, label %bb27
bb26:
  %t190 = load ptr, ptr %l77, !tbaa !29
  %t191 = load i64, ptr %t190
  %t193 = icmp eq i64 %t191, 6
  store i1 %t193, ptr %l78, !tbaa !21
  br label %bb27
bb27:
  %t194 = load i1, ptr %l78, !tbaa !21
  br i1 %t194, label %bb28, label %bb29
bb28:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t197, i32 0, i32 2
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l8, !tbaa !29
  br label %bb30
bb29:
  br label %bb78
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t201 = load ptr, ptr %l2, !tbaa !29
  %t202 = load ptr, ptr %l8, !tbaa !29
  %t205 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t201, ptr %t202)
  store i64 %t205, ptr %l85
  br label %bb31
bb31:
  %t206 = load i64, ptr %l85, !tbaa !24
  store i64 %t206, ptr %l9, !tbaa !24
  %t207 = load i64, ptr %l9, !tbaa !24
  %t209 = icmp slt i64 %t207, 0
  br i1 %t209, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb34
bb33:
  %t211 = load ptr, ptr %l8, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Call", ptr %t211, i32 0, i32 3
  %t214 = load i32, ptr %t213, !tbaa !23
  %t216 = icmp slt i32 %t214, 0
  store i1 %t216, ptr %l88, !tbaa !21
  br label %bb34
bb34:
  %t218 = load i1, ptr %l88, !tbaa !21
  br i1 %t218, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l92, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t220 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t222 = insertvalue { i64, { i64, ptr } } %t220, { i64, ptr } %t219, 1
  store { i64, { i64, ptr } } %t222, ptr %l94
  %t223 = getelementptr { i64, { i64, ptr } }, ptr %l94, i32 0, i32 1
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  store { i64, ptr } %t224, ptr %l95, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  store i64 %t226, ptr %l96, !tbaa !24
  %t227 = load i64, ptr %l96, !tbaa !24
  %t228 = mul i64 %t227, 1
  %t229 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t228)
  %t230 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l97, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l96, !tbaa !24
  %t237 = mul i64 %t236, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t233, ptr %t235, i64 %t237, i1 false)
  %t238 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t239 = getelementptr { i64, { i64, ptr } }, ptr %l94, i32 0, i32 1
  store { i64, ptr } %t238, ptr %t239, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t240 = load { i64, { i64, ptr } }, ptr %l94
  store { i64, { i64, ptr } } %t240, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t241 = load ptr, ptr %l2, !tbaa !29
  %t243 = getelementptr %"compiler/free:Free", ptr %t241, i32 0, i32 1
  %t244 = load i64, ptr %l9, !tbaa !24
  %t247 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t243, i64 %t244)
  store ptr %t247, ptr %l101
  br label %bb38
bb38:
  %t248 = load ptr, ptr %l101, !tbaa !29
  store ptr %t248, ptr %l10, !tbaa !29
  %t249 = load ptr, ptr %l10, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Body", ptr %t249, i32 0, i32 11
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = icmp eq ptr %t252, null
  br i1 %t254, label %bb39, label %bb40
bb39:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l105, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t257 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t259 = insertvalue { i64, { i64, ptr } } %t257, { i64, ptr } %t256, 1
  store { i64, { i64, ptr } } %t259, ptr %l107
  %t260 = getelementptr { i64, { i64, ptr } }, ptr %l107, i32 0, i32 1
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  store { i64, ptr } %t261, ptr %l108, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  store i64 %t263, ptr %l109, !tbaa !24
  %t264 = load i64, ptr %l109, !tbaa !24
  %t265 = mul i64 %t264, 1
  %t266 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t265)
  %t267 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l110, !tbaa !27
  %t269 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = load i64, ptr %l109, !tbaa !24
  %t274 = mul i64 %t273, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t270, ptr %t272, i64 %t274, i1 false)
  %t275 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t276 = getelementptr { i64, { i64, ptr } }, ptr %l107, i32 0, i32 1
  store { i64, ptr } %t275, ptr %t276, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t277 = load { i64, { i64, ptr } }, ptr %l107
  store { i64, { i64, ptr } } %t277, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t278 = load ptr, ptr %l3, !tbaa !29
  %t279 = load ptr, ptr %l10, !tbaa !29
  %t281 = getelementptr %"compiler/typed:Body", ptr %t279, i32 0, i32 2
  %t282 = load i32, ptr %t281, !tbaa !23
  %t285 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t278, i32 %t282)
  store i64 %t285, ptr %l114
  br label %bb42
bb42:
  %t286 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t287 = load i64, ptr %l114, !tbaa !24
  %t289 = icmp eq i64 %t287, %t286
  br i1 %t289, label %bb43, label %bb44
bb43:
  %t291 = load ptr, ptr %l8, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Call", ptr %t291, i32 0, i32 3
  %t294 = load i32, ptr %t293, !tbaa !23
  %t296 = sext i32 %t294 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l120, !tbaa !27
  %t297 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t299 = insertvalue { i64, { i64, ptr } } undef, i64 %t296, 0
  %t301 = insertvalue { i64, { i64, ptr } } %t299, { i64, ptr } %t297, 1
  store { i64, { i64, ptr } } %t301, ptr %l122
  %t302 = getelementptr { i64, { i64, ptr } }, ptr %l122, i32 0, i32 1
  %t303 = load { i64, ptr }, ptr %t302, !tbaa !27
  store { i64, ptr } %t303, ptr %l123, !tbaa !27
  %t304 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 0
  store i64 %t305, ptr %l124, !tbaa !24
  %t306 = load i64, ptr %l124, !tbaa !24
  %t307 = mul i64 %t306, 1
  %t308 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t307)
  %t309 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  store { i64, ptr } %t310, ptr %l125, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = load i64, ptr %l124, !tbaa !24
  %t316 = mul i64 %t315, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t312, ptr %t314, i64 %t316, i1 false)
  %t317 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t318 = getelementptr { i64, { i64, ptr } }, ptr %l122, i32 0, i32 1
  store { i64, ptr } %t317, ptr %t318, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t319 = load { i64, { i64, ptr } }, ptr %l122
  store { i64, { i64, ptr } } %t319, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t320 = load ptr, ptr %l3, !tbaa !29
  %t321 = load ptr, ptr %l10, !tbaa !29
  %t323 = getelementptr %"compiler/typed:Body", ptr %t321, i32 0, i32 2
  %t324 = load i32, ptr %t323, !tbaa !23
  %t327 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s5, ptr %t320, i32 %t324)
  store { i64, ptr } %t327, ptr %l129
  br label %bb46
bb46:
  %t328 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  %t331 = icmp ne i64 %t329, 1
  br i1 %t331, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l132, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t334 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t336 = insertvalue { i64, { i64, ptr } } %t334, { i64, ptr } %t333, 1
  store { i64, { i64, ptr } } %t336, ptr %l134
  %t337 = getelementptr { i64, { i64, ptr } }, ptr %l134, i32 0, i32 1
  %t338 = load { i64, ptr }, ptr %t337, !tbaa !27
  store { i64, ptr } %t338, ptr %l135, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  store i64 %t340, ptr %l136, !tbaa !24
  %t341 = load i64, ptr %l136, !tbaa !24
  %t342 = mul i64 %t341, 1
  %t343 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t342)
  %t344 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  store { i64, ptr } %t345, ptr %l137, !tbaa !27
  %t346 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = load i64, ptr %l136, !tbaa !24
  %t351 = mul i64 %t350, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t347, ptr %t349, i64 %t351, i1 false)
  %t352 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t353 = getelementptr { i64, { i64, ptr } }, ptr %l134, i32 0, i32 1
  store { i64, ptr } %t352, ptr %t353, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t354 = load { i64, { i64, ptr } }, ptr %l134
  store { i64, { i64, ptr } } %t354, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t355 = load ptr, ptr %l3, !tbaa !29
  %t356 = load ptr, ptr %l10, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Body", ptr %t356, i32 0, i32 2
  %t359 = load i32, ptr %t358, !tbaa !23
  %t362 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t355, i32 %t359, i64 0)
  store i64 %t362, ptr %l141
  br label %bb50
bb50:
  %t363 = load i64, ptr %l141, !tbaa !24
  store i64 %t363, ptr %l11, !tbaa !24
  %t364 = load i64, ptr %l11, !tbaa !24
  %t366 = icmp sge i64 %t364, 0
  br i1 %t366, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb53
bb52:
  %t368 = load i64, ptr %l11, !tbaa !24
  %t369 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t372 = icmp eq i64 %t368, %t369
  store i1 %t372, ptr %l144, !tbaa !21
  br label %bb53
bb53:
  %t374 = load i1, ptr %l144, !tbaa !21
  br i1 %t374, label %bb54, label %bb55
bb54:
  %t375 = load i64, ptr %l11, !tbaa !24
  %t377 = icmp sge i64 %t375, 0
  br i1 %t377, label %bb56, label %bb57
bb55:
  br label %bb72
bb56:
  %t379 = load i64, ptr %l11, !tbaa !24
  store i64 %t379, ptr %l151, !tbaa !24
  %t380 = load ptr, ptr %l10, !tbaa !29
  %t382 = getelementptr %"compiler/typed:Body", ptr %t380, i32 0, i32 5
  %t384 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t382)
  store i64 %t384, ptr %l154
  br label %bb58
bb57:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb59
bb58:
  %t385 = load i64, ptr %l151, !tbaa !24
  %t386 = load i64, ptr %l154, !tbaa !24
  %t387 = icmp slt i64 %t385, %t386
  store i1 %t387, ptr %l150, !tbaa !21
  br label %bb59
bb59:
  %t389 = load i1, ptr %l150, !tbaa !21
  br i1 %t389, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t390 = load ptr, ptr %l2, !tbaa !29
  %t392 = getelementptr %"compiler/free:Free", ptr %t390, i32 0, i32 0
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = getelementptr %"compiler/generic:Program", ptr %t393, i32 0, i32 0
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t398 = getelementptr %"compiler/load:Loader", ptr %t396, i32 0, i32 3
  %t399 = load ptr, ptr %t398, !tbaa !29
  store ptr %t399, ptr %l159, !tbaa !29
  %t400 = load ptr, ptr %l10, !tbaa !29
  %t402 = getelementptr %"compiler/typed:Body", ptr %t400, i32 0, i32 7
  store ptr %t402, ptr %l161, !tbaa !29
  %t403 = load ptr, ptr %l10, !tbaa !29
  %t405 = getelementptr %"compiler/typed:Body", ptr %t403, i32 0, i32 5
  %t406 = load i64, ptr %l11, !tbaa !24
  %t409 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t405, i64 %t406)
  store i32 %t409, ptr %l165
  br label %bb62
bb61:
  br label %bb71
bb62:
  %t410 = load i32, ptr %l165, !tbaa !23
  %t411 = sext i32 %t410 to i64
  %t412 = load ptr, ptr %l161, !tbaa !29
  %t414 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t412, i64 %t411)
  store %"compiler/typed:Local" %t414, ptr %l167
  br label %bb63
bb63:
  %t415 = getelementptr %"compiler/typed:Local", ptr %l167, i32 0, i32 0
  %t416 = load i32, ptr %t415, !tbaa !23
  %t417 = load ptr, ptr %l159, !tbaa !29
  %t419 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t417, i32 %t416)
  store { i64, ptr } %t419, ptr %l169
  br label %bb64
bb64:
  %t420 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t420, ptr %l12, !tbaa !27
  %t421 = load ptr, ptr %l2, !tbaa !29
  %t422 = load i64, ptr %l9, !tbaa !24
  %t425 = getelementptr %"compiler/free:Free", ptr %t421, i32 0, i32 42
  store i64 %t422, ptr %t425, !tbaa !24
  %t426 = load ptr, ptr %l2, !tbaa !29
  %t427 = load ptr, ptr %l10, !tbaa !29
  %t429 = getelementptr %"compiler/typed:Body", ptr %t427, i32 0, i32 3
  %t430 = load i64, ptr %t429, !tbaa !24
  %t433 = getelementptr %"compiler/free:Free", ptr %t426, i32 0, i32 43
  store i64 %t430, ptr %t433, !tbaa !24
  %t434 = load ptr, ptr %l2, !tbaa !29
  store ptr %t434, ptr %l175, !tbaa !29
  %t435 = load ptr, ptr %l10, !tbaa !29
  %t437 = getelementptr %"compiler/typed:Body", ptr %t435, i32 0, i32 4
  %t438 = getelementptr %"compiler/source:Span", ptr %t437, i32 0, i32 0
  %t439 = load i32, ptr %t438, !tbaa !23
  %t440 = load ptr, ptr %l10, !tbaa !29
  %t442 = getelementptr %"compiler/typed:Body", ptr %t440, i32 0, i32 4
  %t443 = getelementptr %"compiler/source:Span", ptr %t442, i32 0, i32 0
  %t444 = load i32, ptr %t443, !tbaa !23
  %t447 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 %t439, i32 %t444)
  store %"compiler/source:Span" %t447, ptr %l180
  br label %bb65
bb65:
  %t448 = load %"compiler/source:Span", ptr %l180
  %t449 = load ptr, ptr %l175, !tbaa !29
  %t450 = getelementptr %"compiler/free:Free", ptr %t449, i32 0, i32 44
  store %"compiler/source:Span" %t448, ptr %t450
  %t451 = load ptr, ptr %l2, !tbaa !29
  %t452 = load i64, ptr %l9, !tbaa !24
  %t455 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s11, ptr %t451, i64 %t452)
  store { i64, ptr } %t455, ptr %l183
  br label %bb66
bb66:
  %t456 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t456, ptr %l184, !tbaa !27
  %t457 = load ptr, ptr %l2, !tbaa !29
  store ptr %t457, ptr %l185, !tbaa !29
  %t458 = load ptr, ptr %l3, !tbaa !29
  %t459 = load ptr, ptr %l10, !tbaa !29
  %t461 = getelementptr %"compiler/typed:Body", ptr %t459, i32 0, i32 2
  %t462 = load i32, ptr %t461, !tbaa !23
  %t465 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s11, ptr %t458, i32 %t462)
  store { i64, ptr } %t465, ptr %l189
  br label %bb67
bb67:
  %t466 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t467 = load ptr, ptr %t466, !tbaa !27
  %t468 = getelementptr i32, ptr %t467, i64 0
  %t469 = load i32, ptr %t468, !tbaa !33
  %t470 = load ptr, ptr %l185, !tbaa !29
  %t472 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebuiltSpell(ptr %v0, ptr %s11, ptr %t470, i32 %t469)
  store { i64, ptr } %t472, ptr %l191
  br label %bb68
bb68:
  %t473 = load ptr, ptr %l2, !tbaa !29
  store ptr %t473, ptr %l192, !tbaa !29
  %t474 = load ptr, ptr %l3, !tbaa !29
  %t475 = load ptr, ptr %l10, !tbaa !29
  %t477 = getelementptr %"compiler/typed:Body", ptr %t475, i32 0, i32 2
  %t478 = load i32, ptr %t477, !tbaa !23
  %t481 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s11, ptr %t474, i32 %t478)
  store { i64, ptr } %t481, ptr %l196
  br label %bb69
bb69:
  %t482 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr i32, ptr %t483, i64 0
  %t485 = load i32, ptr %t484, !tbaa !33
  %t486 = load ptr, ptr %l192, !tbaa !29
  %t488 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewhat(ptr %v0, ptr %s11, ptr %t486, i32 %t485)
  store { i64, ptr } %t488, ptr %l198
  br label %bb70
bb70:
  %t489 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t490 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t491 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 1
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t494 = add i64 %t490, %t493
  %t495 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t496 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t497 = add i64 %t494, %t496
  %t498 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t499 = extractvalue { i64, ptr } %t498, 1
  %t500 = extractvalue { i64, ptr } %t498, 0
  %t501 = add i64 %t497, %t500
  %t502 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t503 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t504 = add i64 %t501, %t503
  %t505 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t505, 1
  %t507 = extractvalue { i64, ptr } %t505, 0
  %t508 = add i64 %t504, %t507
  %t509 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t510 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t511 = add i64 %t508, %t510
  %t512 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t512, 1
  %t514 = extractvalue { i64, ptr } %t512, 0
  %t515 = add i64 %t511, %t514
  %t516 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t515)
  call void @olang_textcopy(ptr %t516, ptr %t489, i64 %t490)
  %t517 = getelementptr i8, ptr %t516, i64 %t490
  call void @olang_textcopy(ptr %t517, ptr %t492, i64 %t493)
  %t518 = getelementptr i8, ptr %t517, i64 %t493
  call void @olang_textcopy(ptr %t518, ptr %t495, i64 %t496)
  %t519 = getelementptr i8, ptr %t518, i64 %t496
  call void @olang_textcopy(ptr %t519, ptr %t499, i64 %t500)
  %t520 = getelementptr i8, ptr %t519, i64 %t500
  call void @olang_textcopy(ptr %t520, ptr %t502, i64 %t503)
  %t521 = getelementptr i8, ptr %t520, i64 %t503
  call void @olang_textcopy(ptr %t521, ptr %t506, i64 %t507)
  %t522 = getelementptr i8, ptr %t521, i64 %t507
  call void @olang_textcopy(ptr %t522, ptr %t509, i64 %t510)
  %t523 = getelementptr i8, ptr %t522, i64 %t510
  call void @olang_textcopy(ptr %t523, ptr %t513, i64 %t514)
  %t524 = insertvalue { i64, ptr } undef, i64 %t515, 0
  %t525 = insertvalue { i64, ptr } %t524, ptr %t516, 1
  %t526 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t528 = insertvalue { i64, { i64, ptr } } %t526, { i64, ptr } %t525, 1
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s5)
  store { i64, { i64, ptr } } %t528, ptr %rv
  br label %ret
bb71:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l201, !tbaa !27
  %t530 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t531 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t533 = insertvalue { i64, { i64, ptr } } %t531, { i64, ptr } %t530, 1
  store { i64, { i64, ptr } } %t533, ptr %l203
  %t534 = getelementptr { i64, { i64, ptr } }, ptr %l203, i32 0, i32 1
  %t535 = load { i64, ptr }, ptr %t534, !tbaa !27
  store { i64, ptr } %t535, ptr %l204, !tbaa !27
  %t536 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t537 = extractvalue { i64, ptr } %t536, 0
  store i64 %t537, ptr %l205, !tbaa !24
  %t538 = load i64, ptr %l205, !tbaa !24
  %t539 = mul i64 %t538, 1
  %t540 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t539)
  %t541 = insertvalue { i64, ptr } undef, i64 %t538, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t540, 1
  store { i64, ptr } %t542, ptr %l206, !tbaa !27
  %t543 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !27
  %t547 = load i64, ptr %l205, !tbaa !24
  %t548 = mul i64 %t547, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t544, ptr %t546, i64 %t548, i1 false)
  %t549 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t550 = getelementptr { i64, { i64, ptr } }, ptr %l203, i32 0, i32 1
  store { i64, ptr } %t549, ptr %t550, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t551 = load { i64, { i64, ptr } }, ptr %l203
  store { i64, { i64, ptr } } %t551, ptr %rv
  br label %ret
bb72:
  %t552 = load ptr, ptr %l2, !tbaa !29
  %t554 = getelementptr %"compiler/free:Free", ptr %t552, i32 0, i32 27
  %t555 = load i64, ptr %l9, !tbaa !24
  %t558 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t554, i64 %t555)
  store i1 %t558, ptr %l210
  br label %bb73
bb73:
  %t559 = load i1, ptr %l210, !tbaa !21
  %t560 = xor i1 %t559, true
  br i1 %t560, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s13
  %t562 = load ptr, ptr %l2, !tbaa !29
  %t563 = load i64, ptr %l9, !tbaa !24
  %t566 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s13, ptr %t562, i64 %t563)
  store { i64, ptr } %t566, ptr %l214
  br label %bb76
bb75:
  br label %bb77
bb76:
  %t567 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t568 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t569 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t570 = extractvalue { i64, ptr } %t569, 1
  %t571 = extractvalue { i64, ptr } %t569, 0
  %t572 = add i64 %t568, %t571
  %t573 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t574 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t575 = add i64 %t572, %t574
  %t576 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t575)
  call void @olang_textcopy(ptr %t576, ptr %t567, i64 %t568)
  %t577 = getelementptr i8, ptr %t576, i64 %t568
  call void @olang_textcopy(ptr %t577, ptr %t570, i64 %t571)
  %t578 = getelementptr i8, ptr %t577, i64 %t571
  call void @olang_textcopy(ptr %t578, ptr %t573, i64 %t574)
  %t579 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t576, 1
  %t581 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t583 = insertvalue { i64, { i64, ptr } } %t581, { i64, ptr } %t580, 1
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s5)
  store { i64, { i64, ptr } } %t583, ptr %rv
  br label %ret
bb77:
  %t585 = load ptr, ptr %l8, !tbaa !29
  %t587 = getelementptr %"compiler/typed:Call", ptr %t585, i32 0, i32 3
  %t588 = load i32, ptr %t587, !tbaa !23
  %t590 = sext i32 %t588 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l220, !tbaa !27
  %t591 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t593 = insertvalue { i64, { i64, ptr } } undef, i64 %t590, 0
  %t595 = insertvalue { i64, { i64, ptr } } %t593, { i64, ptr } %t591, 1
  store { i64, { i64, ptr } } %t595, ptr %l222
  %t596 = getelementptr { i64, { i64, ptr } }, ptr %l222, i32 0, i32 1
  %t597 = load { i64, ptr }, ptr %t596, !tbaa !27
  store { i64, ptr } %t597, ptr %l223, !tbaa !27
  %t598 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t598, 0
  store i64 %t599, ptr %l224, !tbaa !24
  %t600 = load i64, ptr %l224, !tbaa !24
  %t601 = mul i64 %t600, 1
  %t602 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t601)
  %t603 = insertvalue { i64, ptr } undef, i64 %t600, 0
  %t604 = insertvalue { i64, ptr } %t603, ptr %t602, 1
  store { i64, ptr } %t604, ptr %l225, !tbaa !27
  %t605 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t606 = load ptr, ptr %t605, !tbaa !27
  %t607 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !27
  %t609 = load i64, ptr %l224, !tbaa !24
  %t610 = mul i64 %t609, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t606, ptr %t608, i64 %t610, i1 false)
  %t611 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t612 = getelementptr { i64, { i64, ptr } }, ptr %l222, i32 0, i32 1
  store { i64, ptr } %t611, ptr %t612, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t613 = load { i64, { i64, ptr } }, ptr %l222
  store { i64, { i64, ptr } } %t613, ptr %rv
  br label %ret
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l226, !tbaa !27
  %t614 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t615 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t617 = insertvalue { i64, { i64, ptr } } %t615, { i64, ptr } %t614, 1
  store { i64, { i64, ptr } } %t617, ptr %l228
  %t618 = getelementptr { i64, { i64, ptr } }, ptr %l228, i32 0, i32 1
  %t619 = load { i64, ptr }, ptr %t618, !tbaa !27
  store { i64, ptr } %t619, ptr %l229, !tbaa !27
  %t620 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t621 = extractvalue { i64, ptr } %t620, 0
  store i64 %t621, ptr %l230, !tbaa !24
  %t622 = load i64, ptr %l230, !tbaa !24
  %t623 = mul i64 %t622, 1
  %t624 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t623)
  %t625 = insertvalue { i64, ptr } undef, i64 %t622, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t624, 1
  store { i64, ptr } %t626, ptr %l231, !tbaa !27
  %t627 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t628 = load ptr, ptr %t627, !tbaa !27
  %t629 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t630 = load ptr, ptr %t629, !tbaa !27
  %t631 = load i64, ptr %l230, !tbaa !24
  %t632 = mul i64 %t631, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t628, ptr %t630, i64 %t632, i1 false)
  %t633 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t634 = getelementptr { i64, { i64, ptr } }, ptr %l228, i32 0, i32 1
  store { i64, ptr } %t633, ptr %t634, !tbaa !27
  %t635 = load { i64, { i64, ptr } }, ptr %l228
  store { i64, { i64, ptr } } %t635, ptr %rv
  br label %ret
bb82:
  call void @__olang_check_failed(ptr @olang_loc_fa71248d89b17b0b_39d265aac120d27f)
  unreachable
ret:
  %rr = load { i64, { i64, ptr } }, ptr %rv
  ret { i64, { i64, ptr } } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca i1
  %l13 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %t9, ptr %a2)
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:walker", ptr %t13, i32 0, i32 4
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t15, i64 %t16)
  store i1 %t19, ptr %l13
  br label %bb5
bb4:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i1, ptr %l13, !tbaa !21
  store i1 %t20, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:walker", ptr %t22, i32 0, i32 5
  store i1 true, ptr %t24, !tbaa !21
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 2
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 25
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t15, i64 %t19)
  store i1 %t22, ptr %l14
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t23 = load i1, ptr %l14, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 25
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t28, i64 %t32, i1 true)
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = getelementptr %"compiler/free:Free", ptr %t35, i32 0, i32 30
  store i1 true, ptr %t37, !tbaa !21
  br label %bb7
bb7:
  br label %ret
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l21, !tbaa !29
  %t39 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  store i64 %t39, ptr %l22, !tbaa !24
  %t40 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t40, ptr %l23, !tbaa !24
  store %"compiler/source:Span" %a1, ptr %l24
  %t44 = call %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v1, ptr %a2)
  store %"compiler/source:Span" %t44, ptr %l26
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = load i64, ptr %l23, !tbaa !24
  %t49 = load %"compiler/source:Span", ptr %l24
  %t50 = load %"compiler/source:Span", ptr %l26
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t46, i64 %t47, i64 %t48, %"compiler/source:Span" %t49, %"compiler/source:Span" %t50, i64 %a3)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einsidePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l10 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ederefRoot(ptr %v1, ptr %a1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %t11)
  store i64 %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load i64, ptr %l10, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopAround(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i1
  %l53 = alloca i64
  %l56 = alloca i1
  %l57 = alloca i64
  %l61 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 14
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l39
  br label %bb12
bb12:
  %t60 = load i64, ptr %l1, !tbaa !24
  %t61 = load i64, ptr %l39, !tbaa !24
  %t63 = icmp slt i64 %t61, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i64, ptr %l1, !tbaa !24
  store i64 %t65, ptr %l43, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 15
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l47
  br label %bb15
bb14:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb16
bb15:
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l47, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  store i1 %t75, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l42, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/free:walker", ptr %t78, i32 0, i32 14
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t80, i64 %t81)
  store i64 %t84, ptr %l53
  br label %bb19
bb18:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb20
bb19:
  %t85 = load i64, ptr %l2, !tbaa !24
  %t86 = load i64, ptr %l53, !tbaa !24
  %t88 = icmp slt i64 %t86, %t85
  store i1 %t88, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t90 = load i1, ptr %l49, !tbaa !21
  br i1 %t90, label %bb21, label %bb22
bb21:
  %t91 = load i64, ptr %l2, !tbaa !24
  store i64 %t91, ptr %l57, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:walker", ptr %t92, i32 0, i32 15
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t94, i64 %t95)
  store i64 %t98, ptr %l61
  br label %bb23
bb22:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb24
bb23:
  %t99 = load i64, ptr %l57, !tbaa !24
  %t100 = load i64, ptr %l61, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  store i1 %t101, ptr %l56, !tbaa !21
  br label %bb24
bb24:
  %t103 = load i1, ptr %l56, !tbaa !21
  br i1 %t103, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t105 = load i64, ptr %l7, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l7, !tbaa !24
  br label %bb8
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopUse(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i1
  %l60 = alloca i64
  %l64 = alloca i64
  %l66 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l76 = alloca i64
  %l78 = alloca i1
  %l82 = alloca i64
  %l86 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i64, ptr %l16, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l23, !tbaa !24
  store i64 %t33, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l20, !tbaa !24
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb42
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l9, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 14
  %t56 = load i64, ptr %l9, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l44
  br label %bb12
bb12:
  %t60 = load i64, ptr %l44, !tbaa !24
  store i64 %t60, ptr %l10, !tbaa !24
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l2, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t67 = load i64, ptr %l2, !tbaa !24
  store i64 %t67, ptr %l49, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/free:walker", ptr %t68, i32 0, i32 15
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t70, i64 %t71)
  store i64 %t74, ptr %l53
  br label %bb15
bb14:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb16
bb15:
  %t75 = load i64, ptr %l49, !tbaa !24
  %t76 = load i64, ptr %l53, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  store i1 %t77, ptr %l48, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l48, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb20
bb18:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 20
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t84, i64 %a1)
  store i64 %t88, ptr %l60
  br label %bb19
bb19:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l60, !tbaa !24
  %t92 = icmp sgt i64 %t90, %t89
  store i1 %t92, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t94 = load i1, ptr %l56, !tbaa !21
  br i1 %t94, label %bb21, label %bb22
bb21:
  br label %bb41
bb22:
  br label %bb23
bb23:
  store ptr %a3, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb24
bb24:
  %t97 = load i64, ptr %l12, !tbaa !24
  store i64 %t97, ptr %l64, !tbaa !24
  %t98 = load ptr, ptr %l11, !tbaa !29
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t98)
  store i64 %t100, ptr %l66
  br label %bb25
bb25:
  %t101 = load i64, ptr %l64, !tbaa !24
  %t102 = load i64, ptr %l66, !tbaa !24
  %t103 = icmp slt i64 %t101, %t102
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb26, label %bb27
bb26:
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t107 = load ptr, ptr %l11, !tbaa !29
  %t108 = load i64, ptr %l12, !tbaa !24
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t107, i64 %t108)
  store i64 %t111, ptr %l71
  br label %bb29
bb29:
  %t112 = load i64, ptr %l71, !tbaa !24
  store i64 %t112, ptr %l13, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  store i64 %t113, ptr %l72, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/free:walker", ptr %t114, i32 0, i32 25
  %t117 = load i64, ptr %l13, !tbaa !24
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t116, i64 %t117)
  store i64 %t120, ptr %l76
  br label %bb30
bb30:
  %t121 = load i64, ptr %l72, !tbaa !24
  %t122 = load i64, ptr %l76, !tbaa !24
  %t123 = icmp slt i64 %t121, %t122
  br i1 %t123, label %bb31, label %bb32
bb31:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:walker", ptr %t125, i32 0, i32 25
  %t128 = load i64, ptr %l13, !tbaa !24
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t127, i64 %t128)
  store i64 %t131, ptr %l82
  br label %bb33
bb32:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb35
bb33:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/free:walker", ptr %t132, i32 0, i32 15
  %t135 = load i64, ptr %l9, !tbaa !24
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t134, i64 %t135)
  store i64 %t138, ptr %l86
  br label %bb34
bb34:
  %t139 = load i64, ptr %l82, !tbaa !24
  %t140 = load i64, ptr %l86, !tbaa !24
  %t141 = icmp sle i64 %t139, %t140
  store i1 %t141, ptr %l78, !tbaa !21
  br label %bb35
bb35:
  %t143 = load i1, ptr %l78, !tbaa !21
  br i1 %t143, label %bb36, label %bb37
bb36:
  %t144 = load i64, ptr %l13, !tbaa !24
  store i64 %t144, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t146 = load i64, ptr %l12, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l12, !tbaa !24
  br label %bb24
bb40:
  br label %bb41
bb41:
  %t150 = load i64, ptr %l8, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l8, !tbaa !24
  br label %bb8
bb42:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, { i64, ptr } }
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/source:Span"
  %l30 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l56 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca i64
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l98 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l109 = alloca i64
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l120 = alloca i64
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca { i64, { i64, ptr } }
  %l128 = alloca { i64, ptr }
  %l130 = alloca i64
  %l132 = alloca i64
  %l133 = alloca { i64, ptr }
  %l138 = alloca i1
  %l140 = alloca ptr
  %l144 = alloca i64
  %l147 = alloca i64
  %l150 = alloca i1
  %l154 = alloca ptr
  %l159 = alloca i1
  %l163 = alloca i64
  %l173 = alloca ptr
  %l175 = alloca %"compiler/source:Span"
  %l176 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l179 = alloca i64
  %l184 = alloca i1
  %l187 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l190 = alloca i64
  %l192 = alloca i64
  %l193 = alloca { i64, ptr }
  %l197 = alloca i1
  %l202 = alloca i1
  %l205 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l208 = alloca i64
  %l210 = alloca i64
  %l211 = alloca { i64, ptr }
  %l213 = alloca ptr
  %l224 = alloca %"compiler/free:store"
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l30
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l30, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 3
  %t12 = load i64, ptr %t11, !tbaa !24
  store i64 %t12, ptr %l6, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  store i64 -1, ptr %l8, !tbaa !24
  store i64 -1, ptr %l9, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t16, ptr %l35, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l36, !tbaa !24
  %t19 = load i64, ptr %l36, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l37, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l36, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t30, ptr %l10, !tbaa !27
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t32 = load ptr, ptr %l38, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb2, label %bb3
bb2:
  %t35 = load ptr, ptr %l38, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 0
  store i1 %t38, ptr %l39, !tbaa !21
  br label %bb3
bb3:
  %t39 = load i1, ptr %l39, !tbaa !21
  br i1 %t39, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t40 = load i64, ptr @G_2ecompiler_2ffree_2eSOk, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  br label %bb98
bb7:
  %t42 = load ptr, ptr %l2, !tbaa !29
  store ptr %t42, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t43 = load ptr, ptr %l43, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load ptr, ptr %l43, !tbaa !29
  %t47 = load i64, ptr %t46
  %t49 = icmp eq i64 %t47, 1
  store i1 %t49, ptr %l44, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l44, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t51 = load i64, ptr @G_2ecompiler_2ffree_2eSOk, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  br label %bb98
bb13:
  %t53 = load ptr, ptr %l2, !tbaa !29
  store ptr %t53, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t54 = load ptr, ptr %l48, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l48, !tbaa !29
  %t58 = load i64, ptr %t57
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l49, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l49, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l11, !tbaa !29
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t69 = load ptr, ptr %l11, !tbaa !29
  %t72 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store i64 %t72, ptr %l56
  br label %bb19
bb19:
  %t73 = load i64, ptr %l56, !tbaa !24
  store i64 %t73, ptr %l12, !tbaa !24
  %t74 = load i64, ptr %l12, !tbaa !24
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = icmp eq i64 %t74, %t75
  br i1 %t78, label %bb20, label %bb21
bb20:
  %t80 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  store i64 %t80, ptr %l7, !tbaa !24
  %t82 = load i64, ptr %l12, !tbaa !24
  store i64 %t82, ptr %l8, !tbaa !24
  br label %bb25
bb21:
  store { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l62, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t84, ptr %l63, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l65, !tbaa !24
  %t90 = load i64, ptr %l65, !tbaa !24
  %t91 = icmp eq i64 %t86, %t90
  br i1 %t91, label %bb22, label %bb23
bb22:
  %t93 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l65, !tbaa !24
  %t98 = mul i64 %t97, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t94, ptr %t96, i64 %t98, i1 false)
  br label %bb24
bb23:
  %t99 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l67, !tbaa !24
  %t101 = load i64, ptr %l67, !tbaa !24
  %t102 = mul i64 %t101, 1
  %t103 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t102)
  %t104 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l68, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l67, !tbaa !24
  %t111 = mul i64 %t110, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t107, ptr %t109, i64 %t111, i1 false)
  %t112 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t112, ptr %l10, !tbaa !27
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb98
bb26:
  %t113 = load ptr, ptr %l2, !tbaa !29
  store ptr %t113, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t114 = load ptr, ptr %l69, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb27, label %bb28
bb27:
  %t117 = load ptr, ptr %l69, !tbaa !29
  %t118 = load i64, ptr %t117
  %t120 = icmp eq i64 %t118, 17
  store i1 %t120, ptr %l70, !tbaa !21
  br label %bb28
bb28:
  %t121 = load i1, ptr %l70, !tbaa !21
  br i1 %t121, label %bb29, label %bb30
bb29:
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l13, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l1, !tbaa !24
  %t130 = load ptr, ptr %l13, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l3
  %t132 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t128, i64 %t129, ptr %t130, %"compiler/source:Span" %t131, i1 %t132)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  %t138 = load ptr, ptr %l2, !tbaa !29
  store ptr %t138, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t139 = load ptr, ptr %l80, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb34, label %bb35
bb34:
  %t142 = load ptr, ptr %l80, !tbaa !29
  %t143 = load i64, ptr %t142
  %t145 = icmp eq i64 %t143, 14
  store i1 %t145, ptr %l81, !tbaa !21
  br label %bb35
bb35:
  %t146 = load i1, ptr %l81, !tbaa !21
  br i1 %t146, label %bb36, label %bb37
bb36:
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t149 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t149, i32 0, i32 2
  %t151 = load ptr, ptr %t150
  store ptr %t151, ptr %l14, !tbaa !29
  br label %bb38
bb37:
  br label %bb58
bb38:
  %t153 = load ptr, ptr %l14, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Try", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = icmp eq ptr %t156, null
  %t160 = xor i1 %t158, true
  store i1 %t160, ptr %l15, !tbaa !21
  %t162 = load ptr, ptr %l14, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Try", ptr %t162, i32 0, i32 1
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l18, !tbaa !24
  br label %bb39
bb39:
  %t171 = load i64, ptr %l17, !tbaa !24
  %t172 = load i64, ptr %l18, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb40, label %bb41
bb40:
  br label %bb47
bb41:
  br label %bb42
bb42:
  %t179 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t179, ptr %l98, !tbaa !27
  %t180 = load i64, ptr %l17, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr ptr, ptr %t183, i64 %t180
  %t185 = load ptr, ptr %t184, !tbaa !39
  %t189 = getelementptr %"compiler/typed:Clause", ptr %t185, i32 0, i32 4
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t194 = icmp sgt i64 %t192, 0
  br i1 %t194, label %bb43, label %bb44
bb43:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t196 = load i64, ptr %l17, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l17, !tbaa !24
  br label %bb39
bb47:
  %t200 = load i1, ptr %l15, !tbaa !21
  br i1 %t200, label %bb48, label %bb49
bb48:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l108, !tbaa !29
  %t203 = load i64, ptr %l1, !tbaa !24
  store i64 %t203, ptr %l109, !tbaa !24
  %t204 = load ptr, ptr %l14, !tbaa !29
  %t206 = getelementptr %"compiler/typed:Try", ptr %t204, i32 0, i32 0
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = icmp eq ptr %t207, null
  br i1 %t209, label %bb50, label %bb51
bb49:
  br label %bb54
bb50:
  call void @__olang_check_failed(ptr @olang_loc_7676aaa4af173342_5bef0e3278c42ba6)
  unreachable
bb51:
  br label %bb52
bb52:
  %t211 = load ptr, ptr %l14, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Try", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l3
  %t216 = load i1, ptr %l4, !tbaa !21
  %t217 = load ptr, ptr %l108, !tbaa !29
  %t218 = load i64, ptr %l109, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t217, i64 %t218, ptr %t214, %"compiler/source:Span" %t215, i1 %t216)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb54:
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l117, !tbaa !27
  %t222 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t222, ptr %l118, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t225 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  store i64 %t226, ptr %l120, !tbaa !24
  %t228 = load i64, ptr %l120, !tbaa !24
  %t229 = icmp eq i64 %t224, %t228
  br i1 %t229, label %bb55, label %bb56
bb55:
  %t231 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = load i64, ptr %l120, !tbaa !24
  %t236 = mul i64 %t235, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t232, ptr %t234, i64 %t236, i1 false)
  br label %bb57
bb56:
  %t237 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  store i64 %t238, ptr %l122, !tbaa !24
  %t239 = load i64, ptr %l122, !tbaa !24
  %t240 = mul i64 %t239, 1
  %t241 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t240)
  %t242 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l123, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = load i64, ptr %l122, !tbaa !24
  %t249 = mul i64 %t248, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t245, ptr %t247, i64 %t249, i1 false)
  %t250 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t250, ptr %l10, !tbaa !27
  br label %bb57
bb57:
  br label %bb98
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb97
bb61:
  store %olang.scope zeroinitializer, ptr %s13
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l2, !tbaa !29
  %t255 = call { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %s13, ptr %t251, ptr %t252)
  store { i64, { i64, ptr } } %t255, ptr %l126
  br label %bb62
bb62:
  %t256 = load { i64, { i64, ptr } }, ptr %l126
  store { i64, { i64, ptr } } %t256, ptr %l20
  %t257 = getelementptr { i64, { i64, ptr } }, ptr %l20, i32 0, i32 0
  %t258 = load i64, ptr %t257, !tbaa !24
  store i64 %t258, ptr %l9, !tbaa !24
  %t260 = getelementptr { i64, { i64, ptr } }, ptr %l20, i32 0, i32 1
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  store { i64, ptr } %t261, ptr %l128, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  %t264 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  store i64 %t265, ptr %l130, !tbaa !24
  %t267 = load i64, ptr %l130, !tbaa !24
  %t268 = icmp eq i64 %t263, %t267
  br i1 %t268, label %bb63, label %bb64
bb63:
  %t270 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = load i64, ptr %l130, !tbaa !24
  %t275 = mul i64 %t274, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t271, ptr %t273, i64 %t275, i1 false)
  br label %bb65
bb64:
  %t276 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t276, 0
  store i64 %t277, ptr %l132, !tbaa !24
  %t278 = load i64, ptr %l132, !tbaa !24
  %t279 = mul i64 %t278, 1
  %t280 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t279)
  %t281 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  store { i64, ptr } %t282, ptr %l133, !tbaa !27
  %t283 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = load i64, ptr %l132, !tbaa !24
  %t288 = mul i64 %t287, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t284, ptr %t286, i64 %t288, i1 false)
  %t289 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t289, ptr %l10, !tbaa !27
  br label %bb65
bb65:
  %t290 = load i64, ptr %l9, !tbaa !24
  %t292 = icmp sge i64 %t290, 0
  br i1 %t292, label %bb66, label %bb67
bb66:
  %t294 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  store i64 %t294, ptr %l7, !tbaa !24
  br label %bb96
bb67:
  store %olang.scope zeroinitializer, ptr %s15
  %t296 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t298 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s15, { i64, ptr } %t296, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i1 %t298, ptr %l138
  br label %bb68
bb68:
  %t299 = load i1, ptr %l138, !tbaa !21
  br i1 %t299, label %bb69, label %bb70
bb69:
  %t300 = load ptr, ptr %l2, !tbaa !29
  %t302 = call ptr @compiler_2ffree_2ecallOf(ptr %v1, ptr %t300)
  store ptr %t302, ptr %l140
  br label %bb71
bb70:
  br label %bb95
bb71:
  %t303 = load ptr, ptr %l140, !tbaa !29
  store ptr %t303, ptr %l21, !tbaa !29
  %t304 = load ptr, ptr %l21, !tbaa !29
  %t306 = icmp eq ptr %t304, null
  %t308 = xor i1 %t306, true
  br i1 %t308, label %bb72, label %bb73
bb72:
  %t310 = load ptr, ptr %l5, !tbaa !29
  %t311 = load ptr, ptr %l21, !tbaa !29
  %t314 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t310, ptr %t311)
  store i64 %t314, ptr %l147
  br label %bb74
bb73:
  store i64 -1, ptr %l144, !tbaa !24
  br label %bb75
bb74:
  %t315 = load i64, ptr %l147, !tbaa !24
  store i64 %t315, ptr %l144, !tbaa !24
  br label %bb75
bb75:
  %t316 = load i64, ptr %l144, !tbaa !24
  store i64 %t316, ptr %l22, !tbaa !24
  %t317 = load i64, ptr %l22, !tbaa !24
  %t319 = icmp sge i64 %t317, 0
  br i1 %t319, label %bb76, label %bb77
bb76:
  %t321 = load ptr, ptr %l5, !tbaa !29
  %t323 = getelementptr %"compiler/free:Free", ptr %t321, i32 0, i32 1
  %t324 = load i64, ptr %l22, !tbaa !24
  %t327 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t323, i64 %t324)
  store ptr %t327, ptr %l154
  br label %bb78
bb77:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb79
bb78:
  %t328 = load ptr, ptr %l154, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Body", ptr %t328, i32 0, i32 11
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = icmp eq ptr %t331, null
  %t335 = xor i1 %t333, true
  store i1 %t335, ptr %l150, !tbaa !21
  br label %bb79
bb79:
  %t337 = load i1, ptr %l150, !tbaa !21
  br i1 %t337, label %bb80, label %bb81
bb80:
  %t338 = load ptr, ptr %l5, !tbaa !29
  %t340 = getelementptr %"compiler/free:Free", ptr %t338, i32 0, i32 26
  %t341 = load i64, ptr %l22, !tbaa !24
  %t344 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t340, i64 %t341)
  store i64 %t344, ptr %l163
  br label %bb82
bb81:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb83
bb82:
  %t345 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t346 = load i64, ptr %l1, !tbaa !24
  %t349 = add i64 %t345, %t346
  %t350 = load i64, ptr %l163, !tbaa !24
  %t352 = icmp eq i64 %t350, %t349
  store i1 %t352, ptr %l159, !tbaa !21
  br label %bb83
bb83:
  %t354 = load i1, ptr %l159, !tbaa !21
  br i1 %t354, label %bb84, label %bb85
bb84:
  %t355 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  store i64 %t355, ptr %l7, !tbaa !24
  %t357 = load i64, ptr %l1, !tbaa !24
  store i64 %t357, ptr %l8, !tbaa !24
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t359 = load i64, ptr %l7, !tbaa !24
  %t360 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t363 = icmp eq i64 %t359, %t360
  br i1 %t363, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s18
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l173, !tbaa !29
  %t366 = load ptr, ptr %l2, !tbaa !29
  %t368 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t366)
  store %"compiler/source:Span" %t368, ptr %l175
  br label %bb89
bb88:
  br label %bb94
bb89:
  %t369 = load ptr, ptr %l173, !tbaa !29
  %t370 = load %"compiler/source:Span", ptr %l175
  %t371 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s18, ptr %t369, %"compiler/source:Span" %t370)
  store { i64, ptr } %t371, ptr %l176
  br label %bb90
bb90:
  %t372 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t374 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  %t377 = add i64 %t373, %t376
  %t378 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t379 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t380 = add i64 %t377, %t379
  %t381 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t380)
  call void @olang_textcopy(ptr %t381, ptr %t372, i64 %t373)
  %t382 = getelementptr i8, ptr %t381, i64 %t373
  call void @olang_textcopy(ptr %t382, ptr %t375, i64 %t376)
  %t383 = getelementptr i8, ptr %t382, i64 %t376
  call void @olang_textcopy(ptr %t383, ptr %t378, i64 %t379)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t381, 1
  store { i64, ptr } %t385, ptr %l177, !tbaa !27
  %t386 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t386, 0
  %t388 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t388, 0
  store i64 %t389, ptr %l179, !tbaa !24
  %t391 = load i64, ptr %l179, !tbaa !24
  %t392 = icmp eq i64 %t387, %t391
  br i1 %t392, label %bb91, label %bb92
bb91:
  %t394 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !27
  %t396 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = load i64, ptr %l179, !tbaa !24
  %t399 = mul i64 %t398, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t395, ptr %t397, i64 %t399, i1 false)
  br label %bb93
bb92:
  %t400 = load { i64, ptr }, ptr %l177, !tbaa !27
  store { i64, ptr } %t400, ptr %l10, !tbaa !27
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s18)
  br label %bb94
bb94:
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s15)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s13)
  br label %bb98
bb97:
  call void @__olang_check_failed(ptr @olang_loc_1665755e987b0d60_2375c09fda7e834)
  unreachable
bb98:
  %t401 = load i64, ptr %l7, !tbaa !24
  %t402 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t405 = icmp eq i64 %t401, %t402
  br i1 %t405, label %bb99, label %bb100
bb99:
  %t407 = load i1, ptr %l4, !tbaa !21
  store i1 %t407, ptr %l184, !tbaa !21
  br label %bb101
bb100:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb101
bb101:
  %t409 = load i1, ptr %l184, !tbaa !21
  br i1 %t409, label %bb102, label %bb103
bb102:
  %t410 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t410, ptr %l7, !tbaa !24
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l187, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l187, !tbaa !27
  store { i64, ptr } %t412, ptr %l188, !tbaa !27
  %t413 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t414 = extractvalue { i64, ptr } %t413, 0
  %t415 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t416 = extractvalue { i64, ptr } %t415, 0
  store i64 %t416, ptr %l190, !tbaa !24
  %t418 = load i64, ptr %l190, !tbaa !24
  %t419 = icmp eq i64 %t414, %t418
  br i1 %t419, label %bb104, label %bb105
bb103:
  br label %bb107
bb104:
  %t421 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !27
  %t425 = load i64, ptr %l190, !tbaa !24
  %t426 = mul i64 %t425, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t422, ptr %t424, i64 %t426, i1 false)
  br label %bb106
bb105:
  %t427 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t428 = extractvalue { i64, ptr } %t427, 0
  store i64 %t428, ptr %l192, !tbaa !24
  %t429 = load i64, ptr %l192, !tbaa !24
  %t430 = mul i64 %t429, 1
  %t431 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t430)
  %t432 = insertvalue { i64, ptr } undef, i64 %t429, 0
  %t433 = insertvalue { i64, ptr } %t432, ptr %t431, 1
  store { i64, ptr } %t433, ptr %l193, !tbaa !27
  %t434 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !27
  %t436 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !27
  %t438 = load i64, ptr %l192, !tbaa !24
  %t439 = mul i64 %t438, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t435, ptr %t437, i64 %t439, i1 false)
  %t440 = load { i64, ptr }, ptr %l193, !tbaa !27
  store { i64, ptr } %t440, ptr %l10, !tbaa !27
  br label %bb106
bb106:
  br label %bb107
bb107:
  %t441 = load i64, ptr %l7, !tbaa !24
  %t442 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t445 = icmp eq i64 %t441, %t442
  br i1 %t445, label %bb108, label %bb109
bb108:
  %t447 = load ptr, ptr %l5, !tbaa !29
  %t449 = getelementptr %"compiler/free:Free", ptr %t447, i32 0, i32 17
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/free:walker", ptr %t450, i32 0, i32 1
  %t453 = load i64, ptr %t452, !tbaa !24
  %t456 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t449, i64 %t453)
  store i1 %t456, ptr %l202
  br label %bb110
bb109:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb111
bb110:
  %t457 = load i1, ptr %l202, !tbaa !21
  %t458 = xor i1 %t457, true
  store i1 %t458, ptr %l197, !tbaa !21
  br label %bb111
bb111:
  %t460 = load i1, ptr %l197, !tbaa !21
  br i1 %t460, label %bb112, label %bb113
bb112:
  %t461 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t461, ptr %l7, !tbaa !24
  store { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l205, !tbaa !27
  %t463 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t463, ptr %l206, !tbaa !27
  %t464 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  %t466 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t466, 0
  store i64 %t467, ptr %l208, !tbaa !24
  %t469 = load i64, ptr %l208, !tbaa !24
  %t470 = icmp eq i64 %t465, %t469
  br i1 %t470, label %bb114, label %bb115
bb113:
  br label %bb117
bb114:
  %t472 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t473 = load ptr, ptr %t472, !tbaa !27
  %t474 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = load i64, ptr %l208, !tbaa !24
  %t477 = mul i64 %t476, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t473, ptr %t475, i64 %t477, i1 false)
  br label %bb116
bb115:
  %t478 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t479 = extractvalue { i64, ptr } %t478, 0
  store i64 %t479, ptr %l210, !tbaa !24
  %t480 = load i64, ptr %l210, !tbaa !24
  %t481 = mul i64 %t480, 1
  %t482 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t481)
  %t483 = insertvalue { i64, ptr } undef, i64 %t480, 0
  %t484 = insertvalue { i64, ptr } %t483, ptr %t482, 1
  store { i64, ptr } %t484, ptr %l211, !tbaa !27
  %t485 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !27
  %t487 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t488 = load ptr, ptr %t487, !tbaa !27
  %t489 = load i64, ptr %l210, !tbaa !24
  %t490 = mul i64 %t489, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t486, ptr %t488, i64 %t490, i1 false)
  %t491 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t491, ptr %l10, !tbaa !27
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t492 = load ptr, ptr %l5, !tbaa !29
  %t494 = getelementptr %"compiler/free:Free", ptr %t492, i32 0, i32 34
  store ptr %t494, ptr %l213, !tbaa !29
  %t495 = load i64, ptr %l1, !tbaa !24
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/free:walker", ptr %t496, i32 0, i32 1
  %t499 = load i64, ptr %t498, !tbaa !24
  %t500 = load i64, ptr %l6, !tbaa !24
  %t501 = load %"compiler/source:Span", ptr %l3
  %t502 = load i64, ptr %l7, !tbaa !24
  %t503 = load i64, ptr %l8, !tbaa !24
  %t504 = load i64, ptr %l9, !tbaa !24
  %t505 = load ptr, ptr %l2, !tbaa !29
  %t515 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v1, ptr %v0, ptr %v0, i64 %t495, i64 %t499, i64 %t500, %"compiler/source:Span" %t501, i64 %t502, i64 %t503, i64 %t504, ptr %t505, ptr null)
  store %"compiler/free:store" %t515, ptr %l224
  br label %bb118
bb118:
  %t516 = load ptr, ptr %l213, !tbaa !29
  %t517 = load %"compiler/free:store", ptr %l224
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t516, %"compiler/free:store" %t517)
  br label %bb119
bb119:
  %t518 = load i64, ptr %l7, !tbaa !24
  %t519 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t522 = icmp eq i64 %t518, %t519
  br i1 %t522, label %bb120, label %bb121
bb120:
  %t524 = load i64, ptr %l6, !tbaa !24
  store i64 %t524, ptr %l23, !tbaa !24
  %t526 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t526, ptr %l24
  %t528 = load ptr, ptr %l5, !tbaa !29
  %t530 = getelementptr %"compiler/free:Free", ptr %t528, i32 0, i32 42
  %t531 = load i64, ptr %t530, !tbaa !24
  %t533 = icmp sge i64 %t531, 0
  br i1 %t533, label %bb122, label %bb123
bb121:
  br label %bb126
bb122:
  %t535 = load ptr, ptr %l5, !tbaa !29
  %t537 = getelementptr %"compiler/free:Free", ptr %t535, i32 0, i32 43
  %t538 = load i64, ptr %t537, !tbaa !24
  %t540 = load ptr, ptr %l5, !tbaa !29
  %t542 = getelementptr %"compiler/free:Free", ptr %t540, i32 0, i32 44
  %t543 = load %"compiler/source:Span", ptr %t542
  store i64 %t538, ptr %l23, !tbaa !24
  store %"compiler/source:Span" %t543, ptr %l24
  %t549 = load ptr, ptr %l5, !tbaa !29
  %t551 = getelementptr %"compiler/free:Free", ptr %t549, i32 0, i32 42
  store i64 -1, ptr %t551, !tbaa !24
  br label %bb124
bb123:
  br label %bb124
bb124:
  %t552 = load ptr, ptr %l5, !tbaa !29
  %t553 = load i64, ptr %l1, !tbaa !24
  %t554 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t555 = load i64, ptr %l23, !tbaa !24
  %t556 = load %"compiler/source:Span", ptr %l24
  %t557 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s0, ptr %t552, i64 %t553, i64 %t554, i64 %t555, %"compiler/source:Span" %t556, { i64, ptr } %t557)
  br label %bb125
bb125:
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorStoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l10 = alloca i1
  %l13 = alloca ptr
  %l18 = alloca i64
  %l23 = alloca ptr
  %l29 = alloca %"compiler/free:orStore"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 17
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t6, i64 %t10)
  store i1 %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load i1, ptr %l10, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = call ptr @compiler_2ffree_2ederefRoot(ptr %v1, ptr %a1)
  store ptr %t19, ptr %l13
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  store ptr %t20, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store i64 %t29, ptr %l18
  br label %bb9
bb9:
  %t30 = load i64, ptr %l18, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp slt i64 %t31, 0
  br i1 %t33, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:walker", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/free:Free", ptr %t38, i32 0, i32 40
  store ptr %t40, ptr %l23, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/free:walker", ptr %t41, i32 0, i32 1
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t52 = call %"compiler/free:orStore" @compiler_2ffree_3aorStore_2ector(ptr %v2, ptr %v1, ptr %v0, i64 %t44, i64 %t45, ptr %a2, ptr %t47)
  store %"compiler/free:orStore" %t52, ptr %l29
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = load %"compiler/free:orStore", ptr %l29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2ePush_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v0, ptr %t53, %"compiler/free:orStore" %t54)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamPaths(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l57 = alloca i64
  %l61 = alloca i64
  %l65 = alloca i1
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i1
  %l100 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i1
  %l113 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l141 = alloca i1
  %l145 = alloca i64
  %l151 = alloca i64
  %l155 = alloca i1
  %l159 = alloca i1
  %l161 = alloca i1
  %l163 = alloca i1
  %l167 = alloca i1
  %l171 = alloca i1
  %l172 = alloca i1
  %l179 = alloca i1
  %l184 = alloca ptr
  %l186 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 43
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l29
  br label %bb1
bb1:
  %t11 = load i64, ptr %l29, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb7
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l36, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l36, !tbaa !24
  store i64 %t38, ptr %l33, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l33, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  br label %bb90
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/free:walker", ptr %t58, i32 0, i32 43
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l57
  br label %bb12
bb12:
  %t65 = load i64, ptr %l57, !tbaa !24
  store i64 %t65, ptr %l8, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 45
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l61
  br label %bb13
bb13:
  %t73 = load i64, ptr %l61, !tbaa !24
  store i64 %t73, ptr %l9, !tbaa !24
  store i1 false, ptr %l10, !tbaa !21
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:walker", ptr %t74, i32 0, i32 22
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t76, i64 %t77)
  store i1 %t80, ptr %l65
  br label %bb14
bb14:
  %t81 = load i1, ptr %l65, !tbaa !21
  store i1 %t81, ptr %l11, !tbaa !21
  store i64 0, ptr %l12, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 14
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l68
  br label %bb15
bb15:
  %t87 = load i64, ptr %l68, !tbaa !24
  store i64 %t87, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t88 = load i64, ptr %l13, !tbaa !24
  %t89 = load i64, ptr %l12, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb16, label %bb17
bb16:
  %t94 = load i64, ptr %l14, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb21
bb18:
  %t98 = load i64, ptr %l13, !tbaa !24
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l14, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l14, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l75, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb20
bb20:
  %t114 = load i64, ptr %l75, !tbaa !24
  store i64 %t114, ptr %l72, !tbaa !24
  br label %bb21
bb21:
  %t115 = load i64, ptr %l72, !tbaa !24
  store i64 %t115, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb22
bb22:
  %t116 = load i64, ptr %l16, !tbaa !24
  %t117 = load i64, ptr %l15, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb23, label %bb24
bb23:
  br label %bb38
bb24:
  br label %bb25
bb25:
  %t124 = load i64, ptr %l12, !tbaa !24
  %t125 = load i64, ptr %l16, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l17, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:walker", ptr %t134, i32 0, i32 14
  %t137 = load i64, ptr %l17, !tbaa !24
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l96
  br label %bb26
bb26:
  %t141 = load i64, ptr %l9, !tbaa !24
  %t142 = load i64, ptr %l96, !tbaa !24
  %t144 = icmp slt i64 %t142, %t141
  br i1 %t144, label %bb27, label %bb28
bb27:
  %t146 = load i64, ptr %l9, !tbaa !24
  store i64 %t146, ptr %l100, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/free:walker", ptr %t147, i32 0, i32 15
  %t150 = load i64, ptr %l17, !tbaa !24
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t149, i64 %t150)
  store i64 %t153, ptr %l104
  br label %bb29
bb28:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb30
bb29:
  %t154 = load i64, ptr %l100, !tbaa !24
  %t155 = load i64, ptr %l104, !tbaa !24
  %t156 = icmp sle i64 %t154, %t155
  store i1 %t156, ptr %l99, !tbaa !21
  br label %bb30
bb30:
  %t158 = load i1, ptr %l99, !tbaa !21
  br i1 %t158, label %bb31, label %bb32
bb31:
  %t159 = load i1, ptr %l11, !tbaa !21
  %t161 = xor i1 %t159, true
  store i1 %t161, ptr %l106, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb33
bb33:
  %t163 = load i1, ptr %l106, !tbaa !21
  br i1 %t163, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t164 = load i64, ptr %l16, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l16, !tbaa !24
  br label %bb22
bb38:
  store i64 0, ptr %l18, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/free:walker", ptr %t168, i32 0, i32 43
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t170)
  store i64 %t172, ptr %l113
  br label %bb39
bb39:
  %t173 = load i64, ptr %l113, !tbaa !24
  store i64 %t173, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t174 = load i64, ptr %l19, !tbaa !24
  %t175 = load i64, ptr %l18, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb40, label %bb41
bb40:
  %t180 = load i64, ptr %l20, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb45
bb42:
  %t184 = load i64, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l18, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l20, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l20, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l120, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb44
bb44:
  %t200 = load i64, ptr %l120, !tbaa !24
  store i64 %t200, ptr %l117, !tbaa !24
  br label %bb45
bb45:
  %t201 = load i64, ptr %l117, !tbaa !24
  store i64 %t201, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb46
bb46:
  %t202 = load i64, ptr %l22, !tbaa !24
  %t203 = load i64, ptr %l21, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb47, label %bb48
bb47:
  br label %bb80
bb48:
  br label %bb49
bb49:
  %t210 = load i64, ptr %l18, !tbaa !24
  %t211 = load i64, ptr %l22, !tbaa !24
  %t212 = load i64, ptr %l20, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l23, !tbaa !24
  %t220 = load i64, ptr %l23, !tbaa !24
  %t221 = load i64, ptr %l7, !tbaa !24
  %t224 = icmp eq i64 %t220, %t221
  br i1 %t224, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb53
bb51:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/free:walker", ptr %t226, i32 0, i32 43
  %t229 = load i64, ptr %l23, !tbaa !24
  %t232 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t228, i64 %t229)
  store i64 %t232, ptr %l145
  br label %bb52
bb52:
  %t233 = load i64, ptr %l8, !tbaa !24
  %t234 = load i64, ptr %l145, !tbaa !24
  %t236 = icmp ne i64 %t234, %t233
  store i1 %t236, ptr %l141, !tbaa !21
  br label %bb53
bb53:
  %t238 = load i1, ptr %l141, !tbaa !21
  br i1 %t238, label %bb54, label %bb55
bb54:
  br label %bb79
bb55:
  br label %bb56
bb56:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/free:walker", ptr %t239, i32 0, i32 45
  %t242 = load i64, ptr %l23, !tbaa !24
  %t245 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t241, i64 %t242)
  store i64 %t245, ptr %l151
  br label %bb57
bb57:
  %t246 = load i64, ptr %l151, !tbaa !24
  store i64 %t246, ptr %l24, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i64, ptr %l9, !tbaa !24
  %t249 = load i64, ptr %l24, !tbaa !24
  %t253 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexclusive(ptr %v0, ptr %t247, i64 %t248, i64 %t249)
  store i1 %t253, ptr %l155
  br label %bb58
bb58:
  %t254 = load i1, ptr %l155, !tbaa !21
  br i1 %t254, label %bb59, label %bb60
bb59:
  br label %bb79
bb60:
  br label %bb61
bb61:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i64, ptr %l9, !tbaa !24
  %t257 = load i64, ptr %l24, !tbaa !24
  %t261 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopAround(ptr %v0, ptr %t255, i64 %t256, i64 %t257)
  store i1 %t261, ptr %l159
  br label %bb62
bb62:
  %t262 = load i1, ptr %l159, !tbaa !21
  %t263 = xor i1 %t262, true
  br i1 %t263, label %bb63, label %bb64
bb63:
  %t265 = load i1, ptr %l11, !tbaa !21
  br i1 %t265, label %bb65, label %bb66
bb64:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb75
bb65:
  %t267 = load i64, ptr %l24, !tbaa !24
  %t268 = load i64, ptr %l9, !tbaa !24
  %t271 = icmp sgt i64 %t267, %t268
  store i1 %t271, ptr %l163, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb67
bb67:
  %t273 = load i1, ptr %l163, !tbaa !21
  br i1 %t273, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l167, !tbaa !21
  br label %bb74
bb69:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/free:walker", ptr %t274, i32 0, i32 22
  %t277 = load i64, ptr %l24, !tbaa !24
  %t280 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t276, i64 %t277)
  store i1 %t280, ptr %l171
  br label %bb70
bb70:
  %t281 = load i1, ptr %l171, !tbaa !21
  br i1 %t281, label %bb71, label %bb72
bb71:
  %t282 = load i64, ptr %l9, !tbaa !24
  %t283 = load i64, ptr %l24, !tbaa !24
  %t286 = icmp sgt i64 %t282, %t283
  store i1 %t286, ptr %l172, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb73
bb73:
  %t288 = load i1, ptr %l172, !tbaa !21
  store i1 %t288, ptr %l167, !tbaa !21
  br label %bb74
bb74:
  %t289 = load i1, ptr %l167, !tbaa !21
  store i1 %t289, ptr %l161, !tbaa !21
  br label %bb75
bb75:
  %t290 = load i1, ptr %l161, !tbaa !21
  br i1 %t290, label %bb76, label %bb77
bb76:
  br label %bb79
bb77:
  br label %bb78
bb78:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb79
bb79:
  %t291 = load i64, ptr %l22, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l22, !tbaa !24
  br label %bb46
bb80:
  %t295 = load i1, ptr %l10, !tbaa !21
  br i1 %t295, label %bb81, label %bb82
bb81:
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr %"compiler/free:Free", ptr %t297, i32 0, i32 23
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/free:walker", ptr %t300, i32 0, i32 1
  %t303 = load i64, ptr %t302, !tbaa !24
  %t306 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t299, i64 %t303)
  store ptr %t306, ptr %l184
  br label %bb83
bb82:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb85
bb83:
  %t307 = load i64, ptr %l8, !tbaa !24
  %t308 = load ptr, ptr %l184, !tbaa !29
  %t310 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t308, i64 %t307)
  store i1 %t310, ptr %l186
  br label %bb84
bb84:
  %t311 = load i1, ptr %l186, !tbaa !21
  store i1 %t311, ptr %l179, !tbaa !21
  br label %bb85
bb85:
  %t312 = load i1, ptr %l179, !tbaa !21
  br i1 %t312, label %bb86, label %bb87
bb86:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr %"compiler/free:Free", ptr %t313, i32 0, i32 30
  store i1 true, ptr %t315, !tbaa !21
  br label %bb88
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t316 = load i64, ptr %l6, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l6, !tbaa !24
  br label %bb8
bb90:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %lp14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %lp18 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i1
  %l33 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i1
  %l45 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i32
  %l58 = alloca i64
  %l61 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l75 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca ptr
  %l77 = alloca i1
  %l86 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l109 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca i32
  %l120 = alloca i64
  %l123 = alloca ptr
  %l126 = alloca i64
  %l127 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l138 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l139 = alloca ptr
  %l140 = alloca i1
  %l147 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l148 = alloca ptr
  %l149 = alloca i1
  %l152 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l155 = alloca i64
  %l157 = alloca ptr
  %l160 = alloca ptr
  %l162 = alloca ptr
  %l165 = alloca i64
  %l167 = alloca ptr
  %l168 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l169 = alloca ptr
  %l173 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t7 = load ptr, ptr %l21, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l21, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l22, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l22, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb24
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l4, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t31 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euse(ptr %v0, ptr %t27, i64 %t30, %"compiler/source:Span" %t31)
  br label %bb6
bb6:
  %t35 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l33
  br label %bb7
bb7:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t36, ptr %lp5
  %t37 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  %t38 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %t38
  %t39 = load ptr, ptr %lp5
  store ptr %t39, ptr %l34, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t40, i32 0, i32 3
  %t43 = load i32, ptr %l4, !tbaa !23
  %t45 = sext i32 %t43 to i64
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t42, i64 %t45)
  store ptr %t48, ptr %l39
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l34, !tbaa !29
  %t50 = load ptr, ptr %l39, !tbaa !29
  %t51 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %v0, ptr %t49, ptr %t50)
  store i1 %t51, ptr %l40
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 4
  %t55 = load i32, ptr %l4, !tbaa !23
  %t57 = sext i32 %t55 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t54, i64 %t57, i1 true)
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:walker", ptr %t60, i32 0, i32 7
  %t63 = load i32, ptr %l4, !tbaa !23
  %t65 = sext i32 %t63 to i64
  %t68 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t62, i64 %t65)
  %t69 = extractvalue { i32, i64 } %t68, 1
  %t70 = extractvalue { i32, i64 } %t68, 0
  store i32 %t70, ptr %l51
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb12, label %ok.72
ok.72:
  store i64 %t69, ptr %l50
  br label %bb11
bb11:
  %t73 = load i64, ptr %l50, !tbaa !24
  store i64 %t73, ptr %l45, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l45, !tbaa !24
  br label %bb14
bb14:
  %t74 = load i64, ptr %l45, !tbaa !24
  store i64 %t74, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp sge i64 %t75, 0
  br i1 %t77, label %bb15, label %bb16
bb15:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:walker", ptr %t80, i32 0, i32 8
  %t83 = load i32, ptr %t82, !tbaa !23
  %t84 = load i64, ptr %l6, !tbaa !24
  %t88 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t79, i32 %t83, i64 %t84)
  store i64 %t88, ptr %l58
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t89 = load i64, ptr %l58, !tbaa !24
  store i64 %t89, ptr %l7, !tbaa !24
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp sge i64 %t90, 0
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t94 = load ptr, ptr %lp5
  store ptr %t94, ptr %l61, !tbaa !29
  %t95 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = call i64 @compiler_2ffree_2eorig(i64 %t95, i64 %t96)
  store i64 %t99, ptr %l64
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t100 = load ptr, ptr %l61, !tbaa !29
  %t101 = load i64, ptr %l64, !tbaa !24
  %t102 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t100, i64 %t101)
  store i1 %t102, ptr %l65
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t103 = load ptr, ptr %lp5
  %t104 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t103
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %rv
  br label %ret
bb24:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t107 = load ptr, ptr %l67, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb25, label %bb26
bb25:
  %t110 = load ptr, ptr %l67, !tbaa !29
  %t111 = load i64, ptr %t110
  %t113 = icmp eq i64 %t111, 2
  store i1 %t113, ptr %l68, !tbaa !21
  br label %bb26
bb26:
  %t114 = load i1, ptr %l68, !tbaa !21
  br i1 %t114, label %bb27, label %bb28
bb27:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l8, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l8, !tbaa !29
  %t125 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t121, ptr %t122)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t125, ptr %l75
  br label %bb30
bb30:
  %t126 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l75
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t126, ptr %rv
  br label %ret
bb31:
  %t127 = load ptr, ptr %l1, !tbaa !29
  store ptr %t127, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t128 = load ptr, ptr %l76, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb32, label %bb33
bb32:
  %t131 = load ptr, ptr %l76, !tbaa !29
  %t132 = load i64, ptr %t131
  %t134 = icmp eq i64 %t132, 3
  store i1 %t134, ptr %l77, !tbaa !21
  br label %bb33
bb33:
  %t135 = load i1, ptr %l77, !tbaa !21
  br i1 %t135, label %bb34, label %bb35
bb34:
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t138, i32 0, i32 2
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l9, !tbaa !29
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t144, i32 0, i32 3
  %t146 = load i64, ptr %t145
  store i64 %t146, ptr %l10, !tbaa !24
  br label %bb36
bb35:
  br label %bb45
bb36:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l9, !tbaa !29
  %t152 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t148, ptr %t149)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %l86
  br label %bb37
bb37:
  %t153 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t153, ptr %lp11
  %t154 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  %t155 = load ptr, ptr %lp11
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %t155
  %t156 = load ptr, ptr %l2, !tbaa !29
  store ptr %t156, ptr %l87, !tbaa !29
  %t157 = load ptr, ptr %l9, !tbaa !29
  %t159 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t157)
  store i32 %t159, ptr %l89
  br label %bb38
bb38:
  %t160 = load i64, ptr %l10, !tbaa !24
  %t161 = load ptr, ptr %l87, !tbaa !29
  %t162 = load i32, ptr %l89, !tbaa !23
  %t164 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t161, i32 %t162, i64 %t160)
  store i64 %t164, ptr %l91
  br label %bb39
bb39:
  %t165 = load i64, ptr %l91, !tbaa !24
  store i64 %t165, ptr %l12, !tbaa !24
  %t166 = load i64, ptr %l12, !tbaa !24
  %t168 = icmp sge i64 %t166, 0
  br i1 %t168, label %bb40, label %bb41
bb40:
  %t170 = load ptr, ptr %lp11
  store ptr %t170, ptr %l94, !tbaa !29
  %t171 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t172 = load i64, ptr %l12, !tbaa !24
  %t175 = call i64 @compiler_2ffree_2eorig(i64 %t171, i64 %t172)
  store i64 %t175, ptr %l97
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t176 = load ptr, ptr %l94, !tbaa !29
  %t177 = load i64, ptr %l97, !tbaa !24
  %t178 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t176, i64 %t177)
  store i1 %t178, ptr %l98
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t179 = load ptr, ptr %lp11
  %t180 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t179
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %rv
  br label %ret
bb45:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t183 = load ptr, ptr %l100, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb46, label %bb47
bb46:
  %t186 = load ptr, ptr %l100, !tbaa !29
  %t187 = load i64, ptr %t186
  %t189 = icmp eq i64 %t187, 4
  store i1 %t189, ptr %l101, !tbaa !21
  br label %bb47
bb47:
  %t190 = load i1, ptr %l101, !tbaa !21
  br i1 %t190, label %bb48, label %bb49
bb48:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t193, i32 0, i32 2
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l13, !tbaa !29
  br label %bb50
bb49:
  br label %bb61
bb50:
  store %olang.scope zeroinitializer, ptr %s7
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l13, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Elem", ptr %t198, i32 0, i32 0
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t204 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t197, ptr %t201)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t204, ptr %l109
  br label %bb51
bb51:
  %t205 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t205, ptr %lp14
  %t206 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  %t207 = load ptr, ptr %lp14
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t206, ptr %t207
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l13, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Elem", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t215 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s7, ptr %t208, ptr %t212)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t215, ptr %l113
  br label %bb52
bb52:
  %t216 = load ptr, ptr %l2, !tbaa !29
  store ptr %t216, ptr %l114, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  store ptr %t217, ptr %l115, !tbaa !29
  %t218 = load ptr, ptr %l13, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Elem", ptr %t218, i32 0, i32 0
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t221)
  store i32 %t223, ptr %l118
  br label %bb53
bb53:
  %t224 = load ptr, ptr %l115, !tbaa !29
  %t225 = load i32, ptr %l118, !tbaa !23
  %t226 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t224, i32 %t225)
  store i32 %t226, ptr %l119
  br label %bb54
bb54:
  %t227 = load ptr, ptr %l114, !tbaa !29
  %t228 = load i32, ptr %l119, !tbaa !23
  %t229 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t227, i32 %t228, i64 -1)
  store i64 %t229, ptr %l120
  br label %bb55
bb55:
  %t230 = load i64, ptr %l120, !tbaa !24
  store i64 %t230, ptr %l15, !tbaa !24
  %t231 = load i64, ptr %l15, !tbaa !24
  %t233 = icmp sge i64 %t231, 0
  br i1 %t233, label %bb56, label %bb57
bb56:
  %t235 = load ptr, ptr %lp14
  store ptr %t235, ptr %l123, !tbaa !29
  %t236 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t237 = load i64, ptr %l15, !tbaa !24
  %t240 = call i64 @compiler_2ffree_2eorig(i64 %t236, i64 %t237)
  store i64 %t240, ptr %l126
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t241 = load ptr, ptr %l123, !tbaa !29
  %t242 = load i64, ptr %l126, !tbaa !24
  %t243 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t241, i64 %t242)
  store i1 %t243, ptr %l127
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t244 = load ptr, ptr %lp14
  %t245 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t244
  call void @__olang_scope_close(ptr %s7)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t245, ptr %rv
  br label %ret
bb61:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t248 = load ptr, ptr %l129, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb62, label %bb63
bb62:
  %t251 = load ptr, ptr %l129, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 5
  store i1 %t254, ptr %l130, !tbaa !21
  br label %bb63
bb63:
  %t255 = load i1, ptr %l130, !tbaa !21
  br i1 %t255, label %bb64, label %bb65
bb64:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [4 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 2
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l16, !tbaa !29
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l16, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Payload", ptr %t263, i32 0, i32 0
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t269 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t262, ptr %t266)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t269, ptr %l138
  br label %bb67
bb67:
  %t270 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l138
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t270, ptr %rv
  br label %ret
bb68:
  %t271 = load ptr, ptr %l1, !tbaa !29
  store ptr %t271, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t272 = load ptr, ptr %l139, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb69, label %bb70
bb69:
  %t275 = load ptr, ptr %l139, !tbaa !29
  %t276 = load i64, ptr %t275
  %t278 = icmp eq i64 %t276, 6
  store i1 %t278, ptr %l140, !tbaa !21
  br label %bb70
bb70:
  %t279 = load i1, ptr %l140, !tbaa !21
  br i1 %t279, label %bb71, label %bb72
bb71:
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t282 = getelementptr { i64, [4 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t282, i32 0, i32 2
  %t284 = load ptr, ptr %t283
  store ptr %t284, ptr %l17, !tbaa !29
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load ptr, ptr %l17, !tbaa !29
  %t290 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t286, ptr %t287)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t290, ptr %l147
  br label %bb74
bb74:
  %t291 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l147
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t291, ptr %rv
  br label %ret
bb75:
  %t292 = load ptr, ptr %l1, !tbaa !29
  store ptr %t292, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t293 = load ptr, ptr %l148, !tbaa !29
  %t294 = icmp ne ptr %t293, null
  br i1 %t294, label %bb76, label %bb77
bb76:
  %t296 = load ptr, ptr %l148, !tbaa !29
  %t297 = load i64, ptr %t296
  %t299 = icmp eq i64 %t297, 7
  store i1 %t299, ptr %l149, !tbaa !21
  br label %bb77
bb77:
  %t300 = load i1, ptr %l149, !tbaa !21
  br i1 %t300, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb89
bb80:
  %t301 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t301, ptr %l152
  br label %bb81
bb81:
  %t302 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t302, ptr %lp18
  %t303 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l152
  %t304 = load ptr, ptr %lp18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t303, ptr %t304
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/free:walker", ptr %t305, i32 0, i32 9
  %t309 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2eLen_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %t307)
  store i64 %t309, ptr %l155
  br label %bb82
bb82:
  %t310 = load i64, ptr %l155, !tbaa !24
  %t311 = icmp sgt i64 %t310, 0
  br i1 %t311, label %bb83, label %bb84
bb83:
  %t313 = load ptr, ptr %l0, !tbaa !29
  store ptr %t313, ptr %l157, !tbaa !29
  %t314 = load ptr, ptr %l157, !tbaa !29
  %t315 = getelementptr %"compiler/free:walker", ptr %t314, i32 0, i32 29
  %t316 = load i64, ptr %t315, !tbaa !24
  %t318 = add i64 %t316, 1
  %t320 = load ptr, ptr %l157, !tbaa !29
  %t321 = getelementptr %"compiler/free:walker", ptr %t320, i32 0, i32 29
  store i64 %t318, ptr %t321, !tbaa !24
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l160, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/free:walker", ptr %t323, i32 0, i32 9
  store ptr %t325, ptr %l162, !tbaa !29
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/free:walker", ptr %t326, i32 0, i32 9
  %t330 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2eLen_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %t328)
  store i64 %t330, ptr %l165
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t331 = load i64, ptr %l165, !tbaa !24
  %t332 = sub i64 %t331, 1
  %t333 = load ptr, ptr %l162, !tbaa !29
  %t335 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %v0, ptr %t333, i64 %t332)
  store ptr %t335, ptr %l167
  br label %bb86
bb86:
  %t336 = load ptr, ptr %l160, !tbaa !29
  %t337 = load ptr, ptr %l167, !tbaa !29
  %t338 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v0, ptr %v2, ptr %t336, ptr %t337)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t338, ptr %l168
  br label %bb87
bb87:
  %t339 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l168
  %t340 = load ptr, ptr %lp18
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t339, ptr %t340
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l169, !tbaa !29
  %t342 = load ptr, ptr %l169, !tbaa !29
  %t343 = getelementptr %"compiler/free:walker", ptr %t342, i32 0, i32 29
  %t344 = load i64, ptr %t343, !tbaa !24
  %t346 = sub i64 %t344, 1
  %t348 = load ptr, ptr %l169, !tbaa !29
  %t349 = getelementptr %"compiler/free:walker", ptr %t348, i32 0, i32 29
  store i64 %t346, ptr %t349, !tbaa !24
  br label %bb88
bb88:
  %t350 = load ptr, ptr %lp18
  %t351 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t350
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t351, ptr %rv
  br label %ret
bb89:
  br i1 true, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t353 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t353, ptr %l173
  br label %bb93
bb93:
  %t354 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l173
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t354, ptr %rv
  br label %ret
bb94:
  call void @__olang_check_failed(ptr @olang_loc_bfa96af29dec6ca7_6eacd8161d4b79f3)
  unreachable
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/free:leaf"
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i1
  %l26 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca %"compiler/free:leaf"
  %l36 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i1
  %l45 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t6, ptr %t7)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t11, ptr %lp4
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t13 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %t13
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  store i64 %t18, ptr %l16
  br label %bb2
bb2:
  %t19 = load i64, ptr %l16, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sge i64 %t20, 0
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load ptr, ptr %lp4
  store ptr %t24, ptr %l19, !tbaa !29
  %t25 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = call i64 @compiler_2ffree_2eorig(i64 %t25, i64 %t26)
  store i64 %t29, ptr %l22
  br label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t31 = load i32, ptr %l2, !tbaa !23
  %t34 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t30, i32 %t31)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l26
  br label %bb7
bb5:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t35, i64 %t36)
  store i1 %t37, ptr %l23
  br label %bb6
bb6:
  br label %bb18
bb7:
  %t38 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  %t39 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %t39
  store ptr %t39, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l7, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load ptr, ptr %l6, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %t42)
  store i64 %t44, ptr %l30
  br label %bb9
bb9:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = load i64, ptr %l30, !tbaa !24
  %t47 = icmp slt i64 %t45, %t46
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb10, label %bb11
bb10:
  br label %bb17
bb11:
  br label %bb12
bb12:
  %t51 = load ptr, ptr %l6, !tbaa !29
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store %"compiler/free:leaf" %t55, ptr %l35
  br label %bb13
bb13:
  %t56 = load %"compiler/free:leaf", ptr %l35
  store %"compiler/free:leaf" %t56, ptr %l8
  %t57 = load ptr, ptr %lp4
  store ptr %t57, ptr %l36, !tbaa !29
  %t58 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t59 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !24
  %t63 = call i64 @compiler_2ffree_2eorig(i64 %t58, i64 %t60)
  store i64 %t63, ptr %l39
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = load i64, ptr %l39, !tbaa !24
  %t66 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t64, i64 %t65)
  store i1 %t66, ptr %l40
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l7, !tbaa !24
  br label %bb8
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l2, !tbaa !23
  %t75 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %t71, i32 %t72)
  store i1 %t75, ptr %l45
  br label %bb19
bb19:
  %t76 = load i1, ptr %l45, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %lp4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v2, ptr %t77, ptr %t78)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t81 = load ptr, ptr %lp4
  %t82 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t81
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2eremoves(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l48 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i1
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l64 = alloca %"compiler/source:Span"
  %l67 = alloca i1
  %l70 = alloca i1
  %l75 = alloca i1
  %l77 = alloca ptr
  %l79 = alloca ptr
  %l81 = alloca i64
  %l85 = alloca %"compiler/source:Span"
  %l86 = alloca { i64, ptr }
  %l92 = alloca i1
  %l95 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i1
  %l108 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t5, ptr %l15, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l16, !tbaa !24
  %t8 = load i64, ptr %l16, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l17, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l16, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t19, ptr %l15, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:walker", ptr %t21, i32 0, i32 36
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l20
  br label %bb4
bb4:
  %t26 = load i64, ptr %l20, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = load i64, ptr %l4, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb10
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l27, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb9
bb9:
  %t53 = load i64, ptr %l27, !tbaa !24
  store i64 %t53, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t54 = load i64, ptr %l24, !tbaa !24
  store i64 %t54, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load i64, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l5, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb62
bb13:
  br label %bb14
bb14:
  %t63 = load i64, ptr %l2, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l4, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l7, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 41
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  store i64 %t79, ptr %l48
  br label %bb15
bb15:
  %t80 = load i64, ptr %l48, !tbaa !24
  store i64 %t80, ptr %l8, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:walker", ptr %t81, i32 0, i32 36
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l52
  br label %bb16
bb16:
  %t88 = load i64, ptr %l1, !tbaa !24
  %t89 = load i64, ptr %l52, !tbaa !24
  %t91 = icmp ne i64 %t89, %t88
  br i1 %t91, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb21
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/free:walker", ptr %t93, i32 0, i32 40
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t95, i64 %t96)
  store %"compiler/source:Span" %t99, ptr %l59
  br label %bb19
bb19:
  %t100 = getelementptr %"compiler/source:Span", ptr %l59, i32 0, i32 0
  %t101 = load i32, ptr %t100, !tbaa !23
  store i32 %t101, ptr %l60, !tbaa !23
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/free:walker", ptr %t102, i32 0, i32 40
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t104, i64 %t105)
  store %"compiler/source:Span" %t108, ptr %l64
  br label %bb20
bb20:
  %t109 = getelementptr %"compiler/source:Span", ptr %l64, i32 0, i32 1
  %t110 = load i32, ptr %t109, !tbaa !23
  %t111 = load i32, ptr %l60, !tbaa !23
  %t113 = icmp sge i32 %t111, %t110
  store i1 %t113, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t115 = load i1, ptr %l55, !tbaa !21
  br i1 %t115, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb24
bb23:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  store i1 %t118, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t120 = load i1, ptr %l67, !tbaa !21
  br i1 %t120, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb28
bb26:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/free:walker", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/free:Free", ptr %t124, i32 0, i32 18
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t126, i64 %t127)
  store i1 %t130, ptr %l75
  br label %bb27
bb27:
  %t131 = load i1, ptr %l75, !tbaa !21
  store i1 %t131, ptr %l70, !tbaa !21
  br label %bb28
bb28:
  %t132 = load i1, ptr %l70, !tbaa !21
  br i1 %t132, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb30:
  br label %bb31
bb31:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/free:walker", ptr %t133, i32 0, i32 0
  %t136 = load ptr, ptr %t135, !tbaa !29
  store ptr %t136, ptr %l77, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t137)
  store ptr %t139, ptr %l79
  br label %bb32
bb32:
  %t140 = load ptr, ptr %l79, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Body", ptr %t140, i32 0, i32 3
  %t143 = load i64, ptr %t142, !tbaa !24
  store i64 %t143, ptr %l81, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/free:walker", ptr %t144, i32 0, i32 40
  %t147 = load i64, ptr %l7, !tbaa !24
  %t150 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t146, i64 %t147)
  store %"compiler/source:Span" %t150, ptr %l85
  br label %bb33
bb33:
  %t151 = load ptr, ptr %l77, !tbaa !29
  %t152 = load i64, ptr %l81, !tbaa !24
  %t153 = load %"compiler/source:Span", ptr %l85
  %t154 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s3, ptr %t151, i64 %t152, %"compiler/source:Span" %t153)
  store { i64, ptr } %t154, ptr %l86
  br label %bb34
bb34:
  %t155 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t155, ptr %l9, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t160 = sub i64 %t158, 1
  store i64 %t160, ptr %l10, !tbaa !24
  br label %bb35
bb35:
  %t162 = load i64, ptr %l10, !tbaa !24
  %t164 = icmp sge i64 %t162, 0
  br i1 %t164, label %bb36, label %bb37
bb36:
  %t166 = load i64, ptr %l10, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr i8, ptr %t169, i64 %t166
  %t171 = load i8, ptr %t170, !tbaa !32
  %t173 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t171)
  store i1 %t173, ptr %l95
  br label %bb38
bb37:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb46
bb38:
  %t174 = load i1, ptr %l95, !tbaa !21
  br i1 %t174, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb42
bb40:
  %t175 = load i64, ptr %l10, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i8, ptr %t178, i64 %t175
  %t180 = load i8, ptr %t179, !tbaa !32
  %t182 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t180)
  store i1 %t182, ptr %l99
  br label %bb41
bb41:
  %t183 = load i1, ptr %l99, !tbaa !21
  store i1 %t183, ptr %l96, !tbaa !21
  br label %bb42
bb42:
  %t184 = load i1, ptr %l96, !tbaa !21
  br i1 %t184, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb45
bb44:
  %t185 = load i64, ptr %l10, !tbaa !24
  %t187 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i8, ptr %t188, i64 %t185
  %t190 = load i8, ptr %t189, !tbaa !32
  %t192 = icmp eq i8 %t190, 95
  store i1 %t192, ptr %l100, !tbaa !21
  br label %bb45
bb45:
  %t194 = load i1, ptr %l100, !tbaa !21
  store i1 %t194, ptr %l92, !tbaa !21
  br label %bb46
bb46:
  %t195 = load i1, ptr %l92, !tbaa !21
  %t196 = xor i1 %t195, true
  br i1 %t196, label %bb47, label %bb48
bb47:
  br label %bb51
bb48:
  br label %bb49
bb49:
  %t198 = load i64, ptr %l10, !tbaa !24
  %t200 = sub i64 %t198, 1
  store i64 %t200, ptr %l10, !tbaa !24
  br label %bb50
bb50:
  br label %bb35
bb51:
  %t202 = load i64, ptr %l10, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l108, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  store i64 %t207, ptr %l110, !tbaa !24
  %t208 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  store i64 %t209, ptr %l111, !tbaa !24
  %t210 = load i64, ptr %l108, !tbaa !24
  %t211 = icmp sge i64 %t210, 0
  br i1 %t211, label %bb52, label %bb53
bb52:
  %t213 = load i64, ptr %l108, !tbaa !24
  %t214 = load i64, ptr %l110, !tbaa !24
  %t215 = icmp sle i64 %t213, %t214
  br i1 %t215, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_3f338d8afa9da51a_e8058e9e002c9166)
  unreachable
bb54:
  %t217 = load i64, ptr %l110, !tbaa !24
  %t218 = load i64, ptr %l111, !tbaa !24
  %t219 = icmp sle i64 %t217, %t218
  br i1 %t219, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_3f338d8afa9da51a_e8058e9e002c9166)
  unreachable
bb56:
  %t221 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = load i64, ptr %l108, !tbaa !24
  %t224 = load i64, ptr %l110, !tbaa !24
  %t225 = getelementptr i8, ptr %t222, i64 %t223
  %t226 = sub i64 %t224, %t223
  %t227 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t225, 1
  store { i64, ptr } %t228, ptr %l11, !tbaa !27
  %t230 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t234 = icmp sgt i64 %t232, 0
  br i1 %t234, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_3f338d8afa9da51a_e8058e9e002c9166)
  unreachable
bb58:
  %t236 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t237 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t240 = extractvalue { i64, ptr } %t236, 1
  %t241 = extractvalue { i64, ptr } %t236, 0
  %t242 = add i64 %t238, %t241
  %t243 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t242)
  call void @olang_textcopy(ptr %t243, ptr %t237, i64 %t238)
  %t244 = getelementptr i8, ptr %t243, i64 %t238
  call void @olang_textcopy(ptr %t244, ptr %t240, i64 %t241)
  %t245 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t243, 1
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t246, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s3)
  br label %bb61
bb61:
  %t248 = load i64, ptr %l6, !tbaa !24
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l6, !tbaa !24
  br label %bb11
bb62:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l123, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t252, ptr %l124, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  store i64 %t254, ptr %l125, !tbaa !24
  %t255 = load i64, ptr %l125, !tbaa !24
  %t256 = mul i64 %t255, 1
  %t257 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t256)
  %t258 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  store { i64, ptr } %t259, ptr %l126, !tbaa !27
  %t260 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = load i64, ptr %l125, !tbaa !24
  %t265 = mul i64 %t264, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t261, ptr %t263, i64 %t265, i1 false)
  %t266 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t266, ptr %l124, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t267, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 4
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l16, !tbaa !24
  store i64 %t33, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l13, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t55, i64 %t51, i1 false)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb8
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t63, i32 0, i32 11
  store i64 0, ptr %t65, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 12
  store i64 0, ptr %t68, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:walker", ptr %t69, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t71)
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t75)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:walker", ptr %t77, i32 0, i32 22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t79)
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:walker", ptr %t81, i32 0, i32 15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t83)
  br label %bb18
bb18:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t87)
  br label %bb19
bb19:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/free:walker", ptr %t89, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t91)
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/free:walker", ptr %t93, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t95)
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/free:walker", ptr %t97, i32 0, i32 19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t99)
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/free:walker", ptr %t101, i32 0, i32 24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t103)
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:walker", ptr %t105, i32 0, i32 25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t107)
  br label %bb24
bb24:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/free:walker", ptr %t109, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t111)
  br label %bb25
bb25:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/free:walker", ptr %t113, i32 0, i32 27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t115)
  br label %bb26
bb26:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:walker", ptr %t117, i32 0, i32 34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t119)
  br label %bb27
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/free:walker", ptr %t121, i32 0, i32 35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t123)
  br label %bb28
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:walker", ptr %t125, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t127)
  br label %bb29
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/free:walker", ptr %t129, i32 0, i32 37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t131)
  br label %bb30
bb30:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/free:walker", ptr %t133, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t135)
  br label %bb31
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/free:walker", ptr %t137, i32 0, i32 39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t139)
  br label %bb32
bb32:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/free:walker", ptr %t141, i32 0, i32 40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t143)
  br label %bb33
bb33:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/free:walker", ptr %t145, i32 0, i32 41
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t147)
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/free:walker", ptr %t149, i32 0, i32 42
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t151)
  br label %bb35
bb35:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/free:walker", ptr %t153, i32 0, i32 43
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t155)
  br label %bb36
bb36:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/free:walker", ptr %t157, i32 0, i32 44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t159)
  br label %bb37
bb37:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/free:walker", ptr %t161, i32 0, i32 45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t163)
  br label %bb38
bb38:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/free:walker", ptr %t165, i32 0, i32 46
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t167)
  br label %bb39
bb39:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:walker", ptr %t169, i32 0, i32 47
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t171)
  br label %bb40
bb40:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/free:walker", ptr %t173, i32 0, i32 48
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t175)
  br label %bb41
bb41:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/free:walker", ptr %t177, i32 0, i32 49
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t179)
  br label %bb42
bb42:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/free:walker", ptr %t181, i32 0, i32 50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t183)
  br label %bb43
bb43:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/free:walker", ptr %t185, i32 0, i32 51
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t187)
  br label %bb44
bb44:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/free:walker", ptr %t189, i32 0, i32 52
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t191)
  br label %bb45
bb45:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/free:walker", ptr %t193, i32 0, i32 53
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t195)
  br label %bb46
bb46:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/free:walker", ptr %t197, i32 0, i32 54
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t199)
  br label %bb47
bb47:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/free:walker", ptr %t201, i32 0, i32 55
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t203)
  br label %bb48
bb48:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/free:walker", ptr %t205, i32 0, i32 56
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t207)
  br label %bb49
bb49:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/free:walker", ptr %t209, i32 0, i32 57
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t211)
  br label %bb50
bb50:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eresult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i1
  %l23 = alloca i64
  %l26 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l9, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l16
  br label %bb6
bb6:
  %t23 = load i64, ptr %l16, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = call i64 @compiler_2ffree_2eokind(i64 %t24)
  store i64 %t26, ptr %l18
  br label %bb7
bb7:
  %t27 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t28 = load i64, ptr %l18, !tbaa !24
  %t30 = icmp eq i64 %t28, %t27
  br i1 %t30, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb16
bb9:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = call i64 @compiler_2ffree_2eokind(i64 %t32)
  store i64 %t34, ptr %l23
  br label %bb10
bb10:
  %t35 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t36 = load i64, ptr %l23, !tbaa !24
  %t38 = icmp eq i64 %t36, %t35
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l2, !tbaa !29
  store ptr %t40, ptr %l27, !tbaa !29
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = call i64 @compiler_2ffree_2eoval(i64 %t41)
  store i64 %t43, ptr %l29
  br label %bb13
bb12:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb15
bb13:
  %t44 = load ptr, ptr %l27, !tbaa !29
  %t45 = load i64, ptr %l29, !tbaa !24
  %t46 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t44, i64 %t45)
  store i1 %t46, ptr %l30
  br label %bb14
bb14:
  %t47 = load i1, ptr %l30, !tbaa !21
  store i1 %t47, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t48 = load i1, ptr %l26, !tbaa !21
  store i1 %t48, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l21, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/free:Free", ptr %t50, i32 0, i32 20
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %t55, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t52, i64 %t56)
  store ptr %t59, ptr %l35
  br label %bb20
bb20:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load ptr, ptr %l35, !tbaa !29
  %t63 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t61, i64 %t60)
  store i1 %t63, ptr %l37
  br label %bb21
bb21:
  %t64 = load i1, ptr %l37, !tbaa !21
  br i1 %t64, label %bb22, label %bb23
bb22:
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 30
  store i1 true, ptr %t67, !tbaa !21
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l4, !tbaa !24
  br label %bb1
bb26:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb26
bb6:
  %t26 = load ptr, ptr %l4, !tbaa !29
  store ptr %t26, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb20
bb11:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l22
  br label %bb12
bb12:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l26
  br label %bb15
bb14:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb16
bb15:
  %t46 = load i1, ptr %l26, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_311feee871305b59_d38294057dde4ced)
  unreachable
bb25:
  store ptr null, ptr %rv
  br label %ret
bb26:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb27, label %bb28
bb27:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58
  %t61 = icmp eq i64 %t59, 3
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb28
bb28:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb29, label %bb30
bb29:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = call ptr @compiler_2ffree_2ederefRoot(ptr %v1, ptr %t69)
  store ptr %t71, ptr %l38
  br label %bb32
bb32:
  %t72 = load ptr, ptr %l38, !tbaa !29
  store ptr %t72, ptr %rv
  br label %ret
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store ptr null, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_421add8d063ee188_aab923ea260c413c)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l37 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i1
  %l63 = alloca i1
  %l68 = alloca i64
  %l77 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l11, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t11)
  store i32 %t13, ptr %l14
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t16, ptr %l15
  br label %bb3
bb3:
  %t17 = load i1, ptr %l15, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb8
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  store ptr %t20, ptr %l18, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l20
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l18, !tbaa !29
  %t25 = load i32, ptr %l20, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t26, ptr %l21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l21, !tbaa !21
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t30 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t33 = load ptr, ptr %l24, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l24, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb46
bb16:
  %t47 = load ptr, ptr %l5, !tbaa !29
  store ptr %t47, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t48 = load ptr, ptr %l30, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 0
  store i1 %t54, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t55 = load i1, ptr %l31, !tbaa !21
  br i1 %t55, label %bb19, label %bb20
bb19:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t58, i32 0, i32 2
  %t60 = load i32, ptr %t59
  store i32 %t60, ptr %l6, !tbaa !23
  br label %bb21
bb20:
  br label %bb29
bb21:
  %t62 = load i32, ptr %l6, !tbaa !23
  %t64 = sext i32 %t62 to i64
  store i64 %t64, ptr %l37, !tbaa !24
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 45
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/free:walker", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %t70, !tbaa !24
  %t74 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t67, i64 %t71)
  store ptr %t74, ptr %l42
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t75)
  store i64 %t76, ptr %l43
  br label %bb23
bb23:
  %t77 = load i64, ptr %l37, !tbaa !24
  %t78 = load i64, ptr %l43, !tbaa !24
  %t79 = icmp slt i64 %t77, %t78
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr %"compiler/free:Free", ptr %t81, i32 0, i32 45
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:walker", ptr %t84, i32 0, i32 1
  %t87 = load i64, ptr %t86, !tbaa !24
  %t90 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t83, i64 %t87)
  store ptr %t90, ptr %l50
  br label %bb26
bb25:
  %t91 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t91, ptr %l45, !tbaa !24
  br label %bb28
bb26:
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = load i32, ptr %l6, !tbaa !23
  %t96 = sext i32 %t94 to i64
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t93, i64 %t96)
  store i64 %t99, ptr %l54
  br label %bb27
bb27:
  %t100 = load i64, ptr %l54, !tbaa !24
  store i64 %t100, ptr %l45, !tbaa !24
  br label %bb28
bb28:
  %t101 = load i64, ptr %l45, !tbaa !24
  store i64 %t101, ptr %l4, !tbaa !24
  br label %bb45
bb29:
  %t102 = load ptr, ptr %l5, !tbaa !29
  store ptr %t102, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t103 = load ptr, ptr %l56, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l56, !tbaa !29
  %t107 = load i64, ptr %t106
  %t109 = icmp eq i64 %t107, 3
  store i1 %t109, ptr %l57, !tbaa !21
  br label %bb31
bb31:
  %t110 = load i1, ptr %l57, !tbaa !21
  br i1 %t110, label %bb32, label %bb33
bb32:
  %t111 = load ptr, ptr %l5, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l7, !tbaa !29
  br label %bb34
bb33:
  br label %bb40
bb34:
  %t117 = load ptr, ptr %l7, !tbaa !29
  %t119 = call i1 @compiler_2ffree_2epureBase(ptr %v1, ptr %t117)
  store i1 %t119, ptr %l63
  br label %bb35
bb35:
  %t120 = load i1, ptr %l63, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb36, label %bb37
bb36:
  store i64 -1, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t128 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  store i64 %t128, ptr %l68
  br label %bb39
bb39:
  %t129 = load i64, ptr %l68, !tbaa !24
  store i64 %t129, ptr %l4, !tbaa !24
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i64 -1, ptr %rv
  br label %ret
bb44:
  call void @__olang_check_failed(ptr @olang_loc_34bfc259355dec67_8a2d14d061fee643)
  unreachable
bb45:
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i64 -1, ptr %rv
  br label %ret
bb50:
  call void @__olang_check_failed(ptr @olang_loc_806a74b5c91de186_4e306eb4964e9ec2)
  unreachable
bb51:
  %t132 = load i64, ptr %l4, !tbaa !24
  %t134 = icmp slt i64 %t132, 0
  br i1 %t134, label %bb52, label %bb53
bb52:
  store i64 -1, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t137 = load i64, ptr %l4, !tbaa !24
  %t138 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t141 = icmp sge i64 %t137, %t138
  br i1 %t141, label %bb55, label %bb56
bb55:
  %t143 = load i64, ptr %l4, !tbaa !24
  %t144 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t147 = sub i64 %t143, %t144
  store i64 %t147, ptr %l77, !tbaa !24
  br label %bb57
bb56:
  %t149 = load i64, ptr %l4, !tbaa !24
  store i64 %t149, ptr %l77, !tbaa !24
  br label %bb57
bb57:
  %t151 = load i64, ptr %l77, !tbaa !24
  store i64 %t151, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esameValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ederefRoot(ptr %v2, ptr %a2)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t14 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v1, ptr %v2, ptr %a1, ptr %t11)
  store i1 %t14, ptr %l11
  br label %bb5
bb5:
  %t15 = load i1, ptr %l11, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 false, i1 %a6)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6, i1 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i64
  %l40 = alloca i1
  %l42 = alloca i64
  %l45 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i64
  %l54 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca i1
  %l61 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l67 = alloca i64
  %l68 = alloca i64
  %l70 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca i1
  %l77 = alloca { i64, ptr }
  %l85 = alloca i1
  %l86 = alloca ptr
  %l89 = alloca i64
  %l90 = alloca i1
  %l91 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca i64
  %l108 = alloca i64
  %l110 = alloca ptr
  %l112 = alloca i64
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca i1
  %l117 = alloca { i64, ptr }
  %l123 = alloca i64
  %l133 = alloca ptr
  %l138 = alloca i1
  %l141 = alloca i1
  %l146 = alloca ptr
  %l148 = alloca i1
  %l165 = alloca i64
  %l167 = alloca i64
  %l172 = alloca i64
  %l174 = alloca i64
  %l177 = alloca i1
  %l179 = alloca i64
  %l183 = alloca i1
  %l188 = alloca ptr
  %l190 = alloca i64
  %l191 = alloca i1
  %l198 = alloca { i64, ptr }
  %l200 = alloca i64
  %l204 = alloca ptr
  %l206 = alloca ptr
  %l211 = alloca { i64, ptr }
  %l216 = alloca i32
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s20 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l10, !tbaa !24
  store i64 %t8, ptr %l19, !tbaa !24
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t9)
  store i64 %t11, ptr %l21
  br label %bb2
bb2:
  %t12 = load i64, ptr %l19, !tbaa !24
  %t13 = load i64, ptr %l21, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb42
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = load i64, ptr %l10, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l26
  br label %bb6
bb6:
  %t23 = load i64, ptr %l26, !tbaa !24
  store i64 %t23, ptr %l11, !tbaa !24
  %t24 = load i64, ptr %l11, !tbaa !24
  %t26 = call i64 @compiler_2ffree_2eokind(i64 %t24)
  store i64 %t26, ptr %l28
  br label %bb7
bb7:
  %t27 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t28 = load i64, ptr %l28, !tbaa !24
  %t30 = icmp eq i64 %t28, %t27
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 2
  %t35 = load i1, ptr %t34, !tbaa !21
  store i1 %t35, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l31, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load i64, ptr %l11, !tbaa !24
  %t40 = call i64 @compiler_2ffree_2eoval(i64 %t38)
  store i64 %t40, ptr %l36
  br label %bb13
bb12:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb14
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/free:walker", ptr %t41, i32 0, i32 31
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load i64, ptr %l36, !tbaa !24
  %t47 = icmp ne i64 %t45, %t44
  store i1 %t47, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l34, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t50 = load i64, ptr %l11, !tbaa !24
  %t52 = call i64 @compiler_2ffree_2eoval(i64 %t50)
  store i64 %t52, ptr %l42
  br label %bb17
bb16:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb18
bb17:
  %t53 = load i64, ptr %l1, !tbaa !24
  %t54 = load i64, ptr %l42, !tbaa !24
  %t56 = icmp ne i64 %t54, %t53
  store i1 %t56, ptr %l40, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l40, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l8, !tbaa !29
  store ptr %t59, ptr %l45, !tbaa !29
  %t60 = load i64, ptr %l11, !tbaa !24
  %t62 = call i64 @compiler_2ffree_2eoval(i64 %t60)
  store i64 %t62, ptr %l47
  br label %bb21
bb20:
  br label %bb40
bb21:
  %t63 = load ptr, ptr %l45, !tbaa !29
  %t64 = load i64, ptr %l47, !tbaa !24
  %t65 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t63, i64 %t64)
  store i1 %t65, ptr %l48
  br label %bb22
bb22:
  %t66 = load i1, ptr %l48, !tbaa !21
  br i1 %t66, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load ptr, ptr %l8, !tbaa !29
  store ptr %t67, ptr %l49, !tbaa !29
  %t68 = load i64, ptr %l11, !tbaa !24
  %t70 = call i64 @compiler_2ffree_2eoval(i64 %t68)
  store i64 %t70, ptr %l51
  br label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t71 = load ptr, ptr %l8, !tbaa !29
  store ptr %t71, ptr %l65, !tbaa !29
  %t72 = load i64, ptr %l11, !tbaa !24
  %t74 = call i64 @compiler_2ffree_2eoval(i64 %t72)
  store i64 %t74, ptr %l67
  br label %bb32
bb25:
  %t75 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t75, ptr %l52, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t76)
  store ptr %t78, ptr %l54
  br label %bb26
bb26:
  %t79 = load ptr, ptr %l54, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Body", ptr %t79, i32 0, i32 3
  %t82 = load i64, ptr %t81, !tbaa !24
  store i64 %t82, ptr %l56, !tbaa !24
  %t83 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t83, ptr %l57
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s4, { i64, ptr } %t84, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store i1 %t86, ptr %l59
  br label %bb27
bb27:
  %t87 = load i1, ptr %l59, !tbaa !21
  %t88 = xor i1 %t87, true
  br i1 %t88, label %bb28, label %bb29
bb28:
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t91 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t94 = extractvalue { i64, ptr } %t90, 1
  %t95 = extractvalue { i64, ptr } %t90, 0
  %t96 = add i64 %t92, %t95
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t99 = add i64 %t96, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t91, i64 %t92)
  %t101 = getelementptr i8, ptr %t100, i64 %t92
  call void @olang_textcopy(ptr %t101, ptr %t94, i64 %t95)
  %t102 = getelementptr i8, ptr %t101, i64 %t95
  call void @olang_textcopy(ptr %t102, ptr %t97, i64 %t98)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t100, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  br label %bb30
bb29:
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l61, !tbaa !27
  br label %bb30
bb30:
  %t113 = load ptr, ptr %l49, !tbaa !29
  %t114 = load i64, ptr %l51, !tbaa !24
  %t115 = load i64, ptr %l52, !tbaa !24
  %t116 = load i64, ptr %l56, !tbaa !24
  %t117 = load %"compiler/source:Span", ptr %l57
  %t118 = load { i64, ptr }, ptr %l61, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s4, ptr %t113, i64 %t114, i64 %t115, i64 %t116, %"compiler/source:Span" %t117, { i64, ptr } %t118)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb32:
  %t119 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t119, ptr %l68, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t120)
  store ptr %t122, ptr %l70
  br label %bb33
bb33:
  %t123 = load ptr, ptr %l70, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Body", ptr %t123, i32 0, i32 3
  %t126 = load i64, ptr %t125, !tbaa !24
  store i64 %t126, ptr %l72, !tbaa !24
  %t127 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t127, ptr %l73
  %t128 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t130 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s6, { i64, ptr } %t128, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t130, ptr %l75
  br label %bb34
bb34:
  %t131 = load i1, ptr %l75, !tbaa !21
  %t132 = xor i1 %t131, true
  br i1 %t132, label %bb35, label %bb36
bb35:
  %t134 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t135 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t138 = extractvalue { i64, ptr } %t134, 1
  %t139 = extractvalue { i64, ptr } %t134, 0
  %t140 = add i64 %t136, %t139
  %t141 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t135, i64 %t136)
  %t145 = getelementptr i8, ptr %t144, i64 %t136
  call void @olang_textcopy(ptr %t145, ptr %t138, i64 %t139)
  %t146 = getelementptr i8, ptr %t145, i64 %t139
  call void @olang_textcopy(ptr %t146, ptr %t141, i64 %t142)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t144, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = extractvalue { i64, ptr } %t148, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l77, !tbaa !27
  br label %bb37
bb36:
  store { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb37
bb37:
  %t157 = load ptr, ptr %l65, !tbaa !29
  %t158 = load i64, ptr %l67, !tbaa !24
  %t159 = load i64, ptr %l68, !tbaa !24
  %t160 = load i64, ptr %l72, !tbaa !24
  %t161 = load %"compiler/source:Span", ptr %l73
  %t162 = load { i64, ptr }, ptr %l77, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s6, ptr %t157, i64 %t158, i64 %t159, i64 %t160, %"compiler/source:Span" %t161, { i64, ptr } %t162)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t163 = load i64, ptr %l10, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l10, !tbaa !24
  br label %bb1
bb42:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/free:walker", ptr %t167, i32 0, i32 2
  %t170 = load i1, ptr %t169, !tbaa !21
  br i1 %t170, label %bb43, label %bb44
bb43:
  %t172 = load ptr, ptr %l3, !tbaa !29
  store ptr %t172, ptr %l86, !tbaa !29
  %t173 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t174 = load i64, ptr %l1, !tbaa !24
  %t177 = call i64 @compiler_2ffree_2eorig(i64 %t173, i64 %t174)
  store i64 %t177, ptr %l89
  br label %bb45
bb44:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb47
bb45:
  %t178 = load ptr, ptr %l86, !tbaa !29
  %t179 = load i64, ptr %l89, !tbaa !24
  %t180 = call i1 @compiler_2ffree_2ehas(ptr %v2, ptr %t178, i64 %t179)
  store i1 %t180, ptr %l90
  br label %bb46
bb46:
  %t181 = load i1, ptr %l90, !tbaa !21
  store i1 %t181, ptr %l85, !tbaa !21
  br label %bb47
bb47:
  %t182 = load i1, ptr %l85, !tbaa !21
  br i1 %t182, label %bb48, label %bb49
bb48:
  %t183 = load i64, ptr %l1, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/free:walker", ptr %t184, i32 0, i32 31
  %t187 = load i64, ptr %t186, !tbaa !24
  %t190 = icmp ne i64 %t183, %t187
  store i1 %t190, ptr %l91, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb50
bb50:
  %t192 = load i1, ptr %l91, !tbaa !21
  br i1 %t192, label %bb51, label %bb52
bb51:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t197 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %t193, ptr %t194)
  store i64 %t197, ptr %l99
  br label %bb53
bb52:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb54
bb53:
  %t198 = load i64, ptr %l99, !tbaa !24
  %t199 = icmp slt i64 %t198, 0
  store i1 %t199, ptr %l96, !tbaa !21
  br label %bb54
bb54:
  %t201 = load i1, ptr %l96, !tbaa !21
  br i1 %t201, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i64, ptr %l1, !tbaa !24
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l4
  %t206 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t202, i64 %t203, ptr %t204, %"compiler/source:Span" %t205, i1 %t206)
  br label %bb57
bb56:
  br label %bb64
bb57:
  %t212 = load ptr, ptr %l8, !tbaa !29
  store ptr %t212, ptr %l106, !tbaa !29
  %t213 = load i64, ptr %l1, !tbaa !24
  store i64 %t213, ptr %l107, !tbaa !24
  %t214 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t214, ptr %l108, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t215)
  store ptr %t217, ptr %l110
  br label %bb58
bb58:
  %t218 = load ptr, ptr %l110, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Body", ptr %t218, i32 0, i32 3
  %t221 = load i64, ptr %t220, !tbaa !24
  store i64 %t221, ptr %l112, !tbaa !24
  %t222 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t222, ptr %l113
  %t223 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t225 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s9, { i64, ptr } %t223, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t225, ptr %l115
  br label %bb59
bb59:
  %t226 = load i1, ptr %l115, !tbaa !21
  %t227 = xor i1 %t226, true
  br i1 %t227, label %bb60, label %bb61
bb60:
  %t229 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t230 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t233 = extractvalue { i64, ptr } %t229, 1
  %t234 = extractvalue { i64, ptr } %t229, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t230, i64 %t231)
  %t240 = getelementptr i8, ptr %t239, i64 %t231
  call void @olang_textcopy(ptr %t240, ptr %t233, i64 %t234)
  %t241 = getelementptr i8, ptr %t240, i64 %t234
  call void @olang_textcopy(ptr %t241, ptr %t236, i64 %t237)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t239, 1
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  store { i64, ptr } %t250, ptr %l117, !tbaa !27
  br label %bb62
bb61:
  store { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l117, !tbaa !27
  br label %bb62
bb62:
  %t252 = load ptr, ptr %l106, !tbaa !29
  %t253 = load i64, ptr %l107, !tbaa !24
  %t254 = load i64, ptr %l108, !tbaa !24
  %t255 = load i64, ptr %l112, !tbaa !24
  %t256 = load %"compiler/source:Span", ptr %l113
  %t257 = load { i64, ptr }, ptr %l117, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s9, ptr %t252, i64 %t253, i64 %t254, i64 %t255, %"compiler/source:Span" %t256, { i64, ptr } %t257)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %ret
bb64:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load ptr, ptr %l2, !tbaa !29
  %t262 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %t258, ptr %t259)
  store i64 %t262, ptr %l123
  br label %bb65
bb65:
  %t263 = load i64, ptr %l123, !tbaa !24
  store i64 %t263, ptr %l12, !tbaa !24
  %t264 = load i64, ptr %l12, !tbaa !24
  %t266 = icmp sge i64 %t264, 0
  br i1 %t266, label %bb66, label %bb67
bb66:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/free:walker", ptr %t268, i32 0, i32 2
  %t271 = load i1, ptr %t270, !tbaa !21
  %t273 = xor i1 %t271, true
  br i1 %t273, label %bb68, label %bb69
bb67:
  br label %bb87
bb68:
  %t275 = load ptr, ptr %l8, !tbaa !29
  %t277 = getelementptr %"compiler/free:Free", ptr %t275, i32 0, i32 21
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/free:walker", ptr %t278, i32 0, i32 1
  %t281 = load i64, ptr %t280, !tbaa !24
  %t284 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t277, i64 %t281)
  store ptr %t284, ptr %l133
  br label %bb70
bb69:
  br label %bb83
bb70:
  %t285 = load i64, ptr %l12, !tbaa !24
  %t287 = shl i64 %t285, 32
  %t288 = load i64, ptr %l1, !tbaa !24
  %t291 = or i64 %t287, %t288
  %t292 = load ptr, ptr %l133, !tbaa !29
  %t294 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t292, i64 %t291)
  store i1 %t294, ptr %l138
  br label %bb71
bb71:
  %t295 = load i1, ptr %l138, !tbaa !21
  br i1 %t295, label %bb72, label %bb73
bb72:
  %t296 = load ptr, ptr %l8, !tbaa !29
  %t298 = getelementptr %"compiler/free:Free", ptr %t296, i32 0, i32 30
  store i1 true, ptr %t298, !tbaa !21
  br label %bb74
bb73:
  br label %bb74
bb74:
  %t299 = load i1, ptr %l6, !tbaa !21
  br i1 %t299, label %bb75, label %bb76
bb75:
  %t301 = load ptr, ptr %l8, !tbaa !29
  %t303 = getelementptr %"compiler/free:Free", ptr %t301, i32 0, i32 23
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/free:walker", ptr %t304, i32 0, i32 1
  %t307 = load i64, ptr %t306, !tbaa !24
  %t310 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t303, i64 %t307)
  store ptr %t310, ptr %l146
  br label %bb77
bb76:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb79
bb77:
  %t311 = load i64, ptr %l12, !tbaa !24
  %t312 = load ptr, ptr %l146, !tbaa !29
  %t314 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t312, i64 %t311)
  store i1 %t314, ptr %l148
  br label %bb78
bb78:
  %t315 = load i1, ptr %l148, !tbaa !21
  store i1 %t315, ptr %l141, !tbaa !21
  br label %bb79
bb79:
  %t316 = load i1, ptr %l141, !tbaa !21
  br i1 %t316, label %bb80, label %bb81
bb80:
  %t317 = load ptr, ptr %l8, !tbaa !29
  %t319 = getelementptr %"compiler/free:Free", ptr %t317, i32 0, i32 30
  store i1 true, ptr %t319, !tbaa !21
  br label %bb82
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"compiler/free:walker", ptr %t320, i32 0, i32 43
  %t323 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t322, i64 %t323)
  br label %bb84
bb84:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/free:walker", ptr %t326, i32 0, i32 44
  %t329 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t328, i64 %t329)
  br label %bb85
bb85:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/free:walker", ptr %t332, i32 0, i32 45
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/free:walker", ptr %t335, i32 0, i32 12
  %t338 = load i64, ptr %t337, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t334, i64 %t338)
  br label %bb86
bb86:
  br label %ret
bb87:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/free:walker", ptr %t341, i32 0, i32 2
  %t344 = load i1, ptr %t343, !tbaa !21
  %t346 = xor i1 %t344, true
  br i1 %t346, label %bb88, label %bb89
bb88:
  br i1 %a7, label %bb90, label %bb91
bb89:
  br label %bb128
bb90:
  br label %ret
bb91:
  br label %bb92
bb92:
  %t350 = load ptr, ptr %l3, !tbaa !29
  store ptr %t350, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb93
bb93:
  %t352 = load i64, ptr %l14, !tbaa !24
  store i64 %t352, ptr %l165, !tbaa !24
  %t353 = load ptr, ptr %l13, !tbaa !29
  %t355 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t353)
  store i64 %t355, ptr %l167
  br label %bb94
bb94:
  %t356 = load i64, ptr %l165, !tbaa !24
  %t357 = load i64, ptr %l167, !tbaa !24
  %t358 = icmp slt i64 %t356, %t357
  %t360 = xor i1 %t358, true
  br i1 %t360, label %bb95, label %bb96
bb95:
  br label %bb127
bb96:
  br label %bb97
bb97:
  %t362 = load ptr, ptr %l13, !tbaa !29
  %t363 = load i64, ptr %l14, !tbaa !24
  %t366 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t362, i64 %t363)
  store i64 %t366, ptr %l172
  br label %bb98
bb98:
  %t367 = load i64, ptr %l172, !tbaa !24
  store i64 %t367, ptr %l15, !tbaa !24
  %t368 = load i64, ptr %l15, !tbaa !24
  %t370 = call i64 @compiler_2ffree_2eokind(i64 %t368)
  store i64 %t370, ptr %l174
  br label %bb99
bb99:
  %t371 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t372 = load i64, ptr %l174, !tbaa !24
  %t374 = icmp eq i64 %t372, %t371
  br i1 %t374, label %bb100, label %bb101
bb100:
  %t376 = load i64, ptr %l15, !tbaa !24
  %t378 = call i64 @compiler_2ffree_2eoval(i64 %t376)
  store i64 %t378, ptr %l179
  br label %bb102
bb101:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb103
bb102:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/free:walker", ptr %t379, i32 0, i32 30
  %t382 = load i64, ptr %t381, !tbaa !24
  %t383 = load i64, ptr %l179, !tbaa !24
  %t385 = icmp ne i64 %t383, %t382
  store i1 %t385, ptr %l177, !tbaa !21
  br label %bb103
bb103:
  %t387 = load i1, ptr %l177, !tbaa !21
  br i1 %t387, label %bb104, label %bb105
bb104:
  %t388 = load ptr, ptr %l8, !tbaa !29
  %t390 = getelementptr %"compiler/free:Free", ptr %t388, i32 0, i32 22
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"compiler/free:walker", ptr %t391, i32 0, i32 1
  %t394 = load i64, ptr %t393, !tbaa !24
  %t397 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t390, i64 %t394)
  store ptr %t397, ptr %l188
  br label %bb106
bb105:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb109
bb106:
  %t398 = load i64, ptr %l15, !tbaa !24
  %t400 = call i64 @compiler_2ffree_2eoval(i64 %t398)
  store i64 %t400, ptr %l190
  br label %bb107
bb107:
  %t401 = load ptr, ptr %l188, !tbaa !29
  %t402 = load i64, ptr %l190, !tbaa !24
  %t403 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t401, i64 %t402)
  store i1 %t403, ptr %l191
  br label %bb108
bb108:
  %t404 = load i1, ptr %l191, !tbaa !21
  store i1 %t404, ptr %l183, !tbaa !21
  br label %bb109
bb109:
  %t405 = load i1, ptr %l183, !tbaa !21
  br i1 %t405, label %bb110, label %bb111
bb110:
  %t406 = load ptr, ptr %l8, !tbaa !29
  %t408 = getelementptr %"compiler/free:Free", ptr %t406, i32 0, i32 30
  store i1 true, ptr %t408, !tbaa !21
  %t409 = load ptr, ptr %l8, !tbaa !29
  %t411 = getelementptr %"compiler/free:Free", ptr %t409, i32 0, i32 68
  %t412 = load i1, ptr %t411, !tbaa !21
  br i1 %t412, label %bb112, label %bb113
bb111:
  br label %bb125
bb112:
  store %olang.scope zeroinitializer, ptr %s20
  %t414 = load ptr, ptr %l8, !tbaa !29
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/free:walker", ptr %t415, i32 0, i32 1
  %t418 = load i64, ptr %t417, !tbaa !24
  %t421 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s20, ptr %t414, i64 %t418)
  store { i64, ptr } %t421, ptr %l198
  br label %bb114
bb113:
  br label %bb124
bb114:
  %t422 = load i64, ptr %l15, !tbaa !24
  %t424 = call i64 @compiler_2ffree_2eoval(i64 %t422)
  store i64 %t424, ptr %l200
  br label %bb115
bb115:
  %t425 = load ptr, ptr %l8, !tbaa !29
  %t427 = getelementptr %"compiler/free:Free", ptr %t425, i32 0, i32 0
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t430 = getelementptr %"compiler/generic:Program", ptr %t428, i32 0, i32 0
  %t431 = load ptr, ptr %t430, !tbaa !29
  %t433 = getelementptr %"compiler/load:Loader", ptr %t431, i32 0, i32 4
  %t434 = load ptr, ptr %t433, !tbaa !29
  store ptr %t434, ptr %l204, !tbaa !29
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t435)
  store ptr %t437, ptr %l206
  br label %bb116
bb116:
  %t438 = load ptr, ptr %l206, !tbaa !29
  %t440 = getelementptr %"compiler/typed:Body", ptr %t438, i32 0, i32 3
  %t441 = load i64, ptr %t440, !tbaa !24
  %t442 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t443 = load i32, ptr %t442, !tbaa !23
  %t445 = sext i32 %t443 to i64
  %t446 = load ptr, ptr %l204, !tbaa !29
  %t449 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s20, ptr %t446, i64 %t441, i64 %t445)
  store { i64, ptr } %t449, ptr %l211
  br label %bb117
bb117:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/free:walker", ptr %t450, i32 0, i32 30
  %t453 = load i64, ptr %t452, !tbaa !24
  %t454 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t455 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t456 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t457 = extractvalue { i64, ptr } %t456, 1
  %t458 = extractvalue { i64, ptr } %t456, 0
  %t459 = add i64 %t455, %t458
  %t460 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t461 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t462 = add i64 %t459, %t461
  %t463 = load i64, ptr %l200, !tbaa !24
  %t464 = call i64 @__olang_fmt_i64(ptr null, i64 %t463)
  %t465 = add i64 %t462, %t464
  %t466 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t467 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t468 = add i64 %t465, %t467
  %t469 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t469, 1
  %t471 = extractvalue { i64, ptr } %t469, 0
  %t472 = add i64 %t468, %t471
  %t473 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t474 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t475 = add i64 %t472, %t474
  %t477 = call i64 @__olang_fmt_i64(ptr null, i64 %t453)
  %t478 = add i64 %t475, %t477
  %t479 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t480 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t481 = add i64 %t478, %t480
  %t482 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t481)
  call void @olang_textcopy(ptr %t482, ptr %t454, i64 %t455)
  %t483 = getelementptr i8, ptr %t482, i64 %t455
  call void @olang_textcopy(ptr %t483, ptr %t457, i64 %t458)
  %t484 = getelementptr i8, ptr %t483, i64 %t458
  call void @olang_textcopy(ptr %t484, ptr %t460, i64 %t461)
  %t485 = getelementptr i8, ptr %t484, i64 %t461
  %t486 = call i64 @__olang_fmt_i64(ptr %t485, i64 %t463)
  %t487 = getelementptr i8, ptr %t485, i64 %t464
  call void @olang_textcopy(ptr %t487, ptr %t466, i64 %t467)
  %t488 = getelementptr i8, ptr %t487, i64 %t467
  call void @olang_textcopy(ptr %t488, ptr %t470, i64 %t471)
  %t489 = getelementptr i8, ptr %t488, i64 %t471
  call void @olang_textcopy(ptr %t489, ptr %t473, i64 %t474)
  %t490 = getelementptr i8, ptr %t489, i64 %t474
  %t491 = call i64 @__olang_fmt_i64(ptr %t490, i64 %t453)
  %t492 = getelementptr i8, ptr %t490, i64 %t477
  call void @olang_textcopy(ptr %t492, ptr %t479, i64 %t480)
  %t493 = insertvalue { i64, ptr } undef, i64 %t481, 0
  %t494 = insertvalue { i64, ptr } %t493, ptr %t482, 1
  %t496 = extractvalue { i64, ptr } %t494, 0
  %t497 = extractvalue { i64, ptr } %t494, 1
  %t498 = mul i64 %t496, 1
  %t499 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t498)
  call void @llvm.memcpy.p0.p0.i64(ptr %t499, ptr %t497, i64 %t498, i1 false)
  %t500 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t499, 1
  %t503 = call i32 @std_2fio_2ePrintErr(ptr %s20, { i64, ptr } %t501)
  store i32 %t503, ptr %l216
  %t504 = icmp ne i32 %t503, 0
  br i1 %t504, label %bb119, label %ok.505
ok.505:
  br label %bb118
bb118:
  br label %bb123
bb119:
  %t506 = load i32, ptr %l216, !tbaa !23
  %t507 = ashr i32 %t506, 16
  %t509 = icmp eq i32 %t507, 1
  br i1 %t509, label %bb120, label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_check_failed(ptr @olang_loc_2058a1f1b30311f1_26f3aef7996ef6dd)
  unreachable
bb122:
  call void @__olang_ert_req_clear()
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s20)
  br label %bb124
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  %t511 = load i64, ptr %l14, !tbaa !24
  %t513 = add i64 %t511, 1
  store i64 %t513, ptr %l14, !tbaa !24
  br label %bb93
bb127:
  br label %ret
bb128:
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load i64, ptr %l1, !tbaa !24
  %t517 = load ptr, ptr %l2, !tbaa !29
  %t518 = load %"compiler/source:Span", ptr %l4
  %t519 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t515, i64 %t516, ptr %t517, %"compiler/source:Span" %t518, i1 %t519)
  br label %bb129
bb129:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca i1
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 8
  %t8 = load i32, ptr %t7, !tbaa !23
  %t13 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t4, i32 %t8, i64 %a1)
  store i64 %t13, ptr %l14
  br label %bb1
bb1:
  %t14 = load i64, ptr %l14, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sge i64 %t15, 0
  br i1 %t17, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %s1, ptr %t19, i64 %t20, ptr %a2, ptr %t22, %"compiler/source:Span" %a4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d105, i32 0, i32 1) }, i1 false)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 2
  %t32 = load i1, ptr %t31, !tbaa !21
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l3, !tbaa !29
  store ptr %t36, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb7:
  br label %bb25
bb8:
  %t38 = load i64, ptr %l7, !tbaa !24
  store i64 %t38, ptr %l26, !tbaa !24
  %t39 = load ptr, ptr %l6, !tbaa !29
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t39)
  store i64 %t41, ptr %l28
  br label %bb9
bb9:
  %t42 = load i64, ptr %l26, !tbaa !24
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = icmp slt i64 %t42, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb10, label %bb11
bb10:
  br label %bb24
bb11:
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t48, i64 %t49)
  store i64 %t52, ptr %l33
  br label %bb13
bb13:
  %t53 = load i64, ptr %l33, !tbaa !24
  store i64 %t53, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = call i64 @compiler_2ffree_2eokind(i64 %t54)
  store i64 %t56, ptr %l35
  br label %bb14
bb14:
  %t57 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t58 = load i64, ptr %l35, !tbaa !24
  %t60 = icmp ne i64 %t58, %t57
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/free:walker", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 20
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/free:walker", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %t70, !tbaa !24
  %t74 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t67, i64 %t71)
  store ptr %t74, ptr %l44
  br label %bb17
bb16:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb19
bb17:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t78 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t76, i64 %t75)
  store i1 %t78, ptr %l46
  br label %bb18
bb18:
  %t79 = load i1, ptr %l46, !tbaa !21
  store i1 %t79, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t80 = load i1, ptr %l38, !tbaa !21
  br i1 %t80, label %bb20, label %bb21
bb20:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:walker", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/free:Free", ptr %t84, i32 0, i32 30
  store i1 true, ptr %t86, !tbaa !21
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb8
bb24:
  br label %bb25
bb25:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t2, i32 0, i32 29
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 29
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t14 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s0, ptr %t10, ptr %t11)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l11
  br label %bb1
bb1:
  %t15 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l5
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 29
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = sub i64 %t19, 1
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 29
  store i64 %t21, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t25, i64 %a1, ptr %t27, ptr %l5, %"compiler/source:Span" %a3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d106, i32 0, i32 1) }, i1 %a4, i1 false)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t5)
  store ptr %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t16 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %t13, i64 %t11, %"compiler/source:Span" %a1)
  store { i64, ptr } %t16, ptr %l9
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euse(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 29
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 24
  %t11 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t10, i64 %t11)
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 25
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 12
  %t20 = load i64, ptr %t19, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t16, i64 %t20)
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t25, %"compiler/source:Span" %a2)
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 51
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 52
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l20
  br label %bb7
bb7:
  %t37 = load i64, ptr %l20, !tbaa !24
  %t38 = icmp sgt i64 %t37, 0
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t40, i32 0, i32 52
  store ptr %t42, ptr %l24, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/free:walker", ptr %t43, i32 0, i32 52
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t45)
  store i64 %t47, ptr %l27
  br label %bb10
bb9:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb12
bb10:
  %t48 = load i64, ptr %l27, !tbaa !24
  %t49 = sub i64 %t48, 1
  %t50 = load ptr, ptr %l24, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t50, i64 %t49)
  store i64 %t52, ptr %l29
  br label %bb11
bb11:
  %t53 = load i64, ptr %l29, !tbaa !24
  store i64 %t53, ptr %l22, !tbaa !24
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l17, !tbaa !29
  %t55 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t54, i64 %t55)
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/free:walker", ptr %t56, i32 0, i32 28
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb14, label %bb15
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t63, i32 0, i32 27
  %t66 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t65, i64 %t66)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2ffree_2ecompiler_2ffree_3awalker_2euseSpAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca i64
  %l44 = alloca %"compiler/source:Span"
  %l48 = alloca ptr
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 25
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 25
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l38
  br label %bb12
bb12:
  %t61 = load i64, ptr %l38, !tbaa !24
  %t63 = icmp eq i64 %t61, %a1
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/free:walker", ptr %t65, i32 0, i32 26
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t67, i64 %t68)
  store %"compiler/source:Span" %t71, ptr %l44
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t72 = load %"compiler/source:Span", ptr %l44
  store %"compiler/source:Span" %t72, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l6, !tbaa !24
  br label %bb8
bb18:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t77)
  store ptr %t79, ptr %l48
  br label %bb19
bb19:
  %t80 = load ptr, ptr %l48, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Body", ptr %t80, i32 0, i32 4
  %t83 = load %"compiler/source:Span", ptr %t82
  store %"compiler/source:Span" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eusedAfter(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i64
  %l36 = alloca i64
  %l40 = alloca i64
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l75 = alloca i64
  %l79 = alloca i1
  %l80 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i1
  %l91 = alloca i64
  %l95 = alloca i64
  %l97 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l107 = alloca i64
  %l109 = alloca i1
  %l113 = alloca i64
  %l117 = alloca i64
  %l127 = alloca i1
  %l128 = alloca i1
  %l130 = alloca i64
  %l133 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 20
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l20
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l20, !tbaa !24
  %t11 = icmp sgt i64 %t9, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l3, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l5, !tbaa !24
  store i64 %t16, ptr %l25, !tbaa !24
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t17)
  store i64 %t19, ptr %l27
  br label %bb6
bb6:
  %t20 = load i64, ptr %l25, !tbaa !24
  %t21 = load i64, ptr %l27, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t26, i64 %t27)
  store i64 %t30, ptr %l32
  br label %bb10
bb10:
  %t31 = load i64, ptr %l32, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 25
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  store i64 %t38, ptr %l36
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:walker", ptr %t39, i32 0, i32 13
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l40
  br label %bb12
bb12:
  %t46 = load i64, ptr %l36, !tbaa !24
  %t47 = load i64, ptr %l40, !tbaa !24
  %t48 = icmp sgt i64 %t46, %t47
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load i64, ptr %l6, !tbaa !24
  store i64 %t50, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l5, !tbaa !24
  br label %bb5
bb17:
  store i64 0, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/free:walker", ptr %t56, i32 0, i32 14
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l47
  br label %bb18
bb18:
  %t61 = load i64, ptr %l47, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb24
bb21:
  %t72 = load i64, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l54, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb23
bb23:
  %t88 = load i64, ptr %l54, !tbaa !24
  store i64 %t88, ptr %l51, !tbaa !24
  br label %bb24
bb24:
  %t89 = load i64, ptr %l51, !tbaa !24
  store i64 %t89, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  %t90 = load i64, ptr %l11, !tbaa !24
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb26, label %bb27
bb26:
  br label %bb59
bb27:
  br label %bb28
bb28:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l12, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:walker", ptr %t108, i32 0, i32 14
  %t111 = load i64, ptr %l12, !tbaa !24
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t110, i64 %t111)
  store i64 %t114, ptr %l75
  br label %bb29
bb29:
  %t115 = load i64, ptr %l75, !tbaa !24
  store i64 %t115, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l2, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  br i1 %t120, label %bb30, label %bb31
bb30:
  %t122 = load i64, ptr %l2, !tbaa !24
  store i64 %t122, ptr %l80, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/free:walker", ptr %t123, i32 0, i32 15
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t126)
  store i64 %t129, ptr %l84
  br label %bb32
bb31:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb33
bb32:
  %t130 = load i64, ptr %l80, !tbaa !24
  %t131 = load i64, ptr %l84, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  store i1 %t132, ptr %l79, !tbaa !21
  br label %bb33
bb33:
  %t134 = load i1, ptr %l79, !tbaa !21
  %t135 = xor i1 %t134, true
  br i1 %t135, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb37
bb35:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/free:walker", ptr %t137, i32 0, i32 20
  %t140 = load i64, ptr %l1, !tbaa !24
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t139, i64 %t140)
  store i64 %t143, ptr %l91
  br label %bb36
bb36:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l91, !tbaa !24
  %t147 = icmp sgt i64 %t145, %t144
  store i1 %t147, ptr %l87, !tbaa !21
  br label %bb37
bb37:
  %t149 = load i1, ptr %l87, !tbaa !21
  br i1 %t149, label %bb38, label %bb39
bb38:
  br label %bb58
bb39:
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l3, !tbaa !29
  store ptr %t150, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb41
bb41:
  %t152 = load i64, ptr %l15, !tbaa !24
  store i64 %t152, ptr %l95, !tbaa !24
  %t153 = load ptr, ptr %l14, !tbaa !29
  %t155 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t153)
  store i64 %t155, ptr %l97
  br label %bb42
bb42:
  %t156 = load i64, ptr %l95, !tbaa !24
  %t157 = load i64, ptr %l97, !tbaa !24
  %t158 = icmp slt i64 %t156, %t157
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb43, label %bb44
bb43:
  br label %bb57
bb44:
  br label %bb45
bb45:
  %t162 = load ptr, ptr %l14, !tbaa !29
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t162, i64 %t163)
  store i64 %t166, ptr %l102
  br label %bb46
bb46:
  %t167 = load i64, ptr %l102, !tbaa !24
  store i64 %t167, ptr %l16, !tbaa !24
  %t168 = load i64, ptr %l13, !tbaa !24
  store i64 %t168, ptr %l103, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:walker", ptr %t169, i32 0, i32 25
  %t172 = load i64, ptr %l16, !tbaa !24
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172)
  store i64 %t175, ptr %l107
  br label %bb47
bb47:
  %t176 = load i64, ptr %l103, !tbaa !24
  %t177 = load i64, ptr %l107, !tbaa !24
  %t178 = icmp slt i64 %t176, %t177
  br i1 %t178, label %bb48, label %bb49
bb48:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/free:walker", ptr %t180, i32 0, i32 25
  %t183 = load i64, ptr %l16, !tbaa !24
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t182, i64 %t183)
  store i64 %t186, ptr %l113
  br label %bb50
bb49:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb52
bb50:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/free:walker", ptr %t187, i32 0, i32 15
  %t190 = load i64, ptr %l12, !tbaa !24
  %t193 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t189, i64 %t190)
  store i64 %t193, ptr %l117
  br label %bb51
bb51:
  %t194 = load i64, ptr %l113, !tbaa !24
  %t195 = load i64, ptr %l117, !tbaa !24
  %t196 = icmp sle i64 %t194, %t195
  store i1 %t196, ptr %l109, !tbaa !21
  br label %bb52
bb52:
  %t198 = load i1, ptr %l109, !tbaa !21
  br i1 %t198, label %bb53, label %bb54
bb53:
  %t199 = load i64, ptr %l16, !tbaa !24
  store i64 %t199, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t201 = load i64, ptr %l15, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l15, !tbaa !24
  br label %bb41
bb57:
  br label %bb58
bb58:
  %t205 = load i64, ptr %l11, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l11, !tbaa !24
  br label %bb25
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/free:walker", ptr %t209, i32 0, i32 27
  %t212 = load i64, ptr %l1, !tbaa !24
  %t215 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t211, i64 %t212)
  store i1 %t215, ptr %l127
  br label %bb60
bb60:
  %t216 = load i1, ptr %l127, !tbaa !21
  br i1 %t216, label %bb61, label %bb62
bb61:
  %t217 = load ptr, ptr %l3, !tbaa !29
  %t219 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t217)
  store i64 %t219, ptr %l130
  br label %bb63
bb62:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb64
bb63:
  %t220 = load i64, ptr %l130, !tbaa !24
  %t221 = icmp sgt i64 %t220, 0
  store i1 %t221, ptr %l128, !tbaa !21
  br label %bb64
bb64:
  %t223 = load i1, ptr %l128, !tbaa !21
  br i1 %t223, label %bb65, label %bb66
bb65:
  %t224 = load ptr, ptr %l3, !tbaa !29
  %t226 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t224, i64 0)
  store i64 %t226, ptr %l133
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t227 = load i64, ptr %l133, !tbaa !24
  store i64 %t227, ptr %rv
  br label %ret
bb68:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i1
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i64
  %l23 = alloca i64
  %l27 = alloca i1
  %l32 = alloca ptr
  %l34 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 29
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l9, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l14, !tbaa !24
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l16
  br label %bb8
bb8:
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = load i64, ptr %l16, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %bb24
bb10:
  br label %bb11
bb11:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t28, i64 %t29)
  store i64 %t32, ptr %l21
  br label %bb12
bb12:
  %t33 = load i64, ptr %l21, !tbaa !24
  store i64 %t33, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = call i64 @compiler_2ffree_2eokind(i64 %t34)
  store i64 %t36, ptr %l23
  br label %bb13
bb13:
  %t37 = load i64, ptr %l23, !tbaa !24
  store i64 %t37, ptr %l5, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t42 = icmp eq i64 %t38, %t39
  br i1 %t42, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb16
bb15:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t48 = icmp eq i64 %t44, %t45
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l27, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/free:walker", ptr %t51, i32 0, i32 34
  store ptr %t53, ptr %l32, !tbaa !29
  %t54 = load i64, ptr %l4, !tbaa !24
  %t56 = call i64 @compiler_2ffree_2eoval(i64 %t54)
  store i64 %t56, ptr %l34
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  br label %bb20
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:walker", ptr %t59, i32 0, i32 35
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/free:walker", ptr %t62, i32 0, i32 12
  %t65 = load i64, ptr %t64, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t61, i64 %t65)
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l3, !tbaa !24
  br label %bb7
bb24:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ffree_2ectorCall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_546be3fdfb2e7861_5a4791e17fa5075d)
  unreachable
bb11:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l5, !tbaa !29
  br label %bb32
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 3
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = call ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %t34)
  store ptr %t36, ptr %l21
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l21, !tbaa !29
  store ptr %t37, ptr %l5, !tbaa !29
  br label %bb32
bb13:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 4
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Elem", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = call ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %t56)
  store ptr %t58, ptr %l30
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l30, !tbaa !29
  store ptr %t59, ptr %l5, !tbaa !29
  br label %bb32
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t61 = load ptr, ptr %l31, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l31, !tbaa !29
  %t65 = load i64, ptr %t64
  %t67 = icmp eq i64 %t65, 5
  store i1 %t67, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t68 = load i1, ptr %l32, !tbaa !21
  br i1 %t68, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Payload", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = call ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %t78)
  store ptr %t80, ptr %l39
  br label %bb26
bb26:
  %t81 = load ptr, ptr %l39, !tbaa !29
  store ptr %t81, ptr %l5, !tbaa !29
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_5891e56eddc46c99_f944b0e713971375)
  unreachable
bb32:
  %t82 = load ptr, ptr %l5, !tbaa !29
  store ptr %t82, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l20 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a0, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t30 = call ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %t24, i64 %a1)
  store ptr %t30, ptr %l20
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l20, !tbaa !29
  store ptr %t31, ptr %l6, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = icmp eq ptr %t32, null
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load ptr, ptr %l6, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l40 = alloca ptr
  %l44 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l14
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l14, !tbaa !29
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb31
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %t37, i64 %t38)
  store ptr %t41, ptr %l23
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l23, !tbaa !29
  store ptr %t42, ptr %l5, !tbaa !29
  br label %bb31
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l25, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb26
bb19:
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Elem", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t65 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l33
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l33, !tbaa !29
  %t67 = icmp eq ptr %t66, null
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Elem", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %t74, i64 %t75)
  store ptr %t78, ptr %l40
  br label %bb23
bb22:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Elem", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t82, i64 %t83)
  store ptr %t86, ptr %l44
  br label %bb24
bb23:
  %t87 = load ptr, ptr %l40, !tbaa !29
  store ptr %t87, ptr %l36, !tbaa !29
  br label %bb25
bb24:
  %t88 = load ptr, ptr %l44, !tbaa !29
  store ptr %t88, ptr %l36, !tbaa !29
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l36, !tbaa !29
  store ptr %t89, ptr %l5, !tbaa !29
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_ee9887f5f58478ff_db34cc814b361eab)
  unreachable
bb31:
  %t90 = load ptr, ptr %l5, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2efindIf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l15 = alloca ptr
  %l31 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:If", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %t22, i64 %t23)
  store ptr %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l15, !tbaa !29
  store ptr %t27, ptr %l2, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/typed:If", ptr %t37, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/typed:If", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb11, label %bb12
bb10:
  br label %bb15
bb11:
  call void @__olang_check_failed(ptr @olang_loc_2779327e577b2afc_81ce12c77e8d0b58)
  unreachable
bb12:
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:If", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i64, ptr %l1, !tbaa !24
  %t60 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %t56, i64 %t57)
  store ptr %t60, ptr %l31
  br label %bb14
bb14:
  %t61 = load ptr, ptr %l31, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
bb15:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ffree_2ehas(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i64, ptr %l13, !tbaa !24
  %t23 = icmp eq i64 %t18, %a1
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2eisConversion(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 20 to i32
  %t4 = icmp eq i32 %a0, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t8 = extractvalue { i64, ptr } %a1, 0
  %t10 = icmp eq i64 %t8, 1
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l4, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2eleaves(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_6ad9637bd46aa97_a10a430e5eff5d73)
  unreachable
bb15:
  %t19 = load i1, ptr %l1, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2eleavesFunction(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 9
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_83047756a0f84ae3_95aa60b35b875f1f)
  unreachable
bb19:
  %t28 = load i1, ptr %l1, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2enewWalker(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, [2 x i64] }
  %l34 = alloca i32
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca %"compiler/free:walker"
  %l81 = alloca ptr
  %l84 = alloca i64
  %l98 = alloca i64
  %l101 = alloca i64
  %l121 = alloca i64
  %l124 = alloca i64
  %l129 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l137 = alloca ptr
  %l138 = alloca %"compiler/source:Span"
  %l143 = alloca i64
  %l147 = alloca i64
  %l150 = alloca i64
  %l171 = alloca i32
  %l180 = alloca ptr
  %l183 = alloca i64
  %l184 = alloca i1
  %l190 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l204 = alloca i64
  %l207 = alloca i64
  %l225 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l235 = alloca i64
  %l238 = alloca i64
  %l259 = alloca ptr
  %l260 = alloca { i64, ptr }
  %l263 = alloca i1
  %l277 = alloca i64
  %l281 = alloca i64
  %l284 = alloca i64
  %l303 = alloca ptr
  %l307 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t12 = alloca %"compiler/free:walker", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 6
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l44, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2ffree_3awalker_2ector(ptr %t12, ptr %v0, ptr %v0, ptr %t9, i64 %t10, i1 %t11)
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %t12, i64 464, i1 false)
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 464, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %l48, i64 464, i1 false)
  %t18 = load ptr, ptr %l44, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t18, i32 0, i32 6
  store ptr %t16, ptr %t19, !tbaa !29
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/free:Free", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_ce893683105a8b06_84bedcfad8df0b4a)
  unreachable
bb6:
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:Free", ptr %t27, i32 0, i32 6
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l3, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 1
  store i64 %t33, ptr %t36, !tbaa !24
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i1, ptr %l2, !tbaa !21
  %t41 = getelementptr %"compiler/free:walker", ptr %t37, i32 0, i32 2
  store i1 %t38, ptr %t41, !tbaa !21
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = getelementptr %"compiler/free:walker", ptr %t42, i32 0, i32 5
  store i1 false, ptr %t44, !tbaa !21
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr %"compiler/free:walker", ptr %t45, i32 0, i32 6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t47)
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/free:walker", ptr %t49, i32 0, i32 7
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t51)
  br label %bb9
bb9:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t57 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 8
  store i32 %t54, ptr %t57, !tbaa !23
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/free:walker", ptr %t58, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2eClear_H3be601f049db8fee531e82245bd6456a(ptr %v0, ptr %t60)
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = getelementptr %"compiler/free:walker", ptr %t62, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t64)
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Hca84839cdf395382408370342cfafe64(ptr %v0, ptr %t68)
  br label %bb12
bb12:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/free:walker", ptr %t70, i32 0, i32 23
  store i64 0, ptr %t72, !tbaa !24
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 28
  store i64 0, ptr %t75, !tbaa !24
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/free:walker", ptr %t76, i32 0, i32 29
  store i64 0, ptr %t78, !tbaa !24
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/free:walker", ptr %t79, i32 0, i32 30
  store i64 -1, ptr %t81, !tbaa !24
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 31
  store i64 -1, ptr %t84, !tbaa !24
  %t85 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %t85)
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 1
  %t90 = load i64, ptr %l1, !tbaa !24
  %t93 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t89, i64 %t90)
  store ptr %t93, ptr %l81
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l81, !tbaa !29
  store ptr %t94, ptr %l4, !tbaa !29
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Body", ptr %t95, i32 0, i32 7
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t97)
  store i64 %t99, ptr %l84
  br label %bb15
bb15:
  %t100 = load i64, ptr %l84, !tbaa !24
  store i64 %t100, ptr %l5, !tbaa !24
  %t101 = load ptr, ptr %l3, !tbaa !29
  %t103 = getelementptr %"compiler/free:walker", ptr %t101, i32 0, i32 3
  %t104 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H2ad576503181bd1b8552368bfa2352a6(ptr %v0, ptr %t103, i64 %t104)
  br label %bb16
bb16:
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t109 = getelementptr %"compiler/free:walker", ptr %t107, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t109)
  br label %bb17
bb17:
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/free:walker", ptr %t111, i32 0, i32 21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t113)
  br label %bb18
bb18:
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t117 = getelementptr %"compiler/free:walker", ptr %t115, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t117)
  br label %bb19
bb19:
  store i64 0, ptr %l6, !tbaa !24
  %t119 = load i64, ptr %l5, !tbaa !24
  store i64 %t119, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load i64, ptr %l6, !tbaa !24
  %t125 = icmp sgt i64 %t121, %t122
  br i1 %t125, label %bb20, label %bb21
bb20:
  %t127 = load i64, ptr %l8, !tbaa !24
  %t129 = icmp sgt i64 %t127, 0
  br i1 %t129, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb25
bb22:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = sub i64 %t131, %t132
  %t136 = load i64, ptr %l8, !tbaa !24
  %t139 = add i64 %t135, %t136
  %t141 = sub i64 %t139, 1
  %t142 = load i64, ptr %l8, !tbaa !24
  %t145 = sdiv i64 %t141, %t142
  store i64 %t145, ptr %l101, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb24
bb24:
  %t147 = load i64, ptr %l101, !tbaa !24
  store i64 %t147, ptr %l98, !tbaa !24
  br label %bb25
bb25:
  %t148 = load i64, ptr %l98, !tbaa !24
  store i64 %t148, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t149 = load i64, ptr %l10, !tbaa !24
  %t150 = load i64, ptr %l9, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb28:
  br label %bb29
bb29:
  %t157 = load i64, ptr %l6, !tbaa !24
  %t158 = load i64, ptr %l10, !tbaa !24
  %t159 = load i64, ptr %l8, !tbaa !24
  %t162 = mul i64 %t158, %t159
  %t165 = add i64 %t157, %t162
  store i64 %t165, ptr %l11, !tbaa !24
  %t167 = load ptr, ptr %l3, !tbaa !29
  %t169 = getelementptr %"compiler/free:walker", ptr %t167, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t169, i1 false)
  br label %bb30
bb30:
  %t171 = load i64, ptr %l11, !tbaa !24
  store i64 %t171, ptr %l121, !tbaa !24
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = getelementptr %"compiler/free:walker", ptr %t172, i32 0, i32 3
  %t176 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %t174)
  store i64 %t176, ptr %l124
  br label %bb31
bb31:
  %t177 = load i64, ptr %l121, !tbaa !24
  %t178 = load i64, ptr %l124, !tbaa !24
  %t179 = icmp slt i64 %t177, %t178
  br i1 %t179, label %bb32, label %bb33
bb32:
  %t181 = load ptr, ptr %l3, !tbaa !29
  %t183 = getelementptr %"compiler/free:walker", ptr %t181, i32 0, i32 3
  %t184 = load i64, ptr %l11, !tbaa !24
  %t187 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t183, i64 %t184)
  store ptr %t187, ptr %l129
  br label %bb34
bb33:
  %t188 = load ptr, ptr %l3, !tbaa !29
  %t190 = getelementptr %"compiler/free:walker", ptr %t188, i32 0, i32 3
  store ptr %t190, ptr %l131, !tbaa !29
  %t191 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t191, ptr %l132
  br label %bb36
bb34:
  %t192 = load ptr, ptr %l129, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t192)
  br label %bb35
bb35:
  br label %bb38
bb36:
  %t193 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l132
  %t194 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t193, ptr %t194
  %t195 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t195, ptr %t194)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t197 = load ptr, ptr %l3, !tbaa !29
  %t199 = getelementptr %"compiler/free:walker", ptr %t197, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t199, i64 0)
  br label %bb39
bb39:
  %t201 = load ptr, ptr %l3, !tbaa !29
  %t203 = getelementptr %"compiler/free:walker", ptr %t201, i32 0, i32 21
  store ptr %t203, ptr %l137, !tbaa !29
  %t204 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 0, i32 0)
  store %"compiler/source:Span" %t204, ptr %l138
  br label %bb40
bb40:
  %t205 = load ptr, ptr %l137, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l138
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t205, %"compiler/source:Span" %t206)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  %t207 = load i64, ptr %l10, !tbaa !24
  %t209 = add i64 %t207, 1
  store i64 %t209, ptr %l10, !tbaa !24
  br label %bb26
bb43:
  store i64 0, ptr %l12, !tbaa !24
  %t211 = load ptr, ptr %l4, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Body", ptr %t211, i32 0, i32 5
  %t215 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t213)
  store i64 %t215, ptr %l143
  br label %bb44
bb44:
  %t216 = load i64, ptr %l143, !tbaa !24
  store i64 %t216, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t217 = load i64, ptr %l13, !tbaa !24
  %t218 = load i64, ptr %l12, !tbaa !24
  %t221 = icmp sgt i64 %t217, %t218
  br i1 %t221, label %bb45, label %bb46
bb45:
  %t223 = load i64, ptr %l14, !tbaa !24
  %t225 = icmp sgt i64 %t223, 0
  br i1 %t225, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb50
bb47:
  %t227 = load i64, ptr %l13, !tbaa !24
  %t228 = load i64, ptr %l12, !tbaa !24
  %t231 = sub i64 %t227, %t228
  %t232 = load i64, ptr %l14, !tbaa !24
  %t235 = add i64 %t231, %t232
  %t237 = sub i64 %t235, 1
  %t238 = load i64, ptr %l14, !tbaa !24
  %t241 = sdiv i64 %t237, %t238
  store i64 %t241, ptr %l150, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l150, !tbaa !24
  br label %bb49
bb49:
  %t243 = load i64, ptr %l150, !tbaa !24
  store i64 %t243, ptr %l147, !tbaa !24
  br label %bb50
bb50:
  %t244 = load i64, ptr %l147, !tbaa !24
  store i64 %t244, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb51
bb51:
  %t245 = load i64, ptr %l16, !tbaa !24
  %t246 = load i64, ptr %l15, !tbaa !24
  %t249 = icmp slt i64 %t245, %t246
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb52, label %bb53
bb52:
  br label %bb61
bb53:
  br label %bb54
bb54:
  %t253 = load i64, ptr %l12, !tbaa !24
  %t254 = load i64, ptr %l16, !tbaa !24
  %t255 = load i64, ptr %l14, !tbaa !24
  %t258 = mul i64 %t254, %t255
  %t261 = add i64 %t253, %t258
  store i64 %t261, ptr %l17, !tbaa !24
  %t263 = load ptr, ptr %l4, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Body", ptr %t263, i32 0, i32 5
  %t266 = load i64, ptr %l17, !tbaa !24
  %t269 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t265, i64 %t266)
  store i32 %t269, ptr %l171
  br label %bb55
bb55:
  %t270 = load i32, ptr %l171, !tbaa !23
  %t271 = sext i32 %t270 to i64
  store i64 %t271, ptr %l18, !tbaa !24
  %t273 = load ptr, ptr %l3, !tbaa !29
  %t275 = getelementptr %"compiler/free:walker", ptr %t273, i32 0, i32 6
  %t276 = load i64, ptr %l18, !tbaa !24
  %t277 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t275, i64 %t276, i64 %t277)
  br label %bb56
bb56:
  %t281 = load ptr, ptr %l3, !tbaa !29
  %t283 = getelementptr %"compiler/free:walker", ptr %t281, i32 0, i32 3
  %t284 = load i64, ptr %l18, !tbaa !24
  %t287 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t283, i64 %t284)
  store ptr %t287, ptr %l180
  br label %bb57
bb57:
  %t288 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t289 = load i64, ptr %l17, !tbaa !24
  %t292 = call i64 @compiler_2ffree_2eorig(i64 %t288, i64 %t289)
  store i64 %t292, ptr %l183
  br label %bb58
bb58:
  %t293 = load ptr, ptr %l180, !tbaa !29
  %t294 = load i64, ptr %l183, !tbaa !24
  %t295 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t293, i64 %t294)
  store i1 %t295, ptr %l184
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t296 = load i64, ptr %l16, !tbaa !24
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l16, !tbaa !24
  br label %bb51
bb61:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/free:Free", ptr %t300, i32 0, i32 50
  %t303 = load i64, ptr %l1, !tbaa !24
  %t306 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t302, i64 %t303)
  store { i64, ptr } %t306, ptr %l190
  br label %bb62
bb62:
  %t307 = load { i64, ptr }, ptr %l190, !tbaa !27
  store { i64, ptr } %t307, ptr %l19, !tbaa !27
  %t308 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = load i64, ptr %l5, !tbaa !24
  %t313 = add i64 %t311, 1
  %t316 = icmp eq i64 %t310, %t313
  br i1 %t316, label %bb63, label %bb64
bb63:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/free:Free", ptr %t318, i32 0, i32 49
  %t321 = load i64, ptr %l1, !tbaa !24
  %t324 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t320, i64 %t321)
  store { i64, ptr } %t324, ptr %l199
  br label %bb65
bb64:
  br label %bb92
bb65:
  %t325 = load { i64, ptr }, ptr %l199, !tbaa !27
  store { i64, ptr } %t325, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t326 = load i64, ptr %l5, !tbaa !24
  store i64 %t326, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t328 = load i64, ptr %l22, !tbaa !24
  %t329 = load i64, ptr %l21, !tbaa !24
  %t332 = icmp sgt i64 %t328, %t329
  br i1 %t332, label %bb66, label %bb67
bb66:
  %t334 = load i64, ptr %l23, !tbaa !24
  %t336 = icmp sgt i64 %t334, 0
  br i1 %t336, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb71
bb68:
  %t338 = load i64, ptr %l22, !tbaa !24
  %t339 = load i64, ptr %l21, !tbaa !24
  %t342 = sub i64 %t338, %t339
  %t343 = load i64, ptr %l23, !tbaa !24
  %t346 = add i64 %t342, %t343
  %t348 = sub i64 %t346, 1
  %t349 = load i64, ptr %l23, !tbaa !24
  %t352 = sdiv i64 %t348, %t349
  store i64 %t352, ptr %l207, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb70
bb70:
  %t354 = load i64, ptr %l207, !tbaa !24
  store i64 %t354, ptr %l204, !tbaa !24
  br label %bb71
bb71:
  %t355 = load i64, ptr %l204, !tbaa !24
  store i64 %t355, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb72
bb72:
  %t356 = load i64, ptr %l25, !tbaa !24
  %t357 = load i64, ptr %l24, !tbaa !24
  %t360 = icmp slt i64 %t356, %t357
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb73, label %bb74
bb73:
  br label %bb91
bb74:
  br label %bb75
bb75:
  %t364 = load i64, ptr %l21, !tbaa !24
  %t365 = load i64, ptr %l25, !tbaa !24
  %t366 = load i64, ptr %l23, !tbaa !24
  %t369 = mul i64 %t365, %t366
  %t372 = add i64 %t364, %t369
  store i64 %t372, ptr %l26, !tbaa !24
  %t374 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t374, ptr %l225, !tbaa !27
  %t375 = load i64, ptr %l26, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr i64, ptr %t378, i64 %t375
  %t380 = load i64, ptr %t379, !tbaa !34
  store i64 %t380, ptr %l27, !tbaa !24
  %t382 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t382, ptr %l228, !tbaa !27
  %t383 = load i64, ptr %l26, !tbaa !24
  %t385 = add i64 %t383, 1
  %t387 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr i64, ptr %t388, i64 %t385
  %t390 = load i64, ptr %t389, !tbaa !34
  store i64 %t390, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t392 = load i64, ptr %l28, !tbaa !24
  %t393 = load i64, ptr %l27, !tbaa !24
  %t396 = icmp sgt i64 %t392, %t393
  br i1 %t396, label %bb76, label %bb77
bb76:
  %t398 = load i64, ptr %l29, !tbaa !24
  %t400 = icmp sgt i64 %t398, 0
  br i1 %t400, label %bb78, label %bb79
bb77:
  store i64 0, ptr %l235, !tbaa !24
  br label %bb81
bb78:
  %t402 = load i64, ptr %l28, !tbaa !24
  %t403 = load i64, ptr %l27, !tbaa !24
  %t406 = sub i64 %t402, %t403
  %t407 = load i64, ptr %l29, !tbaa !24
  %t410 = add i64 %t406, %t407
  %t412 = sub i64 %t410, 1
  %t413 = load i64, ptr %l29, !tbaa !24
  %t416 = sdiv i64 %t412, %t413
  store i64 %t416, ptr %l238, !tbaa !24
  br label %bb80
bb79:
  store i64 0, ptr %l238, !tbaa !24
  br label %bb80
bb80:
  %t418 = load i64, ptr %l238, !tbaa !24
  store i64 %t418, ptr %l235, !tbaa !24
  br label %bb81
bb81:
  %t419 = load i64, ptr %l235, !tbaa !24
  store i64 %t419, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb82
bb82:
  %t420 = load i64, ptr %l31, !tbaa !24
  %t421 = load i64, ptr %l30, !tbaa !24
  %t424 = icmp slt i64 %t420, %t421
  %t426 = xor i1 %t424, true
  br i1 %t426, label %bb83, label %bb84
bb83:
  br label %bb89
bb84:
  br label %bb85
bb85:
  %t428 = load i64, ptr %l27, !tbaa !24
  %t429 = load i64, ptr %l31, !tbaa !24
  %t430 = load i64, ptr %l29, !tbaa !24
  %t433 = mul i64 %t429, %t430
  %t436 = add i64 %t428, %t433
  store i64 %t436, ptr %l32, !tbaa !24
  %t438 = load ptr, ptr %l3, !tbaa !29
  %t440 = getelementptr %"compiler/free:walker", ptr %t438, i32 0, i32 3
  %t441 = load i64, ptr %l26, !tbaa !24
  %t444 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t440, i64 %t441)
  store ptr %t444, ptr %l259
  br label %bb86
bb86:
  %t445 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t445, ptr %l260, !tbaa !27
  %t446 = load i64, ptr %l32, !tbaa !24
  %t448 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !27
  %t450 = getelementptr i64, ptr %t449, i64 %t446
  %t451 = load i64, ptr %t450, !tbaa !34
  %t452 = load ptr, ptr %l259, !tbaa !29
  %t454 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t452, i64 %t451)
  store i1 %t454, ptr %l263
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t455 = load i64, ptr %l31, !tbaa !24
  %t457 = add i64 %t455, 1
  store i64 %t457, ptr %l31, !tbaa !24
  br label %bb82
bb89:
  br label %bb90
bb90:
  %t459 = load i64, ptr %l25, !tbaa !24
  %t461 = add i64 %t459, 1
  store i64 %t461, ptr %l25, !tbaa !24
  br label %bb72
bb91:
  br label %bb92
bb92:
  %t463 = load ptr, ptr %l4, !tbaa !29
  %t465 = getelementptr %"compiler/typed:Body", ptr %t463, i32 0, i32 1
  %t466 = load { i64, [2 x i64] }, ptr %t465
  store { i64, [2 x i64] } %t466, ptr %l33
  %t468 = load { i64, [2 x i64] }, ptr %l33
  %t470 = extractvalue { i64, [2 x i64] } %t468, 0
  %t471 = icmp eq i64 %t470, 1
  br i1 %t471, label %bb93, label %bb94
bb93:
  %t473 = getelementptr { i64, [2 x i64] }, ptr %l33, i32 0, i32 1
  %t474 = getelementptr { i32, i32 }, ptr %t473, i32 0, i32 0
  %t475 = load i32, ptr %t474
  store i32 %t475, ptr %l34, !tbaa !23
  br label %bb95
bb94:
  br label %bb111
bb95:
  %t477 = load ptr, ptr %l3, !tbaa !29
  %t478 = load i32, ptr %l34, !tbaa !23
  %t481 = getelementptr %"compiler/free:walker", ptr %t477, i32 0, i32 8
  store i32 %t478, ptr %t481, !tbaa !23
  store i64 0, ptr %l35, !tbaa !24
  %t482 = load ptr, ptr %l4, !tbaa !29
  %t484 = getelementptr %"compiler/typed:Body", ptr %t482, i32 0, i32 10
  %t486 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t484)
  store i64 %t486, ptr %l277
  br label %bb96
bb96:
  %t487 = load i64, ptr %l277, !tbaa !24
  store i64 %t487, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t488 = load i64, ptr %l36, !tbaa !24
  %t489 = load i64, ptr %l35, !tbaa !24
  %t492 = icmp sgt i64 %t488, %t489
  br i1 %t492, label %bb97, label %bb98
bb97:
  %t494 = load i64, ptr %l37, !tbaa !24
  %t496 = icmp sgt i64 %t494, 0
  br i1 %t496, label %bb99, label %bb100
bb98:
  store i64 0, ptr %l281, !tbaa !24
  br label %bb102
bb99:
  %t498 = load i64, ptr %l36, !tbaa !24
  %t499 = load i64, ptr %l35, !tbaa !24
  %t502 = sub i64 %t498, %t499
  %t503 = load i64, ptr %l37, !tbaa !24
  %t506 = add i64 %t502, %t503
  %t508 = sub i64 %t506, 1
  %t509 = load i64, ptr %l37, !tbaa !24
  %t512 = sdiv i64 %t508, %t509
  store i64 %t512, ptr %l284, !tbaa !24
  br label %bb101
bb100:
  store i64 0, ptr %l284, !tbaa !24
  br label %bb101
bb101:
  %t514 = load i64, ptr %l284, !tbaa !24
  store i64 %t514, ptr %l281, !tbaa !24
  br label %bb102
bb102:
  %t515 = load i64, ptr %l281, !tbaa !24
  store i64 %t515, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb103
bb103:
  %t516 = load i64, ptr %l39, !tbaa !24
  %t517 = load i64, ptr %l38, !tbaa !24
  %t520 = icmp slt i64 %t516, %t517
  %t522 = xor i1 %t520, true
  br i1 %t522, label %bb104, label %bb105
bb104:
  br label %bb110
bb105:
  br label %bb106
bb106:
  %t524 = load i64, ptr %l35, !tbaa !24
  %t525 = load i64, ptr %l39, !tbaa !24
  %t526 = load i64, ptr %l37, !tbaa !24
  %t529 = mul i64 %t525, %t526
  %t532 = add i64 %t524, %t529
  store i64 %t532, ptr %l40, !tbaa !24
  %t534 = load ptr, ptr %l3, !tbaa !29
  %t536 = getelementptr %"compiler/free:walker", ptr %t534, i32 0, i32 7
  store ptr %t536, ptr %l303, !tbaa !29
  %t537 = load ptr, ptr %l4, !tbaa !29
  %t539 = getelementptr %"compiler/typed:Body", ptr %t537, i32 0, i32 10
  %t540 = load i64, ptr %l40, !tbaa !24
  %t543 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t539, i64 %t540)
  store i32 %t543, ptr %l307
  br label %bb107
bb107:
  %t544 = load i32, ptr %l307, !tbaa !23
  %t545 = sext i32 %t544 to i64
  %t546 = load i64, ptr %l40, !tbaa !24
  %t547 = load ptr, ptr %l303, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t547, i64 %t545, i64 %t546)
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t550 = load i64, ptr %l39, !tbaa !24
  %t552 = add i64 %t550, 1
  store i64 %t552, ptr %l39, !tbaa !24
  br label %bb103
bb110:
  br label %bb116
bb111:
  br i1 true, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_check_failed(ptr @olang_loc_1b38cdd871e6a94_bc3035ea47e7c9d8)
  unreachable
bb116:
  %t554 = load ptr, ptr %l3, !tbaa !29
  store ptr %t554, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2ffree_2eoval(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t2 = shl i64 1, 40
  %t4 = sub i64 %t2, 1
  %t7 = and i64 %a0, %t4
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load i1, ptr %l15, !tbaa !21
  store i1 %t21, ptr %l6, !tbaa !21
  br label %bb37
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t41 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i1 %t41, ptr %l24
  br label %bb13
bb13:
  %t42 = load i1, ptr %l24, !tbaa !21
  store i1 %t42, ptr %l6, !tbaa !21
  br label %bb37
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l26, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Elem", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = call i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %t61)
  store i1 %t63, ptr %l33
  br label %bb20
bb20:
  %t64 = load i1, ptr %l33, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Elem", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t72 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store i1 %t72, ptr %l38
  br label %bb23
bb22:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb24
bb23:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  %t74 = load i1, ptr %l34, !tbaa !21
  store i1 %t74, ptr %l6, !tbaa !21
  br label %bb37
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb26, label %bb27
bb26:
  %t79 = load ptr, ptr %l39, !tbaa !29
  %t80 = load i64, ptr %t79
  %t82 = icmp eq i64 %t80, 5
  store i1 %t82, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t83 = load i1, ptr %l40, !tbaa !21
  br i1 %t83, label %bb28, label %bb29
bb28:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Payload", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t97 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t93, ptr %t94)
  store i1 %t97, ptr %l48
  br label %bb31
bb31:
  %t98 = load i1, ptr %l48, !tbaa !21
  store i1 %t98, ptr %l6, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_40628693553637f3_9a0aaf33c7b3625f)
  unreachable
bb37:
  %t99 = load i1, ptr %l6, !tbaa !21
  store i1 %t99, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb35
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb23
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb12, label %bb13
bb12:
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t30 = load i64, ptr %t29
  %t32 = icmp eq i64 %t30, 0
  store i1 %t32, ptr %l16, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_11a48ff1e8d67007_90e1a85549f82d33)
  unreachable
bb22:
  %t34 = load i1, ptr %l14, !tbaa !21
  store i1 %t34, ptr %l3, !tbaa !21
  br label %bb35
bb23:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb24, label %bb25
bb24:
  %t39 = load ptr, ptr %l19, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 17
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb25
bb25:
  %t43 = load i1, ptr %l20, !tbaa !21
  br i1 %t43, label %bb26, label %bb27
bb26:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = call i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %t50)
  store i1 %t52, ptr %l26
  br label %bb29
bb29:
  %t53 = load i1, ptr %l26, !tbaa !21
  store i1 %t53, ptr %l3, !tbaa !21
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_e0188cd4392210a6_c14318bc74dc83b2)
  unreachable
bb35:
  %t54 = load i1, ptr %l3, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ereadLocalOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %l10, !tbaa !24
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d0a35c72e1689727_18f1e8c23ad8e373)
  unreachable
bb16:
  %t35 = load i64, ptr %l10, !tbaa !24
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9d733ba55f12146_b889888c2106eef2)
  unreachable
bb22:
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [1 x i64] }
  %l1 = alloca i1
  %rv = alloca i1
  store { i64, [1 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb7
bb2:
  %t6 = load { i64, [1 x i64] }, ptr %l0
  %t8 = extractvalue { i64, [1 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 2
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t11 = load { i64, [1 x i64] }, ptr %l0
  %t13 = extractvalue { i64, [1 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 3
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9c97567f05482d15_e6d42a2535d66e1)
  unreachable
bb13:
  %t16 = load i1, ptr %l1, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2esamePure(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l3, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t35 = call i1 @compiler_2ffree_2esamePurePlace(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t35, ptr %l20
  br label %bb11
bb11:
  %t36 = load i1, ptr %l20, !tbaa !21
  store i1 %t36, ptr %l11, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a76c2f62bbf8a003_89a44c6922f8d22f)
  unreachable
bb17:
  %t37 = load i1, ptr %l11, !tbaa !21
  store i1 %t37, ptr %l4, !tbaa !21
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_e31a42735e4aee82_13f2226a4db7316e)
  unreachable
bb23:
  %t38 = load i1, ptr %l4, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2eunwrapped(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l24 = alloca { i64, ptr }
  %l39 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Try", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Try", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l4, !tbaa !24
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb10, label %bb11
bb10:
  br label %bb17
bb11:
  br label %bb12
bb12:
  %t42 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  %t52 = getelementptr %"compiler/typed:Clause", ptr %t48, i32 0, i32 4
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l3, !tbaa !24
  br label %bb9
bb17:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Try", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_497cb5294fb5d476_59996708b38ef322)
  unreachable
bb19:
  br label %bb20
bb20:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Try", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = call ptr @compiler_2ffree_2eunwrapped(ptr %v0, ptr %t75)
  store ptr %t77, ptr %l39
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l39, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_d76336629ed12804_de1ad14eaa737c40)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/free:letGo" @compiler_2ffree_3aletGo_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5, %"compiler/source:Span" %a6, i64 %a7, i1 %a8) #0 {
entry:
  %rv = alloca %"compiler/free:letGo"
  br label %start
start:
  br label %bb0
bb0:
  %t20 = insertvalue %"compiler/free:letGo" undef, i64 %a0, 0
  %t22 = insertvalue %"compiler/free:letGo" %t20, i64 %a1, 1
  %t24 = insertvalue %"compiler/free:letGo" %t22, i64 %a2, 2
  %t26 = insertvalue %"compiler/free:letGo" %t24, %"compiler/source:Span" %a3, 3
  %t28 = insertvalue %"compiler/free:letGo" %t26, %"compiler/source:Span" %a4, 4
  %t30 = insertvalue %"compiler/free:letGo" %t28, i64 %a5, 5
  %t32 = insertvalue %"compiler/free:letGo" %t30, %"compiler/source:Span" %a6, 6
  %t34 = insertvalue %"compiler/free:letGo" %t32, i64 %a7, 7
  %t36 = insertvalue %"compiler/free:letGo" %t34, i1 %a8, 8
  store %"compiler/free:letGo" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:letGo", ptr %rv
  ret %"compiler/free:letGo" %rr
}

define dso_local %"compiler/free:orCall" @compiler_2ffree_3aorCall_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, ptr %a5, ptr %a6) #0 {
entry:
  %rv = alloca %"compiler/free:orCall"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/free:orCall" undef, i64 %a0, 0
  %t18 = insertvalue %"compiler/free:orCall" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/free:orCall" %t18, i64 %a2, 2
  %t22 = insertvalue %"compiler/free:orCall" %t20, i64 %a3, 3
  %t24 = insertvalue %"compiler/free:orCall" %t22, i64 %a4, 4
  %t26 = insertvalue %"compiler/free:orCall" %t24, ptr %a5, 5
  %t28 = insertvalue %"compiler/free:orCall" %t26, ptr %a6, 6
  store %"compiler/free:orCall" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:orCall", ptr %rv
  ret %"compiler/free:orCall" %rr
}

define dso_local %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, ptr %a8) #0 {
entry:
  %rv = alloca %"compiler/free:store"
  br label %start
start:
  br label %bb0
bb0:
  %t20 = insertvalue %"compiler/free:store" undef, i64 %a0, 0
  %t22 = insertvalue %"compiler/free:store" %t20, i64 %a1, 1
  %t24 = insertvalue %"compiler/free:store" %t22, i64 %a2, 2
  %t26 = insertvalue %"compiler/free:store" %t24, %"compiler/source:Span" %a3, 3
  %t28 = insertvalue %"compiler/free:store" %t26, i64 %a4, 4
  %t30 = insertvalue %"compiler/free:store" %t28, i64 %a5, 5
  %t32 = insertvalue %"compiler/free:store" %t30, i64 %a6, 6
  %t34 = insertvalue %"compiler/free:store" %t32, ptr %a7, 7
  %t36 = insertvalue %"compiler/free:store" %t34, ptr %a8, 8
  store %"compiler/free:store" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:store", ptr %rv
  ret %"compiler/free:store" %rr
}

@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Pop" }>, align 8
@.d1 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"TakeAt" }>, align 8
@.d2 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"RemoveAt" }>, align 8
@.d3 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"SwapRemove" }>, align 8
@.d4 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Remove" }>, align 8
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Clear" }>, align 8
@.d6 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Truncate" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Take" }>, align 8
@.d8 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"SwapTake" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d9 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"the function" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"eq" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"hash" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb9, label %bb1
bb7:
  br label %bb3
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t46 = load i1, ptr %l2, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d17 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
declare void @__olang_ert_req_clear()
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"the " }>, align 8
@.d22 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'s scope" }>, align 8
@.d23 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'s scope" }>, align 8
@.d24 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"its scope" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d25 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"its value cannot be built in a region of its own here" }>, align 8
@.d26 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"its new value is existing storage: '" }>, align 8
@.d27 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"'; give it new storage - a constructor call, '$...', 'Clone()'" }>, align 8
@.d28 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"its value may be a try's default, not built for it" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d33 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"its value is existing storage: '" }>, align 8
@.d34 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"' - give it an instance of its own: a constructor call, or a call whose result is built" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d36 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"' is a parameter: its caller holds the instance too" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d38 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"' is a field of the instance being built, which holds it too" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d40 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"' (line " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d41 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c") reaches it too, and is used here, after '" }>, align 8
@.d42 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c".Destroy()'" }>, align 8
@.d43 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"it is returned (line " }>, align 8
@.d44 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"), and its Destroy() is deferred: it runs as the function leaves" }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"esc " }>, align 8
@.d46 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" par " }>, align 8
@.d47 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d48 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" inside " }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a reference to it is stored here, in '" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d53 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"it is handed here to what may keep it" }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a reference into it is stored here, in '" }>, align 8
@.d56 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'; store a copy, '$(...)'" }>, align 8
@.d57 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"a reference into it is kept here" }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d60 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d61 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d66 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d67 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d68 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"its new value is built where the old one lives: '" }>, align 8
@.d69 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"' borrows its result from '" }>, align 8
@.d70 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"'; a built result ('" }>, align 8
@.d71 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"') frees the old " }>, align 8
@.d72 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d73 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"its new value is not all new: '" }>, align 8
@.d74 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"' returns storage it was given" }>, align 8
@.d75 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d76 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d78 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"its new value is moved out of another place" }>, align 8
@.d79 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"its new value has a default" }>, align 8
@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d81 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"its new value is existing storage: '" }>, align 8
@.d82 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"'; give it new storage - a constructor call, '$...', 'Clone()'" }>, align 8
@.d83 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"its new value is kept in another place too" }>, align 8
@.d84 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"its new value is built in a module compiled on its own" }>, align 8
@.d85 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"may let go of anything" }>, align 8
@.d86 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"removes " }>, align 8
@.d87 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"lets go of it" }>, align 8
@.d88 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d89 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a reference to it is stored here, in '" }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d91 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"it is handed here to a call that stores it" }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a reference into it is stored here, in '" }>, align 8
@.d94 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'; store a copy, '$(...)'" }>, align 8
@.d95 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a reference into it is stored here; store a copy, '$(...)'" }>, align 8
@.d96 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d97 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a reference into it is stored here, in '" }>, align 8
@.d98 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'; store a copy, '$(...)'" }>, align 8
@.d99 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a reference into it is stored here; store a copy, '$(...)'" }>, align 8
@.d100 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"esc-store " }>, align 8
@.d101 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" par " }>, align 8
@.d102 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d103 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" within " }>, align 8
@.d104 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d105 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d106 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2ffree_2eLCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLDestroy = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLLeaf = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLVacate = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eMustTop = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eOPar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2ffree_2eSMove = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_aa0994ef0ced0737_f892d7c71adaceeb = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eMovBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\40\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0)
declare %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:leaf" %a1)
@olang_loc_3a516a19293feeda_7f77204653e04cce = external constant [0 x i8]
@olang_loc_4cef24e7d17769b7_e2744f91577a9953 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyInLoop(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyUsedAfter(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNotSole(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/free:reason" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyWhy(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_abb447fb014369ff_ca54bae4e013147b = external constant [0 x i8]
@olang_loc_b390d81e3df133fe_1bb65207cb7ceffa = external constant [0 x i8]
@olang_loc_f1cf9d8b5dd1d1b5_4d41c45ca418d191 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f0ef9f3a8cd9f24a_5f2afb921a19c616 = external constant [0 x i8]
@olang_loc_1befe4f0760966d8_ea99a8b72a88b024 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_947cc6b8bd079717_9e266d1a8b9c5cdb = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_708b3215abbdbba7_3cea2bd689d53e8b = external constant [0 x i8]
declare %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eSetAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/free:reason" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2ePush_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:reason" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_997f49c366488af5_93d2651ee5683809 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5c44d6b41b035ab1_55f561a861d07b6d = external constant [0 x i8]
@olang_loc_3bfd4abaed3d7178_ecedd42d9535955c = external constant [0 x i8]
declare ptr @compiler_2ffree_2ecallOf(ptr %v0, ptr %a0)
@olang_loc_18f4ed1d8e27b1ae_93487f3f650a5572 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0)
declare %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eSFresh = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisContents(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_cba1607a5f8c25be_1da50212bb736ed2 = external constant [0 x i8]
@olang_loc_a35b07018a31f4f3_69e61a5b7415d1c7 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0)
declare %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_78dfe086e9f9163d_4fecfa12a5383061 = external constant [0 x i8]
@olang_loc_b4c0d703fa684531_272a8f4f39064c15 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_30cfd3b464a887aa_ca3830b5343a05a6 = external constant [0 x i8]
@olang_loc_3a3557a9366273b1_8eafb121351cf8d = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviews(ptr %v0, ptr %a0)
@G_2ecompiler_2ffree_2eMustNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_6cb79447255537d7_e828faabaec907d3 = external constant [0 x i8]
@olang_loc_b0d58e2b07420cd2_669637d27520b416 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i1 %a5, i1 %a6)
@olang_loc_68d66244454596f9_ea33ff3f8eb363fd = external constant [0 x i8]
@G_2ecompiler_2ffree_2eRMade = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %a0)
declare %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %a0)
declare %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2, { i64, [1 x i64] } %a3)
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_14962ab25e47b4fc_3749941476b1d040 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8d35557863f6e46b_2765f8f7d1e0ebdf = external constant [0 x i8]
@olang_loc_502532e2e95f04ea_fe436d8dc2f78aae = external constant [0 x i8]
@olang_loc_ba297c355e3740f1_9975a70d069e6a55 = external constant [0 x i8]
@olang_loc_bb85040a6a786cb8_20e886069e3b9c04 = external constant [0 x i8]
@olang_loc_be187497b97f18d7_9641cb8c9c409d3 = external constant [0 x i8]
@olang_loc_342e0c3fe78e7ee6_419d07e7c20dd892 = external constant [0 x i8]
@olang_loc_d5478abcfcd1a74_537f989617a8cff0 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2ePush_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2ePop_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_620cc86993d1ee05_2ed463b6a2f232e1 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v0, ptr %a0)
@G_2ecompiler_2ffree_2eLAssign = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5)
@olang_loc_e251e9e241135754_793c210c71879d50 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_2fa77e012092fd19_7ffe9e1eddadbc5d = external constant [0 x i8]
@olang_loc_59a6b24cdfdba848_73366ee735d239ac = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ffree_2eokind(i64 %a0)
@olang_loc_3ed6c54977104fdc_6fa493e2929cd018 = external constant [0 x i8]
declare i1 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClone_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_5c4d06a93fa4e0f2_2916de872c41e4ce = external constant [0 x i8]
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ffree_2eSFail = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
@olang_loc_ecfdd571afc7fb57_85e5c41b21451123 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@G_2ecompiler_2ffree_2eOPl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eorig(i64 %a0, i64 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyAfter(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, ptr %a4)
@G_2ecompiler_2ffree_2eRView = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRStore = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
@olang_loc_5ca0c94719aba3bb_f8486f1b87c86b37 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eborrowOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etakeOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2ffree_2eONew = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2eisVar({ i64, [1 x i64] } %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_dc7e16ca98e3c304_3c9b7555f95fce88 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeStores(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_c4f9ad7cc46c30d3_40011a8198a2fca7 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H5927ce9e0c48ffa4d9cf1c64f8f12c1b(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_fd3298abbcb5ff92_1a857839cb7bbff6 = external constant [0 x i8]
@olang_loc_5a2a443e2f2f03b9_3064adab7524445d = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_f2df24d87159f740_3aba0f93d819cd0c = external constant [0 x i8]
@olang_loc_e2fb89bbcc8912df_b34dca3bd4e44f7b = external constant [0 x i8]
@olang_loc_b9d8fe51bd9fb1ae_e9263c049ba8f2ba = external constant [0 x i8]
@olang_loc_67165cb650ae48c_1f30efdb88316bc8 = external constant [0 x i8]
@olang_loc_b6b576316e1b3293_3c9a5af727622297 = external constant [0 x i8]
@olang_loc_797639ecae530892_5422fc7df8fd29f6 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebuiltSpell(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewhat(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_fa71248d89b17b0b_39d265aac120d27f = external constant [0 x i8]
@G_2ecompiler_2ffree_2eAnyPlace = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v0, ptr %a0)
@G_2ecompiler_2ffree_2eSOk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_7676aaa4af173342_5bef0e3278c42ba6 = external constant [0 x i8]
@olang_loc_1665755e987b0d60_2375c09fda7e834 = external constant [0 x i8]
declare %"compiler/free:orStore" @compiler_2ffree_3aorStore_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, ptr %a2, ptr %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2ePush_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:orStore" %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexclusive(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2eLen_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_bfa96af29dec6ca7_6eacd8161d4b79f3 = external constant [0 x i8]
@olang_loc_3f338d8afa9da51a_e8058e9e002c9166 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_311feee871305b59_d38294057dde4ced = external constant [0 x i8]
@olang_loc_421add8d063ee188_aab923ea260c413c = external constant [0 x i8]
declare i1 @compiler_2ffree_2epureBase(ptr %v0, ptr %a0)
@olang_loc_34bfc259355dec67_8a2d14d061fee643 = external constant [0 x i8]
@olang_loc_806a74b5c91de186_4e306eb4964e9ec2 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2058a1f1b30311f1_26f3aef7996ef6dd = external constant [0 x i8]
@G_2ecompiler_2ffree_2eOMov = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_546be3fdfb2e7861_5a4791e17fa5075d = external constant [0 x i8]
@olang_loc_5891e56eddc46c99_f944b0e713971375 = external constant [0 x i8]
declare ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ee9887f5f58478ff_db34cc814b361eab = external constant [0 x i8]
@olang_loc_2779327e577b2afc_81ce12c77e8d0b58 = external constant [0 x i8]
@olang_loc_6ad9637bd46aa97_a10a430e5eff5d73 = external constant [0 x i8]
@olang_loc_83047756a0f84ae3_95aa60b35b875f1f = external constant [0 x i8]
declare void @compiler_2ffree_3awalker_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_ce893683105a8b06_84bedcfad8df0b4a = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlace_26_3e_2eClear_H3be601f049db8fee531e82245bd6456a(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Hca84839cdf395382408370342cfafe64(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H2ad576503181bd1b8552368bfa2352a6(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_1b38cdd871e6a94_bc3035ea47e7c9d8 = external constant [0 x i8]
@olang_loc_40628693553637f3_9a0aaf33c7b3625f = external constant [0 x i8]
@olang_loc_11a48ff1e8d67007_90e1a85549f82d33 = external constant [0 x i8]
@olang_loc_e0188cd4392210a6_c14318bc74dc83b2 = external constant [0 x i8]
@olang_loc_d0a35c72e1689727_18f1e8c23ad8e373 = external constant [0 x i8]
@olang_loc_9d733ba55f12146_b889888c2106eef2 = external constant [0 x i8]
@olang_loc_9c97567f05482d15_e6d42a2535d66e1 = external constant [0 x i8]
declare i1 @compiler_2ffree_2esamePurePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_a76c2f62bbf8a003_89a44c6922f8d22f = external constant [0 x i8]
@olang_loc_e31a42735e4aee82_13f2226a4db7316e = external constant [0 x i8]
@olang_loc_497cb5294fb5d476_59996708b38ef322 = external constant [0 x i8]
@olang_loc_d76336629ed12804_de1ad14eaa737c40 = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
