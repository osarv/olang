; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"compiler/mir:GenInfo", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/free:feed" = type { i64, i64, i64, i64, { i64, [2 x i64] }, { i64, [2 x i64] }, i64 }
%"compiler/free:retire" = type { i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/free:store" = type { i64, i64, i64, %"compiler/source:Span", i64, i64, i64, ptr, ptr }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/free:mustW" = type { ptr, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/free:walker" = type { ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/free:orStore" = type { i64, i64, ptr, ptr }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
%"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i64, ptr %l13, !tbaa !24
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp eq i64 %t18, %t20
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i64 0, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t30, i64 %t31)
  br label %bb12
bb12:
  store i64 1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2ffree_2ebaseOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  br label %bb23
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 4
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Elem", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  store ptr %t37, ptr %l4, !tbaa !29
  br label %bb23
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 8}
  %t47 = icmp eq i64 %t45, 5
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l23, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Payload", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store ptr null, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_aa0994ef0ced0737_f892d7c71adaceeb)
  unreachable
bb23:
  %t61 = load ptr, ptr %l4, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDroppedMove(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i1
  %l16 = alloca ptr
  %l24 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 115
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %a1)
  store i64 %t11, ptr %l9
  br label %bb4
bb4:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb8
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 1
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l16
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 11
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  store i1 %t29, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l12, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:Free", ptr %t33, i32 0, i32 73
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t35, i64 %t36)
  store i64 %t39, ptr %l24
  br label %bb12
bb12:
  %t40 = load i64, ptr %l24, !tbaa !24
  store i64 %t40, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  br i1 %t45, label %bb13, label %bb14
bb13:
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t52 = sub i64 %t48, %t49
  store i64 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFeedSite(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i64
  %l15 = alloca i32
  %l18 = alloca i64
  %l22 = alloca %"compiler/free:feed"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 115
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/free:Free", ptr %t9, i32 0, i32 111
  store ptr %t11, ptr %l10, !tbaa !29
  %t16 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t16, ptr %l13
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l13
  %t19 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t17, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t18)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l15
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb6, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l14
  br label %bb5
bb5:
  %t24 = load i64, ptr %l14, !tbaa !24
  store i64 %t24, ptr %l8, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t25 = load i64, ptr %l8, !tbaa !24
  store i64 %t25, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/free:Free", ptr %t30, i32 0, i32 110
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t32, i64 %t33)
  store %"compiler/free:feed" %t36, ptr %l22
  br label %bb11
bb10:
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb12
bb11:
  %t37 = getelementptr %"compiler/free:feed", ptr %l22, i32 0, i32 6
  %t38 = load i64, ptr %t37, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i64, ptr %l18, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFrees(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l11 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 115
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sge i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 1
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l11
  br label %bb6
bb5:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l7, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFreshCtorAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l4 = alloca ptr
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 108
  store ptr %t3, ptr %l4, !tbaa !29
  %t8 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t9, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10)
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i1, ptr %l8, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 12
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 12
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t18, i64 %t19)
  store i1 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l10, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eLocalPlaceOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l28 = alloca i64
  %l29 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 115
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, 0
  store i1 %t10, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l6, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb5:
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:Free", ptr %t14, i32 0, i32 104
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l13
  br label %bb6
bb6:
  %t19 = load i64, ptr %l10, !tbaa !24
  %t20 = load i64, ptr %l13, !tbaa !24
  %t21 = icmp sge i64 %t19, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb11
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/free:Free", ptr %t24, i32 0, i32 104
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t26, i64 %t27)
  store i1 %t30, ptr %l19
  br label %bb10
bb10:
  %t31 = load i1, ptr %l19, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  %t34 = load i1, ptr %l15, !tbaa !21
  br i1 %t34, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 101
  store ptr %t38, ptr %l24, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t43 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t39, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t43, ptr %l27
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l27
  %t46 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t44, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t45)
  %t47 = extractvalue { i32, i64 } %t46, 1
  %t48 = extractvalue { i32, i64 } %t46, 0
  store i32 %t48, ptr %l29
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb17, label %ok.50, !prof !99
ok.50:
  store i64 %t47, ptr %l28
  br label %bb16
bb16:
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %l22, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t52 = load i64, ptr %l22, !tbaa !24
  store i64 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eRetirePlaces(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/free:retire"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l19 = alloca i64
  %l24 = alloca %"compiler/free:retire"
  %l26 = alloca %"compiler/free:retire"
  %l30 = alloca i1
  %l31 = alloca %"compiler/source:Span"
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca i1
  %l38 = alloca i64
  %l40 = alloca i64
  %l45 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i1
  %l52 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca ptr
  %l58 = alloca i64
  %l59 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 115
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %lp3
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/free:Free", ptr %t15, i32 0, i32 14
  store ptr %t17, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load i64, ptr %l5, !tbaa !24
  store i64 %t19, ptr %l17, !tbaa !24
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2eLen_3ccompiler_2ffree_3aretire_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l19
  br label %bb6
bb6:
  %t23 = load i64, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l19, !tbaa !24
  %t25 = icmp slt i64 %t23, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb8:
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = call %"compiler/free:retire" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2eAt_3ccompiler_2ffree_3aretire_3e(ptr %v0, ptr %v0, ptr %t29, i64 %t30)
  store %"compiler/free:retire" %t33, ptr %l24
  br label %bb10
bb10:
  %t35 = call %"compiler/free:retire" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aretire(ptr %s3, ptr %l24)
  store %"compiler/free:retire" %t35, ptr %l26
  br label %bb11
bb11:
  %t36 = load %"compiler/free:retire", ptr %l26
  store %"compiler/free:retire" %t36, ptr %l6
  %t37 = getelementptr %"compiler/free:retire", ptr %l6, i32 0, i32 0
  %t38 = load i64, ptr %t37, !tbaa !24
  %t42 = icmp ne i64 %t38, %a1
  br i1 %t42, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb15
bb13:
  %t44 = getelementptr %"compiler/free:retire", ptr %l6, i32 0, i32 1
  %t45 = load %"compiler/source:Span", ptr %t44
  store %"compiler/source:Span" %t45, ptr %l31
  store %"compiler/source:Span" %a2, ptr %l33
  %t49 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l31, ptr %l33)
  store i1 %t49, ptr %l35
  br label %bb14
bb14:
  %t50 = load i1, ptr %l35, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb17:
  br label %bb18
bb18:
  %t54 = getelementptr %"compiler/free:retire", ptr %l6, i32 0, i32 2
  store ptr %t54, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb19
bb19:
  %t56 = load i64, ptr %l8, !tbaa !24
  store i64 %t56, ptr %l38, !tbaa !24
  %t57 = load ptr, ptr %l7, !tbaa !29
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %t57)
  store i64 %t59, ptr %l40
  br label %bb20
bb20:
  %t60 = load i64, ptr %l38, !tbaa !24
  %t61 = load i64, ptr %l40, !tbaa !24
  %t62 = icmp slt i64 %t60, %t61
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb21, label %bb22
bb21:
  br label %bb37
bb22:
  br label %bb23
bb23:
  %t66 = load ptr, ptr %l7, !tbaa !29
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %t66, i64 %t67)
  store i64 %t70, ptr %l45
  br label %bb24
bb24:
  %t71 = load i64, ptr %l45, !tbaa !24
  store i64 %t71, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = call i64 @compiler_2ffree_2eokind(i64 %t72)
  store i64 %t74, ptr %l47
  br label %bb25
bb25:
  %t75 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t76 = load i64, ptr %l47, !tbaa !24
  %t78 = icmp eq i64 %t76, %t75
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:Free", ptr %t80, i32 0, i32 13
  store ptr %t82, ptr %l52, !tbaa !29
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = call i64 @compiler_2ffree_2eoval(i64 %t83)
  store i64 %t85, ptr %l54
  br label %bb28
bb27:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb30
bb28:
  %t86 = load ptr, ptr %l52, !tbaa !29
  %t87 = load i64, ptr %l54, !tbaa !24
  %t88 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t86, i64 %t87)
  store i1 %t88, ptr %l55
  br label %bb29
bb29:
  %t89 = load i1, ptr %l55, !tbaa !21
  store i1 %t89, ptr %l50, !tbaa !21
  br label %bb30
bb30:
  %t90 = load i1, ptr %l50, !tbaa !21
  br i1 %t90, label %bb31, label %bb32
bb31:
  %t91 = load ptr, ptr %lp3
  store ptr %t91, ptr %l56, !tbaa !29
  %t92 = load i64, ptr %l9, !tbaa !24
  %t94 = call i64 @compiler_2ffree_2eoval(i64 %t92)
  store i64 %t94, ptr %l58
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t95 = load ptr, ptr %l56, !tbaa !29
  %t96 = load i64, ptr %l58, !tbaa !24
  %t97 = call i64 @compiler_2ffree_2eaddTo(ptr %v1, ptr %t95, i64 %t96)
  store i64 %t97, ptr %l59
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l8, !tbaa !24
  br label %bb19
bb37:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb38:
  %t102 = load i64, ptr %l5, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l5, !tbaa !24
  br label %bb5
bb39:
  %t106 = load ptr, ptr %lp3
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t106
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSlotPlace(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l18 = alloca i64
  %l20 = alloca i1
  %l24 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i32
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i64
  %l61 = alloca i1
  %l62 = alloca i64
  %l67 = alloca i64
  %l69 = alloca i1
  %l75 = alloca ptr
  %l78 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l86 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i32
  %l90 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i1
  %l101 = alloca i1
  %l104 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 10
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb8
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 10
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l18
  br label %bb7
bb7:
  %t23 = load i64, ptr %l18, !tbaa !24
  %t24 = icmp slt i64 %t23, 0
  store i1 %t24, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l14, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb12
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:Free", ptr %t27, i32 0, i32 13
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t29, i64 %t30)
  store i1 %t33, ptr %l24
  br label %bb11
bb11:
  %t34 = load i1, ptr %l24, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb16
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/free:Free", ptr %t38, i32 0, i32 12
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t40, i64 %t41)
  store i1 %t44, ptr %l30
  br label %bb15
bb15:
  %t45 = load i1, ptr %l30, !tbaa !21
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb20
bb18:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/free:Free", ptr %t47, i32 0, i32 11
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t49, i64 %t50)
  store i1 %t53, ptr %l35
  br label %bb19
bb19:
  %t54 = load i1, ptr %l35, !tbaa !21
  store i1 %t54, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t55 = load i1, ptr %l31, !tbaa !21
  br i1 %t55, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t57)
  store ptr %t59, ptr %l38
  br label %bb24
bb24:
  %t60 = load ptr, ptr %l38, !tbaa !29
  store ptr %t60, ptr %l2, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  store ptr %t61, ptr %l39, !tbaa !29
  %t62 = load ptr, ptr %l2, !tbaa !29
  store ptr %t62, ptr %l40, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:Free", ptr %t63, i32 0, i32 9
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t65, i64 %t66)
  store i32 %t69, ptr %l44
  br label %bb25
bb25:
  %t70 = load ptr, ptr %l40, !tbaa !29
  %t71 = load i32, ptr %l44, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l45
  br label %bb26
bb26:
  %t73 = load ptr, ptr %l39, !tbaa !29
  %t74 = load i32, ptr %l45, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t75, ptr %l46
  br label %bb27
bb27:
  %t76 = load i32, ptr %l46, !tbaa !23
  store i32 %t76, ptr %l3, !tbaa !23
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t81, ptr %l49
  br label %bb28
bb28:
  %t82 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t84 = trunc i64 18 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t90 = load ptr, ptr %l2, !tbaa !29
  store ptr %t90, ptr %l54, !tbaa !29
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t92 = load i32, ptr %l3, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l57
  br label %bb32
bb32:
  %t96 = load ptr, ptr %l54, !tbaa !29
  %t97 = load i32, ptr %l57, !tbaa !23
  %t98 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t96, i32 %t97)
  store i64 %t98, ptr %l58
  br label %bb33
bb33:
  %t99 = load i64, ptr %l58, !tbaa !24
  store i64 %t99, ptr %l4, !tbaa !24
  %t100 = load i64, ptr %l4, !tbaa !24
  %t102 = icmp slt i64 %t100, 0
  br i1 %t102, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb37
bb35:
  %t104 = load i64, ptr %l4, !tbaa !24
  store i64 %t104, ptr %l62, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:Free", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/load:Loader", ptr %t111, i32 0, i32 10
  %t115 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t113)
  store i64 %t115, ptr %l67
  br label %bb36
bb36:
  %t116 = load i64, ptr %l62, !tbaa !24
  %t117 = load i64, ptr %l67, !tbaa !24
  %t118 = icmp sge i64 %t116, %t117
  store i1 %t118, ptr %l61, !tbaa !21
  br label %bb37
bb37:
  %t120 = load i1, ptr %l61, !tbaa !21
  br i1 %t120, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb42
bb39:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/free:Free", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 0
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/load:Loader", ptr %t127, i32 0, i32 10
  %t130 = load i64, ptr %l4, !tbaa !24
  %t133 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t129, i64 %t130)
  store ptr %t133, ptr %l75
  br label %bb40
bb40:
  %t134 = load ptr, ptr %l75, !tbaa !29
  %t136 = getelementptr %"compiler/load:Module", ptr %t134, i32 0, i32 2
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  %t139 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t137, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t139, ptr %l78
  br label %bb41
bb41:
  %t140 = load i1, ptr %l78, !tbaa !21
  %t141 = xor i1 %t140, true
  store i1 %t141, ptr %l69, !tbaa !21
  br label %bb42
bb42:
  %t143 = load i1, ptr %l69, !tbaa !21
  br i1 %t143, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t145 = load ptr, ptr %l2, !tbaa !29
  store ptr %t145, ptr %l81, !tbaa !29
  %t146 = load ptr, ptr %l2, !tbaa !29
  store ptr %t146, ptr %l82, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/free:Free", ptr %t147, i32 0, i32 15
  %t150 = load i64, ptr %l1, !tbaa !24
  %t153 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t149, i64 %t150)
  store i32 %t153, ptr %l86
  br label %bb46
bb46:
  %t154 = load ptr, ptr %l82, !tbaa !29
  %t155 = load i32, ptr %l86, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t156, ptr %l87
  br label %bb47
bb47:
  %t157 = load ptr, ptr %l81, !tbaa !29
  %t158 = load i32, ptr %l87, !tbaa !23
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t157, i32 %t158)
  store i32 %t159, ptr %l88
  br label %bb48
bb48:
  %t160 = load i32, ptr %l88, !tbaa !23
  store i32 %t160, ptr %l5, !tbaa !23
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/free:Free", ptr %t161, i32 0, i32 0
  %t164 = load ptr, ptr %t163, !tbaa !29
  store ptr %t164, ptr %l90, !tbaa !29
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/free:Free", ptr %t165, i32 0, i32 15
  %t168 = load i64, ptr %l1, !tbaa !24
  %t171 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t167, i64 %t168)
  store i32 %t171, ptr %l94
  br label %bb49
bb49:
  %t172 = load ptr, ptr %l90, !tbaa !29
  %t173 = load i32, ptr %l94, !tbaa !23
  %t174 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %t172, i32 %t173)
  store i1 %t174, ptr %l95
  br label %bb50
bb50:
  %t175 = load i1, ptr %l95, !tbaa !21
  br i1 %t175, label %bb51, label %bb52
bb51:
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t177 = load i32, ptr %l5, !tbaa !23
  %t180 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t176, i32 %t177)
  store i1 %t180, ptr %l99
  br label %bb53
bb52:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb54
bb53:
  %t181 = load i1, ptr %l99, !tbaa !21
  %t182 = xor i1 %t181, true
  store i1 %t182, ptr %l96, !tbaa !21
  br label %bb54
bb54:
  %t184 = load i1, ptr %l96, !tbaa !21
  br i1 %t184, label %bb55, label %bb56
bb55:
  %t185 = load ptr, ptr %l2, !tbaa !29
  %t186 = load i32, ptr %l5, !tbaa !23
  %t189 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t185, i32 %t186)
  store i1 %t189, ptr %l104
  br label %bb57
bb56:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb58
bb57:
  %t190 = load i1, ptr %l104, !tbaa !21
  %t191 = xor i1 %t190, true
  store i1 %t191, ptr %l101, !tbaa !21
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t193 = load i1, ptr %l101, !tbaa !21
  store i1 %t193, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSoleNow(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 115
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %lp1
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/free:Free", ptr %t15, i32 0, i32 90
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l15
  br label %bb5
bb5:
  %t20 = load i64, ptr %l15, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb11
bb8:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l22, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l22, !tbaa !24
  store i64 %t47, ptr %l19, !tbaa !24
  br label %bb11
bb11:
  %t48 = load i64, ptr %l19, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb13, label %bb14
bb13:
  br label %bb22
bb14:
  br label %bb15
bb15:
  %t57 = load i64, ptr %l2, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l7, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/free:Free", ptr %t67, i32 0, i32 90
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t69, i64 %t70)
  store i1 %t73, ptr %l43
  br label %bb16
bb16:
  %t74 = load i1, ptr %l43, !tbaa !21
  br i1 %t74, label %bb17, label %bb18
bb17:
  %t75 = load ptr, ptr %lp1
  %t76 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t75, i64 %t76)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l6, !tbaa !24
  br label %bb12
bb22:
  %t83 = load ptr, ptr %lp1
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSplitPath(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l14 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 115
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = icmp sge i64 0, 0
  br i1 %t8, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t10 = icmp sle i64 0, 1152921504606846975
  br i1 %t10, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6a56aba8df98d2ec_68c83986518f8c70)
  unreachable
bb5:
  %t12 = mul i64 0, 8
  %t13 = insertvalue { i64, ptr } undef, i64 0, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t14, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6a56aba8df98d2ec_68c83986518f8c70)
  unreachable
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 109
  store ptr %t18, ptr %l11, !tbaa !29
  %t23 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t23, ptr %l14
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l11, !tbaa !29
  %t25 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l14
  %t26 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf6c82cf5f0e7149f7052eb5498c4cd14(ptr %v0, ptr %v1, ptr %t24, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t25)
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l16
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb10, label %ok.30, !prof !99
ok.30:
  store { i64, ptr } %t27, ptr %l15
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l17, !tbaa !24
  %t33 = load i64, ptr %l17, !tbaa !24
  %t34 = mul i64 %t33, 8
  %t35 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l18, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l17, !tbaa !24
  %t43 = mul i64 %t42, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t44, ptr %l9, !tbaa !27
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t45 = icmp sge i64 0, 0
  br i1 %t45, label %bb12, label %bb13
bb12:
  %t47 = icmp sle i64 0, 1152921504606846975
  br i1 %t47, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8ae6f1105e3c6679_a593dc3435f5df1d)
  unreachable
bb14:
  %t49 = mul i64 0, 8
  %t50 = insertvalue { i64, ptr } undef, i64 0, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t51, ptr %l9, !tbaa !27
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_8ae6f1105e3c6679_a593dc3435f5df1d)
  unreachable
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eacrossHas(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca i64
  %l32 = alloca ptr
  %l34 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 37
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load i1, ptr %l10, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l12
  br label %bb5
bb5:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l3
  %t12 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t12)
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = trunc i64 %t16 to i32
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholdsTypes(ptr %v0, ptr %s0, ptr %t15, i32 %t18, ptr %l3, i64 0)
  br label %bb7
bb7:
  store ptr %l3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t24 = load i64, ptr %l5, !tbaa !24
  store i64 %t24, ptr %l21, !tbaa !24
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t25)
  store i64 %t27, ptr %l23
  br label %bb9
bb9:
  %t28 = load i64, ptr %l21, !tbaa !24
  %t29 = load i64, ptr %l23, !tbaa !24
  %t30 = icmp slt i64 %t28, %t29
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t34, i64 %t35)
  store i64 %t38, ptr %l28
  br label %bb13
bb13:
  %t39 = load i64, ptr %l28, !tbaa !24
  store i64 %t39, ptr %l6, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:Free", ptr %t40, i32 0, i32 36
  %t43 = load i64, ptr %l1, !tbaa !24
  %t46 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t42, i64 %t43)
  store ptr %t46, ptr %l32
  br label %bb14
bb14:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load ptr, ptr %l32, !tbaa !29
  %t50 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t48, i64 %t47)
  store i1 %t50, ptr %l34
  br label %bb15
bb15:
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l5, !tbaa !24
  br label %bb8
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eaddBody(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l8 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i1
  %l30 = alloca ptr
  %l33 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca ptr
  %l42 = alloca i64
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca ptr
  %l48 = alloca i64
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca ptr
  %l60 = alloca i64
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca ptr
  %l66 = alloca i64
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca ptr
  %l72 = alloca i64
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca ptr
  %l84 = alloca i64
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca ptr
  %l105 = alloca ptr
  %l109 = alloca i64
  %l110 = alloca ptr
  %l113 = alloca i1
  %l116 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i64
  %l124 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l127 = alloca ptr
  %l128 = alloca i64
  %l130 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l133 = alloca ptr
  %l134 = alloca i64
  %l136 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l139 = alloca ptr
  %l140 = alloca i64
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l149 = alloca ptr
  %l150 = alloca i64
  %l156 = alloca ptr
  %l157 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 21
  %t10 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t9, i64 %t10)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 22
  store ptr %t15, ptr %l13, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 8
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp eq i64 %t23, -3
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb5:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp eq i64 %t27, %a2
  store i1 %t31, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = load i1, ptr %l17, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t34, i1 %t35)
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 23
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownCode(ptr %v0, ptr %t39, i64 %t40)
  store i1 %t43, ptr %l28
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = load i1, ptr %l28, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t44, i1 %t45)
  br label %bb11
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/free:Free", ptr %t46, i32 0, i32 61
  store ptr %t48, ptr %l30, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epreludeCode(ptr %v0, ptr %t49, i64 %t50)
  store i1 %t53, ptr %l33
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i1, ptr %l33, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t54, i1 %t55)
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/free:Free", ptr %t56, i32 0, i32 62
  store ptr %t58, ptr %l35, !tbaa !29
  %t59 = ptrtoint ptr %v0 to i64
  store i64 %t59, ptr %l36, !tbaa !24
  %t60 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t62 = call ptr @__olang_region_make(ptr %v0)
  %t63 = ptrtoint ptr %t62 to i64
  store i64 %t63, ptr %l36, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l36
  %t65 = inttoptr i64 %t64 to ptr
  %t66 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t65, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %l38
  br label %bb16
bb16:
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  %t68 = load i64, ptr %l36
  %t69 = inttoptr i64 %t68 to ptr
  %t70 = call ptr @__olang_scope_alloc_a(ptr %t69, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %t70
  %t71 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t71, ptr %t70)
  br label %bb17
bb17:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 63
  store ptr %t75, ptr %l41, !tbaa !29
  %t76 = ptrtoint ptr %v0 to i64
  store i64 %t76, ptr %l42, !tbaa !24
  %t77 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t79 = call ptr @__olang_region_make(ptr %v0)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l42, !tbaa !24
  br label %bb19
bb19:
  %t81 = load i64, ptr %l42
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t82, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t83, ptr %l44
  br label %bb20
bb20:
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  %t85 = load i64, ptr %l42
  %t86 = inttoptr i64 %t85 to ptr
  %t87 = call ptr @__olang_scope_alloc_a(ptr %t86, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %t87
  %t88 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t88, ptr %t87)
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:Free", ptr %t90, i32 0, i32 64
  store ptr %t92, ptr %l47, !tbaa !29
  %t93 = ptrtoint ptr %v0 to i64
  store i64 %t93, ptr %l48, !tbaa !24
  %t94 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t96 = call ptr @__olang_region_make(ptr %v0)
  %t97 = ptrtoint ptr %t96 to i64
  store i64 %t97, ptr %l48, !tbaa !24
  br label %bb23
bb23:
  %t98 = load i64, ptr %l48
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t99, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %l50
  br label %bb24
bb24:
  %t101 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  %t102 = load i64, ptr %l48
  %t103 = inttoptr i64 %t102 to ptr
  %t104 = call ptr @__olang_scope_alloc_a(ptr %t103, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t101, ptr %t104
  %t105 = load ptr, ptr %l47, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t105, ptr %t104)
  br label %bb25
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/free:Free", ptr %t107, i32 0, i32 65
  store ptr %t109, ptr %l53, !tbaa !29
  %t110 = ptrtoint ptr %v0 to i64
  store i64 %t110, ptr %l54, !tbaa !24
  %t111 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t113 = call ptr @__olang_region_make(ptr %v0)
  %t114 = ptrtoint ptr %t113 to i64
  store i64 %t114, ptr %l54, !tbaa !24
  br label %bb27
bb27:
  %t115 = load i64, ptr %l54
  %t116 = inttoptr i64 %t115 to ptr
  %t117 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t116, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %l56
  br label %bb28
bb28:
  %t118 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  %t119 = load i64, ptr %l54
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = call ptr @__olang_scope_alloc_a(ptr %t120, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %t121
  %t122 = load ptr, ptr %l53, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t122, ptr %t121)
  br label %bb29
bb29:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/free:Free", ptr %t124, i32 0, i32 66
  store ptr %t126, ptr %l59, !tbaa !29
  %t127 = ptrtoint ptr %v0 to i64
  store i64 %t127, ptr %l60, !tbaa !24
  %t128 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t128, label %bb30, label %bb31
bb30:
  %t130 = call ptr @__olang_region_make(ptr %v0)
  %t131 = ptrtoint ptr %t130 to i64
  store i64 %t131, ptr %l60, !tbaa !24
  br label %bb31
bb31:
  %t132 = load i64, ptr %l60
  %t133 = inttoptr i64 %t132 to ptr
  %t134 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t133, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %l62
  br label %bb32
bb32:
  %t135 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  %t136 = load i64, ptr %l60
  %t137 = inttoptr i64 %t136 to ptr
  %t138 = call ptr @__olang_scope_alloc_a(ptr %t137, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t135, ptr %t138
  %t139 = load ptr, ptr %l59, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t139, ptr %t138)
  br label %bb33
bb33:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/free:Free", ptr %t141, i32 0, i32 67
  store ptr %t143, ptr %l65, !tbaa !29
  %t144 = ptrtoint ptr %v0 to i64
  store i64 %t144, ptr %l66, !tbaa !24
  %t145 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t145, label %bb34, label %bb35
bb34:
  %t147 = call ptr @__olang_region_make(ptr %v0)
  %t148 = ptrtoint ptr %t147 to i64
  store i64 %t148, ptr %l66, !tbaa !24
  br label %bb35
bb35:
  %t149 = load i64, ptr %l66
  %t150 = inttoptr i64 %t149 to ptr
  %t151 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t150, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l68
  br label %bb36
bb36:
  %t152 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  %t153 = load i64, ptr %l66
  %t154 = inttoptr i64 %t153 to ptr
  %t155 = call ptr @__olang_scope_alloc_a(ptr %t154, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %t155
  %t156 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t156, ptr %t155)
  br label %bb37
bb37:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/free:Free", ptr %t158, i32 0, i32 68
  store ptr %t160, ptr %l71, !tbaa !29
  %t161 = ptrtoint ptr %v0 to i64
  store i64 %t161, ptr %l72, !tbaa !24
  %t162 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t162, label %bb38, label %bb39
bb38:
  %t164 = call ptr @__olang_region_make(ptr %v0)
  %t165 = ptrtoint ptr %t164 to i64
  store i64 %t165, ptr %l72, !tbaa !24
  br label %bb39
bb39:
  %t166 = load i64, ptr %l72
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t167, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168, ptr %l74
  br label %bb40
bb40:
  %t169 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  %t170 = load i64, ptr %l72
  %t171 = inttoptr i64 %t170 to ptr
  %t172 = call ptr @__olang_scope_alloc_a(ptr %t171, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t169, ptr %t172
  %t173 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t173, ptr %t172)
  br label %bb41
bb41:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/free:Free", ptr %t175, i32 0, i32 69
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t177, i1 false)
  br label %bb42
bb42:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/free:Free", ptr %t179, i32 0, i32 70
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t181, i64 0)
  br label %bb43
bb43:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/free:Free", ptr %t183, i32 0, i32 71
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t185, i64 0)
  br label %bb44
bb44:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/free:Free", ptr %t187, i32 0, i32 72
  store ptr %t189, ptr %l83, !tbaa !29
  %t190 = ptrtoint ptr %v0 to i64
  store i64 %t190, ptr %l84, !tbaa !24
  %t191 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t191, label %bb45, label %bb46
bb45:
  %t193 = call ptr @__olang_region_make(ptr %v0)
  %t194 = ptrtoint ptr %t193 to i64
  store i64 %t194, ptr %l84, !tbaa !24
  br label %bb46
bb46:
  %t195 = load i64, ptr %l84
  %t196 = inttoptr i64 %t195 to ptr
  %t197 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t196, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t197, ptr %l86
  br label %bb47
bb47:
  %t198 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  %t199 = load i64, ptr %l84
  %t200 = inttoptr i64 %t199 to ptr
  %t201 = call ptr @__olang_scope_alloc_a(ptr %t200, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t198, ptr %t201
  %t202 = load ptr, ptr %l83, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t202, ptr %t201)
  br label %bb48
bb48:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/free:Free", ptr %t204, i32 0, i32 73
  %t207 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t206, i64 %t207)
  br label %bb49
bb49:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/free:Free", ptr %t210, i32 0, i32 74
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t212, i1 true)
  br label %bb50
bb50:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/free:Free", ptr %t214, i32 0, i32 75
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t216, i1 false)
  br label %bb51
bb51:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/free:Free", ptr %t218, i32 0, i32 1
  %t221 = load i64, ptr %l1, !tbaa !24
  %t224 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t220, i64 %t221)
  store ptr %t224, ptr %l98
  br label %bb52
bb52:
  %t225 = load ptr, ptr %l98, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Body", ptr %t225, i32 0, i32 1
  %t228 = load { i64, [2 x i64] }, ptr %t227
  store { i64, [2 x i64] } %t228, ptr %l4
  %t230 = load { i64, [2 x i64] }, ptr %l4
  %t232 = extractvalue { i64, [2 x i64] } %t230, 0
  %t233 = icmp eq i64 %t232, 0
  br i1 %t233, label %bb53, label %bb54
bb53:
  %t235 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t236 = getelementptr { i64 }, ptr %t235, i32 0, i32 0
  %t237 = load i64, ptr %t236
  store i64 %t237, ptr %l5, !tbaa !24
  br label %bb55
bb54:
  br label %bb66
bb55:
  store %olang.scope zeroinitializer, ptr %s1
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/free:Free", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  store ptr %t242, ptr %l105, !tbaa !29
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/free:Free", ptr %t243, i32 0, i32 0
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t247 = load i64, ptr %l5, !tbaa !24
  %t250 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t246, i64 %t247)
  store i64 %t250, ptr %l109
  br label %bb56
bb56:
  %t251 = load ptr, ptr %l105, !tbaa !29
  %t252 = load i64, ptr %l109, !tbaa !24
  %t253 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s1, ptr %t251, i64 %t252)
  store ptr %t253, ptr %l110
  br label %bb57
bb57:
  %t254 = load ptr, ptr %l110, !tbaa !29
  %t256 = getelementptr %"compiler/ast:Func", ptr %t254, i32 0, i32 7
  %t257 = load i1, ptr %t256, !tbaa !21
  br i1 %t257, label %bb58, label %bb59
bb58:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i64, ptr %l5, !tbaa !24
  %t263 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandedToC(ptr %v0, ptr %t259, i64 %t260)
  store i1 %t263, ptr %l116
  br label %bb60
bb59:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb61
bb60:
  %t264 = load i1, ptr %l116, !tbaa !21
  store i1 %t264, ptr %l113, !tbaa !21
  br label %bb61
bb61:
  %t265 = load i1, ptr %l113, !tbaa !21
  br i1 %t265, label %bb62, label %bb63
bb62:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/free:Free", ptr %t266, i32 0, i32 76
  %t269 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t268, i64 %t269)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s1)
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_bdc560d7322c3213_e707f8f411fbb267)
  unreachable
bb71:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/free:Free", ptr %t272, i32 0, i32 94
  store ptr %t274, ptr %l121, !tbaa !29
  %t275 = ptrtoint ptr %v0 to i64
  store i64 %t275, ptr %l122, !tbaa !24
  %t276 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t276, label %bb72, label %bb73
bb72:
  %t278 = call ptr @__olang_region_make(ptr %v0)
  %t279 = ptrtoint ptr %t278 to i64
  store i64 %t279, ptr %l122, !tbaa !24
  br label %bb73
bb73:
  %t280 = load i64, ptr %l122
  %t281 = inttoptr i64 %t280 to ptr
  %t282 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t281, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t282, ptr %l124
  br label %bb74
bb74:
  %t283 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124
  %t284 = load i64, ptr %l122
  %t285 = inttoptr i64 %t284 to ptr
  %t286 = call ptr @__olang_scope_alloc_a(ptr %t285, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t283, ptr %t286
  %t287 = load ptr, ptr %l121, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t287, ptr %t286)
  br label %bb75
bb75:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/free:Free", ptr %t289, i32 0, i32 95
  store ptr %t291, ptr %l127, !tbaa !29
  %t292 = ptrtoint ptr %v0 to i64
  store i64 %t292, ptr %l128, !tbaa !24
  %t293 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t293, label %bb76, label %bb77
bb76:
  %t295 = call ptr @__olang_region_make(ptr %v0)
  %t296 = ptrtoint ptr %t295 to i64
  store i64 %t296, ptr %l128, !tbaa !24
  br label %bb77
bb77:
  %t297 = load i64, ptr %l128
  %t298 = inttoptr i64 %t297 to ptr
  %t299 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t298, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t299, ptr %l130
  br label %bb78
bb78:
  %t300 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l130
  %t301 = load i64, ptr %l128
  %t302 = inttoptr i64 %t301 to ptr
  %t303 = call ptr @__olang_scope_alloc_a(ptr %t302, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t300, ptr %t303
  %t304 = load ptr, ptr %l127, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t304, ptr %t303)
  br label %bb79
bb79:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/free:Free", ptr %t306, i32 0, i32 96
  store ptr %t308, ptr %l133, !tbaa !29
  %t309 = ptrtoint ptr %v0 to i64
  store i64 %t309, ptr %l134, !tbaa !24
  %t310 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_3e_26_3e_2e_2d1
  br i1 %t310, label %bb80, label %bb81
bb80:
  %t312 = call ptr @__olang_region_make(ptr %v0)
  %t313 = ptrtoint ptr %t312 to i64
  store i64 %t313, ptr %l134, !tbaa !24
  br label %bb81
bb81:
  %t314 = load i64, ptr %l134
  %t315 = inttoptr i64 %t314 to ptr
  %t316 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t315, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t316, ptr %l136
  br label %bb82
bb82:
  %t317 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l136
  %t318 = load i64, ptr %l134
  %t319 = inttoptr i64 %t318 to ptr
  %t320 = call ptr @__olang_scope_alloc_a(ptr %t319, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t317, ptr %t320
  %t321 = load ptr, ptr %l133, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_H788cd74f9c006611bc4bb459b5b22001(ptr %v0, ptr %v0, ptr %t321, ptr %t320)
  br label %bb83
bb83:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/free:Free", ptr %t323, i32 0, i32 97
  store ptr %t325, ptr %l139, !tbaa !29
  %t326 = ptrtoint ptr %v0 to i64
  store i64 %t326, ptr %l140, !tbaa !24
  %t327 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t327, label %bb84, label %bb85
bb84:
  %t329 = call ptr @__olang_region_make(ptr %v0)
  %t330 = ptrtoint ptr %t329 to i64
  store i64 %t330, ptr %l140, !tbaa !24
  br label %bb85
bb85:
  %t331 = load i64, ptr %l140
  %t332 = inttoptr i64 %t331 to ptr
  %t333 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t332, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t333, ptr %l142
  br label %bb86
bb86:
  %t334 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l142
  %t335 = load i64, ptr %l140
  %t336 = inttoptr i64 %t335 to ptr
  %t337 = call ptr @__olang_scope_alloc_a(ptr %t336, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t334, ptr %t337
  %t338 = load ptr, ptr %l139, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t338, ptr %t337)
  br label %bb87
bb87:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/free:Free", ptr %t340, i32 0, i32 79
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t342, i1 false)
  br label %bb88
bb88:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/free:Free", ptr %t344, i32 0, i32 80
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t346, i1 false)
  br label %bb89
bb89:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/free:Free", ptr %t348, i32 0, i32 98
  store ptr %t350, ptr %l149, !tbaa !29
  %t351 = ptrtoint ptr %v0 to i64
  store i64 %t351, ptr %l150, !tbaa !24
  %t352 = load i1, ptr @olang_2esole_2eArray_3cArray_3cI64_3e_26_3e_2e_2d1
  br i1 %t352, label %bb90, label %bb91
bb90:
  %t354 = call ptr @__olang_region_make(ptr %v0)
  %t355 = ptrtoint ptr %t354 to i64
  store i64 %t355, ptr %l150, !tbaa !24
  br label %bb91
bb91:
  %t356 = icmp sge i64 0, 0
  br i1 %t356, label %bb92, label %bb93
bb92:
  %t358 = icmp sle i64 0, 1152921504606846975
  br i1 %t358, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @olang_loc_72902bac739aff89_2513c2e385693c05)
  unreachable
bb94:
  %t360 = mul i64 0, 8
  %t361 = load i64, ptr %l150
  %t362 = inttoptr i64 %t361 to ptr
  %t363 = insertvalue { i64, ptr } undef, i64 0, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t365 = load ptr, ptr %l149, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t365, { i64, ptr } %t364)
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_72902bac739aff89_2513c2e385693c05)
  unreachable
bb96:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/free:Free", ptr %t367, i32 0, i32 99
  store ptr %t369, ptr %l156, !tbaa !29
  %t370 = ptrtoint ptr %v0 to i64
  store i64 %t370, ptr %l157, !tbaa !24
  %t371 = load i1, ptr @olang_2esole_2eArray_3cArray_3cI64_3e_26_3e_2e_2d1
  br i1 %t371, label %bb97, label %bb98
bb97:
  %t373 = call ptr @__olang_region_make(ptr %v0)
  %t374 = ptrtoint ptr %t373 to i64
  store i64 %t374, ptr %l157, !tbaa !24
  br label %bb98
bb98:
  %t375 = icmp sge i64 0, 0
  br i1 %t375, label %bb99, label %bb100
bb99:
  %t377 = icmp sle i64 0, 1152921504606846975
  br i1 %t377, label %bb101, label %bb102
bb100:
  call void @__olang_check_failed(ptr @olang_loc_3fc20153d7ed10ca_2c74aea1b5acbce6)
  unreachable
bb101:
  %t379 = mul i64 0, 8
  %t380 = load i64, ptr %l157
  %t381 = inttoptr i64 %t380 to ptr
  %t382 = insertvalue { i64, ptr } undef, i64 0, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t384 = load ptr, ptr %l156, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t384, { i64, ptr } %t383)
  br label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_3fc20153d7ed10ca_2c74aea1b5acbce6)
  unreachable
bb103:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/free:Free", ptr %t386, i32 0, i32 104
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t388, i1 false)
  br label %bb104
bb104:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2enoteDtor(ptr %v0, ptr %t390, i64 %t391)
  br label %bb105
bb105:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eanyMethod(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/generic:AnyTable"
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l21 = alloca i1
  %l25 = alloca i64
  %l28 = alloca ptr
  %l32 = alloca ptr
  %l34 = alloca ptr
  %l36 = alloca i32
  %l38 = alloca %"compiler/typed:Local"
  %l40 = alloca i32
  %l43 = alloca i1
  %l44 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca i32
  %l52 = alloca i64
  %l54 = alloca i64
  %l59 = alloca %"compiler/generic:AnyTable"
  %l62 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store ptr %t11, ptr %l13
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l13, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 5
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l15
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l17
  br label %bb3
bb3:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l3
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3)
  store i64 %t20, ptr %l19
  br label %bb4
bb4:
  %t21 = load i64, ptr %l19, !tbaa !24
  %t22 = icmp eq i64 %t21, 0
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb8
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/free:Free", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 61
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eLen_H9daf28210c013890fd7cb07d1d61ba6e(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l25
  br label %bb7
bb7:
  %t32 = load i64, ptr %l25, !tbaa !24
  %t33 = icmp eq i64 %t32, 0
  store i1 %t33, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l21, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  store ptr %t37, ptr %l28, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/free:Free", ptr %t38, i32 0, i32 1
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t40, i64 %t41)
  store ptr %t44, ptr %l32
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l32, !tbaa !29
  %t47 = getelementptr %"compiler/typed:Body", ptr %t45, i32 0, i32 7
  store ptr %t47, ptr %l34, !tbaa !29
  %t49 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s0, ptr %l3, i64 0)
  store i32 %t49, ptr %l36
  br label %bb13
bb13:
  %t50 = load i32, ptr %l36, !tbaa !23
  %t51 = sext i32 %t50 to i64
  %t52 = load ptr, ptr %l34, !tbaa !29
  %t54 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t52, i64 %t51)
  store %"compiler/typed:Local" %t54, ptr %l38
  br label %bb14
bb14:
  %t55 = getelementptr %"compiler/typed:Local", ptr %l38, i32 0, i32 2
  %t56 = load i32, ptr %t55, !tbaa !23
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t57, i32 %t56)
  store i32 %t59, ptr %l40
  br label %bb15
bb15:
  %t60 = load i32, ptr %l40, !tbaa !23
  store i32 %t60, ptr %l4, !tbaa !23
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t62 = load i32, ptr %l4, !tbaa !23
  %t65 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t61, i32 %t62)
  store i1 %t65, ptr %l43
  br label %bb16
bb16:
  %t66 = load i1, ptr %l43, !tbaa !21
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l2, !tbaa !29
  store ptr %t67, ptr %l44, !tbaa !29
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i32, ptr %l4, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l47
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t73 = load ptr, ptr %l44, !tbaa !29
  %t74 = load i32, ptr %l47, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t75, ptr %l48
  br label %bb20
bb20:
  %t76 = load i32, ptr %l48, !tbaa !23
  store i32 %t76, ptr %l4, !tbaa !23
  br label %bb21
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:Free", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 61
  store ptr %t82, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb22:
  %t84 = load i64, ptr %l6, !tbaa !24
  store i64 %t84, ptr %l52, !tbaa !24
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eLen_H9daf28210c013890fd7cb07d1d61ba6e(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l54
  br label %bb23
bb23:
  %t88 = load i64, ptr %l52, !tbaa !24
  %t89 = load i64, ptr %l54, !tbaa !24
  %t90 = icmp slt i64 %t88, %t89
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb24, label %bb25
bb24:
  br label %bb33
bb25:
  br label %bb26
bb26:
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = call %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v0, ptr %t94, i64 %t95)
  store %"compiler/generic:AnyTable" %t98, ptr %l59
  br label %bb27
bb27:
  %t99 = load %"compiler/generic:AnyTable", ptr %l59
  store %"compiler/generic:AnyTable" %t99, ptr %l7
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = getelementptr %"compiler/generic:AnyTable", ptr %l7, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t100, i32 %t102)
  store i32 %t105, ptr %l62
  br label %bb28
bb28:
  %t106 = load i32, ptr %l4, !tbaa !23
  %t107 = load i32, ptr %l62, !tbaa !23
  %t109 = icmp eq i32 %t107, %t106
  br i1 %t109, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t112 = load i64, ptr %l6, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l6, !tbaa !24
  br label %bb22
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t5, i32 %t4)
  store i1 %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l9
  br label %bb5
bb4:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l6, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1, %"compiler/free:letGo" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca %"compiler/free:letGo"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  store %"compiler/free:letGo" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = icmp ne i64 %t2, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = icmp slt i64 %t10, %t12
  store i1 %t15, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t17 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 3
  %t18 = getelementptr %"compiler/source:Span", ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18, !tbaa !23
  %t20 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 3
  %t21 = getelementptr %"compiler/source:Span", ptr %t20, i32 0, i32 0
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = icmp slt i32 %t19, %t22
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i64, ptr %l11, !tbaa !24
  %t22 = icmp slt i64 %t21, 0
  br i1 %t22, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s2, ptr %t24, i32 %t25)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l15
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4cef24e7d17769b7_e2744f91577a9953)
  unreachable
bb16:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = load i32, ptr %l16, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l19
  br label %bb9
bb9:
  %t32 = load i1, ptr %l19, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edtorCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i32
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l51 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l70 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l12
  br label %bb2
bb2:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb6
bb4:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l17
  br label %bb5
bb5:
  %t18 = load i1, ptr %l17, !tbaa !21
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l21
  br label %bb9
bb9:
  %t25 = load i1, ptr %l21, !tbaa !21
  store i1 %t25, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l23, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l26
  br label %bb14
bb14:
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t35 = load i32, ptr %l26, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l27
  br label %bb15
bb15:
  %t37 = load i32, ptr %l27, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l30
  br label %bb16
bb16:
  %t43 = load i32, ptr %l30, !range !{i32 0, i32 33}
  %t45 = trunc i64 18 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb20
bb18:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l37
  br label %bb19
bb19:
  %t55 = load i1, ptr %l37, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l34, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l34, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb25
bb22:
  %t59 = load ptr, ptr %l2, !tbaa !29
  store ptr %t59, ptr %l40, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l43
  br label %bb23
bb23:
  %t65 = load ptr, ptr %l40, !tbaa !29
  %t66 = load i32, ptr %l43, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t67, ptr %l44
  br label %bb24
bb24:
  %t68 = load i32, ptr %l44, !range !{i32 0, i32 6}
  %t70 = trunc i64 0 to i32
  %t71 = icmp eq i32 %t68, %t70
  %t73 = xor i1 %t71, true
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb25
bb25:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t81 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t77, i32 %t78)
  store i1 %t81, ptr %l51
  br label %bb29
bb29:
  %t82 = load i1, ptr %l51, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb30, label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l54, !tbaa !29
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t88 = load i32, ptr %l3, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l57
  br label %bb33
bb33:
  %t92 = load ptr, ptr %l54, !tbaa !29
  %t93 = load i32, ptr %l57, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t92, i32 %t93)
  store { i64, ptr } %t94, ptr %l58
  br label %bb34
bb34:
  %t95 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t95, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l6, !tbaa !24
  br label %bb35
bb35:
  %t100 = load i64, ptr %l5, !tbaa !24
  %t101 = load i64, ptr %l6, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb36, label %bb37
bb36:
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t108, ptr %l65, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i32, ptr %t112, i64 %t109
  %t114 = load i32, ptr %t113, !tbaa !33
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t120 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t116, i32 %t114)
  store i1 %t120, ptr %l70
  br label %bb39
bb39:
  %t121 = load i1, ptr %l70, !tbaa !21
  %t122 = xor i1 %t121, true
  br i1 %t122, label %bb40, label %bb41
bb40:
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t125 = load i64, ptr %l5, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l5, !tbaa !24
  br label %bb35
bb44:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb8
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l23
  br label %bb5
bb5:
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s1, ptr %t44, i64 %t45)
  store ptr %t46, ptr %l24
  br label %bb6
bb6:
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Func", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %t49, !tbaa !23
  %t51 = load ptr, ptr %l17, !tbaa !29
  %t53 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s1, ptr %t51, i32 %t50)
  store { i64, ptr } %t53, ptr %l27
  br label %bb7
bb7:
  %t54 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t61, ptr %l10, !tbaa !27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_947cc6b8bd079717_9e266d1a8b9c5cdb)
  unreachable
bb13:
  %t63 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l31, !tbaa !24
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l32, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l31, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t76, ptr %l10, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenAcross(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca ptr
  %l62 = alloca i1
  %l65 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l74 = alloca ptr
  %l79 = alloca i64
  %l82 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l90 = alloca ptr
  %l92 = alloca i64
  %l96 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l103 = alloca i32
  %l105 = alloca i1
  %l114 = alloca i64
  %l118 = alloca i64
  %l121 = alloca i64
  %l142 = alloca i64
  %l146 = alloca i64
  %l149 = alloca i1
  %l153 = alloca i1
  %l157 = alloca i1
  %l158 = alloca i1
  %l162 = alloca ptr
  %l169 = alloca i1
  %l174 = alloca i64
  %l177 = alloca i64
  %l179 = alloca i64
  %l184 = alloca i64
  %l187 = alloca i64
  %l191 = alloca i64
  %l196 = alloca i64
  %l199 = alloca i64
  %l220 = alloca i64
  %l228 = alloca ptr
  %l232 = alloca i64
  %l233 = alloca i64
  %l240 = alloca i1
  %l244 = alloca ptr
  %l248 = alloca ptr
  %l249 = alloca i64
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load i64, ptr %l26, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l34, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l34, !tbaa !24
  store i64 %t35, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l31, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb40
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/free:Free", ptr %t55, i32 0, i32 36
  store ptr %t57, ptr %l53, !tbaa !29
  %t58 = ptrtoint ptr %v0 to i64
  store i64 %t58, ptr %l54, !tbaa !24
  %t59 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t61 = call ptr @__olang_region_make(ptr %v0)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l54, !tbaa !24
  br label %bb13
bb13:
  %t63 = load i64, ptr %l54
  %t64 = inttoptr i64 %t63 to ptr
  %t65 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t64, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l56
  br label %bb14
bb14:
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  %t67 = load i64, ptr %l54
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = call ptr @__olang_scope_alloc_a(ptr %t68, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %t69
  %t70 = load ptr, ptr %l53, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t70, ptr %t69)
  br label %bb15
bb15:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/free:Free", ptr %t72, i32 0, i32 37
  store ptr %t74, ptr %l59, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehiddenCalls(ptr %v0, ptr %t75, i64 %t76)
  store i1 %t79, ptr %l62
  br label %bb16
bb16:
  %t80 = load ptr, ptr %l59, !tbaa !29
  %t81 = load i1, ptr %l62, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t80, i1 %t81)
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/free:Free", ptr %t82, i32 0, i32 116
  %t85 = load i1, ptr %t84, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 37
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t93, ptr %l69
  br label %bb20
bb19:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb21
bb20:
  %t94 = load i1, ptr %l69, !tbaa !21
  store i1 %t94, ptr %l65, !tbaa !21
  br label %bb21
bb21:
  %t95 = load i1, ptr %l65, !tbaa !21
  br i1 %t95, label %bb22, label %bb23
bb22:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 1
  %t99 = load i64, ptr %l7, !tbaa !24
  %t102 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t98, i64 %t99)
  store ptr %t102, ptr %l74
  br label %bb24
bb23:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb25
bb24:
  %t103 = load ptr, ptr %l74, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Body", ptr %t103, i32 0, i32 11
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = icmp eq ptr %t106, null
  %t110 = xor i1 %t108, true
  store i1 %t110, ptr %l70, !tbaa !21
  br label %bb25
bb25:
  %t112 = load i1, ptr %l70, !tbaa !21
  br i1 %t112, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t113 = load i64, ptr %l7, !tbaa !24
  store i64 %t113, ptr %l79, !tbaa !24
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i64, ptr %l7, !tbaa !24
  %t118 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s3, ptr %t114, i64 %t115)
  store { i64, ptr } %t118, ptr %l82
  br label %bb28
bb27:
  br label %bb38
bb28:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/free:Free", ptr %t119, i32 0, i32 0
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 0
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/load:Loader", ptr %t125, i32 0, i32 4
  %t128 = load ptr, ptr %t127, !tbaa !29
  store ptr %t128, ptr %l86, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/free:Free", ptr %t129, i32 0, i32 1
  %t132 = load i64, ptr %l7, !tbaa !24
  %t135 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t131, i64 %t132)
  store ptr %t135, ptr %l90
  br label %bb29
bb29:
  %t136 = load ptr, ptr %l90, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Body", ptr %t136, i32 0, i32 3
  %t139 = load i64, ptr %t138, !tbaa !24
  store i64 %t139, ptr %l92, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/free:Free", ptr %t140, i32 0, i32 1
  %t143 = load i64, ptr %l7, !tbaa !24
  %t146 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t142, i64 %t143)
  store ptr %t146, ptr %l96
  br label %bb30
bb30:
  %t147 = load ptr, ptr %l96, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Body", ptr %t147, i32 0, i32 4
  %t150 = getelementptr %"compiler/source:Span", ptr %t149, i32 0, i32 0
  %t151 = load i32, ptr %t150, !tbaa !23
  %t153 = sext i32 %t151 to i64
  %t154 = load ptr, ptr %l86, !tbaa !29
  %t155 = load i64, ptr %l92, !tbaa !24
  %t157 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s3, ptr %t154, i64 %t155, i64 %t153)
  store { i64, ptr } %t157, ptr %l100
  br label %bb31
bb31:
  %t158 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t160 = load i64, ptr %l79, !tbaa !24
  %t161 = call i64 @__olang_fmt_i64(ptr null, i64 %t160)
  %t162 = add i64 %t159, %t161
  %t163 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t166 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = add i64 %t172, %t175
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t179 = add i64 %t176, %t178
  %t180 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t158, i64 %t159)
  %t181 = getelementptr i8, ptr %t180, i64 %t159
  %t182 = call i64 @__olang_fmt_i64(ptr %t181, i64 %t160)
  %t183 = getelementptr i8, ptr %t181, i64 %t161
  call void @olang_textcopy(ptr %t183, ptr %t163, i64 %t164)
  %t184 = getelementptr i8, ptr %t183, i64 %t164
  call void @olang_textcopy(ptr %t184, ptr %t167, i64 %t168)
  %t185 = getelementptr i8, ptr %t184, i64 %t168
  call void @olang_textcopy(ptr %t185, ptr %t170, i64 %t171)
  %t186 = getelementptr i8, ptr %t185, i64 %t171
  call void @olang_textcopy(ptr %t186, ptr %t174, i64 %t175)
  %t187 = getelementptr i8, ptr %t186, i64 %t175
  call void @olang_textcopy(ptr %t187, ptr %t177, i64 %t178)
  %t188 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t180, 1
  %t191 = extractvalue { i64, ptr } %t189, 0
  %t192 = extractvalue { i64, ptr } %t189, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  %t198 = call i32 @std_2fio_2ePutErr(ptr %s3, { i64, ptr } %t196)
  store i32 %t198, ptr %l103
  %t199 = icmp ne i32 %t198, 0
  br i1 %t199, label %bb33, label %ok.200, !prof !99
ok.200:
  br label %bb32
bb32:
  br label %bb37
bb33:
  %t201 = load i32, ptr %l103, !tbaa !23
  %t202 = ashr i32 %t201, 16
  %t204 = icmp eq i32 %t202, 1
  store i1 %t204, ptr %l105, !tbaa !21
  %t205 = load i32, ptr %l103, !tbaa !23
  %t206 = ashr i32 %t205, 16
  %t208 = icmp eq i32 %t206, 1
  br i1 %t208, label %bb34, label %bb35
bb34:
  call void @__olang_errpay_pop()
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t210 = load i64, ptr %l6, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l6, !tbaa !24
  br label %bb8
bb40:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb41
bb41:
  %t214 = load i1, ptr %l8, !tbaa !21
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb42, label %bb43
bb42:
  br label %bb120
bb43:
  br label %bb44
bb44:
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/free:Free", ptr %t218, i32 0, i32 29
  %t222 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t220)
  store i64 %t222, ptr %l114
  br label %bb45
bb45:
  %t223 = load i64, ptr %l114, !tbaa !24
  store i64 %t223, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t224 = load i64, ptr %l10, !tbaa !24
  %t225 = load i64, ptr %l9, !tbaa !24
  %t228 = icmp sgt i64 %t224, %t225
  br i1 %t228, label %bb46, label %bb47
bb46:
  %t230 = load i64, ptr %l11, !tbaa !24
  %t232 = icmp sgt i64 %t230, 0
  br i1 %t232, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb51
bb48:
  %t234 = load i64, ptr %l10, !tbaa !24
  %t235 = load i64, ptr %l9, !tbaa !24
  %t238 = sub i64 %t234, %t235
  %t239 = load i64, ptr %l11, !tbaa !24
  %t242 = add i64 %t238, %t239
  %t244 = sub i64 %t242, 1
  %t245 = load i64, ptr %l11, !tbaa !24
  %t248 = sdiv i64 %t244, %t245
  store i64 %t248, ptr %l121, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb50
bb50:
  %t250 = load i64, ptr %l121, !tbaa !24
  store i64 %t250, ptr %l118, !tbaa !24
  br label %bb51
bb51:
  %t251 = load i64, ptr %l118, !tbaa !24
  store i64 %t251, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb52
bb52:
  %t252 = load i64, ptr %l13, !tbaa !24
  %t253 = load i64, ptr %l12, !tbaa !24
  %t256 = icmp slt i64 %t252, %t253
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb53, label %bb54
bb53:
  br label %bb118
bb54:
  br label %bb55
bb55:
  %t260 = load i64, ptr %l9, !tbaa !24
  %t261 = load i64, ptr %l13, !tbaa !24
  %t262 = load i64, ptr %l11, !tbaa !24
  %t265 = mul i64 %t261, %t262
  %t268 = add i64 %t260, %t265
  store i64 %t268, ptr %l14, !tbaa !24
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/free:Free", ptr %t270, i32 0, i32 29
  %t273 = load i64, ptr %l14, !tbaa !24
  %t276 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t272, i64 %t273)
  store i64 %t276, ptr %l142
  br label %bb56
bb56:
  %t277 = load i64, ptr %l142, !tbaa !24
  store i64 %t277, ptr %l15, !tbaa !24
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/free:Free", ptr %t278, i32 0, i32 30
  %t281 = load i64, ptr %l14, !tbaa !24
  %t284 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t280, i64 %t281)
  store i64 %t284, ptr %l146
  br label %bb57
bb57:
  %t285 = load i64, ptr %l146, !tbaa !24
  store i64 %t285, ptr %l16, !tbaa !24
  %t286 = load i64, ptr %l16, !tbaa !24
  %t288 = icmp slt i64 %t286, 0
  br i1 %t288, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l149, !tbaa !21
  br label %bb60
bb59:
  %t290 = load i64, ptr %l16, !tbaa !24
  %t291 = load i64, ptr %l1, !tbaa !24
  %t294 = icmp sge i64 %t290, %t291
  store i1 %t294, ptr %l149, !tbaa !21
  br label %bb60
bb60:
  %t296 = load i1, ptr %l149, !tbaa !21
  br i1 %t296, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb64
bb62:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/free:Free", ptr %t297, i32 0, i32 37
  %t300 = load i64, ptr %l16, !tbaa !24
  %t303 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t299, i64 %t300)
  store i1 %t303, ptr %l157
  br label %bb63
bb63:
  %t304 = load i1, ptr %l157, !tbaa !21
  store i1 %t304, ptr %l153, !tbaa !21
  br label %bb64
bb64:
  %t305 = load i1, ptr %l153, !tbaa !21
  br i1 %t305, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l158, !tbaa !21
  br label %bb68
bb66:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/free:Free", ptr %t306, i32 0, i32 1
  %t309 = load i64, ptr %l15, !tbaa !24
  %t312 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t308, i64 %t309)
  store ptr %t312, ptr %l162
  br label %bb67
bb67:
  %t313 = load ptr, ptr %l162, !tbaa !29
  %t315 = getelementptr %"compiler/typed:Body", ptr %t313, i32 0, i32 1
  %t316 = load { i64, [2 x i64] }, ptr %t315
  %t318 = extractvalue { i64, [2 x i64] } %t316, 0
  %t319 = icmp eq i64 %t318, 7
  store i1 %t319, ptr %l158, !tbaa !21
  br label %bb68
bb68:
  %t321 = load i1, ptr %l158, !tbaa !21
  br i1 %t321, label %bb69, label %bb70
bb69:
  br label %bb117
bb70:
  br label %bb71
bb71:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/free:Free", ptr %t322, i32 0, i32 37
  %t325 = load i64, ptr %l15, !tbaa !24
  %t328 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t324, i64 %t325)
  store i1 %t328, ptr %l169
  br label %bb72
bb72:
  %t329 = load i1, ptr %l169, !tbaa !21
  br i1 %t329, label %bb73, label %bb74
bb73:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/free:Free", ptr %t330, i32 0, i32 37
  %t333 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t332, i64 %t333, i1 true)
  br label %bb75
bb74:
  br label %bb76
bb75:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb117
bb76:
  %t336 = load i64, ptr %l14, !tbaa !24
  %t338 = add i64 %t336, 1
  store i64 %t338, ptr %l174, !tbaa !24
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/free:Free", ptr %t339, i32 0, i32 33
  %t343 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t341)
  store i64 %t343, ptr %l177
  br label %bb77
bb77:
  %t344 = load i64, ptr %l174, !tbaa !24
  %t345 = load i64, ptr %l177, !tbaa !24
  %t346 = icmp slt i64 %t344, %t345
  br i1 %t346, label %bb78, label %bb79
bb78:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/free:Free", ptr %t348, i32 0, i32 33
  %t351 = load i64, ptr %l14, !tbaa !24
  %t353 = add i64 %t351, 1
  %t356 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t350, i64 %t353)
  store i64 %t356, ptr %l184
  br label %bb80
bb79:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/free:Free", ptr %t357, i32 0, i32 34
  %t361 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t359)
  store i64 %t361, ptr %l187
  br label %bb81
bb80:
  %t362 = load i64, ptr %l184, !tbaa !24
  store i64 %t362, ptr %l179, !tbaa !24
  br label %bb82
bb81:
  %t363 = load i64, ptr %l187, !tbaa !24
  store i64 %t363, ptr %l179, !tbaa !24
  br label %bb82
bb82:
  %t364 = load i64, ptr %l179, !tbaa !24
  store i64 %t364, ptr %l17, !tbaa !24
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/free:Free", ptr %t365, i32 0, i32 33
  %t368 = load i64, ptr %l14, !tbaa !24
  %t371 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t367, i64 %t368)
  store i64 %t371, ptr %l191
  br label %bb83
bb83:
  %t372 = load i64, ptr %l191, !tbaa !24
  store i64 %t372, ptr %l18, !tbaa !24
  %t373 = load i64, ptr %l17, !tbaa !24
  store i64 %t373, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t375 = load i64, ptr %l19, !tbaa !24
  %t376 = load i64, ptr %l18, !tbaa !24
  %t379 = icmp sgt i64 %t375, %t376
  br i1 %t379, label %bb84, label %bb85
bb84:
  %t381 = load i64, ptr %l20, !tbaa !24
  %t383 = icmp sgt i64 %t381, 0
  br i1 %t383, label %bb86, label %bb87
bb85:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb89
bb86:
  %t385 = load i64, ptr %l19, !tbaa !24
  %t386 = load i64, ptr %l18, !tbaa !24
  %t389 = sub i64 %t385, %t386
  %t390 = load i64, ptr %l20, !tbaa !24
  %t393 = add i64 %t389, %t390
  %t395 = sub i64 %t393, 1
  %t396 = load i64, ptr %l20, !tbaa !24
  %t399 = sdiv i64 %t395, %t396
  store i64 %t399, ptr %l199, !tbaa !24
  br label %bb88
bb87:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb88
bb88:
  %t401 = load i64, ptr %l199, !tbaa !24
  store i64 %t401, ptr %l196, !tbaa !24
  br label %bb89
bb89:
  %t402 = load i64, ptr %l196, !tbaa !24
  store i64 %t402, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb90
bb90:
  %t403 = load i64, ptr %l22, !tbaa !24
  %t404 = load i64, ptr %l21, !tbaa !24
  %t407 = icmp slt i64 %t403, %t404
  %t409 = xor i1 %t407, true
  br i1 %t409, label %bb91, label %bb92
bb91:
  br label %bb106
bb92:
  br label %bb93
bb93:
  %t411 = load i64, ptr %l18, !tbaa !24
  %t412 = load i64, ptr %l22, !tbaa !24
  %t413 = load i64, ptr %l20, !tbaa !24
  %t416 = mul i64 %t412, %t413
  %t419 = add i64 %t411, %t416
  store i64 %t419, ptr %l23, !tbaa !24
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/free:Free", ptr %t421, i32 0, i32 34
  %t424 = load i64, ptr %l23, !tbaa !24
  %t427 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t423, i64 %t424)
  store i64 %t427, ptr %l220
  br label %bb94
bb94:
  %t428 = load i64, ptr %l220, !tbaa !24
  %t429 = icmp eq i64 %t428, -1
  br i1 %t429, label %bb95, label %bb96
bb95:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/free:Free", ptr %t431, i32 0, i32 37
  %t434 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t433, i64 %t434, i1 true)
  br label %bb97
bb96:
  br label %bb98
bb97:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb106
bb98:
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/free:Free", ptr %t437, i32 0, i32 36
  %t440 = load i64, ptr %l16, !tbaa !24
  %t443 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t439, i64 %t440)
  store ptr %t443, ptr %l228
  br label %bb99
bb99:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/free:Free", ptr %t444, i32 0, i32 34
  %t447 = load i64, ptr %l23, !tbaa !24
  %t450 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t446, i64 %t447)
  store i64 %t450, ptr %l232
  br label %bb100
bb100:
  %t451 = load ptr, ptr %l228, !tbaa !29
  %t452 = load i64, ptr %l232, !tbaa !24
  %t453 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t451, i64 %t452)
  store i64 %t453, ptr %l233
  br label %bb101
bb101:
  %t454 = load i64, ptr %l233, !tbaa !24
  %t455 = icmp sgt i64 %t454, 0
  br i1 %t455, label %bb102, label %bb103
bb102:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb104
bb103:
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t457 = load i64, ptr %l22, !tbaa !24
  %t459 = add i64 %t457, 1
  store i64 %t459, ptr %l22, !tbaa !24
  br label %bb90
bb106:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/free:Free", ptr %t461, i32 0, i32 37
  %t464 = load i64, ptr %l16, !tbaa !24
  %t467 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t463, i64 %t464)
  store i1 %t467, ptr %l240
  br label %bb107
bb107:
  %t468 = load i1, ptr %l240, !tbaa !21
  br i1 %t468, label %bb108, label %bb109
bb108:
  br label %bb117
bb109:
  br label %bb110
bb110:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/free:Free", ptr %t469, i32 0, i32 36
  %t472 = load i64, ptr %l16, !tbaa !24
  %t475 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t471, i64 %t472)
  store ptr %t475, ptr %l244
  br label %bb111
bb111:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = getelementptr %"compiler/free:Free", ptr %t476, i32 0, i32 36
  %t479 = load i64, ptr %l15, !tbaa !24
  %t482 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t478, i64 %t479)
  store ptr %t482, ptr %l248
  br label %bb112
bb112:
  %t483 = load ptr, ptr %l244, !tbaa !29
  %t484 = load ptr, ptr %l248, !tbaa !29
  %t485 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v0, ptr %t483, ptr %t484)
  store i64 %t485, ptr %l249
  br label %bb113
bb113:
  %t486 = load i64, ptr %l249, !tbaa !24
  %t487 = icmp sgt i64 %t486, 0
  br i1 %t487, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb116
bb115:
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t489 = load i64, ptr %l13, !tbaa !24
  %t491 = add i64 %t489, 1
  store i64 %t491, ptr %l13, !tbaa !24
  br label %bb52
bb118:
  br label %bb119
bb119:
  br label %bb41
bb120:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNeverText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l38 = alloca i1
  %l42 = alloca i32
  %l46 = alloca i1
  %l50 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 39
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb26
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l1, !tbaa !24
  %t55 = icmp eq i64 %t53, -1
  br i1 %t55, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb15
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:Free", ptr %t57, i32 0, i32 39
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t59, i64 %t60)
  store i32 %t63, ptr %l42
  br label %bb14
bb14:
  %t64 = load i32, ptr %l42, !tbaa !23
  %t65 = sext i32 %t64 to i64
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = icmp eq i64 %t65, %t66
  store i1 %t69, ptr %l38, !tbaa !21
  br label %bb15
bb15:
  %t71 = load i1, ptr %l38, !tbaa !21
  br i1 %t71, label %bb16, label %bb17
bb16:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/free:Free", ptr %t72, i32 0, i32 40
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t74, i64 %t75)
  store i1 %t78, ptr %l50
  br label %bb18
bb17:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb19
bb18:
  %t79 = load i1, ptr %l50, !tbaa !21
  store i1 %t79, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t80 = load i1, ptr %l46, !tbaa !21
  br i1 %t80, label %bb20, label %bb21
bb20:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:Free", ptr %t81, i32 0, i32 40
  %t84 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t83, i64 %t84, i1 false)
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 41
  %t90 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v0, ptr %v1, ptr %t89, i64 %t90, { i64, ptr } %a2)
  br label %bb23
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l7, !tbaa !24
  br label %bb8
bb26:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenRows(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l31 = alloca %"std/prelude/text:StringBuilder"
  %l33 = alloca ptr
  %l36 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca i32
  %l70 = alloca i32
  %l72 = alloca { i64, ptr }
  %l76 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l99 = alloca i64
  %l103 = alloca i64
  %l106 = alloca i64
  %l127 = alloca i64
  %l131 = alloca i64
  %l135 = alloca i1
  %l137 = alloca i1
  %l140 = alloca i1
  %l144 = alloca i1
  %l146 = alloca i64
  %l149 = alloca i64
  %l151 = alloca i64
  %l156 = alloca i64
  %l159 = alloca i64
  %l163 = alloca i64
  %l168 = alloca i64
  %l171 = alloca i64
  %l192 = alloca i64
  %l195 = alloca i64
  %l198 = alloca i1
  %l202 = alloca i1
  %l204 = alloca i1
  %l207 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l210 = alloca i1
  %l213 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l219 = alloca i32
  %l220 = alloca i32
  %l221 = alloca i32
  %l223 = alloca { i64, ptr }
  %l224 = alloca ptr
  %l228 = alloca i64
  %l229 = alloca ptr
  %l233 = alloca i64
  %l237 = alloca %"compiler/source:Span"
  %l240 = alloca i64
  %l241 = alloca { i64, ptr }
  %l243 = alloca ptr
  %l244 = alloca { i64, ptr }
  %l245 = alloca ptr
  %l249 = alloca i64
  %l253 = alloca %"compiler/source:Span"
  %l254 = alloca { i64, ptr }
  %l258 = alloca ptr
  %l259 = alloca ptr
  %l263 = alloca i64
  %l267 = alloca %"compiler/source:Span"
  %l270 = alloca { i64, ptr }
  %l271 = alloca ptr
  %l275 = alloca i64
  %l279 = alloca %"compiler/source:Span"
  %l280 = alloca { i64, ptr }
  %l290 = alloca ptr
  %l293 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l31
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l31
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t3)
  store ptr %t5, ptr %l33
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l33, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 39
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l36
  br label %bb3
bb3:
  %t12 = load i64, ptr %l36, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb9
bb6:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l43, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l43, !tbaa !24
  store i64 %t39, ptr %l40, !tbaa !24
  br label %bb9
bb9:
  %t40 = load i64, ptr %l40, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb12:
  br label %bb13
bb13:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/types:Table", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l62, !tbaa !29
  %t63 = load ptr, ptr %l2, !tbaa !29
  store ptr %t63, ptr %l63, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l64, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 39
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t67, i64 %t68)
  store i32 %t71, ptr %l68
  br label %bb14
bb14:
  %t72 = load ptr, ptr %l64, !tbaa !29
  %t73 = load i32, ptr %l68, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t74, ptr %l69
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l63, !tbaa !29
  %t76 = load i32, ptr %l69, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l70
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l62, !tbaa !29
  %t79 = call ptr @__olang_scope_of(ptr %t78, ptr null)
  %t80 = ptrtoint ptr %t79 to i64
  %t82 = inttoptr i64 %t80 to ptr
  %t83 = load ptr, ptr %l62, !tbaa !29
  %t84 = load i32, ptr %l70, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t82, ptr %s2, ptr %t83, i32 %t84)
  store { i64, ptr } %t85, ptr %l72
  br label %bb17
bb17:
  %t86 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t86, ptr %l9, !tbaa !27
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 40
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t93, ptr %l76
  br label %bb18
bb18:
  %t94 = load i1, ptr %l76, !tbaa !21
  br i1 %t94, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t95 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t96 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t99 = extractvalue { i64, ptr } %t95, 1
  %t100 = extractvalue { i64, ptr } %t95, 0
  %t101 = add i64 %t97, %t100
  %t102 = extractvalue { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t96, i64 %t97)
  %t106 = getelementptr i8, ptr %t105, i64 %t97
  call void @olang_textcopy(ptr %t106, ptr %t99, i64 %t100)
  %t107 = getelementptr i8, ptr %t106, i64 %t100
  call void @olang_textcopy(ptr %t107, ptr %t102, i64 %t103)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t105, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = extractvalue { i64, ptr } %t109, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } %t116)
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb22:
  store ptr %l1, ptr %l81, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t119, ptr %l82, !tbaa !27
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/free:Free", ptr %t120, i32 0, i32 41
  %t123 = load i64, ptr %l8, !tbaa !24
  %t126 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s2, ptr %t122, i64 %t123)
  store { i64, ptr } %t126, ptr %l86
  br label %bb23
bb23:
  %t127 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t129 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = add i64 %t128, %t131
  %t133 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t136 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = add i64 %t135, %t138
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t143 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t127, i64 %t128)
  %t144 = getelementptr i8, ptr %t143, i64 %t128
  call void @olang_textcopy(ptr %t144, ptr %t130, i64 %t131)
  %t145 = getelementptr i8, ptr %t144, i64 %t131
  call void @olang_textcopy(ptr %t145, ptr %t133, i64 %t134)
  %t146 = getelementptr i8, ptr %t145, i64 %t134
  call void @olang_textcopy(ptr %t146, ptr %t137, i64 %t138)
  %t147 = getelementptr i8, ptr %t146, i64 %t138
  call void @olang_textcopy(ptr %t147, ptr %t140, i64 %t141)
  %t148 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t143, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = extractvalue { i64, ptr } %t149, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t157 = load ptr, ptr %l81, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t157, { i64, ptr } %t156)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t159 = load i64, ptr %l7, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l7, !tbaa !24
  br label %bb10
bb26:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenLetsOf(ptr %v0, ptr %s0, ptr %t163)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t165, ptr %l92
  br label %bb27
bb27:
  %t166 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t166, ptr %l10
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/free:Free", ptr %t167, i32 0, i32 0
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 0
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/load:Loader", ptr %t173, i32 0, i32 4
  %t176 = load ptr, ptr %t175, !tbaa !29
  store ptr %t176, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/free:Free", ptr %t178, i32 0, i32 29
  %t182 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t180)
  store i64 %t182, ptr %l99
  br label %bb28
bb28:
  %t183 = load i64, ptr %l99, !tbaa !24
  store i64 %t183, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t184 = load i64, ptr %l13, !tbaa !24
  %t185 = load i64, ptr %l12, !tbaa !24
  %t188 = icmp sgt i64 %t184, %t185
  br i1 %t188, label %bb29, label %bb30
bb29:
  %t190 = load i64, ptr %l14, !tbaa !24
  %t192 = icmp sgt i64 %t190, 0
  br i1 %t192, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb34
bb31:
  %t194 = load i64, ptr %l13, !tbaa !24
  %t195 = load i64, ptr %l12, !tbaa !24
  %t198 = sub i64 %t194, %t195
  %t199 = load i64, ptr %l14, !tbaa !24
  %t202 = add i64 %t198, %t199
  %t204 = sub i64 %t202, 1
  %t205 = load i64, ptr %l14, !tbaa !24
  %t208 = sdiv i64 %t204, %t205
  store i64 %t208, ptr %l106, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb33
bb33:
  %t210 = load i64, ptr %l106, !tbaa !24
  store i64 %t210, ptr %l103, !tbaa !24
  br label %bb34
bb34:
  %t211 = load i64, ptr %l103, !tbaa !24
  store i64 %t211, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb35
bb35:
  %t212 = load i64, ptr %l16, !tbaa !24
  %t213 = load i64, ptr %l15, !tbaa !24
  %t216 = icmp slt i64 %t212, %t213
  %t218 = xor i1 %t216, true
  br i1 %t218, label %bb36, label %bb37
bb36:
  br label %bb106
bb37:
  br label %bb38
bb38:
  %t220 = load i64, ptr %l12, !tbaa !24
  %t221 = load i64, ptr %l16, !tbaa !24
  %t222 = load i64, ptr %l14, !tbaa !24
  %t225 = mul i64 %t221, %t222
  %t228 = add i64 %t220, %t225
  store i64 %t228, ptr %l17, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/free:Free", ptr %t230, i32 0, i32 29
  %t233 = load i64, ptr %l17, !tbaa !24
  %t236 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t232, i64 %t233)
  store i64 %t236, ptr %l127
  br label %bb39
bb39:
  %t237 = load i64, ptr %l127, !tbaa !24
  store i64 %t237, ptr %l18, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/free:Free", ptr %t238, i32 0, i32 30
  %t241 = load i64, ptr %l17, !tbaa !24
  %t244 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t240, i64 %t241)
  store i64 %t244, ptr %l131
  br label %bb40
bb40:
  %t245 = load i64, ptr %l131, !tbaa !24
  store i64 %t245, ptr %l19, !tbaa !24
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/free:Free", ptr %t246, i32 0, i32 23
  %t249 = load i64, ptr %l18, !tbaa !24
  %t252 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t248, i64 %t249)
  store i1 %t252, ptr %l135
  br label %bb41
bb41:
  %t253 = load i1, ptr %l135, !tbaa !21
  %t254 = xor i1 %t253, true
  br i1 %t254, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb44
bb43:
  %t256 = load i64, ptr %l19, !tbaa !24
  %t258 = icmp slt i64 %t256, 0
  store i1 %t258, ptr %l137, !tbaa !21
  br label %bb44
bb44:
  %t260 = load i1, ptr %l137, !tbaa !21
  br i1 %t260, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb48
bb46:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/free:Free", ptr %t261, i32 0, i32 37
  %t264 = load i64, ptr %l18, !tbaa !24
  %t267 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t263, i64 %t264)
  store i1 %t267, ptr %l144
  br label %bb47
bb47:
  %t268 = load i1, ptr %l144, !tbaa !21
  store i1 %t268, ptr %l140, !tbaa !21
  br label %bb48
bb48:
  %t269 = load i1, ptr %l140, !tbaa !21
  br i1 %t269, label %bb49, label %bb50
bb49:
  br label %bb105
bb50:
  br label %bb51
bb51:
  %t270 = load i64, ptr %l17, !tbaa !24
  %t272 = add i64 %t270, 1
  store i64 %t272, ptr %l146, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/free:Free", ptr %t273, i32 0, i32 33
  %t277 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t275)
  store i64 %t277, ptr %l149
  br label %bb52
bb52:
  %t278 = load i64, ptr %l146, !tbaa !24
  %t279 = load i64, ptr %l149, !tbaa !24
  %t280 = icmp slt i64 %t278, %t279
  br i1 %t280, label %bb53, label %bb54
bb53:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/free:Free", ptr %t282, i32 0, i32 33
  %t285 = load i64, ptr %l17, !tbaa !24
  %t287 = add i64 %t285, 1
  %t290 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t284, i64 %t287)
  store i64 %t290, ptr %l156
  br label %bb55
bb54:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/free:Free", ptr %t291, i32 0, i32 34
  %t295 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t293)
  store i64 %t295, ptr %l159
  br label %bb56
bb55:
  %t296 = load i64, ptr %l156, !tbaa !24
  store i64 %t296, ptr %l151, !tbaa !24
  br label %bb57
bb56:
  %t297 = load i64, ptr %l159, !tbaa !24
  store i64 %t297, ptr %l151, !tbaa !24
  br label %bb57
bb57:
  %t298 = load i64, ptr %l151, !tbaa !24
  store i64 %t298, ptr %l20, !tbaa !24
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/free:Free", ptr %t299, i32 0, i32 33
  %t302 = load i64, ptr %l17, !tbaa !24
  %t305 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t301, i64 %t302)
  store i64 %t305, ptr %l163
  br label %bb58
bb58:
  %t306 = load i64, ptr %l163, !tbaa !24
  store i64 %t306, ptr %l21, !tbaa !24
  %t307 = load i64, ptr %l20, !tbaa !24
  store i64 %t307, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t309 = load i64, ptr %l22, !tbaa !24
  %t310 = load i64, ptr %l21, !tbaa !24
  %t313 = icmp sgt i64 %t309, %t310
  br i1 %t313, label %bb59, label %bb60
bb59:
  %t315 = load i64, ptr %l23, !tbaa !24
  %t317 = icmp sgt i64 %t315, 0
  br i1 %t317, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l168, !tbaa !24
  br label %bb64
bb61:
  %t319 = load i64, ptr %l22, !tbaa !24
  %t320 = load i64, ptr %l21, !tbaa !24
  %t323 = sub i64 %t319, %t320
  %t324 = load i64, ptr %l23, !tbaa !24
  %t327 = add i64 %t323, %t324
  %t329 = sub i64 %t327, 1
  %t330 = load i64, ptr %l23, !tbaa !24
  %t333 = sdiv i64 %t329, %t330
  store i64 %t333, ptr %l171, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l171, !tbaa !24
  br label %bb63
bb63:
  %t335 = load i64, ptr %l171, !tbaa !24
  store i64 %t335, ptr %l168, !tbaa !24
  br label %bb64
bb64:
  %t336 = load i64, ptr %l168, !tbaa !24
  store i64 %t336, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb65
bb65:
  store %olang.scope zeroinitializer, ptr %s11
  %t337 = load i64, ptr %l25, !tbaa !24
  %t338 = load i64, ptr %l24, !tbaa !24
  %t341 = icmp slt i64 %t337, %t338
  %t343 = xor i1 %t341, true
  br i1 %t343, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s11)
  br label %bb104
bb67:
  br label %bb68
bb68:
  %t345 = load i64, ptr %l21, !tbaa !24
  %t346 = load i64, ptr %l25, !tbaa !24
  %t347 = load i64, ptr %l23, !tbaa !24
  %t350 = mul i64 %t346, %t347
  %t353 = add i64 %t345, %t350
  store i64 %t353, ptr %l26, !tbaa !24
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/free:Free", ptr %t355, i32 0, i32 34
  %t358 = load i64, ptr %l26, !tbaa !24
  %t361 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t357, i64 %t358)
  store i64 %t361, ptr %l192
  br label %bb69
bb69:
  %t362 = load i64, ptr %l192, !tbaa !24
  store i64 %t362, ptr %l27, !tbaa !24
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load i64, ptr %l27, !tbaa !24
  %t367 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenIndex(ptr %v0, ptr %t363, i64 %t364)
  store i64 %t367, ptr %l195
  br label %bb70
bb70:
  %t368 = load i64, ptr %l195, !tbaa !24
  store i64 %t368, ptr %l28, !tbaa !24
  %t369 = load i64, ptr %l28, !tbaa !24
  %t371 = icmp slt i64 %t369, 0
  br i1 %t371, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l198, !tbaa !21
  br label %bb74
bb72:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/free:Free", ptr %t373, i32 0, i32 40
  %t376 = load i64, ptr %l28, !tbaa !24
  %t379 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t375, i64 %t376)
  store i1 %t379, ptr %l202
  br label %bb73
bb73:
  %t380 = load i1, ptr %l202, !tbaa !21
  %t381 = xor i1 %t380, true
  store i1 %t381, ptr %l198, !tbaa !21
  br label %bb74
bb74:
  %t383 = load i1, ptr %l198, !tbaa !21
  br i1 %t383, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l204, !tbaa !21
  br label %bb79
bb76:
  %t384 = load i64, ptr %l19, !tbaa !24
  %t387 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %l10, i64 %t384)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t387, ptr %l207
  br label %bb77
bb77:
  %t388 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l207
  %t389 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t388, ptr %t389
  %t390 = load i64, ptr %l27, !tbaa !24
  %t393 = call i1 @compiler_2ffree_2ehas(ptr %s0, ptr %t389, i64 %t390)
  store i1 %t393, ptr %l210
  br label %bb78
bb78:
  %t394 = load i1, ptr %l210, !tbaa !21
  %t395 = xor i1 %t394, true
  store i1 %t395, ptr %l204, !tbaa !21
  br label %bb79
bb79:
  %t397 = load i1, ptr %l204, !tbaa !21
  br i1 %t397, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb81:
  br label %bb82
bb82:
  %t398 = load ptr, ptr %l2, !tbaa !29
  %t400 = getelementptr %"compiler/types:Table", ptr %t398, i32 0, i32 0
  %t401 = load ptr, ptr %t400, !tbaa !29
  store ptr %t401, ptr %l213, !tbaa !29
  %t402 = load ptr, ptr %l2, !tbaa !29
  store ptr %t402, ptr %l214, !tbaa !29
  %t403 = load ptr, ptr %l2, !tbaa !29
  store ptr %t403, ptr %l215, !tbaa !29
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"compiler/free:Free", ptr %t404, i32 0, i32 39
  %t407 = load i64, ptr %l28, !tbaa !24
  %t410 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t406, i64 %t407)
  store i32 %t410, ptr %l219
  br label %bb83
bb83:
  %t411 = load ptr, ptr %l215, !tbaa !29
  %t412 = load i32, ptr %l219, !tbaa !23
  %t413 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t411, i32 %t412)
  store i32 %t413, ptr %l220
  br label %bb84
bb84:
  %t414 = load ptr, ptr %l214, !tbaa !29
  %t415 = load i32, ptr %l220, !tbaa !23
  %t416 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t414, i32 %t415)
  store i32 %t416, ptr %l221
  br label %bb85
bb85:
  %t417 = load ptr, ptr %l213, !tbaa !29
  %t418 = call ptr @__olang_scope_of(ptr %t417, ptr null)
  %t419 = ptrtoint ptr %t418 to i64
  %t421 = inttoptr i64 %t419 to ptr
  %t422 = load ptr, ptr %l213, !tbaa !29
  %t423 = load i32, ptr %l221, !tbaa !23
  %t424 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t421, ptr %s11, ptr %t422, i32 %t423)
  store { i64, ptr } %t424, ptr %l223
  br label %bb86
bb86:
  %t425 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t425, ptr %l29, !tbaa !27
  %t426 = load ptr, ptr %l11, !tbaa !29
  store ptr %t426, ptr %l224, !tbaa !29
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/free:Free", ptr %t427, i32 0, i32 31
  %t430 = load i64, ptr %l17, !tbaa !24
  %t433 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t429, i64 %t430)
  store i64 %t433, ptr %l228
  br label %bb87
bb87:
  %t434 = load ptr, ptr %l0, !tbaa !29
  store ptr %t434, ptr %l229, !tbaa !29
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/free:Free", ptr %t435, i32 0, i32 31
  %t438 = load i64, ptr %l17, !tbaa !24
  %t441 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t437, i64 %t438)
  store i64 %t441, ptr %l233
  br label %bb88
bb88:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/free:Free", ptr %t442, i32 0, i32 32
  %t445 = load i64, ptr %l17, !tbaa !24
  %t448 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t444, i64 %t445)
  store %"compiler/source:Span" %t448, ptr %l237
  br label %bb89
bb89:
  %t449 = getelementptr %"compiler/source:Span", ptr %l237, i32 0, i32 0
  %t450 = load i32, ptr %t449, !tbaa !23
  %t452 = sext i32 %t450 to i64
  %t453 = load ptr, ptr %l229, !tbaa !29
  %t454 = load i64, ptr %l233, !tbaa !24
  %t456 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elineStart(ptr %v0, ptr %t453, i64 %t454, i64 %t452)
  store i64 %t456, ptr %l240
  br label %bb90
bb90:
  %t457 = load ptr, ptr %l224, !tbaa !29
  %t458 = load i64, ptr %l228, !tbaa !24
  %t459 = load i64, ptr %l240, !tbaa !24
  %t460 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s11, ptr %t457, i64 %t458, i64 %t459)
  store { i64, ptr } %t460, ptr %l241
  br label %bb91
bb91:
  %t461 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t461, 1
  %t463 = extractvalue { i64, ptr } %t461, 0
  %t464 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t463)
  call void @olang_textcopy(ptr %t464, ptr %t462, i64 %t463)
  %t465 = insertvalue { i64, ptr } undef, i64 %t463, 0
  %t466 = insertvalue { i64, ptr } %t465, ptr %t464, 1
  store ptr %l1, ptr %l243, !tbaa !29
  store { i64, ptr } %t466, ptr %l244, !tbaa !27
  %t469 = load ptr, ptr %l0, !tbaa !29
  store ptr %t469, ptr %l245, !tbaa !29
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t472 = getelementptr %"compiler/free:Free", ptr %t470, i32 0, i32 31
  %t473 = load i64, ptr %l17, !tbaa !24
  %t476 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t472, i64 %t473)
  store i64 %t476, ptr %l249
  br label %bb92
bb92:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/free:Free", ptr %t477, i32 0, i32 32
  %t480 = load i64, ptr %l17, !tbaa !24
  %t483 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t479, i64 %t480)
  store %"compiler/source:Span" %t483, ptr %l253
  br label %bb93
bb93:
  %t484 = load ptr, ptr %l245, !tbaa !29
  %t485 = load i64, ptr %l249, !tbaa !24
  %t486 = load %"compiler/source:Span", ptr %l253
  %t487 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s11, ptr %t484, i64 %t485, %"compiler/source:Span" %t486)
  store { i64, ptr } %t487, ptr %l254
  br label %bb94
bb94:
  %t488 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t489 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t490 = extractvalue { i64, ptr } %t489, 1
  %t491 = extractvalue { i64, ptr } %t489, 0
  %t492 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t493 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t494 = add i64 %t491, %t493
  %t495 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t496 = extractvalue { i64, ptr } %t495, 1
  %t497 = extractvalue { i64, ptr } %t495, 0
  %t498 = add i64 %t494, %t497
  %t499 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t500 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t501 = add i64 %t498, %t500
  %t503 = extractvalue { i64, ptr } %t488, 1
  %t504 = extractvalue { i64, ptr } %t488, 0
  %t505 = add i64 %t501, %t504
  %t506 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t507 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t508 = add i64 %t505, %t507
  %t509 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t508)
  call void @olang_textcopy(ptr %t509, ptr %t490, i64 %t491)
  %t510 = getelementptr i8, ptr %t509, i64 %t491
  call void @olang_textcopy(ptr %t510, ptr %t492, i64 %t493)
  %t511 = getelementptr i8, ptr %t510, i64 %t493
  call void @olang_textcopy(ptr %t511, ptr %t496, i64 %t497)
  %t512 = getelementptr i8, ptr %t511, i64 %t497
  call void @olang_textcopy(ptr %t512, ptr %t499, i64 %t500)
  %t513 = getelementptr i8, ptr %t512, i64 %t500
  call void @olang_textcopy(ptr %t513, ptr %t503, i64 %t504)
  %t514 = getelementptr i8, ptr %t513, i64 %t504
  call void @olang_textcopy(ptr %t514, ptr %t506, i64 %t507)
  %t515 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t516 = insertvalue { i64, ptr } %t515, ptr %t509, 1
  %t518 = extractvalue { i64, ptr } %t516, 0
  %t519 = extractvalue { i64, ptr } %t516, 1
  %t520 = mul i64 %t518, 1
  %t521 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t520)
  call void @llvm.memcpy.p0.p0.i64(ptr %t521, ptr %t519, i64 %t520, i1 false)
  %t522 = insertvalue { i64, ptr } undef, i64 %t518, 0
  %t523 = insertvalue { i64, ptr } %t522, ptr %t521, 1
  %t524 = load ptr, ptr %l243, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t524, { i64, ptr } %t523)
  br label %bb95
bb95:
  store ptr %l1, ptr %l258, !tbaa !29
  %t526 = load ptr, ptr %l11, !tbaa !29
  store ptr %t526, ptr %l259, !tbaa !29
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr %"compiler/free:Free", ptr %t527, i32 0, i32 31
  %t530 = load i64, ptr %l17, !tbaa !24
  %t533 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t529, i64 %t530)
  store i64 %t533, ptr %l263
  br label %bb96
bb96:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t536 = getelementptr %"compiler/free:Free", ptr %t534, i32 0, i32 35
  %t537 = load i64, ptr %l26, !tbaa !24
  %t540 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t536, i64 %t537)
  store %"compiler/source:Span" %t540, ptr %l267
  br label %bb97
bb97:
  %t541 = getelementptr %"compiler/source:Span", ptr %l267, i32 0, i32 0
  %t542 = load i32, ptr %t541, !tbaa !23
  %t544 = sext i32 %t542 to i64
  %t545 = load ptr, ptr %l259, !tbaa !29
  %t546 = load i64, ptr %l263, !tbaa !24
  %t548 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s11, ptr %t545, i64 %t546, i64 %t544)
  store { i64, ptr } %t548, ptr %l270
  br label %bb98
bb98:
  %t549 = load ptr, ptr %l0, !tbaa !29
  store ptr %t549, ptr %l271, !tbaa !29
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t552 = getelementptr %"compiler/free:Free", ptr %t550, i32 0, i32 31
  %t553 = load i64, ptr %l17, !tbaa !24
  %t556 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t552, i64 %t553)
  store i64 %t556, ptr %l275
  br label %bb99
bb99:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t559 = getelementptr %"compiler/free:Free", ptr %t557, i32 0, i32 35
  %t560 = load i64, ptr %l26, !tbaa !24
  %t563 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t559, i64 %t560)
  store %"compiler/source:Span" %t563, ptr %l279
  br label %bb100
bb100:
  %t564 = load ptr, ptr %l271, !tbaa !29
  %t565 = load i64, ptr %l275, !tbaa !24
  %t566 = load %"compiler/source:Span", ptr %l279
  %t567 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s11, ptr %t564, i64 %t565, %"compiler/source:Span" %t566)
  store { i64, ptr } %t567, ptr %l280
  br label %bb101
bb101:
  %t568 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t569 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t570 = extractvalue { i64, ptr } %t569, 1
  %t571 = extractvalue { i64, ptr } %t569, 0
  %t572 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t573 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t574 = add i64 %t571, %t573
  %t575 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t576 = extractvalue { i64, ptr } %t575, 1
  %t577 = extractvalue { i64, ptr } %t575, 0
  %t578 = add i64 %t574, %t577
  %t579 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t580 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t581 = add i64 %t578, %t580
  %t583 = extractvalue { i64, ptr } %t568, 1
  %t584 = extractvalue { i64, ptr } %t568, 0
  %t585 = add i64 %t581, %t584
  %t586 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t587 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t588 = add i64 %t585, %t587
  %t589 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t588)
  call void @olang_textcopy(ptr %t589, ptr %t570, i64 %t571)
  %t590 = getelementptr i8, ptr %t589, i64 %t571
  call void @olang_textcopy(ptr %t590, ptr %t572, i64 %t573)
  %t591 = getelementptr i8, ptr %t590, i64 %t573
  call void @olang_textcopy(ptr %t591, ptr %t576, i64 %t577)
  %t592 = getelementptr i8, ptr %t591, i64 %t577
  call void @olang_textcopy(ptr %t592, ptr %t579, i64 %t580)
  %t593 = getelementptr i8, ptr %t592, i64 %t580
  call void @olang_textcopy(ptr %t593, ptr %t583, i64 %t584)
  %t594 = getelementptr i8, ptr %t593, i64 %t584
  call void @olang_textcopy(ptr %t594, ptr %t586, i64 %t587)
  %t595 = insertvalue { i64, ptr } undef, i64 %t588, 0
  %t596 = insertvalue { i64, ptr } %t595, ptr %t589, 1
  %t598 = extractvalue { i64, ptr } %t596, 0
  %t599 = extractvalue { i64, ptr } %t596, 1
  %t600 = mul i64 %t598, 1
  %t601 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t600)
  call void @llvm.memcpy.p0.p0.i64(ptr %t601, ptr %t599, i64 %t600, i1 false)
  %t602 = insertvalue { i64, ptr } undef, i64 %t598, 0
  %t603 = insertvalue { i64, ptr } %t602, ptr %t601, 1
  %t604 = load ptr, ptr %l258, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %t604, { i64, ptr } %t603)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb103:
  %t606 = load i64, ptr %l25, !tbaa !24
  %t608 = add i64 %t606, 1
  store i64 %t608, ptr %l25, !tbaa !24
  br label %bb65
bb104:
  br label %bb105
bb105:
  %t610 = load i64, ptr %l16, !tbaa !24
  %t612 = add i64 %t610, 1
  store i64 %t612, ptr %l16, !tbaa !24
  br label %bb35
bb106:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t616 = getelementptr %"compiler/free:Free", ptr %t614, i32 0, i32 46
  %t617 = load i1, ptr %t616, !tbaa !21
  br i1 %t617, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s18
  store ptr %l1, ptr %l290, !tbaa !29
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t622 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufRows(ptr %v0, ptr %s0, ptr %s18, ptr %t619, ptr %l10)
  store { i64, ptr } %t622, ptr %l293
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t623 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t624 = extractvalue { i64, ptr } %t623, 0
  %t625 = extractvalue { i64, ptr } %t623, 1
  %t626 = mul i64 %t624, 1
  %t627 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t626)
  call void @llvm.memcpy.p0.p0.i64(ptr %t627, ptr %t625, i64 %t626, i1 false)
  %t628 = insertvalue { i64, ptr } undef, i64 %t624, 0
  %t629 = insertvalue { i64, ptr } %t628, ptr %t627, 1
  %t630 = load ptr, ptr %l290, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %t630, { i64, ptr } %t629)
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s18)
  br label %bb111
bb111:
  %t633 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t633, ptr %l296
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s0)
  %t634 = load { i64, ptr }, ptr %l296, !tbaa !27
  store { i64, ptr } %t634, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %lp4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l33 = alloca i1
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca i32
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca i64
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca i32
  %l58 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca i1
  %l72 = alloca i1
  %l73 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca i32
  %l80 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca { i64, ptr }
  %l90 = alloca i64
  %l93 = alloca i64
  %l114 = alloca i64
  %l117 = alloca i1
  %l121 = alloca i1
  %l122 = alloca i1
  %l126 = alloca i1
  %l129 = alloca i64
  %l131 = alloca { i64, ptr }
  %l134 = alloca i1
  %l136 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l141 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l145 = alloca i64
  %l150 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l166 = alloca i1
  %l168 = alloca ptr
  %l171 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l175 = alloca i64
  %l180 = alloca i1
  %l183 = alloca ptr
  %l186 = alloca i32
  %l187 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l199 = alloca i1
  %l201 = alloca ptr
  %l204 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l206 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l208 = alloca i64
  %l212 = alloca ptr
  %l213 = alloca i32
  %l214 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l216 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l24
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l24, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l25, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l28
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l25, !tbaa !29
  %t12 = load i32, ptr %l28, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l29
  br label %bb3
bb3:
  %t14 = load i32, ptr %l29, !tbaa !23
  store i32 %t14, ptr %l3, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/free:Free", ptr %t15, i32 0, i32 20
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H0fa35282e56bd0cd9b08251ba99b9868(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l33
  br label %bb4
bb4:
  %t22 = load i1, ptr %l33, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:Free", ptr %t23, i32 0, i32 20
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H08f3244764437e29647226f03a29c83b(ptr %v0, ptr %v1, ptr %t25, i32 %t26)
  %t30 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t29, 1
  %t31 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t29, 0
  store i32 %t31, ptr %l39
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb8, label %ok.33, !prof !99
ok.33:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l38
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v1, ptr %l38)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l41
  br label %bb10
bb8:
  br label %bb9
bb9:
  %t36 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l42
  br label %bb11
bb10:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l34
  br label %bb12
bb11:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l34
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %rv
  br label %ret
bb13:
  %t40 = ptrtoint ptr %v1 to i64
  store i64 %t40, ptr %l43, !tbaa !24
  %t41 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2eheldPlaces_2elocal_2e4
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t43 = call ptr @__olang_region_make(ptr %v1)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l43, !tbaa !24
  br label %bb15
bb15:
  %t45 = load i64, ptr %l43
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t46, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l45
  br label %bb16
bb16:
  %t48 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2eheldPlaces_2elocal_2e4
  br i1 %t48, label %bb17, label %bb18
bb17:
  %t50 = load i64, ptr %l43
  %t51 = inttoptr i64 %t50 to ptr
  %t52 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45, i32 0, i32 0
  %t53 = load { i64, ptr }, ptr %t52
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = call ptr @__olang_region_or(ptr %t54, ptr null)
  %t56 = icmp ne ptr %t55, null
  %t57 = select i1 %t56, ptr %t55, ptr null
  %t58 = icmp eq ptr %t57, %t51
  call void @__olang_region_settle(ptr %t51, i1 %t58)
  br label %bb18
bb18:
  %t59 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t59, ptr %lp4
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  %t61 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t61
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/free:Free", ptr %t62, i32 0, i32 20
  store ptr %t64, ptr %l48, !tbaa !29
  %t65 = load i32, ptr %l3, !tbaa !23
  store i32 %t65, ptr %l49, !tbaa !23
  %t66 = load ptr, ptr %lp4
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t66
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l50
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l50)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l52
  br label %bb19
bb19:
  %t70 = load ptr, ptr %l48, !tbaa !29
  %t71 = load i32, ptr %l49, !tbaa !23
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H127fb385441fbfd25cd8404c6b268b5d(ptr %v0, ptr %s0, ptr %t70, i32 %t71, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72)
  br label %bb20
bb20:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t74 = load i32, ptr %l3, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l55
  br label %bb21
bb21:
  %t78 = load i32, ptr %l55, !range !{i32 0, i32 33}
  store i32 %t78, ptr %l5
  %t79 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t81 = trunc i64 19 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l58, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t86 = load i32, ptr %l3, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t89, ptr %l61
  br label %bb24
bb23:
  %t90 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t92 = trunc i64 18 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb29, label %bb30
bb24:
  %t95 = load ptr, ptr %l58, !tbaa !29
  %t96 = load i32, ptr %l61, !tbaa !23
  %t97 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v1, ptr %t95, i32 %t96)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l62
  br label %bb25
bb25:
  %t99 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v1, ptr %l62)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l64
  br label %bb26
bb26:
  %t100 = load ptr, ptr %lp4
  %t101 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t100
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t101, ptr %l65
  %t102 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  %t103 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %t103
  %t104 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2eheldPlaces_2elocal_2e4
  br i1 %t104, label %bb27, label %bb28
bb27:
  %t106 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65, i32 0, i32 0
  %t107 = load { i64, ptr }, ptr %t106
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = call ptr @__olang_region_or(ptr %t108, ptr null)
  %t110 = icmp ne ptr %t109, null
  %t111 = select i1 %t110, ptr %t109, ptr null
  call void @__olang_region_drop(ptr %t111)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l65
  br label %bb28
bb28:
  br label %bb114
bb29:
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t113 = load i32, ptr %l3, !tbaa !23
  %t116 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t112, i32 %t113)
  store i1 %t116, ptr %l72
  br label %bb31
bb30:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb32
bb31:
  %t117 = load i1, ptr %l72, !tbaa !21
  store i1 %t117, ptr %l69, !tbaa !21
  br label %bb32
bb32:
  %t118 = load i1, ptr %l69, !tbaa !21
  br i1 %t118, label %bb33, label %bb34
bb33:
  %t119 = load ptr, ptr %l2, !tbaa !29
  store ptr %t119, ptr %l73, !tbaa !29
  %t120 = load ptr, ptr %l2, !tbaa !29
  %t121 = load i32, ptr %l3, !tbaa !23
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t120, i32 %t121)
  store i32 %t124, ptr %l76
  br label %bb35
bb34:
  %t125 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t127 = trunc i64 23 to i32
  %t128 = icmp eq i32 %t125, %t127
  br i1 %t128, label %bb92, label %bb93
bb35:
  %t130 = load ptr, ptr %l73, !tbaa !29
  %t131 = load i32, ptr %l76, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t130, i32 %t131)
  store i32 %t132, ptr %l77
  br label %bb36
bb36:
  %t133 = load i32, ptr %l77, !range !{i32 0, i32 6}
  store i32 %t133, ptr %l6
  %t134 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t136 = trunc i64 0 to i32
  %t137 = icmp eq i32 %t134, %t136
  br i1 %t137, label %bb37, label %bb38
bb37:
  %t139 = load ptr, ptr %l2, !tbaa !29
  store ptr %t139, ptr %l80, !tbaa !29
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t141 = load i32, ptr %l3, !tbaa !23
  %t144 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t140, i32 %t141)
  store i32 %t144, ptr %l83
  br label %bb39
bb38:
  %t145 = load i32, ptr %l6, !range !{i32 0, i32 6}
  %t147 = trunc i64 1 to i32
  %t148 = icmp eq i32 %t145, %t147
  br i1 %t148, label %bb73, label %bb74
bb39:
  %t150 = load ptr, ptr %l80, !tbaa !29
  %t151 = load i32, ptr %l83, !tbaa !23
  %t152 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t150, i32 %t151)
  store { i64, ptr } %t152, ptr %l84
  br label %bb40
bb40:
  %t153 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t153, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  store i64 %t156, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t158 = load i64, ptr %l9, !tbaa !24
  %t159 = load i64, ptr %l8, !tbaa !24
  %t162 = icmp sgt i64 %t158, %t159
  br i1 %t162, label %bb41, label %bb42
bb41:
  %t164 = load i64, ptr %l10, !tbaa !24
  %t166 = icmp sgt i64 %t164, 0
  br i1 %t166, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb46
bb43:
  %t168 = load i64, ptr %l9, !tbaa !24
  %t169 = load i64, ptr %l8, !tbaa !24
  %t172 = sub i64 %t168, %t169
  %t173 = load i64, ptr %l10, !tbaa !24
  %t176 = add i64 %t172, %t173
  %t178 = sub i64 %t176, 1
  %t179 = load i64, ptr %l10, !tbaa !24
  %t182 = sdiv i64 %t178, %t179
  store i64 %t182, ptr %l93, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb45
bb45:
  %t184 = load i64, ptr %l93, !tbaa !24
  store i64 %t184, ptr %l90, !tbaa !24
  br label %bb46
bb46:
  %t185 = load i64, ptr %l90, !tbaa !24
  store i64 %t185, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb47
bb47:
  %t186 = load i64, ptr %l12, !tbaa !24
  %t187 = load i64, ptr %l11, !tbaa !24
  %t190 = icmp slt i64 %t186, %t187
  %t192 = xor i1 %t190, true
  br i1 %t192, label %bb48, label %bb49
bb48:
  br label %bb72
bb49:
  br label %bb50
bb50:
  %t194 = load i64, ptr %l8, !tbaa !24
  %t195 = load i64, ptr %l12, !tbaa !24
  %t196 = load i64, ptr %l10, !tbaa !24
  %t199 = mul i64 %t195, %t196
  %t202 = add i64 %t194, %t199
  store i64 %t202, ptr %l13, !tbaa !24
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load i32, ptr %l3, !tbaa !23
  %t206 = load i64, ptr %l13, !tbaa !24
  %t210 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t204, i32 %t205, i64 %t206)
  store i64 %t210, ptr %l114
  br label %bb51
bb51:
  %t211 = load i64, ptr %l114, !tbaa !24
  store i64 %t211, ptr %l14, !tbaa !24
  %t212 = load i64, ptr %l14, !tbaa !24
  %t214 = icmp sge i64 %t212, 0
  br i1 %t214, label %bb52, label %bb53
bb52:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/free:Free", ptr %t216, i32 0, i32 12
  %t219 = load i64, ptr %l14, !tbaa !24
  %t222 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t218, i64 %t219)
  store i1 %t222, ptr %l121
  br label %bb54
bb53:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb59
bb54:
  %t223 = load i1, ptr %l121, !tbaa !21
  br i1 %t223, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb58
bb56:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/free:Free", ptr %t224, i32 0, i32 13
  %t227 = load i64, ptr %l14, !tbaa !24
  %t230 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t226, i64 %t227)
  store i1 %t230, ptr %l126
  br label %bb57
bb57:
  %t231 = load i1, ptr %l126, !tbaa !21
  store i1 %t231, ptr %l122, !tbaa !21
  br label %bb58
bb58:
  %t232 = load i1, ptr %l122, !tbaa !21
  store i1 %t232, ptr %l117, !tbaa !21
  br label %bb59
bb59:
  %t233 = load i1, ptr %l117, !tbaa !21
  br i1 %t233, label %bb60, label %bb61
bb60:
  %t234 = load ptr, ptr %lp4
  %t235 = load i64, ptr %l14, !tbaa !24
  %t238 = call i64 @compiler_2ffree_2eaddTo(ptr %v1, ptr %t234, i64 %t235)
  store i64 %t238, ptr %l129
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  %t239 = load ptr, ptr %l2, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t240, ptr %l131, !tbaa !27
  %t241 = load i64, ptr %l13, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i32, ptr %t244, i64 %t241
  %t246 = load i32, ptr %t245, !tbaa !33
  %t249 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t239, i32 %t246)
  store i1 %t249, ptr %l134
  br label %bb64
bb64:
  %t250 = load i1, ptr %l134, !tbaa !21
  %t251 = xor i1 %t250, true
  br i1 %t251, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s9
  %t253 = load ptr, ptr %lp4
  store ptr %t253, ptr %l136, !tbaa !29
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t255, ptr %l138, !tbaa !27
  %t256 = load i64, ptr %l13, !tbaa !24
  %t258 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr i32, ptr %t259, i64 %t256
  %t261 = load i32, ptr %t260, !tbaa !33
  %t264 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v0, ptr %t254, i32 %t261)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t264, ptr %l141
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t266 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %l141)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %l143
  br label %bb68
bb68:
  %t267 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l143
  %t268 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t267, ptr %t268
  %t269 = load ptr, ptr %l136, !tbaa !29
  %t271 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v1, ptr %v0, ptr %t269, ptr %t268)
  store i64 %t271, ptr %l145
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s9)
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t272 = load i64, ptr %l12, !tbaa !24
  %t274 = add i64 %t272, 1
  store i64 %t274, ptr %l12, !tbaa !24
  br label %bb47
bb72:
  br label %bb91
bb73:
  %t276 = load ptr, ptr %l2, !tbaa !29
  store ptr %t276, ptr %l150, !tbaa !29
  %t277 = load ptr, ptr %l2, !tbaa !29
  %t278 = load i32, ptr %l3, !tbaa !23
  %t281 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t277, i32 %t278)
  store i32 %t281, ptr %l153
  br label %bb75
bb74:
  br label %bb90
bb75:
  %t282 = load ptr, ptr %l150, !tbaa !29
  %t283 = load i32, ptr %l153, !tbaa !23
  %t284 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t282, i32 %t283)
  store { i64, ptr } %t284, ptr %l154
  br label %bb76
bb76:
  %t285 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t285, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t286 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t286, 0
  store i64 %t288, ptr %l17, !tbaa !24
  br label %bb77
bb77:
  %t290 = load i64, ptr %l16, !tbaa !24
  %t291 = load i64, ptr %l17, !tbaa !24
  %t294 = icmp slt i64 %t290, %t291
  %t296 = xor i1 %t294, true
  br i1 %t296, label %bb78, label %bb79
bb78:
  br label %bb89
bb79:
  br label %bb80
bb80:
  %t298 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t298, ptr %l161, !tbaa !27
  %t299 = load i64, ptr %l16, !tbaa !24
  %t301 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr i32, ptr %t302, i64 %t299
  %t304 = load i32, ptr %t303, !tbaa !33
  store i32 %t304, ptr %l18, !tbaa !23
  %t306 = load ptr, ptr %l2, !tbaa !29
  %t307 = load i32, ptr %l18, !tbaa !23
  %t310 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t306, i32 %t307)
  store i1 %t310, ptr %l166
  br label %bb81
bb81:
  %t311 = load i1, ptr %l166, !tbaa !21
  %t312 = xor i1 %t311, true
  br i1 %t312, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s15
  %t314 = load ptr, ptr %lp4
  store ptr %t314, ptr %l168, !tbaa !29
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load i32, ptr %l18, !tbaa !23
  %t319 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v0, ptr %t315, i32 %t316)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t319, ptr %l171
  br label %bb84
bb83:
  br label %bb87
bb84:
  %t321 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %l171)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t321, ptr %l173
  br label %bb85
bb85:
  %t322 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l173
  %t323 = call ptr @__olang_scope_alloc_a(ptr %s15, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t322, ptr %t323
  %t324 = load ptr, ptr %l168, !tbaa !29
  %t326 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v1, ptr %v0, ptr %t324, ptr %t323)
  store i64 %t326, ptr %l175
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s15)
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t327 = load i64, ptr %l16, !tbaa !24
  %t329 = add i64 %t327, 1
  store i64 %t329, ptr %l16, !tbaa !24
  br label %bb77
bb89:
  br label %bb90
bb90:
  br label %bb91
bb91:
  br label %bb113
bb92:
  store i1 true, ptr %l180, !tbaa !21
  br label %bb94
bb93:
  %t331 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t333 = trunc i64 22 to i32
  %t334 = icmp eq i32 %t331, %t333
  store i1 %t334, ptr %l180, !tbaa !21
  br label %bb94
bb94:
  %t336 = load i1, ptr %l180, !tbaa !21
  br i1 %t336, label %bb95, label %bb96
bb95:
  %t337 = load ptr, ptr %l2, !tbaa !29
  store ptr %t337, ptr %l183, !tbaa !29
  %t338 = load ptr, ptr %l2, !tbaa !29
  %t339 = load i32, ptr %l3, !tbaa !23
  %t342 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t338, i32 %t339)
  store i32 %t342, ptr %l186
  br label %bb97
bb96:
  br label %bb112
bb97:
  %t343 = load ptr, ptr %l183, !tbaa !29
  %t344 = load i32, ptr %l186, !tbaa !23
  %t345 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t343, i32 %t344)
  store { i64, ptr } %t345, ptr %l187
  br label %bb98
bb98:
  %t346 = load { i64, ptr }, ptr %l187, !tbaa !27
  store { i64, ptr } %t346, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t347 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t347, 0
  store i64 %t349, ptr %l21, !tbaa !24
  br label %bb99
bb99:
  %t351 = load i64, ptr %l20, !tbaa !24
  %t352 = load i64, ptr %l21, !tbaa !24
  %t355 = icmp slt i64 %t351, %t352
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb100, label %bb101
bb100:
  br label %bb111
bb101:
  br label %bb102
bb102:
  %t359 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t359, ptr %l194, !tbaa !27
  %t360 = load i64, ptr %l20, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr i32, ptr %t363, i64 %t360
  %t365 = load i32, ptr %t364, !tbaa !33
  store i32 %t365, ptr %l22, !tbaa !23
  %t367 = load ptr, ptr %l2, !tbaa !29
  %t368 = load i32, ptr %l22, !tbaa !23
  %t371 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t367, i32 %t368)
  store i1 %t371, ptr %l199
  br label %bb103
bb103:
  %t372 = load i1, ptr %l199, !tbaa !21
  %t373 = xor i1 %t372, true
  br i1 %t373, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s21
  %t375 = load ptr, ptr %lp4
  store ptr %t375, ptr %l201, !tbaa !29
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load i32, ptr %l22, !tbaa !23
  %t380 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v0, ptr %t376, i32 %t377)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t380, ptr %l204
  br label %bb106
bb105:
  br label %bb109
bb106:
  %t382 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %l204)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t382, ptr %l206
  br label %bb107
bb107:
  %t383 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l206
  %t384 = call ptr @__olang_scope_alloc_a(ptr %s21, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t383, ptr %t384
  %t385 = load ptr, ptr %l201, !tbaa !29
  %t387 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v1, ptr %v0, ptr %t385, ptr %t384)
  store i64 %t387, ptr %l208
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s21)
  br label %bb109
bb109:
  br label %bb110
bb110:
  %t388 = load i64, ptr %l20, !tbaa !24
  %t390 = add i64 %t388, 1
  store i64 %t390, ptr %l20, !tbaa !24
  br label %bb99
bb111:
  br label %bb112
bb112:
  br label %bb113
bb113:
  br label %bb114
bb114:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/free:Free", ptr %t392, i32 0, i32 20
  store ptr %t394, ptr %l212, !tbaa !29
  %t395 = load i32, ptr %l3, !tbaa !23
  store i32 %t395, ptr %l213, !tbaa !23
  %t396 = load ptr, ptr %lp4
  %t397 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t396
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t397, ptr %l214
  %t399 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l214)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t399, ptr %l216
  br label %bb115
bb115:
  %t400 = load ptr, ptr %l212, !tbaa !29
  %t401 = load i32, ptr %l213, !tbaa !23
  %t402 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l216
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H127fb385441fbfd25cd8404c6b268b5d(ptr %v0, ptr %s0, ptr %t400, i32 %t401, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t402)
  br label %bb116
bb116:
  %t403 = load ptr, ptr %lp4
  %t404 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t403
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t404, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehiddenLetGo(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i64
  %l40 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l48 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l59 = alloca ptr
  %l61 = alloca i64
  %l65 = alloca ptr
  %l69 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 68
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp eq i64 %t10, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 69
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t15, i64 %t16)
  store i1 %t19, ptr %l12
  br label %bb5
bb4:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i1, ptr %l12, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l8, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/free:Free", ptr %t24, i32 0, i32 70
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t26, i64 %t27)
  store i64 %t30, ptr %l18
  br label %bb9
bb8:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb9:
  %t31 = load i64, ptr %l18, !tbaa !24
  %t32 = icmp eq i64 %t31, 0
  store i1 %t32, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l14, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eimplicit(ptr %v0, ptr %t35, i64 %t36)
  store i1 %t39, ptr %l22
  br label %bb14
bb14:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb15, label %bb16
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emodelled(ptr %v0, ptr %t41, i64 %t42)
  store i1 %t45, ptr %l26
  br label %bb17
bb16:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb18
bb17:
  %t46 = load i1, ptr %l26, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb18
bb18:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb19, label %bb20
bb19:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/free:Free", ptr %t50, i32 0, i32 69
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t52, i64 %t53)
  store i1 %t56, ptr %l31
  br label %bb21
bb20:
  br label %bb39
bb21:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb25
bb23:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/free:Free", ptr %t58, i32 0, i32 70
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l36
  br label %bb24
bb24:
  %t65 = load i64, ptr %l36, !tbaa !24
  %t66 = icmp ne i64 %t65, 0
  store i1 %t66, ptr %l32, !tbaa !21
  br label %bb25
bb25:
  %t68 = load i1, ptr %l32, !tbaa !21
  br i1 %t68, label %bb26, label %bb27
bb26:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:Free", ptr %t69, i32 0, i32 81
  store i1 true, ptr %t71, !tbaa !21
  br label %bb30
bb27:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/free:Free", ptr %t72, i32 0, i32 82
  store ptr %t74, ptr %l40, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/free:Free", ptr %t75, i32 0, i32 68
  %t78 = load i64, ptr %l1, !tbaa !24
  %t81 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t77, i64 %t78)
  store ptr %t81, ptr %l44
  br label %bb28
bb28:
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = load ptr, ptr %l44, !tbaa !29
  %t84 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v0, ptr %t82, ptr %t83)
  store i64 %t84, ptr %l45
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:Free", ptr %t85, i32 0, i32 116
  %t88 = load i1, ptr %t87, !tbaa !21
  br i1 %t88, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l48, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i64, ptr %l1, !tbaa !24
  %t95 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s5, ptr %t91, i64 %t92)
  store { i64, ptr } %t95, ptr %l51
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/load:Loader", ptr %t102, i32 0, i32 4
  %t105 = load ptr, ptr %t104, !tbaa !29
  store ptr %t105, ptr %l55, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/free:Free", ptr %t106, i32 0, i32 1
  %t109 = load i64, ptr %l1, !tbaa !24
  %t112 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t108, i64 %t109)
  store ptr %t112, ptr %l59
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l59, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Body", ptr %t113, i32 0, i32 3
  %t116 = load i64, ptr %t115, !tbaa !24
  store i64 %t116, ptr %l61, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:Free", ptr %t117, i32 0, i32 1
  %t120 = load i64, ptr %l1, !tbaa !24
  %t123 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t119, i64 %t120)
  store ptr %t123, ptr %l65
  br label %bb35
bb35:
  %t124 = load ptr, ptr %l65, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Body", ptr %t124, i32 0, i32 4
  %t127 = getelementptr %"compiler/source:Span", ptr %t126, i32 0, i32 0
  %t128 = load i32, ptr %t127, !tbaa !23
  %t130 = sext i32 %t128 to i64
  %t131 = load ptr, ptr %l55, !tbaa !29
  %t132 = load i64, ptr %l61, !tbaa !24
  %t134 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s5, ptr %t131, i64 %t132, i64 %t130)
  store { i64, ptr } %t134, ptr %l69
  br label %bb36
bb36:
  %t135 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t137 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = add i64 %t136, %t139
  %t141 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t144 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t151 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t135, i64 %t136)
  %t152 = getelementptr i8, ptr %t151, i64 %t136
  call void @olang_textcopy(ptr %t152, ptr %t138, i64 %t139)
  %t153 = getelementptr i8, ptr %t152, i64 %t139
  call void @olang_textcopy(ptr %t153, ptr %t141, i64 %t142)
  %t154 = getelementptr i8, ptr %t153, i64 %t142
  call void @olang_textcopy(ptr %t154, ptr %t145, i64 %t146)
  %t155 = getelementptr i8, ptr %t154, i64 %t146
  call void @olang_textcopy(ptr %t155, ptr %t148, i64 %t149)
  %t156 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t151, 1
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = extractvalue { i64, ptr } %t157, 1
  %t161 = mul i64 %t159, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t161)
  call void @llvm.memcpy.p0.p0.i64(ptr %t162, ptr %t160, i64 %t161, i1 false)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  %t165 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edebugOut(ptr %v0, ptr %s5, ptr %t165, { i64, ptr } %t164)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholderRows(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca %"compiler/free:store"
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l49 = alloca i32
  %l53 = alloca %"compiler/free:store"
  %l54 = alloca ptr
  %l55 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i32
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l78 = alloca ptr
  %l80 = alloca ptr
  %l82 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca i32
  %l87 = alloca { i64, ptr }
  %l89 = alloca i1
  %l104 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/free:Free", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/load:Loader", ptr %t9, i32 0, i32 4
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:Free", ptr %t14, i32 0, i32 25
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l21
  br label %bb2
bb2:
  %t19 = load i64, ptr %l21, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb8
bb5:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l28, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb7
bb7:
  %t46 = load i64, ptr %l28, !tbaa !24
  store i64 %t46, ptr %l25, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l25, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb11:
  br label %bb12
bb12:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l8, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:Free", ptr %t66, i32 0, i32 25
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t68, i64 %t69)
  store i32 %t72, ptr %l49
  br label %bb13
bb13:
  %t73 = load i32, ptr %l49, !tbaa !23
  store i32 %t73, ptr %l9, !tbaa !23
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 26
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/free:store" %t80, ptr %l53
  br label %bb14
bb14:
  %t81 = load %"compiler/free:store", ptr %l53
  store %"compiler/free:store" %t81, ptr %l10
  %t82 = load ptr, ptr %l2, !tbaa !29
  store ptr %t82, ptr %l54, !tbaa !29
  %t83 = getelementptr %"compiler/free:store", ptr %l10, i32 0, i32 2
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 %t84, ptr %l55, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:store", ptr %l10, i32 0, i32 2
  %t87 = load i64, ptr %t86, !tbaa !24
  %t88 = getelementptr %"compiler/free:store", ptr %l10, i32 0, i32 3
  %t89 = getelementptr %"compiler/source:Span", ptr %t88, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t92 = sext i32 %t90 to i64
  %t96 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elineStart(ptr %v0, ptr %t85, i64 %t87, i64 %t92)
  store i64 %t96, ptr %l60
  br label %bb15
bb15:
  %t97 = load ptr, ptr %l54, !tbaa !29
  %t98 = load i64, ptr %l55, !tbaa !24
  %t99 = load i64, ptr %l60, !tbaa !24
  %t100 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s2, ptr %t97, i64 %t98, i64 %t99)
  store { i64, ptr } %t100, ptr %l61
  br label %bb16
bb16:
  %t101 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t102, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l11, !tbaa !27
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:Free", ptr %t108, i32 0, i32 24
  %t111 = load i32, ptr %l9, !tbaa !23
  %t114 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hdc5ed4f57090b33f7a83fc7b2b1f05b3(ptr %v0, ptr %s2, ptr %t110, i32 %t111)
  %t115 = extractvalue { i32, { i64, ptr } } %t114, 1
  %t116 = extractvalue { i32, { i64, ptr } } %t114, 0
  store i32 %t116, ptr %l68
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb18, label %ok.118, !prof !99
ok.118:
  store { i64, ptr } %t115, ptr %l67
  br label %bb17
bb17:
  %t119 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l69, !tbaa !24
  %t121 = load i64, ptr %l69, !tbaa !24
  %t122 = mul i64 %t121, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l70, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l69, !tbaa !24
  %t131 = mul i64 %t130, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t127, ptr %t129, i64 %t131, i1 false)
  %t132 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t132, ptr %l63, !tbaa !27
  br label %bb20
bb18:
  br label %bb19
bb19:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l71, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t133, ptr %l63, !tbaa !27
  br label %bb20
bb20:
  %t135 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l73, !tbaa !24
  %t137 = load i64, ptr %l73, !tbaa !24
  %t138 = mul i64 %t137, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l74, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = load i64, ptr %l73, !tbaa !24
  %t147 = mul i64 %t146, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t143, ptr %t145, i64 %t147, i1 false)
  %t148 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t148, ptr %l12, !tbaa !27
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t149)
  store ptr %t151, ptr %l76
  br label %bb21
bb21:
  %t152 = load ptr, ptr %l76, !tbaa !29
  %t154 = getelementptr %"compiler/types:Table", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  store ptr %t155, ptr %l78, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t156)
  store ptr %t158, ptr %l80
  br label %bb22
bb22:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t159)
  store ptr %t161, ptr %l82
  br label %bb23
bb23:
  %t162 = load i32, ptr %l9, !tbaa !23
  %t163 = load ptr, ptr %l82, !tbaa !29
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t163, i32 %t162)
  store i32 %t165, ptr %l84
  br label %bb24
bb24:
  %t166 = load ptr, ptr %l80, !tbaa !29
  %t167 = load i32, ptr %l84, !tbaa !23
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t166, i32 %t167)
  store i32 %t168, ptr %l85
  br label %bb25
bb25:
  %t169 = load ptr, ptr %l78, !tbaa !29
  %t170 = call ptr @__olang_scope_of(ptr %t169, ptr null)
  %t171 = ptrtoint ptr %t170 to i64
  %t173 = inttoptr i64 %t171 to ptr
  %t174 = load ptr, ptr %l78, !tbaa !29
  %t175 = load i32, ptr %l85, !tbaa !23
  %t176 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t173, ptr %s2, ptr %t174, i32 %t175)
  store { i64, ptr } %t176, ptr %l87
  br label %bb26
bb26:
  %t177 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t177, ptr %l13, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t180 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t178, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t180, ptr %l89
  br label %bb27
bb27:
  %t181 = load i1, ptr %l89, !tbaa !21
  br i1 %t181, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t182 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t182, 1
  %t186 = extractvalue { i64, ptr } %t182, 0
  %t187 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t191 = extractvalue { i64, ptr } %t183, 1
  %t192 = extractvalue { i64, ptr } %t183, 0
  %t193 = add i64 %t189, %t192
  %t194 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t196)
  call void @olang_textcopy(ptr %t197, ptr %t185, i64 %t186)
  %t198 = getelementptr i8, ptr %t197, i64 %t186
  call void @olang_textcopy(ptr %t198, ptr %t187, i64 %t188)
  %t199 = getelementptr i8, ptr %t198, i64 %t188
  call void @olang_textcopy(ptr %t199, ptr %t191, i64 %t192)
  %t200 = getelementptr i8, ptr %t199, i64 %t192
  call void @olang_textcopy(ptr %t200, ptr %t194, i64 %t195)
  %t201 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t197, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l1, { i64, ptr } %t209)
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb31:
  %t212 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t212, 1
  %t217 = extractvalue { i64, ptr } %t212, 0
  %t218 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t222 = extractvalue { i64, ptr } %t213, 1
  %t223 = extractvalue { i64, ptr } %t213, 0
  %t224 = add i64 %t220, %t223
  %t225 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t229 = extractvalue { i64, ptr } %t214, 1
  %t230 = extractvalue { i64, ptr } %t214, 0
  %t231 = add i64 %t227, %t230
  %t232 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t234 = add i64 %t231, %t233
  %t235 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t234)
  call void @olang_textcopy(ptr %t235, ptr %t216, i64 %t217)
  %t236 = getelementptr i8, ptr %t235, i64 %t217
  call void @olang_textcopy(ptr %t236, ptr %t218, i64 %t219)
  %t237 = getelementptr i8, ptr %t236, i64 %t219
  call void @olang_textcopy(ptr %t237, ptr %t222, i64 %t223)
  %t238 = getelementptr i8, ptr %t237, i64 %t223
  call void @olang_textcopy(ptr %t238, ptr %t225, i64 %t226)
  %t239 = getelementptr i8, ptr %t238, i64 %t226
  call void @olang_textcopy(ptr %t239, ptr %t229, i64 %t230)
  %t240 = getelementptr i8, ptr %t239, i64 %t230
  call void @olang_textcopy(ptr %t240, ptr %t232, i64 %t233)
  %t241 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t235, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = extractvalue { i64, ptr } %t242, 1
  %t246 = mul i64 %t244, 1
  %t247 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t245, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l1, { i64, ptr } %t249)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  %t252 = load i64, ptr %l7, !tbaa !24
  %t254 = add i64 %t252, 1
  store i64 %t254, ptr %l7, !tbaa !24
  br label %bb9
bb34:
  %t257 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t257, ptr %l104
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t258 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t258, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholdsTypes(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l23 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l40 = alloca i1
  %l44 = alloca i64
  %l49 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i32
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l73 = alloca i64
  %l76 = alloca i64
  %l99 = alloca i1
  %l101 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l106 = alloca i32
  %l114 = alloca i1
  %l116 = alloca ptr
  %l119 = alloca i32
  %l120 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l135 = alloca i32
  %l136 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l146 = alloca ptr
  %l149 = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l23, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t5, 32
  br i1 %t7, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l28
  br label %bb5
bb5:
  %t14 = load i32, ptr %l28, !range !{i32 0, i32 33}
  store i32 %t14, ptr %l5
  %t15 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t17 = trunc i64 20 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l4, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l34
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t26 = load ptr, ptr %l31, !tbaa !29
  %t27 = load i32, ptr %l34, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t28, ptr %l35
  br label %bb9
bb9:
  %t29 = load i32, ptr %l35, !tbaa !23
  store i32 %t29, ptr %l6, !tbaa !23
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/free:Free", ptr %t30, i32 0, i32 28
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  %t38 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eIsGen(ptr %v0, ptr %v0, ptr %t32, ptr %t33, i32 %t34)
  store i1 %t38, ptr %l40
  br label %bb10
bb10:
  %t39 = load i1, ptr %l40, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t41 = load i32, ptr %l6, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t46 = call i64 @compiler_2ffree_2eaddTo(ptr %v1, ptr %t40, i64 %t43)
  store i64 %t46, ptr %l44
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %ret
bb15:
  %t47 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t49 = trunc i64 19 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb16, label %bb17
bb16:
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l49
  br label %bb18
bb17:
  br label %bb25
bb18:
  %t57 = load i32, ptr %l49, !tbaa !23
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l51, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  store ptr %t61, ptr %l52, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t63 = load i32, ptr %l1, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l55
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t67 = load ptr, ptr %l52, !tbaa !29
  %t68 = load i32, ptr %l55, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t69, ptr %l56
  br label %bb22
bb22:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = add i64 %t71, 1
  %t74 = load ptr, ptr %l51, !tbaa !29
  %t75 = load i32, ptr %l56, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholdsTypes(ptr %v0, ptr %v1, ptr %t74, i32 %t75, ptr %t70, i64 %t73)
  br label %bb23
bb23:
  br label %bb24
bb24:
  br label %ret
bb25:
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t79 = load i32, ptr %l1, !tbaa !23
  %t82 = call i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %t78, i32 %t79)
  store i1 %t82, ptr %l62
  br label %bb26
bb26:
  %t83 = load i1, ptr %l62, !tbaa !21
  br i1 %t83, label %bb27, label %bb28
bb27:
  %t84 = load ptr, ptr %l4, !tbaa !29
  store ptr %t84, ptr %l63, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t86 = load i32, ptr %l1, !tbaa !23
  %t89 = call i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t89, ptr %l66
  br label %bb29
bb28:
  br label %bb49
bb29:
  %t90 = load ptr, ptr %l63, !tbaa !29
  %t91 = load i32, ptr %l66, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t90, i32 %t91)
  store { i64, ptr } %t92, ptr %l67
  br label %bb30
bb30:
  %t93 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t93, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  store i64 %t96, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t98, %t99
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb36
bb33:
  %t108 = load i64, ptr %l9, !tbaa !24
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = sub i64 %t108, %t109
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = add i64 %t112, %t113
  %t118 = sub i64 %t116, 1
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = sdiv i64 %t118, %t119
  store i64 %t122, ptr %l76, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb35
bb35:
  %t124 = load i64, ptr %l76, !tbaa !24
  store i64 %t124, ptr %l73, !tbaa !24
  br label %bb36
bb36:
  %t125 = load i64, ptr %l73, !tbaa !24
  store i64 %t125, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb37
bb37:
  %t126 = load i64, ptr %l12, !tbaa !24
  %t127 = load i64, ptr %l11, !tbaa !24
  %t130 = icmp slt i64 %t126, %t127
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb38, label %bb39
bb38:
  br label %bb48
bb39:
  br label %bb40
bb40:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t136 = load i64, ptr %l10, !tbaa !24
  %t139 = mul i64 %t135, %t136
  %t142 = add i64 %t134, %t139
  store i64 %t142, ptr %l13, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/free:Free", ptr %t144, i32 0, i32 28
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t148 = load i32, ptr %l1, !tbaa !23
  %t149 = load i64, ptr %l13, !tbaa !24
  %t154 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v0, ptr %t146, ptr %t147, i32 %t148, i64 %t149)
  store i1 %t154, ptr %l99
  br label %bb41
bb41:
  %t155 = load i1, ptr %l99, !tbaa !21
  %t156 = xor i1 %t155, true
  br i1 %t156, label %bb42, label %bb43
bb42:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l101, !tbaa !29
  %t159 = load ptr, ptr %l4, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t160, ptr %l103, !tbaa !27
  %t161 = load i64, ptr %l13, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i32, ptr %t164, i64 %t161
  %t166 = load i32, ptr %t165, !tbaa !33
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t159, i32 %t166)
  store i32 %t169, ptr %l106
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t170 = load ptr, ptr %l2, !tbaa !29
  %t171 = load i64, ptr %l3, !tbaa !24
  %t173 = add i64 %t171, 1
  %t174 = load ptr, ptr %l101, !tbaa !29
  %t175 = load i32, ptr %l106, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholdsTypes(ptr %v0, ptr %v1, ptr %t174, i32 %t175, ptr %t170, i64 %t173)
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t178 = load i64, ptr %l12, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l12, !tbaa !24
  br label %bb37
bb48:
  br label %ret
bb49:
  %t182 = load ptr, ptr %l4, !tbaa !29
  %t183 = load i32, ptr %l1, !tbaa !23
  %t186 = call i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %t182, i32 %t183)
  store i1 %t186, ptr %l114
  br label %bb50
bb50:
  %t187 = load i1, ptr %l114, !tbaa !21
  %t188 = xor i1 %t187, true
  br i1 %t188, label %bb51, label %bb52
bb51:
  br label %ret
bb52:
  br label %bb53
bb53:
  %t190 = load ptr, ptr %l4, !tbaa !29
  store ptr %t190, ptr %l116, !tbaa !29
  %t191 = load ptr, ptr %l4, !tbaa !29
  %t192 = load i32, ptr %l1, !tbaa !23
  %t195 = call i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %t191, i32 %t192)
  store i32 %t195, ptr %l119
  br label %bb54
bb54:
  %t196 = load ptr, ptr %l116, !tbaa !29
  %t197 = load i32, ptr %l119, !tbaa !23
  %t198 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t196, i32 %t197)
  store { i64, ptr } %t198, ptr %l120
  br label %bb55
bb55:
  %t199 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t199, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  store i64 %t202, ptr %l16, !tbaa !24
  br label %bb56
bb56:
  %t204 = load i64, ptr %l15, !tbaa !24
  %t205 = load i64, ptr %l16, !tbaa !24
  %t208 = icmp slt i64 %t204, %t205
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb57, label %bb58
bb57:
  br label %bb74
bb58:
  br label %bb59
bb59:
  %t212 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t212, ptr %l127, !tbaa !27
  %t213 = load i64, ptr %l15, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr i32, ptr %t216, i64 %t213
  %t218 = load i32, ptr %t217, !tbaa !33
  store i32 %t218, ptr %l17, !tbaa !23
  %t220 = load i32, ptr %l17, !tbaa !23
  %t222 = icmp eq i32 %t220, 0
  br i1 %t222, label %bb60, label %bb61
bb60:
  br label %bb73
bb61:
  br label %bb62
bb62:
  %t224 = load ptr, ptr %l4, !tbaa !29
  store ptr %t224, ptr %l132, !tbaa !29
  %t225 = load ptr, ptr %l4, !tbaa !29
  %t226 = load i32, ptr %l17, !tbaa !23
  %t229 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t225, i32 %t226)
  store i32 %t229, ptr %l135
  br label %bb63
bb63:
  %t230 = load ptr, ptr %l132, !tbaa !29
  %t231 = load i32, ptr %l135, !tbaa !23
  %t232 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t230, i32 %t231)
  store { i64, ptr } %t232, ptr %l136
  br label %bb64
bb64:
  %t233 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t233, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t234 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  store i64 %t236, ptr %l20, !tbaa !24
  br label %bb65
bb65:
  %t238 = load i64, ptr %l19, !tbaa !24
  %t239 = load i64, ptr %l20, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb66, label %bb67
bb66:
  br label %bb72
bb67:
  br label %bb68
bb68:
  %t246 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t246, ptr %l143, !tbaa !27
  %t247 = load i64, ptr %l19, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i32, ptr %t250, i64 %t247
  %t252 = load i32, ptr %t251, !tbaa !33
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l146, !tbaa !29
  %t255 = load ptr, ptr %l4, !tbaa !29
  %t259 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t255, i32 %t252)
  store i32 %t259, ptr %l149
  br label %bb69
bb69:
  %t260 = load ptr, ptr %l2, !tbaa !29
  %t261 = load i64, ptr %l3, !tbaa !24
  %t263 = add i64 %t261, 1
  %t264 = load ptr, ptr %l146, !tbaa !29
  %t265 = load i32, ptr %l149, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholdsTypes(ptr %v0, ptr %v1, ptr %t264, i32 %t265, ptr %t260, i64 %t263)
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t268 = load i64, ptr %l19, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l19, !tbaa !24
  br label %bb65
bb72:
  br label %bb73
bb73:
  %t272 = load i64, ptr %l15, !tbaa !24
  %t274 = add i64 %t272, 1
  store i64 %t274, ptr %l15, !tbaa !24
  br label %bb56
bb74:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eimplicit(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 3
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %rv
  br label %ret
bb5:
  %t19 = load { i64, [2 x i64] }, ptr %l2
  %t21 = extractvalue { i64, [2 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t25 = getelementptr { i64 }, ptr %t24, i32 0, i32 0
  %t26 = load i64, ptr %t25
  store i64 %t26, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb33
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/free:Free", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t35, i64 %t36)
  store i64 %t39, ptr %l23
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load i64, ptr %l23, !tbaa !24
  %t42 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t40, i64 %t41)
  store ptr %t42, ptr %l24
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/free:Free", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Func", ptr %t43, i32 0, i32 2
  %t57 = load i32, ptr %t56, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t53, i32 %t57)
  store { i64, ptr } %t60, ptr %l31
  br label %bb11
bb11:
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %l5, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t62, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t64, ptr %l33
  br label %bb12
bb12:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb16
bb14:
  %t66 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t66, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t68, ptr %l36
  br label %bb15
bb15:
  %t69 = load i1, ptr %l36, !tbaa !21
  store i1 %t69, ptr %l34, !tbaa !21
  br label %bb16
bb16:
  %t70 = load i1, ptr %l34, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb20
bb18:
  %t71 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t71, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t73, ptr %l39
  br label %bb19
bb19:
  %t74 = load i1, ptr %l39, !tbaa !21
  store i1 %t74, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l37, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb24
bb22:
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t76, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t78, ptr %l42
  br label %bb23
bb23:
  %t79 = load i1, ptr %l42, !tbaa !21
  store i1 %t79, ptr %l40, !tbaa !21
  br label %bb24
bb24:
  %t80 = load i1, ptr %l40, !tbaa !21
  br i1 %t80, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb28
bb26:
  %t81 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t81, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t83, ptr %l45
  br label %bb27
bb27:
  %t84 = load i1, ptr %l45, !tbaa !21
  store i1 %t84, ptr %l43, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l43, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb32
bb30:
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t86, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t88, ptr %l48
  br label %bb31
bb31:
  %t89 = load i1, ptr %l48, !tbaa !21
  store i1 %t89, ptr %l46, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  %t90 = load i1, ptr %l46, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i1 false, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_708b3215abbdbba7_3cea2bd689d53e8b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisGlobal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 10
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 10
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp eq i64 %t23, -4
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l10, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisOwnLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 10
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 10
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp eq i64 %t23, -3
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l10, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i1
  %l64 = alloca i1
  %l72 = alloca { i64, [2 x i64] }
  %l74 = alloca { i64, [2 x i64] }
  %l76 = alloca i1
  %l77 = alloca i1
  %l80 = alloca { i64, ptr }
  %l83 = alloca i64
  %l85 = alloca i1
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, [2 x i64] }
  %l94 = alloca { i64, [2 x i64] }
  %l96 = alloca i1
  %l98 = alloca i64
  %l106 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, [2 x i64] } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp sge i64 %t5, 63
  store i1 %t7, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 3
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l25
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l25, !tbaa !29
  store ptr %t18, ptr %l6, !tbaa !29
  %t19 = load i64, ptr %l5, !tbaa !24
  store i64 %t19, ptr %l26, !tbaa !24
  %t20 = load i64, ptr %l26, !tbaa !24
  %t21 = load i64, ptr %l26, !tbaa !24
  %t22 = shl i64 1, %t21
  store i64 %t22, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t31 = load i64, ptr %l9, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load i64, ptr %l10, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb13
bb10:
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l10, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l10, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l37, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb12
bb12:
  %t57 = load i64, ptr %l37, !tbaa !24
  store i64 %t57, ptr %l34, !tbaa !24
  br label %bb13
bb13:
  %t58 = load i64, ptr %l34, !tbaa !24
  store i64 %t58, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb14
bb14:
  %t59 = load i64, ptr %l12, !tbaa !24
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb15, label %bb16
bb15:
  br label %bb43
bb16:
  br label %bb17
bb17:
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l12, !tbaa !24
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l13, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l13, !tbaa !24
  %t83 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t77, i64 %t78, i64 %t79)
  store i64 %t83, ptr %l58
  br label %bb18
bb18:
  %t84 = load i64, ptr %l58, !tbaa !24
  store i64 %t84, ptr %l14, !tbaa !24
  %t85 = load i64, ptr %l14, !tbaa !24
  %t87 = icmp slt i64 %t85, 0
  br i1 %t87, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb21
bb20:
  %t89 = load i64, ptr %l14, !tbaa !24
  %t91 = icmp sge i64 %t89, 63
  store i1 %t91, ptr %l61, !tbaa !21
  br label %bb21
bb21:
  %t93 = load i1, ptr %l61, !tbaa !21
  br i1 %t93, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb24
bb23:
  %t94 = load i64, ptr %l14, !tbaa !24
  %t95 = load i64, ptr %l5, !tbaa !24
  %t98 = icmp eq i64 %t94, %t95
  store i1 %t98, ptr %l64, !tbaa !21
  br label %bb24
bb24:
  %t100 = load i1, ptr %l64, !tbaa !21
  br i1 %t100, label %bb25, label %bb26
bb25:
  br label %bb42
bb26:
  br label %bb27
bb27:
  %t101 = load ptr, ptr %l6, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Call", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %t104, !tbaa !23
  %t106 = load i64, ptr %l14, !tbaa !24
  %t110 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t101, i32 %t105, i64 %t106)
  store { i64, [2 x i64] } %t110, ptr %l72
  br label %bb28
bb28:
  %t111 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t111, ptr %l74
  %t114 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l72, ptr %l74)
  store i1 %t114, ptr %l76
  br label %bb29
bb29:
  %t115 = load i1, ptr %l76, !tbaa !21
  br i1 %t115, label %bb30, label %bb31
bb30:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Call", ptr %t117, i32 0, i32 1
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l80, !tbaa !27
  %t121 = load i64, ptr %l13, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 %t121
  %t126 = load ptr, ptr %t125, !tbaa !39
  %t129 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t116, ptr %t126)
  store i64 %t129, ptr %l83
  br label %bb32
bb31:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb33
bb32:
  %t130 = load i64, ptr %l83, !tbaa !24
  %t131 = icmp sge i64 %t130, 0
  store i1 %t131, ptr %l77, !tbaa !21
  br label %bb33
bb33:
  %t133 = load i1, ptr %l77, !tbaa !21
  br i1 %t133, label %bb34, label %bb35
bb34:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l1, !tbaa !24
  %t136 = load ptr, ptr %l2, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Call", ptr %t136, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l89, !tbaa !27
  %t140 = load i64, ptr %l13, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr ptr, ptr %t143, i64 %t140
  %t145 = load ptr, ptr %t144, !tbaa !39
  %t149 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebuiltAt(ptr %v0, ptr %v1, ptr %t134, i64 %t135, ptr %t145)
  store { i64, [2 x i64] } %t149, ptr %l92
  br label %bb36
bb35:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb38
bb36:
  %t150 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t150, ptr %l94
  %t153 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l92, ptr %l94)
  store i1 %t153, ptr %l96
  br label %bb37
bb37:
  %t154 = load i1, ptr %l96, !tbaa !21
  store i1 %t154, ptr %l85, !tbaa !21
  br label %bb38
bb38:
  %t155 = load i1, ptr %l85, !tbaa !21
  br i1 %t155, label %bb39, label %bb40
bb39:
  %t156 = load i64, ptr %l7, !tbaa !24
  %t157 = load i64, ptr %l14, !tbaa !24
  store i64 %t157, ptr %l98, !tbaa !24
  %t158 = load i64, ptr %l98, !tbaa !24
  %t159 = load i64, ptr %l98, !tbaa !24
  %t160 = shl i64 1, %t159
  %t163 = or i64 %t156, %t160
  store i64 %t163, ptr %l7, !tbaa !24
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t165 = load i64, ptr %l12, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l12, !tbaa !24
  br label %bb14
bb43:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:Free", ptr %t169, i32 0, i32 2
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t173 = load i64, ptr %l3, !tbaa !24
  %t176 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %s0, ptr %t172, i64 %t173)
  store { i64, ptr } %t176, ptr %l106
  br label %bb44
bb44:
  %t177 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l7, !tbaa !24
  %t184 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %s0, ptr %t178, { i64, ptr } %t177, i64 %t180)
  store i1 %t184, ptr %l110
  br label %bb45
bb45:
  %t185 = load i1, ptr %l110, !tbaa !21
  br i1 %t185, label %bb46, label %bb47
bb46:
  %t186 = load i64, ptr %l7, !tbaa !24
  store i64 %t186, ptr %l111, !tbaa !24
  br label %bb48
bb47:
  store i64 -1, ptr %l111, !tbaa !24
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t188 = load i64, ptr %l111, !tbaa !24
  store i64 %t188, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eouterFirst(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t69 = alloca { ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store i64 0, ptr %l2, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 83
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l11
  br label %bb2
bb2:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l18, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l18, !tbaa !24
  store i64 %t37, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l15, !tbaa !24
  store i64 %t38, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l2, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  %t57 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t57, i64 %t55)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb9
bb15:
  %t65 = load ptr, ptr %lp1
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t68 = ptrtoint ptr %t67 to i64
  %t70 = getelementptr { ptr, ptr }, ptr %t69, i32 0, i32 0
  store ptr %t66, ptr %t70, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t72 = getelementptr { ptr, ptr }, ptr %t69, i32 0, i32 1
  store ptr %v0, ptr %t72, !tbaa !28
  %t73 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_32, 0
  %t74 = insertvalue { ptr, ptr } %t73, ptr %t69, 1
  %t77 = extractvalue { ptr, ptr } %t74, 0
  %t78 = extractvalue { ptr, ptr } %t74, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v1, ptr %s0, ptr %t65, ptr %t77, ptr %t78)
  br label %bb16
bb16:
  %t79 = load ptr, ptr %lp1
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t79
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:store"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l13 = alloca { i64, [2 x i64] }
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l45 = alloca %"compiler/free:store"
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i64
  %l67 = alloca { i64, [2 x i64] }
  %l70 = alloca i64
  %l71 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:store" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 7
  %t2 = load ptr, ptr %t1, !tbaa !29
  %t4 = icmp eq ptr %t2, null
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_3bfd4abaed3d7178_ecedd42d9535955c)
  unreachable
bb2:
  br label %bb3
bb3:
  %t6 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 7
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t16 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t9, i64 %t11, ptr %t12)
  store { i64, [2 x i64] } %t16, ptr %l13
  br label %bb4
bb4:
  %t17 = load { i64, [2 x i64] }, ptr %l13
  %t18 = call i1 @compiler_2ffree_2eruns({ i64, [2 x i64] } %t17)
  store i1 %t18, ptr %l14
  br label %bb5
bb5:
  %t19 = load i1, ptr %l14, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t26 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %t23)
  store ptr %t26, ptr %l19
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l19, !tbaa !29
  store ptr %t27, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 5
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Promote", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = call ptr @compiler_2ffree_2ectorCall(ptr %v1, ptr %s0, ptr %t46)
  store ptr %t48, ptr %l28
  br label %bb15
bb15:
  %t49 = load ptr, ptr %l28, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb35
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 18}
  %t57 = icmp eq i64 %t55, 17
  store i1 %t57, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l5, !tbaa !29
  br label %bb21
bb20:
  br label %bb24
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l35, !tbaa !29
  %t66 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  %t68 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 2
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 3
  %t73 = load %"compiler/source:Span", ptr %t72
  %t74 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  %t76 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 5
  %t77 = load i64, ptr %t76, !tbaa !24
  %t78 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 6
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t90 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v1, ptr %s3, ptr %s3, i64 %t67, i64 %t69, i64 %t71, %"compiler/source:Span" %t73, i64 %t75, i64 %t77, i64 %t79, ptr %t80, ptr null)
  store %"compiler/free:store" %t90, ptr %l45
  br label %bb22
bb22:
  %t91 = load ptr, ptr %l35, !tbaa !29
  %t92 = load %"compiler/free:store", ptr %l45
  %t93 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %s3, ptr %t91, %"compiler/free:store" %t92)
  store i1 %t93, ptr %l46
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t94 = load i1, ptr %l46, !tbaa !21
  store i1 %t94, ptr %rv
  br label %ret
bb24:
  %t95 = load ptr, ptr %l2, !tbaa !29
  store ptr %t95, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t96 = load ptr, ptr %l47, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t99 = load ptr, ptr %l47, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 18}
  %t102 = icmp eq i64 %t100, 6
  store i1 %t102, ptr %l48, !tbaa !21
  br label %bb26
bb26:
  %t103 = load i1, ptr %l48, !tbaa !21
  br i1 %t103, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_18f4ed1d8e27b1ae_93487f3f650a5572)
  unreachable
bb35:
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t107 = icmp eq ptr %t105, null
  br i1 %t107, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t112 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t110)
  store i64 %t112, ptr %l56
  br label %bb39
bb39:
  %t113 = load i64, ptr %l56, !tbaa !24
  store i64 %t113, ptr %l6, !tbaa !24
  %t114 = load i64, ptr %l6, !tbaa !24
  %t116 = icmp slt i64 %t114, 0
  br i1 %t116, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l60, !tbaa !29
  %t120 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  store i64 %t121, ptr %l61, !tbaa !24
  %t122 = load ptr, ptr %l3, !tbaa !29
  store ptr %t122, ptr %l62, !tbaa !29
  %t123 = load i64, ptr %l6, !tbaa !24
  store i64 %t123, ptr %l63, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t126 = load i64, ptr %t125, !tbaa !24
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t131 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t124, i64 %t126, ptr %t127)
  store { i64, [2 x i64] } %t131, ptr %l67
  br label %bb43
bb43:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l6, !tbaa !24
  %t136 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %t132, i64 %t133)
  store i64 %t136, ptr %l70
  br label %bb44
bb44:
  %t137 = load ptr, ptr %l60, !tbaa !29
  %t138 = load i64, ptr %l61, !tbaa !24
  %t139 = load ptr, ptr %l62, !tbaa !29
  %t140 = load i64, ptr %l63, !tbaa !24
  %t141 = load { i64, [2 x i64] }, ptr %l67
  %t142 = load i64, ptr %l70, !tbaa !24
  %t143 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %t137, i64 %t138, ptr %t139, i64 %t140, { i64, [2 x i64] } %t141, i64 %t142)
  store i64 %t143, ptr %l71
  br label %bb45
bb45:
  %t144 = load i64, ptr %l71, !tbaa !24
  %t145 = icmp sge i64 %t144, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t145, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i32
  %l33 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l51 = alloca i1
  %l58 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb4:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l15
  br label %bb5
bb5:
  %t18 = load i1, ptr %l15, !tbaa !21
  store i1 %t18, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l19
  br label %bb9
bb9:
  %t25 = load i1, ptr %l19, !tbaa !21
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l16, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l24
  br label %bb14
bb14:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l24, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l25
  br label %bb15
bb15:
  %t37 = load i32, ptr %l25, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l28
  br label %bb16
bb16:
  %t43 = load i32, ptr %l28, !range !{i32 0, i32 33}
  store i32 %t43, ptr %l4
  %t44 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t46 = trunc i64 19 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l33
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t54 = load i1, ptr %l33, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
bb20:
  %t55 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t57 = trunc i64 18 to i32
  %t58 = icmp eq i32 %t55, %t57
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb24
bb22:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t62, i32 %t63)
  store i1 %t66, ptr %l40
  br label %bb23
bb23:
  %t67 = load i1, ptr %l40, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t70 = load i1, ptr %l37, !tbaa !21
  br i1 %t70, label %bb25, label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t72 = load ptr, ptr %l2, !tbaa !29
  store ptr %t72, ptr %l43, !tbaa !29
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t74 = load i32, ptr %l3, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l46
  br label %bb28
bb28:
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t79 = load i32, ptr %l46, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t78, i32 %t79)
  store i32 %t80, ptr %l47
  br label %bb29
bb29:
  %t81 = load i32, ptr %l47, !range !{i32 0, i32 6}
  store i32 %t81, ptr %l5
  %t82 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t84 = trunc i64 0 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb30, label %bb31
bb30:
  %t89 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t91 = trunc i64 1 to i32
  %t92 = icmp eq i32 %t89, %t91
  %t94 = xor i1 %t92, true
  store i1 %t94, ptr %l51, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t96 = load i1, ptr %l51, !tbaa !21
  br i1 %t96, label %bb33, label %bb34
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t98, i32 %t99)
  store i1 %t102, ptr %l58
  br label %bb36
bb36:
  %t103 = load i1, ptr %l58, !tbaa !21
  store i1 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l28 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i64
  %l39 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i64
  %l49 = alloca i1
  %l55 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = add i64 %t1, 2
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb30
bb3:
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t13, ptr %l15, !tbaa !27
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i64, ptr %t17, i64 %t14
  %t19 = load i64, ptr %t18, !tbaa !34
  store i64 %t19, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i64, ptr %t27, i64 %t24
  %t29 = load i64, ptr %t28, !tbaa !34
  store i64 %t29, ptr %l5, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t32, 2
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i64, ptr %t37, i64 %t34
  %t39 = load i64, ptr %t38, !tbaa !34
  store i64 %t39, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = icmp sge i64 %t41, 0
  br i1 %t43, label %bb5, label %bb6
bb5:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = icmp slt i64 %t45, 63
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t49 = load i1, ptr %l28, !tbaa !21
  br i1 %t49, label %bb8, label %bb9
bb8:
  %t50 = load i64, ptr %l2, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  store i64 %t51, ptr %l33, !tbaa !24
  %t52 = load i64, ptr %l33, !tbaa !24
  %t53 = load i64, ptr %l33, !tbaa !24
  %t54 = shl i64 1, %t53
  %t57 = and i64 %t50, %t54
  %t59 = icmp ne i64 %t57, 0
  store i1 %t59, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t61 = load i1, ptr %l31, !tbaa !21
  store i1 %t61, ptr %l7, !tbaa !21
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = icmp sge i64 %t62, 0
  br i1 %t64, label %bb11, label %bb12
bb11:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = icmp slt i64 %t66, 63
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t70 = load i1, ptr %l39, !tbaa !21
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t71 = load i64, ptr %l2, !tbaa !24
  %t72 = load i64, ptr %l5, !tbaa !24
  store i64 %t72, ptr %l44, !tbaa !24
  %t73 = load i64, ptr %l44, !tbaa !24
  %t74 = load i64, ptr %l44, !tbaa !24
  %t75 = shl i64 1, %t74
  %t78 = and i64 %t71, %t75
  %t80 = icmp ne i64 %t78, 0
  store i1 %t80, ptr %l42, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t82 = load i1, ptr %l42, !tbaa !21
  store i1 %t82, ptr %l8, !tbaa !21
  %t83 = load i1, ptr %l7, !tbaa !21
  br i1 %t83, label %bb17, label %bb18
bb17:
  %t85 = load i1, ptr %l8, !tbaa !21
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l49, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb19
bb19:
  %t89 = load i1, ptr %l49, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = icmp eq i64 %t91, 1
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = load i1, ptr %l7, !tbaa !21
  %t96 = load i1, ptr %l8, !tbaa !21
  %t99 = icmp ne i1 %t95, %t96
  store i1 %t99, ptr %l55, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb25
bb25:
  %t101 = load i1, ptr %l55, !tbaa !21
  br i1 %t101, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t103 = load i64, ptr %l3, !tbaa !24
  %t105 = add i64 %t103, 3
  store i64 %t105, ptr %l3, !tbaa !24
  br label %bb1
bb30:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereported(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/free:store"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i64
  %l24 = alloca i64
  %l29 = alloca %"compiler/free:store"
  %l33 = alloca i1
  %l36 = alloca i1
  %l40 = alloca i1
  %l51 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i1
  %l63 = alloca i64
  %l66 = alloca i1
  %l67 = alloca i64
  %l72 = alloca i64
  %l74 = alloca i1
  %l80 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i32
  %l101 = alloca i32
  %l106 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca i64
  %l113 = alloca i1
  %l114 = alloca i64
  %l119 = alloca i64
  %l121 = alloca i1
  %l127 = alloca ptr
  %l130 = alloca i1
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 5
  %t8 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Ha270003b2266a12c55eea6eacf9a4be1(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i64, ptr %l13, !tbaa !24
  %t10 = icmp sgt i64 %t9, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenPlace(ptr %v0, ptr %t12, i64 %t13)
  store i1 %t16, ptr %l18
  br label %bb4
bb3:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i1, ptr %l18, !tbaa !21
  store i1 %t17, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  store i1 false, ptr %l2, !tbaa !21
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/free:Free", ptr %t20, i32 0, i32 83
  store ptr %t22, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb9
bb9:
  %t24 = load i64, ptr %l4, !tbaa !24
  store i64 %t24, ptr %l22, !tbaa !24
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l24
  br label %bb10
bb10:
  %t28 = load i64, ptr %l22, !tbaa !24
  %t29 = load i64, ptr %l24, !tbaa !24
  %t30 = icmp slt i64 %t28, %t29
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb11, label %bb12
bb11:
  br label %bb28
bb12:
  br label %bb13
bb13:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t34, i64 %t35)
  store %"compiler/free:store" %t38, ptr %l29
  br label %bb14
bb14:
  %t39 = load %"compiler/free:store", ptr %l29
  store %"compiler/free:store" %t39, ptr %l5
  %t40 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 6
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = icmp sge i64 %t48, 0
  br i1 %t50, label %bb17, label %bb18
bb16:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb23
bb17:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb19
bb18:
  %t52 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 4
  %t53 = load i64, ptr %t52, !tbaa !24
  %t54 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t57 = icmp eq i64 %t53, %t54
  store i1 %t57, ptr %l36, !tbaa !21
  br label %bb19
bb19:
  %t59 = load i1, ptr %l36, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb22
bb21:
  %t60 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 4
  %t61 = load i64, ptr %t60, !tbaa !24
  %t62 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t65 = icmp eq i64 %t61, %t62
  store i1 %t65, ptr %l40, !tbaa !21
  br label %bb22
bb22:
  %t67 = load i1, ptr %l40, !tbaa !21
  store i1 %t67, ptr %l33, !tbaa !21
  br label %bb23
bb23:
  %t68 = load i1, ptr %l33, !tbaa !21
  br i1 %t68, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t69 = load i64, ptr %l4, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l4, !tbaa !24
  br label %bb9
bb28:
  %t73 = load i1, ptr %l2, !tbaa !21
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisContents(ptr %v0, ptr %t78, i64 %t79)
  store i1 %t82, ptr %l51
  br label %bb32
bb32:
  %t83 = load i1, ptr %l51, !tbaa !21
  br i1 %t83, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l1, !tbaa !24
  %t89 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisOwnLocal(ptr %v0, ptr %t85, i64 %t86)
  store i1 %t89, ptr %l55
  br label %bb36
bb36:
  %t90 = load i1, ptr %l55, !tbaa !21
  br i1 %t90, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i64, ptr %l1, !tbaa !24
  %t96 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisGlobal(ptr %v0, ptr %t92, i64 %t93)
  store i1 %t96, ptr %l59
  br label %bb40
bb40:
  %t97 = load i1, ptr %l59, !tbaa !21
  br i1 %t97, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/free:Free", ptr %t98, i32 0, i32 106
  %t101 = load i64, ptr %l1, !tbaa !24
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t100, i64 %t101)
  store i64 %t104, ptr %l63
  br label %bb43
bb42:
  br label %bb53
bb43:
  %t105 = load i64, ptr %l63, !tbaa !24
  store i64 %t105, ptr %l6, !tbaa !24
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = icmp sge i64 %t106, 0
  br i1 %t108, label %bb44, label %bb45
bb44:
  %t110 = load i64, ptr %l6, !tbaa !24
  store i64 %t110, ptr %l67, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/free:Free", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = getelementptr %"compiler/load:Loader", ptr %t117, i32 0, i32 10
  %t121 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t119)
  store i64 %t121, ptr %l72
  br label %bb46
bb45:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb47
bb46:
  %t122 = load i64, ptr %l67, !tbaa !24
  %t123 = load i64, ptr %l72, !tbaa !24
  %t124 = icmp slt i64 %t122, %t123
  store i1 %t124, ptr %l66, !tbaa !21
  br label %bb47
bb47:
  %t126 = load i1, ptr %l66, !tbaa !21
  br i1 %t126, label %bb48, label %bb49
bb48:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/free:Free", ptr %t127, i32 0, i32 0
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/load:Loader", ptr %t133, i32 0, i32 10
  %t136 = load i64, ptr %l6, !tbaa !24
  %t139 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t135, i64 %t136)
  store ptr %t139, ptr %l80
  br label %bb50
bb49:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb52
bb50:
  %t140 = load ptr, ptr %l80, !tbaa !29
  %t142 = getelementptr %"compiler/load:Module", ptr %t140, i32 0, i32 2
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  %t145 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s9, { i64, ptr } %t143, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t145, ptr %l83
  br label %bb51
bb51:
  %t146 = load i1, ptr %l83, !tbaa !21
  %t147 = xor i1 %t146, true
  store i1 %t147, ptr %l74, !tbaa !21
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t149 = load i1, ptr %l74, !tbaa !21
  store i1 %t149, ptr %rv
  br label %ret
bb53:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/free:Free", ptr %t150, i32 0, i32 10
  %t153 = load i64, ptr %l1, !tbaa !24
  %t156 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t152, i64 %t153)
  store i64 %t156, ptr %l88
  br label %bb54
bb54:
  %t157 = load i64, ptr %l88, !tbaa !24
  %t158 = icmp slt i64 %t157, 0
  br i1 %t158, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t161)
  store ptr %t163, ptr %l92
  br label %bb58
bb58:
  %t164 = load ptr, ptr %l92, !tbaa !29
  store ptr %t164, ptr %l7, !tbaa !29
  %t165 = load ptr, ptr %l7, !tbaa !29
  store ptr %t165, ptr %l93, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/free:Free", ptr %t166, i32 0, i32 9
  %t169 = load i64, ptr %l1, !tbaa !24
  %t172 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t168, i64 %t169)
  store i32 %t172, ptr %l97
  br label %bb59
bb59:
  %t173 = load ptr, ptr %l93, !tbaa !29
  %t174 = load i32, ptr %l97, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t175, ptr %l98
  br label %bb60
bb60:
  %t176 = load i32, ptr %l98, !tbaa !23
  store i32 %t176, ptr %l8, !tbaa !23
  %t177 = load ptr, ptr %l7, !tbaa !29
  %t178 = load i32, ptr %l8, !tbaa !23
  %t181 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l101
  br label %bb61
bb61:
  %t182 = load i32, ptr %l101, !range !{i32 0, i32 33}
  %t184 = trunc i64 18 to i32
  %t185 = icmp eq i32 %t182, %t184
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  %t190 = load ptr, ptr %l7, !tbaa !29
  store ptr %t190, ptr %l106, !tbaa !29
  %t191 = load ptr, ptr %l7, !tbaa !29
  %t192 = load i32, ptr %l8, !tbaa !23
  %t195 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t191, i32 %t192)
  store i32 %t195, ptr %l109
  br label %bb65
bb65:
  %t196 = load ptr, ptr %l106, !tbaa !29
  %t197 = load i32, ptr %l109, !tbaa !23
  %t198 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t196, i32 %t197)
  store i64 %t198, ptr %l110
  br label %bb66
bb66:
  %t199 = load i64, ptr %l110, !tbaa !24
  store i64 %t199, ptr %l9, !tbaa !24
  %t200 = load i64, ptr %l9, !tbaa !24
  %t202 = icmp sge i64 %t200, 0
  br i1 %t202, label %bb67, label %bb68
bb67:
  %t204 = load i64, ptr %l9, !tbaa !24
  store i64 %t204, ptr %l114, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/free:Free", ptr %t205, i32 0, i32 0
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 0
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/load:Loader", ptr %t211, i32 0, i32 10
  %t215 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t213)
  store i64 %t215, ptr %l119
  br label %bb69
bb68:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb70
bb69:
  %t216 = load i64, ptr %l114, !tbaa !24
  %t217 = load i64, ptr %l119, !tbaa !24
  %t218 = icmp slt i64 %t216, %t217
  store i1 %t218, ptr %l113, !tbaa !21
  br label %bb70
bb70:
  %t220 = load i1, ptr %l113, !tbaa !21
  br i1 %t220, label %bb71, label %bb72
bb71:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/free:Free", ptr %t221, i32 0, i32 0
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/generic:Program", ptr %t224, i32 0, i32 0
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/load:Loader", ptr %t227, i32 0, i32 10
  %t230 = load i64, ptr %l9, !tbaa !24
  %t233 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t229, i64 %t230)
  store ptr %t233, ptr %l127
  br label %bb73
bb72:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb75
bb73:
  %t234 = load ptr, ptr %l127, !tbaa !29
  %t236 = getelementptr %"compiler/load:Module", ptr %t234, i32 0, i32 2
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  %t239 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t237, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t239, ptr %l130
  br label %bb74
bb74:
  %t240 = load i1, ptr %l130, !tbaa !21
  %t241 = xor i1 %t240, true
  store i1 %t241, ptr %l121, !tbaa !21
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s0)
  %t243 = load i1, ptr %l121, !tbaa !21
  store i1 %t243, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erowBefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1, %"compiler/free:letGo" %a2) #0 {
entry:
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca %"compiler/free:letGo"
  %l16 = alloca i1
  %rv = alloca i1
  store %"compiler/free:letGo" %a1, ptr %l1
  store %"compiler/free:letGo" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 5
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t6 = icmp eq i64 %t2, %t3
  %t7 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 5
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t12 = icmp eq i64 %t8, %t9
  %t15 = icmp ne i1 %t6, %t12
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 5
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t22 = icmp eq i64 %t18, %t19
  store i1 %t22, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t25 = load %"compiler/free:letGo", ptr %l1
  %t26 = load %"compiler/free:letGo", ptr %l2
  %t30 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %t25, %"compiler/free:letGo" %t26)
  store i1 %t30, ptr %l16
  br label %bb4
bb4:
  %t31 = load i1, ptr %l16, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2escopeName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/free:letGo"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca i32
  %l26 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l37 = alloca i64
  %l39 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l58 = alloca i64
  %l60 = alloca i1
  %l63 = alloca i1
  %l67 = alloca i64
  %l69 = alloca i64
  %l74 = alloca %"compiler/free:letGo"
  %l78 = alloca i1
  %l84 = alloca { i64, ptr }
  %l86 = alloca i1
  %l88 = alloca { i64, ptr }
  %l90 = alloca i64
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %l100 = alloca i1
  %l103 = alloca i1
  %l104 = alloca i1
  %l107 = alloca i1
  %l108 = alloca i1
  %l115 = alloca i64
  %l116 = alloca i64
  %l124 = alloca ptr
  %l126 = alloca ptr
  %l129 = alloca i64
  %l133 = alloca i64
  %l136 = alloca i64
  %l157 = alloca ptr
  %l161 = alloca %"compiler/typed:Local"
  %l163 = alloca { i64, ptr }
  %l165 = alloca i1
  %l169 = alloca i64
  %l171 = alloca i64
  %l176 = alloca i32
  %l184 = alloca ptr
  %l188 = alloca %"compiler/typed:Local"
  %l190 = alloca i32
  %l193 = alloca i1
  %l194 = alloca ptr
  %l197 = alloca i32
  %l198 = alloca i32
  %l201 = alloca i32
  %l207 = alloca ptr
  %l208 = alloca ptr
  %l211 = alloca i32
  %l212 = alloca i32
  %l213 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l223 = alloca i64
  %l224 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/free:letGo", ptr %l1
  %t5 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %s0, ptr %t1, %"compiler/free:letGo" %t2)
  store { i64, ptr } %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisGlobal(ptr %v0, ptr %t7, i64 %t8)
  store i1 %t11, ptr %l29
  br label %bb2
bb2:
  %t12 = load i1, ptr %l29, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t13, ptr %l31, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l32, !tbaa !24
  %t16 = load i64, ptr %l32, !tbaa !24
  %t17 = mul i64 %t16, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l33, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l32, !tbaa !24
  %t26 = mul i64 %t25, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %t24, i64 %t26, i1 false)
  %t27 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t27, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t28 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t28, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 10
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l37
  br label %bb6
bb6:
  %t36 = load i64, ptr %l37, !tbaa !24
  %t37 = icmp slt i64 %t36, 0
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t41, ptr %l41
  br label %bb9
bb8:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb10
bb9:
  %t42 = load i1, ptr %l41, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l39, !tbaa !21
  br label %bb10
bb10:
  %t45 = load i1, ptr %l39, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l2, !tbaa !24
  %t50 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisNamed(ptr %v0, ptr %t46, i64 %t47)
  store i1 %t50, ptr %l46
  br label %bb13
bb12:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb14
bb13:
  %t51 = load i1, ptr %l46, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l43, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l43, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t55, ptr %l48, !tbaa !27
  br label %bb18
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load %"compiler/free:letGo", ptr %l1
  %t61 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %s0, ptr %t57, %"compiler/free:letGo" %t58)
  store { i64, ptr } %t61, ptr %l52
  br label %bb17
bb17:
  %t62 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t62, ptr %l48, !tbaa !27
  br label %bb18
bb18:
  %t63 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l53, !tbaa !24
  %t65 = load i64, ptr %l53, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l54, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l53, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t76, ptr %l4, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:Free", ptr %t77, i32 0, i32 10
  %t80 = load i64, ptr %l2, !tbaa !24
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t79, i64 %t80)
  store i64 %t83, ptr %l58
  br label %bb19
bb19:
  %t84 = load i64, ptr %l58, !tbaa !24
  %t85 = icmp slt i64 %t84, 0
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i64, ptr %l2, !tbaa !24
  %t91 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisNamed(ptr %v0, ptr %t87, i64 %t88)
  store i1 %t91, ptr %l63
  br label %bb22
bb21:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb23
bb22:
  %t92 = load i1, ptr %l63, !tbaa !21
  %t93 = xor i1 %t92, true
  store i1 %t93, ptr %l60, !tbaa !21
  br label %bb23
bb23:
  %t95 = load i1, ptr %l60, !tbaa !21
  br i1 %t95, label %bb24, label %bb25
bb24:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 84
  store ptr %t98, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb26
bb25:
  br label %bb48
bb26:
  %t100 = load i64, ptr %l6, !tbaa !24
  store i64 %t100, ptr %l67, !tbaa !24
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t101)
  store i64 %t103, ptr %l69
  br label %bb27
bb27:
  %t104 = load i64, ptr %l67, !tbaa !24
  %t105 = load i64, ptr %l69, !tbaa !24
  %t106 = icmp slt i64 %t104, %t105
  %t108 = xor i1 %t106, true
  br i1 %t108, label %bb28, label %bb29
bb28:
  br label %bb47
bb29:
  br label %bb30
bb30:
  %t110 = load ptr, ptr %l5, !tbaa !29
  %t111 = load i64, ptr %l6, !tbaa !24
  %t114 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t110, i64 %t111)
  store %"compiler/free:letGo" %t114, ptr %l74
  br label %bb31
bb31:
  %t115 = load %"compiler/free:letGo", ptr %l74
  store %"compiler/free:letGo" %t115, ptr %l7
  %t116 = getelementptr %"compiler/free:letGo", ptr %l7, i32 0, i32 0
  %t117 = load i64, ptr %t116, !tbaa !24
  %t118 = load i64, ptr %l2, !tbaa !24
  %t121 = icmp eq i64 %t117, %t118
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t123 = getelementptr %"compiler/free:letGo", ptr %l7, i32 0, i32 1
  %t124 = load i64, ptr %t123, !tbaa !24
  %t125 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t126 = load i64, ptr %t125, !tbaa !24
  %t129 = icmp eq i64 %t124, %t126
  store i1 %t129, ptr %l78, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb34
bb34:
  %t131 = load i1, ptr %l78, !tbaa !21
  br i1 %t131, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/free:letGo", ptr %l7
  %t136 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %s5, ptr %t132, %"compiler/free:letGo" %t133)
  store { i64, ptr } %t136, ptr %l84
  br label %bb37
bb36:
  br label %bb45
bb37:
  %t137 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t137, ptr %l8, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %s5, { i64, ptr } %t138, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t140, ptr %l86
  br label %bb38
bb38:
  %t141 = load i1, ptr %l86, !tbaa !21
  %t142 = xor i1 %t141, true
  br i1 %t142, label %bb39, label %bb40
bb39:
  %t144 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t144, ptr %l88, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l90, !tbaa !24
  %t150 = load i64, ptr %l90, !tbaa !24
  %t151 = icmp eq i64 %t146, %t150
  br i1 %t151, label %bb41, label %bb42
bb40:
  br label %bb44
bb41:
  %t153 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = load i64, ptr %l90, !tbaa !24
  %t158 = mul i64 %t157, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t154, ptr %t156, i64 %t158, i1 false)
  br label %bb43
bb42:
  %t159 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l92, !tbaa !24
  %t161 = load i64, ptr %l92, !tbaa !24
  %t162 = mul i64 %t161, 1
  %t163 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l93, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = load i64, ptr %l92, !tbaa !24
  %t171 = mul i64 %t170, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t167, ptr %t169, i64 %t171, i1 false)
  %t172 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t172, ptr %l4, !tbaa !27
  br label %bb43
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t173 = load i64, ptr %l6, !tbaa !24
  %t175 = add i64 %t173, 1
  store i64 %t175, ptr %l6, !tbaa !24
  br label %bb26
bb47:
  br label %bb48
bb48:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb49
bb49:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = icmp slt i64 %t177, %t180
  br i1 %t183, label %bb50, label %bb51
bb50:
  %t185 = load i64, ptr %l9, !tbaa !24
  %t187 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr i8, ptr %t188, i64 %t185
  %t190 = load i8, ptr %t189, !tbaa !32
  %t192 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t190)
  store i1 %t192, ptr %l103
  br label %bb52
bb51:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb60
bb52:
  %t193 = load i1, ptr %l103, !tbaa !21
  br i1 %t193, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb56
bb54:
  %t194 = load i64, ptr %l9, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i8, ptr %t197, i64 %t194
  %t199 = load i8, ptr %t198, !tbaa !32
  %t201 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t199)
  store i1 %t201, ptr %l107
  br label %bb55
bb55:
  %t202 = load i1, ptr %l107, !tbaa !21
  store i1 %t202, ptr %l104, !tbaa !21
  br label %bb56
bb56:
  %t203 = load i1, ptr %l104, !tbaa !21
  br i1 %t203, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb59
bb58:
  %t204 = load i64, ptr %l9, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i8, ptr %t207, i64 %t204
  %t209 = load i8, ptr %t208, !tbaa !32
  %t211 = icmp eq i8 %t209, 95
  store i1 %t211, ptr %l108, !tbaa !21
  br label %bb59
bb59:
  %t213 = load i1, ptr %l108, !tbaa !21
  store i1 %t213, ptr %l100, !tbaa !21
  br label %bb60
bb60:
  %t214 = load i1, ptr %l100, !tbaa !21
  %t215 = xor i1 %t214, true
  br i1 %t215, label %bb61, label %bb62
bb61:
  br label %bb65
bb62:
  br label %bb63
bb63:
  %t217 = load i64, ptr %l9, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l9, !tbaa !24
  br label %bb64
bb64:
  br label %bb49
bb65:
  %t221 = load i64, ptr %l9, !tbaa !24
  store i64 %t221, ptr %l115, !tbaa !24
  %t222 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  store i64 %t223, ptr %l116, !tbaa !24
  %t224 = icmp sge i64 0, 0
  br i1 %t224, label %bb66, label %bb67
bb66:
  %t226 = load i64, ptr %l115, !tbaa !24
  %t227 = icmp sle i64 0, %t226
  br i1 %t227, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c)
  unreachable
bb68:
  %t229 = load i64, ptr %l115, !tbaa !24
  %t230 = load i64, ptr %l116, !tbaa !24
  %t231 = icmp sle i64 %t229, %t230
  br i1 %t231, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c)
  unreachable
bb70:
  %t233 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = load i64, ptr %l115, !tbaa !24
  %t236 = getelementptr i8, ptr %t234, i64 0
  %t237 = sub i64 %t235, 0
  %t238 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t236, 1
  store { i64, ptr } %t239, ptr %l10, !tbaa !27
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/free:Free", ptr %t241, i32 0, i32 1
  %t244 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t245 = load i64, ptr %t244, !tbaa !24
  %t248 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t243, i64 %t245)
  store ptr %t248, ptr %l124
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c)
  unreachable
bb72:
  %t249 = load ptr, ptr %l124, !tbaa !29
  store ptr %t249, ptr %l11, !tbaa !29
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t250)
  store ptr %t252, ptr %l126
  br label %bb73
bb73:
  %t253 = load ptr, ptr %l126, !tbaa !29
  store ptr %t253, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t254 = load ptr, ptr %l11, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Body", ptr %t254, i32 0, i32 7
  %t258 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t256)
  store i64 %t258, ptr %l129
  br label %bb74
bb74:
  %t259 = load i64, ptr %l129, !tbaa !24
  store i64 %t259, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t260 = load i64, ptr %l14, !tbaa !24
  %t261 = load i64, ptr %l13, !tbaa !24
  %t264 = icmp sgt i64 %t260, %t261
  br i1 %t264, label %bb75, label %bb76
bb75:
  %t266 = load i64, ptr %l15, !tbaa !24
  %t268 = icmp sgt i64 %t266, 0
  br i1 %t268, label %bb77, label %bb78
bb76:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb80
bb77:
  %t270 = load i64, ptr %l14, !tbaa !24
  %t271 = load i64, ptr %l13, !tbaa !24
  %t274 = sub i64 %t270, %t271
  %t275 = load i64, ptr %l15, !tbaa !24
  %t278 = add i64 %t274, %t275
  %t280 = sub i64 %t278, 1
  %t281 = load i64, ptr %l15, !tbaa !24
  %t284 = sdiv i64 %t280, %t281
  store i64 %t284, ptr %l136, !tbaa !24
  br label %bb79
bb78:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb79
bb79:
  %t286 = load i64, ptr %l136, !tbaa !24
  store i64 %t286, ptr %l133, !tbaa !24
  br label %bb80
bb80:
  %t287 = load i64, ptr %l133, !tbaa !24
  store i64 %t287, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s10
  %t288 = load i64, ptr %l17, !tbaa !24
  %t289 = load i64, ptr %l16, !tbaa !24
  %t292 = icmp slt i64 %t288, %t289
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s10)
  br label %bb122
bb83:
  br label %bb84
bb84:
  %t296 = load i64, ptr %l13, !tbaa !24
  %t297 = load i64, ptr %l17, !tbaa !24
  %t298 = load i64, ptr %l15, !tbaa !24
  %t301 = mul i64 %t297, %t298
  %t304 = add i64 %t296, %t301
  store i64 %t304, ptr %l18, !tbaa !24
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/free:Free", ptr %t306, i32 0, i32 0
  %t309 = load ptr, ptr %t308, !tbaa !29
  %t311 = getelementptr %"compiler/generic:Program", ptr %t309, i32 0, i32 0
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = getelementptr %"compiler/load:Loader", ptr %t312, i32 0, i32 3
  %t315 = load ptr, ptr %t314, !tbaa !29
  store ptr %t315, ptr %l157, !tbaa !29
  %t316 = load ptr, ptr %l11, !tbaa !29
  %t318 = getelementptr %"compiler/typed:Body", ptr %t316, i32 0, i32 7
  %t319 = load i64, ptr %l18, !tbaa !24
  %t322 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t318, i64 %t319)
  store %"compiler/typed:Local" %t322, ptr %l161
  br label %bb85
bb85:
  %t323 = getelementptr %"compiler/typed:Local", ptr %l161, i32 0, i32 0
  %t324 = load i32, ptr %t323, !tbaa !23
  %t325 = load ptr, ptr %l157, !tbaa !29
  %t327 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t325, i32 %t324)
  store { i64, ptr } %t327, ptr %l163
  br label %bb86
bb86:
  %t328 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t329 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t331 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t329, { i64, ptr } %t328)
  store i1 %t331, ptr %l165
  br label %bb87
bb87:
  %t332 = load i1, ptr %l165, !tbaa !21
  %t333 = xor i1 %t332, true
  br i1 %t333, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s10)
  br label %bb121
bb89:
  br label %bb90
bb90:
  store i1 false, ptr %l19, !tbaa !21
  %t335 = load ptr, ptr %l11, !tbaa !29
  %t337 = getelementptr %"compiler/typed:Body", ptr %t335, i32 0, i32 5
  store ptr %t337, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb91
bb91:
  %t339 = load i64, ptr %l21, !tbaa !24
  store i64 %t339, ptr %l169, !tbaa !24
  %t340 = load ptr, ptr %l20, !tbaa !29
  %t342 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t340)
  store i64 %t342, ptr %l171
  br label %bb92
bb92:
  %t343 = load i64, ptr %l169, !tbaa !24
  %t344 = load i64, ptr %l171, !tbaa !24
  %t345 = icmp slt i64 %t343, %t344
  %t347 = xor i1 %t345, true
  br i1 %t347, label %bb93, label %bb94
bb93:
  br label %bb101
bb94:
  br label %bb95
bb95:
  %t349 = load ptr, ptr %l20, !tbaa !29
  %t350 = load i64, ptr %l21, !tbaa !24
  %t353 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t349, i64 %t350)
  store i32 %t353, ptr %l176
  br label %bb96
bb96:
  %t354 = load i32, ptr %l176, !tbaa !23
  %t357 = sext i32 %t354 to i64
  %t358 = load i64, ptr %l18, !tbaa !24
  %t361 = icmp eq i64 %t357, %t358
  br i1 %t361, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb99
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t363 = load i64, ptr %l21, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l21, !tbaa !24
  br label %bb91
bb101:
  %t367 = load i1, ptr %l19, !tbaa !21
  br i1 %t367, label %bb102, label %bb103
bb102:
  %t369 = load ptr, ptr %l12, !tbaa !29
  store ptr %t369, ptr %l184, !tbaa !29
  %t370 = load ptr, ptr %l11, !tbaa !29
  %t372 = getelementptr %"compiler/typed:Body", ptr %t370, i32 0, i32 7
  %t373 = load i64, ptr %l18, !tbaa !24
  %t376 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t372, i64 %t373)
  store %"compiler/typed:Local" %t376, ptr %l188
  br label %bb104
bb103:
  br label %bb119
bb104:
  %t377 = getelementptr %"compiler/typed:Local", ptr %l188, i32 0, i32 2
  %t378 = load i32, ptr %t377, !tbaa !23
  %t379 = load ptr, ptr %l184, !tbaa !29
  %t381 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t379, i32 %t378)
  store i32 %t381, ptr %l190
  br label %bb105
bb105:
  %t382 = load i32, ptr %l190, !tbaa !23
  store i32 %t382, ptr %l23, !tbaa !23
  %t383 = load ptr, ptr %l12, !tbaa !29
  %t384 = load i32, ptr %l23, !tbaa !23
  %t387 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t383, i32 %t384)
  store i1 %t387, ptr %l193
  br label %bb106
bb106:
  %t388 = load i1, ptr %l193, !tbaa !21
  br i1 %t388, label %bb107, label %bb108
bb107:
  %t389 = load ptr, ptr %l12, !tbaa !29
  store ptr %t389, ptr %l194, !tbaa !29
  %t390 = load ptr, ptr %l12, !tbaa !29
  %t391 = load i32, ptr %l23, !tbaa !23
  %t394 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t390, i32 %t391)
  store i32 %t394, ptr %l197
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t395 = load ptr, ptr %l194, !tbaa !29
  %t396 = load i32, ptr %l197, !tbaa !23
  %t397 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t395, i32 %t396)
  store i32 %t397, ptr %l198
  br label %bb110
bb110:
  %t398 = load i32, ptr %l198, !tbaa !23
  store i32 %t398, ptr %l23, !tbaa !23
  br label %bb111
bb111:
  %t399 = load ptr, ptr %l12, !tbaa !29
  %t400 = load i32, ptr %l23, !tbaa !23
  %t403 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t399, i32 %t400)
  store i32 %t403, ptr %l201
  br label %bb112
bb112:
  %t404 = load i32, ptr %l201, !range !{i32 0, i32 33}
  %t406 = trunc i64 18 to i32
  %t407 = icmp eq i32 %t404, %t406
  br i1 %t407, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s18
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/free:Free", ptr %t409, i32 0, i32 0
  %t412 = load ptr, ptr %t411, !tbaa !29
  %t414 = getelementptr %"compiler/generic:Program", ptr %t412, i32 0, i32 0
  %t415 = load ptr, ptr %t414, !tbaa !29
  %t417 = getelementptr %"compiler/load:Loader", ptr %t415, i32 0, i32 3
  %t418 = load ptr, ptr %t417, !tbaa !29
  store ptr %t418, ptr %l207, !tbaa !29
  %t419 = load ptr, ptr %l12, !tbaa !29
  store ptr %t419, ptr %l208, !tbaa !29
  %t420 = load ptr, ptr %l12, !tbaa !29
  %t421 = load i32, ptr %l23, !tbaa !23
  %t424 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t420, i32 %t421)
  store i32 %t424, ptr %l211
  br label %bb115
bb114:
  br label %bb118
bb115:
  %t425 = load ptr, ptr %l208, !tbaa !29
  %t426 = load i32, ptr %l211, !tbaa !23
  %t427 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t425, i32 %t426)
  store i32 %t427, ptr %l212
  br label %bb116
bb116:
  %t428 = load ptr, ptr %l207, !tbaa !29
  %t429 = load i32, ptr %l212, !tbaa !23
  %t430 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s18, ptr %t428, i32 %t429)
  store { i64, ptr } %t430, ptr %l213
  br label %bb117
bb117:
  %t431 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t432 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t433 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t433, 1
  %t435 = extractvalue { i64, ptr } %t433, 0
  %t436 = add i64 %t432, %t435
  %t437 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t438 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t439 = add i64 %t436, %t438
  %t440 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t439)
  call void @olang_textcopy(ptr %t440, ptr %t431, i64 %t432)
  %t441 = getelementptr i8, ptr %t440, i64 %t432
  call void @olang_textcopy(ptr %t441, ptr %t434, i64 %t435)
  %t442 = getelementptr i8, ptr %t441, i64 %t435
  call void @olang_textcopy(ptr %t442, ptr %t437, i64 %t438)
  %t443 = insertvalue { i64, ptr } undef, i64 %t439, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t440, 1
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t444, ptr %rv
  br label %ret
bb118:
  br label %bb119
bb119:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t448 = load i64, ptr %t447, !tbaa !24
  %t451 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s10, ptr %t446, i64 %t448)
  store { i64, ptr } %t451, ptr %l217
  br label %bb120
bb120:
  %t452 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 1
  %t454 = extractvalue { i64, ptr } %t452, 0
  %t455 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t456 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t457 = add i64 %t454, %t456
  %t458 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t457)
  call void @olang_textcopy(ptr %t458, ptr %t453, i64 %t454)
  %t459 = getelementptr i8, ptr %t458, i64 %t454
  call void @olang_textcopy(ptr %t459, ptr %t455, i64 %t456)
  %t460 = insertvalue { i64, ptr } undef, i64 %t457, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t458, 1
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t461, ptr %rv
  br label %ret
bb121:
  %t463 = load i64, ptr %l17, !tbaa !24
  %t465 = add i64 %t463, 1
  store i64 %t465, ptr %l17, !tbaa !24
  br label %bb81
bb122:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l221, !tbaa !27
  %t467 = load { i64, ptr }, ptr %l221, !tbaa !27
  store { i64, ptr } %t467, ptr %l222, !tbaa !27
  %t468 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t468, 0
  store i64 %t469, ptr %l223, !tbaa !24
  %t470 = load i64, ptr %l223, !tbaa !24
  %t471 = mul i64 %t470, 1
  %t472 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t471)
  %t473 = insertvalue { i64, ptr } undef, i64 %t470, 0
  %t474 = insertvalue { i64, ptr } %t473, ptr %t472, 1
  store { i64, ptr } %t474, ptr %l224, !tbaa !27
  %t475 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !27
  %t477 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !27
  %t479 = load i64, ptr %l223, !tbaa !24
  %t480 = mul i64 %t479, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t476, ptr %t478, i64 %t480, i1 false)
  %t481 = load { i64, ptr }, ptr %l224, !tbaa !27
  store { i64, ptr } %t481, ptr %l222, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t482 = load { i64, ptr }, ptr %l222, !tbaa !27
  store { i64, ptr } %t482, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitPath(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i32
  %l25 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l42 = alloca i1
  %l44 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l61 = alloca i1
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l71 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = load i32, ptr %l12, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l13
  br label %bb3
bb3:
  %t14 = load i32, ptr %l13, !tbaa !23
  store i32 %t14, ptr %l5, !tbaa !23
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t21 = icmp sge i64 %t15, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb5:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = load i32, ptr %l5, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l21
  br label %bb6
bb6:
  %t28 = load i32, ptr %l21, !range !{i32 0, i32 33}
  %t30 = trunc i64 18 to i32
  %t31 = icmp eq i32 %t28, %t30
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l18, !tbaa !21
  br i1 %t35, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb11
bb9:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t37 = load i32, ptr %l5, !tbaa !23
  %t40 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l28
  br label %bb10
bb10:
  %t41 = load i1, ptr %l28, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l25, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb16
bb13:
  %t45 = load ptr, ptr %l4, !tbaa !29
  store ptr %t45, ptr %l31, !tbaa !29
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t47 = load i32, ptr %l5, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l34
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l31, !tbaa !29
  %t52 = load i32, ptr %l34, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t53, ptr %l35
  br label %bb15
bb15:
  %t54 = load i32, ptr %l35, !range !{i32 0, i32 6}
  %t56 = trunc i64 0 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t61 = load i1, ptr %l30, !tbaa !21
  br i1 %t61, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = load i32, ptr %l5, !tbaa !23
  %t67 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %t63, i32 %t64)
  store i1 %t67, ptr %l42
  br label %bb20
bb20:
  %t68 = load i1, ptr %l42, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t70 = load ptr, ptr %l4, !tbaa !29
  store ptr %t70, ptr %l44, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t72 = load i32, ptr %l5, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l47
  br label %bb24
bb24:
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t77 = load i32, ptr %l47, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t76, i32 %t77)
  store { i64, ptr } %t78, ptr %l48
  br label %bb25
bb25:
  %t79 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t79, ptr %l6, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t80, ptr %l49, !tbaa !27
  %t81 = load i64, ptr %l3, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr i64, ptr %t84, i64 %t81
  %t86 = load i64, ptr %t85, !tbaa !34
  %t87 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t92 = icmp sge i64 %t86, %t89
  br i1 %t92, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t95 = load i64, ptr %l3, !tbaa !24
  %t97 = add i64 %t95, 1
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t103 = icmp sge i64 %t97, %t100
  br i1 %t103, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb32
bb30:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t106, ptr %l63, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t107, ptr %l64, !tbaa !27
  %t108 = load i64, ptr %l3, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i64, ptr %t111, i64 %t108
  %t113 = load i64, ptr %t112, !tbaa !34
  %t115 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t113
  %t118 = load i32, ptr %t117, !tbaa !33
  %t119 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t120 = load i64, ptr %l3, !tbaa !24
  %t122 = add i64 %t120, 1
  %t127 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitPath(ptr %v0, ptr %v1, ptr %t105, i32 %t118, { i64, ptr } %t119, i64 %t122)
  store i1 %t127, ptr %l71
  br label %bb31
bb31:
  %t128 = load i1, ptr %l71, !tbaa !21
  store i1 %t128, ptr %l61, !tbaa !21
  br label %bb32
bb32:
  %t129 = load i1, ptr %l61, !tbaa !21
  store i1 %t129, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etryMayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l52 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Try", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l15, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Try", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_7b3dede47d025484_fbd5a3b64af54730)
  unreachable
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Try", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t24 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t22, ptr %t21)
  store i1 %t24, ptr %l21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l21, !tbaa !21
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l14, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Try", ptr %t28, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb12, label %bb13
bb12:
  br label %bb29
bb13:
  br label %bb14
bb14:
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l31, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 %t46
  %t51 = load ptr, ptr %t50, !tbaa !39
  store ptr %t51, ptr %l5, !tbaa !29
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Clause", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb15, label %bb16
bb15:
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Clause", ptr %t63, i32 0, i32 4
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb19, label %bb20
bb19:
  br label %bb27
bb20:
  br label %bb21
bb21:
  %t80 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t80, ptr %l47, !tbaa !27
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr ptr, ptr %t84, i64 %t81
  %t86 = load ptr, ptr %t85, !tbaa !39
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t92 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t88, ptr %t86)
  store i1 %t92, ptr %l52
  br label %bb22
bb22:
  %t93 = load i1, ptr %l52, !tbaa !21
  br i1 %t93, label %bb23, label %bb24
bb23:
  store i1 true, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l7, !tbaa !24
  br label %bb18
bb27:
  br label %bb28
bb28:
  %t99 = load i64, ptr %l3, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l3, !tbaa !24
  br label %bb11
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l39 = alloca i64
  %l40 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 1
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l18
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l18, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t27, ptr %l2
  %t29 = load { i64, [2 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t35 = getelementptr { i64 }, ptr %t34, i32 0, i32 0
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb16
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/free:Free", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 6
  %t47 = load i64, ptr %l3, !tbaa !24
  %t50 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t46, i64 %t47)
  %t51 = extractvalue { i32, i64 } %t50, 1
  %t52 = extractvalue { i32, i64 } %t50, 0
  store i32 %t52, ptr %l32
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb13, label %ok.54, !prof !99
ok.54:
  store i64 %t51, ptr %l31
  br label %bb12
bb12:
  %t55 = load i64, ptr %l31, !tbaa !24
  store i64 %t55, ptr %l25, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb15
bb15:
  %t56 = load i64, ptr %l25, !tbaa !24
  store i64 %t56, ptr %l21, !tbaa !24
  br label %bb32
bb16:
  %t57 = load { i64, [2 x i64] }, ptr %l2
  %t59 = extractvalue { i64, [2 x i64] } %t57, 0
  %t60 = icmp eq i64 %t59, 1
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t62 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t63 = getelementptr { i32, i32 }, ptr %t62, i32 0, i32 0
  %t64 = load i32, ptr %t63
  store i32 %t64, ptr %l4, !tbaa !23
  %t66 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t67 = getelementptr { i32, i32 }, ptr %t66, i32 0, i32 1
  %t68 = load i32, ptr %t67
  store i32 %t68, ptr %l5, !tbaa !23
  br label %bb19
bb18:
  br label %bb27
bb19:
  %t70 = load i32, ptr %l5, !tbaa !23
  %t72 = icmp eq i32 %t70, 0
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/load:Loader", ptr %t80, i32 0, i32 7
  %t83 = load i32, ptr %l4, !tbaa !23
  %t85 = sext i32 %t83 to i64
  %t88 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t82, i64 %t85)
  %t89 = extractvalue { i32, i64 } %t88, 1
  %t90 = extractvalue { i32, i64 } %t88, 0
  store i32 %t90, ptr %l48
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb23, label %ok.92, !prof !99
ok.92:
  store i64 %t89, ptr %l47
  br label %bb22
bb21:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb26
bb22:
  %t93 = load i64, ptr %l47, !tbaa !24
  store i64 %t93, ptr %l40, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb25
bb25:
  %t94 = load i64, ptr %l40, !tbaa !24
  store i64 %t94, ptr %l39, !tbaa !24
  br label %bb26
bb26:
  %t95 = load i64, ptr %l39, !tbaa !24
  store i64 %t95, ptr %l21, !tbaa !24
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_12d027853a0706eb_617ec39b0606fdd7)
  unreachable
bb32:
  %t96 = load i64, ptr %l21, !tbaa !24
  store i64 %t96, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i1
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i1
  %l67 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l18
  br label %bb6
bb6:
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = load i64, ptr %l18, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = load i32, ptr %l3, !tbaa !23
  %t29 = sext i32 %t27 to i64
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t26, i64 %t29)
  store i64 %t32, ptr %l24
  br label %bb9
bb8:
  %t33 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t33, ptr %l20, !tbaa !24
  br label %bb10
bb9:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  br label %bb10
bb10:
  %t36 = load i64, ptr %l20, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  br label %bb44
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  store ptr %t37, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 8}
  %t44 = icmp eq i64 %t42, 3
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t58 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t52, ptr %t53, ptr %t54)
  store i64 %t58, ptr %l35
  br label %bb17
bb17:
  %t59 = load i64, ptr %l35, !tbaa !24
  store i64 %t59, ptr %l8, !tbaa !24
  br label %bb44
bb18:
  %t60 = load ptr, ptr %l2, !tbaa !29
  store ptr %t60, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 8}
  %t67 = icmp eq i64 %t65, 4
  store i1 %t67, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Elem", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t84 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t75, ptr %t76, ptr %t80)
  store i64 %t84, ptr %l46
  br label %bb24
bb24:
  %t85 = load i64, ptr %l46, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb44
bb25:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t87 = load ptr, ptr %l47, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l47, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 8}
  %t93 = icmp eq i64 %t91, 5
  store i1 %t93, ptr %l48, !tbaa !21
  br label %bb27
bb27:
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Payload", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t110 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, ptr %t106)
  store i64 %t110, ptr %l57
  br label %bb31
bb31:
  %t111 = load i64, ptr %l57, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb44
bb32:
  %t112 = load ptr, ptr %l2, !tbaa !29
  store ptr %t112, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t113 = load ptr, ptr %l58, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb33, label %bb34
bb33:
  %t116 = load ptr, ptr %l58, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 8}
  %t119 = icmp eq i64 %t117, 2
  store i1 %t119, ptr %l59, !tbaa !21
  br label %bb34
bb34:
  %t120 = load i1, ptr %l59, !tbaa !21
  br i1 %t120, label %bb35, label %bb36
bb35:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t123, i32 0, i32 2
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load ptr, ptr %l7, !tbaa !29
  %t133 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t127, ptr %t128, ptr %t129)
  store i64 %t133, ptr %l67
  br label %bb38
bb38:
  %t134 = load i64, ptr %l67, !tbaa !24
  store i64 %t134, ptr %l8, !tbaa !24
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t135 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t135, ptr %l8, !tbaa !24
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_6cb79447255537d7_e828faabaec907d3)
  unreachable
bb44:
  %t137 = load i64, ptr %l8, !tbaa !24
  store i64 %t137, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  %l46 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i1
  %l77 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l124 = alloca ptr
  %l145 = alloca ptr
  %l156 = alloca ptr
  %l157 = alloca i1
  %l166 = alloca ptr
  %l180 = alloca { i64, ptr }
  %l187 = alloca ptr
  %l195 = alloca ptr
  %l196 = alloca i1
  %l209 = alloca { i64, ptr }
  %l216 = alloca ptr
  %l217 = alloca i1
  %l226 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t2 = load ptr, ptr %l32, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l32, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l33, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l33, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Seq", ptr %t16, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l46, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %t41, ptr %t39)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb6
bb12:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Seq", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l57, !tbaa !29
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Seq", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb15, label %bb16
bb14:
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_14962ab25e47b4fc_3749941476b1d040)
  unreachable
bb16:
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Seq", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load ptr, ptr %l57, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t70, ptr %t69)
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb134
bb20:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t73 = load ptr, ptr %l63, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = load ptr, ptr %l63, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 13
  store i1 %t79, ptr %l64, !tbaa !21
  br label %bb22
bb22:
  %t80 = load i1, ptr %l64, !tbaa !21
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l7, !tbaa !29
  br label %bb25
bb24:
  br label %bb76
bb25:
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Match", ptr %t87, i32 0, i32 0
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  store { i64, ptr } %t90, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l10, !tbaa !24
  br label %bb26
bb26:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t100 = icmp slt i64 %t96, %t97
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t104 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t104, ptr %l77, !tbaa !27
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr ptr, ptr %t108, i64 %t105
  %t110 = load ptr, ptr %t109, !tbaa !39
  %t112 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %t112, ptr %t110)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t116 = load i64, ptr %l9, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l9, !tbaa !24
  br label %bb26
bb32:
  %t120 = load ptr, ptr %l7, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Match", ptr %t120, i32 0, i32 1
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  store i64 %t127, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb34, label %bb35
bb34:
  br label %bb59
bb35:
  br label %bb36
bb36:
  %t137 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t137, ptr %l92, !tbaa !27
  %t138 = load i64, ptr %l13, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr ptr, ptr %t141, i64 %t138
  %t143 = load ptr, ptr %t142, !tbaa !39
  store ptr %t143, ptr %l15, !tbaa !29
  %t145 = load ptr, ptr %l15, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Arm", ptr %t145, i32 0, i32 1
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  store i64 %t152, ptr %l18, !tbaa !24
  br label %bb37
bb37:
  %t154 = load i64, ptr %l17, !tbaa !24
  %t155 = load i64, ptr %l18, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb38, label %bb39
bb38:
  br label %bb43
bb39:
  br label %bb40
bb40:
  %t162 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t162, ptr %l103, !tbaa !27
  %t163 = load i64, ptr %l17, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr ptr, ptr %t166, i64 %t163
  %t168 = load ptr, ptr %t167, !tbaa !39
  %t170 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2ebinds(ptr %v0, ptr %v1, ptr %t170, ptr %t168)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t174 = load i64, ptr %l17, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l17, !tbaa !24
  br label %bb37
bb43:
  %t178 = load ptr, ptr %l15, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Arm", ptr %t178, i32 0, i32 3
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = icmp eq ptr %t181, null
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb44, label %bb45
bb44:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l114, !tbaa !29
  %t188 = load ptr, ptr %l15, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Arm", ptr %t188, i32 0, i32 3
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = icmp eq ptr %t191, null
  br i1 %t193, label %bb46, label %bb47
bb45:
  br label %bb50
bb46:
  call void @__olang_check_failed(ptr @olang_loc_8d35557863f6e46b_2765f8f7d1e0ebdf)
  unreachable
bb47:
  br label %bb48
bb48:
  %t195 = load ptr, ptr %l15, !tbaa !29
  %t197 = getelementptr %"compiler/typed:Arm", ptr %t195, i32 0, i32 3
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t199 = load ptr, ptr %l114, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t199, ptr %t198)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t201 = load ptr, ptr %l15, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Arm", ptr %t201, i32 0, i32 4
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = icmp eq ptr %t204, null
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb51, label %bb52
bb51:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l124, !tbaa !29
  %t211 = load ptr, ptr %l15, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Arm", ptr %t211, i32 0, i32 4
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = icmp eq ptr %t214, null
  br i1 %t216, label %bb53, label %bb54
bb52:
  br label %bb57
bb53:
  call void @__olang_check_failed(ptr @olang_loc_502532e2e95f04ea_fe436d8dc2f78aae)
  unreachable
bb54:
  br label %bb55
bb55:
  %t218 = load ptr, ptr %l15, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Arm", ptr %t218, i32 0, i32 4
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t222 = load ptr, ptr %l124, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t222, ptr %t221)
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t224 = load i64, ptr %l13, !tbaa !24
  %t226 = add i64 %t224, 1
  store i64 %t226, ptr %l13, !tbaa !24
  br label %bb33
bb59:
  %t228 = load ptr, ptr %l7, !tbaa !29
  %t230 = getelementptr %"compiler/typed:Match", ptr %t228, i32 0, i32 2
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = icmp eq ptr %t231, null
  %t235 = xor i1 %t233, true
  br i1 %t235, label %bb60, label %bb61
bb60:
  %t237 = load ptr, ptr %l7, !tbaa !29
  %t239 = getelementptr %"compiler/typed:Match", ptr %t237, i32 0, i32 2
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = icmp eq ptr %t240, null
  br i1 %t242, label %bb62, label %bb63
bb61:
  br label %bb75
bb62:
  call void @__olang_check_failed(ptr @olang_loc_ba297c355e3740f1_9975a70d069e6a55)
  unreachable
bb63:
  br label %bb64
bb64:
  %t244 = load ptr, ptr %l7, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Match", ptr %t244, i32 0, i32 2
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t250 = getelementptr %"compiler/typed:Arm", ptr %t247, i32 0, i32 3
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t253 = icmp eq ptr %t251, null
  %t255 = xor i1 %t253, true
  br i1 %t255, label %bb65, label %bb66
bb65:
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l145, !tbaa !29
  %t258 = load ptr, ptr %l7, !tbaa !29
  %t260 = getelementptr %"compiler/typed:Match", ptr %t258, i32 0, i32 2
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t263 = icmp eq ptr %t261, null
  br i1 %t263, label %bb67, label %bb68
bb66:
  br label %bb74
bb67:
  call void @__olang_check_failed(ptr @olang_loc_ba297c355e3740f1_9975a70d069e6a55)
  unreachable
bb68:
  br label %bb69
bb69:
  %t265 = load ptr, ptr %l7, !tbaa !29
  %t267 = getelementptr %"compiler/typed:Match", ptr %t265, i32 0, i32 2
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t271 = getelementptr %"compiler/typed:Arm", ptr %t268, i32 0, i32 3
  %t272 = load ptr, ptr %t271, !tbaa !29
  store ptr %t272, ptr %l20, !tbaa !29
  %t274 = load ptr, ptr %l20, !tbaa !29
  %t276 = icmp eq ptr %t274, null
  br i1 %t276, label %bb70, label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_ba297c355e3740f1_9975a70d069e6a55)
  unreachable
bb71:
  br label %bb72
bb72:
  %t278 = load ptr, ptr %l20, !tbaa !29
  %t279 = load ptr, ptr %l145, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t279, ptr %t278)
  br label %bb73
bb73:
  br label %bb74
bb74:
  br label %bb75
bb75:
  br label %bb134
bb76:
  %t281 = load ptr, ptr %l1, !tbaa !29
  store ptr %t281, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t282 = load ptr, ptr %l156, !tbaa !29
  %t283 = icmp ne ptr %t282, null
  br i1 %t283, label %bb77, label %bb78
bb77:
  %t285 = load ptr, ptr %l156, !tbaa !29
  %t286 = load i64, ptr %t285, !range !{i64 0, i64 18}
  %t288 = icmp eq i64 %t286, 14
  store i1 %t288, ptr %l157, !tbaa !21
  br label %bb78
bb78:
  %t289 = load i1, ptr %l157, !tbaa !21
  br i1 %t289, label %bb79, label %bb80
bb79:
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t292 = getelementptr { i64, [5 x i64] }, ptr %t290, i32 0, i32 1
  %t293 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t292, i32 0, i32 2
  %t294 = load ptr, ptr %t293
  store ptr %t294, ptr %l21, !tbaa !29
  br label %bb81
bb80:
  br label %bb102
bb81:
  %t296 = load ptr, ptr %l21, !tbaa !29
  %t298 = getelementptr %"compiler/typed:Try", ptr %t296, i32 0, i32 0
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = icmp eq ptr %t299, null
  %t303 = xor i1 %t301, true
  br i1 %t303, label %bb82, label %bb83
bb82:
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l166, !tbaa !29
  %t306 = load ptr, ptr %l21, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Try", ptr %t306, i32 0, i32 0
  %t309 = load ptr, ptr %t308, !tbaa !29
  %t311 = icmp eq ptr %t309, null
  br i1 %t311, label %bb84, label %bb85
bb83:
  br label %bb88
bb84:
  call void @__olang_check_failed(ptr @olang_loc_bb85040a6a786cb8_20e886069e3b9c04)
  unreachable
bb85:
  br label %bb86
bb86:
  %t313 = load ptr, ptr %l21, !tbaa !29
  %t315 = getelementptr %"compiler/typed:Try", ptr %t313, i32 0, i32 0
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t317 = load ptr, ptr %l166, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t317, ptr %t316)
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t319 = load ptr, ptr %l21, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Try", ptr %t319, i32 0, i32 1
  %t322 = load { i64, ptr }, ptr %t321, !tbaa !27
  store { i64, ptr } %t322, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t324 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t324, 0
  store i64 %t326, ptr %l24, !tbaa !24
  br label %bb89
bb89:
  %t328 = load i64, ptr %l23, !tbaa !24
  %t329 = load i64, ptr %l24, !tbaa !24
  %t332 = icmp slt i64 %t328, %t329
  %t334 = xor i1 %t332, true
  br i1 %t334, label %bb90, label %bb91
bb90:
  br label %bb101
bb91:
  br label %bb92
bb92:
  %t336 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t336, ptr %l180, !tbaa !27
  %t337 = load i64, ptr %l23, !tbaa !24
  %t339 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = getelementptr ptr, ptr %t340, i64 %t337
  %t342 = load ptr, ptr %t341, !tbaa !39
  store ptr %t342, ptr %l25, !tbaa !29
  %t344 = load ptr, ptr %l25, !tbaa !29
  %t346 = getelementptr %"compiler/typed:Clause", ptr %t344, i32 0, i32 3
  %t347 = load ptr, ptr %t346, !tbaa !29
  %t349 = icmp eq ptr %t347, null
  %t351 = xor i1 %t349, true
  br i1 %t351, label %bb93, label %bb94
bb93:
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l187, !tbaa !29
  %t354 = load ptr, ptr %l25, !tbaa !29
  %t356 = getelementptr %"compiler/typed:Clause", ptr %t354, i32 0, i32 3
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t359 = icmp eq ptr %t357, null
  br i1 %t359, label %bb95, label %bb96
bb94:
  br label %bb99
bb95:
  call void @__olang_check_failed(ptr @olang_loc_be187497b97f18d7_9641cb8c9c409d3)
  unreachable
bb96:
  br label %bb97
bb97:
  %t361 = load ptr, ptr %l25, !tbaa !29
  %t363 = getelementptr %"compiler/typed:Clause", ptr %t361, i32 0, i32 3
  %t364 = load ptr, ptr %t363, !tbaa !29
  %t365 = load ptr, ptr %l187, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t365, ptr %t364)
  br label %bb98
bb98:
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t367 = load i64, ptr %l23, !tbaa !24
  %t369 = add i64 %t367, 1
  store i64 %t369, ptr %l23, !tbaa !24
  br label %bb89
bb101:
  br label %bb134
bb102:
  %t371 = load ptr, ptr %l1, !tbaa !29
  store ptr %t371, ptr %l195, !tbaa !29
  store i1 false, ptr %l196, !tbaa !21
  %t372 = load ptr, ptr %l195, !tbaa !29
  %t373 = icmp ne ptr %t372, null
  br i1 %t373, label %bb103, label %bb104
bb103:
  %t375 = load ptr, ptr %l195, !tbaa !29
  %t376 = load i64, ptr %t375, !range !{i64 0, i64 18}
  %t378 = icmp eq i64 %t376, 6
  store i1 %t378, ptr %l196, !tbaa !21
  br label %bb104
bb104:
  %t379 = load i1, ptr %l196, !tbaa !21
  br i1 %t379, label %bb105, label %bb106
bb105:
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t382, i32 0, i32 2
  %t384 = load ptr, ptr %t383
  store ptr %t384, ptr %l26, !tbaa !29
  br label %bb107
bb106:
  br label %bb115
bb107:
  %t386 = load ptr, ptr %l26, !tbaa !29
  %t388 = getelementptr %"compiler/typed:Call", ptr %t386, i32 0, i32 1
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  store { i64, ptr } %t389, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t391 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t391, 0
  store i64 %t393, ptr %l29, !tbaa !24
  br label %bb108
bb108:
  %t395 = load i64, ptr %l28, !tbaa !24
  %t396 = load i64, ptr %l29, !tbaa !24
  %t399 = icmp slt i64 %t395, %t396
  %t401 = xor i1 %t399, true
  br i1 %t401, label %bb109, label %bb110
bb109:
  br label %bb114
bb110:
  br label %bb111
bb111:
  %t403 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t403, ptr %l209, !tbaa !27
  %t404 = load i64, ptr %l28, !tbaa !24
  %t406 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !27
  %t408 = getelementptr ptr, ptr %t407, i64 %t404
  %t409 = load ptr, ptr %t408, !tbaa !39
  %t411 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t411, ptr %t409)
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t415 = load i64, ptr %l28, !tbaa !24
  %t417 = add i64 %t415, 1
  store i64 %t417, ptr %l28, !tbaa !24
  br label %bb108
bb114:
  br label %bb134
bb115:
  %t419 = load ptr, ptr %l1, !tbaa !29
  store ptr %t419, ptr %l216, !tbaa !29
  store i1 false, ptr %l217, !tbaa !21
  %t420 = load ptr, ptr %l216, !tbaa !29
  %t421 = icmp ne ptr %t420, null
  br i1 %t421, label %bb116, label %bb117
bb116:
  %t423 = load ptr, ptr %l216, !tbaa !29
  %t424 = load i64, ptr %t423, !range !{i64 0, i64 18}
  %t426 = icmp eq i64 %t424, 11
  store i1 %t426, ptr %l217, !tbaa !21
  br label %bb117
bb117:
  %t427 = load i1, ptr %l217, !tbaa !21
  br i1 %t427, label %bb118, label %bb119
bb118:
  %t428 = load ptr, ptr %l1, !tbaa !29
  %t430 = getelementptr { i64, [5 x i64] }, ptr %t428, i32 0, i32 1
  %t431 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t430, i32 0, i32 2
  %t432 = load ptr, ptr %t431
  store ptr %t432, ptr %l31, !tbaa !29
  br label %bb120
bb119:
  br label %bb129
bb120:
  %t434 = load ptr, ptr %l31, !tbaa !29
  %t436 = getelementptr %"compiler/typed:Cond", ptr %t434, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !29
  %t439 = icmp eq ptr %t437, null
  %t441 = xor i1 %t439, true
  br i1 %t441, label %bb121, label %bb122
bb121:
  %t443 = load ptr, ptr %l0, !tbaa !29
  store ptr %t443, ptr %l226, !tbaa !29
  %t444 = load ptr, ptr %l31, !tbaa !29
  %t446 = getelementptr %"compiler/typed:Cond", ptr %t444, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !29
  %t449 = icmp eq ptr %t447, null
  br i1 %t449, label %bb123, label %bb124
bb122:
  br label %bb127
bb123:
  call void @__olang_check_failed(ptr @olang_loc_342e0c3fe78e7ee6_419d07e7c20dd892)
  unreachable
bb124:
  br label %bb125
bb125:
  %t451 = load ptr, ptr %l31, !tbaa !29
  %t453 = getelementptr %"compiler/typed:Cond", ptr %t451, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !29
  %t455 = load ptr, ptr %l226, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t455, ptr %t454)
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = load ptr, ptr %l31, !tbaa !29
  %t460 = getelementptr %"compiler/typed:Cond", ptr %t458, i32 0, i32 2
  %t461 = load ptr, ptr %t460, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t457, ptr %t461)
  br label %bb128
bb128:
  br label %bb134
bb129:
  br i1 true, label %bb130, label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_d5478abcfcd1a74_537f989617a8cff0)
  unreachable
bb134:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efreshLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i1
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i1 false, ptr %l2, !tbaa !21
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:mustW", ptr %t8, i32 0, i32 4
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l15
  br label %bb5
bb5:
  %t13 = load i64, ptr %l15, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb11
bb8:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l22, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb10
bb10:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb11
bb11:
  %t41 = load i64, ptr %l19, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb13, label %bb14
bb13:
  br label %bb26
bb14:
  br label %bb15
bb15:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:mustW", ptr %t60, i32 0, i32 4
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t62, i64 %t63)
  store i64 %t66, ptr %l43
  br label %bb16
bb16:
  %t67 = load i64, ptr %l1, !tbaa !24
  %t68 = load i64, ptr %l43, !tbaa !24
  %t70 = icmp ne i64 %t68, %t67
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l46, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:mustW", ptr %t73, i32 0, i32 5
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t75, i64 %t76)
  store ptr %t79, ptr %l50
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l46, !tbaa !29
  %t81 = load ptr, ptr %l50, !tbaa !29
  %t82 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v0, ptr %t80, ptr %t81, i64 1)
  store i1 %t82, ptr %l51
  br label %bb21
bb21:
  %t83 = load i1, ptr %l51, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb22, label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb25
bb25:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb12
bb26:
  %t91 = load i1, ptr %l2, !tbaa !21
  store i1 %t91, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopiedCtorOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca i64
  %l30 = alloca i1
  %l33 = alloca i64
  %l35 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca i64
  %l43 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca ptr
  %l51 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i1
  %l65 = alloca i1
  %l68 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb10
bb2:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t6 = load ptr, ptr %l10, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb3, label %bb4
bb3:
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 3
  store i1 %t12, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l11, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 4
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l17, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l15, !tbaa !21
  store i1 %t27, ptr %l9, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l9, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/free:walker", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l3, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t35)
  store ptr %t37, ptr %l25
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l25, !tbaa !29
  store ptr %t38, ptr %l4, !tbaa !29
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v2, ptr %t39)
  store i64 %t41, ptr %l27
  br label %bb15
bb15:
  %t42 = load i64, ptr %l27, !tbaa !24
  store i64 %t42, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp slt i64 %t43, 0
  br i1 %t45, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb19
bb17:
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t51 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  store i64 %t51, ptr %l33
  br label %bb18
bb18:
  %t52 = load i64, ptr %l33, !tbaa !24
  %t53 = icmp sge i64 %t52, 0
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t55 = load i1, ptr %l30, !tbaa !21
  br i1 %t55, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb25
bb21:
  %t56 = load ptr, ptr %l3, !tbaa !29
  store ptr %t56, ptr %l36, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t57)
  store i32 %t59, ptr %l38
  br label %bb22
bb22:
  %t60 = load ptr, ptr %l36, !tbaa !29
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t60, i32 %t61)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %l39
  br label %bb23
bb23:
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %l39)
  store i64 %t64, ptr %l41
  br label %bb24
bb24:
  %t65 = load i64, ptr %l41, !tbaa !24
  %t66 = icmp eq i64 %t65, 0
  store i1 %t66, ptr %l35, !tbaa !21
  br label %bb25
bb25:
  %t68 = load i1, ptr %l35, !tbaa !21
  br i1 %t68, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb30
bb27:
  %t69 = load ptr, ptr %l4, !tbaa !29
  store ptr %t69, ptr %l44, !tbaa !29
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/free:Free", ptr %t70, i32 0, i32 1
  %t73 = load i64, ptr %l5, !tbaa !24
  %t76 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t72, i64 %t73)
  store ptr %t76, ptr %l48
  br label %bb28
bb28:
  %t77 = load ptr, ptr %l48, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Body", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t81 = load ptr, ptr %l44, !tbaa !29
  %t83 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t81, i32 %t80)
  store i64 %t83, ptr %l51
  br label %bb29
bb29:
  %t84 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t85 = load i64, ptr %l51, !tbaa !24
  %t87 = icmp ne i64 %t85, %t84
  store i1 %t87, ptr %l43, !tbaa !21
  br label %bb30
bb30:
  %t89 = load i1, ptr %l43, !tbaa !21
  br i1 %t89, label %bb31, label %bb32
bb31:
  store i64 -1, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t92 = load i64, ptr %l5, !tbaa !24
  %t95 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l57
  br label %bb34
bb34:
  %t96 = load i64, ptr %l57, !tbaa !24
  store i64 %t96, ptr %l6, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = icmp eq i64 %t97, 0
  br i1 %t99, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb37
bb36:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t102 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t105 = and i64 %t101, %t102
  %t107 = icmp ne i64 %t105, 0
  store i1 %t107, ptr %l60, !tbaa !21
  br label %bb37
bb37:
  %t109 = load i1, ptr %l60, !tbaa !21
  br i1 %t109, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb41
bb39:
  %t110 = load ptr, ptr %l2, !tbaa !29
  %t111 = load i64, ptr %l6, !tbaa !24
  %t114 = call i1 @compiler_2ftyped_2eViewsMoved(ptr %v2, ptr %t110, i64 %t111)
  store i1 %t114, ptr %l68
  br label %bb40
bb40:
  %t115 = load i1, ptr %l68, !tbaa !21
  store i1 %t115, ptr %l65, !tbaa !21
  br label %bb41
bb41:
  %t116 = load i1, ptr %l65, !tbaa !21
  br i1 %t116, label %bb42, label %bb43
bb42:
  store i64 -1, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Call", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t123 = sext i32 %t121 to i64
  store i64 %t123, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca %"compiler/free:leaf"
  %l26 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i1
  %l51 = alloca ptr
  %l56 = alloca i1
  %l57 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca i64
  %l67 = alloca i1
  %l68 = alloca ptr
  %l72 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l85 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l90 = alloca i32
  %l93 = alloca i32
  %l94 = alloca i1
  %l97 = alloca i64
  %l99 = alloca i1
  %l102 = alloca ptr
  %l105 = alloca i64
  %l106 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l115 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l116 = alloca ptr
  %l119 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l131 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l137 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca ptr
  %l144 = alloca i64
  %l145 = alloca ptr
  %l146 = alloca i64
  %l149 = alloca i64
  %l152 = alloca ptr
  %l153 = alloca i64
  %l157 = alloca i64
  %l164 = alloca ptr
  %l168 = alloca ptr
  %l169 = alloca i1
  %l172 = alloca ptr
  %l173 = alloca i1
  %l180 = alloca i1
  %l185 = alloca i64
  %l187 = alloca i64
  %l192 = alloca %"compiler/free:leaf"
  %l194 = alloca %"compiler/free:leaf"
  %l196 = alloca ptr
  %l197 = alloca i64
  %l199 = alloca i64
  %l201 = alloca ptr
  %l208 = alloca %"compiler/free:store"
  %l209 = alloca ptr
  %l210 = alloca i64
  %l211 = alloca i64
  %l213 = alloca ptr
  %l215 = alloca i64
  %l216 = alloca %"compiler/source:Span"
  %l217 = alloca i64
  %l219 = alloca ptr
  %l221 = alloca %"compiler/source:Span"
  %l222 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l26
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l26, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyLeaves(ptr %v0, ptr %v1, ptr %v4, ptr %t16, ptr %t17, ptr %t18, %"compiler/source:Span" %t19)
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t24
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %rv
  br label %ret
bb5:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t31 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v2, ptr %v2, ptr %t28)
  store ptr %t31, ptr %l38
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l38, !tbaa !29
  store ptr %t32, ptr %l9, !tbaa !29
  %t33 = load ptr, ptr %l9, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l9, !tbaa !29
  %t41 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v2, ptr %t39)
  store i64 %t41, ptr %l44
  br label %bb9
bb8:
  store i64 -1, ptr %l42, !tbaa !24
  br label %bb10
bb9:
  %t42 = load i64, ptr %l44, !tbaa !24
  store i64 %t42, ptr %l42, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l42, !tbaa !24
  store i64 %t43, ptr %l10, !tbaa !24
  %t44 = load i64, ptr %l10, !tbaa !24
  %t46 = icmp sge i64 %t44, 0
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t50 = getelementptr %"compiler/free:Free", ptr %t48, i32 0, i32 1
  %t51 = load i64, ptr %l10, !tbaa !24
  %t54 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t50, i64 %t51)
  store ptr %t54, ptr %l51
  br label %bb13
bb12:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb14
bb13:
  %t55 = load ptr, ptr %l51, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Body", ptr %t55, i32 0, i32 11
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  store i1 %t62, ptr %l47, !tbaa !21
  br label %bb14
bb14:
  %t64 = load i1, ptr %l47, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l8, !tbaa !29
  store ptr %t65, ptr %l57, !tbaa !29
  %t66 = load ptr, ptr %l7, !tbaa !29
  %t68 = getelementptr %"compiler/free:Free", ptr %t66, i32 0, i32 1
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t68, i64 %t69)
  store ptr %t72, ptr %l61
  br label %bb17
bb16:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb19
bb17:
  %t73 = load ptr, ptr %l61, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Body", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %t75, !tbaa !23
  %t77 = load ptr, ptr %l57, !tbaa !29
  %t79 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t77, i32 %t76)
  store i64 %t79, ptr %l64
  br label %bb18
bb18:
  %t80 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t81 = load i64, ptr %l64, !tbaa !24
  %t83 = icmp eq i64 %t81, %t80
  store i1 %t83, ptr %l56, !tbaa !21
  br label %bb19
bb19:
  %t85 = load i1, ptr %l56, !tbaa !21
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t86 = load ptr, ptr %l8, !tbaa !29
  store ptr %t86, ptr %l68, !tbaa !29
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t89 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 1
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t89, i64 %t90)
  store ptr %t93, ptr %l72
  br label %bb22
bb21:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb24
bb22:
  %t94 = load ptr, ptr %l72, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Body", ptr %t94, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t98 = load ptr, ptr %l68, !tbaa !29
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t98, i32 %t97)
  store { i64, ptr } %t100, ptr %l75
  br label %bb23
bb23:
  %t101 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t104 = icmp eq i64 %t102, 1
  store i1 %t104, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t106 = load i1, ptr %l67, !tbaa !21
  br i1 %t106, label %bb25, label %bb26
bb25:
  %t107 = load ptr, ptr %l8, !tbaa !29
  store ptr %t107, ptr %l79, !tbaa !29
  %t108 = load ptr, ptr %l8, !tbaa !29
  store ptr %t108, ptr %l80, !tbaa !29
  %t109 = load ptr, ptr %l8, !tbaa !29
  store ptr %t109, ptr %l81, !tbaa !29
  %t110 = load ptr, ptr %l7, !tbaa !29
  %t112 = getelementptr %"compiler/free:Free", ptr %t110, i32 0, i32 1
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t112, i64 %t113)
  store ptr %t116, ptr %l85
  br label %bb27
bb26:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb32
bb27:
  %t117 = load ptr, ptr %l85, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Body", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %t119, !tbaa !23
  %t121 = load ptr, ptr %l81, !tbaa !29
  %t123 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t121, i32 %t120)
  store { i64, ptr } %t123, ptr %l88
  br label %bb28
bb28:
  %t124 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i32, ptr %t125, i64 0
  %t127 = load i32, ptr %t126, !tbaa !33
  %t128 = load ptr, ptr %l80, !tbaa !29
  %t130 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t128, i32 %t127)
  store i32 %t130, ptr %l90
  br label %bb29
bb29:
  %t131 = load ptr, ptr %l8, !tbaa !29
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t131, i32 %a2)
  store i32 %t135, ptr %l93
  br label %bb30
bb30:
  %t136 = load ptr, ptr %l79, !tbaa !29
  %t137 = load i32, ptr %l90, !tbaa !23
  %t138 = load i32, ptr %l93, !tbaa !23
  %t139 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t136, i32 %t137, i32 %t138)
  store i1 %t139, ptr %l94
  br label %bb31
bb31:
  %t140 = load i1, ptr %l94, !tbaa !21
  store i1 %t140, ptr %l78, !tbaa !21
  br label %bb32
bb32:
  %t141 = load i1, ptr %l78, !tbaa !21
  br i1 %t141, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s2
  %t142 = load ptr, ptr %l7, !tbaa !29
  %t143 = load i64, ptr %l10, !tbaa !24
  %t146 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t142, i64 %t143)
  store i64 %t146, ptr %l97
  br label %bb35
bb34:
  br label %bb78
bb35:
  %t147 = load i64, ptr %l97, !tbaa !24
  %t148 = icmp ne i64 %t147, 0
  br i1 %t148, label %bb36, label %bb37
bb36:
  %t150 = load ptr, ptr %l9, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb38, label %bb39
bb37:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb43
bb38:
  call void @__olang_check_failed(ptr @olang_loc_3ed6c54977104fdc_6fa493e2929cd018)
  unreachable
bb39:
  br label %bb40
bb40:
  %t154 = load ptr, ptr %l9, !tbaa !29
  store ptr %t154, ptr %l102, !tbaa !29
  %t155 = load ptr, ptr %l7, !tbaa !29
  %t156 = load i64, ptr %l10, !tbaa !24
  %t159 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t155, i64 %t156)
  store i64 %t159, ptr %l105
  br label %bb41
bb41:
  %t160 = load ptr, ptr %l102, !tbaa !29
  %t161 = load i64, ptr %l105, !tbaa !24
  %t162 = call i1 @compiler_2ftyped_2eViewsMoved(ptr %v2, ptr %t160, i64 %t161)
  store i1 %t162, ptr %l106
  br label %bb42
bb42:
  %t163 = load i1, ptr %l106, !tbaa !21
  %t164 = xor i1 %t163, true
  store i1 %t164, ptr %l99, !tbaa !21
  br label %bb43
bb43:
  %t166 = load i1, ptr %l99, !tbaa !21
  br i1 %t166, label %bb44, label %bb45
bb44:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l108, !tbaa !29
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l109, !tbaa !29
  %t169 = load ptr, ptr %l9, !tbaa !29
  %t171 = icmp eq ptr %t169, null
  br i1 %t171, label %bb46, label %bb47
bb45:
  br label %bb50
bb46:
  call void @__olang_check_failed(ptr @olang_loc_3ed6c54977104fdc_6fa493e2929cd018)
  unreachable
bb47:
  br label %bb48
bb48:
  %t173 = load ptr, ptr %l9, !tbaa !29
  %t174 = load ptr, ptr %l3, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l5
  %t176 = load ptr, ptr %l108, !tbaa !29
  %t177 = load ptr, ptr %l109, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewCtor(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t176, ptr %t177, ptr %t173, ptr %t174, %"compiler/source:Span" %t175)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t181 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t181, ptr %l115
  br label %bb51
bb51:
  %t182 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 32, i64 8)
  store ptr %t182, ptr %lp11
  %t183 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l115
  %t184 = load ptr, ptr %lp11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t183, ptr %t184
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l116, !tbaa !29
  %t186 = load ptr, ptr %l116, !tbaa !29
  %t187 = getelementptr %"compiler/free:walker", ptr %t186, i32 0, i32 30
  %t188 = load i64, ptr %t187, !tbaa !24
  %t190 = add i64 %t188, 1
  %t192 = load ptr, ptr %l116, !tbaa !29
  %t193 = getelementptr %"compiler/free:walker", ptr %t192, i32 0, i32 30
  store i64 %t190, ptr %t193, !tbaa !24
  %t194 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t194, ptr %l119
  br label %bb52
bb52:
  %t195 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l119
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t195, ptr %l12
  %t196 = load ptr, ptr %l9, !tbaa !29
  %t198 = icmp eq ptr %t196, null
  br i1 %t198, label %bb53, label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_68d09f9a6af90acb_8af3bb3c4e4b4237)
  unreachable
bb54:
  br label %bb55
bb55:
  %t200 = load ptr, ptr %l9, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Call", ptr %t200, i32 0, i32 1
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  store i64 %t208, ptr %l15, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s5
  %t210 = load i64, ptr %l14, !tbaa !24
  %t211 = load i64, ptr %l15, !tbaa !24
  %t214 = icmp slt i64 %t210, %t211
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s5)
  br label %bb63
bb58:
  br label %bb59
bb59:
  %t218 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t218, ptr %l131, !tbaa !27
  %t219 = load i64, ptr %l14, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr ptr, ptr %t222, i64 %t219
  %t224 = load ptr, ptr %t223, !tbaa !39
  store ptr %l12, ptr %l134, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t230 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %s5, ptr %t226, ptr %t224)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t230, ptr %l137
  br label %bb60
bb60:
  %t231 = load ptr, ptr %l134, !tbaa !29
  %t232 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l137
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %s2, ptr %s5, ptr %t231, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t232)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s5)
  br label %bb62
bb62:
  %t233 = load i64, ptr %l14, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l14, !tbaa !24
  br label %bb56
bb63:
  %t237 = load ptr, ptr %l7, !tbaa !29
  %t239 = getelementptr %"compiler/free:Free", ptr %t237, i32 0, i32 62
  %t240 = load i64, ptr %l10, !tbaa !24
  %t243 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t239, i64 %t240)
  store ptr %t243, ptr %l143
  br label %bb64
bb64:
  %t244 = load ptr, ptr %l143, !tbaa !29
  store ptr %t244, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb65
bb65:
  %t245 = load i64, ptr %l18, !tbaa !24
  store i64 %t245, ptr %l144, !tbaa !24
  %t246 = load ptr, ptr %l17, !tbaa !29
  store ptr %t246, ptr %l145, !tbaa !29
  %t247 = ptrtoint ptr %v0 to i64
  store i64 %t247, ptr %l146, !tbaa !24
  %t248 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t248, label %bb66, label %bb67
bb66:
  %t250 = load ptr, ptr %l145, !tbaa !29
  %t251 = call ptr @__olang_region_or(ptr %t250, ptr %v0)
  %t252 = ptrtoint ptr %t251 to i64
  store i64 %t252, ptr %l146, !tbaa !24
  br label %bb67
bb67:
  %t253 = load ptr, ptr %l17, !tbaa !29
  %t254 = load i64, ptr %l146
  %t255 = inttoptr i64 %t254 to ptr
  %t257 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t255, ptr %t253)
  store i64 %t257, ptr %l149
  br label %bb68
bb68:
  %t258 = load i64, ptr %l144, !tbaa !24
  %t259 = load i64, ptr %l149, !tbaa !24
  %t260 = icmp slt i64 %t258, %t259
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb69, label %bb70
bb69:
  br label %bb77
bb70:
  br label %bb71
bb71:
  %t264 = load ptr, ptr %l17, !tbaa !29
  store ptr %t264, ptr %l152, !tbaa !29
  %t265 = ptrtoint ptr %v0 to i64
  store i64 %t265, ptr %l153, !tbaa !24
  %t266 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t266, label %bb72, label %bb73
bb72:
  %t268 = load ptr, ptr %l152, !tbaa !29
  %t269 = call ptr @__olang_region_or(ptr %t268, ptr %v0)
  %t270 = ptrtoint ptr %t269 to i64
  store i64 %t270, ptr %l153, !tbaa !24
  br label %bb73
bb73:
  %t271 = load ptr, ptr %l17, !tbaa !29
  %t272 = load i64, ptr %l18, !tbaa !24
  %t273 = load i64, ptr %l153
  %t274 = inttoptr i64 %t273 to ptr
  %t277 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t274, ptr %t271, i64 %t272)
  store i64 %t277, ptr %l157
  br label %bb74
bb74:
  %t278 = load i64, ptr %l157, !tbaa !24
  %t279 = load ptr, ptr %l7, !tbaa !29
  %t281 = load ptr, ptr %lp11
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ethrough(ptr %v0, ptr %s2, ptr %v5, ptr %t279, i64 %t278, ptr %l12, ptr %t281)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t286 = load i64, ptr %l18, !tbaa !24
  %t288 = add i64 %t286, 1
  store i64 %t288, ptr %l18, !tbaa !24
  br label %bb65
bb77:
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l164, !tbaa !29
  %t291 = load ptr, ptr %l164, !tbaa !29
  %t292 = getelementptr %"compiler/free:walker", ptr %t291, i32 0, i32 30
  %t293 = load i64, ptr %t292, !tbaa !24
  %t295 = sub i64 %t293, 1
  %t297 = load ptr, ptr %l164, !tbaa !29
  %t298 = getelementptr %"compiler/free:walker", ptr %t297, i32 0, i32 30
  store i64 %t295, ptr %t298, !tbaa !24
  %t299 = load ptr, ptr %lp11
  %t300 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t299
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t300, ptr %rv
  br label %ret
bb78:
  %t302 = load ptr, ptr %l3, !tbaa !29
  store ptr %t302, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t303 = load ptr, ptr %l168, !tbaa !29
  %t304 = icmp ne ptr %t303, null
  br i1 %t304, label %bb79, label %bb80
bb79:
  %t306 = load ptr, ptr %l168, !tbaa !29
  %t307 = load i64, ptr %t306, !range !{i64 0, i64 18}
  %t309 = icmp eq i64 %t307, 0
  store i1 %t309, ptr %l169, !tbaa !21
  br label %bb80
bb80:
  %t310 = load i1, ptr %l169, !tbaa !21
  br i1 %t310, label %bb81, label %bb82
bb81:
  br label %bb87
bb82:
  %t311 = load ptr, ptr %l3, !tbaa !29
  store ptr %t311, ptr %l172, !tbaa !29
  store i1 false, ptr %l173, !tbaa !21
  %t312 = load ptr, ptr %l172, !tbaa !29
  %t313 = icmp ne ptr %t312, null
  br i1 %t313, label %bb83, label %bb84
bb83:
  %t315 = load ptr, ptr %l172, !tbaa !29
  %t316 = load i64, ptr %t315, !range !{i64 0, i64 18}
  %t318 = icmp eq i64 %t316, 1
  store i1 %t318, ptr %l173, !tbaa !21
  br label %bb84
bb84:
  %t319 = load i1, ptr %l173, !tbaa !21
  br i1 %t319, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  %t320 = load ptr, ptr %l4, !tbaa !29
  %t322 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t320
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t322, ptr %rv
  br label %ret
bb88:
  br i1 true, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_7f12d3772dd0a929_45b952e679e83a85)
  unreachable
bb93:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/free:walker", ptr %t324, i32 0, i32 2
  %t327 = load i1, ptr %t326, !tbaa !21
  br i1 %t327, label %bb94, label %bb95
bb94:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/free:walker", ptr %t329, i32 0, i32 30
  %t332 = load i64, ptr %t331, !tbaa !24
  %t334 = icmp eq i64 %t332, 0
  store i1 %t334, ptr %l180, !tbaa !21
  br label %bb96
bb95:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb96
bb96:
  %t336 = load i1, ptr %l180, !tbaa !21
  br i1 %t336, label %bb97, label %bb98
bb97:
  %t337 = load ptr, ptr %l1, !tbaa !29
  store ptr %t337, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb99
bb98:
  br label %bb117
bb99:
  store %olang.scope zeroinitializer, ptr %s14
  %t339 = load i64, ptr %l21, !tbaa !24
  store i64 %t339, ptr %l185, !tbaa !24
  %t340 = load ptr, ptr %l20, !tbaa !29
  %t342 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t340)
  store i64 %t342, ptr %l187
  br label %bb100
bb100:
  %t343 = load i64, ptr %l185, !tbaa !24
  %t344 = load i64, ptr %l187, !tbaa !24
  %t345 = icmp slt i64 %t343, %t344
  %t347 = xor i1 %t345, true
  br i1 %t347, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s14)
  br label %bb116
bb102:
  br label %bb103
bb103:
  %t349 = load ptr, ptr %l20, !tbaa !29
  %t350 = load i64, ptr %l21, !tbaa !24
  %t353 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t349, i64 %t350)
  store %"compiler/free:leaf" %t353, ptr %l192
  br label %bb104
bb104:
  %t355 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s14, ptr %l192)
  store %"compiler/free:leaf" %t355, ptr %l194
  br label %bb105
bb105:
  %t356 = load %"compiler/free:leaf", ptr %l194
  store %"compiler/free:leaf" %t356, ptr %l22
  %t357 = load ptr, ptr %l7, !tbaa !29
  %t359 = getelementptr %"compiler/free:Free", ptr %t357, i32 0, i32 83
  store ptr %t359, ptr %l196, !tbaa !29
  %t360 = getelementptr %"compiler/free:leaf", ptr %l22, i32 0, i32 1
  %t361 = load i64, ptr %t360, !tbaa !24
  store i64 %t361, ptr %l197, !tbaa !24
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/free:walker", ptr %t362, i32 0, i32 1
  %t365 = load i64, ptr %t364, !tbaa !24
  store i64 %t365, ptr %l199, !tbaa !24
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t366)
  store ptr %t368, ptr %l201
  br label %bb106
bb106:
  %t369 = load ptr, ptr %l201, !tbaa !29
  %t371 = getelementptr %"compiler/typed:Body", ptr %t369, i32 0, i32 3
  %t372 = load i64, ptr %t371, !tbaa !24
  %t373 = load %"compiler/source:Span", ptr %l5
  %t374 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t375 = load ptr, ptr %l3, !tbaa !29
  %t377 = load i64, ptr %l197, !tbaa !24
  %t378 = load i64, ptr %l199, !tbaa !24
  %t383 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v2, ptr %v0, ptr %v0, i64 %t377, i64 %t378, i64 %t372, %"compiler/source:Span" %t373, i64 %t374, i64 -1, i64 -1, ptr %t375, ptr null)
  store %"compiler/free:store" %t383, ptr %l208
  br label %bb107
bb107:
  %t384 = load ptr, ptr %l196, !tbaa !29
  %t385 = load %"compiler/free:store", ptr %l208
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t384, %"compiler/free:store" %t385)
  br label %bb108
bb108:
  %t386 = load ptr, ptr %l7, !tbaa !29
  store ptr %t386, ptr %l209, !tbaa !29
  %t387 = getelementptr %"compiler/free:leaf", ptr %l22, i32 0, i32 1
  %t388 = load i64, ptr %t387, !tbaa !24
  store i64 %t388, ptr %l210, !tbaa !24
  %t389 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t389, ptr %l211, !tbaa !24
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t390)
  store ptr %t392, ptr %l213
  br label %bb109
bb109:
  %t393 = load ptr, ptr %l213, !tbaa !29
  %t395 = getelementptr %"compiler/typed:Body", ptr %t393, i32 0, i32 3
  %t396 = load i64, ptr %t395, !tbaa !24
  store i64 %t396, ptr %l215, !tbaa !24
  %t397 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t397, ptr %l216
  %t398 = ptrtoint ptr %v0 to i64
  store i64 %t398, ptr %l217, !tbaa !24
  %t399 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t399, label %bb110, label %bb111
bb110:
  %t401 = call ptr @__olang_region_make(ptr %v0)
  %t402 = ptrtoint ptr %t401 to i64
  store i64 %t402, ptr %l217, !tbaa !24
  br label %bb111
bb111:
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l219, !tbaa !29
  %t404 = load ptr, ptr %l3, !tbaa !29
  %t406 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t404)
  store %"compiler/source:Span" %t406, ptr %l221
  br label %bb112
bb112:
  %t407 = load ptr, ptr %l219, !tbaa !29
  %t408 = load %"compiler/source:Span", ptr %l221
  %t409 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s14, ptr %t407, %"compiler/source:Span" %t408)
  store { i64, ptr } %t409, ptr %l222
  br label %bb113
bb113:
  %t410 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t411 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t412 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t412, 1
  %t414 = extractvalue { i64, ptr } %t412, 0
  %t415 = add i64 %t411, %t414
  %t416 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t417 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t418 = add i64 %t415, %t417
  %t419 = load i64, ptr %l217
  %t420 = inttoptr i64 %t419 to ptr
  %t421 = call ptr @__olang_scope_alloc(ptr %t420, i64 %t418)
  call void @olang_textcopy(ptr %t421, ptr %t410, i64 %t411)
  %t422 = getelementptr i8, ptr %t421, i64 %t411
  call void @olang_textcopy(ptr %t422, ptr %t413, i64 %t414)
  %t423 = getelementptr i8, ptr %t422, i64 %t414
  call void @olang_textcopy(ptr %t423, ptr %t416, i64 %t417)
  %t424 = insertvalue { i64, ptr } undef, i64 %t418, 0
  %t425 = insertvalue { i64, ptr } %t424, ptr %t421, 1
  %t427 = load i64, ptr %l217
  %t428 = inttoptr i64 %t427 to ptr
  %t429 = extractvalue { i64, ptr } %t425, 0
  %t430 = extractvalue { i64, ptr } %t425, 1
  %t431 = mul i64 %t429, 1
  %t432 = call ptr @__olang_scope_alloc(ptr %t428, i64 %t431)
  call void @llvm.memcpy.p0.p0.i64(ptr %t432, ptr %t430, i64 %t431, i1 false)
  %t433 = insertvalue { i64, ptr } undef, i64 %t429, 0
  %t434 = insertvalue { i64, ptr } %t433, ptr %t432, 1
  %t435 = load ptr, ptr %l209, !tbaa !29
  %t436 = load i64, ptr %l210, !tbaa !24
  %t437 = load i64, ptr %l211, !tbaa !24
  %t438 = load i64, ptr %l215, !tbaa !24
  %t439 = load %"compiler/source:Span", ptr %l216
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t435, i64 %t436, i64 %t437, i64 %t438, %"compiler/source:Span" %t439, { i64, ptr } %t434)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s14)
  br label %bb115
bb115:
  %t441 = load i64, ptr %l21, !tbaa !24
  %t443 = add i64 %t441, 1
  store i64 %t443, ptr %l21, !tbaa !24
  br label %bb99
bb116:
  br label %bb117
bb117:
  %t445 = load ptr, ptr %l4, !tbaa !29
  %t447 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t445
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t447, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCallsOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i32
  %l28 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i32
  %l43 = alloca ptr
  %l46 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l55 = alloca i64
  %l60 = alloca i1
  %l65 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca %"compiler/source:Span"
  %l83 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca ptr
  %l86 = alloca i64
  %l89 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca i64
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca %"compiler/source:Span"
  %l102 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eValueParts(ptr %v0, ptr %s1, ptr %t9, i32 %a2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l18
  br label %bb2
bb2:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  %t16 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  store ptr %t16, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t18 = load i64, ptr %l6, !tbaa !24
  store i64 %t18, ptr %l20, !tbaa !24
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s1, ptr %t19)
  store i64 %t21, ptr %l22
  br label %bb4
bb4:
  %t22 = load i64, ptr %l20, !tbaa !24
  %t23 = load i64, ptr %l22, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  br label %bb58
bb6:
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s1, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l27
  br label %bb8
bb8:
  %t33 = load i32, ptr %l27, !tbaa !23
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/free:Free", ptr %t34, i32 0, i32 118
  %t39 = sext i32 %t33 to i64
  %t42 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t36, i64 %t39)
  %t43 = extractvalue { i32, i64 } %t42, 1
  %t44 = extractvalue { i32, i64 } %t42, 0
  store i32 %t44, ptr %l34
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb10, label %ok.46, !prof !99
ok.46:
  store i64 %t43, ptr %l33
  br label %bb9
bb9:
  %t47 = load i64, ptr %l33, !tbaa !24
  store i64 %t47, ptr %l28, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %l28, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l28, !tbaa !24
  store i64 %t48, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb13:
  br label %bb57
bb14:
  br label %bb15
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 2
  %t56 = load i1, ptr %t55, !tbaa !21
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/free:Free", ptr %t60, i32 0, i32 97
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l43
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/free:walker", ptr %t67, i32 0, i32 1
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load ptr, ptr %l43, !tbaa !29
  %t73 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t71, i64 %t70)
  store i64 %t73, ptr %l46
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 69
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t76, i64 %t77)
  store i1 %t80, ptr %l50
  br label %bb21
bb21:
  %t81 = load i1, ptr %l50, !tbaa !21
  br i1 %t81, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb25
bb23:
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr %"compiler/free:Free", ptr %t82, i32 0, i32 70
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t84, i64 %t85)
  store i64 %t88, ptr %l55
  br label %bb24
bb24:
  %t89 = load i64, ptr %l55, !tbaa !24
  %t90 = icmp ne i64 %t89, 0
  store i1 %t90, ptr %l51, !tbaa !21
  br label %bb25
bb25:
  %t92 = load i1, ptr %l51, !tbaa !21
  br i1 %t92, label %bb26, label %bb27
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/free:walker", ptr %t93, i32 0, i32 2
  %t96 = load i1, ptr %t95, !tbaa !21
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb28, label %bb29
bb27:
  br label %bb41
bb28:
  %t100 = load ptr, ptr %l3, !tbaa !29
  %t102 = getelementptr %"compiler/free:Free", ptr %t100, i32 0, i32 69
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/free:walker", ptr %t103, i32 0, i32 1
  %t106 = load i64, ptr %t105, !tbaa !24
  %t109 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t102, i64 %t106)
  store i1 %t109, ptr %l65
  br label %bb30
bb29:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb31
bb30:
  %t110 = load i1, ptr %l65, !tbaa !21
  %t111 = xor i1 %t110, true
  store i1 %t111, ptr %l60, !tbaa !21
  br label %bb31
bb31:
  %t113 = load i1, ptr %l60, !tbaa !21
  br i1 %t113, label %bb32, label %bb33
bb32:
  %t114 = load ptr, ptr %l3, !tbaa !29
  %t116 = getelementptr %"compiler/free:Free", ptr %t114, i32 0, i32 69
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:walker", ptr %t117, i32 0, i32 1
  %t120 = load i64, ptr %t119, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t116, i64 %t120, i1 true)
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t123 = load ptr, ptr %l3, !tbaa !29
  %t125 = getelementptr %"compiler/free:Free", ptr %t123, i32 0, i32 77
  store i1 true, ptr %t125, !tbaa !21
  br label %bb35
bb35:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/free:walker", ptr %t126, i32 0, i32 2
  %t129 = load i1, ptr %t128, !tbaa !21
  br i1 %t129, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l74, !tbaa !29
  %t132 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  store i64 %t132, ptr %l75, !tbaa !24
  %t133 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t133, ptr %l76, !tbaa !24
  %t134 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t134, ptr %l77
  %t135 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s7, i32 0, i32 0)
  store %"compiler/source:Span" %t135, ptr %l78
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t136 = load i64, ptr %l8, !tbaa !24
  %t137 = load ptr, ptr %l74, !tbaa !29
  %t138 = load i64, ptr %l75, !tbaa !24
  %t139 = load i64, ptr %l76, !tbaa !24
  %t140 = load %"compiler/source:Span", ptr %l77
  %t141 = load %"compiler/source:Span", ptr %l78
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t137, i64 %t138, i64 %t139, %"compiler/source:Span" %t140, %"compiler/source:Span" %t141, i64 %t136)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb40:
  br label %bb57
bb41:
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t145 = getelementptr %"compiler/free:Free", ptr %t143, i32 0, i32 68
  %t146 = load i64, ptr %l8, !tbaa !24
  %t149 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t145, i64 %t146)
  store ptr %t149, ptr %l83
  br label %bb42
bb42:
  %t150 = load ptr, ptr %l83, !tbaa !29
  store ptr %t150, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  %t151 = load i64, ptr %l10, !tbaa !24
  store i64 %t151, ptr %l84, !tbaa !24
  %t152 = load ptr, ptr %l9, !tbaa !29
  store ptr %t152, ptr %l85, !tbaa !29
  %t153 = ptrtoint ptr %v0 to i64
  store i64 %t153, ptr %l86, !tbaa !24
  %t154 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t154, label %bb44, label %bb45
bb44:
  %t156 = load ptr, ptr %l85, !tbaa !29
  %t157 = call ptr @__olang_region_or(ptr %t156, ptr %v0)
  %t158 = ptrtoint ptr %t157 to i64
  store i64 %t158, ptr %l86, !tbaa !24
  br label %bb45
bb45:
  %t159 = load ptr, ptr %l9, !tbaa !29
  %t160 = load i64, ptr %l86
  %t161 = inttoptr i64 %t160 to ptr
  %t163 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t161, ptr %t159)
  store i64 %t163, ptr %l89
  br label %bb46
bb46:
  %t164 = load i64, ptr %l84, !tbaa !24
  %t165 = load i64, ptr %l89, !tbaa !24
  %t166 = icmp slt i64 %t164, %t165
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb48:
  br label %bb49
bb49:
  %t170 = load ptr, ptr %l9, !tbaa !29
  store ptr %t170, ptr %l92, !tbaa !29
  %t171 = ptrtoint ptr %v0 to i64
  store i64 %t171, ptr %l93, !tbaa !24
  %t172 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t172, label %bb50, label %bb51
bb50:
  %t174 = load ptr, ptr %l92, !tbaa !29
  %t175 = call ptr @__olang_region_or(ptr %t174, ptr %v0)
  %t176 = ptrtoint ptr %t175 to i64
  store i64 %t176, ptr %l93, !tbaa !24
  br label %bb51
bb51:
  %t177 = load ptr, ptr %l9, !tbaa !29
  %t178 = load i64, ptr %l10, !tbaa !24
  %t179 = load i64, ptr %l93
  %t180 = inttoptr i64 %t179 to ptr
  %t183 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t180, ptr %t177, i64 %t178)
  store i64 %t183, ptr %l97
  br label %bb52
bb52:
  %t184 = load i64, ptr %l97, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l98, !tbaa !29
  store i64 %t184, ptr %l99, !tbaa !24
  %t187 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t187, ptr %l100, !tbaa !24
  %t188 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t188, ptr %l101
  %t189 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s9, i32 0, i32 0)
  store %"compiler/source:Span" %t189, ptr %l102
  br label %bb53
bb53:
  %t190 = load i64, ptr %l8, !tbaa !24
  %t191 = load ptr, ptr %l98, !tbaa !29
  %t192 = load i64, ptr %l99, !tbaa !24
  %t193 = load i64, ptr %l100, !tbaa !24
  %t194 = load %"compiler/source:Span", ptr %l101
  %t195 = load %"compiler/source:Span", ptr %l102
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t191, i64 %t192, i64 %t193, %"compiler/source:Span" %t194, %"compiler/source:Span" %t195, i64 %t190)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  %t197 = load i64, ptr %l10, !tbaa !24
  %t199 = add i64 %t197, 1
  store i64 %t199, ptr %l10, !tbaa !24
  br label %bb43
bb56:
  br label %bb57
bb57:
  %t201 = load i64, ptr %l6, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l6, !tbaa !24
  br label %bb3
bb58:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eelemRead(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i1
  %l17 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i64
  %l60 = alloca i64
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2ffree_2einElement(ptr %v1, ptr %a1)
  store i1 %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load i1, ptr %l12, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = getelementptr %"compiler/free:walker", ptr %a0, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t12)
  store i64 %t14, ptr %l17
  br label %bb5
bb5:
  %t15 = load i64, ptr %l17, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t22 = load i64, ptr %l7, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb11
bb8:
  %t26 = load i64, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l24, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb10
bb10:
  %t42 = load i64, ptr %l24, !tbaa !24
  store i64 %t42, ptr %l21, !tbaa !24
  br label %bb11
bb11:
  %t43 = load i64, ptr %l21, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t44 = load i64, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb13, label %bb14
bb13:
  br label %bb30
bb14:
  br label %bb15
bb15:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l10, !tbaa !24
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load i64, ptr %l10, !tbaa !24
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t62, i64 %t63)
  store i64 %t66, ptr %l44
  br label %bb16
bb16:
  %t67 = load i64, ptr %l44, !tbaa !24
  %t68 = call i64 @compiler_2ffree_2eokind(i64 %t67)
  store i64 %t68, ptr %l45
  br label %bb17
bb17:
  %t69 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t70 = load i64, ptr %l45, !tbaa !24
  %t72 = icmp eq i64 %t70, %t69
  br i1 %t72, label %bb18, label %bb19
bb18:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 13
  store ptr %t76, ptr %l50, !tbaa !29
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i64, ptr %l10, !tbaa !24
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t77, i64 %t78)
  store i64 %t81, ptr %l53
  br label %bb20
bb19:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb23
bb20:
  %t82 = load i64, ptr %l53, !tbaa !24
  %t83 = call i64 @compiler_2ffree_2eoval(i64 %t82)
  store i64 %t83, ptr %l54
  br label %bb21
bb21:
  %t84 = load ptr, ptr %l50, !tbaa !29
  %t85 = load i64, ptr %l54, !tbaa !24
  %t86 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t84, i64 %t85)
  store i1 %t86, ptr %l55
  br label %bb22
bb22:
  %t87 = load i1, ptr %l55, !tbaa !21
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb23
bb23:
  %t88 = load i1, ptr %l48, !tbaa !21
  br i1 %t88, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t89 = load ptr, ptr %l2, !tbaa !29
  store ptr %t89, ptr %l56, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l57, !tbaa !24
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t92 = load i64, ptr %l10, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l60
  br label %bb27
bb27:
  %t96 = load ptr, ptr %l56, !tbaa !29
  %t97 = load i64, ptr %l57, !tbaa !24
  %t98 = load i64, ptr %l60, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v2, ptr %t96, i64 %t97, i64 %t98)
  br label %bb28
bb28:
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l4, !tbaa !24
  br label %bb29
bb29:
  %t103 = load i64, ptr %l9, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l9, !tbaa !24
  br label %bb12
bb30:
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t108 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v2, ptr %t107, i64 %t108)
  br label %bb31
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i1 %a4, i64 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i64
  %l28 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i64
  %l37 = alloca i1
  %l42 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca i64
  %l51 = alloca i1
  %l55 = alloca i1
  %l57 = alloca i64
  %l64 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l78 = alloca i64
  %l82 = alloca ptr
  %l84 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l96 = alloca i1
  %l99 = alloca i1
  %l101 = alloca i64
  %l104 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca i64
  %l109 = alloca ptr
  %l111 = alloca i64
  %l112 = alloca %"compiler/source:Span"
  %l114 = alloca i1
  %l116 = alloca { i64, ptr }
  %l123 = alloca i1
  %l126 = alloca i1
  %l129 = alloca i1
  %l133 = alloca i1
  %l134 = alloca ptr
  %l136 = alloca i64
  %l137 = alloca i1
  %l138 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l145 = alloca ptr
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  store ptr %a1, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l9, !tbaa !24
  store i64 %t8, ptr %l15, !tbaa !24
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l17
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  %t13 = load i64, ptr %l17, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb86
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l8, !tbaa !29
  %t19 = load i64, ptr %l9, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l22
  br label %bb6
bb6:
  %t23 = load i64, ptr %l22, !tbaa !24
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l10, !tbaa !24
  %t26 = call i64 @compiler_2ffree_2eokind(i64 %t24)
  store i64 %t26, ptr %l24
  br label %bb7
bb7:
  %t27 = load i64, ptr %l24, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  %t28 = load i64, ptr %l11, !tbaa !24
  %t29 = load i64, ptr @G_2ecompiler_2ffree_2eOParC, !tbaa !24
  %t32 = icmp eq i64 %t28, %t29
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:walker", ptr %t34, i32 0, i32 2
  %t37 = load i1, ptr %t36, !tbaa !21
  %t39 = xor i1 %t37, true
  store i1 %t39, ptr %l28, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb10
bb10:
  %t41 = load i1, ptr %l28, !tbaa !21
  br i1 %t41, label %bb11, label %bb12
bb11:
  %t42 = load i64, ptr %l10, !tbaa !24
  %t44 = call i64 @compiler_2ffree_2eoval(i64 %t42)
  store i64 %t44, ptr %l34
  br label %bb13
bb12:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb14
bb13:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l34, !tbaa !24
  %t48 = icmp ne i64 %t46, %t45
  store i1 %t48, ptr %l32, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l32, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t53 = getelementptr %"compiler/free:Free", ptr %t51, i32 0, i32 65
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/free:walker", ptr %t54, i32 0, i32 1
  %t57 = load i64, ptr %t56, !tbaa !24
  %t60 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t53, i64 %t57)
  store ptr %t60, ptr %l42
  br label %bb17
bb16:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb20
bb17:
  %t61 = load i64, ptr %l10, !tbaa !24
  %t63 = call i64 @compiler_2ffree_2eoval(i64 %t61)
  store i64 %t63, ptr %l44
  br label %bb18
bb18:
  %t64 = load ptr, ptr %l42, !tbaa !29
  %t65 = load i64, ptr %l44, !tbaa !24
  %t66 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t64, i64 %t65)
  store i64 %t66, ptr %l45
  br label %bb19
bb19:
  %t67 = load i64, ptr %l45, !tbaa !24
  %t68 = icmp sgt i64 %t67, 0
  store i1 %t68, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t70 = load i1, ptr %l37, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l7, !tbaa !29
  %t73 = getelementptr %"compiler/free:Free", ptr %t71, i32 0, i32 77
  store i1 true, ptr %t73, !tbaa !21
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t74 = load i64, ptr %l11, !tbaa !24
  %t75 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t78 = icmp eq i64 %t74, %t75
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:walker", ptr %t80, i32 0, i32 2
  %t83 = load i1, ptr %t82, !tbaa !21
  %t85 = xor i1 %t83, true
  store i1 %t85, ptr %l51, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb26
bb26:
  %t87 = load i1, ptr %l51, !tbaa !21
  br i1 %t87, label %bb27, label %bb28
bb27:
  %t88 = load i64, ptr %l10, !tbaa !24
  %t90 = call i64 @compiler_2ffree_2eoval(i64 %t88)
  store i64 %t90, ptr %l57
  br label %bb29
bb28:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb30
bb29:
  %t91 = load i64, ptr %l5, !tbaa !24
  %t92 = load i64, ptr %l57, !tbaa !24
  %t94 = icmp ne i64 %t92, %t91
  store i1 %t94, ptr %l55, !tbaa !21
  br label %bb30
bb30:
  %t96 = load i1, ptr %l55, !tbaa !21
  br i1 %t96, label %bb31, label %bb32
bb31:
  %t97 = load ptr, ptr %l7, !tbaa !29
  %t99 = getelementptr %"compiler/free:Free", ptr %t97, i32 0, i32 64
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/free:walker", ptr %t100, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t106 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t99, i64 %t103)
  store ptr %t106, ptr %l64
  br label %bb33
bb32:
  br label %bb47
bb33:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t109 = call i64 @compiler_2ffree_2eoval(i64 %t107)
  store i64 %t109, ptr %l66
  br label %bb34
bb34:
  %t110 = load ptr, ptr %l64, !tbaa !29
  %t111 = load i64, ptr %l66, !tbaa !24
  %t112 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t110, i64 %t111)
  store i64 %t112, ptr %l67
  br label %bb35
bb35:
  %t113 = load i64, ptr %l67, !tbaa !24
  %t114 = icmp sgt i64 %t113, 0
  br i1 %t114, label %bb36, label %bb37
bb36:
  %t116 = load ptr, ptr %l7, !tbaa !29
  %t118 = getelementptr %"compiler/free:Free", ptr %t116, i32 0, i32 77
  store i1 true, ptr %t118, !tbaa !21
  %t119 = load ptr, ptr %l7, !tbaa !29
  %t121 = getelementptr %"compiler/free:Free", ptr %t119, i32 0, i32 116
  %t122 = load i1, ptr %t121, !tbaa !21
  br i1 %t122, label %bb38, label %bb39
bb37:
  br label %bb46
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t124 = load ptr, ptr %l7, !tbaa !29
  store ptr %t124, ptr %l72, !tbaa !29
  %t125 = load ptr, ptr %l7, !tbaa !29
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/free:walker", ptr %t126, i32 0, i32 1
  %t129 = load i64, ptr %t128, !tbaa !24
  %t132 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s6, ptr %t125, i64 %t129)
  store { i64, ptr } %t132, ptr %l76
  br label %bb40
bb39:
  br label %bb45
bb40:
  %t133 = load i64, ptr %l10, !tbaa !24
  %t135 = call i64 @compiler_2ffree_2eoval(i64 %t133)
  store i64 %t135, ptr %l78
  br label %bb41
bb41:
  %t136 = load ptr, ptr %l7, !tbaa !29
  %t138 = getelementptr %"compiler/free:Free", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/load:Loader", ptr %t142, i32 0, i32 4
  %t145 = load ptr, ptr %t144, !tbaa !29
  store ptr %t145, ptr %l82, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t146)
  store ptr %t148, ptr %l84
  br label %bb42
bb42:
  %t149 = load ptr, ptr %l84, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Body", ptr %t149, i32 0, i32 3
  %t152 = load i64, ptr %t151, !tbaa !24
  %t153 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = sext i32 %t154 to i64
  %t157 = load ptr, ptr %l82, !tbaa !29
  %t160 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s6, ptr %t157, i64 %t152, i64 %t156)
  store { i64, ptr } %t160, ptr %l89
  br label %bb43
bb43:
  %t161 = load i64, ptr %l5, !tbaa !24
  %t162 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t164 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 1
  %t166 = extractvalue { i64, ptr } %t164, 0
  %t167 = add i64 %t163, %t166
  %t168 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = load i64, ptr %l78, !tbaa !24
  %t172 = call i64 @__olang_fmt_i64(ptr null, i64 %t171)
  %t173 = add i64 %t170, %t172
  %t174 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = add i64 %t176, %t179
  %t181 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t183 = add i64 %t180, %t182
  %t185 = call i64 @__olang_fmt_i64(ptr null, i64 %t161)
  %t186 = add i64 %t183, %t185
  %t187 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t188 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t189 = add i64 %t186, %t188
  %t190 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t189)
  call void @olang_textcopy(ptr %t190, ptr %t162, i64 %t163)
  %t191 = getelementptr i8, ptr %t190, i64 %t163
  call void @olang_textcopy(ptr %t191, ptr %t165, i64 %t166)
  %t192 = getelementptr i8, ptr %t191, i64 %t166
  call void @olang_textcopy(ptr %t192, ptr %t168, i64 %t169)
  %t193 = getelementptr i8, ptr %t192, i64 %t169
  %t194 = call i64 @__olang_fmt_i64(ptr %t193, i64 %t171)
  %t195 = getelementptr i8, ptr %t193, i64 %t172
  call void @olang_textcopy(ptr %t195, ptr %t174, i64 %t175)
  %t196 = getelementptr i8, ptr %t195, i64 %t175
  call void @olang_textcopy(ptr %t196, ptr %t178, i64 %t179)
  %t197 = getelementptr i8, ptr %t196, i64 %t179
  call void @olang_textcopy(ptr %t197, ptr %t181, i64 %t182)
  %t198 = getelementptr i8, ptr %t197, i64 %t182
  %t199 = call i64 @__olang_fmt_i64(ptr %t198, i64 %t161)
  %t200 = getelementptr i8, ptr %t198, i64 %t185
  call void @olang_textcopy(ptr %t200, ptr %t187, i64 %t188)
  %t201 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t190, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = extractvalue { i64, ptr } %t202, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  %t210 = load ptr, ptr %l72, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edebugOut(ptr %v0, ptr %s6, ptr %t210, { i64, ptr } %t209)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t212 = load i64, ptr %l11, !tbaa !24
  %t213 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t216 = icmp eq i64 %t212, %t213
  br i1 %t216, label %bb48, label %bb49
bb48:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/free:walker", ptr %t218, i32 0, i32 2
  %t221 = load i1, ptr %t220, !tbaa !21
  store i1 %t221, ptr %l96, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb50
bb50:
  %t223 = load i1, ptr %l96, !tbaa !21
  br i1 %t223, label %bb51, label %bb52
bb51:
  %t224 = load i64, ptr %l10, !tbaa !24
  %t226 = call i64 @compiler_2ffree_2eoval(i64 %t224)
  store i64 %t226, ptr %l101
  br label %bb53
bb52:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb54
bb53:
  %t228 = load i64, ptr %l101, !tbaa !24
  %t230 = icmp ne i64 %t228, %a6
  store i1 %t230, ptr %l99, !tbaa !21
  br label %bb54
bb54:
  %t232 = load i1, ptr %l99, !tbaa !21
  br i1 %t232, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s8
  %t233 = load ptr, ptr %l7, !tbaa !29
  store ptr %t233, ptr %l104, !tbaa !29
  %t234 = load i64, ptr %l10, !tbaa !24
  %t236 = call i64 @compiler_2ffree_2eoval(i64 %t234)
  store i64 %t236, ptr %l106
  br label %bb57
bb56:
  br label %bb64
bb57:
  %t237 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t237, ptr %l107, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t238)
  store ptr %t240, ptr %l109
  br label %bb58
bb58:
  %t241 = load ptr, ptr %l109, !tbaa !29
  %t243 = getelementptr %"compiler/typed:Body", ptr %t241, i32 0, i32 3
  %t244 = load i64, ptr %t243, !tbaa !24
  store i64 %t244, ptr %l111, !tbaa !24
  %t245 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t245, ptr %l112
  %t246 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t248 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s8, { i64, ptr } %t246, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t248, ptr %l114
  br label %bb59
bb59:
  %t249 = load i1, ptr %l114, !tbaa !21
  %t250 = xor i1 %t249, true
  br i1 %t250, label %bb60, label %bb61
bb60:
  %t252 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t253 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t256 = extractvalue { i64, ptr } %t252, 1
  %t257 = extractvalue { i64, ptr } %t252, 0
  %t258 = add i64 %t254, %t257
  %t259 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t260 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t261 = add i64 %t258, %t260
  %t262 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t261)
  call void @olang_textcopy(ptr %t262, ptr %t253, i64 %t254)
  %t263 = getelementptr i8, ptr %t262, i64 %t254
  call void @olang_textcopy(ptr %t263, ptr %t256, i64 %t257)
  %t264 = getelementptr i8, ptr %t263, i64 %t257
  call void @olang_textcopy(ptr %t264, ptr %t259, i64 %t260)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t262, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = extractvalue { i64, ptr } %t266, 1
  %t270 = mul i64 %t268, 1
  %t271 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t270)
  call void @llvm.memcpy.p0.p0.i64(ptr %t271, ptr %t269, i64 %t270, i1 false)
  %t272 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  store { i64, ptr } %t273, ptr %l116, !tbaa !27
  br label %bb62
bb61:
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l116, !tbaa !27
  br label %bb62
bb62:
  %t275 = load ptr, ptr %l104, !tbaa !29
  %t276 = load i64, ptr %l106, !tbaa !24
  %t277 = load i64, ptr %l107, !tbaa !24
  %t278 = load i64, ptr %l111, !tbaa !24
  %t279 = load %"compiler/source:Span", ptr %l112
  %t280 = load { i64, ptr }, ptr %l116, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t275, i64 %t276, i64 %t277, i64 %t278, %"compiler/source:Span" %t279, { i64, ptr } %t280)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s8)
  br label %bb64
bb64:
  %t281 = load i64, ptr %l11, !tbaa !24
  %t282 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t285 = icmp eq i64 %t281, %t282
  br i1 %t285, label %bb65, label %bb66
bb65:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/free:walker", ptr %t287, i32 0, i32 2
  %t290 = load i1, ptr %t289, !tbaa !21
  store i1 %t290, ptr %l123, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb67
bb67:
  %t292 = load i1, ptr %l123, !tbaa !21
  br i1 %t292, label %bb68, label %bb69
bb68:
  %t293 = load ptr, ptr %l7, !tbaa !29
  %t295 = getelementptr %"compiler/free:Free", ptr %t293, i32 0, i32 46
  %t296 = load i1, ptr %t295, !tbaa !21
  store i1 %t296, ptr %l126, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb70
bb70:
  %t298 = load i1, ptr %l126, !tbaa !21
  br i1 %t298, label %bb71, label %bb72
bb71:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/free:walker", ptr %t299, i32 0, i32 30
  %t302 = load i64, ptr %t301, !tbaa !24
  %t304 = icmp eq i64 %t302, 0
  store i1 %t304, ptr %l129, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb73
bb73:
  %t306 = load i1, ptr %l129, !tbaa !21
  br i1 %t306, label %bb74, label %bb75
bb74:
  %t307 = load ptr, ptr %l7, !tbaa !29
  store ptr %t307, ptr %l134, !tbaa !29
  %t308 = load i64, ptr %l10, !tbaa !24
  %t310 = call i64 @compiler_2ffree_2eoval(i64 %t308)
  store i64 %t310, ptr %l136
  br label %bb76
bb75:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb78
bb76:
  %t311 = load ptr, ptr %l134, !tbaa !29
  %t312 = load i64, ptr %l136, !tbaa !24
  %t313 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufPlace(ptr %v0, ptr %t311, i64 %t312)
  store i1 %t313, ptr %l137
  br label %bb77
bb77:
  %t314 = load i1, ptr %l137, !tbaa !21
  store i1 %t314, ptr %l133, !tbaa !21
  br label %bb78
bb78:
  %t315 = load i1, ptr %l133, !tbaa !21
  br i1 %t315, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s10
  %t316 = load ptr, ptr %l7, !tbaa !29
  store ptr %t316, ptr %l138, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l2
  %t321 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s10, ptr %t317, %"compiler/source:Span" %t318)
  store { i64, ptr } %t321, ptr %l141
  br label %bb81
bb80:
  br label %bb84
bb81:
  %t322 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t324 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t324, 1
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t327 = add i64 %t323, %t326
  %t328 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t329 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t330 = add i64 %t327, %t329
  %t331 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t330)
  call void @olang_textcopy(ptr %t331, ptr %t322, i64 %t323)
  %t332 = getelementptr i8, ptr %t331, i64 %t323
  call void @olang_textcopy(ptr %t332, ptr %t325, i64 %t326)
  %t333 = getelementptr i8, ptr %t332, i64 %t326
  call void @olang_textcopy(ptr %t333, ptr %t328, i64 %t329)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t331, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } %t335, 1
  %t339 = mul i64 %t337, 1
  %t340 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t338, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  store { i64, ptr } %t342, ptr %l143, !tbaa !27
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t343)
  store ptr %t345, ptr %l145
  br label %bb82
bb82:
  %t346 = load ptr, ptr %l145, !tbaa !29
  %t348 = getelementptr %"compiler/typed:Body", ptr %t346, i32 0, i32 3
  %t349 = load i64, ptr %t348, !tbaa !24
  %t350 = load %"compiler/source:Span", ptr %l2
  %t351 = load ptr, ptr %l138, !tbaa !29
  %t352 = load { i64, ptr }, ptr %l143, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufNot(ptr %v0, ptr %s10, ptr %t351, { i64, ptr } %t352, i64 %t349, %"compiler/source:Span" %t350)
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t355 = load i64, ptr %l9, !tbaa !24
  %t357 = add i64 %t355, 1
  store i64 %t357, ptr %l9, !tbaa !24
  br label %bb1
bb86:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescapedHolder(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, [2 x i64] }
  %l7 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i64
  %l15 = alloca i1
  %l19 = alloca %"compiler/typed:Local"
  %l22 = alloca i1
  %l24 = alloca i64
  %l28 = alloca i64
  %l35 = alloca %"compiler/typed:Plan"
  %l37 = alloca %"compiler/typed:Plan"
  %l43 = alloca { i64, ptr }
  %l48 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i32
  %l60 = alloca %"compiler/typed:Local"
  %l65 = alloca i1
  %l69 = alloca i64
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, [2 x i64] }
  %l79 = alloca %"compiler/typed:Local"
  %l80 = alloca i32
  %l82 = alloca { i64, ptr }
  %l84 = alloca i32
  %l86 = alloca i1
  %l92 = alloca ptr
  %l96 = alloca %"compiler/typed:Local"
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %t56 = alloca %"compiler/typed:Plan", align 8
  %t59 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i64 @compiler_2ftyped_2eDropHolder(ptr %v0, ptr %v1, ptr %t5, ptr %a1)
  store i64 %t9, ptr %l12
  br label %bb2
bb2:
  %t10 = load i64, ptr %l12, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb4:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Body", ptr %t15, i32 0, i32 7
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t17, i64 %t18)
  store %"compiler/typed:Local" %t21, ptr %l19
  br label %bb5
bb5:
  %t22 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 4
  %t23 = load i32, ptr %t22, !range !{i32 0, i32 7}
  %t25 = trunc i64 6 to i32
  %t26 = icmp eq i32 %t23, %t25
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb10
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l24, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:walker", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 3
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l28
  br label %bb9
bb9:
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  %t43 = icmp sge i64 %t41, %t42
  store i1 %t43, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/free:walker", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t56, ptr %v0, ptr %v0, ptr %t51, i64 %t55)
  call void @llvm.memmove.p0.p0.i64(ptr %l35, ptr %t56, i64 568, i1 false)
  br label %bb14
bb14:
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t59, ptr %v0, ptr %l35)
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %t59, i64 568, i1 false)
  br label %bb15
bb15:
  %t61 = getelementptr %"compiler/typed:Plan", ptr %l37, i32 0, i32 1
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l4, !tbaa !27
  %t64 = load i64, ptr %l3, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t70 = icmp sge i64 %t64, %t67
  br i1 %t70, label %bb16, label %bb17
bb16:
  br label %ret
bb17:
  br label %bb18
bb18:
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t72, ptr %l43, !tbaa !27
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr { i64, [2 x i64] }, ptr %t76, i64 %t73
  %t78 = load { i64, [2 x i64] }, ptr %t77
  store { i64, [2 x i64] } %t78, ptr %l5
  %t80 = load { i64, [2 x i64] }, ptr %l5
  %t82 = extractvalue { i64, [2 x i64] } %t80, 0
  %t83 = icmp eq i64 %t82, 5
  br i1 %t83, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb21
bb20:
  %t85 = load { i64, [2 x i64] }, ptr %l5
  %t87 = extractvalue { i64, [2 x i64] } %t85, 0
  %t88 = icmp eq i64 %t87, 0
  store i1 %t88, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t90 = load i1, ptr %l48, !tbaa !21
  br i1 %t90, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb28
bb23:
  %t91 = load { i64, [2 x i64] }, ptr %l5
  %t93 = extractvalue { i64, [2 x i64] } %t91, 0
  %t94 = icmp eq i64 %t93, 1
  br i1 %t94, label %bb24, label %bb25
bb24:
  %t96 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t97 = getelementptr { i32 }, ptr %t96, i32 0, i32 0
  %t98 = load i32, ptr %t97
  store i32 %t98, ptr %l56, !tbaa !23
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Body", ptr %t101, i32 0, i32 7
  %t104 = load i64, ptr %l3, !tbaa !24
  %t107 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t103, i64 %t104)
  store %"compiler/typed:Local" %t107, ptr %l60
  br label %bb26
bb25:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb27
bb26:
  %t108 = getelementptr %"compiler/typed:Local", ptr %l60, i32 0, i32 3
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = load i32, ptr %l56, !tbaa !23
  %t112 = icmp eq i32 %t110, %t109
  store i1 %t112, ptr %l54, !tbaa !21
  br label %bb27
bb27:
  %t114 = load i1, ptr %l54, !tbaa !21
  store i1 %t114, ptr %l51, !tbaa !21
  br label %bb28
bb28:
  %t115 = load i1, ptr %l51, !tbaa !21
  store i1 %t115, ptr %l7, !tbaa !21
  %t116 = load i1, ptr %l7, !tbaa !21
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb29, label %bb30
bb29:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/free:walker", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/free:Free", ptr %t123, i32 0, i32 116
  %t126 = load i1, ptr %t125, !tbaa !21
  store i1 %t126, ptr %l65, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb31
bb31:
  %t128 = load i1, ptr %l65, !tbaa !21
  br i1 %t128, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s3
  %t129 = load i64, ptr %l3, !tbaa !24
  store i64 %t129, ptr %l69, !tbaa !24
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/free:walker", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:walker", ptr %t134, i32 0, i32 1
  %t137 = load i64, ptr %t136, !tbaa !24
  %t140 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s3, ptr %t133, i64 %t137)
  store { i64, ptr } %t140, ptr %l74
  br label %bb34
bb33:
  br label %bb43
bb34:
  %t141 = load { i64, [2 x i64] }, ptr %l5
  store { i64, [2 x i64] } %t141, ptr %l75
  %t142 = load ptr, ptr %l2, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Body", ptr %t142, i32 0, i32 7
  %t145 = load i64, ptr %l3, !tbaa !24
  %t148 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t144, i64 %t145)
  store %"compiler/typed:Local" %t148, ptr %l79
  br label %bb35
bb35:
  %t149 = getelementptr %"compiler/typed:Local", ptr %l79, i32 0, i32 3
  %t150 = load i32, ptr %t149, !tbaa !23
  store i32 %t150, ptr %l80, !tbaa !23
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t151 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t151, i64 %t152)
  %t153 = load i64, ptr %l69, !tbaa !24
  %t154 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t155 = call i64 @__olang_fmt_i64(ptr %t154, i64 %t153)
  call void @__olang_sb_add(ptr %s4, i64 %t155)
  %t156 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t156, i64 %t157)
  %t158 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = extractvalue { i64, ptr } %t158, 0
  call void @__olang_sb_put(ptr %s4, ptr %t159, i64 %t160)
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t161, i64 %t162)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aScope(ptr %s4, ptr %l75, i64 0)
  br label %bb36
bb36:
  %t164 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t164, i64 %t165)
  %t166 = load i32, ptr %l80, !tbaa !23
  %t167 = sext i32 %t166 to i64
  %t168 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t169 = call i64 @__olang_fmt_i64(ptr %t168, i64 %t167)
  call void @__olang_sb_add(ptr %s4, i64 %t169)
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t170, i64 %t171)
  %t172 = load ptr, ptr %s4
  %t173 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t174 = load i64, ptr %t173
  %t175 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t172, i64 %t174)
  %t176 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  store { i64, ptr } %t177, ptr %l82, !tbaa !27
  %t178 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t179 = load ptr, ptr %t178
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %sbgrew.181, label %sbdone.182
sbgrew.181:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.182
sbdone.182:
  %t183 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  %t185 = extractvalue { i64, ptr } %t183, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  %t191 = call i32 @std_2fio_2ePutErr(ptr %s3, { i64, ptr } %t189)
  store i32 %t191, ptr %l84
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb38, label %ok.193, !prof !99
ok.193:
  br label %bb37
bb37:
  br label %bb42
bb38:
  %t194 = load i32, ptr %l84, !tbaa !23
  %t195 = ashr i32 %t194, 16
  %t197 = icmp eq i32 %t195, 1
  store i1 %t197, ptr %l86, !tbaa !21
  %t198 = load i32, ptr %l84, !tbaa !23
  %t199 = ashr i32 %t198, 16
  %t201 = icmp eq i32 %t199, 1
  br i1 %t201, label %bb39, label %bb40
bb39:
  call void @__olang_errpay_pop()
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  %t203 = load i1, ptr %l7, !tbaa !21
  %t205 = xor i1 %t203, true
  br i1 %t205, label %bb44, label %bb45
bb44:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/free:walker", ptr %t207, i32 0, i32 0
  %t210 = load ptr, ptr %t209, !tbaa !29
  store ptr %t210, ptr %l92, !tbaa !29
  %t211 = load ptr, ptr %l2, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Body", ptr %t211, i32 0, i32 7
  %t214 = load i64, ptr %l3, !tbaa !24
  %t217 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t213, i64 %t214)
  store %"compiler/typed:Local" %t217, ptr %l96
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t218 = getelementptr %"compiler/typed:Local", ptr %l96, i32 0, i32 2
  %t219 = load i32, ptr %t218, !tbaa !23
  %t220 = load ptr, ptr %l92, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eregister(ptr %v0, ptr %t220, i32 %t219)
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i1
  %l12 = alloca i1
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexprOf(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t6, ptr %lp2
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t8 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %t8
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/free:walker", ptr %t9, i32 0, i32 2
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 46
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l8, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 30
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l12, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l12, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = load ptr, ptr %lp2
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2enoteView(ptr %v0, ptr %v1, ptr %v2, ptr %t31, ptr %t32, ptr %t33)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %lp2
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeeder(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l8 = alloca i64
  %l11 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca i64
  %l20 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 110
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eLen_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l8
  br label %bb3
bb3:
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = icmp eq i64 %t13, 0
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l4, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/free:walker", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/free:Free", ptr %t21, i32 0, i32 111
  store ptr %t23, ptr %l14, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/free:walker", ptr %t24, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t27, i64 %t28)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, ptr %l18
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l14, !tbaa !29
  %t33 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  %t34 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t33)
  %t35 = extractvalue { i32, i64 } %t34, 1
  %t36 = extractvalue { i32, i64 } %t34, 0
  store i32 %t36, ptr %l20
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb10, label %ok.38, !prof !99
ok.38:
  store i64 %t35, ptr %l19
  br label %bb9
bb9:
  %t39 = load i64, ptr %l19, !tbaa !24
  store i64 %t39, ptr %l11, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i64, ptr %l11, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efixedParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i1
  %l11 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i32
  %l23 = alloca i1
  %l26 = alloca i1
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i32
  %l38 = alloca i1
  %l45 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2epastAway(ptr %v1, ptr %v1, ptr %t1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  %t5 = call i64 @compiler_2ffree_2ereadLocalOf(ptr %v1, ptr %t4)
  store i64 %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb6
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t11)
  store ptr %t13, ptr %l11
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Body", ptr %t14, i32 0, i32 14
  %t17 = load i1, ptr %t16, !tbaa !21
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  store i64 -1, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:walker", ptr %t21, i32 0, i32 6
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t23, i64 %t24)
  %t28 = extractvalue { i32, i64 } %t27, 1
  %t29 = extractvalue { i32, i64 } %t27, 0
  store i32 %t29, ptr %l20
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb11, label %ok.31, !prof !99
ok.31:
  store i64 %t28, ptr %l19
  br label %bb10
bb10:
  %t32 = load i64, ptr %l19, !tbaa !24
  store i64 %t32, ptr %l15, !tbaa !24
  br label %bb13
bb11:
  br label %bb12
bb12:
  store i64 -1, ptr %l15, !tbaa !24
  br label %bb13
bb13:
  %t33 = load i64, ptr %l15, !tbaa !24
  store i64 %t33, ptr %l3, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp slt i64 %t34, 0
  br i1 %t36, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb16
bb15:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = icmp sge i64 %t38, 62
  store i1 %t40, ptr %l23, !tbaa !21
  br label %bb16
bb16:
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb24
bb18:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t43)
  store ptr %t45, ptr %l28
  br label %bb19
bb19:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t46)
  store ptr %t48, ptr %l30
  br label %bb20
bb20:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t49)
  store i32 %t51, ptr %l32
  br label %bb21
bb21:
  %t52 = load ptr, ptr %l30, !tbaa !29
  %t53 = load i32, ptr %l32, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l33
  br label %bb22
bb22:
  %t55 = load ptr, ptr %l28, !tbaa !29
  %t56 = load i32, ptr %l33, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t57, ptr %l34
  br label %bb23
bb23:
  %t58 = load i32, ptr %l34, !range !{i32 0, i32 33}
  %t60 = trunc i64 21 to i32
  %t61 = icmp eq i32 %t58, %t60
  %t63 = xor i1 %t61, true
  store i1 %t63, ptr %l26, !tbaa !21
  br label %bb24
bb24:
  %t65 = load i1, ptr %l26, !tbaa !21
  br i1 %t65, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb28
bb26:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/free:Free", ptr %t69, i32 0, i32 2
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 1
  %t76 = load i64, ptr %t75, !tbaa !24
  %t77 = load i64, ptr %l2, !tbaa !24
  %t81 = call i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eAssignedLocal(ptr %v0, ptr %t72, i64 %t76, i64 %t77)
  store i1 %t81, ptr %l45
  br label %bb27
bb27:
  %t82 = load i1, ptr %l45, !tbaa !21
  store i1 %t82, ptr %l38, !tbaa !21
  br label %bb28
bb28:
  %t83 = load i1, ptr %l38, !tbaa !21
  br i1 %t83, label %bb29, label %bb30
bb29:
  store i64 -1, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t85 = load i64, ptr %l3, !tbaa !24
  store i64 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, { i64, ptr } }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, { i64, ptr } }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca { i64, ptr }
  %l58 = alloca { i64, { i64, ptr } }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, { i64, ptr } }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca i1
  %l84 = alloca i64
  %l87 = alloca i1
  %l91 = alloca { i64, ptr }
  %l93 = alloca { i64, { i64, ptr } }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l106 = alloca { i64, { i64, ptr } }
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %l113 = alloca i64
  %l119 = alloca { i64, ptr }
  %l121 = alloca { i64, { i64, ptr } }
  %l122 = alloca { i64, ptr }
  %l123 = alloca i64
  %l124 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l133 = alloca { i64, { i64, ptr } }
  %l134 = alloca { i64, ptr }
  %l135 = alloca i64
  %l136 = alloca { i64, ptr }
  %l140 = alloca i64
  %l143 = alloca i1
  %l149 = alloca i1
  %l150 = alloca i64
  %l153 = alloca i64
  %l158 = alloca ptr
  %l160 = alloca ptr
  %l164 = alloca i32
  %l166 = alloca %"compiler/typed:Local"
  %l168 = alloca { i64, ptr }
  %l174 = alloca ptr
  %l179 = alloca %"compiler/source:Span"
  %l182 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l184 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l195 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l202 = alloca { i64, { i64, ptr } }
  %l203 = alloca { i64, ptr }
  %l204 = alloca i64
  %l205 = alloca { i64, ptr }
  %l209 = alloca i1
  %l213 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l221 = alloca { i64, { i64, ptr } }
  %l222 = alloca { i64, ptr }
  %l223 = alloca i64
  %l224 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l227 = alloca { i64, { i64, ptr } }
  %l228 = alloca { i64, ptr }
  %l229 = alloca i64
  %l230 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l16
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l16, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t11 = load ptr, ptr %l17, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l17, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 5
  store i1 %t17, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l18, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Promote", ptr %t25, i32 0, i32 1
  %t28 = load i32, ptr %t27, !tbaa !23
  %t30 = sext i32 %t28 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t33 = insertvalue { i64, { i64, ptr } } undef, i64 %t30, 0
  %t35 = insertvalue { i64, { i64, ptr } } %t33, { i64, ptr } %t31, 1
  store { i64, { i64, ptr } } %t35, ptr %l28
  %t36 = getelementptr { i64, { i64, ptr } }, ptr %l28, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l29, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l30, !tbaa !24
  %t40 = load i64, ptr %l30, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l30, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t52 = getelementptr { i64, { i64, ptr } }, ptr %l28, i32 0, i32 1
  store { i64, ptr } %t51, ptr %t52, !tbaa !27
  %t53 = load { i64, { i64, ptr } }, ptr %l28
  store { i64, { i64, ptr } } %t53, ptr %rv
  br label %ret
bb7:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb8, label %bb9
bb8:
  %t58 = load ptr, ptr %l32, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 7
  store i1 %t61, ptr %l33, !tbaa !21
  br label %bb9
bb9:
  %t62 = load i1, ptr %l33, !tbaa !21
  br i1 %t62, label %bb10, label %bb11
bb10:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Make", ptr %t69, i32 0, i32 4
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = sext i32 %t72 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = insertvalue { i64, { i64, ptr } } undef, i64 %t74, 0
  %t79 = insertvalue { i64, { i64, ptr } } %t77, { i64, ptr } %t75, 1
  store { i64, { i64, ptr } } %t79, ptr %l43
  %t80 = getelementptr { i64, { i64, ptr } }, ptr %l43, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l44, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l45, !tbaa !24
  %t84 = load i64, ptr %l45, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l46, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l45, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t96 = getelementptr { i64, { i64, ptr } }, ptr %l43, i32 0, i32 1
  store { i64, ptr } %t95, ptr %t96, !tbaa !27
  %t97 = load { i64, { i64, ptr } }, ptr %l43
  store { i64, { i64, ptr } } %t97, ptr %rv
  br label %ret
bb13:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t99 = load ptr, ptr %l47, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb14, label %bb15
bb14:
  %t102 = load ptr, ptr %l47, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 18}
  %t105 = icmp eq i64 %t103, 16
  store i1 %t105, ptr %l48, !tbaa !21
  br label %bb15
bb15:
  %t106 = load i1, ptr %l48, !tbaa !21
  br i1 %t106, label %bb16, label %bb17
bb16:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l6, !tbaa !29
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Text", ptr %t113, i32 0, i32 1
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = sext i32 %t116 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l56, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t121 = insertvalue { i64, { i64, ptr } } undef, i64 %t118, 0
  %t123 = insertvalue { i64, { i64, ptr } } %t121, { i64, ptr } %t119, 1
  store { i64, { i64, ptr } } %t123, ptr %l58
  %t124 = getelementptr { i64, { i64, ptr } }, ptr %l58, i32 0, i32 1
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l59, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l60, !tbaa !24
  %t128 = load i64, ptr %l60, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l61, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l60, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t140 = getelementptr { i64, { i64, ptr } }, ptr %l58, i32 0, i32 1
  store { i64, ptr } %t139, ptr %t140, !tbaa !27
  %t141 = load { i64, { i64, ptr } }, ptr %l58
  store { i64, { i64, ptr } } %t141, ptr %rv
  br label %ret
bb19:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t143 = load ptr, ptr %l62, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb20, label %bb21
bb20:
  %t146 = load ptr, ptr %l62, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 18}
  %t149 = icmp eq i64 %t147, 8
  store i1 %t149, ptr %l63, !tbaa !21
  br label %bb21
bb21:
  %t150 = load i1, ptr %l63, !tbaa !21
  br i1 %t150, label %bb22, label %bb23
bb22:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l7, !tbaa !29
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Collect", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %t159, !tbaa !23
  %t162 = sext i32 %t160 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l71, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t165 = insertvalue { i64, { i64, ptr } } undef, i64 %t162, 0
  %t167 = insertvalue { i64, { i64, ptr } } %t165, { i64, ptr } %t163, 1
  store { i64, { i64, ptr } } %t167, ptr %l73
  %t168 = getelementptr { i64, { i64, ptr } }, ptr %l73, i32 0, i32 1
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l74, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l75, !tbaa !24
  %t172 = load i64, ptr %l75, !tbaa !24
  %t173 = mul i64 %t172, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t173)
  %t175 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l76, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l75, !tbaa !24
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  %t183 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t184 = getelementptr { i64, { i64, ptr } }, ptr %l73, i32 0, i32 1
  store { i64, ptr } %t183, ptr %t184, !tbaa !27
  %t185 = load { i64, { i64, ptr } }, ptr %l73
  store { i64, { i64, ptr } } %t185, ptr %rv
  br label %ret
bb25:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t187 = load ptr, ptr %l77, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb26, label %bb27
bb26:
  %t190 = load ptr, ptr %l77, !tbaa !29
  %t191 = load i64, ptr %t190, !range !{i64 0, i64 18}
  %t193 = icmp eq i64 %t191, 6
  store i1 %t193, ptr %l78, !tbaa !21
  br label %bb27
bb27:
  %t194 = load i1, ptr %l78, !tbaa !21
  br i1 %t194, label %bb28, label %bb29
bb28:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t197, i32 0, i32 2
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l8, !tbaa !29
  br label %bb30
bb29:
  br label %bb78
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t201 = load ptr, ptr %l8, !tbaa !29
  %t203 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t201)
  store i64 %t203, ptr %l84
  br label %bb31
bb31:
  %t204 = load i64, ptr %l84, !tbaa !24
  store i64 %t204, ptr %l9, !tbaa !24
  %t205 = load i64, ptr %l9, !tbaa !24
  %t207 = icmp slt i64 %t205, 0
  br i1 %t207, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb34
bb33:
  %t209 = load ptr, ptr %l8, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Call", ptr %t209, i32 0, i32 2
  %t212 = load i32, ptr %t211, !tbaa !23
  %t214 = icmp slt i32 %t212, 0
  store i1 %t214, ptr %l87, !tbaa !21
  br label %bb34
bb34:
  %t216 = load i1, ptr %l87, !tbaa !21
  br i1 %t216, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l91, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t218 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t220 = insertvalue { i64, { i64, ptr } } %t218, { i64, ptr } %t217, 1
  store { i64, { i64, ptr } } %t220, ptr %l93
  %t221 = getelementptr { i64, { i64, ptr } }, ptr %l93, i32 0, i32 1
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  store { i64, ptr } %t222, ptr %l94, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  store i64 %t224, ptr %l95, !tbaa !24
  %t225 = load i64, ptr %l95, !tbaa !24
  %t226 = mul i64 %t225, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t226)
  %t228 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  store { i64, ptr } %t229, ptr %l96, !tbaa !27
  %t230 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = load i64, ptr %l95, !tbaa !24
  %t235 = mul i64 %t234, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t231, ptr %t233, i64 %t235, i1 false)
  %t236 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t237 = getelementptr { i64, { i64, ptr } }, ptr %l93, i32 0, i32 1
  store { i64, ptr } %t236, ptr %t237, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t238 = load { i64, { i64, ptr } }, ptr %l93
  store { i64, { i64, ptr } } %t238, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t239 = load ptr, ptr %l2, !tbaa !29
  %t241 = getelementptr %"compiler/free:Free", ptr %t239, i32 0, i32 1
  %t242 = load i64, ptr %l9, !tbaa !24
  %t245 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t241, i64 %t242)
  store ptr %t245, ptr %l100
  br label %bb38
bb38:
  %t246 = load ptr, ptr %l100, !tbaa !29
  store ptr %t246, ptr %l10, !tbaa !29
  %t247 = load ptr, ptr %l10, !tbaa !29
  %t249 = getelementptr %"compiler/typed:Body", ptr %t247, i32 0, i32 11
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = icmp eq ptr %t250, null
  br i1 %t252, label %bb39, label %bb40
bb39:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l104, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t255 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t257 = insertvalue { i64, { i64, ptr } } %t255, { i64, ptr } %t254, 1
  store { i64, { i64, ptr } } %t257, ptr %l106
  %t258 = getelementptr { i64, { i64, ptr } }, ptr %l106, i32 0, i32 1
  %t259 = load { i64, ptr }, ptr %t258, !tbaa !27
  store { i64, ptr } %t259, ptr %l107, !tbaa !27
  %t260 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 0
  store i64 %t261, ptr %l108, !tbaa !24
  %t262 = load i64, ptr %l108, !tbaa !24
  %t263 = mul i64 %t262, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t263)
  %t265 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  store { i64, ptr } %t266, ptr %l109, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = load i64, ptr %l108, !tbaa !24
  %t272 = mul i64 %t271, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t268, ptr %t270, i64 %t272, i1 false)
  %t273 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t274 = getelementptr { i64, { i64, ptr } }, ptr %l106, i32 0, i32 1
  store { i64, ptr } %t273, ptr %t274, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t275 = load { i64, { i64, ptr } }, ptr %l106
  store { i64, { i64, ptr } } %t275, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t276 = load ptr, ptr %l3, !tbaa !29
  %t277 = load ptr, ptr %l10, !tbaa !29
  %t279 = getelementptr %"compiler/typed:Body", ptr %t277, i32 0, i32 2
  %t280 = load i32, ptr %t279, !tbaa !23
  %t283 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t276, i32 %t280)
  store i64 %t283, ptr %l113
  br label %bb42
bb42:
  %t284 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t285 = load i64, ptr %l113, !tbaa !24
  %t287 = icmp eq i64 %t285, %t284
  br i1 %t287, label %bb43, label %bb44
bb43:
  %t289 = load ptr, ptr %l8, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Call", ptr %t289, i32 0, i32 2
  %t292 = load i32, ptr %t291, !tbaa !23
  %t294 = sext i32 %t292 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l119, !tbaa !27
  %t295 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t297 = insertvalue { i64, { i64, ptr } } undef, i64 %t294, 0
  %t299 = insertvalue { i64, { i64, ptr } } %t297, { i64, ptr } %t295, 1
  store { i64, { i64, ptr } } %t299, ptr %l121
  %t300 = getelementptr { i64, { i64, ptr } }, ptr %l121, i32 0, i32 1
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !27
  store { i64, ptr } %t301, ptr %l122, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t302, 0
  store i64 %t303, ptr %l123, !tbaa !24
  %t304 = load i64, ptr %l123, !tbaa !24
  %t305 = mul i64 %t304, 1
  %t306 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t305)
  %t307 = insertvalue { i64, ptr } undef, i64 %t304, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t306, 1
  store { i64, ptr } %t308, ptr %l124, !tbaa !27
  %t309 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = load i64, ptr %l123, !tbaa !24
  %t314 = mul i64 %t313, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t310, ptr %t312, i64 %t314, i1 false)
  %t315 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t316 = getelementptr { i64, { i64, ptr } }, ptr %l121, i32 0, i32 1
  store { i64, ptr } %t315, ptr %t316, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t317 = load { i64, { i64, ptr } }, ptr %l121
  store { i64, { i64, ptr } } %t317, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t318 = load ptr, ptr %l3, !tbaa !29
  %t319 = load ptr, ptr %l10, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Body", ptr %t319, i32 0, i32 2
  %t322 = load i32, ptr %t321, !tbaa !23
  %t325 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s5, ptr %t318, i32 %t322)
  store { i64, ptr } %t325, ptr %l128
  br label %bb46
bb46:
  %t326 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 0
  %t329 = icmp ne i64 %t327, 1
  br i1 %t329, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l131, !tbaa !27
  %t331 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t332 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t334 = insertvalue { i64, { i64, ptr } } %t332, { i64, ptr } %t331, 1
  store { i64, { i64, ptr } } %t334, ptr %l133
  %t335 = getelementptr { i64, { i64, ptr } }, ptr %l133, i32 0, i32 1
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  store { i64, ptr } %t336, ptr %l134, !tbaa !27
  %t337 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t338 = extractvalue { i64, ptr } %t337, 0
  store i64 %t338, ptr %l135, !tbaa !24
  %t339 = load i64, ptr %l135, !tbaa !24
  %t340 = mul i64 %t339, 1
  %t341 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t340)
  %t342 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t341, 1
  store { i64, ptr } %t343, ptr %l136, !tbaa !27
  %t344 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = load i64, ptr %l135, !tbaa !24
  %t349 = mul i64 %t348, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t345, ptr %t347, i64 %t349, i1 false)
  %t350 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t351 = getelementptr { i64, { i64, ptr } }, ptr %l133, i32 0, i32 1
  store { i64, ptr } %t350, ptr %t351, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t352 = load { i64, { i64, ptr } }, ptr %l133
  store { i64, { i64, ptr } } %t352, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t353 = load ptr, ptr %l3, !tbaa !29
  %t354 = load ptr, ptr %l10, !tbaa !29
  %t356 = getelementptr %"compiler/typed:Body", ptr %t354, i32 0, i32 2
  %t357 = load i32, ptr %t356, !tbaa !23
  %t360 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t353, i32 %t357, i64 0)
  store i64 %t360, ptr %l140
  br label %bb50
bb50:
  %t361 = load i64, ptr %l140, !tbaa !24
  store i64 %t361, ptr %l11, !tbaa !24
  %t362 = load i64, ptr %l11, !tbaa !24
  %t364 = icmp sge i64 %t362, 0
  br i1 %t364, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb53
bb52:
  %t366 = load i64, ptr %l11, !tbaa !24
  %t367 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t370 = icmp eq i64 %t366, %t367
  store i1 %t370, ptr %l143, !tbaa !21
  br label %bb53
bb53:
  %t372 = load i1, ptr %l143, !tbaa !21
  br i1 %t372, label %bb54, label %bb55
bb54:
  %t373 = load i64, ptr %l11, !tbaa !24
  %t375 = icmp sge i64 %t373, 0
  br i1 %t375, label %bb56, label %bb57
bb55:
  br label %bb72
bb56:
  %t377 = load i64, ptr %l11, !tbaa !24
  store i64 %t377, ptr %l150, !tbaa !24
  %t378 = load ptr, ptr %l10, !tbaa !29
  %t380 = getelementptr %"compiler/typed:Body", ptr %t378, i32 0, i32 5
  %t382 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t380)
  store i64 %t382, ptr %l153
  br label %bb58
bb57:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb59
bb58:
  %t383 = load i64, ptr %l150, !tbaa !24
  %t384 = load i64, ptr %l153, !tbaa !24
  %t385 = icmp slt i64 %t383, %t384
  store i1 %t385, ptr %l149, !tbaa !21
  br label %bb59
bb59:
  %t387 = load i1, ptr %l149, !tbaa !21
  br i1 %t387, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t388 = load ptr, ptr %l2, !tbaa !29
  %t390 = getelementptr %"compiler/free:Free", ptr %t388, i32 0, i32 0
  %t391 = load ptr, ptr %t390, !tbaa !29
  %t393 = getelementptr %"compiler/generic:Program", ptr %t391, i32 0, i32 0
  %t394 = load ptr, ptr %t393, !tbaa !29
  %t396 = getelementptr %"compiler/load:Loader", ptr %t394, i32 0, i32 3
  %t397 = load ptr, ptr %t396, !tbaa !29
  store ptr %t397, ptr %l158, !tbaa !29
  %t398 = load ptr, ptr %l10, !tbaa !29
  %t400 = getelementptr %"compiler/typed:Body", ptr %t398, i32 0, i32 7
  store ptr %t400, ptr %l160, !tbaa !29
  %t401 = load ptr, ptr %l10, !tbaa !29
  %t403 = getelementptr %"compiler/typed:Body", ptr %t401, i32 0, i32 5
  %t404 = load i64, ptr %l11, !tbaa !24
  %t407 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t403, i64 %t404)
  store i32 %t407, ptr %l164
  br label %bb62
bb61:
  br label %bb71
bb62:
  %t408 = load i32, ptr %l164, !tbaa !23
  %t409 = sext i32 %t408 to i64
  %t410 = load ptr, ptr %l160, !tbaa !29
  %t412 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t410, i64 %t409)
  store %"compiler/typed:Local" %t412, ptr %l166
  br label %bb63
bb63:
  %t413 = getelementptr %"compiler/typed:Local", ptr %l166, i32 0, i32 0
  %t414 = load i32, ptr %t413, !tbaa !23
  %t415 = load ptr, ptr %l158, !tbaa !29
  %t417 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t415, i32 %t414)
  store { i64, ptr } %t417, ptr %l168
  br label %bb64
bb64:
  %t418 = load { i64, ptr }, ptr %l168, !tbaa !27
  store { i64, ptr } %t418, ptr %l12, !tbaa !27
  %t419 = load ptr, ptr %l2, !tbaa !29
  %t420 = load i64, ptr %l9, !tbaa !24
  %t423 = getelementptr %"compiler/free:Free", ptr %t419, i32 0, i32 91
  store i64 %t420, ptr %t423, !tbaa !24
  %t424 = load ptr, ptr %l2, !tbaa !29
  %t425 = load ptr, ptr %l10, !tbaa !29
  %t427 = getelementptr %"compiler/typed:Body", ptr %t425, i32 0, i32 3
  %t428 = load i64, ptr %t427, !tbaa !24
  %t431 = getelementptr %"compiler/free:Free", ptr %t424, i32 0, i32 92
  store i64 %t428, ptr %t431, !tbaa !24
  %t432 = load ptr, ptr %l2, !tbaa !29
  store ptr %t432, ptr %l174, !tbaa !29
  %t433 = load ptr, ptr %l10, !tbaa !29
  %t435 = getelementptr %"compiler/typed:Body", ptr %t433, i32 0, i32 4
  %t436 = getelementptr %"compiler/source:Span", ptr %t435, i32 0, i32 0
  %t437 = load i32, ptr %t436, !tbaa !23
  %t438 = load ptr, ptr %l10, !tbaa !29
  %t440 = getelementptr %"compiler/typed:Body", ptr %t438, i32 0, i32 4
  %t441 = getelementptr %"compiler/source:Span", ptr %t440, i32 0, i32 0
  %t442 = load i32, ptr %t441, !tbaa !23
  %t445 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 %t437, i32 %t442)
  store %"compiler/source:Span" %t445, ptr %l179
  br label %bb65
bb65:
  %t446 = load %"compiler/source:Span", ptr %l179
  %t447 = load ptr, ptr %l174, !tbaa !29
  %t448 = getelementptr %"compiler/free:Free", ptr %t447, i32 0, i32 93
  store %"compiler/source:Span" %t446, ptr %t448
  %t449 = load ptr, ptr %l2, !tbaa !29
  %t450 = load i64, ptr %l9, !tbaa !24
  %t453 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s11, ptr %t449, i64 %t450)
  store { i64, ptr } %t453, ptr %l182
  br label %bb66
bb66:
  %t454 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t454, ptr %l183, !tbaa !27
  %t455 = load ptr, ptr %l2, !tbaa !29
  store ptr %t455, ptr %l184, !tbaa !29
  %t456 = load ptr, ptr %l3, !tbaa !29
  %t457 = load ptr, ptr %l10, !tbaa !29
  %t459 = getelementptr %"compiler/typed:Body", ptr %t457, i32 0, i32 2
  %t460 = load i32, ptr %t459, !tbaa !23
  %t463 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s11, ptr %t456, i32 %t460)
  store { i64, ptr } %t463, ptr %l188
  br label %bb67
bb67:
  %t464 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t465 = load ptr, ptr %t464, !tbaa !27
  %t466 = getelementptr i32, ptr %t465, i64 0
  %t467 = load i32, ptr %t466, !tbaa !33
  %t468 = load ptr, ptr %l184, !tbaa !29
  %t470 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebuiltSpell(ptr %v0, ptr %s11, ptr %t468, i32 %t467)
  store { i64, ptr } %t470, ptr %l190
  br label %bb68
bb68:
  %t471 = load ptr, ptr %l2, !tbaa !29
  store ptr %t471, ptr %l191, !tbaa !29
  %t472 = load ptr, ptr %l3, !tbaa !29
  %t473 = load ptr, ptr %l10, !tbaa !29
  %t475 = getelementptr %"compiler/typed:Body", ptr %t473, i32 0, i32 2
  %t476 = load i32, ptr %t475, !tbaa !23
  %t479 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s11, ptr %t472, i32 %t476)
  store { i64, ptr } %t479, ptr %l195
  br label %bb69
bb69:
  %t480 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = getelementptr i32, ptr %t481, i64 0
  %t483 = load i32, ptr %t482, !tbaa !33
  %t484 = load ptr, ptr %l191, !tbaa !29
  %t486 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewhat(ptr %v0, ptr %s11, ptr %t484, i32 %t483)
  store { i64, ptr } %t486, ptr %l197
  br label %bb70
bb70:
  %t487 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t488 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t489 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t490 = extractvalue { i64, ptr } %t489, 1
  %t491 = extractvalue { i64, ptr } %t489, 0
  %t492 = add i64 %t488, %t491
  %t493 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t494 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t495 = add i64 %t492, %t494
  %t496 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t496, 1
  %t498 = extractvalue { i64, ptr } %t496, 0
  %t499 = add i64 %t495, %t498
  %t500 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t501 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t502 = add i64 %t499, %t501
  %t503 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t503, 1
  %t505 = extractvalue { i64, ptr } %t503, 0
  %t506 = add i64 %t502, %t505
  %t507 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t508 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t509 = add i64 %t506, %t508
  %t510 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t511 = extractvalue { i64, ptr } %t510, 1
  %t512 = extractvalue { i64, ptr } %t510, 0
  %t513 = add i64 %t509, %t512
  %t514 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t513)
  call void @olang_textcopy(ptr %t514, ptr %t487, i64 %t488)
  %t515 = getelementptr i8, ptr %t514, i64 %t488
  call void @olang_textcopy(ptr %t515, ptr %t490, i64 %t491)
  %t516 = getelementptr i8, ptr %t515, i64 %t491
  call void @olang_textcopy(ptr %t516, ptr %t493, i64 %t494)
  %t517 = getelementptr i8, ptr %t516, i64 %t494
  call void @olang_textcopy(ptr %t517, ptr %t497, i64 %t498)
  %t518 = getelementptr i8, ptr %t517, i64 %t498
  call void @olang_textcopy(ptr %t518, ptr %t500, i64 %t501)
  %t519 = getelementptr i8, ptr %t518, i64 %t501
  call void @olang_textcopy(ptr %t519, ptr %t504, i64 %t505)
  %t520 = getelementptr i8, ptr %t519, i64 %t505
  call void @olang_textcopy(ptr %t520, ptr %t507, i64 %t508)
  %t521 = getelementptr i8, ptr %t520, i64 %t508
  call void @olang_textcopy(ptr %t521, ptr %t511, i64 %t512)
  %t522 = insertvalue { i64, ptr } undef, i64 %t513, 0
  %t523 = insertvalue { i64, ptr } %t522, ptr %t514, 1
  %t524 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t526 = insertvalue { i64, { i64, ptr } } %t524, { i64, ptr } %t523, 1
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s5)
  store { i64, { i64, ptr } } %t526, ptr %rv
  br label %ret
bb71:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l200, !tbaa !27
  %t528 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t529 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t531 = insertvalue { i64, { i64, ptr } } %t529, { i64, ptr } %t528, 1
  store { i64, { i64, ptr } } %t531, ptr %l202
  %t532 = getelementptr { i64, { i64, ptr } }, ptr %l202, i32 0, i32 1
  %t533 = load { i64, ptr }, ptr %t532, !tbaa !27
  store { i64, ptr } %t533, ptr %l203, !tbaa !27
  %t534 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t535 = extractvalue { i64, ptr } %t534, 0
  store i64 %t535, ptr %l204, !tbaa !24
  %t536 = load i64, ptr %l204, !tbaa !24
  %t537 = mul i64 %t536, 1
  %t538 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t537)
  %t539 = insertvalue { i64, ptr } undef, i64 %t536, 0
  %t540 = insertvalue { i64, ptr } %t539, ptr %t538, 1
  store { i64, ptr } %t540, ptr %l205, !tbaa !27
  %t541 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = load i64, ptr %l204, !tbaa !24
  %t546 = mul i64 %t545, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t542, ptr %t544, i64 %t546, i1 false)
  %t547 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t548 = getelementptr { i64, { i64, ptr } }, ptr %l202, i32 0, i32 1
  store { i64, ptr } %t547, ptr %t548, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t549 = load { i64, { i64, ptr } }, ptr %l202
  store { i64, { i64, ptr } } %t549, ptr %rv
  br label %ret
bb72:
  %t550 = load ptr, ptr %l2, !tbaa !29
  %t552 = getelementptr %"compiler/free:Free", ptr %t550, i32 0, i32 74
  %t553 = load i64, ptr %l9, !tbaa !24
  %t556 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t552, i64 %t553)
  store i1 %t556, ptr %l209
  br label %bb73
bb73:
  %t557 = load i1, ptr %l209, !tbaa !21
  %t558 = xor i1 %t557, true
  br i1 %t558, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s13
  %t560 = load ptr, ptr %l2, !tbaa !29
  %t561 = load i64, ptr %l9, !tbaa !24
  %t564 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s13, ptr %t560, i64 %t561)
  store { i64, ptr } %t564, ptr %l213
  br label %bb76
bb75:
  br label %bb77
bb76:
  %t565 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t566 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t567 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t568 = extractvalue { i64, ptr } %t567, 1
  %t569 = extractvalue { i64, ptr } %t567, 0
  %t570 = add i64 %t566, %t569
  %t571 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t572 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t573 = add i64 %t570, %t572
  %t574 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t573)
  call void @olang_textcopy(ptr %t574, ptr %t565, i64 %t566)
  %t575 = getelementptr i8, ptr %t574, i64 %t566
  call void @olang_textcopy(ptr %t575, ptr %t568, i64 %t569)
  %t576 = getelementptr i8, ptr %t575, i64 %t569
  call void @olang_textcopy(ptr %t576, ptr %t571, i64 %t572)
  %t577 = insertvalue { i64, ptr } undef, i64 %t573, 0
  %t578 = insertvalue { i64, ptr } %t577, ptr %t574, 1
  %t579 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t581 = insertvalue { i64, { i64, ptr } } %t579, { i64, ptr } %t578, 1
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s5)
  store { i64, { i64, ptr } } %t581, ptr %rv
  br label %ret
bb77:
  %t583 = load ptr, ptr %l8, !tbaa !29
  %t585 = getelementptr %"compiler/typed:Call", ptr %t583, i32 0, i32 2
  %t586 = load i32, ptr %t585, !tbaa !23
  %t588 = sext i32 %t586 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %l219, !tbaa !27
  %t589 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t591 = insertvalue { i64, { i64, ptr } } undef, i64 %t588, 0
  %t593 = insertvalue { i64, { i64, ptr } } %t591, { i64, ptr } %t589, 1
  store { i64, { i64, ptr } } %t593, ptr %l221
  %t594 = getelementptr { i64, { i64, ptr } }, ptr %l221, i32 0, i32 1
  %t595 = load { i64, ptr }, ptr %t594, !tbaa !27
  store { i64, ptr } %t595, ptr %l222, !tbaa !27
  %t596 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t597 = extractvalue { i64, ptr } %t596, 0
  store i64 %t597, ptr %l223, !tbaa !24
  %t598 = load i64, ptr %l223, !tbaa !24
  %t599 = mul i64 %t598, 1
  %t600 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t599)
  %t601 = insertvalue { i64, ptr } undef, i64 %t598, 0
  %t602 = insertvalue { i64, ptr } %t601, ptr %t600, 1
  store { i64, ptr } %t602, ptr %l224, !tbaa !27
  %t603 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t604 = load ptr, ptr %t603, !tbaa !27
  %t605 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t606 = load ptr, ptr %t605, !tbaa !27
  %t607 = load i64, ptr %l223, !tbaa !24
  %t608 = mul i64 %t607, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t604, ptr %t606, i64 %t608, i1 false)
  %t609 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t610 = getelementptr { i64, { i64, ptr } }, ptr %l221, i32 0, i32 1
  store { i64, ptr } %t609, ptr %t610, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t611 = load { i64, { i64, ptr } }, ptr %l221
  store { i64, { i64, ptr } } %t611, ptr %rv
  br label %ret
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l225, !tbaa !27
  %t612 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t613 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t615 = insertvalue { i64, { i64, ptr } } %t613, { i64, ptr } %t612, 1
  store { i64, { i64, ptr } } %t615, ptr %l227
  %t616 = getelementptr { i64, { i64, ptr } }, ptr %l227, i32 0, i32 1
  %t617 = load { i64, ptr }, ptr %t616, !tbaa !27
  store { i64, ptr } %t617, ptr %l228, !tbaa !27
  %t618 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t619 = extractvalue { i64, ptr } %t618, 0
  store i64 %t619, ptr %l229, !tbaa !24
  %t620 = load i64, ptr %l229, !tbaa !24
  %t621 = mul i64 %t620, 1
  %t622 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t621)
  %t623 = insertvalue { i64, ptr } undef, i64 %t620, 0
  %t624 = insertvalue { i64, ptr } %t623, ptr %t622, 1
  store { i64, ptr } %t624, ptr %l230, !tbaa !27
  %t625 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t626 = load ptr, ptr %t625, !tbaa !27
  %t627 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t628 = load ptr, ptr %t627, !tbaa !27
  %t629 = load i64, ptr %l229, !tbaa !24
  %t630 = mul i64 %t629, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t626, ptr %t628, i64 %t630, i1 false)
  %t631 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t632 = getelementptr { i64, { i64, ptr } }, ptr %l227, i32 0, i32 1
  store { i64, ptr } %t631, ptr %t632, !tbaa !27
  %t633 = load { i64, { i64, ptr } }, ptr %l227
  store { i64, { i64, ptr } } %t633, ptr %rv
  br label %ret
bb82:
  call void @__olang_check_failed(ptr @olang_loc_fa71248d89b17b0b_39d265aac120d27f)
  unreachable
ret:
  %rr = load { i64, { i64, ptr } }, ptr %rv
  ret { i64, { i64, ptr } } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egenCalls(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l62 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l95 = alloca i64
  %l96 = alloca ptr
  %l100 = alloca %"compiler/typed:Local"
  %l102 = alloca i64
  %l105 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca i64
  %l113 = alloca i64
  %l131 = alloca ptr
  %l132 = alloca i64
  %l134 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l140 = alloca i64
  %l144 = alloca i64
  %l147 = alloca i64
  %l168 = alloca i64
  %l171 = alloca i1
  %l175 = alloca i1
  %l181 = alloca ptr
  %l185 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l186 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l195 = alloca i64
  %l197 = alloca i64
  %l202 = alloca i64
  %l203 = alloca ptr
  %l207 = alloca ptr
  %l208 = alloca i1
  %l209 = alloca ptr
  %l211 = alloca i64
  %l215 = alloca %"compiler/typed:Local"
  %l221 = alloca i64
  %l225 = alloca i64
  %l228 = alloca i64
  %l249 = alloca i64
  %l253 = alloca %"compiler/source:Span"
  %l254 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l255 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l260 = alloca i64
  %l263 = alloca i64
  %l284 = alloca ptr
  %l285 = alloca i64
  %l286 = alloca i64
  %l287 = alloca %"compiler/source:Span"
  %l290 = alloca ptr
  %l291 = alloca i64
  %l294 = alloca i1
  %l298 = alloca i1
  %l302 = alloca ptr
  %l306 = alloca %"compiler/source:Span"
  %l311 = alloca i64
  %l315 = alloca i64
  %l318 = alloca i64
  %l339 = alloca i64
  %l342 = alloca i1
  %l346 = alloca %"compiler/source:Span"
  %l348 = alloca i1
  %l349 = alloca i1
  %l350 = alloca %"compiler/source:Span"
  %l354 = alloca %"compiler/source:Span"
  %l355 = alloca i1
  %l356 = alloca i1
  %l357 = alloca ptr
  %l361 = alloca i64
  %l362 = alloca i1
  %l363 = alloca ptr
  %l367 = alloca i64
  %l368 = alloca ptr
  %l372 = alloca %"compiler/source:Span"
  %l380 = alloca ptr
  %l384 = alloca i64
  %l393 = alloca ptr
  %l396 = alloca i64
  %l398 = alloca i64
  %l402 = alloca i64
  %l405 = alloca i64
  %l424 = alloca ptr
  %l427 = alloca i64
  %l429 = alloca ptr
  %l432 = alloca %"compiler/source:Span"
  %l437 = alloca ptr
  %l440 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %t26 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l62
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l62, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 7
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l65
  br label %bb2
bb2:
  %t15 = load i64, ptr %l65, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l66, !tbaa !24
  %t17 = load i64, ptr %l66, !tbaa !24
  %t18 = icmp sge i64 %t17, 0
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load i64, ptr %l66, !tbaa !24
  %t21 = icmp sle i64 %t20, 1152921504606846975
  br i1 %t21, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a7dbf91e7cbb7208_810d022031132c04)
  unreachable
bb5:
  %t23 = load i64, ptr %l66, !tbaa !24
  %t24 = mul i64 %t23, 8
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  store i64 0, ptr %t26
  br label %fill.27
fill.27:
  %t30 = load i64, ptr %t26
  %t31 = icmp slt i64 %t30, %t23
  br i1 %t31, label %fillb.28, label %filld.29
fillb.28:
  %t32 = getelementptr i64, ptr %t25, i64 %t30
  store i64 -2, ptr %t32
  %t33 = add i64 %t30, 1
  store i64 %t33, ptr %t26
  br label %fill.27
filld.29:
  %t34 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t25, 1
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  store i64 %t37, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a7dbf91e7cbb7208_810d022031132c04)
  unreachable
bb7:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb12
bb9:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l77, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb11
bb11:
  %t65 = load i64, ptr %l77, !tbaa !24
  store i64 %t65, ptr %l74, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l74, !tbaa !24
  store i64 %t66, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb15:
  br label %bb16
bb16:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l10, !tbaa !24
  %t85 = load i64, ptr %l10, !tbaa !24
  store i64 %t85, ptr %l95, !tbaa !24
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l96, !tbaa !29
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Body", ptr %t87, i32 0, i32 7
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t89, i64 %t90)
  store %"compiler/typed:Local" %t93, ptr %l100
  br label %bb17
bb17:
  %t94 = load ptr, ptr %l96, !tbaa !29
  %t96 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elocalReach(ptr %v0, ptr %s2, ptr %t94, ptr %l100)
  store i64 %t96, ptr %l102
  br label %bb18
bb18:
  %t97 = load i64, ptr %l102, !tbaa !24
  %t98 = load i64, ptr %l95, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i64, ptr %t100, i64 %t98
  store i64 %t97, ptr %t101, !tbaa !34
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t102 = load i64, ptr %l9, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l9, !tbaa !24
  br label %bb13
bb20:
  %t106 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %l105
  br label %bb21
bb21:
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l105
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t108 = load i64, ptr %l3, !tbaa !24
  store i64 %t108, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t110 = load i64, ptr %l13, !tbaa !24
  %t111 = load i64, ptr %l12, !tbaa !24
  %t114 = icmp sgt i64 %t110, %t111
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t116 = load i64, ptr %l14, !tbaa !24
  %t118 = icmp sgt i64 %t116, 0
  br i1 %t118, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb27
bb24:
  %t120 = load i64, ptr %l13, !tbaa !24
  %t121 = load i64, ptr %l12, !tbaa !24
  %t124 = sub i64 %t120, %t121
  %t125 = load i64, ptr %l14, !tbaa !24
  %t128 = add i64 %t124, %t125
  %t130 = sub i64 %t128, 1
  %t131 = load i64, ptr %l14, !tbaa !24
  %t134 = sdiv i64 %t130, %t131
  store i64 %t134, ptr %l113, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb26
bb26:
  %t136 = load i64, ptr %l113, !tbaa !24
  store i64 %t136, ptr %l110, !tbaa !24
  br label %bb27
bb27:
  %t137 = load i64, ptr %l110, !tbaa !24
  store i64 %t137, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb28
bb28:
  %t138 = load i64, ptr %l16, !tbaa !24
  %t139 = load i64, ptr %l15, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb29, label %bb30
bb29:
  br label %bb37
bb30:
  br label %bb31
bb31:
  %t146 = load i64, ptr %l12, !tbaa !24
  %t147 = load i64, ptr %l16, !tbaa !24
  %t148 = load i64, ptr %l14, !tbaa !24
  %t151 = mul i64 %t147, %t148
  %t154 = add i64 %t146, %t151
  store i64 %t154, ptr %l17, !tbaa !24
  store ptr %l11, ptr %l131, !tbaa !29
  %t156 = ptrtoint ptr %s0 to i64
  store i64 %t156, ptr %l132, !tbaa !24
  %t157 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t157, label %bb32, label %bb33
bb32:
  %t159 = call ptr @__olang_region_make(ptr %s0)
  %t160 = ptrtoint ptr %t159 to i64
  store i64 %t160, ptr %l132, !tbaa !24
  br label %bb33
bb33:
  %t161 = load i64, ptr %l132
  %t162 = inttoptr i64 %t161 to ptr
  %t163 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t162, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %l134
  br label %bb34
bb34:
  %t164 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l134
  %t165 = load i64, ptr %l132
  %t166 = inttoptr i64 %t165 to ptr
  %t167 = call ptr @__olang_scope_alloc_a(ptr %t166, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %t167
  %t168 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %s0, ptr %s0, ptr %t168, ptr %t167)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t170 = load i64, ptr %l16, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l16, !tbaa !24
  br label %bb28
bb37:
  store i64 0, ptr %l18, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/free:walker", ptr %t174, i32 0, i32 25
  %t178 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t176)
  store i64 %t178, ptr %l140
  br label %bb38
bb38:
  %t179 = load i64, ptr %l140, !tbaa !24
  store i64 %t179, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t180 = load i64, ptr %l19, !tbaa !24
  %t181 = load i64, ptr %l18, !tbaa !24
  %t184 = icmp sgt i64 %t180, %t181
  br i1 %t184, label %bb39, label %bb40
bb39:
  %t186 = load i64, ptr %l20, !tbaa !24
  %t188 = icmp sgt i64 %t186, 0
  br i1 %t188, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb44
bb41:
  %t190 = load i64, ptr %l19, !tbaa !24
  %t191 = load i64, ptr %l18, !tbaa !24
  %t194 = sub i64 %t190, %t191
  %t195 = load i64, ptr %l20, !tbaa !24
  %t198 = add i64 %t194, %t195
  %t200 = sub i64 %t198, 1
  %t201 = load i64, ptr %l20, !tbaa !24
  %t204 = sdiv i64 %t200, %t201
  store i64 %t204, ptr %l147, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb43
bb43:
  %t206 = load i64, ptr %l147, !tbaa !24
  store i64 %t206, ptr %l144, !tbaa !24
  br label %bb44
bb44:
  %t207 = load i64, ptr %l144, !tbaa !24
  store i64 %t207, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb45
bb45:
  %t208 = load i64, ptr %l22, !tbaa !24
  %t209 = load i64, ptr %l21, !tbaa !24
  %t212 = icmp slt i64 %t208, %t209
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb46, label %bb47
bb46:
  br label %bb62
bb47:
  br label %bb48
bb48:
  %t216 = load i64, ptr %l18, !tbaa !24
  %t217 = load i64, ptr %l22, !tbaa !24
  %t218 = load i64, ptr %l20, !tbaa !24
  %t221 = mul i64 %t217, %t218
  %t224 = add i64 %t216, %t221
  store i64 %t224, ptr %l23, !tbaa !24
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/free:walker", ptr %t226, i32 0, i32 25
  %t229 = load i64, ptr %l23, !tbaa !24
  %t232 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t228, i64 %t229)
  store i64 %t232, ptr %l168
  br label %bb49
bb49:
  %t233 = load i64, ptr %l168, !tbaa !24
  store i64 %t233, ptr %l24, !tbaa !24
  %t234 = load i64, ptr %l24, !tbaa !24
  %t236 = icmp sge i64 %t234, 0
  br i1 %t236, label %bb50, label %bb51
bb50:
  %t238 = load i64, ptr %l24, !tbaa !24
  %t239 = load i64, ptr %l3, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  store i1 %t242, ptr %l171, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb52
bb52:
  %t244 = load i1, ptr %l171, !tbaa !21
  br i1 %t244, label %bb53, label %bb54
bb53:
  %t245 = load i64, ptr %l24, !tbaa !24
  %t247 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = getelementptr i64, ptr %t248, i64 %t245
  %t250 = load i64, ptr %t249, !tbaa !34
  %t252 = icmp ne i64 %t250, -2
  store i1 %t252, ptr %l175, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb55
bb55:
  %t254 = load i1, ptr %l175, !tbaa !21
  br i1 %t254, label %bb56, label %bb57
bb56:
  %t255 = load i64, ptr %l24, !tbaa !24
  %t258 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %s0, ptr %s0, ptr %l11, i64 %t255)
  store ptr %t258, ptr %l181
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t259 = load i64, ptr %l23, !tbaa !24
  %t260 = load ptr, ptr %l181, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t260, i64 %t259)
  br label %bb59
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t262 = load i64, ptr %l22, !tbaa !24
  %t264 = add i64 %t262, 1
  store i64 %t264, ptr %l22, !tbaa !24
  br label %bb45
bb62:
  %t266 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %l185
  br label %bb63
bb63:
  %t267 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l185
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t267, ptr %l25
  %t268 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t268, ptr %l186
  br label %bb64
bb64:
  %t269 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l186
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t269, ptr %l26
  %t270 = load ptr, ptr %l1, !tbaa !29
  %t272 = getelementptr %"compiler/free:Free", ptr %t270, i32 0, i32 46
  %t273 = load i1, ptr %t272, !tbaa !21
  br i1 %t273, label %bb65, label %bb66
bb65:
  %t275 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewLocals(ptr %v0, ptr %s0, ptr %s0, ptr %t275, ptr %l25, ptr %l26)
  br label %bb67
bb66:
  br label %bb86
bb67:
  %t279 = load ptr, ptr %l2, !tbaa !29
  %t281 = getelementptr %"compiler/typed:Body", ptr %t279, i32 0, i32 14
  %t282 = load i1, ptr %t281, !tbaa !21
  br i1 %t282, label %bb68, label %bb69
bb68:
  store ptr %l25, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb70
bb69:
  br label %bb85
bb70:
  %t285 = load i64, ptr %l28, !tbaa !24
  store i64 %t285, ptr %l195, !tbaa !24
  %t286 = load ptr, ptr %l27, !tbaa !29
  %t288 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t286)
  store i64 %t288, ptr %l197
  br label %bb71
bb71:
  %t289 = load i64, ptr %l195, !tbaa !24
  %t290 = load i64, ptr %l197, !tbaa !24
  %t291 = icmp slt i64 %t289, %t290
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb72, label %bb73
bb72:
  br label %bb84
bb73:
  br label %bb74
bb74:
  %t295 = load ptr, ptr %l27, !tbaa !29
  %t296 = load i64, ptr %l28, !tbaa !24
  %t299 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t295, i64 %t296)
  store i64 %t299, ptr %l202
  br label %bb75
bb75:
  %t300 = load i64, ptr %l202, !tbaa !24
  store i64 %t300, ptr %l29, !tbaa !24
  %t301 = load ptr, ptr %l1, !tbaa !29
  store ptr %t301, ptr %l203, !tbaa !29
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/free:walker", ptr %t302, i32 0, i32 3
  %t305 = load i64, ptr %l29, !tbaa !24
  %t308 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t304, i64 %t305)
  store ptr %t308, ptr %l207
  br label %bb76
bb76:
  %t309 = load ptr, ptr %l203, !tbaa !29
  %t310 = load ptr, ptr %l207, !tbaa !29
  %t311 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayView(ptr %v0, ptr %v0, ptr %t309, ptr %t310)
  store i1 %t311, ptr %l208
  br label %bb77
bb77:
  %t312 = load i1, ptr %l208, !tbaa !21
  br i1 %t312, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s15
  %t313 = load ptr, ptr %l1, !tbaa !29
  store ptr %t313, ptr %l209, !tbaa !29
  %t314 = load ptr, ptr %l2, !tbaa !29
  %t316 = getelementptr %"compiler/typed:Body", ptr %t314, i32 0, i32 3
  %t317 = load i64, ptr %t316, !tbaa !24
  store i64 %t317, ptr %l211, !tbaa !24
  %t318 = load ptr, ptr %l2, !tbaa !29
  %t320 = getelementptr %"compiler/typed:Body", ptr %t318, i32 0, i32 7
  %t321 = load i64, ptr %l29, !tbaa !24
  %t324 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t320, i64 %t321)
  store %"compiler/typed:Local" %t324, ptr %l215
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t325 = getelementptr %"compiler/typed:Local", ptr %l215, i32 0, i32 1
  %t326 = load %"compiler/source:Span", ptr %t325
  %t327 = load ptr, ptr %l209, !tbaa !29
  %t328 = load i64, ptr %l211, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufNot(ptr %v0, ptr %s15, ptr %t327, { i64, ptr } { i64 105, ptr getelementptr inbounds (<{ i64, [105 x i8] }>, ptr @.d76, i32 0, i32 1) }, i64 %t328, %"compiler/source:Span" %t326)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s15)
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t330 = load i64, ptr %l28, !tbaa !24
  %t332 = add i64 %t330, 1
  store i64 %t332, ptr %l28, !tbaa !24
  br label %bb70
bb84:
  br label %bb85
bb85:
  br label %bb86
bb86:
  store i64 0, ptr %l30, !tbaa !24
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/free:walker", ptr %t334, i32 0, i32 56
  %t338 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t336)
  store i64 %t338, ptr %l221
  br label %bb87
bb87:
  %t339 = load i64, ptr %l221, !tbaa !24
  store i64 %t339, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t340 = load i64, ptr %l31, !tbaa !24
  %t341 = load i64, ptr %l30, !tbaa !24
  %t344 = icmp sgt i64 %t340, %t341
  br i1 %t344, label %bb88, label %bb89
bb88:
  %t346 = load i64, ptr %l32, !tbaa !24
  %t348 = icmp sgt i64 %t346, 0
  br i1 %t348, label %bb90, label %bb91
bb89:
  store i64 0, ptr %l225, !tbaa !24
  br label %bb93
bb90:
  %t350 = load i64, ptr %l31, !tbaa !24
  %t351 = load i64, ptr %l30, !tbaa !24
  %t354 = sub i64 %t350, %t351
  %t355 = load i64, ptr %l32, !tbaa !24
  %t358 = add i64 %t354, %t355
  %t360 = sub i64 %t358, 1
  %t361 = load i64, ptr %l32, !tbaa !24
  %t364 = sdiv i64 %t360, %t361
  store i64 %t364, ptr %l228, !tbaa !24
  br label %bb92
bb91:
  store i64 0, ptr %l228, !tbaa !24
  br label %bb92
bb92:
  %t366 = load i64, ptr %l228, !tbaa !24
  store i64 %t366, ptr %l225, !tbaa !24
  br label %bb93
bb93:
  %t367 = load i64, ptr %l225, !tbaa !24
  store i64 %t367, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb94
bb94:
  store %olang.scope zeroinitializer, ptr %s18
  %t368 = load i64, ptr %l34, !tbaa !24
  %t369 = load i64, ptr %l33, !tbaa !24
  %t372 = icmp slt i64 %t368, %t369
  %t374 = xor i1 %t372, true
  br i1 %t374, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s18)
  br label %bb195
bb96:
  br label %bb97
bb97:
  %t376 = load i64, ptr %l30, !tbaa !24
  %t377 = load i64, ptr %l34, !tbaa !24
  %t378 = load i64, ptr %l32, !tbaa !24
  %t381 = mul i64 %t377, %t378
  %t384 = add i64 %t376, %t381
  store i64 %t384, ptr %l35, !tbaa !24
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/free:walker", ptr %t386, i32 0, i32 56
  %t389 = load i64, ptr %l35, !tbaa !24
  %t392 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t388, i64 %t389)
  store i64 %t392, ptr %l249
  br label %bb98
bb98:
  %t393 = load i64, ptr %l249, !tbaa !24
  store i64 %t393, ptr %l36, !tbaa !24
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = getelementptr %"compiler/free:walker", ptr %t394, i32 0, i32 57
  %t397 = load i64, ptr %l35, !tbaa !24
  %t400 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t396, i64 %t397)
  store %"compiler/source:Span" %t400, ptr %l253
  br label %bb99
bb99:
  %t401 = load %"compiler/source:Span", ptr %l253
  store %"compiler/source:Span" %t401, ptr %l37
  %t402 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s18, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t402, ptr %l254
  br label %bb100
bb100:
  %t403 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l254
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t403, ptr %l38
  %t404 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %s18, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t404, ptr %l255
  br label %bb101
bb101:
  %t405 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l255
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t405, ptr %l39
  store i64 0, ptr %l40, !tbaa !24
  %t406 = load i64, ptr %l3, !tbaa !24
  store i64 %t406, ptr %l41, !tbaa !24
  store i64 1, ptr %l42, !tbaa !24
  %t408 = load i64, ptr %l41, !tbaa !24
  %t409 = load i64, ptr %l40, !tbaa !24
  %t412 = icmp sgt i64 %t408, %t409
  br i1 %t412, label %bb102, label %bb103
bb102:
  %t414 = load i64, ptr %l42, !tbaa !24
  %t416 = icmp sgt i64 %t414, 0
  br i1 %t416, label %bb104, label %bb105
bb103:
  store i64 0, ptr %l260, !tbaa !24
  br label %bb107
bb104:
  %t418 = load i64, ptr %l41, !tbaa !24
  %t419 = load i64, ptr %l40, !tbaa !24
  %t422 = sub i64 %t418, %t419
  %t423 = load i64, ptr %l42, !tbaa !24
  %t426 = add i64 %t422, %t423
  %t428 = sub i64 %t426, 1
  %t429 = load i64, ptr %l42, !tbaa !24
  %t432 = sdiv i64 %t428, %t429
  store i64 %t432, ptr %l263, !tbaa !24
  br label %bb106
bb105:
  store i64 0, ptr %l263, !tbaa !24
  br label %bb106
bb106:
  %t434 = load i64, ptr %l263, !tbaa !24
  store i64 %t434, ptr %l260, !tbaa !24
  br label %bb107
bb107:
  %t435 = load i64, ptr %l260, !tbaa !24
  store i64 %t435, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb108
bb108:
  %t436 = load i64, ptr %l44, !tbaa !24
  %t437 = load i64, ptr %l43, !tbaa !24
  %t440 = icmp slt i64 %t436, %t437
  %t442 = xor i1 %t440, true
  br i1 %t442, label %bb109, label %bb110
bb109:
  br label %bb128
bb110:
  br label %bb111
bb111:
  %t444 = load i64, ptr %l40, !tbaa !24
  %t445 = load i64, ptr %l44, !tbaa !24
  %t446 = load i64, ptr %l42, !tbaa !24
  %t449 = mul i64 %t445, %t446
  %t452 = add i64 %t444, %t449
  store i64 %t452, ptr %l45, !tbaa !24
  %t454 = load i64, ptr %l45, !tbaa !24
  %t456 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !27
  %t458 = getelementptr i64, ptr %t457, i64 %t454
  %t459 = load i64, ptr %t458, !tbaa !34
  %t461 = icmp eq i64 %t459, -2
  br i1 %t461, label %bb112, label %bb113
bb112:
  br label %bb127
bb113:
  br label %bb114
bb114:
  %t463 = load ptr, ptr %l0, !tbaa !29
  store ptr %t463, ptr %l284, !tbaa !29
  %t464 = load i64, ptr %l45, !tbaa !24
  store i64 %t464, ptr %l285, !tbaa !24
  %t465 = load i64, ptr %l36, !tbaa !24
  store i64 %t465, ptr %l286, !tbaa !24
  %t466 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t466, ptr %l287
  %t467 = load i64, ptr %l45, !tbaa !24
  %t470 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %s0, ptr %s0, ptr %l11, i64 %t467)
  store ptr %t470, ptr %l290
  br label %bb115
bb115:
  %t471 = load ptr, ptr %l284, !tbaa !29
  %t472 = load i64, ptr %l285, !tbaa !24
  %t473 = load i64, ptr %l286, !tbaa !24
  %t474 = load %"compiler/source:Span", ptr %l287
  %t475 = load ptr, ptr %l290, !tbaa !29
  %t476 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einUseAcross(ptr %v0, ptr %s0, ptr %t471, i64 %t472, i64 %t473, %"compiler/source:Span" %t474, ptr %t475)
  store i64 %t476, ptr %l291
  br label %bb116
bb116:
  %t477 = load i64, ptr %l291, !tbaa !24
  store i64 %t477, ptr %l46, !tbaa !24
  %t478 = load i64, ptr %l46, !tbaa !24
  %t480 = icmp slt i64 %t478, 0
  br i1 %t480, label %bb117, label %bb118
bb117:
  store i1 true, ptr %l294, !tbaa !21
  br label %bb120
bb118:
  %t482 = load i64, ptr %l45, !tbaa !24
  %t484 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t485 = load ptr, ptr %t484, !tbaa !27
  %t486 = getelementptr i64, ptr %t485, i64 %t482
  %t487 = load i64, ptr %t486, !tbaa !34
  %t490 = call i1 @compiler_2ffree_2ehas(ptr %s18, ptr %l38, i64 %t487)
  store i1 %t490, ptr %l298
  br label %bb119
bb119:
  %t491 = load i1, ptr %l298, !tbaa !21
  store i1 %t491, ptr %l294, !tbaa !21
  br label %bb120
bb120:
  %t492 = load i1, ptr %l294, !tbaa !21
  br i1 %t492, label %bb121, label %bb122
bb121:
  br label %bb127
bb122:
  br label %bb123
bb123:
  %t493 = load i64, ptr %l45, !tbaa !24
  %t495 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !27
  %t497 = getelementptr i64, ptr %t496, i64 %t493
  %t498 = load i64, ptr %t497, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s18, ptr %l38, i64 %t498)
  br label %bb124
bb124:
  store ptr %l39, ptr %l302, !tbaa !29
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = getelementptr %"compiler/free:walker", ptr %t501, i32 0, i32 27
  %t504 = load i64, ptr %l46, !tbaa !24
  %t507 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t503, i64 %t504)
  store %"compiler/source:Span" %t507, ptr %l306
  br label %bb125
bb125:
  %t508 = load ptr, ptr %l302, !tbaa !29
  %t509 = load %"compiler/source:Span", ptr %l306
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %s18, ptr %t508, %"compiler/source:Span" %t509)
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t510 = load i64, ptr %l44, !tbaa !24
  %t512 = add i64 %t510, 1
  store i64 %t512, ptr %l44, !tbaa !24
  br label %bb108
bb128:
  store i64 0, ptr %l47, !tbaa !24
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t516 = getelementptr %"compiler/free:walker", ptr %t514, i32 0, i32 59
  %t518 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t516)
  store i64 %t518, ptr %l311
  br label %bb129
bb129:
  %t519 = load i64, ptr %l311, !tbaa !24
  store i64 %t519, ptr %l48, !tbaa !24
  store i64 1, ptr %l49, !tbaa !24
  %t520 = load i64, ptr %l48, !tbaa !24
  %t521 = load i64, ptr %l47, !tbaa !24
  %t524 = icmp sgt i64 %t520, %t521
  br i1 %t524, label %bb130, label %bb131
bb130:
  %t526 = load i64, ptr %l49, !tbaa !24
  %t528 = icmp sgt i64 %t526, 0
  br i1 %t528, label %bb132, label %bb133
bb131:
  store i64 0, ptr %l315, !tbaa !24
  br label %bb135
bb132:
  %t530 = load i64, ptr %l48, !tbaa !24
  %t531 = load i64, ptr %l47, !tbaa !24
  %t534 = sub i64 %t530, %t531
  %t535 = load i64, ptr %l49, !tbaa !24
  %t538 = add i64 %t534, %t535
  %t540 = sub i64 %t538, 1
  %t541 = load i64, ptr %l49, !tbaa !24
  %t544 = sdiv i64 %t540, %t541
  store i64 %t544, ptr %l318, !tbaa !24
  br label %bb134
bb133:
  store i64 0, ptr %l318, !tbaa !24
  br label %bb134
bb134:
  %t546 = load i64, ptr %l318, !tbaa !24
  store i64 %t546, ptr %l315, !tbaa !24
  br label %bb135
bb135:
  %t547 = load i64, ptr %l315, !tbaa !24
  store i64 %t547, ptr %l50, !tbaa !24
  store i64 0, ptr %l51, !tbaa !24
  br label %bb136
bb136:
  %t548 = load i64, ptr %l51, !tbaa !24
  %t549 = load i64, ptr %l50, !tbaa !24
  %t552 = icmp slt i64 %t548, %t549
  %t554 = xor i1 %t552, true
  br i1 %t554, label %bb137, label %bb138
bb137:
  br label %bb164
bb138:
  br label %bb139
bb139:
  %t556 = load i64, ptr %l47, !tbaa !24
  %t557 = load i64, ptr %l51, !tbaa !24
  %t558 = load i64, ptr %l49, !tbaa !24
  %t561 = mul i64 %t557, %t558
  %t564 = add i64 %t556, %t561
  store i64 %t564, ptr %l52, !tbaa !24
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = getelementptr %"compiler/free:walker", ptr %t566, i32 0, i32 59
  %t569 = load i64, ptr %l52, !tbaa !24
  %t572 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t568, i64 %t569)
  store i64 %t572, ptr %l339
  br label %bb140
bb140:
  %t573 = load i64, ptr %l36, !tbaa !24
  %t574 = load i64, ptr %l339, !tbaa !24
  %t576 = icmp ne i64 %t574, %t573
  br i1 %t576, label %bb141, label %bb142
bb141:
  store i1 true, ptr %l342, !tbaa !21
  br label %bb145
bb142:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t580 = getelementptr %"compiler/free:walker", ptr %t578, i32 0, i32 60
  %t581 = load i64, ptr %l52, !tbaa !24
  %t584 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t580, i64 %t581)
  store %"compiler/source:Span" %t584, ptr %l346
  br label %bb143
bb143:
  %t585 = load %"compiler/source:Span", ptr %l37
  %t586 = load %"compiler/source:Span", ptr %l346
  %t588 = call i1 @compiler_2ffree_2espanIn(%"compiler/source:Span" %t586, %"compiler/source:Span" %t585)
  store i1 %t588, ptr %l348
  br label %bb144
bb144:
  %t589 = load i1, ptr %l348, !tbaa !21
  store i1 %t589, ptr %l342, !tbaa !21
  br label %bb145
bb145:
  %t590 = load i1, ptr %l342, !tbaa !21
  br i1 %t590, label %bb146, label %bb147
bb146:
  store i1 true, ptr %l349, !tbaa !21
  br label %bb150
bb147:
  %t591 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t591, ptr %l350
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t594 = getelementptr %"compiler/free:walker", ptr %t592, i32 0, i32 60
  %t595 = load i64, ptr %l52, !tbaa !24
  %t598 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t594, i64 %t595)
  store %"compiler/source:Span" %t598, ptr %l354
  br label %bb148
bb148:
  %t599 = load %"compiler/source:Span", ptr %l350
  %t600 = load %"compiler/source:Span", ptr %l354
  %t601 = call i1 @compiler_2ffree_2espanIn(%"compiler/source:Span" %t599, %"compiler/source:Span" %t600)
  store i1 %t601, ptr %l355
  br label %bb149
bb149:
  %t602 = load i1, ptr %l355, !tbaa !21
  store i1 %t602, ptr %l349, !tbaa !21
  br label %bb150
bb150:
  %t603 = load i1, ptr %l349, !tbaa !21
  br i1 %t603, label %bb151, label %bb152
bb151:
  store i1 true, ptr %l356, !tbaa !21
  br label %bb155
bb152:
  store ptr %l38, ptr %l357, !tbaa !29
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t606 = getelementptr %"compiler/free:walker", ptr %t604, i32 0, i32 61
  %t607 = load i64, ptr %l52, !tbaa !24
  %t610 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t606, i64 %t607)
  store i64 %t610, ptr %l361
  br label %bb153
bb153:
  %t611 = load ptr, ptr %l357, !tbaa !29
  %t612 = load i64, ptr %l361, !tbaa !24
  %t613 = call i1 @compiler_2ffree_2ehas(ptr %s18, ptr %t611, i64 %t612)
  store i1 %t613, ptr %l362
  br label %bb154
bb154:
  %t614 = load i1, ptr %l362, !tbaa !21
  store i1 %t614, ptr %l356, !tbaa !21
  br label %bb155
bb155:
  %t615 = load i1, ptr %l356, !tbaa !21
  br i1 %t615, label %bb156, label %bb157
bb156:
  br label %bb163
bb157:
  br label %bb158
bb158:
  store ptr %l38, ptr %l363, !tbaa !29
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t618 = getelementptr %"compiler/free:walker", ptr %t616, i32 0, i32 61
  %t619 = load i64, ptr %l52, !tbaa !24
  %t622 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t618, i64 %t619)
  store i64 %t622, ptr %l367
  br label %bb159
bb159:
  %t623 = load ptr, ptr %l363, !tbaa !29
  %t624 = load i64, ptr %l367, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s18, ptr %t623, i64 %t624)
  br label %bb160
bb160:
  store ptr %l39, ptr %l368, !tbaa !29
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t627 = getelementptr %"compiler/free:walker", ptr %t625, i32 0, i32 60
  %t628 = load i64, ptr %l52, !tbaa !24
  %t631 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t627, i64 %t628)
  store %"compiler/source:Span" %t631, ptr %l372
  br label %bb161
bb161:
  %t632 = load ptr, ptr %l368, !tbaa !29
  %t633 = load %"compiler/source:Span", ptr %l372
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %s18, ptr %t632, %"compiler/source:Span" %t633)
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t634 = load i64, ptr %l51, !tbaa !24
  %t636 = add i64 %t634, 1
  store i64 %t636, ptr %l51, !tbaa !24
  br label %bb136
bb164:
  %t638 = load ptr, ptr %l1, !tbaa !29
  %t640 = getelementptr %"compiler/free:Free", ptr %t638, i32 0, i32 29
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t643 = getelementptr %"compiler/free:walker", ptr %t641, i32 0, i32 1
  %t644 = load i64, ptr %t643, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t640, i64 %t644)
  br label %bb165
bb165:
  %t647 = load ptr, ptr %l1, !tbaa !29
  %t649 = getelementptr %"compiler/free:Free", ptr %t647, i32 0, i32 30
  store ptr %t649, ptr %l380, !tbaa !29
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t652 = getelementptr %"compiler/free:walker", ptr %t650, i32 0, i32 58
  %t653 = load i64, ptr %l35, !tbaa !24
  %t656 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t652, i64 %t653)
  store i64 %t656, ptr %l384
  br label %bb166
bb166:
  %t657 = load ptr, ptr %l380, !tbaa !29
  %t658 = load i64, ptr %l384, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t657, i64 %t658)
  br label %bb167
bb167:
  %t659 = load ptr, ptr %l1, !tbaa !29
  %t661 = getelementptr %"compiler/free:Free", ptr %t659, i32 0, i32 31
  %t662 = load ptr, ptr %l2, !tbaa !29
  %t664 = getelementptr %"compiler/typed:Body", ptr %t662, i32 0, i32 3
  %t665 = load i64, ptr %t664, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t661, i64 %t665)
  br label %bb168
bb168:
  %t668 = load ptr, ptr %l1, !tbaa !29
  %t670 = getelementptr %"compiler/free:Free", ptr %t668, i32 0, i32 32
  %t671 = load %"compiler/source:Span", ptr %l37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t670, %"compiler/source:Span" %t671)
  br label %bb169
bb169:
  %t674 = load ptr, ptr %l1, !tbaa !29
  %t676 = getelementptr %"compiler/free:Free", ptr %t674, i32 0, i32 33
  store ptr %t676, ptr %l393, !tbaa !29
  %t677 = load ptr, ptr %l1, !tbaa !29
  %t679 = getelementptr %"compiler/free:Free", ptr %t677, i32 0, i32 34
  %t681 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t679)
  store i64 %t681, ptr %l396
  br label %bb170
bb170:
  %t682 = load ptr, ptr %l393, !tbaa !29
  %t683 = load i64, ptr %l396, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t682, i64 %t683)
  br label %bb171
bb171:
  store i64 0, ptr %l53, !tbaa !24
  %t685 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %l38)
  store i64 %t685, ptr %l398
  br label %bb172
bb172:
  %t686 = load i64, ptr %l398, !tbaa !24
  store i64 %t686, ptr %l54, !tbaa !24
  store i64 1, ptr %l55, !tbaa !24
  %t687 = load i64, ptr %l54, !tbaa !24
  %t688 = load i64, ptr %l53, !tbaa !24
  %t691 = icmp sgt i64 %t687, %t688
  br i1 %t691, label %bb173, label %bb174
bb173:
  %t693 = load i64, ptr %l55, !tbaa !24
  %t695 = icmp sgt i64 %t693, 0
  br i1 %t695, label %bb175, label %bb176
bb174:
  store i64 0, ptr %l402, !tbaa !24
  br label %bb178
bb175:
  %t697 = load i64, ptr %l54, !tbaa !24
  %t698 = load i64, ptr %l53, !tbaa !24
  %t701 = sub i64 %t697, %t698
  %t702 = load i64, ptr %l55, !tbaa !24
  %t705 = add i64 %t701, %t702
  %t707 = sub i64 %t705, 1
  %t708 = load i64, ptr %l55, !tbaa !24
  %t711 = sdiv i64 %t707, %t708
  store i64 %t711, ptr %l405, !tbaa !24
  br label %bb177
bb176:
  store i64 0, ptr %l405, !tbaa !24
  br label %bb177
bb177:
  %t713 = load i64, ptr %l405, !tbaa !24
  store i64 %t713, ptr %l402, !tbaa !24
  br label %bb178
bb178:
  %t714 = load i64, ptr %l402, !tbaa !24
  store i64 %t714, ptr %l56, !tbaa !24
  store i64 0, ptr %l57, !tbaa !24
  br label %bb179
bb179:
  %t715 = load i64, ptr %l57, !tbaa !24
  %t716 = load i64, ptr %l56, !tbaa !24
  %t719 = icmp slt i64 %t715, %t716
  %t721 = xor i1 %t719, true
  br i1 %t721, label %bb180, label %bb181
bb180:
  br label %bb188
bb181:
  br label %bb182
bb182:
  %t723 = load i64, ptr %l53, !tbaa !24
  %t724 = load i64, ptr %l57, !tbaa !24
  %t725 = load i64, ptr %l55, !tbaa !24
  %t728 = mul i64 %t724, %t725
  %t731 = add i64 %t723, %t728
  store i64 %t731, ptr %l58, !tbaa !24
  %t733 = load ptr, ptr %l1, !tbaa !29
  %t735 = getelementptr %"compiler/free:Free", ptr %t733, i32 0, i32 34
  store ptr %t735, ptr %l424, !tbaa !29
  %t736 = load i64, ptr %l58, !tbaa !24
  %t739 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %l38, i64 %t736)
  store i64 %t739, ptr %l427
  br label %bb183
bb183:
  %t740 = load ptr, ptr %l424, !tbaa !29
  %t741 = load i64, ptr %l427, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t740, i64 %t741)
  br label %bb184
bb184:
  %t742 = load ptr, ptr %l1, !tbaa !29
  %t744 = getelementptr %"compiler/free:Free", ptr %t742, i32 0, i32 35
  store ptr %t744, ptr %l429, !tbaa !29
  %t745 = load i64, ptr %l58, !tbaa !24
  %t748 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s18, ptr %l39, i64 %t745)
  store %"compiler/source:Span" %t748, ptr %l432
  br label %bb185
bb185:
  %t749 = load ptr, ptr %l429, !tbaa !29
  %t750 = load %"compiler/source:Span", ptr %l432
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t749, %"compiler/source:Span" %t750)
  br label %bb186
bb186:
  br label %bb187
bb187:
  %t751 = load i64, ptr %l57, !tbaa !24
  %t753 = add i64 %t751, 1
  store i64 %t753, ptr %l57, !tbaa !24
  br label %bb179
bb188:
  %t755 = load ptr, ptr %l1, !tbaa !29
  %t757 = getelementptr %"compiler/free:Free", ptr %t755, i32 0, i32 46
  %t758 = load i1, ptr %t757, !tbaa !21
  br i1 %t758, label %bb189, label %bb190
bb189:
  %t760 = load ptr, ptr %l0, !tbaa !29
  store ptr %t760, ptr %l437, !tbaa !29
  %t761 = load ptr, ptr %l1, !tbaa !29
  %t763 = getelementptr %"compiler/free:Free", ptr %t761, i32 0, i32 29
  %t765 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t763)
  store i64 %t765, ptr %l440
  br label %bb191
bb190:
  br label %bb193
bb191:
  %t766 = load i64, ptr %l440, !tbaa !24
  %t767 = sub i64 %t766, 1
  %t768 = load i64, ptr %l36, !tbaa !24
  %t769 = load %"compiler/source:Span", ptr %l37
  %t770 = load ptr, ptr %l437, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewsAcross(ptr %v0, ptr %s0, ptr %s0, ptr %t770, i64 %t767, i64 %t768, %"compiler/source:Span" %t769, ptr %l25, ptr %l26)
  br label %bb192
bb192:
  br label %bb193
bb193:
  call void @__olang_scope_close(ptr %s18)
  br label %bb194
bb194:
  %t776 = load i64, ptr %l34, !tbaa !24
  %t778 = add i64 %t776, 1
  store i64 %t778, ptr %l34, !tbaa !24
  br label %bb94
bb195:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einUseAcross(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i64
  %l43 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i1
  %l72 = alloca %"compiler/source:Span"
  %l74 = alloca i1
  %l81 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i64
  %l109 = alloca i64
  %l113 = alloca i1
  %l114 = alloca i64
  %l118 = alloca i64
  %l121 = alloca i1
  %l125 = alloca i64
  %l129 = alloca i64
  %l131 = alloca i64
  %l136 = alloca i64
  %l137 = alloca i64
  %l141 = alloca i64
  %l143 = alloca i1
  %l147 = alloca i64
  %l151 = alloca i64
  %l161 = alloca i1
  %l162 = alloca i1
  %l164 = alloca i64
  %l167 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 20
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l22
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l22, !tbaa !24
  %t11 = icmp sgt i64 %t9, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 20
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l29
  br label %bb5
bb5:
  %t21 = load i64, ptr %l29, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:walker", ptr %t22, i32 0, i32 21
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t24, i64 %t25)
  store i1 %t28, ptr %l33
  br label %bb6
bb6:
  %t29 = load i1, ptr %l33, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sle i64 %t30, %t31
  store i1 %t34, ptr %l34, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l34, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load i64, ptr %l2, !tbaa !24
  store i64 %t37, ptr %l39, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/free:walker", ptr %t38, i32 0, i32 13
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t40, i64 %t41)
  store i64 %t44, ptr %l43
  br label %bb12
bb11:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb13
bb12:
  %t45 = load i64, ptr %l39, !tbaa !24
  %t46 = load i64, ptr %l43, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  store i1 %t47, ptr %l38, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l38, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l4, !tbaa !29
  store ptr %t51, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t53 = load i64, ptr %l7, !tbaa !24
  store i64 %t53, ptr %l47, !tbaa !24
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t54)
  store i64 %t56, ptr %l49
  br label %bb18
bb18:
  %t57 = load i64, ptr %l47, !tbaa !24
  %t58 = load i64, ptr %l49, !tbaa !24
  %t59 = icmp slt i64 %t57, %t58
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb19, label %bb20
bb19:
  br label %bb37
bb20:
  br label %bb21
bb21:
  %t63 = load ptr, ptr %l6, !tbaa !29
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t63, i64 %t64)
  store i64 %t67, ptr %l54
  br label %bb22
bb22:
  %t68 = load i64, ptr %l54, !tbaa !24
  store i64 %t68, ptr %l8, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:walker", ptr %t69, i32 0, i32 26
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t71, i64 %t72)
  store i64 %t75, ptr %l58
  br label %bb23
bb23:
  %t76 = load i64, ptr %l2, !tbaa !24
  %t77 = load i64, ptr %l58, !tbaa !24
  %t79 = icmp sgt i64 %t77, %t76
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t81 = load i64, ptr %l8, !tbaa !24
  store i64 %t81, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:walker", ptr %t83, i32 0, i32 26
  %t86 = load i64, ptr %l8, !tbaa !24
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t85, i64 %t86)
  store i64 %t89, ptr %l65
  br label %bb27
bb27:
  %t90 = load i64, ptr %l2, !tbaa !24
  %t91 = load i64, ptr %l65, !tbaa !24
  %t93 = icmp eq i64 %t91, %t90
  br i1 %t93, label %bb28, label %bb29
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/free:walker", ptr %t95, i32 0, i32 27
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t97, i64 %t98)
  store %"compiler/source:Span" %t101, ptr %l72
  br label %bb30
bb29:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb32
bb30:
  %t103 = load %"compiler/source:Span", ptr %l72
  %t105 = call i1 @compiler_2ffree_2espanIn(%"compiler/source:Span" %t103, %"compiler/source:Span" %a3)
  store i1 %t105, ptr %l74
  br label %bb31
bb31:
  %t106 = load i1, ptr %l74, !tbaa !21
  %t107 = xor i1 %t106, true
  store i1 %t107, ptr %l68, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l68, !tbaa !21
  br i1 %t109, label %bb33, label %bb34
bb33:
  %t110 = load i64, ptr %l8, !tbaa !24
  store i64 %t110, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t112 = load i64, ptr %l7, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l7, !tbaa !24
  br label %bb17
bb37:
  store i64 0, ptr %l9, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/free:walker", ptr %t116, i32 0, i32 14
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t118)
  store i64 %t120, ptr %l81
  br label %bb38
bb38:
  %t121 = load i64, ptr %l81, !tbaa !24
  store i64 %t121, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp sgt i64 %t122, %t123
  br i1 %t126, label %bb39, label %bb40
bb39:
  %t128 = load i64, ptr %l11, !tbaa !24
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb44
bb41:
  %t132 = load i64, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l9, !tbaa !24
  %t136 = sub i64 %t132, %t133
  %t137 = load i64, ptr %l11, !tbaa !24
  %t140 = add i64 %t136, %t137
  %t142 = sub i64 %t140, 1
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = sdiv i64 %t142, %t143
  store i64 %t146, ptr %l88, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb43
bb43:
  %t148 = load i64, ptr %l88, !tbaa !24
  store i64 %t148, ptr %l85, !tbaa !24
  br label %bb44
bb44:
  %t149 = load i64, ptr %l85, !tbaa !24
  store i64 %t149, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb45
bb45:
  %t150 = load i64, ptr %l13, !tbaa !24
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = icmp slt i64 %t150, %t151
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb46, label %bb47
bb46:
  br label %bb79
bb47:
  br label %bb48
bb48:
  %t158 = load i64, ptr %l9, !tbaa !24
  %t159 = load i64, ptr %l13, !tbaa !24
  %t160 = load i64, ptr %l11, !tbaa !24
  %t163 = mul i64 %t159, %t160
  %t166 = add i64 %t158, %t163
  store i64 %t166, ptr %l14, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/free:walker", ptr %t168, i32 0, i32 14
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t170, i64 %t171)
  store i64 %t174, ptr %l109
  br label %bb49
bb49:
  %t175 = load i64, ptr %l109, !tbaa !24
  store i64 %t175, ptr %l15, !tbaa !24
  %t176 = load i64, ptr %l15, !tbaa !24
  %t177 = load i64, ptr %l2, !tbaa !24
  %t180 = icmp slt i64 %t176, %t177
  br i1 %t180, label %bb50, label %bb51
bb50:
  %t182 = load i64, ptr %l2, !tbaa !24
  store i64 %t182, ptr %l114, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/free:walker", ptr %t183, i32 0, i32 15
  %t186 = load i64, ptr %l14, !tbaa !24
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t185, i64 %t186)
  store i64 %t189, ptr %l118
  br label %bb52
bb51:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb53
bb52:
  %t190 = load i64, ptr %l114, !tbaa !24
  %t191 = load i64, ptr %l118, !tbaa !24
  %t192 = icmp sle i64 %t190, %t191
  store i1 %t192, ptr %l113, !tbaa !21
  br label %bb53
bb53:
  %t194 = load i1, ptr %l113, !tbaa !21
  %t195 = xor i1 %t194, true
  br i1 %t195, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l121, !tbaa !21
  br label %bb57
bb55:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/free:walker", ptr %t197, i32 0, i32 20
  %t200 = load i64, ptr %l1, !tbaa !24
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t199, i64 %t200)
  store i64 %t203, ptr %l125
  br label %bb56
bb56:
  %t204 = load i64, ptr %l15, !tbaa !24
  %t205 = load i64, ptr %l125, !tbaa !24
  %t207 = icmp sgt i64 %t205, %t204
  store i1 %t207, ptr %l121, !tbaa !21
  br label %bb57
bb57:
  %t209 = load i1, ptr %l121, !tbaa !21
  br i1 %t209, label %bb58, label %bb59
bb58:
  br label %bb78
bb59:
  br label %bb60
bb60:
  %t210 = load ptr, ptr %l4, !tbaa !29
  store ptr %t210, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb61
bb61:
  %t212 = load i64, ptr %l17, !tbaa !24
  store i64 %t212, ptr %l129, !tbaa !24
  %t213 = load ptr, ptr %l16, !tbaa !29
  %t215 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t213)
  store i64 %t215, ptr %l131
  br label %bb62
bb62:
  %t216 = load i64, ptr %l129, !tbaa !24
  %t217 = load i64, ptr %l131, !tbaa !24
  %t218 = icmp slt i64 %t216, %t217
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb63, label %bb64
bb63:
  br label %bb77
bb64:
  br label %bb65
bb65:
  %t222 = load ptr, ptr %l16, !tbaa !29
  %t223 = load i64, ptr %l17, !tbaa !24
  %t226 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t222, i64 %t223)
  store i64 %t226, ptr %l136
  br label %bb66
bb66:
  %t227 = load i64, ptr %l136, !tbaa !24
  store i64 %t227, ptr %l18, !tbaa !24
  %t228 = load i64, ptr %l15, !tbaa !24
  store i64 %t228, ptr %l137, !tbaa !24
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/free:walker", ptr %t229, i32 0, i32 26
  %t232 = load i64, ptr %l18, !tbaa !24
  %t235 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t231, i64 %t232)
  store i64 %t235, ptr %l141
  br label %bb67
bb67:
  %t236 = load i64, ptr %l137, !tbaa !24
  %t237 = load i64, ptr %l141, !tbaa !24
  %t238 = icmp slt i64 %t236, %t237
  br i1 %t238, label %bb68, label %bb69
bb68:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/free:walker", ptr %t240, i32 0, i32 26
  %t243 = load i64, ptr %l18, !tbaa !24
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t242, i64 %t243)
  store i64 %t246, ptr %l147
  br label %bb70
bb69:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb72
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/free:walker", ptr %t247, i32 0, i32 15
  %t250 = load i64, ptr %l14, !tbaa !24
  %t253 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t249, i64 %t250)
  store i64 %t253, ptr %l151
  br label %bb71
bb71:
  %t254 = load i64, ptr %l147, !tbaa !24
  %t255 = load i64, ptr %l151, !tbaa !24
  %t256 = icmp sle i64 %t254, %t255
  store i1 %t256, ptr %l143, !tbaa !21
  br label %bb72
bb72:
  %t258 = load i1, ptr %l143, !tbaa !21
  br i1 %t258, label %bb73, label %bb74
bb73:
  %t259 = load i64, ptr %l18, !tbaa !24
  store i64 %t259, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t261 = load i64, ptr %l17, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l17, !tbaa !24
  br label %bb61
bb77:
  br label %bb78
bb78:
  %t265 = load i64, ptr %l13, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l13, !tbaa !24
  br label %bb45
bb79:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/free:walker", ptr %t269, i32 0, i32 28
  %t272 = load i64, ptr %l1, !tbaa !24
  %t275 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t271, i64 %t272)
  store i1 %t275, ptr %l161
  br label %bb80
bb80:
  %t276 = load i1, ptr %l161, !tbaa !21
  br i1 %t276, label %bb81, label %bb82
bb81:
  %t277 = load ptr, ptr %l4, !tbaa !29
  %t279 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t277)
  store i64 %t279, ptr %l164
  br label %bb83
bb82:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb84
bb83:
  %t280 = load i64, ptr %l164, !tbaa !24
  %t281 = icmp sgt i64 %t280, 0
  store i1 %t281, ptr %l162, !tbaa !21
  br label %bb84
bb84:
  %t283 = load i1, ptr %l162, !tbaa !21
  br i1 %t283, label %bb85, label %bb86
bb85:
  %t284 = load ptr, ptr %l4, !tbaa !29
  %t286 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t284, i64 0)
  store i64 %t286, ptr %l167
  br label %bb87
bb86:
  br label %bb88
bb87:
  %t287 = load i64, ptr %l167, !tbaa !24
  store i64 %t287, ptr %rv
  br label %ret
bb88:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einsidePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l10 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ederefRoot(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %t11)
  store i64 %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load i64, ptr %l10, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eletsThrough(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i1 %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i32
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i64
  %l34 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l55 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca ptr
  %l67 = alloca i64
  %l70 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca i64
  %l78 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca %"compiler/source:Span"
  %l91 = alloca i64
  %l96 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca %"compiler/source:Span"
  %l100 = alloca %"compiler/source:Span"
  %l107 = alloca i1
  %l109 = alloca ptr
  %l111 = alloca ptr
  %l113 = alloca i32
  %l114 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i1 %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ewrittenRecs(ptr %v2, ptr %s0, ptr %t6)
  %t9 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t8, 1
  %t10 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t8, 0
  store i32 %t10, ptr %l21
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb2, label %ok.12, !prof !99
ok.12:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l20
  br label %bb1
bb1:
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l18
  br label %bb5
bb2:
  br label %bb3
bb3:
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l22
  br label %bb4
bb4:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l18
  br label %bb5
bb5:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l7
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t18, ptr %l24
  br label %bb6
bb6:
  %t19 = load i64, ptr %l24, !tbaa !24
  %t20 = icmp sgt i64 %t19, 0
  br i1 %t20, label %bb7, label %bb8
bb7:
  store ptr %l7, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb8:
  br label %bb46
bb9:
  %t23 = load i64, ptr %l9, !tbaa !24
  store i64 %t23, ptr %l27, !tbaa !24
  %t24 = load ptr, ptr %l8, !tbaa !29
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t24)
  store i64 %t26, ptr %l29
  br label %bb10
bb10:
  %t27 = load i64, ptr %l27, !tbaa !24
  %t28 = load i64, ptr %l29, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb11, label %bb12
bb11:
  br label %bb45
bb12:
  br label %bb13
bb13:
  %t33 = load ptr, ptr %l8, !tbaa !29
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t33, i64 %t34)
  store i64 %t37, ptr %l34
  br label %bb14
bb14:
  %t38 = load i64, ptr %l34, !tbaa !24
  %t41 = ashr i64 %t38, 1
  store i64 %t41, ptr %l11, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/free:walker", ptr %t43, i32 0, i32 2
  %t46 = load i1, ptr %t45, !tbaa !21
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l6, !tbaa !29
  %t52 = getelementptr %"compiler/free:Free", ptr %t50, i32 0, i32 97
  %t53 = load i64, ptr %l11, !tbaa !24
  %t56 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t52, i64 %t53)
  store ptr %t56, ptr %l43
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:walker", ptr %t57, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = load ptr, ptr %l43, !tbaa !29
  %t63 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t61, i64 %t60)
  store i64 %t63, ptr %l46
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t66 = getelementptr %"compiler/free:Free", ptr %t64, i32 0, i32 69
  %t67 = load i64, ptr %l11, !tbaa !24
  %t70 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t66, i64 %t67)
  store i1 %t70, ptr %l50
  br label %bb20
bb20:
  %t71 = load i1, ptr %l50, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb24
bb22:
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t74 = getelementptr %"compiler/free:Free", ptr %t72, i32 0, i32 70
  %t75 = load i64, ptr %l11, !tbaa !24
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t74, i64 %t75)
  store i64 %t78, ptr %l55
  br label %bb23
bb23:
  %t79 = load i64, ptr %l55, !tbaa !24
  %t80 = icmp ne i64 %t79, 0
  store i1 %t80, ptr %l51, !tbaa !21
  br label %bb24
bb24:
  %t82 = load i1, ptr %l51, !tbaa !21
  br i1 %t82, label %bb25, label %bb26
bb25:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l5
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t86 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t83, %"compiler/source:Span" %t84, ptr %t85, i64 %t86)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb44
bb28:
  %t91 = load ptr, ptr %l6, !tbaa !29
  %t93 = getelementptr %"compiler/free:Free", ptr %t91, i32 0, i32 68
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t93, i64 %t94)
  store ptr %t97, ptr %l64
  br label %bb29
bb29:
  %t98 = load ptr, ptr %l64, !tbaa !29
  store ptr %t98, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t99 = load i64, ptr %l13, !tbaa !24
  store i64 %t99, ptr %l65, !tbaa !24
  %t100 = load ptr, ptr %l12, !tbaa !29
  store ptr %t100, ptr %l66, !tbaa !29
  %t101 = ptrtoint ptr %v0 to i64
  store i64 %t101, ptr %l67, !tbaa !24
  %t102 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = load ptr, ptr %l66, !tbaa !29
  %t105 = call ptr @__olang_region_or(ptr %t104, ptr %v0)
  %t106 = ptrtoint ptr %t105 to i64
  store i64 %t106, ptr %l67, !tbaa !24
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l12, !tbaa !29
  %t108 = load i64, ptr %l67
  %t109 = inttoptr i64 %t108 to ptr
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t109, ptr %t107)
  store i64 %t111, ptr %l70
  br label %bb33
bb33:
  %t112 = load i64, ptr %l65, !tbaa !24
  %t113 = load i64, ptr %l70, !tbaa !24
  %t114 = icmp slt i64 %t112, %t113
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb35:
  br label %bb36
bb36:
  %t118 = load ptr, ptr %l12, !tbaa !29
  store ptr %t118, ptr %l73, !tbaa !29
  %t119 = ptrtoint ptr %v0 to i64
  store i64 %t119, ptr %l74, !tbaa !24
  %t120 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t120, label %bb37, label %bb38
bb37:
  %t122 = load ptr, ptr %l73, !tbaa !29
  %t123 = call ptr @__olang_region_or(ptr %t122, ptr %v0)
  %t124 = ptrtoint ptr %t123 to i64
  store i64 %t124, ptr %l74, !tbaa !24
  br label %bb38
bb38:
  %t125 = load ptr, ptr %l12, !tbaa !29
  %t126 = load i64, ptr %l13, !tbaa !24
  %t127 = load i64, ptr %l74
  %t128 = inttoptr i64 %t127 to ptr
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t128, ptr %t125, i64 %t126)
  store i64 %t131, ptr %l78
  br label %bb39
bb39:
  %t132 = load i64, ptr %l78, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l79, !tbaa !29
  store i64 %t132, ptr %l80, !tbaa !24
  %t135 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t135, ptr %l81, !tbaa !24
  %t136 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t136, ptr %l82
  %t137 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s7, i32 0, i32 0)
  store %"compiler/source:Span" %t137, ptr %l83
  br label %bb40
bb40:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load ptr, ptr %l79, !tbaa !29
  %t140 = load i64, ptr %l80, !tbaa !24
  %t141 = load i64, ptr %l81, !tbaa !24
  %t142 = load %"compiler/source:Span", ptr %l82
  %t143 = load %"compiler/source:Span", ptr %l83
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t139, i64 %t140, i64 %t141, %"compiler/source:Span" %t142, %"compiler/source:Span" %t143, i64 %t138)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb42:
  %t145 = load i64, ptr %l13, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l13, !tbaa !24
  br label %bb30
bb43:
  br label %bb44
bb44:
  %t149 = load i64, ptr %l9, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l9, !tbaa !24
  br label %bb9
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb46:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l2, !tbaa !29
  %t157 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efixedParam(ptr %v0, ptr %v2, ptr %t153, ptr %t154)
  store i64 %t157, ptr %l91
  br label %bb47
bb47:
  %t158 = load i64, ptr %l91, !tbaa !24
  store i64 %t158, ptr %l15, !tbaa !24
  %t159 = load i64, ptr %l15, !tbaa !24
  %t161 = icmp sge i64 %t159, 0
  br i1 %t161, label %bb48, label %bb49
bb48:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/free:walker", ptr %t163, i32 0, i32 2
  %t166 = load i1, ptr %t165, !tbaa !21
  br i1 %t166, label %bb50, label %bb51
bb49:
  br label %bb56
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l96, !tbaa !29
  %t169 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  store i64 %t169, ptr %l97, !tbaa !24
  %t170 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t170, ptr %l98, !tbaa !24
  %t171 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t171, ptr %l99
  %t172 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 0, i32 0)
  store %"compiler/source:Span" %t172, ptr %l100
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t173 = load i64, ptr @G_2ecompiler_2ffree_2eCalleeGiven, !tbaa !24
  %t174 = load ptr, ptr %l96, !tbaa !29
  %t175 = load i64, ptr %l97, !tbaa !24
  %t176 = load i64, ptr %l98, !tbaa !24
  %t177 = load %"compiler/source:Span", ptr %l99
  %t178 = load %"compiler/source:Span", ptr %l100
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t174, i64 %t175, i64 %t176, %"compiler/source:Span" %t177, %"compiler/source:Span" %t178, i64 %t173)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb54:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l15, !tbaa !24
  %t182 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2evia(ptr %v0, ptr %t180, i64 %t181, i1 %t182)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  %t186 = load i1, ptr %l4, !tbaa !21
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb57, label %bb58
bb57:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t190)
  store ptr %t192, ptr %l109
  br label %bb59
bb58:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb67
bb59:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t193)
  store ptr %t195, ptr %l111
  br label %bb60
bb60:
  %t197 = load ptr, ptr %l111, !tbaa !29
  %t199 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t197, i32 %a3)
  store i32 %t199, ptr %l113
  br label %bb61
bb61:
  %t200 = load ptr, ptr %l109, !tbaa !29
  %t201 = load i32, ptr %l113, !tbaa !23
  %t202 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesPure(ptr %v0, ptr %t200, i32 %t201)
  store i1 %t202, ptr %l114
  br label %bb62
bb62:
  %t203 = load i1, ptr %l114, !tbaa !21
  br i1 %t203, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb66
bb64:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l2, !tbaa !29
  %t208 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2epureValue(ptr %v0, ptr %v2, ptr %t204, ptr %t205)
  store i1 %t208, ptr %l118
  br label %bb65
bb65:
  %t209 = load i1, ptr %l118, !tbaa !21
  store i1 %t209, ptr %l115, !tbaa !21
  br label %bb66
bb66:
  %t210 = load i1, ptr %l115, !tbaa !21
  store i1 %t210, ptr %l107, !tbaa !21
  br label %bb67
bb67:
  %t211 = load i1, ptr %l107, !tbaa !21
  br i1 %t211, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb69:
  br label %bb70
bb70:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l5
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t215 = load i64, ptr @G_2ecompiler_2ffree_2eCalleeGiven, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t212, %"compiler/source:Span" %t213, ptr %t214, i64 %t215)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopAround(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i1
  %l53 = alloca i64
  %l56 = alloca i1
  %l57 = alloca i64
  %l61 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 14
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l39
  br label %bb12
bb12:
  %t60 = load i64, ptr %l1, !tbaa !24
  %t61 = load i64, ptr %l39, !tbaa !24
  %t63 = icmp slt i64 %t61, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i64, ptr %l1, !tbaa !24
  store i64 %t65, ptr %l43, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 15
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l47
  br label %bb15
bb14:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb16
bb15:
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l47, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  store i1 %t75, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l42, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/free:walker", ptr %t78, i32 0, i32 14
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t80, i64 %t81)
  store i64 %t84, ptr %l53
  br label %bb19
bb18:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb20
bb19:
  %t85 = load i64, ptr %l2, !tbaa !24
  %t86 = load i64, ptr %l53, !tbaa !24
  %t88 = icmp slt i64 %t86, %t85
  store i1 %t88, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t90 = load i1, ptr %l49, !tbaa !21
  br i1 %t90, label %bb21, label %bb22
bb21:
  %t91 = load i64, ptr %l2, !tbaa !24
  store i64 %t91, ptr %l57, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:walker", ptr %t92, i32 0, i32 15
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t94, i64 %t95)
  store i64 %t98, ptr %l61
  br label %bb23
bb22:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb24
bb23:
  %t99 = load i64, ptr %l57, !tbaa !24
  %t100 = load i64, ptr %l61, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  store i1 %t101, ptr %l56, !tbaa !21
  br label %bb24
bb24:
  %t103 = load i1, ptr %l56, !tbaa !21
  br i1 %t103, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t105 = load i64, ptr %l7, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l7, !tbaa !24
  br label %bb8
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i1
  %l12 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i1
  %l25 = alloca i1
  %l34 = alloca { i64, ptr }
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i64
  %l51 = alloca ptr
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l71 = alloca i64
  %l77 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l79 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca i1
  %l88 = alloca i1
  %l98 = alloca i1
  %l102 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = ptrtoint ptr %v2 to i64
  store i64 %t1, ptr %l12, !tbaa !24
  %t2 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2emakeOf_2elocal_2e4
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = call ptr @__olang_region_make(ptr %v2)
  %t5 = ptrtoint ptr %t4 to i64
  store i64 %t5, ptr %l12, !tbaa !24
  br label %bb2
bb2:
  %t6 = load i64, ptr %l12
  %t7 = inttoptr i64 %t6 to ptr
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t7, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l14
  br label %bb3
bb3:
  %t9 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2emakeOf_2elocal_2e4
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l12
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = call ptr @__olang_region_or(ptr %t15, ptr null)
  %t17 = icmp ne ptr %t16, null
  %t18 = select i1 %t17, ptr %t16, ptr null
  %t19 = icmp eq ptr %t18, %t12
  call void @__olang_region_settle(ptr %t12, i1 %t19)
  br label %bb5
bb5:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t20, ptr %lp4
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  %t22 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %t22
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Make", ptr %t23, i32 0, i32 0
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 5}
  %t28 = trunc i64 3 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:walker", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/free:Free", ptr %t34, i32 0, i32 61
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:walker", ptr %t37, i32 0, i32 1
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t36, i64 %t40)
  store i1 %t43, ptr %l25
  br label %bb8
bb7:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb9
bb8:
  %t44 = load i1, ptr %l25, !tbaa !21
  store i1 %t44, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l19, !tbaa !21
  store i1 %t45, ptr %l5, !tbaa !21
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Make", ptr %t46, i32 0, i32 2
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t63 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t63, ptr %l34, !tbaa !27
  %t64 = load i64, ptr %l7, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr ptr, ptr %t67, i64 %t64
  %t69 = load ptr, ptr %t68, !tbaa !39
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t75 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %t71, ptr %t69)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l39
  br label %bb14
bb14:
  %t76 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %l10
  %t77 = load i1, ptr %l5, !tbaa !21
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb15, label %bb16
bb15:
  %t81 = load ptr, ptr %lp4
  %t84 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s2, ptr %t81, ptr %l10)
  store i64 %t84, ptr %l44
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb10
bb20:
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Make", ptr %t89, i32 0, i32 3
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l51, !tbaa !29
  %t99 = load ptr, ptr %l3, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Make", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb23, label %bb24
bb22:
  br label %bb27
bb23:
  call void @__olang_check_failed(ptr @olang_loc_f349e97cfb4cca10_59712e6808efe99c)
  unreachable
bb24:
  br label %bb25
bb25:
  %t106 = load ptr, ptr %l3, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Make", ptr %t106, i32 0, i32 3
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load ptr, ptr %l51, !tbaa !29
  %t112 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t110, ptr %t109)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %l57
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Make", ptr %t113, i32 0, i32 4
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = icmp sge i32 %t116, 0
  br i1 %t118, label %bb28, label %bb29
bb28:
  %t120 = load ptr, ptr %lp4
  store ptr %t120, ptr %l61, !tbaa !29
  %t121 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Make", ptr %t122, i32 0, i32 4
  %t125 = load i32, ptr %t124, !tbaa !23
  %t127 = sext i32 %t125 to i64
  %t130 = call i64 @compiler_2ffree_2eorig(i64 %t121, i64 %t127)
  store i64 %t130, ptr %l66
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t131 = load ptr, ptr %l61, !tbaa !29
  %t132 = load i64, ptr %l66, !tbaa !24
  %t133 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t131, i64 %t132)
  store i64 %t133, ptr %l67
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t134 = load ptr, ptr %l3, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Make", ptr %t134, i32 0, i32 0
  %t137 = load i32, ptr %t136, !range !{i32 0, i32 5}
  %t139 = trunc i64 4 to i32
  %t140 = icmp eq i32 %t137, %t139
  br i1 %t140, label %bb33, label %bb34
bb33:
  %t142 = ptrtoint ptr %v2 to i64
  store i64 %t142, ptr %l71, !tbaa !24
  %t143 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2emakeOf_2elocal_2e4
  br i1 %t143, label %bb35, label %bb36
bb34:
  br label %bb42
bb35:
  %t145 = call ptr @__olang_region_make(ptr %v2)
  %t146 = ptrtoint ptr %t145 to i64
  store i64 %t146, ptr %l71, !tbaa !24
  br label %bb36
bb36:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/free:walker", ptr %t147, i32 0, i32 0
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t151 = load ptr, ptr %lp4
  %t152 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t151
  %t154 = load i64, ptr %l71
  %t155 = inttoptr i64 %t154 to ptr
  %t156 = call ptr @__olang_scope_alloc_a(ptr %t155, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %t156
  %t157 = load i64, ptr %l71
  %t158 = inttoptr i64 %t157 to ptr
  %t159 = load i64, ptr %l71
  %t160 = inttoptr i64 %t159 to ptr
  %t163 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %t158, ptr %t160, ptr %t150, ptr %t156)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t163, ptr %l77
  br label %bb37
bb37:
  %t164 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2emakeOf_2elocal_2e4
  br i1 %t164, label %bb38, label %bb39
bb38:
  %t166 = load i64, ptr %l71
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77, i32 0, i32 0
  %t169 = load { i64, ptr }, ptr %t168
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = call ptr @__olang_region_or(ptr %t170, ptr null)
  %t172 = icmp ne ptr %t171, null
  %t173 = select i1 %t172, ptr %t171, ptr null
  %t174 = icmp eq ptr %t173, %t167
  call void @__olang_region_settle(ptr %t167, i1 %t174)
  br label %bb39
bb39:
  %t175 = load ptr, ptr %lp4
  %t176 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t175
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t176, ptr %l79
  %t177 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77
  %t178 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t177, ptr %t178
  %t179 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2emakeOf_2elocal_2e4
  br i1 %t179, label %bb40, label %bb41
bb40:
  %t181 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l79, i32 0, i32 0
  %t182 = load { i64, ptr }, ptr %t181
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = call ptr @__olang_region_or(ptr %t183, ptr null)
  %t185 = icmp ne ptr %t184, null
  %t186 = select i1 %t185, ptr %t184, ptr null
  call void @__olang_region_drop(ptr %t186)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l79
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t187 = load ptr, ptr %l3, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Make", ptr %t187, i32 0, i32 0
  %t190 = load i32, ptr %t189, !range !{i32 0, i32 5}
  %t192 = trunc i64 4 to i32
  %t193 = icmp eq i32 %t190, %t192
  br i1 %t193, label %bb43, label %bb44
bb43:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/free:walker", ptr %t195, i32 0, i32 36
  %t198 = load i64, ptr %t197, !tbaa !24
  %t200 = icmp sge i64 %t198, 0
  store i1 %t200, ptr %l84, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb45
bb45:
  %t202 = load i1, ptr %l84, !tbaa !21
  br i1 %t202, label %bb46, label %bb47
bb46:
  %t203 = load ptr, ptr %l3, !tbaa !29
  %t205 = getelementptr %"compiler/typed:Make", ptr %t203, i32 0, i32 4
  %t206 = load i32, ptr %t205, !tbaa !23
  %t208 = sext i32 %t206 to i64
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/free:walker", ptr %t209, i32 0, i32 36
  %t212 = load i64, ptr %t211, !tbaa !24
  %t215 = icmp eq i64 %t208, %t212
  store i1 %t215, ptr %l88, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb48
bb48:
  %t217 = load i1, ptr %l88, !tbaa !21
  store i1 %t217, ptr %l11, !tbaa !21
  %t218 = load ptr, ptr %l3, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Make", ptr %t218, i32 0, i32 0
  %t221 = load i32, ptr %t220, !range !{i32 0, i32 5}
  %t223 = trunc i64 4 to i32
  %t224 = icmp eq i32 %t221, %t223
  br i1 %t224, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb51
bb50:
  %t226 = load ptr, ptr %l3, !tbaa !29
  %t228 = getelementptr %"compiler/typed:Make", ptr %t226, i32 0, i32 0
  %t229 = load i32, ptr %t228, !range !{i32 0, i32 5}
  %t231 = trunc i64 3 to i32
  %t232 = icmp eq i32 %t229, %t231
  store i1 %t232, ptr %l98, !tbaa !21
  br label %bb51
bb51:
  %t234 = load i1, ptr %l98, !tbaa !21
  br i1 %t234, label %bb52, label %bb53
bb52:
  %t235 = load i1, ptr %l11, !tbaa !21
  %t237 = xor i1 %t235, true
  store i1 %t237, ptr %l102, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb54
bb54:
  %t239 = load i1, ptr %l102, !tbaa !21
  br i1 %t239, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s8
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l2, !tbaa !23
  %t242 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %s8, ptr %t240, i32 %t241, %"compiler/source:Span" %t242, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d77, i32 0, i32 1) })
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb58:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load ptr, ptr %l3, !tbaa !29
  %t248 = load i32, ptr %l2, !tbaa !23
  %t249 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeStores(ptr %v0, ptr %v1, ptr %t246, ptr %t247, i32 %t248, %"compiler/source:Span" %t249)
  br label %bb59
bb59:
  %t254 = load ptr, ptr %lp4
  %t255 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t254
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t255, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l18 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca i1
  %l37 = alloca ptr
  %l39 = alloca i1
  %l53 = alloca i1
  %l54 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb4:
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t12, i32 0, i32 1
  %t15 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t14, i32 0, i32 0
  %t16 = load %"compiler/source:Span", ptr %t15
  store %"compiler/source:Span" %t16, ptr %l3
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr { i64, [4 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t20, i32 0, i32 1
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l4, !tbaa !23
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l5, !tbaa !23
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t30)
  store ptr %t32, ptr %l26
  br label %bb5
bb5:
  %t33 = load i32, ptr %l2, !tbaa !23
  %t34 = load ptr, ptr %l26, !tbaa !29
  %t36 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t34, i32 %t33)
  store i1 %t36, ptr %l28
  br label %bb6
bb6:
  %t37 = load i1, ptr %l28, !tbaa !21
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t38 = load i1, ptr %l18, !tbaa !21
  br i1 %t38, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb9:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t41, i32 0, i32 0
  %t43 = load %"compiler/source:Span", ptr %t42
  store %"compiler/source:Span" %t43, ptr %l6
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t47, i32 0, i32 1
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l7, !tbaa !23
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t53, i32 0, i32 2
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l8, !tbaa !23
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t57)
  store ptr %t59, ptr %l37
  br label %bb10
bb10:
  %t60 = load i32, ptr %l2, !tbaa !23
  %t61 = load ptr, ptr %l37, !tbaa !29
  %t63 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %t61, i32 %t60)
  store i1 %t63, ptr %l39
  br label %bb11
bb11:
  %t64 = load i1, ptr %l39, !tbaa !21
  %t65 = xor i1 %t64, true
  store i1 %t65, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t67 = load i1, ptr %l29, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t71, i32 0, i32 0
  %t73 = load %"compiler/source:Span", ptr %t72
  store %"compiler/source:Span" %t73, ptr %l9
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t77, i32 0, i32 1
  %t79 = load i32, ptr %t78
  store i32 %t79, ptr %l10, !tbaa !23
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t83, i32 0, i32 2
  %t85 = load i32, ptr %t84
  %t89 = sext i32 %t85 to i64
  store i64 %t89, ptr %l12, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/free:walker", ptr %t91, i32 0, i32 41
  %t94 = load i64, ptr %l12, !tbaa !24
  %t97 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t93, i64 %t94)
  store i1 %t97, ptr %l53
  br label %bb16
bb16:
  %t98 = load i1, ptr %l53, !tbaa !21
  br i1 %t98, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb23
bb18:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/free:walker", ptr %t99, i32 0, i32 40
  %t102 = load i64, ptr %t101, !tbaa !24
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb19, label %bb20
bb19:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/free:walker", ptr %t106, i32 0, i32 6
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t108, i64 %t109)
  store i1 %t112, ptr %l62
  br label %bb21
bb20:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb22
bb21:
  %t113 = load i1, ptr %l62, !tbaa !21
  store i1 %t113, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t114 = load i1, ptr %l58, !tbaa !21
  store i1 %t114, ptr %l54, !tbaa !21
  br label %bb23
bb23:
  %t115 = load i1, ptr %l54, !tbaa !21
  store i1 %t115, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2enoteReach(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l16 = alloca i32
  %l20 = alloca i1
  %l27 = alloca i64
  %l35 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l42 = alloca i1
  %l52 = alloca i1
  %l63 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l69 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i64
  %l74 = alloca ptr
  %l76 = alloca i64
  %l78 = alloca %"compiler/source:Span"
  %l81 = alloca ptr
  %l82 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l101 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l107 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca i64
  %l112 = alloca ptr
  %l114 = alloca i64
  %l116 = alloca %"compiler/source:Span"
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load i32, ptr %l16, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i32, ptr %l2, !tbaa !23
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t15 = icmp eq i32 %t11, %t12
  store i1 %t15, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l20, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/free:walker", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachTy(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t25, ptr %l27
  br label %bb8
bb8:
  %t26 = load i64, ptr %l27, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp ne i64 %t27, -2
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:walker", ptr %t31, i32 0, i32 59
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:walker", ptr %t34, i32 0, i32 12
  %t37 = load i64, ptr %t36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t33, i64 %t37)
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t40, i32 0, i32 60
  store ptr %t42, ptr %l35, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t43)
  store %"compiler/source:Span" %t45, ptr %l37
  br label %bb12
bb12:
  %t46 = load ptr, ptr %l35, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t46, %"compiler/source:Span" %t47)
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/free:walker", ptr %t48, i32 0, i32 61
  %t51 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t50, i64 %t51)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t55 = load ptr, ptr %l41, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t58 = load ptr, ptr %l41, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 9
  store i1 %t61, ptr %l42, !tbaa !21
  br label %bb17
bb17:
  %t62 = load i1, ptr %l42, !tbaa !21
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t65, i32 0, i32 2
  %t67 = load i32, ptr %t66, !range !{i32 0, i32 52}
  store i32 %t67, ptr %l4
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [5 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t71, i32 0, i32 4
  %t73 = load { i64, ptr }, ptr %t72
  store { i64, ptr } %t73, ptr %l5, !tbaa !27
  br label %bb20
bb19:
  br label %bb38
bb20:
  %t75 = load i32, ptr %l4, !range !{i32 0, i32 52}
  %t77 = trunc i64 42 to i32
  %t78 = icmp eq i32 %t75, %t77
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load i32, ptr %l4, !range !{i32 0, i32 52}
  %t84 = trunc i64 43 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l52, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb23
bb23:
  %t89 = load i1, ptr %l52, !tbaa !21
  br i1 %t89, label %bb24, label %bb25
bb24:
  br label %ret
bb25:
  br label %bb26
bb26:
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t90, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l8, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l8, !tbaa !24
  %t100 = icmp slt i64 %t96, %t97
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb29:
  br label %bb30
bb30:
  %t104 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t104, ptr %l63, !tbaa !27
  %t105 = load i64, ptr %l7, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr ptr, ptr %t108, i64 %t105
  %t110 = load ptr, ptr %t109, !tbaa !39
  store ptr %t110, ptr %l9, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/free:walker", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  store ptr %t115, ptr %l67, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/free:walker", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  store ptr %t119, ptr %l69, !tbaa !29
  %t120 = load ptr, ptr %l9, !tbaa !29
  %t122 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t120)
  store i32 %t122, ptr %l71
  br label %bb31
bb31:
  %t123 = load ptr, ptr %l69, !tbaa !29
  %t124 = load i32, ptr %l71, !tbaa !23
  %t125 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachTy(ptr %v0, ptr %t123, i32 %t124)
  store i64 %t125, ptr %l72
  br label %bb32
bb32:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t126)
  store ptr %t128, ptr %l74
  br label %bb33
bb33:
  %t129 = load ptr, ptr %l74, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Body", ptr %t129, i32 0, i32 3
  %t132 = load i64, ptr %t131, !tbaa !24
  store i64 %t132, ptr %l76, !tbaa !24
  %t133 = load ptr, ptr %l9, !tbaa !29
  %t135 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t133)
  store %"compiler/source:Span" %t135, ptr %l78
  br label %bb34
bb34:
  %t136 = load ptr, ptr %l67, !tbaa !29
  %t137 = load i64, ptr %l72, !tbaa !24
  %t138 = load i64, ptr %l76, !tbaa !24
  %t139 = load %"compiler/source:Span", ptr %l78
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNever(ptr %v0, ptr %s6, ptr %t136, i64 %t137, { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d78, i32 0, i32 1) }, i64 %t138, %"compiler/source:Span" %t139)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb36:
  %t140 = load i64, ptr %l7, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l7, !tbaa !24
  br label %bb27
bb37:
  br label %bb65
bb38:
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t145 = load ptr, ptr %l81, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb39, label %bb40
bb39:
  %t148 = load ptr, ptr %l81, !tbaa !29
  %t149 = load i64, ptr %t148, !range !{i64 0, i64 18}
  %t151 = icmp eq i64 %t149, 6
  store i1 %t151, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t152 = load i1, ptr %l82, !tbaa !21
  br i1 %t152, label %bb41, label %bb42
bb41:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr { i64, [5 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t155, i32 0, i32 2
  %t157 = load ptr, ptr %t156
  store ptr %t157, ptr %l10, !tbaa !29
  br label %bb43
bb42:
  br label %bb60
bb43:
  %t159 = load ptr, ptr %l10, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Call", ptr %t159, i32 0, i32 0
  %t162 = load ptr, ptr %t161, !tbaa !29
  store ptr %t162, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t163 = load ptr, ptr %l88, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb44, label %bb45
bb44:
  %t166 = load ptr, ptr %l88, !tbaa !29
  %t167 = load i64, ptr %t166, !range !{i64 0, i64 5}
  %t169 = icmp eq i64 %t167, 1
  store i1 %t169, ptr %l89, !tbaa !21
  br label %bb45
bb45:
  %t170 = load i1, ptr %l89, !tbaa !21
  %t171 = xor i1 %t170, true
  br i1 %t171, label %bb46, label %bb47
bb46:
  br label %ret
bb47:
  br label %bb48
bb48:
  %t173 = load ptr, ptr %l10, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Call", ptr %t173, i32 0, i32 1
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  store { i64, ptr } %t176, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  store i64 %t180, ptr %l13, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t182 = load i64, ptr %l12, !tbaa !24
  %t183 = load i64, ptr %l13, !tbaa !24
  %t186 = icmp slt i64 %t182, %t183
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s11)
  br label %bb59
bb51:
  br label %bb52
bb52:
  %t190 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t190, ptr %l101, !tbaa !27
  %t191 = load i64, ptr %l12, !tbaa !24
  %t193 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr ptr, ptr %t194, i64 %t191
  %t196 = load ptr, ptr %t195, !tbaa !39
  store ptr %t196, ptr %l14, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/free:walker", ptr %t198, i32 0, i32 0
  %t201 = load ptr, ptr %t200, !tbaa !29
  store ptr %t201, ptr %l105, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/free:walker", ptr %t202, i32 0, i32 0
  %t205 = load ptr, ptr %t204, !tbaa !29
  store ptr %t205, ptr %l107, !tbaa !29
  %t206 = load ptr, ptr %l14, !tbaa !29
  %t208 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t206)
  store i32 %t208, ptr %l109
  br label %bb53
bb53:
  %t209 = load ptr, ptr %l107, !tbaa !29
  %t210 = load i32, ptr %l109, !tbaa !23
  %t211 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachTy(ptr %v0, ptr %t209, i32 %t210)
  store i64 %t211, ptr %l110
  br label %bb54
bb54:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t212)
  store ptr %t214, ptr %l112
  br label %bb55
bb55:
  %t215 = load ptr, ptr %l112, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Body", ptr %t215, i32 0, i32 3
  %t218 = load i64, ptr %t217, !tbaa !24
  store i64 %t218, ptr %l114, !tbaa !24
  %t219 = load ptr, ptr %l14, !tbaa !29
  %t221 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t219)
  store %"compiler/source:Span" %t221, ptr %l116
  br label %bb56
bb56:
  %t222 = load ptr, ptr %l105, !tbaa !29
  %t223 = load i64, ptr %l110, !tbaa !24
  %t224 = load i64, ptr %l114, !tbaa !24
  %t225 = load %"compiler/source:Span", ptr %l116
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNever(ptr %v0, ptr %s11, ptr %t222, i64 %t223, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d79, i32 0, i32 1) }, i64 %t224, %"compiler/source:Span" %t225)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb58
bb58:
  %t226 = load i64, ptr %l12, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l12, !tbaa !24
  br label %bb49
bb59:
  br label %bb65
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_3fe28685437e06db_e899c2573511637)
  unreachable
bb65:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorStoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l11 = alloca i64
  %l16 = alloca ptr
  %l22 = alloca %"compiler/free:orStore"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ederefRoot(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %t9, ptr %t10)
  store i64 %t13, ptr %l11
  br label %bb5
bb5:
  %t14 = load i64, ptr %l11, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/free:walker", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 89
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/free:walker", ptr %t25, i32 0, i32 1
  %t28 = load i64, ptr %t27, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t36 = call %"compiler/free:orStore" @compiler_2ffree_3aorStore_2ector(ptr %v2, ptr %v1, ptr %v0, i64 %t28, i64 %t29, ptr %a2, ptr %t31)
  store %"compiler/free:orStore" %t36, ptr %l22
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load %"compiler/free:orStore", ptr %l22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2ePush_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v0, ptr %t37, %"compiler/free:orStore" %t38)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l16 = alloca ptr
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i64
  %l22 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 104
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:walker", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t10, i64 %t14)
  store i1 %t17, ptr %l10
  br label %bb3
bb3:
  %t18 = load i1, ptr %l10, !tbaa !21
  %t19 = xor i1 %t18, true
  store i1 %t19, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l4, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 101
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t32, i64 %t33)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36, ptr %l20
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t37, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t38)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l22
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb10, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l21
  br label %bb9
bb9:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l13, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load i64, ptr %l13, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamPaths(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l57 = alloca i64
  %l61 = alloca i64
  %l65 = alloca i1
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i1
  %l100 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i1
  %l113 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l141 = alloca i1
  %l145 = alloca i64
  %l151 = alloca i64
  %l155 = alloca i1
  %l159 = alloca i1
  %l161 = alloca i1
  %l163 = alloca i1
  %l167 = alloca i1
  %l171 = alloca i1
  %l172 = alloca i1
  %l179 = alloca i1
  %l184 = alloca ptr
  %l186 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 53
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l29
  br label %bb1
bb1:
  %t11 = load i64, ptr %l29, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb7
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l36, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l36, !tbaa !24
  store i64 %t38, ptr %l33, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l33, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  br label %bb90
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/free:walker", ptr %t58, i32 0, i32 53
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l57
  br label %bb12
bb12:
  %t65 = load i64, ptr %l57, !tbaa !24
  store i64 %t65, ptr %l8, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 55
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l61
  br label %bb13
bb13:
  %t73 = load i64, ptr %l61, !tbaa !24
  store i64 %t73, ptr %l9, !tbaa !24
  store i1 false, ptr %l10, !tbaa !21
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:walker", ptr %t74, i32 0, i32 23
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t76, i64 %t77)
  store i1 %t80, ptr %l65
  br label %bb14
bb14:
  %t81 = load i1, ptr %l65, !tbaa !21
  store i1 %t81, ptr %l11, !tbaa !21
  store i64 0, ptr %l12, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 14
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l68
  br label %bb15
bb15:
  %t87 = load i64, ptr %l68, !tbaa !24
  store i64 %t87, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t88 = load i64, ptr %l13, !tbaa !24
  %t89 = load i64, ptr %l12, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb16, label %bb17
bb16:
  %t94 = load i64, ptr %l14, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb21
bb18:
  %t98 = load i64, ptr %l13, !tbaa !24
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l14, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l14, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l75, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb20
bb20:
  %t114 = load i64, ptr %l75, !tbaa !24
  store i64 %t114, ptr %l72, !tbaa !24
  br label %bb21
bb21:
  %t115 = load i64, ptr %l72, !tbaa !24
  store i64 %t115, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb22
bb22:
  %t116 = load i64, ptr %l16, !tbaa !24
  %t117 = load i64, ptr %l15, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb23, label %bb24
bb23:
  br label %bb38
bb24:
  br label %bb25
bb25:
  %t124 = load i64, ptr %l12, !tbaa !24
  %t125 = load i64, ptr %l16, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l17, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:walker", ptr %t134, i32 0, i32 14
  %t137 = load i64, ptr %l17, !tbaa !24
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l96
  br label %bb26
bb26:
  %t141 = load i64, ptr %l9, !tbaa !24
  %t142 = load i64, ptr %l96, !tbaa !24
  %t144 = icmp slt i64 %t142, %t141
  br i1 %t144, label %bb27, label %bb28
bb27:
  %t146 = load i64, ptr %l9, !tbaa !24
  store i64 %t146, ptr %l100, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/free:walker", ptr %t147, i32 0, i32 15
  %t150 = load i64, ptr %l17, !tbaa !24
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t149, i64 %t150)
  store i64 %t153, ptr %l104
  br label %bb29
bb28:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb30
bb29:
  %t154 = load i64, ptr %l100, !tbaa !24
  %t155 = load i64, ptr %l104, !tbaa !24
  %t156 = icmp sle i64 %t154, %t155
  store i1 %t156, ptr %l99, !tbaa !21
  br label %bb30
bb30:
  %t158 = load i1, ptr %l99, !tbaa !21
  br i1 %t158, label %bb31, label %bb32
bb31:
  %t159 = load i1, ptr %l11, !tbaa !21
  %t161 = xor i1 %t159, true
  store i1 %t161, ptr %l106, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb33
bb33:
  %t163 = load i1, ptr %l106, !tbaa !21
  br i1 %t163, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t164 = load i64, ptr %l16, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l16, !tbaa !24
  br label %bb22
bb38:
  store i64 0, ptr %l18, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/free:walker", ptr %t168, i32 0, i32 53
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t170)
  store i64 %t172, ptr %l113
  br label %bb39
bb39:
  %t173 = load i64, ptr %l113, !tbaa !24
  store i64 %t173, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t174 = load i64, ptr %l19, !tbaa !24
  %t175 = load i64, ptr %l18, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb40, label %bb41
bb40:
  %t180 = load i64, ptr %l20, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb45
bb42:
  %t184 = load i64, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l18, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l20, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l20, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l120, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb44
bb44:
  %t200 = load i64, ptr %l120, !tbaa !24
  store i64 %t200, ptr %l117, !tbaa !24
  br label %bb45
bb45:
  %t201 = load i64, ptr %l117, !tbaa !24
  store i64 %t201, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb46
bb46:
  %t202 = load i64, ptr %l22, !tbaa !24
  %t203 = load i64, ptr %l21, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb47, label %bb48
bb47:
  br label %bb80
bb48:
  br label %bb49
bb49:
  %t210 = load i64, ptr %l18, !tbaa !24
  %t211 = load i64, ptr %l22, !tbaa !24
  %t212 = load i64, ptr %l20, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l23, !tbaa !24
  %t220 = load i64, ptr %l23, !tbaa !24
  %t221 = load i64, ptr %l7, !tbaa !24
  %t224 = icmp eq i64 %t220, %t221
  br i1 %t224, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb53
bb51:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/free:walker", ptr %t226, i32 0, i32 53
  %t229 = load i64, ptr %l23, !tbaa !24
  %t232 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t228, i64 %t229)
  store i64 %t232, ptr %l145
  br label %bb52
bb52:
  %t233 = load i64, ptr %l8, !tbaa !24
  %t234 = load i64, ptr %l145, !tbaa !24
  %t236 = icmp ne i64 %t234, %t233
  store i1 %t236, ptr %l141, !tbaa !21
  br label %bb53
bb53:
  %t238 = load i1, ptr %l141, !tbaa !21
  br i1 %t238, label %bb54, label %bb55
bb54:
  br label %bb79
bb55:
  br label %bb56
bb56:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/free:walker", ptr %t239, i32 0, i32 55
  %t242 = load i64, ptr %l23, !tbaa !24
  %t245 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t241, i64 %t242)
  store i64 %t245, ptr %l151
  br label %bb57
bb57:
  %t246 = load i64, ptr %l151, !tbaa !24
  store i64 %t246, ptr %l24, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i64, ptr %l9, !tbaa !24
  %t249 = load i64, ptr %l24, !tbaa !24
  %t253 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexclusive(ptr %v0, ptr %t247, i64 %t248, i64 %t249)
  store i1 %t253, ptr %l155
  br label %bb58
bb58:
  %t254 = load i1, ptr %l155, !tbaa !21
  br i1 %t254, label %bb59, label %bb60
bb59:
  br label %bb79
bb60:
  br label %bb61
bb61:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i64, ptr %l9, !tbaa !24
  %t257 = load i64, ptr %l24, !tbaa !24
  %t261 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopAround(ptr %v0, ptr %t255, i64 %t256, i64 %t257)
  store i1 %t261, ptr %l159
  br label %bb62
bb62:
  %t262 = load i1, ptr %l159, !tbaa !21
  %t263 = xor i1 %t262, true
  br i1 %t263, label %bb63, label %bb64
bb63:
  %t265 = load i1, ptr %l11, !tbaa !21
  br i1 %t265, label %bb65, label %bb66
bb64:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb75
bb65:
  %t267 = load i64, ptr %l24, !tbaa !24
  %t268 = load i64, ptr %l9, !tbaa !24
  %t271 = icmp sgt i64 %t267, %t268
  store i1 %t271, ptr %l163, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb67
bb67:
  %t273 = load i1, ptr %l163, !tbaa !21
  br i1 %t273, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l167, !tbaa !21
  br label %bb74
bb69:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/free:walker", ptr %t274, i32 0, i32 23
  %t277 = load i64, ptr %l24, !tbaa !24
  %t280 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t276, i64 %t277)
  store i1 %t280, ptr %l171
  br label %bb70
bb70:
  %t281 = load i1, ptr %l171, !tbaa !21
  br i1 %t281, label %bb71, label %bb72
bb71:
  %t282 = load i64, ptr %l9, !tbaa !24
  %t283 = load i64, ptr %l24, !tbaa !24
  %t286 = icmp sgt i64 %t282, %t283
  store i1 %t286, ptr %l172, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb73
bb73:
  %t288 = load i1, ptr %l172, !tbaa !21
  store i1 %t288, ptr %l167, !tbaa !21
  br label %bb74
bb74:
  %t289 = load i1, ptr %l167, !tbaa !21
  store i1 %t289, ptr %l161, !tbaa !21
  br label %bb75
bb75:
  %t290 = load i1, ptr %l161, !tbaa !21
  br i1 %t290, label %bb76, label %bb77
bb76:
  br label %bb79
bb77:
  br label %bb78
bb78:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb79
bb79:
  %t291 = load i64, ptr %l22, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l22, !tbaa !24
  br label %bb46
bb80:
  %t295 = load i1, ptr %l10, !tbaa !21
  br i1 %t295, label %bb81, label %bb82
bb81:
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr %"compiler/free:Free", ptr %t297, i32 0, i32 66
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/free:walker", ptr %t300, i32 0, i32 1
  %t303 = load i64, ptr %t302, !tbaa !24
  %t306 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t299, i64 %t303)
  store ptr %t306, ptr %l184
  br label %bb83
bb82:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb85
bb83:
  %t307 = load i64, ptr %l8, !tbaa !24
  %t308 = load ptr, ptr %l184, !tbaa !29
  %t310 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t308, i64 %t307)
  store i64 %t310, ptr %l186
  br label %bb84
bb84:
  %t311 = load i64, ptr %l186, !tbaa !24
  %t312 = icmp sgt i64 %t311, 0
  store i1 %t312, ptr %l179, !tbaa !21
  br label %bb85
bb85:
  %t314 = load i1, ptr %l179, !tbaa !21
  br i1 %t314, label %bb86, label %bb87
bb86:
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t317 = getelementptr %"compiler/free:Free", ptr %t315, i32 0, i32 77
  store i1 true, ptr %t317, !tbaa !21
  br label %bb88
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t318 = load i64, ptr %l6, !tbaa !24
  %t320 = add i64 %t318, 1
  store i64 %t320, ptr %l6, !tbaa !24
  br label %bb8
bb90:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2epureValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t7)
  store i32 %t9, ptr %l11
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i32, ptr %l11, !tbaa !23
  %t12 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t12, ptr %l12
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = load i32, ptr %l12, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesPure(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l1, !tbaa !29
  store ptr %t18, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l16, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 18}
  %t25 = icmp eq i64 %t23, 17
  store i1 %t25, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l17, !tbaa !21
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t29, i32 0, i32 2
  %t31 = load ptr, ptr %t30
  store ptr %t31, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t37 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2epureValue(ptr %v0, ptr %v1, ptr %t33, ptr %t34)
  store i1 %t37, ptr %l24
  br label %bb13
bb13:
  %t38 = load i1, ptr %l24, !tbaa !21
  store i1 %t38, ptr %l15, !tbaa !21
  br label %bb32
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  store ptr %t39, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t40 = load ptr, ptr %l25, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 18}
  %t46 = icmp eq i64 %t44, 9
  store i1 %t46, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l26, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t50, i32 0, i32 2
  %t52 = load i32, ptr %t51, !range !{i32 0, i32 52}
  store i32 %t52, ptr %l4
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t56, i32 0, i32 4
  %t58 = load { i64, ptr }, ptr %t57
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  br label %bb19
bb18:
  br label %bb27
bb19:
  %t60 = load i32, ptr %l4, !range !{i32 0, i32 52}
  %t62 = trunc i64 20 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb20, label %bb21
bb20:
  %t65 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t69 = icmp eq i64 %t67, 1
  store i1 %t69, ptr %l35, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t71 = load i1, ptr %l35, !tbaa !21
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t73, ptr %l41, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr ptr, ptr %t75, i64 0
  %t77 = load ptr, ptr %t76, !tbaa !39
  %t80 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2epureValue(ptr %v0, ptr %v1, ptr %t72, ptr %t77)
  store i1 %t80, ptr %l43
  br label %bb25
bb24:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb26
bb25:
  %t81 = load i1, ptr %l43, !tbaa !21
  store i1 %t81, ptr %l39, !tbaa !21
  br label %bb26
bb26:
  %t82 = load i1, ptr %l39, !tbaa !21
  store i1 %t82, ptr %l15, !tbaa !21
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_5b2db086410f023b_92c7c7c81d16141f)
  unreachable
bb32:
  %t83 = load i1, ptr %l15, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %lp13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca ptr
  %lp16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %lp20 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i64
  %l47 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i32
  %l60 = alloca i64
  %l63 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca i64
  %l82 = alloca i64
  %l85 = alloca ptr
  %l86 = alloca i64
  %l91 = alloca %"compiler/free:feed"
  %l93 = alloca i64
  %l94 = alloca i64
  %l96 = alloca ptr
  %l97 = alloca i1
  %l104 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca ptr
  %l106 = alloca i1
  %l115 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l116 = alloca ptr
  %l118 = alloca i32
  %l120 = alloca i64
  %l123 = alloca ptr
  %l126 = alloca i64
  %l127 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca i1
  %l138 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l147 = alloca i32
  %l148 = alloca i32
  %l149 = alloca i64
  %l152 = alloca ptr
  %l155 = alloca i64
  %l156 = alloca i64
  %l158 = alloca ptr
  %l159 = alloca i1
  %l167 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l168 = alloca ptr
  %l169 = alloca i1
  %l176 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l177 = alloca ptr
  %l178 = alloca i1
  %l181 = alloca i64
  %l183 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l187 = alloca i64
  %l189 = alloca ptr
  %l192 = alloca i64
  %l194 = alloca ptr
  %l196 = alloca ptr
  %l199 = alloca i64
  %l201 = alloca ptr
  %l202 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l204 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l206 = alloca ptr
  %l210 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s9 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t7 = load ptr, ptr %l23, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l23, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l24, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb37
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l4, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t31 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euse(ptr %v0, ptr %t27, i64 %t30, %"compiler/source:Span" %t31)
  br label %bb6
bb6:
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l35
  br label %bb7
bb7:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t36, ptr %lp5
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  %t38 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %t38
  %t39 = load ptr, ptr %lp5
  store ptr %t39, ptr %l36, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t40, i32 0, i32 3
  %t43 = load i32, ptr %l4, !tbaa !23
  %t45 = sext i32 %t43 to i64
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t42, i64 %t45)
  store ptr %t48, ptr %l41
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l36, !tbaa !29
  %t50 = load ptr, ptr %l41, !tbaa !29
  %t51 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %v0, ptr %t49, ptr %t50)
  store i64 %t51, ptr %l42
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 4
  %t55 = load i32, ptr %l4, !tbaa !23
  %t57 = sext i32 %t55 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t54, i64 %t57, i1 true)
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:walker", ptr %t60, i32 0, i32 7
  %t63 = load i32, ptr %l4, !tbaa !23
  %t65 = sext i32 %t63 to i64
  %t68 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t62, i64 %t65)
  %t69 = extractvalue { i32, i64 } %t68, 1
  %t70 = extractvalue { i32, i64 } %t68, 0
  store i32 %t70, ptr %l53
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb12, label %ok.72, !prof !99
ok.72:
  store i64 %t69, ptr %l52
  br label %bb11
bb11:
  %t73 = load i64, ptr %l52, !tbaa !24
  store i64 %t73, ptr %l47, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l47, !tbaa !24
  br label %bb14
bb14:
  %t74 = load i64, ptr %l47, !tbaa !24
  store i64 %t74, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp sge i64 %t75, 0
  br i1 %t77, label %bb15, label %bb16
bb15:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:walker", ptr %t80, i32 0, i32 8
  %t83 = load i32, ptr %t82, !tbaa !23
  %t84 = load i64, ptr %l6, !tbaa !24
  %t88 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t79, i32 %t83, i64 %t84)
  store i64 %t88, ptr %l60
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t89 = load i64, ptr %l60, !tbaa !24
  store i64 %t89, ptr %l7, !tbaa !24
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp sge i64 %t90, 0
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t94 = load ptr, ptr %lp5
  store ptr %t94, ptr %l63, !tbaa !29
  %t95 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = call i64 @compiler_2ffree_2eorig(i64 %t95, i64 %t96)
  store i64 %t99, ptr %l66
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t100 = load ptr, ptr %l63, !tbaa !29
  %t101 = load i64, ptr %l66, !tbaa !24
  %t102 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t100, i64 %t101)
  store i64 %t102, ptr %l67
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i32, ptr %l4, !tbaa !23
  %t106 = sext i32 %t104 to i64
  %t109 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %t103, i64 %t106)
  store i64 %t109, ptr %l71
  br label %bb24
bb24:
  %t110 = load i64, ptr %l71, !tbaa !24
  store i64 %t110, ptr %l8, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = icmp sge i64 %t111, 0
  br i1 %t113, label %bb25, label %bb26
bb25:
  %t115 = load ptr, ptr %lp5
  store ptr %t115, ptr %l74, !tbaa !29
  %t116 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t117 = load i64, ptr %l8, !tbaa !24
  %t120 = call i64 @compiler_2ffree_2eorig(i64 %t116, i64 %t117)
  store i64 %t120, ptr %l77
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t121 = load ptr, ptr %l74, !tbaa !29
  %t122 = load i64, ptr %l77, !tbaa !24
  %t123 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t121, i64 %t122)
  store i64 %t123, ptr %l78
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i32, ptr %l4, !tbaa !23
  %t127 = sext i32 %t125 to i64
  %t130 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeeder(ptr %v0, ptr %t124, i64 %t127)
  store i64 %t130, ptr %l82
  br label %bb30
bb30:
  %t131 = load i64, ptr %l82, !tbaa !24
  store i64 %t131, ptr %l9, !tbaa !24
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = icmp sge i64 %t132, 0
  br i1 %t134, label %bb31, label %bb32
bb31:
  %t136 = load ptr, ptr %lp5
  store ptr %t136, ptr %l85, !tbaa !29
  %t137 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  store i64 %t137, ptr %l86, !tbaa !24
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/free:walker", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/free:Free", ptr %t141, i32 0, i32 110
  %t144 = load i64, ptr %l9, !tbaa !24
  %t147 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t143, i64 %t144)
  store %"compiler/free:feed" %t147, ptr %l91
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t148 = getelementptr %"compiler/free:feed", ptr %l91, i32 0, i32 2
  %t149 = load i64, ptr %t148, !tbaa !24
  %t150 = load i64, ptr %l86, !tbaa !24
  %t152 = call i64 @compiler_2ffree_2eorig(i64 %t150, i64 %t149)
  store i64 %t152, ptr %l93
  br label %bb34
bb34:
  %t153 = load ptr, ptr %l85, !tbaa !29
  %t154 = load i64, ptr %l93, !tbaa !24
  %t155 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t153, i64 %t154)
  store i64 %t155, ptr %l94
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t156 = load ptr, ptr %lp5
  %t157 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t156
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %rv
  br label %ret
bb37:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t160 = load ptr, ptr %l96, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb38, label %bb39
bb38:
  %t163 = load ptr, ptr %l96, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 8}
  %t166 = icmp eq i64 %t164, 2
  store i1 %t166, ptr %l97, !tbaa !21
  br label %bb39
bb39:
  %t167 = load i1, ptr %l97, !tbaa !21
  br i1 %t167, label %bb40, label %bb41
bb40:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [4 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t170, i32 0, i32 2
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l10, !tbaa !29
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l10, !tbaa !29
  %t178 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t174, ptr %t175)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t178, ptr %l104
  br label %bb43
bb43:
  %t179 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l104
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t179, ptr %rv
  br label %ret
bb44:
  %t180 = load ptr, ptr %l1, !tbaa !29
  store ptr %t180, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t181 = load ptr, ptr %l105, !tbaa !29
  %t182 = icmp ne ptr %t181, null
  br i1 %t182, label %bb45, label %bb46
bb45:
  %t184 = load ptr, ptr %l105, !tbaa !29
  %t185 = load i64, ptr %t184, !range !{i64 0, i64 8}
  %t187 = icmp eq i64 %t185, 3
  store i1 %t187, ptr %l106, !tbaa !21
  br label %bb46
bb46:
  %t188 = load i1, ptr %l106, !tbaa !21
  br i1 %t188, label %bb47, label %bb48
bb47:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr { i64, [4 x i64] }, ptr %t189, i32 0, i32 1
  %t192 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t191, i32 0, i32 2
  %t193 = load ptr, ptr %t192
  store ptr %t193, ptr %l11, !tbaa !29
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t197, i32 0, i32 3
  %t199 = load i64, ptr %t198
  store i64 %t199, ptr %l12, !tbaa !24
  br label %bb49
bb48:
  br label %bb58
bb49:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load ptr, ptr %l11, !tbaa !29
  %t205 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t201, ptr %t202)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l115
  br label %bb50
bb50:
  %t206 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t206, ptr %lp13
  %t207 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l115
  %t208 = load ptr, ptr %lp13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t207, ptr %t208
  %t209 = load ptr, ptr %l2, !tbaa !29
  store ptr %t209, ptr %l116, !tbaa !29
  %t210 = load ptr, ptr %l11, !tbaa !29
  %t212 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t210)
  store i32 %t212, ptr %l118
  br label %bb51
bb51:
  %t213 = load i64, ptr %l12, !tbaa !24
  %t214 = load ptr, ptr %l116, !tbaa !29
  %t215 = load i32, ptr %l118, !tbaa !23
  %t217 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t214, i32 %t215, i64 %t213)
  store i64 %t217, ptr %l120
  br label %bb52
bb52:
  %t218 = load i64, ptr %l120, !tbaa !24
  store i64 %t218, ptr %l14, !tbaa !24
  %t219 = load i64, ptr %l14, !tbaa !24
  %t221 = icmp sge i64 %t219, 0
  br i1 %t221, label %bb53, label %bb54
bb53:
  %t223 = load ptr, ptr %lp13
  store ptr %t223, ptr %l123, !tbaa !29
  %t224 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t225 = load i64, ptr %l14, !tbaa !24
  %t228 = call i64 @compiler_2ffree_2eorig(i64 %t224, i64 %t225)
  store i64 %t228, ptr %l126
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t229 = load ptr, ptr %l123, !tbaa !29
  %t230 = load i64, ptr %l126, !tbaa !24
  %t231 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t229, i64 %t230)
  store i64 %t231, ptr %l127
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t232 = load ptr, ptr %lp13
  %t233 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t232
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t233, ptr %rv
  br label %ret
bb58:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t236 = load ptr, ptr %l129, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb59, label %bb60
bb59:
  %t239 = load ptr, ptr %l129, !tbaa !29
  %t240 = load i64, ptr %t239, !range !{i64 0, i64 8}
  %t242 = icmp eq i64 %t240, 4
  store i1 %t242, ptr %l130, !tbaa !21
  br label %bb60
bb60:
  %t243 = load i1, ptr %l130, !tbaa !21
  br i1 %t243, label %bb61, label %bb62
bb61:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [4 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t246, i32 0, i32 2
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l15, !tbaa !29
  br label %bb63
bb62:
  br label %bb74
bb63:
  store %olang.scope zeroinitializer, ptr %s9
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l15, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Elem", ptr %t251, i32 0, i32 0
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t257 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t250, ptr %t254)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t257, ptr %l138
  br label %bb64
bb64:
  %t258 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t258, ptr %lp16
  %t259 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l138
  %t260 = load ptr, ptr %lp16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t259, ptr %t260
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l15, !tbaa !29
  %t264 = getelementptr %"compiler/typed:Elem", ptr %t262, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t268 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %t261, ptr %t265)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t268, ptr %l142
  br label %bb65
bb65:
  %t269 = load ptr, ptr %l2, !tbaa !29
  store ptr %t269, ptr %l143, !tbaa !29
  %t270 = load ptr, ptr %l2, !tbaa !29
  store ptr %t270, ptr %l144, !tbaa !29
  %t271 = load ptr, ptr %l15, !tbaa !29
  %t273 = getelementptr %"compiler/typed:Elem", ptr %t271, i32 0, i32 0
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t274)
  store i32 %t276, ptr %l147
  br label %bb66
bb66:
  %t277 = load ptr, ptr %l144, !tbaa !29
  %t278 = load i32, ptr %l147, !tbaa !23
  %t279 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t277, i32 %t278)
  store i32 %t279, ptr %l148
  br label %bb67
bb67:
  %t280 = load ptr, ptr %l143, !tbaa !29
  %t281 = load i32, ptr %l148, !tbaa !23
  %t282 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t280, i32 %t281, i64 -1)
  store i64 %t282, ptr %l149
  br label %bb68
bb68:
  %t283 = load i64, ptr %l149, !tbaa !24
  store i64 %t283, ptr %l17, !tbaa !24
  %t284 = load i64, ptr %l17, !tbaa !24
  %t286 = icmp sge i64 %t284, 0
  br i1 %t286, label %bb69, label %bb70
bb69:
  %t288 = load ptr, ptr %lp16
  store ptr %t288, ptr %l152, !tbaa !29
  %t289 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t290 = load i64, ptr %l17, !tbaa !24
  %t293 = call i64 @compiler_2ffree_2eorig(i64 %t289, i64 %t290)
  store i64 %t293, ptr %l155
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t294 = load ptr, ptr %l152, !tbaa !29
  %t295 = load i64, ptr %l155, !tbaa !24
  %t296 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t294, i64 %t295)
  store i64 %t296, ptr %l156
  br label %bb72
bb72:
  br label %bb73
bb73:
  %t297 = load ptr, ptr %lp16
  %t298 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t297
  call void @__olang_scope_close(ptr %s9)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t298, ptr %rv
  br label %ret
bb74:
  %t300 = load ptr, ptr %l1, !tbaa !29
  store ptr %t300, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t301 = load ptr, ptr %l158, !tbaa !29
  %t302 = icmp ne ptr %t301, null
  br i1 %t302, label %bb75, label %bb76
bb75:
  %t304 = load ptr, ptr %l158, !tbaa !29
  %t305 = load i64, ptr %t304, !range !{i64 0, i64 8}
  %t307 = icmp eq i64 %t305, 5
  store i1 %t307, ptr %l159, !tbaa !21
  br label %bb76
bb76:
  %t308 = load i1, ptr %l159, !tbaa !21
  br i1 %t308, label %bb77, label %bb78
bb77:
  %t309 = load ptr, ptr %l1, !tbaa !29
  %t311 = getelementptr { i64, [4 x i64] }, ptr %t309, i32 0, i32 1
  %t312 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t311, i32 0, i32 2
  %t313 = load ptr, ptr %t312
  store ptr %t313, ptr %l18, !tbaa !29
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load ptr, ptr %l18, !tbaa !29
  %t318 = getelementptr %"compiler/typed:Payload", ptr %t316, i32 0, i32 0
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t322 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t315, ptr %t319)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t322, ptr %l167
  br label %bb80
bb80:
  %t323 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l167
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t323, ptr %rv
  br label %ret
bb81:
  %t324 = load ptr, ptr %l1, !tbaa !29
  store ptr %t324, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t325 = load ptr, ptr %l168, !tbaa !29
  %t326 = icmp ne ptr %t325, null
  br i1 %t326, label %bb82, label %bb83
bb82:
  %t328 = load ptr, ptr %l168, !tbaa !29
  %t329 = load i64, ptr %t328, !range !{i64 0, i64 8}
  %t331 = icmp eq i64 %t329, 6
  store i1 %t331, ptr %l169, !tbaa !21
  br label %bb83
bb83:
  %t332 = load i1, ptr %l169, !tbaa !21
  br i1 %t332, label %bb84, label %bb85
bb84:
  %t333 = load ptr, ptr %l1, !tbaa !29
  %t335 = getelementptr { i64, [4 x i64] }, ptr %t333, i32 0, i32 1
  %t336 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t335, i32 0, i32 2
  %t337 = load ptr, ptr %t336
  store ptr %t337, ptr %l19, !tbaa !29
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load ptr, ptr %l19, !tbaa !29
  %t343 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t339, ptr %t340)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t343, ptr %l176
  br label %bb87
bb87:
  %t344 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l176
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t344, ptr %rv
  br label %ret
bb88:
  %t345 = load ptr, ptr %l1, !tbaa !29
  store ptr %t345, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t346 = load ptr, ptr %l177, !tbaa !29
  %t347 = icmp ne ptr %t346, null
  br i1 %t347, label %bb89, label %bb90
bb89:
  %t349 = load ptr, ptr %l177, !tbaa !29
  %t350 = load i64, ptr %t349, !range !{i64 0, i64 8}
  %t352 = icmp eq i64 %t350, 7
  store i1 %t352, ptr %l178, !tbaa !21
  br label %bb90
bb90:
  %t353 = load i1, ptr %l178, !tbaa !21
  br i1 %t353, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb112
bb93:
  %t354 = ptrtoint ptr %v2 to i64
  store i64 %t354, ptr %l181, !tbaa !24
  %t355 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ereach_2elocal_2e20
  br i1 %t355, label %bb94, label %bb95
bb94:
  %t357 = call ptr @__olang_region_make(ptr %v2)
  %t358 = ptrtoint ptr %t357 to i64
  store i64 %t358, ptr %l181, !tbaa !24
  br label %bb95
bb95:
  %t359 = load i64, ptr %l181
  %t360 = inttoptr i64 %t359 to ptr
  %t361 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t360, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t361, ptr %l183
  br label %bb96
bb96:
  %t362 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ereach_2elocal_2e20
  br i1 %t362, label %bb97, label %bb98
bb97:
  %t364 = load i64, ptr %l181
  %t365 = inttoptr i64 %t364 to ptr
  %t366 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l183, i32 0, i32 0
  %t367 = load { i64, ptr }, ptr %t366
  %t368 = extractvalue { i64, ptr } %t367, 1
  %t369 = call ptr @__olang_region_or(ptr %t368, ptr null)
  %t370 = icmp ne ptr %t369, null
  %t371 = select i1 %t370, ptr %t369, ptr null
  %t372 = icmp eq ptr %t371, %t365
  call void @__olang_region_settle(ptr %t365, i1 %t372)
  br label %bb98
bb98:
  %t373 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t373, ptr %lp20
  %t374 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l183
  %t375 = load ptr, ptr %lp20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t374, ptr %t375
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/free:walker", ptr %t376, i32 0, i32 9
  %t380 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t378)
  store i64 %t380, ptr %l187
  br label %bb99
bb99:
  %t381 = load i64, ptr %l187, !tbaa !24
  %t382 = icmp sgt i64 %t381, 0
  br i1 %t382, label %bb100, label %bb101
bb100:
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l189, !tbaa !29
  %t385 = load ptr, ptr %l189, !tbaa !29
  %t386 = getelementptr %"compiler/free:walker", ptr %t385, i32 0, i32 30
  %t387 = load i64, ptr %t386, !tbaa !24
  %t389 = add i64 %t387, 1
  %t391 = load ptr, ptr %l189, !tbaa !29
  %t392 = getelementptr %"compiler/free:walker", ptr %t391, i32 0, i32 30
  store i64 %t389, ptr %t392, !tbaa !24
  %t393 = ptrtoint ptr %v2 to i64
  store i64 %t393, ptr %l192, !tbaa !24
  %t394 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ereach_2elocal_2e20
  br i1 %t394, label %bb102, label %bb103
bb101:
  br label %bb111
bb102:
  %t396 = call ptr @__olang_region_make(ptr %v2)
  %t397 = ptrtoint ptr %t396 to i64
  store i64 %t397, ptr %l192, !tbaa !24
  br label %bb103
bb103:
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l194, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = getelementptr %"compiler/free:walker", ptr %t399, i32 0, i32 9
  store ptr %t401, ptr %l196, !tbaa !29
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/free:walker", ptr %t402, i32 0, i32 9
  %t406 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t404)
  store i64 %t406, ptr %l199
  br label %bb104
bb104:
  %t407 = load i64, ptr %l199, !tbaa !24
  %t408 = sub i64 %t407, 1
  %t409 = load ptr, ptr %l196, !tbaa !29
  %t411 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v0, ptr %t409, i64 %t408)
  store ptr %t411, ptr %l201
  br label %bb105
bb105:
  %t412 = load i64, ptr %l192
  %t413 = inttoptr i64 %t412 to ptr
  %t414 = load ptr, ptr %l194, !tbaa !29
  %t415 = load ptr, ptr %l201, !tbaa !29
  %t416 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v0, ptr %t413, ptr %t414, ptr %t415)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t416, ptr %l202
  br label %bb106
bb106:
  %t417 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ereach_2elocal_2e20
  br i1 %t417, label %bb107, label %bb108
bb107:
  %t419 = load i64, ptr %l192
  %t420 = inttoptr i64 %t419 to ptr
  %t421 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l202, i32 0, i32 0
  %t422 = load { i64, ptr }, ptr %t421
  %t423 = extractvalue { i64, ptr } %t422, 1
  %t424 = call ptr @__olang_region_or(ptr %t423, ptr null)
  %t425 = icmp ne ptr %t424, null
  %t426 = select i1 %t425, ptr %t424, ptr null
  %t427 = icmp eq ptr %t426, %t420
  call void @__olang_region_settle(ptr %t420, i1 %t427)
  br label %bb108
bb108:
  %t428 = load ptr, ptr %lp20
  %t429 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t428
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t429, ptr %l204
  %t430 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l202
  %t431 = load ptr, ptr %lp20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t430, ptr %t431
  %t432 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ereach_2elocal_2e20
  br i1 %t432, label %bb109, label %bb110
bb109:
  %t434 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l204, i32 0, i32 0
  %t435 = load { i64, ptr }, ptr %t434
  %t436 = extractvalue { i64, ptr } %t435, 1
  %t437 = call ptr @__olang_region_or(ptr %t436, ptr null)
  %t438 = icmp ne ptr %t437, null
  %t439 = select i1 %t438, ptr %t437, ptr null
  call void @__olang_region_drop(ptr %t439)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l204
  br label %bb110
bb110:
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l206, !tbaa !29
  %t441 = load ptr, ptr %l206, !tbaa !29
  %t442 = getelementptr %"compiler/free:walker", ptr %t441, i32 0, i32 30
  %t443 = load i64, ptr %t442, !tbaa !24
  %t445 = sub i64 %t443, 1
  %t447 = load ptr, ptr %l206, !tbaa !29
  %t448 = getelementptr %"compiler/free:walker", ptr %t447, i32 0, i32 30
  store i64 %t445, ptr %t448, !tbaa !24
  br label %bb111
bb111:
  %t449 = load ptr, ptr %lp20
  %t450 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t449
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t450, ptr %rv
  br label %ret
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb117
bb115:
  %t452 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t452, ptr %l210
  br label %bb116
bb116:
  %t453 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l210
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t453, ptr %rv
  br label %ret
bb117:
  call void @__olang_check_failed(ptr @olang_loc_bfa96af29dec6ca7_6eacd8161d4b79f3)
  unreachable
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 4
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l16, !tbaa !24
  store i64 %t33, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l13, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t55, i64 %t51, i1 false)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb8
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t63, i32 0, i32 11
  store i64 0, ptr %t65, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 12
  store i64 0, ptr %t68, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:walker", ptr %t69, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t71)
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t75)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:walker", ptr %t77, i32 0, i32 23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t79)
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:walker", ptr %t81, i32 0, i32 15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t83)
  br label %bb18
bb18:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t87)
  br label %bb19
bb19:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/free:walker", ptr %t89, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t91)
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/free:walker", ptr %t93, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t95)
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/free:walker", ptr %t97, i32 0, i32 19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t99)
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/free:walker", ptr %t101, i32 0, i32 25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t103)
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:walker", ptr %t105, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t107)
  br label %bb24
bb24:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/free:walker", ptr %t109, i32 0, i32 27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t111)
  br label %bb25
bb25:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/free:walker", ptr %t113, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t115)
  br label %bb26
bb26:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:walker", ptr %t117, i32 0, i32 44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t119)
  br label %bb27
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/free:walker", ptr %t121, i32 0, i32 45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t123)
  br label %bb28
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:walker", ptr %t125, i32 0, i32 46
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t127)
  br label %bb29
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/free:walker", ptr %t129, i32 0, i32 47
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t131)
  br label %bb30
bb30:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/free:walker", ptr %t133, i32 0, i32 48
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t135)
  br label %bb31
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/free:walker", ptr %t137, i32 0, i32 49
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t139)
  br label %bb32
bb32:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/free:walker", ptr %t141, i32 0, i32 50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t143)
  br label %bb33
bb33:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/free:walker", ptr %t145, i32 0, i32 51
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t147)
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/free:walker", ptr %t149, i32 0, i32 52
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t151)
  br label %bb35
bb35:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/free:walker", ptr %t153, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t155)
  br label %bb36
bb36:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/free:walker", ptr %t157, i32 0, i32 39
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hcb8ba31809995dcae45f5acc6cf39f88(ptr %v0, ptr %t159)
  br label %bb37
bb37:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/free:walker", ptr %t161, i32 0, i32 53
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t163)
  br label %bb38
bb38:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/free:walker", ptr %t165, i32 0, i32 54
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t167)
  br label %bb39
bb39:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:walker", ptr %t169, i32 0, i32 55
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t171)
  br label %bb40
bb40:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/free:walker", ptr %t173, i32 0, i32 65
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t175)
  br label %bb41
bb41:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/free:walker", ptr %t177, i32 0, i32 66
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t179)
  br label %bb42
bb42:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/free:walker", ptr %t181, i32 0, i32 56
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t183)
  br label %bb43
bb43:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/free:walker", ptr %t185, i32 0, i32 57
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t187)
  br label %bb44
bb44:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/free:walker", ptr %t189, i32 0, i32 58
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t191)
  br label %bb45
bb45:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/free:walker", ptr %t193, i32 0, i32 59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t195)
  br label %bb46
bb46:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/free:walker", ptr %t197, i32 0, i32 60
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t199)
  br label %bb47
bb47:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/free:walker", ptr %t201, i32 0, i32 61
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t203)
  br label %bb48
bb48:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/free:walker", ptr %t205, i32 0, i32 62
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t207)
  br label %bb49
bb49:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/free:walker", ptr %t209, i32 0, i32 63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t211)
  br label %bb50
bb50:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/free:walker", ptr %t213, i32 0, i32 64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Hca84839cdf395382408370342cfafe64(ptr %v0, ptr %t215)
  br label %bb51
bb51:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l37 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i1
  %l63 = alloca i1
  %l68 = alloca i64
  %l77 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l11, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t11)
  store i32 %t13, ptr %l14
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t16, ptr %l15
  br label %bb3
bb3:
  %t17 = load i1, ptr %l15, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb8
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  store ptr %t20, ptr %l18, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l20
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l18, !tbaa !29
  %t25 = load i32, ptr %l20, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t26, ptr %l21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l21, !tbaa !21
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t30 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t33 = load ptr, ptr %l24, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l24, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 18}
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb46
bb16:
  %t47 = load ptr, ptr %l5, !tbaa !29
  store ptr %t47, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t48 = load ptr, ptr %l30, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 8}
  %t54 = icmp eq i64 %t52, 0
  store i1 %t54, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t55 = load i1, ptr %l31, !tbaa !21
  br i1 %t55, label %bb19, label %bb20
bb19:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t58, i32 0, i32 2
  %t60 = load i32, ptr %t59
  store i32 %t60, ptr %l6, !tbaa !23
  br label %bb21
bb20:
  br label %bb29
bb21:
  %t62 = load i32, ptr %l6, !tbaa !23
  %t64 = sext i32 %t62 to i64
  store i64 %t64, ptr %l37, !tbaa !24
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 94
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/free:walker", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %t70, !tbaa !24
  %t74 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t67, i64 %t71)
  store ptr %t74, ptr %l42
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t75)
  store i64 %t76, ptr %l43
  br label %bb23
bb23:
  %t77 = load i64, ptr %l37, !tbaa !24
  %t78 = load i64, ptr %l43, !tbaa !24
  %t79 = icmp slt i64 %t77, %t78
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr %"compiler/free:Free", ptr %t81, i32 0, i32 94
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:walker", ptr %t84, i32 0, i32 1
  %t87 = load i64, ptr %t86, !tbaa !24
  %t90 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t83, i64 %t87)
  store ptr %t90, ptr %l50
  br label %bb26
bb25:
  %t91 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t91, ptr %l45, !tbaa !24
  br label %bb28
bb26:
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = load i32, ptr %l6, !tbaa !23
  %t96 = sext i32 %t94 to i64
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t93, i64 %t96)
  store i64 %t99, ptr %l54
  br label %bb27
bb27:
  %t100 = load i64, ptr %l54, !tbaa !24
  store i64 %t100, ptr %l45, !tbaa !24
  br label %bb28
bb28:
  %t101 = load i64, ptr %l45, !tbaa !24
  store i64 %t101, ptr %l4, !tbaa !24
  br label %bb45
bb29:
  %t102 = load ptr, ptr %l5, !tbaa !29
  store ptr %t102, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t103 = load ptr, ptr %l56, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l56, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 8}
  %t109 = icmp eq i64 %t107, 3
  store i1 %t109, ptr %l57, !tbaa !21
  br label %bb31
bb31:
  %t110 = load i1, ptr %l57, !tbaa !21
  br i1 %t110, label %bb32, label %bb33
bb32:
  %t111 = load ptr, ptr %l5, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l7, !tbaa !29
  br label %bb34
bb33:
  br label %bb40
bb34:
  %t117 = load ptr, ptr %l7, !tbaa !29
  %t119 = call i1 @compiler_2ffree_2epureBase(ptr %v1, ptr %t117)
  store i1 %t119, ptr %l63
  br label %bb35
bb35:
  %t120 = load i1, ptr %l63, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb36, label %bb37
bb36:
  store i64 -1, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t128 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  store i64 %t128, ptr %l68
  br label %bb39
bb39:
  %t129 = load i64, ptr %l68, !tbaa !24
  store i64 %t129, ptr %l4, !tbaa !24
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i64 -1, ptr %rv
  br label %ret
bb44:
  call void @__olang_check_failed(ptr @olang_loc_34bfc259355dec67_8a2d14d061fee643)
  unreachable
bb45:
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i64 -1, ptr %rv
  br label %ret
bb50:
  call void @__olang_check_failed(ptr @olang_loc_806a74b5c91de186_4e306eb4964e9ec2)
  unreachable
bb51:
  %t132 = load i64, ptr %l4, !tbaa !24
  %t134 = icmp slt i64 %t132, 0
  br i1 %t134, label %bb52, label %bb53
bb52:
  store i64 -1, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t137 = load i64, ptr %l4, !tbaa !24
  %t138 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t141 = icmp sge i64 %t137, %t138
  br i1 %t141, label %bb55, label %bb56
bb55:
  %t143 = load i64, ptr %l4, !tbaa !24
  %t144 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t147 = sub i64 %t143, %t144
  store i64 %t147, ptr %l77, !tbaa !24
  br label %bb57
bb56:
  %t149 = load i64, ptr %l4, !tbaa !24
  store i64 %t149, ptr %l77, !tbaa !24
  br label %bb57
bb57:
  %t151 = load i64, ptr %l77, !tbaa !24
  store i64 %t151, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esameValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ederefRoot(ptr %v2, ptr %v2, ptr %a2)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t14 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v1, ptr %v2, ptr %a1, ptr %t11)
  store i1 %t14, ptr %l11
  br label %bb5
bb5:
  %t15 = load i1, ptr %l11, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 8
  %t8 = load i32, ptr %t7, !tbaa !23
  %t13 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t4, i32 %t8, i64 %a1)
  store i64 %t13, ptr %l14
  br label %bb1
bb1:
  %t14 = load i64, ptr %l14, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sge i64 %t15, 0
  br i1 %t17, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %s1, ptr %t19, i64 %t20, ptr %a2, ptr %t22, %"compiler/source:Span" %a4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) }, i1 false)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 2
  %t32 = load i1, ptr %t31, !tbaa !21
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l3, !tbaa !29
  store ptr %t36, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb7:
  br label %bb25
bb8:
  %t38 = load i64, ptr %l7, !tbaa !24
  store i64 %t38, ptr %l26, !tbaa !24
  %t39 = load ptr, ptr %l6, !tbaa !29
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t39)
  store i64 %t41, ptr %l28
  br label %bb9
bb9:
  %t42 = load i64, ptr %l26, !tbaa !24
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = icmp slt i64 %t42, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb10, label %bb11
bb10:
  br label %bb24
bb11:
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t48, i64 %t49)
  store i64 %t52, ptr %l33
  br label %bb13
bb13:
  %t53 = load i64, ptr %l33, !tbaa !24
  store i64 %t53, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = call i64 @compiler_2ffree_2eokind(i64 %t54)
  store i64 %t56, ptr %l35
  br label %bb14
bb14:
  %t57 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t58 = load i64, ptr %l35, !tbaa !24
  %t60 = icmp ne i64 %t58, %t57
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/free:walker", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 62
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/free:walker", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %t70, !tbaa !24
  %t74 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t67, i64 %t71)
  store ptr %t74, ptr %l44
  br label %bb17
bb16:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb19
bb17:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t78 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t76, i64 %t75)
  store i64 %t78, ptr %l46
  br label %bb18
bb18:
  %t79 = load i64, ptr %l46, !tbaa !24
  %t80 = icmp sgt i64 %t79, 0
  store i1 %t80, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t82 = load i1, ptr %l38, !tbaa !21
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:walker", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/free:Free", ptr %t86, i32 0, i32 77
  store i1 true, ptr %t88, !tbaa !21
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t89 = load i64, ptr %l7, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l7, !tbaa !24
  br label %bb8
bb24:
  br label %bb25
bb25:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t2, i32 0, i32 30
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 30
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s0, ptr %t10, ptr %t11)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l11
  br label %bb1
bb1:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l5
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 30
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = sub i64 %t19, 1
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 30
  store i64 %t21, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t25, i64 %a1, ptr %t27, ptr %l5, %"compiler/source:Span" %a3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) }, i1 %a4, i1 false)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t5)
  store ptr %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t16 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %t13, i64 %t11, %"compiler/source:Span" %a1)
  store { i64, ptr } %t16, ptr %l9
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca i64
  %l32 = alloca i64
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l47 = alloca i32
  %l49 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i64
  %l57 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca i64
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 30
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l10, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %s2, ptr %t19, i32 %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l17
  br label %bb7
bb7:
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s2, ptr %l17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l19
  br label %bb8
bb8:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t27 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t27
  store ptr %t27, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load i64, ptr %l5, !tbaa !24
  store i64 %t29, ptr %l21, !tbaa !24
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t30)
  store i64 %t32, ptr %l23
  br label %bb10
bb10:
  %t33 = load i64, ptr %l21, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t35 = icmp slt i64 %t33, %t34
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb12:
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l4, !tbaa !29
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l28
  br label %bb14
bb14:
  %t44 = load i64, ptr %l28, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/free:walker", ptr %t45, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/free:Free", ptr %t48, i32 0, i32 116
  %t51 = load i1, ptr %t50, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t53 = load i64, ptr %l6, !tbaa !24
  store i64 %t53, ptr %l32, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/free:walker", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/free:Free", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/load:Loader", ptr %t63, i32 0, i32 4
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l37, !tbaa !29
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t67)
  store ptr %t69, ptr %l39
  br label %bb17
bb16:
  br label %bb25
bb17:
  %t70 = load ptr, ptr %l39, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 3
  %t73 = load i64, ptr %t72, !tbaa !24
  %t74 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t75 = load i32, ptr %t74, !tbaa !23
  %t77 = sext i32 %t75 to i64
  %t78 = load ptr, ptr %l37, !tbaa !29
  %t81 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s4, ptr %t78, i64 %t73, i64 %t77)
  store { i64, ptr } %t81, ptr %l44
  br label %bb18
bb18:
  %t82 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t84 = load i64, ptr %l32, !tbaa !24
  %t85 = call i64 @__olang_fmt_i64(ptr null, i64 %t84)
  %t86 = add i64 %t83, %t85
  %t87 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t90 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = add i64 %t89, %t92
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t82, i64 %t83)
  %t98 = getelementptr i8, ptr %t97, i64 %t83
  %t99 = call i64 @__olang_fmt_i64(ptr %t98, i64 %t84)
  %t100 = getelementptr i8, ptr %t98, i64 %t85
  call void @olang_textcopy(ptr %t100, ptr %t87, i64 %t88)
  %t101 = getelementptr i8, ptr %t100, i64 %t88
  call void @olang_textcopy(ptr %t101, ptr %t91, i64 %t92)
  %t102 = getelementptr i8, ptr %t101, i64 %t92
  call void @olang_textcopy(ptr %t102, ptr %t94, i64 %t95)
  %t103 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t97, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t113 = call i32 @std_2fio_2ePutErr(ptr %s4, { i64, ptr } %t111)
  store i32 %t113, ptr %l47
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb20, label %ok.115, !prof !99
ok.115:
  br label %bb19
bb19:
  br label %bb24
bb20:
  %t116 = load i32, ptr %l47, !tbaa !23
  %t117 = ashr i32 %t116, 16
  %t119 = icmp eq i32 %t117, 1
  store i1 %t119, ptr %l49, !tbaa !21
  %t120 = load i32, ptr %l47, !tbaa !23
  %t121 = ashr i32 %t120, 16
  %t123 = icmp eq i32 %t121, 1
  br i1 %t123, label %bb21, label %bb22
bb21:
  call void @__olang_errpay_pop()
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:walker", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  store ptr %t128, ptr %l53, !tbaa !29
  %t129 = load i64, ptr %l6, !tbaa !24
  store i64 %t129, ptr %l54, !tbaa !24
  %t130 = load i64, ptr @G_2ecompiler_2ffree_2eRCopied, !tbaa !24
  store i64 %t130, ptr %l55, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t131)
  store ptr %t133, ptr %l57
  br label %bb26
bb26:
  %t134 = load ptr, ptr %l57, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Body", ptr %t134, i32 0, i32 3
  %t137 = load i64, ptr %t136, !tbaa !24
  store i64 %t137, ptr %l59, !tbaa !24
  %t138 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t138, ptr %l60
  %t139 = ptrtoint ptr %v0 to i64
  store i64 %t139, ptr %l61, !tbaa !24
  %t140 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t140, label %bb27, label %bb28
bb27:
  %t142 = call ptr @__olang_region_make(ptr %v0)
  %t143 = ptrtoint ptr %t142 to i64
  store i64 %t143, ptr %l61, !tbaa !24
  br label %bb28
bb28:
  store { i64, ptr } %a3, ptr %l63, !tbaa !27
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l2
  %t149 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s3, ptr %t145, %"compiler/source:Span" %t146)
  store { i64, ptr } %t149, ptr %l66
  br label %bb29
bb29:
  %t150 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t151 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t152 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = add i64 %t151, %t154
  %t156 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t158 = add i64 %t155, %t157
  %t159 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t166 = load i64, ptr %l61
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = call ptr @__olang_scope_alloc(ptr %t167, i64 %t165)
  call void @olang_textcopy(ptr %t168, ptr %t150, i64 %t151)
  %t169 = getelementptr i8, ptr %t168, i64 %t151
  call void @olang_textcopy(ptr %t169, ptr %t153, i64 %t154)
  %t170 = getelementptr i8, ptr %t169, i64 %t154
  call void @olang_textcopy(ptr %t170, ptr %t156, i64 %t157)
  %t171 = getelementptr i8, ptr %t170, i64 %t157
  call void @olang_textcopy(ptr %t171, ptr %t160, i64 %t161)
  %t172 = getelementptr i8, ptr %t171, i64 %t161
  call void @olang_textcopy(ptr %t172, ptr %t163, i64 %t164)
  %t173 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t168, 1
  %t176 = load i64, ptr %l61
  %t177 = inttoptr i64 %t176 to ptr
  %t178 = extractvalue { i64, ptr } %t174, 0
  %t179 = extractvalue { i64, ptr } %t174, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %t177, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t184 = load ptr, ptr %l53, !tbaa !29
  %t185 = load i64, ptr %l54, !tbaa !24
  %t186 = load i64, ptr %l55, !tbaa !24
  %t187 = load i64, ptr %l59, !tbaa !24
  %t188 = load %"compiler/source:Span", ptr %l60
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t184, i64 %t185, i64 %t186, i64 %t187, %"compiler/source:Span" %t188, { i64, ptr } %t183)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb31:
  %t190 = load i64, ptr %l5, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l5, !tbaa !24
  br label %bb9
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euse(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 30
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 25
  %t11 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t10, i64 %t11)
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 26
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 12
  %t20 = load i64, ptr %t19, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t16, i64 %t20)
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t25, %"compiler/source:Span" %a2)
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 29
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:walker", ptr %t36, i32 0, i32 28
  %t39 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t38, i64 %t39)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewCtor(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/free:leaf"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l23 = alloca i1
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l32 = alloca i64
  %l37 = alloca %"compiler/free:leaf"
  %l39 = alloca %"compiler/free:leaf"
  %l42 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l59 = alloca i64
  %l61 = alloca i1
  %l63 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i32
  %l74 = alloca i64
  %l76 = alloca i64
  %l81 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca i64
  %l86 = alloca i64
  %l88 = alloca ptr
  %l95 = alloca %"compiler/free:store"
  %l96 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca i64
  %l100 = alloca ptr
  %l102 = alloca i64
  %l103 = alloca %"compiler/source:Span"
  %l104 = alloca i64
  %l106 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca { i64, ptr }
  %l115 = alloca i64
  %l118 = alloca i64
  %l120 = alloca i1
  %l124 = alloca i1
  %l125 = alloca ptr
  %l127 = alloca i64
  %l130 = alloca i64
  %l132 = alloca i32
  %l133 = alloca ptr
  %l135 = alloca i64
  %l136 = alloca i1
  %l138 = alloca i64
  %l140 = alloca i64
  %l145 = alloca i64
  %l147 = alloca ptr
  %l148 = alloca i64
  %l150 = alloca i64
  %l152 = alloca ptr
  %l154 = alloca i64
  %l155 = alloca %"compiler/source:Span"
  %l157 = alloca i64
  %l161 = alloca i64
  %l167 = alloca %"compiler/free:store"
  %l170 = alloca ptr
  %l171 = alloca i64
  %l172 = alloca i64
  %l174 = alloca ptr
  %l176 = alloca i64
  %l177 = alloca %"compiler/source:Span"
  %l178 = alloca i64
  %l180 = alloca ptr
  %l182 = alloca %"compiler/source:Span"
  %l183 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 2
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:walker", ptr %t13, i32 0, i32 30
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  store i1 %t18, ptr %l23, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l23, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l27
  br label %bb7
bb7:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l6
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l28
  br label %bb8
bb8:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l7
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load i64, ptr %l9, !tbaa !24
  store i64 %t27, ptr %l30, !tbaa !24
  %t28 = load ptr, ptr %l8, !tbaa !29
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t28)
  store i64 %t30, ptr %l32
  br label %bb10
bb10:
  %t31 = load i64, ptr %l30, !tbaa !24
  %t32 = load i64, ptr %l32, !tbaa !24
  %t33 = icmp slt i64 %t31, %t32
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb12:
  br label %bb13
bb13:
  %t37 = load ptr, ptr %l8, !tbaa !29
  %t38 = load i64, ptr %l9, !tbaa !24
  %t41 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t37, i64 %t38)
  store %"compiler/free:leaf" %t41, ptr %l37
  br label %bb14
bb14:
  %t43 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s3, ptr %l37)
  store %"compiler/free:leaf" %t43, ptr %l39
  br label %bb15
bb15:
  %t44 = load %"compiler/free:leaf", ptr %l39
  store %"compiler/free:leaf" %t44, ptr %l10
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t46 = getelementptr %"compiler/free:leaf", ptr %l10, i32 0, i32 1
  %t47 = load i64, ptr %t46, !tbaa !24
  %t50 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %t45, i64 %t47)
  store i1 %t50, ptr %l42
  br label %bb16
bb16:
  %t51 = load i1, ptr %l42, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = getelementptr %"compiler/free:leaf", ptr %l10, i32 0, i32 1
  %t53 = load i64, ptr %t52, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t53)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = getelementptr %"compiler/free:Free", ptr %t56, i32 0, i32 13
  %t59 = getelementptr %"compiler/free:leaf", ptr %l10, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !24
  %t63 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t58, i64 %t60)
  store i1 %t63, ptr %l48
  br label %bb21
bb21:
  %t64 = load i1, ptr %l48, !tbaa !21
  br i1 %t64, label %bb22, label %bb23
bb22:
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"compiler/free:leaf", ptr %l10, i32 0, i32 1
  %t67 = load i64, ptr %t66, !tbaa !24
  %t70 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %t65, i64 %t67)
  store i1 %t70, ptr %l52
  br label %bb24
bb23:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb25
bb24:
  %t71 = load i1, ptr %l52, !tbaa !21
  %t72 = xor i1 %t71, true
  store i1 %t72, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t74 = load i1, ptr %l49, !tbaa !21
  br i1 %t74, label %bb26, label %bb27
bb26:
  %t75 = getelementptr %"compiler/free:leaf", ptr %l10, i32 0, i32 1
  %t76 = load i64, ptr %t75, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l7, i64 %t76)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l9, !tbaa !24
  br label %bb9
bb31:
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t84, ptr %l59
  br label %bb32
bb32:
  %t85 = load i64, ptr %l59, !tbaa !24
  %t86 = icmp eq i64 %t85, 0
  br i1 %t86, label %bb33, label %bb34
bb33:
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t89, ptr %l63
  br label %bb35
bb34:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb36
bb35:
  %t90 = load i64, ptr %l63, !tbaa !24
  %t91 = icmp eq i64 %t90, 1
  store i1 %t91, ptr %l61, !tbaa !21
  br label %bb36
bb36:
  %t93 = load i1, ptr %l61, !tbaa !21
  br i1 %t93, label %bb37, label %bb38
bb37:
  store ptr %l6, ptr %l65, !tbaa !29
  %t95 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %s0, ptr %l7)
  %t96 = extractvalue { i32, i64 } %t95, 1
  %t97 = extractvalue { i32, i64 } %t95, 0
  store i32 %t97, ptr %l69
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb40, label %ok.99, !prof !99
ok.99:
  store i64 %t96, ptr %l68
  br label %bb39
bb38:
  br label %bb49
bb39:
  %t100 = load i64, ptr %l68, !tbaa !24
  store i64 %t100, ptr %l66, !tbaa !24
  br label %bb47
bb40:
  %t101 = load i32, ptr %l69, !tbaa !23
  %t102 = icmp eq i32 %t101, 65536
  br i1 %t102, label %bb41, label %bb42
bb41:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b3a24969a5664c78_6a2ceec1abacdcc4)
  unreachable
bb42:
  %t104 = load i32, ptr %l69, !tbaa !23
  %t105 = icmp eq i32 %t104, 65537
  br i1 %t105, label %bb43, label %bb44
bb43:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1adc22647748ff1d_11d3fcef2a51f919)
  unreachable
bb44:
  %t107 = load i32, ptr %l69, !tbaa !23
  %t108 = icmp eq i32 %t107, 65538
  br i1 %t108, label %bb45, label %bb46
bb45:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6035cb012844bf8d_c31ea78c8ebfe279)
  unreachable
bb46:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6b9356bc715f0c33_1387949cfe4e721f)
  unreachable
bb47:
  %t110 = load ptr, ptr %l65, !tbaa !29
  %t111 = load i64, ptr %l66, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t110, i64 %t111)
  br label %bb48
bb48:
  br label %bb49
bb49:
  store ptr %l7, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t113 = load i64, ptr %l12, !tbaa !24
  store i64 %t113, ptr %l74, !tbaa !24
  %t114 = load ptr, ptr %l11, !tbaa !29
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t114)
  store i64 %t116, ptr %l76
  br label %bb51
bb51:
  %t117 = load i64, ptr %l74, !tbaa !24
  %t118 = load i64, ptr %l76, !tbaa !24
  %t119 = icmp slt i64 %t117, %t118
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb53:
  br label %bb54
bb54:
  %t123 = load ptr, ptr %l11, !tbaa !29
  %t124 = load i64, ptr %l12, !tbaa !24
  %t127 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t123, i64 %t124)
  store i64 %t127, ptr %l81
  br label %bb55
bb55:
  %t128 = load i64, ptr %l81, !tbaa !24
  store i64 %t128, ptr %l13, !tbaa !24
  %t129 = load ptr, ptr %l5, !tbaa !29
  %t131 = getelementptr %"compiler/free:Free", ptr %t129, i32 0, i32 83
  store ptr %t131, ptr %l83, !tbaa !29
  %t132 = load i64, ptr %l13, !tbaa !24
  store i64 %t132, ptr %l84, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/free:walker", ptr %t133, i32 0, i32 1
  %t136 = load i64, ptr %t135, !tbaa !24
  store i64 %t136, ptr %l86, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t137)
  store ptr %t139, ptr %l88
  br label %bb56
bb56:
  %t140 = load ptr, ptr %l88, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Body", ptr %t140, i32 0, i32 3
  %t143 = load i64, ptr %t142, !tbaa !24
  %t144 = load %"compiler/source:Span", ptr %l4
  %t145 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t146 = load ptr, ptr %l3, !tbaa !29
  %t148 = load i64, ptr %l84, !tbaa !24
  %t149 = load i64, ptr %l86, !tbaa !24
  %t154 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v3, ptr %v0, ptr %v0, i64 %t148, i64 %t149, i64 %t143, %"compiler/source:Span" %t144, i64 %t145, i64 -1, i64 -1, ptr %t146, ptr null)
  store %"compiler/free:store" %t154, ptr %l95
  br label %bb57
bb57:
  %t155 = load ptr, ptr %l83, !tbaa !29
  %t156 = load %"compiler/free:store", ptr %l95
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t155, %"compiler/free:store" %t156)
  br label %bb58
bb58:
  %t157 = load ptr, ptr %l5, !tbaa !29
  store ptr %t157, ptr %l96, !tbaa !29
  %t158 = load i64, ptr %l13, !tbaa !24
  store i64 %t158, ptr %l97, !tbaa !24
  %t159 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t159, ptr %l98, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t160)
  store ptr %t162, ptr %l100
  br label %bb59
bb59:
  %t163 = load ptr, ptr %l100, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Body", ptr %t163, i32 0, i32 3
  %t166 = load i64, ptr %t165, !tbaa !24
  store i64 %t166, ptr %l102, !tbaa !24
  %t167 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t167, ptr %l103
  %t168 = ptrtoint ptr %v0 to i64
  store i64 %t168, ptr %l104, !tbaa !24
  %t169 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t169, label %bb60, label %bb61
bb60:
  %t171 = call ptr @__olang_region_make(ptr %v0)
  %t172 = ptrtoint ptr %t171 to i64
  store i64 %t172, ptr %l104, !tbaa !24
  br label %bb61
bb61:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l106, !tbaa !29
  %t174 = load ptr, ptr %l3, !tbaa !29
  %t176 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v3, ptr %t174)
  store %"compiler/source:Span" %t176, ptr %l108
  br label %bb62
bb62:
  %t177 = load ptr, ptr %l106, !tbaa !29
  %t178 = load %"compiler/source:Span", ptr %l108
  %t179 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s9, ptr %t177, %"compiler/source:Span" %t178)
  store { i64, ptr } %t179, ptr %l109
  br label %bb63
bb63:
  %t180 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t182 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 1
  %t184 = extractvalue { i64, ptr } %t182, 0
  %t185 = add i64 %t181, %t184
  %t186 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t187 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t188 = add i64 %t185, %t187
  %t189 = load i64, ptr %l104
  %t190 = inttoptr i64 %t189 to ptr
  %t191 = call ptr @__olang_scope_alloc(ptr %t190, i64 %t188)
  call void @olang_textcopy(ptr %t191, ptr %t180, i64 %t181)
  %t192 = getelementptr i8, ptr %t191, i64 %t181
  call void @olang_textcopy(ptr %t192, ptr %t183, i64 %t184)
  %t193 = getelementptr i8, ptr %t192, i64 %t184
  call void @olang_textcopy(ptr %t193, ptr %t186, i64 %t187)
  %t194 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t191, 1
  %t197 = load i64, ptr %l104
  %t198 = inttoptr i64 %t197 to ptr
  %t199 = extractvalue { i64, ptr } %t195, 0
  %t200 = extractvalue { i64, ptr } %t195, 1
  %t201 = mul i64 %t199, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %t198, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  %t205 = load ptr, ptr %l96, !tbaa !29
  %t206 = load i64, ptr %l97, !tbaa !24
  %t207 = load i64, ptr %l98, !tbaa !24
  %t208 = load i64, ptr %l102, !tbaa !24
  %t209 = load %"compiler/source:Span", ptr %l103
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t205, i64 %t206, i64 %t207, i64 %t208, %"compiler/source:Span" %t209, { i64, ptr } %t204)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s9)
  br label %bb65
bb65:
  %t211 = load i64, ptr %l12, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l12, !tbaa !24
  br label %bb50
bb66:
  %t216 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t216, ptr %l115
  br label %bb67
bb67:
  %t217 = load i64, ptr %l115, !tbaa !24
  %t218 = icmp eq i64 %t217, 0
  br i1 %t218, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb69:
  br label %bb70
bb70:
  %t221 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t221, ptr %l118
  br label %bb71
bb71:
  %t222 = load i64, ptr %l118, !tbaa !24
  %t223 = icmp eq i64 %t222, 1
  br i1 %t223, label %bb72, label %bb73
bb72:
  %t225 = load ptr, ptr %l2, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Call", ptr %t225, i32 0, i32 2
  %t228 = load i32, ptr %t227, !tbaa !23
  %t230 = icmp sge i32 %t228, 0
  store i1 %t230, ptr %l120, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb74
bb74:
  %t232 = load i1, ptr %l120, !tbaa !21
  br i1 %t232, label %bb75, label %bb76
bb75:
  %t233 = load ptr, ptr %l5, !tbaa !29
  store ptr %t233, ptr %l125, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/free:walker", ptr %t234, i32 0, i32 1
  %t237 = load i64, ptr %t236, !tbaa !24
  store i64 %t237, ptr %l127, !tbaa !24
  %t238 = load ptr, ptr %l2, !tbaa !29
  %t240 = getelementptr %"compiler/typed:Call", ptr %t238, i32 0, i32 2
  %t241 = load i32, ptr %t240, !tbaa !23
  %t243 = sext i32 %t241 to i64
  store i64 %t243, ptr %l130, !tbaa !24
  %t244 = load ptr, ptr %l3, !tbaa !29
  %t246 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v3, ptr %t244)
  store i32 %t246, ptr %l132
  br label %bb77
bb76:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb80
bb77:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l133, !tbaa !29
  %t249 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 0)
  store i64 %t249, ptr %l135
  br label %bb78
bb78:
  %t250 = load ptr, ptr %l125, !tbaa !29
  %t251 = load i64, ptr %l127, !tbaa !24
  %t252 = load i64, ptr %l130, !tbaa !24
  %t253 = load i32, ptr %l132, !tbaa !23
  %t254 = load ptr, ptr %l133, !tbaa !29
  %t255 = load i64, ptr %l135, !tbaa !24
  %t256 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitLeaf(ptr %v0, ptr %v1, ptr %t250, i64 %t251, i64 %t252, i32 %t253, ptr %t254, i64 %t255)
  store i1 %t256, ptr %l136
  br label %bb79
bb79:
  %t257 = load i1, ptr %l136, !tbaa !21
  store i1 %t257, ptr %l124, !tbaa !21
  br label %bb80
bb80:
  %t258 = load i1, ptr %l124, !tbaa !21
  store i1 %t258, ptr %l14, !tbaa !21
  store ptr %l6, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb81
bb81:
  %t260 = load i64, ptr %l16, !tbaa !24
  store i64 %t260, ptr %l138, !tbaa !24
  %t261 = load ptr, ptr %l15, !tbaa !29
  %t263 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t261)
  store i64 %t263, ptr %l140
  br label %bb82
bb82:
  %t264 = load i64, ptr %l138, !tbaa !24
  %t265 = load i64, ptr %l140, !tbaa !24
  %t266 = icmp slt i64 %t264, %t265
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb83, label %bb84
bb83:
  br label %bb106
bb84:
  br label %bb85
bb85:
  %t270 = load ptr, ptr %l15, !tbaa !29
  %t271 = load i64, ptr %l16, !tbaa !24
  %t274 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t270, i64 %t271)
  store i64 %t274, ptr %l145
  br label %bb86
bb86:
  %t275 = load i64, ptr %l145, !tbaa !24
  store i64 %t275, ptr %l17, !tbaa !24
  %t276 = load ptr, ptr %l5, !tbaa !29
  %t278 = getelementptr %"compiler/free:Free", ptr %t276, i32 0, i32 83
  store ptr %t278, ptr %l147, !tbaa !29
  %t279 = load i64, ptr %l17, !tbaa !24
  store i64 %t279, ptr %l148, !tbaa !24
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/free:walker", ptr %t280, i32 0, i32 1
  %t283 = load i64, ptr %t282, !tbaa !24
  store i64 %t283, ptr %l150, !tbaa !24
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t284)
  store ptr %t286, ptr %l152
  br label %bb87
bb87:
  %t287 = load ptr, ptr %l152, !tbaa !29
  %t289 = getelementptr %"compiler/typed:Body", ptr %t287, i32 0, i32 3
  %t290 = load i64, ptr %t289, !tbaa !24
  store i64 %t290, ptr %l154, !tbaa !24
  %t291 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t291, ptr %l155
  %t292 = load i1, ptr %l14, !tbaa !21
  br i1 %t292, label %bb88, label %bb89
bb88:
  %t294 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  store i64 %t294, ptr %l157, !tbaa !24
  br label %bb90
bb89:
  %t296 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t296, ptr %l157, !tbaa !24
  br label %bb90
bb90:
  %t298 = load i1, ptr %l14, !tbaa !21
  br i1 %t298, label %bb91, label %bb92
bb91:
  %t300 = load ptr, ptr %l2, !tbaa !29
  %t302 = getelementptr %"compiler/typed:Call", ptr %t300, i32 0, i32 2
  %t303 = load i32, ptr %t302, !tbaa !23
  %t305 = sext i32 %t303 to i64
  store i64 %t305, ptr %l161, !tbaa !24
  br label %bb93
bb92:
  store i64 -1, ptr %l161, !tbaa !24
  br label %bb93
bb93:
  %t307 = load ptr, ptr %l3, !tbaa !29
  %t309 = load i64, ptr %l148, !tbaa !24
  %t310 = load i64, ptr %l150, !tbaa !24
  %t311 = load i64, ptr %l154, !tbaa !24
  %t312 = load %"compiler/source:Span", ptr %l155
  %t313 = load i64, ptr %l157, !tbaa !24
  %t314 = load i64, ptr %l161, !tbaa !24
  %t316 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v3, ptr %v0, ptr %v0, i64 %t309, i64 %t310, i64 %t311, %"compiler/source:Span" %t312, i64 %t313, i64 -1, i64 %t314, ptr %t307, ptr null)
  store %"compiler/free:store" %t316, ptr %l167
  br label %bb94
bb94:
  %t317 = load ptr, ptr %l147, !tbaa !29
  %t318 = load %"compiler/free:store", ptr %l167
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t317, %"compiler/free:store" %t318)
  br label %bb95
bb95:
  %t319 = load i1, ptr %l14, !tbaa !21
  %t321 = xor i1 %t319, true
  br i1 %t321, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s15
  %t323 = load ptr, ptr %l5, !tbaa !29
  store ptr %t323, ptr %l170, !tbaa !29
  %t324 = load i64, ptr %l17, !tbaa !24
  store i64 %t324, ptr %l171, !tbaa !24
  %t325 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t325, ptr %l172, !tbaa !24
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t326)
  store ptr %t328, ptr %l174
  br label %bb98
bb97:
  br label %bb104
bb98:
  %t329 = load ptr, ptr %l174, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Body", ptr %t329, i32 0, i32 3
  %t332 = load i64, ptr %t331, !tbaa !24
  store i64 %t332, ptr %l176, !tbaa !24
  %t333 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t333, ptr %l177
  %t334 = ptrtoint ptr %v0 to i64
  store i64 %t334, ptr %l178, !tbaa !24
  %t335 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t335, label %bb99, label %bb100
bb99:
  %t337 = call ptr @__olang_region_make(ptr %v0)
  %t338 = ptrtoint ptr %t337 to i64
  store i64 %t338, ptr %l178, !tbaa !24
  br label %bb100
bb100:
  %t339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t339, ptr %l180, !tbaa !29
  %t340 = load ptr, ptr %l3, !tbaa !29
  %t342 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v3, ptr %t340)
  store %"compiler/source:Span" %t342, ptr %l182
  br label %bb101
bb101:
  %t343 = load ptr, ptr %l180, !tbaa !29
  %t344 = load %"compiler/source:Span", ptr %l182
  %t345 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s15, ptr %t343, %"compiler/source:Span" %t344)
  store { i64, ptr } %t345, ptr %l183
  br label %bb102
bb102:
  %t346 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t347 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t348 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 1
  %t350 = extractvalue { i64, ptr } %t348, 0
  %t351 = add i64 %t347, %t350
  %t352 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t353 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t354 = add i64 %t351, %t353
  %t355 = load i64, ptr %l178
  %t356 = inttoptr i64 %t355 to ptr
  %t357 = call ptr @__olang_scope_alloc(ptr %t356, i64 %t354)
  call void @olang_textcopy(ptr %t357, ptr %t346, i64 %t347)
  %t358 = getelementptr i8, ptr %t357, i64 %t347
  call void @olang_textcopy(ptr %t358, ptr %t349, i64 %t350)
  %t359 = getelementptr i8, ptr %t358, i64 %t350
  call void @olang_textcopy(ptr %t359, ptr %t352, i64 %t353)
  %t360 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t357, 1
  %t363 = load i64, ptr %l178
  %t364 = inttoptr i64 %t363 to ptr
  %t365 = extractvalue { i64, ptr } %t361, 0
  %t366 = extractvalue { i64, ptr } %t361, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %t364, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  %t371 = load ptr, ptr %l170, !tbaa !29
  %t372 = load i64, ptr %l171, !tbaa !24
  %t373 = load i64, ptr %l172, !tbaa !24
  %t374 = load i64, ptr %l176, !tbaa !24
  %t375 = load %"compiler/source:Span", ptr %l177
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t371, i64 %t372, i64 %t373, i64 %t374, %"compiler/source:Span" %t375, { i64, ptr } %t370)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s15)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t377 = load i64, ptr %l16, !tbaa !24
  %t379 = add i64 %t377, 1
  store i64 %t379, ptr %l16, !tbaa !24
  br label %bb81
bb106:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewsAcross(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l38 = alloca i1
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l69 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l97 = alloca i64
  %l100 = alloca i1
  %l104 = alloca %"compiler/source:Span"
  %l106 = alloca i1
  %l107 = alloca i1
  %l108 = alloca %"compiler/source:Span"
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i64
  %l124 = alloca ptr
  %l125 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l128 = alloca ptr
  %l132 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  store ptr %a4, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %l20, !tbaa !24
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l22
  br label %bb2
bb2:
  %t12 = load i64, ptr %l20, !tbaa !24
  %t13 = load i64, ptr %l22, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l7, !tbaa !29
  %t19 = load i64, ptr %l8, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l27
  br label %bb6
bb6:
  %t23 = load i64, ptr %l27, !tbaa !24
  store i64 %t23, ptr %l9, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l28, !tbaa !29
  %t25 = load i64, ptr %l9, !tbaa !24
  store i64 %t25, ptr %l29, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %l30, !tbaa !24
  %t27 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t27, ptr %l31
  %t29 = load i64, ptr %l9, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v2, ptr %v2, ptr %a5, i64 %t29)
  store ptr %t32, ptr %l34
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l28, !tbaa !29
  %t34 = load i64, ptr %l29, !tbaa !24
  %t35 = load i64, ptr %l30, !tbaa !24
  %t36 = load %"compiler/source:Span", ptr %l31
  %t37 = load ptr, ptr %l34, !tbaa !29
  %t38 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einUseAcross(ptr %v0, ptr %v2, ptr %t33, i64 %t34, i64 %t35, %"compiler/source:Span" %t36, ptr %t37)
  store i64 %t38, ptr %l35
  br label %bb8
bb8:
  %t39 = load i64, ptr %l35, !tbaa !24
  store i64 %t39, ptr %l10, !tbaa !24
  %t40 = load i64, ptr %l10, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb13
bb10:
  %t44 = load ptr, ptr %l6, !tbaa !29
  store ptr %t44, ptr %l39, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/free:walker", ptr %t45, i32 0, i32 3
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t47, i64 %t48)
  store ptr %t51, ptr %l43
  br label %bb11
bb11:
  %t52 = load ptr, ptr %l39, !tbaa !29
  %t53 = load ptr, ptr %l43, !tbaa !29
  %t54 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayView(ptr %v0, ptr %v0, ptr %t52, ptr %t53)
  store i1 %t54, ptr %l44
  br label %bb12
bb12:
  %t55 = load i1, ptr %l44, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l38, !tbaa !21
  br label %bb13
bb13:
  %t58 = load i1, ptr %l38, !tbaa !21
  br i1 %t58, label %bb14, label %bb15
bb14:
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t59 = load ptr, ptr %l6, !tbaa !29
  %t61 = getelementptr %"compiler/free:Free", ptr %t59, i32 0, i32 53
  %t62 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t61, i64 %t62)
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l6, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 54
  store ptr %t67, ptr %l50, !tbaa !29
  %t68 = ptrtoint ptr %v0 to i64
  store i64 %t68, ptr %l51, !tbaa !24
  %t69 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t69, label %bb18, label %bb19
bb18:
  %t71 = call ptr @__olang_region_make(ptr %v0)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l51, !tbaa !24
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 3
  %t76 = load i64, ptr %l9, !tbaa !24
  %t79 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t75, i64 %t76)
  store ptr %t79, ptr %l56
  br label %bb20
bb20:
  %t80 = load i64, ptr %l51
  %t81 = inttoptr i64 %t80 to ptr
  %t82 = load i64, ptr %l51
  %t83 = inttoptr i64 %t82 to ptr
  %t84 = load ptr, ptr %l56, !tbaa !29
  %t85 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecopyOf(ptr %t81, ptr %t83, ptr %t84)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %l57
  br label %bb21
bb21:
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  %t87 = load i64, ptr %l51
  %t88 = inttoptr i64 %t87 to ptr
  %t89 = call ptr @__olang_scope_alloc_a(ptr %t88, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %t89
  %t90 = load ptr, ptr %l50, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t90, ptr %t89)
  br label %bb22
bb22:
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = getelementptr %"compiler/free:Free", ptr %t92, i32 0, i32 55
  store ptr %t94, ptr %l60, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/free:walker", ptr %t95, i32 0, i32 27
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t97, i64 %t98)
  store %"compiler/source:Span" %t101, ptr %l64
  br label %bb23
bb23:
  %t102 = load ptr, ptr %l60, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t102, %"compiler/source:Span" %t103)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l8, !tbaa !24
  br label %bb1
bb26:
  store i64 0, ptr %l11, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:walker", ptr %t108, i32 0, i32 62
  %t112 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t110)
  store i64 %t112, ptr %l69
  br label %bb27
bb27:
  %t113 = load i64, ptr %l69, !tbaa !24
  store i64 %t113, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t114 = load i64, ptr %l12, !tbaa !24
  %t115 = load i64, ptr %l11, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb28, label %bb29
bb28:
  %t120 = load i64, ptr %l13, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb33
bb30:
  %t124 = load i64, ptr %l12, !tbaa !24
  %t125 = load i64, ptr %l11, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l13, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l76, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb32
bb32:
  %t140 = load i64, ptr %l76, !tbaa !24
  store i64 %t140, ptr %l73, !tbaa !24
  br label %bb33
bb33:
  %t141 = load i64, ptr %l73, !tbaa !24
  store i64 %t141, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb34
bb34:
  %t142 = load i64, ptr %l15, !tbaa !24
  %t143 = load i64, ptr %l14, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb35, label %bb36
bb35:
  br label %bb61
bb36:
  br label %bb37
bb37:
  %t150 = load i64, ptr %l11, !tbaa !24
  %t151 = load i64, ptr %l15, !tbaa !24
  %t152 = load i64, ptr %l13, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l16, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/free:walker", ptr %t160, i32 0, i32 62
  %t163 = load i64, ptr %l16, !tbaa !24
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t162, i64 %t163)
  store i64 %t166, ptr %l97
  br label %bb38
bb38:
  %t167 = load i64, ptr %l2, !tbaa !24
  %t168 = load i64, ptr %l97, !tbaa !24
  %t170 = icmp ne i64 %t168, %t167
  br i1 %t170, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb43
bb40:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/free:walker", ptr %t172, i32 0, i32 63
  %t175 = load i64, ptr %l16, !tbaa !24
  %t178 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t174, i64 %t175)
  store %"compiler/source:Span" %t178, ptr %l104
  br label %bb41
bb41:
  %t179 = load %"compiler/source:Span", ptr %l3
  %t180 = load %"compiler/source:Span", ptr %l104
  %t182 = call i1 @compiler_2ffree_2espanIn(%"compiler/source:Span" %t180, %"compiler/source:Span" %t179)
  store i1 %t182, ptr %l106
  br label %bb42
bb42:
  %t183 = load i1, ptr %l106, !tbaa !21
  store i1 %t183, ptr %l100, !tbaa !21
  br label %bb43
bb43:
  %t184 = load i1, ptr %l100, !tbaa !21
  br i1 %t184, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l107, !tbaa !21
  br label %bb48
bb45:
  %t185 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t185, ptr %l108
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/free:walker", ptr %t186, i32 0, i32 63
  %t189 = load i64, ptr %l16, !tbaa !24
  %t192 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t188, i64 %t189)
  store %"compiler/source:Span" %t192, ptr %l112
  br label %bb46
bb46:
  %t193 = load %"compiler/source:Span", ptr %l108
  %t194 = load %"compiler/source:Span", ptr %l112
  %t195 = call i1 @compiler_2ffree_2espanIn(%"compiler/source:Span" %t193, %"compiler/source:Span" %t194)
  store i1 %t195, ptr %l113
  br label %bb47
bb47:
  %t196 = load i1, ptr %l113, !tbaa !21
  store i1 %t196, ptr %l107, !tbaa !21
  br label %bb48
bb48:
  %t197 = load i1, ptr %l107, !tbaa !21
  br i1 %t197, label %bb49, label %bb50
bb49:
  br label %bb60
bb50:
  br label %bb51
bb51:
  %t198 = load ptr, ptr %l6, !tbaa !29
  %t200 = getelementptr %"compiler/free:Free", ptr %t198, i32 0, i32 53
  %t201 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t200, i64 %t201)
  br label %bb52
bb52:
  %t204 = load ptr, ptr %l6, !tbaa !29
  %t206 = getelementptr %"compiler/free:Free", ptr %t204, i32 0, i32 54
  store ptr %t206, ptr %l118, !tbaa !29
  %t207 = ptrtoint ptr %v0 to i64
  store i64 %t207, ptr %l119, !tbaa !24
  %t208 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t208, label %bb53, label %bb54
bb53:
  %t210 = call ptr @__olang_region_make(ptr %v0)
  %t211 = ptrtoint ptr %t210 to i64
  store i64 %t211, ptr %l119, !tbaa !24
  br label %bb54
bb54:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/free:walker", ptr %t212, i32 0, i32 64
  %t215 = load i64, ptr %l16, !tbaa !24
  %t218 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t214, i64 %t215)
  store ptr %t218, ptr %l124
  br label %bb55
bb55:
  %t219 = load i64, ptr %l119
  %t220 = inttoptr i64 %t219 to ptr
  %t221 = load i64, ptr %l119
  %t222 = inttoptr i64 %t221 to ptr
  %t223 = load ptr, ptr %l124, !tbaa !29
  %t224 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecopyOf(ptr %t220, ptr %t222, ptr %t223)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t224, ptr %l125
  br label %bb56
bb56:
  %t225 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125
  %t226 = load i64, ptr %l119
  %t227 = inttoptr i64 %t226 to ptr
  %t228 = call ptr @__olang_scope_alloc_a(ptr %t227, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t225, ptr %t228
  %t229 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t229, ptr %t228)
  br label %bb57
bb57:
  %t231 = load ptr, ptr %l6, !tbaa !29
  %t233 = getelementptr %"compiler/free:Free", ptr %t231, i32 0, i32 55
  store ptr %t233, ptr %l128, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/free:walker", ptr %t234, i32 0, i32 63
  %t237 = load i64, ptr %l16, !tbaa !24
  %t240 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t236, i64 %t237)
  store %"compiler/source:Span" %t240, ptr %l132
  br label %bb58
bb58:
  %t241 = load ptr, ptr %l128, !tbaa !29
  %t242 = load %"compiler/source:Span", ptr %l132
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t241, %"compiler/source:Span" %t242)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t243 = load i64, ptr %l15, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l15, !tbaa !24
  br label %bb34
bb61:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecopyOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l7, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l9
  br label %bb3
bb3:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb10
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l14
  br label %bb7
bb7:
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t23, i64 %t22)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb2
bb10:
  %t31 = load ptr, ptr %lp1
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l40 = alloca ptr
  %l44 = alloca ptr
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l14
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l14, !tbaa !29
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb31
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %t37, i64 %t38)
  store ptr %t41, ptr %l23
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l23, !tbaa !29
  store ptr %t42, ptr %l5, !tbaa !29
  br label %bb31
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l25, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb26
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Elem", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t65 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %s3, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l33
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l33, !tbaa !29
  %t67 = icmp eq ptr %t66, null
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Elem", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %t74, i64 %t75)
  store ptr %t78, ptr %l40
  br label %bb23
bb22:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Elem", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t82, i64 %t83)
  store ptr %t86, ptr %l44
  br label %bb24
bb23:
  %t87 = load ptr, ptr %l40, !tbaa !29
  store ptr %t87, ptr %l36, !tbaa !29
  br label %bb25
bb24:
  %t88 = load ptr, ptr %l44, !tbaa !29
  store ptr %t88, ptr %l36, !tbaa !29
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l36, !tbaa !29
  store ptr %t89, ptr %l5, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_ee9887f5f58478ff_db34cc814b361eab)
  unreachable
bb31:
  %t90 = load ptr, ptr %l5, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2efindIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l6 = alloca ptr
  %l15 = alloca ptr
  %l31 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l6, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:If", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %v1, ptr %t22, i64 %t23)
  store ptr %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l15, !tbaa !29
  store ptr %t27, ptr %l2, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l2, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/typed:If", ptr %t37, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/typed:If", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  br i1 %t51, label %bb11, label %bb12
bb10:
  br label %bb15
bb11:
  call void @__olang_check_failed(ptr @olang_loc_2779327e577b2afc_81ce12c77e8d0b58)
  unreachable
bb12:
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:If", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i64, ptr %l1, !tbaa !24
  %t60 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %v1, ptr %t56, i64 %t57)
  store ptr %t60, ptr %l31
  br label %bb14
bb14:
  %t61 = load ptr, ptr %l31, !tbaa !29
  store ptr %t61, ptr %rv
  br label %ret
bb15:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ffree_2eisConversion(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 20 to i32
  %t4 = icmp eq i32 %a0, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t8 = extractvalue { i64, ptr } %a1, 0
  %t10 = icmp eq i64 %t8, 1
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l4, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2eleaves(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 17}
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_6ad9637bd46aa97_a10a430e5eff5d73)
  unreachable
bb15:
  %t19 = load i1, ptr %l1, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2eoval(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t2 = shl i64 1, 40
  %t4 = sub i64 %t2, 1
  %t7 = and i64 %a0, %t4
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2eownCopySite(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i1
  %l12 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 4 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Make", ptr %t24, i32 0, i32 4
  %t27 = load i32, ptr %t26, !tbaa !23
  %t29 = sext i32 %t27 to i64
  store i64 %t29, ptr %l12, !tbaa !24
  br label %bb8
bb7:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t31 = load i64, ptr %l12, !tbaa !24
  store i64 %t31, ptr %l2, !tbaa !24
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_3413d17bc44a57e3_7c445ad346a50247)
  unreachable
bb14:
  %t32 = load i64, ptr %l2, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load i1, ptr %l15, !tbaa !21
  store i1 %t21, ptr %l6, !tbaa !21
  br label %bb37
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t41 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i1 %t41, ptr %l24
  br label %bb13
bb13:
  %t42 = load i1, ptr %l24, !tbaa !21
  store i1 %t42, ptr %l6, !tbaa !21
  br label %bb37
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l26, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Elem", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = call i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %t61)
  store i1 %t63, ptr %l33
  br label %bb20
bb20:
  %t64 = load i1, ptr %l33, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Elem", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t72 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store i1 %t72, ptr %l38
  br label %bb23
bb22:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb24
bb23:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  %t74 = load i1, ptr %l34, !tbaa !21
  store i1 %t74, ptr %l6, !tbaa !21
  br label %bb37
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb26, label %bb27
bb26:
  %t79 = load ptr, ptr %l39, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 8}
  %t82 = icmp eq i64 %t80, 5
  store i1 %t82, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t83 = load i1, ptr %l40, !tbaa !21
  br i1 %t83, label %bb28, label %bb29
bb28:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Payload", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t97 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t93, ptr %t94)
  store i1 %t97, ptr %l48
  br label %bb31
bb31:
  %t98 = load i1, ptr %l48, !tbaa !21
  store i1 %t98, ptr %l6, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_40628693553637f3_9a0aaf33c7b3625f)
  unreachable
bb37:
  %t99 = load i1, ptr %l6, !tbaa !21
  store i1 %t99, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb35
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb23
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb12, label %bb13
bb12:
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 8}
  %t32 = icmp eq i64 %t30, 0
  store i1 %t32, ptr %l16, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_11a48ff1e8d67007_90e1a85549f82d33)
  unreachable
bb22:
  %t34 = load i1, ptr %l14, !tbaa !21
  store i1 %t34, ptr %l3, !tbaa !21
  br label %bb35
bb23:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb24, label %bb25
bb24:
  %t39 = load ptr, ptr %l19, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 17
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb25
bb25:
  %t43 = load i1, ptr %l20, !tbaa !21
  br i1 %t43, label %bb26, label %bb27
bb26:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = call i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %t50)
  store i1 %t52, ptr %l26
  br label %bb29
bb29:
  %t53 = load i1, ptr %l26, !tbaa !21
  store i1 %t53, ptr %l3, !tbaa !21
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_e0188cd4392210a6_c14318bc74dc83b2)
  unreachable
bb35:
  %t54 = load i1, ptr %l3, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ereadLocalOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l2, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t33 = sext i32 %t31 to i64
  store i64 %t33, ptr %l10, !tbaa !24
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_d0a35c72e1689727_18f1e8c23ad8e373)
  unreachable
bb16:
  %t35 = load i64, ptr %l10, !tbaa !24
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_9d733ba55f12146_b889888c2106eef2)
  unreachable
bb22:
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2esamePure(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l3, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t35 = call i1 @compiler_2ffree_2esamePurePlace(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t35, ptr %l20
  br label %bb11
bb11:
  %t36 = load i1, ptr %l20, !tbaa !21
  store i1 %t36, ptr %l11, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_a76c2f62bbf8a003_89a44c6922f8d22f)
  unreachable
bb17:
  %t37 = load i1, ptr %l11, !tbaa !21
  store i1 %t37, ptr %l4, !tbaa !21
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_e31a42735e4aee82_13f2226a4db7316e)
  unreachable
bb23:
  %t38 = load i1, ptr %l4, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/free:orCall" @compiler_2ffree_3aorCall_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, ptr %a5, ptr %a6) #0 {
entry:
  %rv = alloca %"compiler/free:orCall"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/free:orCall" undef, i64 %a0, 0
  %t18 = insertvalue %"compiler/free:orCall" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/free:orCall" %t18, i64 %a2, 2
  %t22 = insertvalue %"compiler/free:orCall" %t20, i64 %a3, 3
  %t24 = insertvalue %"compiler/free:orCall" %t22, i64 %a4, 4
  %t26 = insertvalue %"compiler/free:orCall" %t24, ptr %a5, 5
  %t28 = insertvalue %"compiler/free:orCall" %t26, ptr %a6, 6
  store %"compiler/free:orCall" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:orCall", ptr %rv
  ret %"compiler/free:orCall" %rr
}

define dso_local %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, ptr %a8) #0 {
entry:
  %rv = alloca %"compiler/free:store"
  br label %start
start:
  br label %bb0
bb0:
  %t20 = insertvalue %"compiler/free:store" undef, i64 %a0, 0
  %t22 = insertvalue %"compiler/free:store" %t20, i64 %a1, 1
  %t24 = insertvalue %"compiler/free:store" %t22, i64 %a2, 2
  %t26 = insertvalue %"compiler/free:store" %t24, %"compiler/source:Span" %a3, 3
  %t28 = insertvalue %"compiler/free:store" %t26, i64 %a4, 4
  %t30 = insertvalue %"compiler/free:store" %t28, i64 %a5, 5
  %t32 = insertvalue %"compiler/free:store" %t30, i64 %a6, 6
  %t34 = insertvalue %"compiler/free:store" %t32, ptr %a7, 7
  %t36 = insertvalue %"compiler/free:store" %t34, ptr %a8, 8
  store %"compiler/free:store" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:store", ptr %rv
  ret %"compiler/free:store" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"compiler/free:retire" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aretire(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:retire"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/free:retire"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:retire", ptr %a0
  store %"compiler/free:retire" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:retire", ptr %l1, i32 0, i32 2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/free:retire", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/free:retire", ptr %l1
  store %"compiler/free:retire" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:retire", ptr %rv
  ret %"compiler/free:retire" %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d0 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"std/prelude" }>, align 8
@__olang_empty_array = external constant [16 x i64]
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_3e_26_3e_2e_2d1 = weak hidden constant i1 false
@olang_2esole_2eArray_3cArray_3cI64_3e_26_3e_2e_2d1 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"the function" }>, align 8
@.d2 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"hidden " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_errpay_pop()
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d5 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"memory: a " }>, align 8
@.d6 = private constant <{ i64, [103 x i8] }> <{ i64 0, [103 x i8] c" is reclaimed where the last owning place holding it lets go of it, once no reference to one is in use\0A" }>, align 8
@.d7 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"memory: a " }>, align 8
@.d8 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c" is kept until its scope closes, never reclaimed early\0A" }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d10 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c": memory: '" }>, align 8
@.d11 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"' keeps the " }>, align 8
@.d12 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"s it lets go of until their scope closes\0A" }>, align 8
@.d13 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c": note: '" }>, align 8
@.d14 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"', a reference to a " }>, align 8
@.d15 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c", is in use across this call\0A" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3aFree__2eheldPlaces_2elocal_2e4 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle(ptr, i1)
declare void @__olang_region_drop(ptr) noinline
@.d16 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"free: hidden let-go in " }>, align 8
@.d17 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d21 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c": memory: " }>, align 8
@.d22 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c" has one holder: every instance stored into an owning place is a new one\0A" }>, align 8
@.d23 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c": memory: " }>, align 8
@.d24 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c" may be held by two owning places at once, so it has no one holder\0A" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d26 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"eq" }>, align 8
@.d31 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"hash" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 9}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 9}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb15
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 7, label %bb7 i64 8, label %bb8 ]
bb3:
  br label %bb15
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb9, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb10, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb11, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 0
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 0
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb13, label %bb1
bb9:
  br label %bb3
bb10:
  br label %bb3
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64 }, ptr %t71, i32 0, i32 1
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64 }, ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb14, label %bb1
bb14:
  br label %bb3
bb15:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_32(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"compiler/free:store"
  %l4 = alloca %"compiler/free:store"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l10 = alloca %"compiler/free:store"
  %l14 = alloca %"compiler/free:store"
  %l23 = alloca i1
  %l32 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/source:Span"
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 83
  %t4 = load i64, ptr %l0, !tbaa !24
  %t7 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %vc0, ptr %vc0, ptr %t3, i64 %t4)
  store %"compiler/free:store" %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load %"compiler/free:store", ptr %l10
  store %"compiler/free:store" %t8, ptr %l3
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/free:Free", ptr %t9, i32 0, i32 83
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %vc0, ptr %vc0, ptr %t11, i64 %t12)
  store %"compiler/free:store" %t15, ptr %l14
  br label %bb2
bb2:
  %t16 = load %"compiler/free:store", ptr %l14
  store %"compiler/free:store" %t16, ptr %l4
  %t17 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 1
  %t20 = load i64, ptr %t19, !tbaa !24
  %t23 = icmp ne i64 %t18, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 1
  %t28 = load i64, ptr %t27, !tbaa !24
  %t31 = icmp slt i64 %t26, %t28
  store i1 %t31, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t33 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 7
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb8
bb7:
  %t38 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 7
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  store i1 %t41, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t44 = load i64, ptr %l0, !tbaa !24
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  store i1 %t48, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t50 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 7
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  br i1 %t53, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_239d88d441cb182b_2c8019ca300f83c7)
  unreachable
bb13:
  br label %bb14
bb14:
  %t55 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 7
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %vc0, ptr %t56)
  store %"compiler/source:Span" %t58, ptr %l32
  br label %bb15
bb15:
  %t59 = load %"compiler/source:Span", ptr %l32
  store %"compiler/source:Span" %t59, ptr %l5
  %t60 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 7
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  br i1 %t63, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_239d88d441cb182b_2c8019ca300f83c7)
  unreachable
bb17:
  br label %bb18
bb18:
  %t65 = getelementptr %"compiler/free:store", ptr %l4, i32 0, i32 7
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %vc0, ptr %t66)
  store %"compiler/source:Span" %t68, ptr %l36
  br label %bb19
bb19:
  %t69 = load %"compiler/source:Span", ptr %l36
  store %"compiler/source:Span" %t69, ptr %l6
  %t70 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t71 = load i32, ptr %t70, !tbaa !23
  %t72 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t73 = load i32, ptr %t72, !tbaa !23
  %t76 = icmp ne i32 %t71, %t73
  br i1 %t76, label %bb20, label %bb21
bb20:
  %t78 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t79 = load i32, ptr %t78, !tbaa !23
  %t80 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t84 = icmp slt i32 %t79, %t81
  store i1 %t84, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t86 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t87 = load i32, ptr %t86, !tbaa !23
  %t88 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 1
  %t89 = load i32, ptr %t88, !tbaa !23
  %t92 = icmp ne i32 %t87, %t89
  br i1 %t92, label %bb23, label %bb24
bb23:
  %t94 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t95 = load i32, ptr %t94, !tbaa !23
  %t96 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 1
  %t97 = load i32, ptr %t96, !tbaa !23
  %t100 = icmp sgt i32 %t95, %t97
  store i1 %t100, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t102 = load i64, ptr %l0, !tbaa !24
  %t103 = load i64, ptr %l1, !tbaa !24
  %t106 = icmp slt i64 %t102, %t103
  store i1 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d34 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d35 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"the program's scope" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"the " }>, align 8
@.d39 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'s scope" }>, align 8
@.d40 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'s scope" }>, align 8
@.d41 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"its scope" }>, align 8
define linkonce_odr %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:leaf"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:leaf", ptr %a0
  store %"compiler/free:leaf" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/free:leaf", ptr %l1
  store %"compiler/free:leaf" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

@olang_2esole_2ecompiler_2ffree_3areason_2e3 = weak hidden constant i1 false
@.d42 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"its new value is existing storage: '" }>, align 8
@.d43 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"'; give it new storage - a constructor call, '$...', 'Copy()'" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"esc " }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" par " }>, align 8
@.d46 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d47 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" inside " }>, align 8
@.d48 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a reference into it is stored here, in '" }>, align 8
@.d51 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'; store a copy, '$(...)'" }>, align 8
@.d52 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"a reference into it is kept here" }>, align 8
@.d53 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"a view that may be into an array a generational instance holds in place is kept here: '" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 568, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 10
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 11
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 15
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 16
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 17
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 18
  %t29 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H37dabf8663d733dfb3cf8a6ba127be58(ptr %v0, ptr %t27)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  %t31 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %t31
  %t32 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 19
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 20
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec__Hdbcf217951d8a5e6be477b9bbf1b3074(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  %t42 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 21
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t46 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  %t47 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 22
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l21
  br label %bb10
bb10:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t51 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 568, i1 false)
  br label %ret
ret:
  ret void
}

@.d55 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"free: escaped holder " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d56 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aScope(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 9}
  switch i64 %t2, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 i64 8, label %bb10 ]
bb1:
  br label %ret
bb2:
  %t4 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t4, i64 %t5)
  br label %bb1
bb3:
  %t6 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t6, i64 %t7)
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t8, i64 %t9)
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t15 = sext i32 %t13 to i64
  %t16 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %t15)
  call void @__olang_sb_add(ptr %v0, i64 %t17)
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t18, i64 %t19)
  br label %bb1
bb4:
  %t20 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t20, i64 %t21)
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t22, i64 %t23)
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t24, i32 0, i32 1
  %t26 = getelementptr { i64 }, ptr %t25, i32 0, i32 0
  %t27 = load i64, ptr %t26
  %t29 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t30 = call i64 @__olang_fmt_i64(ptr %t29, i64 %t27)
  call void @__olang_sb_add(ptr %v0, i64 %t30)
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t31, i64 %t32)
  br label %bb1
bb5:
  %t33 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t33, i64 %t34)
  br label %bb1
bb6:
  %t35 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t35, i64 %t36)
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t37, i64 %t38)
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 1
  %t41 = getelementptr { i32 }, ptr %t40, i32 0, i32 0
  %t42 = load i32, ptr %t41
  %t44 = sext i32 %t42 to i64
  %t45 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t46 = call i64 @__olang_fmt_i64(ptr %t45, i64 %t44)
  call void @__olang_sb_add(ptr %v0, i64 %t46)
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t47, i64 %t48)
  br label %bb1
bb7:
  %t49 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t49, i64 %t50)
  br label %bb1
bb8:
  %t51 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t51, i64 %t52)
  br label %bb1
bb9:
  %t53 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t53, i64 %t54)
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t55, i64 %t56)
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr { i64, [2 x i64] }, ptr %t57, i32 0, i32 1
  %t59 = getelementptr { i64 }, ptr %t58, i32 0, i32 0
  %t60 = load i64, ptr %t59
  %t62 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t63 = call i64 @__olang_fmt_i64(ptr %t62, i64 %t60)
  call void @__olang_sb_add(ptr %v0, i64 %t63)
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t64, i64 %t65)
  br label %bb1
bb10:
  %t66 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t66, i64 %t67)
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t68, i64 %t69)
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64 }, ptr %t71, i32 0, i32 0
  %t73 = load i64, ptr %t72
  %t75 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t76 = call i64 @__olang_fmt_i64(ptr %t75, i64 %t73)
  call void @__olang_sb_add(ptr %v0, i64 %t76)
  %t77 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t77, i64 %t78)
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr { i64, [2 x i64] }, ptr %t79, i32 0, i32 1
  %t81 = getelementptr { i64, i64 }, ptr %t80, i32 0, i32 1
  %t82 = load i64, ptr %t81
  %t84 = call ptr @__olang_sb_room(ptr %v0, i64 24)
  %t85 = call i64 @__olang_fmt_i64(ptr %t84, i64 %t82)
  call void @__olang_sb_add(ptr %v0, i64 %t85)
  %t86 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t86, i64 %t87)
  br label %bb1
ret:
  ret void
}

@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @__olang_sb_done(ptr)
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d60 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d61 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d66 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d67 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"its new value is built where the old one lives: '" }>, align 8
@.d68 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"' borrows its result from '" }>, align 8
@.d69 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"'; a built result ('" }>, align 8
@.d70 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"') frees the old " }>, align 8
@.d71 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d72 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"its new value is not all new: '" }>, align 8
@.d73 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"' returns storage it was given" }>, align 8
@.d74 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d75 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d76 = private constant <{ i64, [105 x i8] }> <{ i64 0, [105 x i8] c"a generator holds a view that may be into an array a generational instance holds in place, across a yield" }>, align 8
@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2emakeOf_2elocal_2e4 = weak hidden constant i1 false
@.d77 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"a copy of a value holding it" }>, align 8
@.d78 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"an 'any' is made of a reference that may reach one, which nothing counts" }>, align 8
@.d79 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"C is given a reference that may reach one" }>, align 8
@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ereach_2elocal_2e20 = weak hidden constant i1 false
@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d82 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"untracked " }>, align 8
@.d83 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d84 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d85 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"a value holding it is made with no store into it, by " }>, align 8
@.d86 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c": '" }>, align 8
@.d87 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d88 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"its new value is a copy of what a constructor is given: '" }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d90 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"its new value is a copy of what a constructor is given, which holds other owners too: '" }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H37dabf8663d733dfb3cf8a6ba127be58(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std__Hc31c075a081277beb11a6149e950d3c3(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = mul i64 %t13, 8
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = mul i64 %t22, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  %t26 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l8, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l9, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = mul i64 %t39, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t42 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t41, ptr %t42, !tbaa !27
  %t43 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec__Hdbcf217951d8a5e6be477b9bbf1b3074(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare ptr @__olang_sb_grow(ptr, i64) noinline
@.d92 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.Scope.Unset" }>, align 8
@.d93 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.Scope.Block" }>, align 8
@.d94 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d95 = private unnamed_addr constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d96 = private unnamed_addr constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"typed.Scope.Var" }>, align 8
@.d97 = private unnamed_addr constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"typed.Scope.Program" }>, align 8
@.d98 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.Scope.Region" }>, align 8
@.d99 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.Scope.Frame" }>, align 8
@.d100 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.Scope.Inert" }>, align 8
@.d101 = private unnamed_addr constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"typed.Scope.Found" }>, align 8
@.d102 = private unnamed_addr constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"typed.Scope.Passed" }>, align 8
@.d103 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std__Hc31c075a081277beb11a6149e950d3c3(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 40
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelud_Hc8a994261b444ea12c5b83da9413a98f(ptr %v0, ptr %t15)
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t22, i64 %t20
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 32
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i64 %t20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare ptr @__olang_scope_mine_slow(ptr) noinline
define linkonce_odr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelud_Hc8a994261b444ea12c5b83da9413a98f(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %a0
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %rv
  ret %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_aa0994ef0ced0737_f892d7c71adaceeb = external constant [0 x i8]
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eMovBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\40\00\00\00\00" }>, align 8
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2eLen_3ccompiler_2ffree_3aretire_3e(ptr %v0, ptr %a0)
declare %"compiler/free:retire" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2eAt_3ccompiler_2ffree_3aretire_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2eokind(i64 %a0)
@G_2ecompiler_2ffree_2eOPl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eImmut(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6a56aba8df98d2ec_68c83986518f8c70 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf6c82cf5f0e7149f7052eb5498c4cd14(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_8ae6f1105e3c6679_a593dc3435f5df1d = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ehas(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownCode(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epreludeCode(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ffree_2eMustTop = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandedToC(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bdc560d7322c3213_e707f8f411fbb267 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_H788cd74f9c006611bc4bb459b5b22001(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_72902bac739aff89_2513c2e385693c05 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_3fc20153d7ed10ca_2c74aea1b5acbce6 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2enoteDtor(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eLen_H9daf28210c013890fd7cb07d1d61ba6e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_4cef24e7d17769b7_e2744f91577a9953 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_947cc6b8bd079717_9e266d1a8b9c5cdb = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehiddenCalls(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i32 @std_2fio_2ePutErr(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_Haae4fbc3ba15583a49040d883d2248d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenLetsOf(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenIndex(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elineStart(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufRows(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H0fa35282e56bd0cd9b08251ba99b9868(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H08f3244764437e29647226f03a29c83b(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H127fb385441fbfd25cd8404c6b268b5d(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emodelled(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edebugOut(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hdc5ed4f57090b33f7a83fc7b2b1f05b3(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eIsGen(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_708b3215abbdbba7_3cea2bd689d53e8b = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebuiltAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
@olang_loc_3bfd4abaed3d7178_ecedd42d9535955c = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2ffree_2eruns({ i64, [2 x i64] } %a0)
declare ptr @compiler_2ftyped_2eCall_2eOf(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2ffree_2ectorCall(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_18f4ed1d8e27b1ae_93487f3f650a5572 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i64 %a5)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Ha270003b2266a12c55eea6eacf9a4be1(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenPlace(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eSFresh = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSMove = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisContents(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eLCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisNamed(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0)
declare %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclaresCopy(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7b3dede47d025484_fbd5a3b64af54730 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_12d027853a0706eb_617ec39b0606fdd7 = external constant [0 x i8]
@G_2ecompiler_2ffree_2eMustNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_6cb79447255537d7_e828faabaec907d3 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_14962ab25e47b4fc_3749941476b1d040 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2ebinds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8d35557863f6e46b_2765f8f7d1e0ebdf = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_502532e2e95f04ea_fe436d8dc2f78aae = external constant [0 x i8]
@olang_loc_ba297c355e3740f1_9975a70d069e6a55 = external constant [0 x i8]
@olang_loc_bb85040a6a786cb8_20e886069e3b9c04 = external constant [0 x i8]
@olang_loc_be187497b97f18d7_9641cb8c9c409d3 = external constant [0 x i8]
@olang_loc_342e0c3fe78e7ee6_419d07e7c20dd892 = external constant [0 x i8]
@olang_loc_d5478abcfcd1a74_537f989617a8cff0 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
declare i1 @compiler_2ftyped_2eViewsMoved(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyLeaves(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, %"compiler/source:Span" %a3)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_3ed6c54977104fdc_6fa493e2929cd018 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_68d09f9a6af90acb_8af3bb3c4e4b4237 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
@olang_loc_7f12d3772dd0a929_45b952e679e83a85 = external constant [0 x i8]
declare %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ffree_2eSFail = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1)
@G_2ecompiler_2ffree_2eRMade = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eValueParts(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eAnyPlace = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5)
declare i1 @compiler_2ffree_2einElement(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eOParC = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOPar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRStore = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufPlace(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufNot(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, %"compiler/source:Span" %a3)
declare i64 @compiler_2ftyped_2eDropHolder(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eregister(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexprOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2enoteView(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eLen_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2ffree_2epastAway(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eAssignedLocal(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebuiltSpell(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewhat(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_fa71248d89b17b0b_39d265aac120d27f = external constant [0 x i8]
@olang_loc_a7dbf91e7cbb7208_810d022031132c04 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elocalReach(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewLocals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayView(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2ffree_2espanIn(%"compiler/source:Span" %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ewrittenRecs(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
@G_2ecompiler_2ffree_2eCalleeGiven = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FD\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2evia(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesPure(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f349e97cfb4cca10_59712e6808efe99c = external constant [0 x i8]
@G_2ecompiler_2ffree_2eONew = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eorig(i64 %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeStores(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachTy(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNever(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4)
@olang_loc_3fe28685437e06db_e899c2573511637 = external constant [0 x i8]
declare %"compiler/free:orStore" @compiler_2ffree_3aorStore_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, ptr %a2, ptr %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2ePush_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:orStore" %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexclusive(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_5b2db086410f023b_92c7c7c81d16141f = external constant [0 x i8]
declare i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_bfa96af29dec6ca7_6eacd8161d4b79f3 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hcb8ba31809995dcae45f5acc6cf39f88(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Hca84839cdf395382408370342cfafe64(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2epureBase(ptr %v0, ptr %a0)
@olang_loc_34bfc259355dec67_8a2d14d061fee643 = external constant [0 x i8]
@olang_loc_806a74b5c91de186_4e306eb4964e9ec2 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6, i1 %a7)
@G_2ecompiler_2ffree_2eRCopied = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_b3a24969a5664c78_6a2ceec1abacdcc4 = external constant [0 x i8]
@olang_loc_1adc22647748ff1d_11d3fcef2a51f919 = external constant [0 x i8]
@olang_loc_6035cb012844bf8d_c31ea78c8ebfe279 = external constant [0 x i8]
@olang_loc_6b9356bc715f0c33_1387949cfe4e721f = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitLeaf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, ptr %a4, i64 %a5)
declare ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ee9887f5f58478ff_db34cc814b361eab = external constant [0 x i8]
declare ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_2779327e577b2afc_81ce12c77e8d0b58 = external constant [0 x i8]
@olang_loc_6ad9637bd46aa97_a10a430e5eff5d73 = external constant [0 x i8]
@olang_loc_3413d17bc44a57e3_7c445ad346a50247 = external constant [0 x i8]
@olang_loc_40628693553637f3_9a0aaf33c7b3625f = external constant [0 x i8]
@olang_loc_11a48ff1e8d67007_90e1a85549f82d33 = external constant [0 x i8]
@olang_loc_e0188cd4392210a6_c14318bc74dc83b2 = external constant [0 x i8]
@olang_loc_d0a35c72e1689727_18f1e8c23ad8e373 = external constant [0 x i8]
@olang_loc_9d733ba55f12146_b889888c2106eef2 = external constant [0 x i8]
declare i1 @compiler_2ffree_2esamePurePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_a76c2f62bbf8a003_89a44c6922f8d22f = external constant [0 x i8]
@olang_loc_e31a42735e4aee82_13f2226a4db7316e = external constant [0 x i8]
@olang_loc_239d88d441cb182b_2c8019ca300f83c7 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
