; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/source:Names" = type { %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" }
%"std/prelude/list:List<std/prelude/text:String&>" = type { ptr }
%"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
define dso_local { i64, ptr } @compiler_2fsource_2eLineStarts(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %lp6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i8
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i8
  %l23 = alloca i8
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i8
  %l44 = alloca i8
  %l45 = alloca i1
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i32
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 1, ptr %l1, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l13, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t3, ptr %l14, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l15, !tbaa !24
  %t6 = load i64, ptr %l15, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l16, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l17, !tbaa !24
  %t9 = load i64, ptr %l16, !tbaa !24
  %t10 = load i64, ptr %l17, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l18, !tbaa !21
  %t12 = load i1, ptr %l18, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l19, !tbaa !21
  %t14 = load i1, ptr %l19, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l20, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l21, !tbaa !24
  %t17 = load i64, ptr %l21, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t17
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l22, !tbaa !22
  %t22 = load i8, ptr %l22, !tbaa !22
  store i8 %t22, ptr %l5, !tbaa !22
  %t23 = load i8, ptr %l5, !tbaa !22
  store i8 %t23, ptr %l23, !tbaa !22
  %t24 = load i8, ptr %l23, !tbaa !22
  %t25 = icmp eq i8 %t24, 10
  store i1 %t25, ptr %l24, !tbaa !21
  %t26 = load i1, ptr %l24, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load i64, ptr %l1, !tbaa !24
  store i64 %t27, ptr %l25, !tbaa !24
  %t28 = load i64, ptr %l25, !tbaa !24
  %t29 = add i64 %t28, 1
  store i64 %t29, ptr %l26, !tbaa !24
  %t30 = load i64, ptr %l26, !tbaa !24
  store i64 %t30, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb7
bb6:
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load i64, ptr %l3, !tbaa !24
  store i64 %t31, ptr %l27, !tbaa !24
  %t32 = load i64, ptr %l27, !tbaa !24
  %t33 = add i64 %t32, 1
  store i64 %t33, ptr %l28, !tbaa !24
  %t34 = load i64, ptr %l28, !tbaa !24
  store i64 %t34, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb1
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t35 = load i64, ptr %l1, !tbaa !24
  store i64 %t35, ptr %l29, !tbaa !24
  %t36 = load i64, ptr %l29, !tbaa !24
  %t37 = icmp sge i64 %t36, 0
  store i1 %t37, ptr %l30, !tbaa !21
  %t38 = load i1, ptr %l30, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = icmp sle i64 %t39, 2305843009213693951
  store i1 %t40, ptr %l31, !tbaa !21
  %t41 = load i1, ptr %l31, !tbaa !21
  br i1 %t41, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb12:
  %t42 = load i64, ptr %l29, !tbaa !24
  %t43 = mul i64 %t42, 4
  %t44 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l32, !tbaa !27
  %t47 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t47, ptr %lp6
  %t48 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t49 = load ptr, ptr %lp6
  store { i64, ptr } %t48, ptr %t49, !tbaa !27
  store i64 1, ptr %l7, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s5
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t50, ptr %l33, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t51, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t52, ptr %l34, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l35, !tbaa !24
  %t55 = load i64, ptr %l35, !tbaa !24
  store i64 %t55, ptr %l10, !tbaa !24
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb14:
  store %olang.scope zeroinitializer, ptr %s6
  %t56 = load i64, ptr %l9, !tbaa !24
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  store i64 %t57, ptr %l37, !tbaa !24
  %t58 = load i64, ptr %l36, !tbaa !24
  %t59 = load i64, ptr %l37, !tbaa !24
  %t60 = icmp slt i64 %t58, %t59
  store i1 %t60, ptr %l38, !tbaa !21
  %t61 = load i1, ptr %l38, !tbaa !21
  %t62 = xor i1 %t61, true
  store i1 %t62, ptr %l39, !tbaa !21
  %t63 = load i1, ptr %l39, !tbaa !21
  br i1 %t63, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb16:
  br label %bb17
bb17:
  %t64 = load i64, ptr %l9, !tbaa !24
  store i64 %t64, ptr %l40, !tbaa !24
  %t65 = load i64, ptr %l40, !tbaa !24
  store i64 %t65, ptr %l11, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t66, ptr %l41, !tbaa !27
  %t67 = load i64, ptr %l9, !tbaa !24
  store i64 %t67, ptr %l42, !tbaa !24
  %t68 = load i64, ptr %l42, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t68
  %t72 = load i8, ptr %t71, !tbaa !32
  store i8 %t72, ptr %l43, !tbaa !22
  %t73 = load i8, ptr %l43, !tbaa !22
  store i8 %t73, ptr %l12, !tbaa !22
  %t74 = load i8, ptr %l12, !tbaa !22
  store i8 %t74, ptr %l44, !tbaa !22
  %t75 = load i8, ptr %l44, !tbaa !22
  %t76 = icmp eq i8 %t75, 10
  store i1 %t76, ptr %l45, !tbaa !21
  %t77 = load i1, ptr %l45, !tbaa !21
  br i1 %t77, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s7
  %t78 = load i64, ptr %l7, !tbaa !24
  store i64 %t78, ptr %l46, !tbaa !24
  %t79 = load i64, ptr %l11, !tbaa !24
  store i64 %t79, ptr %l47, !tbaa !24
  %t80 = load i64, ptr %l47, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l48, !tbaa !24
  %t82 = load i64, ptr %l48, !tbaa !24
  %t83 = trunc i64 %t82 to i32
  store i32 %t83, ptr %l49, !tbaa !23
  %t84 = load i32, ptr %l49, !tbaa !23
  %t85 = load ptr, ptr %lp6
  %t86 = load i64, ptr %l46, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i32, ptr %t88, i64 %t86
  store i32 %t84, ptr %t89, !tbaa !33
  %t90 = load i64, ptr %l7, !tbaa !24
  store i64 %t90, ptr %l50, !tbaa !24
  %t91 = load i64, ptr %l50, !tbaa !24
  %t92 = add i64 %t91, 1
  store i64 %t92, ptr %l51, !tbaa !24
  %t93 = load i64, ptr %l51, !tbaa !24
  store i64 %t93, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb20
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  %t94 = load i64, ptr %l9, !tbaa !24
  store i64 %t94, ptr %l52, !tbaa !24
  %t95 = load i64, ptr %l52, !tbaa !24
  %t96 = add i64 %t95, 1
  store i64 %t96, ptr %l53, !tbaa !24
  %t97 = load i64, ptr %l53, !tbaa !24
  store i64 %t97, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb14
bb22:
  call void @__olang_scope_close(ptr %s5)
  %t98 = load ptr, ptr %lp6
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l54, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t100 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"compiler/source:Source" } @compiler_2fsource_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Source"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i32, %"compiler/source:Source" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %t2)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  br label %bb3
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  store i32 %t17, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l6, !tbaa !23
  %t19 = insertvalue { i32, %"compiler/source:Source" } zeroinitializer, i32 %t18, 0
  store { i32, %"compiler/source:Source" } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t20, ptr %lp1
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = load ptr, ptr %lp1
  store { i64, ptr } %t21, ptr %t22, !tbaa !27
  %t23 = load ptr, ptr %lp1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l7, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l8, !tbaa !24
  %t27 = load i64, ptr %l8, !tbaa !24
  %t28 = icmp slt i64 %t27, 2147483647
  store i1 %t28, ptr %l9, !tbaa !21
  %t29 = load i1, ptr %l9, !tbaa !21
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load ptr, ptr %lp1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l14, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t35 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v1, { i64, ptr } %t33, { i64, ptr } %t34)
  store %"compiler/source:Source" %t35, ptr %l15
  br label %bb6
bb5:
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t36, ptr %l10, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t37 = extractvalue { i64, ptr } { i64 8, ptr @.d1 }, 1
  %t38 = extractvalue { i64, ptr } { i64 8, ptr @.d1 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t37, i64 %t38)
  %t39 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  call void @__olang_sb_put(ptr %s1, ptr %t40, i64 %t41)
  %t42 = extractvalue { i64, ptr } { i64 20, ptr @.d2 }, 1
  %t43 = extractvalue { i64, ptr } { i64 20, ptr @.d2 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t42, i64 %t43)
  %t44 = load ptr, ptr %s1
  %t45 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t46 = load i64, ptr %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t44, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l11, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t50 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  %t52 = extractvalue { i64, ptr } %t50, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l12, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t58, 1
  call void @__olang_check_failed_text(ptr @.c3, { i64, ptr } %t61)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load %"compiler/source:Source", ptr %l15
  %t63 = insertvalue { i32, %"compiler/source:Source" } zeroinitializer, %"compiler/source:Source" %t62, 1
  store { i32, %"compiler/source:Source" } %t63, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/source:Source" }, ptr %rv
  ret { i32, %"compiler/source:Source" } %rr
}

define dso_local i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/source:Names", ptr %t2, i32 0, i32 0
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eadd(ptr %v0, ptr %s1, ptr %t10, { i64, ptr } { i64 0, ptr @.d4 })
  store i32 %t11, ptr %l7
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t14 = getelementptr %"compiler/source:Names", ptr %t13, i32 0, i32 1
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l11, !tbaa !27
  %t16 = load ptr, ptr %l10, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t18 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H7cdf11fa982e6abfb09bba8099b31363(ptr %v0, ptr %v1, ptr %t16, { i64, ptr } %t17)
  %t19 = extractvalue { i32, i32 } %t18, 1
  %t20 = extractvalue { i32, i32 } %t18, 0
  store i32 %t20, ptr %l13
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb7, label %ok.22
ok.22:
  store i32 %t19, ptr %l12
  br label %bb6
bb6:
  %t23 = load i32, ptr %l12, !tbaa !23
  store i32 %t23, ptr %l8, !tbaa !23
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l14, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t25, ptr %l15, !tbaa !27
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t28 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eadd(ptr %v0, ptr %v1, ptr %t26, { i64, ptr } %t27)
  store i32 %t28, ptr %l16
  br label %bb9
bb9:
  %t29 = load i32, ptr %l16, !tbaa !23
  store i32 %t29, ptr %l8, !tbaa !23
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i32, ptr %l8, !tbaa !23
  store i32 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/source:Names", ptr %t2, i32 0, i32 0
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  store i32 %t4, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l4, !tbaa !23
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store { i64, ptr } %t9, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eadd(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/source:Names", ptr %t2, i32 0, i32 0
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = trunc i64 %t6 to i32
  store i32 %t7, ptr %l6, !tbaa !23
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %l7, !tbaa !23
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = getelementptr %"compiler/source:Names", ptr %t11, i32 0, i32 0
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = load ptr, ptr %s1
  %t18 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t19 = load i64, ptr %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t17, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l11, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t23 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l12, !tbaa !27
  %t30 = load ptr, ptr %l9, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t30, { i64, ptr } %t31)
  br label %bb2
bb2:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l13, !tbaa !29
  %t33 = load ptr, ptr %l13, !tbaa !29
  %t34 = getelementptr %"compiler/source:Names", ptr %t33, i32 0, i32 1
  store ptr %t34, ptr %l14, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l15, !tbaa !29
  %t36 = load ptr, ptr %l15, !tbaa !29
  %t37 = getelementptr %"compiler/source:Names", ptr %t36, i32 0, i32 0
  store ptr %t37, ptr %l16, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l17, !tbaa !29
  %t39 = load ptr, ptr %l17, !tbaa !29
  %t40 = getelementptr %"compiler/source:Names", ptr %t39, i32 0, i32 0
  store ptr %t40, ptr %l18, !tbaa !29
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t42 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t41)
  store i64 %t42, ptr %l19
  br label %bb3
bb3:
  %t43 = load i64, ptr %l19, !tbaa !24
  %t44 = sub i64 %t43, 1
  store i64 %t44, ptr %l20, !tbaa !24
  %t45 = load ptr, ptr %l16, !tbaa !29
  %t46 = load i64, ptr %l20, !tbaa !24
  %t47 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t45, i64 %t46)
  store { i64, ptr } %t47, ptr %l21
  br label %bb4
bb4:
  %t48 = load i32, ptr %l2, !tbaa !23
  store i32 %t48, ptr %l22, !tbaa !23
  %t49 = load ptr, ptr %l14, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t51 = load i32, ptr %l22, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Head3ac46f52d9d4661d8417badad2a94(ptr %v0, ptr %v0, ptr %t49, { i64, ptr } %t50, i32 %t51)
  br label %bb5
bb5:
  %t52 = load i32, ptr %l2, !tbaa !23
  store i32 %t52, ptr %l23, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t53 = load i32, ptr %l23, !tbaa !23
  store i32 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = getelementptr %"compiler/source:Source", ptr %t2, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l6, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l7, !tbaa !24
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = sub i64 %t7, 1
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l8, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l9, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l10, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  store i1 %t14, ptr %l11, !tbaa !21
  %t15 = load i1, ptr %l11, !tbaa !21
  %t16 = xor i1 %t15, true
  store i1 %t16, ptr %l12, !tbaa !21
  %t17 = load i1, ptr %l12, !tbaa !21
  br i1 %t17, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l13, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  store i64 %t19, ptr %l14, !tbaa !24
  %t20 = load i64, ptr %l13, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = add i64 %t20, %t21
  store i64 %t22, ptr %l15, !tbaa !24
  %t23 = load i64, ptr %l15, !tbaa !24
  %t24 = add i64 %t23, 1
  store i64 %t24, ptr %l16, !tbaa !24
  %t25 = load i64, ptr %l16, !tbaa !24
  %t26 = sdiv i64 %t25, 2
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load i64, ptr %l17, !tbaa !24
  store i64 %t27, ptr %l4, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 2
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l19, !tbaa !27
  %t32 = load i64, ptr %l4, !tbaa !24
  store i64 %t32, ptr %l20, !tbaa !24
  %t33 = load i64, ptr %l20, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i32, ptr %t35, i64 %t33
  %t37 = load i32, ptr %t36, !tbaa !33
  store i32 %t37, ptr %l21, !tbaa !23
  %t38 = load i32, ptr %l1, !tbaa !23
  store i32 %t38, ptr %l22, !tbaa !23
  %t39 = load i32, ptr %l21, !tbaa !23
  %t40 = load i32, ptr %l22, !tbaa !23
  %t41 = icmp sle i32 %t39, %t40
  store i1 %t41, ptr %l23, !tbaa !21
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load i64, ptr %l4, !tbaa !24
  store i64 %t43, ptr %l24, !tbaa !24
  %t44 = load i64, ptr %l24, !tbaa !24
  store i64 %t44, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i64, ptr %l4, !tbaa !24
  store i64 %t45, ptr %l25, !tbaa !24
  %t46 = load i64, ptr %l25, !tbaa !24
  %t47 = sub i64 %t46, 1
  store i64 %t47, ptr %l26, !tbaa !24
  %t48 = load i64, ptr %l26, !tbaa !24
  store i64 %t48, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t49 = load i64, ptr %l2, !tbaa !24
  store i64 %t49, ptr %l27, !tbaa !24
  %t50 = load i64, ptr %l27, !tbaa !24
  %t51 = add i64 %t50, 1
  store i64 %t51, ptr %l28, !tbaa !24
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = trunc i64 %t52 to i32
  store i32 %t53, ptr %l29, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t54 = load i32, ptr %l29, !tbaa !23
  store i32 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLineStart(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/source:Source", ptr %t2, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = sub i32 %t6, 1
  store i32 %t7, ptr %l5, !tbaa !23
  %t8 = load i32, ptr %l5, !tbaa !23
  %t9 = sext i32 %t8 to i64
  %t10 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i32, ptr %t11, i64 %t9
  %t13 = load i32, ptr %t12, !tbaa !33
  store i32 %t13, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i32, ptr %l6, !tbaa !23
  store i32 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/source:Source", ptr %t2, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = sext i32 %t7 to i64
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l6, !tbaa !23
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = sext i32 %t11 to i64
  store i64 %t12, ptr %l7, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l8, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  store i1 %t16, ptr %l9, !tbaa !21
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t18 = load i64, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sle i64 %t18, %t19
  store i1 %t20, ptr %l10, !tbaa !21
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb3:
  %t22 = load i64, ptr %l7, !tbaa !24
  %t23 = load i64, ptr %l8, !tbaa !24
  %t24 = icmp sle i64 %t22, %t23
  store i1 %t24, ptr %l11, !tbaa !21
  %t25 = load i1, ptr %l11, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb5:
  %t26 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = getelementptr i8, ptr %t27, i64 %t28
  %t31 = sub i64 %t29, %t28
  %t32 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t30, 1
  store { i64, ptr } %t33, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t34 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t34, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l1 = alloca %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>"
  %l2 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l3 = alloca %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>"
  %l4 = alloca %"compiler/source:Names"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Names"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l2
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l2
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_H106597710f9fc90fceb0a5b4451f24b7(ptr %t4)
  store %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" %t5, ptr %l3
  br label %bb2
bb2:
  %t6 = load %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>", ptr %l3
  store %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" %t6, ptr %l1
  %t7 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l0
  %t8 = insertvalue %"compiler/source:Names" undef, %"std/prelude/list:List<std/prelude/text:String&>" %t7, 0
  %t9 = load %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>", ptr %l1
  %t10 = insertvalue %"compiler/source:Names" %t8, %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" %t9, 1
  store %"compiler/source:Names" %t10, ptr %l4
  call void @__olang_scope_close(ptr %s0)
  %t11 = load %"compiler/source:Names", ptr %l4
  store %"compiler/source:Names" %t11, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Names", ptr %rv
  ret %"compiler/source:Names" %rr
}

define dso_local %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/source:Source"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Source"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l6, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t5, ptr %l7, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fsource_2eLineStarts(ptr %v1, ptr %v2, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = insertvalue %"compiler/source:Source" undef, { i64, ptr } %t9, 0
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = insertvalue %"compiler/source:Source" %t10, { i64, ptr } %t11, 1
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = insertvalue %"compiler/source:Source" %t12, { i64, ptr } %t13, 2
  store %"compiler/source:Source" %t14, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t15 = load %"compiler/source:Source", ptr %l9
  store %"compiler/source:Source" %t15, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Source", ptr %rv
  ret %"compiler/source:Source" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !23
  store i32 %t1, ptr %l4, !tbaa !23
  %t2 = load i32, ptr %l4, !tbaa !23
  store i32 %t2, ptr %l2, !tbaa !23
  %t3 = load i32, ptr %l1, !tbaa !23
  store i32 %t3, ptr %l5, !tbaa !23
  %t4 = load i32, ptr %l5, !tbaa !23
  store i32 %t4, ptr %l3, !tbaa !23
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = insertvalue %"compiler/source:Span" undef, i32 %t5, 0
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = insertvalue %"compiler/source:Span" %t6, i32 %t7, 1
  store %"compiler/source:Span" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [53 x i8] c"compiler/source.olang:62: array length out of range\0A\00"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d1 = private constant [8 x i8] c"source: "
declare void @__olang_sb_put(ptr, ptr, i64)
@.d2 = private constant [20 x i8] c" is larger than 2 GB"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_sb_done(ptr)
declare void @__olang_check_failed_text(ptr, { i64, ptr })
@.c3 = private unnamed_addr constant [45 x i8] c"compiler/source.olang:52: assertion failed: \00"
@.d4 = private constant [0 x i8] c""
@.c5 = private unnamed_addr constant [53 x i8] c"compiler/source.olang:97: slice bounds out of range\0A\00"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l0
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

define linkonce_odr %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_H106597710f9fc90fceb0a5b4451f24b7(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>", ptr %l0
  store %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>", ptr %rv
  ret %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H7cdf11fa982e6abfb09bba8099b31363(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Head3ac46f52d9d4661d8417badad2a94(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map<std/prelude/text:String&, compiler/source:NameId>" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20compiler_2fsource_3aNameId_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
