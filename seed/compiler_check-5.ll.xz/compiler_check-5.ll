; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/check:altsCovered" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1 }
%"compiler/check:payloadItem" = type { i32, ptr }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/check:factsMark" = type { i64, i64, i64 }
%"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" = type { %"compiler/generic:Origin", i64 }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" = type { { ptr, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:errNarrow" = type { i32, i32, i64, i1 }
%"compiler/check:rawTable" = type { i32, i1, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/check:setAt" = type { ptr, i64, { i64, ptr }, { i64, ptr }, %"compiler/source:Span", i32 }
%"compiler/check:idleCall" = type { i64, i64, %"compiler/source:Span", { i64, ptr }, ptr }
%"compiler/check:tailAsk" = type { i64, i64, %"compiler/source:Span", i64 }
%"compiler/types:DtorWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:atRec" = type { i64, i64, ptr, i32 }
%"compiler/check:collWalk" = type { ptr, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:elemsShape" = type { { i64, ptr }, i64 }
%"compiler/check:ownerAt" = type { i32, i1 }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
define dso_local i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %a1)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2echainNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:TopIf", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TopIf", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_2196821906d7172f_ce8d1c9901dd14c3)
  unreachable
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TopIf", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = getelementptr %"compiler/ast:TopBranch", ptr %t20, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t25 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2edeclNames(ptr %v0, ptr %v1, { i64, ptr } %t24, ptr %t25)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/ast:TopIf", ptr %t28, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/ast:TopIf", ptr %t37, i32 0, i32 2
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  br i1 %t42, label %bb10, label %bb11
bb9:
  br label %bb14
bb10:
  call void @__olang_check_failed(ptr @olang_loc_507ed937f609d1d0_9b704622aa820f34)
  unreachable
bb11:
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/ast:TopIf", ptr %t44, i32 0, i32 2
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2echainNames(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/ast:TopIf", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb15, label %bb16
bb15:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/ast:TopIf", ptr %t60, i32 0, i32 3
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb17, label %bb18
bb16:
  br label %bb21
bb17:
  call void @__olang_check_failed(ptr @olang_loc_27f4d264c3bf025_5d55a961c8f61129)
  unreachable
bb18:
  br label %bb19
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/ast:TopIf", ptr %t67, i32 0, i32 3
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t73 = getelementptr %"compiler/ast:TopBranch", ptr %t70, i32 0, i32 1
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t75 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2edeclNames(ptr %v0, ptr %v1, { i64, ptr } %t74, ptr %t75)
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2eclosedCall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Call", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l1, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 5}
  %t19 = icmp eq i64 %t17, 0
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l8, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t22 = load ptr, ptr %l11, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l11, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 5}
  %t28 = icmp eq i64 %t26, 4
  store i1 %t28, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = call i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %t33)
  store i1 %t35, ptr %l17
  br label %bb13
bb13:
  %t36 = load i1, ptr %l17, !tbaa !21
  store i1 %t36, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_317fdf139725c543_9c9e0109f99156f7)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l7 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t9 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %t4)
  store i64 %t9, ptr %l7
  br label %bb1
bb1:
  %t10 = load i64, ptr %l7, !tbaa !24
  store i64 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l23 = alloca i32
  %l26 = alloca i64
  %l31 = alloca ptr
  %l35 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca i32
  %l49 = alloca { i64, ptr }
  %l54 = alloca i1
  %l65 = alloca i32
  %l81 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca i32
  %l96 = alloca ptr
  %rv = alloca ptr
  %t75 = alloca { i64, [5 x i64] }, align 8
  %t128 = alloca { i64, [4 x i64] }, align 8
  %t140 = alloca { i64, [4 x i64] }, align 8
  %t153 = alloca { i64, [5 x i64] }, align 8
  %t192 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t7)
  store i32 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = load i32, ptr %l16, !tbaa !23
  %t13 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t13, ptr %l17
  br label %bb2
bb2:
  %t14 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t15 = load i64, ptr %l17, !tbaa !24
  %t17 = and i64 %t15, %t14
  store i64 %t17, ptr %l5, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l23
  br label %bb3
bb3:
  %t27 = load i32, ptr %l23, !tbaa !23
  store i32 %t27, ptr %l6, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 36
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l26
  br label %bb4
bb4:
  %t33 = load i64, ptr %l26, !tbaa !24
  store i64 %t33, ptr %l7, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 36
  %t37 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t36, ptr %t37)
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 36
  store ptr %t42, ptr %l31, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l1
  %t45 = load i32, ptr %l3, !tbaa !23
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t43, %"compiler/source:Span" %t44, i32 %t45, i64 0)
  store ptr %t49, ptr %l35
  br label %bb6
bb6:
  %t50 = load ptr, ptr %l31, !tbaa !29
  %t51 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t50, ptr %t51)
  br label %bb7
bb7:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l6, !tbaa !23
  %t59 = load i64, ptr %l5, !tbaa !24
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t57, i32 %t58, i64 %t59)
  store i32 %t63, ptr %l41
  br label %bb8
bb8:
  %t64 = load i32, ptr %l41, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l42
  store i32 %t64, ptr %l43, !tbaa !23
  store i32 44, ptr %l44
  store i32 %a4, ptr %l45
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 36
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t70, i64 %t71)
  store { i64, ptr } %t74, ptr %l49
  br label %bb9
bb9:
  store { i64, [5 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 0
  store i64 9, ptr %t76
  %t77 = load %"compiler/source:Span", ptr %l42
  %t78 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t77, 0
  %t79 = load i32, ptr %l43, !tbaa !23
  %t80 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t78, i32 %t79, 1
  %t81 = load i32, ptr %l44, !range !{i32 0, i32 49}
  %t82 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t80, i32 %t81, 2
  %t83 = load i32, ptr %l45, !range !{i32 0, i32 3}
  %t84 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t82, i32 %t83, 3
  %t85 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t86 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t84, { i64, ptr } %t85, 4
  %t87 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t86, ptr %t87
  %t88 = load { i64, [5 x i64] }, ptr %t75
  %t90 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t88, ptr %t90
  store ptr %t90, ptr %l9, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCopies(ptr %v0, ptr %t92, i32 %t93)
  store i1 %t96, ptr %l54
  br label %bb10
bb10:
  %t97 = load i1, ptr %l54, !tbaa !21
  %t98 = xor i1 %t97, true
  br i1 %t98, label %bb11, label %bb12
bb11:
  %t100 = load ptr, ptr %l9, !tbaa !29
  store ptr %t100, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t102 = load i32, ptr %l6, !tbaa !23
  %t103 = load i32, ptr %l3, !tbaa !23
  %t106 = icmp ne i32 %t102, %t103
  br i1 %t106, label %bb14, label %bb15
bb14:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l3, !tbaa !23
  %t115 = load i64, ptr %l5, !tbaa !24
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t113, i32 %t114, i64 %t115)
  store i32 %t119, ptr %l65
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t120 = load i32, ptr %l65, !tbaa !23
  %t121 = load %"compiler/source:Span", ptr %l1
  %t123 = load %"compiler/source:Span", ptr %l1
  %t124 = load i32, ptr %l3, !tbaa !23
  %t125 = load %"compiler/source:Span", ptr %l1
  %t126 = load i32, ptr %l6, !tbaa !23
  %t127 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t128, i32 0, i32 0
  store i64 2, ptr %t129
  %t131 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t125, 0
  %t133 = insertvalue { %"compiler/source:Span", i32, ptr } %t131, i32 %t126, 1
  %t135 = insertvalue { %"compiler/source:Span", i32, ptr } %t133, ptr %t127, 2
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t128, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t135, ptr %t136
  %t137 = load { i64, [4 x i64] }, ptr %t128
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t137, ptr %t139
  store { i64, [4 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 0
  store i64 3, ptr %t141
  %t143 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t123, 0
  %t145 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t143, i32 %t124, 1
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t145, ptr %t139, 2
  %t148 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t147, i64 0, 3
  %t149 = getelementptr { i64, [4 x i64] }, ptr %t140, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t148, ptr %t149
  %t150 = load { i64, [4 x i64] }, ptr %t140
  %t152 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t150, ptr %t152
  store { i64, [5 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t153, i32 0, i32 0
  store i64 3, ptr %t154
  %t156 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t121, 0
  %t158 = insertvalue { %"compiler/source:Span", i32, ptr } %t156, i32 %t120, 1
  %t160 = insertvalue { %"compiler/source:Span", i32, ptr } %t158, ptr %t152, 2
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t153, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t160, ptr %t161
  %t162 = load { i64, [5 x i64] }, ptr %t153
  %t164 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t162, ptr %t164
  store ptr %t164, ptr %rv
  br label %ret
bb17:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  store ptr %t171, ptr %l81, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l3, !tbaa !23
  %t176 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l84
  br label %bb18
bb18:
  %t177 = load ptr, ptr %l81, !tbaa !29
  %t178 = load i32, ptr %l84, !tbaa !23
  %t179 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t179, ptr %l85
  br label %bb19
bb19:
  %t180 = load i32, ptr %l85, !range !{i32 0, i32 33}
  %t182 = trunc i64 19 to i32
  %t183 = icmp eq i32 %t180, %t182
  br i1 %t183, label %bb20, label %bb21
bb20:
  %t185 = load ptr, ptr %l9, !tbaa !29
  store ptr %t185, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l1
  %t189 = load %"compiler/source:Span", ptr %l1
  %t190 = load i32, ptr %l3, !tbaa !23
  %t191 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 0
  store i64 2, ptr %t193
  %t195 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t189, 0
  %t197 = insertvalue { %"compiler/source:Span", i32, ptr } %t195, i32 %t190, 1
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } %t197, ptr %t191, 2
  %t200 = getelementptr { i64, [4 x i64] }, ptr %t192, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t199, ptr %t200
  %t201 = load { i64, [4 x i64] }, ptr %t192
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t201, ptr %t203
  %t207 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t187, %"compiler/source:Span" %t188, ptr %t203)
  store ptr %t207, ptr %l96
  br label %bb23
bb23:
  %t208 = load ptr, ptr %l96, !tbaa !29
  store ptr %t208, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/names:Ref"
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l30 = alloca %"compiler/names:Ref"
  %l34 = alloca i1
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l45 = alloca %"compiler/names:Ref"
  %l48 = alloca i1
  %l54 = alloca { i64, ptr }
  %l60 = alloca i1
  %l63 = alloca i1
  %l66 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i32
  %l76 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca { i64, ptr }
  %l83 = alloca %"compiler/diagmsg:Msg"
  %l84 = alloca i64
  %l90 = alloca i32
  %l95 = alloca i1
  %l97 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l101 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l110 = alloca i64
  %l112 = alloca i64
  %l113 = alloca %"compiler/diagmsg:Msg"
  %l114 = alloca i64
  %l123 = alloca { i64, ptr }
  %l127 = alloca i1
  %l131 = alloca i1
  %l138 = alloca i32
  %l141 = alloca ptr
  %l143 = alloca %"compiler/source:Span"
  %l144 = alloca ptr
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l152 = alloca %"compiler/diagmsg:Msg"
  %l153 = alloca i64
  %l156 = alloca ptr
  %l158 = alloca %"compiler/source:Span"
  %l159 = alloca ptr
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca { i64, ptr }
  %l163 = alloca %"compiler/diagmsg:Msg"
  %l164 = alloca i64
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t24, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb74
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l24, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t35)
  store ptr %t37, ptr %l26
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 2
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t43 = load i32, ptr %t42, !tbaa !23
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t47 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t44, i64 %t41, i32 %t43)
  store %"compiler/names:Ref" %t47, ptr %l30
  br label %bb7
bb7:
  %t48 = load %"compiler/names:Ref", ptr %l30
  store %"compiler/names:Ref" %t48, ptr %l5
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t53 = icmp sgt i64 %t51, 1
  br i1 %t53, label %bb8, label %bb9
bb8:
  %t55 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t56 = load i32, ptr %t55, !range !{i32 0, i32 9}
  %t58 = trunc i64 0 to i32
  %t59 = icmp eq i32 %t56, %t58
  store i1 %t59, ptr %l34, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb10
bb10:
  %t61 = load i1, ptr %l34, !tbaa !21
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l39, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t69)
  store ptr %t71, ptr %l41
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t72 = load ptr, ptr %l41, !tbaa !29
  %t74 = getelementptr %"compiler/check:frame", ptr %t72, i32 0, i32 2
  %t75 = load i64, ptr %t74, !tbaa !24
  %t76 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t81 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t78, i64 %t75, i32 %t77)
  store %"compiler/names:Ref" %t81, ptr %l45
  br label %bb14
bb14:
  %t82 = load %"compiler/names:Ref", ptr %l45
  store %"compiler/names:Ref" %t82, ptr %l5
  br label %bb15
bb15:
  %t83 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t84 = load i32, ptr %t83, !range !{i32 0, i32 9}
  %t86 = trunc i64 0 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb16, label %bb17
bb16:
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t93 = icmp eq i64 %t91, 1
  store i1 %t93, ptr %l48, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb18
bb18:
  %t95 = load i1, ptr %l48, !tbaa !21
  br i1 %t95, label %bb19, label %bb20
bb19:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load %"compiler/source:Span", ptr %l2
  %t98 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t98, ptr %l54, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i32, ptr %t100, i64 0
  %t102 = load i32, ptr %t101, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %t96, %"compiler/source:Span" %t97, i32 %t102)
  br label %bb21
bb20:
  br label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  %t107 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t108 = load i32, ptr %t107, !range !{i32 0, i32 9}
  %t110 = trunc i64 4 to i32
  %t111 = icmp eq i32 %t108, %t110
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb25
bb24:
  %t115 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 2
  %t116 = load i64, ptr %t115, !tbaa !24
  %t118 = icmp slt i64 %t116, 0
  store i1 %t118, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t120 = load i1, ptr %l60, !tbaa !21
  br i1 %t120, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb30
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  store ptr %t126, ptr %l66, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t132 = load i64, ptr %t131, !tbaa !24
  %t133 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 2
  %t134 = load i64, ptr %t133, !tbaa !24
  %t138 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t130, i64 %t132, i64 %t134)
  store i32 %t138, ptr %l71
  br label %bb28
bb28:
  %t139 = load ptr, ptr %l66, !tbaa !29
  %t140 = load i32, ptr %l71, !tbaa !23
  %t141 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t141, ptr %l72
  br label %bb29
bb29:
  %t142 = load i32, ptr %l72, !range !{i32 0, i32 6}
  %t144 = trunc i64 3 to i32
  %t145 = icmp eq i32 %t142, %t144
  %t147 = xor i1 %t145, true
  store i1 %t147, ptr %l63, !tbaa !21
  br label %bb30
bb30:
  %t149 = load i1, ptr %l63, !tbaa !21
  br i1 %t149, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s4
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l76, !tbaa !29
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t151)
  store %"compiler/source:Span" %t153, ptr %l78
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l79, !tbaa !29
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t157 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t155)
  store %"compiler/source:Span" %t157, ptr %l81
  br label %bb34
bb34:
  %t158 = load ptr, ptr %l79, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l81
  %t160 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t158, %"compiler/source:Span" %t159)
  store { i64, ptr } %t160, ptr %l82
  br label %bb35
bb35:
  %t161 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t162 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNotTrait(ptr %v0, ptr %s4, { i64, ptr } %t161)
  store %"compiler/diagmsg:Msg" %t162, ptr %l83
  br label %bb36
bb36:
  %t163 = load ptr, ptr %l76, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l78
  %t165 = load %"compiler/diagmsg:Msg", ptr %l83
  %t166 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t163, %"compiler/source:Span" %t164, %"compiler/diagmsg:Msg" %t165)
  store i64 %t166, ptr %l84
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb38:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t172 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t173 = load i64, ptr %t172, !tbaa !24
  %t174 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 2
  %t175 = load i64, ptr %t174, !tbaa !24
  %t179 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t171, i64 %t173, i64 %t175)
  store i32 %t179, ptr %l90
  br label %bb39
bb39:
  %t180 = load i32, ptr %l90, !tbaa !23
  store i32 %t180, ptr %l6, !tbaa !23
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/check:Checker", ptr %t181, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t185 = load i32, ptr %l6, !tbaa !23
  %t186 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t190 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %t184, i32 %t185, { i64, ptr } %t186)
  store i1 %t190, ptr %l95
  br label %bb40
bb40:
  %t191 = load i1, ptr %l95, !tbaa !21
  %t192 = xor i1 %t191, true
  br i1 %t192, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s5
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l97, !tbaa !29
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t195)
  store %"compiler/source:Span" %t197, ptr %l99
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t199, ptr %l101, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t204 = sub i64 %t202, 1
  %t206 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr i32, ptr %t207, i64 %t204
  %t209 = load i32, ptr %t208, !tbaa !33
  %t212 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t198, i32 %t209)
  store { i64, ptr } %t212, ptr %l106
  br label %bb44
bb44:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t217 = load i32, ptr %l6, !tbaa !23
  %t220 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t216, i32 %t217)
  store i64 %t220, ptr %l110
  br label %bb45
bb45:
  %t221 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t223 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t221)
  store i64 %t223, ptr %l112
  br label %bb46
bb46:
  %t224 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t225 = load i64, ptr %l110, !tbaa !24
  %t226 = load i64, ptr %l112, !tbaa !24
  %t227 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s5, { i64, ptr } %t224, i64 %t225, i64 %t226)
  store %"compiler/diagmsg:Msg" %t227, ptr %l113
  br label %bb47
bb47:
  %t228 = load ptr, ptr %l97, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l99
  %t230 = load %"compiler/diagmsg:Msg", ptr %l113
  %t231 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t228, %"compiler/source:Span" %t229, %"compiler/diagmsg:Msg" %t230)
  store i64 %t231, ptr %l114
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s5)
  store i1 false, ptr %rv
  br label %ret
bb49:
  %t233 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t233, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t235, 0
  store i64 %t237, ptr %l9, !tbaa !24
  br label %bb50
bb50:
  %t239 = load i64, ptr %l8, !tbaa !24
  %t240 = load i64, ptr %l9, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb51, label %bb52
bb51:
  br label %bb63
bb52:
  br label %bb53
bb53:
  %t247 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t247, ptr %l123, !tbaa !27
  %t248 = load i64, ptr %l8, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr ptr, ptr %t251, i64 %t248
  %t253 = load ptr, ptr %t252, !tbaa !39
  store ptr %t253, ptr %l10, !tbaa !29
  %t255 = load ptr, ptr %l10, !tbaa !29
  %t257 = call i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v1, ptr %t255)
  store i1 %t257, ptr %l127
  br label %bb54
bb54:
  %t258 = load i1, ptr %l127, !tbaa !21
  br i1 %t258, label %bb55, label %bb56
bb55:
  br label %bb62
bb56:
  br label %bb57
bb57:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l10, !tbaa !29
  %t264 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %t259, ptr %t260)
  store i1 %t264, ptr %l131
  br label %bb58
bb58:
  %t265 = load i1, ptr %l131, !tbaa !21
  %t266 = xor i1 %t265, true
  br i1 %t266, label %bb59, label %bb60
bb59:
  store i1 false, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t269 = load i64, ptr %l8, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l8, !tbaa !24
  br label %bb50
bb63:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i32, ptr %l6, !tbaa !23
  %t277 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderRequired(ptr %v0, ptr %t273, i32 %t274, i64 0)
  store i32 %t277, ptr %l138
  br label %bb64
bb64:
  %t278 = load i32, ptr %l138, !tbaa !23
  store i32 %t278, ptr %l11, !tbaa !23
  %t279 = load i32, ptr %l11, !tbaa !23
  %t281 = icmp ne i32 %t279, 0
  br i1 %t281, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s11
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l141, !tbaa !29
  %t284 = load ptr, ptr %l1, !tbaa !29
  %t286 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t284)
  store %"compiler/source:Span" %t286, ptr %l143
  br label %bb67
bb66:
  br label %bb73
bb67:
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l144, !tbaa !29
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t288)
  store %"compiler/source:Span" %t290, ptr %l146
  br label %bb68
bb68:
  %t291 = load ptr, ptr %l144, !tbaa !29
  %t292 = load %"compiler/source:Span", ptr %l146
  %t293 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t291, %"compiler/source:Span" %t292)
  store { i64, ptr } %t293, ptr %l147
  br label %bb69
bb69:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i32, ptr %l11, !tbaa !23
  %t298 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s11, ptr %t294, i32 %t295)
  store { i64, ptr } %t298, ptr %l150
  br label %bb70
bb70:
  %t299 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 0
  %t301 = extractvalue { i64, ptr } %t299, 1
  %t302 = mul i64 %t300, 1
  %t303 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t302)
  call void @llvm.memcpy.p0.p0.i64(ptr %t303, ptr %t301, i64 %t302, i1 false)
  %t304 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  %t306 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t308 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyOfBuilderTrait(ptr %v0, ptr %s11, ptr %s11, { i64, ptr } %t306, { i64, ptr } %t305)
  store %"compiler/diagmsg:Msg" %t308, ptr %l152
  br label %bb71
bb71:
  %t309 = load ptr, ptr %l141, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l143
  %t311 = load %"compiler/diagmsg:Msg", ptr %l152
  %t312 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t309, %"compiler/source:Span" %t310, %"compiler/diagmsg:Msg" %t311)
  store i64 %t312, ptr %l153
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s11)
  store i1 false, ptr %rv
  br label %ret
bb73:
  store i1 true, ptr %rv
  br label %ret
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb83
bb77:
  store %olang.scope zeroinitializer, ptr %s12
  %t315 = load ptr, ptr %l0, !tbaa !29
  store ptr %t315, ptr %l156, !tbaa !29
  %t316 = load ptr, ptr %l1, !tbaa !29
  %t318 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t316)
  store %"compiler/source:Span" %t318, ptr %l158
  br label %bb78
bb78:
  %t319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t319, ptr %l159, !tbaa !29
  %t320 = load ptr, ptr %l1, !tbaa !29
  %t322 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t320)
  store %"compiler/source:Span" %t322, ptr %l161
  br label %bb79
bb79:
  %t323 = load ptr, ptr %l159, !tbaa !29
  %t324 = load %"compiler/source:Span", ptr %l161
  %t325 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t323, %"compiler/source:Span" %t324)
  store { i64, ptr } %t325, ptr %l162
  br label %bb80
bb80:
  %t326 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t327 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNotTrait(ptr %v0, ptr %s12, { i64, ptr } %t326)
  store %"compiler/diagmsg:Msg" %t327, ptr %l163
  br label %bb81
bb81:
  %t328 = load ptr, ptr %l156, !tbaa !29
  %t329 = load %"compiler/source:Span", ptr %l158
  %t330 = load %"compiler/diagmsg:Msg", ptr %l163
  %t331 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t328, %"compiler/source:Span" %t329, %"compiler/diagmsg:Msg" %t330)
  store i64 %t331, ptr %l164
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s12)
  store i1 false, ptr %rv
  br label %ret
bb83:
  call void @__olang_check_failed(ptr @olang_loc_f1dda0dd7850fdf4_6d8deef1a8ceb3f0)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca %"compiler/diagmsg:Msg"
  %l20 = alloca i64
  %l23 = alloca ptr
  %l26 = alloca i1
  %l31 = alloca ptr
  %l35 = alloca i32
  %l43 = alloca ptr
  %l46 = alloca i1
  %l48 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l69 = alloca i32
  %l74 = alloca i32
  %l77 = alloca i1
  %l82 = alloca i32
  %l84 = alloca i1
  %l87 = alloca ptr
  %l92 = alloca i32
  %l95 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca i32
  %l100 = alloca i1
  %l108 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l114 = alloca ptr
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca i32
  %l117 = alloca { i64, ptr }
  %l118 = alloca i32
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca i32
  %l122 = alloca { i64, ptr }
  %l124 = alloca %"compiler/source:Span"
  %l125 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l133 = alloca i32
  %l134 = alloca ptr
  %l137 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp slt i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp sgt i64 %t9, 2
  store i1 %t11, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l11, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l15, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t15, ptr %l16
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCountRange(ptr %s1, i64 1, i64 2, i64 %t18)
  store %"compiler/diagmsg:Msg" %t20, ptr %l19
  br label %bb6
bb5:
  br label %bb9
bb6:
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l16
  %t23 = load %"compiler/diagmsg:Msg", ptr %l19
  %t24 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t21, %"compiler/source:Span" %t22, %"compiler/diagmsg:Msg" %t23)
  store i64 %t24, ptr %l20
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t25, %"compiler/source:Span" %t26)
  store ptr %t29, ptr %l23
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  %t30 = load ptr, ptr %l23, !tbaa !29
  store ptr %t30, ptr %rv
  br label %ret
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutOnValue(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  store i1 %t35, ptr %l26
  br label %bb10
bb10:
  %t36 = load i1, ptr %l26, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t37, { i64, ptr } %t38)
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l1
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t41, %"compiler/source:Span" %t42)
  store ptr %t45, ptr %l31
  br label %bb14
bb14:
  %t46 = load ptr, ptr %l31, !tbaa !29
  store ptr %t46, ptr %rv
  br label %ret
bb15:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t52 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t47, ptr %t48)
  store i32 %t52, ptr %l35
  br label %bb16
bb16:
  %t53 = load i32, ptr %l35, !tbaa !23
  store i32 %t53, ptr %l5, !tbaa !23
  %t54 = load i32, ptr %l5, !tbaa !23
  %t55 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t58 = icmp eq i32 %t54, %t55
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t60, { i64, ptr } %t61)
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l1
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t64, %"compiler/source:Span" %t65)
  store ptr %t68, ptr %l43
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l43, !tbaa !29
  store ptr %t69, ptr %rv
  br label %ret
bb21:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l5, !tbaa !23
  %t74 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t70, i32 %t71)
  store i1 %t74, ptr %l46
  br label %bb22
bb22:
  %t75 = load i1, ptr %l46, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb25
bb24:
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t82 = icmp ne i64 %t80, 2
  store i1 %t82, ptr %l48, !tbaa !21
  br label %bb25
bb25:
  %t84 = load i1, ptr %l48, !tbaa !21
  br i1 %t84, label %bb26, label %bb27
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l52, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t86, ptr %l53
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load i32, ptr %l5, !tbaa !23
  %t90 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t91 = load i32, ptr %l4, !tbaa !23
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMake(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %t87, %"compiler/source:Span" %t88, i32 %t89, { i64, ptr } %t90, i32 %t91, ptr null)
  store ptr %t97, ptr %l59
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t98 = load ptr, ptr %l52, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l53
  %t100 = load ptr, ptr %l59, !tbaa !29
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMade(ptr %v0, ptr %v0, ptr %v3, ptr %t98, %"compiler/source:Span" %t99, ptr %t100)
  store ptr %t101, ptr %l60
  br label %bb29
bb29:
  %t102 = load ptr, ptr %l60, !tbaa !29
  store ptr %t102, ptr %rv
  br label %ret
bb30:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t104, ptr %l62, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 1
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t110 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t114 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v3, ptr %t103, ptr %t108, i32 %t110)
  store ptr %t114, ptr %l66
  br label %bb31
bb31:
  %t115 = load ptr, ptr %l66, !tbaa !29
  store ptr %t115, ptr %l6, !tbaa !29
  %t116 = load ptr, ptr %l6, !tbaa !29
  %t119 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t116)
  store i32 %t119, ptr %l69
  br label %bb32
bb32:
  %t120 = load i32, ptr %l69, !tbaa !23
  store i32 %t120, ptr %l7, !tbaa !23
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %l7, !tbaa !23
  %t130 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t126, i32 %t127)
  store i32 %t130, ptr %l74
  br label %bb33
bb33:
  %t131 = load i32, ptr %l74, !range !{i32 0, i32 33}
  %t133 = trunc i64 19 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb34, label %bb35
bb34:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  %t142 = load i32, ptr %l7, !tbaa !23
  %t145 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t141, i32 %t142)
  store i32 %t145, ptr %l82
  br label %bb36
bb35:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb37
bb36:
  %t146 = load i32, ptr %l82, !tbaa !23
  %t147 = icmp ne i32 %t146, 0
  store i1 %t147, ptr %l77, !tbaa !21
  br label %bb37
bb37:
  %t149 = load i1, ptr %l77, !tbaa !21
  br i1 %t149, label %bb38, label %bb39
bb38:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  store ptr %t155, ptr %l87, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  %t162 = load i32, ptr %l7, !tbaa !23
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t161, i32 %t162)
  store i32 %t165, ptr %l92
  br label %bb40
bb39:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb44
bb40:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 2
  store ptr %t171, ptr %l95, !tbaa !29
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l5, !tbaa !23
  %t176 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l98
  br label %bb41
bb41:
  %t177 = load ptr, ptr %l95, !tbaa !29
  %t178 = load i32, ptr %l98, !tbaa !23
  %t179 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t179, ptr %l99
  br label %bb42
bb42:
  %t180 = load ptr, ptr %l87, !tbaa !29
  %t181 = load i32, ptr %l92, !tbaa !23
  %t182 = load i32, ptr %l99, !tbaa !23
  %t183 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t180, i32 %t181, i32 %t182)
  store i1 %t183, ptr %l100
  br label %bb43
bb43:
  %t184 = load i1, ptr %l100, !tbaa !21
  store i1 %t184, ptr %l84, !tbaa !21
  br label %bb44
bb44:
  %t185 = load i1, ptr %l84, !tbaa !21
  br i1 %t185, label %bb45, label %bb46
bb45:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  %t188 = load i32, ptr %l7, !tbaa !23
  %t189 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t190 = load i32, ptr %l4, !tbaa !23
  %t191 = load ptr, ptr %l6, !tbaa !29
  %t199 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMake(ptr %v0, ptr %v2, ptr %v3, ptr %v3, ptr %t186, %"compiler/source:Span" %t187, i32 %t188, { i64, ptr } %t189, i32 %t190, ptr %t191)
  store ptr %t199, ptr %l108
  br label %bb47
bb46:
  br label %bb48
bb47:
  %t200 = load ptr, ptr %l108, !tbaa !29
  store ptr %t200, ptr %rv
  br label %ret
bb48:
  %t201 = load i32, ptr %l7, !tbaa !23
  %t202 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t205 = icmp ne i32 %t201, %t202
  br i1 %t205, label %bb49, label %bb50
bb49:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l112, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t208, ptr %l113
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l114, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t210, ptr %l115
  %t211 = load i32, ptr %l5, !tbaa !23
  store i32 %t211, ptr %l116, !tbaa !23
  %t212 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t212, ptr %l117, !tbaa !27
  %t213 = load i32, ptr %l4, !tbaa !23
  store i32 %t213, ptr %l118, !tbaa !23
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l119, !tbaa !29
  %t215 = load ptr, ptr %l6, !tbaa !29
  store ptr %t215, ptr %l120, !tbaa !29
  %t216 = load i32, ptr %l5, !tbaa !23
  store i32 %t216, ptr %l121, !tbaa !23
  %t217 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t217, ptr %l122, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr ptr, ptr %t219, i64 1
  %t221 = load ptr, ptr %t220, !tbaa !39
  %t223 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t221)
  store %"compiler/source:Span" %t223, ptr %l124
  br label %bb51
bb50:
  br label %bb55
bb51:
  %t224 = load ptr, ptr %l119, !tbaa !29
  %t225 = load ptr, ptr %l120, !tbaa !29
  %t226 = load i32, ptr %l121, !tbaa !23
  %t227 = load %"compiler/source:Span", ptr %l124
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v3, ptr %v0, ptr %t224, ptr %t225, i32 %t226, %"compiler/source:Span" %t227)
  store ptr %t228, ptr %l125
  br label %bb52
bb52:
  %t229 = load ptr, ptr %l125, !tbaa !29
  %t230 = load ptr, ptr %l114, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l115
  %t232 = load i32, ptr %l116, !tbaa !23
  %t233 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t234 = load i32, ptr %l118, !tbaa !23
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMake(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %t230, %"compiler/source:Span" %t231, i32 %t232, { i64, ptr } %t233, i32 %t234, ptr %t229)
  store ptr %t236, ptr %l127
  br label %bb53
bb53:
  %t237 = load ptr, ptr %l112, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l113
  %t239 = load ptr, ptr %l127, !tbaa !29
  %t240 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMade(ptr %v0, ptr %v0, ptr %v3, ptr %t237, %"compiler/source:Span" %t238, ptr %t239)
  store ptr %t240, ptr %l128
  br label %bb54
bb54:
  %t241 = load ptr, ptr %l128, !tbaa !29
  store ptr %t241, ptr %rv
  br label %ret
bb55:
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l129, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t243, ptr %l130, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr ptr, ptr %t245, i64 0
  %t247 = load ptr, ptr %t246, !tbaa !39
  store ptr %t247, ptr %l131, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t248)
  store i32 %t250, ptr %l133
  br label %bb56
bb56:
  %t251 = load ptr, ptr %l129, !tbaa !29
  %t252 = load ptr, ptr %l131, !tbaa !29
  %t253 = load i32, ptr %l133, !tbaa !23
  %t254 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %v0, ptr %t251, ptr %t252, i32 %t253)
  store ptr %t254, ptr %l134
  br label %bb57
bb57:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l1
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t255, %"compiler/source:Span" %t256)
  store ptr %t259, ptr %l137
  br label %bb58
bb58:
  %t260 = load ptr, ptr %l137, !tbaa !29
  store ptr %t260, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatColls(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i32
  %l25 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallArgs(ptr %v0, ptr %v1, ptr %v1, ptr %t5, ptr %a1)
  store { i64, ptr } %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %lp2
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %lp2
  store ptr %t21, ptr %l17, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l19, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 0
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t30 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t27)
  store i32 %t30, ptr %l22
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load i32, ptr %l22, !tbaa !23
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t33, ptr %l23
  br label %bb7
bb7:
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = load i32, ptr %l23, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t34, i32 %t35)
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l25, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 0
  %t41 = load ptr, ptr %t40, !tbaa !39
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatValue(ptr %v0, ptr %v1, ptr %v1, ptr %t36, ptr %t41)
  store ptr %t44, ptr %l27
  br label %bb9
bb9:
  %t45 = load ptr, ptr %l27, !tbaa !29
  store ptr %t45, ptr %l4, !tbaa !29
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t56 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatColls(ptr %v0, ptr %v1, ptr %s3, ptr %t52, ptr %t53)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l33
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t58 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %t58
  store ptr %t58, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %l35, !tbaa !24
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s3, ptr %t61)
  store i64 %t63, ptr %l37
  br label %bb14
bb14:
  %t64 = load i64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l37, !tbaa !24
  %t66 = icmp slt i64 %t64, %t65
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  br label %bb21
bb16:
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s3, ptr %t70, i64 %t71)
  store i32 %t74, ptr %l42
  br label %bb18
bb18:
  %t75 = load i32, ptr %l42, !tbaa !23
  %t76 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t76, i32 %t75)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l6, !tbaa !24
  br label %bb13
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t84 = load ptr, ptr %lp2
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aGlobal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l16 = alloca i64
  %l17 = alloca i32
  %l24 = alloca i1
  %l29 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:b5aWalk", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 27
  store ptr %t8, ptr %l11, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = sext i32 %a3 to i64
  %t15 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t9, i64 %t12)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t15, ptr %l15
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l15
  %t18 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t16, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t17)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l17
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb6, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l16
  br label %bb5
bb5:
  %t23 = load i64, ptr %l16, !tbaa !24
  store i64 %t23, ptr %l9, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t24 = load i64, ptr %l9, !tbaa !24
  store i64 %t24, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/check:b5aWalk", ptr %t30, i32 0, i32 0
  %t33 = load i64, ptr %t32, !tbaa !24
  %t36 = icmp eq i64 %t29, %t33
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/check:b5aWalk", ptr %t40, i32 0, i32 3
  %t46 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t42, i64 %t38)
  store i1 %t46, ptr %l29
  br label %bb14
bb13:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb15
bb14:
  %t47 = load i1, ptr %l29, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t50 = load i1, ptr %l24, !tbaa !21
  br i1 %t50, label %bb16, label %bb17
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/check:b5aWalk", ptr %t51, i32 0, i32 3
  %t54 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t53, i64 %t54)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/check:b5aWalk", ptr %t57, i32 0, i32 4
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %t59, i64 %t60)
  store i1 %t63, ptr %l37
  br label %bb20
bb20:
  %t64 = load i1, ptr %l37, !tbaa !21
  %t65 = xor i1 %t64, true
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %t67, i32 %a4, i64 0)
  store i1 %t71, ptr %l42
  br label %bb23
bb22:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb24
bb23:
  %t72 = load i1, ptr %l42, !tbaa !21
  store i1 %t72, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t73 = load i1, ptr %l39, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/check:b5aWalk", ptr %t74, i32 0, i32 4
  %t77 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t76, i64 %t77, i1 true)
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/check:b5aWalk", ptr %t80, i32 0, i32 6
  store i1 true, ptr %t82, !tbaa !21
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %t83, ptr %t84, i64 %t85)
  br label %bb28
bb28:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/check:b5aWalk", ptr %t89, i32 0, i32 6
  store i1 false, ptr %t91, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a2)
  store ptr %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l13, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 11
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_76c98d42818871e4_51853c380fcafc70)
  unreachable
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Body", ptr %t23, i32 0, i32 11
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Block", ptr %t26, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  br label %bb38
bb10:
  br label %bb11
bb11:
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t44, ptr %l30, !tbaa !27
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l7, !tbaa !29
  %t52 = load ptr, ptr %l7, !tbaa !29
  store ptr %t52, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t53 = load ptr, ptr %l33, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 17}
  %t59 = icmp eq i64 %t57, 1
  store i1 %t59, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t60 = load i1, ptr %l34, !tbaa !21
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t61 = load ptr, ptr %l7, !tbaa !29
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t63, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l8, !tbaa !29
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t69 = getelementptr { i64, [3 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l9, !tbaa !29
  br label %bb16
bb15:
  br label %bb30
bb16:
  %t73 = load ptr, ptr %l8, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t74 = load ptr, ptr %l41, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb17, label %bb18
bb17:
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 8}
  %t80 = icmp eq i64 %t78, 1
  store i1 %t80, ptr %l42, !tbaa !21
  br label %bb18
bb18:
  %t81 = load i1, ptr %l42, !tbaa !21
  br i1 %t81, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t84 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t82, ptr %t83, ptr %t84)
  br label %bb22
bb22:
  br label %bb29
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t91 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v0, ptr %t89, ptr %t90, ptr %t91)
  br label %bb27
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_5b6dfd884f12314a_d55d816e86cc2196)
  unreachable
bb29:
  br label %bb36
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t98 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v0, ptr %t96, ptr %t97, ptr %t98)
  br label %bb34
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_fdeda218c1a4d1e1_676c59a9a8adaaad)
  unreachable
bb36:
  br label %bb37
bb37:
  %t103 = load i64, ptr %l5, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l5, !tbaa !24
  br label %bb8
bb38:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecPointerArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l22 = alloca i32
  %l26 = alloca i1
  %l33 = alloca i32
  %l36 = alloca i32
  %l39 = alloca i1
  %l42 = alloca i1
  %l49 = alloca i32
  %l52 = alloca i1
  %l55 = alloca i1
  %l60 = alloca ptr
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l72 = alloca i32
  %l75 = alloca i1
  %l78 = alloca i1
  %l83 = alloca i32
  %l84 = alloca i32
  %l88 = alloca i32
  %l90 = alloca i1
  %l91 = alloca i32
  %l95 = alloca i32
  %l102 = alloca i1
  %l103 = alloca i1
  %l104 = alloca ptr
  %l107 = alloca i32
  %l108 = alloca i1
  %l109 = alloca i1
  %l114 = alloca i32
  %l121 = alloca i32
  %l124 = alloca ptr
  %l125 = alloca i32
  %l128 = alloca i32
  %l129 = alloca i1
  %l130 = alloca i1
  %l131 = alloca ptr
  %l134 = alloca i32
  %l135 = alloca i1
  %l140 = alloca ptr
  %l144 = alloca i1
  %l145 = alloca i1
  %l148 = alloca i1
  %l149 = alloca i1
  %l150 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca i1
  %l155 = alloca i1
  %l158 = alloca i1
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_7362f3ae74bf0a7_8f389ee36c95dce3)
  unreachable
bb11:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t13 = xor i1 %t10, true
  br i1 %t13, label %bb12, label %bb13
bb12:
  store ptr null, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t16)
  store i32 %t19, ptr %l22
  br label %bb15
bb15:
  %t20 = load i32, ptr %l22, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = load i32, ptr %l6, !tbaa !23
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t25 = icmp eq i32 %t21, %t22
  br i1 %t25, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb18
bb17:
  %t27 = load i32, ptr %l6, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  store i1 %t31, ptr %l26, !tbaa !21
  br label %bb18
bb18:
  %t33 = load i1, ptr %l26, !tbaa !21
  br i1 %t33, label %bb19, label %bb20
bb19:
  store ptr null, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l6, !tbaa !23
  %t39 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l33
  br label %bb22
bb22:
  %t40 = load i32, ptr %l33, !tbaa !23
  store i32 %t40, ptr %l7, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l7, !tbaa !23
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l36
  br label %bb23
bb23:
  %t46 = load i32, ptr %l36, !tbaa !23
  store i32 %t46, ptr %l8, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecVoidRef(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l39
  br label %bb24
bb24:
  %t52 = load i1, ptr %l39, !tbaa !21
  br i1 %t52, label %bb25, label %bb26
bb25:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l6, !tbaa !23
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l42
  br label %bb27
bb26:
  br label %bb40
bb27:
  %t58 = load i1, ptr %l42, !tbaa !21
  br i1 %t58, label %bb28, label %bb29
bb28:
  %t59 = load ptr, ptr %l2, !tbaa !29
  store ptr %t59, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l8, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l49
  br label %bb31
bb31:
  %t72 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t74 = trunc i64 19 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb35
bb33:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i32, ptr %l7, !tbaa !23
  %t81 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t77, i32 %t78, i64 0)
  store i1 %t81, ptr %l55
  br label %bb34
bb34:
  %t82 = load i1, ptr %l55, !tbaa !21
  store i1 %t82, ptr %l52, !tbaa !21
  br label %bb35
bb35:
  %t83 = load i1, ptr %l52, !tbaa !21
  br i1 %t83, label %bb36, label %bb37
bb36:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t86 = load i32, ptr %l3, !tbaa !23
  %t87 = load %"compiler/source:Span", ptr %l4
  %t92 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecBorrow(ptr %v0, ptr %v2, ptr %v3, ptr %t84, ptr %t85, i32 %t86, %"compiler/source:Span" %t87)
  store ptr %t92, ptr %l60
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t93 = load ptr, ptr %l60, !tbaa !29
  store ptr %t93, ptr %rv
  br label %ret
bb39:
  store ptr null, ptr %rv
  br label %ret
bb40:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l63, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t97, i32 %t98)
  store i32 %t101, ptr %l66
  br label %bb41
bb41:
  %t102 = load ptr, ptr %l63, !tbaa !29
  %t103 = load i32, ptr %l66, !tbaa !23
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t104, ptr %l67
  br label %bb42
bb42:
  %t105 = load i32, ptr %l67, !tbaa !23
  store i32 %t105, ptr %l9, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l9, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l72
  br label %bb43
bb43:
  %t116 = load i32, ptr %l72, !range !{i32 0, i32 33}
  %t118 = trunc i64 19 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb44, label %bb45
bb44:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l6, !tbaa !23
  %t125 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCStrRef(ptr %v0, ptr %t121, i32 %t122)
  store i1 %t125, ptr %l78
  br label %bb46
bb45:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb47
bb46:
  %t126 = load i1, ptr %l78, !tbaa !21
  store i1 %t126, ptr %l75, !tbaa !21
  br label %bb47
bb47:
  %t127 = load i1, ptr %l75, !tbaa !21
  br i1 %t127, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %l9, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t137, ptr %l83
  br label %bb50
bb49:
  br label %bb59
bb50:
  %t138 = load i32, ptr %l83, !tbaa !23
  store i32 %t138, ptr %l10, !tbaa !23
  %t139 = load i32, ptr %l10, !tbaa !23
  store i32 %t139, ptr %l84, !tbaa !23
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s8, ptr %t145, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i32 %t147, ptr %l88
  br label %bb51
bb51:
  %t148 = load i32, ptr %l84, !tbaa !23
  %t149 = load i32, ptr %l88, !tbaa !23
  %t150 = icmp eq i32 %t148, %t149
  br i1 %t150, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb55
bb53:
  %t152 = load i32, ptr %l10, !tbaa !23
  store i32 %t152, ptr %l91, !tbaa !23
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/check:Checker", ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 2
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s8, ptr %t158, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t160, ptr %l95
  br label %bb54
bb54:
  %t161 = load i32, ptr %l91, !tbaa !23
  %t162 = load i32, ptr %l95, !tbaa !23
  %t163 = icmp eq i32 %t161, %t162
  store i1 %t163, ptr %l90, !tbaa !21
  br label %bb55
bb55:
  %t165 = load i1, ptr %l90, !tbaa !21
  br i1 %t165, label %bb56, label %bb57
bb56:
  %t166 = load ptr, ptr %l2, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  store ptr %t166, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s8)
  store ptr null, ptr %rv
  br label %ret
bb59:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l3, !tbaa !23
  %t174 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t170, i32 %t171)
  store i1 %t174, ptr %l102
  br label %bb60
bb60:
  %t175 = load i1, ptr %l102, !tbaa !21
  br i1 %t175, label %bb61, label %bb62
bb61:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l104, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l3, !tbaa !23
  %t181 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t177, i32 %t178)
  store i32 %t181, ptr %l107
  br label %bb63
bb62:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb65
bb63:
  %t182 = load ptr, ptr %l104, !tbaa !29
  %t183 = load i32, ptr %l107, !tbaa !23
  %t184 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecStruct(ptr %v0, ptr %t182, i32 %t183)
  store i1 %t184, ptr %l108
  br label %bb64
bb64:
  %t185 = load i1, ptr %l108, !tbaa !21
  store i1 %t185, ptr %l103, !tbaa !21
  br label %bb65
bb65:
  %t186 = load i1, ptr %l103, !tbaa !21
  br i1 %t186, label %bb66, label %bb67
bb66:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Program", ptr %t190, i32 0, i32 2
  %t193 = load i32, ptr %l8, !tbaa !23
  %t196 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t196, ptr %l114
  br label %bb68
bb67:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb69
bb68:
  %t197 = load i32, ptr %l114, !range !{i32 0, i32 33}
  %t199 = trunc i64 19 to i32
  %t200 = icmp eq i32 %t197, %t199
  store i1 %t200, ptr %l109, !tbaa !21
  br label %bb69
bb69:
  %t202 = load i1, ptr %l109, !tbaa !21
  br i1 %t202, label %bb70, label %bb71
bb70:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/generic:Program", ptr %t206, i32 0, i32 2
  %t209 = load i32, ptr %l8, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t208, i32 %t209)
  store i32 %t212, ptr %l121
  br label %bb72
bb71:
  br label %bb84
bb72:
  %t213 = load i32, ptr %l121, !tbaa !23
  store i32 %t213, ptr %l11, !tbaa !23
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = getelementptr %"compiler/generic:Program", ptr %t217, i32 0, i32 2
  store ptr %t219, ptr %l124, !tbaa !29
  %t220 = load i32, ptr %l11, !tbaa !23
  store i32 %t220, ptr %l125, !tbaa !23
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load i32, ptr %l3, !tbaa !23
  %t225 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l128
  br label %bb73
bb73:
  %t226 = load ptr, ptr %l124, !tbaa !29
  %t227 = load i32, ptr %l125, !tbaa !23
  %t228 = load i32, ptr %l128, !tbaa !23
  %t229 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t226, i32 %t227, i32 %t228)
  store i1 %t229, ptr %l129
  br label %bb74
bb74:
  %t230 = load i1, ptr %l129, !tbaa !21
  br i1 %t230, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb79
bb76:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l131, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load i32, ptr %l11, !tbaa !23
  %t236 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t232, i32 %t233)
  store i32 %t236, ptr %l134
  br label %bb77
bb77:
  %t237 = load ptr, ptr %l131, !tbaa !29
  %t238 = load i32, ptr %l134, !tbaa !23
  %t239 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecNumber(ptr %v0, ptr %t237, i32 %t238)
  store i1 %t239, ptr %l135
  br label %bb78
bb78:
  %t240 = load i1, ptr %l135, !tbaa !21
  store i1 %t240, ptr %l130, !tbaa !21
  br label %bb79
bb79:
  %t241 = load i1, ptr %l130, !tbaa !21
  br i1 %t241, label %bb80, label %bb81
bb80:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l2, !tbaa !29
  %t244 = load i32, ptr %l3, !tbaa !23
  %t245 = load %"compiler/source:Span", ptr %l4
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecBorrow(ptr %v0, ptr %v2, ptr %v3, ptr %t242, ptr %t243, i32 %t244, %"compiler/source:Span" %t245)
  store ptr %t250, ptr %l140
  br label %bb82
bb81:
  br label %bb83
bb82:
  %t251 = load ptr, ptr %l140, !tbaa !29
  store ptr %t251, ptr %rv
  br label %ret
bb83:
  br label %bb84
bb84:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load i32, ptr %l3, !tbaa !23
  %t257 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t253, i32 %t254)
  store i1 %t257, ptr %l144
  br label %bb85
bb85:
  %t258 = load i1, ptr %l144, !tbaa !21
  br i1 %t258, label %bb86, label %bb87
bb86:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i32, ptr %l6, !tbaa !23
  %t263 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecVoidRef(ptr %v0, ptr %t259, i32 %t260)
  store i1 %t263, ptr %l148
  br label %bb88
bb87:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb89
bb88:
  %t264 = load i1, ptr %l148, !tbaa !21
  store i1 %t264, ptr %l145, !tbaa !21
  br label %bb89
bb89:
  %t265 = load i1, ptr %l145, !tbaa !21
  br i1 %t265, label %bb90, label %bb91
bb90:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l150, !tbaa !29
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t268 = load i32, ptr %l3, !tbaa !23
  %t271 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t267, i32 %t268)
  store i32 %t271, ptr %l153
  br label %bb92
bb91:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb98
bb92:
  %t272 = load ptr, ptr %l150, !tbaa !29
  %t273 = load i32, ptr %l153, !tbaa !23
  %t274 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecStruct(ptr %v0, ptr %t272, i32 %t273)
  store i1 %t274, ptr %l154
  br label %bb93
bb93:
  %t275 = load i1, ptr %l154, !tbaa !21
  br i1 %t275, label %bb94, label %bb95
bb94:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb97
bb95:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load i32, ptr %l3, !tbaa !23
  %t280 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %t276, i32 %t277)
  store i1 %t280, ptr %l158
  br label %bb96
bb96:
  %t281 = load i1, ptr %l158, !tbaa !21
  store i1 %t281, ptr %l155, !tbaa !21
  br label %bb97
bb97:
  %t282 = load i1, ptr %l155, !tbaa !21
  store i1 %t282, ptr %l149, !tbaa !21
  br label %bb98
bb98:
  %t283 = load i1, ptr %l149, !tbaa !21
  br i1 %t283, label %bb99, label %bb100
bb99:
  %t284 = load ptr, ptr %l2, !tbaa !29
  store ptr %t284, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseNameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i32
  %l9 = alloca { i64, ptr }
  %l13 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:CaseDecl", ptr %t1, i32 0, i32 0
  %t4 = getelementptr %"compiler/source:Span", ptr %t3, i32 0, i32 0
  %t5 = load i32, ptr %t4, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:CaseDecl", ptr %t6, i32 0, i32 0
  %t9 = getelementptr %"compiler/source:Span", ptr %t8, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  store i32 %t10, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/ast:CaseDecl", ptr %t12, i32 0, i32 1
  %t15 = load i32, ptr %t14, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %a0, i32 %t15)
  store { i64, ptr } %t18, ptr %l9
  br label %bb1
bb1:
  %t19 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t22 = trunc i64 %t20 to i32
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = add i32 %t23, %t22
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t26, i32 %t25)
  store %"compiler/source:Span" %t28, ptr %l13
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t29, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local { ptr, i32, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l16 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l28 = alloca ptr
  %l30 = alloca i32
  %l35 = alloca ptr
  %l43 = alloca i1
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca i32
  %l59 = alloca i32
  %l64 = alloca i64
  %l69 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i32
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca ptr
  %l84 = alloca i64
  %l97 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %rv = alloca { ptr, i32, i32 }
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a3, ptr %l5, !tbaa !23
  store i32 %a4, ptr %l6, !tbaa !23
  %t5 = load i32, ptr %l6, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t15 = icmp ne i32 %t11, %t12
  store i1 %t15, ptr %l16, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l16, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v2, ptr %t18, ptr %t19)
  store i1 %t22, ptr %l23
  br label %bb6
bb5:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  %t23 = load i1, ptr %l23, !tbaa !21
  store i1 %t23, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l20, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v2, ptr %t25, ptr %t26, i32 %t28)
  store ptr %t32, ptr %l28
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t33 = load ptr, ptr %l28, !tbaa !29
  %t35 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t33)
  store i32 %t35, ptr %l30
  br label %bb11
bb11:
  %t36 = load i32, ptr %l30, !tbaa !23
  store i32 %t36, ptr %l6, !tbaa !23
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = load i32, ptr %l5, !tbaa !23
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v3, ptr %t37, ptr %t38, i32 %t40)
  store ptr %t44, ptr %l35
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l35, !tbaa !29
  store ptr %t45, ptr %l7, !tbaa !29
  %t46 = load i32, ptr %l6, !tbaa !23
  %t47 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t50 = icmp eq i32 %t46, %t47
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t52 = load i32, ptr %l5, !tbaa !23
  store i32 %t52, ptr %l6, !tbaa !23
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t54 = load i32, ptr %l5, !tbaa !23
  %t55 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t58 = icmp eq i32 %t54, %t55
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t60 = load ptr, ptr %l7, !tbaa !29
  %t63 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t60)
  store i32 %t63, ptr %l46
  br label %bb19
bb18:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb20
bb19:
  %t64 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t65 = load i32, ptr %l46, !tbaa !23
  %t67 = icmp ne i32 %t65, %t64
  store i1 %t67, ptr %l43, !tbaa !21
  br label %bb20
bb20:
  %t69 = load i1, ptr %l43, !tbaa !21
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t70 = load ptr, ptr %l7, !tbaa !29
  %t73 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t70)
  store i32 %t73, ptr %l52
  br label %bb23
bb22:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb24
bb23:
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t75 = load i32, ptr %l52, !tbaa !23
  %t77 = icmp ne i32 %t75, %t74
  store i1 %t77, ptr %l49, !tbaa !21
  br label %bb24
bb24:
  %t79 = load i1, ptr %l49, !tbaa !21
  br i1 %t79, label %bb25, label %bb26
bb25:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l7, !tbaa !29
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t88 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstValueType(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t80, ptr %a1, ptr %t82, ptr %t83)
  store i32 %t88, ptr %l59
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t89 = load i32, ptr %l59, !tbaa !23
  store i32 %t89, ptr %l5, !tbaa !23
  br label %bb28
bb28:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/load:Loader", ptr %t96, i32 0, i32 4
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t99)
  store i64 %t101, ptr %l64
  br label %bb29
bb29:
  %t102 = load i64, ptr %l64, !tbaa !24
  store i64 %t102, ptr %l8, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 4
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l69
  br label %bb30
bb30:
  %t115 = load i64, ptr %l69, !tbaa !24
  store i64 %t115, ptr %l9, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l70, !tbaa !29
  %t117 = load ptr, ptr %l7, !tbaa !29
  store ptr %t117, ptr %l71, !tbaa !29
  %t118 = load i32, ptr %l5, !tbaa !23
  store i32 %t118, ptr %l72, !tbaa !23
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t119)
  store %"compiler/source:Span" %t121, ptr %l74
  br label %bb31
bb31:
  %t122 = load ptr, ptr %l70, !tbaa !29
  %t123 = load ptr, ptr %l71, !tbaa !29
  %t124 = load i32, ptr %l72, !tbaa !23
  %t125 = load %"compiler/source:Span", ptr %l74
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v3, ptr %v3, ptr %t122, ptr %t123, i32 %t124, %"compiler/source:Span" %t125)
  store ptr %t126, ptr %l75
  br label %bb32
bb32:
  %t127 = load ptr, ptr %l75, !tbaa !29
  store ptr %t127, ptr %l10, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/load:Loader", ptr %t134, i32 0, i32 4
  %t137 = load ptr, ptr %t136, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t137)
  br label %bb33
bb33:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 0
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/load:Loader", ptr %t145, i32 0, i32 4
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t148)
  store i64 %t150, ptr %l84
  br label %bb34
bb34:
  %t151 = load i64, ptr %l8, !tbaa !24
  %t152 = load i64, ptr %l84, !tbaa !24
  %t154 = icmp eq i64 %t152, %t151
  br i1 %t154, label %bb35, label %bb36
bb35:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 0
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/load:Loader", ptr %t162, i32 0, i32 4
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t166 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t165, i64 %t166)
  br label %bb37
bb36:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = getelementptr %"compiler/generic:Program", ptr %t172, i32 0, i32 0
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t177 = getelementptr %"compiler/load:Loader", ptr %t175, i32 0, i32 4
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t179 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t178, i64 %t179)
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l97, !tbaa !29
  %t183 = load ptr, ptr %l2, !tbaa !29
  %t185 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t183)
  store %"compiler/source:Span" %t185, ptr %l99
  br label %bb39
bb39:
  %t186 = load i32, ptr %l6, !tbaa !23
  %t187 = load i32, ptr %l5, !tbaa !23
  %t188 = load ptr, ptr %l10, !tbaa !29
  %t189 = load ptr, ptr %l97, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l99
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchValueMismatch(ptr %v0, ptr %v3, ptr %t189, %"compiler/source:Span" %t190, i32 %t186, i32 %t187, ptr %t188)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t194 = load ptr, ptr %l10, !tbaa !29
  %t195 = load i32, ptr %l5, !tbaa !23
  %t196 = load i32, ptr %l6, !tbaa !23
  %t198 = insertvalue { ptr, i32, i32 } undef, ptr %t194, 0
  %t200 = insertvalue { ptr, i32, i32 } %t198, i32 %t195, 1
  %t202 = insertvalue { ptr, i32, i32 } %t200, i32 %t196, 2
  store { ptr, i32, i32 } %t202, ptr %rv
  br label %ret
ret:
  %rr = load { ptr, i32, i32 }, ptr %rv
  ret { ptr, i32, i32 } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseZero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l33 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i1
  %l56 = alloca { i64, ptr }
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l64 = alloca %"compiler/typed:Make"
  %rv = alloca ptr
  %t106 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l16, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %a3)
  store i32 %t16, ptr %l21
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = load i32, ptr %l21, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 36
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l25
  br label %bb3
bb3:
  %t26 = load i64, ptr %l25, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  store i1 true, ptr %l6, !tbaa !21
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb5, label %bb6
bb5:
  br label %bb25
bb6:
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t41, ptr %l33, !tbaa !27
  %t42 = load i64, ptr %l8, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i32, ptr %t45, i64 %t42
  %t47 = load i32, ptr %t46, !tbaa !33
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t49, %"compiler/source:Span" %t50, i32 %t47)
  store ptr %t55, ptr %l39
  br label %bb8
bb8:
  %t56 = load ptr, ptr %l39, !tbaa !29
  store ptr %t56, ptr %l11, !tbaa !29
  %t57 = load ptr, ptr %l11, !tbaa !29
  store ptr %t57, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t58 = load ptr, ptr %l40, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb9, label %bb10
bb9:
  %t61 = load ptr, ptr %l40, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 18}
  %t64 = icmp eq i64 %t62, 0
  store i1 %t64, ptr %l41, !tbaa !21
  br label %bb10
bb10:
  %t65 = load i1, ptr %l41, !tbaa !21
  br i1 %t65, label %bb11, label %bb12
bb11:
  %t66 = load ptr, ptr %l11, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t68, i32 0, i32 2
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l12, !tbaa !24
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t72 = load i64, ptr %l12, !tbaa !24
  %t74 = icmp ne i64 %t72, 0
  br i1 %t74, label %bb14, label %bb15
bb14:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ea1bc73a77e68519_ca6969815981751d)
  unreachable
bb22:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 36
  %t79 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t78, ptr %t79)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb4
bb25:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 36
  %t89 = load i64, ptr %l5, !tbaa !24
  %t92 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t88, i64 %t89)
  store { i64, ptr } %t92, ptr %l56
  br label %bb26
bb26:
  %t93 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t93, ptr %l13, !tbaa !27
  %t94 = load i1, ptr %l6, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  store ptr null, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t97 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t97, ptr %l59
  store i32 %a2, ptr %l60, !tbaa !23
  %t99 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t103 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v1, ptr %v1, ptr %v1, i32 1, i64 0, { i64, ptr } %t99, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t103, ptr %l64
  br label %bb30
bb30:
  %t104 = load %"compiler/typed:Make", ptr %l64
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/typed:Make" %t104, ptr %t105
  store { i64, [5 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 0
  store i64 7, ptr %t107
  %t108 = load %"compiler/source:Span", ptr %l59
  %t109 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t108, 0
  %t110 = load i32, ptr %l60, !tbaa !23
  %t111 = insertvalue { %"compiler/source:Span", i32, ptr } %t109, i32 %t110, 1
  %t113 = insertvalue { %"compiler/source:Span", i32, ptr } %t111, ptr %t105, 2
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t113, ptr %t114
  %t115 = load { i64, [5 x i64] }, ptr %t106
  %t117 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t115, ptr %t117
  store ptr %t117, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:altsCovered" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtAlts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %lp6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/check:payloadItem"
  %l21 = alloca ptr
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp23 = alloca ptr
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca i1
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l61 = alloca i1
  %l64 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l68 = alloca %"compiler/diagmsg:Msg"
  %l69 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l79 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca i32
  %l82 = alloca i1
  %l83 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l86 = alloca %"compiler/diagmsg:Msg"
  %l87 = alloca i64
  %l95 = alloca i1
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca i64
  %l104 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l107 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l116 = alloca %"compiler/diagmsg:Msg"
  %l117 = alloca i64
  %l122 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l125 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l127 = alloca i64
  %l129 = alloca i64
  %l134 = alloca %"compiler/check:payloadItem"
  %l136 = alloca i1
  %l138 = alloca i1
  %l139 = alloca i1
  %l141 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i1
  %l151 = alloca ptr
  %l152 = alloca i1
  %l157 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l160 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l161 = alloca i32
  %l163 = alloca i1
  %l164 = alloca ptr
  %l166 = alloca %"compiler/source:Span"
  %l167 = alloca %"compiler/diagmsg:Msg"
  %l168 = alloca i64
  %l172 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l174 = alloca i64
  %l176 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l179 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l188 = alloca %"compiler/diagmsg:Msg"
  %l189 = alloca i64
  %l194 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l195 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca %"compiler/diagmsg:Msg"
  %l199 = alloca i64
  %l202 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l204 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l208 = alloca %"compiler/check:altsCovered"
  %l210 = alloca %"compiler/check:altsCovered"
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca %"compiler/check:altsCovered"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l24
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t2, ptr %lp6
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  %t4 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store i1 false, ptr %l7, !tbaa !21
  store i1 false, ptr %l8, !tbaa !21
  store i1 true, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:Case", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l13, !tbaa !24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = load i64, ptr %l13, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb117
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t22, ptr %l33, !tbaa !27
  %t23 = load i64, ptr %l12, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l14, !tbaa !29
  %t30 = load ptr, ptr %l14, !tbaa !29
  store ptr %t30, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t31 = load ptr, ptr %l36, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l36, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 9}
  %t37 = icmp eq i64 %t35, 0
  store i1 %t37, ptr %l37, !tbaa !21
  br label %bb7
bb7:
  %t38 = load i1, ptr %l37, !tbaa !21
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Case", ptr %t39, i32 0, i32 3
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  br i1 %t44, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb13
bb12:
  br label %bb13
bb13:
  store i1 true, ptr %l7, !tbaa !21
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %lp6
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t47
  %t50 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %t50
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %v4, ptr %v3, ptr %v4, ptr %t46, ptr %t50, ptr %t51)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l47
  br label %bb14
bb14:
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  %t57 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %t57
  br label %bb115
bb15:
  %t58 = load ptr, ptr %l14, !tbaa !29
  store ptr %t58, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t59 = load ptr, ptr %l48, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %l48, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 9}
  %t65 = icmp eq i64 %t63, 1
  store i1 %t65, ptr %l49, !tbaa !21
  br label %bb17
bb17:
  %t66 = load i1, ptr %l49, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t67 = load ptr, ptr %l14, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr }, ptr %t69, i32 0, i32 1
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l15, !tbaa !29
  br label %bb24
bb19:
  %t73 = load ptr, ptr %l14, !tbaa !29
  store ptr %t73, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t74 = load ptr, ptr %l54, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb20, label %bb21
bb20:
  %t77 = load ptr, ptr %l54, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 9}
  %t80 = icmp eq i64 %t78, 4
  store i1 %t80, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t81 = load i1, ptr %l55, !tbaa !21
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t82 = load ptr, ptr %l14, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", ptr }, ptr %t84, i32 0, i32 1
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l15, !tbaa !29
  br label %bb24
bb23:
  br label %bb34
bb24:
  %t88 = load ptr, ptr %l15, !tbaa !29
  %t90 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t88)
  store i1 %t90, ptr %l61
  br label %bb25
bb25:
  %t91 = load i1, ptr %l61, !tbaa !21
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t94 = xor i1 %a4, true
  br i1 %t94, label %bb28, label %bb29
bb27:
  br label %bb34
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l64, !tbaa !29
  %t97 = load ptr, ptr %l14, !tbaa !29
  %t99 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t97)
  store %"compiler/source:Span" %t99, ptr %l66
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t100 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t102 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %v2, ptr %s6, { i64, ptr } %t100)
  store %"compiler/diagmsg:Msg" %t102, ptr %l68
  br label %bb31
bb31:
  %t103 = load ptr, ptr %l64, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l66
  %t105 = load %"compiler/diagmsg:Msg", ptr %l68
  %t106 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t103, %"compiler/source:Span" %t104, %"compiler/diagmsg:Msg" %t105)
  store i64 %t106, ptr %l69
  br label %bb32
bb32:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb115
bb34:
  %t107 = load ptr, ptr %l14, !tbaa !29
  store ptr %t107, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t108 = load ptr, ptr %l70, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb35, label %bb36
bb35:
  %t111 = load ptr, ptr %l70, !tbaa !29
  %t112 = load i64, ptr %t111, !range !{i64 0, i64 9}
  %t114 = icmp eq i64 %t112, 2
  store i1 %t114, ptr %l71, !tbaa !21
  br label %bb36
bb36:
  %t115 = load i1, ptr %l71, !tbaa !21
  br i1 %t115, label %bb37, label %bb38
bb37:
  %t116 = load ptr, ptr %l14, !tbaa !29
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t118, i32 0, i32 1
  %t120 = load ptr, ptr %t119
  store ptr %t120, ptr %l16, !tbaa !29
  br label %bb39
bb38:
  br label %bb79
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l16, !tbaa !29
  %t126 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %s7, ptr %t122, ptr %t123)
  %t127 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t126, 1
  %t128 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t126, 0
  store i32 %t128, ptr %l80
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb41, label %ok.130, !prof !99
ok.130:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %l79
  br label %bb40
bb40:
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l79
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %l76
  br label %bb46
bb41:
  %t132 = load i32, ptr %l80, !tbaa !23
  %t133 = ashr i32 %t132, 16
  %t135 = icmp eq i32 %t133, 1
  store i1 %t135, ptr %l82, !tbaa !21
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l83, !tbaa !29
  %t137 = load ptr, ptr %l14, !tbaa !29
  %t139 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t137)
  store %"compiler/source:Span" %t139, ptr %l85
  br label %bb43
bb43:
  %t140 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %s8)
  store %"compiler/diagmsg:Msg" %t140, ptr %l86
  br label %bb44
bb44:
  %t141 = load ptr, ptr %l83, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l85
  %t143 = load %"compiler/diagmsg:Msg", ptr %l86
  %t144 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t141, %"compiler/source:Span" %t142, %"compiler/diagmsg:Msg" %t143)
  store i64 %t144, ptr %l87
  br label %bb45
bb45:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  br label %bb116
bb46:
  %t145 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l76
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t145, ptr %l17
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l14, !tbaa !29
  %t148 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr %"compiler/ast:Case", ptr %t150, i32 0, i32 1
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t161 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadPatternOk(ptr %v0, ptr %v1, ptr %v2, ptr %t146, ptr %t147, { i64, ptr } %t148, i1 %a5, i64 %t155)
  store i1 %t161, ptr %l95
  br label %bb47
bb47:
  %t162 = load i1, ptr %l95, !tbaa !21
  %t163 = xor i1 %t162, true
  br i1 %t163, label %bb48, label %bb49
bb48:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb117
bb49:
  br label %bb50
bb50:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l3, !tbaa !29
  %t170 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v3, ptr %s7, ptr %s7, ptr %t165, ptr %t166, ptr %l17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %l100
  br label %bb51
bb51:
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s7, ptr %l100)
  store i64 %t172, ptr %l102
  br label %bb52
bb52:
  %t173 = load i64, ptr %l102, !tbaa !24
  %t174 = icmp eq i64 %t173, 0
  br i1 %t174, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l104, !tbaa !29
  %t177 = load ptr, ptr %l14, !tbaa !29
  %t179 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t177)
  store %"compiler/source:Span" %t179, ptr %l106
  br label %bb55
bb54:
  br label %bb60
bb55:
  %t180 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t180, ptr %l107, !tbaa !27
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t184 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s7, ptr %s10, ptr %t181, ptr %l17)
  store { i64, ptr } %t184, ptr %l110
  br label %bb56
bb56:
  %t185 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t187 = extractvalue { i64, ptr } %t185, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l111, !tbaa !27
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t196 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v3, ptr %s10, ptr %t192, ptr %t193)
  store { i64, ptr } %t196, ptr %l114
  br label %bb57
bb57:
  %t197 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  %t199 = extractvalue { i64, ptr } %t197, 1
  %t200 = mul i64 %t198, 1
  %t201 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t200)
  call void @llvm.memcpy.p0.p0.i64(ptr %t201, ptr %t199, i64 %t200, i1 false)
  %t202 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  %t204 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t207 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v2, ptr %s10, ptr %s10, ptr %s10, { i64, ptr } %t204, { i64, ptr } %t205, { i64, ptr } %t203)
  store %"compiler/diagmsg:Msg" %t207, ptr %l116
  br label %bb58
bb58:
  %t208 = load ptr, ptr %l104, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l106
  %t210 = load %"compiler/diagmsg:Msg", ptr %l116
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t208, %"compiler/source:Span" %t209, %"compiler/diagmsg:Msg" %t210)
  store i64 %t211, ptr %l117
  br label %bb59
bb59:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s7)
  br label %bb116
bb60:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load ptr, ptr %lp6
  %t214 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t213
  %t216 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t214, ptr %t216
  %t220 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %v4, ptr %s7, ptr %v4, ptr %t212, ptr %t216, ptr %l17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t220, ptr %l122
  br label %bb61
bb61:
  %t221 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122
  %t222 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t221, ptr %t222
  store %olang.scope zeroinitializer, ptr %s11
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l14, !tbaa !29
  %t227 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItems(ptr %v0, ptr %v1, ptr %s11, ptr %t223, ptr %t224)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t227, ptr %l125
  br label %bb62
bb62:
  %t228 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125
  %t229 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, ptr %t229
  store ptr %t229, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb63
bb63:
  %t231 = load i64, ptr %l19, !tbaa !24
  store i64 %t231, ptr %l127, !tbaa !24
  %t232 = load ptr, ptr %l18, !tbaa !29
  %t234 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eLe_Hf8109b64a4e45220d0da36a987cf38b1(ptr %s11, ptr %t232)
  store i64 %t234, ptr %l129
  br label %bb64
bb64:
  %t235 = load i64, ptr %l127, !tbaa !24
  %t236 = load i64, ptr %l129, !tbaa !24
  %t237 = icmp slt i64 %t235, %t236
  %t239 = xor i1 %t237, true
  br i1 %t239, label %bb65, label %bb66
bb65:
  br label %bb78
bb66:
  br label %bb67
bb67:
  %t241 = load ptr, ptr %l18, !tbaa !29
  %t242 = load i64, ptr %l19, !tbaa !24
  %t245 = call %"compiler/check:payloadItem" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eAt_H64f851f610dd8566f1d7651b626ec99d(ptr %s11, ptr %s11, ptr %t241, i64 %t242)
  store %"compiler/check:payloadItem" %t245, ptr %l134
  br label %bb68
bb68:
  %t246 = load %"compiler/check:payloadItem", ptr %l134
  store %"compiler/check:payloadItem" %t246, ptr %l20
  %t247 = load i1, ptr %l10, !tbaa !21
  br i1 %t247, label %bb69, label %bb70
bb69:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb76
bb70:
  %t249 = getelementptr %"compiler/check:payloadItem", ptr %l20, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = call i1 @compiler_2fcheck_2eisWild(ptr %s11, ptr %t250)
  store i1 %t252, ptr %l138
  br label %bb71
bb71:
  %t253 = load i1, ptr %l138, !tbaa !21
  br i1 %t253, label %bb72, label %bb73
bb72:
  store i1 true, ptr %l139, !tbaa !21
  br label %bb75
bb73:
  %t254 = getelementptr %"compiler/check:payloadItem", ptr %l20, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = call i1 @compiler_2fcheck_2eisBind(ptr %s11, ptr %t255)
  store i1 %t257, ptr %l141
  br label %bb74
bb74:
  %t258 = load i1, ptr %l141, !tbaa !21
  store i1 %t258, ptr %l139, !tbaa !21
  br label %bb75
bb75:
  %t259 = load i1, ptr %l139, !tbaa !21
  %t260 = xor i1 %t259, true
  store i1 %t260, ptr %l136, !tbaa !21
  br label %bb76
bb76:
  %t262 = load i1, ptr %l136, !tbaa !21
  store i1 %t262, ptr %l10, !tbaa !21
  br label %bb77
bb77:
  %t263 = load i64, ptr %l19, !tbaa !24
  %t265 = add i64 %t263, 1
  store i64 %t265, ptr %l19, !tbaa !24
  br label %bb63
bb78:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s7)
  br label %bb115
bb79:
  %t267 = load ptr, ptr %l14, !tbaa !29
  store ptr %t267, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t268 = load ptr, ptr %l145, !tbaa !29
  %t269 = icmp ne ptr %t268, null
  br i1 %t269, label %bb80, label %bb81
bb80:
  %t271 = load ptr, ptr %l145, !tbaa !29
  %t272 = load i64, ptr %t271, !range !{i64 0, i64 9}
  %t274 = icmp eq i64 %t272, 1
  store i1 %t274, ptr %l146, !tbaa !21
  br label %bb81
bb81:
  %t275 = load i1, ptr %l146, !tbaa !21
  br i1 %t275, label %bb82, label %bb83
bb82:
  %t276 = load ptr, ptr %l14, !tbaa !29
  %t278 = getelementptr { i64, [4 x i64] }, ptr %t276, i32 0, i32 1
  %t279 = getelementptr { %"compiler/source:Span", ptr }, ptr %t278, i32 0, i32 1
  %t280 = load ptr, ptr %t279
  store ptr %t280, ptr %l21, !tbaa !29
  br label %bb88
bb83:
  %t282 = load ptr, ptr %l14, !tbaa !29
  store ptr %t282, ptr %l151, !tbaa !29
  store i1 false, ptr %l152, !tbaa !21
  %t283 = load ptr, ptr %l151, !tbaa !29
  %t284 = icmp ne ptr %t283, null
  br i1 %t284, label %bb84, label %bb85
bb84:
  %t286 = load ptr, ptr %l151, !tbaa !29
  %t287 = load i64, ptr %t286, !range !{i64 0, i64 9}
  %t289 = icmp eq i64 %t287, 4
  store i1 %t289, ptr %l152, !tbaa !21
  br label %bb85
bb85:
  %t290 = load i1, ptr %l152, !tbaa !21
  br i1 %t290, label %bb86, label %bb87
bb86:
  %t291 = load ptr, ptr %l14, !tbaa !29
  %t293 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", ptr }, ptr %t293, i32 0, i32 1
  %t295 = load ptr, ptr %t294
  store ptr %t295, ptr %l21, !tbaa !29
  br label %bb88
bb87:
  br label %bb107
bb88:
  store %olang.scope zeroinitializer, ptr %s14
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l21, !tbaa !29
  %t301 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %s14, ptr %t297, ptr %t298)
  %t302 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t301, 1
  %t303 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t301, 0
  store i32 %t303, ptr %l161
  %t304 = icmp ne i32 %t303, 0
  br i1 %t304, label %bb90, label %ok.305, !prof !99
ok.305:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t302, ptr %l160
  br label %bb89
bb89:
  %t306 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l160
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t306, ptr %l157
  br label %bb95
bb90:
  %t307 = load i32, ptr %l161, !tbaa !23
  %t308 = ashr i32 %t307, 16
  %t310 = icmp eq i32 %t308, 1
  store i1 %t310, ptr %l163, !tbaa !21
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s15
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l164, !tbaa !29
  %t312 = load ptr, ptr %l14, !tbaa !29
  %t314 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t312)
  store %"compiler/source:Span" %t314, ptr %l166
  br label %bb92
bb92:
  %t315 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %s15)
  store %"compiler/diagmsg:Msg" %t315, ptr %l167
  br label %bb93
bb93:
  %t316 = load ptr, ptr %l164, !tbaa !29
  %t317 = load %"compiler/source:Span", ptr %l166
  %t318 = load %"compiler/diagmsg:Msg", ptr %l167
  %t319 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t316, %"compiler/source:Span" %t317, %"compiler/diagmsg:Msg" %t318)
  store i64 %t319, ptr %l168
  br label %bb94
bb94:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s14)
  br label %bb116
bb95:
  %t320 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l157
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t320, ptr %l22
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l3, !tbaa !29
  %t326 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v3, ptr %s14, ptr %s14, ptr %t321, ptr %t322, ptr %l22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t326, ptr %l172
  br label %bb96
bb96:
  %t328 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s14, ptr %l172)
  store i64 %t328, ptr %l174
  br label %bb97
bb97:
  %t329 = load i64, ptr %l174, !tbaa !24
  %t330 = icmp eq i64 %t329, 0
  br i1 %t330, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s16
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l176, !tbaa !29
  %t333 = load ptr, ptr %l14, !tbaa !29
  %t335 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t333)
  store %"compiler/source:Span" %t335, ptr %l178
  br label %bb100
bb99:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load ptr, ptr %lp6
  %t338 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t337
  %t340 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t338, ptr %t340
  %t344 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %v4, ptr %s14, ptr %v4, ptr %t336, ptr %t340, ptr %l22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t344, ptr %l194
  br label %bb105
bb100:
  %t345 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t345, ptr %l179, !tbaa !27
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t349 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s14, ptr %s16, ptr %t346, ptr %l22)
  store { i64, ptr } %t349, ptr %l182
  br label %bb101
bb101:
  %t350 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 0
  %t352 = extractvalue { i64, ptr } %t350, 1
  %t353 = mul i64 %t351, 1
  %t354 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t353)
  call void @llvm.memcpy.p0.p0.i64(ptr %t354, ptr %t352, i64 %t353, i1 false)
  %t355 = insertvalue { i64, ptr } undef, i64 %t351, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t354, 1
  store { i64, ptr } %t356, ptr %l183, !tbaa !27
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load ptr, ptr %l3, !tbaa !29
  %t361 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v3, ptr %s16, ptr %t357, ptr %t358)
  store { i64, ptr } %t361, ptr %l186
  br label %bb102
bb102:
  %t362 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t362, 0
  %t364 = extractvalue { i64, ptr } %t362, 1
  %t365 = mul i64 %t363, 1
  %t366 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t365)
  call void @llvm.memcpy.p0.p0.i64(ptr %t366, ptr %t364, i64 %t365, i1 false)
  %t367 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t368 = insertvalue { i64, ptr } %t367, ptr %t366, 1
  %t369 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t370 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t372 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v2, ptr %s16, ptr %s16, ptr %s16, { i64, ptr } %t369, { i64, ptr } %t370, { i64, ptr } %t368)
  store %"compiler/diagmsg:Msg" %t372, ptr %l188
  br label %bb103
bb103:
  %t373 = load ptr, ptr %l176, !tbaa !29
  %t374 = load %"compiler/source:Span", ptr %l178
  %t375 = load %"compiler/diagmsg:Msg", ptr %l188
  %t376 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t373, %"compiler/source:Span" %t374, %"compiler/diagmsg:Msg" %t375)
  store i64 %t376, ptr %l189
  br label %bb104
bb104:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s16)
  br label %bb106
bb105:
  %t377 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l194
  %t378 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t377, ptr %t378
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s14)
  br label %bb115
bb107:
  br i1 true, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb114
bb110:
  store %olang.scope zeroinitializer, ptr %s18
  %t379 = load ptr, ptr %l0, !tbaa !29
  store ptr %t379, ptr %l195, !tbaa !29
  %t380 = load ptr, ptr %l14, !tbaa !29
  %t382 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t380)
  store %"compiler/source:Span" %t382, ptr %l197
  br label %bb111
bb111:
  %t383 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %s18)
  store %"compiler/diagmsg:Msg" %t383, ptr %l198
  br label %bb112
bb112:
  %t384 = load ptr, ptr %l195, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l197
  %t386 = load %"compiler/diagmsg:Msg", ptr %l198
  %t387 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t384, %"compiler/source:Span" %t385, %"compiler/diagmsg:Msg" %t386)
  store i64 %t387, ptr %l199
  br label %bb113
bb113:
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s18)
  br label %bb115
bb114:
  call void @__olang_check_failed(ptr @olang_loc_7f447623c50cbf0b_d88fa4c796e8075f)
  unreachable
bb115:
  br label %bb116
bb116:
  %t388 = load i64, ptr %l12, !tbaa !24
  %t390 = add i64 %t388, 1
  store i64 %t390, ptr %l12, !tbaa !24
  br label %bb2
bb117:
  %t392 = load ptr, ptr %lp6
  %t393 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t392
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t393, ptr %l202
  %t395 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v4, ptr %l202)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t395, ptr %l204
  br label %bb118
bb118:
  %t396 = load i1, ptr %l7, !tbaa !21
  %t397 = load i1, ptr %l8, !tbaa !21
  %t398 = load i1, ptr %l9, !tbaa !21
  %t399 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l204
  %t403 = call %"compiler/check:altsCovered" @compiler_2fcheck_3aaltsCovered_2ector(ptr %v4, ptr %v4, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t399, i1 %t396, i1 %t397, i1 %t398)
  store %"compiler/check:altsCovered" %t403, ptr %l208
  br label %bb119
bb119:
  %t405 = call %"compiler/check:altsCovered" @olang_2eHelperKind_2eCopy_2ecompiler_2fcheck_3aaltsCovered(ptr %v4, ptr %l208)
  store %"compiler/check:altsCovered" %t405, ptr %l210
  br label %bb120
bb120:
  %t406 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store ptr %t406, ptr %lp23
  %t407 = load %"compiler/check:altsCovered", ptr %l210
  %t408 = load ptr, ptr %lp23
  store %"compiler/check:altsCovered" %t407, ptr %t408
  %t409 = load i1, ptr %l10, !tbaa !21
  %t411 = load ptr, ptr %lp23
  %t412 = getelementptr %"compiler/check:altsCovered", ptr %t411, i32 0, i32 4
  store i1 %t409, ptr %t412, !tbaa !21
  %t413 = load ptr, ptr %lp23
  %t414 = load %"compiler/check:altsCovered", ptr %t413
  store %"compiler/check:altsCovered" %t414, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:altsCovered", ptr %rv
  ret %"compiler/check:altsCovered" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNarrow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i1 %a2, i32 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp13 = alloca ptr
  %lp14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca ptr
  %l49 = alloca i1
  %l60 = alloca i1
  %l66 = alloca i32
  %l72 = alloca i32
  %l77 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca i32
  %l83 = alloca i1
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l106 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l108 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l115 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l116 = alloca ptr
  %l121 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l123 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l124 = alloca ptr
  %l129 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l131 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l133 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l144 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l149 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l151 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l152 = alloca ptr
  %l157 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l159 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l160 = alloca ptr
  %l165 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l167 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l169 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l5, !tbaa !29
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t18 = load i1, ptr %l2, !tbaa !21
  %t19 = load i32, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNarrow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t16, ptr %t17, i1 %t18, i32 %t19, ptr %t20)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l26
  br label %bb6
bb6:
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3, ptr %l26)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l28
  br label %bb7
bb7:
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %rv
  br label %ret
bb8:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t31 = load ptr, ptr %l29, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l29, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 30}
  %t37 = icmp eq i64 %t35, 3
  store i1 %t37, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l30, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42, !range !{i32 0, i32 98}
  store i32 %t43, ptr %l6
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l7, !tbaa !29
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t51 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t53 = trunc i64 48 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb14, label %bb15
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l7, !tbaa !29
  %t58 = load i1, ptr %l2, !tbaa !21
  %t60 = xor i1 %t58, true
  %t61 = load i32, ptr %l3, !tbaa !23
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t68 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNarrow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t56, ptr %t57, i1 %t60, i32 %t61, ptr %t62)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l45
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t70 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3, ptr %l45)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %l47
  br label %bb17
bb17:
  %t71 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %rv
  br label %ret
bb18:
  br label %bb83
bb19:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t73 = load ptr, ptr %l48, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb20, label %bb21
bb20:
  %t76 = load ptr, ptr %l48, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 30}
  %t79 = icmp eq i64 %t77, 5
  store i1 %t79, ptr %l49, !tbaa !21
  br label %bb21
bb21:
  %t80 = load i1, ptr %l49, !tbaa !21
  br i1 %t80, label %bb22, label %bb23
bb22:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84, !range !{i32 0, i32 98}
  store i32 %t85, ptr %l8
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l9, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t95, i32 0, i32 3
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l10, !tbaa !29
  br label %bb24
bb23:
  br label %bb78
bb24:
  %t99 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t101 = trunc i64 78 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb27
bb26:
  %t104 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t106 = trunc i64 79 to i32
  %t107 = icmp eq i32 %t104, %t106
  store i1 %t107, ptr %l60, !tbaa !21
  br label %bb27
bb27:
  %t109 = load i1, ptr %l60, !tbaa !21
  br i1 %t109, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t110 = load ptr, ptr %l9, !tbaa !29
  store ptr %t110, ptr %l11, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l9, !tbaa !29
  %t116 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %t112, ptr %t113)
  store i32 %t116, ptr %l66
  br label %bb30
bb29:
  br label %bb47
bb30:
  %t117 = load i32, ptr %l3, !tbaa !23
  %t118 = load i32, ptr %l66, !tbaa !23
  %t120 = icmp eq i32 %t118, %t117
  br i1 %t120, label %bb31, label %bb32
bb31:
  %t122 = load ptr, ptr %l10, !tbaa !29
  store ptr %t122, ptr %l11, !tbaa !29
  br label %bb37
bb32:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l10, !tbaa !29
  %t128 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  store i32 %t128, ptr %l72
  br label %bb33
bb33:
  %t129 = load i32, ptr %l3, !tbaa !23
  %t130 = load i32, ptr %l72, !tbaa !23
  %t132 = icmp ne i32 %t130, %t129
  br i1 %t132, label %bb34, label %bb35
bb34:
  %t134 = load ptr, ptr %l4, !tbaa !29
  %t136 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t134
  call void @__olang_scope_close(ptr %s5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l11, !tbaa !29
  %t142 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %s5, ptr %t138, ptr %t139)
  %t143 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t142, 1
  %t144 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t142, 0
  store i32 %t144, ptr %l81
  %t145 = icmp ne i32 %t144, 0
  br i1 %t145, label %bb39, label %ok.146, !prof !99
ok.146:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %l80
  br label %bb38
bb38:
  %t147 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t147, ptr %l77
  br label %bb41
bb39:
  %t148 = load i32, ptr %l81, !tbaa !23
  %t149 = ashr i32 %t148, 16
  %t151 = icmp eq i32 %t149, 1
  store i1 %t151, ptr %l83, !tbaa !21
  br label %bb40
bb40:
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t154 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t152
  call void @__olang_scope_close(ptr %s5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %rv
  br label %ret
bb41:
  %t156 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t156, ptr %l12
  %t157 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t159 = trunc i64 78 to i32
  %t160 = icmp eq i32 %t157, %t159
  %t161 = load i1, ptr %l2, !tbaa !21
  %t164 = icmp eq i1 %t160, %t161
  br i1 %t164, label %bb42, label %bb43
bb42:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l4, !tbaa !29
  %t171 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v2, ptr %s5, ptr %v3, ptr %t166, ptr %t167, ptr %l12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t171, ptr %l94
  br label %bb44
bb43:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l4, !tbaa !29
  %t177 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %v2, ptr %s5, ptr %v3, ptr %t172, ptr %t173, ptr %l12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t177, ptr %l98
  br label %bb45
bb44:
  %t178 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t178, ptr %l90
  br label %bb46
bb45:
  %t179 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t179, ptr %l90
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s5)
  %t180 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t180, ptr %rv
  br label %ret
bb47:
  %t181 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t183 = trunc i64 45 to i32
  %t184 = icmp eq i32 %t181, %t183
  br i1 %t184, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  %t186 = load i1, ptr %l2, !tbaa !21
  br i1 %t186, label %bb50, label %bb51
bb49:
  br label %bb62
bb50:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %l9, !tbaa !29
  %t190 = load i32, ptr %l3, !tbaa !23
  %t191 = load ptr, ptr %l4, !tbaa !29
  %t196 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNarrow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t188, ptr %t189, i1 true, i32 %t190, ptr %t191)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t196, ptr %l106
  br label %bb52
bb51:
  br label %bb56
bb52:
  %t198 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3, ptr %l106)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t198, ptr %l108
  br label %bb53
bb53:
  %t199 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t199, ptr %lp13
  %t200 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l108
  %t201 = load ptr, ptr %lp13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t200, ptr %t201
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l10, !tbaa !29
  %t204 = load i32, ptr %l3, !tbaa !23
  %t205 = load ptr, ptr %lp13
  %t210 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNarrow(ptr %v0, ptr %v1, ptr %v3, ptr %v3, ptr %t202, ptr %t203, i1 true, i32 %t204, ptr %t205)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t210, ptr %l113
  br label %bb54
bb54:
  %t212 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3, ptr %l113)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t212, ptr %l115
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s10)
  %t213 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l115
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t213, ptr %rv
  br label %ret
bb56:
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l116, !tbaa !29
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l9, !tbaa !29
  %t217 = load i32, ptr %l3, !tbaa !23
  %t218 = load ptr, ptr %l4, !tbaa !29
  %t223 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNarrow(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t215, ptr %t216, i1 false, i32 %t217, ptr %t218)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t223, ptr %l121
  br label %bb57
bb57:
  %t225 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %l121)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t225, ptr %l123
  br label %bb58
bb58:
  %t226 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l123
  %t227 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t226, ptr %t227
  store ptr %t227, ptr %l124, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l10, !tbaa !29
  %t230 = load i32, ptr %l3, !tbaa !23
  %t231 = load ptr, ptr %l4, !tbaa !29
  %t236 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNarrow(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t228, ptr %t229, i1 false, i32 %t230, ptr %t231)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t236, ptr %l129
  br label %bb59
bb59:
  %t238 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %l129)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t238, ptr %l131
  br label %bb60
bb60:
  %t239 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l131
  %t240 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %t240
  %t241 = load ptr, ptr %l116, !tbaa !29
  %t242 = load ptr, ptr %l124, !tbaa !29
  %t244 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %v2, ptr %v2, ptr %v3, ptr %t241, ptr %t242, ptr %t240)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t244, ptr %l133
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s10)
  %t245 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l133
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t245, ptr %rv
  br label %ret
bb62:
  %t246 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t248 = trunc i64 46 to i32
  %t249 = icmp eq i32 %t246, %t248
  br i1 %t249, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s12
  %t251 = load i1, ptr %l2, !tbaa !21
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb65, label %bb66
bb64:
  br label %bb77
bb65:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load ptr, ptr %l9, !tbaa !29
  %t257 = load i32, ptr %l3, !tbaa !23
  %t258 = load ptr, ptr %l4, !tbaa !29
  %t263 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNarrow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t255, ptr %t256, i1 false, i32 %t257, ptr %t258)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t263, ptr %l142
  br label %bb67
bb66:
  br label %bb71
bb67:
  %t265 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3, ptr %l142)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265, ptr %l144
  br label %bb68
bb68:
  %t266 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t266, ptr %lp14
  %t267 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l144
  %t268 = load ptr, ptr %lp14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t267, ptr %t268
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load ptr, ptr %l10, !tbaa !29
  %t271 = load i32, ptr %l3, !tbaa !23
  %t272 = load ptr, ptr %lp14
  %t277 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNarrow(ptr %v0, ptr %v1, ptr %v3, ptr %v3, ptr %t269, ptr %t270, i1 false, i32 %t271, ptr %t272)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t277, ptr %l149
  br label %bb69
bb69:
  %t279 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3, ptr %l149)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t279, ptr %l151
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s12)
  %t280 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l151
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t280, ptr %rv
  br label %ret
bb71:
  %t281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t281, ptr %l152, !tbaa !29
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load ptr, ptr %l9, !tbaa !29
  %t284 = load i32, ptr %l3, !tbaa !23
  %t285 = load ptr, ptr %l4, !tbaa !29
  %t290 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNarrow(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t282, ptr %t283, i1 true, i32 %t284, ptr %t285)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t290, ptr %l157
  br label %bb72
bb72:
  %t292 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %l157)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t292, ptr %l159
  br label %bb73
bb73:
  %t293 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l159
  %t294 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t293, ptr %t294
  store ptr %t294, ptr %l160, !tbaa !29
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load ptr, ptr %l10, !tbaa !29
  %t297 = load i32, ptr %l3, !tbaa !23
  %t298 = load ptr, ptr %l4, !tbaa !29
  %t303 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNarrow(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t295, ptr %t296, i1 true, i32 %t297, ptr %t298)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t303, ptr %l165
  br label %bb74
bb74:
  %t305 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %l165)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t305, ptr %l167
  br label %bb75
bb75:
  %t306 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l167
  %t307 = call ptr @__olang_scope_alloc_a(ptr %s12, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t306, ptr %t307
  %t308 = load ptr, ptr %l152, !tbaa !29
  %t309 = load ptr, ptr %l160, !tbaa !29
  %t311 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %v2, ptr %v2, ptr %v3, ptr %t308, ptr %t309, ptr %t307)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t311, ptr %l169
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s12)
  %t312 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l169
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t312, ptr %rv
  br label %ret
bb77:
  br label %bb83
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_e75bf8e677cd64fa_b74b0f73d6209566)
  unreachable
bb83:
  %t313 = load ptr, ptr %l4, !tbaa !29
  %t315 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t313
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t315, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/generic:Origin"
  %l3 = alloca i32
  %l4 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 44
  %t7 = load %"compiler/generic:Origin", ptr %t6
  store %"compiler/generic:Origin" %t7, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 23
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %l3, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 42
  %t17 = load i32, ptr %t16, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %t19, i64 %a1)
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load %"compiler/generic:Origin", ptr %l2
  %t30 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 44
  store %"compiler/generic:Origin" %t27, ptr %t30
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 23
  store i32 %t32, ptr %t35, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l4, !tbaa !23
  %t40 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 42
  store i32 %t37, ptr %t40, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca i32
  %l45 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l92 = alloca %"compiler/source:Span"
  %l93 = alloca i32
  %l97 = alloca ptr
  %l101 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca i1
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca i32
  %l119 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca i1
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l138 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca %"compiler/typed:Promote"
  %l148 = alloca ptr
  %l149 = alloca i1
  %l158 = alloca %"compiler/source:Span"
  %l159 = alloca i32
  %l161 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l171 = alloca i32
  %l174 = alloca %"compiler/typed:Call"
  %l178 = alloca ptr
  %l179 = alloca i1
  %l192 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l204 = alloca ptr
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca i32
  %l209 = alloca i32
  %l211 = alloca i64
  %l212 = alloca { i64, ptr }
  %l213 = alloca ptr
  %l218 = alloca i32
  %l221 = alloca %"compiler/typed:Make"
  %l225 = alloca ptr
  %l226 = alloca i1
  %l239 = alloca %"compiler/source:Span"
  %l240 = alloca i32
  %l241 = alloca i32
  %l242 = alloca i32
  %l246 = alloca { i64, ptr }
  %l249 = alloca ptr
  %l250 = alloca i1
  %l259 = alloca %"compiler/source:Span"
  %l260 = alloca i32
  %l265 = alloca ptr
  %l270 = alloca ptr
  %l275 = alloca ptr
  %l278 = alloca %"compiler/typed:Slice"
  %l282 = alloca ptr
  %l283 = alloca i1
  %l296 = alloca ptr
  %l303 = alloca ptr
  %l305 = alloca %"compiler/source:Span"
  %l306 = alloca i32
  %l311 = alloca ptr
  %l312 = alloca ptr
  %l317 = alloca ptr
  %l318 = alloca %"compiler/typed:Cond"
  %l322 = alloca ptr
  %l323 = alloca i1
  %l332 = alloca %"compiler/source:Span"
  %l333 = alloca i64
  %l337 = alloca ptr
  %l340 = alloca ptr
  %l341 = alloca i1
  %l350 = alloca ptr
  %l351 = alloca i1
  %l363 = alloca ptr
  %l365 = alloca %"compiler/source:Span"
  %l366 = alloca ptr
  %rv = alloca ptr
  %t31 = alloca { i64, [5 x i64] }, align 8
  %t81 = alloca { i64, [5 x i64] }, align 8
  %t145 = alloca { i64, [5 x i64] }, align 8
  %t196 = alloca { i64, [5 x i64] }, align 8
  %t263 = alloca { i64, [5 x i64] }, align 8
  %t340 = alloca { i64, [5 x i64] }, align 8
  %t454 = alloca { i64, [5 x i64] }, align 8
  %t517 = alloca { i64, [5 x i64] }, align 8
  %t604 = alloca { i64, [5 x i64] }, align 8
  %t701 = alloca { i64, [5 x i64] }, align 8
  %t750 = alloca { i64, [5 x i64] }, align 8
  %t808 = alloca { i64, [4 x i64] }, align 8
  %t816 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t2 = load ptr, ptr %l47, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l47, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l48, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l48, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t24, i32 0, i32 2
  %t26 = load i64, ptr %t25
  store i64 %t26, ptr %l5, !tbaa !24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t28 = load %"compiler/source:Span", ptr %l3
  %t29 = load i32, ptr %l4, !tbaa !23
  %t30 = load i64, ptr %l5, !tbaa !24
  store { i64, [5 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t34 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t28, 0
  %t36 = insertvalue { %"compiler/source:Span", i32, i64 } %t34, i32 %t29, 1
  %t38 = insertvalue { %"compiler/source:Span", i32, i64 } %t36, i64 %t30, 2
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t38, ptr %t39
  %t40 = load { i64, [5 x i64] }, ptr %t31
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t40, ptr %t42
  store ptr %t42, ptr %rv
  br label %ret
bb6:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t45 = load ptr, ptr %l62, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load ptr, ptr %l62, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 1
  store i1 %t51, ptr %l63, !tbaa !21
  br label %bb8
bb8:
  %t52 = load i1, ptr %l63, !tbaa !21
  br i1 %t52, label %bb9, label %bb10
bb9:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l6
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l7, !tbaa !23
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load i64, ptr %t68
  store i64 %t69, ptr %l8, !tbaa !24
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t73, i32 0, i32 3
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l9, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t77 = load %"compiler/source:Span", ptr %l6
  %t78 = load i32, ptr %l7, !tbaa !23
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load ptr, ptr %l9, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 0
  store i64 1, ptr %t82
  %t84 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t77, 0
  %t86 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t84, i32 %t78, 1
  %t88 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t86, i64 %t79, 2
  %t90 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t88, ptr %t80, 3
  %t91 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t90, ptr %t91
  %t92 = load { i64, [5 x i64] }, ptr %t81
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t92, ptr %t94
  store ptr %t94, ptr %rv
  br label %ret
bb12:
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t97 = load ptr, ptr %l80, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb13, label %bb14
bb13:
  %t100 = load ptr, ptr %l80, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 18}
  %t103 = icmp eq i64 %t101, 2
  store i1 %t103, ptr %l81, !tbaa !21
  br label %bb14
bb14:
  %t104 = load i1, ptr %l81, !tbaa !21
  br i1 %t104, label %bb15, label %bb16
bb15:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t107, i32 0, i32 0
  %t109 = load %"compiler/source:Span", ptr %t108
  store %"compiler/source:Span" %t109, ptr %l10
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t113, i32 0, i32 1
  %t115 = load i32, ptr %t114
  store i32 %t115, ptr %l11, !tbaa !23
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l12, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t125, i32 0, i32 3
  %t127 = load i32, ptr %t126
  store i32 %t127, ptr %l13, !tbaa !23
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t129 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t129, ptr %l92
  %t130 = load i32, ptr %l11, !tbaa !23
  store i32 %t130, ptr %l93, !tbaa !23
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l12, !tbaa !29
  %t133 = load i64, ptr %l2, !tbaa !24
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t131, ptr %t132, i64 %t133)
  store ptr %t137, ptr %l97
  br label %bb18
bb18:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i32, ptr %l13, !tbaa !23
  %t140 = load i64, ptr %l2, !tbaa !24
  %t144 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t138, i32 %t139, i64 %t140)
  store i32 %t144, ptr %l101
  br label %bb19
bb19:
  store { i64, [5 x i64] } zeroinitializer, ptr %t145
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 0
  store i64 2, ptr %t146
  %t147 = load %"compiler/source:Span", ptr %l92
  %t148 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t147, 0
  %t149 = load i32, ptr %l93, !tbaa !23
  %t150 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t148, i32 %t149, 1
  %t151 = load ptr, ptr %l97, !tbaa !29
  %t152 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t150, ptr %t151, 2
  %t153 = load i32, ptr %l101, !tbaa !23
  %t154 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t152, i32 %t153, 3
  %t155 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t154, ptr %t155
  %t156 = load { i64, [5 x i64] }, ptr %t145
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t156, ptr %t158
  store ptr %t158, ptr %rv
  br label %ret
bb20:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t161 = load ptr, ptr %l104, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb21, label %bb22
bb21:
  %t164 = load ptr, ptr %l104, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 18}
  %t167 = icmp eq i64 %t165, 3
  store i1 %t167, ptr %l105, !tbaa !21
  br label %bb22
bb22:
  %t168 = load i1, ptr %l105, !tbaa !21
  br i1 %t168, label %bb23, label %bb24
bb23:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [5 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t171, i32 0, i32 0
  %t173 = load %"compiler/source:Span", ptr %t172
  store %"compiler/source:Span" %t173, ptr %l14
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr { i64, [5 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t177, i32 0, i32 1
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l15, !tbaa !23
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t183, i32 0, i32 2
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l16, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t187 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t187, ptr %l114
  %t188 = load i32, ptr %l15, !tbaa !23
  store i32 %t188, ptr %l115, !tbaa !23
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l16, !tbaa !29
  %t191 = load i64, ptr %l2, !tbaa !24
  %t195 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t189, ptr %t190, i64 %t191)
  store ptr %t195, ptr %l119
  br label %bb26
bb26:
  store { i64, [5 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 0
  store i64 3, ptr %t197
  %t198 = load %"compiler/source:Span", ptr %l114
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t198, 0
  %t200 = load i32, ptr %l115, !tbaa !23
  %t201 = insertvalue { %"compiler/source:Span", i32, ptr } %t199, i32 %t200, 1
  %t202 = load ptr, ptr %l119, !tbaa !29
  %t203 = insertvalue { %"compiler/source:Span", i32, ptr } %t201, ptr %t202, 2
  %t204 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t203, ptr %t204
  %t205 = load { i64, [5 x i64] }, ptr %t196
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t205, ptr %t207
  store ptr %t207, ptr %rv
  br label %ret
bb27:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t210 = load ptr, ptr %l122, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb28, label %bb29
bb28:
  %t213 = load ptr, ptr %l122, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 18}
  %t216 = icmp eq i64 %t214, 5
  store i1 %t216, ptr %l123, !tbaa !21
  br label %bb29
bb29:
  %t217 = load i1, ptr %l123, !tbaa !21
  br i1 %t217, label %bb30, label %bb31
bb30:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t220, i32 0, i32 0
  %t222 = load %"compiler/source:Span", ptr %t221
  store %"compiler/source:Span" %t222, ptr %l17
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [5 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t226, i32 0, i32 1
  %t228 = load i32, ptr %t227
  store i32 %t228, ptr %l18, !tbaa !23
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr { i64, [5 x i64] }, ptr %t230, i32 0, i32 1
  %t233 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t232, i32 0, i32 2
  %t234 = load ptr, ptr %t233
  store ptr %t234, ptr %l19, !tbaa !29
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t236 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t236, ptr %l132
  %t237 = load i32, ptr %l18, !tbaa !23
  store i32 %t237, ptr %l133, !tbaa !23
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l19, !tbaa !29
  %t241 = getelementptr %"compiler/typed:Promote", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t243 = load i64, ptr %l2, !tbaa !24
  %t247 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t238, ptr %t242, i64 %t243)
  store ptr %t247, ptr %l138
  br label %bb33
bb33:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l19, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Promote", ptr %t249, i32 0, i32 1
  %t252 = load i32, ptr %t251, !tbaa !23
  %t253 = load i64, ptr %l2, !tbaa !24
  %t257 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t248, i32 %t252, i64 %t253)
  store i32 %t257, ptr %l143
  br label %bb34
bb34:
  %t258 = load ptr, ptr %l138, !tbaa !29
  %t259 = load i32, ptr %l143, !tbaa !23
  %t260 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v2, ptr %t258, i32 %t259)
  store %"compiler/typed:Promote" %t260, ptr %l144
  br label %bb35
bb35:
  %t261 = load %"compiler/typed:Promote", ptr %l144
  %t262 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store %"compiler/typed:Promote" %t261, ptr %t262
  store { i64, [5 x i64] } zeroinitializer, ptr %t263
  %t264 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 0
  store i64 5, ptr %t264
  %t265 = load %"compiler/source:Span", ptr %l132
  %t266 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t265, 0
  %t267 = load i32, ptr %l133, !tbaa !23
  %t268 = insertvalue { %"compiler/source:Span", i32, ptr } %t266, i32 %t267, 1
  %t270 = insertvalue { %"compiler/source:Span", i32, ptr } %t268, ptr %t262, 2
  %t271 = getelementptr { i64, [5 x i64] }, ptr %t263, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t270, ptr %t271
  %t272 = load { i64, [5 x i64] }, ptr %t263
  %t274 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t272, ptr %t274
  store ptr %t274, ptr %rv
  br label %ret
bb36:
  %t276 = load ptr, ptr %l1, !tbaa !29
  store ptr %t276, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t277 = load ptr, ptr %l148, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb37, label %bb38
bb37:
  %t280 = load ptr, ptr %l148, !tbaa !29
  %t281 = load i64, ptr %t280, !range !{i64 0, i64 18}
  %t283 = icmp eq i64 %t281, 6
  store i1 %t283, ptr %l149, !tbaa !21
  br label %bb38
bb38:
  %t284 = load i1, ptr %l149, !tbaa !21
  br i1 %t284, label %bb39, label %bb40
bb39:
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t287 = getelementptr { i64, [5 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t287, i32 0, i32 0
  %t289 = load %"compiler/source:Span", ptr %t288
  store %"compiler/source:Span" %t289, ptr %l20
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [5 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t293, i32 0, i32 1
  %t295 = load i32, ptr %t294
  store i32 %t295, ptr %l21, !tbaa !23
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr { i64, [5 x i64] }, ptr %t297, i32 0, i32 1
  %t300 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t299, i32 0, i32 2
  %t301 = load ptr, ptr %t300
  store ptr %t301, ptr %l22, !tbaa !29
  br label %bb41
bb40:
  br label %bb45
bb41:
  %t303 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t303, ptr %l158
  %t304 = load i32, ptr %l21, !tbaa !23
  store i32 %t304, ptr %l159, !tbaa !23
  %t305 = load ptr, ptr %l22, !tbaa !29
  %t307 = getelementptr %"compiler/typed:Call", ptr %t305, i32 0, i32 0
  %t308 = load ptr, ptr %t307, !tbaa !29
  store ptr %t308, ptr %l161, !tbaa !29
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l22, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Call", ptr %t310, i32 0, i32 1
  %t313 = load { i64, ptr }, ptr %t312, !tbaa !27
  %t314 = load i64, ptr %l2, !tbaa !24
  %t318 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %v0, ptr %t309, { i64, ptr } %t313, i64 %t314)
  store { i64, ptr } %t318, ptr %l166
  br label %bb42
bb42:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load ptr, ptr %l22, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Call", ptr %t320, i32 0, i32 2
  %t323 = load i32, ptr %t322, !tbaa !23
  %t324 = load i64, ptr %l2, !tbaa !24
  %t328 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t319, i32 %t323, i64 %t324)
  store i32 %t328, ptr %l171
  br label %bb43
bb43:
  %t329 = load ptr, ptr %l22, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Call", ptr %t329, i32 0, i32 3
  %t332 = load i1, ptr %t331, !tbaa !21
  %t333 = load ptr, ptr %l161, !tbaa !29
  %t334 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t335 = load i32, ptr %l171, !tbaa !23
  %t337 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v1, ptr %v0, ptr %v2, ptr %t333, { i64, ptr } %t334, i32 %t335, i1 %t332, i1 false)
  store %"compiler/typed:Call" %t337, ptr %l174
  br label %bb44
bb44:
  %t338 = load %"compiler/typed:Call", ptr %l174
  %t339 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Call" %t338, ptr %t339
  store { i64, [5 x i64] } zeroinitializer, ptr %t340
  %t341 = getelementptr { i64, [5 x i64] }, ptr %t340, i32 0, i32 0
  store i64 6, ptr %t341
  %t342 = load %"compiler/source:Span", ptr %l158
  %t343 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t342, 0
  %t344 = load i32, ptr %l159, !tbaa !23
  %t345 = insertvalue { %"compiler/source:Span", i32, ptr } %t343, i32 %t344, 1
  %t347 = insertvalue { %"compiler/source:Span", i32, ptr } %t345, ptr %t339, 2
  %t348 = getelementptr { i64, [5 x i64] }, ptr %t340, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t347, ptr %t348
  %t349 = load { i64, [5 x i64] }, ptr %t340
  %t351 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t349, ptr %t351
  store ptr %t351, ptr %rv
  br label %ret
bb45:
  %t353 = load ptr, ptr %l1, !tbaa !29
  store ptr %t353, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t354 = load ptr, ptr %l178, !tbaa !29
  %t355 = icmp ne ptr %t354, null
  br i1 %t355, label %bb46, label %bb47
bb46:
  %t357 = load ptr, ptr %l178, !tbaa !29
  %t358 = load i64, ptr %t357, !range !{i64 0, i64 18}
  %t360 = icmp eq i64 %t358, 7
  store i1 %t360, ptr %l179, !tbaa !21
  br label %bb47
bb47:
  %t361 = load i1, ptr %l179, !tbaa !21
  br i1 %t361, label %bb48, label %bb49
bb48:
  %t362 = load ptr, ptr %l1, !tbaa !29
  %t364 = getelementptr { i64, [5 x i64] }, ptr %t362, i32 0, i32 1
  %t365 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t364, i32 0, i32 0
  %t366 = load %"compiler/source:Span", ptr %t365
  store %"compiler/source:Span" %t366, ptr %l23
  %t368 = load ptr, ptr %l1, !tbaa !29
  %t370 = getelementptr { i64, [5 x i64] }, ptr %t368, i32 0, i32 1
  %t371 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t370, i32 0, i32 1
  %t372 = load i32, ptr %t371
  store i32 %t372, ptr %l24, !tbaa !23
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t376 = getelementptr { i64, [5 x i64] }, ptr %t374, i32 0, i32 1
  %t377 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t376, i32 0, i32 2
  %t378 = load ptr, ptr %t377
  store ptr %t378, ptr %l25, !tbaa !29
  br label %bb50
bb49:
  br label %bb61
bb50:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load ptr, ptr %l25, !tbaa !29
  %t383 = getelementptr %"compiler/typed:Make", ptr %t381, i32 0, i32 2
  %t384 = load { i64, ptr }, ptr %t383, !tbaa !27
  %t385 = load i64, ptr %l2, !tbaa !24
  %t389 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %v2, ptr %t380, { i64, ptr } %t384, i64 %t385)
  store { i64, ptr } %t389, ptr %l192
  br label %bb51
bb51:
  %t390 = load { i64, ptr }, ptr %l192, !tbaa !27
  store { i64, ptr } %t390, ptr %l26, !tbaa !27
  store ptr null, ptr %l27, !tbaa !29
  %t391 = load ptr, ptr %l25, !tbaa !29
  %t393 = getelementptr %"compiler/typed:Make", ptr %t391, i32 0, i32 3
  %t394 = load ptr, ptr %t393, !tbaa !29
  %t396 = icmp eq ptr %t394, null
  %t398 = xor i1 %t396, true
  br i1 %t398, label %bb52, label %bb53
bb52:
  %t400 = load ptr, ptr %l0, !tbaa !29
  store ptr %t400, ptr %l197, !tbaa !29
  %t401 = load ptr, ptr %l25, !tbaa !29
  %t403 = getelementptr %"compiler/typed:Make", ptr %t401, i32 0, i32 3
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = icmp eq ptr %t404, null
  br i1 %t406, label %bb54, label %bb55
bb53:
  br label %bb58
bb54:
  call void @__olang_check_failed(ptr @olang_loc_4aef7e9433005aa6_9cd0eb13e1392442)
  unreachable
bb55:
  br label %bb56
bb56:
  %t408 = load ptr, ptr %l25, !tbaa !29
  %t410 = getelementptr %"compiler/typed:Make", ptr %t408, i32 0, i32 3
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t412 = load i64, ptr %l2, !tbaa !24
  %t413 = load ptr, ptr %l197, !tbaa !29
  %t416 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t413, ptr %t411, i64 %t412)
  store ptr %t416, ptr %l204
  br label %bb57
bb57:
  %t417 = load ptr, ptr %l204, !tbaa !29
  store ptr %t417, ptr %l27, !tbaa !29
  br label %bb58
bb58:
  %t419 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t419, ptr %l206
  %t420 = load i32, ptr %l24, !tbaa !23
  store i32 %t420, ptr %l207, !tbaa !23
  %t421 = load ptr, ptr %l25, !tbaa !29
  %t423 = getelementptr %"compiler/typed:Make", ptr %t421, i32 0, i32 0
  %t424 = load i32, ptr %t423, !range !{i32 0, i32 5}
  store i32 %t424, ptr %l209
  %t425 = load ptr, ptr %l25, !tbaa !29
  %t427 = getelementptr %"compiler/typed:Make", ptr %t425, i32 0, i32 1
  %t428 = load i64, ptr %t427, !tbaa !24
  store i64 %t428, ptr %l211, !tbaa !24
  %t429 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t429, ptr %l212, !tbaa !27
  %t430 = load ptr, ptr %l27, !tbaa !29
  store ptr %t430, ptr %l213, !tbaa !29
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load ptr, ptr %l25, !tbaa !29
  %t434 = getelementptr %"compiler/typed:Make", ptr %t432, i32 0, i32 4
  %t435 = load i32, ptr %t434, !tbaa !23
  %t436 = load i64, ptr %l2, !tbaa !24
  %t440 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t431, i32 %t435, i64 %t436)
  store i32 %t440, ptr %l218
  br label %bb59
bb59:
  %t441 = load ptr, ptr %l25, !tbaa !29
  %t443 = getelementptr %"compiler/typed:Make", ptr %t441, i32 0, i32 5
  %t444 = load i32, ptr %t443, !range !{i32 0, i32 3}
  %t445 = load i32, ptr %l209, !range !{i32 0, i32 5}
  %t446 = load i64, ptr %l211, !tbaa !24
  %t447 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t448 = load ptr, ptr %l213, !tbaa !29
  %t449 = load i32, ptr %l218, !tbaa !23
  %t451 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t445, i64 %t446, { i64, ptr } %t447, ptr %t448, i32 %t449, i32 %t444, i1 false)
  store %"compiler/typed:Make" %t451, ptr %l221
  br label %bb60
bb60:
  %t452 = load %"compiler/typed:Make", ptr %l221
  %t453 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t452, ptr %t453
  store { i64, [5 x i64] } zeroinitializer, ptr %t454
  %t455 = getelementptr { i64, [5 x i64] }, ptr %t454, i32 0, i32 0
  store i64 7, ptr %t455
  %t456 = load %"compiler/source:Span", ptr %l206
  %t457 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t456, 0
  %t458 = load i32, ptr %l207, !tbaa !23
  %t459 = insertvalue { %"compiler/source:Span", i32, ptr } %t457, i32 %t458, 1
  %t461 = insertvalue { %"compiler/source:Span", i32, ptr } %t459, ptr %t453, 2
  %t462 = getelementptr { i64, [5 x i64] }, ptr %t454, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t461, ptr %t462
  %t463 = load { i64, [5 x i64] }, ptr %t454
  %t465 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t463, ptr %t465
  store ptr %t465, ptr %rv
  br label %ret
bb61:
  %t467 = load ptr, ptr %l1, !tbaa !29
  store ptr %t467, ptr %l225, !tbaa !29
  store i1 false, ptr %l226, !tbaa !21
  %t468 = load ptr, ptr %l225, !tbaa !29
  %t469 = icmp ne ptr %t468, null
  br i1 %t469, label %bb62, label %bb63
bb62:
  %t471 = load ptr, ptr %l225, !tbaa !29
  %t472 = load i64, ptr %t471, !range !{i64 0, i64 18}
  %t474 = icmp eq i64 %t472, 9
  store i1 %t474, ptr %l226, !tbaa !21
  br label %bb63
bb63:
  %t475 = load i1, ptr %l226, !tbaa !21
  br i1 %t475, label %bb64, label %bb65
bb64:
  %t476 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr { i64, [5 x i64] }, ptr %t476, i32 0, i32 1
  %t479 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t478, i32 0, i32 0
  %t480 = load %"compiler/source:Span", ptr %t479
  store %"compiler/source:Span" %t480, ptr %l28
  %t482 = load ptr, ptr %l1, !tbaa !29
  %t484 = getelementptr { i64, [5 x i64] }, ptr %t482, i32 0, i32 1
  %t485 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t484, i32 0, i32 1
  %t486 = load i32, ptr %t485
  store i32 %t486, ptr %l29, !tbaa !23
  %t488 = load ptr, ptr %l1, !tbaa !29
  %t490 = getelementptr { i64, [5 x i64] }, ptr %t488, i32 0, i32 1
  %t491 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t490, i32 0, i32 2
  %t492 = load i32, ptr %t491, !range !{i32 0, i32 49}
  store i32 %t492, ptr %l30
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t496 = getelementptr { i64, [5 x i64] }, ptr %t494, i32 0, i32 1
  %t497 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t496, i32 0, i32 3
  %t498 = load i32, ptr %t497, !range !{i32 0, i32 3}
  store i32 %t498, ptr %l31
  %t500 = load ptr, ptr %l1, !tbaa !29
  %t502 = getelementptr { i64, [5 x i64] }, ptr %t500, i32 0, i32 1
  %t503 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t502, i32 0, i32 4
  %t504 = load { i64, ptr }, ptr %t503
  store { i64, ptr } %t504, ptr %l32, !tbaa !27
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t506 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t506, ptr %l239
  %t507 = load i32, ptr %l29, !tbaa !23
  store i32 %t507, ptr %l240, !tbaa !23
  %t508 = load i32, ptr %l30, !range !{i32 0, i32 49}
  store i32 %t508, ptr %l241
  %t509 = load i32, ptr %l31, !range !{i32 0, i32 3}
  store i32 %t509, ptr %l242
  %t510 = load ptr, ptr %l0, !tbaa !29
  %t511 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t512 = load i64, ptr %l2, !tbaa !24
  %t516 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %v2, ptr %t510, { i64, ptr } %t511, i64 %t512)
  store { i64, ptr } %t516, ptr %l246
  br label %bb67
bb67:
  store { i64, [5 x i64] } zeroinitializer, ptr %t517
  %t518 = getelementptr { i64, [5 x i64] }, ptr %t517, i32 0, i32 0
  store i64 9, ptr %t518
  %t519 = load %"compiler/source:Span", ptr %l239
  %t520 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t519, 0
  %t521 = load i32, ptr %l240, !tbaa !23
  %t522 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t520, i32 %t521, 1
  %t523 = load i32, ptr %l241, !range !{i32 0, i32 49}
  %t524 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t522, i32 %t523, 2
  %t525 = load i32, ptr %l242, !range !{i32 0, i32 3}
  %t526 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t524, i32 %t525, 3
  %t527 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t528 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t526, { i64, ptr } %t527, 4
  %t529 = getelementptr { i64, [5 x i64] }, ptr %t517, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t528, ptr %t529
  %t530 = load { i64, [5 x i64] }, ptr %t517
  %t532 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t530, ptr %t532
  store ptr %t532, ptr %rv
  br label %ret
bb68:
  %t534 = load ptr, ptr %l1, !tbaa !29
  store ptr %t534, ptr %l249, !tbaa !29
  store i1 false, ptr %l250, !tbaa !21
  %t535 = load ptr, ptr %l249, !tbaa !29
  %t536 = icmp ne ptr %t535, null
  br i1 %t536, label %bb69, label %bb70
bb69:
  %t538 = load ptr, ptr %l249, !tbaa !29
  %t539 = load i64, ptr %t538, !range !{i64 0, i64 18}
  %t541 = icmp eq i64 %t539, 10
  store i1 %t541, ptr %l250, !tbaa !21
  br label %bb70
bb70:
  %t542 = load i1, ptr %l250, !tbaa !21
  br i1 %t542, label %bb71, label %bb72
bb71:
  %t543 = load ptr, ptr %l1, !tbaa !29
  %t545 = getelementptr { i64, [5 x i64] }, ptr %t543, i32 0, i32 1
  %t546 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t545, i32 0, i32 0
  %t547 = load %"compiler/source:Span", ptr %t546
  store %"compiler/source:Span" %t547, ptr %l33
  %t549 = load ptr, ptr %l1, !tbaa !29
  %t551 = getelementptr { i64, [5 x i64] }, ptr %t549, i32 0, i32 1
  %t552 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t551, i32 0, i32 1
  %t553 = load i32, ptr %t552
  store i32 %t553, ptr %l34, !tbaa !23
  %t555 = load ptr, ptr %l1, !tbaa !29
  %t557 = getelementptr { i64, [5 x i64] }, ptr %t555, i32 0, i32 1
  %t558 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t557, i32 0, i32 2
  %t559 = load ptr, ptr %t558
  store ptr %t559, ptr %l35, !tbaa !29
  br label %bb73
bb72:
  br label %bb78
bb73:
  %t561 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t561, ptr %l259
  %t562 = load i32, ptr %l34, !tbaa !23
  store i32 %t562, ptr %l260, !tbaa !23
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load ptr, ptr %l35, !tbaa !29
  %t566 = getelementptr %"compiler/typed:Slice", ptr %t564, i32 0, i32 0
  %t567 = load ptr, ptr %t566, !tbaa !29
  %t568 = load i64, ptr %l2, !tbaa !24
  %t572 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %v0, ptr %t563, ptr %t567, i64 %t568)
  store ptr %t572, ptr %l265
  br label %bb74
bb74:
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t574 = load ptr, ptr %l35, !tbaa !29
  %t576 = getelementptr %"compiler/typed:Slice", ptr %t574, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !29
  %t578 = load i64, ptr %l2, !tbaa !24
  %t582 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t573, ptr %t577, i64 %t578)
  store ptr %t582, ptr %l270
  br label %bb75
bb75:
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t584 = load ptr, ptr %l35, !tbaa !29
  %t586 = getelementptr %"compiler/typed:Slice", ptr %t584, i32 0, i32 2
  %t587 = load ptr, ptr %t586, !tbaa !29
  %t588 = load i64, ptr %l2, !tbaa !24
  %t592 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t583, ptr %t587, i64 %t588)
  store ptr %t592, ptr %l275
  br label %bb76
bb76:
  %t593 = load ptr, ptr %l35, !tbaa !29
  %t595 = getelementptr %"compiler/typed:Slice", ptr %t593, i32 0, i32 3
  %t596 = load i32, ptr %t595, !range !{i32 0, i32 3}
  %t597 = load ptr, ptr %l265, !tbaa !29
  %t598 = load ptr, ptr %l270, !tbaa !29
  %t599 = load ptr, ptr %l275, !tbaa !29
  %t601 = call %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %t597, ptr %t598, ptr %t599, i32 %t596)
  store %"compiler/typed:Slice" %t601, ptr %l278
  br label %bb77
bb77:
  %t602 = load %"compiler/typed:Slice", ptr %l278
  %t603 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Slice" %t602, ptr %t603
  store { i64, [5 x i64] } zeroinitializer, ptr %t604
  %t605 = getelementptr { i64, [5 x i64] }, ptr %t604, i32 0, i32 0
  store i64 10, ptr %t605
  %t606 = load %"compiler/source:Span", ptr %l259
  %t607 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t606, 0
  %t608 = load i32, ptr %l260, !tbaa !23
  %t609 = insertvalue { %"compiler/source:Span", i32, ptr } %t607, i32 %t608, 1
  %t611 = insertvalue { %"compiler/source:Span", i32, ptr } %t609, ptr %t603, 2
  %t612 = getelementptr { i64, [5 x i64] }, ptr %t604, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t611, ptr %t612
  %t613 = load { i64, [5 x i64] }, ptr %t604
  %t615 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t613, ptr %t615
  store ptr %t615, ptr %rv
  br label %ret
bb78:
  %t617 = load ptr, ptr %l1, !tbaa !29
  store ptr %t617, ptr %l282, !tbaa !29
  store i1 false, ptr %l283, !tbaa !21
  %t618 = load ptr, ptr %l282, !tbaa !29
  %t619 = icmp ne ptr %t618, null
  br i1 %t619, label %bb79, label %bb80
bb79:
  %t621 = load ptr, ptr %l282, !tbaa !29
  %t622 = load i64, ptr %t621, !range !{i64 0, i64 18}
  %t624 = icmp eq i64 %t622, 11
  store i1 %t624, ptr %l283, !tbaa !21
  br label %bb80
bb80:
  %t625 = load i1, ptr %l283, !tbaa !21
  br i1 %t625, label %bb81, label %bb82
bb81:
  %t626 = load ptr, ptr %l1, !tbaa !29
  %t628 = getelementptr { i64, [5 x i64] }, ptr %t626, i32 0, i32 1
  %t629 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t628, i32 0, i32 0
  %t630 = load %"compiler/source:Span", ptr %t629
  store %"compiler/source:Span" %t630, ptr %l36
  %t632 = load ptr, ptr %l1, !tbaa !29
  %t634 = getelementptr { i64, [5 x i64] }, ptr %t632, i32 0, i32 1
  %t635 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t634, i32 0, i32 1
  %t636 = load i32, ptr %t635
  store i32 %t636, ptr %l37, !tbaa !23
  %t638 = load ptr, ptr %l1, !tbaa !29
  %t640 = getelementptr { i64, [5 x i64] }, ptr %t638, i32 0, i32 1
  %t641 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t640, i32 0, i32 2
  %t642 = load ptr, ptr %t641
  store ptr %t642, ptr %l38, !tbaa !29
  br label %bb83
bb82:
  br label %bb94
bb83:
  store ptr null, ptr %l39, !tbaa !29
  %t644 = load ptr, ptr %l38, !tbaa !29
  %t646 = getelementptr %"compiler/typed:Cond", ptr %t644, i32 0, i32 1
  %t647 = load ptr, ptr %t646, !tbaa !29
  %t649 = icmp eq ptr %t647, null
  %t651 = xor i1 %t649, true
  br i1 %t651, label %bb84, label %bb85
bb84:
  %t653 = load ptr, ptr %l0, !tbaa !29
  store ptr %t653, ptr %l296, !tbaa !29
  %t654 = load ptr, ptr %l38, !tbaa !29
  %t656 = getelementptr %"compiler/typed:Cond", ptr %t654, i32 0, i32 1
  %t657 = load ptr, ptr %t656, !tbaa !29
  %t659 = icmp eq ptr %t657, null
  br i1 %t659, label %bb86, label %bb87
bb85:
  br label %bb90
bb86:
  call void @__olang_check_failed(ptr @olang_loc_89a248f11218248d_cad7b116269b1029)
  unreachable
bb87:
  br label %bb88
bb88:
  %t661 = load ptr, ptr %l38, !tbaa !29
  %t663 = getelementptr %"compiler/typed:Cond", ptr %t661, i32 0, i32 1
  %t664 = load ptr, ptr %t663, !tbaa !29
  %t665 = load i64, ptr %l2, !tbaa !24
  %t666 = load ptr, ptr %l296, !tbaa !29
  %t669 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t666, ptr %t664, i64 %t665)
  store ptr %t669, ptr %l303
  br label %bb89
bb89:
  %t670 = load ptr, ptr %l303, !tbaa !29
  store ptr %t670, ptr %l39, !tbaa !29
  br label %bb90
bb90:
  %t672 = load %"compiler/source:Span", ptr %l36
  store %"compiler/source:Span" %t672, ptr %l305
  %t673 = load i32, ptr %l37, !tbaa !23
  store i32 %t673, ptr %l306, !tbaa !23
  %t674 = load ptr, ptr %l0, !tbaa !29
  %t675 = load ptr, ptr %l38, !tbaa !29
  %t677 = getelementptr %"compiler/typed:Cond", ptr %t675, i32 0, i32 0
  %t678 = load ptr, ptr %t677, !tbaa !29
  %t679 = load i64, ptr %l2, !tbaa !24
  %t683 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t674, ptr %t678, i64 %t679)
  store ptr %t683, ptr %l311
  br label %bb91
bb91:
  %t684 = load ptr, ptr %l39, !tbaa !29
  store ptr %t684, ptr %l312, !tbaa !29
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load ptr, ptr %l38, !tbaa !29
  %t688 = getelementptr %"compiler/typed:Cond", ptr %t686, i32 0, i32 2
  %t689 = load ptr, ptr %t688, !tbaa !29
  %t690 = load i64, ptr %l2, !tbaa !24
  %t694 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t685, ptr %t689, i64 %t690)
  store ptr %t694, ptr %l317
  br label %bb92
bb92:
  %t695 = load ptr, ptr %l311, !tbaa !29
  %t696 = load ptr, ptr %l312, !tbaa !29
  %t697 = load ptr, ptr %l317, !tbaa !29
  %t698 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v2, ptr %v0, ptr %v2, ptr %t695, ptr %t696, ptr %t697)
  store %"compiler/typed:Cond" %t698, ptr %l318
  br label %bb93
bb93:
  %t699 = load %"compiler/typed:Cond", ptr %l318
  %t700 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Cond" %t699, ptr %t700
  store { i64, [5 x i64] } zeroinitializer, ptr %t701
  %t702 = getelementptr { i64, [5 x i64] }, ptr %t701, i32 0, i32 0
  store i64 11, ptr %t702
  %t703 = load %"compiler/source:Span", ptr %l305
  %t704 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t703, 0
  %t705 = load i32, ptr %l306, !tbaa !23
  %t706 = insertvalue { %"compiler/source:Span", i32, ptr } %t704, i32 %t705, 1
  %t708 = insertvalue { %"compiler/source:Span", i32, ptr } %t706, ptr %t700, 2
  %t709 = getelementptr { i64, [5 x i64] }, ptr %t701, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t708, ptr %t709
  %t710 = load { i64, [5 x i64] }, ptr %t701
  %t712 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t710, ptr %t712
  store ptr %t712, ptr %rv
  br label %ret
bb94:
  %t714 = load ptr, ptr %l1, !tbaa !29
  store ptr %t714, ptr %l322, !tbaa !29
  store i1 false, ptr %l323, !tbaa !21
  %t715 = load ptr, ptr %l322, !tbaa !29
  %t716 = icmp ne ptr %t715, null
  br i1 %t716, label %bb95, label %bb96
bb95:
  %t718 = load ptr, ptr %l322, !tbaa !29
  %t719 = load i64, ptr %t718, !range !{i64 0, i64 18}
  %t721 = icmp eq i64 %t719, 17
  store i1 %t721, ptr %l323, !tbaa !21
  br label %bb96
bb96:
  %t722 = load i1, ptr %l323, !tbaa !21
  br i1 %t722, label %bb97, label %bb98
bb97:
  %t723 = load ptr, ptr %l1, !tbaa !29
  %t725 = getelementptr { i64, [5 x i64] }, ptr %t723, i32 0, i32 1
  %t726 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t725, i32 0, i32 0
  %t727 = load %"compiler/source:Span", ptr %t726
  store %"compiler/source:Span" %t727, ptr %l40
  %t729 = load ptr, ptr %l1, !tbaa !29
  %t731 = getelementptr { i64, [5 x i64] }, ptr %t729, i32 0, i32 1
  %t732 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t731, i32 0, i32 1
  %t733 = load i64, ptr %t732
  store i64 %t733, ptr %l41, !tbaa !24
  %t735 = load ptr, ptr %l1, !tbaa !29
  %t737 = getelementptr { i64, [5 x i64] }, ptr %t735, i32 0, i32 1
  %t738 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t737, i32 0, i32 2
  %t739 = load ptr, ptr %t738
  store ptr %t739, ptr %l42, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t741 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t741, ptr %l332
  %t742 = load i64, ptr %l41, !tbaa !24
  store i64 %t742, ptr %l333, !tbaa !24
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t744 = load ptr, ptr %l42, !tbaa !29
  %t745 = load i64, ptr %l2, !tbaa !24
  %t749 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t743, ptr %t744, i64 %t745)
  store ptr %t749, ptr %l337
  br label %bb100
bb100:
  store { i64, [5 x i64] } zeroinitializer, ptr %t750
  %t751 = getelementptr { i64, [5 x i64] }, ptr %t750, i32 0, i32 0
  store i64 17, ptr %t751
  %t752 = load %"compiler/source:Span", ptr %l332
  %t753 = insertvalue { %"compiler/source:Span", i64, ptr } undef, %"compiler/source:Span" %t752, 0
  %t754 = load i64, ptr %l333, !tbaa !24
  %t755 = insertvalue { %"compiler/source:Span", i64, ptr } %t753, i64 %t754, 1
  %t756 = load ptr, ptr %l337, !tbaa !29
  %t757 = insertvalue { %"compiler/source:Span", i64, ptr } %t755, ptr %t756, 2
  %t758 = getelementptr { i64, [5 x i64] }, ptr %t750, i32 0, i32 1
  store { %"compiler/source:Span", i64, ptr } %t757, ptr %t758
  %t759 = load { i64, [5 x i64] }, ptr %t750
  %t761 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t759, ptr %t761
  store ptr %t761, ptr %rv
  br label %ret
bb101:
  %t763 = load ptr, ptr %l1, !tbaa !29
  store ptr %t763, ptr %l340, !tbaa !29
  store i1 false, ptr %l341, !tbaa !21
  %t764 = load ptr, ptr %l340, !tbaa !29
  %t765 = icmp ne ptr %t764, null
  br i1 %t765, label %bb102, label %bb103
bb102:
  %t767 = load ptr, ptr %l340, !tbaa !29
  %t768 = load i64, ptr %t767, !range !{i64 0, i64 18}
  %t770 = icmp eq i64 %t768, 15
  store i1 %t770, ptr %l341, !tbaa !21
  br label %bb103
bb103:
  %t771 = load i1, ptr %l341, !tbaa !21
  br i1 %t771, label %bb104, label %bb105
bb104:
  %t772 = load ptr, ptr %l1, !tbaa !29
  %t774 = getelementptr { i64, [5 x i64] }, ptr %t772, i32 0, i32 1
  %t775 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t774, i32 0, i32 0
  %t776 = load %"compiler/source:Span", ptr %t775
  store %"compiler/source:Span" %t776, ptr %l43
  %t778 = load ptr, ptr %l1, !tbaa !29
  %t780 = getelementptr { i64, [5 x i64] }, ptr %t778, i32 0, i32 1
  %t781 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t780, i32 0, i32 1
  %t782 = load i32, ptr %t781
  store i32 %t782, ptr %l44, !tbaa !23
  %t784 = load ptr, ptr %l1, !tbaa !29
  %t786 = getelementptr { i64, [5 x i64] }, ptr %t784, i32 0, i32 1
  %t787 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t786, i32 0, i32 2
  %t788 = load ptr, ptr %t787
  store ptr %t788, ptr %l45, !tbaa !29
  br label %bb106
bb105:
  br label %bb118
bb106:
  %t790 = load ptr, ptr %l45, !tbaa !29
  store ptr %t790, ptr %l350, !tbaa !29
  store i1 false, ptr %l351, !tbaa !21
  %t791 = load ptr, ptr %l350, !tbaa !29
  %t792 = icmp ne ptr %t791, null
  br i1 %t792, label %bb107, label %bb108
bb107:
  %t794 = load ptr, ptr %l350, !tbaa !29
  %t795 = load i64, ptr %t794, !range !{i64 0, i64 3}
  %t797 = icmp eq i64 %t795, 0
  store i1 %t797, ptr %l351, !tbaa !21
  br label %bb108
bb108:
  %t798 = load i1, ptr %l351, !tbaa !21
  br i1 %t798, label %bb109, label %bb110
bb109:
  %t799 = load ptr, ptr %l45, !tbaa !29
  %t801 = getelementptr { i64, [4 x i64] }, ptr %t799, i32 0, i32 1
  %t802 = getelementptr { i32 }, ptr %t801, i32 0, i32 0
  %t803 = load i32, ptr %t802
  store i32 %t803, ptr %l46, !tbaa !23
  br label %bb111
bb110:
  br label %bb112
bb111:
  %t805 = load %"compiler/source:Span", ptr %l43
  %t806 = load i32, ptr %l44, !tbaa !23
  %t807 = load i32, ptr %l46, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t808
  %t809 = getelementptr { i64, [4 x i64] }, ptr %t808, i32 0, i32 0
  store i64 0, ptr %t809
  %t811 = insertvalue { i32 } undef, i32 %t807, 0
  %t812 = getelementptr { i64, [4 x i64] }, ptr %t808, i32 0, i32 1
  store { i32 } %t811, ptr %t812
  %t813 = load { i64, [4 x i64] }, ptr %t808
  %t815 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t813, ptr %t815
  store { i64, [5 x i64] } zeroinitializer, ptr %t816
  %t817 = getelementptr { i64, [5 x i64] }, ptr %t816, i32 0, i32 0
  store i64 15, ptr %t817
  %t819 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t805, 0
  %t821 = insertvalue { %"compiler/source:Span", i32, ptr } %t819, i32 %t806, 1
  %t823 = insertvalue { %"compiler/source:Span", i32, ptr } %t821, ptr %t815, 2
  %t824 = getelementptr { i64, [5 x i64] }, ptr %t816, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t823, ptr %t824
  %t825 = load { i64, [5 x i64] }, ptr %t816
  %t827 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t825, ptr %t827
  store ptr %t827, ptr %rv
  br label %ret
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @olang_loc_eb46e205ba3ff6f_6cc0aaf3953c4d5b)
  unreachable
bb117:
  br label %bb123
bb118:
  br i1 true, label %bb119, label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb122
bb121:
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_b8f4ea1c8ca382ae_7341728a048bae5a)
  unreachable
bb123:
  %t829 = load ptr, ptr %l0, !tbaa !29
  store ptr %t829, ptr %l363, !tbaa !29
  %t830 = load ptr, ptr %l1, !tbaa !29
  %t832 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t830)
  store %"compiler/source:Span" %t832, ptr %l365
  br label %bb124
bb124:
  %t833 = load ptr, ptr %l363, !tbaa !29
  %t834 = load %"compiler/source:Span", ptr %l365
  %t835 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t833, %"compiler/source:Span" %t834)
  store ptr %t835, ptr %l366
  br label %bb125
bb125:
  %t836 = load ptr, ptr %l366, !tbaa !29
  store ptr %t836, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i64 %a5, i32 %a6, i64 %a7, i64 %a8, ptr %a9, i32 %a10) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l19 = alloca i64
  %l20 = alloca { i64, i64, i64 }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca { i64, i64, i64 }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l41 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i32
  %l62 = alloca ptr
  %l64 = alloca i32
  %l67 = alloca i32
  %l68 = alloca i32
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l77 = alloca i32
  %l81 = alloca ptr
  %l86 = alloca ptr
  %l90 = alloca ptr
  %l106 = alloca i64
  %l110 = alloca { i64, i64, i64 }
  %l115 = alloca ptr
  %l120 = alloca ptr
  %l127 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca i32
  %l137 = alloca i32
  %l141 = alloca ptr
  %l145 = alloca ptr
  %l147 = alloca ptr
  %l149 = alloca ptr
  %l152 = alloca i32
  %l163 = alloca i64
  %l164 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l168 = alloca i32
  %l172 = alloca ptr
  %l179 = alloca i32
  %l180 = alloca %"compiler/source:Span"
  %l185 = alloca i32
  %l189 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l194 = alloca %"compiler/source:Span"
  %l199 = alloca i32
  %l200 = alloca ptr
  %l204 = alloca ptr
  %l206 = alloca %"compiler/typed:Elem"
  %l210 = alloca ptr
  %l215 = alloca ptr
  %l217 = alloca ptr
  %l218 = alloca %"compiler/source:Span"
  %l219 = alloca i32
  %l220 = alloca i32
  %l224 = alloca ptr
  %l225 = alloca ptr
  %l226 = alloca %"compiler/source:Span"
  %l227 = alloca i32
  %l228 = alloca i32
  %l232 = alloca ptr
  %l236 = alloca ptr
  %l238 = alloca ptr
  %l240 = alloca ptr
  %l242 = alloca ptr
  %l244 = alloca i32
  %l245 = alloca %"compiler/source:Span"
  %l247 = alloca i32
  %l250 = alloca i64
  %l255 = alloca ptr
  %l257 = alloca ptr
  %l261 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l267 = alloca ptr
  %l269 = alloca ptr
  %l273 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l275 = alloca ptr
  %l277 = alloca ptr
  %l281 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l282 = alloca ptr
  %l283 = alloca %"compiler/source:Span"
  %l284 = alloca ptr
  %l285 = alloca i64
  %l289 = alloca ptr
  %l290 = alloca %"compiler/source:Span"
  %l293 = alloca i32
  %l303 = alloca i64
  %l305 = alloca ptr
  %l308 = alloca i64
  %l309 = alloca i32
  %l310 = alloca i64
  %l312 = alloca ptr
  %l315 = alloca i64
  %l316 = alloca i32
  %l322 = alloca ptr
  %l325 = alloca i64
  %l329 = alloca { i64, i64, i64 }
  %l333 = alloca ptr
  %l334 = alloca %"compiler/source:Span"
  %l335 = alloca i32
  %l336 = alloca i32
  %l340 = alloca ptr
  %l344 = alloca ptr
  %l346 = alloca ptr
  %l364 = alloca ptr
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t91 = alloca { i64, [3 x i64] }, align 8
  %t253 = alloca { i64, [1 x i64] }, align 8
  %t277 = alloca { i64, [3 x i64] }, align 8
  %t329 = alloca { i64, [4 x i64] }, align 8
  %t369 = alloca { i64, [4 x i64] }, align 8
  %t440 = alloca { i64, [1 x i64] }, align 8
  %t543 = alloca { i64, [3 x i64] }, align 8
  %t659 = alloca { i64, [4 x i64] }, align 8
  %t672 = alloca { i64, [3 x i64] }, align 8
  %t703 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a5, ptr %l5
  store ptr %a9, ptr %l9
  store i32 %a10, ptr %l10
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  %t5 = xor i1 %t3, true
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 107
  %t10 = load i64, ptr %t9, !tbaa !24
  %t12 = icmp eq i64 %t10, 1
  store i1 %t12, ptr %l41, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l41, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Compr", ptr %t15, i32 0, i32 5
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb6, label %bb7
bb5:
  br label %bb24
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 114
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp sge i64 %t25, 0
  store i1 %t27, ptr %l48, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l48, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load i32, ptr %l10, !tbaa !23
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = icmp ne i32 %t30, %t31
  store i1 %t34, ptr %l52, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l52, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l58, !tbaa !29
  %t43 = load i32, ptr %l10, !tbaa !23
  store i32 %t43, ptr %l59, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  store ptr %t49, ptr %l62, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t50)
  store i32 %t52, ptr %l64
  br label %bb14
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %t53, %"compiler/source:Span" %t54)
  br label %bb22
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 114
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = load ptr, ptr %l62, !tbaa !29
  %t62 = load i32, ptr %l64, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t61, i32 %t62, i64 %t60)
  store i32 %t64, ptr %l67
  br label %bb15
bb15:
  %t65 = load ptr, ptr %l58, !tbaa !29
  %t66 = load i32, ptr %l59, !tbaa !23
  %t67 = load i32, ptr %l67, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t65, i32 %t66, i32 %t67)
  store i32 %t68, ptr %l68
  br label %bb16
bb16:
  %t69 = load i32, ptr %l68, !tbaa !23
  store i32 %t69, ptr %l11, !tbaa !23
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l1
  %t72 = load i32, ptr %l11, !tbaa !23
  %t76 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t70, %"compiler/source:Span" %t71, i32 %t72)
  store i64 %t76, ptr %l72
  br label %bb17
bb17:
  %t77 = load i64, ptr %l72, !tbaa !24
  store i64 %t77, ptr %l12, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l73, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t79, ptr %l74
  %t80 = load i64, ptr %l12, !tbaa !24
  %t82 = trunc i64 %t80 to i32
  store i32 %t82, ptr %l77, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l1
  %t86 = load i32, ptr %l11, !tbaa !23
  %t90 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t84, %"compiler/source:Span" %t85, i32 %t86, i64 0)
  store ptr %t90, ptr %l81
  br label %bb18
bb18:
  store { i64, [3 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [3 x i64] }, ptr %t91, i32 0, i32 0
  store i64 0, ptr %t92
  %t93 = load %"compiler/source:Span", ptr %l74
  %t94 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t93, 0
  %t95 = load i32, ptr %l77, !tbaa !23
  %t96 = insertvalue { %"compiler/source:Span", i32, ptr } %t94, i32 %t95, 1
  %t97 = load ptr, ptr %l81, !tbaa !29
  %t98 = insertvalue { %"compiler/source:Span", i32, ptr } %t96, ptr %t97, 2
  %t99 = getelementptr { i64, [3 x i64] }, ptr %t91, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t98, ptr %t99
  %t100 = load { i64, [3 x i64] }, ptr %t91
  %t102 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t100, ptr %t102
  %t103 = load ptr, ptr %l73, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t103, ptr %t102)
  br label %bb19
bb19:
  %t105 = load i64, ptr %l12, !tbaa !24
  store i64 %t105, ptr %l13, !tbaa !24
  store i1 true, ptr %l14, !tbaa !21
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t107)
  store ptr %t109, ptr %l86
  br label %bb20
bb20:
  %t110 = load ptr, ptr %l86, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Body", ptr %t110, i32 0, i32 7
  %t113 = load i64, ptr %l13, !tbaa !24
  %t116 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v0, ptr %t112, i64 %t113)
  store ptr %t116, ptr %l90
  br label %bb21
bb21:
  %t117 = load ptr, ptr %l90, !tbaa !29
  %t119 = load i1, ptr %l14, !tbaa !21
  %t122 = getelementptr %"compiler/typed:Local", ptr %t117, i32 0, i32 6
  store i1 %t119, ptr %t122, !tbaa !21
  %t123 = load i64, ptr %l12, !tbaa !24
  %t125 = load i64, ptr %l3, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 112
  store i64 %t123, ptr %t131, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 113
  store i64 %t125, ptr %t136, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 107
  store i64 3, ptr %t141, !tbaa !24
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 114
  store i64 -1, ptr %t144, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 37
  %t149 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t147)
  store i64 %t149, ptr %l106
  br label %bb25
bb25:
  %t150 = load i64, ptr %l106, !tbaa !24
  store i64 %t150, ptr %l19, !tbaa !24
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load %"compiler/source:Span", ptr %l1
  %t156 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t151, i32 2, %"compiler/source:Span" %t152)
  store { i64, i64, i64 } %t156, ptr %l110
  br label %bb26
bb26:
  %t157 = load { i64, i64, i64 }, ptr %l110
  store { i64, i64, i64 } %t157, ptr %l20
  %t158 = getelementptr { i64, i64, i64 }, ptr %l20, i32 0, i32 0
  %t159 = load i64, ptr %t158, !tbaa !24
  store i64 %t159, ptr %l21, !tbaa !24
  %t161 = getelementptr { i64, i64, i64 }, ptr %l20, i32 0, i32 1
  %t162 = load i64, ptr %t161, !tbaa !24
  store i64 %t162, ptr %l22, !tbaa !24
  %t164 = getelementptr { i64, i64, i64 }, ptr %l20, i32 0, i32 2
  %t165 = load i64, ptr %t164, !tbaa !24
  store i64 %t165, ptr %l23, !tbaa !24
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t167)
  store ptr %t169, ptr %l115
  br label %bb27
bb27:
  %t170 = load ptr, ptr %l115, !tbaa !29
  %t172 = getelementptr %"compiler/check:frame", ptr %t170, i32 0, i32 10
  %t173 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t172, i64 %t173)
  br label %bb28
bb28:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t176)
  store ptr %t178, ptr %l120
  br label %bb29
bb29:
  %t179 = load ptr, ptr %l120, !tbaa !29
  %t181 = getelementptr %"compiler/typed:Body", ptr %t179, i32 0, i32 19
  %t182 = load i64, ptr %l21, !tbaa !24
  %t184 = trunc i64 %t182 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t181, i32 %t184)
  br label %bb30
bb30:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t188)
  store ptr %t190, ptr %l127
  br label %bb31
bb31:
  %t191 = load ptr, ptr %l127, !tbaa !29
  %t193 = getelementptr %"compiler/check:frame", ptr %t191, i32 0, i32 11
  %t194 = load i64, ptr %l21, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t193, i64 %t194)
  br label %bb32
bb32:
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l131, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l132, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t199, ptr %l133
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l134, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t201, ptr %l135
  %t202 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t202, ptr %l136, !tbaa !23
  store i32 15, ptr %l137
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l1
  %t205 = load i64, ptr %l3, !tbaa !24
  %t209 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t203, %"compiler/source:Span" %t204, i64 %t205)
  store ptr %t209, ptr %l141
  br label %bb33
bb33:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  %t216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t210, %"compiler/source:Span" %t211, i64 %a4)
  store ptr %t216, ptr %l145
  br label %bb34
bb34:
  %t217 = load ptr, ptr %l145, !tbaa !29
  %t218 = load ptr, ptr %l134, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l135
  %t220 = load i32, ptr %l136, !tbaa !23
  %t221 = load i32, ptr %l137, !range !{i32 0, i32 49}
  %t222 = load ptr, ptr %l141, !tbaa !29
  %t224 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t218, %"compiler/source:Span" %t219, i32 %t220, i32 %t221, ptr %t222, ptr %t217)
  store ptr %t224, ptr %l147
  br label %bb35
bb35:
  %t225 = load i64, ptr %l21, !tbaa !24
  %t226 = load ptr, ptr %l132, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l133
  %t228 = load ptr, ptr %l147, !tbaa !29
  %t230 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v0, ptr %v0, ptr %t226, %"compiler/source:Span" %t227, ptr %t228, i64 %t225)
  store ptr %t230, ptr %l149
  br label %bb36
bb36:
  %t231 = load ptr, ptr %l131, !tbaa !29
  %t232 = load ptr, ptr %l149, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t231, ptr %t232)
  br label %bb37
bb37:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i64, ptr %l3, !tbaa !24
  %t237 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t233, i64 %t234)
  store i32 %t237, ptr %l152
  br label %bb38
bb38:
  %t238 = load i32, ptr %l152, !tbaa !23
  store i32 %t238, ptr %l24, !tbaa !23
  %t239 = load ptr, ptr %l2, !tbaa !29
  %t241 = getelementptr %"compiler/ast:ForIn", ptr %t239, i32 0, i32 0
  %t242 = load i32, ptr %t241, !tbaa !23
  %t244 = icmp ne i32 %t242, 0
  br i1 %t244, label %bb39, label %bb40
bb39:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load ptr, ptr %l2, !tbaa !29
  %t249 = getelementptr %"compiler/ast:ForIn", ptr %t247, i32 0, i32 0
  %t250 = load i32, ptr %t249, !tbaa !23
  %t251 = load %"compiler/source:Span", ptr %l1
  %t252 = load i32, ptr %l24, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [1 x i64] }, ptr %t253, i32 0, i32 0
  store i64 0, ptr %t254
  %t255 = load { i64, [1 x i64] }, ptr %t253
  %t262 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t246, i32 %t250, %"compiler/source:Span" %t251, i32 %t252, i32 1, { i64, [1 x i64] } %t255)
  store i64 %t262, ptr %l163
  br label %bb41
bb40:
  br label %bb44
bb41:
  %t263 = load i64, ptr %l163, !tbaa !24
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l164, !tbaa !29
  %t265 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t265, ptr %l165
  %t268 = trunc i64 %t263 to i32
  store i32 %t268, ptr %l168, !tbaa !23
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l1
  %t272 = load i64, ptr %l3, !tbaa !24
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t270, %"compiler/source:Span" %t271, i64 %t272)
  store ptr %t276, ptr %l172
  br label %bb42
bb42:
  store { i64, [3 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 0
  store i64 0, ptr %t278
  %t279 = load %"compiler/source:Span", ptr %l165
  %t280 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t279, 0
  %t281 = load i32, ptr %l168, !tbaa !23
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } %t280, i32 %t281, 1
  %t283 = load ptr, ptr %l172, !tbaa !29
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, ptr %t283, 2
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t284, ptr %t285
  %t286 = load { i64, [3 x i64] }, ptr %t277
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t286, ptr %t288
  %t289 = load ptr, ptr %l164, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t289, ptr %t288)
  br label %bb43
bb43:
  br label %bb44
bb44:
  store ptr null, ptr %l26, !tbaa !29
  %t291 = load i64, ptr %l5, !tbaa !24
  %t293 = icmp sge i64 %t291, 0
  br i1 %t293, label %bb45, label %bb46
bb45:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load i64, ptr %l5, !tbaa !24
  %t299 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t295, i64 %t296)
  store i32 %t299, ptr %l179
  br label %bb47
bb46:
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l217, !tbaa !29
  %t301 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t301, ptr %l218
  %t302 = load i32, ptr %l24, !tbaa !23
  store i32 %t302, ptr %l219, !tbaa !23
  store i32 3, ptr %l220
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l1
  %t309 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t303, %"compiler/source:Span" %t304, i64 %a7)
  store ptr %t309, ptr %l224
  br label %bb55
bb47:
  %t310 = load i32, ptr %l179, !tbaa !23
  %t311 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t311, ptr %l180
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/check:Checker", ptr %t312, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 2
  %t321 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t317, i32 %t310)
  store i32 %t321, ptr %l185
  br label %bb48
bb48:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l1
  %t324 = load i64, ptr %l5, !tbaa !24
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t322, %"compiler/source:Span" %t323, i64 %t324)
  store ptr %t328, ptr %l189
  br label %bb49
bb49:
  store { i64, [4 x i64] } zeroinitializer, ptr %t329
  %t330 = getelementptr { i64, [4 x i64] }, ptr %t329, i32 0, i32 0
  store i64 2, ptr %t330
  %t331 = load %"compiler/source:Span", ptr %l180
  %t332 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t331, 0
  %t333 = load i32, ptr %l185, !tbaa !23
  %t334 = insertvalue { %"compiler/source:Span", i32, ptr } %t332, i32 %t333, 1
  %t335 = load ptr, ptr %l189, !tbaa !29
  %t336 = insertvalue { %"compiler/source:Span", i32, ptr } %t334, ptr %t335, 2
  %t337 = getelementptr { i64, [4 x i64] }, ptr %t329, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t336, ptr %t337
  %t338 = load { i64, [4 x i64] }, ptr %t329
  %t340 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t338, ptr %t340
  store ptr %t340, ptr %l28, !tbaa !29
  %t342 = load ptr, ptr %l0, !tbaa !29
  store ptr %t342, ptr %l192, !tbaa !29
  %t343 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t343, ptr %l193
  %t344 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t344, ptr %l194
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t350 = getelementptr %"compiler/generic:Program", ptr %t348, i32 0, i32 2
  %t354 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t350, i32 %a6)
  store i32 %t354, ptr %l199
  br label %bb50
bb50:
  %t355 = load ptr, ptr %l28, !tbaa !29
  store ptr %t355, ptr %l200, !tbaa !29
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l1
  %t358 = load i64, ptr %l3, !tbaa !24
  %t362 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t356, %"compiler/source:Span" %t357, i64 %t358)
  store ptr %t362, ptr %l204
  br label %bb51
bb51:
  %t363 = load ptr, ptr %l200, !tbaa !29
  %t364 = load ptr, ptr %l204, !tbaa !29
  %t366 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t363, ptr %t364, i32 0)
  store %"compiler/typed:Elem" %t366, ptr %l206
  br label %bb52
bb52:
  %t367 = load %"compiler/typed:Elem", ptr %l206
  %t368 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t367, ptr %t368
  store { i64, [4 x i64] } zeroinitializer, ptr %t369
  %t370 = getelementptr { i64, [4 x i64] }, ptr %t369, i32 0, i32 0
  store i64 4, ptr %t370
  %t371 = load %"compiler/source:Span", ptr %l194
  %t372 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t371, 0
  %t373 = load i32, ptr %l199, !tbaa !23
  %t374 = insertvalue { %"compiler/source:Span", i32, ptr } %t372, i32 %t373, 1
  %t376 = insertvalue { %"compiler/source:Span", i32, ptr } %t374, ptr %t368, 2
  %t377 = getelementptr { i64, [4 x i64] }, ptr %t369, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t376, ptr %t377
  %t378 = load { i64, [4 x i64] }, ptr %t369
  %t380 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t378, ptr %t380
  %t381 = load ptr, ptr %l192, !tbaa !29
  %t382 = load %"compiler/source:Span", ptr %l193
  %t384 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t381, %"compiler/source:Span" %t382, ptr %t380)
  store ptr %t384, ptr %l210
  br label %bb53
bb53:
  %t385 = load ptr, ptr %l210, !tbaa !29
  store ptr %t385, ptr %l26, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l26, !tbaa !29
  %t389 = load %"compiler/source:Span", ptr %l1
  %t393 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v0, ptr %v0, ptr %t387, ptr %t388, %"compiler/source:Span" %t389, i1 false)
  store ptr %t393, ptr %l215
  br label %bb54
bb54:
  %t394 = load ptr, ptr %l215, !tbaa !29
  store ptr %t394, ptr %l26, !tbaa !29
  br label %bb60
bb55:
  %t396 = load ptr, ptr %l0, !tbaa !29
  store ptr %t396, ptr %l225, !tbaa !29
  %t397 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t397, ptr %l226
  %t398 = load i32, ptr %l24, !tbaa !23
  store i32 %t398, ptr %l227, !tbaa !23
  store i32 5, ptr %l228
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = load %"compiler/source:Span", ptr %l1
  %t401 = load i64, ptr %l3, !tbaa !24
  %t405 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t399, %"compiler/source:Span" %t400, i64 %t401)
  store ptr %t405, ptr %l232
  br label %bb56
bb56:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l1
  %t412 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t406, %"compiler/source:Span" %t407, i64 %a8)
  store ptr %t412, ptr %l236
  br label %bb57
bb57:
  %t413 = load ptr, ptr %l236, !tbaa !29
  %t414 = load ptr, ptr %l225, !tbaa !29
  %t415 = load %"compiler/source:Span", ptr %l226
  %t416 = load i32, ptr %l227, !tbaa !23
  %t417 = load i32, ptr %l228, !range !{i32 0, i32 49}
  %t418 = load ptr, ptr %l232, !tbaa !29
  %t420 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t414, %"compiler/source:Span" %t415, i32 %t416, i32 %t417, ptr %t418, ptr %t413)
  store ptr %t420, ptr %l238
  br label %bb58
bb58:
  %t421 = load ptr, ptr %l238, !tbaa !29
  %t422 = load ptr, ptr %l217, !tbaa !29
  %t423 = load %"compiler/source:Span", ptr %l218
  %t424 = load i32, ptr %l219, !tbaa !23
  %t425 = load i32, ptr %l220, !range !{i32 0, i32 49}
  %t426 = load ptr, ptr %l224, !tbaa !29
  %t428 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t422, %"compiler/source:Span" %t423, i32 %t424, i32 %t425, ptr %t426, ptr %t421)
  store ptr %t428, ptr %l240
  br label %bb59
bb59:
  %t429 = load ptr, ptr %l240, !tbaa !29
  store ptr %t429, ptr %l26, !tbaa !29
  br label %bb60
bb60:
  %t431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t431, ptr %l242, !tbaa !29
  %t432 = load ptr, ptr %l2, !tbaa !29
  %t434 = getelementptr %"compiler/ast:ForIn", ptr %t432, i32 0, i32 1
  %t435 = load i32, ptr %t434, !tbaa !23
  store i32 %t435, ptr %l244, !tbaa !23
  %t436 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t436, ptr %l245
  %t437 = load ptr, ptr %l26, !tbaa !29
  %t439 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t437)
  store i32 %t439, ptr %l247
  br label %bb61
bb61:
  store { i64, [1 x i64] } zeroinitializer, ptr %t440
  %t441 = getelementptr { i64, [1 x i64] }, ptr %t440, i32 0, i32 0
  store i64 4, ptr %t441
  %t442 = load { i64, [1 x i64] }, ptr %t440
  %t443 = load ptr, ptr %l242, !tbaa !29
  %t444 = load i32, ptr %l244, !tbaa !23
  %t445 = load %"compiler/source:Span", ptr %l245
  %t446 = load i32, ptr %l247, !tbaa !23
  %t449 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t443, i32 %t444, %"compiler/source:Span" %t445, i32 %t446, i32 1, { i64, [1 x i64] } %t442)
  store i64 %t449, ptr %l250
  br label %bb62
bb62:
  %t450 = load i64, ptr %l250, !tbaa !24
  store i64 %t450, ptr %l29, !tbaa !24
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr %"compiler/check:Checker", ptr %t451, i32 0, i32 34
  %t454 = getelementptr %"compiler/source:Span", ptr %t453, i32 0, i32 0
  %t455 = load i32, ptr %t454, !tbaa !23
  %t457 = icmp sge i32 %t455, 0
  br i1 %t457, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s7
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/check:Checker", ptr %t459, i32 0, i32 32
  store ptr %t461, ptr %l255, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t462)
  store ptr %t464, ptr %l257
  br label %bb65
bb64:
  br label %bb78
bb65:
  %t465 = load ptr, ptr %l257, !tbaa !29
  %t467 = getelementptr %"compiler/check:frame", ptr %t465, i32 0, i32 0
  %t468 = load i64, ptr %t467, !tbaa !24
  %t469 = load i64, ptr %l29, !tbaa !24
  %t472 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s7, i64 %t468, i64 %t469)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t472, ptr %l261
  br label %bb66
bb66:
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t475 = getelementptr %"compiler/check:Checker", ptr %t473, i32 0, i32 34
  %t476 = load %"compiler/source:Span", ptr %t475
  %t477 = load ptr, ptr %l255, !tbaa !29
  %t478 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l261
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_He56f4e53267726fe8dffcfd34146d8e6(ptr %v0, ptr %t477, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t478, %"compiler/source:Span" %t476)
  br label %bb67
bb67:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = getelementptr %"compiler/check:Checker", ptr %t480, i32 0, i32 35
  %t483 = load i1, ptr %t482, !tbaa !21
  br i1 %t483, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s8
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/check:Checker", ptr %t485, i32 0, i32 31
  store ptr %t487, ptr %l267, !tbaa !29
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t488)
  store ptr %t490, ptr %l269
  br label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s9
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/check:Checker", ptr %t491, i32 0, i32 33
  store ptr %t493, ptr %l275, !tbaa !29
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t494)
  store ptr %t496, ptr %l277
  br label %bb73
bb70:
  %t497 = load ptr, ptr %l269, !tbaa !29
  %t499 = getelementptr %"compiler/check:frame", ptr %t497, i32 0, i32 0
  %t500 = load i64, ptr %t499, !tbaa !24
  %t501 = load i64, ptr %l29, !tbaa !24
  %t504 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s8, i64 %t500, i64 %t501)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t504, ptr %l273
  br label %bb71
bb71:
  %t505 = load ptr, ptr %l267, !tbaa !29
  %t506 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l273
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t505, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t506, i1 true)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s8)
  br label %bb76
bb73:
  %t507 = load ptr, ptr %l277, !tbaa !29
  %t509 = getelementptr %"compiler/check:frame", ptr %t507, i32 0, i32 0
  %t510 = load i64, ptr %t509, !tbaa !24
  %t511 = load i64, ptr %l29, !tbaa !24
  %t514 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s9, i64 %t510, i64 %t511)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t514, ptr %l281
  br label %bb74
bb74:
  %t515 = load ptr, ptr %l275, !tbaa !29
  %t516 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l281
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t515, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t516, i1 true)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s9)
  br label %bb76
bb76:
  %t517 = load ptr, ptr %l0, !tbaa !29
  store ptr %t517, ptr %l282, !tbaa !29
  %t518 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s7, i32 -1, i32 -1)
  store %"compiler/source:Span" %t518, ptr %l283
  br label %bb77
bb77:
  %t519 = load %"compiler/source:Span", ptr %l283
  %t520 = load ptr, ptr %l282, !tbaa !29
  %t521 = getelementptr %"compiler/check:Checker", ptr %t520, i32 0, i32 34
  store %"compiler/source:Span" %t519, ptr %t521
  call void @__olang_scope_close(ptr %s7)
  br label %bb78
bb78:
  %t522 = load ptr, ptr %l0, !tbaa !29
  store ptr %t522, ptr %l284, !tbaa !29
  %t523 = load i64, ptr %l29, !tbaa !24
  store i64 %t523, ptr %l285, !tbaa !24
  %t524 = load ptr, ptr %l26, !tbaa !29
  %t526 = icmp eq ptr %t524, null
  br i1 %t526, label %bb79, label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_8ffd1bc2c5314d3c_1a7e454980bc5230)
  unreachable
bb80:
  br label %bb81
bb81:
  %t528 = load ptr, ptr %l26, !tbaa !29
  %t529 = load ptr, ptr %l284, !tbaa !29
  %t530 = load i64, ptr %l285, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t529, i64 %t530, ptr %t528)
  br label %bb82
bb82:
  %t532 = load ptr, ptr %l0, !tbaa !29
  store ptr %t532, ptr %l289, !tbaa !29
  %t533 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t533, ptr %l290
  %t534 = load i64, ptr %l29, !tbaa !24
  %t536 = trunc i64 %t534 to i32
  store i32 %t536, ptr %l293, !tbaa !23
  %t538 = load ptr, ptr %l26, !tbaa !29
  %t540 = icmp eq ptr %t538, null
  br i1 %t540, label %bb83, label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_6754b7d1e64b38ab_d9cb88888f730d0f)
  unreachable
bb84:
  br label %bb85
bb85:
  %t542 = load ptr, ptr %l26, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t543
  %t544 = getelementptr { i64, [3 x i64] }, ptr %t543, i32 0, i32 0
  store i64 0, ptr %t544
  %t545 = load %"compiler/source:Span", ptr %l290
  %t546 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t545, 0
  %t547 = load i32, ptr %l293, !tbaa !23
  %t548 = insertvalue { %"compiler/source:Span", i32, ptr } %t546, i32 %t547, 1
  %t550 = insertvalue { %"compiler/source:Span", i32, ptr } %t548, ptr %t542, 2
  %t551 = getelementptr { i64, [3 x i64] }, ptr %t543, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t550, ptr %t551
  %t552 = load { i64, [3 x i64] }, ptr %t543
  %t554 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t552, ptr %t554
  %t555 = load ptr, ptr %l289, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t555, ptr %t554)
  br label %bb86
bb86:
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load ptr, ptr %l2, !tbaa !29
  %t559 = load ptr, ptr %l9, !tbaa !29
  %t560 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %t557, ptr %t558, ptr %t559, i32 %t560)
  br label %bb87
bb87:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t567 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t565)
  store ptr %t567, ptr %l305
  br label %bb88
bb88:
  %t568 = load ptr, ptr %l305, !tbaa !29
  %t570 = getelementptr %"compiler/check:frame", ptr %t568, i32 0, i32 10
  %t572 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t570)
  %t573 = extractvalue { i32, i64 } %t572, 1
  %t574 = extractvalue { i32, i64 } %t572, 0
  store i32 %t574, ptr %l309
  %t575 = icmp ne i32 %t574, 0
  br i1 %t575, label %bb90, label %ok.576, !prof !99
ok.576:
  store i64 %t573, ptr %l308
  br label %bb89
bb89:
  %t577 = load i64, ptr %l308, !tbaa !24
  store i64 %t577, ptr %l303, !tbaa !24
  br label %bb92
bb90:
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t580 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t578)
  store ptr %t580, ptr %l312
  br label %bb93
bb93:
  %t581 = load ptr, ptr %l312, !tbaa !29
  %t583 = getelementptr %"compiler/check:frame", ptr %t581, i32 0, i32 11
  %t585 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t583)
  %t586 = extractvalue { i32, i64 } %t585, 1
  %t587 = extractvalue { i32, i64 } %t585, 0
  store i32 %t587, ptr %l316
  %t588 = icmp ne i32 %t587, 0
  br i1 %t588, label %bb95, label %ok.589, !prof !99
ok.589:
  store i64 %t586, ptr %l315
  br label %bb94
bb94:
  %t590 = load i64, ptr %l315, !tbaa !24
  store i64 %t590, ptr %l310, !tbaa !24
  br label %bb97
bb95:
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t592 = load i64, ptr %l21, !tbaa !24
  %t593 = load i64, ptr %l22, !tbaa !24
  %t594 = load i64, ptr %l23, !tbaa !24
  %t595 = load i64, ptr %l19, !tbaa !24
  %t601 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t591, i64 %t592, i64 %t593, i64 %t594, i64 %t595)
  store ptr %t601, ptr %l322
  br label %bb98
bb98:
  %t602 = load ptr, ptr %l322, !tbaa !29
  store ptr %t602, ptr %l30, !tbaa !29
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t605 = getelementptr %"compiler/check:Checker", ptr %t603, i32 0, i32 37
  %t607 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t605)
  store i64 %t607, ptr %l325
  br label %bb99
bb99:
  %t608 = load i64, ptr %l325, !tbaa !24
  store i64 %t608, ptr %l31, !tbaa !24
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t610 = load %"compiler/source:Span", ptr %l1
  %t614 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t609, i32 3, %"compiler/source:Span" %t610)
  store { i64, i64, i64 } %t614, ptr %l329
  br label %bb100
bb100:
  %t615 = load { i64, i64, i64 }, ptr %l329
  store { i64, i64, i64 } %t615, ptr %l32
  %t616 = getelementptr { i64, i64, i64 }, ptr %l32, i32 0, i32 0
  %t617 = load i64, ptr %t616, !tbaa !24
  store i64 %t617, ptr %l33, !tbaa !24
  %t619 = getelementptr { i64, i64, i64 }, ptr %l32, i32 0, i32 1
  %t620 = load i64, ptr %t619, !tbaa !24
  store i64 %t620, ptr %l34, !tbaa !24
  %t622 = getelementptr { i64, i64, i64 }, ptr %l32, i32 0, i32 2
  %t623 = load i64, ptr %t622, !tbaa !24
  store i64 %t623, ptr %l35, !tbaa !24
  %t625 = load ptr, ptr %l0, !tbaa !29
  store ptr %t625, ptr %l333, !tbaa !29
  %t626 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t626, ptr %l334
  %t627 = load i32, ptr %l24, !tbaa !23
  store i32 %t627, ptr %l335, !tbaa !23
  store i32 3, ptr %l336
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t629 = load %"compiler/source:Span", ptr %l1
  %t630 = load i64, ptr %l3, !tbaa !24
  %t634 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t628, %"compiler/source:Span" %t629, i64 %t630)
  store ptr %t634, ptr %l340
  br label %bb101
bb101:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t636 = load %"compiler/source:Span", ptr %l1
  %t637 = load i32, ptr %l24, !tbaa !23
  %t641 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t635, %"compiler/source:Span" %t636, i32 %t637, i64 1)
  store ptr %t641, ptr %l344
  br label %bb102
bb102:
  %t642 = load ptr, ptr %l344, !tbaa !29
  %t643 = load ptr, ptr %l333, !tbaa !29
  %t644 = load %"compiler/source:Span", ptr %l334
  %t645 = load i32, ptr %l335, !tbaa !23
  %t646 = load i32, ptr %l336, !range !{i32 0, i32 49}
  %t647 = load ptr, ptr %l340, !tbaa !29
  %t649 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t643, %"compiler/source:Span" %t644, i32 %t645, i32 %t646, ptr %t647, ptr %t642)
  store ptr %t649, ptr %l346
  br label %bb103
bb103:
  %t650 = load ptr, ptr %l346, !tbaa !29
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t652 = load %"compiler/source:Span", ptr %l1
  %t653 = load %"compiler/source:Span", ptr %l1
  %t654 = load i32, ptr %l24, !tbaa !23
  %t655 = load i64, ptr %l3, !tbaa !24
  %t657 = trunc i64 %t655 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t659
  %t660 = getelementptr { i64, [4 x i64] }, ptr %t659, i32 0, i32 0
  store i64 0, ptr %t660
  %t662 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t653, 0
  %t664 = insertvalue { %"compiler/source:Span", i32, i32 } %t662, i32 %t654, 1
  %t666 = insertvalue { %"compiler/source:Span", i32, i32 } %t664, i32 %t657, 2
  %t667 = getelementptr { i64, [4 x i64] }, ptr %t659, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t666, ptr %t667
  %t668 = load { i64, [4 x i64] }, ptr %t659
  %t670 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t668, ptr %t670
  store { i64, [3 x i64] } zeroinitializer, ptr %t672
  %t673 = getelementptr { i64, [3 x i64] }, ptr %t672, i32 0, i32 0
  store i64 1, ptr %t673
  %t675 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t652, 0
  %t677 = insertvalue { %"compiler/source:Span", ptr, ptr } %t675, ptr %t670, 1
  %t679 = insertvalue { %"compiler/source:Span", ptr, ptr } %t677, ptr %t650, 2
  %t680 = getelementptr { i64, [3 x i64] }, ptr %t672, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t679, ptr %t680
  %t681 = load { i64, [3 x i64] }, ptr %t672
  %t683 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t681, ptr %t683
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t651, ptr %t683)
  br label %bb104
bb104:
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t687 = load i64, ptr %l33, !tbaa !24
  %t688 = load i64, ptr %l34, !tbaa !24
  %t689 = load i64, ptr %l35, !tbaa !24
  %t690 = load i64, ptr %l31, !tbaa !24
  %t696 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t686, i64 %t687, i64 %t688, i64 %t689, i64 %t690)
  store ptr %t696, ptr %l364
  br label %bb105
bb105:
  %t697 = load ptr, ptr %l364, !tbaa !29
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t699 = load %"compiler/source:Span", ptr %l1
  %t700 = load ptr, ptr %l30, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t703
  %t704 = getelementptr { i64, [3 x i64] }, ptr %t703, i32 0, i32 0
  store i64 4, ptr %t704
  %t706 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t699, 0
  %t708 = insertvalue { %"compiler/source:Span", ptr, ptr } %t706, ptr %t700, 1
  %t710 = insertvalue { %"compiler/source:Span", ptr, ptr } %t708, ptr %t697, 2
  %t711 = getelementptr { i64, [3 x i64] }, ptr %t703, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t710, ptr %t711
  %t712 = load { i64, [3 x i64] }, ptr %t703
  %t714 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t712, ptr %t714
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t698, ptr %t714)
  br label %bb106
bb106:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectCond(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca { i64, i64, i64 }
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l46 = alloca %"compiler/typed:If"
  %t41 = alloca { i64, [3 x i64] }, align 8
  %t80 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v0, ptr %t1, ptr %a2)
  store ptr %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l12, !tbaa !29
  store ptr %t6, ptr %l3, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 37
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/source:Span", ptr %l1
  %t18 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t13, i32 1, %"compiler/source:Span" %t14)
  store { i64, i64, i64 } %t18, ptr %l19
  br label %bb3
bb3:
  %t19 = load { i64, i64, i64 }, ptr %l19
  store { i64, i64, i64 } %t19, ptr %l5
  %t20 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l6, !tbaa !24
  %t23 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  store i64 %t24, ptr %l7, !tbaa !24
  %t26 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l8, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 37
  store ptr %t31, ptr %l24, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t32, ptr %l25
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t33, %"compiler/source:Span" %t34, i32 %t35, i64 0)
  store ptr %t39, ptr %l29
  br label %bb4
bb4:
  %t40 = load ptr, ptr %l29, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t41, i32 0, i32 0
  store i64 6, ptr %t42
  %t43 = load %"compiler/source:Span", ptr %l25
  %t44 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t43, 0
  %t46 = insertvalue { %"compiler/source:Span", ptr } %t44, ptr %t40, 1
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t41, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t46, ptr %t47
  %t48 = load { i64, [3 x i64] }, ptr %t41
  %t50 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t48, ptr %t50
  %t51 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t51, ptr %t50)
  br label %bb5
bb5:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t53, i64 %t54, i64 %t55, i64 %t56, i64 %t57)
  store ptr %t63, ptr %l38
  br label %bb6
bb6:
  %t64 = load ptr, ptr %l38, !tbaa !29
  store ptr %t64, ptr %l9, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l39, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t66, ptr %l40
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l1
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t73 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v0, ptr %v0, ptr %t67, %"compiler/source:Span" %t68, ptr %t69)
  store ptr %t73, ptr %l44
  br label %bb7
bb7:
  %t74 = load ptr, ptr %l9, !tbaa !29
  %t75 = load ptr, ptr %l44, !tbaa !29
  %t77 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t75, ptr %t74, ptr null)
  store %"compiler/typed:If" %t77, ptr %l46
  br label %bb8
bb8:
  %t78 = load %"compiler/typed:If", ptr %l46
  %t79 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t78, ptr %t79
  store { i64, [3 x i64] } zeroinitializer, ptr %t80
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 0
  store i64 3, ptr %t81
  %t82 = load %"compiler/source:Span", ptr %l40
  %t83 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t82, 0
  %t85 = insertvalue { %"compiler/source:Span", ptr } %t83, ptr %t79, 1
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t85, ptr %t86
  %t87 = load { i64, [3 x i64] }, ptr %t80
  %t89 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t87, ptr %t89
  %t90 = load ptr, ptr %l39, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t90, ptr %t89)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l76 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i1
  %l131 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i1
  %l145 = alloca i1
  %l146 = alloca i1
  %l150 = alloca i1
  %l151 = alloca i1
  %l155 = alloca i1
  %l156 = alloca ptr
  %l157 = alloca i1
  %l165 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca i1
  %l177 = alloca i1
  %l178 = alloca i1
  %l181 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i1
  %l193 = alloca i1
  %l194 = alloca i1
  %l197 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i1
  %l211 = alloca i1
  %l212 = alloca i1
  %l215 = alloca i1
  %l216 = alloca i1
  %l219 = alloca i1
  %l220 = alloca ptr
  %l221 = alloca i1
  %l226 = alloca ptr
  %l227 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca i1
  %l238 = alloca ptr
  %l239 = alloca i1
  %l244 = alloca ptr
  %l245 = alloca i1
  %l252 = alloca i1
  %l253 = alloca ptr
  %l254 = alloca i1
  %l264 = alloca i1
  %l265 = alloca i1
  %l269 = alloca ptr
  %l270 = alloca i1
  %l277 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t7 = load ptr, ptr %l25, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l25, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 30}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l26, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t16 = load ptr, ptr %l29, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l29, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 30}
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l30, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t25 = load ptr, ptr %l33, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l33, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 30}
  %t31 = icmp eq i64 %t29, 25
  store i1 %t31, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l34, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb182
bb17:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t34 = load ptr, ptr %l37, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb18, label %bb19
bb18:
  %t37 = load ptr, ptr %l37, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 30}
  %t40 = icmp eq i64 %t38, 2
  store i1 %t40, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t41 = load i1, ptr %l38, !tbaa !21
  br i1 %t41, label %bb20, label %bb21
bb20:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", ptr }, ptr %t44, i32 0, i32 1
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l2, !tbaa !29
  br label %bb42
bb21:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t49 = load ptr, ptr %l43, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb22, label %bb23
bb22:
  %t52 = load ptr, ptr %l43, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 30}
  %t55 = icmp eq i64 %t53, 26
  store i1 %t55, ptr %l44, !tbaa !21
  br label %bb23
bb23:
  %t56 = load i1, ptr %l44, !tbaa !21
  br i1 %t56, label %bb24, label %bb25
bb24:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l2, !tbaa !29
  br label %bb42
bb25:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t64 = load ptr, ptr %l49, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb26, label %bb27
bb26:
  %t67 = load ptr, ptr %l49, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 30}
  %t70 = icmp eq i64 %t68, 28
  store i1 %t70, ptr %l50, !tbaa !21
  br label %bb27
bb27:
  %t71 = load i1, ptr %l50, !tbaa !21
  br i1 %t71, label %bb28, label %bb29
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr }, ptr %t74, i32 0, i32 1
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l2, !tbaa !29
  br label %bb42
bb29:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t79 = load ptr, ptr %l55, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb30, label %bb31
bb30:
  %t82 = load ptr, ptr %l55, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 30}
  %t85 = icmp eq i64 %t83, 3
  store i1 %t85, ptr %l56, !tbaa !21
  br label %bb31
bb31:
  %t86 = load i1, ptr %l56, !tbaa !21
  br i1 %t86, label %bb32, label %bb33
bb32:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l2, !tbaa !29
  br label %bb42
bb33:
  %t93 = load ptr, ptr %l1, !tbaa !29
  store ptr %t93, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t94 = load ptr, ptr %l61, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb34, label %bb35
bb34:
  %t97 = load ptr, ptr %l61, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 30}
  %t100 = icmp eq i64 %t98, 4
  store i1 %t100, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t101 = load i1, ptr %l62, !tbaa !21
  br i1 %t101, label %bb36, label %bb37
bb36:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 2
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l2, !tbaa !29
  br label %bb42
bb37:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t109 = load ptr, ptr %l67, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb38, label %bb39
bb38:
  %t112 = load ptr, ptr %l67, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 30}
  %t115 = icmp eq i64 %t113, 14
  store i1 %t115, ptr %l68, !tbaa !21
  br label %bb39
bb39:
  %t116 = load i1, ptr %l68, !tbaa !21
  br i1 %t116, label %bb40, label %bb41
bb40:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l2, !tbaa !29
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t128 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t123, ptr %t124)
  store i1 %t128, ptr %l76
  br label %bb43
bb43:
  %t129 = load i1, ptr %l76, !tbaa !21
  store i1 %t129, ptr %l24, !tbaa !21
  br label %bb182
bb44:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t131 = load ptr, ptr %l77, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb45, label %bb46
bb45:
  %t134 = load ptr, ptr %l77, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 30}
  %t137 = icmp eq i64 %t135, 9
  store i1 %t137, ptr %l78, !tbaa !21
  br label %bb46
bb46:
  %t138 = load i1, ptr %l78, !tbaa !21
  br i1 %t138, label %bb47, label %bb48
bb47:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t141, i32 0, i32 1
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l3, !tbaa !29
  br label %bb57
bb48:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t146 = load ptr, ptr %l83, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb49, label %bb50
bb49:
  %t149 = load ptr, ptr %l83, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 30}
  %t152 = icmp eq i64 %t150, 11
  store i1 %t152, ptr %l84, !tbaa !21
  br label %bb50
bb50:
  %t153 = load i1, ptr %l84, !tbaa !21
  br i1 %t153, label %bb51, label %bb52
bb51:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [4 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t156, i32 0, i32 1
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l3, !tbaa !29
  br label %bb57
bb52:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t161 = load ptr, ptr %l89, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb53, label %bb54
bb53:
  %t164 = load ptr, ptr %l89, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 30}
  %t167 = icmp eq i64 %t165, 13
  store i1 %t167, ptr %l90, !tbaa !21
  br label %bb54
bb54:
  %t168 = load i1, ptr %l90, !tbaa !21
  br i1 %t168, label %bb55, label %bb56
bb55:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [4 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t171, i32 0, i32 1
  %t173 = load ptr, ptr %t172
  store ptr %t173, ptr %l3, !tbaa !29
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load ptr, ptr %l3, !tbaa !29
  %t180 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t175, ptr %t176)
  store i1 %t180, ptr %l98
  br label %bb58
bb58:
  %t181 = load i1, ptr %l98, !tbaa !21
  store i1 %t181, ptr %l24, !tbaa !21
  br label %bb182
bb59:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t183 = load ptr, ptr %l99, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb60, label %bb61
bb60:
  %t186 = load ptr, ptr %l99, !tbaa !29
  %t187 = load i64, ptr %t186, !range !{i64 0, i64 30}
  %t189 = icmp eq i64 %t187, 5
  store i1 %t189, ptr %l100, !tbaa !21
  br label %bb61
bb61:
  %t190 = load i1, ptr %l100, !tbaa !21
  br i1 %t190, label %bb62, label %bb63
bb62:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t193, i32 0, i32 2
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l4, !tbaa !29
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t199, i32 0, i32 3
  %t201 = load ptr, ptr %t200
  store ptr %t201, ptr %l5, !tbaa !29
  br label %bb72
bb63:
  %t203 = load ptr, ptr %l1, !tbaa !29
  store ptr %t203, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t204 = load ptr, ptr %l107, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb64, label %bb65
bb64:
  %t207 = load ptr, ptr %l107, !tbaa !29
  %t208 = load i64, ptr %t207, !range !{i64 0, i64 30}
  %t210 = icmp eq i64 %t208, 6
  store i1 %t210, ptr %l108, !tbaa !21
  br label %bb65
bb65:
  %t211 = load i1, ptr %l108, !tbaa !21
  br i1 %t211, label %bb66, label %bb67
bb66:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [4 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t214, i32 0, i32 1
  %t216 = load ptr, ptr %t215
  store ptr %t216, ptr %l4, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t220, i32 0, i32 2
  %t222 = load ptr, ptr %t221
  store ptr %t222, ptr %l5, !tbaa !29
  br label %bb72
bb67:
  %t224 = load ptr, ptr %l1, !tbaa !29
  store ptr %t224, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t225 = load ptr, ptr %l115, !tbaa !29
  %t226 = icmp ne ptr %t225, null
  br i1 %t226, label %bb68, label %bb69
bb68:
  %t228 = load ptr, ptr %l115, !tbaa !29
  %t229 = load i64, ptr %t228, !range !{i64 0, i64 30}
  %t231 = icmp eq i64 %t229, 10
  store i1 %t231, ptr %l116, !tbaa !21
  br label %bb69
bb69:
  %t232 = load i1, ptr %l116, !tbaa !21
  br i1 %t232, label %bb70, label %bb71
bb70:
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t235, i32 0, i32 1
  %t237 = load ptr, ptr %t236
  store ptr %t237, ptr %l4, !tbaa !29
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t241, i32 0, i32 2
  %t243 = load ptr, ptr %t242
  store ptr %t243, ptr %l5, !tbaa !29
  br label %bb72
bb71:
  br label %bb78
bb72:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l4, !tbaa !29
  %t250 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t245, ptr %t246)
  store i1 %t250, ptr %l126
  br label %bb73
bb73:
  %t251 = load i1, ptr %l126, !tbaa !21
  br i1 %t251, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb77
bb75:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load ptr, ptr %l5, !tbaa !29
  %t257 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t252, ptr %t253)
  store i1 %t257, ptr %l131
  br label %bb76
bb76:
  %t258 = load i1, ptr %l131, !tbaa !21
  store i1 %t258, ptr %l127, !tbaa !21
  br label %bb77
bb77:
  %t259 = load i1, ptr %l127, !tbaa !21
  store i1 %t259, ptr %l24, !tbaa !21
  br label %bb182
bb78:
  %t260 = load ptr, ptr %l1, !tbaa !29
  store ptr %t260, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t261 = load ptr, ptr %l132, !tbaa !29
  %t262 = icmp ne ptr %t261, null
  br i1 %t262, label %bb79, label %bb80
bb79:
  %t264 = load ptr, ptr %l132, !tbaa !29
  %t265 = load i64, ptr %t264, !range !{i64 0, i64 30}
  %t267 = icmp eq i64 %t265, 8
  store i1 %t267, ptr %l133, !tbaa !21
  br label %bb80
bb80:
  %t268 = load i1, ptr %l133, !tbaa !21
  br i1 %t268, label %bb81, label %bb82
bb81:
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr { i64, [4 x i64] }, ptr %t269, i32 0, i32 1
  %t272 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t271, i32 0, i32 1
  %t273 = load ptr, ptr %t272
  store ptr %t273, ptr %l6, !tbaa !29
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr { i64, [4 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t277, i32 0, i32 2
  %t279 = load ptr, ptr %t278
  store ptr %t279, ptr %l7, !tbaa !29
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr { i64, [4 x i64] }, ptr %t281, i32 0, i32 1
  %t284 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t283, i32 0, i32 3
  %t285 = load ptr, ptr %t284
  store ptr %t285, ptr %l8, !tbaa !29
  br label %bb83
bb82:
  br label %bb93
bb83:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load ptr, ptr %l6, !tbaa !29
  %t292 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t287, ptr %t288)
  store i1 %t292, ptr %l145
  br label %bb84
bb84:
  %t293 = load i1, ptr %l145, !tbaa !21
  br i1 %t293, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l146, !tbaa !21
  br label %bb88
bb86:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load ptr, ptr %l7, !tbaa !29
  %t299 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t294, ptr %t295)
  store i1 %t299, ptr %l150
  br label %bb87
bb87:
  %t300 = load i1, ptr %l150, !tbaa !21
  store i1 %t300, ptr %l146, !tbaa !21
  br label %bb88
bb88:
  %t301 = load i1, ptr %l146, !tbaa !21
  br i1 %t301, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l151, !tbaa !21
  br label %bb92
bb90:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load ptr, ptr %l8, !tbaa !29
  %t307 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t302, ptr %t303)
  store i1 %t307, ptr %l155
  br label %bb91
bb91:
  %t308 = load i1, ptr %l155, !tbaa !21
  store i1 %t308, ptr %l151, !tbaa !21
  br label %bb92
bb92:
  %t309 = load i1, ptr %l151, !tbaa !21
  store i1 %t309, ptr %l24, !tbaa !21
  br label %bb182
bb93:
  %t310 = load ptr, ptr %l1, !tbaa !29
  store ptr %t310, ptr %l156, !tbaa !29
  store i1 false, ptr %l157, !tbaa !21
  %t311 = load ptr, ptr %l156, !tbaa !29
  %t312 = icmp ne ptr %t311, null
  br i1 %t312, label %bb94, label %bb95
bb94:
  %t314 = load ptr, ptr %l156, !tbaa !29
  %t315 = load i64, ptr %t314, !range !{i64 0, i64 30}
  %t317 = icmp eq i64 %t315, 7
  store i1 %t317, ptr %l157, !tbaa !21
  br label %bb95
bb95:
  %t318 = load i1, ptr %l157, !tbaa !21
  br i1 %t318, label %bb96, label %bb97
bb96:
  %t319 = load ptr, ptr %l1, !tbaa !29
  %t321 = getelementptr { i64, [4 x i64] }, ptr %t319, i32 0, i32 1
  %t322 = getelementptr { %"compiler/source:Span", ptr }, ptr %t321, i32 0, i32 1
  %t323 = load ptr, ptr %t322
  store ptr %t323, ptr %l9, !tbaa !29
  br label %bb98
bb97:
  br label %bb100
bb98:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load ptr, ptr %l9, !tbaa !29
  %t328 = getelementptr %"compiler/ast:Chain", ptr %t326, i32 0, i32 1
  %t329 = load { i64, ptr }, ptr %t328, !tbaa !27
  %t332 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %t325, { i64, ptr } %t329)
  store i1 %t332, ptr %l165
  br label %bb99
bb99:
  %t333 = load i1, ptr %l165, !tbaa !21
  store i1 %t333, ptr %l24, !tbaa !21
  br label %bb182
bb100:
  %t334 = load ptr, ptr %l1, !tbaa !29
  store ptr %t334, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t335 = load ptr, ptr %l166, !tbaa !29
  %t336 = icmp ne ptr %t335, null
  br i1 %t336, label %bb101, label %bb102
bb101:
  %t338 = load ptr, ptr %l166, !tbaa !29
  %t339 = load i64, ptr %t338, !range !{i64 0, i64 30}
  %t341 = icmp eq i64 %t339, 12
  store i1 %t341, ptr %l167, !tbaa !21
  br label %bb102
bb102:
  %t342 = load i1, ptr %l167, !tbaa !21
  br i1 %t342, label %bb103, label %bb104
bb103:
  %t343 = load ptr, ptr %l1, !tbaa !29
  %t345 = getelementptr { i64, [4 x i64] }, ptr %t343, i32 0, i32 1
  %t346 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t345, i32 0, i32 1
  %t347 = load ptr, ptr %t346
  store ptr %t347, ptr %l10, !tbaa !29
  %t349 = load ptr, ptr %l1, !tbaa !29
  %t351 = getelementptr { i64, [4 x i64] }, ptr %t349, i32 0, i32 1
  %t352 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t351, i32 0, i32 2
  %t353 = load { i64, ptr }, ptr %t352
  store { i64, ptr } %t353, ptr %l11, !tbaa !27
  br label %bb105
bb104:
  br label %bb111
bb105:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load ptr, ptr %l10, !tbaa !29
  %t360 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t355, ptr %t356)
  store i1 %t360, ptr %l177
  br label %bb106
bb106:
  %t361 = load i1, ptr %l177, !tbaa !21
  br i1 %t361, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb110
bb108:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t366 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %t362, { i64, ptr } %t363)
  store i1 %t366, ptr %l181
  br label %bb109
bb109:
  %t367 = load i1, ptr %l181, !tbaa !21
  store i1 %t367, ptr %l178, !tbaa !21
  br label %bb110
bb110:
  %t368 = load i1, ptr %l178, !tbaa !21
  store i1 %t368, ptr %l24, !tbaa !21
  br label %bb182
bb111:
  %t369 = load ptr, ptr %l1, !tbaa !29
  store ptr %t369, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t370 = load ptr, ptr %l182, !tbaa !29
  %t371 = icmp ne ptr %t370, null
  br i1 %t371, label %bb112, label %bb113
bb112:
  %t373 = load ptr, ptr %l182, !tbaa !29
  %t374 = load i64, ptr %t373, !range !{i64 0, i64 30}
  %t376 = icmp eq i64 %t374, 15
  store i1 %t376, ptr %l183, !tbaa !21
  br label %bb113
bb113:
  %t377 = load i1, ptr %l183, !tbaa !21
  br i1 %t377, label %bb114, label %bb115
bb114:
  %t378 = load ptr, ptr %l1, !tbaa !29
  %t380 = getelementptr { i64, [4 x i64] }, ptr %t378, i32 0, i32 1
  %t381 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t380, i32 0, i32 1
  %t382 = load ptr, ptr %t381
  store ptr %t382, ptr %l12, !tbaa !29
  %t384 = load ptr, ptr %l1, !tbaa !29
  %t386 = getelementptr { i64, [4 x i64] }, ptr %t384, i32 0, i32 1
  %t387 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t386, i32 0, i32 2
  %t388 = load { i64, ptr }, ptr %t387
  store { i64, ptr } %t388, ptr %l13, !tbaa !27
  br label %bb116
bb115:
  br label %bb122
bb116:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load ptr, ptr %l12, !tbaa !29
  %t395 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t390, ptr %t391)
  store i1 %t395, ptr %l193
  br label %bb117
bb117:
  %t396 = load i1, ptr %l193, !tbaa !21
  br i1 %t396, label %bb118, label %bb119
bb118:
  store i1 true, ptr %l194, !tbaa !21
  br label %bb121
bb119:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t401 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %t397, { i64, ptr } %t398)
  store i1 %t401, ptr %l197
  br label %bb120
bb120:
  %t402 = load i1, ptr %l197, !tbaa !21
  store i1 %t402, ptr %l194, !tbaa !21
  br label %bb121
bb121:
  %t403 = load i1, ptr %l194, !tbaa !21
  store i1 %t403, ptr %l24, !tbaa !21
  br label %bb182
bb122:
  %t404 = load ptr, ptr %l1, !tbaa !29
  store ptr %t404, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t405 = load ptr, ptr %l198, !tbaa !29
  %t406 = icmp ne ptr %t405, null
  br i1 %t406, label %bb123, label %bb124
bb123:
  %t408 = load ptr, ptr %l198, !tbaa !29
  %t409 = load i64, ptr %t408, !range !{i64 0, i64 30}
  %t411 = icmp eq i64 %t409, 16
  store i1 %t411, ptr %l199, !tbaa !21
  br label %bb124
bb124:
  %t412 = load i1, ptr %l199, !tbaa !21
  br i1 %t412, label %bb125, label %bb126
bb125:
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr { i64, [4 x i64] }, ptr %t413, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t415, i32 0, i32 1
  %t417 = load ptr, ptr %t416
  store ptr %t417, ptr %l14, !tbaa !29
  %t419 = load ptr, ptr %l1, !tbaa !29
  %t421 = getelementptr { i64, [4 x i64] }, ptr %t419, i32 0, i32 1
  %t422 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t421, i32 0, i32 2
  %t423 = load ptr, ptr %t422
  store ptr %t423, ptr %l15, !tbaa !29
  %t425 = load ptr, ptr %l1, !tbaa !29
  %t427 = getelementptr { i64, [4 x i64] }, ptr %t425, i32 0, i32 1
  %t428 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t427, i32 0, i32 3
  %t429 = load ptr, ptr %t428
  store ptr %t429, ptr %l16, !tbaa !29
  br label %bb127
bb126:
  br label %bb137
bb127:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load ptr, ptr %l14, !tbaa !29
  %t436 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t431, ptr %t432)
  store i1 %t436, ptr %l211
  br label %bb128
bb128:
  %t437 = load i1, ptr %l211, !tbaa !21
  br i1 %t437, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l212, !tbaa !21
  br label %bb132
bb130:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load ptr, ptr %l15, !tbaa !29
  %t442 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t438, ptr %t439)
  store i1 %t442, ptr %l215
  br label %bb131
bb131:
  %t443 = load i1, ptr %l215, !tbaa !21
  store i1 %t443, ptr %l212, !tbaa !21
  br label %bb132
bb132:
  %t444 = load i1, ptr %l212, !tbaa !21
  br i1 %t444, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb136
bb134:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load ptr, ptr %l16, !tbaa !29
  %t449 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t445, ptr %t446)
  store i1 %t449, ptr %l219
  br label %bb135
bb135:
  %t450 = load i1, ptr %l219, !tbaa !21
  store i1 %t450, ptr %l216, !tbaa !21
  br label %bb136
bb136:
  %t451 = load i1, ptr %l216, !tbaa !21
  store i1 %t451, ptr %l24, !tbaa !21
  br label %bb182
bb137:
  %t452 = load ptr, ptr %l1, !tbaa !29
  store ptr %t452, ptr %l220, !tbaa !29
  store i1 false, ptr %l221, !tbaa !21
  %t453 = load ptr, ptr %l220, !tbaa !29
  %t454 = icmp ne ptr %t453, null
  br i1 %t454, label %bb138, label %bb139
bb138:
  %t456 = load ptr, ptr %l220, !tbaa !29
  %t457 = load i64, ptr %t456, !range !{i64 0, i64 30}
  %t459 = icmp eq i64 %t457, 17
  store i1 %t459, ptr %l221, !tbaa !21
  br label %bb139
bb139:
  %t460 = load i1, ptr %l221, !tbaa !21
  br i1 %t460, label %bb140, label %bb141
bb140:
  %t461 = load ptr, ptr %l1, !tbaa !29
  %t463 = getelementptr { i64, [4 x i64] }, ptr %t461, i32 0, i32 1
  %t464 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t463, i32 0, i32 2
  %t465 = load { i64, ptr }, ptr %t464
  store { i64, ptr } %t465, ptr %l17, !tbaa !27
  br label %bb158
bb141:
  %t467 = load ptr, ptr %l1, !tbaa !29
  store ptr %t467, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t468 = load ptr, ptr %l226, !tbaa !29
  %t469 = icmp ne ptr %t468, null
  br i1 %t469, label %bb142, label %bb143
bb142:
  %t471 = load ptr, ptr %l226, !tbaa !29
  %t472 = load i64, ptr %t471, !range !{i64 0, i64 30}
  %t474 = icmp eq i64 %t472, 18
  store i1 %t474, ptr %l227, !tbaa !21
  br label %bb143
bb143:
  %t475 = load i1, ptr %l227, !tbaa !21
  br i1 %t475, label %bb144, label %bb145
bb144:
  %t476 = load ptr, ptr %l1, !tbaa !29
  %t478 = getelementptr { i64, [4 x i64] }, ptr %t476, i32 0, i32 1
  %t479 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t478, i32 0, i32 1
  %t480 = load { i64, ptr }, ptr %t479
  store { i64, ptr } %t480, ptr %l17, !tbaa !27
  br label %bb158
bb145:
  %t482 = load ptr, ptr %l1, !tbaa !29
  store ptr %t482, ptr %l232, !tbaa !29
  store i1 false, ptr %l233, !tbaa !21
  %t483 = load ptr, ptr %l232, !tbaa !29
  %t484 = icmp ne ptr %t483, null
  br i1 %t484, label %bb146, label %bb147
bb146:
  %t486 = load ptr, ptr %l232, !tbaa !29
  %t487 = load i64, ptr %t486, !range !{i64 0, i64 30}
  %t489 = icmp eq i64 %t487, 29
  store i1 %t489, ptr %l233, !tbaa !21
  br label %bb147
bb147:
  %t490 = load i1, ptr %l233, !tbaa !21
  br i1 %t490, label %bb148, label %bb149
bb148:
  %t491 = load ptr, ptr %l1, !tbaa !29
  %t493 = getelementptr { i64, [4 x i64] }, ptr %t491, i32 0, i32 1
  %t494 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t493, i32 0, i32 1
  %t495 = load { i64, ptr }, ptr %t494
  store { i64, ptr } %t495, ptr %l17, !tbaa !27
  br label %bb158
bb149:
  %t497 = load ptr, ptr %l1, !tbaa !29
  store ptr %t497, ptr %l238, !tbaa !29
  store i1 false, ptr %l239, !tbaa !21
  %t498 = load ptr, ptr %l238, !tbaa !29
  %t499 = icmp ne ptr %t498, null
  br i1 %t499, label %bb150, label %bb151
bb150:
  %t501 = load ptr, ptr %l238, !tbaa !29
  %t502 = load i64, ptr %t501, !range !{i64 0, i64 30}
  %t504 = icmp eq i64 %t502, 20
  store i1 %t504, ptr %l239, !tbaa !21
  br label %bb151
bb151:
  %t505 = load i1, ptr %l239, !tbaa !21
  br i1 %t505, label %bb152, label %bb153
bb152:
  %t506 = load ptr, ptr %l1, !tbaa !29
  %t508 = getelementptr { i64, [4 x i64] }, ptr %t506, i32 0, i32 1
  %t509 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t508, i32 0, i32 1
  %t510 = load { i64, ptr }, ptr %t509
  store { i64, ptr } %t510, ptr %l17, !tbaa !27
  br label %bb158
bb153:
  %t512 = load ptr, ptr %l1, !tbaa !29
  store ptr %t512, ptr %l244, !tbaa !29
  store i1 false, ptr %l245, !tbaa !21
  %t513 = load ptr, ptr %l244, !tbaa !29
  %t514 = icmp ne ptr %t513, null
  br i1 %t514, label %bb154, label %bb155
bb154:
  %t516 = load ptr, ptr %l244, !tbaa !29
  %t517 = load i64, ptr %t516, !range !{i64 0, i64 30}
  %t519 = icmp eq i64 %t517, 24
  store i1 %t519, ptr %l245, !tbaa !21
  br label %bb155
bb155:
  %t520 = load i1, ptr %l245, !tbaa !21
  br i1 %t520, label %bb156, label %bb157
bb156:
  %t521 = load ptr, ptr %l1, !tbaa !29
  %t523 = getelementptr { i64, [4 x i64] }, ptr %t521, i32 0, i32 1
  %t524 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t523, i32 0, i32 1
  %t525 = load { i64, ptr }, ptr %t524
  store { i64, ptr } %t525, ptr %l17, !tbaa !27
  br label %bb158
bb157:
  br label %bb160
bb158:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t531 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %t527, { i64, ptr } %t528)
  store i1 %t531, ptr %l252
  br label %bb159
bb159:
  %t532 = load i1, ptr %l252, !tbaa !21
  store i1 %t532, ptr %l24, !tbaa !21
  br label %bb182
bb160:
  %t533 = load ptr, ptr %l1, !tbaa !29
  store ptr %t533, ptr %l253, !tbaa !29
  store i1 false, ptr %l254, !tbaa !21
  %t534 = load ptr, ptr %l253, !tbaa !29
  %t535 = icmp ne ptr %t534, null
  br i1 %t535, label %bb161, label %bb162
bb161:
  %t537 = load ptr, ptr %l253, !tbaa !29
  %t538 = load i64, ptr %t537, !range !{i64 0, i64 30}
  %t540 = icmp eq i64 %t538, 21
  store i1 %t540, ptr %l254, !tbaa !21
  br label %bb162
bb162:
  %t541 = load i1, ptr %l254, !tbaa !21
  br i1 %t541, label %bb163, label %bb164
bb163:
  %t542 = load ptr, ptr %l1, !tbaa !29
  %t544 = getelementptr { i64, [4 x i64] }, ptr %t542, i32 0, i32 1
  %t545 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t544, i32 0, i32 1
  %t546 = load ptr, ptr %t545
  store ptr %t546, ptr %l18, !tbaa !29
  %t548 = load ptr, ptr %l1, !tbaa !29
  %t550 = getelementptr { i64, [4 x i64] }, ptr %t548, i32 0, i32 1
  %t551 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t550, i32 0, i32 2
  %t552 = load { i64, ptr }, ptr %t551
  store { i64, ptr } %t552, ptr %l19, !tbaa !27
  br label %bb165
bb164:
  br label %bb170
bb165:
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load ptr, ptr %l18, !tbaa !29
  %t559 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t554, ptr %t555)
  store i1 %t559, ptr %l264
  br label %bb166
bb166:
  %t560 = load i1, ptr %l264, !tbaa !21
  br i1 %t560, label %bb167, label %bb168
bb167:
  store i1 true, ptr %l265, !tbaa !21
  br label %bb169
bb168:
  %t561 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t563 = extractvalue { i64, ptr } %t561, 0
  %t565 = icmp sgt i64 %t563, 0
  store i1 %t565, ptr %l265, !tbaa !21
  br label %bb169
bb169:
  %t567 = load i1, ptr %l265, !tbaa !21
  store i1 %t567, ptr %l24, !tbaa !21
  br label %bb182
bb170:
  %t568 = load ptr, ptr %l1, !tbaa !29
  store ptr %t568, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t569 = load ptr, ptr %l269, !tbaa !29
  %t570 = icmp ne ptr %t569, null
  br i1 %t570, label %bb171, label %bb172
bb171:
  %t572 = load ptr, ptr %l269, !tbaa !29
  %t573 = load i64, ptr %t572, !range !{i64 0, i64 30}
  %t575 = icmp eq i64 %t573, 27
  store i1 %t575, ptr %l270, !tbaa !21
  br label %bb172
bb172:
  %t576 = load i1, ptr %l270, !tbaa !21
  br i1 %t576, label %bb173, label %bb174
bb173:
  %t577 = load ptr, ptr %l1, !tbaa !29
  %t579 = getelementptr { i64, [4 x i64] }, ptr %t577, i32 0, i32 1
  %t580 = getelementptr { %"compiler/source:Span", ptr }, ptr %t579, i32 0, i32 1
  %t581 = load ptr, ptr %t580
  store ptr %t581, ptr %l20, !tbaa !29
  br label %bb175
bb174:
  br label %bb177
bb175:
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t584 = load ptr, ptr %l20, !tbaa !29
  %t587 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t583, ptr %t584)
  store i1 %t587, ptr %l277
  br label %bb176
bb176:
  %t588 = load i1, ptr %l277, !tbaa !21
  store i1 %t588, ptr %l24, !tbaa !21
  br label %bb182
bb177:
  br i1 true, label %bb178, label %bb179
bb178:
  br label %bb180
bb179:
  br label %bb181
bb180:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb182
bb181:
  call void @__olang_check_failed(ptr @olang_loc_35a8764184624626_7069e8aee12fde2)
  unreachable
bb182:
  %t589 = load i1, ptr %l24, !tbaa !21
  store i1 %t589, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffArm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l18 = alloca { i64, ptr }
  %l25 = alloca i1
  %l35 = alloca { i64, ptr }
  %l42 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l61 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb20
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l18, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t34 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  store i1 %t34, ptr %l25
  br label %bb5
bb5:
  %t35 = load i1, ptr %l25, !tbaa !21
  br i1 %t35, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr %"compiler/typed:Alt", ptr %t37, i32 0, i32 1
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr ptr, ptr %t58, i64 %t55
  %t60 = load ptr, ptr %t59, !tbaa !39
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Bind", ptr %t60, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t70 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t62, ptr %t66)
  store i1 %t70, ptr %l42
  br label %bb13
bb13:
  %t71 = load i1, ptr %l42, !tbaa !21
  br i1 %t71, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l7, !tbaa !24
  br label %bb9
bb18:
  br label %bb19
bb19:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l3, !tbaa !24
  br label %bb1
bb20:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Arm", ptr %t82, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t81, ptr %t85)
  store i1 %t88, ptr %l51
  br label %bb21
bb21:
  %t89 = load i1, ptr %l51, !tbaa !21
  br i1 %t89, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb25
bb23:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Arm", ptr %t91, i32 0, i32 3
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t97 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %t90, ptr %t94)
  store i1 %t97, ptr %l56
  br label %bb24
bb24:
  %t98 = load i1, ptr %l56, !tbaa !21
  store i1 %t98, ptr %l52, !tbaa !21
  br label %bb25
bb25:
  %t99 = load i1, ptr %l52, !tbaa !21
  br i1 %t99, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb29
bb27:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Arm", ptr %t101, i32 0, i32 4
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t107 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %t100, ptr %t104)
  store i1 %t107, ptr %l61
  br label %bb28
bb28:
  %t108 = load i1, ptr %l61, !tbaa !21
  store i1 %t108, ptr %l57, !tbaa !21
  br label %bb29
bb29:
  %t109 = load i1, ptr %l57, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffS(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  store i1 %t27, ptr %l18
  br label %bb5
bb5:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, [3 x i64] }
  %l46 = alloca ptr
  %l50 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i32
  %l65 = alloca i32
  %l69 = alloca i64
  %l72 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l81 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca %"compiler/msgs:Nearest"
  %l92 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l102 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca ptr
  %l115 = alloca i32
  %l116 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l124 = alloca %"compiler/diagmsg:Msg"
  %l125 = alloca i64
  %l130 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l139 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca %"compiler/source:Span"
  %l148 = alloca { i64, ptr }
  %l150 = alloca %"compiler/diagmsg:Msg"
  %l151 = alloca i64
  %l156 = alloca ptr
  %l160 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca %"compiler/source:Span"
  %l174 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l180 = alloca %"compiler/diagmsg:Msg"
  %l181 = alloca i64
  %l185 = alloca ptr
  %l186 = alloca %"compiler/source:Span"
  %l190 = alloca { i64, ptr }
  %l196 = alloca %"compiler/diagmsg:Msg"
  %l197 = alloca i64
  %l202 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l207 = alloca i32
  %l210 = alloca ptr
  %l215 = alloca i32
  %l216 = alloca { i64, ptr }
  %l222 = alloca i64
  %l225 = alloca i64
  %l246 = alloca { i64, ptr }
  %l249 = alloca i32
  %l258 = alloca i32
  %l262 = alloca ptr
  %l263 = alloca %"compiler/source:Span"
  %l264 = alloca %"compiler/source:Span"
  %l265 = alloca i32
  %l269 = alloca { i64, ptr }
  %l270 = alloca { i64, ptr }
  %l272 = alloca i32
  %l273 = alloca { i64, ptr }
  %l277 = alloca ptr
  %l281 = alloca i32
  %l286 = alloca ptr
  %l297 = alloca ptr
  %l298 = alloca ptr
  %l299 = alloca %"compiler/source:Span"
  %l302 = alloca { i64, ptr }
  %l303 = alloca { i64, ptr }
  %l306 = alloca { i64, ptr }
  %l307 = alloca %"compiler/diagmsg:Msg"
  %l308 = alloca i64
  %l313 = alloca ptr
  %l318 = alloca { i64, ptr }
  %l327 = alloca i64
  %l330 = alloca i64
  %l348 = alloca { i64, ptr }
  %l358 = alloca ptr
  %l359 = alloca %"compiler/source:Span"
  %l363 = alloca %"compiler/diagmsg:Msg"
  %l364 = alloca i64
  %l367 = alloca ptr
  %l376 = alloca i32
  %l379 = alloca ptr
  %l384 = alloca i32
  %l385 = alloca { i64, ptr }
  %l395 = alloca ptr
  %l396 = alloca %"compiler/source:Span"
  %l398 = alloca i64
  %l402 = alloca { i64, ptr }
  %l404 = alloca %"compiler/diagmsg:Msg"
  %l405 = alloca i64
  %l408 = alloca ptr
  %l411 = alloca i64
  %l413 = alloca ptr
  %l418 = alloca i32
  %l419 = alloca ptr
  %l421 = alloca ptr
  %l426 = alloca i64
  %l429 = alloca i64
  %l452 = alloca i1
  %l457 = alloca i1
  %l463 = alloca ptr
  %l464 = alloca ptr
  %l466 = alloca ptr
  %l471 = alloca i32
  %l472 = alloca i64
  %l474 = alloca { i64, ptr }
  %l478 = alloca { i64, [3 x i64] }
  %l483 = alloca i1
  %l484 = alloca { i64, ptr }
  %l491 = alloca ptr
  %l492 = alloca ptr
  %l493 = alloca { i64, ptr }
  %l495 = alloca ptr
  %l496 = alloca { i64, ptr }
  %l498 = alloca i32
  %l500 = alloca { i64, ptr }
  %l503 = alloca %"compiler/source:Span"
  %l504 = alloca ptr
  %l506 = alloca { i64, ptr }
  %l509 = alloca { i64, ptr }
  %l512 = alloca ptr
  %l516 = alloca { i64, ptr }
  %l519 = alloca i1
  %l521 = alloca ptr
  %l523 = alloca ptr
  %l524 = alloca { i64, ptr }
  %l527 = alloca %"compiler/source:Span"
  %l529 = alloca i1
  %l531 = alloca ptr
  %l534 = alloca ptr
  %l540 = alloca { i64, ptr }
  %l541 = alloca %"compiler/source:Span"
  %l542 = alloca i32
  %l547 = alloca %"compiler/typed:Make"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca ptr
  %t1067 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l50
  br label %bb1
bb1:
  %t6 = load i1, ptr %l50, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l3, !tbaa !23
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l54
  br label %bb4
bb3:
  br label %bb118
bb4:
  %t14 = load i1, ptr %l54, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l58
  br label %bb7
bb6:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb8
bb7:
  %t20 = load i32, ptr %l58, !range !{i32 0, i32 6}
  %t22 = trunc i64 2 to i32
  %t23 = icmp eq i32 %t20, %t22
  store i1 %t23, ptr %l55, !tbaa !21
  br label %bb8
bb8:
  %t25 = load i1, ptr %l55, !tbaa !21
  br i1 %t25, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l65
  br label %bb11
bb10:
  br label %bb111
bb11:
  %t36 = load i32, ptr %l65, !tbaa !23
  store i32 %t36, ptr %l7, !tbaa !23
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l7, !tbaa !23
  %t39 = load i32, ptr %l4, !tbaa !23
  %t43 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %t37, i32 %t38, i32 %t39)
  store i64 %t43, ptr %l69
  br label %bb12
bb12:
  %t44 = load i64, ptr %l69, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t45, 0
  br i1 %t47, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb20
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i32, ptr %l3, !tbaa !23
  %t56 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l76
  br label %bb15
bb15:
  %t57 = load i1, ptr %l76, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i32, ptr %l7, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s2, ptr %t61, i32 %t62)
  store { i64, ptr } %t65, ptr %l81
  br label %bb18
bb17:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb19
bb18:
  %t66 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  %t69 = icmp eq i64 %t67, 0
  store i1 %t69, ptr %l77, !tbaa !21
  br label %bb19
bb19:
  %t71 = load i1, ptr %l77, !tbaa !21
  store i1 %t71, ptr %l72, !tbaa !21
  br label %bb20
bb20:
  %t72 = load i1, ptr %l72, !tbaa !21
  br i1 %t72, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l4, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t73, i32 %t74)
  store { i64, ptr } %t77, ptr %l86
  br label %bb23
bb22:
  br label %bb42
bb23:
  %t78 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t79 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s3, { i64, ptr } %t78)
  store %"compiler/msgs:Nearest" %t79, ptr %l87
  br label %bb24
bb24:
  %t80 = load %"compiler/msgs:Nearest", ptr %l87
  %t81 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t80, ptr %t81
  store ptr %t81, ptr %l9, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s4
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load i32, ptr %l7, !tbaa !23
  %t90 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s4, ptr %t86, i32 %t87)
  store { i64, ptr } %t90, ptr %l92
  br label %bb25
bb25:
  %t91 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t91, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l12, !tbaa !24
  br label %bb26
bb26:
  %t96 = load i64, ptr %l11, !tbaa !24
  %t97 = load i64, ptr %l12, !tbaa !24
  %t100 = icmp slt i64 %t96, %t97
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  br label %bb29
bb29:
  %t104 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t104, ptr %l99, !tbaa !27
  %t105 = load i64, ptr %l11, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i32, ptr %t108, i64 %t105
  %t110 = load i32, ptr %t109, !tbaa !33
  %t112 = load ptr, ptr %l9, !tbaa !29
  store ptr %t112, ptr %l102, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t117 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t113, i32 %t110)
  store { i64, ptr } %t117, ptr %l105
  br label %bb30
bb30:
  %t118 = load ptr, ptr %l102, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l105, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s3, ptr %v0, ptr %t118, { i64, ptr } %t119)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l11, !tbaa !24
  br label %bb26
bb33:
  call void @__olang_scope_close(ptr %s4)
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l108, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t125, ptr %l109
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l110, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l7, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l115
  br label %bb34
bb34:
  %t137 = load ptr, ptr %l110, !tbaa !29
  %t138 = load i32, ptr %l115, !tbaa !23
  %t139 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t137, i32 %t138)
  store { i64, ptr } %t139, ptr %l116
  br label %bb35
bb35:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l4, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l119
  br label %bb36
bb36:
  %t145 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l120, !tbaa !27
  %t152 = load ptr, ptr %l9, !tbaa !29
  %t154 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s3, ptr %s3, ptr %t152)
  store { i64, ptr } %t154, ptr %l122
  br label %bb37
bb37:
  %t155 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t157 = extractvalue { i64, ptr } %t155, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  %t162 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t165 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoSuchErrorWord(ptr %v0, ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t162, { i64, ptr } %t163, { i64, ptr } %t161)
  store %"compiler/diagmsg:Msg" %t165, ptr %l124
  br label %bb38
bb38:
  %t166 = load ptr, ptr %l108, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l109
  %t168 = load %"compiler/diagmsg:Msg", ptr %l124
  %t169 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t166, %"compiler/source:Span" %t167, %"compiler/diagmsg:Msg" %t168)
  store i64 %t169, ptr %l125
  br label %bb39
bb39:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t170, { i64, ptr } %t171)
  br label %bb40
bb40:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l1
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t174, %"compiler/source:Span" %t175)
  store ptr %t178, ptr %l130
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t179 = load ptr, ptr %l130, !tbaa !29
  store ptr %t179, ptr %rv
  br label %ret
bb42:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t184 = load i32, ptr %l7, !tbaa !23
  %t185 = load i64, ptr %l8, !tbaa !24
  %t189 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %s2, ptr %t183, i32 %t184, i64 %t185)
  store { i64, ptr } %t189, ptr %l135
  br label %bb43
bb43:
  %t190 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t190, ptr %l14, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t195 = icmp eq i64 %t193, 0
  br i1 %t195, label %bb44, label %bb45
bb44:
  %t197 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t201 = icmp sgt i64 %t199, 0
  store i1 %t201, ptr %l139, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb46
bb46:
  %t203 = load i1, ptr %l139, !tbaa !21
  br i1 %t203, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l143, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t205, ptr %l144
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i32, ptr %l3, !tbaa !23
  %t208 = load i64, ptr %l8, !tbaa !24
  %t212 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %s7, ptr %t206, i32 %t207, i64 %t208)
  store { i64, ptr } %t212, ptr %l148
  br label %bb49
bb48:
  br label %bb54
bb49:
  %t213 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 0
  %t215 = extractvalue { i64, ptr } %t213, 1
  %t216 = mul i64 %t214, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t217, ptr %t215, i64 %t216, i1 false)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  %t221 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %s7, ptr %s7, { i64, ptr } %t219)
  store %"compiler/diagmsg:Msg" %t221, ptr %l150
  br label %bb50
bb50:
  %t222 = load ptr, ptr %l143, !tbaa !29
  %t223 = load %"compiler/source:Span", ptr %l144
  %t224 = load %"compiler/diagmsg:Msg", ptr %l150
  %t225 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t222, %"compiler/source:Span" %t223, %"compiler/diagmsg:Msg" %t224)
  store i64 %t225, ptr %l151
  br label %bb51
bb51:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t226, { i64, ptr } %t227)
  br label %bb52
bb52:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l1
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t230, %"compiler/source:Span" %t231)
  store ptr %t234, ptr %l156
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t235 = load ptr, ptr %l156, !tbaa !29
  store ptr %t235, ptr %rv
  br label %ret
bb54:
  %t236 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t240 = icmp sgt i64 %t238, 0
  br i1 %t240, label %bb55, label %bb56
bb55:
  %t242 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t242, 0
  %t245 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t245, 0
  %t250 = icmp ne i64 %t244, %t247
  store i1 %t250, ptr %l160, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb57
bb57:
  %t252 = load i1, ptr %l160, !tbaa !21
  br i1 %t252, label %bb58, label %bb59
bb58:
  %t253 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t257 = icmp eq i64 %t255, 0
  br i1 %t257, label %bb60, label %bb61
bb59:
  br label %bb75
bb60:
  store %olang.scope zeroinitializer, ptr %s9
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l169, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t260, ptr %l170
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i32, ptr %l3, !tbaa !23
  %t263 = load i64, ptr %l8, !tbaa !24
  %t267 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %s9, ptr %t261, i32 %t262, i64 %t263)
  store { i64, ptr } %t267, ptr %l174
  br label %bb62
bb61:
  br label %bb66
bb62:
  %t268 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 0
  %t270 = extractvalue { i64, ptr } %t268, 1
  %t271 = mul i64 %t269, 1
  %t272 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t271)
  call void @llvm.memcpy.p0.p0.i64(ptr %t272, ptr %t270, i64 %t271, i1 false)
  %t273 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  store { i64, ptr } %t274, ptr %l175, !tbaa !27
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t279 = call { i64, ptr } @compiler_2fcheck_2efieldNames(ptr %v0, ptr %s2, ptr %s9, ptr %t275, { i64, ptr } %t276)
  store { i64, ptr } %t279, ptr %l178
  br label %bb63
bb63:
  %t280 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 0
  %t282 = extractvalue { i64, ptr } %t280, 1
  %t283 = mul i64 %t281, 1
  %t284 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t283)
  call void @llvm.memcpy.p0.p0.i64(ptr %t284, ptr %t282, i64 %t283, i1 false)
  %t285 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t284, 1
  %t287 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t289 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadWordBare(ptr %s9, ptr %s9, ptr %s9, { i64, ptr } %t287, { i64, ptr } %t286)
  store %"compiler/diagmsg:Msg" %t289, ptr %l180
  br label %bb64
bb64:
  %t290 = load ptr, ptr %l169, !tbaa !29
  %t291 = load %"compiler/source:Span", ptr %l170
  %t292 = load %"compiler/diagmsg:Msg", ptr %l180
  %t293 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t290, %"compiler/source:Span" %t291, %"compiler/diagmsg:Msg" %t292)
  store i64 %t293, ptr %l181
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb66:
  %t294 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t298 = icmp sgt i64 %t296, 0
  br i1 %t298, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s10
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l185, !tbaa !29
  %t301 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t301, ptr %l186
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load i32, ptr %l3, !tbaa !23
  %t304 = load i64, ptr %l8, !tbaa !24
  %t308 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %s10, ptr %t302, i32 %t303, i64 %t304)
  store { i64, ptr } %t308, ptr %l190
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t309 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 0
  %t311 = extractvalue { i64, ptr } %t309, 1
  %t312 = mul i64 %t310, 1
  %t313 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t313, ptr %t311, i64 %t312, i1 false)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  %t316 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t319, 0
  %t325 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadArgs(ptr %s10, ptr %s10, { i64, ptr } %t315, i64 %t318, i64 %t321)
  store %"compiler/diagmsg:Msg" %t325, ptr %l196
  br label %bb70
bb70:
  %t326 = load ptr, ptr %l185, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l186
  %t328 = load %"compiler/diagmsg:Msg", ptr %l196
  %t329 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t326, %"compiler/source:Span" %t327, %"compiler/diagmsg:Msg" %t328)
  store i64 %t329, ptr %l197
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s10)
  br label %bb72
bb72:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t330, { i64, ptr } %t331)
  br label %bb73
bb73:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load %"compiler/source:Span", ptr %l1
  %t338 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t334, %"compiler/source:Span" %t335)
  store ptr %t338, ptr %l202
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t339 = load ptr, ptr %l202, !tbaa !29
  store ptr %t339, ptr %rv
  br label %ret
bb75:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/check:Checker", ptr %t340, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !29
  %t344 = load i32, ptr %l3, !tbaa !23
  %t345 = mul i64 1, 4
  %t346 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t345)
  %t347 = insertvalue { i64, ptr } undef, i64 1, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  store { i64, ptr } %t348, ptr %l206, !tbaa !27
  %t350 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr i32, ptr %t351, i64 0
  store i32 %t344, ptr %t352, !tbaa !33
  %t354 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t355 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %s2, ptr %t343, { i64, ptr } %t354)
  store i32 %t355, ptr %l207
  br label %bb76
bb76:
  %t356 = load i32, ptr %l207, !tbaa !23
  store i32 %t356, ptr %l15, !tbaa !23
  store i64 0, ptr %l16, !tbaa !24
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/check:Checker", ptr %t357, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t362 = getelementptr %"compiler/generic:Program", ptr %t360, i32 0, i32 2
  store ptr %t362, ptr %l210, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t368 = getelementptr %"compiler/generic:Program", ptr %t366, i32 0, i32 2
  %t369 = load i32, ptr %l15, !tbaa !23
  %t372 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t368, i32 %t369)
  store i32 %t372, ptr %l215
  br label %bb77
bb77:
  %t373 = load ptr, ptr %l210, !tbaa !29
  %t374 = load i32, ptr %l215, !tbaa !23
  %t375 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t373, i32 %t374)
  store { i64, ptr } %t375, ptr %l216
  br label %bb78
bb78:
  %t376 = load { i64, ptr }, ptr %l216, !tbaa !27
  store { i64, ptr } %t376, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t377 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t379 = extractvalue { i64, ptr } %t377, 0
  store i64 %t379, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t381 = load i64, ptr %l19, !tbaa !24
  %t382 = load i64, ptr %l18, !tbaa !24
  %t385 = icmp sgt i64 %t381, %t382
  br i1 %t385, label %bb79, label %bb80
bb79:
  %t387 = load i64, ptr %l20, !tbaa !24
  %t389 = icmp sgt i64 %t387, 0
  br i1 %t389, label %bb81, label %bb82
bb80:
  store i64 0, ptr %l222, !tbaa !24
  br label %bb84
bb81:
  %t391 = load i64, ptr %l19, !tbaa !24
  %t392 = load i64, ptr %l18, !tbaa !24
  %t395 = sub i64 %t391, %t392
  %t396 = load i64, ptr %l20, !tbaa !24
  %t399 = add i64 %t395, %t396
  %t401 = sub i64 %t399, 1
  %t402 = load i64, ptr %l20, !tbaa !24
  %t405 = sdiv i64 %t401, %t402
  store i64 %t405, ptr %l225, !tbaa !24
  br label %bb83
bb82:
  store i64 0, ptr %l225, !tbaa !24
  br label %bb83
bb83:
  %t407 = load i64, ptr %l225, !tbaa !24
  store i64 %t407, ptr %l222, !tbaa !24
  br label %bb84
bb84:
  %t408 = load i64, ptr %l222, !tbaa !24
  store i64 %t408, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb85
bb85:
  %t409 = load i64, ptr %l22, !tbaa !24
  %t410 = load i64, ptr %l21, !tbaa !24
  %t413 = icmp slt i64 %t409, %t410
  %t415 = xor i1 %t413, true
  br i1 %t415, label %bb86, label %bb87
bb86:
  br label %bb94
bb87:
  br label %bb88
bb88:
  %t417 = load i64, ptr %l18, !tbaa !24
  %t418 = load i64, ptr %l22, !tbaa !24
  %t419 = load i64, ptr %l20, !tbaa !24
  %t422 = mul i64 %t418, %t419
  %t425 = add i64 %t417, %t422
  store i64 %t425, ptr %l23, !tbaa !24
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/check:Checker", ptr %t427, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !29
  %t432 = getelementptr %"compiler/generic:Program", ptr %t430, i32 0, i32 2
  %t433 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t433, ptr %l246, !tbaa !27
  %t434 = load i64, ptr %l23, !tbaa !24
  %t436 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !27
  %t438 = getelementptr i32, ptr %t437, i64 %t434
  %t439 = load i32, ptr %t438, !tbaa !33
  %t442 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t432, i32 %t439)
  store i32 %t442, ptr %l249
  br label %bb89
bb89:
  %t443 = load i32, ptr %l3, !tbaa !23
  %t444 = load i32, ptr %l249, !tbaa !23
  %t446 = icmp eq i32 %t444, %t443
  br i1 %t446, label %bb90, label %bb91
bb90:
  %t448 = load i64, ptr %l23, !tbaa !24
  store i64 %t448, ptr %l16, !tbaa !24
  br label %bb92
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t450 = load i64, ptr %l22, !tbaa !24
  %t452 = add i64 %t450, 1
  store i64 %t452, ptr %l22, !tbaa !24
  br label %bb85
bb94:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/check:Checker", ptr %t454, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !29
  %t458 = load i32, ptr %l3, !tbaa !23
  %t461 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %t457, i32 %t458)
  store i32 %t461, ptr %l258
  br label %bb95
bb95:
  %t462 = load i32, ptr %l258, !tbaa !23
  store i32 %t462, ptr %l24, !tbaa !23
  store ptr null, ptr %l25, !tbaa !29
  %t463 = load i32, ptr %l24, !tbaa !23
  %t464 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t467 = icmp ne i32 %t463, %t464
  br i1 %t467, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s15
  %t469 = load ptr, ptr %l0, !tbaa !29
  store ptr %t469, ptr %l262, !tbaa !29
  %t470 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t470, ptr %l263
  %t471 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t471, ptr %l264
  %t472 = load i32, ptr %l24, !tbaa !23
  store i32 %t472, ptr %l265, !tbaa !23
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t475 = getelementptr %"compiler/check:Checker", ptr %t473, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !29
  %t477 = load i32, ptr %l7, !tbaa !23
  %t480 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s15, ptr %t476, i32 %t477)
  store { i64, ptr } %t480, ptr %l269
  br label %bb98
bb97:
  br label %bb109
bb98:
  %t481 = load { i64, ptr }, ptr %l269, !tbaa !27
  store { i64, ptr } %t481, ptr %l270, !tbaa !27
  %t482 = load i64, ptr %l8, !tbaa !24
  %t484 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t485 = load ptr, ptr %t484, !tbaa !27
  %t486 = getelementptr i32, ptr %t485, i64 %t482
  %t487 = load i32, ptr %t486, !tbaa !33
  store i32 %t487, ptr %l272, !tbaa !23
  %t488 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t488, ptr %l273, !tbaa !27
  %t489 = icmp sge i64 0, 0
  br i1 %t489, label %bb99, label %bb100
bb99:
  %t491 = icmp sle i64 0, 1152921504606846975
  br i1 %t491, label %bb101, label %bb102
bb100:
  call void @__olang_check_failed(ptr @olang_loc_e0fb1c8b8de5bfa7_80560e432f46ee03)
  unreachable
bb101:
  %t493 = mul i64 0, 8
  %t494 = insertvalue { i64, ptr } undef, i64 0, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t496 = load ptr, ptr %l262, !tbaa !29
  %t497 = load %"compiler/source:Span", ptr %l263
  %t498 = load %"compiler/source:Span", ptr %l264
  %t499 = load i32, ptr %l265, !tbaa !23
  %t500 = load i32, ptr %l272, !tbaa !23
  %t501 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t503 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %v0, ptr %v3, ptr %t496, %"compiler/source:Span" %t497, %"compiler/source:Span" %t498, i32 %t499, i32 %t500, { i64, ptr } %t501, { i64, ptr } %t495)
  store ptr %t503, ptr %l277
  br label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_e0fb1c8b8de5bfa7_80560e432f46ee03)
  unreachable
bb103:
  %t504 = load ptr, ptr %l277, !tbaa !29
  store ptr %t504, ptr %l25, !tbaa !29
  %t506 = load ptr, ptr %l25, !tbaa !29
  %t509 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t506)
  store i32 %t509, ptr %l281
  br label %bb104
bb104:
  %t510 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t511 = load i32, ptr %l281, !tbaa !23
  %t513 = icmp eq i32 %t511, %t510
  br i1 %t513, label %bb105, label %bb106
bb105:
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load %"compiler/source:Span", ptr %l1
  %t519 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t515, %"compiler/source:Span" %t516)
  store ptr %t519, ptr %l286
  br label %bb107
bb106:
  br label %bb108
bb107:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t520 = load ptr, ptr %l286, !tbaa !29
  store ptr %t520, ptr %rv
  br label %ret
bb108:
  call void @__olang_scope_close(ptr %s15)
  br label %bb109
bb109:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load %"compiler/source:Span", ptr %l1
  %t523 = load i32, ptr %l15, !tbaa !23
  %t524 = load i64, ptr %l16, !tbaa !24
  %t525 = load i64, ptr %l16, !tbaa !24
  %t527 = add i64 %t525, 1
  %t529 = shl i64 %t527, 16
  %t530 = load i64, ptr %l8, !tbaa !24
  %t533 = or i64 %t529, %t530
  %t534 = load ptr, ptr %l25, !tbaa !29
  %t541 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValue(ptr %v0, ptr %v3, ptr %v3, ptr %t521, %"compiler/source:Span" %t522, i32 %t523, i64 %t524, i64 %t533, ptr %t534)
  store ptr %t541, ptr %l297
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t542 = load ptr, ptr %l297, !tbaa !29
  store ptr %t542, ptr %rv
  br label %ret
bb111:
  %t543 = load ptr, ptr %l0, !tbaa !29
  store ptr %t543, ptr %l298, !tbaa !29
  %t544 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t544, ptr %l299
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t546 = load i32, ptr %l3, !tbaa !23
  %t549 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t545, i32 %t546)
  store { i64, ptr } %t549, ptr %l302
  br label %bb112
bb112:
  %t550 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t551 = extractvalue { i64, ptr } %t550, 0
  %t552 = extractvalue { i64, ptr } %t550, 1
  %t553 = mul i64 %t551, 1
  %t554 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t553)
  call void @llvm.memcpy.p0.p0.i64(ptr %t554, ptr %t552, i64 %t553, i1 false)
  %t555 = insertvalue { i64, ptr } undef, i64 %t551, 0
  %t556 = insertvalue { i64, ptr } %t555, ptr %t554, 1
  store { i64, ptr } %t556, ptr %l303, !tbaa !27
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load i32, ptr %l4, !tbaa !23
  %t561 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t557, i32 %t558)
  store { i64, ptr } %t561, ptr %l306
  br label %bb113
bb113:
  %t562 = load { i64, ptr }, ptr %l303, !tbaa !27
  %t563 = load { i64, ptr }, ptr %l306, !tbaa !27
  %t564 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoMember(ptr %s1, ptr %v0, ptr %s1, { i64, ptr } %t562, { i64, ptr } %t563)
  store %"compiler/diagmsg:Msg" %t564, ptr %l307
  br label %bb114
bb114:
  %t565 = load ptr, ptr %l298, !tbaa !29
  %t566 = load %"compiler/source:Span", ptr %l299
  %t567 = load %"compiler/diagmsg:Msg", ptr %l307
  %t568 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t565, %"compiler/source:Span" %t566, %"compiler/diagmsg:Msg" %t567)
  store i64 %t568, ptr %l308
  br label %bb115
bb115:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t569, { i64, ptr } %t570)
  br label %bb116
bb116:
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t574 = load %"compiler/source:Span", ptr %l1
  %t577 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t573, %"compiler/source:Span" %t574)
  store ptr %t577, ptr %l313
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t578 = load ptr, ptr %l313, !tbaa !29
  store ptr %t578, ptr %rv
  br label %ret
bb118:
  store i64 -1, ptr %l26, !tbaa !24
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t581 = getelementptr %"compiler/check:Checker", ptr %t579, i32 0, i32 1
  %t582 = load ptr, ptr %t581, !tbaa !29
  %t584 = getelementptr %"compiler/generic:Program", ptr %t582, i32 0, i32 2
  %t585 = load i32, ptr %l3, !tbaa !23
  %t588 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s0, ptr %t584, i32 %t585)
  store { i64, ptr } %t588, ptr %l318
  br label %bb119
bb119:
  %t589 = load { i64, ptr }, ptr %l318, !tbaa !27
  store { i64, ptr } %t589, ptr %l27, !tbaa !27
  %t590 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t592 = extractvalue { i64, ptr } %t590, 0
  %t594 = icmp sgt i64 %t592, 0
  br i1 %t594, label %bb120, label %bb121
bb120:
  store i64 0, ptr %l28, !tbaa !24
  %t596 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t598 = extractvalue { i64, ptr } %t596, 0
  store i64 %t598, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t600 = load i64, ptr %l29, !tbaa !24
  %t601 = load i64, ptr %l28, !tbaa !24
  %t604 = icmp sgt i64 %t600, %t601
  br i1 %t604, label %bb122, label %bb123
bb121:
  br label %bb137
bb122:
  %t606 = load i64, ptr %l30, !tbaa !24
  %t608 = icmp sgt i64 %t606, 0
  br i1 %t608, label %bb124, label %bb125
bb123:
  store i64 0, ptr %l327, !tbaa !24
  br label %bb127
bb124:
  %t610 = load i64, ptr %l29, !tbaa !24
  %t611 = load i64, ptr %l28, !tbaa !24
  %t614 = sub i64 %t610, %t611
  %t615 = load i64, ptr %l30, !tbaa !24
  %t618 = add i64 %t614, %t615
  %t620 = sub i64 %t618, 1
  %t621 = load i64, ptr %l30, !tbaa !24
  %t624 = sdiv i64 %t620, %t621
  store i64 %t624, ptr %l330, !tbaa !24
  br label %bb126
bb125:
  store i64 0, ptr %l330, !tbaa !24
  br label %bb126
bb126:
  %t626 = load i64, ptr %l330, !tbaa !24
  store i64 %t626, ptr %l327, !tbaa !24
  br label %bb127
bb127:
  %t627 = load i64, ptr %l327, !tbaa !24
  store i64 %t627, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb128
bb128:
  %t628 = load i64, ptr %l32, !tbaa !24
  %t629 = load i64, ptr %l31, !tbaa !24
  %t632 = icmp slt i64 %t628, %t629
  %t634 = xor i1 %t632, true
  br i1 %t634, label %bb129, label %bb130
bb129:
  br label %bb136
bb130:
  br label %bb131
bb131:
  %t636 = load i64, ptr %l28, !tbaa !24
  %t637 = load i64, ptr %l32, !tbaa !24
  %t638 = load i64, ptr %l30, !tbaa !24
  %t641 = mul i64 %t637, %t638
  %t644 = add i64 %t636, %t641
  store i64 %t644, ptr %l33, !tbaa !24
  %t646 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t646, ptr %l348, !tbaa !27
  %t647 = load i64, ptr %l33, !tbaa !24
  %t649 = getelementptr { i64, ptr }, ptr %l348, i32 0, i32 1
  %t650 = load ptr, ptr %t649, !tbaa !27
  %t651 = getelementptr i32, ptr %t650, i64 %t647
  %t652 = load i32, ptr %t651, !tbaa !33
  %t653 = load i32, ptr %l4, !tbaa !23
  %t656 = icmp eq i32 %t652, %t653
  br i1 %t656, label %bb132, label %bb133
bb132:
  %t658 = load i64, ptr %l33, !tbaa !24
  store i64 %t658, ptr %l26, !tbaa !24
  br label %bb134
bb133:
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t660 = load i64, ptr %l32, !tbaa !24
  %t662 = add i64 %t660, 1
  store i64 %t662, ptr %l32, !tbaa !24
  br label %bb128
bb136:
  br label %bb137
bb137:
  %t664 = load i64, ptr %l26, !tbaa !24
  %t666 = icmp slt i64 %t664, 0
  br i1 %t666, label %bb138, label %bb139
bb138:
  store %olang.scope zeroinitializer, ptr %s22
  %t668 = load ptr, ptr %l0, !tbaa !29
  store ptr %t668, ptr %l358, !tbaa !29
  %t669 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t669, ptr %l359
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load i32, ptr %l3, !tbaa !23
  %t672 = load i32, ptr %l4, !tbaa !23
  %t676 = call %"compiler/diagmsg:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %s22, ptr %t670, i32 %t671, i32 %t672)
  store %"compiler/diagmsg:Msg" %t676, ptr %l363
  br label %bb140
bb139:
  br label %bb143
bb140:
  %t677 = load ptr, ptr %l358, !tbaa !29
  %t678 = load %"compiler/source:Span", ptr %l359
  %t679 = load %"compiler/diagmsg:Msg", ptr %l363
  %t680 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t677, %"compiler/source:Span" %t678, %"compiler/diagmsg:Msg" %t679)
  store i64 %t680, ptr %l364
  br label %bb141
bb141:
  %t681 = load ptr, ptr %l0, !tbaa !29
  %t682 = load %"compiler/source:Span", ptr %l1
  %t685 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t681, %"compiler/source:Span" %t682)
  store ptr %t685, ptr %l367
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  %t686 = load ptr, ptr %l367, !tbaa !29
  store ptr %t686, ptr %rv
  br label %ret
bb143:
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t688 = load i32, ptr %l3, !tbaa !23
  %t689 = load i32, ptr %l4, !tbaa !23
  %t690 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %t687, i32 %t688, i32 %t689, %"compiler/source:Span" %t690)
  br label %bb144
bb144:
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t697 = getelementptr %"compiler/check:Checker", ptr %t695, i32 0, i32 1
  %t698 = load ptr, ptr %t697, !tbaa !29
  %t699 = load i32, ptr %l3, !tbaa !23
  %t700 = load i64, ptr %l26, !tbaa !24
  %t704 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t698, i32 %t699, i64 %t700)
  store i32 %t704, ptr %l376
  br label %bb145
bb145:
  %t705 = load i32, ptr %l376, !tbaa !23
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t708 = getelementptr %"compiler/check:Checker", ptr %t706, i32 0, i32 1
  %t709 = load ptr, ptr %t708, !tbaa !29
  %t711 = getelementptr %"compiler/generic:Program", ptr %t709, i32 0, i32 2
  store ptr %t711, ptr %l379, !tbaa !29
  %t712 = load ptr, ptr %l0, !tbaa !29
  %t714 = getelementptr %"compiler/check:Checker", ptr %t712, i32 0, i32 1
  %t715 = load ptr, ptr %t714, !tbaa !29
  %t717 = getelementptr %"compiler/generic:Program", ptr %t715, i32 0, i32 2
  %t721 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t717, i32 %t705)
  store i32 %t721, ptr %l384
  br label %bb146
bb146:
  %t722 = load ptr, ptr %l379, !tbaa !29
  %t723 = load i32, ptr %l384, !tbaa !23
  %t724 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t722, i32 %t723)
  store { i64, ptr } %t724, ptr %l385
  br label %bb147
bb147:
  %t725 = load { i64, ptr }, ptr %l385, !tbaa !27
  store { i64, ptr } %t725, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t726 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t728 = extractvalue { i64, ptr } %t726, 0
  %t730 = icmp sgt i64 %t728, 0
  br i1 %t730, label %bb148, label %bb149
bb148:
  %t732 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t734 = extractvalue { i64, ptr } %t732, 0
  store i64 %t734, ptr %l36, !tbaa !24
  br label %bb150
bb149:
  br label %bb150
bb150:
  %t736 = load i64, ptr %l36, !tbaa !24
  %t737 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t739 = extractvalue { i64, ptr } %t737, 0
  %t742 = icmp ne i64 %t736, %t739
  br i1 %t742, label %bb151, label %bb152
bb151:
  store %olang.scope zeroinitializer, ptr %s24
  %t744 = load ptr, ptr %l0, !tbaa !29
  store ptr %t744, ptr %l395, !tbaa !29
  %t745 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t745, ptr %l396
  %t746 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t748 = extractvalue { i64, ptr } %t746, 0
  store i64 %t748, ptr %l398, !tbaa !24
  %t749 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t751 = extractvalue { i64, ptr } %t749, 0
  %t753 = icmp eq i64 %t751, 1
  br i1 %t753, label %bb153, label %bb154
bb152:
  br label %bb159
bb153:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l402, !tbaa !27
  br label %bb155
bb154:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l402, !tbaa !27
  br label %bb155
bb155:
  %t755 = load i64, ptr %l36, !tbaa !24
  %t756 = load i64, ptr %l398, !tbaa !24
  %t757 = load { i64, ptr }, ptr %l402, !tbaa !27
  %t759 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %s24, ptr %s24, i64 %t756, { i64, ptr } %t757, i64 %t755)
  store %"compiler/diagmsg:Msg" %t759, ptr %l404
  br label %bb156
bb156:
  %t760 = load ptr, ptr %l395, !tbaa !29
  %t761 = load %"compiler/source:Span", ptr %l396
  %t762 = load %"compiler/diagmsg:Msg", ptr %l404
  %t763 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s24, ptr %t760, %"compiler/source:Span" %t761, %"compiler/diagmsg:Msg" %t762)
  store i64 %t763, ptr %l405
  br label %bb157
bb157:
  %t764 = load ptr, ptr %l0, !tbaa !29
  %t765 = load %"compiler/source:Span", ptr %l1
  %t768 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t764, %"compiler/source:Span" %t765)
  store ptr %t768, ptr %l408
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  %t769 = load ptr, ptr %l408, !tbaa !29
  store ptr %t769, ptr %rv
  br label %ret
bb159:
  %t770 = load ptr, ptr %l0, !tbaa !29
  %t772 = getelementptr %"compiler/check:Checker", ptr %t770, i32 0, i32 36
  %t774 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t772)
  store i64 %t774, ptr %l411
  br label %bb160
bb160:
  %t775 = load i64, ptr %l411, !tbaa !24
  store i64 %t775, ptr %l37, !tbaa !24
  %t776 = load ptr, ptr %l0, !tbaa !29
  %t778 = getelementptr %"compiler/check:Checker", ptr %t776, i32 0, i32 1
  %t779 = load ptr, ptr %t778, !tbaa !29
  store ptr %t779, ptr %l413, !tbaa !29
  %t780 = load ptr, ptr %l0, !tbaa !29
  %t782 = getelementptr %"compiler/check:Checker", ptr %t780, i32 0, i32 1
  %t783 = load ptr, ptr %t782, !tbaa !29
  %t785 = getelementptr %"compiler/generic:Program", ptr %t783, i32 0, i32 2
  %t786 = load i32, ptr %l3, !tbaa !23
  %t789 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t785, i32 %t786)
  store i32 %t789, ptr %l418
  br label %bb161
bb161:
  %t790 = load ptr, ptr %l413, !tbaa !29
  %t791 = load i32, ptr %l418, !tbaa !23
  %t792 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t790, i32 %t791)
  store ptr %t792, ptr %l419
  br label %bb162
bb162:
  %t793 = load i64, ptr %l26, !tbaa !24
  %t794 = load ptr, ptr %l419, !tbaa !29
  %t796 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v0, ptr %t794, i64 %t793)
  store ptr %t796, ptr %l421
  br label %bb163
bb163:
  %t797 = load ptr, ptr %l421, !tbaa !29
  store ptr %t797, ptr %l38, !tbaa !29
  store i64 0, ptr %l39, !tbaa !24
  %t798 = load i64, ptr %l36, !tbaa !24
  store i64 %t798, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t800 = load i64, ptr %l40, !tbaa !24
  %t801 = load i64, ptr %l39, !tbaa !24
  %t804 = icmp sgt i64 %t800, %t801
  br i1 %t804, label %bb164, label %bb165
bb164:
  %t806 = load i64, ptr %l41, !tbaa !24
  %t808 = icmp sgt i64 %t806, 0
  br i1 %t808, label %bb166, label %bb167
bb165:
  store i64 0, ptr %l426, !tbaa !24
  br label %bb169
bb166:
  %t810 = load i64, ptr %l40, !tbaa !24
  %t811 = load i64, ptr %l39, !tbaa !24
  %t814 = sub i64 %t810, %t811
  %t815 = load i64, ptr %l41, !tbaa !24
  %t818 = add i64 %t814, %t815
  %t820 = sub i64 %t818, 1
  %t821 = load i64, ptr %l41, !tbaa !24
  %t824 = sdiv i64 %t820, %t821
  store i64 %t824, ptr %l429, !tbaa !24
  br label %bb168
bb167:
  store i64 0, ptr %l429, !tbaa !24
  br label %bb168
bb168:
  %t826 = load i64, ptr %l429, !tbaa !24
  store i64 %t826, ptr %l426, !tbaa !24
  br label %bb169
bb169:
  %t827 = load i64, ptr %l426, !tbaa !24
  store i64 %t827, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb170
bb170:
  %t828 = load i64, ptr %l43, !tbaa !24
  %t829 = load i64, ptr %l42, !tbaa !24
  %t832 = icmp slt i64 %t828, %t829
  %t834 = xor i1 %t832, true
  br i1 %t834, label %bb171, label %bb172
bb171:
  br label %bb204
bb172:
  br label %bb173
bb173:
  %t836 = load i64, ptr %l39, !tbaa !24
  %t837 = load i64, ptr %l43, !tbaa !24
  %t838 = load i64, ptr %l41, !tbaa !24
  %t841 = mul i64 %t837, %t838
  %t844 = add i64 %t836, %t841
  store i64 %t844, ptr %l44, !tbaa !24
  %t846 = load ptr, ptr %l0, !tbaa !29
  %t848 = getelementptr %"compiler/check:Checker", ptr %t846, i32 0, i32 13
  %t849 = load { i64, [3 x i64] }, ptr %t848
  store { i64, [3 x i64] } %t849, ptr %l45
  %t851 = load ptr, ptr %l38, !tbaa !29
  %t853 = icmp eq ptr %t851, null
  %t855 = xor i1 %t853, true
  br i1 %t855, label %bb174, label %bb175
bb174:
  %t857 = load ptr, ptr %l38, !tbaa !29
  %t859 = getelementptr %"compiler/ast:CaseDecl", ptr %t857, i32 0, i32 2
  %t860 = load { i64, ptr }, ptr %t859, !tbaa !27
  %t862 = extractvalue { i64, ptr } %t860, 0
  %t864 = icmp sgt i64 %t862, 0
  store i1 %t864, ptr %l452, !tbaa !21
  br label %bb176
bb175:
  store i1 false, ptr %l452, !tbaa !21
  br label %bb176
bb176:
  %t866 = load i1, ptr %l452, !tbaa !21
  br i1 %t866, label %bb177, label %bb178
bb177:
  %t867 = load i64, ptr %l44, !tbaa !24
  %t868 = load ptr, ptr %l38, !tbaa !29
  %t870 = getelementptr %"compiler/ast:CaseDecl", ptr %t868, i32 0, i32 2
  %t871 = load { i64, ptr }, ptr %t870, !tbaa !27
  %t873 = extractvalue { i64, ptr } %t871, 0
  %t876 = icmp slt i64 %t867, %t873
  store i1 %t876, ptr %l457, !tbaa !21
  br label %bb179
bb178:
  store i1 false, ptr %l457, !tbaa !21
  br label %bb179
bb179:
  %t878 = load i1, ptr %l457, !tbaa !21
  br i1 %t878, label %bb180, label %bb181
bb180:
  %t879 = load ptr, ptr %l0, !tbaa !29
  store ptr %t879, ptr %l463, !tbaa !29
  %t880 = load ptr, ptr %l0, !tbaa !29
  store ptr %t880, ptr %l464, !tbaa !29
  %t881 = load ptr, ptr %l0, !tbaa !29
  %t883 = getelementptr %"compiler/check:Checker", ptr %t881, i32 0, i32 1
  %t884 = load ptr, ptr %t883, !tbaa !29
  store ptr %t884, ptr %l466, !tbaa !29
  %t885 = load ptr, ptr %l0, !tbaa !29
  %t887 = getelementptr %"compiler/check:Checker", ptr %t885, i32 0, i32 1
  %t888 = load ptr, ptr %t887, !tbaa !29
  %t890 = getelementptr %"compiler/generic:Program", ptr %t888, i32 0, i32 2
  %t891 = load i32, ptr %l3, !tbaa !23
  %t894 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t890, i32 %t891)
  store i32 %t894, ptr %l471
  br label %bb182
bb181:
  br label %bb185
bb182:
  %t895 = load ptr, ptr %l466, !tbaa !29
  %t896 = load i32, ptr %l471, !tbaa !23
  %t897 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t895, i32 %t896)
  store i64 %t897, ptr %l472
  br label %bb183
bb183:
  %t898 = load ptr, ptr %l38, !tbaa !29
  %t900 = getelementptr %"compiler/ast:CaseDecl", ptr %t898, i32 0, i32 2
  %t901 = load { i64, ptr }, ptr %t900, !tbaa !27
  store { i64, ptr } %t901, ptr %l474, !tbaa !27
  %t902 = load i64, ptr %l44, !tbaa !24
  %t904 = getelementptr { i64, ptr }, ptr %l474, i32 0, i32 1
  %t905 = load ptr, ptr %t904, !tbaa !27
  %t906 = getelementptr ptr, ptr %t905, i64 %t902
  %t907 = load ptr, ptr %t906, !tbaa !39
  %t909 = getelementptr %"compiler/ast:Param", ptr %t907, i32 0, i32 2
  %t910 = load ptr, ptr %t909, !tbaa !29
  %t911 = load ptr, ptr %l464, !tbaa !29
  %t912 = load i64, ptr %l472, !tbaa !24
  %t914 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t911, i64 %t912, ptr %t910)
  store { i64, [3 x i64] } %t914, ptr %l478
  br label %bb184
bb184:
  %t915 = load { i64, [3 x i64] }, ptr %l478
  %t916 = load ptr, ptr %l463, !tbaa !29
  %t917 = getelementptr %"compiler/check:Checker", ptr %t916, i32 0, i32 13
  store { i64, [3 x i64] } %t915, ptr %t917
  br label %bb185
bb185:
  %t918 = load i64, ptr %l44, !tbaa !24
  %t919 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t921 = extractvalue { i64, ptr } %t919, 0
  %t924 = icmp slt i64 %t918, %t921
  br i1 %t924, label %bb186, label %bb187
bb186:
  %t926 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t926, ptr %l484, !tbaa !27
  %t927 = load i64, ptr %l44, !tbaa !24
  %t929 = getelementptr { i64, ptr }, ptr %l484, i32 0, i32 1
  %t930 = load ptr, ptr %t929, !tbaa !27
  %t931 = getelementptr ptr, ptr %t930, i64 %t927
  %t932 = load ptr, ptr %t931, !tbaa !39
  %t933 = load ptr, ptr %l0, !tbaa !29
  %t935 = getelementptr %"compiler/check:Checker", ptr %t933, i32 0, i32 0
  %t936 = load ptr, ptr %t935, !tbaa !29
  %t939 = icmp eq ptr %t932, %t936
  %t941 = xor i1 %t939, true
  store i1 %t941, ptr %l483, !tbaa !21
  br label %bb188
bb187:
  store i1 false, ptr %l483, !tbaa !21
  br label %bb188
bb188:
  %t943 = load i1, ptr %l483, !tbaa !21
  br i1 %t943, label %bb189, label %bb190
bb189:
  %t944 = load ptr, ptr %l0, !tbaa !29
  store ptr %t944, ptr %l492, !tbaa !29
  %t945 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t945, ptr %l493, !tbaa !27
  %t946 = load i64, ptr %l44, !tbaa !24
  %t948 = getelementptr { i64, ptr }, ptr %l493, i32 0, i32 1
  %t949 = load ptr, ptr %t948, !tbaa !27
  %t950 = getelementptr ptr, ptr %t949, i64 %t946
  %t951 = load ptr, ptr %t950, !tbaa !39
  store ptr %t951, ptr %l495, !tbaa !29
  %t952 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t952, ptr %l496, !tbaa !27
  %t953 = load i64, ptr %l44, !tbaa !24
  %t955 = getelementptr { i64, ptr }, ptr %l496, i32 0, i32 1
  %t956 = load ptr, ptr %t955, !tbaa !27
  %t957 = getelementptr i32, ptr %t956, i64 %t953
  %t958 = load i32, ptr %t957, !tbaa !33
  store i32 %t958, ptr %l498, !tbaa !23
  %t959 = load ptr, ptr %l0, !tbaa !29
  %t960 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t960, ptr %l500, !tbaa !27
  %t961 = load i64, ptr %l44, !tbaa !24
  %t963 = getelementptr { i64, ptr }, ptr %l500, i32 0, i32 1
  %t964 = load ptr, ptr %t963, !tbaa !27
  %t965 = getelementptr ptr, ptr %t964, i64 %t961
  %t966 = load ptr, ptr %t965, !tbaa !39
  %t969 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t959, ptr %t966)
  store %"compiler/source:Span" %t969, ptr %l503
  br label %bb191
bb190:
  %t970 = load ptr, ptr %l0, !tbaa !29
  %t971 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t971, ptr %l506, !tbaa !27
  %t972 = load i64, ptr %l44, !tbaa !24
  %t974 = getelementptr { i64, ptr }, ptr %l506, i32 0, i32 1
  %t975 = load ptr, ptr %t974, !tbaa !27
  %t976 = getelementptr ptr, ptr %t975, i64 %t972
  %t977 = load ptr, ptr %t976, !tbaa !39
  %t978 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t978, ptr %l509, !tbaa !27
  %t979 = load i64, ptr %l44, !tbaa !24
  %t981 = getelementptr { i64, ptr }, ptr %l509, i32 0, i32 1
  %t982 = load ptr, ptr %t981, !tbaa !27
  %t983 = getelementptr i32, ptr %t982, i64 %t979
  %t984 = load i32, ptr %t983, !tbaa !33
  %t988 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v0, ptr %t970, ptr %t977, i32 %t984)
  store ptr %t988, ptr %l512
  br label %bb193
bb191:
  %t989 = load ptr, ptr %l492, !tbaa !29
  %t990 = load ptr, ptr %l495, !tbaa !29
  %t991 = load i32, ptr %l498, !tbaa !23
  %t992 = load %"compiler/source:Span", ptr %l503
  %t993 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t989, ptr %t990, i32 %t991, %"compiler/source:Span" %t992)
  store ptr %t993, ptr %l504
  br label %bb192
bb192:
  %t994 = load ptr, ptr %l504, !tbaa !29
  store ptr %t994, ptr %l491, !tbaa !29
  br label %bb194
bb193:
  %t995 = load ptr, ptr %l512, !tbaa !29
  store ptr %t995, ptr %l491, !tbaa !29
  br label %bb194
bb194:
  %t996 = load ptr, ptr %l491, !tbaa !29
  store ptr %t996, ptr %l46, !tbaa !29
  %t997 = load ptr, ptr %l0, !tbaa !29
  %t998 = load { i64, [3 x i64] }, ptr %l45
  %t1001 = getelementptr %"compiler/check:Checker", ptr %t997, i32 0, i32 13
  store { i64, [3 x i64] } %t998, ptr %t1001
  %t1002 = load ptr, ptr %l0, !tbaa !29
  %t1003 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t1003, ptr %l516, !tbaa !27
  %t1004 = load i64, ptr %l44, !tbaa !24
  %t1006 = getelementptr { i64, ptr }, ptr %l516, i32 0, i32 1
  %t1007 = load ptr, ptr %t1006, !tbaa !27
  %t1008 = getelementptr i32, ptr %t1007, i64 %t1004
  %t1009 = load i32, ptr %t1008, !tbaa !33
  %t1012 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1002, i32 %t1009)
  store i1 %t1012, ptr %l519
  br label %bb195
bb195:
  %t1013 = load i1, ptr %l519, !tbaa !21
  %t1014 = xor i1 %t1013, true
  br i1 %t1014, label %bb196, label %bb197
bb196:
  %t1016 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1016, ptr %l521, !tbaa !29
  %t1017 = load ptr, ptr %l46, !tbaa !29
  store ptr %t1017, ptr %l523, !tbaa !29
  %t1019 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1019, ptr %l524, !tbaa !27
  %t1020 = load i64, ptr %l44, !tbaa !24
  %t1022 = getelementptr { i64, ptr }, ptr %l524, i32 0, i32 1
  %t1023 = load ptr, ptr %t1022, !tbaa !27
  %t1024 = getelementptr ptr, ptr %t1023, i64 %t1020
  %t1025 = load ptr, ptr %t1024, !tbaa !39
  %t1027 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1025)
  store %"compiler/source:Span" %t1027, ptr %l527
  br label %bb198
bb197:
  br label %bb200
bb198:
  %t1028 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t1029 = load ptr, ptr %l521, !tbaa !29
  %t1030 = load ptr, ptr %l523, !tbaa !29
  %t1031 = load %"compiler/source:Span", ptr %l527
  %t1033 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t1029, ptr %t1030, %"compiler/source:Span" %t1031, i64 %t1028)
  store i1 %t1033, ptr %l529
  br label %bb199
bb199:
  br label %bb200
bb200:
  %t1034 = load ptr, ptr %l0, !tbaa !29
  %t1036 = getelementptr %"compiler/check:Checker", ptr %t1034, i32 0, i32 36
  store ptr %t1036, ptr %l531, !tbaa !29
  %t1037 = load ptr, ptr %l0, !tbaa !29
  %t1038 = load ptr, ptr %l46, !tbaa !29
  %t1041 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartCopy(ptr %v0, ptr %v0, ptr %v0, ptr %t1037, ptr %t1038)
  store ptr %t1041, ptr %l534
  br label %bb201
bb201:
  %t1042 = load ptr, ptr %l531, !tbaa !29
  %t1043 = load ptr, ptr %l534, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t1042, ptr %t1043)
  br label %bb202
bb202:
  br label %bb203
bb203:
  %t1044 = load i64, ptr %l43, !tbaa !24
  %t1046 = add i64 %t1044, 1
  store i64 %t1046, ptr %l43, !tbaa !24
  br label %bb170
bb204:
  %t1048 = load ptr, ptr %l0, !tbaa !29
  %t1050 = getelementptr %"compiler/check:Checker", ptr %t1048, i32 0, i32 36
  %t1051 = load i64, ptr %l37, !tbaa !24
  %t1054 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v3, ptr %t1050, i64 %t1051)
  store { i64, ptr } %t1054, ptr %l540
  br label %bb205
bb205:
  %t1055 = load { i64, ptr }, ptr %l540, !tbaa !27
  %t1056 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1056, ptr %l541
  %t1057 = load i32, ptr %l3, !tbaa !23
  store i32 %t1057, ptr %l542, !tbaa !23
  %t1058 = load i64, ptr %l26, !tbaa !24
  %t1064 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v3, ptr %v3, ptr %v3, i32 1, i64 %t1058, { i64, ptr } %t1055, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t1064, ptr %l547
  br label %bb206
bb206:
  %t1065 = load %"compiler/typed:Make", ptr %l547
  %t1066 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 56, i64 8)
  store %"compiler/typed:Make" %t1065, ptr %t1066
  store { i64, [5 x i64] } zeroinitializer, ptr %t1067
  %t1068 = getelementptr { i64, [5 x i64] }, ptr %t1067, i32 0, i32 0
  store i64 7, ptr %t1068
  %t1069 = load %"compiler/source:Span", ptr %l541
  %t1070 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1069, 0
  %t1071 = load i32, ptr %l542, !tbaa !23
  %t1072 = insertvalue { %"compiler/source:Span", i32, ptr } %t1070, i32 %t1071, 1
  %t1074 = insertvalue { %"compiler/source:Span", i32, ptr } %t1072, ptr %t1066, 2
  %t1075 = getelementptr { i64, [5 x i64] }, ptr %t1067, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1074, ptr %t1075
  %t1076 = load { i64, [5 x i64] }, ptr %t1067
  %t1078 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t1076, ptr %t1078
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1078, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l19 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l34 = alloca i1
  %l35 = alloca i32
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"compiler/diagmsg:Msg"
  %l41 = alloca i64
  %l44 = alloca ptr
  %l49 = alloca i1
  %l51 = alloca i1
  %l56 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l74 = alloca %"compiler/diagmsg:Msg"
  %l75 = alloca i64
  %l79 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l109 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca i32
  %l119 = alloca i32
  %l125 = alloca ptr
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l12, !tbaa !23
  store i32 %t5, ptr %l6, !tbaa !23
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t6)
  store i32 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i32, ptr %l15, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t13 = trunc i64 78 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t20 = trunc i64 79 to i32
  %t21 = icmp eq i32 %t18, %t20
  %t23 = xor i1 %t21, true
  store i1 %t23, ptr %l19, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l19, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l23, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t27, ptr %l24
  %t28 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t30 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s1, i32 %t28)
  store { i64, ptr } %t30, ptr %l26
  br label %bb8
bb7:
  br label %bb18
bb8:
  %t31 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t32 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s1, ptr %s1, { i64, ptr } %t31)
  store { i64, ptr } %t32, ptr %l27
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l28, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l29, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l6, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l34
  br label %bb10
bb10:
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t52 = load i32, ptr %l6, !tbaa !23
  store i32 %t52, ptr %l35, !tbaa !23
  br label %bb13
bb12:
  %t54 = load i32, ptr %l7, !tbaa !23
  store i32 %t54, ptr %l35, !tbaa !23
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = load i32, ptr %l35, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t56, i32 %t57)
  store { i64, ptr } %t58, ptr %l38
  br label %bb14
bb14:
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrValueNoOp(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t66, { i64, ptr } %t65)
  store %"compiler/diagmsg:Msg" %t68, ptr %l40
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l23, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l24
  %t71 = load %"compiler/diagmsg:Msg", ptr %l40
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t69, %"compiler/source:Span" %t70, %"compiler/diagmsg:Msg" %t71)
  store i64 %t72, ptr %l41
  br label %bb16
bb16:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t73, %"compiler/source:Span" %t74)
  store ptr %t77, ptr %l44
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  %t78 = load ptr, ptr %l44, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb18:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l6, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l49
  br label %bb19
bb19:
  %t89 = load i1, ptr %l49, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb23
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l7, !tbaa !23
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l56
  br label %bb22
bb22:
  %t102 = load i1, ptr %l56, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t105 = load i1, ptr %l51, !tbaa !21
  br i1 %t105, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s2
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l6, !tbaa !23
  %t115 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l62
  br label %bb26
bb25:
  br label %bb35
bb26:
  %t116 = load i1, ptr %l62, !tbaa !21
  br i1 %t116, label %bb27, label %bb28
bb27:
  %t117 = load ptr, ptr %l4, !tbaa !29
  store ptr %t117, ptr %l63, !tbaa !29
  br label %bb29
bb28:
  %t119 = load ptr, ptr %l5, !tbaa !29
  store ptr %t119, ptr %l63, !tbaa !29
  br label %bb29
bb29:
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l66, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l67
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l68, !tbaa !29
  %t126 = load ptr, ptr @__olang_prog_scope
  %t128 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %t126, ptr %t121)
  store %"compiler/source:Span" %t128, ptr %l70
  br label %bb30
bb30:
  %t129 = load ptr, ptr %l68, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l70
  %t131 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s2, ptr %t129, %"compiler/source:Span" %t130)
  store { i64, ptr } %t131, ptr %l71
  br label %bb31
bb31:
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t134 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t132, i64 %t133)
  %t142 = getelementptr i8, ptr %t141, i64 %t133
  call void @olang_textcopy(ptr %t142, ptr %t135, i64 %t136)
  %t143 = getelementptr i8, ptr %t142, i64 %t136
  call void @olang_textcopy(ptr %t143, ptr %t138, i64 %t139)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t141, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t154 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCompareWhat(ptr %s2, ptr %s2, { i64, ptr } %t152)
  store %"compiler/diagmsg:Msg" %t154, ptr %l74
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l66, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l67
  %t157 = load %"compiler/diagmsg:Msg", ptr %l74
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t155, %"compiler/source:Span" %t156, %"compiler/diagmsg:Msg" %t157)
  store i64 %t158, ptr %l75
  br label %bb33
bb33:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t159, %"compiler/source:Span" %t160, i32 %t161, i64 0)
  store ptr %t165, ptr %l79
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s2)
  %t166 = load ptr, ptr %l79, !tbaa !29
  store ptr %t166, ptr %rv
  br label %ret
bb35:
  %t167 = load i32, ptr %l6, !tbaa !23
  %t168 = load i32, ptr %l7, !tbaa !23
  %t171 = icmp ne i32 %t167, %t168
  br i1 %t171, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  store ptr %t176, ptr %l84, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l85, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l86, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l6, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l91
  br label %bb38
bb37:
  br label %bb47
bb38:
  %t189 = load ptr, ptr %l86, !tbaa !29
  %t190 = load i32, ptr %l91, !tbaa !23
  %t191 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s4, ptr %t189, i32 %t190)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t191, ptr %l92
  br label %bb39
bb39:
  %t192 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  %t193 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t192, ptr %t193
  store ptr %t193, ptr %l93, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l94, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = load i32, ptr %l7, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l99
  br label %bb40
bb40:
  %t205 = load ptr, ptr %l94, !tbaa !29
  %t206 = load i32, ptr %l99, !tbaa !23
  %t207 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s4, ptr %t205, i32 %t206)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t207, ptr %l100
  br label %bb41
bb41:
  %t208 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  %t209 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t208, ptr %t209
  %t210 = load ptr, ptr %l85, !tbaa !29
  %t211 = load ptr, ptr %l93, !tbaa !29
  %t213 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s4, ptr %s4, ptr %s4, ptr %t210, ptr %t211, ptr %t209)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t213, ptr %l102
  br label %bb42
bb42:
  %t214 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l102
  %t215 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t214, ptr %t215
  %t217 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s4, ptr %s4, ptr %t215)
  store { i64, ptr } %t217, ptr %l104
  br label %bb43
bb43:
  %t218 = load ptr, ptr %l84, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t220 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %s4, ptr %t218, { i64, ptr } %t219)
  store i32 %t220, ptr %l105
  br label %bb44
bb44:
  %t221 = load i32, ptr %l105, !tbaa !23
  store i32 %t221, ptr %l9, !tbaa !23
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load ptr, ptr %l4, !tbaa !29
  %t224 = load i32, ptr %l9, !tbaa !23
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrRecode(ptr %v0, ptr %v1, ptr %v1, ptr %t222, ptr %t223, i32 %t224)
  store ptr %t228, ptr %l109
  br label %bb45
bb45:
  %t229 = load ptr, ptr %l109, !tbaa !29
  store ptr %t229, ptr %l4, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l5, !tbaa !29
  %t232 = load i32, ptr %l9, !tbaa !23
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrRecode(ptr %v0, ptr %v2, ptr %v2, ptr %t230, ptr %t231, i32 %t232)
  store ptr %t236, ptr %l113
  br label %bb46
bb46:
  %t237 = load ptr, ptr %l113, !tbaa !29
  store ptr %t237, ptr %l5, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb47:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l114, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t239, ptr %l115
  %t240 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t240, ptr %l116, !tbaa !23
  %t241 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t243 = trunc i64 78 to i32
  %t244 = icmp eq i32 %t241, %t243
  br i1 %t244, label %bb48, label %bb49
bb48:
  store i32 13, ptr %l119
  br label %bb50
bb49:
  store i32 14, ptr %l119
  br label %bb50
bb50:
  %t248 = load ptr, ptr %l4, !tbaa !29
  %t249 = load ptr, ptr %l5, !tbaa !29
  %t251 = load ptr, ptr %l114, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l115
  %t253 = load i32, ptr %l116, !tbaa !23
  %t254 = load i32, ptr %l119, !range !{i32 0, i32 49}
  %t257 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t251, %"compiler/source:Span" %t252, i32 %t253, i32 %t254, ptr %t248, ptr %t249)
  store ptr %t257, ptr %l125
  br label %bb51
bb51:
  %t258 = load ptr, ptr %l125, !tbaa !29
  store ptr %t258, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:factsMark" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsHeld(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca %"compiler/check:factsMark"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:factsMark"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 50
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 46
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l9
  br label %bb3
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 59
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = call %"compiler/check:factsMark" @compiler_2fcheck_3afactsMark_2ector(ptr %s0, i64 %t20, i64 %t21, i64 %t22)
  store %"compiler/check:factsMark" %t23, ptr %l13
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load %"compiler/check:factsMark", ptr %l13
  store %"compiler/check:factsMark" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:factsMark", ptr %rv
  ret %"compiler/check:factsMark" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l8 = alloca i64
  %rv = alloca i64
  %t4 = alloca { i64, [1 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [1 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [1 x i64] }, ptr %t4, i32 0, i32 0
  store i64 0, ptr %t5
  %t6 = load { i64, [1 x i64] }, ptr %t4
  %t12 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 0, %"compiler/source:Span" %a1, i32 %a2, i32 3, { i64, [1 x i64] } %t6)
  store i64 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i64, ptr %l8, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstContexts(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/generic:Origin"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l26 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l57 = alloca %"compiler/generic:Origin"
  %l60 = alloca ptr
  %l63 = alloca %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f"
  %l70 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l95 = alloca ptr
  %l97 = alloca i64
  %l101 = alloca %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f"
  %l105 = alloca ptr
  %l111 = alloca { i64, [3 x i64] }
  %l114 = alloca { i64, ptr }
  %l119 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i64
  %t192 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store i64 %a1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 32, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l26, !tbaa !24
  store i64 %t31, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l23, !tbaa !24
  store i64 %t32, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l9, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  store ptr %t56, ptr %l46, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i64, ptr %l3, !tbaa !24
  %t64 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t60, i64 %t61)
  store i32 %t64, ptr %l50
  br label %bb12
bb12:
  %t65 = load ptr, ptr %l46, !tbaa !29
  %t66 = load i32, ptr %l50, !tbaa !23
  %t67 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t65, i32 %t66)
  store { i64, ptr } %t67, ptr %l51
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t71 = icmp eq i64 %t69, 0
  br i1 %t71, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb15:
  br label %bb16
bb16:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t77 = load i64, ptr %l3, !tbaa !24
  %t80 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/generic:Origin" %t80, ptr %l57
  br label %bb17
bb17:
  %t81 = load %"compiler/generic:Origin", ptr %l57
  store %"compiler/generic:Origin" %t81, ptr %l10
  %t82 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t85 = icmp slt i64 %t83, 0
  br i1 %t85, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb19:
  br label %bb20
bb20:
  store ptr %l2, ptr %l60, !tbaa !29
  %t87 = load %"compiler/generic:Origin", ptr %l10
  %t88 = load i64, ptr %l3, !tbaa !24
  %t91 = call %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_2ector(ptr %s2, %"compiler/generic:Origin" %t87, i64 %t88)
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t91, ptr %l63
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l60, !tbaa !29
  %t93 = load %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_Hb1726e9607ca4add8166541fc83d3bee(ptr %s0, ptr %t92, %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t93)
  br label %bb22
bb22:
  %t94 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 2
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = icmp slt i64 %t95, 0
  br i1 %t97, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t99 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 2
  %t100 = load i64, ptr %t99, !tbaa !24
  store i64 %t100, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t102 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t102, 1
  store i64 %t104, ptr %l8, !tbaa !24
  br label %bb8
bb27:
  store i64 0, ptr %l11, !tbaa !24
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_H15a1a3e8469a5976ffa48722eeacbbc7(ptr %s0, ptr %l2)
  store i64 %t107, ptr %l70
  br label %bb28
bb28:
  %t108 = load i64, ptr %l70, !tbaa !24
  store i64 %t108, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t110 = load i64, ptr %l11, !tbaa !24
  %t113 = icmp sgt i64 %t109, %t110
  br i1 %t113, label %bb29, label %bb30
bb29:
  %t115 = load i64, ptr %l13, !tbaa !24
  %t117 = icmp sgt i64 %t115, 0
  br i1 %t117, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb34
bb31:
  %t119 = load i64, ptr %l12, !tbaa !24
  %t120 = load i64, ptr %l11, !tbaa !24
  %t123 = sub i64 %t119, %t120
  %t124 = load i64, ptr %l13, !tbaa !24
  %t127 = add i64 %t123, %t124
  %t129 = sub i64 %t127, 1
  %t130 = load i64, ptr %l13, !tbaa !24
  %t133 = sdiv i64 %t129, %t130
  store i64 %t133, ptr %l77, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb33
bb33:
  %t135 = load i64, ptr %l77, !tbaa !24
  store i64 %t135, ptr %l74, !tbaa !24
  br label %bb34
bb34:
  %t136 = load i64, ptr %l74, !tbaa !24
  store i64 %t136, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t137 = load i64, ptr %l15, !tbaa !24
  %t138 = load i64, ptr %l14, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t145 = load i64, ptr %l11, !tbaa !24
  %t146 = load i64, ptr %l15, !tbaa !24
  %t147 = load i64, ptr %l13, !tbaa !24
  %t150 = mul i64 %t146, %t147
  %t153 = add i64 %t145, %t150
  store i64 %t153, ptr %l16, !tbaa !24
  store ptr %l2, ptr %l95, !tbaa !29
  %t156 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_H15a1a3e8469a5976ffa48722eeacbbc7(ptr %s0, ptr %l2)
  store i64 %t156, ptr %l97
  br label %bb39
bb39:
  %t157 = load i64, ptr %l97, !tbaa !24
  %t158 = sub i64 %t157, 1
  %t159 = load i64, ptr %l16, !tbaa !24
  %t162 = sub i64 %t158, %t159
  %t163 = load ptr, ptr %l95, !tbaa !29
  %t165 = call %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_Hb10eca62c04bf212a25728cfc6f83c9c(ptr %s0, ptr %t163, i64 %t162)
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t165, ptr %l101
  br label %bb40
bb40:
  %t166 = load %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l101
  store %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %t166, ptr %l17
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 0
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/load:Loader", ptr %t173, i32 0, i32 4
  %t176 = load ptr, ptr %t175, !tbaa !29
  store ptr %t176, ptr %l105, !tbaa !29
  %t177 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l17, i32 0, i32 0
  %t178 = getelementptr %"compiler/generic:Origin", ptr %t177, i32 0, i32 0
  %t179 = load i64, ptr %t178, !tbaa !24
  %t180 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l17, i32 0, i32 0
  %t181 = getelementptr %"compiler/generic:Origin", ptr %t180, i32 0, i32 1
  %t182 = getelementptr %"compiler/source:Span", ptr %t181, i32 0, i32 0
  %t183 = load i32, ptr %t182, !tbaa !23
  %t185 = sext i32 %t183 to i64
  %t186 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l17, i32 0, i32 0
  %t187 = getelementptr %"compiler/generic:Origin", ptr %t186, i32 0, i32 1
  %t188 = getelementptr %"compiler/source:Span", ptr %t187, i32 0, i32 1
  %t189 = load i32, ptr %t188, !tbaa !23
  %t191 = sext i32 %t189 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t192
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 0
  store i64 3, ptr %t193
  %t195 = insertvalue { i64, i64, i64 } undef, i64 %t179, 0
  %t197 = insertvalue { i64, i64, i64 } %t195, i64 %t185, 1
  %t199 = insertvalue { i64, i64, i64 } %t197, i64 %t191, 2
  %t200 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  store { i64, i64, i64 } %t199, ptr %t200
  %t201 = load { i64, [3 x i64] }, ptr %t192
  store { i64, [3 x i64] } %t201, ptr %l111
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f", ptr %l17, i32 0, i32 1
  %t204 = load i64, ptr %t203, !tbaa !24
  %t207 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstNote(ptr %v0, ptr %s8, ptr %t202, i64 %t204)
  store { i64, ptr } %t207, ptr %l114
  br label %bb41
bb41:
  %t208 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  %t210 = extractvalue { i64, ptr } %t208, 1
  %t211 = mul i64 %t209, 1
  %t212 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t211)
  call void @llvm.memcpy.p0.p0.i64(ptr %t212, ptr %t210, i64 %t211, i1 false)
  %t213 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t212, 1
  %t215 = load ptr, ptr %l105, !tbaa !29
  %t216 = load { i64, [3 x i64] }, ptr %l111
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %s8, ptr %t215, { i64, [3 x i64] } %t216, { i64, ptr } %t214)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb43
bb43:
  %t218 = load i64, ptr %l15, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l15, !tbaa !24
  br label %bb35
bb44:
  %t223 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_H15a1a3e8469a5976ffa48722eeacbbc7(ptr %s0, ptr %l2)
  store i64 %t223, ptr %l119
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t224 = load i64, ptr %l119, !tbaa !24
  store i64 %t224, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t14 = trunc i64 1 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l15
  br label %bb8
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l11, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l12 = alloca i32
  %l15 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l36 = alloca i32
  %l40 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i32
  %l55 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l78 = alloca i32
  %l79 = alloca i32
  %l83 = alloca ptr
  %l86 = alloca ptr
  %l89 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca i32
  %l96 = alloca i32
  %l97 = alloca { i64, ptr }
  %l98 = alloca i1
  %l104 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %a1)
  store i32 %t8, ptr %l12
  br label %bb1
bb1:
  %t9 = load i32, ptr %l12, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l15, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l20
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i32, ptr %l20, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l21
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp ne i64 %t32, 1
  br i1 %t34, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb7
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i32, ptr %t39, i64 0
  %t41 = load i32, ptr %t40, !tbaa !33
  %t44 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t36, i32 %t41)
  store i1 %t44, ptr %l29
  br label %bb6
bb6:
  %t45 = load i1, ptr %l29, !tbaa !21
  %t46 = xor i1 %t45, true
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb7
bb7:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l36
  br label %bb11
bb11:
  %t60 = load i32, ptr %l36, !tbaa !23
  store i32 %t60, ptr %l4, !tbaa !23
  %t61 = load i32, ptr %l4, !tbaa !23
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t65 = icmp eq i32 %t61, %t62
  br i1 %t65, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb14
bb13:
  %t67 = load i32, ptr %l4, !tbaa !23
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t71 = icmp eq i32 %t67, %t68
  store i1 %t71, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb18
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l4, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l49
  br label %bb17
bb17:
  %t84 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t86 = trunc i64 22 to i32
  %t87 = icmp eq i32 %t84, %t86
  store i1 %t87, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l44, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 2
  store ptr %t96, ptr %l55, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l2, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l60
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l55, !tbaa !29
  %t108 = load i32, ptr %l60, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t107, i32 %t108)
  store { i64, ptr } %t109, ptr %l61
  br label %bb23
bb23:
  %t110 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t110, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l7, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t115 = load i64, ptr %l6, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb42
bb26:
  br label %bb27
bb27:
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t123, ptr %l68, !tbaa !27
  %t124 = load i64, ptr %l6, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i32, ptr %t127, i64 %t124
  %t129 = load i32, ptr %t128, !tbaa !33
  store i32 %t129, ptr %l8, !tbaa !23
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  store ptr %t136, ptr %l73, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 2
  %t143 = load i32, ptr %l8, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t142, i32 %t143)
  store i32 %t146, ptr %l78
  br label %bb28
bb28:
  %t147 = load ptr, ptr %l73, !tbaa !29
  %t148 = load i32, ptr %l78, !tbaa !23
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t149, ptr %l79
  br label %bb29
bb29:
  %t150 = load i32, ptr %l79, !range !{i32 0, i32 33}
  %t152 = trunc i64 18 to i32
  %t153 = icmp eq i32 %t150, %t152
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb31:
  br label %bb32
bb32:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l83, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  store ptr %t163, ptr %l86, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  store ptr %t169, ptr %l89, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  %t176 = load i32, ptr %l8, !tbaa !23
  %t179 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t175, i32 %t176)
  store i32 %t179, ptr %l94
  br label %bb33
bb33:
  %t180 = load ptr, ptr %l89, !tbaa !29
  %t181 = load i32, ptr %l94, !tbaa !23
  %t182 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t180, i32 %t181)
  store i32 %t182, ptr %l95
  br label %bb34
bb34:
  %t183 = load ptr, ptr %l86, !tbaa !29
  %t184 = load i32, ptr %l95, !tbaa !23
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t183, i32 %t184)
  store i32 %t185, ptr %l96
  br label %bb35
bb35:
  %t186 = load ptr, ptr %l83, !tbaa !29
  %t187 = load i32, ptr %l96, !tbaa !23
  %t188 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t186, i32 %t187)
  store { i64, ptr } %t188, ptr %l97
  br label %bb36
bb36:
  %t189 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t190 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t189, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t190, ptr %l98
  br label %bb37
bb37:
  %t191 = load i1, ptr %l98, !tbaa !21
  br i1 %t191, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s4)
  br label %bb41
bb41:
  %t193 = load i64, ptr %l6, !tbaa !24
  %t195 = add i64 %t193, 1
  store i64 %t195, ptr %l6, !tbaa !24
  br label %bb24
bb42:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i32, ptr %l2, !tbaa !23
  %t201 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t197, i32 %t198)
  store i1 %t201, ptr %l104
  br label %bb43
bb43:
  %t202 = load i1, ptr %l104, !tbaa !21
  store i1 %t202, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejoinStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i64
  %l51 = alloca ptr
  %l59 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca i64
  %l69 = alloca { i64, i64, i64 }
  %l85 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l100 = alloca ptr
  %l102 = alloca ptr
  %l105 = alloca i64
  %l107 = alloca i64
  %l109 = alloca ptr
  %l112 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i32
  %l120 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i32
  %l127 = alloca ptr
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca %"compiler/diagmsg:Msg"
  %l130 = alloca i64
  %l131 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l135 = alloca i64
  %l139 = alloca i64
  %l142 = alloca i64
  %l163 = alloca i32
  %l165 = alloca i64
  %l167 = alloca i64
  %l172 = alloca i32
  %l187 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l193 = alloca i1
  %l198 = alloca i64
  %l200 = alloca ptr
  %l203 = alloca { i64, ptr }
  %l205 = alloca %"compiler/source:Span"
  %l206 = alloca %"compiler/diagmsg:Msg"
  %l207 = alloca i64
  %l211 = alloca i64
  %l213 = alloca i1
  %l218 = alloca ptr
  %l219 = alloca %"compiler/source:Span"
  %l220 = alloca %"compiler/diagmsg:Msg"
  %l221 = alloca i64
  %l224 = alloca i64
  %l226 = alloca i64
  %l228 = alloca i64
  %l233 = alloca i32
  %l241 = alloca i64
  %l254 = alloca { i64, ptr }
  %l263 = alloca { i64, ptr }
  %l266 = alloca ptr
  %l272 = alloca ptr
  %l280 = alloca i64
  %l284 = alloca i64
  %l287 = alloca i64
  %l308 = alloca ptr
  %l313 = alloca i1
  %l317 = alloca ptr
  %l323 = alloca i1
  %l324 = alloca ptr
  %l327 = alloca { i64, ptr }
  %l330 = alloca %"compiler/source:Span"
  %l331 = alloca %"compiler/diagmsg:Msg"
  %l332 = alloca i64
  %l339 = alloca i64
  %l340 = alloca i64
  %l343 = alloca { i64, ptr }
  %l344 = alloca i64
  %l345 = alloca i32
  %l346 = alloca ptr
  %l356 = alloca %"compiler/source:Span"
  %l360 = alloca i64
  %l362 = alloca ptr
  %l363 = alloca %"compiler/source:Span"
  %l364 = alloca ptr
  %l366 = alloca i32
  %l367 = alloca { i64, ptr }
  %l369 = alloca %"compiler/diagmsg:Msg"
  %l370 = alloca i64
  %l373 = alloca ptr
  %l374 = alloca %"compiler/source:Span"
  %l375 = alloca ptr
  %l377 = alloca i1
  %l379 = alloca { i64, ptr }
  %l380 = alloca %"compiler/typed:Join"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %t674 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l51
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l51, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 33
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 41
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 38
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t17, i64 0)
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 39
  store ptr %t21, ptr %l59, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 40
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l62
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l59, !tbaa !29
  %t28 = load i64, ptr %l62, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t27, i64 %t28)
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 37
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l65
  br label %bb5
bb5:
  %t34 = load i64, ptr %l65, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l1
  %t40 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t35, i32 5, %"compiler/source:Span" %t36)
  store { i64, i64, i64 } %t40, ptr %l69
  br label %bb6
bb6:
  %t41 = load { i64, i64, i64 }, ptr %l69
  store { i64, i64, i64 } %t41, ptr %l7
  %t42 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 0
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  %t45 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t48 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 2
  %t49 = load i64, ptr %t48, !tbaa !24
  store i64 %t49, ptr %l10, !tbaa !24
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/ast:JoinS", ptr %t51, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb7, label %bb8
bb7:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/ast:JoinS", ptr %t60, i32 0, i32 1
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l13, !tbaa !24
  br label %bb9
bb8:
  br label %bb16
bb9:
  %t69 = load i64, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l13, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb10, label %bb11
bb10:
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t77 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t77, ptr %l85, !tbaa !27
  %t78 = load i64, ptr %l12, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 %t78
  %t83 = load ptr, ptr %t82, !tbaa !39
  %t85 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t85, ptr %t83)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t90 = load i64, ptr %l12, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l12, !tbaa !24
  br label %bb9
bb15:
  br label %bb16
bb16:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l6, !tbaa !24
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t94, i64 %t95, i64 %t96, i64 %t97, i64 %t98)
  store ptr %t104, ptr %l98
  br label %bb17
bb17:
  %t105 = load ptr, ptr %l98, !tbaa !29
  store ptr %t105, ptr %l15, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t106)
  store ptr %t108, ptr %l100
  br label %bb18
bb18:
  %t109 = load ptr, ptr %l100, !tbaa !29
  store ptr %t109, ptr %l3, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t112 = getelementptr %"compiler/check:frame", ptr %t110, i32 0, i32 38
  store ptr %t112, ptr %l102, !tbaa !29
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t115 = getelementptr %"compiler/check:frame", ptr %t113, i32 0, i32 38
  %t117 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l105
  br label %bb19
bb19:
  %t118 = load i64, ptr %l105, !tbaa !24
  %t119 = sub i64 %t118, 1
  %t120 = load ptr, ptr %l102, !tbaa !29
  %t122 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t120, i64 %t119)
  store i64 %t122, ptr %l107
  br label %bb20
bb20:
  %t123 = load i64, ptr %l107, !tbaa !24
  store i64 %t123, ptr %l16, !tbaa !24
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t126 = getelementptr %"compiler/check:frame", ptr %t124, i32 0, i32 39
  store ptr %t126, ptr %l109, !tbaa !29
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 39
  %t131 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t129)
  store i64 %t131, ptr %l112
  br label %bb21
bb21:
  %t132 = load i64, ptr %l112, !tbaa !24
  %t133 = sub i64 %t132, 1
  %t134 = load ptr, ptr %l109, !tbaa !29
  %t136 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t134, i64 %t133)
  store i64 %t136, ptr %l114
  br label %bb22
bb22:
  %t137 = load i64, ptr %l114, !tbaa !24
  store i64 %t137, ptr %l17, !tbaa !24
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = getelementptr %"compiler/check:frame", ptr %t138, i32 0, i32 38
  %t142 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t140)
  %t143 = extractvalue { i32, i64 } %t142, 1
  %t144 = extractvalue { i32, i64 } %t142, 0
  store i32 %t144, ptr %l119
  %t145 = icmp ne i32 %t144, 0
  br i1 %t145, label %bb24, label %ok.146, !prof !99
ok.146:
  store i64 %t143, ptr %l118
  br label %bb23
bb23:
  %t147 = load i64, ptr %l118, !tbaa !24
  store i64 %t147, ptr %l115, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t150 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 39
  %t152 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t150)
  %t153 = extractvalue { i32, i64 } %t152, 1
  %t154 = extractvalue { i32, i64 } %t152, 0
  store i32 %t154, ptr %l124
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb28, label %ok.156, !prof !99
ok.156:
  store i64 %t153, ptr %l123
  br label %bb27
bb27:
  %t157 = load i64, ptr %l123, !tbaa !24
  store i64 %t157, ptr %l120, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t158 = load i64, ptr %l16, !tbaa !24
  %t160 = icmp eq i64 %t158, 0
  br i1 %t160, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l127, !tbaa !29
  %t163 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t163, ptr %l128
  %t164 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eJoinWithoutSpawn(ptr %s7)
  store %"compiler/diagmsg:Msg" %t164, ptr %l129
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t165 = load ptr, ptr %l127, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l128
  %t167 = load %"compiler/diagmsg:Msg", ptr %l129
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t165, %"compiler/source:Span" %t166, %"compiler/diagmsg:Msg" %t167)
  store i64 %t168, ptr %l130
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t169 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t169, ptr %l131
  br label %bb36
bb36:
  %t170 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l131
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %l18
  %t171 = load i64, ptr %l17, !tbaa !24
  store i64 %t171, ptr %l19, !tbaa !24
  %t173 = load ptr, ptr %l3, !tbaa !29
  %t175 = getelementptr %"compiler/check:frame", ptr %t173, i32 0, i32 40
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t175)
  store i64 %t177, ptr %l135
  br label %bb37
bb37:
  %t178 = load i64, ptr %l135, !tbaa !24
  store i64 %t178, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t179 = load i64, ptr %l20, !tbaa !24
  %t180 = load i64, ptr %l19, !tbaa !24
  %t183 = icmp sgt i64 %t179, %t180
  br i1 %t183, label %bb38, label %bb39
bb38:
  %t185 = load i64, ptr %l21, !tbaa !24
  %t187 = icmp sgt i64 %t185, 0
  br i1 %t187, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l139, !tbaa !24
  br label %bb43
bb40:
  %t189 = load i64, ptr %l20, !tbaa !24
  %t190 = load i64, ptr %l19, !tbaa !24
  %t193 = sub i64 %t189, %t190
  %t194 = load i64, ptr %l21, !tbaa !24
  %t197 = add i64 %t193, %t194
  %t199 = sub i64 %t197, 1
  %t200 = load i64, ptr %l21, !tbaa !24
  %t203 = sdiv i64 %t199, %t200
  store i64 %t203, ptr %l142, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l142, !tbaa !24
  br label %bb42
bb42:
  %t205 = load i64, ptr %l142, !tbaa !24
  store i64 %t205, ptr %l139, !tbaa !24
  br label %bb43
bb43:
  %t206 = load i64, ptr %l139, !tbaa !24
  store i64 %t206, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb44
bb44:
  %t207 = load i64, ptr %l23, !tbaa !24
  %t208 = load i64, ptr %l22, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb45, label %bb46
bb45:
  br label %bb65
bb46:
  br label %bb47
bb47:
  %t215 = load i64, ptr %l19, !tbaa !24
  %t216 = load i64, ptr %l23, !tbaa !24
  %t217 = load i64, ptr %l21, !tbaa !24
  %t220 = mul i64 %t216, %t217
  %t223 = add i64 %t215, %t220
  %t225 = load ptr, ptr %l3, !tbaa !29
  %t227 = getelementptr %"compiler/check:frame", ptr %t225, i32 0, i32 40
  %t231 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t227, i64 %t223)
  store i32 %t231, ptr %l163
  br label %bb48
bb48:
  %t232 = load i32, ptr %l163, !tbaa !23
  store i32 %t232, ptr %l25, !tbaa !23
  store i1 false, ptr %l26, !tbaa !21
  store ptr %l18, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb49
bb49:
  %t234 = load i64, ptr %l28, !tbaa !24
  store i64 %t234, ptr %l165, !tbaa !24
  %t235 = load ptr, ptr %l27, !tbaa !29
  %t237 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t235)
  store i64 %t237, ptr %l167
  br label %bb50
bb50:
  %t238 = load i64, ptr %l165, !tbaa !24
  %t239 = load i64, ptr %l167, !tbaa !24
  %t240 = icmp slt i64 %t238, %t239
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb51, label %bb52
bb51:
  br label %bb59
bb52:
  br label %bb53
bb53:
  %t244 = load ptr, ptr %l27, !tbaa !29
  %t245 = load i64, ptr %l28, !tbaa !24
  %t248 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t244, i64 %t245)
  store i32 %t248, ptr %l172
  br label %bb54
bb54:
  %t249 = load i32, ptr %l172, !tbaa !23
  %t251 = load i32, ptr %l25, !tbaa !23
  %t254 = icmp eq i32 %t249, %t251
  br i1 %t254, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb57
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t256 = load i64, ptr %l28, !tbaa !24
  %t258 = add i64 %t256, 1
  store i64 %t258, ptr %l28, !tbaa !24
  br label %bb49
bb59:
  %t260 = load i1, ptr %l26, !tbaa !21
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb60, label %bb61
bb60:
  %t264 = load i32, ptr %l25, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18, i32 %t264)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t267 = load i64, ptr %l23, !tbaa !24
  %t269 = add i64 %t267, 1
  store i64 %t269, ptr %l23, !tbaa !24
  br label %bb44
bb65:
  %t271 = load ptr, ptr %l3, !tbaa !29
  %t273 = getelementptr %"compiler/check:frame", ptr %t271, i32 0, i32 40
  %t274 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t273, i64 %t274)
  br label %bb66
bb66:
  %t277 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t277, ptr %l187
  br label %bb67
bb67:
  %t278 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l187
  %t279 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %t279
  store ptr %t279, ptr %l30, !tbaa !29
  %t281 = load ptr, ptr %l2, !tbaa !29
  %t283 = getelementptr %"compiler/ast:JoinS", ptr %t281, i32 0, i32 2
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t284, 0
  %t288 = icmp sgt i64 %t286, 0
  br i1 %t288, label %bb68, label %bb69
bb68:
  %t290 = load ptr, ptr %l2, !tbaa !29
  %t292 = getelementptr %"compiler/ast:JoinS", ptr %t290, i32 0, i32 0
  %t293 = load i1, ptr %t292, !tbaa !21
  %t295 = xor i1 %t293, true
  store i1 %t295, ptr %l193, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb70
bb70:
  %t297 = load i1, ptr %l193, !tbaa !21
  br i1 %t297, label %bb71, label %bb72
bb71:
  %t299 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18)
  store i64 %t299, ptr %l198
  br label %bb73
bb72:
  br label %bb80
bb73:
  %t300 = load i64, ptr %l198, !tbaa !24
  %t301 = icmp eq i64 %t300, 0
  br i1 %t301, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s17
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l200, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t307 = getelementptr %"compiler/ast:JoinS", ptr %t305, i32 0, i32 2
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  store { i64, ptr } %t308, ptr %l203, !tbaa !27
  %t309 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr ptr, ptr %t310, i64 0
  %t312 = load ptr, ptr %t311, !tbaa !39
  %t315 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t304, ptr %t312)
  store %"compiler/source:Span" %t315, ptr %l205
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t316 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eJoinCatchNeedsTry(ptr %s17)
  store %"compiler/diagmsg:Msg" %t316, ptr %l206
  br label %bb77
bb77:
  %t317 = load ptr, ptr %l200, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l205
  %t319 = load %"compiler/diagmsg:Msg", ptr %l206
  %t320 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t317, %"compiler/source:Span" %t318, %"compiler/diagmsg:Msg" %t319)
  store i64 %t320, ptr %l207
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s17)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t321 = load ptr, ptr %l2, !tbaa !29
  %t323 = getelementptr %"compiler/ast:JoinS", ptr %t321, i32 0, i32 0
  %t324 = load i1, ptr %t323, !tbaa !21
  br i1 %t324, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s18
  %t327 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18)
  store i64 %t327, ptr %l211
  br label %bb83
bb82:
  %t329 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18)
  store i64 %t329, ptr %l360
  br label %bb155
bb83:
  %t330 = load i64, ptr %l211, !tbaa !24
  %t331 = icmp eq i64 %t330, 0
  br i1 %t331, label %bb84, label %bb85
bb84:
  %t333 = load ptr, ptr %l3, !tbaa !29
  %t335 = getelementptr %"compiler/check:frame", ptr %t333, i32 0, i32 41
  %t336 = load i64, ptr %t335, !tbaa !24
  %t337 = load i64, ptr %l5, !tbaa !24
  %t340 = icmp eq i64 %t336, %t337
  store i1 %t340, ptr %l213, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb86
bb86:
  %t342 = load i1, ptr %l213, !tbaa !21
  br i1 %t342, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s19
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l218, !tbaa !29
  %t344 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t344, ptr %l219
  %t345 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eJoinCannotFail(ptr %s19)
  store %"compiler/diagmsg:Msg" %t345, ptr %l220
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t346 = load ptr, ptr %l218, !tbaa !29
  %t347 = load %"compiler/source:Span", ptr %l219
  %t348 = load %"compiler/diagmsg:Msg", ptr %l220
  %t349 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t346, %"compiler/source:Span" %t347, %"compiler/diagmsg:Msg" %t348)
  store i64 %t349, ptr %l221
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s19)
  br label %bb91
bb91:
  %t350 = load ptr, ptr %l3, !tbaa !29
  %t352 = getelementptr %"compiler/check:frame", ptr %t350, i32 0, i32 28
  %t354 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t352)
  store i64 %t354, ptr %l224
  br label %bb92
bb92:
  %t355 = load i64, ptr %l224, !tbaa !24
  store i64 %t355, ptr %l31, !tbaa !24
  store ptr %l18, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb93
bb93:
  %t357 = load i64, ptr %l33, !tbaa !24
  store i64 %t357, ptr %l226, !tbaa !24
  %t358 = load ptr, ptr %l32, !tbaa !29
  %t360 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t358)
  store i64 %t360, ptr %l228
  br label %bb94
bb94:
  %t361 = load i64, ptr %l226, !tbaa !24
  %t362 = load i64, ptr %l228, !tbaa !24
  %t363 = icmp slt i64 %t361, %t362
  %t365 = xor i1 %t363, true
  br i1 %t365, label %bb95, label %bb96
bb95:
  br label %bb101
bb96:
  br label %bb97
bb97:
  %t367 = load ptr, ptr %l32, !tbaa !29
  %t368 = load i64, ptr %l33, !tbaa !24
  %t371 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t367, i64 %t368)
  store i32 %t371, ptr %l233
  br label %bb98
bb98:
  %t372 = load i32, ptr %l233, !tbaa !23
  %t373 = load ptr, ptr %l3, !tbaa !29
  %t375 = getelementptr %"compiler/check:frame", ptr %t373, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t375, i32 %t372)
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t379 = load i64, ptr %l33, !tbaa !24
  %t381 = add i64 %t379, 1
  store i64 %t381, ptr %l33, !tbaa !24
  br label %bb93
bb101:
  %t383 = load ptr, ptr %l3, !tbaa !29
  %t385 = getelementptr %"compiler/check:frame", ptr %t383, i32 0, i32 28
  %t387 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t385)
  store i64 %t387, ptr %l241
  br label %bb102
bb102:
  %t388 = load i64, ptr %l241, !tbaa !24
  store i64 %t388, ptr %l35, !tbaa !24
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load ptr, ptr %l2, !tbaa !29
  %t392 = getelementptr %"compiler/ast:JoinS", ptr %t390, i32 0, i32 2
  %t393 = load { i64, ptr }, ptr %t392, !tbaa !27
  %t394 = load i64, ptr %l31, !tbaa !24
  %t395 = load i64, ptr %l35, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %t389, { i64, ptr } %t393, i64 %t394, i64 %t395)
  br label %bb103
bb103:
  %t400 = load ptr, ptr %l2, !tbaa !29
  %t402 = getelementptr %"compiler/ast:JoinS", ptr %t400, i32 0, i32 2
  %t403 = load { i64, ptr }, ptr %t402, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t403, 0
  %t407 = icmp sgt i64 %t405, 0
  br i1 %t407, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s23
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load i64, ptr %l31, !tbaa !24
  %t411 = load i64, ptr %l35, !tbaa !24
  %t415 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %s23, ptr %t409, i64 %t410, i64 %t411)
  store { i64, ptr } %t415, ptr %l254
  br label %bb106
bb105:
  br label %bb146
bb106:
  %t416 = load { i64, ptr }, ptr %l254, !tbaa !27
  store { i64, ptr } %t416, ptr %l36, !tbaa !27
  %t417 = load ptr, ptr %l2, !tbaa !29
  %t419 = getelementptr %"compiler/ast:JoinS", ptr %t417, i32 0, i32 2
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  store { i64, ptr } %t420, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t422 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t422, 0
  store i64 %t424, ptr %l39, !tbaa !24
  br label %bb107
bb107:
  %t426 = load i64, ptr %l38, !tbaa !24
  %t427 = load i64, ptr %l39, !tbaa !24
  %t430 = icmp slt i64 %t426, %t427
  %t432 = xor i1 %t430, true
  br i1 %t432, label %bb108, label %bb109
bb108:
  br label %bb114
bb109:
  br label %bb110
bb110:
  %t434 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t434, ptr %l263, !tbaa !27
  %t435 = load i64, ptr %l38, !tbaa !24
  %t437 = getelementptr { i64, ptr }, ptr %l263, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr ptr, ptr %t438, i64 %t435
  %t440 = load ptr, ptr %t439, !tbaa !39
  %t442 = load ptr, ptr %l30, !tbaa !29
  store ptr %t442, ptr %l266, !tbaa !29
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t446 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t447 = load ptr, ptr %l30, !tbaa !29
  %t453 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %s23, ptr %v0, ptr %v0, ptr %t443, ptr %t440, i32 %t445, i1 false, { i64, ptr } %t446, ptr %t447)
  store ptr %t453, ptr %l272
  br label %bb111
bb111:
  %t454 = load ptr, ptr %l266, !tbaa !29
  %t455 = load ptr, ptr %l272, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v0, ptr %t454, ptr %t455)
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t456 = load i64, ptr %l38, !tbaa !24
  %t458 = add i64 %t456, 1
  store i64 %t458, ptr %l38, !tbaa !24
  br label %bb107
bb114:
  %t460 = load ptr, ptr %l3, !tbaa !29
  %t462 = getelementptr %"compiler/check:frame", ptr %t460, i32 0, i32 33
  %t463 = load i64, ptr %t462, !tbaa !24
  %t464 = load i64, ptr %l4, !tbaa !24
  %t467 = icmp sgt i64 %t463, %t464
  br i1 %t467, label %bb115, label %bb116
bb115:
  store i64 0, ptr %l41, !tbaa !24
  %t469 = load ptr, ptr %l30, !tbaa !29
  %t471 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eLen__H4e51b5ca7b68af485b8486164a690a5f(ptr %v0, ptr %t469)
  store i64 %t471, ptr %l280
  br label %bb117
bb116:
  br label %bb145
bb117:
  %t472 = load i64, ptr %l280, !tbaa !24
  store i64 %t472, ptr %l42, !tbaa !24
  store i64 1, ptr %l43, !tbaa !24
  %t473 = load i64, ptr %l42, !tbaa !24
  %t474 = load i64, ptr %l41, !tbaa !24
  %t477 = icmp sgt i64 %t473, %t474
  br i1 %t477, label %bb118, label %bb119
bb118:
  %t479 = load i64, ptr %l43, !tbaa !24
  %t481 = icmp sgt i64 %t479, 0
  br i1 %t481, label %bb120, label %bb121
bb119:
  store i64 0, ptr %l284, !tbaa !24
  br label %bb123
bb120:
  %t483 = load i64, ptr %l42, !tbaa !24
  %t484 = load i64, ptr %l41, !tbaa !24
  %t487 = sub i64 %t483, %t484
  %t488 = load i64, ptr %l43, !tbaa !24
  %t491 = add i64 %t487, %t488
  %t493 = sub i64 %t491, 1
  %t494 = load i64, ptr %l43, !tbaa !24
  %t497 = sdiv i64 %t493, %t494
  store i64 %t497, ptr %l287, !tbaa !24
  br label %bb122
bb121:
  store i64 0, ptr %l287, !tbaa !24
  br label %bb122
bb122:
  %t499 = load i64, ptr %l287, !tbaa !24
  store i64 %t499, ptr %l284, !tbaa !24
  br label %bb123
bb123:
  %t500 = load i64, ptr %l284, !tbaa !24
  store i64 %t500, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb124
bb124:
  store %olang.scope zeroinitializer, ptr %s29
  %t501 = load i64, ptr %l45, !tbaa !24
  %t502 = load i64, ptr %l44, !tbaa !24
  %t505 = icmp slt i64 %t501, %t502
  %t507 = xor i1 %t505, true
  br i1 %t507, label %bb125, label %bb126
bb125:
  call void @__olang_scope_close(ptr %s29)
  br label %bb144
bb126:
  br label %bb127
bb127:
  %t509 = load i64, ptr %l41, !tbaa !24
  %t510 = load i64, ptr %l45, !tbaa !24
  %t511 = load i64, ptr %l43, !tbaa !24
  %t514 = mul i64 %t510, %t511
  %t517 = add i64 %t509, %t514
  store i64 %t517, ptr %l46, !tbaa !24
  %t519 = load ptr, ptr %l30, !tbaa !29
  %t521 = load i64, ptr %l46, !tbaa !24
  %t524 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0, ptr %v0, ptr %t519, i64 %t521)
  store ptr %t524, ptr %l308
  br label %bb128
bb128:
  %t525 = load ptr, ptr %l308, !tbaa !29
  %t527 = getelementptr %"compiler/typed:Clause", ptr %t525, i32 0, i32 3
  %t528 = load ptr, ptr %t527, !tbaa !29
  %t530 = icmp eq ptr %t528, null
  %t532 = xor i1 %t530, true
  br i1 %t532, label %bb129, label %bb130
bb129:
  %t534 = load ptr, ptr %l30, !tbaa !29
  %t536 = load i64, ptr %l46, !tbaa !24
  %t539 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0, ptr %v0, ptr %t534, i64 %t536)
  store ptr %t539, ptr %l317
  br label %bb131
bb130:
  store i1 false, ptr %l313, !tbaa !21
  br label %bb136
bb131:
  %t540 = load ptr, ptr %l317, !tbaa !29
  %t542 = getelementptr %"compiler/typed:Clause", ptr %t540, i32 0, i32 3
  %t543 = load ptr, ptr %t542, !tbaa !29
  store ptr %t543, ptr %l47, !tbaa !29
  %t545 = load ptr, ptr %l47, !tbaa !29
  %t547 = icmp eq ptr %t545, null
  br i1 %t547, label %bb132, label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_951d796b2ec85af2_4e6ca0fa0a1175d6)
  unreachable
bb133:
  br label %bb134
bb134:
  %t549 = load ptr, ptr %l47, !tbaa !29
  %t551 = call i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %t549)
  store i1 %t551, ptr %l323
  br label %bb135
bb135:
  %t552 = load i1, ptr %l323, !tbaa !21
  store i1 %t552, ptr %l313, !tbaa !21
  br label %bb136
bb136:
  %t553 = load i1, ptr %l313, !tbaa !21
  br i1 %t553, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s29)
  br label %bb143
bb138:
  br label %bb139
bb139:
  %t554 = load ptr, ptr %l0, !tbaa !29
  store ptr %t554, ptr %l324, !tbaa !29
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t556 = load ptr, ptr %l2, !tbaa !29
  %t558 = getelementptr %"compiler/ast:JoinS", ptr %t556, i32 0, i32 2
  %t559 = load { i64, ptr }, ptr %t558, !tbaa !27
  store { i64, ptr } %t559, ptr %l327, !tbaa !27
  %t560 = load i64, ptr %l46, !tbaa !24
  %t562 = getelementptr { i64, ptr }, ptr %l327, i32 0, i32 1
  %t563 = load ptr, ptr %t562, !tbaa !27
  %t564 = getelementptr ptr, ptr %t563, i64 %t560
  %t565 = load ptr, ptr %t564, !tbaa !39
  %t568 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t555, ptr %t565)
  store %"compiler/source:Span" %t568, ptr %l330
  br label %bb140
bb140:
  %t569 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eJoinClauseMustLeave(ptr %s29)
  store %"compiler/diagmsg:Msg" %t569, ptr %l331
  br label %bb141
bb141:
  %t570 = load ptr, ptr %l324, !tbaa !29
  %t571 = load %"compiler/source:Span", ptr %l330
  %t572 = load %"compiler/diagmsg:Msg", ptr %l331
  %t573 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s29, ptr %t570, %"compiler/source:Span" %t571, %"compiler/diagmsg:Msg" %t572)
  store i64 %t573, ptr %l332
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s29)
  br label %bb144
bb143:
  %t574 = load i64, ptr %l45, !tbaa !24
  %t576 = add i64 %t574, 1
  store i64 %t576, ptr %l45, !tbaa !24
  br label %bb124
bb144:
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s23)
  br label %bb146
bb146:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load i64, ptr %l31, !tbaa !24
  %t580 = load i64, ptr %l35, !tbaa !24
  %t581 = load ptr, ptr %l30, !tbaa !29
  %t586 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v0, ptr %t578, i64 %t579, i64 %t580, ptr %t581)
  store i64 %t586, ptr %l339
  br label %bb147
bb147:
  %t587 = load i64, ptr %l339, !tbaa !24
  store i64 %t587, ptr %l48, !tbaa !24
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load %"compiler/source:Span", ptr %l1
  %t592 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t588, %"compiler/source:Span" %t589)
  store { i64, ptr } %t592, ptr %l343
  br label %bb148
bb148:
  %t593 = load { i64, ptr }, ptr %l343, !tbaa !27
  %t594 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s18, { i64, ptr } %t593, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d6, i32 0, i32 1) })
  %t595 = extractvalue { i32, i64 } %t594, 1
  %t596 = extractvalue { i32, i64 } %t594, 0
  store i32 %t596, ptr %l345
  %t597 = icmp ne i32 %t596, 0
  br i1 %t597, label %bb150, label %ok.598, !prof !99
ok.598:
  store i64 %t595, ptr %l344
  br label %bb149
bb149:
  %t599 = load i64, ptr %l344, !tbaa !24
  store i64 %t599, ptr %l340, !tbaa !24
  br label %bb152
bb150:
  br label %bb151
bb151:
  store i64 0, ptr %l340, !tbaa !24
  br label %bb152
bb152:
  %t600 = load i64, ptr %l340, !tbaa !24
  store i64 %t600, ptr %l49, !tbaa !24
  %t601 = load ptr, ptr %l0, !tbaa !29
  store ptr %t601, ptr %l346, !tbaa !29
  %t602 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t603 = load i32, ptr %t602, !tbaa !23
  %t604 = load i64, ptr %l49, !tbaa !24
  %t606 = trunc i64 %t604 to i32
  %t609 = add i32 %t603, %t606
  %t610 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t611 = load i32, ptr %t610, !tbaa !23
  %t612 = load i64, ptr %l49, !tbaa !24
  %t614 = trunc i64 %t612 to i32
  %t617 = add i32 %t611, %t614
  %t619 = add i32 %t617, 4
  %t622 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s18, i32 %t609, i32 %t619)
  store %"compiler/source:Span" %t622, ptr %l356
  br label %bb153
bb153:
  %t623 = load i64, ptr %l31, !tbaa !24
  %t624 = load i64, ptr %l48, !tbaa !24
  %t625 = load ptr, ptr %l346, !tbaa !29
  %t626 = load %"compiler/source:Span", ptr %l356
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %t625, %"compiler/source:Span" %t626, i64 %t623, i64 %t624)
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s18)
  br label %bb163
bb155:
  %t629 = load i64, ptr %l360, !tbaa !24
  %t630 = icmp sgt i64 %t629, 0
  br i1 %t630, label %bb156, label %bb157
bb156:
  store %olang.scope zeroinitializer, ptr %s33
  %t632 = load ptr, ptr %l0, !tbaa !29
  store ptr %t632, ptr %l362, !tbaa !29
  %t633 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t633, ptr %l363
  %t634 = load ptr, ptr %l0, !tbaa !29
  store ptr %t634, ptr %l364, !tbaa !29
  %t636 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18, i64 0)
  store i32 %t636, ptr %l366
  br label %bb158
bb157:
  br label %bb162
bb158:
  %t637 = load ptr, ptr %l364, !tbaa !29
  %t638 = load i32, ptr %l366, !tbaa !23
  %t639 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s33, ptr %t637, i32 %t638)
  store { i64, ptr } %t639, ptr %l367
  br label %bb159
bb159:
  %t640 = load { i64, ptr }, ptr %l367, !tbaa !27
  %t641 = extractvalue { i64, ptr } %t640, 0
  %t642 = extractvalue { i64, ptr } %t640, 1
  %t643 = mul i64 %t641, 1
  %t644 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t643)
  call void @llvm.memcpy.p0.p0.i64(ptr %t644, ptr %t642, i64 %t643, i1 false)
  %t645 = insertvalue { i64, ptr } undef, i64 %t641, 0
  %t646 = insertvalue { i64, ptr } %t645, ptr %t644, 1
  %t648 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eJoinNotTried(ptr %s33, ptr %s33, { i64, ptr } %t646)
  store %"compiler/diagmsg:Msg" %t648, ptr %l369
  br label %bb160
bb160:
  %t649 = load ptr, ptr %l362, !tbaa !29
  %t650 = load %"compiler/source:Span", ptr %l363
  %t651 = load %"compiler/diagmsg:Msg", ptr %l369
  %t652 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s33, ptr %t649, %"compiler/source:Span" %t650, %"compiler/diagmsg:Msg" %t651)
  store i64 %t652, ptr %l370
  br label %bb161
bb161:
  call void @__olang_scope_close(ptr %s33)
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t653 = load ptr, ptr %l3, !tbaa !29
  %t654 = load i64, ptr %l4, !tbaa !24
  %t657 = getelementptr %"compiler/check:frame", ptr %t653, i32 0, i32 33
  store i64 %t654, ptr %t657, !tbaa !24
  %t658 = load ptr, ptr %l0, !tbaa !29
  store ptr %t658, ptr %l373, !tbaa !29
  %t659 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t659, ptr %l374
  %t660 = load ptr, ptr %l15, !tbaa !29
  store ptr %t660, ptr %l375, !tbaa !29
  %t661 = load ptr, ptr %l2, !tbaa !29
  %t663 = getelementptr %"compiler/ast:JoinS", ptr %t661, i32 0, i32 0
  %t664 = load i1, ptr %t663, !tbaa !21
  store i1 %t664, ptr %l377, !tbaa !21
  %t665 = load ptr, ptr %l30, !tbaa !29
  %t667 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v0, ptr %v0, ptr %t665)
  store { i64, ptr } %t667, ptr %l379
  br label %bb164
bb164:
  %t668 = load ptr, ptr %l375, !tbaa !29
  %t669 = load i1, ptr %l377, !tbaa !21
  %t670 = load { i64, ptr }, ptr %l379, !tbaa !27
  %t671 = call %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t668, i1 %t669, { i64, ptr } %t670)
  store %"compiler/typed:Join" %t671, ptr %l380
  br label %bb165
bb165:
  %t672 = load %"compiler/typed:Join", ptr %l380
  %t673 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Join" %t672, ptr %t673
  store { i64, [3 x i64] } zeroinitializer, ptr %t674
  %t675 = getelementptr { i64, [3 x i64] }, ptr %t674, i32 0, i32 0
  store i64 13, ptr %t675
  %t676 = load %"compiler/source:Span", ptr %l374
  %t677 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t676, 0
  %t679 = insertvalue { %"compiler/source:Span", ptr } %t677, ptr %t673, 1
  %t680 = getelementptr { i64, [3 x i64] }, ptr %t674, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t679, ptr %t680
  %t681 = load { i64, [3 x i64] }, ptr %t674
  %t683 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t681, ptr %t683
  %t684 = load ptr, ptr %l373, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t684, ptr %t683)
  br label %bb166
bb166:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/check:laneNode"
  %l17 = alloca { i64, ptr }
  %l23 = alloca %"compiler/check:laneNode"
  %l40 = alloca i1
  %l48 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca i32
  %l56 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1, ptr %l3, !tbaa !23
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %bb20
bb3:
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t17, ptr %l17, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i64, ptr %t21, i64 %t18
  %t23 = load i64, ptr %t22, !tbaa !34
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 39
  %t31 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t27, i64 %t23)
  store %"compiler/check:laneNode" %t31, ptr %l23
  br label %bb5
bb5:
  %t32 = load %"compiler/check:laneNode", ptr %l23
  store %"compiler/check:laneNode" %t32, ptr %l8
  %t33 = getelementptr %"compiler/check:laneNode", ptr %l8, i32 0, i32 0
  %t34 = load i64, ptr %t33, !tbaa !24
  %t35 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneScalar, !tbaa !24
  %t38 = icmp eq i64 %t34, %t35
  br i1 %t38, label %bb6, label %bb7
bb6:
  br label %bb19
bb7:
  br label %bb8
bb8:
  %t40 = getelementptr %"compiler/check:laneNode", ptr %l8, i32 0, i32 10
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t45 = icmp eq i32 %t41, %t42
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t49 = load i32, ptr %l3, !tbaa !23
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t53 = icmp eq i32 %t49, %t50
  br i1 %t53, label %bb12, label %bb13
bb12:
  %t55 = getelementptr %"compiler/check:laneNode", ptr %l8, i32 0, i32 10
  %t56 = load i32, ptr %t55, !tbaa !23
  store i32 %t56, ptr %l3, !tbaa !23
  br label %bb18
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l3, !tbaa !23
  %t65 = getelementptr %"compiler/check:laneNode", ptr %l8, i32 0, i32 10
  %t66 = load i32, ptr %t65, !tbaa !23
  %t70 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t63, i32 %t64, i32 %t66)
  store i1 %t70, ptr %l40
  br label %bb14
bb14:
  %t71 = load i1, ptr %l40, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb15, label %bb16
bb15:
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l5, !tbaa !24
  br label %bb1
bb20:
  %t80 = load i32, ptr %l3, !tbaa !23
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t84 = icmp eq i32 %t80, %t81
  br i1 %t84, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb25
bb22:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  store ptr %t91, ptr %l51, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l54
  br label %bb23
bb23:
  %t98 = load ptr, ptr %l51, !tbaa !29
  %t99 = load i32, ptr %l54, !tbaa !23
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t98, i32 %t99, i32 %a2)
  store i1 %t101, ptr %l56
  br label %bb24
bb24:
  %t102 = load i1, ptr %l56, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l48, !tbaa !21
  br label %bb25
bb25:
  %t105 = load i1, ptr %l48, !tbaa !21
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t106, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t108 = load i32, ptr %l3, !tbaa !23
  store i32 %t108, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l24 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l19, !tbaa !27
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  store i32 %t30, ptr %l7, !tbaa !23
  %t32 = load i32, ptr %l7, !tbaa !23
  %t34 = icmp ne i32 %t32, 0
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l7, !tbaa !23
  %t41 = add i64 %a3, 1
  %t46 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %t36, i32 %t37, i32 %a2, i64 %t41)
  store i1 %t46, ptr %l30
  br label %bb8
bb7:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb9
bb8:
  %t47 = load i1, ptr %l30, !tbaa !21
  store i1 %t47, ptr %l24, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l24, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb2
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l27 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t15, ptr %l14
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  br label %bb14
bb7:
  br label %bb8
bb8:
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t29, ptr %l21, !tbaa !27
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i32, ptr %t33, i64 %t30
  %t35 = load i32, ptr %t34, !tbaa !33
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t37, i32 %t35, i64 %a2)
  store i1 %t43, ptr %l27
  br label %bb9
bb9:
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l4, !tbaa !24
  br label %bb5
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca %"compiler/generic:Desc"
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i1
  %l32 = alloca i1
  %l37 = alloca %"compiler/check:reflList"
  %l40 = alloca i32
  %l43 = alloca i32
  %l48 = alloca %"compiler/check:reflList"
  %l49 = alloca %"compiler/check:reflList"
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l56 = alloca %"compiler/check:reflList"
  %l59 = alloca i32
  %l65 = alloca %"compiler/generic:Desc"
  %l69 = alloca i1
  %l76 = alloca %"compiler/check:reflList"
  %l80 = alloca i1
  %l86 = alloca %"compiler/check:reflList"
  %l90 = alloca i1
  %l96 = alloca %"compiler/check:reflList"
  %l97 = alloca %"compiler/check:reflList"
  %l100 = alloca i32
  %l103 = alloca %"compiler/check:reflList"
  %l106 = alloca i1
  %l107 = alloca i1
  %l110 = alloca i1
  %l112 = alloca i1
  %l116 = alloca i1
  %l117 = alloca %"compiler/check:reflList"
  %l120 = alloca %"compiler/check:reflList"
  %l121 = alloca ptr
  %l122 = alloca i1
  %l129 = alloca %"compiler/check:reflList"
  %l130 = alloca %"compiler/check:reflList"
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"compiler/check:reflList"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb81
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t22, i32 %t23)
  store { i64, ptr } %t26, ptr %l21
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t27, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t28, ptr %l22
  br label %bb7
bb7:
  %t29 = load i1, ptr %l22, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t34 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealiasModule(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  store i64 %t34, ptr %l25
  br label %bb10
bb9:
  br label %bb28
bb10:
  %t35 = load i64, ptr %l25, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sge i64 %t36, 0
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i32, ptr %l3, !tbaa !23
  %t46 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresName(ptr %v0, ptr %t40, i64 %t41, i32 %t42)
  store i1 %t46, ptr %l32
  br label %bb13
bb12:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb14
bb13:
  %t47 = load i1, ptr %l32, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l28, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l28, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t52 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFunctions, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t57 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s3, i1 true, i32 %t51, i64 %t52, i64 %t53)
  store %"compiler/check:reflList" %t57, ptr %l37
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  %t58 = load %"compiler/check:reflList", ptr %l37
  store %"compiler/check:reflList" %t58, ptr %rv
  br label %ret
bb18:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = icmp slt i64 %t59, 0
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t63, ptr %t64)
  store i32 %t67, ptr %l43
  br label %bb21
bb20:
  store i32 -1, ptr %l40, !tbaa !23
  br label %bb22
bb21:
  %t68 = load i32, ptr %l43, !tbaa !23
  store i32 %t68, ptr %l40, !tbaa !23
  br label %bb22
bb22:
  %t69 = load i32, ptr %l40, !tbaa !23
  store i32 %t69, ptr %l5, !tbaa !23
  %t70 = load i32, ptr %l5, !tbaa !23
  %t72 = icmp sge i32 %t70, 0
  br i1 %t72, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t74 = load i32, ptr %l5, !tbaa !23
  %t75 = load i64, ptr @G_2ecompiler_2fgeneric_2eListBuilders, !tbaa !24
  %t78 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s4, i1 true, i32 %t74, i64 %t75, i64 -1)
  store %"compiler/check:reflList" %t78, ptr %l48
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  %t79 = load %"compiler/check:reflList", ptr %l48
  store %"compiler/check:reflList" %t79, ptr %rv
  br label %ret
bb26:
  %t80 = call %"compiler/check:reflList" @compiler_2fcheck_2ereflList_2enoList()
  store %"compiler/check:reflList" %t80, ptr %l49
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s1)
  %t81 = load %"compiler/check:reflList", ptr %l49
  store %"compiler/check:reflList" %t81, ptr %rv
  br label %ret
bb28:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l3, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t82, i32 %t83)
  store { i64, ptr } %t86, ptr %l52
  br label %bb29
bb29:
  %t87 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t88 = call i64 @compiler_2fcheck_2elistIndex(ptr %v0, { i64, ptr } %t87)
  store i64 %t88, ptr %l53
  br label %bb30
bb30:
  %t89 = load i64, ptr %l53, !tbaa !24
  store i64 %t89, ptr %l6, !tbaa !24
  %t90 = load i64, ptr %l6, !tbaa !24
  %t92 = icmp slt i64 %t90, 0
  br i1 %t92, label %bb31, label %bb32
bb31:
  %t94 = call %"compiler/check:reflList" @compiler_2fcheck_2ereflList_2enoList()
  store %"compiler/check:reflList" %t94, ptr %l56
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s1)
  %t95 = load %"compiler/check:reflList", ptr %l56
  store %"compiler/check:reflList" %t95, ptr %rv
  br label %ret
bb34:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t100 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i32 %t100, ptr %l59
  br label %bb35
bb35:
  %t101 = load i32, ptr %l59, !tbaa !23
  store i32 %t101, ptr %l7, !tbaa !23
  %t102 = load i32, ptr %l7, !tbaa !23
  %t104 = icmp sge i32 %t102, 0
  br i1 %t104, label %bb36, label %bb37
bb36:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i32, ptr %l7, !tbaa !23
  %t113 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t109, i32 %t110)
  store %"compiler/generic:Desc" %t113, ptr %l65
  br label %bb38
bb37:
  br label %bb61
bb38:
  %t114 = load %"compiler/generic:Desc", ptr %l65
  store %"compiler/generic:Desc" %t114, ptr %l8
  %t115 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 0
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescCase, !tbaa !24
  %t120 = icmp eq i64 %t116, %t117
  br i1 %t120, label %bb39, label %bb40
bb39:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr @G_2ecompiler_2fgeneric_2eListFields, !tbaa !24
  %t126 = icmp eq i64 %t122, %t123
  store i1 %t126, ptr %l69, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb41
bb41:
  %t128 = load i1, ptr %l69, !tbaa !21
  br i1 %t128, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s7
  %t129 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 1
  %t130 = load i32, ptr %t129, !tbaa !23
  %t131 = load i64, ptr %l6, !tbaa !24
  %t132 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 2
  %t133 = load i64, ptr %t132, !tbaa !24
  %t137 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s7, i1 true, i32 %t130, i64 %t131, i64 %t133)
  store %"compiler/check:reflList" %t137, ptr %l76
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s1)
  %t138 = load %"compiler/check:reflList", ptr %l76
  store %"compiler/check:reflList" %t138, ptr %rv
  br label %ret
bb45:
  %t139 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 0
  %t140 = load i64, ptr %t139, !tbaa !24
  %t141 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t144 = icmp eq i64 %t140, %t141
  br i1 %t144, label %bb46, label %bb47
bb46:
  %t146 = load i64, ptr %l6, !tbaa !24
  %t147 = load i64, ptr @G_2ecompiler_2fgeneric_2eListParams, !tbaa !24
  %t150 = icmp eq i64 %t146, %t147
  store i1 %t150, ptr %l80, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb48
bb48:
  %t152 = load i1, ptr %l80, !tbaa !21
  br i1 %t152, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t153 = load i32, ptr %l7, !tbaa !23
  %t154 = load i64, ptr %l6, !tbaa !24
  %t157 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s8, i1 true, i32 %t153, i64 %t154, i64 -1)
  store %"compiler/check:reflList" %t157, ptr %l86
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s1)
  %t158 = load %"compiler/check:reflList", ptr %l86
  store %"compiler/check:reflList" %t158, ptr %rv
  br label %ret
bb52:
  %t159 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 0
  %t160 = load i64, ptr %t159, !tbaa !24
  %t161 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t164 = icmp eq i64 %t160, %t161
  br i1 %t164, label %bb53, label %bb54
bb53:
  %t166 = load i64, ptr %l6, !tbaa !24
  %t167 = load i64, ptr @G_2ecompiler_2fgeneric_2eListResults, !tbaa !24
  %t170 = icmp eq i64 %t166, %t167
  store i1 %t170, ptr %l90, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb55
bb55:
  %t172 = load i1, ptr %l90, !tbaa !21
  br i1 %t172, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t173 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 1
  %t174 = load i32, ptr %t173, !tbaa !23
  %t175 = load i64, ptr %l6, !tbaa !24
  %t178 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s9, i1 true, i32 %t174, i64 %t175, i64 -1)
  store %"compiler/check:reflList" %t178, ptr %l96
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s1)
  %t179 = load %"compiler/check:reflList", ptr %l96
  store %"compiler/check:reflList" %t179, ptr %rv
  br label %ret
bb59:
  %t180 = call %"compiler/check:reflList" @compiler_2fcheck_2ereflList_2enoList()
  store %"compiler/check:reflList" %t180, ptr %l97
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s1)
  %t181 = load %"compiler/check:reflList", ptr %l97
  store %"compiler/check:reflList" %t181, ptr %rv
  br label %ret
bb61:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l2, !tbaa !29
  %t186 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t182, ptr %t183)
  store i32 %t186, ptr %l100
  br label %bb62
bb62:
  %t187 = load i32, ptr %l100, !tbaa !23
  store i32 %t187, ptr %l9, !tbaa !23
  %t188 = load i32, ptr %l9, !tbaa !23
  %t190 = icmp slt i32 %t188, 0
  br i1 %t190, label %bb63, label %bb64
bb63:
  %t192 = call %"compiler/check:reflList" @compiler_2fcheck_2ereflList_2enoList()
  store %"compiler/check:reflList" %t192, ptr %l103
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s1)
  %t193 = load %"compiler/check:reflList", ptr %l103
  store %"compiler/check:reflList" %t193, ptr %rv
  br label %ret
bb66:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l9, !tbaa !23
  %t198 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t194, i32 %t195)
  store i1 %t198, ptr %l106
  br label %bb67
bb67:
  %t199 = load i1, ptr %l106, !tbaa !21
  br i1 %t199, label %bb68, label %bb69
bb68:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l2, !tbaa !29
  %t204 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %t200, ptr %t201)
  store i1 %t204, ptr %l110
  br label %bb70
bb69:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb71
bb70:
  %t205 = load i1, ptr %l110, !tbaa !21
  %t206 = xor i1 %t205, true
  store i1 %t206, ptr %l107, !tbaa !21
  br label %bb71
bb71:
  %t208 = load i1, ptr %l107, !tbaa !21
  br i1 %t208, label %bb72, label %bb73
bb72:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i32, ptr %l9, !tbaa !23
  %t211 = load i32, ptr %l3, !tbaa !23
  %t215 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t209, i32 %t210, i32 %t211)
  store i1 %t215, ptr %l116
  br label %bb74
bb73:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb75
bb74:
  %t216 = load i1, ptr %l116, !tbaa !21
  store i1 %t216, ptr %l112, !tbaa !21
  br label %bb75
bb75:
  %t217 = load i1, ptr %l112, !tbaa !21
  br i1 %t217, label %bb76, label %bb77
bb76:
  %t218 = call %"compiler/check:reflList" @compiler_2fcheck_2ereflList_2enoList()
  store %"compiler/check:reflList" %t218, ptr %l117
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_scope_close(ptr %s1)
  %t219 = load %"compiler/check:reflList", ptr %l117
  store %"compiler/check:reflList" %t219, ptr %rv
  br label %ret
bb79:
  %t220 = load i32, ptr %l9, !tbaa !23
  %t221 = load i64, ptr %l6, !tbaa !24
  %t224 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s1, i1 true, i32 %t220, i64 %t221, i64 -1)
  store %"compiler/check:reflList" %t224, ptr %l120
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s1)
  %t225 = load %"compiler/check:reflList", ptr %l120
  store %"compiler/check:reflList" %t225, ptr %rv
  br label %ret
bb81:
  %t226 = load ptr, ptr %l1, !tbaa !29
  store ptr %t226, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t227 = load ptr, ptr %l121, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb82, label %bb83
bb82:
  %t230 = load ptr, ptr %l121, !tbaa !29
  %t231 = load i64, ptr %t230, !range !{i64 0, i64 30}
  %t233 = icmp eq i64 %t231, 2
  store i1 %t233, ptr %l122, !tbaa !21
  br label %bb83
bb83:
  %t234 = load i1, ptr %l122, !tbaa !21
  br i1 %t234, label %bb84, label %bb85
bb84:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr { i64, [4 x i64] }, ptr %t235, i32 0, i32 1
  %t238 = getelementptr { %"compiler/source:Span", ptr }, ptr %t237, i32 0, i32 1
  %t239 = load ptr, ptr %t238
  store ptr %t239, ptr %l10, !tbaa !29
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l10, !tbaa !29
  %t245 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t241, ptr %t242)
  store %"compiler/check:reflList" %t245, ptr %l129
  br label %bb87
bb87:
  %t246 = load %"compiler/check:reflList", ptr %l129
  store %"compiler/check:reflList" %t246, ptr %rv
  br label %ret
bb88:
  br i1 true, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb93
bb91:
  %t247 = call %"compiler/check:reflList" @compiler_2fcheck_2ereflList_2enoList()
  store %"compiler/check:reflList" %t247, ptr %l130
  br label %bb92
bb92:
  %t248 = load %"compiler/check:reflList", ptr %l130
  store %"compiler/check:reflList" %t248, ptr %rv
  br label %ret
bb93:
  call void @__olang_check_failed(ptr @olang_loc_7b7c458ad09559c8_7a5ff3a2c3d540e4)
  unreachable
ret:
  %rr = load %"compiler/check:reflList", ptr %rv
  ret %"compiler/check:reflList" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:litv"
  %l3 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i32
  %l32 = alloca double
  %l33 = alloca i1
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 1
  %t22 = load i1, ptr %t21, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l19
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 4
  %t37 = load double, ptr %t36, !tbaa !26
  %t40 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t35, double %t37)
  store i1 %t40, ptr %l23
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t41 = load i1, ptr %l23, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l20, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l29
  br label %bb14
bb14:
  %t55 = load i1, ptr %l29, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t56 = load i32, ptr %l3, !tbaa !23
  store i32 %t56, ptr %l30, !tbaa !23
  %t57 = load %"compiler/check:litv", ptr %l1
  %t59 = call double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %t57)
  store double %t59, ptr %l32
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t60 = load i32, ptr %l30, !tbaa !23
  %t61 = load double, ptr %l32, !tbaa !26
  %t62 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t60, double %t61)
  store i1 %t62, ptr %l33
  br label %bb18
bb18:
  %t63 = load i1, ptr %l33, !tbaa !21
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %rv
  br label %ret
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load %"compiler/check:litv", ptr %l1
  %t73 = load i32, ptr %l3, !tbaa !23
  %t77 = call i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %t71, %"compiler/check:litv" %t72, i32 %t73)
  store i1 %t77, ptr %l40
  br label %bb20
bb20:
  %t78 = load i1, ptr %l40, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca %"compiler/check:litv"
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/check:litv" %t6, ptr %l8
  br label %bb1
bb1:
  %t7 = getelementptr %"compiler/check:litv", ptr %l8, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t15 = load ptr, ptr %l11, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 30}
  %t18 = icmp eq i64 %t16, 2
  store i1 %t18, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i1 %t30, ptr %l19
  br label %bb10
bb10:
  %t31 = load i1, ptr %l19, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 30}
  %t39 = icmp eq i64 %t37, 8
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l3, !tbaa !29
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t49, i32 0, i32 3
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t53, ptr %t54)
  store i1 %t57, ptr %l30
  br label %bb17
bb17:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t63 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t59, ptr %t60)
  store i1 %t63, ptr %l34
  br label %bb20
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb21
bb20:
  %t64 = load i1, ptr %l34, !tbaa !21
  store i1 %t64, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t65 = load i1, ptr %l31, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_c608509fed4a7aab_41eb2a14c072322f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca ptr
  %l7 = alloca %"compiler/typed:Local"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %a1)
  store %"compiler/typed:Local" %t10, ptr %l7
  br label %bb2
bb2:
  %t11 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca { i64, [1 x i64] }
  %l7 = alloca ptr
  %l8 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca { i64, [1 x i64] }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l28 = alloca i1
  %l29 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t5 = alloca { i64, [1 x i64] }, align 8
  %t18 = alloca { i64, [1 x i64] }, align 8
  %t59 = alloca { i64, [1 x i64] }, align 8
  %t63 = alloca { i64, [1 x i64] }, align 8
  %t68 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, [1 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [1 x i64] }, ptr %t5, i32 0, i32 0
  store i64 4, ptr %t6
  %t7 = load { i64, [1 x i64] }, ptr %t5
  store { i64, [1 x i64] } %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 8}
  %t16 = icmp eq i64 %t14, 3
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store { i64, [1 x i64] } zeroinitializer, ptr %t18
  %t19 = getelementptr { i64, [1 x i64] }, ptr %t18, i32 0, i32 0
  store i64 1, ptr %t19
  %t20 = load { i64, [1 x i64] }, ptr %t18
  store { i64, [1 x i64] } %t20, ptr %l6
  br label %bb31
bb9:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l13, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t33, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l2, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t41 = call { i64, [1 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkOf(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store { i64, [1 x i64] } %t41, ptr %l20
  br label %bb15
bb15:
  %t42 = load { i64, [1 x i64] }, ptr %l20
  store { i64, [1 x i64] } %t42, ptr %l6
  br label %bb31
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb17, label %bb18
bb17:
  %t47 = load ptr, ptr %l21, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 0
  store i1 %t50, ptr %l22, !tbaa !21
  br label %bb18
bb18:
  %t51 = load i1, ptr %l22, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb26
bb21:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  store i1 %t57, ptr %l28
  br label %bb22
bb22:
  %t58 = load i1, ptr %l28, !tbaa !21
  br i1 %t58, label %bb23, label %bb24
bb23:
  store { i64, [1 x i64] } zeroinitializer, ptr %t59
  %t60 = getelementptr { i64, [1 x i64] }, ptr %t59, i32 0, i32 0
  store i64 4, ptr %t60
  %t61 = load { i64, [1 x i64] }, ptr %t59
  store { i64, [1 x i64] } %t61, ptr %l29
  br label %bb25
bb24:
  store { i64, [1 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [1 x i64] }, ptr %t63, i32 0, i32 0
  store i64 0, ptr %t64
  %t65 = load { i64, [1 x i64] }, ptr %t63
  store { i64, [1 x i64] } %t65, ptr %l29
  br label %bb25
bb25:
  %t67 = load { i64, [1 x i64] }, ptr %l29
  store { i64, [1 x i64] } %t67, ptr %l6
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, [1 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [1 x i64] }, ptr %t68, i32 0, i32 0
  store i64 0, ptr %t69
  %t70 = load { i64, [1 x i64] }, ptr %t68
  store { i64, [1 x i64] } %t70, ptr %l6
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_7175167c8688a627_14932d1cc2bc03fb)
  unreachable
bb31:
  %t72 = load { i64, [1 x i64] }, ptr %l6
  store { i64, [1 x i64] } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchValueMismatch(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l22 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca %"compiler/diagmsg:Msg"
  %l37 = alloca i64
  %l40 = alloca i32
  %l43 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca { i64, ptr }
  %l61 = alloca %"compiler/diagmsg:Msg"
  %l62 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l71 = alloca i32
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l80 = alloca %"compiler/diagmsg:Msg"
  %l81 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t6 = load i32, ptr %l8, !tbaa !23
  %t8 = icmp eq i32 %t6, %t5
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l16
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t20 = load i1, ptr %l16, !tbaa !21
  store i1 %t20, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l22
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  %t32 = load i1, ptr %l22, !tbaa !21
  %t33 = xor i1 %t32, true
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l17, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t37, ptr %l25
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l26, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = load i32, ptr %l29, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t44, i32 %t45)
  store { i64, ptr } %t46, ptr %l30
  br label %bb13
bb13:
  %t47 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l31, !tbaa !27
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemptyArray(ptr %v0, ptr %s1, ptr %t54, i32 %t55)
  store { i64, ptr } %t58, ptr %l34
  br label %bb14
bb14:
  %t59 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullToArray(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t66, { i64, ptr } %t65)
  store %"compiler/diagmsg:Msg" %t68, ptr %l36
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l24, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l25
  %t71 = load %"compiler/diagmsg:Msg", ptr %l36
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t69, %"compiler/source:Span" %t70, %"compiler/diagmsg:Msg" %t71)
  store i64 %t72, ptr %l37
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t76 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t73)
  store i32 %t76, ptr %l40
  br label %bb18
bb18:
  %t77 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t78 = load i32, ptr %l40, !tbaa !23
  %t80 = icmp eq i32 %t78, %t77
  br i1 %t80, label %bb19, label %bb20
bb19:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l3, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l46
  br label %bb21
bb20:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb22
bb21:
  %t87 = load i1, ptr %l46, !tbaa !21
  store i1 %t87, ptr %l43, !tbaa !21
  br label %bb22
bb22:
  %t88 = load i1, ptr %l43, !tbaa !21
  br i1 %t88, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l47, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t90, ptr %l48
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l3, !tbaa !23
  %t95 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t91, i32 %t92)
  store { i64, ptr } %t95, ptr %l51
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t96 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  %t98 = extractvalue { i64, ptr } %t96, 1
  %t99 = mul i64 %t97, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t99)
  call void @llvm.memcpy.p0.p0.i64(ptr %t100, ptr %t98, i64 %t99, i1 false)
  %t101 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l52, !tbaa !27
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l53, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l3, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l58
  br label %bb26
bb26:
  %t114 = load ptr, ptr %l53, !tbaa !29
  %t115 = load i32, ptr %l58, !tbaa !23
  %t116 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t114, i32 %t115)
  store { i64, ptr } %t116, ptr %l59
  br label %bb27
bb27:
  %t117 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  %t119 = extractvalue { i64, ptr } %t117, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  %t124 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t126 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullToNonNull(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t124, { i64, ptr } %t123)
  store %"compiler/diagmsg:Msg" %t126, ptr %l61
  br label %bb28
bb28:
  %t127 = load ptr, ptr %l47, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l48
  %t129 = load %"compiler/diagmsg:Msg", ptr %l61
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t127, %"compiler/source:Span" %t128, %"compiler/diagmsg:Msg" %t129)
  store i64 %t130, ptr %l62
  br label %bb29
bb29:
  %t131 = load i64, ptr %l62, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %t132, i64 %t131)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l65, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t137, ptr %l66
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l67, !tbaa !29
  %t139 = load i32, ptr %l2, !tbaa !23
  %t140 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t143 = icmp ne i32 %t139, %t140
  br i1 %t143, label %bb32, label %bb33
bb32:
  %t145 = load i32, ptr %l2, !tbaa !23
  store i32 %t145, ptr %l71, !tbaa !23
  br label %bb34
bb33:
  %t147 = load i32, ptr %l3, !tbaa !23
  store i32 %t147, ptr %l71, !tbaa !23
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l67, !tbaa !29
  %t150 = load i32, ptr %l71, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t149, i32 %t150)
  store { i64, ptr } %t151, ptr %l74
  br label %bb35
bb35:
  %t152 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l75, !tbaa !27
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l4, !tbaa !29
  %t163 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %s0, ptr %t159, ptr %t160)
  store { i64, ptr } %t163, ptr %l78
  br label %bb36
bb36:
  %t164 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  %t171 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t173 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchValueTypes(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t171, { i64, ptr } %t170)
  store %"compiler/diagmsg:Msg" %t173, ptr %l80
  br label %bb37
bb37:
  %t174 = load ptr, ptr %l65, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l66
  %t176 = load %"compiler/diagmsg:Msg", ptr %l80
  %t177 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t174, %"compiler/source:Span" %t175, %"compiler/diagmsg:Msg" %t176)
  store i64 %t177, ptr %l81
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ememberHint(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca i1
  %l13 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i32
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"compiler/msgs:Nearest"
  %l26 = alloca i32
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca i32
  %l43 = alloca i64
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i64
  %l55 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca i1
  %l66 = alloca i64
  %l68 = alloca ptr
  %l72 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l79 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i64
  %l104 = alloca ptr
  %l109 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l110 = alloca ptr
  %l112 = alloca ptr
  %l113 = alloca i32
  %l115 = alloca i1
  %l124 = alloca { i64, ptr }
  %l128 = alloca i1
  %l131 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l134 = alloca i1
  %l135 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %wh8 = alloca ptr
  %wc8 = alloca ptr
  %ws8 = alloca i32
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %a2)
  store { i64, ptr } %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t7 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t6)
  store %"compiler/msgs:Nearest" %t7, ptr %l22
  br label %bb2
bb2:
  %t8 = load %"compiler/msgs:Nearest", ptr %l22
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t8, ptr %t9
  store ptr %t9, ptr %l4, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t11, i32 %a1)
  store i32 %t15, ptr %l26
  br label %bb3
bb3:
  %t16 = load i32, ptr %l26, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodNames(ptr %v0, ptr %s1, ptr %t20)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l29
  br label %bb4
bb4:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  %t24 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %t24
  store ptr %t24, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load i64, ptr %l7, !tbaa !24
  store i64 %t26, ptr %l31, !tbaa !24
  %t27 = load ptr, ptr %l6, !tbaa !29
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s1, ptr %t27)
  store i64 %t29, ptr %l33
  br label %bb6
bb6:
  %t30 = load i64, ptr %l31, !tbaa !24
  %t31 = load i64, ptr %l33, !tbaa !24
  %t32 = icmp slt i64 %t30, %t31
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s1, ptr %t36, i64 %t37)
  store i32 %t40, ptr %l38
  br label %bb10
bb10:
  %t41 = load i32, ptr %l38, !tbaa !23
  store i32 %t41, ptr %l8, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i32, ptr %l5, !tbaa !23
  %t47 = load i32, ptr %l8, !tbaa !23
  %t51 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t45, i32 %t46, i32 %t47)
  store i64 %t51, ptr %l43
  br label %bb11
bb11:
  %t52 = load i64, ptr %l43, !tbaa !24
  store i64 %t52, ptr %l9, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t55 = icmp slt i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i32, ptr %l5, !tbaa !23
  %t62 = load i32, ptr %l8, !tbaa !23
  %t66 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s3, ptr %t60, i32 %t61, i32 %t62)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %l50
  br label %bb14
bb13:
  br label %bb20
bb14:
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l10
  %t69 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %l10)
  store i64 %t69, ptr %l52
  br label %bb15
bb15:
  %t70 = load i64, ptr %l52, !tbaa !24
  %t71 = icmp ne i64 %t70, 1
  br i1 %t71, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb17:
  br label %bb18
bb18:
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %l10, i64 0)
  store i64 %t74, ptr %l55
  br label %bb19
bb19:
  %t75 = load i64, ptr %l55, !tbaa !24
  store i64 %t75, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l8, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t76, i32 %t77)
  store { i64, ptr } %t80, ptr %l58
  br label %bb21
bb21:
  %t81 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t81, ptr %l59, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 0
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t85)
  store i1 %t87, ptr %l61
  br label %bb22
bb22:
  %t88 = load i1, ptr %l61, !tbaa !21
  br i1 %t88, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb27
bb24:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t92, i64 %t93)
  store i64 %t96, ptr %l66
  br label %bb25
bb25:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t97)
  store ptr %t99, ptr %l68
  br label %bb26
bb26:
  %t100 = load ptr, ptr %l68, !tbaa !29
  %t102 = getelementptr %"compiler/check:frame", ptr %t100, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = load i64, ptr %l66, !tbaa !24
  %t106 = icmp eq i64 %t104, %t103
  store i1 %t106, ptr %l62, !tbaa !21
  br label %bb27
bb27:
  %t108 = load i1, ptr %l62, !tbaa !21
  br i1 %t108, label %bb28, label %bb29
bb28:
  %t109 = load ptr, ptr %l4, !tbaa !29
  store ptr %t109, ptr %l72, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i32, ptr %l8, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t110, i32 %t111)
  store { i64, ptr } %t114, ptr %l75
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t115 = load ptr, ptr %l72, !tbaa !29
  %t116 = load { i64, ptr }, ptr %l75, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t115, { i64, ptr } %t116)
  br label %bb31
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  %t117 = load i64, ptr %l7, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l7, !tbaa !24
  br label %bb5
bb34:
  call void @__olang_scope_close(ptr %s1)
  br i1 %a3, label %bb35, label %bb36
bb35:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l5, !tbaa !23
  %t127 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t123, i32 %t124)
  store i1 %t127, ptr %l82
  br label %bb37
bb36:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb38
bb37:
  %t128 = load i1, ptr %l82, !tbaa !21
  store i1 %t128, ptr %l79, !tbaa !21
  br label %bb38
bb38:
  %t129 = load i1, ptr %l79, !tbaa !21
  br i1 %t129, label %bb39, label %bb40
bb39:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l84, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l5, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t136, i32 %t137)
  store i32 %t140, ptr %l89
  br label %bb41
bb40:
  store ptr null, ptr %l83, !tbaa !29
  br label %bb43
bb41:
  %t141 = load ptr, ptr %l84, !tbaa !29
  %t142 = load i32, ptr %l89, !tbaa !23
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructBody(ptr %v0, ptr %s0, ptr %t141, i32 %t142)
  store ptr %t143, ptr %l90
  br label %bb42
bb42:
  %t144 = load ptr, ptr %l90, !tbaa !29
  store ptr %t144, ptr %l83, !tbaa !29
  br label %bb43
bb43:
  %t145 = load ptr, ptr %l83, !tbaa !29
  store ptr %t145, ptr %l11, !tbaa !29
  %t146 = load ptr, ptr %l11, !tbaa !29
  %t148 = icmp eq ptr %t146, null
  br i1 %t148, label %bb44, label %bb45
bb44:
  %t150 = load ptr, ptr %l4, !tbaa !29
  %t152 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s0, ptr %v1, ptr %t150)
  store { i64, ptr } %t152, ptr %l94
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t153 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t153, ptr %rv
  br label %ret
bb47:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  store ptr %t157, ptr %l96, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l5, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t167, ptr %l101
  br label %bb48
bb48:
  %t168 = load ptr, ptr %l96, !tbaa !29
  %t169 = load i32, ptr %l101, !tbaa !23
  %t170 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t168, i32 %t169)
  store i64 %t170, ptr %l102
  br label %bb49
bb49:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t171)
  store ptr %t173, ptr %l104
  br label %bb50
bb50:
  %t174 = load ptr, ptr %l104, !tbaa !29
  %t176 = getelementptr %"compiler/check:frame", ptr %t174, i32 0, i32 1
  %t177 = load i64, ptr %t176, !tbaa !24
  %t178 = load i64, ptr %l102, !tbaa !24
  %t180 = icmp eq i64 %t178, %t177
  store i1 %t180, ptr %l12, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s8
  %t182 = load ptr, ptr %l11, !tbaa !29
  %t184 = call %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %s0, ptr %s8, ptr %t182)
  %t185 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t184, 0, 1
  %t186 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t184, 0, 0
  store ptr %t185, ptr %wh8
  store ptr %t186, ptr %wc8
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t184, ptr %l109
  br label %bb51
bb51:
  %t187 = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %l109
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t187, ptr %l13
  br label %bb52
bb52:
  %t189 = call { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %s8, ptr %l13)
  %t190 = extractvalue { i32, ptr } %t189, 1
  %t191 = extractvalue { i32, ptr } %t189, 0
  store i32 %t191, ptr %l113
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb54, label %ok.193, !prof !99
ok.193:
  store ptr %t190, ptr %l112
  br label %bb53
bb53:
  %t194 = load ptr, ptr %l112, !tbaa !29
  store ptr %t194, ptr %l110, !tbaa !29
  br label %bb56
bb54:
  %t195 = load i32, ptr %l113, !tbaa !23
  %t196 = ashr i32 %t195, 16
  %t198 = icmp eq i32 %t196, 1
  store i1 %t198, ptr %l115, !tbaa !21
  br label %bb55
bb55:
  br label %bb74
bb56:
  %t199 = load ptr, ptr %l110, !tbaa !29
  %t202 = getelementptr %"compiler/ast:VarDecl", ptr %t199, i32 0, i32 0
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  store { i64, ptr } %t203, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  store i64 %t207, ptr %l17, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s11
  %t209 = load i64, ptr %l16, !tbaa !24
  %t210 = load i64, ptr %l17, !tbaa !24
  %t213 = icmp slt i64 %t209, %t210
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb59:
  br label %bb60
bb60:
  %t217 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t217, ptr %l124, !tbaa !27
  %t218 = load i64, ptr %l16, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr i32, ptr %t221, i64 %t218
  %t223 = load i32, ptr %t222, !tbaa !33
  store i32 %t223, ptr %l18, !tbaa !23
  %t225 = load i1, ptr %l12, !tbaa !21
  br i1 %t225, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l128, !tbaa !21
  br label %bb65
bb62:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i32, ptr %l18, !tbaa !23
  %t231 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s11, ptr %t227, i32 %t228)
  store { i64, ptr } %t231, ptr %l131
  br label %bb63
bb63:
  %t232 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t232, ptr %l132, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i8, ptr %t234, i64 0
  %t236 = load i8, ptr %t235, !tbaa !32
  %t238 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t236)
  store i1 %t238, ptr %l134
  br label %bb64
bb64:
  %t239 = load i1, ptr %l134, !tbaa !21
  store i1 %t239, ptr %l128, !tbaa !21
  br label %bb65
bb65:
  %t240 = load i1, ptr %l128, !tbaa !21
  br i1 %t240, label %bb66, label %bb67
bb66:
  %t241 = load ptr, ptr %l4, !tbaa !29
  store ptr %t241, ptr %l135, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i32, ptr %l18, !tbaa !23
  %t246 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t242, i32 %t243)
  store { i64, ptr } %t246, ptr %l138
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t247 = load ptr, ptr %l135, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l138, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t247, { i64, ptr } %t248)
  br label %bb69
bb69:
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s11)
  br label %bb71
bb71:
  %t249 = load i64, ptr %l16, !tbaa !24
  %t251 = add i64 %t249, 1
  store i64 %t251, ptr %l16, !tbaa !24
  br label %bb57
bb72:
  br label %bb73
bb73:
  br label %bb52
bb74:
  store i32 0, ptr %ws8
  br label %wend8
wend8.c0:
  call void @__olang_scope_close(ptr %s8)
  %t253 = load ptr, ptr %l4, !tbaa !29
  %t255 = call { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %s0, ptr %v1, ptr %t253)
  store { i64, ptr } %t255, ptr %l142
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s0)
  %t256 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t256, ptr %rv
  br label %ret
wend8:
  %t257 = load ptr, ptr %wh8
  %t258 = load ptr, ptr %wc8
  %t259 = call ptr @llvm.coro.promise(ptr %t257, i32 8, i1 false)
  %t260 = getelementptr { { i32, ptr }, i32 }, ptr %t259, i32 0, i32 1
  store i32 2, ptr %t260
  %t261 = call { i32, ptr } %t258(ptr %t257, ptr null)
  %t262 = load i32, ptr %ws8
  switch i32 %t262, label %wend8.c0 [ ]
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l52 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l11
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l14
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_cabdf486839d2fe5_195cd685fa5544d9)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t46 = icmp slt i64 %t40, %t43
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t48, ptr %l29, !tbaa !27
  %t49 = load i64, ptr %l5, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i8, ptr %t52, i64 %t49
  %t54 = load i8, ptr %t53, !tbaa !32
  %t56 = icmp eq i8 %t54, 32
  br i1 %t56, label %bb9, label %bb10
bb8:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb12
bb9:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb11
bb10:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l34, !tbaa !27
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 41
  store i1 %t66, ptr %l33, !tbaa !21
  br label %bb11
bb11:
  %t68 = load i1, ptr %l33, !tbaa !21
  store i1 %t68, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t69 = load i1, ptr %l28, !tbaa !21
  %t70 = xor i1 %t69, true
  br i1 %t70, label %bb13, label %bb14
bb13:
  br label %bb17
bb14:
  br label %bb15
bb15:
  %t72 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  br label %bb6
bb17:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t82 = icmp sge i64 %t76, %t79
  br i1 %t82, label %bb18, label %bb19
bb18:
  %t84 = load %"compiler/source:Span", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t84, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = trunc i64 %t86 to i32
  %t89 = load i64, ptr %l5, !tbaa !24
  %t93 = add i64 %t89, %a2
  %t95 = trunc i64 %t93 to i32
  %t98 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t88, i32 %t95)
  store %"compiler/source:Span" %t98, ptr %l52
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t99 = load %"compiler/source:Span", ptr %l52
  store %"compiler/source:Span" %t99, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandParam(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l11 = alloca i32
  %l14 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l30 = alloca i32
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca i32
  %l54 = alloca { i64, ptr }
  %l56 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t10, i64 %t11)
  store i32 %t14, ptr %l11
  br label %bb4
bb4:
  %t15 = load i32, ptr %l11, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb5
bb5:
  %t32 = load ptr, ptr %l14, !tbaa !29
  %t33 = load i32, ptr %l19, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l20
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t42 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t40)
  store i64 %t42, ptr %l24
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t43, i64 %t44)
  store i64 %t45, ptr %l25
  br label %bb8
bb8:
  %t46 = load i64, ptr %l25, !tbaa !24
  %t47 = icmp sgt i64 %t46, 0
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t55 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %t49, i64 %t50, i32 %a2)
  store i32 %t55, ptr %l30
  br label %bb11
bb10:
  br label %bb21
bb11:
  %t56 = load i32, ptr %l30, !tbaa !23
  store i32 %t56, ptr %l3, !tbaa !23
  %t57 = load i32, ptr %l3, !tbaa !23
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t61 = icmp eq i32 %t57, %t58
  br i1 %t61, label %bb12, label %bb13
bb12:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t63, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  store ptr %t70, ptr %l37, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l3, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l42
  br label %bb15
bb15:
  %t81 = load ptr, ptr %l37, !tbaa !29
  %t82 = load i32, ptr %l42, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t81, i32 %t82)
  store { i64, ptr } %t83, ptr %l43
  br label %bb16
bb16:
  %t84 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t84, ptr %l4, !tbaa !27
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 1
  %t95 = load i32, ptr %t94, !tbaa !33
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t90, i32 %t95)
  store i32 %t98, ptr %l49
  br label %bb17
bb17:
  %t99 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t101 = trunc i64 25 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb18, label %bb19
bb18:
  %t104 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t104, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t107, ptr %l54, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 1
  %t111 = load i32, ptr %t110, !tbaa !33
  %t114 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t106, i32 %t111)
  store i32 %t114, ptr %l56
  br label %bb22
bb22:
  %t115 = load i32, ptr %l56, !tbaa !23
  store i32 %t115, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i32
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i64
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca i1
  %l66 = alloca i64
  %l68 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %t4, { i64, ptr } %a1, { i64, ptr } %a2)
  store i32 %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load i32, ptr %l16, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load i32, ptr %l4, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l22, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l4, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l27
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i32, ptr %l27, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s0, ptr %t34, i32 %t35)
  store { i64, ptr } %t36, ptr %l28
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  br i1 %t46, label %bb7, label %bb8
bb7:
  %t48 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb12
bb9:
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = sub i64 %t52, %t53
  %t57 = load i64, ptr %l8, !tbaa !24
  %t60 = add i64 %t56, %t57
  %t62 = sub i64 %t60, 1
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = sdiv i64 %t62, %t63
  store i64 %t66, ptr %l37, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l37, !tbaa !24
  store i64 %t68, ptr %l34, !tbaa !24
  br label %bb12
bb12:
  %t69 = load i64, ptr %l34, !tbaa !24
  store i64 %t69, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t70 = load i64, ptr %l10, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = icmp slt i64 %t70, %t71
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb14, label %bb15
bb14:
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = mul i64 %t79, %t80
  %t86 = add i64 %t78, %t83
  store i64 %t86, ptr %l11, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t89, ptr %l56, !tbaa !27
  %t90 = load i64, ptr %l11, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  %t98 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t88, i32 %t95)
  store { i64, ptr } %t98, ptr %l59
  br label %bb17
bb17:
  %t100 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v3, { i64, ptr } %t100, { i64, ptr } %a3)
  store i1 %t102, ptr %l61
  br label %bb18
bb18:
  %t103 = load i1, ptr %l61, !tbaa !21
  br i1 %t103, label %bb19, label %bb20
bb19:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l4, !tbaa !23
  %t111 = load i64, ptr %l11, !tbaa !24
  store i64 %t111, ptr %l66, !tbaa !24
  %t112 = load i64, ptr %l66, !tbaa !24
  %t113 = load i64, ptr %l66, !tbaa !24
  %t114 = shl i64 1, %t113
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t109, i32 %t110, i64 %t114)
  store i32 %t118, ptr %l68
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t119 = load i32, ptr %l68, !tbaa !23
  store i32 %t119, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l10, !tbaa !24
  br label %bb13
bb24:
  %t124 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t124, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushErrNarrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l14 = alloca i32
  %l19 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i32
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca i32
  %l49 = alloca %"compiler/check:errNarrow"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 16
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v1, ptr %t9, ptr %t10)
  store i32 %t13, ptr %l14
  br label %bb5
bb5:
  %t14 = load i32, ptr %l14, !tbaa !23
  store i32 %t14, ptr %l4, !tbaa !23
  %t15 = load i32, ptr %l4, !tbaa !23
  %t17 = icmp eq i32 %t15, 0
  br i1 %t17, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l4, !tbaa !23
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t19, i32 %t20)
  store i64 %t23, ptr %l19
  br label %bb9
bb9:
  %t24 = load i64, ptr %l19, !tbaa !24
  store i64 %t24, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load i32, ptr %l4, !tbaa !23
  store i32 %t30, ptr %l23, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  store ptr %t36, ptr %l26, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t37, i64 %t38)
  store i32 %t41, ptr %l29
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l26, !tbaa !29
  %t43 = load i32, ptr %l29, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t44, ptr %l30
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load i32, ptr %l23, !tbaa !23
  %t47 = load i32, ptr %l30, !tbaa !23
  %t48 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNow(ptr %v0, ptr %s0, ptr %t45, i32 %t46, i32 %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l31
  br label %bb15
bb15:
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l6
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = load i32, ptr %l4, !tbaa !23
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNarrow(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t50, ptr %t51, i1 %a2, i32 %t53, ptr %l6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l37
  br label %bb16
bb16:
  %t61 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %l39
  br label %bb17
bb17:
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %l7
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l41
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l41, !tbaa !29
  %t68 = getelementptr %"compiler/check:frame", ptr %t66, i32 0, i32 59
  store ptr %t68, ptr %l43, !tbaa !29
  %t69 = load i32, ptr %l4, !tbaa !23
  store i32 %t69, ptr %l44, !tbaa !23
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t73 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %s0, ptr %t70, ptr %l7)
  store i32 %t73, ptr %l47
  br label %bb19
bb19:
  %t75 = load i32, ptr %l44, !tbaa !23
  %t76 = load i32, ptr %l47, !tbaa !23
  %t78 = call %"compiler/check:errNarrow" @compiler_2fcheck_3aerrNarrow_2ector(ptr %s0, i32 %t75, i32 %t76, i64 %a3, i1 false)
  store %"compiler/check:errNarrow" %t78, ptr %l49
  br label %bb20
bb20:
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = load %"compiler/check:errNarrow", ptr %l49
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2ePush_H97bb9732c658fc3569a453b270fe50d0(ptr %v0, ptr %t79, %"compiler/check:errNarrow" %t80)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:litv"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i32
  %l13 = alloca i64
  %l15 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l36 = alloca i1
  %l41 = alloca i1
  %l50 = alloca i1
  %l52 = alloca i64
  %l61 = alloca i64
  %l67 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t12, i32 %t13)
  store i64 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i64, ptr %l13, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 6
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t21, 64
  store i1 %t23, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l15, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 6
  %t27 = load i1, ptr %t26, !tbaa !21
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb8, label %bb9
bb7:
  br label %bb19
bb8:
  %t31 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t32 = load i1, ptr %t31, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb9:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l27
  br label %bb12
bb11:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb13
bb12:
  %t44 = load i1, ptr %l27, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l22, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l20, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 2
  %t57 = load %"compiler/check:litv", ptr %l1
  %t58 = load i32, ptr %l3, !tbaa !23
  %t62 = call i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %t56, %"compiler/check:litv" %t57, i32 %t58)
  store i1 %t62, ptr %l36
  br label %bb17
bb16:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t63 = load i1, ptr %l36, !tbaa !21
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t64 = load i1, ptr %l30, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  %t71 = load i32, ptr %l3, !tbaa !23
  %t74 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t70, i32 %t71)
  store i1 %t74, ptr %l41
  br label %bb20
bb20:
  %t75 = load i1, ptr %l41, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t77 = load i1, ptr %t76, !tbaa !21
  br i1 %t77, label %bb23, label %bb24
bb22:
  br label %bb32
bb23:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t81 = icmp eq i64 %t79, 64
  store i1 %t81, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t83 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t89 = load i64, ptr %l4, !tbaa !24
  %t91 = icmp eq i64 %t89, 64
  br i1 %t91, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb31
bb30:
  %t93 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = load i64, ptr %l4, !tbaa !24
  store i64 %t95, ptr %l52, !tbaa !24
  %t96 = load i64, ptr %l52, !tbaa !24
  %t97 = load i64, ptr %l52, !tbaa !24
  %t98 = shl i64 1, %t97
  %t101 = icmp slt i64 %t94, %t98
  store i1 %t101, ptr %l50, !tbaa !21
  br label %bb31
bb31:
  %t103 = load i1, ptr %l50, !tbaa !21
  store i1 %t103, ptr %rv
  br label %ret
bb32:
  %t104 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t105 = load i1, ptr %t104, !tbaa !21
  br i1 %t105, label %bb33, label %bb34
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t108 = load i64, ptr %l4, !tbaa !24
  %t110 = icmp eq i64 %t108, 64
  br i1 %t110, label %bb36, label %bb37
bb36:
  store i1 true, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t113 = load i64, ptr %l4, !tbaa !24
  %t115 = sub i64 %t113, 1
  store i64 %t115, ptr %l61, !tbaa !24
  %t116 = load i64, ptr %l61, !tbaa !24
  %t117 = load i64, ptr %l61, !tbaa !24
  %t118 = shl i64 1, %t117
  store i64 %t118, ptr %l5, !tbaa !24
  %t120 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t121 = load i64, ptr %t120, !tbaa !24
  %t122 = load i64, ptr %l5, !tbaa !24
  %t124 = sub i64 0, %t122
  %t127 = icmp sge i64 %t121, %t124
  br i1 %t127, label %bb39, label %bb40
bb39:
  %t129 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load i64, ptr %l5, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  store i1 %t134, ptr %l67, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb41
bb41:
  %t136 = load i1, ptr %l67, !tbaa !21
  store i1 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l11 = alloca i32
  %l13 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %rv = alloca ptr
  %t38 = alloca { i64, [2 x i64] }, align 8
  %t46 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/check:rawTable", ptr %t1, i32 0, i32 1
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t6, ptr %l6
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t13)
  store i32 %t15, ptr %l11
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t16 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load i32, ptr %l11, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t17, i32 %t18, i64 %t16)
  store i32 %t20, ptr %l13
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t21)
  store ptr %t23, ptr %l15
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t26 = getelementptr %"compiler/check:frame", ptr %t24, i32 0, i32 2
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/check:rawTable", ptr %t28, i32 0, i32 3
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l19, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %t35, i64 %t32
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !37
  store { i64, [2 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 0
  store i64 1, ptr %t39
  %t41 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t37, 0
  %t42 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  store { { i64, ptr } } %t41, ptr %t42
  %t43 = load { i64, [2 x i64] }, ptr %t38
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t43, ptr %t45
  store { i64, [5 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 0
  store i64 1, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l6
  %t49 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t48, 0
  %t50 = load i32, ptr %l13, !tbaa !23
  %t51 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t49, i32 %t50, 1
  %t53 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t51, i64 %t27, 2
  %t55 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t53, ptr %t45, 3
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t55, ptr %t56
  %t57 = load { i64, [5 x i64] }, ptr %t46
  %t59 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t57, ptr %t59
  store ptr %t59, ptr %rv
  br label %ret
bb6:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l1
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr %"compiler/check:rawTable", ptr %t63, i32 0, i32 0
  %t66 = load i32, ptr %t65, !tbaa !23
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t69 = getelementptr %"compiler/check:rawTable", ptr %t67, i32 0, i32 2
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l31, !tbaa !27
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i64, ptr %t74, i64 %t71
  %t76 = load i64, ptr %t75, !tbaa !34
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t61, %"compiler/source:Span" %t62, i32 %t66, i64 %t76)
  store ptr %t81, ptr %l34
  br label %bb7
bb7:
  %t82 = load ptr, ptr %l34, !tbaa !29
  store ptr %t82, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i32
  %rv = alloca ptr
  %t15 = alloca { i64, [4 x i64] }, align 8
  %t27 = alloca { i64, [5 x i64] }, align 8
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load %"compiler/source:Span", ptr %l1
  %t8 = load i32, ptr %l3, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l1
  %t10 = load i32, ptr %l3, !tbaa !23
  %t11 = load i64, ptr %l2, !tbaa !24
  %t13 = trunc i64 %t11 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 0
  store i64 0, ptr %t16
  %t18 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t9, 0
  %t20 = insertvalue { %"compiler/source:Span", i32, i32 } %t18, i32 %t10, 1
  %t22 = insertvalue { %"compiler/source:Span", i32, i32 } %t20, i32 %t13, 2
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t22, ptr %t23
  %t24 = load { i64, [4 x i64] }, ptr %t15
  %t26 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t24, ptr %t26
  store { i64, [5 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 0
  store i64 2, ptr %t28
  %t30 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t7, 0
  %t32 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t30, i32 %t8, 1
  %t34 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t32, ptr %t26, 2
  %t35 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t34, i32 -1, 3
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t35, ptr %t36
  %t37 = load { i64, [5 x i64] }, ptr %t27
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t37, ptr %t39
  store ptr %t39, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l8 = alloca i32
  %l14 = alloca i1
  %l19 = alloca i32
  %l22 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i1
  %l44 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !range !{i32 0, i32 33}
  %t14 = trunc i64 18 to i32
  %t15 = icmp eq i32 %t11, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l14
  br label %bb4
bb3:
  br label %bb14
bb4:
  %t25 = load i1, ptr %l14, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l19
  br label %bb8
bb8:
  %t34 = load i32, ptr %l19, !range !{i32 0, i32 6}
  %t37 = trunc i64 4 to i32
  %t38 = icmp eq i32 %t34, %t37
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l27
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t51 = load ptr, ptr %l22, !tbaa !29
  %t52 = load i32, ptr %l27, !tbaa !23
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t53, ptr %l28
  br label %bb12
bb12:
  %t54 = load i1, ptr %l28, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t61, i32 %t62)
  store i1 %t65, ptr %l34
  br label %bb15
bb15:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb18
bb17:
  %t67 = load i32, ptr %l1, !tbaa !23
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t71 = icmp eq i32 %t67, %t68
  store i1 %t71, ptr %l35, !tbaa !21
  br label %bb18
bb18:
  %t73 = load i1, ptr %l35, !tbaa !21
  br i1 %t73, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb22
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l1, !tbaa !23
  %t83 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l44
  br label %bb21
bb21:
  %t84 = load i1, ptr %l44, !tbaa !21
  store i1 %t84, ptr %l39, !tbaa !21
  br label %bb22
bb22:
  %t85 = load i1, ptr %l39, !tbaa !21
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca i1
  %l12 = alloca i1
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i1
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t13, i64 %t12)
  store i1 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t24 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t21)
  store i32 %t24, ptr %l16
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l16, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t27, ptr %l17
  br label %bb9
bb9:
  %t28 = load i1, ptr %l17, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l12, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  br label %ret
bb12:
  br label %bb13
bb13:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 83
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t35)
  store ptr %t37, ptr %l22
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t45 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, ptr %v0, i64 %t41, ptr %t42)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t45, ptr %l26
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v0, ptr %t46, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t47)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetAtTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %l21 = alloca i32
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i32
  %l37 = alloca i1
  %l40 = alloca i32
  %l49 = alloca i64
  %l52 = alloca i1
  %l55 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i64
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca %"compiler/source:Span"
  %l74 = alloca i32
  %l80 = alloca %"compiler/check:setAt"
  %l82 = alloca %"compiler/check:setAt"
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t24, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb38
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i32 %t32, ptr %l21
  br label %bb6
bb6:
  %t33 = load i32, ptr %l21, !tbaa !23
  %t34 = icmp sge i32 %t33, 0
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %t37, ptr %t38)
  store ptr %t41, ptr %l26
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l26, !tbaa !29
  store ptr %t42, ptr %l5, !tbaa !29
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s1)
  store ptr null, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l30, !tbaa !29
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t51 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v2, ptr %t49)
  store i32 %t51, ptr %l32
  br label %bb14
bb14:
  %t52 = load ptr, ptr %l30, !tbaa !29
  %t53 = load i32, ptr %l32, !tbaa !23
  %t54 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t54, ptr %l33
  br label %bb15
bb15:
  %t55 = load i32, ptr %l33, !tbaa !23
  store i32 %t55, ptr %l6, !tbaa !23
  %t56 = load i32, ptr %l6, !tbaa !23
  %t57 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t60 = icmp eq i32 %t56, %t57
  br i1 %t60, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb19
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l6, !tbaa !23
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l40
  br label %bb18
bb18:
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t68 = load i32, ptr %l40, !tbaa !23
  %t70 = icmp ne i32 %t68, %t67
  store i1 %t70, ptr %l37, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l37, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s1)
  store ptr null, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l6, !tbaa !23
  %t76 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = add i64 %t78, 1
  %t84 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s1, ptr %t74, i32 %t75, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d8, i32 0, i32 1) }, i64 %t80)
  store i64 %t84, ptr %l49
  br label %bb23
bb23:
  %t85 = load i64, ptr %l49, !tbaa !24
  store i64 %t85, ptr %l7, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  %t88 = icmp slt i64 %t86, 0
  br i1 %t88, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb27
bb25:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t94 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v2, ptr %t90, ptr %t91)
  store i64 %t94, ptr %l55
  br label %bb26
bb26:
  %t95 = load i64, ptr %l55, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  store i1 %t96, ptr %l52, !tbaa !21
  br label %bb27
bb27:
  %t98 = load i1, ptr %l52, !tbaa !21
  br i1 %t98, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s1)
  store ptr null, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l58, !tbaa !29
  %t101 = load i64, ptr %l7, !tbaa !24
  store i64 %t101, ptr %l59, !tbaa !24
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t104 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v2, ptr %t102)
  store i32 %t104, ptr %l61
  br label %bb31
bb31:
  %t105 = load ptr, ptr %l58, !tbaa !29
  %t106 = load i64, ptr %l59, !tbaa !24
  %t107 = load i32, ptr %l61, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamsOn(ptr %v0, ptr %s1, ptr %t105, i64 %t106, i32 %t107)
  store { i64, ptr } %t108, ptr %l62
  br label %bb32
bb32:
  %t109 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t109, ptr %l8, !tbaa !27
  %t110 = load ptr, ptr %l5, !tbaa !29
  store ptr %t110, ptr %l63, !tbaa !29
  %t111 = load i64, ptr %l7, !tbaa !24
  store i64 %t111, ptr %l64, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t112, ptr %l65, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t113, ptr %l66, !tbaa !27
  %t114 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t114, ptr %l67
  %t115 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t119 = add i64 %t117, 1
  %t120 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t125 = icmp slt i64 %t119, %t122
  br i1 %t125, label %bb33, label %bb34
bb33:
  %t127 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t131 = add i64 %t129, 1
  %t133 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr i32, ptr %t134, i64 %t131
  %t136 = load i32, ptr %t135, !tbaa !33
  store i32 %t136, ptr %l74, !tbaa !23
  br label %bb35
bb34:
  %t138 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t138, ptr %l74, !tbaa !23
  br label %bb35
bb35:
  %t140 = load ptr, ptr %l63, !tbaa !29
  %t141 = load i64, ptr %l64, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t144 = load %"compiler/source:Span", ptr %l67
  %t145 = load i32, ptr %l74, !tbaa !23
  %t146 = call %"compiler/check:setAt" @compiler_2fcheck_3asetAt_2ector(ptr %v2, ptr %v1, ptr %v2, ptr %t140, i64 %t141, { i64, ptr } %t142, { i64, ptr } %t143, %"compiler/source:Span" %t144, i32 %t145)
  store %"compiler/check:setAt" %t146, ptr %l80
  br label %bb36
bb36:
  %t148 = call %"compiler/check:setAt" @olang_2eHelperKind_2eCopy_2ecompiler_2fcheck_3asetAt(ptr %v2, ptr %l80)
  store %"compiler/check:setAt" %t148, ptr %l82
  br label %bb37
bb37:
  %t149 = load %"compiler/check:setAt", ptr %l82
  %t150 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 64, i64 8)
  store %"compiler/check:setAt" %t149, ptr %t150
  call void @__olang_scope_close(ptr %s1)
  store ptr %t150, ptr %rv
  br label %ret
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store ptr null, ptr %rv
  br label %ret
bb42:
  call void @__olang_check_failed(ptr @olang_loc_9413809856381141_f41a02fc0683f50d)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleIdle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/check:idleCall"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/check:idleCall"
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l36 = alloca i64
  %l38 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca %"compiler/check:idleCall"
  %l55 = alloca ptr
  %l57 = alloca i64
  %l60 = alloca ptr
  %l64 = alloca i1
  %l67 = alloca i64
  %l69 = alloca i64
  %l74 = alloca i64
  %l79 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i64
  %l84 = alloca i64
  %l92 = alloca ptr
  %l94 = alloca i64
  %l95 = alloca i64
  %l97 = alloca i64
  %l102 = alloca i64
  %l105 = alloca i1
  %l106 = alloca i64
  %l109 = alloca i64
  %l111 = alloca i1
  %l115 = alloca ptr
  %l123 = alloca ptr
  %l127 = alloca ptr
  %l130 = alloca i1
  %l135 = alloca i64
  %l137 = alloca i64
  %l142 = alloca i64
  %l143 = alloca ptr
  %l146 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l149 = alloca i1
  %l151 = alloca ptr
  %l152 = alloca i64
  %l154 = alloca i64
  %l165 = alloca i64
  %l167 = alloca i64
  %l172 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l175 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca i64
  %l180 = alloca i64
  %l181 = alloca i32
  %l182 = alloca i1
  %l189 = alloca i64
  %l191 = alloca i64
  %l197 = alloca %"compiler/check:idleCall"
  %l200 = alloca i1
  %l201 = alloca i1
  %l204 = alloca i1
  %l205 = alloca i64
  %l208 = alloca i64
  %l212 = alloca i64
  %l216 = alloca i64
  %l220 = alloca i64
  %l223 = alloca i64
  %l241 = alloca ptr
  %l242 = alloca i64
  %l243 = alloca ptr
  %l246 = alloca i64
  %l247 = alloca i64
  %l248 = alloca i32
  %l249 = alloca i1
  %l257 = alloca ptr
  %l263 = alloca { i64, [3 x i64] }
  %l265 = alloca %"compiler/diagmsg:Msg"
  %l266 = alloca i64
  %s0 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %t432 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 104
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eLen_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l36
  br label %bb1
bb1:
  %t6 = load i64, ptr %l36, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l38
  br label %bb5
bb5:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l38
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %l1
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l39
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l2
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l40
  br label %bb7
bb7:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l3
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l41
  br label %bb8
bb8:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l4
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l42
  br label %bb9
bb9:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l5
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l43
  br label %bb10
bb10:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l6
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l44
  br label %bb11
bb11:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l7
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 104
  store ptr %t25, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t27 = load i64, ptr %l9, !tbaa !24
  store i64 %t27, ptr %l47, !tbaa !24
  %t28 = load ptr, ptr %l8, !tbaa !29
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eLen_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l49
  br label %bb13
bb13:
  %t31 = load i64, ptr %l47, !tbaa !24
  %t32 = load i64, ptr %l49, !tbaa !24
  %t33 = icmp slt i64 %t31, %t32
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb14, label %bb15
bb14:
  br label %bb41
bb15:
  br label %bb16
bb16:
  %t37 = load ptr, ptr %l8, !tbaa !29
  %t38 = load i64, ptr %l9, !tbaa !24
  %t41 = call %"compiler/check:idleCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eAt_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %v0, ptr %t37, i64 %t38)
  store %"compiler/check:idleCall" %t41, ptr %l54
  br label %bb17
bb17:
  %t42 = load %"compiler/check:idleCall", ptr %l54
  store %"compiler/check:idleCall" %t42, ptr %l10
  store ptr %l6, ptr %l55, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t44, ptr %l57
  br label %bb18
bb18:
  %t45 = load ptr, ptr %l55, !tbaa !29
  %t46 = load i64, ptr %l57, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t45, i64 %t46)
  br label %bb19
bb19:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 105
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t49)
  br label %bb20
bb20:
  store ptr %l5, ptr %l60, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:idleCall", ptr %l10, i32 0, i32 4
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v0, ptr %t51, ptr %t53)
  store i1 %t57, ptr %l64
  br label %bb21
bb21:
  %t58 = load ptr, ptr %l60, !tbaa !29
  %t59 = load i1, ptr %l64, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %t58, i1 %t59)
  br label %bb22
bb22:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 105
  store ptr %t62, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb23
bb23:
  %t64 = load i64, ptr %l12, !tbaa !24
  store i64 %t64, ptr %l67, !tbaa !24
  %t65 = load ptr, ptr %l11, !tbaa !29
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t65)
  store i64 %t67, ptr %l69
  br label %bb24
bb24:
  %t68 = load i64, ptr %l67, !tbaa !24
  %t69 = load i64, ptr %l69, !tbaa !24
  %t70 = icmp slt i64 %t68, %t69
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb25, label %bb26
bb25:
  br label %bb39
bb26:
  br label %bb27
bb27:
  %t74 = load ptr, ptr %l11, !tbaa !29
  %t75 = load i64, ptr %l12, !tbaa !24
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t74, i64 %t75)
  store i64 %t78, ptr %l74
  br label %bb28
bb28:
  %t79 = load i64, ptr %l74, !tbaa !24
  store i64 %t79, ptr %l13, !tbaa !24
  %t80 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l7, i64 %t80)
  br label %bb29
bb29:
  %t83 = load i64, ptr %l13, !tbaa !24
  %t86 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l1, i64 %t83)
  store i1 %t86, ptr %l79
  br label %bb30
bb30:
  %t87 = load i1, ptr %l79, !tbaa !21
  %t88 = xor i1 %t87, true
  br i1 %t88, label %bb31, label %bb32
bb31:
  store ptr %l1, ptr %l81, !tbaa !29
  %t90 = load i64, ptr %l13, !tbaa !24
  store i64 %t90, ptr %l82, !tbaa !24
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t92, ptr %l84
  br label %bb33
bb32:
  br label %bb37
bb33:
  %t93 = load ptr, ptr %l81, !tbaa !29
  %t94 = load i64, ptr %l82, !tbaa !24
  %t95 = load i64, ptr %l84, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t93, i64 %t94, i64 %t95)
  br label %bb34
bb34:
  %t96 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t96)
  br label %bb35
bb35:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %l3, i1 false)
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t100 = load i64, ptr %l12, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l12, !tbaa !24
  br label %bb23
bb39:
  br label %bb40
bb40:
  %t104 = load i64, ptr %l9, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l9, !tbaa !24
  br label %bb12
bb41:
  store ptr %l6, ptr %l92, !tbaa !29
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l7)
  store i64 %t109, ptr %l94
  br label %bb42
bb42:
  %t110 = load ptr, ptr %l92, !tbaa !29
  %t111 = load i64, ptr %l94, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t110, i64 %t111)
  br label %bb43
bb43:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb44
bb44:
  %t112 = load i64, ptr %l14, !tbaa !24
  store i64 %t112, ptr %l95, !tbaa !24
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t114, ptr %l97
  br label %bb45
bb45:
  %t115 = load i64, ptr %l95, !tbaa !24
  %t116 = load i64, ptr %l97, !tbaa !24
  %t117 = icmp slt i64 %t115, %t116
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb46, label %bb47
bb46:
  br label %bb88
bb47:
  br label %bb48
bb48:
  %t121 = load i64, ptr %l14, !tbaa !24
  %t124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l2, i64 %t121)
  store i64 %t124, ptr %l102
  br label %bb49
bb49:
  %t125 = load i64, ptr %l102, !tbaa !24
  store i64 %t125, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l15, !tbaa !24
  %t128 = icmp slt i64 %t126, 0
  br i1 %t128, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb53
bb51:
  %t130 = load i64, ptr %l15, !tbaa !24
  store i64 %t130, ptr %l106, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 14
  %t135 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t133)
  store i64 %t135, ptr %l109
  br label %bb52
bb52:
  %t136 = load i64, ptr %l106, !tbaa !24
  %t137 = load i64, ptr %l109, !tbaa !24
  %t138 = icmp sge i64 %t136, %t137
  store i1 %t138, ptr %l105, !tbaa !21
  br label %bb53
bb53:
  %t140 = load i1, ptr %l105, !tbaa !21
  br i1 %t140, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb57
bb55:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 14
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t143, i64 %t144)
  store ptr %t147, ptr %l115
  br label %bb56
bb56:
  %t148 = load ptr, ptr %l115, !tbaa !29
  %t150 = getelementptr %"compiler/typed:Body", ptr %t148, i32 0, i32 11
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  store i1 %t153, ptr %l111, !tbaa !21
  br label %bb57
bb57:
  %t155 = load i1, ptr %l111, !tbaa !21
  br i1 %t155, label %bb58, label %bb59
bb58:
  %t156 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %s0, ptr %l3, i64 %t156, i1 true)
  br label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb87
bb61:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 105
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t161)
  br label %bb62
bb62:
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l123, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 14
  %t167 = load i64, ptr %l15, !tbaa !24
  %t170 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t166, i64 %t167)
  store ptr %t170, ptr %l127
  br label %bb63
bb63:
  %t171 = load ptr, ptr %l127, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Body", ptr %t171, i32 0, i32 11
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t175 = load ptr, ptr %l123, !tbaa !29
  %t177 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v0, ptr %t175, ptr %t174)
  store i1 %t177, ptr %l130
  br label %bb64
bb64:
  %t178 = load i1, ptr %l130, !tbaa !21
  br i1 %t178, label %bb65, label %bb66
bb65:
  %t179 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %s0, ptr %l3, i64 %t179, i1 true)
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb87
bb68:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 105
  store ptr %t184, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s14
  %t186 = load i64, ptr %l17, !tbaa !24
  store i64 %t186, ptr %l135, !tbaa !24
  %t187 = load ptr, ptr %l16, !tbaa !29
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t187)
  store i64 %t189, ptr %l137
  br label %bb70
bb70:
  %t190 = load i64, ptr %l135, !tbaa !24
  %t191 = load i64, ptr %l137, !tbaa !24
  %t192 = icmp slt i64 %t190, %t191
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s14)
  br label %bb86
bb72:
  br label %bb73
bb73:
  %t196 = load ptr, ptr %l16, !tbaa !29
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t196, i64 %t197)
  store i64 %t200, ptr %l142
  br label %bb74
bb74:
  %t201 = load i64, ptr %l142, !tbaa !24
  store i64 %t201, ptr %l18, !tbaa !24
  store ptr %l4, ptr %l143, !tbaa !29
  %t202 = load i64, ptr %l14, !tbaa !24
  %t203 = load i64, ptr %l18, !tbaa !24
  %t206 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s14, i64 %t202, i64 %t203)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t206, ptr %l146
  br label %bb75
bb75:
  %t207 = load ptr, ptr %l143, !tbaa !29
  %t208 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l146
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %s0, ptr %t207, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t208)
  br label %bb76
bb76:
  %t209 = load i64, ptr %l18, !tbaa !24
  %t212 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l1, i64 %t209)
  store i1 %t212, ptr %l149
  br label %bb77
bb77:
  %t213 = load i1, ptr %l149, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb78, label %bb79
bb78:
  store ptr %l1, ptr %l151, !tbaa !29
  %t216 = load i64, ptr %l18, !tbaa !24
  store i64 %t216, ptr %l152, !tbaa !24
  %t218 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l2)
  store i64 %t218, ptr %l154
  br label %bb80
bb79:
  br label %bb84
bb80:
  %t219 = load ptr, ptr %l151, !tbaa !29
  %t220 = load i64, ptr %l152, !tbaa !24
  %t221 = load i64, ptr %l154, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t219, i64 %t220, i64 %t221)
  br label %bb81
bb81:
  %t222 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l2, i64 %t222)
  br label %bb82
bb82:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %s0, ptr %l3, i1 false)
  br label %bb83
bb83:
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s14)
  br label %bb85
bb85:
  %t226 = load i64, ptr %l17, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l17, !tbaa !24
  br label %bb69
bb86:
  br label %bb87
bb87:
  %t230 = load i64, ptr %l14, !tbaa !24
  %t232 = add i64 %t230, 1
  store i64 %t232, ptr %l14, !tbaa !24
  br label %bb44
bb88:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb89
bb89:
  %t234 = load i1, ptr %l19, !tbaa !21
  %t236 = xor i1 %t234, true
  br i1 %t236, label %bb90, label %bb91
bb90:
  br label %bb115
bb91:
  br label %bb92
bb92:
  store i1 false, ptr %l19, !tbaa !21
  store ptr %l4, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb93
bb93:
  %t239 = load i64, ptr %l21, !tbaa !24
  store i64 %t239, ptr %l165, !tbaa !24
  %t240 = load ptr, ptr %l20, !tbaa !29
  %t242 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %s0, ptr %t240)
  store i64 %t242, ptr %l167
  br label %bb94
bb94:
  %t243 = load i64, ptr %l165, !tbaa !24
  %t244 = load i64, ptr %l167, !tbaa !24
  %t245 = icmp slt i64 %t243, %t244
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb95, label %bb96
bb95:
  br label %bb113
bb96:
  br label %bb97
bb97:
  %t249 = load ptr, ptr %l20, !tbaa !29
  %t250 = load i64, ptr %l21, !tbaa !24
  %t253 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %s0, ptr %t249, i64 %t250)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t253, ptr %l172
  br label %bb98
bb98:
  %t254 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l172
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t254, ptr %l22
  %t255 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l22, i32 0, i32 0
  %t256 = load i64, ptr %t255, !tbaa !24
  %t259 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %l3, i64 %t256)
  store i1 %t259, ptr %l175
  br label %bb99
bb99:
  %t260 = load i1, ptr %l175, !tbaa !21
  br i1 %t260, label %bb100, label %bb101
bb100:
  br label %bb112
bb101:
  br label %bb102
bb102:
  store ptr %l3, ptr %l176, !tbaa !29
  %t261 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l22, i32 0, i32 1
  %t262 = load i64, ptr %t261, !tbaa !24
  %t265 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %l1, i64 %t262)
  %t266 = extractvalue { i32, i64 } %t265, 1
  %t267 = extractvalue { i32, i64 } %t265, 0
  store i32 %t267, ptr %l181
  %t268 = icmp ne i32 %t267, 0
  br i1 %t268, label %bb104, label %ok.269, !prof !99
ok.269:
  store i64 %t266, ptr %l180
  br label %bb103
bb103:
  %t270 = load i64, ptr %l180, !tbaa !24
  store i64 %t270, ptr %l177, !tbaa !24
  br label %bb106
bb104:
  br label %bb105
bb105:
  store i64 0, ptr %l177, !tbaa !24
  br label %bb106
bb106:
  %t271 = load ptr, ptr %l176, !tbaa !29
  %t272 = load i64, ptr %l177, !tbaa !24
  %t273 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t271, i64 %t272)
  store i1 %t273, ptr %l182
  br label %bb107
bb107:
  %t274 = load i1, ptr %l182, !tbaa !21
  br i1 %t274, label %bb108, label %bb109
bb108:
  %t275 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l22, i32 0, i32 0
  %t276 = load i64, ptr %t275, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %s0, ptr %l3, i64 %t276, i1 true)
  br label %bb110
bb109:
  br label %bb111
bb110:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb111
bb111:
  br label %bb112
bb112:
  %t279 = load i64, ptr %l21, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l21, !tbaa !24
  br label %bb93
bb113:
  br label %bb114
bb114:
  br label %bb89
bb115:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/check:Checker", ptr %t283, i32 0, i32 104
  store ptr %t285, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb116
bb116:
  store %olang.scope zeroinitializer, ptr %s25
  %t287 = load i64, ptr %l24, !tbaa !24
  store i64 %t287, ptr %l189, !tbaa !24
  %t288 = load ptr, ptr %l23, !tbaa !29
  %t290 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eLen_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %t288)
  store i64 %t290, ptr %l191
  br label %bb117
bb117:
  %t291 = load i64, ptr %l189, !tbaa !24
  %t292 = load i64, ptr %l191, !tbaa !24
  %t293 = icmp slt i64 %t291, %t292
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb118, label %bb119
bb118:
  call void @__olang_scope_close(ptr %s25)
  br label %bb162
bb119:
  br label %bb120
bb120:
  %t297 = load i64, ptr %l24, !tbaa !24
  store i64 %t297, ptr %l25, !tbaa !24
  %t299 = load ptr, ptr %l23, !tbaa !29
  %t300 = load i64, ptr %l24, !tbaa !24
  %t303 = call %"compiler/check:idleCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eAt_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %v0, ptr %t299, i64 %t300)
  store %"compiler/check:idleCall" %t303, ptr %l197
  br label %bb121
bb121:
  %t304 = load %"compiler/check:idleCall", ptr %l197
  store %"compiler/check:idleCall" %t304, ptr %l26
  %t305 = load i64, ptr %l25, !tbaa !24
  %t308 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %l5, i64 %t305)
  store i1 %t308, ptr %l200
  br label %bb122
bb122:
  %t309 = load i1, ptr %l200, !tbaa !21
  br i1 %t309, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb125
bb124:
  %t310 = getelementptr %"compiler/check:idleCall", ptr %l26, i32 0, i32 0
  %t311 = load i64, ptr %t310, !tbaa !24
  %t313 = icmp slt i64 %t311, 0
  store i1 %t313, ptr %l201, !tbaa !21
  br label %bb125
bb125:
  %t315 = load i1, ptr %l201, !tbaa !21
  br i1 %t315, label %bb126, label %bb127
bb126:
  store i1 true, ptr %l204, !tbaa !21
  br label %bb129
bb127:
  %t316 = getelementptr %"compiler/check:idleCall", ptr %l26, i32 0, i32 0
  %t317 = load i64, ptr %t316, !tbaa !24
  store i64 %t317, ptr %l205, !tbaa !24
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/check:Checker", ptr %t318, i32 0, i32 14
  %t322 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t320)
  store i64 %t322, ptr %l208
  br label %bb128
bb128:
  %t323 = load i64, ptr %l205, !tbaa !24
  %t324 = load i64, ptr %l208, !tbaa !24
  %t325 = icmp sge i64 %t323, %t324
  store i1 %t325, ptr %l204, !tbaa !21
  br label %bb129
bb129:
  %t327 = load i1, ptr %l204, !tbaa !21
  br i1 %t327, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s25)
  br label %bb161
bb131:
  br label %bb132
bb132:
  store i1 true, ptr %l27, !tbaa !21
  %t328 = load i64, ptr %l25, !tbaa !24
  %t331 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t328)
  store i64 %t331, ptr %l212
  br label %bb133
bb133:
  %t332 = load i64, ptr %l212, !tbaa !24
  store i64 %t332, ptr %l28, !tbaa !24
  %t333 = load i64, ptr %l25, !tbaa !24
  %t335 = add i64 %t333, 1
  %t338 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t335)
  store i64 %t338, ptr %l216
  br label %bb134
bb134:
  %t339 = load i64, ptr %l216, !tbaa !24
  store i64 %t339, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t340 = load i64, ptr %l29, !tbaa !24
  %t341 = load i64, ptr %l28, !tbaa !24
  %t344 = icmp sgt i64 %t340, %t341
  br i1 %t344, label %bb135, label %bb136
bb135:
  %t346 = load i64, ptr %l30, !tbaa !24
  %t348 = icmp sgt i64 %t346, 0
  br i1 %t348, label %bb137, label %bb138
bb136:
  store i64 0, ptr %l220, !tbaa !24
  br label %bb140
bb137:
  %t350 = load i64, ptr %l29, !tbaa !24
  %t351 = load i64, ptr %l28, !tbaa !24
  %t354 = sub i64 %t350, %t351
  %t355 = load i64, ptr %l30, !tbaa !24
  %t358 = add i64 %t354, %t355
  %t360 = sub i64 %t358, 1
  %t361 = load i64, ptr %l30, !tbaa !24
  %t364 = sdiv i64 %t360, %t361
  store i64 %t364, ptr %l223, !tbaa !24
  br label %bb139
bb138:
  store i64 0, ptr %l223, !tbaa !24
  br label %bb139
bb139:
  %t366 = load i64, ptr %l223, !tbaa !24
  store i64 %t366, ptr %l220, !tbaa !24
  br label %bb140
bb140:
  %t367 = load i64, ptr %l220, !tbaa !24
  store i64 %t367, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb141
bb141:
  %t368 = load i64, ptr %l32, !tbaa !24
  %t369 = load i64, ptr %l31, !tbaa !24
  %t372 = icmp slt i64 %t368, %t369
  %t374 = xor i1 %t372, true
  br i1 %t374, label %bb142, label %bb143
bb142:
  br label %bb155
bb143:
  br label %bb144
bb144:
  %t376 = load i64, ptr %l28, !tbaa !24
  %t377 = load i64, ptr %l32, !tbaa !24
  %t378 = load i64, ptr %l30, !tbaa !24
  %t381 = mul i64 %t377, %t378
  %t384 = add i64 %t376, %t381
  store ptr %l3, ptr %l241, !tbaa !29
  store ptr %l1, ptr %l243, !tbaa !29
  %t389 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l7, i64 %t384)
  store i64 %t389, ptr %l246
  br label %bb145
bb145:
  %t390 = load ptr, ptr %l243, !tbaa !29
  %t391 = load i64, ptr %l246, !tbaa !24
  %t392 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t390, i64 %t391)
  %t393 = extractvalue { i32, i64 } %t392, 1
  %t394 = extractvalue { i32, i64 } %t392, 0
  store i32 %t394, ptr %l248
  %t395 = icmp ne i32 %t394, 0
  br i1 %t395, label %bb147, label %ok.396, !prof !99
ok.396:
  store i64 %t393, ptr %l247
  br label %bb146
bb146:
  %t397 = load i64, ptr %l247, !tbaa !24
  store i64 %t397, ptr %l242, !tbaa !24
  br label %bb149
bb147:
  br label %bb148
bb148:
  store i64 0, ptr %l242, !tbaa !24
  br label %bb149
bb149:
  %t398 = load ptr, ptr %l241, !tbaa !29
  %t399 = load i64, ptr %l242, !tbaa !24
  %t400 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %t398, i64 %t399)
  store i1 %t400, ptr %l249
  br label %bb150
bb150:
  %t401 = load i1, ptr %l249, !tbaa !21
  br i1 %t401, label %bb151, label %bb152
bb151:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb153
bb152:
  br label %bb153
bb153:
  br label %bb154
bb154:
  %t402 = load i64, ptr %l32, !tbaa !24
  %t404 = add i64 %t402, 1
  store i64 %t404, ptr %l32, !tbaa !24
  br label %bb141
bb155:
  %t406 = load i1, ptr %l27, !tbaa !21
  %t408 = xor i1 %t406, true
  br i1 %t408, label %bb156, label %bb157
bb156:
  call void @__olang_scope_close(ptr %s25)
  br label %bb161
bb157:
  br label %bb158
bb158:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/check:Checker", ptr %t410, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t415 = getelementptr %"compiler/generic:Program", ptr %t413, i32 0, i32 0
  %t416 = load ptr, ptr %t415, !tbaa !29
  %t418 = getelementptr %"compiler/load:Loader", ptr %t416, i32 0, i32 4
  %t419 = load ptr, ptr %t418, !tbaa !29
  store ptr %t419, ptr %l257, !tbaa !29
  %t420 = getelementptr %"compiler/check:idleCall", ptr %l26, i32 0, i32 1
  %t421 = load i64, ptr %t420, !tbaa !24
  %t422 = getelementptr %"compiler/check:idleCall", ptr %l26, i32 0, i32 2
  %t423 = getelementptr %"compiler/source:Span", ptr %t422, i32 0, i32 0
  %t424 = load i32, ptr %t423, !tbaa !23
  %t426 = sext i32 %t424 to i64
  %t427 = getelementptr %"compiler/check:idleCall", ptr %l26, i32 0, i32 2
  %t428 = getelementptr %"compiler/source:Span", ptr %t427, i32 0, i32 1
  %t429 = load i32, ptr %t428, !tbaa !23
  %t431 = sext i32 %t429 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t432
  %t433 = getelementptr { i64, [3 x i64] }, ptr %t432, i32 0, i32 0
  store i64 3, ptr %t433
  %t435 = insertvalue { i64, i64, i64 } undef, i64 %t421, 0
  %t437 = insertvalue { i64, i64, i64 } %t435, i64 %t426, 1
  %t439 = insertvalue { i64, i64, i64 } %t437, i64 %t431, 2
  %t440 = getelementptr { i64, [3 x i64] }, ptr %t432, i32 0, i32 1
  store { i64, i64, i64 } %t439, ptr %t440
  %t441 = load { i64, [3 x i64] }, ptr %t432
  store { i64, [3 x i64] } %t441, ptr %l263
  %t442 = getelementptr %"compiler/check:idleCall", ptr %l26, i32 0, i32 3
  %t443 = load { i64, ptr }, ptr %t442, !tbaa !27
  %t445 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCallDoesNothing(ptr %v0, ptr %s25, { i64, ptr } %t443)
  store %"compiler/diagmsg:Msg" %t445, ptr %l265
  br label %bb159
bb159:
  %t446 = load ptr, ptr %l257, !tbaa !29
  %t447 = load { i64, [3 x i64] }, ptr %l263
  %t448 = load %"compiler/diagmsg:Msg", ptr %l265
  %t449 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s25, ptr %t446, { i64, [3 x i64] } %t447, %"compiler/diagmsg:Msg" %t448)
  store i64 %t449, ptr %l266
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s25)
  br label %bb161
bb161:
  %t450 = load i64, ptr %l24, !tbaa !24
  %t452 = add i64 %t450, 1
  store i64 %t452, ptr %l24, !tbaa !24
  br label %bb116
bb162:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etailSets(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/check:tailAsk"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca %"compiler/types:DtorWalk"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/typed:Local"
  %l24 = alloca i64
  %l26 = alloca i64
  %l31 = alloca %"compiler/check:tailAsk"
  %l34 = alloca i32
  %l37 = alloca i32
  %l41 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l48 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l72 = alloca i64
  %l75 = alloca i64
  %l96 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l102 = alloca i1
  %l109 = alloca %"compiler/source:Span"
  %l112 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l116 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l122 = alloca %"compiler/diagmsg:Msg"
  %l123 = alloca i64
  %l127 = alloca ptr
  %l131 = alloca %"compiler/types:DtorWalk"
  %l134 = alloca i64
  %l136 = alloca i64
  %l141 = alloca %"compiler/typed:Local"
  %l146 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca %"compiler/source:Span"
  %l151 = alloca { i64, ptr }
  %l154 = alloca %"compiler/diagmsg:Msg"
  %l155 = alloca i64
  %l159 = alloca ptr
  %l160 = alloca i64
  %l163 = alloca { i64, [3 x i64] }
  %l164 = alloca %"compiler/diagmsg:Msg"
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 100
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l24, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atailAsk_3e_2eLen_3ccompiler_2fcheck_3atailAsk_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l26
  br label %bb2
bb2:
  %t9 = load i64, ptr %l24, !tbaa !24
  %t10 = load i64, ptr %l26, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb66
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/check:tailAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atailAsk_3e_2eAt_3ccompiler_2fcheck_3atailAsk_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/check:tailAsk" %t19, ptr %l31
  br label %bb6
bb6:
  %t20 = load %"compiler/check:tailAsk", ptr %l31
  store %"compiler/check:tailAsk" %t20, ptr %l3
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:tailAsk", ptr %l3, i32 0, i32 0
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t21, i64 %t23)
  store i32 %t26, ptr %l34
  br label %bb7
bb7:
  %t27 = load i32, ptr %l34, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:tailAsk", ptr %l3, i32 0, i32 1
  %t30 = load i64, ptr %t29, !tbaa !24
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t28, i64 %t30)
  store i32 %t33, ptr %l37
  br label %bb8
bb8:
  %t34 = load i32, ptr %l37, !tbaa !23
  store i32 %t34, ptr %l5, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:tailAsk", ptr %l3, i32 0, i32 3
  %t37 = load i64, ptr %t36, !tbaa !24
  %t38 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t35, i64 -1, i64 %t37, i32 %t38, i32 0)
  store ptr %t42, ptr %l41
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t43)
  store ptr %t45, ptr %l43
  br label %bb10
bb10:
  %t46 = load ptr, ptr %l43, !tbaa !29
  store ptr %t46, ptr %l44, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 14
  %t50 = getelementptr %"compiler/check:tailAsk", ptr %l3, i32 0, i32 0
  %t51 = load i64, ptr %t50, !tbaa !24
  %t54 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t49, i64 %t51)
  store ptr %t54, ptr %l48
  br label %bb11
bb11:
  %t55 = load ptr, ptr %l48, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Body", ptr %t55, i32 0, i32 3
  %t58 = load i64, ptr %t57, !tbaa !24
  %t60 = load ptr, ptr %l44, !tbaa !29
  %t61 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 2
  store i64 %t58, ptr %t61, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t67, i32 %t68)
  store { i64, ptr } %t71, ptr %l55
  br label %bb12
bb12:
  %t72 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t72, ptr %l6, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l5, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t78, i32 %t79)
  store { i64, ptr } %t82, ptr %l60
  br label %bb13
bb13:
  %t83 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t83, ptr %l7, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t92 = icmp eq i64 %t86, %t89
  store i1 %t92, ptr %l8, !tbaa !21
  %t94 = load i1, ptr %l8, !tbaa !21
  br i1 %t94, label %bb14, label %bb15
bb14:
  store i64 0, ptr %l9, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l10, !tbaa !24
  %t101 = load i64, ptr %l9, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb16, label %bb17
bb15:
  br label %bb32
bb16:
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb21
bb18:
  %t110 = load i64, ptr %l10, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l11, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l11, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l75, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb20
bb20:
  %t126 = load i64, ptr %l75, !tbaa !24
  store i64 %t126, ptr %l72, !tbaa !24
  br label %bb21
bb21:
  %t127 = load i64, ptr %l72, !tbaa !24
  store i64 %t127, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb22
bb22:
  %t128 = load i64, ptr %l13, !tbaa !24
  %t129 = load i64, ptr %l12, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  br label %bb25
bb25:
  %t136 = load i64, ptr %l9, !tbaa !24
  %t137 = load i64, ptr %l13, !tbaa !24
  %t138 = load i64, ptr %l11, !tbaa !24
  %t141 = mul i64 %t137, %t138
  %t144 = add i64 %t136, %t141
  store i64 %t144, ptr %l14, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  %t152 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t152, ptr %l96, !tbaa !27
  %t153 = load i64, ptr %l14, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i32, ptr %t156, i64 %t153
  %t158 = load i32, ptr %t157, !tbaa !33
  %t159 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t159, ptr %l99, !tbaa !27
  %t160 = load i64, ptr %l14, !tbaa !24
  %t162 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i32, ptr %t163, i64 %t160
  %t165 = load i32, ptr %t164, !tbaa !33
  %t169 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t151, i32 %t158, i32 %t165)
  store i1 %t169, ptr %l102
  br label %bb26
bb26:
  %t170 = load i1, ptr %l102, !tbaa !21
  %t171 = xor i1 %t170, true
  br i1 %t171, label %bb27, label %bb28
bb27:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb29
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t173 = load i64, ptr %l13, !tbaa !24
  %t175 = add i64 %t173, 1
  store i64 %t175, ptr %l13, !tbaa !24
  br label %bb22
bb31:
  br label %bb32
bb32:
  %t177 = getelementptr %"compiler/check:tailAsk", ptr %l3, i32 0, i32 2
  %t178 = getelementptr %"compiler/source:Span", ptr %t177, i32 0, i32 0
  %t179 = load i32, ptr %t178, !tbaa !23
  %t180 = getelementptr %"compiler/check:tailAsk", ptr %l3, i32 0, i32 2
  %t181 = getelementptr %"compiler/source:Span", ptr %t180, i32 0, i32 0
  %t182 = load i32, ptr %t181, !tbaa !23
  %t184 = add i32 %t182, 6
  %t187 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t179, i32 %t184)
  store %"compiler/source:Span" %t187, ptr %l109
  br label %bb33
bb33:
  %t188 = load %"compiler/source:Span", ptr %l109
  store %"compiler/source:Span" %t188, ptr %l15
  %t189 = load i1, ptr %l8, !tbaa !21
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l112, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t194, ptr %l113
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l4, !tbaa !23
  %t199 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsText(ptr %v0, ptr %s8, ptr %t195, i32 %t196)
  store { i64, ptr } %t199, ptr %l116
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t200 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  store { i64, ptr } %t206, ptr %l117, !tbaa !27
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l5, !tbaa !23
  %t211 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsText(ptr %v0, ptr %s8, ptr %t207, i32 %t208)
  store { i64, ptr } %t211, ptr %l120
  br label %bb37
bb37:
  %t212 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  %t214 = extractvalue { i64, ptr } %t212, 1
  %t215 = mul i64 %t213, 1
  %t216 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t215)
  call void @llvm.memcpy.p0.p0.i64(ptr %t216, ptr %t214, i64 %t215, i1 false)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  %t219 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t221 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBecomeErrors(ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t219, { i64, ptr } %t218)
  store %"compiler/diagmsg:Msg" %t221, ptr %l122
  br label %bb38
bb38:
  %t222 = load ptr, ptr %l112, !tbaa !29
  %t223 = load %"compiler/source:Span", ptr %l113
  %t224 = load %"compiler/diagmsg:Msg", ptr %l122
  %t225 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t222, %"compiler/source:Span" %t223, %"compiler/diagmsg:Msg" %t224)
  store i64 %t225, ptr %l123
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb40:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/check:Checker", ptr %t226, i32 0, i32 14
  %t229 = getelementptr %"compiler/check:tailAsk", ptr %l3, i32 0, i32 0
  %t230 = load i64, ptr %t229, !tbaa !24
  %t233 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t228, i64 %t230)
  store ptr %t233, ptr %l127
  br label %bb41
bb41:
  %t234 = load ptr, ptr %l127, !tbaa !29
  store ptr %t234, ptr %l16, !tbaa !29
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = getelementptr %"compiler/generic:Program", ptr %t238, i32 0, i32 2
  %t242 = call %"compiler/types:DtorWalk" @compiler_2ftypes_3aDtorWalk_2ector(ptr %v0, ptr %s2, ptr %t240)
  store %"compiler/types:DtorWalk" %t242, ptr %l131
  br label %bb42
bb42:
  %t243 = load %"compiler/types:DtorWalk", ptr %l131
  store %"compiler/types:DtorWalk" %t243, ptr %l17
  %t244 = load ptr, ptr %l16, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Body", ptr %t244, i32 0, i32 7
  store ptr %t246, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb43
bb43:
  %t248 = load i64, ptr %l19, !tbaa !24
  store i64 %t248, ptr %l134, !tbaa !24
  %t249 = load ptr, ptr %l18, !tbaa !29
  %t251 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t249)
  store i64 %t251, ptr %l136
  br label %bb44
bb44:
  %t252 = load i64, ptr %l134, !tbaa !24
  %t253 = load i64, ptr %l136, !tbaa !24
  %t254 = icmp slt i64 %t252, %t253
  %t256 = xor i1 %t254, true
  br i1 %t256, label %bb45, label %bb46
bb45:
  br label %bb63
bb46:
  br label %bb47
bb47:
  %t258 = load ptr, ptr %l18, !tbaa !29
  %t259 = load i64, ptr %l19, !tbaa !24
  %t262 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t258, i64 %t259)
  store %"compiler/typed:Local" %t262, ptr %l141
  br label %bb48
bb48:
  %t263 = load %"compiler/typed:Local", ptr %l141
  store %"compiler/typed:Local" %t263, ptr %l20
  %t264 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 4
  %t265 = load i32, ptr %t264, !range !{i32 0, i32 7}
  %t267 = trunc i64 0 to i32
  %t268 = icmp eq i32 %t265, %t267
  br i1 %t268, label %bb49, label %bb50
bb49:
  br label %bb62
bb50:
  br label %bb51
bb51:
  %t270 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 2
  %t271 = load i32, ptr %t270, !tbaa !23
  %t274 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %s2, ptr %l17, i32 %t271)
  store i1 %t274, ptr %l146
  br label %bb52
bb52:
  %t275 = load i1, ptr %l146, !tbaa !21
  br i1 %t275, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s12
  %t276 = load ptr, ptr %l0, !tbaa !29
  store ptr %t276, ptr %l147, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t277, ptr %l148
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 2
  %t280 = load i32, ptr %t279, !tbaa !23
  %t283 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t278, i32 %t280)
  store { i64, ptr } %t283, ptr %l151
  br label %bb55
bb54:
  br label %bb61
bb55:
  %t284 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t285 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t286 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = add i64 %t285, %t288
  %t290 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t291 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t292 = add i64 %t289, %t291
  %t293 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t292)
  call void @olang_textcopy(ptr %t293, ptr %t284, i64 %t285)
  %t294 = getelementptr i8, ptr %t293, i64 %t285
  call void @olang_textcopy(ptr %t294, ptr %t287, i64 %t288)
  %t295 = getelementptr i8, ptr %t294, i64 %t288
  call void @olang_textcopy(ptr %t295, ptr %t290, i64 %t291)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t293, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = extractvalue { i64, ptr } %t297, 1
  %t301 = mul i64 %t299, 1
  %t302 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t302, ptr %t300, i64 %t301, i1 false)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  %t306 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBecomeDestructor(ptr %s12, ptr %s12, { i64, ptr } %t304)
  store %"compiler/diagmsg:Msg" %t306, ptr %l154
  br label %bb56
bb56:
  %t307 = load ptr, ptr %l147, !tbaa !29
  %t308 = load %"compiler/source:Span", ptr %l148
  %t309 = load %"compiler/diagmsg:Msg", ptr %l154
  %t310 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t307, %"compiler/source:Span" %t308, %"compiler/diagmsg:Msg" %t309)
  store i64 %t310, ptr %l155
  br label %bb57
bb57:
  %t311 = load i64, ptr %l155, !tbaa !24
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/check:Checker", ptr %t312, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 0
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t320 = getelementptr %"compiler/load:Loader", ptr %t318, i32 0, i32 4
  %t321 = load ptr, ptr %t320, !tbaa !29
  store ptr %t321, ptr %l159, !tbaa !29
  store i64 %t311, ptr %l160, !tbaa !24
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 1
  %t325 = load %"compiler/source:Span", ptr %t324
  %t328 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t323, %"compiler/source:Span" %t325)
  store { i64, [3 x i64] } %t328, ptr %l163
  br label %bb58
bb58:
  %t329 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteHere(ptr %s12)
  store %"compiler/diagmsg:Msg" %t329, ptr %l164
  br label %bb59
bb59:
  %t330 = load ptr, ptr %l159, !tbaa !29
  %t331 = load i64, ptr %l160, !tbaa !24
  %t332 = load { i64, [3 x i64] }, ptr %l163
  %t333 = load %"compiler/diagmsg:Msg", ptr %l164
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s12, ptr %t330, i64 %t331, { i64, [3 x i64] } %t332, %"compiler/diagmsg:Msg" %t333)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s12)
  br label %bb63
bb61:
  br label %bb62
bb62:
  %t334 = load i64, ptr %l19, !tbaa !24
  %t336 = add i64 %t334, 1
  store i64 %t336, ptr %l19, !tbaa !24
  br label %bb43
bb63:
  %t338 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t338)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s2)
  br label %bb65
bb65:
  %t340 = load i64, ptr %l2, !tbaa !24
  %t342 = add i64 %t340, 1
  store i64 %t342, ptr %l2, !tbaa !24
  br label %bb1
bb66:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNames(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i1
  %l24 = alloca i32
  %l29 = alloca ptr
  %l34 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i1
  %l46 = alloca i32
  %l53 = alloca i32
  %l56 = alloca i1
  %l61 = alloca i32
  %l66 = alloca i32
  %l71 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l92 = alloca i1
  %l98 = alloca ptr
  %l103 = alloca i32
  %l107 = alloca i1
  %l110 = alloca ptr
  %l115 = alloca i32
  %l119 = alloca i1
  %l124 = alloca ptr
  %l129 = alloca i32
  %l130 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l145 = alloca i1
  %l149 = alloca ptr
  %l154 = alloca i32
  %l158 = alloca i1
  %l161 = alloca ptr
  %l166 = alloca i32
  %l170 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l15, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l24
  br label %bb7
bb7:
  %t23 = load i32, ptr %l24, !range !{i32 0, i32 33}
  %t25 = trunc i64 25 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  store ptr %t33, ptr %l29, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l34
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l39
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = load i32, ptr %l34, !tbaa !23
  %t56 = load i32, ptr %l39, !tbaa !23
  %t57 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t54, i32 %t55, i32 %t56)
  store i1 %t57, ptr %l40
  br label %bb12
bb12:
  %t58 = load i1, ptr %l40, !tbaa !21
  br i1 %t58, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l46
  br label %bb17
bb17:
  %t70 = load i32, ptr %l46, !range !{i32 0, i32 33}
  store i32 %t70, ptr %l4
  %t71 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t73 = trunc i64 18 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb42
bb20:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l2, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l53
  br label %bb21
bb21:
  %t86 = load i32, ptr %l53, !range !{i32 0, i32 33}
  %t88 = trunc i64 18 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb22, label %bb23
bb22:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 2
  %t97 = load i32, ptr %l1, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t96, i32 %t97)
  store i32 %t100, ptr %l61
  br label %bb24
bb23:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb26
bb24:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %l2, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l66
  br label %bb25
bb25:
  %t111 = load i32, ptr %l61, !tbaa !23
  %t112 = load i32, ptr %l66, !tbaa !23
  %t113 = icmp eq i32 %t111, %t112
  store i1 %t113, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t115 = load i1, ptr %l56, !tbaa !21
  br i1 %t115, label %bb27, label %bb28
bb27:
  store i1 true, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  store ptr %t122, ptr %l71, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  %t129 = load i32, ptr %l1, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l76
  br label %bb30
bb30:
  %t133 = load ptr, ptr %l71, !tbaa !29
  %t134 = load i32, ptr %l76, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t133, i32 %t134)
  store { i64, ptr } %t135, ptr %l77
  br label %bb31
bb31:
  %t136 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t136, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l7, !tbaa !24
  br label %bb32
bb32:
  %t141 = load i64, ptr %l6, !tbaa !24
  %t142 = load i64, ptr %l7, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb33, label %bb34
bb33:
  br label %bb41
bb34:
  br label %bb35
bb35:
  %t149 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t149, ptr %l84, !tbaa !27
  %t150 = load i64, ptr %l6, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t150
  %t155 = load i32, ptr %t154, !tbaa !33
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l2, !tbaa !23
  %t160 = load i64, ptr %l3, !tbaa !24
  %t162 = add i64 %t160, 1
  %t167 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNames(ptr %v0, ptr %t157, i32 %t155, i32 %t159, i64 %t162)
  store i1 %t167, ptr %l92
  br label %bb36
bb36:
  %t168 = load i1, ptr %l92, !tbaa !21
  br i1 %t168, label %bb37, label %bb38
bb37:
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t170 = load i64, ptr %l6, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l6, !tbaa !24
  br label %bb32
bb41:
  br label %bb83
bb42:
  %t174 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t176 = trunc i64 20 to i32
  %t177 = icmp eq i32 %t174, %t176
  br i1 %t177, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l98, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 2
  %t186 = load i32, ptr %l1, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l103
  br label %bb46
bb46:
  %t190 = load i32, ptr %l2, !tbaa !23
  %t191 = load i64, ptr %l3, !tbaa !24
  %t193 = add i64 %t191, 1
  %t194 = load ptr, ptr %l98, !tbaa !29
  %t195 = load i32, ptr %l103, !tbaa !23
  %t198 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNames(ptr %v0, ptr %t194, i32 %t195, i32 %t190, i64 %t193)
  store i1 %t198, ptr %l107
  br label %bb47
bb47:
  %t199 = load i1, ptr %l107, !tbaa !21
  store i1 %t199, ptr %rv
  br label %ret
bb48:
  %t200 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t202 = trunc i64 19 to i32
  %t203 = icmp eq i32 %t200, %t202
  br i1 %t203, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l110, !tbaa !29
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Program", ptr %t209, i32 0, i32 2
  %t212 = load i32, ptr %l1, !tbaa !23
  %t215 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t211, i32 %t212)
  store i32 %t215, ptr %l115
  br label %bb52
bb52:
  %t216 = load i32, ptr %l2, !tbaa !23
  %t217 = load i64, ptr %l3, !tbaa !24
  %t219 = add i64 %t217, 1
  %t220 = load ptr, ptr %l110, !tbaa !29
  %t221 = load i32, ptr %l115, !tbaa !23
  %t224 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNames(ptr %v0, ptr %t220, i32 %t221, i32 %t216, i64 %t219)
  store i1 %t224, ptr %l119
  br label %bb53
bb53:
  %t225 = load i1, ptr %l119, !tbaa !21
  store i1 %t225, ptr %rv
  br label %ret
bb54:
  %t226 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t228 = trunc i64 21 to i32
  %t229 = icmp eq i32 %t226, %t228
  br i1 %t229, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb72
bb57:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/check:Checker", ptr %t231, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = getelementptr %"compiler/generic:Program", ptr %t234, i32 0, i32 2
  store ptr %t236, ptr %l124, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/check:Checker", ptr %t237, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = getelementptr %"compiler/generic:Program", ptr %t240, i32 0, i32 2
  %t243 = load i32, ptr %l1, !tbaa !23
  %t246 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t242, i32 %t243)
  store i32 %t246, ptr %l129
  br label %bb58
bb58:
  %t247 = load ptr, ptr %l124, !tbaa !29
  %t248 = load i32, ptr %l129, !tbaa !23
  %t249 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t247, i32 %t248)
  store { i64, ptr } %t249, ptr %l130
  br label %bb59
bb59:
  %t250 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t250, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t251 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t251, 0
  store i64 %t253, ptr %l11, !tbaa !24
  br label %bb60
bb60:
  %t255 = load i64, ptr %l10, !tbaa !24
  %t256 = load i64, ptr %l11, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb61, label %bb62
bb61:
  br label %bb69
bb62:
  br label %bb63
bb63:
  %t263 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t263, ptr %l137, !tbaa !27
  %t264 = load i64, ptr %l10, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i32, ptr %t267, i64 %t264
  %t269 = load i32, ptr %t268, !tbaa !33
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = load i32, ptr %l2, !tbaa !23
  %t274 = load i64, ptr %l3, !tbaa !24
  %t276 = add i64 %t274, 1
  %t281 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNames(ptr %v0, ptr %t271, i32 %t269, i32 %t273, i64 %t276)
  store i1 %t281, ptr %l145
  br label %bb64
bb64:
  %t282 = load i1, ptr %l145, !tbaa !21
  br i1 %t282, label %bb65, label %bb66
bb65:
  store i1 true, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t284 = load i64, ptr %l10, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l10, !tbaa !24
  br label %bb60
bb69:
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l149, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/check:Checker", ptr %t289, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = getelementptr %"compiler/generic:Program", ptr %t292, i32 0, i32 2
  %t295 = load i32, ptr %l1, !tbaa !23
  %t298 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t294, i32 %t295)
  store i32 %t298, ptr %l154
  br label %bb70
bb70:
  %t299 = load i32, ptr %l2, !tbaa !23
  %t300 = load i64, ptr %l3, !tbaa !24
  %t302 = add i64 %t300, 1
  %t303 = load ptr, ptr %l149, !tbaa !29
  %t304 = load i32, ptr %l154, !tbaa !23
  %t307 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNames(ptr %v0, ptr %t303, i32 %t304, i32 %t299, i64 %t302)
  store i1 %t307, ptr %l158
  br label %bb71
bb71:
  %t308 = load i1, ptr %l158, !tbaa !21
  store i1 %t308, ptr %rv
  br label %ret
bb72:
  %t309 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t311 = trunc i64 29 to i32
  %t312 = icmp eq i32 %t309, %t311
  br i1 %t312, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t314, ptr %l161, !tbaa !29
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Program", ptr %t318, i32 0, i32 2
  %t321 = load i32, ptr %l1, !tbaa !23
  %t324 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t320, i32 %t321)
  store i32 %t324, ptr %l166
  br label %bb76
bb76:
  %t325 = load i32, ptr %l2, !tbaa !23
  %t326 = load i64, ptr %l3, !tbaa !24
  %t328 = add i64 %t326, 1
  %t329 = load ptr, ptr %l161, !tbaa !29
  %t330 = load i32, ptr %l166, !tbaa !23
  %t333 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNames(ptr %v0, ptr %t329, i32 %t330, i32 %t325, i64 %t328)
  store i1 %t333, ptr %l170
  br label %bb77
bb77:
  %t334 = load i1, ptr %l170, !tbaa !21
  store i1 %t334, ptr %rv
  br label %ret
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_ba4cbfec236fac31_e934563b75f0ca1d)
  unreachable
bb83:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolled(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:reflList"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, i64, i64 }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca { i64, i64, i64 }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l35 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/diagmsg:Msg"
  %l41 = alloca i64
  %l42 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l54 = alloca { i64, i64, i64 }
  %l59 = alloca ptr
  %l64 = alloca ptr
  %l75 = alloca i64
  %l78 = alloca i64
  %l98 = alloca i64
  %l102 = alloca { i64, i64, i64 }
  %l107 = alloca ptr
  %l112 = alloca ptr
  %l118 = alloca ptr
  %l120 = alloca i32
  %l125 = alloca i32
  %l126 = alloca i32
  %l127 = alloca ptr
  %l129 = alloca i32
  %l132 = alloca ptr
  %l134 = alloca i32
  %l136 = alloca i32
  %l137 = alloca i32
  %l161 = alloca i64
  %l163 = alloca ptr
  %l166 = alloca i64
  %l167 = alloca i32
  %l173 = alloca ptr
  %l176 = alloca i64
  %l180 = alloca { i64, i64, i64 }
  %l197 = alloca ptr
  %l215 = alloca i64
  %l217 = alloca ptr
  %l220 = alloca i64
  %l221 = alloca i32
  %l227 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t258 = alloca { i64, [3 x i64] }, align 8
  %t325 = alloca { i64, [3 x i64] }, align 8
  %t356 = alloca { i64, [3 x i64] }, align 8
  %t380 = alloca { i64, [3 x i64] }, align 8
  %t422 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/check:reflList" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t3 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = add i32 %t4, 3
  %t9 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t2, i32 %t6)
  store %"compiler/source:Span" %t9, ptr %l35
  br label %bb1
bb1:
  %t10 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t10, ptr %l4
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:ForIn", ptr %t11, i32 0, i32 3
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l38, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t17, ptr %l39
  %t18 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTryList(ptr %s1)
  store %"compiler/diagmsg:Msg" %t18, ptr %l40
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t19 = load ptr, ptr %l38, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l39
  %t21 = load %"compiler/diagmsg:Msg", ptr %l40
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t19, %"compiler/source:Span" %t20, %"compiler/diagmsg:Msg" %t21)
  store i64 %t22, ptr %l41
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l42, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:ForIn", ptr %t24, i32 0, i32 2
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t27)
  store %"compiler/source:Span" %t29, ptr %l45
  br label %bb7
bb7:
  %t30 = load %"compiler/check:reflList", ptr %l3
  %t31 = load ptr, ptr %l42, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l45
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %s0, ptr %t31, %"compiler/source:Span" %t32, %"compiler/check:reflList" %t30)
  store { i64, ptr } %t34, ptr %l47
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 37
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l50
  br label %bb9
bb9:
  %t41 = load i64, ptr %l50, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  %t47 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t42, i32 2, %"compiler/source:Span" %t43)
  store { i64, i64, i64 } %t47, ptr %l54
  br label %bb10
bb10:
  %t48 = load { i64, i64, i64 }, ptr %l54
  store { i64, i64, i64 } %t48, ptr %l7
  %t49 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 0
  %t50 = load i64, ptr %t49, !tbaa !24
  store i64 %t50, ptr %l8, !tbaa !24
  %t52 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 1
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l9, !tbaa !24
  %t55 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t58)
  store ptr %t60, ptr %l59
  br label %bb11
bb11:
  %t61 = load ptr, ptr %l59, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 11
  %t64 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t67)
  store ptr %t69, ptr %l64
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l64, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Body", ptr %t70, i32 0, i32 19
  %t73 = load i64, ptr %l8, !tbaa !24
  %t75 = trunc i64 %t73 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t72, i32 %t75)
  br label %bb14
bb14:
  store i64 0, ptr %l11, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  store i64 %t81, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t83 = load i64, ptr %l12, !tbaa !24
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = icmp sgt i64 %t83, %t84
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load i64, ptr %l13, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb20
bb17:
  %t93 = load i64, ptr %l12, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = sub i64 %t93, %t94
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t103 = sub i64 %t101, 1
  %t104 = load i64, ptr %l13, !tbaa !24
  %t107 = sdiv i64 %t103, %t104
  store i64 %t107, ptr %l78, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb19
bb19:
  %t109 = load i64, ptr %l78, !tbaa !24
  store i64 %t109, ptr %l75, !tbaa !24
  br label %bb20
bb20:
  %t110 = load i64, ptr %l75, !tbaa !24
  store i64 %t110, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  %t111 = load i64, ptr %l15, !tbaa !24
  %t112 = load i64, ptr %l14, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb22, label %bb23
bb22:
  br label %bb55
bb23:
  br label %bb24
bb24:
  %t119 = load i64, ptr %l11, !tbaa !24
  %t120 = load i64, ptr %l15, !tbaa !24
  %t121 = load i64, ptr %l13, !tbaa !24
  %t124 = mul i64 %t120, %t121
  %t127 = add i64 %t119, %t124
  store i64 %t127, ptr %l16, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 37
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t131)
  store i64 %t133, ptr %l98
  br label %bb25
bb25:
  %t134 = load i64, ptr %l98, !tbaa !24
  store i64 %t134, ptr %l17, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  %t140 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t135, i32 2, %"compiler/source:Span" %t136)
  store { i64, i64, i64 } %t140, ptr %l102
  br label %bb26
bb26:
  %t141 = load { i64, i64, i64 }, ptr %l102
  store { i64, i64, i64 } %t141, ptr %l18
  %t142 = getelementptr { i64, i64, i64 }, ptr %l18, i32 0, i32 0
  %t143 = load i64, ptr %t142, !tbaa !24
  store i64 %t143, ptr %l19, !tbaa !24
  %t145 = getelementptr { i64, i64, i64 }, ptr %l18, i32 0, i32 1
  %t146 = load i64, ptr %t145, !tbaa !24
  store i64 %t146, ptr %l20, !tbaa !24
  %t148 = getelementptr { i64, i64, i64 }, ptr %l18, i32 0, i32 2
  %t149 = load i64, ptr %t148, !tbaa !24
  store i64 %t149, ptr %l21, !tbaa !24
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t151)
  store ptr %t153, ptr %l107
  br label %bb27
bb27:
  %t154 = load ptr, ptr %l107, !tbaa !29
  %t156 = getelementptr %"compiler/check:frame", ptr %t154, i32 0, i32 10
  %t157 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t156, i64 %t157)
  br label %bb28
bb28:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t160)
  store ptr %t162, ptr %l112
  br label %bb29
bb29:
  %t163 = load ptr, ptr %l112, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Body", ptr %t163, i32 0, i32 19
  %t166 = load i64, ptr %l19, !tbaa !24
  %t168 = trunc i64 %t166 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t165, i32 %t168)
  br label %bb30
bb30:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l118, !tbaa !29
  %t173 = load ptr, ptr %l2, !tbaa !29
  %t175 = getelementptr %"compiler/ast:ForIn", ptr %t173, i32 0, i32 1
  %t176 = load i32, ptr %t175, !tbaa !23
  store i32 %t176, ptr %l120, !tbaa !23
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load %"compiler/check:reflList", ptr %l3
  %t179 = load i64, ptr %l16, !tbaa !24
  %t181 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr i64, ptr %t182, i64 %t179
  %t184 = load i64, ptr %t183, !tbaa !34
  %t188 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t177, %"compiler/check:reflList" %t178, i64 %t184)
  store i32 %t188, ptr %l125
  br label %bb31
bb31:
  %t189 = load ptr, ptr %l118, !tbaa !29
  %t190 = load i32, ptr %l120, !tbaa !23
  %t191 = load i32, ptr %l125, !tbaa !23
  %t192 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t189, i32 %t190, i32 %t191)
  store i32 %t192, ptr %l126
  br label %bb32
bb32:
  %t193 = load i32, ptr %l126, !tbaa !23
  store i32 %t193, ptr %l22, !tbaa !23
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l127, !tbaa !29
  %t195 = load ptr, ptr %l2, !tbaa !29
  %t197 = getelementptr %"compiler/ast:ForIn", ptr %t195, i32 0, i32 0
  %t198 = load i32, ptr %t197, !tbaa !23
  store i32 %t198, ptr %l129, !tbaa !23
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  store ptr %t204, ptr %l132, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t205)
  store i32 %t207, ptr %l134
  br label %bb33
bb33:
  %t208 = load i64, ptr %l16, !tbaa !24
  %t209 = load ptr, ptr %l132, !tbaa !29
  %t210 = load i32, ptr %l134, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t209, i32 %t210, i64 %t208)
  store i32 %t212, ptr %l136
  br label %bb34
bb34:
  %t213 = load ptr, ptr %l127, !tbaa !29
  %t214 = load i32, ptr %l129, !tbaa !23
  %t215 = load i32, ptr %l136, !tbaa !23
  %t216 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %t213, i32 %t214, i32 %t215)
  store i32 %t216, ptr %l137
  br label %bb35
bb35:
  %t217 = load i32, ptr %l137, !tbaa !23
  store i32 %t217, ptr %l23, !tbaa !23
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t220 = getelementptr %"compiler/ast:ForIn", ptr %t218, i32 0, i32 4
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t225 = icmp sgt i64 %t223, 0
  br i1 %t225, label %bb36, label %bb37
bb36:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load ptr, ptr %l2, !tbaa !29
  %t230 = getelementptr %"compiler/ast:ForIn", ptr %t228, i32 0, i32 4
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t227, { i64, ptr } %t231)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l2, !tbaa !29
  %t237 = getelementptr %"compiler/ast:ForIn", ptr %t235, i32 0, i32 0
  %t238 = load i32, ptr %t237, !tbaa !23
  %t239 = load i32, ptr %l23, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t234, i32 %t238, i32 %t239)
  br label %bb40
bb40:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t246 = getelementptr %"compiler/ast:ForIn", ptr %t244, i32 0, i32 1
  %t247 = load i32, ptr %t246, !tbaa !23
  %t248 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %t243, i32 %t247, i32 %t248)
  br label %bb41
bb41:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  %t254 = load i64, ptr %l19, !tbaa !24
  %t256 = trunc i64 %t254 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t258
  %t259 = getelementptr { i64, [3 x i64] }, ptr %t258, i32 0, i32 0
  store i64 5, ptr %t259
  %t261 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t253, 0
  %t263 = insertvalue { %"compiler/source:Span", i32, i32 } %t261, i32 0, 1
  %t265 = insertvalue { %"compiler/source:Span", i32, i32 } %t263, i32 %t256, 2
  %t266 = getelementptr { i64, [3 x i64] }, ptr %t258, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t265, ptr %t266
  %t267 = load { i64, [3 x i64] }, ptr %t258
  %t269 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t267, ptr %t269
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t252, ptr %t269)
  br label %bb42
bb42:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t272)
  store ptr %t274, ptr %l163
  br label %bb43
bb43:
  %t275 = load ptr, ptr %l163, !tbaa !29
  %t277 = getelementptr %"compiler/check:frame", ptr %t275, i32 0, i32 10
  %t279 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t277)
  %t280 = extractvalue { i32, i64 } %t279, 1
  %t281 = extractvalue { i32, i64 } %t279, 0
  store i32 %t281, ptr %l167
  %t282 = icmp ne i32 %t281, 0
  br i1 %t282, label %bb45, label %ok.283, !prof !99
ok.283:
  store i64 %t280, ptr %l166
  br label %bb44
bb44:
  %t284 = load i64, ptr %l166, !tbaa !24
  store i64 %t284, ptr %l161, !tbaa !24
  br label %bb47
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load i64, ptr %l19, !tbaa !24
  %t287 = load i64, ptr %l20, !tbaa !24
  %t288 = load i64, ptr %l21, !tbaa !24
  %t289 = load i64, ptr %l17, !tbaa !24
  %t295 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t285, i64 %t286, i64 %t287, i64 %t288, i64 %t289)
  store ptr %t295, ptr %l173
  br label %bb48
bb48:
  %t296 = load ptr, ptr %l173, !tbaa !29
  store ptr %t296, ptr %l24, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/check:Checker", ptr %t297, i32 0, i32 37
  %t301 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t299)
  store i64 %t301, ptr %l176
  br label %bb49
bb49:
  %t302 = load i64, ptr %l176, !tbaa !24
  store i64 %t302, ptr %l25, !tbaa !24
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l1
  %t308 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t303, i32 3, %"compiler/source:Span" %t304)
  store { i64, i64, i64 } %t308, ptr %l180
  br label %bb50
bb50:
  %t309 = load { i64, i64, i64 }, ptr %l180
  store { i64, i64, i64 } %t309, ptr %l26
  %t310 = getelementptr { i64, i64, i64 }, ptr %l26, i32 0, i32 0
  %t311 = load i64, ptr %t310, !tbaa !24
  store i64 %t311, ptr %l27, !tbaa !24
  %t313 = getelementptr { i64, i64, i64 }, ptr %l26, i32 0, i32 1
  %t314 = load i64, ptr %t313, !tbaa !24
  store i64 %t314, ptr %l28, !tbaa !24
  %t316 = getelementptr { i64, i64, i64 }, ptr %l26, i32 0, i32 2
  %t317 = load i64, ptr %t316, !tbaa !24
  store i64 %t317, ptr %l29, !tbaa !24
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l1
  %t321 = load i64, ptr %l19, !tbaa !24
  %t323 = trunc i64 %t321 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t325
  %t326 = getelementptr { i64, [3 x i64] }, ptr %t325, i32 0, i32 0
  store i64 5, ptr %t326
  %t328 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t320, 0
  %t330 = insertvalue { %"compiler/source:Span", i32, i32 } %t328, i32 0, 1
  %t332 = insertvalue { %"compiler/source:Span", i32, i32 } %t330, i32 %t323, 2
  %t333 = getelementptr { i64, [3 x i64] }, ptr %t325, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t332, ptr %t333
  %t334 = load { i64, [3 x i64] }, ptr %t325
  %t336 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t334, ptr %t336
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t319, ptr %t336)
  br label %bb51
bb51:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i64, ptr %l27, !tbaa !24
  %t341 = load i64, ptr %l28, !tbaa !24
  %t342 = load i64, ptr %l29, !tbaa !24
  %t343 = load i64, ptr %l25, !tbaa !24
  %t349 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t339, i64 %t340, i64 %t341, i64 %t342, i64 %t343)
  store ptr %t349, ptr %l197
  br label %bb52
bb52:
  %t350 = load ptr, ptr %l197, !tbaa !29
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load %"compiler/source:Span", ptr %l1
  %t353 = load ptr, ptr %l24, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t356
  %t357 = getelementptr { i64, [3 x i64] }, ptr %t356, i32 0, i32 0
  store i64 4, ptr %t357
  %t359 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t352, 0
  %t361 = insertvalue { %"compiler/source:Span", ptr, ptr } %t359, ptr %t353, 1
  %t363 = insertvalue { %"compiler/source:Span", ptr, ptr } %t361, ptr %t350, 2
  %t364 = getelementptr { i64, [3 x i64] }, ptr %t356, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t363, ptr %t364
  %t365 = load { i64, [3 x i64] }, ptr %t356
  %t367 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t365, ptr %t367
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t351, ptr %t367)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t370 = load i64, ptr %l15, !tbaa !24
  %t372 = add i64 %t370, 1
  store i64 %t372, ptr %l15, !tbaa !24
  br label %bb21
bb55:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load %"compiler/source:Span", ptr %l1
  %t376 = load i64, ptr %l8, !tbaa !24
  %t378 = trunc i64 %t376 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t380
  %t381 = getelementptr { i64, [3 x i64] }, ptr %t380, i32 0, i32 0
  store i64 5, ptr %t381
  %t383 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t375, 0
  %t385 = insertvalue { %"compiler/source:Span", i32, i32 } %t383, i32 0, 1
  %t387 = insertvalue { %"compiler/source:Span", i32, i32 } %t385, i32 %t378, 2
  %t388 = getelementptr { i64, [3 x i64] }, ptr %t380, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t387, ptr %t388
  %t389 = load { i64, [3 x i64] }, ptr %t380
  %t391 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t389, ptr %t391
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t374, ptr %t391)
  br label %bb56
bb56:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t394)
  store ptr %t396, ptr %l217
  br label %bb57
bb57:
  %t397 = load ptr, ptr %l217, !tbaa !29
  %t399 = getelementptr %"compiler/check:frame", ptr %t397, i32 0, i32 11
  %t401 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t399)
  %t402 = extractvalue { i32, i64 } %t401, 1
  %t403 = extractvalue { i32, i64 } %t401, 0
  store i32 %t403, ptr %l221
  %t404 = icmp ne i32 %t403, 0
  br i1 %t404, label %bb59, label %ok.405, !prof !99
ok.405:
  store i64 %t402, ptr %l220
  br label %bb58
bb58:
  %t406 = load i64, ptr %l220, !tbaa !24
  store i64 %t406, ptr %l215, !tbaa !24
  br label %bb61
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t408 = load i64, ptr %l8, !tbaa !24
  %t409 = load i64, ptr %l9, !tbaa !24
  %t410 = load i64, ptr %l10, !tbaa !24
  %t411 = load i64, ptr %l6, !tbaa !24
  %t417 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t407, i64 %t408, i64 %t409, i64 %t410, i64 %t411)
  store ptr %t417, ptr %l227
  br label %bb62
bb62:
  %t418 = load ptr, ptr %l227, !tbaa !29
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t422
  %t423 = getelementptr { i64, [3 x i64] }, ptr %t422, i32 0, i32 0
  store i64 4, ptr %t423
  %t425 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t420, 0
  %t427 = insertvalue { %"compiler/source:Span", ptr, ptr } %t425, ptr %t418, 1
  %t428 = insertvalue { %"compiler/source:Span", ptr, ptr } %t427, ptr null, 2
  %t429 = getelementptr { i64, [3 x i64] }, ptr %t422, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t428, ptr %t429
  %t430 = load { i64, [3 x i64] }, ptr %t422
  %t432 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t430, ptr %t432
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t419, ptr %t432)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewakeThunks(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l11 = alloca i64
  %l17 = alloca i64
  %l21 = alloca ptr
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l36 = alloca %"compiler/generic:AnyTable"
  %l39 = alloca i64
  %l40 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i64
  %l58 = alloca %"compiler/typed:Body"
  %l69 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i1
  %t106 = alloca %"compiler/typed:Body", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l1, !tbaa !21
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l8, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 145
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l11
  br label %bb2
bb2:
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb38
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 145
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t15, i64 %t16)
  store i64 %t19, ptr %l17
  br label %bb6
bb6:
  %t20 = load i64, ptr %l17, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 14
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store ptr %t27, ptr %l21
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l21, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 1
  %t31 = load { i64, [2 x i64] }, ptr %t30
  store { i64, [2 x i64] } %t31, ptr %l4
  %t33 = load { i64, [2 x i64] }, ptr %l4
  %t35 = extractvalue { i64, [2 x i64] } %t33, 0
  %t36 = icmp eq i64 %t35, 9
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t39 = getelementptr { i64, i64 }, ptr %t38, i32 0, i32 0
  %t40 = load i64, ptr %t39
  store i64 %t40, ptr %l5, !tbaa !24
  %t42 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t43 = getelementptr { i64, i64 }, ptr %t42, i32 0, i32 1
  %t44 = load i64, ptr %t43
  store i64 %t44, ptr %l6, !tbaa !24
  br label %bb10
bb9:
  br label %bb31
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 144
  store ptr %t48, ptr %l29, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  store ptr %t52, ptr %l31, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 54
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = call %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %s2, ptr %t58, i64 %t59)
  store %"compiler/generic:AnyTable" %t62, ptr %l36
  br label %bb11
bb11:
  %t63 = getelementptr %"compiler/generic:AnyTable", ptr %l36, i32 0, i32 1
  %t64 = load i32, ptr %t63, !tbaa !23
  %t65 = load i64, ptr %l6, !tbaa !24
  %t66 = load ptr, ptr %l31, !tbaa !29
  %t69 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %t66, i32 %t64, i64 %t65)
  store i64 %t69, ptr %l39
  br label %bb12
bb12:
  %t70 = load ptr, ptr %l29, !tbaa !29
  %t71 = load i64, ptr %l39, !tbaa !24
  %t72 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Had7920a3eff3220b2e12299d961f9124(ptr %v0, ptr %t70, i64 %t71)
  store i1 %t72, ptr %l40
  br label %bb13
bb13:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb14, label %bb15
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 14
  %t77 = load i64, ptr %l3, !tbaa !24
  %t80 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t76, i64 %t77)
  store ptr %t80, ptr %l44
  br label %bb16
bb15:
  br label %bb30
bb16:
  %t81 = load ptr, ptr %l44, !tbaa !29
  store ptr %t81, ptr %l7, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 14
  store ptr %t84, ptr %l46, !tbaa !29
  %t85 = load i64, ptr %l3, !tbaa !24
  store i64 %t85, ptr %l47, !tbaa !24
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Body", ptr %t86, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t90 = load ptr, ptr %l7, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Body", ptr %t90, i32 0, i32 1
  %t93 = load { i64, [2 x i64] }, ptr %t92
  %t94 = load ptr, ptr %l7, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Body", ptr %t94, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t98 = load ptr, ptr %l7, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Body", ptr %t98, i32 0, i32 3
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = load ptr, ptr %l7, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Body", ptr %t102, i32 0, i32 4
  %t105 = load %"compiler/source:Span", ptr %t104
  call void @compiler_2ftyped_3aBody_2ector(ptr %t106, ptr %v0, i32 %t89, { i64, [2 x i64] } %t93, i32 %t97, i64 %t101, %"compiler/source:Span" %t105)
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %t106, i64 408, i1 false)
  br label %bb17
bb17:
  %t112 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 408, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %l58, i64 408, i1 false)
  %t113 = load ptr, ptr %l46, !tbaa !29
  %t114 = load i64, ptr %l47, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_H84397c9e89cd48160670049091ea20f1(ptr %v0, ptr %v0, ptr %t113, i64 %t114, ptr %t112)
  br label %bb18
bb18:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 19
  %t119 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t118, i64 %t119, i64 0)
  br label %bb19
bb19:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 17
  %t125 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t124, i64 %t125)
  br label %bb20
bb20:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 145
  %t131 = load i64, ptr %l2, !tbaa !24
  %t134 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %t130, i64 %t131)
  store i32 %t134, ptr %l69
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb22, label %ok.136, !prof !99
ok.136:
  br label %bb21
bb21:
  br label %bb29
bb22:
  %t137 = load i32, ptr %l69, !tbaa !23
  %t138 = icmp eq i32 %t137, 65536
  br i1 %t138, label %bb23, label %bb24
bb23:
  call void @__olang_bang_failed_plain(ptr @olang_loc_73788fcff98f9805_b41ea2f3f6de2ed1)
  unreachable
bb24:
  %t140 = load i32, ptr %l69, !tbaa !23
  %t141 = icmp eq i32 %t140, 65537
  br i1 %t141, label %bb25, label %bb26
bb25:
  call void @__olang_bang_failed_plain(ptr @olang_loc_c2b8ccded0b87422_4b497586bdf0fd3e)
  unreachable
bb26:
  %t143 = load i32, ptr %l69, !tbaa !23
  %t144 = icmp eq i32 %t143, 65538
  br i1 %t144, label %bb27, label %bb28
bb27:
  call void @__olang_bang_failed_plain(ptr @olang_loc_c457ecfc87e57822_ebd31f6668a566ee)
  unreachable
bb28:
  call void @__olang_bang_failed_plain(ptr @olang_loc_c596147ee3c3620c_9098292257d7bbb8)
  unreachable
bb29:
  store i1 true, ptr %l1, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_cde66c6c8e102014_3203f82d8b2f03c0)
  unreachable
bb36:
  %t146 = load i64, ptr %l2, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l2, !tbaa !24
  br label %bb37
bb37:
  br label %bb1
bb38:
  %t150 = load i1, ptr %l1, !tbaa !21
  store i1 %t150, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewithin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l43 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t7 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2, ptr %t3)
  store i1 %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load i1, ptr %l9, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewithin(ptr %v0, ptr %v1, ptr %v2, ptr %t25, ptr %t26, ptr %t27)
  store i1 %t31, ptr %l21
  br label %bb10
bb10:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l11, !tbaa !21
  br label %bb30
bb11:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l22, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 8}
  %t40 = icmp eq i64 %t38, 4
  store i1 %t40, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t41 = load i1, ptr %l23, !tbaa !21
  br i1 %t41, label %bb14, label %bb15
bb14:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Elem", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewithin(ptr %v0, ptr %v1, ptr %v2, ptr %t48, ptr %t52, ptr %t53)
  store i1 %t57, ptr %l32
  br label %bb17
bb17:
  %t58 = load i1, ptr %l32, !tbaa !21
  store i1 %t58, ptr %l11, !tbaa !21
  br label %bb30
bb18:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 5
  store i1 %t66, ptr %l34, !tbaa !21
  br label %bb20
bb20:
  %t67 = load i1, ptr %l34, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Payload", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewithin(ptr %v0, ptr %v1, ptr %v2, ptr %t74, ptr %t78, ptr %t79)
  store i1 %t83, ptr %l43
  br label %bb24
bb24:
  %t84 = load i1, ptr %l43, !tbaa !21
  store i1 %t84, ptr %l11, !tbaa !21
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_e1df209ea46513ba_c2fba828617e051e)
  unreachable
bb30:
  %t85 = load i1, ptr %l11, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l19, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb9, label %bb10
bb9:
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l9, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t60, ptr %l40, !tbaa !27
  %t61 = load i64, ptr %l9, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i32, ptr %t64, i64 %t61
  %t66 = load i32, ptr %t65, !tbaa !33
  %t70 = icmp eq i32 %t66, %a2
  br i1 %t70, label %bb12, label %bb13
bb12:
  %t72 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t72, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t74 = load i64, ptr %l8, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l8, !tbaa !24
  br label %bb8
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca %"compiler/source:Span"
  %l17 = alloca { i64, ptr }
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca %"compiler/source:Span"
  %l39 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t22, ptr %l14
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s1, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l17
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = load %"compiler/source:Span", ptr %l14
  %t32 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t30, i64 %t29)
  store %"compiler/source:Span" %t32, ptr %l19
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  %t33 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t33, ptr %rv
  br label %ret
bb8:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t35 = load ptr, ptr %l20, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l20, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 30}
  %t41 = icmp eq i64 %t39, 15
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t45, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t53 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketOf(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store %"compiler/source:Span" %t53, ptr %l28
  br label %bb14
bb14:
  %t54 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t54, ptr %rv
  br label %ret
bb15:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l29, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 30}
  %t62 = icmp eq i64 %t60, 2
  store i1 %t62, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t63 = load i1, ptr %l30, !tbaa !21
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr }, ptr %t66, i32 0, i32 1
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l5, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t74 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteAt(ptr %v0, ptr %v1, ptr %t70, ptr %t71)
  store %"compiler/source:Span" %t74, ptr %l37
  br label %bb21
bb21:
  %t75 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t75, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t76)
  store %"compiler/source:Span" %t78, ptr %l39
  br label %bb26
bb26:
  %t79 = load %"compiler/source:Span", ptr %l39
  store %"compiler/source:Span" %t79, ptr %rv
  br label %ret
bb27:
  call void @__olang_check_failed(ptr @olang_loc_75b6f594e3a638af_f29916a598710c13)
  unreachable
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBack(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5, i64 %a6, { i64, ptr } %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca i32
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca i32
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca %"compiler/check:laneVals"
  %l67 = alloca i32
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l70 = alloca i32
  %l71 = alloca i1
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l88 = alloca i64
  %l89 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca ptr
  %l129 = alloca %"compiler/source:Span"
  %l131 = alloca %"compiler/source:Span"
  %l135 = alloca i64
  %l139 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l140 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l147 = alloca ptr
  %l150 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l167 = alloca i32
  %l170 = alloca i32
  %l177 = alloca %"compiler/check:atRec"
  %l181 = alloca i64
  %l183 = alloca i64
  %l184 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l189 = alloca i64
  %l192 = alloca i64
  %l211 = alloca ptr
  %l214 = alloca i64
  %l215 = alloca %"compiler/check:atRec"
  %l219 = alloca { i64, ptr }
  %l226 = alloca i64
  %l232 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca %"compiler/source:Span"
  %l238 = alloca { i64, ptr }
  %l240 = alloca %"compiler/diagmsg:Msg"
  %l241 = alloca i64
  %l249 = alloca ptr
  %l255 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l261 = alloca i64
  %l264 = alloca i64
  %l282 = alloca ptr
  %l292 = alloca i64
  %l295 = alloca i64
  %l319 = alloca { i64, ptr }
  %l322 = alloca i64
  %l332 = alloca i64
  %l335 = alloca i64
  %l353 = alloca { i64, ptr }
  %l357 = alloca ptr
  %l359 = alloca %"compiler/source:Span"
  %l362 = alloca i32
  %l365 = alloca i64
  %l366 = alloca ptr
  %l368 = alloca %"compiler/source:Span"
  %l375 = alloca { i64, ptr }
  %l386 = alloca i32
  %l387 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l393 = alloca { i64, ptr }
  %l399 = alloca i64
  %l402 = alloca i64
  %l420 = alloca { i64, ptr }
  %l423 = alloca ptr
  %l424 = alloca ptr
  %l426 = alloca ptr
  %l432 = alloca i32
  %l437 = alloca ptr
  %l439 = alloca %"compiler/source:Span"
  %l440 = alloca ptr
  %l441 = alloca ptr
  %l443 = alloca %"compiler/source:Span"
  %l446 = alloca i32
  %l449 = alloca i64
  %l450 = alloca ptr
  %l452 = alloca %"compiler/source:Span"
  %l466 = alloca i32
  %l472 = alloca ptr
  %l473 = alloca i64
  %l475 = alloca i32
  %l479 = alloca i32
  %l483 = alloca i1
  %l486 = alloca i1
  %l488 = alloca %"compiler/check:laneVals"
  %l491 = alloca ptr
  %l496 = alloca ptr
  %l498 = alloca i32
  %l500 = alloca i32
  %l502 = alloca i1
  %l503 = alloca ptr
  %l505 = alloca i32
  %l506 = alloca i1
  %l507 = alloca ptr
  %l508 = alloca %"compiler/source:Span"
  %l509 = alloca %"compiler/source:Span"
  %l510 = alloca i32
  %l516 = alloca ptr
  %l521 = alloca i1
  %l524 = alloca i1
  %l525 = alloca i1
  %l527 = alloca i32
  %l528 = alloca i1
  %l531 = alloca i32
  %l532 = alloca ptr
  %l536 = alloca ptr
  %l537 = alloca i64
  %l541 = alloca %"compiler/check:laneNode"
  %l543 = alloca { i64, ptr }
  %l544 = alloca { i64, ptr }
  %l545 = alloca i64
  %l546 = alloca { i64, ptr }
  %l549 = alloca i1
  %l551 = alloca i1
  %l554 = alloca i1
  %l557 = alloca i32
  %l558 = alloca { i64, ptr }
  %l559 = alloca { i64, ptr }
  %l561 = alloca i64
  %l565 = alloca { i64, ptr }
  %l567 = alloca i64
  %l570 = alloca i1
  %l572 = alloca ptr
  %l573 = alloca %"compiler/source:Span"
  %l574 = alloca ptr
  %l577 = alloca i1
  %l579 = alloca i32
  %l582 = alloca { i64, ptr }
  %l585 = alloca %"compiler/diagmsg:Msg"
  %l586 = alloca i64
  %l593 = alloca i1
  %l595 = alloca i1
  %l598 = alloca i1
  %l599 = alloca i1
  %l603 = alloca i1
  %l617 = alloca ptr
  %l618 = alloca %"compiler/source:Span"
  %l619 = alloca i32
  %l622 = alloca ptr
  %l625 = alloca i32
  %l626 = alloca i1
  %l627 = alloca i64
  %l630 = alloca i32
  %l631 = alloca i64
  %l632 = alloca ptr
  %l634 = alloca ptr
  %l635 = alloca ptr
  %l637 = alloca ptr
  %l640 = alloca i32
  %l643 = alloca i32
  %l645 = alloca ptr
  %l647 = alloca ptr
  %l652 = alloca i1
  %l654 = alloca i32
  %l657 = alloca i1
  %l658 = alloca ptr
  %l660 = alloca i32
  %l661 = alloca i1
  %l662 = alloca i1
  %l664 = alloca ptr
  %l666 = alloca i32
  %l668 = alloca i1
  %l669 = alloca ptr
  %l670 = alloca %"compiler/source:Span"
  %l675 = alloca ptr
  %l678 = alloca i32
  %l681 = alloca i1
  %l684 = alloca i1
  %l685 = alloca ptr
  %l686 = alloca i32
  %l691 = alloca i1
  %l696 = alloca i1
  %l699 = alloca i1
  %l703 = alloca i1
  %l706 = alloca ptr
  %l707 = alloca %"compiler/source:Span"
  %l709 = alloca i32
  %l712 = alloca i64
  %l713 = alloca ptr
  %l714 = alloca %"compiler/source:Span"
  %l717 = alloca i32
  %l723 = alloca i64
  %l727 = alloca i64
  %l730 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l736 = alloca i64
  %l739 = alloca i64
  %l764 = alloca i64
  %l767 = alloca i64
  %l790 = alloca ptr
  %l793 = alloca i64
  %l794 = alloca %"compiler/check:atRec"
  %l805 = alloca ptr
  %l812 = alloca { i64, ptr }
  %l814 = alloca i64
  %l817 = alloca ptr
  %l826 = alloca i64
  %l829 = alloca i64
  %l847 = alloca { i64, ptr }
  %l848 = alloca i64
  %l851 = alloca { i64, ptr }
  %l854 = alloca ptr
  %l857 = alloca ptr
  %l859 = alloca ptr
  %l862 = alloca i64
  %l863 = alloca %"compiler/check:atRec"
  %l864 = alloca i32
  %l866 = alloca i64
  %l869 = alloca i32
  %l870 = alloca i64
  %l876 = alloca i64
  %l878 = alloca ptr
  %l880 = alloca ptr
  %l883 = alloca i64
  %l884 = alloca %"compiler/check:atRec"
  %l888 = alloca i64
  %l889 = alloca ptr
  %l890 = alloca %"compiler/source:Span"
  %l891 = alloca %"compiler/source:Span"
  %l892 = alloca i64
  %l896 = alloca ptr
  %l897 = alloca ptr
  %l900 = alloca { i64, ptr }
  %l901 = alloca { i64, ptr }
  %l905 = alloca ptr
  %l906 = alloca ptr
  %l907 = alloca %"compiler/source:Span"
  %l910 = alloca i32
  %l911 = alloca i64
  %l927 = alloca ptr
  %l932 = alloca ptr
  %l937 = alloca ptr
  %l942 = alloca i64
  %l943 = alloca i64
  %l946 = alloca ptr
  %l951 = alloca i64
  %l955 = alloca i64
  %l958 = alloca i64
  %l976 = alloca { i64, ptr }
  %l977 = alloca i64
  %l978 = alloca ptr
  %l979 = alloca %"compiler/source:Span"
  %l982 = alloca i64
  %l983 = alloca ptr
  %l986 = alloca { i64, ptr }
  %l988 = alloca i64
  %l992 = alloca ptr
  %l993 = alloca %"compiler/source:Span"
  %l994 = alloca ptr
  %l995 = alloca %"compiler/source:Span"
  %l996 = alloca %"compiler/source:Span"
  %l997 = alloca i64
  %l1001 = alloca ptr
  %l1002 = alloca ptr
  %l1005 = alloca { i64, ptr }
  %l1006 = alloca { i64, ptr }
  %l1010 = alloca ptr
  %l1015 = alloca ptr
  %l1016 = alloca %"compiler/source:Span"
  %l1017 = alloca %"compiler/source:Span"
  %l1019 = alloca i32
  %l1020 = alloca i32
  %l1024 = alloca i64
  %l1029 = alloca ptr
  %l1030 = alloca ptr
  %l1031 = alloca %"compiler/source:Span"
  %l1032 = alloca %"compiler/source:Span"
  %l1039 = alloca ptr
  %l1043 = alloca ptr
  %l1046 = alloca ptr
  %l1051 = alloca ptr
  %l1052 = alloca %"compiler/source:Span"
  %l1053 = alloca i32
  %l1055 = alloca i32
  %l1056 = alloca i32
  %l1063 = alloca ptr
  %l1065 = alloca ptr
  %l1067 = alloca ptr
  %l1068 = alloca %"compiler/source:Span"
  %l1069 = alloca ptr
  %l1079 = alloca i64
  %l1082 = alloca i64
  %l1104 = alloca { i64, ptr }
  %l1107 = alloca i64
  %l1110 = alloca ptr
  %l1119 = alloca i64
  %l1122 = alloca i64
  %l1140 = alloca { i64, ptr }
  %l1141 = alloca i64
  %l1144 = alloca { i64, ptr }
  %l1147 = alloca ptr
  %l1150 = alloca { i64, ptr }
  %l1152 = alloca i64
  %l1157 = alloca ptr
  %l1158 = alloca ptr
  %l1159 = alloca %"compiler/source:Span"
  %l1160 = alloca ptr
  %l1161 = alloca %"compiler/source:Span"
  %l1162 = alloca %"compiler/source:Span"
  %l1165 = alloca i64
  %l1166 = alloca ptr
  %l1167 = alloca %"compiler/source:Span"
  %l1170 = alloca ptr
  %l1174 = alloca ptr
  %l1175 = alloca ptr
  %l1178 = alloca { i64, ptr }
  %l1179 = alloca { i64, ptr }
  %l1183 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %rv = alloca i1
  %t463 = alloca { i64, [1 x i64] }, align 8
  %t482 = alloca { i64, [3 x i64] }, align 8
  %t639 = alloca { i64, [1 x i64] }, align 8
  %t658 = alloca { i64, [3 x i64] }, align 8
  %t782 = alloca { i64, [4 x i64] }, align 8
  %t1199 = alloca { i64, [1 x i64] }, align 8
  %t1220 = alloca { i64, [3 x i64] }, align 8
  %t1244 = alloca i64
  %t1446 = alloca i64
  %t1649 = alloca { i64, [3 x i64] }, align 8
  %t1732 = alloca i64
  %t1864 = alloca { i64, [3 x i64] }, align 8
  %t1912 = alloca { i64, [4 x i64] }, align 8
  %t1965 = alloca { i64, [4 x i64] }, align 8
  %t1997 = alloca { i64, [3 x i64] }, align 8
  %t2092 = alloca i64
  %t2249 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  store i64 %a6, ptr %l6
  store { i64, ptr } %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  %t5 = xor i1 %t3, true
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t7)
  store %"compiler/source:Span" %t9, ptr %l131
  br label %bb3
bb2:
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l129
  br label %bb4
bb3:
  %t12 = load %"compiler/source:Span", ptr %l131
  store %"compiler/source:Span" %t12, ptr %l129
  br label %bb4
bb4:
  %t13 = load %"compiler/source:Span", ptr %l129
  store %"compiler/source:Span" %t13, ptr %l8
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t18 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  store i64 %t18, ptr %l135
  br label %bb5
bb5:
  %t19 = load i64, ptr %l135, !tbaa !24
  store i64 %t19, ptr %l9, !tbaa !24
  %t20 = load i64, ptr %l9, !tbaa !24
  %t22 = icmp slt i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l139
  br label %bb9
bb9:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l139
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l10
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l140
  br label %bb10
bb10:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l140
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l11
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l141
  br label %bb11
bb11:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l141
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  store ptr %t31, ptr %l12, !tbaa !29
  %t33 = load ptr, ptr %l3, !tbaa !29
  store ptr %t33, ptr %l13, !tbaa !29
  br label %bb12
bb12:
  %t35 = load i64, ptr %l9, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb13, label %bb14
bb13:
  br label %bb33
bb14:
  br label %bb15
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l147, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l13, !tbaa !29
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v1, ptr %v1, ptr %t42, ptr %t43)
  store ptr %t46, ptr %l150
  br label %bb16
bb16:
  %t47 = load ptr, ptr %l147, !tbaa !29
  %t48 = load ptr, ptr %l150, !tbaa !29
  %t49 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallArgs(ptr %v0, ptr %v1, ptr %v1, ptr %t47, ptr %t48)
  store { i64, ptr } %t49, ptr %l151
  br label %bb17
bb17:
  %t50 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t50, ptr %l14, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s3, ptr %t57, %"compiler/source:Span" %t58, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d11, i32 0, i32 1) })
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb21:
  %t62 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l10, i64 %t62)
  br label %bb22
bb22:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l13, !tbaa !29
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v1, ptr %v1, ptr %t65, ptr %t66)
  store ptr %t69, ptr %l162
  br label %bb23
bb23:
  %t70 = load ptr, ptr %l162, !tbaa !29
  store ptr %t70, ptr %l15, !tbaa !29
  store ptr %l11, ptr %l163, !tbaa !29
  %t71 = load ptr, ptr %l15, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t77 = load ptr, ptr %l15, !tbaa !29
  %t80 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t77)
  store i32 %t80, ptr %l170
  br label %bb26
bb25:
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t81, ptr %l167, !tbaa !23
  br label %bb27
bb26:
  %t83 = load i32, ptr %l170, !tbaa !23
  store i32 %t83, ptr %l167, !tbaa !23
  br label %bb27
bb27:
  %t84 = load ptr, ptr %l163, !tbaa !29
  %t85 = load i32, ptr %l167, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t84, i32 %t85)
  br label %bb28
bb28:
  %t86 = load ptr, ptr %l12, !tbaa !29
  %t87 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e__H4f2a00f637999dd5fb4d6b4e8f1ae171(ptr %v0, ptr %v1, ptr %t86, { i64, ptr } %t87)
  br label %bb29
bb29:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 38
  %t93 = load i64, ptr %l9, !tbaa !24
  %t96 = call %"compiler/check:atRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v1, ptr %t92, i64 %t93)
  store %"compiler/check:atRec" %t96, ptr %l177
  br label %bb30
bb30:
  %t97 = getelementptr %"compiler/check:atRec", ptr %l177, i32 0, i32 2
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l13, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l13, !tbaa !29
  %t104 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %t100, ptr %t101)
  store i64 %t104, ptr %l181
  br label %bb31
bb31:
  %t105 = load i64, ptr %l181, !tbaa !24
  store i64 %t105, ptr %l9, !tbaa !24
  br label %bb32
bb32:
  br label %bb12
bb33:
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l10)
  store i64 %t107, ptr %l183
  br label %bb34
bb34:
  %t108 = load i64, ptr %l183, !tbaa !24
  store i64 %t108, ptr %l16, !tbaa !24
  %t109 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l184
  br label %bb35
bb35:
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l184
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %l17
  store i64 0, ptr %l18, !tbaa !24
  %t111 = load i64, ptr %l16, !tbaa !24
  store i64 %t111, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t113 = load i64, ptr %l19, !tbaa !24
  %t114 = load i64, ptr %l18, !tbaa !24
  %t117 = icmp sgt i64 %t113, %t114
  br i1 %t117, label %bb36, label %bb37
bb36:
  %t119 = load i64, ptr %l20, !tbaa !24
  %t121 = icmp sgt i64 %t119, 0
  br i1 %t121, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l189, !tbaa !24
  br label %bb41
bb38:
  %t123 = load i64, ptr %l19, !tbaa !24
  %t124 = load i64, ptr %l18, !tbaa !24
  %t127 = sub i64 %t123, %t124
  %t128 = load i64, ptr %l20, !tbaa !24
  %t131 = add i64 %t127, %t128
  %t133 = sub i64 %t131, 1
  %t134 = load i64, ptr %l20, !tbaa !24
  %t137 = sdiv i64 %t133, %t134
  store i64 %t137, ptr %l192, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l192, !tbaa !24
  br label %bb40
bb40:
  %t139 = load i64, ptr %l192, !tbaa !24
  store i64 %t139, ptr %l189, !tbaa !24
  br label %bb41
bb41:
  %t140 = load i64, ptr %l189, !tbaa !24
  store i64 %t140, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s5
  %t141 = load i64, ptr %l22, !tbaa !24
  %t142 = load i64, ptr %l21, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s5)
  br label %bb66
bb44:
  br label %bb45
bb45:
  %t149 = load i64, ptr %l18, !tbaa !24
  %t150 = load i64, ptr %l22, !tbaa !24
  %t151 = load i64, ptr %l20, !tbaa !24
  %t154 = mul i64 %t150, %t151
  %t157 = add i64 %t149, %t154
  store i64 %t157, ptr %l23, !tbaa !24
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 38
  store ptr %t161, ptr %l211, !tbaa !29
  %t162 = load i64, ptr %l23, !tbaa !24
  %t165 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l10, i64 %t162)
  store i64 %t165, ptr %l214
  br label %bb46
bb46:
  %t166 = load ptr, ptr %l211, !tbaa !29
  %t167 = load i64, ptr %l214, !tbaa !24
  %t168 = call %"compiler/check:atRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %s5, ptr %t166, i64 %t167)
  store %"compiler/check:atRec" %t168, ptr %l215
  br label %bb47
bb47:
  %t169 = getelementptr %"compiler/check:atRec", ptr %l215, i32 0, i32 3
  %t170 = load i32, ptr %t169, !tbaa !23
  store i32 %t170, ptr %l24, !tbaa !23
  %t172 = load ptr, ptr %l12, !tbaa !29
  %t173 = load i64, ptr %l23, !tbaa !24
  %t176 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e__H6fdae4ec28a8e0f494e79cb375983eb8(ptr %v0, ptr %s5, ptr %t172, i64 %t173)
  store { i64, ptr } %t176, ptr %l219
  br label %bb48
bb48:
  %t177 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = sub i64 %t178, 1
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i32, ptr %l24, !tbaa !23
  %t186 = add i64 %t180, 1
  %t190 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s5, ptr %t182, i32 %t183, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d12, i32 0, i32 1) }, i64 %t186)
  store i64 %t190, ptr %l226
  br label %bb49
bb49:
  %t191 = load i64, ptr %l226, !tbaa !24
  store i64 %t191, ptr %l26, !tbaa !24
  %t192 = load i64, ptr %l26, !tbaa !24
  %t194 = icmp slt i64 %t192, 0
  br i1 %t194, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s6
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i32, ptr %l24, !tbaa !23
  %t198 = load %"compiler/source:Span", ptr %l5
  %t202 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s6, ptr %s6, ptr %t196, i32 %t197, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d13, i32 0, i32 1) }, %"compiler/source:Span" %t198, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d14, i32 0, i32 1) }, i64 2, i1 true)
  store i1 %t202, ptr %l232
  br label %bb52
bb51:
  br label %bb63
bb52:
  %t203 = load i1, ptr %l232, !tbaa !21
  %t204 = xor i1 %t203, true
  br i1 %t204, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s7
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l234, !tbaa !29
  %t207 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t207, ptr %l235
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load i32, ptr %l24, !tbaa !23
  %t212 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t208, i32 %t209)
  store { i64, ptr } %t212, ptr %l238
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t213 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 0
  %t215 = extractvalue { i64, ptr } %t213, 1
  %t216 = mul i64 %t214, 1
  %t217 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t216)
  call void @llvm.memcpy.p0.p0.i64(ptr %t217, ptr %t215, i64 %t216, i1 false)
  %t218 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  %t221 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWriteThroughAtNoSetat(ptr %s7, ptr %s7, { i64, ptr } %t219)
  store %"compiler/diagmsg:Msg" %t221, ptr %l240
  br label %bb56
bb56:
  %t222 = load ptr, ptr %l234, !tbaa !29
  %t223 = load %"compiler/source:Span", ptr %l235
  %t224 = load %"compiler/diagmsg:Msg", ptr %l240
  %t225 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t222, %"compiler/source:Span" %t223, %"compiler/diagmsg:Msg" %t224)
  store i64 %t225, ptr %l241
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s7)
  br label %bb58
bb58:
  %t226 = load ptr, ptr %l4, !tbaa !29
  %t228 = icmp eq ptr %t226, null
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb59, label %bb60
bb59:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load ptr, ptr %l4, !tbaa !29
  %t235 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t239 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t232, ptr %t233, i32 %t235)
  store ptr %t239, ptr %l249
  br label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb63:
  %t241 = load i64, ptr %l26, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l17, i64 %t241)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s5)
  br label %bb65
bb65:
  %t244 = load i64, ptr %l22, !tbaa !24
  %t246 = add i64 %t244, 1
  store i64 %t246, ptr %l22, !tbaa !24
  br label %bb42
bb66:
  %t248 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t248, ptr %l255
  br label %bb67
bb67:
  %t249 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l255
  %t250 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t249, ptr %t250
  store ptr %t250, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  %t252 = load i64, ptr %l16, !tbaa !24
  store i64 %t252, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t254 = load i64, ptr %l29, !tbaa !24
  %t255 = load i64, ptr %l28, !tbaa !24
  %t258 = icmp sgt i64 %t254, %t255
  br i1 %t258, label %bb68, label %bb69
bb68:
  %t260 = load i64, ptr %l30, !tbaa !24
  %t262 = icmp sgt i64 %t260, 0
  br i1 %t262, label %bb70, label %bb71
bb69:
  store i64 0, ptr %l261, !tbaa !24
  br label %bb73
bb70:
  %t264 = load i64, ptr %l29, !tbaa !24
  %t265 = load i64, ptr %l28, !tbaa !24
  %t268 = sub i64 %t264, %t265
  %t269 = load i64, ptr %l30, !tbaa !24
  %t272 = add i64 %t268, %t269
  %t274 = sub i64 %t272, 1
  %t275 = load i64, ptr %l30, !tbaa !24
  %t278 = sdiv i64 %t274, %t275
  store i64 %t278, ptr %l264, !tbaa !24
  br label %bb72
bb71:
  store i64 0, ptr %l264, !tbaa !24
  br label %bb72
bb72:
  %t280 = load i64, ptr %l264, !tbaa !24
  store i64 %t280, ptr %l261, !tbaa !24
  br label %bb73
bb73:
  %t281 = load i64, ptr %l261, !tbaa !24
  store i64 %t281, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb74
bb74:
  %t282 = load i64, ptr %l32, !tbaa !24
  %t283 = load i64, ptr %l31, !tbaa !24
  %t286 = icmp slt i64 %t282, %t283
  %t288 = xor i1 %t286, true
  br i1 %t288, label %bb75, label %bb76
bb75:
  br label %bb84
bb76:
  br label %bb77
bb77:
  %t290 = load i64, ptr %l28, !tbaa !24
  %t291 = load i64, ptr %l32, !tbaa !24
  %t292 = load i64, ptr %l30, !tbaa !24
  %t295 = mul i64 %t291, %t292
  %t298 = add i64 %t290, %t295
  store i64 %t298, ptr %l33, !tbaa !24
  %t300 = load ptr, ptr %l27, !tbaa !29
  store ptr %t300, ptr %l282, !tbaa !29
  %t301 = icmp sge i64 0, 0
  br i1 %t301, label %bb78, label %bb79
bb78:
  %t303 = icmp sle i64 0, 1152921504606846975
  br i1 %t303, label %bb80, label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_f5f1ca6bc4d4202_a62b55a8c6b3a336)
  unreachable
bb80:
  %t305 = mul i64 0, 8
  %t306 = insertvalue { i64, ptr } undef, i64 0, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t308 = load ptr, ptr %l282, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %s0, ptr %s0, ptr %t308, { i64, ptr } %t307)
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_f5f1ca6bc4d4202_a62b55a8c6b3a336)
  unreachable
bb82:
  br label %bb83
bb83:
  %t310 = load i64, ptr %l32, !tbaa !24
  %t312 = add i64 %t310, 1
  store i64 %t312, ptr %l32, !tbaa !24
  br label %bb74
bb84:
  store i64 0, ptr %l34, !tbaa !24
  %t314 = load i64, ptr %l16, !tbaa !24
  store i64 %t314, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t316 = load i64, ptr %l35, !tbaa !24
  %t317 = load i64, ptr %l34, !tbaa !24
  %t320 = icmp sgt i64 %t316, %t317
  br i1 %t320, label %bb85, label %bb86
bb85:
  %t322 = load i64, ptr %l36, !tbaa !24
  %t324 = icmp sgt i64 %t322, 0
  br i1 %t324, label %bb87, label %bb88
bb86:
  store i64 0, ptr %l292, !tbaa !24
  br label %bb90
bb87:
  %t326 = load i64, ptr %l35, !tbaa !24
  %t327 = load i64, ptr %l34, !tbaa !24
  %t330 = sub i64 %t326, %t327
  %t331 = load i64, ptr %l36, !tbaa !24
  %t334 = add i64 %t330, %t331
  %t336 = sub i64 %t334, 1
  %t337 = load i64, ptr %l36, !tbaa !24
  %t340 = sdiv i64 %t336, %t337
  store i64 %t340, ptr %l295, !tbaa !24
  br label %bb89
bb88:
  store i64 0, ptr %l295, !tbaa !24
  br label %bb89
bb89:
  %t342 = load i64, ptr %l295, !tbaa !24
  store i64 %t342, ptr %l292, !tbaa !24
  br label %bb90
bb90:
  %t343 = load i64, ptr %l292, !tbaa !24
  store i64 %t343, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb91
bb91:
  %t344 = load i64, ptr %l38, !tbaa !24
  %t345 = load i64, ptr %l37, !tbaa !24
  %t348 = icmp slt i64 %t344, %t345
  %t350 = xor i1 %t348, true
  br i1 %t350, label %bb92, label %bb93
bb92:
  br label %bb119
bb93:
  br label %bb94
bb94:
  %t352 = load i64, ptr %l34, !tbaa !24
  %t353 = load i64, ptr %l38, !tbaa !24
  %t354 = load i64, ptr %l36, !tbaa !24
  %t357 = mul i64 %t353, %t354
  %t360 = add i64 %t352, %t357
  %t362 = load i64, ptr %l16, !tbaa !24
  %t364 = sub i64 %t362, 1
  %t368 = sub i64 %t364, %t360
  store i64 %t368, ptr %l40, !tbaa !24
  %t370 = load ptr, ptr %l12, !tbaa !29
  %t371 = load i64, ptr %l40, !tbaa !24
  %t374 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e__H6fdae4ec28a8e0f494e79cb375983eb8(ptr %v0, ptr %v0, ptr %t370, i64 %t371)
  store { i64, ptr } %t374, ptr %l319
  br label %bb95
bb95:
  %t375 = load { i64, ptr }, ptr %l319, !tbaa !27
  store { i64, ptr } %t375, ptr %l41, !tbaa !27
  %t376 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t380 = sub i64 %t378, 1
  store i64 %t380, ptr %l322, !tbaa !24
  %t381 = load i64, ptr %l322, !tbaa !24
  %t382 = icmp sge i64 %t381, 0
  br i1 %t382, label %bb96, label %bb97
bb96:
  %t384 = load i64, ptr %l322, !tbaa !24
  %t385 = icmp sle i64 %t384, 1152921504606846975
  br i1 %t385, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @olang_loc_17f46f322b5d16b7_69863e823125c3cb)
  unreachable
bb98:
  %t387 = load i64, ptr %l322, !tbaa !24
  %t388 = mul i64 %t387, 8
  %t389 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t388)
  %t390 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t389, 1
  store { i64, ptr } %t391, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t393 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t393, 0
  %t397 = sub i64 %t395, 1
  store i64 %t397, ptr %l44, !tbaa !24
  store i64 1, ptr %l45, !tbaa !24
  %t399 = load i64, ptr %l44, !tbaa !24
  %t400 = load i64, ptr %l43, !tbaa !24
  %t403 = icmp sgt i64 %t399, %t400
  br i1 %t403, label %bb100, label %bb101
bb99:
  call void @__olang_check_failed(ptr @olang_loc_17f46f322b5d16b7_69863e823125c3cb)
  unreachable
bb100:
  %t405 = load i64, ptr %l45, !tbaa !24
  %t407 = icmp sgt i64 %t405, 0
  br i1 %t407, label %bb102, label %bb103
bb101:
  store i64 0, ptr %l332, !tbaa !24
  br label %bb105
bb102:
  %t409 = load i64, ptr %l44, !tbaa !24
  %t410 = load i64, ptr %l43, !tbaa !24
  %t413 = sub i64 %t409, %t410
  %t414 = load i64, ptr %l45, !tbaa !24
  %t417 = add i64 %t413, %t414
  %t419 = sub i64 %t417, 1
  %t420 = load i64, ptr %l45, !tbaa !24
  %t423 = sdiv i64 %t419, %t420
  store i64 %t423, ptr %l335, !tbaa !24
  br label %bb104
bb103:
  store i64 0, ptr %l335, !tbaa !24
  br label %bb104
bb104:
  %t425 = load i64, ptr %l335, !tbaa !24
  store i64 %t425, ptr %l332, !tbaa !24
  br label %bb105
bb105:
  %t426 = load i64, ptr %l332, !tbaa !24
  store i64 %t426, ptr %l46, !tbaa !24
  store i64 0, ptr %l47, !tbaa !24
  br label %bb106
bb106:
  %t427 = load i64, ptr %l47, !tbaa !24
  %t428 = load i64, ptr %l46, !tbaa !24
  %t431 = icmp slt i64 %t427, %t428
  %t433 = xor i1 %t431, true
  br i1 %t433, label %bb107, label %bb108
bb107:
  br label %bb116
bb108:
  br label %bb109
bb109:
  %t435 = load i64, ptr %l43, !tbaa !24
  %t436 = load i64, ptr %l47, !tbaa !24
  %t437 = load i64, ptr %l45, !tbaa !24
  %t440 = mul i64 %t436, %t437
  %t443 = add i64 %t435, %t440
  store i64 %t443, ptr %l48, !tbaa !24
  %t445 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t445, ptr %l353, !tbaa !27
  %t446 = load i64, ptr %l48, !tbaa !24
  %t448 = add i64 %t446, 1
  %t450 = getelementptr { i64, ptr }, ptr %l353, i32 0, i32 1
  %t451 = load ptr, ptr %t450, !tbaa !27
  %t452 = getelementptr ptr, ptr %t451, i64 %t448
  %t453 = load ptr, ptr %t452, !tbaa !39
  store ptr %t453, ptr %l49, !tbaa !29
  %t455 = load ptr, ptr %l0, !tbaa !29
  store ptr %t455, ptr %l357, !tbaa !29
  %t456 = load ptr, ptr %l49, !tbaa !29
  %t458 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t456)
  store %"compiler/source:Span" %t458, ptr %l359
  br label %bb110
bb110:
  %t459 = load ptr, ptr %l49, !tbaa !29
  %t462 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t459)
  store i32 %t462, ptr %l362
  br label %bb111
bb111:
  store { i64, [1 x i64] } zeroinitializer, ptr %t463
  %t464 = getelementptr { i64, [1 x i64] }, ptr %t463, i32 0, i32 0
  store i64 0, ptr %t464
  %t465 = load { i64, [1 x i64] }, ptr %t463
  %t466 = load ptr, ptr %l357, !tbaa !29
  %t467 = load %"compiler/source:Span", ptr %l359
  %t468 = load i32, ptr %l362, !tbaa !23
  %t471 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t466, i32 0, %"compiler/source:Span" %t467, i32 %t468, i32 2, { i64, [1 x i64] } %t465)
  store i64 %t471, ptr %l365
  br label %bb112
bb112:
  %t472 = load i64, ptr %l365, !tbaa !24
  store i64 %t472, ptr %l50, !tbaa !24
  %t473 = load ptr, ptr %l0, !tbaa !29
  store ptr %t473, ptr %l366, !tbaa !29
  %t474 = load ptr, ptr %l49, !tbaa !29
  %t476 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t474)
  store %"compiler/source:Span" %t476, ptr %l368
  br label %bb113
bb113:
  %t477 = load i64, ptr %l50, !tbaa !24
  %t479 = trunc i64 %t477 to i32
  %t481 = load ptr, ptr %l49, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t482
  %t483 = getelementptr { i64, [3 x i64] }, ptr %t482, i32 0, i32 0
  store i64 0, ptr %t483
  %t484 = load %"compiler/source:Span", ptr %l368
  %t485 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t484, 0
  %t487 = insertvalue { %"compiler/source:Span", i32, ptr } %t485, i32 %t479, 1
  %t489 = insertvalue { %"compiler/source:Span", i32, ptr } %t487, ptr %t481, 2
  %t490 = getelementptr { i64, [3 x i64] }, ptr %t482, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t489, ptr %t490
  %t491 = load { i64, [3 x i64] }, ptr %t482
  %t493 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t491, ptr %t493
  %t494 = load ptr, ptr %l366, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t494, ptr %t493)
  br label %bb114
bb114:
  %t496 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t496, ptr %l375, !tbaa !27
  %t497 = load i64, ptr %l48, !tbaa !24
  %t498 = load i64, ptr %l50, !tbaa !24
  %t501 = getelementptr { i64, ptr }, ptr %l375, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr i64, ptr %t502, i64 %t497
  store i64 %t498, ptr %t503, !tbaa !34
  br label %bb115
bb115:
  %t504 = load i64, ptr %l47, !tbaa !24
  %t506 = add i64 %t504, 1
  store i64 %t506, ptr %l47, !tbaa !24
  br label %bb106
bb116:
  %t508 = load ptr, ptr %l27, !tbaa !29
  %t509 = load i64, ptr %l40, !tbaa !24
  %t510 = load { i64, ptr }, ptr %l42, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %s0, ptr %s0, ptr %t508, i64 %t509, { i64, ptr } %t510)
  br label %bb117
bb117:
  br label %bb118
bb118:
  %t514 = load i64, ptr %l38, !tbaa !24
  %t516 = add i64 %t514, 1
  store i64 %t516, ptr %l38, !tbaa !24
  br label %bb91
bb119:
  %t518 = load ptr, ptr %l3, !tbaa !29
  %t520 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t518)
  store i32 %t520, ptr %l386
  br label %bb120
bb120:
  %t521 = load i32, ptr %l386, !tbaa !23
  store i32 %t521, ptr %l51, !tbaa !23
  %t522 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t522, ptr %l387
  br label %bb121
bb121:
  %t523 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l387
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t523, ptr %l52
  %t524 = load i64, ptr %l6, !tbaa !24
  %t526 = icmp sge i64 %t524, 0
  br i1 %t526, label %bb122, label %bb123
bb122:
  store %olang.scope zeroinitializer, ptr %s19
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load i64, ptr %l6, !tbaa !24
  %t530 = load i32, ptr %l51, !tbaa !23
  %t534 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamsOn(ptr %v0, ptr %s19, ptr %t528, i64 %t529, i32 %t530)
  store { i64, ptr } %t534, ptr %l393
  br label %bb124
bb123:
  br label %bb161
bb124:
  %t535 = load { i64, ptr }, ptr %l393, !tbaa !27
  store { i64, ptr } %t535, ptr %l53, !tbaa !27
  store i64 0, ptr %l54, !tbaa !24
  %t536 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t538 = extractvalue { i64, ptr } %t536, 0
  store i64 %t538, ptr %l55, !tbaa !24
  store i64 1, ptr %l56, !tbaa !24
  %t540 = load i64, ptr %l55, !tbaa !24
  %t541 = load i64, ptr %l54, !tbaa !24
  %t544 = icmp sgt i64 %t540, %t541
  br i1 %t544, label %bb125, label %bb126
bb125:
  %t546 = load i64, ptr %l56, !tbaa !24
  %t548 = icmp sgt i64 %t546, 0
  br i1 %t548, label %bb127, label %bb128
bb126:
  store i64 0, ptr %l399, !tbaa !24
  br label %bb130
bb127:
  %t550 = load i64, ptr %l55, !tbaa !24
  %t551 = load i64, ptr %l54, !tbaa !24
  %t554 = sub i64 %t550, %t551
  %t555 = load i64, ptr %l56, !tbaa !24
  %t558 = add i64 %t554, %t555
  %t560 = sub i64 %t558, 1
  %t561 = load i64, ptr %l56, !tbaa !24
  %t564 = sdiv i64 %t560, %t561
  store i64 %t564, ptr %l402, !tbaa !24
  br label %bb129
bb128:
  store i64 0, ptr %l402, !tbaa !24
  br label %bb129
bb129:
  %t566 = load i64, ptr %l402, !tbaa !24
  store i64 %t566, ptr %l399, !tbaa !24
  br label %bb130
bb130:
  %t567 = load i64, ptr %l399, !tbaa !24
  store i64 %t567, ptr %l57, !tbaa !24
  store i64 0, ptr %l58, !tbaa !24
  br label %bb131
bb131:
  %t568 = load i64, ptr %l58, !tbaa !24
  %t569 = load i64, ptr %l57, !tbaa !24
  %t572 = icmp slt i64 %t568, %t569
  %t574 = xor i1 %t572, true
  br i1 %t574, label %bb132, label %bb133
bb132:
  br label %bb148
bb133:
  br label %bb134
bb134:
  %t576 = load i64, ptr %l54, !tbaa !24
  %t577 = load i64, ptr %l58, !tbaa !24
  %t578 = load i64, ptr %l56, !tbaa !24
  %t581 = mul i64 %t577, %t578
  %t584 = add i64 %t576, %t581
  store i64 %t584, ptr %l59, !tbaa !24
  %t586 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t586, ptr %l420, !tbaa !27
  %t587 = load i64, ptr %l59, !tbaa !24
  %t589 = getelementptr { i64, ptr }, ptr %l420, i32 0, i32 1
  %t590 = load ptr, ptr %t589, !tbaa !27
  %t591 = getelementptr ptr, ptr %t590, i64 %t587
  %t592 = load ptr, ptr %t591, !tbaa !39
  store ptr %t592, ptr %l60, !tbaa !29
  %t594 = load ptr, ptr %l0, !tbaa !29
  store ptr %t594, ptr %l423, !tbaa !29
  %t595 = load ptr, ptr %l0, !tbaa !29
  store ptr %t595, ptr %l424, !tbaa !29
  %t596 = load ptr, ptr %l60, !tbaa !29
  store ptr %t596, ptr %l426, !tbaa !29
  %t598 = load i64, ptr %l59, !tbaa !24
  %t600 = add i64 1, %t598
  %t601 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t603 = extractvalue { i64, ptr } %t601, 0
  %t606 = icmp slt i64 %t600, %t603
  br i1 %t606, label %bb135, label %bb136
bb135:
  %t608 = load i64, ptr %l59, !tbaa !24
  %t610 = add i64 1, %t608
  %t612 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t613 = load ptr, ptr %t612, !tbaa !27
  %t614 = getelementptr i32, ptr %t613, i64 %t610
  %t615 = load i32, ptr %t614, !tbaa !33
  store i32 %t615, ptr %l432, !tbaa !23
  br label %bb137
bb136:
  %t617 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t617, ptr %l432, !tbaa !23
  br label %bb137
bb137:
  %t619 = load ptr, ptr %l424, !tbaa !29
  %t620 = load ptr, ptr %l426, !tbaa !29
  %t621 = load i32, ptr %l432, !tbaa !23
  %t622 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v3, ptr %v0, ptr %t619, ptr %t620, i32 %t621)
  store ptr %t622, ptr %l437
  br label %bb138
bb138:
  %t623 = load ptr, ptr %l60, !tbaa !29
  %t625 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t623)
  store %"compiler/source:Span" %t625, ptr %l439
  br label %bb139
bb139:
  %t626 = load ptr, ptr %l423, !tbaa !29
  %t627 = load ptr, ptr %l437, !tbaa !29
  %t628 = load %"compiler/source:Span", ptr %l439
  %t629 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t626, ptr %t627, %"compiler/source:Span" %t628)
  store ptr %t629, ptr %l440
  br label %bb140
bb140:
  %t630 = load ptr, ptr %l440, !tbaa !29
  store ptr %t630, ptr %l61, !tbaa !29
  %t631 = load ptr, ptr %l0, !tbaa !29
  store ptr %t631, ptr %l441, !tbaa !29
  %t632 = load ptr, ptr %l60, !tbaa !29
  %t634 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t632)
  store %"compiler/source:Span" %t634, ptr %l443
  br label %bb141
bb141:
  %t635 = load ptr, ptr %l61, !tbaa !29
  %t638 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t635)
  store i32 %t638, ptr %l446
  br label %bb142
bb142:
  store { i64, [1 x i64] } zeroinitializer, ptr %t639
  %t640 = getelementptr { i64, [1 x i64] }, ptr %t639, i32 0, i32 0
  store i64 0, ptr %t640
  %t641 = load { i64, [1 x i64] }, ptr %t639
  %t642 = load ptr, ptr %l441, !tbaa !29
  %t643 = load %"compiler/source:Span", ptr %l443
  %t644 = load i32, ptr %l446, !tbaa !23
  %t647 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t642, i32 0, %"compiler/source:Span" %t643, i32 %t644, i32 2, { i64, [1 x i64] } %t641)
  store i64 %t647, ptr %l449
  br label %bb143
bb143:
  %t648 = load i64, ptr %l449, !tbaa !24
  store i64 %t648, ptr %l62, !tbaa !24
  %t649 = load ptr, ptr %l0, !tbaa !29
  store ptr %t649, ptr %l450, !tbaa !29
  %t650 = load ptr, ptr %l60, !tbaa !29
  %t652 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t650)
  store %"compiler/source:Span" %t652, ptr %l452
  br label %bb144
bb144:
  %t653 = load i64, ptr %l62, !tbaa !24
  %t655 = trunc i64 %t653 to i32
  %t657 = load ptr, ptr %l61, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t658
  %t659 = getelementptr { i64, [3 x i64] }, ptr %t658, i32 0, i32 0
  store i64 0, ptr %t659
  %t660 = load %"compiler/source:Span", ptr %l452
  %t661 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t660, 0
  %t663 = insertvalue { %"compiler/source:Span", i32, ptr } %t661, i32 %t655, 1
  %t665 = insertvalue { %"compiler/source:Span", i32, ptr } %t663, ptr %t657, 2
  %t666 = getelementptr { i64, [3 x i64] }, ptr %t658, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t665, ptr %t666
  %t667 = load { i64, [3 x i64] }, ptr %t658
  %t669 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t667, ptr %t669
  %t670 = load ptr, ptr %l450, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t670, ptr %t669)
  br label %bb145
bb145:
  %t672 = load i64, ptr %l62, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l52, i64 %t672)
  br label %bb146
bb146:
  br label %bb147
bb147:
  %t675 = load i64, ptr %l58, !tbaa !24
  %t677 = add i64 %t675, 1
  store i64 %t677, ptr %l58, !tbaa !24
  br label %bb131
bb148:
  %t679 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t681 = extractvalue { i64, ptr } %t679, 0
  %t683 = icmp sgt i64 %t681, 0
  br i1 %t683, label %bb149, label %bb150
bb149:
  %t685 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t687 = extractvalue { i64, ptr } %t685, 0
  %t689 = sub i64 %t687, 1
  %t691 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t692 = load ptr, ptr %t691, !tbaa !27
  %t693 = getelementptr i32, ptr %t692, i64 %t689
  %t694 = load i32, ptr %t693, !tbaa !33
  store i32 %t694, ptr %l466, !tbaa !23
  br label %bb151
bb150:
  %t696 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t696, ptr %l466, !tbaa !23
  br label %bb151
bb151:
  %t698 = load i32, ptr %l466, !tbaa !23
  store i32 %t698, ptr %l51, !tbaa !23
  %t699 = load ptr, ptr %l0, !tbaa !29
  store ptr %t699, ptr %l472, !tbaa !29
  %t700 = load i64, ptr %l6, !tbaa !24
  store i64 %t700, ptr %l473, !tbaa !24
  %t701 = load ptr, ptr %l3, !tbaa !29
  %t703 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t701)
  store i32 %t703, ptr %l475
  br label %bb152
bb152:
  %t704 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t706 = extractvalue { i64, ptr } %t704, 0
  %t708 = sub i64 %t706, 1
  %t709 = load ptr, ptr %l472, !tbaa !29
  %t710 = load i64, ptr %l473, !tbaa !24
  %t711 = load i32, ptr %l475, !tbaa !23
  %t713 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOn(ptr %v0, ptr %t709, i64 %t710, i32 %t711, i64 %t708)
  store i32 %t713, ptr %l479
  br label %bb153
bb153:
  %t714 = load i32, ptr %l479, !tbaa !23
  store i32 %t714, ptr %l63, !tbaa !23
  %t715 = load i32, ptr %l63, !tbaa !23
  %t716 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t719 = icmp ne i32 %t715, %t716
  br i1 %t719, label %bb154, label %bb155
bb154:
  %t721 = load ptr, ptr %l0, !tbaa !29
  %t722 = load i32, ptr %l63, !tbaa !23
  %t725 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t721, i32 %t722)
  store i1 %t725, ptr %l486
  br label %bb156
bb155:
  store i1 false, ptr %l483, !tbaa !21
  br label %bb157
bb156:
  %t726 = load i1, ptr %l486, !tbaa !21
  store i1 %t726, ptr %l483, !tbaa !21
  br label %bb157
bb157:
  %t727 = load i1, ptr %l483, !tbaa !21
  br i1 %t727, label %bb158, label %bb159
bb158:
  %t728 = load i32, ptr %l63, !tbaa !23
  store i32 %t728, ptr %l51, !tbaa !23
  br label %bb160
bb159:
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s19)
  br label %bb161
bb161:
  store ptr null, ptr %l64, !tbaa !29
  store i64 -1, ptr %l65, !tbaa !24
  %t730 = call %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %s0)
  store %"compiler/check:laneVals" %t730, ptr %l488
  br label %bb162
bb162:
  %t731 = load %"compiler/check:laneVals", ptr %l488
  store %"compiler/check:laneVals" %t731, ptr %l66
  %t732 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t734 = trunc i64 62 to i32
  %t735 = icmp eq i32 %t732, %t734
  br i1 %t735, label %bb163, label %bb164
bb163:
  %t737 = load ptr, ptr %l0, !tbaa !29
  store ptr %t737, ptr %l491, !tbaa !29
  %t738 = load ptr, ptr %l4, !tbaa !29
  %t740 = icmp eq ptr %t738, null
  br i1 %t740, label %bb165, label %bb166
bb164:
  %t742 = load ptr, ptr %l4, !tbaa !29
  %t744 = icmp eq ptr %t742, null
  %t746 = xor i1 %t744, true
  br i1 %t746, label %bb182, label %bb183
bb165:
  call void @__olang_check_failed(ptr @olang_loc_8e17bc78d2dfbd4_98f8be4925a702f0)
  unreachable
bb166:
  br label %bb167
bb167:
  %t748 = load ptr, ptr %l4, !tbaa !29
  %t749 = load i32, ptr %l51, !tbaa !23
  %t750 = load ptr, ptr %l491, !tbaa !29
  %t753 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %v0, ptr %t750, ptr %t748, i32 %t749)
  store ptr %t753, ptr %l496
  br label %bb168
bb168:
  %t754 = load ptr, ptr %l496, !tbaa !29
  store ptr %t754, ptr %l64, !tbaa !29
  %t756 = load i32, ptr %l51, !tbaa !23
  store i32 %t756, ptr %l498, !tbaa !23
  %t757 = load ptr, ptr %l0, !tbaa !29
  %t759 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t757)
  store i32 %t759, ptr %l500
  br label %bb169
bb169:
  %t760 = load i32, ptr %l498, !tbaa !23
  %t761 = load i32, ptr %l500, !tbaa !23
  %t762 = icmp eq i32 %t760, %t761
  br i1 %t762, label %bb170, label %bb171
bb170:
  %t764 = load ptr, ptr %l0, !tbaa !29
  store ptr %t764, ptr %l503, !tbaa !29
  %t765 = load ptr, ptr %l64, !tbaa !29
  %t767 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t765)
  store i32 %t767, ptr %l505
  br label %bb172
bb171:
  store i1 false, ptr %l502, !tbaa !21
  br label %bb174
bb172:
  %t768 = load ptr, ptr %l503, !tbaa !29
  %t769 = load i32, ptr %l505, !tbaa !23
  %t770 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t768, i32 %t769)
  store i1 %t770, ptr %l506
  br label %bb173
bb173:
  %t771 = load i1, ptr %l506, !tbaa !21
  store i1 %t771, ptr %l502, !tbaa !21
  br label %bb174
bb174:
  %t772 = load i1, ptr %l502, !tbaa !21
  br i1 %t772, label %bb175, label %bb176
bb175:
  %t773 = load ptr, ptr %l0, !tbaa !29
  store ptr %t773, ptr %l507, !tbaa !29
  %t774 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t774, ptr %l508
  %t775 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t775, ptr %l509
  %t776 = load i32, ptr %l51, !tbaa !23
  store i32 %t776, ptr %l510, !tbaa !23
  %t777 = load ptr, ptr %l64, !tbaa !29
  %t779 = icmp eq ptr %t777, null
  br i1 %t779, label %bb177, label %bb178
bb176:
  br label %bb181
bb177:
  call void @__olang_check_failed(ptr @olang_loc_7c9348342eb48ce3_d1653baf0fdc2fcf)
  unreachable
bb178:
  br label %bb179
bb179:
  %t781 = load ptr, ptr %l64, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t782
  %t783 = getelementptr { i64, [4 x i64] }, ptr %t782, i32 0, i32 0
  store i64 2, ptr %t783
  %t784 = load %"compiler/source:Span", ptr %l509
  %t785 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t784, 0
  %t786 = load i32, ptr %l510, !tbaa !23
  %t787 = insertvalue { %"compiler/source:Span", i32, ptr } %t785, i32 %t786, 1
  %t789 = insertvalue { %"compiler/source:Span", i32, ptr } %t787, ptr %t781, 2
  %t790 = getelementptr { i64, [4 x i64] }, ptr %t782, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t789, ptr %t790
  %t791 = load { i64, [4 x i64] }, ptr %t782
  %t793 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t791, ptr %t793
  %t794 = load ptr, ptr %l507, !tbaa !29
  %t795 = load %"compiler/source:Span", ptr %l508
  %t797 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t794, %"compiler/source:Span" %t795, ptr %t793)
  store ptr %t797, ptr %l516
  br label %bb180
bb180:
  %t798 = load ptr, ptr %l516, !tbaa !29
  store ptr %t798, ptr %l64, !tbaa !29
  br label %bb181
bb181:
  br label %bb295
bb182:
  %t800 = load ptr, ptr %l0, !tbaa !29
  %t801 = load i32, ptr %l51, !tbaa !23
  %t804 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t800, i32 %t801)
  store i1 %t804, ptr %l524
  br label %bb184
bb183:
  store i1 false, ptr %l521, !tbaa !21
  br label %bb185
bb184:
  %t805 = load i1, ptr %l524, !tbaa !21
  store i1 %t805, ptr %l521, !tbaa !21
  br label %bb185
bb185:
  %t806 = load i1, ptr %l521, !tbaa !21
  br i1 %t806, label %bb186, label %bb187
bb186:
  %t807 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t809 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t807)
  store i32 %t809, ptr %l527
  br label %bb188
bb187:
  store i1 false, ptr %l525, !tbaa !21
  br label %bb190
bb188:
  %t810 = load i32, ptr %l527, !range !{i32 0, i32 98}
  %t811 = call i1 @compiler_2fcheck_2elaneTok(i32 %t810)
  store i1 %t811, ptr %l528
  br label %bb189
bb189:
  %t812 = load i1, ptr %l528, !tbaa !21
  store i1 %t812, ptr %l525, !tbaa !21
  br label %bb190
bb190:
  %t813 = load i1, ptr %l525, !tbaa !21
  br i1 %t813, label %bb191, label %bb192
bb191:
  store %olang.scope zeroinitializer, ptr %s27
  %t814 = load ptr, ptr %l0, !tbaa !29
  %t815 = load i32, ptr %l51, !tbaa !23
  %t818 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t814, i32 %t815)
  store i32 %t818, ptr %l531
  br label %bb193
bb192:
  %t819 = load ptr, ptr %l0, !tbaa !29
  %t820 = load i32, ptr %l51, !tbaa !23
  %t823 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t819, i32 %t820)
  store i1 %t823, ptr %l593
  br label %bb226
bb193:
  %t824 = load i32, ptr %l531, !tbaa !23
  store i32 %t824, ptr %l67, !tbaa !23
  %t825 = load ptr, ptr %l0, !tbaa !29
  store ptr %t825, ptr %l532, !tbaa !29
  %t826 = load ptr, ptr %l0, !tbaa !29
  %t827 = load ptr, ptr %l4, !tbaa !29
  %t828 = load i32, ptr %l67, !tbaa !23
  %t832 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v2, ptr %v0, ptr %t826, ptr %t827, i32 %t828)
  store ptr %t832, ptr %l536
  br label %bb194
bb194:
  %t833 = load ptr, ptr %l532, !tbaa !29
  %t834 = load ptr, ptr %l536, !tbaa !29
  %t835 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v0, ptr %t833, ptr %t834)
  store i64 %t835, ptr %l537
  br label %bb195
bb195:
  %t836 = load i64, ptr %l537, !tbaa !24
  store i64 %t836, ptr %l65, !tbaa !24
  %t837 = load ptr, ptr %l0, !tbaa !29
  %t839 = getelementptr %"compiler/check:Checker", ptr %t837, i32 0, i32 39
  %t840 = load i64, ptr %l65, !tbaa !24
  %t843 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s27, ptr %t839, i64 %t840)
  store %"compiler/check:laneNode" %t843, ptr %l541
  br label %bb196
bb196:
  %t844 = getelementptr %"compiler/check:laneNode", ptr %l541, i32 0, i32 8
  %t845 = load i32, ptr %t844, !tbaa !23
  store i32 %t845, ptr %l68, !tbaa !23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l543, !tbaa !27
  %t847 = load { i64, ptr }, ptr %l543, !tbaa !27
  store { i64, ptr } %t847, ptr %l544, !tbaa !27
  %t848 = load { i64, ptr }, ptr %l544, !tbaa !27
  %t849 = extractvalue { i64, ptr } %t848, 0
  store i64 %t849, ptr %l545, !tbaa !24
  %t850 = load i64, ptr %l545, !tbaa !24
  %t851 = mul i64 %t850, 1
  %t852 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t851)
  %t853 = insertvalue { i64, ptr } undef, i64 %t850, 0
  %t854 = insertvalue { i64, ptr } %t853, ptr %t852, 1
  store { i64, ptr } %t854, ptr %l546, !tbaa !27
  %t855 = getelementptr { i64, ptr }, ptr %l546, i32 0, i32 1
  %t856 = load ptr, ptr %t855, !tbaa !27
  %t857 = getelementptr { i64, ptr }, ptr %l544, i32 0, i32 1
  %t858 = load ptr, ptr %t857, !tbaa !27
  %t859 = load i64, ptr %l545, !tbaa !24
  %t860 = mul i64 %t859, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t856, ptr %t858, i64 %t860, i1 false)
  %t861 = load { i64, ptr }, ptr %l546, !tbaa !27
  store { i64, ptr } %t861, ptr %l69, !tbaa !27
  %t862 = load ptr, ptr %l0, !tbaa !29
  %t863 = load i32, ptr %l67, !tbaa !23
  %t866 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinElem(ptr %v0, ptr %t862, i32 %t863)
  store i1 %t866, ptr %l549
  br label %bb197
bb197:
  %t867 = load i1, ptr %l549, !tbaa !21
  %t868 = xor i1 %t867, true
  br i1 %t868, label %bb198, label %bb199
bb198:
  store i1 true, ptr %l551, !tbaa !21
  br label %bb201
bb199:
  %t870 = load ptr, ptr %l0, !tbaa !29
  %t871 = load i32, ptr %l68, !tbaa !23
  %t874 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinElem(ptr %v0, ptr %t870, i32 %t871)
  store i1 %t874, ptr %l554
  br label %bb200
bb200:
  %t875 = load i1, ptr %l554, !tbaa !21
  %t876 = xor i1 %t875, true
  store i1 %t876, ptr %l551, !tbaa !21
  br label %bb201
bb201:
  %t878 = load i1, ptr %l551, !tbaa !21
  br i1 %t878, label %bb202, label %bb203
bb202:
  store %olang.scope zeroinitializer, ptr %s28
  %t879 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t881 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t879)
  store i32 %t881, ptr %l557
  br label %bb204
bb203:
  %t882 = load ptr, ptr %l0, !tbaa !29
  %t883 = load i64, ptr %l65, !tbaa !24
  %t886 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethodCalled(ptr %v0, ptr %s27, ptr %t882, i64 %t883)
  store { i64, ptr } %t886, ptr %l565
  br label %bb209
bb204:
  %t887 = load i32, ptr %l557, !range !{i32 0, i32 98}
  %t888 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s28, i32 %t887)
  store { i64, ptr } %t888, ptr %l558
  br label %bb205
bb205:
  %t889 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t890 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t891 = load { i64, ptr }, ptr %l558, !tbaa !27
  %t892 = extractvalue { i64, ptr } %t891, 1
  %t893 = extractvalue { i64, ptr } %t891, 0
  %t894 = add i64 %t890, %t893
  %t895 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t896 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t897 = add i64 %t894, %t896
  %t898 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t897)
  call void @olang_textcopy(ptr %t898, ptr %t889, i64 %t890)
  %t899 = getelementptr i8, ptr %t898, i64 %t890
  call void @olang_textcopy(ptr %t899, ptr %t892, i64 %t893)
  %t900 = getelementptr i8, ptr %t899, i64 %t893
  call void @olang_textcopy(ptr %t900, ptr %t895, i64 %t896)
  %t901 = insertvalue { i64, ptr } undef, i64 %t897, 0
  %t902 = insertvalue { i64, ptr } %t901, ptr %t898, 1
  store { i64, ptr } %t902, ptr %l559, !tbaa !27
  %t903 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t904 = extractvalue { i64, ptr } %t903, 0
  %t905 = load { i64, ptr }, ptr %l559, !tbaa !27
  %t906 = extractvalue { i64, ptr } %t905, 0
  store i64 %t906, ptr %l561, !tbaa !24
  %t908 = load i64, ptr %l561, !tbaa !24
  %t909 = icmp eq i64 %t904, %t908
  br i1 %t909, label %bb206, label %bb207
bb206:
  %t911 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t912 = load ptr, ptr %t911, !tbaa !27
  %t913 = getelementptr { i64, ptr }, ptr %l559, i32 0, i32 1
  %t914 = load ptr, ptr %t913, !tbaa !27
  %t915 = load i64, ptr %l561, !tbaa !24
  %t916 = mul i64 %t915, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t912, ptr %t914, i64 %t916, i1 false)
  br label %bb208
bb207:
  %t917 = load { i64, ptr }, ptr %l559, !tbaa !27
  store { i64, ptr } %t917, ptr %l69, !tbaa !27
  br label %bb208
bb208:
  call void @__olang_scope_close(ptr %s28)
  br label %bb213
bb209:
  %t918 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t919 = extractvalue { i64, ptr } %t918, 0
  %t920 = load { i64, ptr }, ptr %l565, !tbaa !27
  %t921 = extractvalue { i64, ptr } %t920, 0
  store i64 %t921, ptr %l567, !tbaa !24
  %t923 = load i64, ptr %l567, !tbaa !24
  %t924 = icmp eq i64 %t919, %t923
  br i1 %t924, label %bb210, label %bb211
bb210:
  %t926 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t927 = load ptr, ptr %t926, !tbaa !27
  %t928 = getelementptr { i64, ptr }, ptr %l565, i32 0, i32 1
  %t929 = load ptr, ptr %t928, !tbaa !27
  %t930 = load i64, ptr %l567, !tbaa !24
  %t931 = mul i64 %t930, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t927, ptr %t929, i64 %t931, i1 false)
  br label %bb212
bb211:
  %t932 = load { i64, ptr }, ptr %l565, !tbaa !27
  store { i64, ptr } %t932, ptr %l69, !tbaa !27
  br label %bb212
bb212:
  br label %bb213
bb213:
  %t933 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t935 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s27, ptr %s27, { i64, ptr } %t933, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t935, ptr %l570
  br label %bb214
bb214:
  %t936 = load i1, ptr %l570, !tbaa !21
  %t937 = xor i1 %t936, true
  br i1 %t937, label %bb215, label %bb216
bb215:
  store %olang.scope zeroinitializer, ptr %s31
  %t939 = load ptr, ptr %l0, !tbaa !29
  store ptr %t939, ptr %l572, !tbaa !29
  %t940 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t940, ptr %l573
  %t941 = load ptr, ptr %l0, !tbaa !29
  store ptr %t941, ptr %l574, !tbaa !29
  %t942 = load ptr, ptr %l0, !tbaa !29
  %t943 = load i32, ptr %l67, !tbaa !23
  %t946 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinElem(ptr %v0, ptr %t942, i32 %t943)
  store i1 %t946, ptr %l577
  br label %bb217
bb216:
  br label %bb224
bb217:
  %t947 = load i1, ptr %l577, !tbaa !21
  %t948 = xor i1 %t947, true
  br i1 %t948, label %bb218, label %bb219
bb218:
  %t950 = load i32, ptr %l67, !tbaa !23
  store i32 %t950, ptr %l579, !tbaa !23
  br label %bb220
bb219:
  %t952 = load i32, ptr %l68, !tbaa !23
  store i32 %t952, ptr %l579, !tbaa !23
  br label %bb220
bb220:
  %t954 = load ptr, ptr %l574, !tbaa !29
  %t955 = load i32, ptr %l579, !tbaa !23
  %t956 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s31, ptr %t954, i32 %t955)
  store { i64, ptr } %t956, ptr %l582
  br label %bb221
bb221:
  %t957 = load { i64, ptr }, ptr %l582, !tbaa !27
  %t958 = extractvalue { i64, ptr } %t957, 0
  %t959 = extractvalue { i64, ptr } %t957, 1
  %t960 = mul i64 %t958, 1
  %t961 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t960)
  call void @llvm.memcpy.p0.p0.i64(ptr %t961, ptr %t959, i64 %t960, i1 false)
  %t962 = insertvalue { i64, ptr } undef, i64 %t958, 0
  %t963 = insertvalue { i64, ptr } %t962, ptr %t961, 1
  %t964 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t967 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWriteThroughAtOperator(ptr %s31, ptr %s27, ptr %s31, { i64, ptr } %t963, { i64, ptr } %t964)
  store %"compiler/diagmsg:Msg" %t967, ptr %l585
  br label %bb222
bb222:
  %t968 = load ptr, ptr %l572, !tbaa !29
  %t969 = load %"compiler/source:Span", ptr %l573
  %t970 = load %"compiler/diagmsg:Msg", ptr %l585
  %t971 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s31, ptr %t968, %"compiler/source:Span" %t969, %"compiler/diagmsg:Msg" %t970)
  store i64 %t971, ptr %l586
  br label %bb223
bb223:
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb224:
  %t973 = load ptr, ptr %l0, !tbaa !29
  %t974 = load i64, ptr %l65, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHoldLeaves(ptr %v0, ptr %s0, ptr %t973, i64 %t974, ptr %l66)
  br label %bb225
bb225:
  call void @__olang_scope_close(ptr %s27)
  br label %bb294
bb226:
  %t978 = load i1, ptr %l593, !tbaa !21
  %t979 = xor i1 %t978, true
  br i1 %t979, label %bb227, label %bb228
bb227:
  store i1 true, ptr %l595, !tbaa !21
  br label %bb234
bb228:
  %t981 = load ptr, ptr %l0, !tbaa !29
  %t982 = load i32, ptr %l51, !tbaa !23
  %t985 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t981, i32 %t982)
  store i1 %t985, ptr %l598
  br label %bb229
bb229:
  %t986 = load i1, ptr %l598, !tbaa !21
  br i1 %t986, label %bb230, label %bb231
bb230:
  %t987 = load ptr, ptr %l0, !tbaa !29
  %t989 = getelementptr %"compiler/check:Checker", ptr %t987, i32 0, i32 1
  %t990 = load ptr, ptr %t989, !tbaa !29
  %t991 = load i32, ptr %l51, !tbaa !23
  %t994 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t990, i32 %t991)
  store i1 %t994, ptr %l603
  br label %bb232
bb231:
  store i1 false, ptr %l599, !tbaa !21
  br label %bb233
bb232:
  %t995 = load i1, ptr %l603, !tbaa !21
  %t996 = xor i1 %t995, true
  store i1 %t996, ptr %l599, !tbaa !21
  br label %bb233
bb233:
  %t998 = load i1, ptr %l599, !tbaa !21
  store i1 %t998, ptr %l595, !tbaa !21
  br label %bb234
bb234:
  %t999 = load i1, ptr %l595, !tbaa !21
  br i1 %t999, label %bb235, label %bb236
bb235:
  %t1000 = load i32, ptr %l51, !tbaa !23
  %t1001 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1004 = icmp ne i32 %t1000, %t1001
  br i1 %t1004, label %bb237, label %bb238
bb236:
  br label %bb241
bb237:
  %t1006 = load ptr, ptr %l0, !tbaa !29
  %t1007 = load %"compiler/source:Span", ptr %l1
  %t1008 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1009 = load i32, ptr %l51, !tbaa !23
  %t1010 = load ptr, ptr %l4, !tbaa !29
  %t1011 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBackNoNumber(ptr %v0, ptr %v2, ptr %t1006, %"compiler/source:Span" %t1007, i32 %t1008, i32 %t1009, ptr %t1010, %"compiler/source:Span" %t1011)
  br label %bb239
bb238:
  br label %bb240
bb239:
  br label %bb240
bb240:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb241:
  %t1019 = load ptr, ptr %l4, !tbaa !29
  %t1021 = icmp eq ptr %t1019, null
  br i1 %t1021, label %bb242, label %bb243
bb242:
  %t1023 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1023, ptr %l617, !tbaa !29
  %t1024 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1024, ptr %l618
  %t1025 = load i32, ptr %l51, !tbaa !23
  store i32 %t1025, ptr %l619, !tbaa !23
  %t1026 = load ptr, ptr %l0, !tbaa !29
  %t1028 = getelementptr %"compiler/check:Checker", ptr %t1026, i32 0, i32 1
  %t1029 = load ptr, ptr %t1028, !tbaa !29
  %t1031 = getelementptr %"compiler/generic:Program", ptr %t1029, i32 0, i32 2
  store ptr %t1031, ptr %l622, !tbaa !29
  %t1032 = load ptr, ptr %l0, !tbaa !29
  %t1033 = load i32, ptr %l51, !tbaa !23
  %t1036 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1032, i32 %t1033)
  store i32 %t1036, ptr %l625
  br label %bb244
bb243:
  %t1037 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1037, ptr %l634, !tbaa !29
  %t1038 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1038, ptr %l635, !tbaa !29
  %t1039 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1039, ptr %l637, !tbaa !29
  %t1041 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1043 = trunc i64 68 to i32
  %t1044 = icmp eq i32 %t1041, %t1043
  br i1 %t1044, label %bb252, label %bb253
bb244:
  %t1046 = load ptr, ptr %l622, !tbaa !29
  %t1047 = load i32, ptr %l625, !tbaa !23
  %t1048 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t1046, i32 %t1047)
  store i1 %t1048, ptr %l626
  br label %bb245
bb245:
  %t1049 = load i1, ptr %l626, !tbaa !21
  br i1 %t1049, label %bb246, label %bb247
bb246:
  %t1050 = load ptr, ptr %l0, !tbaa !29
  %t1051 = load i32, ptr %l51, !tbaa !23
  %t1054 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1050, i32 %t1051)
  store i32 %t1054, ptr %l630
  br label %bb248
bb247:
  store i64 1, ptr %l627, !tbaa !24
  br label %bb250
bb248:
  %t1055 = load i32, ptr %l630, !tbaa !23
  %t1056 = call i64 @compiler_2fcheck_2efloatBits(i32 %t1055, double 0x3ff0000000000000)
  store i64 %t1056, ptr %l631
  br label %bb249
bb249:
  %t1057 = load i64, ptr %l631, !tbaa !24
  store i64 %t1057, ptr %l627, !tbaa !24
  br label %bb250
bb250:
  %t1058 = load ptr, ptr %l617, !tbaa !29
  %t1059 = load %"compiler/source:Span", ptr %l618
  %t1060 = load i32, ptr %l619, !tbaa !23
  %t1061 = load i64, ptr %l627, !tbaa !24
  %t1062 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t1058, %"compiler/source:Span" %t1059, i32 %t1060, i64 %t1061)
  store ptr %t1062, ptr %l632
  br label %bb251
bb251:
  %t1063 = load ptr, ptr %l632, !tbaa !29
  store ptr %t1063, ptr %l64, !tbaa !29
  br label %bb293
bb252:
  %t1065 = load ptr, ptr %l0, !tbaa !29
  %t1066 = load i32, ptr %l51, !tbaa !23
  %t1069 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %t1065, i32 %t1066)
  store i32 %t1069, ptr %l643
  br label %bb254
bb253:
  %t1070 = load i32, ptr %l51, !tbaa !23
  store i32 %t1070, ptr %l640, !tbaa !23
  br label %bb255
bb254:
  %t1072 = load i32, ptr %l643, !tbaa !23
  store i32 %t1072, ptr %l640, !tbaa !23
  br label %bb255
bb255:
  %t1073 = load ptr, ptr %l635, !tbaa !29
  %t1074 = load ptr, ptr %l637, !tbaa !29
  %t1075 = load i32, ptr %l640, !tbaa !23
  %t1076 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t1073, ptr %t1074, i32 %t1075)
  store ptr %t1076, ptr %l645
  br label %bb256
bb256:
  %t1077 = load %"compiler/source:Span", ptr %l8
  %t1078 = load ptr, ptr %l634, !tbaa !29
  %t1079 = load ptr, ptr %l645, !tbaa !29
  %t1081 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t1078, ptr %t1079, %"compiler/source:Span" %t1077)
  store ptr %t1081, ptr %l647
  br label %bb257
bb257:
  %t1082 = load ptr, ptr %l647, !tbaa !29
  store ptr %t1082, ptr %l64, !tbaa !29
  %t1084 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1086 = trunc i64 68 to i32
  %t1087 = icmp eq i32 %t1084, %t1086
  %t1089 = xor i1 %t1087, true
  br i1 %t1089, label %bb258, label %bb259
bb258:
  %t1091 = load ptr, ptr %l64, !tbaa !29
  %t1093 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1091)
  store i32 %t1093, ptr %l654
  br label %bb260
bb259:
  store i1 false, ptr %l652, !tbaa !21
  br label %bb261
bb260:
  %t1094 = load i32, ptr %l51, !tbaa !23
  %t1095 = load i32, ptr %l654, !tbaa !23
  %t1097 = icmp ne i32 %t1095, %t1094
  store i1 %t1097, ptr %l652, !tbaa !21
  br label %bb261
bb261:
  %t1099 = load i1, ptr %l652, !tbaa !21
  br i1 %t1099, label %bb262, label %bb263
bb262:
  %t1100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1100, ptr %l658, !tbaa !29
  %t1101 = load ptr, ptr %l64, !tbaa !29
  %t1103 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1101)
  store i32 %t1103, ptr %l660
  br label %bb264
bb263:
  store i1 false, ptr %l657, !tbaa !21
  br label %bb266
bb264:
  %t1104 = load ptr, ptr %l658, !tbaa !29
  %t1105 = load i32, ptr %l660, !tbaa !23
  %t1106 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t1104, i32 %t1105)
  store i1 %t1106, ptr %l661
  br label %bb265
bb265:
  %t1107 = load i1, ptr %l661, !tbaa !21
  store i1 %t1107, ptr %l657, !tbaa !21
  br label %bb266
bb266:
  %t1108 = load i1, ptr %l657, !tbaa !21
  br i1 %t1108, label %bb267, label %bb268
bb267:
  %t1109 = load ptr, ptr %l0, !tbaa !29
  %t1111 = getelementptr %"compiler/check:Checker", ptr %t1109, i32 0, i32 1
  %t1112 = load ptr, ptr %t1111, !tbaa !29
  store ptr %t1112, ptr %l664, !tbaa !29
  %t1113 = load ptr, ptr %l64, !tbaa !29
  %t1115 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1113)
  store i32 %t1115, ptr %l666
  br label %bb269
bb268:
  store i1 false, ptr %l662, !tbaa !21
  br label %bb271
bb269:
  %t1116 = load i32, ptr %l51, !tbaa !23
  %t1117 = load ptr, ptr %l664, !tbaa !29
  %t1118 = load i32, ptr %l666, !tbaa !23
  %t1120 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %t1117, i32 %t1118, i32 %t1116)
  store i1 %t1120, ptr %l668
  br label %bb270
bb270:
  %t1121 = load i1, ptr %l668, !tbaa !21
  store i1 %t1121, ptr %l662, !tbaa !21
  br label %bb271
bb271:
  %t1122 = load i1, ptr %l662, !tbaa !21
  br i1 %t1122, label %bb272, label %bb273
bb272:
  %t1123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1123, ptr %l669, !tbaa !29
  %t1124 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t1124, ptr %l670
  %t1125 = load ptr, ptr %l64, !tbaa !29
  %t1127 = icmp eq ptr %t1125, null
  br i1 %t1127, label %bb274, label %bb275
bb273:
  br label %bb278
bb274:
  call void @__olang_check_failed(ptr @olang_loc_161638cb42cb28fe_744a250164fb3182)
  unreachable
bb275:
  br label %bb276
bb276:
  %t1129 = load ptr, ptr %l64, !tbaa !29
  %t1130 = load i32, ptr %l51, !tbaa !23
  %t1131 = load ptr, ptr %l669, !tbaa !29
  %t1132 = load %"compiler/source:Span", ptr %l670
  %t1135 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v0, ptr %v0, ptr %t1131, %"compiler/source:Span" %t1132, ptr %t1129, i32 %t1130)
  store ptr %t1135, ptr %l675
  br label %bb277
bb277:
  %t1136 = load ptr, ptr %l675, !tbaa !29
  store ptr %t1136, ptr %l64, !tbaa !29
  br label %bb278
bb278:
  %t1138 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1140 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t1138)
  store i32 %t1140, ptr %l678
  br label %bb279
bb279:
  %t1141 = load i32, ptr %l678, !range !{i32 0, i32 98}
  store i32 %t1141, ptr %l70
  %t1142 = load i32, ptr %l70, !range !{i32 0, i32 98}
  %t1144 = trunc i64 90 to i32
  %t1145 = icmp eq i32 %t1142, %t1144
  br i1 %t1145, label %bb280, label %bb281
bb280:
  store i1 true, ptr %l681, !tbaa !21
  br label %bb282
bb281:
  %t1147 = load i32, ptr %l70, !range !{i32 0, i32 98}
  %t1149 = trunc i64 91 to i32
  %t1150 = icmp eq i32 %t1147, %t1149
  store i1 %t1150, ptr %l681, !tbaa !21
  br label %bb282
bb282:
  %t1152 = load i1, ptr %l681, !tbaa !21
  br i1 %t1152, label %bb283, label %bb284
bb283:
  %t1153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1153, ptr %l685, !tbaa !29
  %t1154 = load i32, ptr %l51, !tbaa !23
  store i32 %t1154, ptr %l686, !tbaa !23
  %t1155 = load ptr, ptr %l64, !tbaa !29
  %t1157 = icmp eq ptr %t1155, null
  br i1 %t1157, label %bb285, label %bb286
bb284:
  store i1 false, ptr %l684, !tbaa !21
  br label %bb289
bb285:
  call void @__olang_check_failed(ptr @olang_loc_d3f4fca21c1b05a5_cc4b7e60173cb869)
  unreachable
bb286:
  br label %bb287
bb287:
  %t1159 = load ptr, ptr %l64, !tbaa !29
  %t1160 = load %"compiler/source:Span", ptr %l8
  %t1161 = load ptr, ptr %l685, !tbaa !29
  %t1162 = load i32, ptr %l686, !tbaa !23
  %t1165 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftInRange(ptr %v0, ptr %v0, ptr %t1161, i32 %t1162, ptr %t1159, %"compiler/source:Span" %t1160)
  store i1 %t1165, ptr %l691
  br label %bb288
bb288:
  %t1166 = load i1, ptr %l691, !tbaa !21
  %t1167 = xor i1 %t1166, true
  store i1 %t1167, ptr %l684, !tbaa !21
  br label %bb289
bb289:
  %t1169 = load i1, ptr %l684, !tbaa !21
  br i1 %t1169, label %bb290, label %bb291
bb290:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb291:
  br label %bb292
bb292:
  br label %bb293
bb293:
  br label %bb294
bb294:
  br label %bb295
bb295:
  %t1171 = load i64, ptr %l65, !tbaa !24
  %t1173 = icmp sge i64 %t1171, 0
  br i1 %t1173, label %bb296, label %bb297
bb296:
  store i1 true, ptr %l696, !tbaa !21
  br label %bb305
bb297:
  %t1175 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1177 = trunc i64 62 to i32
  %t1178 = icmp eq i32 %t1175, %t1177
  br i1 %t1178, label %bb298, label %bb299
bb298:
  %t1180 = load ptr, ptr %l64, !tbaa !29
  %t1182 = icmp eq ptr %t1180, null
  br i1 %t1182, label %bb300, label %bb301
bb299:
  store i1 false, ptr %l699, !tbaa !21
  br label %bb304
bb300:
  call void @__olang_check_failed(ptr @olang_loc_21f488b3c5e8e750_2d22ad345f3d4574)
  unreachable
bb301:
  br label %bb302
bb302:
  %t1184 = load ptr, ptr %l64, !tbaa !29
  %t1186 = call i1 @compiler_2fcheck_2elocalRead(ptr %v0, ptr %t1184)
  store i1 %t1186, ptr %l703
  br label %bb303
bb303:
  %t1187 = load i1, ptr %l703, !tbaa !21
  store i1 %t1187, ptr %l699, !tbaa !21
  br label %bb304
bb304:
  %t1188 = load i1, ptr %l699, !tbaa !21
  store i1 %t1188, ptr %l696, !tbaa !21
  br label %bb305
bb305:
  %t1189 = load i1, ptr %l696, !tbaa !21
  store i1 %t1189, ptr %l71, !tbaa !21
  store i64 -1, ptr %l72, !tbaa !24
  %t1190 = load i1, ptr %l71, !tbaa !21
  %t1192 = xor i1 %t1190, true
  br i1 %t1192, label %bb306, label %bb307
bb306:
  %t1194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1194, ptr %l706, !tbaa !29
  %t1195 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t1195, ptr %l707
  %t1196 = load ptr, ptr %l64, !tbaa !29
  %t1198 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1196)
  store i32 %t1198, ptr %l709
  br label %bb308
bb307:
  br label %bb314
bb308:
  store { i64, [1 x i64] } zeroinitializer, ptr %t1199
  %t1200 = getelementptr { i64, [1 x i64] }, ptr %t1199, i32 0, i32 0
  store i64 0, ptr %t1200
  %t1201 = load { i64, [1 x i64] }, ptr %t1199
  %t1202 = load ptr, ptr %l706, !tbaa !29
  %t1203 = load %"compiler/source:Span", ptr %l707
  %t1204 = load i32, ptr %l709, !tbaa !23
  %t1207 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t1202, i32 0, %"compiler/source:Span" %t1203, i32 %t1204, i32 2, { i64, [1 x i64] } %t1201)
  store i64 %t1207, ptr %l712
  br label %bb309
bb309:
  %t1208 = load i64, ptr %l712, !tbaa !24
  store i64 %t1208, ptr %l72, !tbaa !24
  %t1209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1209, ptr %l713, !tbaa !29
  %t1210 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t1210, ptr %l714
  %t1211 = load i64, ptr %l72, !tbaa !24
  %t1213 = trunc i64 %t1211 to i32
  store i32 %t1213, ptr %l717, !tbaa !23
  %t1215 = load ptr, ptr %l64, !tbaa !29
  %t1217 = icmp eq ptr %t1215, null
  br i1 %t1217, label %bb310, label %bb311
bb310:
  call void @__olang_check_failed(ptr @olang_loc_f30c3194d6b62caf_3ce94d7e88579503)
  unreachable
bb311:
  br label %bb312
bb312:
  %t1219 = load ptr, ptr %l64, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t1220
  %t1221 = getelementptr { i64, [3 x i64] }, ptr %t1220, i32 0, i32 0
  store i64 0, ptr %t1221
  %t1222 = load %"compiler/source:Span", ptr %l714
  %t1223 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1222, 0
  %t1224 = load i32, ptr %l717, !tbaa !23
  %t1225 = insertvalue { %"compiler/source:Span", i32, ptr } %t1223, i32 %t1224, 1
  %t1227 = insertvalue { %"compiler/source:Span", i32, ptr } %t1225, ptr %t1219, 2
  %t1228 = getelementptr { i64, [3 x i64] }, ptr %t1220, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1227, ptr %t1228
  %t1229 = load { i64, [3 x i64] }, ptr %t1220
  %t1231 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1229, ptr %t1231
  %t1232 = load ptr, ptr %l713, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1232, ptr %t1231)
  br label %bb313
bb313:
  br label %bb314
bb314:
  %t1234 = load i64, ptr %l16, !tbaa !24
  store i64 %t1234, ptr %l723, !tbaa !24
  %t1235 = load i64, ptr %l723, !tbaa !24
  %t1236 = icmp sge i64 %t1235, 0
  br i1 %t1236, label %bb315, label %bb316
bb315:
  %t1238 = load i64, ptr %l723, !tbaa !24
  %t1239 = icmp sle i64 %t1238, 1152921504606846975
  br i1 %t1239, label %bb317, label %bb318
bb316:
  call void @__olang_check_failed(ptr @olang_loc_cb5bd539a2ebdd1a_6c90c646f95f810e)
  unreachable
bb317:
  %t1241 = load i64, ptr %l723, !tbaa !24
  %t1242 = mul i64 %t1241, 8
  %t1243 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1242)
  store i64 0, ptr %t1244
  br label %fill.1245
fill.1245:
  %t1248 = load i64, ptr %t1244
  %t1249 = icmp slt i64 %t1248, %t1241
  br i1 %t1249, label %fillb.1246, label %filld.1247
fillb.1246:
  %t1250 = getelementptr i64, ptr %t1243, i64 %t1248
  store i64 -1, ptr %t1250
  %t1251 = add i64 %t1248, 1
  store i64 %t1251, ptr %t1244
  br label %fill.1245
filld.1247:
  %t1252 = insertvalue { i64, ptr } undef, i64 %t1241, 0
  %t1253 = insertvalue { i64, ptr } %t1252, ptr %t1243, 1
  store { i64, ptr } %t1253, ptr %l73, !tbaa !27
  %t1255 = load i64, ptr %l16, !tbaa !24
  store i64 %t1255, ptr %l727, !tbaa !24
  %t1256 = load i64, ptr %l727, !tbaa !24
  %t1257 = icmp sge i64 %t1256, 0
  br i1 %t1257, label %bb319, label %bb320
bb318:
  call void @__olang_check_failed(ptr @olang_loc_cb5bd539a2ebdd1a_6c90c646f95f810e)
  unreachable
bb319:
  %t1259 = load i64, ptr %l727, !tbaa !24
  %t1260 = mul i64 %t1259, 1
  %t1261 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t1260)
  %t1262 = insertvalue { i64, ptr } undef, i64 %t1259, 0
  %t1263 = insertvalue { i64, ptr } %t1262, ptr %t1261, 1
  store { i64, ptr } %t1263, ptr %l74, !tbaa !27
  %t1265 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1265, ptr %l730
  br label %bb321
bb320:
  call void @__olang_check_failed(ptr @olang_loc_ec12a5e6811badef_17bc7d420925a003)
  unreachable
bb321:
  %t1266 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l730
  %t1267 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1266, ptr %t1267
  store ptr %t1267, ptr %l75, !tbaa !29
  store i64 0, ptr %l76, !tbaa !24
  %t1269 = load i64, ptr %l16, !tbaa !24
  store i64 %t1269, ptr %l77, !tbaa !24
  store i64 1, ptr %l78, !tbaa !24
  %t1271 = load i64, ptr %l77, !tbaa !24
  %t1272 = load i64, ptr %l76, !tbaa !24
  %t1275 = icmp sgt i64 %t1271, %t1272
  br i1 %t1275, label %bb322, label %bb323
bb322:
  %t1277 = load i64, ptr %l78, !tbaa !24
  %t1279 = icmp sgt i64 %t1277, 0
  br i1 %t1279, label %bb324, label %bb325
bb323:
  store i64 0, ptr %l736, !tbaa !24
  br label %bb327
bb324:
  %t1281 = load i64, ptr %l77, !tbaa !24
  %t1282 = load i64, ptr %l76, !tbaa !24
  %t1285 = sub i64 %t1281, %t1282
  %t1286 = load i64, ptr %l78, !tbaa !24
  %t1289 = add i64 %t1285, %t1286
  %t1291 = sub i64 %t1289, 1
  %t1292 = load i64, ptr %l78, !tbaa !24
  %t1295 = sdiv i64 %t1291, %t1292
  store i64 %t1295, ptr %l739, !tbaa !24
  br label %bb326
bb325:
  store i64 0, ptr %l739, !tbaa !24
  br label %bb326
bb326:
  %t1297 = load i64, ptr %l739, !tbaa !24
  store i64 %t1297, ptr %l736, !tbaa !24
  br label %bb327
bb327:
  %t1298 = load i64, ptr %l736, !tbaa !24
  store i64 %t1298, ptr %l79, !tbaa !24
  store i64 0, ptr %l80, !tbaa !24
  br label %bb328
bb328:
  %t1299 = load i64, ptr %l80, !tbaa !24
  %t1300 = load i64, ptr %l79, !tbaa !24
  %t1303 = icmp slt i64 %t1299, %t1300
  %t1305 = xor i1 %t1303, true
  br i1 %t1305, label %bb329, label %bb330
bb329:
  br label %bb334
bb330:
  br label %bb331
bb331:
  %t1307 = load i64, ptr %l76, !tbaa !24
  %t1308 = load i64, ptr %l80, !tbaa !24
  %t1309 = load i64, ptr %l78, !tbaa !24
  %t1312 = mul i64 %t1308, %t1309
  %t1315 = add i64 %t1307, %t1312
  store i64 %t1315, ptr %l81, !tbaa !24
  %t1317 = load ptr, ptr %l75, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eP_Ha5c233616e2ae02d7fe37742cfaef2c2(ptr %v0, ptr %v0, ptr %t1317, ptr null)
  br label %bb332
bb332:
  br label %bb333
bb333:
  %t1319 = load i64, ptr %l80, !tbaa !24
  %t1321 = add i64 %t1319, 1
  store i64 %t1321, ptr %l80, !tbaa !24
  br label %bb328
bb334:
  store i64 0, ptr %l82, !tbaa !24
  %t1323 = load i64, ptr %l16, !tbaa !24
  store i64 %t1323, ptr %l83, !tbaa !24
  store i64 1, ptr %l84, !tbaa !24
  %t1325 = load i64, ptr %l83, !tbaa !24
  %t1326 = load i64, ptr %l82, !tbaa !24
  %t1329 = icmp sgt i64 %t1325, %t1326
  br i1 %t1329, label %bb335, label %bb336
bb335:
  %t1331 = load i64, ptr %l84, !tbaa !24
  %t1333 = icmp sgt i64 %t1331, 0
  br i1 %t1333, label %bb337, label %bb338
bb336:
  store i64 0, ptr %l764, !tbaa !24
  br label %bb340
bb337:
  %t1335 = load i64, ptr %l83, !tbaa !24
  %t1336 = load i64, ptr %l82, !tbaa !24
  %t1339 = sub i64 %t1335, %t1336
  %t1340 = load i64, ptr %l84, !tbaa !24
  %t1343 = add i64 %t1339, %t1340
  %t1345 = sub i64 %t1343, 1
  %t1346 = load i64, ptr %l84, !tbaa !24
  %t1349 = sdiv i64 %t1345, %t1346
  store i64 %t1349, ptr %l767, !tbaa !24
  br label %bb339
bb338:
  store i64 0, ptr %l767, !tbaa !24
  br label %bb339
bb339:
  %t1351 = load i64, ptr %l767, !tbaa !24
  store i64 %t1351, ptr %l764, !tbaa !24
  br label %bb340
bb340:
  %t1352 = load i64, ptr %l764, !tbaa !24
  store i64 %t1352, ptr %l85, !tbaa !24
  store i64 0, ptr %l86, !tbaa !24
  br label %bb341
bb341:
  store %olang.scope zeroinitializer, ptr %s44
  %t1353 = load i64, ptr %l86, !tbaa !24
  %t1354 = load i64, ptr %l85, !tbaa !24
  %t1357 = icmp slt i64 %t1353, %t1354
  %t1359 = xor i1 %t1357, true
  br i1 %t1359, label %bb342, label %bb343
bb342:
  call void @__olang_scope_close(ptr %s44)
  br label %bb395
bb343:
  br label %bb344
bb344:
  %t1361 = load i64, ptr %l82, !tbaa !24
  %t1362 = load i64, ptr %l86, !tbaa !24
  %t1363 = load i64, ptr %l84, !tbaa !24
  %t1366 = mul i64 %t1362, %t1363
  %t1369 = add i64 %t1361, %t1366
  %t1371 = load i64, ptr %l16, !tbaa !24
  %t1373 = sub i64 %t1371, 1
  %t1377 = sub i64 %t1373, %t1369
  store i64 %t1377, ptr %l88, !tbaa !24
  %t1379 = load ptr, ptr %l0, !tbaa !29
  %t1381 = getelementptr %"compiler/check:Checker", ptr %t1379, i32 0, i32 38
  store ptr %t1381, ptr %l790, !tbaa !29
  %t1382 = load i64, ptr %l88, !tbaa !24
  %t1385 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l10, i64 %t1382)
  store i64 %t1385, ptr %l793
  br label %bb345
bb345:
  %t1386 = load ptr, ptr %l790, !tbaa !29
  %t1387 = load i64, ptr %l793, !tbaa !24
  %t1388 = call %"compiler/check:atRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v0, ptr %t1386, i64 %t1387)
  store %"compiler/check:atRec" %t1388, ptr %l794
  br label %bb346
bb346:
  %t1389 = getelementptr %"compiler/check:atRec", ptr %l794, i32 0, i32 2
  %t1390 = load ptr, ptr %t1389, !tbaa !29
  store ptr %t1390, ptr %l89, !tbaa !29
  %t1392 = load i64, ptr %l88, !tbaa !24
  %t1394 = add i64 %t1392, 1
  %t1395 = load i64, ptr %l16, !tbaa !24
  %t1398 = icmp slt i64 %t1394, %t1395
  br i1 %t1398, label %bb347, label %bb348
bb347:
  %t1400 = load ptr, ptr %l0, !tbaa !29
  %t1401 = load ptr, ptr %l89, !tbaa !29
  %t1402 = load i64, ptr %l88, !tbaa !24
  %t1404 = add i64 %t1402, 1
  %t1406 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t1407 = load ptr, ptr %t1406, !tbaa !27
  %t1408 = getelementptr i64, ptr %t1407, i64 %t1404
  %t1409 = load i64, ptr %t1408, !tbaa !34
  %t1413 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %v0, ptr %v0, ptr %t1400, ptr %t1401, i64 %t1409)
  store ptr %t1413, ptr %l805
  br label %bb349
bb348:
  br label %bb350
bb349:
  %t1414 = load ptr, ptr %l805, !tbaa !29
  store ptr %t1414, ptr %l89, !tbaa !29
  br label %bb350
bb350:
  %t1415 = load ptr, ptr %l75, !tbaa !29
  %t1416 = load i64, ptr %l88, !tbaa !24
  %t1417 = load ptr, ptr %l89, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eS_H34f0b8d4004ea3d8dbd5c02acd682062(ptr %v0, ptr %v0, ptr %t1415, i64 %t1416, ptr %t1417)
  br label %bb351
bb351:
  %t1422 = load ptr, ptr %l27, !tbaa !29
  %t1423 = load i64, ptr %l88, !tbaa !24
  %t1426 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %s0, ptr %s0, ptr %t1422, i64 %t1423)
  store { i64, ptr } %t1426, ptr %l812
  br label %bb352
bb352:
  %t1427 = load { i64, ptr }, ptr %l812, !tbaa !27
  store { i64, ptr } %t1427, ptr %l90, !tbaa !27
  %t1428 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t1430 = extractvalue { i64, ptr } %t1428, 0
  store i64 %t1430, ptr %l814, !tbaa !24
  %t1431 = load ptr, ptr %l0, !tbaa !29
  %t1432 = load %"compiler/source:Span", ptr %l1
  %t1435 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v0, ptr %t1431, %"compiler/source:Span" %t1432)
  store ptr %t1435, ptr %l817
  br label %bb353
bb353:
  %t1436 = load i64, ptr %l814, !tbaa !24
  %t1437 = icmp sge i64 %t1436, 0
  br i1 %t1437, label %bb354, label %bb355
bb354:
  %t1439 = load i64, ptr %l814, !tbaa !24
  %t1440 = icmp sle i64 %t1439, 1152921504606846975
  br i1 %t1440, label %bb356, label %bb357
bb355:
  call void @__olang_check_failed(ptr @olang_loc_da0d16ec43a70817_ac9d3ce40fb81973)
  unreachable
bb356:
  %t1442 = load i64, ptr %l814, !tbaa !24
  %t1443 = mul i64 %t1442, 8
  %t1444 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1443)
  %t1445 = load ptr, ptr %l817, !tbaa !29
  store i64 0, ptr %t1446
  br label %fill.1447
fill.1447:
  %t1450 = load i64, ptr %t1446
  %t1451 = icmp slt i64 %t1450, %t1442
  br i1 %t1451, label %fillb.1448, label %filld.1449
fillb.1448:
  %t1452 = getelementptr ptr, ptr %t1444, i64 %t1450
  store ptr %t1445, ptr %t1452
  %t1453 = add i64 %t1450, 1
  store i64 %t1453, ptr %t1446
  br label %fill.1447
filld.1449:
  %t1454 = insertvalue { i64, ptr } undef, i64 %t1442, 0
  %t1455 = insertvalue { i64, ptr } %t1454, ptr %t1444, 1
  store { i64, ptr } %t1455, ptr %l91, !tbaa !27
  store i64 0, ptr %l92, !tbaa !24
  %t1457 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t1459 = extractvalue { i64, ptr } %t1457, 0
  store i64 %t1459, ptr %l93, !tbaa !24
  store i64 1, ptr %l94, !tbaa !24
  %t1461 = load i64, ptr %l93, !tbaa !24
  %t1462 = load i64, ptr %l92, !tbaa !24
  %t1465 = icmp sgt i64 %t1461, %t1462
  br i1 %t1465, label %bb358, label %bb359
bb357:
  call void @__olang_check_failed(ptr @olang_loc_da0d16ec43a70817_ac9d3ce40fb81973)
  unreachable
bb358:
  %t1467 = load i64, ptr %l94, !tbaa !24
  %t1469 = icmp sgt i64 %t1467, 0
  br i1 %t1469, label %bb360, label %bb361
bb359:
  store i64 0, ptr %l826, !tbaa !24
  br label %bb363
bb360:
  %t1471 = load i64, ptr %l93, !tbaa !24
  %t1472 = load i64, ptr %l92, !tbaa !24
  %t1475 = sub i64 %t1471, %t1472
  %t1476 = load i64, ptr %l94, !tbaa !24
  %t1479 = add i64 %t1475, %t1476
  %t1481 = sub i64 %t1479, 1
  %t1482 = load i64, ptr %l94, !tbaa !24
  %t1485 = sdiv i64 %t1481, %t1482
  store i64 %t1485, ptr %l829, !tbaa !24
  br label %bb362
bb361:
  store i64 0, ptr %l829, !tbaa !24
  br label %bb362
bb362:
  %t1487 = load i64, ptr %l829, !tbaa !24
  store i64 %t1487, ptr %l826, !tbaa !24
  br label %bb363
bb363:
  %t1488 = load i64, ptr %l826, !tbaa !24
  store i64 %t1488, ptr %l95, !tbaa !24
  store i64 0, ptr %l96, !tbaa !24
  br label %bb364
bb364:
  %t1489 = load i64, ptr %l96, !tbaa !24
  %t1490 = load i64, ptr %l95, !tbaa !24
  %t1493 = icmp slt i64 %t1489, %t1490
  %t1495 = xor i1 %t1493, true
  br i1 %t1495, label %bb365, label %bb366
bb365:
  br label %bb370
bb366:
  br label %bb367
bb367:
  %t1497 = load i64, ptr %l92, !tbaa !24
  %t1498 = load i64, ptr %l96, !tbaa !24
  %t1499 = load i64, ptr %l94, !tbaa !24
  %t1502 = mul i64 %t1498, %t1499
  %t1505 = add i64 %t1497, %t1502
  store i64 %t1505, ptr %l97, !tbaa !24
  %t1507 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t1507, ptr %l847, !tbaa !27
  %t1508 = load i64, ptr %l97, !tbaa !24
  store i64 %t1508, ptr %l848, !tbaa !24
  %t1509 = load ptr, ptr %l0, !tbaa !29
  %t1510 = load %"compiler/source:Span", ptr %l1
  %t1511 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t1511, ptr %l851, !tbaa !27
  %t1512 = load i64, ptr %l97, !tbaa !24
  %t1514 = getelementptr { i64, ptr }, ptr %l851, i32 0, i32 1
  %t1515 = load ptr, ptr %t1514, !tbaa !27
  %t1516 = getelementptr i64, ptr %t1515, i64 %t1512
  %t1517 = load i64, ptr %t1516, !tbaa !34
  %t1521 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t1509, %"compiler/source:Span" %t1510, i64 %t1517)
  store ptr %t1521, ptr %l854
  br label %bb368
bb368:
  %t1522 = load ptr, ptr %l854, !tbaa !29
  %t1523 = load i64, ptr %l848, !tbaa !24
  %t1524 = getelementptr { i64, ptr }, ptr %l847, i32 0, i32 1
  %t1525 = load ptr, ptr %t1524, !tbaa !27
  %t1526 = getelementptr ptr, ptr %t1525, i64 %t1523
  store ptr %t1522, ptr %t1526, !tbaa !39
  br label %bb369
bb369:
  %t1527 = load i64, ptr %l96, !tbaa !24
  %t1529 = add i64 %t1527, 1
  store i64 %t1529, ptr %l96, !tbaa !24
  br label %bb364
bb370:
  %t1531 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1531, ptr %l857, !tbaa !29
  %t1532 = load ptr, ptr %l0, !tbaa !29
  %t1534 = getelementptr %"compiler/check:Checker", ptr %t1532, i32 0, i32 38
  store ptr %t1534, ptr %l859, !tbaa !29
  %t1535 = load i64, ptr %l88, !tbaa !24
  %t1538 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l10, i64 %t1535)
  store i64 %t1538, ptr %l862
  br label %bb371
bb371:
  %t1539 = load ptr, ptr %l859, !tbaa !29
  %t1540 = load i64, ptr %l862, !tbaa !24
  %t1541 = call %"compiler/check:atRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %s44, ptr %t1539, i64 %t1540)
  store %"compiler/check:atRec" %t1541, ptr %l863
  br label %bb372
bb372:
  %t1542 = getelementptr %"compiler/check:atRec", ptr %l863, i32 0, i32 3
  %t1543 = load i32, ptr %t1542, !tbaa !23
  store i32 %t1543, ptr %l864, !tbaa !23
  %t1544 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t1546 = extractvalue { i64, ptr } %t1544, 0
  store i64 %t1546, ptr %l866, !tbaa !24
  %t1547 = load i64, ptr %l88, !tbaa !24
  %t1550 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l11, i64 %t1547)
  store i32 %t1550, ptr %l869
  br label %bb373
bb373:
  %t1551 = load ptr, ptr %l857, !tbaa !29
  %t1552 = load i32, ptr %l864, !tbaa !23
  %t1553 = load i64, ptr %l866, !tbaa !24
  %t1554 = load i32, ptr %l869, !tbaa !23
  %t1555 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlace(ptr %v0, ptr %t1551, i32 %t1552, i64 %t1553, i32 %t1554)
  store i64 %t1555, ptr %l870
  br label %bb374
bb374:
  %t1556 = load i64, ptr %l870, !tbaa !24
  store i64 %t1556, ptr %l98, !tbaa !24
  %t1557 = load i64, ptr %l88, !tbaa !24
  %t1558 = load i64, ptr %l98, !tbaa !24
  %t1560 = icmp sge i64 %t1558, 0
  %t1563 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t1564 = load ptr, ptr %t1563, !tbaa !27
  %t1565 = getelementptr i1, ptr %t1564, i64 %t1557
  store i1 %t1560, ptr %t1565, !tbaa !31
  %t1566 = load i64, ptr %l98, !tbaa !24
  %t1568 = icmp sge i64 %t1566, 0
  br i1 %t1568, label %bb375, label %bb376
bb375:
  %t1570 = load i64, ptr %l98, !tbaa !24
  store i64 %t1570, ptr %l876, !tbaa !24
  br label %bb380
bb376:
  %t1572 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1572, ptr %l878, !tbaa !29
  %t1573 = load ptr, ptr %l0, !tbaa !29
  %t1575 = getelementptr %"compiler/check:Checker", ptr %t1573, i32 0, i32 38
  store ptr %t1575, ptr %l880, !tbaa !29
  %t1576 = load i64, ptr %l88, !tbaa !24
  %t1579 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l10, i64 %t1576)
  store i64 %t1579, ptr %l883
  br label %bb377
bb377:
  %t1580 = load ptr, ptr %l880, !tbaa !29
  %t1581 = load i64, ptr %l883, !tbaa !24
  %t1582 = call %"compiler/check:atRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %s44, ptr %t1580, i64 %t1581)
  store %"compiler/check:atRec" %t1582, ptr %l884
  br label %bb378
bb378:
  %t1583 = getelementptr %"compiler/check:atRec", ptr %l884, i32 0, i32 3
  %t1584 = load i32, ptr %t1583, !tbaa !23
  %t1585 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t1587 = extractvalue { i64, ptr } %t1585, 0
  %t1588 = load ptr, ptr %l878, !tbaa !29
  %t1591 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s44, ptr %t1588, i32 %t1584, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d18, i32 0, i32 1) }, i64 %t1587)
  store i64 %t1591, ptr %l888
  br label %bb379
bb379:
  %t1592 = load i64, ptr %l888, !tbaa !24
  store i64 %t1592, ptr %l876, !tbaa !24
  br label %bb380
bb380:
  %t1593 = load i64, ptr %l876, !tbaa !24
  %t1594 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1594, ptr %l889, !tbaa !29
  %t1595 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1595, ptr %l890
  %t1596 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1596, ptr %l891
  store i64 %t1593, ptr %l892, !tbaa !24
  %t1598 = load ptr, ptr %l0, !tbaa !29
  %t1599 = load %"compiler/source:Span", ptr %l1
  %t1600 = load ptr, ptr %l89, !tbaa !29
  %t1604 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t1598, %"compiler/source:Span" %t1599, ptr %t1600)
  store ptr %t1604, ptr %l896
  br label %bb381
bb381:
  %t1605 = load ptr, ptr %l896, !tbaa !29
  store ptr %t1605, ptr %l897, !tbaa !29
  %t1606 = icmp sge i64 0, 0
  br i1 %t1606, label %bb382, label %bb383
bb382:
  %t1608 = icmp sle i64 0, 1152921504606846975
  br i1 %t1608, label %bb384, label %bb385
bb383:
  call void @__olang_check_failed(ptr @olang_loc_1e80b96f97cf3962_d4e3965ce5124a3e)
  unreachable
bb384:
  %t1610 = mul i64 0, 8
  %t1611 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1612 = insertvalue { i64, ptr } %t1611, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1612, ptr %l900, !tbaa !27
  %t1613 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t1613, ptr %l901, !tbaa !27
  %t1614 = icmp sge i64 0, 0
  br i1 %t1614, label %bb386, label %bb387
bb385:
  call void @__olang_check_failed(ptr @olang_loc_1e80b96f97cf3962_d4e3965ce5124a3e)
  unreachable
bb386:
  %t1616 = icmp sle i64 0, 2305843009213693951
  br i1 %t1616, label %bb388, label %bb389
bb387:
  call void @__olang_check_failed(ptr @olang_loc_f5f2ded9311e9d81_bb624a8d0118ae7d)
  unreachable
bb388:
  %t1618 = mul i64 0, 4
  %t1619 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1620 = insertvalue { i64, ptr } %t1619, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1621 = load ptr, ptr %l889, !tbaa !29
  %t1622 = load %"compiler/source:Span", ptr %l890
  %t1623 = load %"compiler/source:Span", ptr %l891
  %t1624 = load i64, ptr %l892, !tbaa !24
  %t1625 = load ptr, ptr %l897, !tbaa !29
  %t1626 = load { i64, ptr }, ptr %l900, !tbaa !27
  %t1627 = load { i64, ptr }, ptr %l901, !tbaa !27
  %t1629 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1621, %"compiler/source:Span" %t1622, %"compiler/source:Span" %t1623, i64 %t1624, ptr %t1625, { i64, ptr } %t1626, { i64, ptr } %t1627, { i64, ptr } %t1620)
  store ptr %t1629, ptr %l905
  br label %bb390
bb389:
  call void @__olang_check_failed(ptr @olang_loc_f5f2ded9311e9d81_bb624a8d0118ae7d)
  unreachable
bb390:
  %t1630 = load ptr, ptr %l905, !tbaa !29
  store ptr %t1630, ptr %l100, !tbaa !29
  %t1631 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1631, ptr %l906, !tbaa !29
  %t1632 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1632, ptr %l907
  %t1633 = load ptr, ptr %l100, !tbaa !29
  %t1636 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1633)
  store i32 %t1636, ptr %l910
  br label %bb391
bb391:
  %t1637 = load ptr, ptr %l906, !tbaa !29
  %t1638 = load %"compiler/source:Span", ptr %l907
  %t1639 = load i32, ptr %l910, !tbaa !23
  %t1640 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t1637, %"compiler/source:Span" %t1638, i32 %t1639)
  store i64 %t1640, ptr %l911
  br label %bb392
bb392:
  %t1641 = load i64, ptr %l911, !tbaa !24
  store i64 %t1641, ptr %l101, !tbaa !24
  %t1642 = load ptr, ptr %l0, !tbaa !29
  %t1643 = load %"compiler/source:Span", ptr %l1
  %t1644 = load i64, ptr %l101, !tbaa !24
  %t1646 = trunc i64 %t1644 to i32
  %t1648 = load ptr, ptr %l100, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t1649
  %t1650 = getelementptr { i64, [3 x i64] }, ptr %t1649, i32 0, i32 0
  store i64 0, ptr %t1650
  %t1652 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1643, 0
  %t1654 = insertvalue { %"compiler/source:Span", i32, ptr } %t1652, i32 %t1646, 1
  %t1656 = insertvalue { %"compiler/source:Span", i32, ptr } %t1654, ptr %t1648, 2
  %t1657 = getelementptr { i64, [3 x i64] }, ptr %t1649, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1656, ptr %t1657
  %t1658 = load { i64, [3 x i64] }, ptr %t1649
  %t1660 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1658, ptr %t1660
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1642, ptr %t1660)
  br label %bb393
bb393:
  %t1663 = load i64, ptr %l88, !tbaa !24
  %t1664 = load i64, ptr %l101, !tbaa !24
  %t1667 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t1668 = load ptr, ptr %t1667, !tbaa !27
  %t1669 = getelementptr i64, ptr %t1668, i64 %t1663
  store i64 %t1664, ptr %t1669, !tbaa !34
  call void @__olang_scope_close(ptr %s44)
  br label %bb394
bb394:
  %t1670 = load i64, ptr %l86, !tbaa !24
  %t1672 = add i64 %t1670, 1
  store i64 %t1672, ptr %l86, !tbaa !24
  br label %bb341
bb395:
  %t1674 = load ptr, ptr %l0, !tbaa !29
  %t1675 = load ptr, ptr %l3, !tbaa !29
  %t1676 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t1677 = load ptr, ptr %t1676, !tbaa !27
  %t1678 = getelementptr i64, ptr %t1677, i64 0
  %t1679 = load i64, ptr %t1678, !tbaa !34
  %t1683 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %v1, ptr %v1, ptr %t1674, ptr %t1675, i64 %t1679)
  store ptr %t1683, ptr %l927
  br label %bb396
bb396:
  %t1684 = load ptr, ptr %l927, !tbaa !29
  store ptr %t1684, ptr %l102, !tbaa !29
  %t1685 = load ptr, ptr %l0, !tbaa !29
  %t1686 = load ptr, ptr %l102, !tbaa !29
  %t1687 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %t1685, ptr %t1686, %"compiler/source:Span" %t1687)
  br label %bb397
bb397:
  %t1691 = load i1, ptr %l71, !tbaa !21
  br i1 %t1691, label %bb398, label %bb399
bb398:
  %t1693 = load ptr, ptr %l64, !tbaa !29
  store ptr %t1693, ptr %l932, !tbaa !29
  br label %bb401
bb399:
  %t1695 = load ptr, ptr %l0, !tbaa !29
  %t1696 = load %"compiler/source:Span", ptr %l1
  %t1697 = load i64, ptr %l72, !tbaa !24
  %t1701 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t1695, %"compiler/source:Span" %t1696, i64 %t1697)
  store ptr %t1701, ptr %l937
  br label %bb400
bb400:
  %t1702 = load ptr, ptr %l937, !tbaa !29
  store ptr %t1702, ptr %l932, !tbaa !29
  br label %bb401
bb401:
  %t1704 = load ptr, ptr %l932, !tbaa !29
  store ptr %t1704, ptr %l103, !tbaa !29
  %t1705 = load i64, ptr %l6, !tbaa !24
  %t1707 = icmp sge i64 %t1705, 0
  br i1 %t1707, label %bb402, label %bb403
bb402:
  %t1710 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l52)
  store i64 %t1710, ptr %l942
  br label %bb404
bb403:
  %t1711 = load i64, ptr %l65, !tbaa !24
  %t1713 = icmp sge i64 %t1711, 0
  br i1 %t1713, label %bb440, label %bb441
bb404:
  %t1715 = load i64, ptr %l942, !tbaa !24
  %t1716 = add i64 %t1715, 1
  store i64 %t1716, ptr %l943, !tbaa !24
  %t1717 = load ptr, ptr %l0, !tbaa !29
  %t1718 = load %"compiler/source:Span", ptr %l1
  %t1721 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v0, ptr %t1717, %"compiler/source:Span" %t1718)
  store ptr %t1721, ptr %l946
  br label %bb405
bb405:
  %t1722 = load i64, ptr %l943, !tbaa !24
  %t1723 = icmp sge i64 %t1722, 0
  br i1 %t1723, label %bb406, label %bb407
bb406:
  %t1725 = load i64, ptr %l943, !tbaa !24
  %t1726 = icmp sle i64 %t1725, 1152921504606846975
  br i1 %t1726, label %bb408, label %bb409
bb407:
  call void @__olang_check_failed(ptr @olang_loc_44f96d5c56a14674_ff860f9933920150)
  unreachable
bb408:
  %t1728 = load i64, ptr %l943, !tbaa !24
  %t1729 = mul i64 %t1728, 8
  %t1730 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1729)
  %t1731 = load ptr, ptr %l946, !tbaa !29
  store i64 0, ptr %t1732
  br label %fill.1733
fill.1733:
  %t1736 = load i64, ptr %t1732
  %t1737 = icmp slt i64 %t1736, %t1728
  br i1 %t1737, label %fillb.1734, label %filld.1735
fillb.1734:
  %t1738 = getelementptr ptr, ptr %t1730, i64 %t1736
  store ptr %t1731, ptr %t1738
  %t1739 = add i64 %t1736, 1
  store i64 %t1739, ptr %t1732
  br label %fill.1733
filld.1735:
  %t1740 = insertvalue { i64, ptr } undef, i64 %t1728, 0
  %t1741 = insertvalue { i64, ptr } %t1740, ptr %t1730, 1
  store { i64, ptr } %t1741, ptr %l104, !tbaa !27
  store i64 0, ptr %l105, !tbaa !24
  %t1744 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l52)
  store i64 %t1744, ptr %l951
  br label %bb410
bb409:
  call void @__olang_check_failed(ptr @olang_loc_44f96d5c56a14674_ff860f9933920150)
  unreachable
bb410:
  %t1745 = load i64, ptr %l951, !tbaa !24
  store i64 %t1745, ptr %l106, !tbaa !24
  store i64 1, ptr %l107, !tbaa !24
  %t1746 = load i64, ptr %l106, !tbaa !24
  %t1747 = load i64, ptr %l105, !tbaa !24
  %t1750 = icmp sgt i64 %t1746, %t1747
  br i1 %t1750, label %bb411, label %bb412
bb411:
  %t1752 = load i64, ptr %l107, !tbaa !24
  %t1754 = icmp sgt i64 %t1752, 0
  br i1 %t1754, label %bb413, label %bb414
bb412:
  store i64 0, ptr %l955, !tbaa !24
  br label %bb416
bb413:
  %t1756 = load i64, ptr %l106, !tbaa !24
  %t1757 = load i64, ptr %l105, !tbaa !24
  %t1760 = sub i64 %t1756, %t1757
  %t1761 = load i64, ptr %l107, !tbaa !24
  %t1764 = add i64 %t1760, %t1761
  %t1766 = sub i64 %t1764, 1
  %t1767 = load i64, ptr %l107, !tbaa !24
  %t1770 = sdiv i64 %t1766, %t1767
  store i64 %t1770, ptr %l958, !tbaa !24
  br label %bb415
bb414:
  store i64 0, ptr %l958, !tbaa !24
  br label %bb415
bb415:
  %t1772 = load i64, ptr %l958, !tbaa !24
  store i64 %t1772, ptr %l955, !tbaa !24
  br label %bb416
bb416:
  %t1773 = load i64, ptr %l955, !tbaa !24
  store i64 %t1773, ptr %l108, !tbaa !24
  store i64 0, ptr %l109, !tbaa !24
  br label %bb417
bb417:
  %t1774 = load i64, ptr %l109, !tbaa !24
  %t1775 = load i64, ptr %l108, !tbaa !24
  %t1778 = icmp slt i64 %t1774, %t1775
  %t1780 = xor i1 %t1778, true
  br i1 %t1780, label %bb418, label %bb419
bb418:
  br label %bb424
bb419:
  br label %bb420
bb420:
  %t1782 = load i64, ptr %l105, !tbaa !24
  %t1783 = load i64, ptr %l109, !tbaa !24
  %t1784 = load i64, ptr %l107, !tbaa !24
  %t1787 = mul i64 %t1783, %t1784
  %t1790 = add i64 %t1782, %t1787
  store i64 %t1790, ptr %l110, !tbaa !24
  %t1792 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t1792, ptr %l976, !tbaa !27
  %t1793 = load i64, ptr %l110, !tbaa !24
  store i64 %t1793, ptr %l977, !tbaa !24
  %t1794 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1794, ptr %l978, !tbaa !29
  %t1795 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1795, ptr %l979
  %t1796 = load i64, ptr %l110, !tbaa !24
  %t1799 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l52, i64 %t1796)
  store i64 %t1799, ptr %l982
  br label %bb421
bb421:
  %t1800 = load ptr, ptr %l978, !tbaa !29
  %t1801 = load %"compiler/source:Span", ptr %l979
  %t1802 = load i64, ptr %l982, !tbaa !24
  %t1803 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t1800, %"compiler/source:Span" %t1801, i64 %t1802)
  store ptr %t1803, ptr %l983
  br label %bb422
bb422:
  %t1804 = load ptr, ptr %l983, !tbaa !29
  %t1805 = load i64, ptr %l977, !tbaa !24
  %t1806 = getelementptr { i64, ptr }, ptr %l976, i32 0, i32 1
  %t1807 = load ptr, ptr %t1806, !tbaa !27
  %t1808 = getelementptr ptr, ptr %t1807, i64 %t1805
  store ptr %t1804, ptr %t1808, !tbaa !39
  br label %bb423
bb423:
  %t1809 = load i64, ptr %l109, !tbaa !24
  %t1811 = add i64 %t1809, 1
  store i64 %t1811, ptr %l109, !tbaa !24
  br label %bb417
bb424:
  %t1813 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t1813, ptr %l986, !tbaa !27
  %t1815 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l52)
  store i64 %t1815, ptr %l988
  br label %bb425
bb425:
  %t1816 = load ptr, ptr %l103, !tbaa !29
  %t1818 = icmp eq ptr %t1816, null
  br i1 %t1818, label %bb426, label %bb427
bb426:
  call void @__olang_check_failed(ptr @olang_loc_e884266833675005_1350b544c014e651)
  unreachable
bb427:
  br label %bb428
bb428:
  %t1820 = load ptr, ptr %l103, !tbaa !29
  %t1822 = load i64, ptr %l988, !tbaa !24
  %t1823 = getelementptr { i64, ptr }, ptr %l986, i32 0, i32 1
  %t1824 = load ptr, ptr %t1823, !tbaa !27
  %t1825 = getelementptr ptr, ptr %t1824, i64 %t1822
  store ptr %t1820, ptr %t1825, !tbaa !39
  %t1826 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1826, ptr %l992, !tbaa !29
  %t1827 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1827, ptr %l993
  %t1828 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1828, ptr %l994, !tbaa !29
  %t1829 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1829, ptr %l995
  %t1830 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1830, ptr %l996
  %t1831 = load i64, ptr %l6, !tbaa !24
  store i64 %t1831, ptr %l997, !tbaa !24
  %t1832 = load ptr, ptr %l0, !tbaa !29
  %t1833 = load %"compiler/source:Span", ptr %l1
  %t1834 = load ptr, ptr %l102, !tbaa !29
  %t1838 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v0, ptr %t1832, %"compiler/source:Span" %t1833, ptr %t1834)
  store ptr %t1838, ptr %l1001
  br label %bb429
bb429:
  %t1839 = load ptr, ptr %l1001, !tbaa !29
  store ptr %t1839, ptr %l1002, !tbaa !29
  %t1840 = icmp sge i64 0, 0
  br i1 %t1840, label %bb430, label %bb431
bb430:
  %t1842 = icmp sle i64 0, 1152921504606846975
  br i1 %t1842, label %bb432, label %bb433
bb431:
  call void @__olang_check_failed(ptr @olang_loc_c1ca3a4930838c76_683816946b44ecaa)
  unreachable
bb432:
  %t1844 = mul i64 0, 8
  %t1845 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1846 = insertvalue { i64, ptr } %t1845, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t1846, ptr %l1005, !tbaa !27
  %t1847 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t1847, ptr %l1006, !tbaa !27
  %t1848 = icmp sge i64 0, 0
  br i1 %t1848, label %bb434, label %bb435
bb433:
  call void @__olang_check_failed(ptr @olang_loc_c1ca3a4930838c76_683816946b44ecaa)
  unreachable
bb434:
  %t1850 = icmp sle i64 0, 2305843009213693951
  br i1 %t1850, label %bb436, label %bb437
bb435:
  call void @__olang_check_failed(ptr @olang_loc_f5f2ded9311e9d81_bb624a8d0118ae7d)
  unreachable
bb436:
  %t1852 = mul i64 0, 4
  %t1853 = insertvalue { i64, ptr } undef, i64 0, 0
  %t1854 = insertvalue { i64, ptr } %t1853, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t1855 = load ptr, ptr %l994, !tbaa !29
  %t1856 = load %"compiler/source:Span", ptr %l995
  %t1857 = load %"compiler/source:Span", ptr %l996
  %t1858 = load i64, ptr %l997, !tbaa !24
  %t1859 = load ptr, ptr %l1002, !tbaa !29
  %t1860 = load { i64, ptr }, ptr %l1005, !tbaa !27
  %t1861 = load { i64, ptr }, ptr %l1006, !tbaa !27
  %t1863 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1855, %"compiler/source:Span" %t1856, %"compiler/source:Span" %t1857, i64 %t1858, ptr %t1859, { i64, ptr } %t1860, { i64, ptr } %t1861, { i64, ptr } %t1854)
  store ptr %t1863, ptr %l1010
  br label %bb438
bb437:
  call void @__olang_check_failed(ptr @olang_loc_f5f2ded9311e9d81_bb624a8d0118ae7d)
  unreachable
bb438:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1864
  %t1865 = getelementptr { i64, [3 x i64] }, ptr %t1864, i32 0, i32 0
  store i64 2, ptr %t1865
  %t1866 = load %"compiler/source:Span", ptr %l993
  %t1867 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1866, 0
  %t1868 = load ptr, ptr %l1010, !tbaa !29
  %t1869 = insertvalue { %"compiler/source:Span", ptr } %t1867, ptr %t1868, 1
  %t1870 = getelementptr { i64, [3 x i64] }, ptr %t1864, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1869, ptr %t1870
  %t1871 = load { i64, [3 x i64] }, ptr %t1864
  %t1873 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1871, ptr %t1873
  %t1874 = load ptr, ptr %l992, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1874, ptr %t1873)
  br label %bb439
bb439:
  br label %bb466
bb440:
  %t1876 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1876, ptr %l1015, !tbaa !29
  %t1877 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1877, ptr %l1016
  %t1878 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t1878, ptr %l1017
  %t1879 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1881 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t1879)
  store i32 %t1881, ptr %l1019
  br label %bb442
bb441:
  %t1882 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1884 = trunc i64 68 to i32
  %t1885 = icmp eq i32 %t1882, %t1884
  br i1 %t1885, label %bb445, label %bb446
bb442:
  %t1887 = load i32, ptr %l51, !tbaa !23
  store i32 %t1887, ptr %l1020, !tbaa !23
  %t1888 = load ptr, ptr %l0, !tbaa !29
  %t1889 = load %"compiler/source:Span", ptr %l1
  %t1890 = load ptr, ptr %l102, !tbaa !29
  %t1894 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTarget(ptr %v0, ptr %v1, ptr %t1888, %"compiler/source:Span" %t1889, ptr %t1890)
  store i64 %t1894, ptr %l1024
  br label %bb443
bb443:
  %t1895 = load i64, ptr %l65, !tbaa !24
  %t1896 = load ptr, ptr %l1015, !tbaa !29
  %t1897 = load %"compiler/source:Span", ptr %l1016
  %t1898 = load %"compiler/source:Span", ptr %l1017
  %t1899 = load i32, ptr %l1019, !range !{i32 0, i32 98}
  %t1900 = load i32, ptr %l1020, !tbaa !23
  %t1901 = load i64, ptr %l1024, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneStore(ptr %v0, ptr %s0, ptr %t1896, %"compiler/source:Span" %t1897, %"compiler/source:Span" %t1898, i32 %t1899, i32 %t1900, i64 %t1901, i64 %t1895, ptr %l66)
  br label %bb444
bb444:
  br label %bb465
bb445:
  %t1904 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1904, ptr %l1029, !tbaa !29
  %t1905 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1905, ptr %l1030, !tbaa !29
  %t1906 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1906, ptr %l1031
  %t1907 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t1907, ptr %l1032
  %t1908 = load ptr, ptr %l0, !tbaa !29
  %t1909 = load %"compiler/source:Span", ptr %l1
  %t1910 = load %"compiler/source:Span", ptr %l1
  %t1911 = load i32, ptr %l51, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t1912
  %t1913 = getelementptr { i64, [4 x i64] }, ptr %t1912, i32 0, i32 0
  store i64 7, ptr %t1913
  %t1915 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t1910, 0
  %t1917 = insertvalue { %"compiler/source:Span", i32 } %t1915, i32 %t1911, 1
  %t1918 = getelementptr { i64, [4 x i64] }, ptr %t1912, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t1917, ptr %t1918
  %t1919 = load { i64, [4 x i64] }, ptr %t1912
  %t1921 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1919, ptr %t1921
  %t1925 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t1908, %"compiler/source:Span" %t1909, ptr %t1921)
  store ptr %t1925, ptr %l1039
  br label %bb447
bb446:
  %t1926 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1928 = trunc i64 62 to i32
  %t1929 = icmp eq i32 %t1926, %t1928
  %t1931 = xor i1 %t1929, true
  br i1 %t1931, label %bb453, label %bb454
bb447:
  %t1933 = load ptr, ptr %l103, !tbaa !29
  %t1935 = icmp eq ptr %t1933, null
  br i1 %t1935, label %bb448, label %bb449
bb448:
  call void @__olang_check_failed(ptr @olang_loc_ac1acea96ae6618f_a282f6741fbb5f4b)
  unreachable
bb449:
  br label %bb450
bb450:
  %t1937 = load ptr, ptr %l103, !tbaa !29
  %t1938 = load ptr, ptr %l1030, !tbaa !29
  %t1939 = load %"compiler/source:Span", ptr %l1031
  %t1940 = load %"compiler/source:Span", ptr %l1032
  %t1941 = load ptr, ptr %l1039, !tbaa !29
  %t1943 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1938, %"compiler/source:Span" %t1939, %"compiler/source:Span" %t1940, ptr %t1941, ptr %t1937)
  store ptr %t1943, ptr %l1043
  br label %bb451
bb451:
  %t1944 = load i32, ptr %l51, !tbaa !23
  %t1945 = load %"compiler/source:Span", ptr %l1
  %t1946 = load ptr, ptr %l1029, !tbaa !29
  %t1947 = load ptr, ptr %l1043, !tbaa !29
  %t1950 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t1946, ptr %t1947, i32 %t1944, %"compiler/source:Span" %t1945)
  store ptr %t1950, ptr %l1046
  br label %bb452
bb452:
  %t1951 = load ptr, ptr %l1046, !tbaa !29
  store ptr %t1951, ptr %l103, !tbaa !29
  br label %bb460
bb453:
  %t1953 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1953, ptr %l1051, !tbaa !29
  %t1954 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1954, ptr %l1052
  %t1955 = load i32, ptr %l51, !tbaa !23
  store i32 %t1955, ptr %l1053, !tbaa !23
  %t1956 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t1958 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t1956)
  store i32 %t1958, ptr %l1055
  br label %bb455
bb454:
  br label %bb459
bb455:
  %t1959 = load i32, ptr %l1055, !range !{i32 0, i32 98}
  %t1960 = call i32 @compiler_2fcheck_2ebinaryOp(i32 %t1959)
  store i32 %t1960, ptr %l1056
  br label %bb456
bb456:
  %t1961 = load ptr, ptr %l0, !tbaa !29
  %t1962 = load %"compiler/source:Span", ptr %l1
  %t1963 = load %"compiler/source:Span", ptr %l1
  %t1964 = load i32, ptr %l51, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t1965
  %t1966 = getelementptr { i64, [4 x i64] }, ptr %t1965, i32 0, i32 0
  store i64 7, ptr %t1966
  %t1968 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t1963, 0
  %t1970 = insertvalue { %"compiler/source:Span", i32 } %t1968, i32 %t1964, 1
  %t1971 = getelementptr { i64, [4 x i64] }, ptr %t1965, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t1970, ptr %t1971
  %t1972 = load { i64, [4 x i64] }, ptr %t1965
  %t1974 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1972, ptr %t1974
  %t1978 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t1961, %"compiler/source:Span" %t1962, ptr %t1974)
  store ptr %t1978, ptr %l1063
  br label %bb457
bb457:
  %t1979 = load ptr, ptr %l103, !tbaa !29
  %t1980 = load ptr, ptr %l1051, !tbaa !29
  %t1981 = load %"compiler/source:Span", ptr %l1052
  %t1982 = load i32, ptr %l1053, !tbaa !23
  %t1983 = load i32, ptr %l1056, !range !{i32 0, i32 49}
  %t1984 = load ptr, ptr %l1063, !tbaa !29
  %t1986 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1980, %"compiler/source:Span" %t1981, i32 %t1982, i32 %t1983, ptr %t1984, ptr %t1979)
  store ptr %t1986, ptr %l1065
  br label %bb458
bb458:
  %t1987 = load ptr, ptr %l1065, !tbaa !29
  store ptr %t1987, ptr %l103, !tbaa !29
  br label %bb459
bb459:
  br label %bb460
bb460:
  %t1989 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1989, ptr %l1067, !tbaa !29
  %t1990 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1990, ptr %l1068
  %t1991 = load ptr, ptr %l102, !tbaa !29
  store ptr %t1991, ptr %l1069, !tbaa !29
  %t1992 = load ptr, ptr %l103, !tbaa !29
  %t1994 = icmp eq ptr %t1992, null
  br i1 %t1994, label %bb461, label %bb462
bb461:
  call void @__olang_check_failed(ptr @olang_loc_eccd8b6a5c2fa6b0_78891c232bd2a45c)
  unreachable
bb462:
  br label %bb463
bb463:
  %t1996 = load ptr, ptr %l103, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t1997
  %t1998 = getelementptr { i64, [3 x i64] }, ptr %t1997, i32 0, i32 0
  store i64 1, ptr %t1998
  %t1999 = load %"compiler/source:Span", ptr %l1068
  %t2000 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t1999, 0
  %t2001 = load ptr, ptr %l1069, !tbaa !29
  %t2002 = insertvalue { %"compiler/source:Span", ptr, ptr } %t2000, ptr %t2001, 1
  %t2004 = insertvalue { %"compiler/source:Span", ptr, ptr } %t2002, ptr %t1996, 2
  %t2005 = getelementptr { i64, [3 x i64] }, ptr %t1997, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t2004, ptr %t2005
  %t2006 = load { i64, [3 x i64] }, ptr %t1997
  %t2008 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t2006, ptr %t2008
  %t2009 = load ptr, ptr %l1067, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t2009, ptr %t2008)
  br label %bb464
bb464:
  br label %bb465
bb465:
  br label %bb466
bb466:
  store i64 0, ptr %l111, !tbaa !24
  %t2011 = load i64, ptr %l16, !tbaa !24
  store i64 %t2011, ptr %l112, !tbaa !24
  store i64 1, ptr %l113, !tbaa !24
  %t2013 = load i64, ptr %l112, !tbaa !24
  %t2014 = load i64, ptr %l111, !tbaa !24
  %t2017 = icmp sgt i64 %t2013, %t2014
  br i1 %t2017, label %bb467, label %bb468
bb467:
  %t2019 = load i64, ptr %l113, !tbaa !24
  %t2021 = icmp sgt i64 %t2019, 0
  br i1 %t2021, label %bb469, label %bb470
bb468:
  store i64 0, ptr %l1079, !tbaa !24
  br label %bb472
bb469:
  %t2023 = load i64, ptr %l112, !tbaa !24
  %t2024 = load i64, ptr %l111, !tbaa !24
  %t2027 = sub i64 %t2023, %t2024
  %t2028 = load i64, ptr %l113, !tbaa !24
  %t2031 = add i64 %t2027, %t2028
  %t2033 = sub i64 %t2031, 1
  %t2034 = load i64, ptr %l113, !tbaa !24
  %t2037 = sdiv i64 %t2033, %t2034
  store i64 %t2037, ptr %l1082, !tbaa !24
  br label %bb471
bb470:
  store i64 0, ptr %l1082, !tbaa !24
  br label %bb471
bb471:
  %t2039 = load i64, ptr %l1082, !tbaa !24
  store i64 %t2039, ptr %l1079, !tbaa !24
  br label %bb472
bb472:
  %t2040 = load i64, ptr %l1079, !tbaa !24
  store i64 %t2040, ptr %l114, !tbaa !24
  store i64 0, ptr %l115, !tbaa !24
  br label %bb473
bb473:
  %t2041 = load i64, ptr %l115, !tbaa !24
  %t2042 = load i64, ptr %l114, !tbaa !24
  %t2045 = icmp slt i64 %t2041, %t2042
  %t2047 = xor i1 %t2045, true
  br i1 %t2047, label %bb474, label %bb475
bb474:
  br label %bb517
bb475:
  br label %bb476
bb476:
  %t2049 = load i64, ptr %l111, !tbaa !24
  %t2050 = load i64, ptr %l115, !tbaa !24
  %t2051 = load i64, ptr %l113, !tbaa !24
  %t2054 = mul i64 %t2050, %t2051
  %t2057 = add i64 %t2049, %t2054
  store i64 %t2057, ptr %l116, !tbaa !24
  %t2059 = load i64, ptr %l116, !tbaa !24
  %t2061 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t2062 = load ptr, ptr %t2061, !tbaa !27
  %t2063 = getelementptr i1, ptr %t2062, i64 %t2059
  %t2064 = load i1, ptr %t2063, !tbaa !31
  br i1 %t2064, label %bb477, label %bb478
bb477:
  br label %bb516
bb478:
  br label %bb479
bb479:
  %t2066 = load ptr, ptr %l27, !tbaa !29
  %t2067 = load i64, ptr %l116, !tbaa !24
  %t2070 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %s0, ptr %s0, ptr %t2066, i64 %t2067)
  store { i64, ptr } %t2070, ptr %l1104
  br label %bb480
bb480:
  %t2071 = load { i64, ptr }, ptr %l1104, !tbaa !27
  store { i64, ptr } %t2071, ptr %l117, !tbaa !27
  %t2072 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t2074 = extractvalue { i64, ptr } %t2072, 0
  %t2076 = add i64 %t2074, 1
  store i64 %t2076, ptr %l1107, !tbaa !24
  %t2077 = load ptr, ptr %l0, !tbaa !29
  %t2078 = load %"compiler/source:Span", ptr %l1
  %t2081 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v0, ptr %t2077, %"compiler/source:Span" %t2078)
  store ptr %t2081, ptr %l1110
  br label %bb481
bb481:
  %t2082 = load i64, ptr %l1107, !tbaa !24
  %t2083 = icmp sge i64 %t2082, 0
  br i1 %t2083, label %bb482, label %bb483
bb482:
  %t2085 = load i64, ptr %l1107, !tbaa !24
  %t2086 = icmp sle i64 %t2085, 1152921504606846975
  br i1 %t2086, label %bb484, label %bb485
bb483:
  call void @__olang_check_failed(ptr @olang_loc_f0e5921914b2a2cf_65ed047d8124f4fb)
  unreachable
bb484:
  %t2088 = load i64, ptr %l1107, !tbaa !24
  %t2089 = mul i64 %t2088, 8
  %t2090 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t2089)
  %t2091 = load ptr, ptr %l1110, !tbaa !29
  store i64 0, ptr %t2092
  br label %fill.2093
fill.2093:
  %t2096 = load i64, ptr %t2092
  %t2097 = icmp slt i64 %t2096, %t2088
  br i1 %t2097, label %fillb.2094, label %filld.2095
fillb.2094:
  %t2098 = getelementptr ptr, ptr %t2090, i64 %t2096
  store ptr %t2091, ptr %t2098
  %t2099 = add i64 %t2096, 1
  store i64 %t2099, ptr %t2092
  br label %fill.2093
filld.2095:
  %t2100 = insertvalue { i64, ptr } undef, i64 %t2088, 0
  %t2101 = insertvalue { i64, ptr } %t2100, ptr %t2090, 1
  store { i64, ptr } %t2101, ptr %l118, !tbaa !27
  store i64 0, ptr %l119, !tbaa !24
  %t2103 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t2105 = extractvalue { i64, ptr } %t2103, 0
  store i64 %t2105, ptr %l120, !tbaa !24
  store i64 1, ptr %l121, !tbaa !24
  %t2107 = load i64, ptr %l120, !tbaa !24
  %t2108 = load i64, ptr %l119, !tbaa !24
  %t2111 = icmp sgt i64 %t2107, %t2108
  br i1 %t2111, label %bb486, label %bb487
bb485:
  call void @__olang_check_failed(ptr @olang_loc_f0e5921914b2a2cf_65ed047d8124f4fb)
  unreachable
bb486:
  %t2113 = load i64, ptr %l121, !tbaa !24
  %t2115 = icmp sgt i64 %t2113, 0
  br i1 %t2115, label %bb488, label %bb489
bb487:
  store i64 0, ptr %l1119, !tbaa !24
  br label %bb491
bb488:
  %t2117 = load i64, ptr %l120, !tbaa !24
  %t2118 = load i64, ptr %l119, !tbaa !24
  %t2121 = sub i64 %t2117, %t2118
  %t2122 = load i64, ptr %l121, !tbaa !24
  %t2125 = add i64 %t2121, %t2122
  %t2127 = sub i64 %t2125, 1
  %t2128 = load i64, ptr %l121, !tbaa !24
  %t2131 = sdiv i64 %t2127, %t2128
  store i64 %t2131, ptr %l1122, !tbaa !24
  br label %bb490
bb489:
  store i64 0, ptr %l1122, !tbaa !24
  br label %bb490
bb490:
  %t2133 = load i64, ptr %l1122, !tbaa !24
  store i64 %t2133, ptr %l1119, !tbaa !24
  br label %bb491
bb491:
  %t2134 = load i64, ptr %l1119, !tbaa !24
  store i64 %t2134, ptr %l122, !tbaa !24
  store i64 0, ptr %l123, !tbaa !24
  br label %bb492
bb492:
  %t2135 = load i64, ptr %l123, !tbaa !24
  %t2136 = load i64, ptr %l122, !tbaa !24
  %t2139 = icmp slt i64 %t2135, %t2136
  %t2141 = xor i1 %t2139, true
  br i1 %t2141, label %bb493, label %bb494
bb493:
  br label %bb498
bb494:
  br label %bb495
bb495:
  %t2143 = load i64, ptr %l119, !tbaa !24
  %t2144 = load i64, ptr %l123, !tbaa !24
  %t2145 = load i64, ptr %l121, !tbaa !24
  %t2148 = mul i64 %t2144, %t2145
  %t2151 = add i64 %t2143, %t2148
  store i64 %t2151, ptr %l124, !tbaa !24
  %t2153 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t2153, ptr %l1140, !tbaa !27
  %t2154 = load i64, ptr %l124, !tbaa !24
  store i64 %t2154, ptr %l1141, !tbaa !24
  %t2155 = load ptr, ptr %l0, !tbaa !29
  %t2156 = load %"compiler/source:Span", ptr %l1
  %t2157 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t2157, ptr %l1144, !tbaa !27
  %t2158 = load i64, ptr %l124, !tbaa !24
  %t2160 = getelementptr { i64, ptr }, ptr %l1144, i32 0, i32 1
  %t2161 = load ptr, ptr %t2160, !tbaa !27
  %t2162 = getelementptr i64, ptr %t2161, i64 %t2158
  %t2163 = load i64, ptr %t2162, !tbaa !34
  %t2167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t2155, %"compiler/source:Span" %t2156, i64 %t2163)
  store ptr %t2167, ptr %l1147
  br label %bb496
bb496:
  %t2168 = load ptr, ptr %l1147, !tbaa !29
  %t2169 = load i64, ptr %l1141, !tbaa !24
  %t2170 = getelementptr { i64, ptr }, ptr %l1140, i32 0, i32 1
  %t2171 = load ptr, ptr %t2170, !tbaa !27
  %t2172 = getelementptr ptr, ptr %t2171, i64 %t2169
  store ptr %t2168, ptr %t2172, !tbaa !39
  br label %bb497
bb497:
  %t2173 = load i64, ptr %l123, !tbaa !24
  %t2175 = add i64 %t2173, 1
  store i64 %t2175, ptr %l123, !tbaa !24
  br label %bb492
bb498:
  %t2177 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t2177, ptr %l1150, !tbaa !27
  %t2178 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t2180 = extractvalue { i64, ptr } %t2178, 0
  store i64 %t2180, ptr %l1152, !tbaa !24
  %t2181 = load ptr, ptr %l0, !tbaa !29
  %t2182 = load %"compiler/source:Span", ptr %l1
  %t2183 = load i64, ptr %l116, !tbaa !24
  %t2185 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t2186 = load ptr, ptr %t2185, !tbaa !27
  %t2187 = getelementptr i64, ptr %t2186, i64 %t2183
  %t2188 = load i64, ptr %t2187, !tbaa !34
  %t2192 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t2181, %"compiler/source:Span" %t2182, i64 %t2188)
  store ptr %t2192, ptr %l1157
  br label %bb499
bb499:
  %t2193 = load ptr, ptr %l1157, !tbaa !29
  %t2194 = load i64, ptr %l1152, !tbaa !24
  %t2195 = getelementptr { i64, ptr }, ptr %l1150, i32 0, i32 1
  %t2196 = load ptr, ptr %t2195, !tbaa !27
  %t2197 = getelementptr ptr, ptr %t2196, i64 %t2194
  store ptr %t2193, ptr %t2197, !tbaa !39
  %t2198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2198, ptr %l1158, !tbaa !29
  %t2199 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2199, ptr %l1159
  %t2200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2200, ptr %l1160, !tbaa !29
  %t2201 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2201, ptr %l1161
  %t2202 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2202, ptr %l1162
  %t2203 = load i64, ptr %l116, !tbaa !24
  %t2206 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t2203)
  store i64 %t2206, ptr %l1165
  br label %bb500
bb500:
  %t2207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2207, ptr %l1166, !tbaa !29
  %t2208 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2208, ptr %l1167
  %t2209 = load ptr, ptr %l75, !tbaa !29
  %t2210 = load i64, ptr %l116, !tbaa !24
  %t2213 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v0, ptr %t2209, i64 %t2210)
  store ptr %t2213, ptr %l1170
  br label %bb501
bb501:
  %t2214 = load ptr, ptr %l1170, !tbaa !29
  store ptr %t2214, ptr %l125, !tbaa !29
  %t2215 = load ptr, ptr %l125, !tbaa !29
  %t2217 = icmp eq ptr %t2215, null
  br i1 %t2217, label %bb502, label %bb503
bb502:
  call void @__olang_check_failed(ptr @olang_loc_a07392af54ad709a_dc39b5b43cdaa0e)
  unreachable
bb503:
  br label %bb504
bb504:
  %t2219 = load ptr, ptr %l125, !tbaa !29
  %t2220 = load ptr, ptr %l1166, !tbaa !29
  %t2221 = load %"compiler/source:Span", ptr %l1167
  %t2223 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t2220, %"compiler/source:Span" %t2221, ptr %t2219)
  store ptr %t2223, ptr %l1174
  br label %bb505
bb505:
  %t2224 = load ptr, ptr %l1174, !tbaa !29
  store ptr %t2224, ptr %l1175, !tbaa !29
  %t2225 = icmp sge i64 0, 0
  br i1 %t2225, label %bb506, label %bb507
bb506:
  %t2227 = icmp sle i64 0, 1152921504606846975
  br i1 %t2227, label %bb508, label %bb509
bb507:
  call void @__olang_check_failed(ptr @olang_loc_daae6e7c52984fda_6773826fb422e0b6)
  unreachable
bb508:
  %t2229 = mul i64 0, 8
  %t2230 = insertvalue { i64, ptr } undef, i64 0, 0
  %t2231 = insertvalue { i64, ptr } %t2230, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t2231, ptr %l1178, !tbaa !27
  %t2232 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t2232, ptr %l1179, !tbaa !27
  %t2233 = icmp sge i64 0, 0
  br i1 %t2233, label %bb510, label %bb511
bb509:
  call void @__olang_check_failed(ptr @olang_loc_daae6e7c52984fda_6773826fb422e0b6)
  unreachable
bb510:
  %t2235 = icmp sle i64 0, 2305843009213693951
  br i1 %t2235, label %bb512, label %bb513
bb511:
  call void @__olang_check_failed(ptr @olang_loc_f5f2ded9311e9d81_bb624a8d0118ae7d)
  unreachable
bb512:
  %t2237 = mul i64 0, 4
  %t2238 = insertvalue { i64, ptr } undef, i64 0, 0
  %t2239 = insertvalue { i64, ptr } %t2238, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t2240 = load ptr, ptr %l1160, !tbaa !29
  %t2241 = load %"compiler/source:Span", ptr %l1161
  %t2242 = load %"compiler/source:Span", ptr %l1162
  %t2243 = load i64, ptr %l1165, !tbaa !24
  %t2244 = load ptr, ptr %l1175, !tbaa !29
  %t2245 = load { i64, ptr }, ptr %l1178, !tbaa !27
  %t2246 = load { i64, ptr }, ptr %l1179, !tbaa !27
  %t2248 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t2240, %"compiler/source:Span" %t2241, %"compiler/source:Span" %t2242, i64 %t2243, ptr %t2244, { i64, ptr } %t2245, { i64, ptr } %t2246, { i64, ptr } %t2239)
  store ptr %t2248, ptr %l1183
  br label %bb514
bb513:
  call void @__olang_check_failed(ptr @olang_loc_f5f2ded9311e9d81_bb624a8d0118ae7d)
  unreachable
bb514:
  store { i64, [3 x i64] } zeroinitializer, ptr %t2249
  %t2250 = getelementptr { i64, [3 x i64] }, ptr %t2249, i32 0, i32 0
  store i64 2, ptr %t2250
  %t2251 = load %"compiler/source:Span", ptr %l1159
  %t2252 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t2251, 0
  %t2253 = load ptr, ptr %l1183, !tbaa !29
  %t2254 = insertvalue { %"compiler/source:Span", ptr } %t2252, ptr %t2253, 1
  %t2255 = getelementptr { i64, [3 x i64] }, ptr %t2249, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t2254, ptr %t2255
  %t2256 = load { i64, [3 x i64] }, ptr %t2249
  %t2258 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t2256, ptr %t2258
  %t2259 = load ptr, ptr %l1158, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t2259, ptr %t2258)
  br label %bb515
bb515:
  br label %bb516
bb516:
  %t2261 = load i64, ptr %l115, !tbaa !24
  %t2263 = add i64 %t2261, 1
  store i64 %t2263, ptr %l115, !tbaa !24
  br label %bb473
bb517:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBackNoNumber(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l28 = alloca i64
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca i64
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l51 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca i64
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l66 = alloca { i64, ptr }
  %l68 = alloca %"compiler/diagmsg:Msg"
  %l69 = alloca i64
  %l71 = alloca i32
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i32
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i64
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l97 = alloca i32
  %l100 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l103 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l111 = alloca ptr
  %l113 = alloca ptr
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l126 = alloca %"compiler/diagmsg:Msg"
  %l127 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t253 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t3 = trunc i64 65 to i32
  %t4 = icmp eq i32 %t1, %t3
  store i1 %t4, ptr %l6, !tbaa !21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l13, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l14, !tbaa !24
  %t9 = load i64, ptr %l14, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l15, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l14, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t20, ptr %l7, !tbaa !27
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l20
  br label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s6
  %t30 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t32 = call i32 @compiler_2fcheck_2ecompoundOp(i32 %t30)
  store i32 %t32, ptr %l71
  br label %bb37
bb3:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t34 = load i1, ptr %l6, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb5:
  br label %bb29
bb6:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l22, !tbaa !27
  br label %bb8
bb8:
  %t40 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l28, !tbaa !24
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = icmp eq i64 %t41, %t45
  br i1 %t46, label %bb9, label %bb10
bb9:
  %t48 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = mul i64 %t52, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %t51, i64 %t53, i1 false)
  br label %bb11
bb10:
  %t54 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l30, !tbaa !24
  %t56 = load i64, ptr %l30, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l31, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l30, !tbaa !24
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t67, ptr %l7, !tbaa !27
  br label %bb11
bb11:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  %t70 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t74 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t68, i32 %t69, { i64, ptr } %t70, i64 0)
  store i64 %t74, ptr %l35
  br label %bb12
bb12:
  %t75 = load i64, ptr %l35, !tbaa !24
  %t76 = icmp slt i64 %t75, 0
  br i1 %t76, label %bb13, label %bb14
bb13:
  %t78 = load i1, ptr %l6, !tbaa !21
  br i1 %t78, label %bb15, label %bb16
bb14:
  br label %bb28
bb15:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t80, ptr %l38, !tbaa !27
  br label %bb17
bb16:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  br label %bb17
bb17:
  %t84 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l44, !tbaa !24
  %t89 = load i64, ptr %l44, !tbaa !24
  %t90 = icmp eq i64 %t85, %t89
  br i1 %t90, label %bb18, label %bb19
bb18:
  %t92 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = load i64, ptr %l44, !tbaa !24
  %t97 = mul i64 %t96, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t93, ptr %t95, i64 %t97, i1 false)
  br label %bb20
bb19:
  %t98 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l46, !tbaa !24
  %t100 = load i64, ptr %l46, !tbaa !24
  %t101 = mul i64 %t100, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l47, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l46, !tbaa !24
  %t110 = mul i64 %t109, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t106, ptr %t108, i64 %t110, i1 false)
  %t111 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t111, ptr %l7, !tbaa !27
  br label %bb20
bb20:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l3, !tbaa !23
  %t114 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t118 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t112, i32 %t113, { i64, ptr } %t114, i64 1)
  store i64 %t118, ptr %l51
  br label %bb21
bb21:
  %t119 = load i64, ptr %l51, !tbaa !24
  %t120 = icmp slt i64 %t119, 0
  br i1 %t120, label %bb22, label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l53, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t122, ptr %l54, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l56, !tbaa !24
  %t128 = load i64, ptr %l56, !tbaa !24
  %t129 = icmp eq i64 %t124, %t128
  br i1 %t129, label %bb24, label %bb25
bb23:
  br label %bb27
bb24:
  %t131 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = load i64, ptr %l56, !tbaa !24
  %t136 = mul i64 %t135, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t132, ptr %t134, i64 %t136, i1 false)
  br label %bb26
bb25:
  %t137 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  store i64 %t138, ptr %l58, !tbaa !24
  %t139 = load i64, ptr %l58, !tbaa !24
  %t140 = mul i64 %t139, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  store { i64, ptr } %t143, ptr %l59, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = mul i64 %t148, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %t147, i64 %t149, i1 false)
  %t150 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t150, ptr %l7, !tbaa !27
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t151 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t153 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s1, { i64, ptr } %t151, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t153, ptr %l61
  br label %bb30
bb30:
  %t154 = load i1, ptr %l61, !tbaa !21
  br i1 %t154, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l62, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t156, ptr %l63
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i32, ptr %l3, !tbaa !23
  %t161 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t157, i32 %t158)
  store { i64, ptr } %t161, ptr %l66
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t162 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  %t164 = extractvalue { i64, ptr } %t162, 1
  %t165 = mul i64 %t163, 1
  %t166 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t165)
  call void @llvm.memcpy.p0.p0.i64(ptr %t166, ptr %t164, i64 %t165, i1 false)
  %t167 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  %t170 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %s5, ptr %s5, { i64, ptr } %t168)
  store %"compiler/diagmsg:Msg" %t170, ptr %l68
  br label %bb34
bb34:
  %t171 = load ptr, ptr %l62, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l63
  %t173 = load %"compiler/diagmsg:Msg", ptr %l68
  %t174 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t171, %"compiler/source:Span" %t172, %"compiler/diagmsg:Msg" %t173)
  store i64 %t174, ptr %l69
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb36:
  call void @__olang_scope_close(ptr %s1)
  br label %bb62
bb37:
  %t175 = load i32, ptr %l71, !range !{i32 0, i32 98}
  store i32 %t175, ptr %l8
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l3, !tbaa !23
  %t180 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t176, i32 %t177)
  store i1 %t180, ptr %l74
  br label %bb38
bb38:
  %t181 = load i1, ptr %l74, !tbaa !21
  br i1 %t181, label %bb39, label %bb40
bb39:
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l76, !tbaa !29
  %t183 = load i32, ptr %l3, !tbaa !23
  store i32 %t183, ptr %l77, !tbaa !23
  %t184 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t186 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s6, i32 %t184)
  store { i64, ptr } %t186, ptr %l79
  br label %bb41
bb40:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb43
bb41:
  %t187 = load ptr, ptr %l76, !tbaa !29
  %t188 = load i32, ptr %l77, !tbaa !23
  %t189 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t190 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s6, ptr %t187, i32 %t188, { i64, ptr } %t189, i64 1)
  store i64 %t190, ptr %l80
  br label %bb42
bb42:
  %t191 = load i64, ptr %l80, !tbaa !24
  %t192 = icmp sge i64 %t191, 0
  store i1 %t192, ptr %l75, !tbaa !21
  br label %bb43
bb43:
  %t194 = load i1, ptr %l75, !tbaa !21
  br i1 %t194, label %bb44, label %bb45
bb44:
  %t195 = load i32, ptr %l8, !range !{i32 0, i32 98}
  %t197 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t195)
  store { i64, ptr } %t197, ptr %l83
  br label %bb46
bb45:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l4, !tbaa !29
  %t201 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t205 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t198, ptr %t199, i32 %t201)
  store ptr %t205, ptr %l94
  br label %bb50
bb46:
  %t206 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t206, ptr %l84, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t209 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  store i64 %t210, ptr %l86, !tbaa !24
  %t212 = load i64, ptr %l86, !tbaa !24
  %t213 = icmp eq i64 %t208, %t212
  br i1 %t213, label %bb47, label %bb48
bb47:
  %t215 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = load i64, ptr %l86, !tbaa !24
  %t220 = mul i64 %t219, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t216, ptr %t218, i64 %t220, i1 false)
  br label %bb49
bb48:
  %t221 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l88, !tbaa !24
  %t223 = load i64, ptr %l88, !tbaa !24
  %t224 = mul i64 %t223, 1
  %t225 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t224)
  %t226 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  store { i64, ptr } %t227, ptr %l89, !tbaa !27
  %t228 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = load i64, ptr %l88, !tbaa !24
  %t233 = mul i64 %t232, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t229, ptr %t231, i64 %t233, i1 false)
  %t234 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t234, ptr %l7, !tbaa !27
  br label %bb49
bb49:
  br label %bb61
bb50:
  %t235 = load ptr, ptr %l94, !tbaa !29
  store ptr %t235, ptr %l9, !tbaa !29
  %t236 = load ptr, ptr %l9, !tbaa !29
  %t239 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t236)
  store i32 %t239, ptr %l97
  br label %bb51
bb51:
  %t240 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t241 = load i32, ptr %l97, !tbaa !23
  %t243 = icmp ne i32 %t241, %t240
  br i1 %t243, label %bb52, label %bb53
bb52:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l101, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t246, ptr %l102
  %t247 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t247, ptr %l103
  %t248 = load i32, ptr %l8, !range !{i32 0, i32 98}
  store i32 %t248, ptr %l104
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l1
  %t251 = load %"compiler/source:Span", ptr %l1
  %t252 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t253
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t253, i32 0, i32 0
  store i64 7, ptr %t254
  %t256 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t251, 0
  %t258 = insertvalue { %"compiler/source:Span", i32 } %t256, i32 %t252, 1
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t253, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t258, ptr %t259
  %t260 = load { i64, [4 x i64] }, ptr %t253
  %t262 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t260, ptr %t262
  %t266 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t249, %"compiler/source:Span" %t250, ptr %t262)
  store ptr %t266, ptr %l111
  br label %bb54
bb53:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb56
bb54:
  %t267 = load ptr, ptr %l9, !tbaa !29
  %t268 = load ptr, ptr %l101, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l102
  %t270 = load %"compiler/source:Span", ptr %l103
  %t271 = load i32, ptr %l104, !range !{i32 0, i32 98}
  %t272 = load ptr, ptr %l111, !tbaa !29
  %t274 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t268, %"compiler/source:Span" %t269, %"compiler/source:Span" %t270, i32 %t271, ptr %t272, ptr %t267)
  store ptr %t274, ptr %l113
  br label %bb55
bb55:
  %t275 = load ptr, ptr %l113, !tbaa !29
  %t276 = icmp eq ptr %t275, null
  store i1 %t276, ptr %l100, !tbaa !21
  br label %bb56
bb56:
  %t278 = load i1, ptr %l100, !tbaa !21
  br i1 %t278, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s9
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s9, ptr %t279, %"compiler/source:Span" %t280, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb61:
  call void @__olang_scope_close(ptr %s6)
  br label %bb62
bb62:
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l117, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t284, ptr %l118
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load i32, ptr %l3, !tbaa !23
  %t289 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t285, i32 %t286)
  store { i64, ptr } %t289, ptr %l121
  br label %bb63
bb63:
  %t290 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 0
  %t292 = extractvalue { i64, ptr } %t290, 1
  %t293 = mul i64 %t291, 1
  %t294 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t293)
  call void @llvm.memcpy.p0.p0.i64(ptr %t294, ptr %t292, i64 %t293, i1 false)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  %t297 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t298 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t301 = extractvalue { i64, ptr } %t297, 1
  %t302 = extractvalue { i64, ptr } %t297, 0
  %t303 = add i64 %t299, %t302
  %t304 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t306 = add i64 %t303, %t305
  %t307 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t306)
  call void @olang_textcopy(ptr %t307, ptr %t298, i64 %t299)
  %t308 = getelementptr i8, ptr %t307, i64 %t299
  call void @olang_textcopy(ptr %t308, ptr %t301, i64 %t302)
  %t309 = getelementptr i8, ptr %t308, i64 %t302
  call void @olang_textcopy(ptr %t309, ptr %t304, i64 %t305)
  %t310 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t307, 1
  %t313 = extractvalue { i64, ptr } %t311, 0
  %t314 = extractvalue { i64, ptr } %t311, 1
  %t315 = mul i64 %t313, 1
  %t316 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t315)
  call void @llvm.memcpy.p0.p0.i64(ptr %t316, ptr %t314, i64 %t315, i1 false)
  %t317 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t316, 1
  %t321 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWriteThroughAtOperator(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t296, { i64, ptr } %t318)
  store %"compiler/diagmsg:Msg" %t321, ptr %l126
  br label %bb64
bb64:
  %t322 = load ptr, ptr %l117, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l118
  %t324 = load %"compiler/diagmsg:Msg", ptr %l126
  %t325 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t322, %"compiler/source:Span" %t323, %"compiler/diagmsg:Msg" %t324)
  store i64 %t325, ptr %l127
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2ereaches(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i1
  %l24 = alloca i32
  %l25 = alloca i1
  %l36 = alloca i64
  %l40 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l69 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca { i64, ptr }
  %l78 = alloca i1
  %l83 = alloca i1
  %l85 = alloca i1
  %l86 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l91 = alloca i1
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:collWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr @__olang_prog_scope
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t8, ptr %t6, i32 %a1)
  store i32 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load i32, ptr %l9, !tbaa !23
  store i32 %t12, ptr %l3, !tbaa !23
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t15 = load ptr, ptr @__olang_prog_scope
  %t18 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %t15, ptr %t13, i32 %t14)
  store i1 %t18, ptr %l12
  br label %bb2
bb2:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:collWalk", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l17
  br label %bb5
bb5:
  %t27 = load i1, ptr %l17, !tbaa !21
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:collWalk", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t32, i32 %t33)
  br label %bb10
bb10:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr @__olang_prog_scope
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t38, ptr %t36, i32 %t37)
  store i32 %t41, ptr %l24
  br label %bb11
bb11:
  %t42 = load i32, ptr %l24, !range !{i32 0, i32 33}
  store i32 %t42, ptr %l4
  %t43 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t45 = trunc i64 21 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  %t48 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t50 = trunc i64 25 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  %t53 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t55 = trunc i64 29 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb71
bb19:
  %t58 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t60 = trunc i64 20 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb34
bb22:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t64 = load i32, ptr %l3, !tbaa !23
  %t65 = load ptr, ptr @__olang_prog_scope
  %t68 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t65, ptr %t63, i32 %t64)
  store i64 %t68, ptr %l36
  br label %bb23
bb23:
  %t69 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t70 = load i64, ptr %l36, !tbaa !24
  %t72 = and i64 %t70, %t69
  %t74 = icmp ne i64 %t72, 0
  br i1 %t74, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l41, !tbaa !29
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t79 = load ptr, ptr @__olang_prog_scope
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t79, ptr %t77, i32 %t78)
  store i32 %t82, ptr %l44
  br label %bb26
bb25:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb28
bb26:
  %t83 = load ptr, ptr %l41, !tbaa !29
  %t84 = load i32, ptr %l44, !tbaa !23
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2eholds(ptr %v0, ptr %t83, i32 %t84, i64 0)
  store i1 %t85, ptr %l45
  br label %bb27
bb27:
  %t86 = load i1, ptr %l45, !tbaa !21
  store i1 %t86, ptr %l40, !tbaa !21
  br label %bb28
bb28:
  %t87 = load i1, ptr %l40, !tbaa !21
  br i1 %t87, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb33
bb30:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l47, !tbaa !29
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t90 = load i32, ptr %l3, !tbaa !23
  %t91 = load ptr, ptr @__olang_prog_scope
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t91, ptr %t89, i32 %t90)
  store i32 %t94, ptr %l50
  br label %bb31
bb31:
  %t95 = load ptr, ptr %l47, !tbaa !29
  %t96 = load i32, ptr %l50, !tbaa !23
  %t97 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2ereaches(ptr %v0, ptr %t95, i32 %t96)
  store i1 %t97, ptr %l51
  br label %bb32
bb32:
  %t98 = load i1, ptr %l51, !tbaa !21
  store i1 %t98, ptr %l46, !tbaa !21
  br label %bb33
bb33:
  %t99 = load i1, ptr %l46, !tbaa !21
  store i1 %t99, ptr %l25, !tbaa !21
  br label %bb71
bb34:
  %t100 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t102 = trunc i64 19 to i32
  %t103 = icmp eq i32 %t100, %t102
  br i1 %t103, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l54, !tbaa !29
  %t106 = load ptr, ptr %l2, !tbaa !29
  %t107 = load i32, ptr %l3, !tbaa !23
  %t108 = load ptr, ptr @__olang_prog_scope
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t108, ptr %t106, i32 %t107)
  store i32 %t111, ptr %l57
  br label %bb38
bb38:
  %t112 = load ptr, ptr %l54, !tbaa !29
  %t113 = load i32, ptr %l57, !tbaa !23
  %t114 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2ereaches(ptr %v0, ptr %t112, i32 %t113)
  store i1 %t114, ptr %l58
  br label %bb39
bb39:
  %t115 = load i1, ptr %l58, !tbaa !21
  store i1 %t115, ptr %l25, !tbaa !21
  br label %bb71
bb40:
  %t116 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t118 = trunc i64 22 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb41, label %bb42
bb41:
  br label %bb45
bb42:
  %t121 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t123 = trunc i64 23 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb49
bb45:
  store %olang.scope zeroinitializer, ptr %s5
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l63, !tbaa !29
  %t127 = load ptr, ptr %l2, !tbaa !29
  store ptr %t127, ptr %l64, !tbaa !29
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t129 = load i32, ptr %l3, !tbaa !23
  %t130 = load ptr, ptr @__olang_prog_scope
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t130, ptr %t128, i32 %t129)
  store i32 %t133, ptr %l67
  br label %bb46
bb46:
  %t134 = load ptr, ptr @__olang_prog_scope
  %t135 = load ptr, ptr %l64, !tbaa !29
  %t136 = load i32, ptr %l67, !tbaa !23
  %t137 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t134, ptr %s5, ptr %t135, i32 %t136)
  store { i64, ptr } %t137, ptr %l68
  br label %bb47
bb47:
  %t138 = load ptr, ptr %l63, !tbaa !29
  %t139 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t140 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esome(ptr %v0, ptr %s5, ptr %t138, { i64, ptr } %t139)
  store i1 %t140, ptr %l69
  br label %bb48
bb48:
  %t141 = load i1, ptr %l69, !tbaa !21
  store i1 %t141, ptr %l25, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb71
bb49:
  %t142 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t144 = trunc i64 24 to i32
  %t145 = icmp eq i32 %t142, %t144
  br i1 %t145, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb56
bb52:
  store %olang.scope zeroinitializer, ptr %s6
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l72, !tbaa !29
  %t148 = load ptr, ptr %l2, !tbaa !29
  store ptr %t148, ptr %l73, !tbaa !29
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t150 = load i32, ptr %l3, !tbaa !23
  %t151 = load ptr, ptr @__olang_prog_scope
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %t151, ptr %t149, i32 %t150)
  store i32 %t154, ptr %l76
  br label %bb53
bb53:
  %t155 = load ptr, ptr @__olang_prog_scope
  %t156 = load ptr, ptr %l73, !tbaa !29
  %t157 = load i32, ptr %l76, !tbaa !23
  %t158 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t155, ptr %s6, ptr %t156, i32 %t157)
  store { i64, ptr } %t158, ptr %l77
  br label %bb54
bb54:
  %t159 = load ptr, ptr %l72, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t161 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esome(ptr %v0, ptr %s6, ptr %t159, { i64, ptr } %t160)
  store i1 %t161, ptr %l78
  br label %bb55
bb55:
  %t162 = load i1, ptr %l78, !tbaa !21
  store i1 %t162, ptr %l25, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb71
bb56:
  %t163 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t165 = trunc i64 18 to i32
  %t166 = icmp eq i32 %t163, %t165
  br i1 %t166, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb66
bb59:
  store %olang.scope zeroinitializer, ptr %s7
  %t168 = load ptr, ptr %l2, !tbaa !29
  %t169 = load i32, ptr %l3, !tbaa !23
  %t170 = load ptr, ptr @__olang_prog_scope
  %t173 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %t170, ptr %t168, i32 %t169)
  store i1 %t173, ptr %l83
  br label %bb60
bb60:
  %t174 = load i1, ptr %l83, !tbaa !21
  %t175 = xor i1 %t174, true
  br i1 %t175, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb65
bb62:
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l86, !tbaa !29
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t179 = load i32, ptr %l3, !tbaa !23
  %t180 = load ptr, ptr @__olang_prog_scope
  %t183 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %t180, ptr %s7, ptr %t178, i32 %t179)
  store { i64, ptr } %t183, ptr %l89
  br label %bb63
bb63:
  %t184 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  %t186 = extractvalue { i64, ptr } %t184, 1
  %t187 = mul i64 %t185, 4
  %t188 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t191 = load ptr, ptr %l86, !tbaa !29
  %t193 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esome(ptr %v0, ptr %s7, ptr %t191, { i64, ptr } %t190)
  store i1 %t193, ptr %l91
  br label %bb64
bb64:
  %t194 = load i1, ptr %l91, !tbaa !21
  store i1 %t194, ptr %l85, !tbaa !21
  br label %bb65
bb65:
  %t195 = load i1, ptr %l85, !tbaa !21
  store i1 %t195, ptr %l25, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_a46104116b782e24_270a9dbf173892f8)
  unreachable
bb71:
  %t196 = load i1, ptr %l25, !tbaa !21
  store i1 %t196, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompoundOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = trunc i64 65 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i32 52, ptr %l1
  br label %bb49
bb4:
  %t7 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t9 = trunc i64 66 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i32 53, ptr %l1
  br label %bb49
bb8:
  %t13 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t15 = trunc i64 67 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i32 54, ptr %l1
  br label %bb49
bb12:
  %t19 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t21 = trunc i64 68 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i32 55, ptr %l1
  br label %bb49
bb16:
  %t25 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t27 = trunc i64 69 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 56, ptr %l1
  br label %bb49
bb20:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t33 = trunc i64 70 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 57, ptr %l1
  br label %bb49
bb24:
  %t37 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t39 = trunc i64 71 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i32 90, ptr %l1
  br label %bb49
bb28:
  %t43 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t45 = trunc i64 72 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i32 91, ptr %l1
  br label %bb49
bb32:
  %t49 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t51 = trunc i64 73 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i32 85, ptr %l1
  br label %bb49
bb36:
  %t55 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t57 = trunc i64 74 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i32 86, ptr %l1
  br label %bb49
bb40:
  %t61 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t63 = trunc i64 75 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i32 87, ptr %l1
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store i32 0, ptr %l1
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_20f9f67d26588f89_c77aed4cf9eaedd5)
  unreachable
bb49:
  %t68 = load i32, ptr %l1, !range !{i32 0, i32 98}
  store i32 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2edeclNames(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb36
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l19, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l5, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t30 = load ptr, ptr %l22, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load ptr, ptr %l22, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 11}
  %t36 = icmp eq i64 %t34, 8
  store i1 %t36, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t40 = getelementptr { i64, [8 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t40, i32 0, i32 1
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb22
bb12:
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t46 = call i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %t44)
  store i32 %t46, ptr %l29
  br label %bb13
bb13:
  %t47 = load i32, ptr %l29, !tbaa !23
  store i32 %t47, ptr %l7, !tbaa !23
  %t48 = load i32, ptr %l7, !tbaa !23
  %t50 = icmp ne i32 %t48, 0
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t53 = load i32, ptr %l7, !tbaa !23
  %t56 = call i1 @compiler_2fcheck_2ehasName(ptr %v1, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l35
  br label %bb16
bb15:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb17
bb16:
  %t57 = load i1, ptr %l35, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t60 = load i1, ptr %l32, !tbaa !21
  br i1 %t60, label %bb18, label %bb19
bb18:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load i32, ptr %l7, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v1, ptr %t61, i32 %t62)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %bb34
bb22:
  %t65 = load ptr, ptr %l5, !tbaa !29
  store ptr %t65, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t66 = load ptr, ptr %l39, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l39, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 11}
  %t72 = icmp eq i64 %t70, 7
  store i1 %t72, ptr %l40, !tbaa !21
  br label %bb24
bb24:
  %t73 = load i1, ptr %l40, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t74 = load ptr, ptr %l5, !tbaa !29
  %t76 = getelementptr { i64, [8 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr }, ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t80 = load ptr, ptr %l8, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2echainNames(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  br label %bb28
bb28:
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_bae3cd237d905c4d_ccae9f7ce38212b9)
  unreachable
bb34:
  br label %bb35
bb35:
  %t84 = load i64, ptr %l3, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l3, !tbaa !24
  br label %bb4
bb36:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ehandleRef(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l35 = alloca i64
  %l37 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2fcheck_2ehandleRoot(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l12
  br label %bb6
bb6:
  %t19 = load i64, ptr %l12, !tbaa !24
  store i64 %t19, ptr %rv
  br label %ret
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 6
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Call", ptr %t35, i32 0, i32 1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Call", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l25, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 0
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t53 = call i64 @compiler_2fcheck_2ehandleRef(ptr %v0, ptr %t51)
  store i64 %t53, ptr %l27
  br label %bb15
bb14:
  store i64 -1, ptr %l23, !tbaa !24
  br label %bb16
bb15:
  %t54 = load i64, ptr %l27, !tbaa !24
  store i64 %t54, ptr %l23, !tbaa !24
  br label %bb16
bb16:
  %t55 = load i64, ptr %l23, !tbaa !24
  store i64 %t55, ptr %rv
  br label %ret
bb17:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 18}
  %t63 = icmp eq i64 %t61, 17
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb19
bb19:
  %t64 = load i1, ptr %l29, !tbaa !21
  br i1 %t64, label %bb20, label %bb21
bb20:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = call i64 @compiler_2fcheck_2ehandleRef(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l35
  br label %bb23
bb23:
  %t74 = load i64, ptr %l35, !tbaa !24
  store i64 %t74, ptr %rv
  br label %ret
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_cf73afff9a9afd3c_75ef637926e6ccb8)
  unreachable
bb29:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v0, ptr %t75)
  store ptr %t77, ptr %l37
  br label %bb30
bb30:
  %t78 = load ptr, ptr %l37, !tbaa !29
  store ptr %t78, ptr %l4, !tbaa !29
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = icmp eq ptr %t79, null
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb31, label %bb32
bb31:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = call i64 @compiler_2fcheck_2ehandleRoot(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l43
  br label %bb33
bb32:
  store i64 -1, ptr %l41, !tbaa !24
  br label %bb34
bb33:
  %t88 = load i64, ptr %l43, !tbaa !24
  store i64 %t88, ptr %l41, !tbaa !24
  br label %bb34
bb34:
  %t89 = load i64, ptr %l41, !tbaa !24
  store i64 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2elitv_2eofMag(i1 %a0, i128 %a1) #0 {
entry:
  %l1 = alloca i128
  %l2 = alloca i128
  %l5 = alloca %"compiler/check:litv"
  %l14 = alloca %"compiler/check:litv"
  %l20 = alloca %"compiler/check:litv"
  %l22 = alloca %"compiler/check:litv"
  %l30 = alloca %"compiler/check:litv"
  %l35 = alloca %"compiler/check:litv"
  %l36 = alloca %"compiler/check:litv"
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  store i128 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i128, ptr %l1
  %t3 = icmp eq i128 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 0)
  store %"compiler/check:litv" %t5, ptr %l5
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load %"compiler/check:litv", ptr %l5
  store %"compiler/check:litv" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = shl i128 1, 63
  store i128 %t7, ptr %l2
  %t11 = xor i1 %a0, true
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t13 = load i128, ptr %l1
  %t14 = load i128, ptr %l2
  %t17 = icmp ult i128 %t13, %t14
  br i1 %t17, label %bb7, label %bb8
bb6:
  br label %bb16
bb7:
  %t19 = load i128, ptr %l1
  %t21 = trunc i128 %t19 to i64
  %t23 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t21)
  store %"compiler/check:litv" %t23, ptr %l14
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t24 = load %"compiler/check:litv", ptr %l14
  store %"compiler/check:litv" %t24, ptr %rv
  br label %ret
bb10:
  %t25 = load i128, ptr %l1
  %t26 = shl i128 1, 64
  %t29 = icmp ult i128 %t25, %t26
  br i1 %t29, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load i128, ptr %l1
  %t33 = trunc i128 %t31 to i64
  %t35 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s4, i1 true, i1 false, i1 true, i64 %t33, double 0x0000000000000000)
  store %"compiler/check:litv" %t35, ptr %l20
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  %t36 = load %"compiler/check:litv", ptr %l20
  store %"compiler/check:litv" %t36, ptr %rv
  br label %ret
bb14:
  %t37 = load i128, ptr %l1
  %t39 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2ewideLit(i1 false, i128 %t37)
  store %"compiler/check:litv" %t39, ptr %l22
  br label %bb15
bb15:
  %t40 = load %"compiler/check:litv", ptr %l22
  store %"compiler/check:litv" %t40, ptr %rv
  br label %ret
bb16:
  %t41 = load i128, ptr %l1
  %t42 = load i128, ptr %l2
  %t45 = icmp ule i128 %t41, %t42
  br i1 %t45, label %bb17, label %bb18
bb17:
  %t47 = load i128, ptr %l1
  %t49 = trunc i128 %t47 to i64
  %t51 = sub i64 0, %t49
  %t54 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %t51)
  store %"compiler/check:litv" %t54, ptr %l30
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t55 = load %"compiler/check:litv", ptr %l30
  store %"compiler/check:litv" %t55, ptr %rv
  br label %ret
bb20:
  %t56 = load i128, ptr %l1
  %t57 = shl i128 1, 127
  %t60 = icmp ule i128 %t56, %t57
  br i1 %t60, label %bb21, label %bb22
bb21:
  %t62 = load i128, ptr %l1
  %t64 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2ewideLit(i1 true, i128 %t62)
  store %"compiler/check:litv" %t64, ptr %l35
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t65 = load %"compiler/check:litv", ptr %l35
  store %"compiler/check:litv" %t65, ptr %rv
  br label %ret
bb24:
  %t66 = call %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
  store %"compiler/check:litv" %t66, ptr %l36
  br label %bb25
bb25:
  %t67 = load %"compiler/check:litv", ptr %l36
  store %"compiler/check:litv" %t67, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local %"compiler/check:elemsShape" @compiler_2fcheck_3aelemsShape_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/check:elemsShape"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/check:elemsShape" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/check:elemsShape" %t6, i64 %a1, 1
  store %"compiler/check:elemsShape" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:elemsShape", ptr %rv
  ret %"compiler/check:elemsShape" %rr
}

define dso_local %"compiler/check:ownerAt" @compiler_2fcheck_3aownerAt_2ector(ptr %v0, i32 %a0, i1 %a1) #0 {
entry:
  %rv = alloca %"compiler/check:ownerAt"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/check:ownerAt" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/check:ownerAt" %t6, i1 %a1, 1
  store %"compiler/check:ownerAt" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:ownerAt", ptr %rv
  ret %"compiler/check:ownerAt" %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, i32 %a4) #0 {
entry:
  %rv = alloca %"compiler/check:reflVal"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/check:reflVal" undef, i1 %a0, 0
  %t14 = insertvalue %"compiler/check:reflVal" %t12, i64 %a1, 1
  %t16 = insertvalue %"compiler/check:reflVal" %t14, i64 %a2, 2
  %t18 = insertvalue %"compiler/check:reflVal" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/check:reflVal" %t18, i32 %a4, 4
  store %"compiler/check:reflVal" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"compiler/check:altsCovered" @olang_2eHelperKind_2eCopy_2ecompiler_2fcheck_3aaltsCovered(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/check:altsCovered"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/check:altsCovered"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/check:altsCovered", ptr %a0
  store %"compiler/check:altsCovered" %t2, ptr %l1
  %t3 = getelementptr %"compiler/check:altsCovered", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/check:altsCovered", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/check:altsCovered", ptr %l1
  store %"compiler/check:altsCovered" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:altsCovered", ptr %rv
  ret %"compiler/check:altsCovered" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@__olang_empty_array = external constant [16 x i64]
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d5 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
@.d6 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"join" }>, align 8
@.d7 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Functions" }>, align 8
declare ptr @llvm.coro.promise(ptr, i32, i1)
@.d8 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
define linkonce_odr %"compiler/check:setAt" @olang_2eHelperKind_2eCopy_2ecompiler_2fcheck_3asetAt(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/check:setAt"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/check:setAt"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/check:setAt", ptr %a0
  store %"compiler/check:setAt" %t2, ptr %l1
  %t3 = getelementptr %"compiler/check:setAt", ptr %l1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/check:setAt", ptr %l1, i32 0, i32 3
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/check:setAt", ptr %l1
  store %"compiler/check:setAt" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:setAt", ptr %rv
  ret %"compiler/check:setAt" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d9 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it holds a value of " }>, align 8
@.d10 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c", which may hold an instance" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d11 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"a store through an element read of this kind (E31b)" }>, align 8
@.d12 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d13 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d14 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"'x[i] = v'" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inc" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Dec" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d23 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a compound assignment to what has no operator method (E31)" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_2196821906d7172f_ce8d1c9901dd14c3 = external constant [0 x i8]
@olang_loc_507ed937f609d1d0_9b704622aa820f34 = external constant [0 x i8]
@olang_loc_27f4d264c3bf025_5d55a961c8f61129 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_317fdf139725c543_9c9e0109f99156f7 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCopies(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v0, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderRequired(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyOfBuilderTrait(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_f1dda0dd7850fdf4_6d8deef1a8ceb3f0 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCountRange(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutOnValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMake(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, i32 %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMade(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallArgs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eatValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_76c98d42818871e4_51853c380fcafc70 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_5b6dfd884f12314a_d55d816e86cc2196 = external constant [0 x i8]
@olang_loc_fdeda218c1a4d1e1_676c59a9a8adaaad = external constant [0 x i8]
@olang_loc_7362f3ae74bf0a7_8f389ee36c95dce3 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecVoidRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecBorrow(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCStrRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstValueType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
@olang_loc_ea1bc73a77e68519_ca6969815981751d = external constant [0 x i8]
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadPatternOk(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, i64 %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eLe_Hf8109b64a4e45220d0da36a987cf38b1(ptr %v0, ptr %a0)
declare %"compiler/check:payloadItem" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2eAt_H64f851f610dd8566f1d7651b626ec99d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2eisWild(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eisBind(ptr %v0, ptr %a0)
@olang_loc_7f447623c50cbf0b_d88fa4c796e8075f = external constant [0 x i8]
declare %"compiler/check:altsCovered" @compiler_2fcheck_3aaltsCovered_2ector(ptr %v0, ptr %v1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, i1 %a1, i1 %a2, i1 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_e75bf8e677cd64fa_b74b0f73d6209566 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i1 %a3, i1 %a4)
@olang_loc_4aef7e9433005aa6_9cd0eb13e1392442 = external constant [0 x i8]
declare %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
@olang_loc_89a248f11218248d_cad7b116269b1029 = external constant [0 x i8]
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_eb46e205ba3ff6f_6cc0aaf3953c4d5b = external constant [0 x i8]
@olang_loc_b8f4ea1c8ca382ae_7341728a048bae5a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueRef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i1 %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_He56f4e53267726fe8dffcfd34146d8e6(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
@olang_loc_8ffd1bc2c5314d3c_1a7e454980bc5230 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_6754b7d1e64b38ab_d9cb88888f730d0f = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_35a8764184624626_7069e8aee12fde2 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffX(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffS(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrorSet(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eHint(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoSuchErrorWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePlainWordCalled(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2efieldNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadWordBare(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePayloadArgs(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e0fb1c8b8de5bfa7_80560e432f46ee03 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, i64 %a4, ptr %a5)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflNoMember(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartCopy(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrValueNoOp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtCompareWhat(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrRecode(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0)
declare %"compiler/check:factsMark" @compiler_2fcheck_3afactsMark_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fpair_3aPair_3ccompiler_2fgeneric_3aOrigin_2c_20I64_3e_2ector(ptr %v0, %"compiler/generic:Origin" %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_Hb1726e9607ca4add8166541fc83d3bee(ptr %v0, ptr %a0, %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_H15a1a3e8469a5976ffa48722eeacbbc7(ptr %v0, ptr %a0)
declare %"std/pair:Pair.0eea5a06f8f0107e600fd23235f2e98f" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fgeneric_Hb10eca62c04bf212a25728cfc6f83c9c(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eJoinWithoutSpawn(ptr %v0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eJoinCatchNeedsTry(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eJoinCannotFail(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i1 %a3, { i64, ptr } %a4, ptr %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eLen__H4e51b5ca7b68af485b8486164a690a5f(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_951d796b2ec85af2_4e6ca0fa0a1175d6 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eJoinClauseMustLeave(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eJoinNotTried(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, { i64, ptr } %a2)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eLaneScalar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealiasModule(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresName(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2fgeneric_2eListFunctions = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %v0, i1 %a0, i32 %a1, i64 %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fgeneric_2eListBuilders = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:reflList" @compiler_2fcheck_2ereflList_2enoList()
declare i64 @compiler_2fcheck_2elistIndex(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListFields = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListParams = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fgeneric_2eListResults = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_7b7c458ad09559c8_7a5ff3a2c3d540e4 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2efloatOverflows(i32 %a0, double %a1)
declare double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %a0)
declare i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c608509fed4a7aab_41eb2a14c072322f = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_7175167c8688a627_14932d1cc2bc03fb = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemptyArray(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullToArray(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullToNonNull(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchValueTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodNames(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_cabdf486839d2fe5_195cd685fa5544d9 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNow(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:errNarrow" @compiler_2fcheck_3aerrNarrow_2ector(ptr %v0, i32 %a0, i32 %a1, i64 %a2, i1 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2ePush_H97bb9732c658fc3569a453b270fe50d0(ptr %v0, ptr %a0, %"compiler/check:errNarrow" %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamsOn(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/check:setAt" @compiler_2fcheck_3asetAt_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, i32 %a5)
@olang_loc_9413809856381141_f41a02fc0683f50d = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eLen_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"compiler/check:idleCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2eAt_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_Hda4ef06466535e66801340e999dad217(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H87a29777ccf22aa2985fa9d3c61f9cd3(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCallDoesNothing(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atailAsk_3e_2eLen_3ccompiler_2fcheck_3atailAsk_3e(ptr %v0, ptr %a0)
declare %"compiler/check:tailAsk" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atailAsk_3e_2eAt_3ccompiler_2fcheck_3atailAsk_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBecomeErrors(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/types:DtorWalk" @compiler_2ftypes_3aDtorWalk_2ector(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aDtorWalk_2eHolds(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBecomeDestructor(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteHere(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ba4cbfec236fac31_e934563b75f0ca1d = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflTryList(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflBind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflUnbind(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/generic:AnyTable" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fgeneric_3aAnyTable_3e_2eAt__He9601a52fe5cfa5abe1b41d520aed001(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Had7920a3eff3220b2e12299d961f9124(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_3aBody_2ector(ptr %out, ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_H84397c9e89cd48160670049091ea20f1(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eRemoveAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_73788fcff98f9805_b41ea2f3f6de2ed1 = external constant [0 x i8]
@olang_loc_c2b8ccded0b87422_4b497586bdf0fd3e = external constant [0 x i8]
@olang_loc_c457ecfc87e57822_ebd31f6668a566ee = external constant [0 x i8]
@olang_loc_c596147ee3c3620c_9098292257d7bbb8 = external constant [0 x i8]
@olang_loc_cde66c6c8e102014_3203f82d8b2f03c0 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_e1df209ea46513ba_c2fba828617e051e = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_75b6f594e3a638af_f29916a598710c13 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e__H4f2a00f637999dd5fb4d6b4e8f1ae171(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/check:atRec" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2ftyped_3aExpr_26_3e__H6fdae4ec28a8e0f494e79cb375983eb8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWriteThroughAtNoSetat(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_f5f1ca6bc4d4202_a62b55a8c6b3a336 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_17f46f322b5d16b7_69863e823125c3cb = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eSetAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3)
declare %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %v0)
@olang_loc_8e17bc78d2dfbd4_98f8be4925a702f0 = external constant [0 x i8]
@olang_loc_7c9348342eb48ce3_d1653baf0fdc2fcf = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2elaneTok(i32 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinElem(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneMethodCalled(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWriteThroughAtOperator(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHoldLeaves(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowExponent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFlows(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_161638cb42cb28fe_744a250164fb3182 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
@olang_loc_d3f4fca21c1b05a5_cc4b7e60173cb869 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftInRange(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, %"compiler/source:Span" %a3)
@olang_loc_21f488b3c5e8e750_2d22ad345f3d4574 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2elocalRead(ptr %v0, ptr %a0)
@olang_loc_f30c3194d6b62caf_3ce94d7e88579503 = external constant [0 x i8]
@olang_loc_cb5bd539a2ebdd1a_6c90c646f95f810e = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_ec12a5e6811badef_17bc7d420925a003 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eP_Ha5c233616e2ae02d7fe37742cfaef2c2(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereplaceTemp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eS_H34f0b8d4004ea3d8dbd5c02acd682062(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_da0d16ec43a70817_ac9d3ce40fb81973 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einPlace(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
@olang_loc_1e80b96f97cf3962_d4e3965ce5124a3e = external constant [0 x i8]
@olang_loc_f5f2ded9311e9d81_bb624a8d0118ae7d = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@olang_loc_44f96d5c56a14674_ff860f9933920150 = external constant [0 x i8]
@olang_loc_e884266833675005_1350b544c014e651 = external constant [0 x i8]
@olang_loc_c1ca3a4930838c76_683816946b44ecaa = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTarget(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneStore(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, i64 %a5, i64 %a6, ptr %a7)
@olang_loc_ac1acea96ae6618f_a282f6741fbb5f4b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epowValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4)
declare i32 @compiler_2fcheck_2ebinaryOp(i32 %a0)
@olang_loc_eccd8b6a5c2fa6b0_78891c232bd2a45c = external constant [0 x i8]
@olang_loc_f0e5921914b2a2cf_65ed047d8124f4fb = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_a07392af54ad709a_dc39b5b43cdaa0e = external constant [0 x i8]
@olang_loc_daae6e7c52984fda_6773826fb422e0b6 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2eholds(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esome(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_a46104116b782e24_270a9dbf173892f8 = external constant [0 x i8]
@olang_loc_20f9f67d26588f89_c77aed4cf9eaedd5 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ehasName(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_bae3cd237d905c4d_ccae9f7ce38212b9 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ehandleRoot(ptr %v0, ptr %a0)
@olang_loc_cf73afff9a9afd3c_75ef637926e6ccb8 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2eintLit(i64 %a0)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2ewideLit(i1 %a0, i128 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2elitv_2enoLit()
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
